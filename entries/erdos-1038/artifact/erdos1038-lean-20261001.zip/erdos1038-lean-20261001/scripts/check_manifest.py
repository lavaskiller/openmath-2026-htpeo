#!/usr/bin/env python3
from pathlib import Path
import hashlib, json
root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'SOURCE_MANIFEST.json').read_text())
for rel,expected in manifest['sha256'].items():
 p=root/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise SystemExit('Payload checksum mismatch: '+rel)
print(f"Payload checksums passed: {len(manifest['sha256'])} files")
