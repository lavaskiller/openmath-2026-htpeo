#!/usr/bin/env python3
"""Validate the actual output of Lean's #print axioms commands."""
from pathlib import Path
import json, re, sys
root=Path(__file__).resolve().parent.parent
expected=set(json.loads((root/'verification/expected_axiom_checks.json').read_text()))
report=Path(sys.argv[1]).read_text()
allowed={'propext','Classical.choice','Quot.sound'}
found={}
for name, axioms in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",report):
 values={a.strip() for a in axioms.split(',') if a.strip()}
 if values-allowed: raise SystemExit(f'Unexpected axiom dependency in {name}: {sorted(values-allowed)}')
 found[name]=sorted(values)
for name in re.findall(r"'([^']+)' does not depend on any axioms",report):found[name]=[]
if set(found)!=expected: raise SystemExit(f'Axiom check mismatch: missing={sorted(expected-set(found))}, extra={sorted(set(found)-expected)}')
print(json.dumps({'status':'passed','theorem_count':len(found),'allowed_axioms':sorted(allowed),'checked':found},indent=2))
