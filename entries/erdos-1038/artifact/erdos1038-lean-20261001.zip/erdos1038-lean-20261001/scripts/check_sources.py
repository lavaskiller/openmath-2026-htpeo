#!/usr/bin/env python3
"""Check the self-contained local import closure and scan for proof placeholders.
The scan is a hygiene check; Lean compilation and axiom inspection are authoritative.
"""
from pathlib import Path
import hashlib, json, re
root=Path(__file__).resolve().parent.parent
lean=root/'Lean'
def mask(text):
 out=[];i=0;depth=0;quoted=False
 while i<len(text):
  if depth:
   if text.startswith('/-',i):depth+=1;out.extend('  ');i+=2
   elif text.startswith('-/',i):depth-=1;out.extend('  ');i+=2
   else:out.append('\n' if text[i]=='\n' else ' ');i+=1
  elif quoted:
   if text[i]=='\\':out.extend('  ');i+=2
   elif text[i]=='"':quoted=False;out.append(' ');i+=1
   else:out.append('\n' if text[i]=='\n' else ' ');i+=1
  elif text.startswith('--',i):
   j=text.find('\n',i);j=len(text) if j<0 else j;out.extend(' '*(j-i));i=j
  elif text.startswith('/-',i):depth=1;out.extend('  ');i+=2
  elif text[i]=='"':quoted=True;out.append(' ');i+=1
  else:out.append(text[i]);i+=1
 if depth or quoted:raise SystemExit('Unterminated comment/string during source scan')
 return ''.join(out)
files=sorted((lean/'LeanProject').glob('*.lean'))+[lean/'LeanProject.lean',lean/'Verify.lean']
modules={str(p.relative_to(lean)).replace('/','.').removesuffix('.lean'):p for p in files if p.name!='Verify.lean'}
seen=set()
def visit(m):
 if m in seen:return
 if m not in modules:raise SystemExit('Missing local module: '+m)
 seen.add(m)
 for dep in re.findall(r'^import\s+([\w.]+)',mask(modules[m].read_text()),re.M):
  if dep=='LeanProject' or dep.startswith('LeanProject.'):visit(dep)
visit('LeanProject')
if seen!=set(modules):raise SystemExit('Packaged but unimported proof modules: '+str(sorted(set(modules)-seen)))
for p in files:
 code=mask(p.read_text())
 bad=re.search(r'\b(sorry|admit|sorryAx|native_decide|axiom)\b',code)
 if bad:raise SystemExit(f'Forbidden proof placeholder/axiom in {p.relative_to(root)}: {bad[0]}')
inventory=json.loads((root/'verification/source_inventory.json').read_text())
for m,data in inventory['modules'].items():
 if hashlib.sha256((root/data['path']).read_bytes()).hexdigest()!=data['sha256']:raise SystemExit('Snapshot hash mismatch: '+m)
print(json.dumps({'status':'passed','proof_modules_including_root':len(modules),'scanned_lean_files':len(files),'local_import_closure_complete':True,'forbidden_tokens':[]},indent=2))
