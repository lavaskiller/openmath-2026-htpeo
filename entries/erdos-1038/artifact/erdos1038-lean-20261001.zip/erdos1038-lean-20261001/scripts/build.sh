#!/bin/sh
set -eu
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 "$package_dir/scripts/check_manifest.py"
python3 "$package_dir/scripts/check_sources.py"
cd "$package_dir/Lean"
# Use the committed lockfile; do not run `lake update`.
lake exe cache get
lake -q --log-level=error build LeanProject
axiom_report=$(mktemp)
trap 'rm -f "$axiom_report"' EXIT HUP INT TERM
lake env lean Verify.lean > "$axiom_report"
python3 "$package_dir/scripts/check_axioms.py" "$axiom_report"
printf '%s\n' 'Build and final theorem axiom checks passed.'
