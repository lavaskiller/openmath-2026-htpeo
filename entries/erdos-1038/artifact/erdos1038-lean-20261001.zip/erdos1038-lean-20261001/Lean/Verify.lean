import LeanProject

-- Inspect the completed reference statements and their bridges.

#check Erdos1038.erdos_1038.parts.i
#print axioms Erdos1038.erdos_1038.parts.i
#check Erdos1038.erdos_1038.parts.ii
#print axioms Erdos1038.erdos_1038.parts.ii
#check Erdos1038.erdos_1038.variants.inf_upperBound
#print axioms Erdos1038.erdos_1038.variants.inf_upperBound
#check Erdos1038.erdos_1038.varaints.inf_lowerBound
#print axioms Erdos1038.erdos_1038.varaints.inf_lowerBound
#check Erdos1038.erdos_1038.inf_nonattainment
#print axioms Erdos1038.erdos_1038.inf_nonattainment
#check Erdos1038.erdos_1038.D_enclosure
#print axioms Erdos1038.erdos_1038.D_enclosure
#check EP1038.DeepMind.filtered_roots_iff
#print axioms EP1038.DeepMind.filtered_roots_iff
#check EP1038.DeepMind.inf_admissible_iff
#print axioms EP1038.DeepMind.inf_admissible_iff
#check EP1038.DeepMind.sup_admissible_iff
#print axioms EP1038.DeepMind.sup_admissible_iff
#check EP1038.DeepMind.officialInf_eq_localInf
#print axioms EP1038.DeepMind.officialInf_eq_localInf
#check EP1038.DeepMind.officialSup_eq_localSup
#print axioms EP1038.DeepMind.officialSup_eq_localSup
#check EP1038.DeepMind.official_equality_iff
#print axioms EP1038.DeepMind.official_equality_iff
#check EP1038.ReferenceCert.COV
#print axioms EP1038.ReferenceCert.COV
#check EP1038.ReferenceCert.universal_strict_lower
#print axioms EP1038.ReferenceCert.universal_strict_lower
#check EP1038.ReferenceCert.exact_infimum_and_nonattainment
#print axioms EP1038.ReferenceCert.exact_infimum_and_nonattainment
#check EP1038.DLowerCert.actual_numerical_family_lower
#print axioms EP1038.DLowerCert.actual_numerical_family_lower
#check EP1038.DLowerCert.actual_numerical_D_enclosure
#print axioms EP1038.DLowerCert.actual_numerical_D_enclosure
#check EP1038.Stage9.sharpness
#print axioms EP1038.Stage9.sharpness
