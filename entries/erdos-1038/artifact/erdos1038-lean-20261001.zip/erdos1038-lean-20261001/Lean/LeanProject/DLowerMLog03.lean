import LeanProject.DLowerMTools
import LeanProject.DLowerMLog00
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_120 : RB (Real.log ((14501135434613163 : ℝ) / 31250000000000000)) ((-383896211993116561 : ℝ) / 500000000000000000) ((-4798702649913957 : ℝ) / 6250000000000000) := by
  have hm := log_bounds_of_series (x := ((14501135434613163 : ℝ) / 15625000000000000)) (t := ((-1123864565386837 : ℝ) / 30126135434613163))
    (lo := ((-18661310856571953 : ℝ) / 250000000000000000)) (hi := ((-74645243426287811 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14501135434613163 : ℝ) / 31250000000000000) = Real.log ((14501135434613163 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((14501135434613163 : ℝ) / 31250000000000000) = ((14501135434613163 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_121 : RB (Real.log ((117395652170149139 : ℝ) / 250000000000000000)) ((-75591104547985447 : ℝ) / 100000000000000000) ((-188977761369963617 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((117395652170149139 : ℝ) / 125000000000000000)) (t := ((-7604347829850861 : ℝ) / 242395652170149139))
    (lo := ((-1569096622997729 : ℝ) / 25000000000000000)) (hi := ((-62763864919909159 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((117395652170149139 : ℝ) / 250000000000000000) = Real.log ((117395652170149139 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((117395652170149139 : ℝ) / 250000000000000000) = ((117395652170149139 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_122 : RB (Real.log ((106003478263880689 : ℝ) / 200000000000000000)) ((-19838920598879239 : ℝ) / 31250000000000000) ((-317422729582067823 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((106003478263880689 : ℝ) / 100000000000000000)) (t := ((6003478263880689 : ℝ) / 206003478263880689))
    (lo := ((29150860697904831 : ℝ) / 500000000000000000)) (hi := ((58301721395809663 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((106003478263880689 : ℝ) / 200000000000000000) = Real.log ((106003478263880689 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((106003478263880689 : ℝ) / 200000000000000000) = ((106003478263880689 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_123 : RB (Real.log ((16733044252886837 : ℝ) / 31250000000000000)) ((-312316957012978963 : ℝ) / 500000000000000000) ((-156158478506489481 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((16733044252886837 : ℝ) / 15625000000000000)) (t := ((1108044252886837 : ℝ) / 32358044252886837))
    (lo := ((8564158316748423 : ℝ) / 125000000000000000)) (hi := ((13702653306797477 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16733044252886837 : ℝ) / 31250000000000000) = Real.log ((16733044252886837 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((16733044252886837 : ℝ) / 31250000000000000) = ((16733044252886837 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_124 : RB (Real.log ((14516955747113163 : ℝ) / 31250000000000000)) ((-191675512014267227 : ℝ) / 250000000000000000) ((-383351024028534453 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((14516955747113163 : ℝ) / 15625000000000000)) (t := ((-1108044252886837 : ℝ) / 30141955747113163))
    (lo := ((-36777433748561799 : ℝ) / 500000000000000000)) (hi := ((-73554867497123597 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14516955747113163 : ℝ) / 31250000000000000) = Real.log ((14516955747113163 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((14516955747113163 : ℝ) / 31250000000000000) = ((14516955747113163 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_125 : RB (Real.log ((93996521736119311 : ℝ) / 200000000000000000)) ((-151011917553978983 : ℝ) / 200000000000000000) ((-755059587769894913 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((93996521736119311 : ℝ) / 100000000000000000)) (t := ((-6003478263880689 : ℝ) / 193996521736119311))
    (lo := ((-12382481441989921 : ℝ) / 200000000000000000)) (hi := ((-15478101802487401 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((93996521736119311 : ℝ) / 200000000000000000) = Real.log ((93996521736119311 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((93996521736119311 : ℝ) / 200000000000000000) = ((93996521736119311 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_126 : RB (Real.log ((14502844418988163 : ℝ) / 31250000000000000)) ((-767674579167307999 : ℝ) / 1000000000000000000) ((-767674579167307997 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((14502844418988163 : ℝ) / 15625000000000000)) (t := ((-1122155581011837 : ℝ) / 30127844418988163))
    (lo := ((-74527398607362689 : ℝ) / 1000000000000000000)) (hi := ((-582245301620021 : ℝ) / 7812500000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14502844418988163 : ℝ) / 31250000000000000) = Real.log ((14502844418988163 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((14502844418988163 : ℝ) / 31250000000000000) = ((14502844418988163 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_127 : RB (Real.log ((464091021407621217 : ℝ) / 1000000000000000000)) ((-767674579167307997 : ℝ) / 1000000000000000000) ((-153534915833461599 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((464091021407621217 : ℝ) / 500000000000000000)) (t := ((-35908978592378783 : ℝ) / 964091021407621217))
    (lo := ((-74527398607362687 : ℝ) / 1000000000000000000)) (hi := ((-37263699303681343 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((464091021407621217 : ℝ) / 1000000000000000000) = Real.log ((464091021407621217 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((464091021407621217 : ℝ) / 1000000000000000000) = ((464091021407621217 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_128 : RB (Real.log ((464142583907621217 : ℝ) / 1000000000000000000)) ((-767563481056320033 : ℝ) / 1000000000000000000) ((-767563481056320031 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((464142583907621217 : ℝ) / 500000000000000000)) (t := ((-35857416092378783 : ℝ) / 964142583907621217))
    (lo := ((-74416300496374723 : ℝ) / 1000000000000000000)) (hi := ((-37208150248187361 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((464142583907621217 : ℝ) / 1000000000000000000) = Real.log ((464142583907621217 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((464142583907621217 : ℝ) / 1000000000000000000) = ((464142583907621217 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_129 : RB (Real.log ((93906209236119311 : ℝ) / 200000000000000000)) ((-151204171293958287 : ℝ) / 200000000000000000) ((-756020856469791433 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((93906209236119311 : ℝ) / 100000000000000000)) (t := ((-6093790763880689 : ℝ) / 193906209236119311))
    (lo := ((-502989407278769 : ℝ) / 8000000000000000)) (hi := ((-15718418977461531 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((93906209236119311 : ℝ) / 200000000000000000) = Real.log ((93906209236119311 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((93906209236119311 : ℝ) / 200000000000000000) = ((93906209236119311 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_130 : RB (Real.log ((117382761545149139 : ℝ) / 250000000000000000)) ((-756020856469791433 : ℝ) / 1000000000000000000) ((-756020856469791431 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((117382761545149139 : ℝ) / 125000000000000000)) (t := ((-7617238454850861 : ℝ) / 242382761545149139))
    (lo := ((-62873675909846123 : ℝ) / 1000000000000000000)) (hi := ((-31436837954923061 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((117382761545149139 : ℝ) / 250000000000000000) = Real.log ((117382761545149139 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((117382761545149139 : ℝ) / 250000000000000000) = ((117382761545149139 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_131 : RB (Real.log ((93895271736119311 : ℝ) / 200000000000000000)) ((-756137335849567817 : ℝ) / 1000000000000000000) ((-151227467169913563 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((93895271736119311 : ℝ) / 100000000000000000)) (t := ((-6104728263880689 : ℝ) / 193895271736119311))
    (lo := ((-62990155289622507 : ℝ) / 1000000000000000000)) (hi := ((-31495077644811253 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((93895271736119311 : ℝ) / 200000000000000000) = Real.log ((93895271736119311 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((93895271736119311 : ℝ) / 200000000000000000) = ((93895271736119311 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_132 : RB (Real.log ((14240880084004559 : ℝ) / 10000000000000000)) ((353531614732022557 : ℝ) / 1000000000000000000) ((353531614732022559 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((14240880084004559 : ℝ) / 20000000000000000)) (t := ((-5759119915995441 : ℝ) / 34240880084004559))
    (lo := ((-5306493216061293 : ℝ) / 15625000000000000)) (hi := ((-339615565827922751 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14240880084004559 : ℝ) / 10000000000000000) = Real.log ((14240880084004559 : ℝ) / 20000000000000000) + 1 * Real.log 2 := by
    rw [show ((14240880084004559 : ℝ) / 10000000000000000) = ((14240880084004559 : ℝ) / 20000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_133 : RB (Real.log ((712398210817551501 : ℝ) / 500000000000000000)) ((177014470752205389 : ℝ) / 500000000000000000) ((17701447075220539 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((712398210817551501 : ℝ) / 1000000000000000000)) (t := ((-287601789182448499 : ℝ) / 1712398210817551501))
    (lo := ((-339118239055534531 : ℝ) / 1000000000000000000)) (hi := ((-33911823905553453 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712398210817551501 : ℝ) / 500000000000000000) = Real.log ((712398210817551501 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712398210817551501 : ℝ) / 500000000000000000) = ((712398210817551501 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_134 : RB (Real.log ((4245942584004559 : ℝ) / 10000000000000000)) ((-428310626088667391 : ℝ) / 500000000000000000) ((-42831062608866739 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((4245942584004559 : ℝ) / 5000000000000000)) (t := ((-754057415995441 : ℝ) / 9245942584004559))
    (lo := ((-5108564738043421 : ℝ) / 31250000000000000)) (hi := ((-163474071617389471 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4245942584004559 : ℝ) / 10000000000000000) = Real.log ((4245942584004559 : ℝ) / 5000000000000000) - 1 * Real.log 2 := by
    rw [show ((4245942584004559 : ℝ) / 10000000000000000) = ((4245942584004559 : ℝ) / 5000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_135 : RB (Real.log ((425196421635103001 : ℝ) / 1000000000000000000)) ((-53450253016970469 : ℝ) / 62500000000000000) ((-427602024135763751 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((425196421635103001 : ℝ) / 500000000000000000)) (t := ((-74803578364896999 : ℝ) / 925196421635103001))
    (lo := ((-81028433855791097 : ℝ) / 500000000000000000)) (hi := ((-162056867711582193 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425196421635103001 : ℝ) / 1000000000000000000) = Real.log ((425196421635103001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425196421635103001 : ℝ) / 1000000000000000000) = ((425196421635103001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_136 : RB (Real.log ((14245942584004559 : ℝ) / 10000000000000000)) ((88471760557503267 : ℝ) / 250000000000000000) ((35388704223001307 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((14245942584004559 : ℝ) / 20000000000000000)) (t := ((-5754057415995441 : ℝ) / 34245942584004559))
    (lo := ((-339260138329932241 : ℝ) / 1000000000000000000)) (hi := ((-4240751729124153 : ℝ) / 12500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14245942584004559 : ℝ) / 10000000000000000) = Real.log ((14245942584004559 : ℝ) / 20000000000000000) + 1 * Real.log 2 := by
    rw [show ((14245942584004559 : ℝ) / 10000000000000000) = ((14245942584004559 : ℝ) / 20000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_137 : RB (Real.log ((1425196421635103001 : ℝ) / 1000000000000000000)) ((8857741099138029 : ℝ) / 25000000000000000) ((177154821982760581 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425196421635103001 : ℝ) / 2000000000000000000)) (t := ((-574803578364896999 : ℝ) / 3425196421635103001))
    (lo := ((-338837536594424149 : ℝ) / 1000000000000000000)) (hi := ((-84709384148606037 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425196421635103001 : ℝ) / 1000000000000000000) = Real.log ((1425196421635103001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425196421635103001 : ℝ) / 1000000000000000000) = ((1425196421635103001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_138 : RB (Real.log ((14241426959004559 : ℝ) / 10000000000000000)) ((2762265748160799 : ℝ) / 7812500000000000) ((176785007882291137 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((14241426959004559 : ℝ) / 20000000000000000)) (t := ((-5758573040995441 : ℝ) / 34241426959004559))
    (lo := ((-339577164795363037 : ℝ) / 1000000000000000000)) (hi := ((-84894291198840759 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14241426959004559 : ℝ) / 10000000000000000) = Real.log ((14241426959004559 : ℝ) / 20000000000000000) + 1 * Real.log 2 := by
    rw [show ((14241426959004559 : ℝ) / 10000000000000000) = ((14241426959004559 : ℝ) / 20000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_139 : RB (Real.log ((1424142695900455901 : ℝ) / 1000000000000000000)) ((353570015764582273 : ℝ) / 1000000000000000000) ((14142800630583291 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424142695900455901 : ℝ) / 2000000000000000000)) (t := ((-575857304099544099 : ℝ) / 3424142695900455901))
    (lo := ((-84894291198840759 : ℝ) / 250000000000000000)) (hi := ((-67915432959072607 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424142695900455901 : ℝ) / 1000000000000000000) = Real.log ((1424142695900455901 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424142695900455901 : ℝ) / 1000000000000000000) = ((1424142695900455901 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_140 : RB (Real.log ((1424194258400455901 : ℝ) / 1000000000000000000)) ((353606221101824957 : ℝ) / 1000000000000000000) ((353606221101824959 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424194258400455901 : ℝ) / 2000000000000000000)) (t := ((-575805741599544099 : ℝ) / 3424194258400455901))
    (lo := ((-10610654983066261 : ℝ) / 31250000000000000)) (hi := ((-339540959458120351 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424194258400455901 : ℝ) / 1000000000000000000) = Real.log ((1424194258400455901 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424194258400455901 : ℝ) / 1000000000000000000) = ((1424194258400455901 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_141 : RB (Real.log ((1424744859135103001 : ℝ) / 1000000000000000000)) ((88498187867236339 : ℝ) / 250000000000000000) ((176996375734472679 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424744859135103001 : ℝ) / 2000000000000000000)) (t := ((-575255140864896999 : ℝ) / 3424744859135103001))
    (lo := ((-339154429090999953 : ℝ) / 1000000000000000000)) (hi := ((-21197151818187497 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424744859135103001 : ℝ) / 1000000000000000000) = Real.log ((1424744859135103001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424744859135103001 : ℝ) / 1000000000000000000) = ((1424744859135103001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_142 : RB (Real.log ((712372429567551501 : ℝ) / 500000000000000000)) ((353992751468945357 : ℝ) / 1000000000000000000) ((353992751468945359 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712372429567551501 : ℝ) / 1000000000000000000)) (t := ((-287627570432448499 : ℝ) / 1712372429567551501))
    (lo := ((-21197151818187497 : ℝ) / 62500000000000000)) (hi := ((-339154429090999951 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712372429567551501 : ℝ) / 500000000000000000) = Real.log ((712372429567551501 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712372429567551501 : ℝ) / 500000000000000000) = ((712372429567551501 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_143 : RB (Real.log ((1424690171635103001 : ℝ) / 1000000000000000000)) ((88488591666688483 : ℝ) / 250000000000000000) ((176977183333376967 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424690171635103001 : ℝ) / 2000000000000000000)) (t := ((-575309828364896999 : ℝ) / 3424690171635103001))
    (lo := ((-339192813893191377 : ℝ) / 1000000000000000000)) (hi := ((-21199550868324461 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424690171635103001 : ℝ) / 1000000000000000000) = Real.log ((1424690171635103001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424690171635103001 : ℝ) / 1000000000000000000) = ((1424690171635103001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_144 : RB (Real.log ((23749999999999999 : ℝ) / 1000000000000000000)) ((-23376079678134293 : ℝ) / 6250000000000000) ((-1870086374250743439 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((23749999999999999 : ℝ) / 31250000000000000)) (t := ((-7500000000000001 : ℝ) / 54999999999999999))
    (lo := ((-68609211425440083 : ℝ) / 250000000000000000)) (hi := ((-274436845701760331 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23749999999999999 : ℝ) / 1000000000000000000) = Real.log ((23749999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((23749999999999999 : ℝ) / 1000000000000000000) = ((23749999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_145 : RB (Real.log ((19 : ℝ) / 800)) ((-1870086374250743419 : ℝ) / 500000000000000000) ((-935043187125371709 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((19 : ℝ) / 25)) (t := ((-3 : ℝ) / 22))
    (lo := ((-27443684570176029 : ℝ) / 100000000000000000)) (hi := ((-274436845701760289 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19 : ℝ) / 800) = Real.log ((19 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((19 : ℝ) / 800) = ((19 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_146 : RB (Real.log ((1023749999999999999 : ℝ) / 1000000000000000000)) ((11736178092571063 : ℝ) / 500000000000000000) ((23472356185142127 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1023749999999999999 : ℝ) / 1000000000000000000)) (t := ((23749999999999999 : ℝ) / 2023749999999999999))
    (lo := ((11736178092571063 : ℝ) / 500000000000000000)) (hi := ((23472356185142127 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_147 : RB (Real.log ((819 : ℝ) / 800)) ((23472356185142127 : ℝ) / 1000000000000000000) ((1467022261571383 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((819 : ℝ) / 800)) (t := ((19 : ℝ) / 1619))
    (lo := ((23472356185142127 : ℝ) / 1000000000000000000)) (hi := ((1467022261571383 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_148 : RB (Real.log ((22499999999999999 : ℝ) / 1000000000000000000)) ((-75884799395435253 : ℝ) / 20000000000000000) ((-474279996221470331 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((22499999999999999 : ℝ) / 31250000000000000)) (t := ((-8750000000000001 : ℝ) / 53749999999999999))
    (lo := ((-164252033486018051 : ℝ) / 500000000000000000)) (hi := ((-328504066972036101 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22499999999999999 : ℝ) / 1000000000000000000) = Real.log ((22499999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((22499999999999999 : ℝ) / 1000000000000000000) = ((22499999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_149 : RB (Real.log ((1 : ℝ) / 40)) ((-230554965882121019 : ℝ) / 62500000000000000) ((-1844439727056968151 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((4 : ℝ) / 5)) (t := ((-1 : ℝ) / 9))
    (lo := ((-55785887828552439 : ℝ) / 250000000000000000)) (hi := ((-44628710262841951 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 40) = Real.log ((4 : ℝ) / 5) - 5 * Real.log 2 := by
    rw [show ((1 : ℝ) / 40) = ((4 : ℝ) / 5) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_150 : RB (Real.log ((1022499999999999999 : ℝ) / 1000000000000000000)) ((22250608934819757 : ℝ) / 1000000000000000000) ((11125304467409879 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1022499999999999999 : ℝ) / 1000000000000000000)) (t := ((22499999999999999 : ℝ) / 2022499999999999999))
    (lo := ((22250608934819757 : ℝ) / 1000000000000000000)) (hi := ((11125304467409879 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_151 : RB (Real.log ((41 : ℝ) / 40)) ((24692612590371501 : ℝ) / 1000000000000000000) ((12346306295185751 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((41 : ℝ) / 40)) (t := ((1 : ℝ) / 81))
    (lo := ((24692612590371501 : ℝ) / 1000000000000000000)) (hi := ((12346306295185751 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_152 : RB (Real.log ((231148004955469 : ℝ) / 500000000000000)) ((-771549878977101211 : ℝ) / 1000000000000000000) ((-771549878977101209 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((231148004955469 : ℝ) / 250000000000000)) (t := ((-18851995044531 : ℝ) / 481148004955469))
    (lo := ((-78402698417155901 : ℝ) / 1000000000000000000)) (hi := ((-784026984171559 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((231148004955469 : ℝ) / 500000000000000) = Real.log ((231148004955469 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((231148004955469 : ℝ) / 500000000000000) = ((231148004955469 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_153 : RB (Real.log ((462296009910941001 : ℝ) / 1000000000000000000)) ((-2411093371803421 : ℝ) / 3125000000000000) ((-385774939488547359 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((462296009910941001 : ℝ) / 500000000000000000)) (t := ((-37703990089058999 : ℝ) / 962296009910941001))
    (lo := ((-7840269841714941 : ℝ) / 100000000000000000)) (hi := ((-78402698417149409 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((462296009910941001 : ℝ) / 1000000000000000000) = Real.log ((462296009910941001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((462296009910941001 : ℝ) / 1000000000000000000) = ((462296009910941001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_154 : RB (Real.log ((537139927589059 : ℝ) / 1000000000000000)) ((-62149664562492213 : ℝ) / 100000000000000000) ((-38843540351557633 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((537139927589059 : ℝ) / 500000000000000)) (t := ((37139927589059 : ℝ) / 1037139927589059))
    (lo := ((3582526746751159 : ℝ) / 50000000000000000)) (hi := ((71650534935023181 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((537139927589059 : ℝ) / 1000000000000000) = Real.log ((537139927589059 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((537139927589059 : ℝ) / 1000000000000000) = ((537139927589059 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_155 : RB (Real.log ((268569963794531 : ℝ) / 500000000000000)) ((-124299329124983309 : ℝ) / 200000000000000000) ((-621496645624916543 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((268569963794531 : ℝ) / 250000000000000)) (t := ((18569963794531 : ℝ) / 518569963794531))
    (lo := ((14330106987005753 : ℝ) / 200000000000000000)) (hi := ((35825267467514383 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((268569963794531 : ℝ) / 500000000000000) = Real.log ((268569963794531 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((268569963794531 : ℝ) / 500000000000000) = ((268569963794531 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_156 : RB (Real.log ((231430036205469 : ℝ) / 500000000000000)) ((-96291311248526797 : ℝ) / 125000000000000000) ((-385165244994107187 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((231430036205469 : ℝ) / 250000000000000)) (t := ((-18569963794531 : ℝ) / 481430036205469))
    (lo := ((-38591654714134533 : ℝ) / 500000000000000000)) (hi := ((-15436661885653813 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((231430036205469 : ℝ) / 500000000000000) = Real.log ((231430036205469 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((231430036205469 : ℝ) / 500000000000000) = ((231430036205469 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_157 : RB (Real.log ((462860072410941 : ℝ) / 1000000000000000)) ((-385165244994103947 : ℝ) / 500000000000000000) ((-192582622497051973 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((462860072410941 : ℝ) / 500000000000000)) (t := ((-37139927589059 : ℝ) / 962860072410941))
    (lo := ((-9647913678532823 : ℝ) / 125000000000000000)) (hi := ((-77183309428262583 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((462860072410941 : ℝ) / 1000000000000000) = Real.log ((462860072410941 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((462860072410941 : ℝ) / 1000000000000000) = ((462860072410941 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_158 : RB (Real.log ((462296009910938001 : ℝ) / 1000000000000000000)) ((-771549878977101209 : ℝ) / 1000000000000000000) ((-771549878977101207 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((462296009910938001 : ℝ) / 500000000000000000)) (t := ((-37703990089061999 : ℝ) / 962296009910938001))
    (lo := ((-78402698417155899 : ℝ) / 1000000000000000000)) (hi := ((-39201349208577949 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((462296009910938001 : ℝ) / 1000000000000000000) = Real.log ((462296009910938001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((462296009910938001 : ℝ) / 1000000000000000000) = ((462296009910938001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_159 : RB (Real.log ((462296009910941 : ℝ) / 1000000000000000)) ((-385774939488547361 : ℝ) / 500000000000000000) ((-2411093371803421 : ℝ) / 3125000000000000) := by
  have hm := log_bounds_of_series (x := ((462296009910941 : ℝ) / 500000000000000)) (t := ((-37703990089059 : ℝ) / 962296009910941))
    (lo := ((-19600674604287353 : ℝ) / 250000000000000000)) (hi := ((-78402698417149411 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((462296009910941 : ℝ) / 1000000000000000) = Real.log ((462296009910941 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((462296009910941 : ℝ) / 1000000000000000) = ((462296009910941 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
