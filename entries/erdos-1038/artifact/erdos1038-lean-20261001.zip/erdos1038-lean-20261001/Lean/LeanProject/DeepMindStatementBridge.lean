import LeanProject.DeepMindBoundsBridge
import LeanProject.DeepMindInfimumBridge

/-!
# Bridges to the Erdős 1038 statements in Formal Conjectures

The original statement heads are recorded in
`../../reference_statements/DeepMind_1038.lean` (Apache-2.0).
This module imports no `sorry`-containing reference file.

The supremum and classical lower-bound statements have unconditional proofs.
The exact infimum and the upper-bound variant are connected to explicit proof
obligations; neither of these outstanding obligations is assumed implicitly.
-/

open MeasureTheory
open scoped Real ENNReal

namespace EP1038.DeepMind

/-- The supremum bound is exactly the pointwise bound in the local model. -/
theorem officialSup_le_iff (b : ℝ≥0∞) :
    officialSup ≤ b ↔
      ∀ p : Polynomial ℝ, EP1038.Admissible p → EP1038.sublevelMeasure p ≤ b := by
  rw [officialSup_eq_localSup]
  constructor
  · intro h p hp
    exact (le_iSup_of_le (⟨p, hp⟩ : {p : Polynomial ℝ // EP1038.Admissible p})
      (le_refl (EP1038.sublevelMeasure p))).trans h
  · intro h
    exact iSup_le fun p => h p.1 p.2

/-- The infimum bound is exactly the pointwise bound in the local model. -/
theorem le_officialInf_iff (b : ℝ≥0∞) :
    b ≤ officialInf ↔
      ∀ p : Polynomial ℝ, EP1038.Admissible p → b ≤ EP1038.sublevelMeasure p := by
  rw [officialInf_eq_localInf]
  constructor
  · intro h p hp
    exact h.trans (iInf_le_of_le
      (⟨p, hp⟩ : {p : Polynomial ℝ // EP1038.Admissible p})
      (le_refl (EP1038.sublevelMeasure p)))
  · intro h
    exact le_iInf fun p => h p.1 p.2

/-- With the proved upper direction, strictness is equivalent to exactness
and nonattainment. This is an equivalence of remaining obligations. -/
theorem strict_lower_iff_exact_inf_and_nonattainment :
    (∀ p : Polynomial ℝ, InfAdmissible p →
      ENNReal.ofReal EP1038.Stage9.Dval < volume {x : ℝ | |p.eval x| < 1}) ↔
      (officialInf = ENNReal.ofReal EP1038.Stage9.Dval ∧
        ∀ p : Polynomial ℝ, InfAdmissible p →
          volume {x : ℝ | |p.eval x| < 1} ≠ officialInf) := by
  constructor
  · exact strict_lower_implies_exact_inf_and_nonattainment
  · rintro ⟨heq, hnot⟩ p hp
    have hbound := officialInf_eq_D_iff.mp heq p hp
    rcases lt_or_eq_of_le hbound with hlt | he
    · exact hlt
    · exact False.elim (hnot p hp (he.symm.trans heq.symm))

end EP1038.DeepMind

namespace Erdos1038

set_option linter.unusedVariables false in
/-- The exact supremum statement from the reference file, with its proof filled. -/
theorem erdos_1038.parts.ii (n : ℕ) : 2 * 2 ^ (1 / 2 : ℝ) =
    ⨆ f : {f : Polynomial ℝ // f.Monic ∧
      (f.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1).card = f.natDegree},
      volume {x | |f.1.eval x| < 1} := by
  simpa only [EP1038.DeepMind.officialSup, EP1038.DeepMind.SupAdmissible]
    using EP1038.DeepMind.officialSup_eq.symm

set_option linter.unusedVariables false in
/-- The exact reference lower-bound statement (including its original name). -/
theorem erdos_1038.varaints.inf_lowerBound (n : ℕ) : 2 ^ (4 / 3 : ℝ) - 1 ≤
    ⨅ f : {f : Polynomial ℝ // f.Monic ∧ f ≠ 1 ∧
      (f.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1).card = f.natDegree},
      volume {x | |f.1.eval x| < 1} := by
  simpa only [EP1038.DeepMind.officialInf, EP1038.DeepMind.InfAdmissible]
    using EP1038.DeepMind.officialInf_lowerBound

set_option linter.unusedVariables false in
/-- The official upper-bound variant is equivalent to a witness in the local class.
This proves the equivalence, without asserting that the witness has been constructed. -/
theorem erdos_1038.variants.inf_upperBound_iff_exists (n : ℕ) :
    ((⨅ f : {f : Polynomial ℝ // f.Monic ∧ f ≠ 1 ∧
      (f.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1).card = f.natDegree},
      volume {x | |f.1.eval x| < 1}) < 1.835) ↔
      ∃ p : Polynomial ℝ, EP1038.Admissible p ∧
        EP1038.sublevelMeasure p < 1.835 := by
  change EP1038.DeepMind.officialInf < (1.835 : ℝ≥0∞) ↔ _
  rw [EP1038.DeepMind.officialInf_lt_iff]
  constructor
  · rintro ⟨p, hp, hmeasure⟩
    exact ⟨p, (EP1038.DeepMind.inf_admissible_iff p).mp hp, hmeasure⟩
  · rintro ⟨p, hp, hmeasure⟩
    exact ⟨p, (EP1038.DeepMind.inf_admissible_iff p).mpr hp, hmeasure⟩

set_option linter.unusedVariables false in
/-- Filling the official unknown answer with `Dval` is equivalent to the remaining
universal lower bound, because the opposite infimum bound is already proved. -/
theorem erdos_1038.parts.i_iff_lowerBound (n : ℕ) :
    (ENNReal.ofReal EP1038.Stage9.Dval =
      ⨅ f : {f : Polynomial ℝ // f.Monic ∧ f ≠ 1 ∧
        (f.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1).card = f.natDegree},
        volume {x | |f.1.eval x| < 1}) ↔
      ∀ p : Polynomial ℝ, EP1038.Admissible p →
        ENNReal.ofReal EP1038.Stage9.Dval ≤ EP1038.sublevelMeasure p := by
  change (ENNReal.ofReal EP1038.Stage9.Dval = EP1038.DeepMind.officialInf) ↔ _
  constructor
  · intro h p hp
    exact EP1038.DeepMind.officialInf_eq_D_iff.mp h.symm p
      ((EP1038.DeepMind.inf_admissible_iff p).mpr hp)
  · intro h
    apply Eq.symm
    apply EP1038.DeepMind.officialInf_eq_D_iff.mpr
    intro p hp
    exact h p ((EP1038.DeepMind.inf_admissible_iff p).mp hp)

end Erdos1038
