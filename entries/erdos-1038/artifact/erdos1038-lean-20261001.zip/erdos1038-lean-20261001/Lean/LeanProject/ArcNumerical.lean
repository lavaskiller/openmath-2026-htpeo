import LeanProject.CertificateArithmetic

/-! Kernel-checked trigonometric and finite-energy bounds used by the full cover. -/
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc

theorem sin_sq_shift_pi (x : ℝ) (m : ℕ) :
    Real.sin x ^ 2 = Real.sin (x - m * π) ^ 2 := by
  have h := Real.sin_add_nat_mul_pi (x - m * π) m
  rw [show x - m * π + m * π = x by ring] at h
  rw [h, mul_pow, ← pow_mul, Nat.mul_comm m 2, pow_mul]
  norm_num

theorem sin_sq_shift_half_pi (x : ℝ) (m : ℕ) :
    Real.sin x ^ 2 = Real.cos (x - (m + (1 : ℝ) / 2) * π) ^ 2 := by
  have h := Real.sin_add_nat_mul_pi (x - (m + (1 : ℝ) / 2) * π + π / 2) m
  rw [show x - (m + (1 : ℝ) / 2) * π + π / 2 + m * π = x by ring] at h
  rw [Real.sin_add_pi_div_two] at h
  rw [h, mul_pow, ← pow_mul, Nat.mul_comm m 2, pow_mul]
  norm_num

theorem sin_sq_upper_small {x l u : ℝ} (h : RB |x| l u) (hl : 0 ≤ l) (hu : u ≤ 1) :
    Real.sin x ^ 2 ≤ (u - l ^ 3 / 6 + u ^ 5 / 100) ^ 2 := by
  have hu0 : 0 ≤ u := (abs_nonneg x).trans h.2
  have hx := h.2.trans hu
  have hx2 : x ^ 2 ≤ 1 := by
    have hh := pow_le_pow_left₀ (abs_nonneg x) hx 2
    simpa using hh
  have he : |x - x ^ 3 / 6| = |x| - |x| ^ 3 / 6 := by
    rw [show x - x ^ 3 / 6 = x * (1 - x ^ 2 / 6) by ring, abs_mul,
      abs_of_nonneg (by linarith : (0 : ℝ) ≤ 1 - x ^ 2 / 6)]
    rw [show x ^ 2 = |x| ^ 2 by simp]
    ring
  have hb := Real.sin_bound hx
  have ht : |Real.sin x| ≤ |Real.sin x - (x - x ^ 3 / 6)| + |x - x ^ 3 / 6| := by
    convert abs_add_le (Real.sin x - (x - x ^ 3 / 6)) (x - x ^ 3 / 6) using 1 <;> ring
  rw [he] at ht
  have hc := pow_le_pow_left₀ hl h.1 3
  have hu5 := pow_le_pow_left₀ (abs_nonneg x) h.2 5
  have hb' : |Real.sin x| ≤ u - l ^ 3 / 6 + u ^ 5 / 100 := by linarith [h.2]
  have hh := pow_le_pow_left₀ (abs_nonneg (Real.sin x)) hb' 2
  simpa using hh

theorem cos_sq_upper_small {x l u : ℝ} (h : RB |x| l u) (hl : 0 ≤ l) (hu : u ≤ 1) :
    Real.cos x ^ 2 ≤ (1 - l ^ 2 / 2 + u ^ 4 * (5 / 96)) ^ 2 := by
  have hx := h.2.trans hu
  have hxI : x ∈ Icc (-(π / 2)) (π / 2) := by
    rw [abs_le] at hx
    constructor <;> linarith [Real.pi_gt_d4]
  have hc0 := Real.cos_nonneg_of_mem_Icc hxI
  have hb := (abs_le.mp (Real.cos_bound hx)).2
  have hl2 := pow_le_pow_left₀ hl h.1 2
  have hu4 := pow_le_pow_left₀ (abs_nonneg x) h.2 4
  have he : |x| ^ 2 = x ^ 2 := by simp
  rw [he] at hl2
  have hh : Real.cos x ≤ 1 - l ^ 2 / 2 + u ^ 4 * (5 / 96) := by linarith
  exact pow_le_pow_left₀ hc0 hh 2

theorem hfun_lower_finite {X b l : ℝ} (hX : 0 < X) {N : ℕ} (hN : 1 ≤ N)
    (hb : (∑ n ∈ range N, tq X n) ≤ b) (hl : l ≤ Real.log (π / X)) :
    l - b - 1 / (2 * (N : ℝ) ^ 2 * X ^ 2) ≤ hfun X := by
  have ht := (AE_tail hX hN).1
  have he : Real.log (X / π) = -Real.log (π / X) := by
    rw [Real.log_div hX.ne' Real.pi_pos.ne', Real.log_div Real.pi_pos.ne' hX.ne']
    ring
  unfold hfun
  rw [he]
  linarith

theorem sinc_lower_near_half_pi {X u lo : ℝ} (hX : 0 < X) (hu : 0 ≤ u)
    (hx : |X - π / 2| ≤ u) (hlo : lo * X ≤ 1 - u ^ 2 / 2) :
    lo ≤ EP1038.Arc.sinc X := by
  have hs := pow_le_pow_left₀ (abs_nonneg (X - π / 2)) hx 2
  simp only [sq_abs] at hs
  have hc := Real.one_sub_sq_div_two_le_cos (x := X - π / 2)
  have he : Real.cos (X - π / 2) = Real.sin X := by
    rw [Real.cos_sub, Real.cos_pi_div_two, Real.sin_pi_div_two]
    ring
  rw [he] at hc
  unfold EP1038.Arc.sinc
  apply (le_div_iff₀ hX).mpr
  linarith

end EP1038.ReferenceCert
