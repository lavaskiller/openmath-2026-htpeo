import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog08
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_660 : RB (Real.log ((893389 : ℝ) / 800000)) ((5520518433 : ℝ) / 50000000000) ((110410368661 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((893389 : ℝ) / 800000)) (t := ((93389 : ℝ) / 1693389))
    (lo := ((5520518433 : ℝ) / 50000000000)) (hi := ((110410368661 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_661 : RB (Real.log ((115585624999 : ℝ) / 1000000000000)) ((-2157743681697 : ℝ) / 1000000000000) ((-431548736339 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((115585624999 : ℝ) / 125000000000)) (t := ((-9414375001 : ℝ) / 240585624999))
    (lo := ((-78302140017 : ℝ) / 1000000000000)) (hi := ((-4893883751 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((115585624999 : ℝ) / 1000000000000) = Real.log ((115585624999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((115585624999 : ℝ) / 1000000000000) = ((115585624999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_662 : RB (Real.log ((93389 : ℝ) / 800000)) ((-2147838162389 : ℝ) / 1000000000000) ((-2147838162387 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((93389 : ℝ) / 100000)) (t := ((-6611 : ℝ) / 193389))
    (lo := ((-68396620709 : ℝ) / 1000000000000)) (hi := ((-17099155177 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((93389 : ℝ) / 800000) = Real.log ((93389 : ℝ) / 100000) - 3 * Real.log 2 := by
    rw [show ((93389 : ℝ) / 800000) = ((93389 : ℝ) / 100000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_663 : RB (Real.log ((42612366659 : ℝ) / 125000000000)) ((-1076169228997 : ℝ) / 1000000000000) ((-1076169228993 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((42612366659 : ℝ) / 62500000000)) (t := ((-19887633341 : ℝ) / 105112366659))
    (lo := ((-383022048437 : ℝ) / 1000000000000)) (hi := ((-191511024217 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42612366659 : ℝ) / 125000000000) = Real.log ((42612366659 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((42612366659 : ℝ) / 125000000000) = ((42612366659 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_664 : RB (Real.log ((42657791033 : ℝ) / 125000000000)) ((-268775951589 : ℝ) / 250000000000) ((-67193987897 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((42657791033 : ℝ) / 62500000000)) (t := ((-19842208967 : ℝ) / 105157791033))
    (lo := ((-95489156449 : ℝ) / 250000000000)) (hi := ((-381956625793 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42657791033 : ℝ) / 125000000000) = Real.log ((42657791033 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((42657791033 : ℝ) / 125000000000) = ((42657791033 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_665 : RB (Real.log ((132197243409 : ℝ) / 500000000000)) ((-665156511447 : ℝ) / 500000000000) ((-332578255723 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((132197243409 : ℝ) / 125000000000)) (t := ((7197243409 : ℝ) / 257197243409))
    (lo := ((27990669113 : ℝ) / 500000000000)) (hi := ((55981338227 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((132197243409 : ℝ) / 500000000000) = Real.log ((132197243409 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((132197243409 : ℝ) / 500000000000) = ((132197243409 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_666 : RB (Real.log ((3059020912497 : ℝ) / 1000000000000)) ((1118094901527 : ℝ) / 1000000000000) ((1118094901529 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3059020912497 : ℝ) / 4000000000000)) (t := ((-940979087503 : ℝ) / 7059020912497))
    (lo := ((-33524932449 : ℝ) / 125000000000)) (hi := ((-268199459591 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3059020912497 : ℝ) / 1000000000000) = Real.log ((3059020912497 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3059020912497 : ℝ) / 1000000000000) = ((3059020912497 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_667 : RB (Real.log ((19122368279 : ℝ) / 6250000000)) ((1118277300167 : ℝ) / 1000000000000) ((1118277300169 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((19122368279 : ℝ) / 25000000000)) (t := ((-5877631721 : ℝ) / 44122368279))
    (lo := ((-33502132619 : ℝ) / 125000000000)) (hi := ((-268017060951 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19122368279 : ℝ) / 6250000000) = Real.log ((19122368279 : ℝ) / 25000000000) + 2 * Real.log 2 := by
    rw [show ((19122368279 : ℝ) / 6250000000) = ((19122368279 : ℝ) / 25000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_668 : RB (Real.log ((1479049358823 : ℝ) / 1000000000000)) ((97849889069 : ℝ) / 250000000000) ((195699778139 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1479049358823 : ℝ) / 2000000000000)) (t := ((-520950641177 : ℝ) / 3479049358823))
    (lo := ((-301747624283 : ℝ) / 1000000000000)) (hi := ((-150873812141 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1479049358823 : ℝ) / 1000000000000) = Real.log ((1479049358823 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1479049358823 : ℝ) / 1000000000000) = ((1479049358823 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_669 : RB (Real.log ((1116736249999 : ℝ) / 1000000000000)) ((110410368659 : ℝ) / 1000000000000) ((5520518433 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((1116736249999 : ℝ) / 1000000000000)) (t := ((116736249999 : ℝ) / 2116736249999))
    (lo := ((110410368659 : ℝ) / 1000000000000)) (hi := ((5520518433 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_670 : RB (Real.log ((1788619 : ℝ) / 1600000)) ((111440184461 : ℝ) / 1000000000000) ((55720092231 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1788619 : ℝ) / 1600000)) (t := ((188619 : ℝ) / 3388619))
    (lo := ((111440184461 : ℝ) / 1000000000000)) (hi := ((55720092231 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_671 : RB (Real.log ((116736249999 : ℝ) / 1000000000000)) ((-2147838162397 : ℝ) / 1000000000000) ((-429567632479 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((116736249999 : ℝ) / 125000000000)) (t := ((-8263750001 : ℝ) / 241736249999))
    (lo := ((-68396620717 : ℝ) / 1000000000000)) (hi := ((-17099155179 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((116736249999 : ℝ) / 1000000000000) = Real.log ((116736249999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((116736249999 : ℝ) / 1000000000000) = ((116736249999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_672 : RB (Real.log ((188619 : ℝ) / 1600000)) ((-267253725099 : ℝ) / 125000000000) ((-213802980079 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((188619 : ℝ) / 200000)) (t := ((-11381 : ℝ) / 388619))
    (lo := ((-7323532389 : ℝ) / 125000000000)) (hi := ((-58588259111 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((188619 : ℝ) / 1600000) = Real.log ((188619 : ℝ) / 200000) - 3 * Real.log 2 := by
    rw [show ((188619 : ℝ) / 1600000) = ((188619 : ℝ) / 200000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_673 : RB (Real.log ((8743360087 : ℝ) / 25000000000)) ((-105058125977 : ℝ) / 100000000000) ((-1050581259767 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((8743360087 : ℝ) / 12500000000)) (t := ((-3756639913 : ℝ) / 21243360087))
    (lo := ((-35743407921 : ℝ) / 100000000000)) (hi := ((-44679259901 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8743360087 : ℝ) / 25000000000) = Real.log ((8743360087 : ℝ) / 12500000000) - 1 * Real.log 2 := by
    rw [show ((8743360087 : ℝ) / 25000000000) = ((8743360087 : ℝ) / 12500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_674 : RB (Real.log ((175051958699 : ℝ) / 500000000000)) ((-262381315429 : ℝ) / 250000000000) ((-524762630857 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((175051958699 : ℝ) / 250000000000)) (t := ((-74948041301 : ℝ) / 425051958699))
    (lo := ((-89094520289 : ℝ) / 250000000000)) (hi := ((-71275616231 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((175051958699 : ℝ) / 500000000000) = Real.log ((175051958699 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((175051958699 : ℝ) / 500000000000) = ((175051958699 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_675 : RB (Real.log ((3367622899 : ℝ) / 12500000000)) ((-1311521520053 : ℝ) / 1000000000000) ((-1311521520051 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3367622899 : ℝ) / 3125000000)) (t := ((242622899 : ℝ) / 6492622899))
    (lo := ((74772841067 : ℝ) / 1000000000000)) (hi := ((18693210267 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3367622899 : ℝ) / 12500000000) = Real.log ((3367622899 : ℝ) / 3125000000) - 2 * Real.log 2 := by
    rw [show ((3367622899 : ℝ) / 12500000000) = ((3367622899 : ℝ) / 3125000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_676 : RB (Real.log ((3053933311721 : ℝ) / 1000000000000)) ((223286074037 : ℝ) / 200000000000) ((1116430370187 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3053933311721 : ℝ) / 4000000000000)) (t := ((-946066688279 : ℝ) / 7053933311721))
    (lo := ((-134931995467 : ℝ) / 500000000000)) (hi := ((-269863990933 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3053933311721 : ℝ) / 1000000000000) = Real.log ((3053933311721 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3053933311721 : ℝ) / 1000000000000) = ((3053933311721 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_677 : RB (Real.log ((3054495612677 : ℝ) / 1000000000000)) ((558307238379 : ℝ) / 500000000000) ((27915361919 : ℝ) / 25000000000) := by
  have hm := log_bounds_of_series (x := ((3054495612677 : ℝ) / 4000000000000)) (t := ((-945504387323 : ℝ) / 7054495612677))
    (lo := ((-269679884361 : ℝ) / 1000000000000)) (hi := ((-6741997109 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3054495612677 : ℝ) / 1000000000000) = Real.log ((3054495612677 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3054495612677 : ℝ) / 1000000000000) = ((3054495612677 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_678 : RB (Real.log ((1480104528747 : ℝ) / 1000000000000)) ((98028178203 : ℝ) / 250000000000) ((196056356407 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1480104528747 : ℝ) / 2000000000000)) (t := ((-519895471253 : ℝ) / 3480104528747))
    (lo := ((-301034467747 : ℝ) / 1000000000000)) (hi := ((-150517233873 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1480104528747 : ℝ) / 1000000000000) = Real.log ((1480104528747 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1480104528747 : ℝ) / 1000000000000) = ((1480104528747 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_679 : RB (Real.log ((1117886874999 : ℝ) / 1000000000000)) ((5572009223 : ℝ) / 50000000000) ((111440184461 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1117886874999 : ℝ) / 1000000000000)) (t := ((117886874999 : ℝ) / 2117886874999))
    (lo := ((5572009223 : ℝ) / 50000000000)) (hi := ((111440184461 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_680 : RB (Real.log ((89523 : ℝ) / 80000)) ((3514654401 : ℝ) / 31250000000) ((112468940833 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((89523 : ℝ) / 80000)) (t := ((9523 : ℝ) / 169523))
    (lo := ((3514654401 : ℝ) / 31250000000)) (hi := ((112468940833 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_681 : RB (Real.log ((117886874999 : ℝ) / 1000000000000)) ((-2672537251 : ℝ) / 1250000000) ((-1069014900399 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((117886874999 : ℝ) / 125000000000)) (t := ((-7113125001 : ℝ) / 242886874999))
    (lo := ((-732353239 : ℝ) / 12500000000)) (hi := ((-58588259119 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((117886874999 : ℝ) / 1000000000000) = Real.log ((117886874999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((117886874999 : ℝ) / 1000000000000) = ((117886874999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_682 : RB (Real.log ((9523 : ℝ) / 80000)) ((-2128316709463 : ℝ) / 1000000000000) ((-2128316709461 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((9523 : ℝ) / 10000)) (t := ((-477 : ℝ) / 19523))
    (lo := ((-48875167783 : ℝ) / 1000000000000)) (hi := ((-24437583891 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9523 : ℝ) / 80000) = Real.log ((9523 : ℝ) / 10000) - 3 * Real.log 2 := by
    rw [show ((9523 : ℝ) / 80000) = ((9523 : ℝ) / 10000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_683 : RB (Real.log ((92089182299 : ℝ) / 250000000000)) ((-998703437537 : ℝ) / 1000000000000) ((-199740687507 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((92089182299 : ℝ) / 125000000000)) (t := ((-32910817701 : ℝ) / 217089182299))
    (lo := ((-305556256977 : ℝ) / 1000000000000)) (hi := ((-19097266061 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92089182299 : ℝ) / 250000000000) = Real.log ((92089182299 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((92089182299 : ℝ) / 250000000000) = ((92089182299 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_684 : RB (Real.log ((368735120217 : ℝ) / 1000000000000)) ((-997676724097 : ℝ) / 1000000000000) ((-199535344819 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((368735120217 : ℝ) / 500000000000)) (t := ((-131264879783 : ℝ) / 868735120217))
    (lo := ((-304529543537 : ℝ) / 1000000000000)) (hi := ((-19033096471 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((368735120217 : ℝ) / 1000000000000) = Real.log ((368735120217 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((368735120217 : ℝ) / 1000000000000) = ((368735120217 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_685 : RB (Real.log ((279551850363 : ℝ) / 1000000000000)) ((-254913498491 : ℝ) / 200000000000) ((-1274567492453 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((279551850363 : ℝ) / 250000000000)) (t := ((29551850363 : ℝ) / 529551850363))
    (lo := ((22345373733 : ℝ) / 200000000000)) (hi := ((55863434333 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((279551850363 : ℝ) / 1000000000000) = Real.log ((279551850363 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((279551850363 : ℝ) / 1000000000000) = ((279551850363 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_686 : RB (Real.log ((190552384797 : ℝ) / 62500000000)) ((139345073229 : ℝ) / 125000000000) ((557380292917 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((190552384797 : ℝ) / 250000000000)) (t := ((-59447615203 : ℝ) / 440552384797))
    (lo := ((-271533775287 : ℝ) / 1000000000000)) (hi := ((-135766887643 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((190552384797 : ℝ) / 62500000000) = Real.log ((190552384797 : ℝ) / 250000000000) + 2 * Real.log 2 := by
    rw [show ((190552384797 : ℝ) / 62500000000) = ((190552384797 : ℝ) / 250000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_687 : RB (Real.log ((3049404720971 : ℝ) / 1000000000000)) ((1114946398117 : ℝ) / 1000000000000) ((1114946398119 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3049404720971 : ℝ) / 4000000000000)) (t := ((-950595279029 : ℝ) / 7049404720971))
    (lo := ((-135673981501 : ℝ) / 500000000000)) (hi := ((-271347963001 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3049404720971 : ℝ) / 1000000000000) = Real.log ((3049404720971 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3049404720971 : ℝ) / 1000000000000) = ((3049404720971 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_688 : RB (Real.log ((1481165420677 : ℝ) / 1000000000000)) ((78565844861 : ℝ) / 200000000000) ((392829224307 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1481165420677 : ℝ) / 2000000000000)) (t := ((-518834579323 : ℝ) / 3481165420677))
    (lo := ((-150158978127 : ℝ) / 500000000000)) (hi := ((-300317956253 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1481165420677 : ℝ) / 1000000000000) = Real.log ((1481165420677 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1481165420677 : ℝ) / 1000000000000) = ((1481165420677 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_689 : RB (Real.log ((1119037499999 : ℝ) / 1000000000000)) ((112468940831 : ℝ) / 1000000000000) ((3514654401 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((1119037499999 : ℝ) / 1000000000000)) (t := ((119037499999 : ℝ) / 2119037499999))
    (lo := ((112468940831 : ℝ) / 1000000000000)) (hi := ((3514654401 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_690 : RB (Real.log ((3582761 : ℝ) / 3200000)) ((28245730603 : ℝ) / 250000000000) ((112982922413 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3582761 : ℝ) / 3200000)) (t := ((382761 : ℝ) / 6782761))
    (lo := ((28245730603 : ℝ) / 250000000000)) (hi := ((112982922413 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_691 : RB (Real.log ((119037499999 : ℝ) / 1000000000000)) ((-2128316709471 : ℝ) / 1000000000000) ((-2128316709469 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((119037499999 : ℝ) / 125000000000)) (t := ((-5962500001 : ℝ) / 244037499999))
    (lo := ((-48875167791 : ℝ) / 1000000000000)) (hi := ((-4887516779 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((119037499999 : ℝ) / 1000000000000) = Real.log ((119037499999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((119037499999 : ℝ) / 1000000000000) = ((119037499999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_692 : RB (Real.log ((382761 : ℝ) / 3200000)) ((-1061747657639 : ℝ) / 500000000000) ((-530873828819 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((382761 : ℝ) / 400000)) (t := ((-17239 : ℝ) / 782761))
    (lo := ((-22026886799 : ℝ) / 500000000000)) (hi := ((-44053773597 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((382761 : ℝ) / 3200000) = Real.log ((382761 : ℝ) / 400000) - 3 * Real.log 2 := by
    rw [show ((382761 : ℝ) / 3200000) = ((382761 : ℝ) / 400000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_693 : RB (Real.log ((142888957559 : ℝ) / 500000000000)) ((-626270145189 : ℝ) / 500000000000) ((-156567536297 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((142888957559 : ℝ) / 125000000000)) (t := ((17888957559 : ℝ) / 267888957559))
    (lo := ((66877035371 : ℝ) / 500000000000)) (hi := ((133754070743 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142888957559 : ℝ) / 500000000000) = Real.log ((142888957559 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((142888957559 : ℝ) / 500000000000) = ((142888957559 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_694 : RB (Real.log ((285957012901 : ℝ) / 1000000000000)) ((-625956892001 : ℝ) / 500000000000) ((-156489223 : ℝ) / 125000000) := by
  have hm := log_bounds_of_series (x := ((285957012901 : ℝ) / 250000000000)) (t := ((35957012901 : ℝ) / 535957012901))
    (lo := ((67190288559 : ℝ) / 500000000000)) (hi := ((134380577119 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285957012901 : ℝ) / 1000000000000) = Real.log ((285957012901 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((285957012901 : ℝ) / 1000000000000) = ((285957012901 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_695 : RB (Real.log ((46677600619 : ℝ) / 200000000000)) ((-1455052961073 : ℝ) / 1000000000000) ((-1455052961071 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((46677600619 : ℝ) / 50000000000)) (t := ((-3322399381 : ℝ) / 96677600619))
    (lo := ((-68758599953 : ℝ) / 1000000000000)) (hi := ((-4297412497 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((46677600619 : ℝ) / 200000000000) = Real.log ((46677600619 : ℝ) / 50000000000) - 2 * Real.log 2 := by
    rw [show ((46677600619 : ℝ) / 200000000000) = ((46677600619 : ℝ) / 50000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_696 : RB (Real.log ((3036066178467 : ℝ) / 1000000000000)) ((138820332151 : ℝ) / 125000000000) ((111056265721 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((3036066178467 : ℝ) / 4000000000000)) (t := ((-963933821533 : ℝ) / 7036066178467))
    (lo := ((-275731703911 : ℝ) / 1000000000000)) (hi := ((-27573170391 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3036066178467 : ℝ) / 1000000000000) = Real.log ((3036066178467 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3036066178467 : ℝ) / 1000000000000) = ((3036066178467 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_697 : RB (Real.log ((151817489247 : ℝ) / 50000000000)) ((555328032663 : ℝ) / 500000000000) ((69416004083 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((151817489247 : ℝ) / 200000000000)) (t := ((-48182510753 : ℝ) / 351817489247))
    (lo := ((-275638295793 : ℝ) / 1000000000000)) (hi := ((-17227393487 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((151817489247 : ℝ) / 50000000000) = Real.log ((151817489247 : ℝ) / 200000000000) + 2 * Real.log 2 := by
    rw [show ((151817489247 : ℝ) / 50000000000) = ((151817489247 : ℝ) / 200000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_698 : RB (Real.log ((742058137773 : ℝ) / 500000000000)) ((98704873617 : ℝ) / 250000000000) ((39481949447 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((742058137773 : ℝ) / 1000000000000)) (t := ((-257941862227 : ℝ) / 1742058137773))
    (lo := ((-298327686091 : ℝ) / 1000000000000)) (hi := ((-29832768609 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((742058137773 : ℝ) / 500000000000) = Real.log ((742058137773 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((742058137773 : ℝ) / 500000000000) = ((742058137773 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_699 : RB (Real.log ((1119612812499 : ℝ) / 1000000000000)) ((28245730603 : ℝ) / 250000000000) ((112982922413 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1119612812499 : ℝ) / 1000000000000)) (t := ((119612812499 : ℝ) / 2119612812499))
    (lo := ((28245730603 : ℝ) / 250000000000)) (hi := ((112982922413 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_700 : RB (Real.log ((1792301 : ℝ) / 1600000)) ((113496639951 : ℝ) / 1000000000000) ((7093539997 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((1792301 : ℝ) / 1600000)) (t := ((192301 : ℝ) / 3392301))
    (lo := ((113496639951 : ℝ) / 1000000000000)) (hi := ((7093539997 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_701 : RB (Real.log ((119612812499 : ℝ) / 1000000000000)) ((-1061747657643 : ℝ) / 500000000000) ((-530873828821 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((119612812499 : ℝ) / 125000000000)) (t := ((-5387187501 : ℝ) / 244612812499))
    (lo := ((-22026886803 : ℝ) / 500000000000)) (hi := ((-8810754721 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((119612812499 : ℝ) / 1000000000000) = Real.log ((119612812499 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((119612812499 : ℝ) / 1000000000000) = ((119612812499 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_702 : RB (Real.log ((192301 : ℝ) / 1600000)) ((-2118697055439 : ℝ) / 1000000000000) ((-2118697055437 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((192301 : ℝ) / 200000)) (t := ((-7699 : ℝ) / 392301))
    (lo := ((-39255513759 : ℝ) / 1000000000000)) (hi := ((-19627756879 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192301 : ℝ) / 1600000) = Real.log ((192301 : ℝ) / 200000) - 3 * Real.log 2 := by
    rw [show ((192301 : ℝ) / 1600000) = ((192301 : ℝ) / 200000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_703 : RB (Real.log ((292508894603 : ℝ) / 1000000000000)) ((-614630101937 : ℝ) / 500000000000) ((-38414381371 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((292508894603 : ℝ) / 250000000000)) (t := ((42508894603 : ℝ) / 542508894603))
    (lo := ((78517078623 : ℝ) / 500000000000)) (hi := ((157034157247 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((292508894603 : ℝ) / 1000000000000) = Real.log ((292508894603 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((292508894603 : ℝ) / 1000000000000) = ((292508894603 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_704 : RB (Real.log ((146344911649 : ℝ) / 500000000000)) ((-61432092713 : ℝ) / 50000000000) ((-614320927129 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((146344911649 : ℝ) / 125000000000)) (t := ((21344911649 : ℝ) / 271344911649))
    (lo := ((7882625343 : ℝ) / 50000000000)) (hi := ((157652506861 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((146344911649 : ℝ) / 500000000000) = Real.log ((146344911649 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((146344911649 : ℝ) / 500000000000) = ((146344911649 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_705 : RB (Real.log ((7421469237 : ℝ) / 31250000000)) ((-359410582057 : ℝ) / 250000000000) ((-718821164113 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((7421469237 : ℝ) / 7812500000)) (t := ((-391030763 : ℝ) / 15233969237))
    (lo := ((-12836991777 : ℝ) / 250000000000)) (hi := ((-51347967107 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7421469237 : ℝ) / 31250000000) = Real.log ((7421469237 : ℝ) / 7812500000) - 2 * Real.log 2 := by
    rw [show ((7421469237 : ℝ) / 31250000000) = ((7421469237 : ℝ) / 7812500000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_706 : RB (Real.log ((1516764423009 : ℝ) / 500000000000)) ((1109726577507 : ℝ) / 1000000000000) ((1109726577509 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1516764423009 : ℝ) / 2000000000000)) (t := ((-483235576991 : ℝ) / 3516764423009))
    (lo := ((-69141945903 : ℝ) / 250000000000)) (hi := ((-276567783611 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1516764423009 : ℝ) / 500000000000) = Real.log ((1516764423009 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1516764423009 : ℝ) / 500000000000) = ((1516764423009 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_707 : RB (Real.log ((1516906752289 : ℝ) / 500000000000)) ((554910205269 : ℝ) / 500000000000) ((55491020527 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((1516906752289 : ℝ) / 2000000000000)) (t := ((-483093247711 : ℝ) / 3516906752289))
    (lo := ((-276473950581 : ℝ) / 1000000000000)) (hi := ((-13823697529 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1516906752289 : ℝ) / 500000000000) = Real.log ((1516906752289 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1516906752289 : ℝ) / 500000000000) = ((1516906752289 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_708 : RB (Real.log ((1484652487983 : ℝ) / 1000000000000)) ((395180730041 : ℝ) / 1000000000000) ((395180730043 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1484652487983 : ℝ) / 2000000000000)) (t := ((-515347512017 : ℝ) / 3484652487983))
    (lo := ((-148983225259 : ℝ) / 500000000000)) (hi := ((-297966450517 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1484652487983 : ℝ) / 1000000000000) = Real.log ((1484652487983 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1484652487983 : ℝ) / 1000000000000) = ((1484652487983 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_709 : RB (Real.log ((1120188124999 : ℝ) / 1000000000000)) ((2269932799 : ℝ) / 20000000000) ((113496639951 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1120188124999 : ℝ) / 1000000000000)) (t := ((120188124999 : ℝ) / 2120188124999))
    (lo := ((2269932799 : ℝ) / 20000000000)) (hi := ((113496639951 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_710 : RB (Real.log ((3586443 : ℝ) / 3200000)) ((2850252343 : ℝ) / 25000000000) ((114010093721 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3586443 : ℝ) / 3200000)) (t := ((386443 : ℝ) / 6786443))
    (lo := ((2850252343 : ℝ) / 25000000000)) (hi := ((114010093721 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_711 : RB (Real.log ((120188124999 : ℝ) / 1000000000000)) ((-264837131931 : ℝ) / 125000000000) ((-1059348527723 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((120188124999 : ℝ) / 125000000000)) (t := ((-4811875001 : ℝ) / 245188124999))
    (lo := ((-4906939221 : ℝ) / 125000000000)) (hi := ((-39255513767 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((120188124999 : ℝ) / 1000000000000) = Real.log ((120188124999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((120188124999 : ℝ) / 1000000000000) = ((120188124999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_712 : RB (Real.log ((386443 : ℝ) / 3200000)) ((-1056960854499 : ℝ) / 500000000000) ((-528480427249 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((386443 : ℝ) / 400000)) (t := ((-13557 : ℝ) / 786443))
    (lo := ((-17240083659 : ℝ) / 500000000000)) (hi := ((-34480167317 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((386443 : ℝ) / 3200000) = Real.log ((386443 : ℝ) / 400000) - 3 * Real.log 2 := by
    rw [show ((386443 : ℝ) / 3200000) = ((386443 : ℝ) / 400000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_713 : RB (Real.log ((152190171913 : ℝ) / 500000000000)) ((-594738614291 : ℝ) / 500000000000) ((-59473861429 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((152190171913 : ℝ) / 125000000000)) (t := ((27190171913 : ℝ) / 277190171913))
    (lo := ((98408566269 : ℝ) / 500000000000)) (hi := ((196817132539 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((152190171913 : ℝ) / 500000000000) = Real.log ((152190171913 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((152190171913 : ℝ) / 500000000000) = ((152190171913 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_714 : RB (Real.log ((3807047953 : ℝ) / 12500000000)) ((-59443728549 : ℝ) / 50000000000) ((-594437285489 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3807047953 : ℝ) / 3125000000)) (t := ((682047953 : ℝ) / 6932047953))
    (lo := ((9870989507 : ℝ) / 50000000000)) (hi := ((197419790141 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3807047953 : ℝ) / 12500000000) = Real.log ((3807047953 : ℝ) / 3125000000) - 2 * Real.log 2 := by
    rw [show ((3807047953 : ℝ) / 12500000000) = ((3807047953 : ℝ) / 3125000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_715 : RB (Real.log ((244533086667 : ℝ) / 1000000000000)) ((-176050581929 : ℝ) / 125000000000) ((-140840465543 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((244533086667 : ℝ) / 250000000000)) (t := ((-5466913333 : ℝ) / 494533086667))
    (lo := ((-2763786789 : ℝ) / 125000000000)) (hi := ((-22110294311 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((244533086667 : ℝ) / 1000000000000) = Real.log ((244533086667 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((244533086667 : ℝ) / 1000000000000) = ((244533086667 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_716 : RB (Real.log ((3030989839217 : ℝ) / 1000000000000)) ((1108889245781 : ℝ) / 1000000000000) ((1108889245783 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3030989839217 : ℝ) / 4000000000000)) (t := ((-969010160783 : ℝ) / 7030989839217))
    (lo := ((-138702557669 : ℝ) / 500000000000)) (hi := ((-277405115337 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3030989839217 : ℝ) / 1000000000000) = Real.log ((3030989839217 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3030989839217 : ℝ) / 1000000000000) = ((3030989839217 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_717 : RB (Real.log ((1515637773351 : ℝ) / 500000000000)) ((221796700689 : ℝ) / 200000000000) ((1108983503447 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1515637773351 : ℝ) / 2000000000000)) (t := ((-484362226649 : ℝ) / 3515637773351))
    (lo := ((-138655428837 : ℝ) / 500000000000)) (hi := ((-277310857673 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1515637773351 : ℝ) / 500000000000) = Real.log ((1515637773351 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1515637773351 : ℝ) / 500000000000) = ((1515637773351 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_718 : RB (Real.log ((742595057133 : ℝ) / 500000000000)) ((197771393567 : ℝ) / 500000000000) ((6180356049 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((742595057133 : ℝ) / 1000000000000)) (t := ((-257404942867 : ℝ) / 1742595057133))
    (lo := ((-11904175737 : ℝ) / 40000000000)) (hi := ((-18600274589 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((742595057133 : ℝ) / 500000000000) = Real.log ((742595057133 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((742595057133 : ℝ) / 500000000000) = ((742595057133 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_719 : RB (Real.log ((1120763437499 : ℝ) / 1000000000000)) ((114010093719 : ℝ) / 1000000000000) ((2850252343 : ℝ) / 25000000000) := by
  have hm := log_bounds_of_series (x := ((1120763437499 : ℝ) / 1000000000000)) (t := ((120763437499 : ℝ) / 2120763437499))
    (lo := ((114010093719 : ℝ) / 1000000000000)) (hi := ((2850252343 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
