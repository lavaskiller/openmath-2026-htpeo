import LeanProject.AtomicAdjoint
import LeanProject.RefDensities

/-!
# Adjoint inequality for a finite atomic angular velocity

The target positions are an initial value plus nonnegative steps. The density
weighted velocity is decomposed into a cosine-Lipschitz remainder and positive
jumps. Identification with the residual quantile and the series derivative is a
separate coordinate-dictionary theorem, not an assumption hidden in this module.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset

namespace EP1038.Stage11
open EP1038.Arc

theorem XLip.add {M N : ℝ} {f g : ℝ → ℝ} (hf : XLip M f) (hg : XLip N g) :
    XLip (M + N) (f + g) := by
  intro φ θ
  calc
    _ = |(f φ - f θ) + (g φ - g θ)| := by simp only [Pi.add_apply]; congr 1; ring
    _ ≤ |f φ - f θ| + |g φ - g θ| := abs_add_le _ _
    _ ≤ M * |cos φ - cos θ| + N * |cos φ - cos θ| := add_le_add (hf φ θ) (hg φ θ)
    _ = _ := by ring

theorem XLip.smul {M : ℝ} {f : ℝ → ℝ} (hf : XLip M f) (c : ℝ) :
    XLip (|c| * M) (c • f) := by
  intro φ θ
  simp only [Pi.smul_apply, smul_eq_mul, ← mul_sub, abs_mul]
  simpa only [mul_assoc] using mul_le_mul_of_nonneg_left (hf φ θ) (abs_nonneg c)

theorem XLip.mul {M N A B : ℝ} {f g : ℝ → ℝ} (hf : XLip M f) (hg : XLip N g)
    (hM : 0 ≤ M) (_hN : 0 ≤ N) (hA : ∀ θ, |f θ| ≤ A) (hB : ∀ θ, |g θ| ≤ B) :
    XLip (A * N + B * M) (f * g) := by
  intro φ θ
  have hf' := mul_le_mul (hA φ) (hg φ θ) (abs_nonneg _) (le_trans (abs_nonneg _) (hA φ))
  have hg' := mul_le_mul (hf φ θ) (hB θ) (abs_nonneg _) (mul_nonneg hM (abs_nonneg _))
  calc
    _ = |f φ * (g φ - g θ) + (f φ - f θ) * g θ| := by
      simp only [Pi.mul_apply]; congr 1; ring
    _ ≤ |f φ * (g φ - g θ)| + |(f φ - f θ) * g θ| := abs_add_le _ _
    _ = |f φ| * |g φ - g θ| + |f φ - f θ| * |g θ| := by rw [abs_mul, abs_mul]
    _ ≤ A * (N * |cos φ - cos θ|) + (M * |cos φ - cos θ|) * B := add_le_add hf' hg'
    _ = _ := by ring

noncomputable def poissonLip (ρ : ℝ) : ℝ := 2 * ρ * (1 - ρ ^ 2) / (1 - ρ) ^ 4

theorem poissonLip_nonneg {ρ : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ < 1) : 0 ≤ poissonLip ρ :=
  div_nonneg (mul_nonneg (by positivity) (by nlinarith)) (by positivity)

theorem Pq_XLip {ρ : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ < 1) : XLip (poissonLip ρ) (Pq ρ) := by
  intro φ θ
  let D := fun t => 1 - 2 * ρ * cos t + ρ ^ 2
  have hd : ∀ t, 0 < D t := Pq_den_pos h0 h1
  have hlo : ∀ t, (1 - ρ) ^ 2 ≤ D t := by
    intro t
    dsimp [D]
    nlinarith [mul_nonneg h0 (sub_nonneg.mpr (Real.cos_le_one t))]
  have hprod : (1 - ρ) ^ 4 ≤ D φ * D θ := by
    have ht := mul_le_mul (hlo φ) (hlo θ) (by positivity : 0 ≤ (1 - ρ) ^ 2) (hd φ).le
    nlinarith
  have hc : 0 ≤ 2 * ρ * (1 - ρ ^ 2) := mul_nonneg (by positivity) (by nlinarith)
  have heq : Pq ρ φ - Pq ρ θ = (2 * ρ * (1 - ρ ^ 2) / (D φ * D θ)) *
      (cos φ - cos θ) := by
    change (1 - ρ ^ 2) / D φ - (1 - ρ ^ 2) / D θ = _
    field_simp [(hd φ).ne', (hd θ).ne']
    dsimp [D]
    ring
  rw [heq, abs_mul, abs_of_nonneg (div_nonneg hc (mul_pos (hd φ) (hd θ)).le)]
  exact mul_le_mul_of_nonneg_right
    (div_le_div_of_nonneg_left hc (by positivity : 0 < (1 - ρ) ^ 4) hprod) (abs_nonneg _)

theorem alpha_XLip {k ρ : ℝ} (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1) :
    XLip (k * poissonLip ρ) (alpha k ρ) := by
  intro φ θ
  rw [show alpha k ρ φ - alpha k ρ θ = -(k * (Pq ρ φ - Pq ρ θ)) by
    dsimp [alpha]; ring, abs_neg, abs_mul, abs_of_nonneg hk]
  simpa only [mul_assoc] using mul_le_mul_of_nonneg_left (Pq_XLip h0 h1 φ θ) hk

theorem alpha_bounds {k ρ : ℝ} (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1)
    (ha0 : 0 ≤ alpha k ρ 0) (θ : ℝ) : 0 ≤ alpha k ρ θ ∧ |alpha k ρ θ| ≤ k + 1 := by
  have hp := Pq_nonneg h0 h1 θ
  have hl := Pq_le h0 h1 θ
  rw [← Pq_zero_val h1] at hl
  have ha : 0 ≤ alpha k ρ θ := by dsimp [alpha] at *; nlinarith
  refine ⟨ha, ?_⟩
  rw [abs_of_nonneg ha]
  dsimp [alpha]
  nlinarith

theorem alpha_order_cos {k ρ φ θ : ℝ} (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1)
    (hc : cos φ ≤ cos θ) : alpha k ρ θ ≤ alpha k ρ φ := by
  have hP : Pq ρ φ ≤ Pq ρ θ := by
    unfold Pq
    apply div_le_div_of_nonneg_left (by nlinarith) (Pq_den_pos h0 h1 θ)
    nlinarith
  dsimp [alpha]
  nlinarith

noncomputable def stepPosition {ι : Type*} (s : Finset ι) (d0 : ℝ) (δ z : ι → ℝ) : ℝ → ℝ :=
  fun θ => d0 + ∑ i ∈ s, δ i * jump (z i) θ

noncomputable def atomicVelocity {ι : Type*} (s : Finset ι) (k ρ c r d0 : ℝ)
    (δ z : ι → ℝ) : ℝ → ℝ :=
  fun θ => alpha k ρ θ * (stepPosition s d0 δ z θ - (c - r * cos θ))

noncomputable def jumpDensity (k ρ z : ℝ) : ℝ := alpha k ρ (Real.arccos z)

noncomputable def velocityRemainder {ι : Type*} (s : Finset ι) (k ρ c r d0 : ℝ)
    (δ z : ι → ℝ) : ℝ → ℝ :=
  fun θ => alpha k ρ θ * (d0 - (c - r * cos θ)) +
    ∑ i ∈ s, δ i * max 0 (alpha k ρ θ - jumpDensity k ρ (z i))

theorem density_jump_hinge {k ρ z : ℝ} (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1)
    (hz : z ∈ Set.Icc (-1 : ℝ) 1) (θ : ℝ) :
    (alpha k ρ θ - jumpDensity k ρ z) * jump z θ =
      max 0 (alpha k ρ θ - jumpDensity k ρ z) := by
  have hzcos := Real.cos_arccos hz.1 hz.2
  by_cases hc : cos θ < z
  · have ha := alpha_order_cos hk h0 h1 (φ := θ) (θ := arccos z)
      (by rw [hzcos]; exact hc.le)
    simp only [jump, hc, ite_true, mul_one, jumpDensity]
    exact (max_eq_right (sub_nonneg.mpr ha)).symm
  · have ha := alpha_order_cos hk h0 h1 (φ := arccos z) (θ := θ) (by rw [hzcos]; linarith)
    simp only [jump, hc, ite_false, mul_zero, jumpDensity]
    exact (max_eq_left (sub_nonpos.mpr ha)).symm

theorem atomicVelocity_decomposition {ι : Type*} (s : Finset ι) {k ρ c r d0 : ℝ}
    (δ z : ι → ℝ) (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1)
    (hz : ∀ i ∈ s, z i ∈ Set.Icc (-1 : ℝ) 1) :
    atomicVelocity s k ρ c r d0 δ z = velocityRemainder s k ρ c r d0 δ z +
      ∑ i ∈ s, (jumpDensity k ρ (z i) * δ i) • jump (z i) := by
  funext θ
  simp only [atomicVelocity, velocityRemainder, stepPosition, Pi.add_apply,
    Finset.sum_apply, Pi.smul_apply, smul_eq_mul]
  have hsum : (∑ i ∈ s, δ i * max 0 (alpha k ρ θ - jumpDensity k ρ (z i))) +
      (∑ i ∈ s, jumpDensity k ρ (z i) * δ i * jump (z i) θ) =
      alpha k ρ θ * ∑ i ∈ s, δ i * jump (z i) θ := by
    rw [← Finset.sum_add_distrib, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    rw [← density_jump_hinge hk h0 h1 (hz i hi)]
    ring
  linear_combination -hsum

theorem velocityRemainder_XLip {ι : Type*} (s : Finset ι) {k ρ c r d0 : ℝ} (δ z : ι → ℝ)
    (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1) (hr : 0 ≤ r) (ha0 : 0 ≤ alpha k ρ 0) :
    ∃ M : ℝ, 0 ≤ M ∧ XLip M (velocityRemainder s k ρ c r d0 δ z) := by
  have ha := alpha_XLip hk h0 h1
  have hMa : 0 ≤ k * poissonLip ρ := mul_nonneg hk (poissonLip_nonneg h0 h1)
  have hd : XLip r (fun θ => d0 - (c - r * cos θ)) := by
    intro φ θ
    rw [show (d0 - (c - r * cos φ)) - (d0 - (c - r * cos θ)) =
      r * (cos φ - cos θ) by ring, abs_mul, abs_of_nonneg hr]
  have hdb : ∀ θ, |d0 - (c - r * cos θ)| ≤ |d0 - c| + r := by
    intro θ
    calc
      _ = |(d0 - c) + r * cos θ| := by congr 1; ring
      _ ≤ |d0 - c| + |r * cos θ| := abs_add_le _ _
      _ ≤ |d0 - c| + r := by
        rw [abs_mul, abs_of_nonneg hr]
        exact add_le_add_right (mul_le_of_le_one_right hr (Real.abs_cos_le_one θ)) _
  have hb := ha.mul hd hMa hr (fun θ => (alpha_bounds hk h0 h1 ha0 θ).2) hdb
  have hMb : 0 ≤ (k + 1) * r + (|d0 - c| + r) * (k * poissonLip ρ) := by positivity
  have hh : ∀ i, XLip (k * poissonLip ρ)
      (fun θ => max 0 (alpha k ρ θ - jumpDensity k ρ (z i))) := by
    intro i φ θ
    have h := abs_max_sub_max_le_max (0 : ℝ) (alpha k ρ φ - jumpDensity k ρ (z i))
      0 (alpha k ρ θ - jumpDensity k ρ (z i))
    simp only [sub_self, abs_zero, sub_sub_sub_cancel_right] at h
    rw [max_eq_right (abs_nonneg (alpha k ρ φ - alpha k ρ θ))] at h
    exact h.trans (ha φ θ)
  have hsum : ∃ M : ℝ, 0 ≤ M ∧
      XLip M (∑ i ∈ s, δ i • (fun θ => max 0 (alpha k ρ θ - jumpDensity k ρ (z i)))) := by
    classical
    induction s using Finset.induction_on with
    | empty => exact ⟨0, le_rfl, by simp [XLip]⟩
    | @insert i s hi ih =>
      obtain ⟨M, hM, hLip⟩ := ih
      refine ⟨|δ i| * (k * poissonLip ρ) + M, add_nonneg (mul_nonneg (abs_nonneg _) hMa) hM, ?_⟩
      rw [Finset.sum_insert hi]
      exact ((hh i).smul (δ i)).add hLip
  obtain ⟨M, hM, hs⟩ := hsum
  refine ⟨(k + 1) * r + (|d0 - c| + r) * (k * poissonLip ρ) + M, add_nonneg hMb hM, ?_⟩
  have heq : velocityRemainder s k ρ c r d0 δ z =
      (alpha k ρ * (fun θ => d0 - (c - r * cos θ))) +
        ∑ i ∈ s, δ i • (fun θ => max 0 (alpha k ρ θ - jumpDensity k ρ (z i))) := by
    funext θ
    simp [velocityRemainder, Finset.sum_apply]
  rw [heq]
  exact hb.add hs

theorem atomicVelocity_pi {ι : Type*} (s : Finset ι) (k ρ c r d0 : ℝ) (δ z : ι → ℝ)
    (hz : ∀ i ∈ s, -1 < z i) :
    atomicVelocity s k ρ c r d0 δ z π = alpha k ρ π * (d0 + ∑ i ∈ s, δ i - (c + r)) := by
  have hj : ∀ i ∈ s, jump (z i) π = 1 := fun i hi => by simp [jump, hz i hi]
  simp only [atomicVelocity, stepPosition, Real.cos_pi, mul_neg, mul_one, sub_neg_eq_add]
  have hsum : (∑ i ∈ s, δ i * jump (z i) π) = ∑ i ∈ s, δ i := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [hj i hi, mul_one]
  rw [hsum]

/-- Adjoint and endpoint inequality for an actual density-weighted finite step velocity. -/
theorem atomicVelocity_adjoint {ι : Type*} (s : Finset ι) {k ρ c r d0 ρ1 ρ2 σ1 σ2 : ℝ}
    (δ z : ι → ℝ) (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1)
    (ha0 : 0 ≤ alpha k ρ 0) (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (hδ : ∀ i ∈ s, 0 ≤ δ i)
    (hz : ∀ i ∈ s, z i ∈ Set.Ioo (-1 : ℝ) 1) (hend : d0 + ∑ i ∈ s, δ i ≤ c + r) :
    AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (atomicVelocity s k ρ c r d0 δ z) ∧
      0 ≤ Lfun r ρ1 ρ2 σ1 σ2 (atomicVelocity s k ρ c r d0 δ z) ∧
      0 ≤ -Gam r ρ1 ρ2 σ1 σ2 * atomicVelocity s k ρ c r d0 δ z π ∧
      -Gam r ρ1 ρ2 σ1 σ2 * atomicVelocity s k ρ c r d0 δ z π ≤
        widthVariation r ρ1 ρ2 σ1 σ2 (atomicVelocity s k ρ c r d0 δ z) -
          adjointIntegral r ρ1 ρ2 σ1 σ2 (atomicVelocity s k ρ c r d0 δ z) := by
  have hz' : ∀ i ∈ s, z i ∈ Set.Icc (-1 : ℝ) 1 := fun i hi => ⟨(hz i hi).1.le, (hz i hi).2.le⟩
  obtain ⟨M, hM, hfc⟩ := velocityRemainder_XLip s (c := c) (d0 := d0) δ z hk h0 h1 hr.le ha0
  have hΔ : ∀ i ∈ s, 0 ≤ jumpDensity k ρ (z i) * δ i := by
    intro i hi
    exact mul_nonneg (alpha_bounds hk h0 h1 ha0 _).1 (hδ i hi)
  have hdec := atomicVelocity_decomposition s (c := c) (r := r) (d0 := d0) δ z hk h0 h1 hz'
  obtain ⟨hfi, hL⟩ := finite_jump_adjoint hr h10 h11 h20 h21 hs1 hs2 hM hfc s
    (fun i => jumpDensity k ρ (z i) * δ i) z hΔ (fun i hi => (hz i hi).1)
  rw [← hdec] at hfi hL
  have hπ : atomicVelocity s k ρ c r d0 δ z π ≤ 0 := by
    rw [atomicVelocity_pi s k ρ c r d0 δ z (fun i hi => (hz i hi).1)]
    exact mul_nonpos_of_nonneg_of_nonpos (alpha_bounds hk h0 h1 ha0 π).1 (sub_nonpos.mpr hend)
  exact ⟨hfi, hL, mul_nonneg_of_nonpos_of_nonpos
    (neg_nonpos.mpr (Gam_nonneg hr h10 h11 h20 h21 hs1 hs2)) hπ,
    endpoint_corrected_inequality hL⟩

/-- In the normalized coordinates the paper's correction is exactly
`Γ α(π) (2 - d_last)`. -/
theorem atomicVelocity_endpoint_formula {ι : Type*} (s : Finset ι)
    (k ρ c r d0 ρ1 ρ2 σ1 σ2 : ℝ) (δ z : ι → ℝ)
    (hz : ∀ i ∈ s, -1 < z i) (hpos : c + r = 2) :
    -Gam r ρ1 ρ2 σ1 σ2 * atomicVelocity s k ρ c r d0 δ z π =
      Gam r ρ1 ρ2 σ1 σ2 * alpha k ρ π * (2 - (d0 + ∑ i ∈ s, δ i)) := by
  rw [atomicVelocity_pi s k ρ c r d0 δ z hz, hpos]
  ring

theorem atomicVelocity_adjoint_bound {ι : Type*} (s : Finset ι)
    {k ρ c r d0 ρ1 ρ2 σ1 σ2 : ℝ} (δ z : ι → ℝ)
    (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1) (ha0 : 0 ≤ alpha k ρ 0) (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (hδ : ∀ i ∈ s, 0 ≤ δ i)
    (hz : ∀ i ∈ s, z i ∈ Set.Ioo (-1 : ℝ) 1) (hend : d0 + ∑ i ∈ s, δ i ≤ c + r) :
    adjointIntegral r ρ1 ρ2 σ1 σ2 (atomicVelocity s k ρ c r d0 δ z) ≤
      widthVariation r ρ1 ρ2 σ1 σ2 (atomicVelocity s k ρ c r d0 δ z) := by
  obtain ⟨_, _, hnonneg, hcorr⟩ :=
    atomicVelocity_adjoint s δ z hk h0 h1 ha0 hr h10 h11 h20 h21 hs1 hs2 hδ hz hend
  linarith

end EP1038.Stage11
