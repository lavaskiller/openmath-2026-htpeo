import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk17
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_64 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((319867594312213361986084133247385 : ℝ) / 2596148429267413814265248164610048) ((640108587785229951224177739431935 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((15401064453 : ℝ) / 125000000000) ((15410053711 : ℝ) / 125000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((140401064453 : ℝ) / 125000000000) ((140410053711 : ℝ) / 125000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((58094667917 : ℝ) / 500000000000) ((58126679677 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_799.1 dlower_log_800.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((58094667917 : ℝ) / 250000000000) ((58126679677 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460640461851 : ℝ) / 1000000000000) ((115192127223 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2093877109947 : ℝ) / 1000000000000) ((-2093293602511 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_801.1 dlower_log_802.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2093293602511 : ℝ) / 1000000000000) ((2093877109947 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((27499253637 : ℝ) / 125000000000) ((55029130689 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((194970869311 : ℝ) / 250000000000) ((97500746363 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7590169161 : ℝ) / 500000000000) ((3039612869 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((41825690689 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((1939303891 : ℝ) / 10000000000) ((193948115123 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((41825690689 : ℝ) / 200000000000) ((41825690689 : ℝ) / 200000000000) ((41825690689 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((158174309311 : ℝ) / 200000000000))
  have h11 : RB z11 ((122605491337 : ℝ) / 500000000000) ((15327087247 : ℝ) / 62500000000) := rb_div_signed h10 (show RB ((158174309311 : ℝ) / 200000000000) ((158174309311 : ℝ) / 200000000000) ((158174309311 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1405636285247 : ℝ) / 1000000000000) ((-1405544885367 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_803.1 dlower_log_804.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-274101173853 : ℝ) / 250000000000) ((-548080616311 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((41825690689 : ℝ) / 200000000000))
  have h14 : RB z14 ((-391201651507 : ℝ) / 250000000000) ((-782403303013 : ℝ) / 500000000000) := rb_log (show RB ((41825690689 : ℝ) / 200000000000) ((41825690689 : ℝ) / 200000000000) ((41825690689 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_805.1 dlower_log_805.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((234200955307 : ℝ) / 500000000000) ((234322686703 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((3816700861 : ℝ) / 500000000000) ((1600982311 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7590169161 : ℝ) / 500000000000) ((3039612869 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((744843353947 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1474488643549 : ℝ) / 1000000000000) ((368626592393 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((744843353947 : ℝ) / 500000000000) ((744843353947 : ℝ) / 500000000000) ((744843353947 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((244843353947 : ℝ) / 500000000000))
  have h19 : RB z19 ((602217139971 : ℝ) / 200000000000) ((1505560949279 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((244843353947 : ℝ) / 500000000000) ((244843353947 : ℝ) / 500000000000) ((244843353947 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((22046014227 : ℝ) / 20000000000) ((1102312733091 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_806.1 dlower_log_807.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((107458263967 : ℝ) / 125000000000) ((171962102723 : ℝ) / 200000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((744843353947 : ℝ) / 500000000000))
  have h22 : RB z22 ((398565834689 : ℝ) / 1000000000000) ((398565834691 : ℝ) / 1000000000000) := rb_log (show RB ((744843353947 : ℝ) / 500000000000) ((744843353947 : ℝ) / 500000000000) ((744843353947 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_808.1 dlower_log_808.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((92220055409 : ℝ) / 200000000000) ((230622339463 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((331768153 : ℝ) / 1000000000000) ((24168683 : ℝ) / 40000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((140401064453 : ℝ) / 125000000000) ((140410053711 : ℝ) / 125000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((126159736957 : ℝ) / 100000000000) ((1261758923721 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1585088848907 : ℝ) / 1000000000000) ((792645913919 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1280558254449 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1014899304751 : ℝ) / 500000000000) ((2030058535849 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1280558254449 : ℝ) / 1000000000000) ((1280558254449 : ℝ) / 1000000000000) ((1280558254449 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7590169161 : ℝ) / 500000000000) ((3039612869 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((31153587733944569299483 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((48727416089 : ℝ) / 1000000000000) ((12196078727 : ℝ) / 250000000000) := rb_div_signed h29 (show RB ((31153587733944569299483 : ℝ) / 100000000000000000000000) ((31153587733944569299483 : ℝ) / 100000000000000000000000) ((31153587733944569299483 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((237803921273 : ℝ) / 250000000000) ((951272583911 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((241347034367 : ℝ) / 125000000000) ((241392378611 : ℝ) / 125000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((41825690689 : ℝ) / 200000000000)) ((3816700861 : ℝ) / 500000000000) ((1600982311 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((744843353947 : ℝ) / 500000000000)) ((331768153 : ℝ) / 1000000000000) ((24168683 : ℝ) / 40000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((41825690689 : ℝ) / 200000000000)) (wl := ((744843353947 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((241347034367 : ℝ) / 125000000000) ≤ D0q (q) * (((744843353947 : ℝ) / 500000000000) - ((41825690689 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((744843353947 : ℝ) / 500000000000) * ((41825690689 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_65 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((640108587785229951224177739431935 : ℝ) / 5192296858534827628530496329220096) ((160120496736508294619046803092275 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((123280429687 : ℝ) / 1000000000000) ((157891 : ℝ) / 1280000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1123280429687 : ℝ) / 1000000000000) ((1437891 : ℝ) / 1280000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((116253359353 : ℝ) / 1000000000000) ((116317378773 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_809.1 dlower_log_810.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((116253359353 : ℝ) / 500000000000) ((116317378773 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460512423013 : ℝ) / 1000000000000) ((230320230927 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2093293602521 : ℝ) / 1000000000000) ((-16741683483 : ℝ) / 8000000000) := rb_log hqr (by norm_num) dlower_log_811.1 dlower_log_812.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((16741683483 : ℝ) / 8000000000) ((2093293602521 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((109997093207 : ℝ) / 500000000000) ((110058337281 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((389941662719 : ℝ) / 500000000000) ((390002906793 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15198064343 : ℝ) / 1000000000000) ((15215800709 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((45017614473 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((26234033957 : ℝ) / 125000000000) ((104945004011 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((45017614473 : ℝ) / 200000000000) ((45017614473 : ℝ) / 200000000000) ((45017614473 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((154982385527 : ℝ) / 200000000000))
  have h11 : RB z11 ((67708427297 : ℝ) / 250000000000) ((16928537339 : ℝ) / 62500000000) := rb_div_signed h10 (show RB ((154982385527 : ℝ) / 200000000000) ((154982385527 : ℝ) / 200000000000) ((154982385527 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1306250265677 : ℝ) / 1000000000000) ((-1306165758953 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_813.1 dlower_log_814.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-1018882801227 : ℝ) / 1000000000000) ((-203731379133 : ℝ) / 200000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((45017614473 : ℝ) / 200000000000))
  have h14 : RB z14 ((-298252704127 : ℝ) / 200000000000) ((-1491263520633 : ℝ) / 1000000000000) := rb_log (show RB ((45017614473 : ℝ) / 200000000000) ((45017614473 : ℝ) / 200000000000) ((45017614473 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_815.1 dlower_log_815.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((236190359703 : ℝ) / 500000000000) ((47260662497 : ℝ) / 100000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((733766097 : ℝ) / 62500000000) ((12094201957 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15198064343 : ℝ) / 1000000000000) ((15215800709 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((744877509353 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1474539217997 : ℝ) / 1000000000000) ((1474556954363 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((744877509353 : ℝ) / 500000000000) ((744877509353 : ℝ) / 500000000000) ((744877509353 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((244877509353 : ℝ) / 500000000000))
  have h19 : RB z19 ((12043075919 : ℝ) / 4000000000) ((1505402597261 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((244877509353 : ℝ) / 500000000000) ((244877509353 : ℝ) / 500000000000) ((244877509353 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1102195521131 : ℝ) / 1000000000000) ((551103774737 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_816.1 dlower_log_817.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((429791954151 : ℝ) / 500000000000) ((859728296369 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((744877509353 : ℝ) / 500000000000))
  have h22 : RB z22 ((199305844731 : ℝ) / 500000000000) ((49826461183 : ℝ) / 125000000000) := rb_log (show RB ((744877509353 : ℝ) / 500000000000) ((744877509353 : ℝ) / 500000000000) ((744877509353 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_818.1 dlower_log_818.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((230486109419 : ℝ) / 500000000000) ((461116606907 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41469623 : ℝ) / 125000000000) ((302091947 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1123280429687 : ℝ) / 1000000000000) ((1437891 : ℝ) / 1280000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1261758923717 : ℝ) / 1000000000000) ((1261920488209 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1584885908967 : ℝ) / 1000000000000) ((1585088848913 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1264666946341 : ℝ) / 1000000000000))
  have h28 : RB z28 ((250544102849 : ℝ) / 125000000000) ((1002304737117 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((1264666946341 : ℝ) / 1000000000000) ((1264666946341 : ℝ) / 1000000000000) ((1264666946341 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15198064343 : ℝ) / 1000000000000) ((15215800709 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((33532608545661805665969 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((22661619543 : ℝ) / 500000000000) ((45376131977 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((33532608545661805665969 : ℝ) / 100000000000000000000000) ((33532608545661805665969 : ℝ) / 100000000000000000000000) ((33532608545661805665969 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((954623868023 : ℝ) / 1000000000000) ((477338380457 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((59793845143 : ℝ) / 31250000000) ((23921925997 : ℝ) / 12500000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((45017614473 : ℝ) / 200000000000)) ((733766097 : ℝ) / 62500000000) ((12094201957 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((744877509353 : ℝ) / 500000000000)) ((41469623 : ℝ) / 125000000000) ((302091947 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((45017614473 : ℝ) / 200000000000)) (wl := ((744877509353 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((59793845143 : ℝ) / 31250000000) ≤ D0q (q) * (((744877509353 : ℝ) / 500000000000) - ((45017614473 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((744877509353 : ℝ) / 500000000000) * ((45017614473 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_66 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((160120496736508294619046803092275 : ℝ) / 1298074214633706907132624082305024) ((640855386106836405728196685306265 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((123352343749 : ℝ) / 1000000000000) ((123424257813 : ℝ) / 1000000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1123352343749 : ℝ) / 1000000000000) ((1123424257813 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((116317378771 : ℝ) / 1000000000000) ((58190697047 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_819.1 dlower_log_820.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((116317378771 : ℝ) / 500000000000) ((58190697047 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460384392371 : ℝ) / 1000000000000) ((230256211509 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-418542087077 : ℝ) / 200000000000) ((-2092127608117 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_821.1 dlower_log_822.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2092127608117 : ℝ) / 1000000000000) ((418542087077 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((219994311963 : ℝ) / 1000000000000) ((220116794613 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779883205387 : ℝ) / 1000000000000) ((780005688037 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3803950177 : ℝ) / 250000000000) ((15233547417 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((50587566279 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((118852141989 : ℝ) / 500000000000) ((237722030687 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((50587566279 : ℝ) / 200000000000) ((50587566279 : ℝ) / 200000000000) ((50587566279 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((149412433721 : ℝ) / 200000000000))
  have h11 : RB z11 ((159092706047 : ℝ) / 500000000000) ((159104583713 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((149412433721 : ℝ) / 200000000000) ((149412433721 : ℝ) / 200000000000) ((149412433721 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-229024201843 : ℝ) / 200000000000) ((-286261588307 : ℝ) / 250000000000) := rb_log h11 (by norm_num) dlower_log_823.1 dlower_log_824.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-893200900679 : ℝ) / 1000000000000) ((-55812651267 : ℝ) / 62500000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((50587566279 : ℝ) / 200000000000))
  have h14 : RB z14 ((-687305773081 : ℝ) / 500000000000) ((-17182644327 : ℝ) / 12500000000) := rb_log (show RB ((50587566279 : ℝ) / 200000000000) ((50587566279 : ℝ) / 200000000000) ((50587566279 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_825.1 dlower_log_825.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((481410645481 : ℝ) / 1000000000000) ((48160912589 : ℝ) / 100000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((20898222463 : ℝ) / 1000000000000) ((21224733519 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3803950177 : ℝ) / 250000000000) ((15233547417 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((297964670253 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((184323725481 : ℝ) / 125000000000) ((1474607550557 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((297964670253 : ℝ) / 200000000000) ((297964670253 : ℝ) / 200000000000) ((297964670253 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((97964670253 : ℝ) / 200000000000))
  have h19 : RB z19 ((3010452237607 : ℝ) / 1000000000000) ((3010488468443 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((97964670253 : ℝ) / 200000000000) ((97964670253 : ℝ) / 200000000000) ((97964670253 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((551045156263 : ℝ) / 500000000000) ((110210234747 : ℝ) / 100000000000) := rb_log h19 (by norm_num) dlower_log_826.1 dlower_log_827.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((429750862779 : ℝ) / 500000000000) ((429823049913 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((297964670253 : ℝ) / 200000000000))
  have h22 : RB z22 ((39865755673 : ℝ) / 100000000000) ((99664389183 : ℝ) / 250000000000) := rb_log (show RB ((297964670253 : ℝ) / 200000000000) ((297964670253 : ℝ) / 200000000000) ((297964670253 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_828.1 dlower_log_828.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((230422084413 : ℝ) / 500000000000) ((57623567887 : ℝ) / 125000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((20734113 : ℝ) / 62500000000) ((24166029 : ℝ) / 40000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1123352343749 : ℝ) / 1000000000000) ((1123424257813 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((630960244103 : ℝ) / 500000000000) ((1262082063043 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((316936601599 : ℝ) / 200000000000) ((396221477243 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((123688551987 : ℝ) / 100000000000))
  have h28 : RB z28 ((1960071466173 : ℝ) / 1000000000000) ((980161215727 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((123688551987 : ℝ) / 100000000000) ((123688551987 : ℝ) / 100000000000) ((123688551987 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3803950177 : ℝ) / 250000000000) ((15233547417 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((15073307505224017198587 : ℝ) / 40000000000000000000000))
  have h30 : RB z30 ((4037813387 : ℝ) / 100000000000) ((4042522827 : ℝ) / 100000000000) := rb_div_signed h29 (show RB ((15073307505224017198587 : ℝ) / 40000000000000000000000) ((15073307505224017198587 : ℝ) / 40000000000000000000000) ((15073307505224017198587 : ℝ) / 40000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((95957477173 : ℝ) / 100000000000) ((95962186613 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1880835129727 : ℝ) / 1000000000000) ((1881168269889 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((50587566279 : ℝ) / 200000000000)) ((20898222463 : ℝ) / 1000000000000) ((21224733519 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((297964670253 : ℝ) / 200000000000)) ((20734113 : ℝ) / 62500000000) ((24166029 : ℝ) / 40000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((50587566279 : ℝ) / 200000000000)) (wl := ((297964670253 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1880835129727 : ℝ) / 1000000000000) ≤ D0q (q) * (((297964670253 : ℝ) / 200000000000) - ((50587566279 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((297964670253 : ℝ) / 200000000000) * ((50587566279 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_67 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((640855386106836405728196685306265 : ℝ) / 5192296858534827628530496329220096) ((641042085687238019354201421774847 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((30856064453 : ℝ) / 250000000000) ((30865053711 : ℝ) / 250000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((280856064453 : ℝ) / 250000000000) ((280865053711 : ℝ) / 250000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((29095348523 : ℝ) / 250000000000) ((58206700109 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_829.1 dlower_log_830.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((29095348523 : ℝ) / 125000000000) ((58206700109 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460320380123 : ℝ) / 1000000000000) ((57548049047 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2092127608127 : ℝ) / 1000000000000) ((-83673452873 : ℝ) / 40000000000) := rb_log hqr (by norm_num) dlower_log_831.1 dlower_log_832.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((83673452873 : ℝ) / 40000000000) ((2092127608127 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((220025001503 : ℝ) / 1000000000000) ((22008624077 : ℝ) / 100000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((77991375923 : ℝ) / 100000000000) ((779974998497 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1904193427 : ℝ) / 125000000000) ((304848493 : ℝ) / 20000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((51313744119 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((95006275913 : ℝ) / 500000000000) ((9501071453 : ℝ) / 50000000000) := rb_widen (rb_sub (show RB ((51313744119 : ℝ) / 250000000000) ((51313744119 : ℝ) / 250000000000) ((51313744119 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((198686255881 : ℝ) / 250000000000))
  have h11 : RB z11 ((239086180097 : ℝ) / 1000000000000) ((239097350013 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((198686255881 : ℝ) / 250000000000) ((198686255881 : ℝ) / 250000000000) ((198686255881 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1430931205867 : ℝ) / 1000000000000) ((-178860560969 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_833.1 dlower_log_834.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-558045282573 : ℝ) / 500000000000) ((-557983249933 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((51313744119 : ℝ) / 250000000000))
  have h14 : RB z14 ((-79175114251 : ℝ) / 50000000000) ((-791751142509 : ℝ) / 500000000000) := rb_log (show RB ((51313744119 : ℝ) / 250000000000) ((51313744119 : ℝ) / 250000000000) ((51313744119 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_835.1 dlower_log_835.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((7303308123 : ℝ) / 15625000000) ((233767892577 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((878415937 : ℝ) / 125000000000) ((7215405031 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1904193427 : ℝ) / 125000000000) ((304848493 : ℝ) / 20000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((372502388003 : ℝ) / 250000000000)) - (z17)
  have h18 : RB z18 ((737383563681 : ℝ) / 500000000000) ((368694001149 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((372502388003 : ℝ) / 250000000000) ((372502388003 : ℝ) / 250000000000) ((372502388003 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((122502388003 : ℝ) / 250000000000))
  have h19 : RB z19 ((601934032227 : ℝ) / 200000000000) ((3009688277587 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((122502388003 : ℝ) / 250000000000) ((122502388003 : ℝ) / 250000000000) ((122502388003 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1101830491737 : ℝ) / 1000000000000) ((220367302227 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_836.1 dlower_log_837.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((214833190211 : ℝ) / 250000000000) ((859404931117 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((372502388003 : ℝ) / 250000000000))
  have h22 : RB z22 ((199391265341 : ℝ) / 500000000000) ((99695632671 : ℝ) / 250000000000) := rb_log (show RB ((372502388003 : ℝ) / 250000000000) ((372502388003 : ℝ) / 250000000000) ((372502388003 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_838.1 dlower_log_838.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((5756877877 : ℝ) / 12500000000) ((92124480087 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((20729723 : ℝ) / 125000000000) ((37752539 : ℝ) / 125000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((280856064453 : ℝ) / 250000000000) ((280865053711 : ℝ) / 250000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((3944006447 : ℝ) / 3125000000) ((631081427169 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1584581572121 : ℝ) / 1000000000000) ((3095084 : ℝ) / 1953125) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((80297160971 : ℝ) / 62500000000))
  have h28 : RB z28 ((508949606273 : ℝ) / 250000000000) ((2035928745303 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((80297160971 : ℝ) / 62500000000) ((80297160971 : ℝ) / 62500000000) ((80297160971 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1904193427 : ℝ) / 125000000000) ((304848493 : ℝ) / 20000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((19114492221702397404357 : ℝ) / 62500000000000000000000))
  have h30 : RB z30 ((389142201 : ℝ) / 7812500000) ((24919614123 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((19114492221702397404357 : ℝ) / 62500000000000000000000) ((19114492221702397404357 : ℝ) / 62500000000000000000000) ((19114492221702397404357 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((475080385877 : ℝ) / 500000000000) ((7423357799 : ℝ) / 7812500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((12089598767 : ℝ) / 6250000000) ((483629680949 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((51313744119 : ℝ) / 250000000000)) ((878415937 : ℝ) / 125000000000) ((7215405031 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((372502388003 : ℝ) / 250000000000)) ((20729723 : ℝ) / 125000000000) ((37752539 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((51313744119 : ℝ) / 250000000000)) (wl := ((372502388003 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((12089598767 : ℝ) / 6250000000) ≤ D0q (q) * (((372502388003 : ℝ) / 250000000000) - ((51313744119 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((372502388003 : ℝ) / 250000000000) * ((51313744119 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
