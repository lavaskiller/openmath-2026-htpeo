import LeanProject.R1Pilot

/-! Certified brackets for the actual endpoints on the middle-R1 pilot slab. -/

open Real Set Finset

namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11

theorem pilot_D0_bounds {k : ℝ} (hk : k ∈ pilotSlab) :
    1927301 / 1000000 ≤ D0a (r1A k) ∧ D0a (r1A k) ≤ 1927329 / 1000000 := by
  have ha := r1_a_pos (pilot_slab_subset hk)
  have hs := Real.sqrt_nonneg (r1A k)
  have h2 := Real.sqrt_nonneg (2 : ℝ)
  have hsq := Real.sq_sqrt ha.le
  have hsq2 := Real.sq_sqrt (show (0 : ℝ) ≤ 2 by norm_num)
  have ha_lo : (37119 : ℝ) / 20000 ≤ r1A k := by
    unfold r1A; linarith [hk.2]
  have ha_hi := (pilot_a_bounds hk).2
  have hsa_lo : (544933 : ℝ) / 400000 ≤ √(r1A k) := by nlinarith
  have hsa_hi : √(r1A k) ≤ (1362351 : ℝ) / 1000000 := by nlinarith
  have hs2_lo : (28284271 : ℝ) / 20000000 ≤ √2 := by nlinarith
  have hs2_hi : √2 ≤ (141421357 : ℝ) / 100000000 := by nlinarith
  have hl : (277654605 : ℝ) / 100000000 ≤ √(r1A k) + √2 := by linarith
  have hu : √(r1A k) + √2 ≤ (277656457 : ℝ) / 100000000 := by linarith
  have hpl := mul_nonneg (sub_nonneg.mpr hl)
    (show (0 : ℝ) ≤ √(r1A k) + √2 + 277654605 / 100000000 by positivity)
  have hpu := mul_nonneg (sub_nonneg.mpr hu)
    (show (0 : ℝ) ≤ 277656457 / 100000000 + (√(r1A k) + √2) by positivity)
  unfold D0a
  constructor <;> nlinarith

theorem pilot_q_bounds {k : ℝ} (hk : k ∈ pilotSlab) :
    9339 / 500000 ≤ qa (r1A k) ∧ qa (r1A k) ≤ 9343 / 500000 := by
  have ha := r1_a_pos (pilot_slab_subset hk)
  have ha2 := (r1_a_mem (pilot_slab_subset hk)).2
  have hq := (qa_pos ha ha2).le
  have hmul := D0a_mul_qa ha
  have hlo := mul_nonneg (sub_nonneg.mpr (pilot_D0_bounds hk).1) hq
  have hhi := mul_nonneg (sub_nonneg.mpr (pilot_D0_bounds hk).2) hq
  have ha_lo : (37119 : ℝ) / 20000 ≤ r1A k := by
    unfold r1A; linarith [hk.2]
  constructor <;> nlinarith [ha_lo, (pilot_a_bounds hk).2]

theorem pilot_A_bounds {k : ℝ} (hk : k ∈ pilotSlab) :
    9 / 14 ≤ k / (k + 1) ∧ k / (k + 1) ≤ 9001 / 14001 := by
  have hd : 0 < k + 1 := by linarith [hk.1]
  constructor
  · apply (le_div_iff₀ hd).mpr; linarith [hk.1]
  · apply (div_le_iff₀ hd).mpr; linarith [hk.2]

theorem pilot_ratio_bounds {k v lo hi : ℝ} (hk : k ∈ pilotSlab) (hv : v ≠ 1)
    (hlo : lo ≤ (v - (9343 / 500000) ^ 2) / |1 - v|)
    (hhi : (v - (9339 / 500000) ^ 2) / |1 - v| ≤ hi) :
    lo ≤ (v - (qa (r1A k)) ^ 2) / |1 - v| ∧
      (v - (qa (r1A k)) ^ 2) / |1 - v| ≤ hi := by
  have hq := pilot_q_bounds hk
  have hq0 := (qa_pos (r1_a_pos (pilot_slab_subset hk))
    (r1_a_mem (pilot_slab_subset hk)).2).le
  have hd : 0 < |1 - v| := abs_pos.mpr (sub_ne_zero.mpr (Ne.symm hv))
  constructor
  · refine hlo.trans ((div_le_div_iff_of_pos_right hd).mpr ?_)
    nlinarith [hq.2]
  · refine ((div_le_div_iff_of_pos_right hd).mpr ?_).trans hhi
    nlinarith [hq.1]

theorem pilot_E_bounds_negative_log {k v rl ru lrl url lv uv ld ud : ℝ}
    (hk : k ∈ pilotSlab) (hr : rl ≤ (v - (qa (r1A k)) ^ 2) / |1 - v| ∧
      (v - (qa (r1A k)) ^ 2) / |1 - v| ≤ ru) (hrl : 0 < rl)
    (hlrl : lrl ≤ Real.log rl) (hurl : Real.log ru ≤ url) (hurl0 : url ≤ 0)
    (hlv : lv ≤ Real.log v) (huv : Real.log v ≤ uv)
    (hld : ld ≤ Real.log (1927301 / 1000000))
    (hud : Real.log (1927329 / 1000000) ≤ ud) :
    9001 / 14001 * lrl - uv - ud ≤ certE k (r1A k) v ∧
      certE k (r1A k) v ≤ 9 / 14 * url - lv - ld := by
  have hk0 := r1_k_pos (pilot_slab_subset hk)
  have hA := pilot_A_bounds hk
  have hll := hlrl.trans (Real.log_le_log hrl hr.1)
  have hlu := (Real.log_le_log (hrl.trans_le hr.1) hr.2).trans hurl
  have hDlo := hld.trans (Real.log_le_log (by norm_num) (pilot_D0_bounds hk).1)
  have hDhi := (Real.log_le_log (D0a_pos (r1_a_pos (pilot_slab_subset hk)))
    (pilot_D0_bounds hk).2).trans hud
  have hlrl0 : lrl ≤ 0 := hll.trans (hlu.trans hurl0)
  have hp0 : 0 ≤ k / (k + 1) := by positivity
  have hmlo := (mul_le_mul_of_nonpos_right hA.2 hlrl0).trans
    (mul_le_mul_of_nonneg_left hll hp0)
  have hmhi := (mul_le_mul_of_nonneg_left hlu hp0).trans
    (mul_le_mul_of_nonpos_right hA.1 hurl0)
  unfold certE
  constructor <;> linarith

theorem pilot_E_bounds_positive_log {k v rl ru lrl url lv uv ld ud : ℝ}
    (hk : k ∈ pilotSlab) (hr : rl ≤ (v - (qa (r1A k)) ^ 2) / |1 - v| ∧
      (v - (qa (r1A k)) ^ 2) / |1 - v| ≤ ru) (hrl : 0 < rl)
    (hlrl : lrl ≤ Real.log rl) (hurl : Real.log ru ≤ url) (hlrl0 : 0 ≤ lrl)
    (hlv : lv ≤ Real.log v) (huv : Real.log v ≤ uv)
    (hld : ld ≤ Real.log (1927301 / 1000000))
    (hud : Real.log (1927329 / 1000000) ≤ ud) :
    9 / 14 * lrl - uv - ud ≤ certE k (r1A k) v ∧
      certE k (r1A k) v ≤ 9001 / 14001 * url - lv - ld := by
  have hk0 := r1_k_pos (pilot_slab_subset hk)
  have hA := pilot_A_bounds hk
  have hll := hlrl.trans (Real.log_le_log hrl hr.1)
  have hlu := (Real.log_le_log (hrl.trans_le hr.1) hr.2).trans hurl
  have hDlo := hld.trans (Real.log_le_log (by norm_num) (pilot_D0_bounds hk).1)
  have hDhi := (Real.log_le_log (D0a_pos (r1_a_pos (pilot_slab_subset hk)))
    (pilot_D0_bounds hk).2).trans hud
  have hurl0 : 0 ≤ url := hlrl0.trans (hll.trans hlu)
  have hp0 : 0 ≤ k / (k + 1) := by positivity
  have hmlo := (mul_le_mul_of_nonneg_right hA.1 hlrl0).trans
    (mul_le_mul_of_nonneg_left hll hp0)
  have hmhi := (mul_le_mul_of_nonneg_left hlu hp0).trans
    (mul_le_mul_of_nonneg_right hA.2 hurl0)
  unfold certE
  constructor <;> linarith


theorem pilot_log_Dlo :
    (65612057 : ℝ) / 100000000 ≤ Real.log ((1927301 : ℝ) / 1000000) ∧ Real.log ((1927301 : ℝ) / 1000000) ≤ (32806029 : ℝ) / 50000000 := by
  apply log_bounds_of_series (t := (927301 : ℝ) / 2927301) (by norm_num) (by norm_num) 9
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_Dhi :
    (6561351 : ℝ) / 10000000 ≤ Real.log ((1927329 : ℝ) / 1000000) ∧ Real.log ((1927329 : ℝ) / 1000000) ≤ (65613511 : ℝ) / 100000000 := by
  apply log_bounds_of_series (t := (927329 : ℝ) / 2927329) (by norm_num) (by norm_num) 9
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_plus_lo_rl :
    (-7677527 : ℝ) / 20000000 ≤ Real.log ((34060783 : ℝ) / 50000000) ∧ Real.log ((34060783 : ℝ) / 50000000) ≤ (-19193817 : ℝ) / 50000000 := by
  apply log_bounds_of_series (t := (-15939217 : ℝ) / 84060783) (by norm_num) (by norm_num) 6
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_plus_lo_ru :
    (-959689 : ℝ) / 2500000 ≤ Real.log ((68121617 : ℝ) / 100000000) ∧ Real.log ((68121617 : ℝ) / 100000000) ≤ (-38387559 : ℝ) / 100000000 := by
  apply log_bounds_of_series (t := (-31878383 : ℝ) / 168121617) (by norm_num) (by norm_num) 6
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_plus_lo_v :
    (-18057621 : ℝ) / 20000000 ≤ Real.log ((2027 : ℝ) / 5000) ∧ Real.log ((2027 : ℝ) / 5000) ≤ (-11286013 : ℝ) / 12500000 := by
  apply log_bounds_of_series (t := (-2973 : ℝ) / 7027) (by norm_num) (by norm_num) 13
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_E_plus_lo {k : ℝ} (hk : k ∈ pilotSlab) :
    certE k (r1A k) ((2027 : ℝ) / 5000) < 0 := by
  have hr := pilot_ratio_bounds (v := (2027 : ℝ) / 5000) hk (by norm_num)
    (lo := (34060783 : ℝ) / 50000000) (hi := (68121617 : ℝ) / 100000000) (by norm_num) (by norm_num)
  have hb := pilot_E_bounds_negative_log hk hr (by norm_num)
    pilot_log_plus_lo_rl.1 pilot_log_plus_lo_ru.2 (by norm_num)
    pilot_log_plus_lo_v.1 pilot_log_plus_lo_v.2 pilot_log_Dlo.1 pilot_log_Dhi.2
  linarith [hb.1, hb.2]

theorem pilot_log_plus_hi_rl :
    (-38263131 : ℝ) / 100000000 ≤ Real.log ((68206433 : ℝ) / 100000000) ∧ Real.log ((68206433 : ℝ) / 100000000) ≤ (-38263129 : ℝ) / 100000000 := by
  apply log_bounds_of_series (t := (-31793567 : ℝ) / 168206433) (by norm_num) (by norm_num) 6
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_plus_hi_ru :
    (-2391441 : ℝ) / 6250000 ≤ Real.log ((17051621 : ℝ) / 25000000) ∧ Real.log ((17051621 : ℝ) / 25000000) ≤ (-7652611 : ℝ) / 20000000 := by
  apply log_bounds_of_series (t := (-7948379 : ℝ) / 42051621) (by norm_num) (by norm_num) 6
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_plus_hi_v :
    (-90214131 : ℝ) / 100000000 ≤ Real.log ((4057 : ℝ) / 10000) ∧ Real.log ((4057 : ℝ) / 10000) ≤ (-9021413 : ℝ) / 10000000 := by
  apply log_bounds_of_series (t := (-5943 : ℝ) / 14057) (by norm_num) (by norm_num) 13
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_E_plus_hi {k : ℝ} (hk : k ∈ pilotSlab) :
    0 < certE k (r1A k) ((4057 : ℝ) / 10000) := by
  have hr := pilot_ratio_bounds (v := (4057 : ℝ) / 10000) hk (by norm_num)
    (lo := (68206433 : ℝ) / 100000000) (hi := (17051621 : ℝ) / 25000000) (by norm_num) (by norm_num)
  have hb := pilot_E_bounds_negative_log hk hr (by norm_num)
    pilot_log_plus_hi_rl.1 pilot_log_plus_hi_ru.2 (by norm_num)
    pilot_log_plus_hi_v.1 pilot_log_plus_hi_v.2 pilot_log_Dlo.1 pilot_log_Dhi.2
  linarith [hb.1, hb.2]

theorem pilot_log_minus_lo_rl :
    (72047177 : ℝ) / 50000000 ≤ Real.log ((42246801 : ℝ) / 10000000) ∧ Real.log ((42246801 : ℝ) / 10000000) ≤ (28818871 : ℝ) / 20000000 := by
  apply log_bounds_of_series (t := (32246801 : ℝ) / 52246801) (by norm_num) (by norm_num) 23
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_minus_lo_ru :
    (144094377 : ℝ) / 100000000 ≤ Real.log ((105617027 : ℝ) / 25000000) ∧ Real.log ((105617027 : ℝ) / 25000000) ≤ (72047189 : ℝ) / 50000000 := by
  apply log_bounds_of_series (t := (80617027 : ℝ) / 130617027) (by norm_num) (by norm_num) 23
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_minus_lo_v :
    (27002713 : ℝ) / 100000000 ≤ Real.log ((131 : ℝ) / 100) ∧ Real.log ((131 : ℝ) / 100) ≤ (13501357 : ℝ) / 50000000 := by
  apply log_bounds_of_series (t := (31 : ℝ) / 231) (by norm_num) (by norm_num) 5
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_E_minus_lo {k : ℝ} (hk : k ∈ pilotSlab) :
    0 < certE k (r1A k) ((131 : ℝ) / 100) := by
  have hr := pilot_ratio_bounds (v := (131 : ℝ) / 100) hk (by norm_num)
    (lo := (42246801 : ℝ) / 10000000) (hi := (105617027 : ℝ) / 25000000) (by norm_num) (by norm_num)
  have hb := pilot_E_bounds_positive_log hk hr (by norm_num)
    pilot_log_minus_lo_rl.1 pilot_log_minus_lo_ru.2 (by norm_num)
    pilot_log_minus_lo_v.1 pilot_log_minus_lo_v.2 pilot_log_Dlo.1 pilot_log_Dhi.2
  linarith [hb.1, hb.2]

theorem pilot_log_minus_hi_rl :
    (144045129 : ℝ) / 100000000 ≤ Real.log ((422260101 : ℝ) / 100000000) ∧ Real.log ((422260101 : ℝ) / 100000000) ≤ (14404513 : ℝ) / 10000000 := by
  apply log_bounds_of_series (t := (322260101 : ℝ) / 522260101) (by norm_num) (by norm_num) 23
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_minus_hi_ru :
    (4501411 : ℝ) / 3125000 ≤ Real.log ((211130099 : ℝ) / 50000000) ∧ Real.log ((211130099 : ℝ) / 50000000) ≤ (144045153 : ℝ) / 100000000 := by
  apply log_bounds_of_series (t := (161130099 : ℝ) / 261130099) (by norm_num) (by norm_num) 23
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_log_minus_hi_v :
    (27017979 : ℝ) / 100000000 ≤ Real.log ((6551 : ℝ) / 5000) ∧ Real.log ((6551 : ℝ) / 5000) ≤ (1350899 : ℝ) / 5000000 := by
  apply log_bounds_of_series (t := (1551 : ℝ) / 11551) (by norm_num) (by norm_num) 5
  · norm_num [sum_range_succ]
  · norm_num [sum_range_succ]

theorem pilot_E_minus_hi {k : ℝ} (hk : k ∈ pilotSlab) :
    certE k (r1A k) ((6551 : ℝ) / 5000) < 0 := by
  have hr := pilot_ratio_bounds (v := (6551 : ℝ) / 5000) hk (by norm_num)
    (lo := (422260101 : ℝ) / 100000000) (hi := (211130099 : ℝ) / 50000000) (by norm_num) (by norm_num)
  have hb := pilot_E_bounds_positive_log hk hr (by norm_num)
    pilot_log_minus_hi_rl.1 pilot_log_minus_hi_ru.2 (by norm_num)
    pilot_log_minus_hi_v.1 pilot_log_minus_hi_v.2 pilot_log_Dlo.1 pilot_log_Dhi.2
  linarith [hb.1, hb.2]

theorem pilot_positive_root_box {k : ℝ} (hk : k ∈ pilotSlab) :
    ∃ v ∈ Ioo (2027 / 5000 : ℝ) (4057 / 10000), certE k (r1A k) v = 0 ∧
      certPoint (r1A k) v = Stage10.xpS (pilotReference hk).angles.k (pilotReference hk).quantile := by
  exact certificate_plus_bracket (r1_k_pos (pilot_slab_subset hk))
    (r1_a_pos (pilot_slab_subset hk)) (r1_a_mem (pilot_slab_subset hk)).2
    (r1_H1 (pilot_slab_subset hk)) (v0 := (9 : ℝ) / 25)
    (by linarith [pilot_q_bound hk]) (by norm_num) (pilot_negative_certificate hk)
    (by norm_num) (by norm_num) (by norm_num) (pilot_E_plus_lo hk) (pilot_E_plus_hi hk)

theorem pilot_negative_root_box {k : ℝ} (hk : k ∈ pilotSlab) :
    ∃ v ∈ Ioo (131 / 100 : ℝ) (6551 / 5000), certE k (r1A k) v = 0 ∧
      certPoint (r1A k) v = Stage10.xmS (pilotReference hk).angles.k (pilotReference hk).quantile := by
  exact certificate_minus_bracket (r1_k_pos (pilot_slab_subset hk))
    (r1_a_pos (pilot_slab_subset hk)) (r1_a_mem (pilot_slab_subset hk)).2
    (r1_H1 (pilot_slab_subset hk)) (v0 := (9 : ℝ) / 25)
    (by linarith [pilot_q_bound hk]) (by norm_num) (pilot_negative_certificate hk)
    (by norm_num) (by norm_num) (pilot_E_minus_lo hk) (pilot_E_minus_hi hk)

end EP1038.ReferenceCert
