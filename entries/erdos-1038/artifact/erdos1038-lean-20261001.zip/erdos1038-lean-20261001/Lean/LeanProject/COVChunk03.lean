import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_15 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((9579 : ℝ) / 15979) ((2403 : ℝ) / 4003))
    (hq : RB (qa a) ((867089 : ℝ) / 100000000) ((883777 : ℝ) / 100000000))
    (hd : RB (D0a a) ((49127803 : ℝ) / 25000000) ((196576241 : ℝ) / 100000000))
    : certE k a ((21746233 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((43877457 : ℝ) / 100000000) ∧ 0 < certE k a ((127463669 : ℝ) / 100000000) ∧ certE k a ((127655719 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((3759 : ℝ) / 50000000) ((7811 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((21746233 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((8696931 : ℝ) / 20000000) ((10871237 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((21746233 : ℝ) / 50000000) ((21746233 : ℝ) / 50000000) ((21746233 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((28253767 : ℝ) / 50000000))
  have h3 : RB z3 ((76953729 : ℝ) / 100000000) ((76954249 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((28253767 : ℝ) / 50000000) ((28253767 : ℝ) / 50000000) ((28253767 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-26196587 : ℝ) / 100000000) ((-2619591 : ℝ) / 10000000) := rb_log h3 (by norm_num) cov_log_270.1 cov_log_271.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-7862903 : ℝ) / 50000000) ((-628151 : ℝ) / 4000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((21746233 : ℝ) / 50000000))
  have h6 : RB z6 ((-83258247 : ℝ) / 100000000) ((-16651649 : ℝ) / 20000000) := rb_log (show RB ((21746233 : ℝ) / 50000000) ((21746233 : ℝ) / 50000000) ((21746233 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_272.1 cov_log_272.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((67532439 : ℝ) / 100000000) ((8444309 : ℝ) / 12500000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((6755493 : ℝ) / 10000000) ((33794009 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_273.1 cov_log_274.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-55579 : ℝ) / 100000000) ((-229 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((3759 : ℝ) / 50000000) ((7811 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43877457 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((21934823 : ℝ) / 50000000) ((43869939 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43877457 : ℝ) / 100000000) ((43877457 : ℝ) / 100000000) ((43877457 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56122543 : ℝ) / 100000000))
  have h12 : RB z12 ((78167601 : ℝ) / 100000000) ((19542031 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((56122543 : ℝ) / 100000000) ((56122543 : ℝ) / 100000000) ((56122543 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-12315747 : ℝ) / 50000000) ((-3078853 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_275.1 cov_log_276.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-14786281 : ℝ) / 100000000) ((-7382773 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43877457 : ℝ) / 100000000))
  have h15 : RB z15 ((-10297119 : ℝ) / 12500000) ((-1647539 : ℝ) / 2000000) := rb_log (show RB ((43877457 : ℝ) / 100000000) ((43877457 : ℝ) / 100000000) ((43877457 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_277.1 cov_log_277.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67590669 : ℝ) / 100000000) ((33805703 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((6755493 : ℝ) / 10000000) ((33794009 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_273.1 cov_log_274.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2651 : ℝ) / 100000000) ((14119 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((3759 : ℝ) / 50000000) ((7811 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((127463669 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((63727929 : ℝ) / 50000000) ((127456151 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((127463669 : ℝ) / 100000000) ((127463669 : ℝ) / 100000000) ((127463669 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((27463669 : ℝ) / 100000000))
  have h21 : RB z21 ((464088967 : ℝ) / 100000000) ((92818007 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((27463669 : ℝ) / 100000000) ((27463669 : ℝ) / 100000000) ((27463669 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((9593163 : ℝ) / 6250000) ((153490841 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_278.1 cov_log_279.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23003419 : ℝ) / 25000000) ((46070259 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((127463669 : ℝ) / 100000000))
  have h24 : RB z24 ((12133059 : ℝ) / 50000000) ((24266119 : ℝ) / 100000000) := rb_log (show RB ((127463669 : ℝ) / 100000000) ((127463669 : ℝ) / 100000000) ((127463669 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_280.1 cov_log_280.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67747557 : ℝ) / 100000000) ((84843 : ℝ) / 125000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((6755493 : ℝ) / 10000000) ((33794009 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_273.1 cov_log_274.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((159539 : ℝ) / 100000000) ((31947 : ℝ) / 10000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((3759 : ℝ) / 50000000) ((7811 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((127655719 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((31911977 : ℝ) / 25000000) ((127648201 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((127655719 : ℝ) / 100000000) ((127655719 : ℝ) / 100000000) ((127655719 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((27655719 : ℝ) / 100000000))
  have h30 : RB z30 ((461560619 : ℝ) / 100000000) ((5769521 : ℝ) / 1250000) := rb_div_signed h29 (show RB ((27655719 : ℝ) / 100000000) ((27655719 : ℝ) / 100000000) ((27655719 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((152944321 : ℝ) / 100000000) ((152944553 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_281.1 cov_log_282.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91686191 : ℝ) / 100000000) ((91812581 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((127655719 : ℝ) / 100000000))
  have h33 : RB z33 ((976667 : ℝ) / 4000000) ((6104169 : ℝ) / 25000000) := rb_log (show RB ((127655719 : ℝ) / 100000000) ((127655719 : ℝ) / 100000000) ((127655719 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_283.1 cov_log_283.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((13453903 : ℝ) / 20000000) ((33697953 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((6755493 : ℝ) / 10000000) ((33794009 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_273.1 cov_log_274.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-318503 : ℝ) / 100000000) ((-9939 : ℝ) / 6250000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((21746233 : ℝ) / 50000000)) ((-55579 : ℝ) / 100000000) ((-229 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43877457 : ℝ) / 100000000)) ((2651 : ℝ) / 100000000) ((14119 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((127463669 : ℝ) / 100000000)) ((159539 : ℝ) / 100000000) ((31947 : ℝ) / 10000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((127655719 : ℝ) / 100000000)) ((-318503 : ℝ) / 100000000) ((-9939 : ℝ) / 6250000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_15 {k A q d vp vm : ℝ}
    (hk : RB k ((9579 : ℝ) / 6400) ((2403 : ℝ) / 1600))
    (hA : RB A ((9579 : ℝ) / 15979) ((2403 : ℝ) / 4003))
    (hq : RB q ((867089 : ℝ) / 100000000) ((883777 : ℝ) / 100000000))
    (hd : RB d ((49127803 : ℝ) / 25000000) ((196576241 : ℝ) / 100000000))
    (hp : RB vp ((21746233 : ℝ) / 50000000) ((43877457 : ℝ) / 100000000))
    (hm : RB vm ((127463669 : ℝ) / 100000000) ((127655719 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((3759 : ℝ) / 50000000) ((7811 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99992189 : ℝ) / 100000000) ((49996241 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((14985687 : ℝ) / 25000000) ((12005093 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((8567 : ℝ) / 50000000) ((449 : ℝ) / 2500000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((2499551 : ℝ) / 2500000) ((49991433 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56122543 : ℝ) / 100000000) ((28253767 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((56112463 : ℝ) / 100000000) ((14124463 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((6631087 : ℝ) / 6250000) ((106973499 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((381087 : ℝ) / 6250000) ((6973499 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99992189 : ℝ) / 100000000) ((49996241 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((14985687 : ℝ) / 25000000) ((12005093 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((5889 : ℝ) / 100000000) ((6129 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99993871 : ℝ) / 100000000) ((99994111 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((27463669 : ℝ) / 100000000) ((27655719 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((5492397 : ℝ) / 20000000) ((27654091 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((216759061 : ℝ) / 100000000) ((218576571 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((316759061 : ℝ) / 100000000) ((318576571 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1434000349 : ℝ) / 100000000) ((1640045449 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31389627 : ℝ) / 100000000) ((31569737 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((9579 : ℝ) / 3200) ((2403 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((324447 : ℝ) / 12500000) ((1327323 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100867089 : ℝ) / 100000000) ((100883777 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2572837 : ℝ) / 100000000) ((1315913 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((102572837 : ℝ) / 100000000) ((51315913 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((20896553 : ℝ) / 25000000) ((84163253 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((82128139 : ℝ) / 50000000) ((1034031 : ℝ) / 625000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13859273 : ℝ) / 25000000) ((14003021 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((6711 : ℝ) / 50000000) ((1409 : ℝ) / 10000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((9998591 : ℝ) / 10000000) ((49993289 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((82116567 : ℝ) / 50000000) ((82711377 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((49127803 : ℝ) / 12500000) ((196576241 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1703927 : ℝ) / 50000000) ((108581 : ℝ) / 3125000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((15979 : ℝ) / 6400) ((4003 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((34053 : ℝ) / 2500000) ((86979 : ℝ) / 6250000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((12351 : ℝ) / 625000) ((254003 : ℝ) / 12500000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((637351 : ℝ) / 625000) ((12754003 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((146233849 : ℝ) / 10000000) ((1673371567 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((16981 : ℝ) / 2500000) ((693357 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((2516981 : ℝ) / 2500000) ((100693357 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31602837 : ℝ) / 100000000) ((7947157 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1493941327 : ℝ) / 100000000) ((341032039 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((20349273 : ℝ) / 100000000) ((23730101 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((15979 : ℝ) / 6400) ((4003 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((102572837 : ℝ) / 50000000) ((51315913 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((183173747 : ℝ) / 12500000) ((835807593 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1503092071 : ℝ) / 50000000) ((3431218379 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((3638239 : ℝ) / 50000000) ((2080607 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-262052327 : ℝ) / 100000000) ((-124310807 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_284.1 cov_log_285.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1703927 : ℝ) / 100000000) ((108581 : ℝ) / 6250000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-203611733 : ℝ) / 50000000) ((-40528403 : ℝ) / 10000000) := rb_log h49 (by norm_num) cov_log_286.1 cov_log_287.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((6755493 : ℝ) / 10000000) ((33794009 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_273.1 cov_log_274.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((10111073 : ℝ) / 10000000) ((20301751 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-9566023 : ℝ) / 3125000) ((-12151011 : ℝ) / 4000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((18020293 : ℝ) / 100000000) ((9604957 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((75938543 : ℝ) / 100000000) ((18880197 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-230174193 : ℝ) / 100000000) ((-20937429 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((102572837 : ℝ) / 100000000) ((51315913 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-262052327 : ℝ) / 100000000) ((-124310807 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-230174193 : ℝ) / 100000000) ((-20937429 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((307 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((12351 : ℝ) / 625000) ((254003 : ℝ) / 12500000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((12754003 : ℝ) / 25000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((307 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-116854107 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((307 : ℝ) / 100) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_4, cov_h_3]
  have hP : ((640882421 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((20937429 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((20937429 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((342 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((342 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((347 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((347 : ℝ) / 125)) (lo := ((342 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((352 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((352 : ℝ) / 125)) (lo := ((347 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((357 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((357 : ℝ) / 125)) (lo := ((352 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((362 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((362 : ℝ) / 125)) (lo := ((357 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((367 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((367 : ℝ) / 125)) (lo := ((362 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((372 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((372 : ℝ) / 125)) (lo := ((367 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((377 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((377 : ℝ) / 125)) (lo := ((372 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((382 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((382 : ℝ) / 125)) (lo := ((377 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((307 : ℝ) / 100)) (lo := ((382 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_15 {k : ℝ} (hk : RB k ((9579 : ℝ) / 6400) ((2403 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((9579 : ℝ) / 15979) ((2403 : ℝ) / 4003) ∧
    RB (qa (r1A k)) ((867089 : ℝ) / 100000000) ((883777 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((49127803 : ℝ) / 25000000) ((196576241 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2338623 : ℝ) / 6250000) ((2403 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((61777 : ℝ) / 32000) ((12073877 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((69471779 : ℝ) / 50000000) ((6949497 : ℝ) / 5000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((140182457 : ℝ) / 50000000) ((280411297 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140182457 : ℝ) / 100000000) ((140205649 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((49127803 : ℝ) / 25000000) ((196576241 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((426123 : ℝ) / 6250000) ((2223 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((426123 : ℝ) / 25000000) ((1736719 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((867089 : ℝ) / 100000000) ((883777 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((49127803 : ℝ) / 25000000) ((196576241 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((867089 : ℝ) / 100000000) ((883777 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((9579 : ℝ) / 15979) ((2403 : ℝ) / 4003) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_15 {k : ℝ} (hk : RB k ((9579 : ℝ) / 6400) ((2403 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_15 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_15 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((21746233 : ℝ) / 50000000)) (ph := ((43877457 : ℝ) / 100000000)) (ml := ((127463669 : ℝ) / 100000000)) (mh := ((127655719 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_15 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_16 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2403 : ℝ) / 4003) ((1929 : ℝ) / 3209))
    (hq : RB (qa a) ((35351 : ℝ) / 4000000) ((450237 : ℝ) / 50000000))
    (hd : RB (D0a a) ((98223089 : ℝ) / 50000000) ((12281951 : ℝ) / 6250000))
    : certE k a ((21678771 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((43857129 : ℝ) / 100000000) ∧ 0 < certE k a ((1020223 : ℝ) / 800000) ∧ certE k a ((63859677 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((781 : ℝ) / 10000000) ((8109 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((21678771 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((43349433 : ℝ) / 100000000) ((10837433 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((21678771 : ℝ) / 50000000) ((21678771 : ℝ) / 50000000) ((21678771 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((28321229 : ℝ) / 50000000))
  have h3 : RB z3 ((38265847 : ℝ) / 50000000) ((76532223 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((28321229 : ℝ) / 50000000) ((28321229 : ℝ) / 50000000) ((28321229 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-6686631 : ℝ) / 25000000) ((-26745831 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_288.1 cov_log_289.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-100487 : ℝ) / 625000) ((-4013879 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((21678771 : ℝ) / 50000000))
  have h6 : RB z6 ((-83568953 : ℝ) / 100000000) ((-83568951 : ℝ) / 100000000) := rb_log (show RB ((21678771 : ℝ) / 50000000) ((21678771 : ℝ) / 50000000) ((21678771 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_290.1 cov_log_290.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((67491031 : ℝ) / 100000000) ((67513437 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((6752183 : ℝ) / 10000000) ((33777467 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_291.1 cov_log_292.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-63903 : ℝ) / 100000000) ((-8393 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((781 : ℝ) / 10000000) ((8109 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43857129 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((2192451 : ℝ) / 5000000) ((43849319 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43857129 : ℝ) / 100000000) ((43857129 : ℝ) / 100000000) ((43857129 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56142871 : ℝ) / 100000000))
  have h12 : RB z12 ((488141 : ℝ) / 625000) ((39051547 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((56142871 : ℝ) / 100000000) ((56142871 : ℝ) / 100000000) ((56142871 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-1544671 : ℝ) / 6250000) ((-24714051 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_293.1 cov_log_294.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-1857071 : ℝ) / 12500000) ((-14835839 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43857129 : ℝ) / 100000000))
  have h15 : RB z15 ((-20605823 : ℝ) / 25000000) ((-8242329 : ℝ) / 10000000) := rb_log (show RB ((43857129 : ℝ) / 100000000) ((43857129 : ℝ) / 100000000) ((43857129 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_295.1 cov_log_295.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33783361 : ℝ) / 50000000) ((67587453 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((6752183 : ℝ) / 10000000) ((33777467 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_291.1 cov_log_292.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2947 : ℝ) / 25000000) ((65623 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((781 : ℝ) / 10000000) ((8109 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((1020223 : ℝ) / 800000)) - (z19)
  have h20 : RB z20 ((63759883 : ℝ) / 50000000) ((25504013 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((1020223 : ℝ) / 800000) ((1020223 : ℝ) / 800000) ((1020223 : ℝ) / 800000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((220223 : ℝ) / 800000))
  have h21 : RB z21 ((115809671 : ℝ) / 25000000) ((463239771 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((220223 : ℝ) / 800000) ((220223 : ℝ) / 800000) ((220223 : ℝ) / 800000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((6132289 : ℝ) / 4000000) ((76653731 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_296.1 cov_log_297.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23007573 : ℝ) / 25000000) ((18431293 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((1020223 : ℝ) / 800000))
  have h24 : RB z24 ((12158239 : ℝ) / 50000000) ((24316479 : ℝ) / 100000000) := rb_log (show RB ((1020223 : ℝ) / 800000) ((1020223 : ℝ) / 800000) ((1020223 : ℝ) / 800000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_298.1 cov_log_298.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67713813 : ℝ) / 100000000) ((67839987 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((6752183 : ℝ) / 10000000) ((33777467 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_291.1 cov_log_292.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((158879 : ℝ) / 100000000) ((318157 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((781 : ℝ) / 10000000) ((8109 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((63859677 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((25542249 : ℝ) / 20000000) ((15963943 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((63859677 : ℝ) / 50000000) ((63859677 : ℝ) / 50000000) ((63859677 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((13859677 : ℝ) / 50000000))
  have h30 : RB z30 ((230364757 : ℝ) / 50000000) ((460730593 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((13859677 : ℝ) / 50000000) ((13859677 : ℝ) / 50000000) ((13859677 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((76382047 : ℝ) / 50000000) ((152764331 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_299.1 cov_log_300.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91704251 : ℝ) / 100000000) ((91829977 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((63859677 : ℝ) / 50000000))
  have h33 : RB z33 ((1529157 : ℝ) / 6250000) ((24466513 : ℝ) / 100000000) := rb_log (show RB ((63859677 : ℝ) / 50000000) ((63859677 : ℝ) / 50000000) ((63859677 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_301.1 cov_log_301.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33618869 : ℝ) / 50000000) ((13472693 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((6752183 : ℝ) / 10000000) ((33777467 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_291.1 cov_log_292.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-79299 : ℝ) / 25000000) ((-31673 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((21678771 : ℝ) / 50000000)) ((-63903 : ℝ) / 100000000) ((-8393 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43857129 : ℝ) / 100000000)) ((2947 : ℝ) / 25000000) ((65623 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((1020223 : ℝ) / 800000)) ((158879 : ℝ) / 100000000) ((318157 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((63859677 : ℝ) / 50000000)) ((-79299 : ℝ) / 25000000) ((-31673 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_16 {k A q d vp vm : ℝ}
    (hk : RB k ((2403 : ℝ) / 1600) ((1929 : ℝ) / 1280))
    (hA : RB A ((2403 : ℝ) / 4003) ((1929 : ℝ) / 3209))
    (hq : RB q ((35351 : ℝ) / 4000000) ((450237 : ℝ) / 50000000))
    (hd : RB d ((98223089 : ℝ) / 50000000) ((12281951 : ℝ) / 6250000))
    (hp : RB vp ((21678771 : ℝ) / 50000000) ((43857129 : ℝ) / 100000000))
    (hm : RB vm ((1020223 : ℝ) / 800000) ((63859677 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((781 : ℝ) / 10000000) ((8109 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99991891 : ℝ) / 100000000) ((9999219 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((60025109 : ℝ) / 100000000) ((6010749 : ℝ) / 10000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((17807 : ℝ) / 100000000) ((18703 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99981297 : ℝ) / 100000000) ((99982193 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56142871 : ℝ) / 100000000) ((28321229 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((5613237 : ℝ) / 10000000) ((14158093 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((13248851 : ℝ) / 12500000) ((10708169 : ℝ) / 10000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((748851 : ℝ) / 12500000) ((708169 : ℝ) / 10000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99991891 : ℝ) / 100000000) ((9999219 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((60025109 : ℝ) / 100000000) ((6010749 : ℝ) / 10000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3057 : ℝ) / 50000000) ((6359 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99993641 : ℝ) / 100000000) ((49996943 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((220223 : ℝ) / 800000) ((13859677 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((6881531 : ℝ) / 25000000) ((1385883 : ℝ) / 5000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((108279539 : ℝ) / 50000000) ((54591313 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((158279539 : ℝ) / 50000000) ((79591313 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1412092311 : ℝ) / 100000000) ((834611959 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31410463 : ℝ) / 100000000) ((31589681 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2403 : ℝ) / 800) ((1929 : ℝ) / 640) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2654639 : ℝ) / 100000000) ((542817 : ℝ) / 20000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((4035351 : ℝ) / 4000000) ((50450237 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2630947 : ℝ) / 100000000) ((2690309 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((102630947 : ℝ) / 100000000) ((102690309 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((41835373 : ℝ) / 50000000) ((21090453 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((82183991 : ℝ) / 50000000) ((165780423 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((55292951 : ℝ) / 100000000) ((28007021 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((6971 : ℝ) / 50000000) ((7333 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49992667 : ℝ) / 50000000) ((49993029 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1314751 : ℝ) / 800000) ((16575731 : ℝ) / 10000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((98223089 : ℝ) / 25000000) ((12281951 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((868071 : ℝ) / 25000000) ((707813 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4003 : ℝ) / 1600) ((3209 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((692509 : ℝ) / 50000000) ((707283 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1007561 : ℝ) / 50000000) ((2076857 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51007561 : ℝ) / 50000000) ((102076857 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1440547693 : ℝ) / 100000000) ((106493207 : ℝ) / 6250000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((345983 : ℝ) / 50000000) ((7061 : ℝ) / 1000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50345983 : ℝ) / 50000000) ((1007061 : ℝ) / 1000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((7906953 : ℝ) / 25000000) ((248537 : ℝ) / 781250) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((294435101 : ℝ) / 20000000) ((108481503 : ℝ) / 6250000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((4077979 : ℝ) / 20000000) ((613817 : ℝ) / 2500000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4003 : ℝ) / 1600) ((3209 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((102630947 : ℝ) / 50000000) ((102690309 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((721751387 : ℝ) / 50000000) ((1700813599 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2962961133 : ℝ) / 100000000) ((3493141481 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7162249 : ℝ) / 100000000) ((2115309 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-263634619 : ℝ) / 100000000) ((-61741873 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_302.1 cov_log_303.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((868071 : ℝ) / 50000000) ((1769533 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-101337621 : ℝ) / 25000000) ((-403445451 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_304.1 cov_log_305.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((6752183 : ℝ) / 10000000) ((33777467 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_291.1 cov_log_292.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((25352337 : ℝ) / 25000000) ((101807397 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-18996321 : ℝ) / 6250000) ((-150819027 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((17685737 : ℝ) / 100000000) ((19099173 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((36015899 : ℝ) / 50000000) ((23417449 : ℝ) / 25000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-115954669 : ℝ) / 50000000) ((-103984129 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((102630947 : ℝ) / 100000000) ((102690309 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-263634619 : ℝ) / 100000000) ((-61741873 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-115954669 : ℝ) / 50000000) ((-103984129 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((307 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1007561 : ℝ) / 50000000) ((2076857 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((102076857 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((307 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-117645253 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((307 : ℝ) / 100) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_4, cov_h_3]
  have hP : ((636216103 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((103984129 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((103984129 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1349 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1349 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1369 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1369 : ℝ) / 500)) (lo := ((1349 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1389 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1389 : ℝ) / 500)) (lo := ((1369 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1409 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1409 : ℝ) / 500)) (lo := ((1389 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1429 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1429 : ℝ) / 500)) (lo := ((1409 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1449 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1449 : ℝ) / 500)) (lo := ((1429 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1469 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1469 : ℝ) / 500)) (lo := ((1449 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1489 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1489 : ℝ) / 500)) (lo := ((1469 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1509 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1509 : ℝ) / 500)) (lo := ((1489 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1529 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1529 : ℝ) / 500)) (lo := ((1509 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((307 : ℝ) / 100)) (lo := ((1529 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_16 {k : ℝ} (hk : RB k ((2403 : ℝ) / 1600) ((1929 : ℝ) / 1280)) :
    RB (k / (k + 1)) ((2403 : ℝ) / 4003) ((1929 : ℝ) / 3209) ∧
    RB (qa (r1A k)) ((35351 : ℝ) / 4000000) ((450237 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((98223089 : ℝ) / 50000000) ((12281951 : ℝ) / 6250000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2403 : ℝ) / 6400) ((18837891 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((96462109 : ℝ) / 50000000) ((61777 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((69448581 : ℝ) / 50000000) ((138943559 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((140159259 : ℝ) / 50000000) ((70091229 : ℝ) / 25000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140159259 : ℝ) / 100000000) ((70091229 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((98223089 : ℝ) / 50000000) ((12281951 : ℝ) / 6250000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2223 : ℝ) / 32000) ((3537891 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((868359 : ℝ) / 50000000) ((884473 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((35351 : ℝ) / 4000000) ((450237 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((98223089 : ℝ) / 50000000) ((12281951 : ℝ) / 6250000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((35351 : ℝ) / 4000000) ((450237 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2403 : ℝ) / 4003) ((1929 : ℝ) / 3209) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_16 {k : ℝ} (hk : RB k ((2403 : ℝ) / 1600) ((1929 : ℝ) / 1280)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_16 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_16 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((21678771 : ℝ) / 50000000)) (ph := ((43857129 : ℝ) / 100000000)) (ml := ((1020223 : ℝ) / 800000)) (mh := ((63859677 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_16 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_17 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1929 : ℝ) / 3209) ((4839 : ℝ) / 8039))
    (hq : RB (qa a) ((900473 : ℝ) / 100000000) ((458591 : ℝ) / 50000000))
    (hd : RB (D0a a) ((196381133 : ℝ) / 100000000) ((39289237 : ℝ) / 20000000))
    : certE k a ((43285129 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((8755353 : ℝ) / 20000000) ∧ 0 < certE k a ((12759189 : ℝ) / 10000000) ∧ certE k a ((127782803 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((2027 : ℝ) / 25000000) ((8413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((43285129 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((10819179 : ℝ) / 25000000) ((43277021 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43285129 : ℝ) / 100000000) ((43285129 : ℝ) / 100000000) ((43285129 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((56714871 : ℝ) / 100000000))
  have h3 : RB z3 ((19076441 : ℝ) / 25000000) ((76306303 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((56714871 : ℝ) / 100000000) ((56714871 : ℝ) / 100000000) ((56714871 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-27042171 : ℝ) / 100000000) ((-3380183 : ℝ) / 12500000) := rb_log h3 (by norm_num) cov_log_306.1 cov_log_307.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-813889 : ℝ) / 5000000) ((-8127607 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((43285129 : ℝ) / 100000000))
  have h6 : RB z6 ((-83736107 : ℝ) / 100000000) ((-16747221 : ℝ) / 20000000) := rb_log (show RB ((43285129 : ℝ) / 100000000) ((43285129 : ℝ) / 100000000) ((43285129 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_308.1 cov_log_308.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((2698333 : ℝ) / 4000000) ((67480893 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33744357 : ℝ) / 50000000) ((13504367 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_309.1 cov_log_310.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-6351 : ℝ) / 10000000) ((-7821 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((2027 : ℝ) / 25000000) ((8413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((8755353 : ℝ) / 20000000)) - (z10)
  have h11 : RB z11 ((1367761 : ℝ) / 3125000) ((43768657 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((8755353 : ℝ) / 20000000) ((8755353 : ℝ) / 20000000) ((8755353 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((11244647 : ℝ) / 20000000))
  have h12 : RB z12 ((15569489 : ℝ) / 20000000) ((19461997 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((11244647 : ℝ) / 20000000) ((11244647 : ℝ) / 20000000) ((11244647 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-25041911 : ℝ) / 100000000) ((-25041213 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_311.1 cov_log_312.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-7536871 : ℝ) / 50000000) ((-752641 : ℝ) / 5000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((8755353 : ℝ) / 20000000))
  have h15 : RB z15 ((-826067 : ℝ) / 1000000) ((-41303349 : ℝ) / 50000000) := rb_log (show RB ((8755353 : ℝ) / 20000000) ((8755353 : ℝ) / 20000000) ((8755353 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_313.1 cov_log_313.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16883239 : ℝ) / 25000000) ((1688847 : ℝ) / 2500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33744357 : ℝ) / 50000000) ((13504367 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_309.1 cov_log_310.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((11121 : ℝ) / 100000000) ((32583 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((2027 : ℝ) / 25000000) ((8413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((12759189 : ℝ) / 10000000)) - (z19)
  have h20 : RB z20 ((127583477 : ℝ) / 100000000) ((63791891 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((12759189 : ℝ) / 10000000) ((12759189 : ℝ) / 10000000) ((12759189 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((2759189 : ℝ) / 10000000))
  have h21 : RB z21 ((92478969 : ℝ) / 20000000) ((462395951 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((2759189 : ℝ) / 10000000) ((2759189 : ℝ) / 10000000) ((2759189 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((76562449 : ℝ) / 50000000) ((7656257 : ℝ) / 5000000) := rb_log h21 (by norm_num) cov_log_314.1 cov_log_315.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92046721 : ℝ) / 100000000) ((9217223 : ℝ) / 10000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((12759189 : ℝ) / 10000000))
  have h24 : RB z24 ((12183331 : ℝ) / 50000000) ((24366663 : ℝ) / 100000000) := rb_log (show RB ((12759189 : ℝ) / 10000000) ((12759189 : ℝ) / 10000000) ((12759189 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_316.1 cov_log_316.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33840029 : ℝ) / 50000000) ((529731 : ℝ) / 781250) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33744357 : ℝ) / 50000000) ((13504367 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_309.1 cov_log_310.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((158223 : ℝ) / 100000000) ((158427 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((2027 : ℝ) / 25000000) ((8413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((127782803 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((12777439 : ℝ) / 10000000) ((25554939 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((127782803 : ℝ) / 100000000) ((127782803 : ℝ) / 100000000) ((127782803 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((27782803 : ℝ) / 100000000))
  have h30 : RB z30 ((459904603 : ℝ) / 100000000) ((229952851 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((27782803 : ℝ) / 100000000) ((27782803 : ℝ) / 100000000) ((27782803 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((152584889 : ℝ) / 100000000) ((152585131 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_317.1 cov_log_318.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91722109 : ℝ) / 100000000) ((91847177 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((127782803 : ℝ) / 100000000))
  have h33 : RB z33 ((12258089 : ℝ) / 50000000) ((24516179 : ℝ) / 100000000) := rb_log (show RB ((127782803 : ℝ) / 100000000) ((127782803 : ℝ) / 100000000) ((127782803 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_319.1 cov_log_319.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6720593 : ℝ) / 10000000) ((67330999 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33744357 : ℝ) / 50000000) ((13504367 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_309.1 cov_log_310.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-63181 : ℝ) / 20000000) ((-31543 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((43285129 : ℝ) / 100000000)) ((-6351 : ℝ) / 10000000) ((-7821 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((8755353 : ℝ) / 20000000)) ((11121 : ℝ) / 100000000) ((32583 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((12759189 : ℝ) / 10000000)) ((158223 : ℝ) / 100000000) ((158427 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((127782803 : ℝ) / 100000000)) ((-63181 : ℝ) / 20000000) ((-31543 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_17 {k A q d vp vm : ℝ}
    (hk : RB k ((1929 : ℝ) / 1280) ((4839 : ℝ) / 3200))
    (hA : RB A ((1929 : ℝ) / 3209) ((4839 : ℝ) / 8039))
    (hq : RB q ((900473 : ℝ) / 100000000) ((458591 : ℝ) / 50000000))
    (hd : RB d ((196381133 : ℝ) / 100000000) ((39289237 : ℝ) / 20000000))
    (hp : RB vp ((43285129 : ℝ) / 100000000) ((8755353 : ℝ) / 20000000))
    (hm : RB vm ((12759189 : ℝ) / 10000000) ((127782803 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((2027 : ℝ) / 25000000) ((8413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99991587 : ℝ) / 100000000) ((24997973 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((60107127 : ℝ) / 100000000) ((30094587 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((18521 : ℝ) / 100000000) ((19437 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99980563 : ℝ) / 100000000) ((99981479 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((11244647 : ℝ) / 20000000) ((56714871 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((28106153 : ℝ) / 50000000) ((56704367 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53000439 : ℝ) / 50000000) ((107074729 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3000439 : ℝ) / 50000000) ((7074729 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99991587 : ℝ) / 100000000) ((24997973 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((60107127 : ℝ) / 100000000) ((30094587 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((1269 : ℝ) / 20000000) ((3297 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49996703 : ℝ) / 50000000) ((19998731 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((2759189 : ℝ) / 10000000) ((27782803 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((2759007 : ℝ) / 10000000) ((27781041 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((2704503 : ℝ) / 1250000) ((109077603 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((3954503 : ℝ) / 1250000) ((159077603 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1413481703 : ℝ) / 100000000) ((833211407 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((39289 : ℝ) / 125000) ((6321907 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1929 : ℝ) / 640) ((4839 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2714081 : ℝ) / 100000000) ((2773903 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100900473 : ℝ) / 100000000) ((50458591 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1344707 : ℝ) / 50000000) ((687287 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((51344707 : ℝ) / 50000000) ((25687287 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((670521 : ℝ) / 800000) ((42248837 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((41149273 : ℝ) / 25000000) ((165992457 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27614157 : ℝ) / 50000000) ((27969589 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((7247 : ℝ) / 50000000) ((7617 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49992383 : ℝ) / 50000000) ((49992753 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((164572017 : ℝ) / 100000000) ((165968399 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((196381133 : ℝ) / 50000000) ((39289237 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1768359 : ℝ) / 50000000) ((3603539 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3209 : ℝ) / 1280) ((8039 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((87989 : ℝ) / 6250000) ((1437373 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((411393 : ℝ) / 20000000) ((2118931 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((20411393 : ℝ) / 20000000) ((102118931 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((721278263 : ℝ) / 50000000) ((425433291 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((70469 : ℝ) / 10000000) ((718841 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((10070469 : ℝ) / 10000000) ((100718841 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((7913173 : ℝ) / 25000000) ((15918379 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((737104609 : ℝ) / 50000000) ((866784961 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((20754271 : ℝ) / 100000000) ((12458933 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3209 : ℝ) / 1280) ((8039 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((51344707 : ℝ) / 25000000) ((25687287 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1444912903 : ℝ) / 100000000) ((1698032349 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((593509037 : ℝ) / 20000000) ((3489427543 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7184649 : ℝ) / 100000000) ((8465541 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-65830589 : ℝ) / 25000000) ((-123458313 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_320.1 cov_log_321.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1768359 : ℝ) / 100000000) ((180177 : ℝ) / 10000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-16140473 : ℝ) / 4000000) ((-200820033 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_322.1 cov_log_323.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33744357 : ℝ) / 50000000) ((13504367 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_309.1 cov_log_310.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((101707601 : ℝ) / 100000000) ((4084227 : ℝ) / 4000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-4715691 : ℝ) / 1562500) ((-299534391 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2184331 : ℝ) / 12500000) ((18871031 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((7012899 : ℝ) / 10000000) ((90926013 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-115837617 : ℝ) / 50000000) ((-104304189 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((51344707 : ℝ) / 50000000) ((25687287 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-65830589 : ℝ) / 25000000) ((-123458313 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-115837617 : ℝ) / 50000000) ((-104304189 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((153 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((411393 : ℝ) / 20000000) ((2118931 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((102118931 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((153 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-29337439 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((153 : ℝ) / 50) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_5, cov_h_3]
  have hP : ((159452227 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((104304189 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((104304189 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((339 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((339 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((344 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((344 : ℝ) / 125)) (lo := ((339 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((349 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((349 : ℝ) / 125)) (lo := ((344 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((354 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((354 : ℝ) / 125)) (lo := ((349 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((359 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((359 : ℝ) / 125)) (lo := ((354 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((364 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((364 : ℝ) / 125)) (lo := ((359 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((369 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((369 : ℝ) / 125)) (lo := ((364 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((374 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((374 : ℝ) / 125)) (lo := ((369 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((379 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((379 : ℝ) / 125)) (lo := ((374 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((153 : ℝ) / 50)) (lo := ((379 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_17 {k : ℝ} (hk : RB k ((1929 : ℝ) / 1280) ((4839 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((1929 : ℝ) / 3209) ((4839 : ℝ) / 8039) ∧
    RB (qa (r1A k)) ((900473 : ℝ) / 100000000) ((458591 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((196381133 : ℝ) / 100000000) ((39289237 : ℝ) / 20000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((37675781 : ℝ) / 100000000) ((2362793 : ℝ) / 6250000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((12049707 : ℝ) / 6250000) ((192924219 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138850751 : ℝ) / 100000000) ((34724291 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((280272107 : ℝ) / 100000000) ((280318521 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140136053 : ℝ) / 100000000) ((140159261 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((196381133 : ℝ) / 100000000) ((39289237 : ℝ) / 20000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((7075781 : ℝ) / 100000000) ((450293 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((353789 : ℝ) / 20000000) ((450293 : ℝ) / 25000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((900473 : ℝ) / 100000000) ((458591 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((196381133 : ℝ) / 100000000) ((39289237 : ℝ) / 20000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((900473 : ℝ) / 100000000) ((458591 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1929 : ℝ) / 3209) ((4839 : ℝ) / 8039) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_17 {k : ℝ} (hk : RB k ((1929 : ℝ) / 1280) ((4839 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_17 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_17 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((43285129 : ℝ) / 100000000)) (ph := ((8755353 : ℝ) / 20000000)) (ml := ((12759189 : ℝ) / 10000000)) (mh := ((127782803 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_17 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_18 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((4839 : ℝ) / 8039) ((9711 : ℝ) / 16111))
    (hq : RB (qa a) ((917181 : ℝ) / 100000000) ((466951 : ℝ) / 50000000))
    (hd : RB (D0a a) ((196316079 : ℝ) / 100000000) ((9819057 : ℝ) / 5000000))
    : certE k a ((8642771 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((4369769 : ℝ) / 10000000) ∧ 0 < certE k a ((25531143 : ℝ) / 20000000) ∧ certE k a ((7990379 : ℝ) / 6250000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((2103 : ℝ) / 25000000) ((4361 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8642771 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((43205133 : ℝ) / 100000000) ((43205443 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((8642771 : ℝ) / 20000000) ((8642771 : ℝ) / 20000000) ((8642771 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11357229 : ℝ) / 20000000))
  have h3 : RB z3 ((76083933 : ℝ) / 100000000) ((59441 : ℝ) / 78125) := rb_div_signed h2 (show RB ((11357229 : ℝ) / 20000000) ((11357229 : ℝ) / 20000000) ((11357229 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-6833327 : ℝ) / 25000000) ((-6833147 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_324.1 cov_log_325.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-16475313 : ℝ) / 100000000) ((-1028287 : ℝ) / 6250000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8642771 : ℝ) / 20000000))
  have h6 : RB z6 ((-10487613 : ℝ) / 12500000) ((-41950451 : ℝ) / 50000000) := rb_log (show RB ((8642771 : ℝ) / 20000000) ((8642771 : ℝ) / 20000000) ((8642771 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_326.1 cov_log_326.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((67425589 : ℝ) / 100000000) ((8431039 : ℝ) / 12500000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33727791 : ℝ) / 50000000) ((67488719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_327.1 cov_log_328.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-6313 : ℝ) / 10000000) ((-727 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((2103 : ℝ) / 25000000) ((4361 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((4369769 : ℝ) / 10000000)) - (z10)
  have h11 : RB z11 ((5461121 : ℝ) / 12500000) ((21844639 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4369769 : ℝ) / 10000000) ((4369769 : ℝ) / 10000000) ((4369769 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((5630231 : ℝ) / 10000000))
  have h12 : RB z12 ((38798557 : ℝ) / 50000000) ((38798833 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((5630231 : ℝ) / 10000000) ((5630231 : ℝ) / 10000000) ((5630231 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-6340999 : ℝ) / 25000000) ((-25363283 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_329.1 cov_log_330.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-7644149 : ℝ) / 50000000) ((-3816797 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((4369769 : ℝ) / 10000000))
  have h15 : RB z15 ((-10348437 : ℝ) / 12500000) ((-41393747 : ℝ) / 50000000) := rb_log (show RB ((4369769 : ℝ) / 10000000) ((4369769 : ℝ) / 10000000) ((4369769 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_331.1 cov_log_331.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16874799 : ℝ) / 25000000) ((16880077 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33727791 : ℝ) / 50000000) ((67488719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_327.1 cov_log_328.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((10477 : ℝ) / 100000000) ((32363 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((2103 : ℝ) / 25000000) ((4361 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((25531143 : ℝ) / 20000000)) - (z19)
  have h20 : RB z20 ((127646993 : ℝ) / 100000000) ((127647303 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((25531143 : ℝ) / 20000000) ((25531143 : ℝ) / 20000000) ((25531143 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((5531143 : ℝ) / 20000000))
  have h21 : RB z21 ((461557377 : ℝ) / 100000000) ((461558499 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((5531143 : ℝ) / 20000000) ((5531143 : ℝ) / 20000000) ((5531143 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((76471809 : ℝ) / 50000000) ((19117983 : ℝ) / 12500000) := rb_log h21 (by norm_num) cov_log_332.1 cov_log_333.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92062963 : ℝ) / 100000000) ((46093907 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((25531143 : ℝ) / 20000000))
  have h24 : RB z24 ((763021 : ℝ) / 3125000) ((24416673 : ℝ) / 100000000) := rb_log (show RB ((25531143 : ℝ) / 20000000) ((25531143 : ℝ) / 20000000) ((25531143 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_334.1 cov_log_334.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((6764629 : ℝ) / 10000000) ((33885571 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33727791 : ℝ) / 50000000) ((67488719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_327.1 cov_log_328.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((157571 : ℝ) / 100000000) ((7889 : ℝ) / 2500000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((2103 : ℝ) / 25000000) ((4361 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((7990379 : ℝ) / 6250000)) - (z28)
  have h29 : RB z29 ((63918671 : ℝ) / 50000000) ((31959413 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((7990379 : ℝ) / 6250000) ((7990379 : ℝ) / 6250000) ((7990379 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((1740379 : ℝ) / 6250000))
  have h30 : RB z30 ((229542929 : ℝ) / 50000000) ((114771743 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((1740379 : ℝ) / 6250000) ((1740379 : ℝ) / 6250000) ((1740379 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((30481341 : ℝ) / 20000000) ((152406951 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_335.1 cov_log_336.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((45869887 : ℝ) / 50000000) ((91864187 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((7990379 : ℝ) / 6250000))
  have h33 : RB z33 ((3070709 : ℝ) / 12500000) ((24565673 : ℝ) / 100000000) := rb_log (show RB ((7990379 : ℝ) / 6250000) ((7990379 : ℝ) / 6250000) ((7990379 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_337.1 cov_log_337.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67174101 : ℝ) / 100000000) ((13459703 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33727791 : ℝ) / 50000000) ((67488719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_327.1 cov_log_328.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-157309 : ℝ) / 50000000) ((-157067 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8642771 : ℝ) / 20000000)) ((-6313 : ℝ) / 10000000) ((-727 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((4369769 : ℝ) / 10000000)) ((10477 : ℝ) / 100000000) ((32363 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((25531143 : ℝ) / 20000000)) ((157571 : ℝ) / 100000000) ((7889 : ℝ) / 2500000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((7990379 : ℝ) / 6250000)) ((-157309 : ℝ) / 50000000) ((-157067 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_18 {k A q d vp vm : ℝ}
    (hk : RB k ((4839 : ℝ) / 3200) ((9711 : ℝ) / 6400))
    (hA : RB A ((4839 : ℝ) / 8039) ((9711 : ℝ) / 16111))
    (hq : RB q ((917181 : ℝ) / 100000000) ((466951 : ℝ) / 50000000))
    (hd : RB d ((196316079 : ℝ) / 100000000) ((9819057 : ℝ) / 5000000))
    (hp : RB vp ((8642771 : ℝ) / 20000000) ((4369769 : ℝ) / 10000000))
    (hm : RB vm ((25531143 : ℝ) / 20000000) ((7990379 : ℝ) / 6250000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((2103 : ℝ) / 25000000) ((4361 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49995639 : ℝ) / 50000000) ((24997897 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((60188803 : ℝ) / 100000000) ((30135259 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((77 : ℝ) / 400000) ((2523 : ℝ) / 12500000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((12497477 : ℝ) / 12500000) ((399923 : ℝ) / 400000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((5630231 : ℝ) / 10000000) ((11357229 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11258189 : ℝ) / 20000000) ((28387607 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106012463 : ℝ) / 100000000) ((107069651 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6012463 : ℝ) / 100000000) ((7069651 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49995639 : ℝ) / 50000000) ((24997897 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((60188803 : ℝ) / 100000000) ((30135259 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((6579 : ℝ) / 100000000) ((6833 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99993167 : ℝ) / 100000000) ((99993421 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((5531143 : ℝ) / 20000000) ((1740379 : ℝ) / 6250000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1106153 : ℝ) / 4000000) ((27844233 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((108081273 : ℝ) / 50000000) ((27243301 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((158081273 : ℝ) / 50000000) ((39743301 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1414496981 : ℝ) / 100000000) ((1663211899 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31451841 : ℝ) / 100000000) ((316293 : ℝ) / 1000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((4839 : ℝ) / 1600) ((9711 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2773899 : ℝ) / 100000000) ((2834101 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100917181 : ℝ) / 100000000) ((50466951 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2748233 : ℝ) / 100000000) ((351043 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((102748233 : ℝ) / 100000000) ((12851043 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((3358321 : ℝ) / 4000000) ((84632209 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((82411551 : ℝ) / 50000000) ((166201697 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((11032991 : ℝ) / 20000000) ((55865777 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((15057 : ℝ) / 100000000) ((15811 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99984189 : ℝ) / 100000000) ((99984943 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((164797041 : ℝ) / 100000000) ((166176673 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((196316079 : ℝ) / 50000000) ((9819057 : ℝ) / 2500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((3601147 : ℝ) / 100000000) ((733603 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8039 : ℝ) / 3200) ((16111 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((715267 : ℝ) / 50000000) ((1460089 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2098923 : ℝ) / 100000000) ((1080559 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((102098923 : ℝ) / 100000000) ((51080559 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1444186183 : ℝ) / 100000000) ((1699155871 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((71741 : ℝ) / 10000000) ((731579 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((10071741 : ℝ) / 10000000) ((100731579 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31677479 : ℝ) / 100000000) ((15930347 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((737931831 : ℝ) / 50000000) ((346203313 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((21112731 : ℝ) / 100000000) ((25274383 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8039 : ℝ) / 3200) ((16111 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((102748233 : ℝ) / 50000000) ((12851043 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((722974411 : ℝ) / 50000000) ((1694841199 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2971373729 : ℝ) / 100000000) ((3484876341 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1802207 : ℝ) / 25000000) ((8471987 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-16436649 : ℝ) / 6250000) ((-246840511 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_338.1 cov_log_339.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1800573 : ℝ) / 100000000) ((229251 : ℝ) / 12500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-40170653 : ℝ) / 10000000) ((-99966661 : ℝ) / 25000000) := rb_log h49 (by norm_num) cov_log_340.1 cov_log_341.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33727791 : ℝ) / 50000000) ((67488719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_327.1 cov_log_328.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((102005487 : ℝ) / 100000000) ((51201793 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-299701043 : ℝ) / 100000000) ((-148731529 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((8633187 : ℝ) / 50000000) ((18646007 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((68315709 : ℝ) / 100000000) ((17663283 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-115692667 : ℝ) / 50000000) ((-209146643 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((102748233 : ℝ) / 100000000) ((12851043 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-16436649 : ℝ) / 6250000) ((-246840511 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-115692667 : ℝ) / 50000000) ((-209146643 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((153 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2098923 : ℝ) / 100000000) ((1080559 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((51080559 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((153 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-11718177 : ℝ) / 5000000) ≤ formC0 k A q vp vm + hfun ((153 : ℝ) / 50) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_5, cov_h_3]
  have hP : ((639086433 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((209146643 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((209146643 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2721 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2721 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2761 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2761 : ℝ) / 1000)) (lo := ((2721 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2801 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2801 : ℝ) / 1000)) (lo := ((2761 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2841 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2841 : ℝ) / 1000)) (lo := ((2801 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2881 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2881 : ℝ) / 1000)) (lo := ((2841 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2921 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2921 : ℝ) / 1000)) (lo := ((2881 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2961 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2961 : ℝ) / 1000)) (lo := ((2921 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3001 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3001 : ℝ) / 1000)) (lo := ((2961 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3041 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3041 : ℝ) / 1000)) (lo := ((3001 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((153 : ℝ) / 50)) (lo := ((3041 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_18 {k : ℝ} (hk : RB k ((4839 : ℝ) / 3200) ((9711 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((4839 : ℝ) / 8039) ((9711 : ℝ) / 16111) ∧
    RB (qa (r1A k)) ((917181 : ℝ) / 100000000) ((466951 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((196316079 : ℝ) / 100000000) ((9819057 : ℝ) / 5000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((37804687 : ℝ) / 100000000) ((18966797 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((96333203 : ℝ) / 50000000) ((192795313 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((34701081 : ℝ) / 25000000) ((2169543 : ℝ) / 1562500) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((3502821 : ℝ) / 1250000) ((280272109 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((3502821 : ℝ) / 2500000) ((28027211 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((196316079 : ℝ) / 100000000) ((9819057 : ℝ) / 5000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((7204687 : ℝ) / 100000000) ((3666797 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1801171 : ℝ) / 100000000) ((1833399 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((917181 : ℝ) / 100000000) ((466951 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((196316079 : ℝ) / 100000000) ((9819057 : ℝ) / 5000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((917181 : ℝ) / 100000000) ((466951 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((4839 : ℝ) / 8039) ((9711 : ℝ) / 16111) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_18 {k : ℝ} (hk : RB k ((4839 : ℝ) / 3200) ((9711 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_18 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_18 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((8642771 : ℝ) / 20000000)) (ph := ((4369769 : ℝ) / 10000000)) (ml := ((25531143 : ℝ) / 20000000)) (mh := ((7990379 : ℝ) / 6250000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_18 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_19 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((9711 : ℝ) / 16111) ((609 : ℝ) / 1009))
    (hq : RB (qa a) ((933901 : ℝ) / 100000000) ((950633 : ℝ) / 100000000))
    (hd : RB (D0a a) ((196251013 : ℝ) / 100000000) ((39263217 : ℝ) / 20000000))
    : certE k a ((8628739 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((43619881 : ℝ) / 100000000) ∧ 0 < certE k a ((127719351 : ℝ) / 100000000) ∧ certE k a ((127909141 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((8721 : ℝ) / 100000000) ((4519 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8628739 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((43134657 : ℝ) / 100000000) ((21567487 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((8628739 : ℝ) / 20000000) ((8628739 : ℝ) / 20000000) ((8628739 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11371261 : ℝ) / 20000000))
  have h3 : RB z3 ((18966523 : ℝ) / 25000000) ((75866651 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((11371261 : ℝ) / 20000000) ((11371261 : ℝ) / 20000000) ((11371261 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-5524007 : ℝ) / 20000000) ((-27619297 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_342.1 cov_log_343.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-16670567 : ℝ) / 100000000) ((-16647693 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8628739 : ℝ) / 20000000))
  have h6 : RB z6 ((-84063391 : ℝ) / 100000000) ((-84063389 : ℝ) / 100000000) := rb_log (show RB ((8628739 : ℝ) / 20000000) ((8628739 : ℝ) / 20000000) ((8628739 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_344.1 cov_log_344.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33696411 : ℝ) / 50000000) ((33707849 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67422433 : ℝ) / 100000000) ((67455587 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_345.1 cov_log_346.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-12553 : ℝ) / 20000000) ((-1347 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((8721 : ℝ) / 100000000) ((4519 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43619881 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((43610843 : ℝ) / 100000000) ((1090279 : ℝ) / 2500000) := rb_widen (rb_sub (show RB ((43619881 : ℝ) / 100000000) ((43619881 : ℝ) / 100000000) ((43619881 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56380119 : ℝ) / 100000000))
  have h12 : RB z12 ((2417233 : ℝ) / 3125000) ((77352019 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((56380119 : ℝ) / 100000000) ((56380119 : ℝ) / 100000000) ((56380119 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-25681079 : ℝ) / 100000000) ((-513607 : ℝ) / 2000000) := rb_log h12 (by norm_num) cov_log_347.1 cov_log_348.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-620011 : ℝ) / 4000000) ((-15478981 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43619881 : ℝ) / 100000000))
  have h15 : RB z15 ((-82965717 : ℝ) / 100000000) ((-16593143 : ℝ) / 20000000) := rb_log (show RB ((43619881 : ℝ) / 100000000) ((43619881 : ℝ) / 100000000) ((43619881 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_349.1 cov_log_349.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((421659 : ℝ) / 625000) ((4217921 : ℝ) / 6250000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67422433 : ℝ) / 100000000) ((67455587 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_345.1 cov_log_346.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((9853 : ℝ) / 100000000) ((64303 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((8721 : ℝ) / 100000000) ((4519 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((127719351 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((127710313 : ℝ) / 100000000) ((12771063 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((127719351 : ℝ) / 100000000) ((127719351 : ℝ) / 100000000) ((127719351 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((27719351 : ℝ) / 100000000))
  have h21 : RB z21 ((460726201 : ℝ) / 100000000) ((230363673 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((27719351 : ℝ) / 100000000) ((27719351 : ℝ) / 100000000) ((27719351 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((1222107 : ℝ) / 800000) ((152763627 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_350.1 cov_log_351.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46039511 : ℝ) / 50000000) ((4610161 : ℝ) / 5000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((127719351 : ℝ) / 100000000))
  have h24 : RB z24 ((2446651 : ℝ) / 10000000) ((24466511 : ℝ) / 100000000) := rb_log (show RB ((127719351 : ℝ) / 100000000) ((127719351 : ℝ) / 100000000) ((127719351 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_352.1 cov_log_352.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67612511 : ℝ) / 100000000) ((6773671 : ℝ) / 10000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67422433 : ℝ) / 100000000) ((67455587 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_345.1 cov_log_346.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((39231 : ℝ) / 25000000) ((314277 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((8721 : ℝ) / 100000000) ((4519 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((127909141 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((127900103 : ℝ) / 100000000) ((6395021 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((127909141 : ℝ) / 100000000) ((127909141 : ℝ) / 100000000) ((127909141 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((27909141 : ℝ) / 100000000))
  have h30 : RB z30 ((229136581 : ℝ) / 50000000) ((458274299 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((27909141 : ℝ) / 100000000) ((27909141 : ℝ) / 100000000) ((27909141 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((38057381 : ℝ) / 25000000) ((6089191 : ℝ) / 4000000) := rb_log h30 (by norm_num) cov_log_353.1 cov_log_354.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((2293931 : ℝ) / 2500000) ((22970251 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((127909141 : ℝ) / 100000000))
  have h33 : RB z33 ((12307499 : ℝ) / 50000000) ((24614999 : ℝ) / 100000000) := rb_log (show RB ((127909141 : ℝ) / 100000000) ((127909141 : ℝ) / 100000000) ((127909141 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_355.1 cov_log_355.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67142241 : ℝ) / 100000000) ((33633003 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67422433 : ℝ) / 100000000) ((67455587 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_345.1 cov_log_346.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-156673 : ℝ) / 50000000) ((-156427 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8628739 : ℝ) / 20000000)) ((-12553 : ℝ) / 20000000) ((-1347 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43619881 : ℝ) / 100000000)) ((9853 : ℝ) / 100000000) ((64303 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((127719351 : ℝ) / 100000000)) ((39231 : ℝ) / 25000000) ((314277 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((127909141 : ℝ) / 100000000)) ((-156673 : ℝ) / 50000000) ((-156427 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_19 {k A q d vp vm : ℝ}
    (hk : RB k ((9711 : ℝ) / 6400) ((609 : ℝ) / 400))
    (hA : RB A ((9711 : ℝ) / 16111) ((609 : ℝ) / 1009))
    (hq : RB q ((933901 : ℝ) / 100000000) ((950633 : ℝ) / 100000000))
    (hd : RB d ((196251013 : ℝ) / 100000000) ((39263217 : ℝ) / 20000000))
    (hp : RB vp ((8628739 : ℝ) / 20000000) ((43619881 : ℝ) / 100000000))
    (hm : RB vm ((127719351 : ℝ) / 100000000) ((127909141 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((8721 : ℝ) / 100000000) ((4519 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49995481 : ℝ) / 50000000) ((99991279 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((3013507 : ℝ) / 5000000) ((30175763 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((19993 : ℝ) / 100000000) ((20949 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99979051 : ℝ) / 100000000) ((99980007 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56380119 : ℝ) / 100000000) ((11371261 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((56368307 : ℝ) / 100000000) ((28422469 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53012759 : ℝ) / 50000000) ((6691651 : ℝ) / 6250000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3012759 : ℝ) / 50000000) ((441651 : ℝ) / 6250000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49995481 : ℝ) / 50000000) ((99991279 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((3013507 : ℝ) / 5000000) ((30175763 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3409 : ℝ) / 50000000) ((7077 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99992923 : ℝ) / 100000000) ((49996591 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((27719351 : ℝ) / 100000000) ((27909141 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((27717389 : ℝ) / 100000000) ((27907239 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((53991493 : ℝ) / 25000000) ((108869429 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((78991493 : ℝ) / 25000000) ((158869429 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1415144537 : ℝ) / 100000000) ((1659608353 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15736193 : ℝ) / 50000000) ((15824489 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((9711 : ℝ) / 3200) ((609 : ℝ) / 200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2834097 : ℝ) / 100000000) ((1447339 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100933901 : ℝ) / 100000000) ((100950633 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((175463 : ℝ) / 6250000) ((573579 : ℝ) / 20000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((6425463 : ℝ) / 6250000) ((20573579 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((8409947 : ℝ) / 10000000) ((42382723 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((165046061 : ℝ) / 100000000) ((83204103 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((55102847 : ℝ) / 100000000) ((6974227 : ℝ) / 12500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1563 : ℝ) / 10000000) ((16403 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99983597 : ℝ) / 100000000) ((9998437 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((41254747 : ℝ) / 25000000) ((166382197 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((196251013 : ℝ) / 50000000) ((39263217 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((183279 : ℝ) / 5000000) ((3732491 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16111 : ℝ) / 6400) ((1009 : ℝ) / 400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1453153 : ℝ) / 100000000) ((1482711 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1070499 : ℝ) / 50000000) ((550853 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51070499 : ℝ) / 50000000) ((25550853 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1445442753 : ℝ) / 100000000) ((1696176363 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((45633 : ℝ) / 6250000) ((372157 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((6295633 : ℝ) / 6250000) ((50372157 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((15851087 : ℝ) / 50000000) ((15942273 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1477144927 : ℝ) / 100000000) ((1728060909 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((858607 : ℝ) / 4000000) ((512443 : ℝ) / 2000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16111 : ℝ) / 6400) ((1009 : ℝ) / 400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((6425463 : ℝ) / 3125000) ((20573579 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1446616923 : ℝ) / 100000000) ((1691257331 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((743614681 : ℝ) / 25000000) ((3479521631 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((361737 : ℝ) / 5000000) ((1696107 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-262627581 : ℝ) / 100000000) ((-15421229 : ℝ) / 6250000) := rb_log h47 (by norm_num) cov_log_356.1 cov_log_357.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((183279 : ℝ) / 10000000) ((933123 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-79986617 : ℝ) / 20000000) ((-3184993 : ℝ) / 800000) := rb_log h49 (by norm_num) cov_log_358.1 cov_log_359.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67422433 : ℝ) / 100000000) ((67455587 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_345.1 cov_log_346.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((102303007 : ℝ) / 100000000) ((25675283 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-148815039 : ℝ) / 50000000) ((-295422993 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((341217 : ℝ) / 2000000) ((921203 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((16646583 : ℝ) / 25000000) ((85832331 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-115521873 : ℝ) / 50000000) ((-104795331 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((6425463 : ℝ) / 6250000) ((20573579 : ℝ) / 20000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-262627581 : ℝ) / 100000000) ((-15421229 : ℝ) / 6250000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-115521873 : ℝ) / 50000000) ((-104795331 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((153 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1070499 : ℝ) / 50000000) ((550853 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((25550853 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((153 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-234004737 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((153 : ℝ) / 50) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_5, cov_h_3]
  have hP : ((320036229 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((104795331 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((104795331 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2729 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2729 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2769 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2769 : ℝ) / 1000)) (lo := ((2729 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2809 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2809 : ℝ) / 1000)) (lo := ((2769 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2849 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2849 : ℝ) / 1000)) (lo := ((2809 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2889 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2889 : ℝ) / 1000)) (lo := ((2849 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2929 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2929 : ℝ) / 1000)) (lo := ((2889 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2969 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2969 : ℝ) / 1000)) (lo := ((2929 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3009 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3009 : ℝ) / 1000)) (lo := ((2969 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3049 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3049 : ℝ) / 1000)) (lo := ((3009 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((153 : ℝ) / 50)) (lo := ((3049 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_19 {k : ℝ} (hk : RB k ((9711 : ℝ) / 6400) ((609 : ℝ) / 400)) :
    RB (k / (k + 1)) ((9711 : ℝ) / 16111) ((609 : ℝ) / 1009) ∧
    RB (qa (r1A k)) ((933901 : ℝ) / 100000000) ((950633 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((196251013 : ℝ) / 100000000) ((39263217 : ℝ) / 20000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((37933593 : ℝ) / 100000000) ((609 : ℝ) / 1600) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((15403 : ℝ) / 8000) ((192666407 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((69378941 : ℝ) / 50000000) ((69402163 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((140089619 : ℝ) / 50000000) ((280225683 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140089619 : ℝ) / 100000000) ((70056421 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((196251013 : ℝ) / 100000000) ((39263217 : ℝ) / 20000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((7333593 : ℝ) / 100000000) ((597 : ℝ) / 8000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((916699 : ℝ) / 50000000) ((597 : ℝ) / 32000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((933901 : ℝ) / 100000000) ((950633 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((196251013 : ℝ) / 100000000) ((39263217 : ℝ) / 20000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((933901 : ℝ) / 100000000) ((950633 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((9711 : ℝ) / 16111) ((609 : ℝ) / 1009) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_19 {k : ℝ} (hk : RB k ((9711 : ℝ) / 6400) ((609 : ℝ) / 400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_19 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_19 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((8628739 : ℝ) / 20000000)) (ph := ((43619881 : ℝ) / 100000000)) (ml := ((127719351 : ℝ) / 100000000)) (mh := ((127909141 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_19 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
