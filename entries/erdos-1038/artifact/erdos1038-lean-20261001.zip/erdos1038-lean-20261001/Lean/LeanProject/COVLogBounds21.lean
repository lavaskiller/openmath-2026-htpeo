import LeanProject.COVLogTwo
import LeanProject.COVLogBounds17
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1680 : RB (Real.log ((3986981 : ℝ) / 6250000)) ((-22477359 : ℝ) / 50000000) ((-11238679 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((3986981 : ℝ) / 3125000)) (t := ((861981 : ℝ) / 7111981))
    (lo := ((24360001 : ℝ) / 100000000)) (hi := ((12180001 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3986981 : ℝ) / 6250000) = Real.log ((3986981 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((3986981 : ℝ) / 6250000) = ((3986981 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1681 : RB (Real.log ((9748139 : ℝ) / 25000000)) ((-11772493 : ℝ) / 12500000) ((-47089971 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9748139 : ℝ) / 12500000)) (t := ((-2751861 : ℝ) / 22248139))
    (lo := ((-994609 : ℝ) / 4000000)) (hi := ((-3108153 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9748139 : ℝ) / 25000000) = Real.log ((9748139 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9748139 : ℝ) / 25000000) = ((9748139 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1682 : RB (Real.log ((99548579 : ℝ) / 25000000)) ((138176993 : ℝ) / 100000000) ((34544249 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((99548579 : ℝ) / 100000000)) (t := ((-451421 : ℝ) / 199548579))
    (lo := ((-452443 : ℝ) / 100000000)) (hi := ((-226221 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((99548579 : ℝ) / 25000000) = Real.log ((99548579 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((99548579 : ℝ) / 25000000) = ((99548579 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1683 : RB (Real.log ((199098631 : ℝ) / 50000000)) ((34544433 : ℝ) / 25000000) ((27635547 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((199098631 : ℝ) / 200000000)) (t := ((-901369 : ℝ) / 399098631))
    (lo := ((-56463 : ℝ) / 12500000)) (hi := ((-451703 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((199098631 : ℝ) / 50000000) = Real.log ((199098631 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((199098631 : ℝ) / 50000000) = ((199098631 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1684 : RB (Real.log ((6675487 : ℝ) / 5000000)) ((3612553 : ℝ) / 12500000) ((14450213 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6675487 : ℝ) / 10000000)) (t := ((-3324513 : ℝ) / 16675487))
    (lo := ((-20207147 : ℝ) / 50000000)) (hi := ((-40414293 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6675487 : ℝ) / 5000000) = Real.log ((6675487 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((6675487 : ℝ) / 5000000) = ((6675487 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1685 : RB (Real.log ((396885767 : ℝ) / 100000000)) ((137847831 : ℝ) / 100000000) ((68923917 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((396885767 : ℝ) / 400000000)) (t := ((-3114233 : ℝ) / 796885767))
    (lo := ((-156321 : ℝ) / 20000000)) (hi := ((-195401 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((396885767 : ℝ) / 100000000) = Real.log ((396885767 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((396885767 : ℝ) / 100000000) = ((396885767 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1686 : RB (Real.log ((3968887 : ℝ) / 1000000)) ((13784857 : ℝ) / 10000000) ((137848573 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3968887 : ℝ) / 4000000)) (t := ((-31113 : ℝ) / 7968887))
    (lo := ((-390433 : ℝ) / 50000000)) (hi := ((-156173 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3968887 : ℝ) / 1000000) = Real.log ((3968887 : ℝ) / 4000000) + 2 * Real.log 2 := by
    rw [show ((3968887 : ℝ) / 1000000) = ((3968887 : ℝ) / 4000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1687 : RB (Real.log ((133657437 : ℝ) / 100000000)) ((29010989 : ℝ) / 100000000) ((29010991 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133657437 : ℝ) / 200000000)) (t := ((-66342563 : ℝ) / 333657437))
    (lo := ((-40303729 : ℝ) / 100000000)) (hi := ((-2518983 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133657437 : ℝ) / 100000000) = Real.log ((133657437 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133657437 : ℝ) / 100000000) = ((133657437 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1688 : RB (Real.log ((13148079 : ℝ) / 100000000)) ((-12680591 : ℝ) / 6250000) ((-50722363 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((13148079 : ℝ) / 12500000)) (t := ((648079 : ℝ) / 25648079))
    (lo := ((5054701 : ℝ) / 100000000)) (hi := ((2527351 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13148079 : ℝ) / 100000000) = Real.log ((13148079 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13148079 : ℝ) / 100000000) = ((13148079 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1689 : RB (Real.log ((870933 : ℝ) / 6250000)) ((-197077173 : ℝ) / 100000000) ((-197077169 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((870933 : ℝ) / 781250)) (t := ((89683 : ℝ) / 1652183))
    (lo := ((1358373 : ℝ) / 12500000)) (hi := ((2173397 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((870933 : ℝ) / 6250000) = Real.log ((870933 : ℝ) / 781250) - 3 * Real.log 2 := by
    rw [show ((870933 : ℝ) / 6250000) = ((870933 : ℝ) / 781250) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1690 : RB (Real.log ((647893 : ℝ) / 12500000)) ((-295975841 : ℝ) / 100000000) ((-73993959 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((647893 : ℝ) / 781250)) (t := ((-133357 : ℝ) / 1429143))
    (lo := ((-3743393 : ℝ) / 20000000)) (hi := ((-4679241 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((647893 : ℝ) / 12500000) = Real.log ((647893 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((647893 : ℝ) / 12500000) = ((647893 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1691 : RB (Real.log ((1043803 : ℝ) / 20000000)) ((-147643077 : ℝ) / 50000000) ((-295286149 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1043803 : ℝ) / 1250000)) (t := ((-206197 : ℝ) / 2293803))
    (lo := ((-9013639 : ℝ) / 50000000)) (hi := ((-18027277 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1043803 : ℝ) / 20000000) = Real.log ((1043803 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1043803 : ℝ) / 20000000) = ((1043803 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1692 : RB (Real.log ((62985017 : ℝ) / 100000000)) ((-46227333 : ℝ) / 100000000) ((-46227331 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((62985017 : ℝ) / 50000000)) (t := ((12985017 : ℝ) / 112985017))
    (lo := ((11543693 : ℝ) / 50000000)) (hi := ((23087387 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62985017 : ℝ) / 100000000) = Real.log ((62985017 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62985017 : ℝ) / 100000000) = ((62985017 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1693 : RB (Real.log ((62986641 : ℝ) / 100000000)) ((-23112377 : ℝ) / 50000000) ((-2889047 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((62986641 : ℝ) / 50000000)) (t := ((12986641 : ℝ) / 112986641))
    (lo := ((4617993 : ℝ) / 20000000)) (hi := ((11544983 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62986641 : ℝ) / 100000000) = Real.log ((62986641 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62986641 : ℝ) / 100000000) = ((62986641 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1694 : RB (Real.log ((38691821 : ℝ) / 100000000)) ((-94954197 : ℝ) / 100000000) ((-18990839 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((38691821 : ℝ) / 50000000)) (t := ((-11308179 : ℝ) / 88691821))
    (lo := ((-12819739 : ℝ) / 50000000)) (hi := ((-25639477 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38691821 : ℝ) / 100000000) = Real.log ((38691821 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38691821 : ℝ) / 100000000) = ((38691821 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1695 : RB (Real.log ((94677821 : ℝ) / 50000000)) ((15961419 : ℝ) / 25000000) ((31922839 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((94677821 : ℝ) / 100000000)) (t := ((-5322179 : ℝ) / 194677821))
    (lo := ((-2734521 : ℝ) / 50000000)) (hi := ((-5469041 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94677821 : ℝ) / 50000000) = Real.log ((94677821 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94677821 : ℝ) / 50000000) = ((94677821 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1696 : RB (Real.log ((94710967 : ℝ) / 50000000)) ((63880679 : ℝ) / 100000000) ((63880681 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((94710967 : ℝ) / 100000000)) (t := ((-5289033 : ℝ) / 194710967))
    (lo := ((-5434039 : ℝ) / 100000000)) (hi := ((-2717019 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94710967 : ℝ) / 50000000) = Real.log ((94710967 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94710967 : ℝ) / 50000000) = ((94710967 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1697 : RB (Real.log ((31852093 : ℝ) / 50000000)) ((-45091993 : ℝ) / 100000000) ((-45091991 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((31852093 : ℝ) / 25000000)) (t := ((6852093 : ℝ) / 56852093))
    (lo := ((12111363 : ℝ) / 50000000)) (hi := ((24222727 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31852093 : ℝ) / 50000000) = Real.log ((31852093 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31852093 : ℝ) / 50000000) = ((31852093 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1698 : RB (Real.log ((63705817 : ℝ) / 100000000)) ((-5636179 : ℝ) / 12500000) ((-4508943 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((63705817 : ℝ) / 50000000)) (t := ((13705817 : ℝ) / 113705817))
    (lo := ((24225287 : ℝ) / 100000000)) (hi := ((3028161 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63705817 : ℝ) / 100000000) = Real.log ((63705817 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63705817 : ℝ) / 100000000) = ((63705817 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1699 : RB (Real.log ((19480577 : ℝ) / 50000000)) ((-9426051 : ℝ) / 10000000) ((-23565127 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((19480577 : ℝ) / 25000000)) (t := ((-5519423 : ℝ) / 44480577))
    (lo := ((-24945791 : ℝ) / 100000000)) (hi := ((-2494579 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19480577 : ℝ) / 50000000) = Real.log ((19480577 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19480577 : ℝ) / 50000000) = ((19480577 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1700 : RB (Real.log ((397753051 : ℝ) / 100000000)) ((27613223 : ℝ) / 20000000) ((69033059 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((397753051 : ℝ) / 400000000)) (t := ((-2246949 : ℝ) / 797753051))
    (lo := ((-563321 : ℝ) / 100000000)) (hi := ((-14083 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((397753051 : ℝ) / 100000000) = Real.log ((397753051 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((397753051 : ℝ) / 100000000) = ((397753051 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1701 : RB (Real.log ((397756017 : ℝ) / 100000000)) ((6903343 : ℝ) / 5000000) ((138066863 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((397756017 : ℝ) / 400000000)) (t := ((-2243983 : ℝ) / 797756017))
    (lo := ((-35161 : ℝ) / 6250000)) (hi := ((-22503 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((397756017 : ℝ) / 100000000) = Real.log ((397756017 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((397756017 : ℝ) / 100000000) = ((397756017 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1702 : RB (Real.log ((133559067 : ℝ) / 100000000)) ((7234341 : ℝ) / 25000000) ((14468683 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((133559067 : ℝ) / 200000000)) (t := ((-66440933 : ℝ) / 333559067))
    (lo := ((-20188677 : ℝ) / 50000000)) (hi := ((-40377353 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133559067 : ℝ) / 100000000) = Real.log ((133559067 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133559067 : ℝ) / 100000000) = ((133559067 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1703 : RB (Real.log ((198225433 : ℝ) / 50000000)) ((8608637 : ℝ) / 6250000) ((27547639 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((198225433 : ℝ) / 200000000)) (t := ((-1774567 : ℝ) / 398225433))
    (lo := ((-222811 : ℝ) / 25000000)) (hi := ((-891243 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((198225433 : ℝ) / 50000000) = Real.log ((198225433 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((198225433 : ℝ) / 50000000) = ((198225433 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1704 : RB (Real.log ((396453819 : ℝ) / 100000000)) ((137738937 : ℝ) / 100000000) ((6886947 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((396453819 : ℝ) / 400000000)) (t := ((-3546181 : ℝ) / 796453819))
    (lo := ((-890499 : ℝ) / 100000000)) (hi := ((-445249 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((396453819 : ℝ) / 100000000) = Real.log ((396453819 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((396453819 : ℝ) / 100000000) = ((396453819 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1705 : RB (Real.log ((66853239 : ℝ) / 50000000)) ((14523837 : ℝ) / 50000000) ((7261919 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((66853239 : ℝ) / 100000000)) (t := ((-33146761 : ℝ) / 166853239))
    (lo := ((-10066761 : ℝ) / 25000000)) (hi := ((-40267043 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66853239 : ℝ) / 50000000) = Real.log ((66853239 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((66853239 : ℝ) / 50000000) = ((66853239 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1706 : RB (Real.log ((13206171 : ℝ) / 100000000)) ((-1012243 : ℝ) / 500000) ((-50612149 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((13206171 : ℝ) / 12500000)) (t := ((706171 : ℝ) / 25706171))
    (lo := ((5495557 : ℝ) / 100000000)) (hi := ((2747779 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13206171 : ℝ) / 100000000) = Real.log ((13206171 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13206171 : ℝ) / 100000000) = ((13206171 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1707 : RB (Real.log ((13991491 : ℝ) / 100000000)) ((-98336043 : ℝ) / 50000000) ((-98336041 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((13991491 : ℝ) / 12500000)) (t := ((1491491 : ℝ) / 26491491))
    (lo := ((11272071 : ℝ) / 100000000)) (hi := ((1409009 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13991491 : ℝ) / 100000000) = Real.log ((13991491 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13991491 : ℝ) / 100000000) = ((13991491 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1708 : RB (Real.log ((5215359 : ℝ) / 100000000)) ((-29535623 : ℝ) / 10000000) ((-11814249 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((5215359 : ℝ) / 6250000)) (t := ((-1034641 : ℝ) / 11465359))
    (lo := ((-9048677 : ℝ) / 50000000)) (hi := ((-18097353 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5215359 : ℝ) / 100000000) = Real.log ((5215359 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5215359 : ℝ) / 100000000) = ((5215359 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1709 : RB (Real.log ((2625627 : ℝ) / 50000000)) ((-73667583 : ℝ) / 25000000) ((-294670327 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2625627 : ℝ) / 3125000)) (t := ((-499373 : ℝ) / 5750627))
    (lo := ((-136027 : ℝ) / 781250)) (hi := ((-3482291 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2625627 : ℝ) / 50000000) = Real.log ((2625627 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2625627 : ℝ) / 50000000) = ((2625627 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1710 : RB (Real.log ((12580393 : ℝ) / 20000000)) ((-579491 : ℝ) / 1250000) ((-23179639 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12580393 : ℝ) / 10000000)) (t := ((2580393 : ℝ) / 22580393))
    (lo := ((22955439 : ℝ) / 100000000)) (hi := ((286943 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12580393 : ℝ) / 20000000) = Real.log ((12580393 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((12580393 : ℝ) / 20000000) = ((12580393 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1711 : RB (Real.log ((157259 : ℝ) / 250000)) ((-1158917 : ℝ) / 2500000) ((-23178339 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((157259 : ℝ) / 125000)) (t := ((32259 : ℝ) / 282259))
    (lo := ((22958039 : ℝ) / 100000000)) (hi := ((573951 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((157259 : ℝ) / 250000) = Real.log ((157259 : ℝ) / 125000) - 1 * Real.log 2 := by
    rw [show ((157259 : ℝ) / 250000) = ((157259 : ℝ) / 125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1712 : RB (Real.log ((38661179 : ℝ) / 100000000)) ((-95033423 : ℝ) / 100000000) ((-95033421 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38661179 : ℝ) / 50000000)) (t := ((-11338821 : ℝ) / 88661179))
    (lo := ((-1607419 : ℝ) / 6250000)) (hi := ((-25718703 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38661179 : ℝ) / 100000000) = Real.log ((38661179 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38661179 : ℝ) / 100000000) = ((38661179 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1713 : RB (Real.log ((94644673 : ℝ) / 50000000)) ((31905329 : ℝ) / 50000000) ((3190533 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((94644673 : ℝ) / 100000000)) (t := ((-5355327 : ℝ) / 194644673))
    (lo := ((-275203 : ℝ) / 5000000)) (hi := ((-5504059 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94644673 : ℝ) / 50000000) = Real.log ((94644673 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94644673 : ℝ) / 50000000) = ((94644673 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1714 : RB (Real.log ((189355649 : ℝ) / 100000000)) ((798071 : ℝ) / 1250000) ((31922841 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((189355649 : ℝ) / 200000000)) (t := ((-10644351 : ℝ) / 389355649))
    (lo := ((-2734519 : ℝ) / 50000000)) (hi := ((-5469037 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189355649 : ℝ) / 100000000) = Real.log ((189355649 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189355649 : ℝ) / 100000000) = ((189355649 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1715 : RB (Real.log ((63618601 : ℝ) / 100000000)) ((-4522643 : ℝ) / 10000000) ((-11306607 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((63618601 : ℝ) / 50000000)) (t := ((13618601 : ℝ) / 113618601))
    (lo := ((24088289 : ℝ) / 100000000)) (hi := ((2408829 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63618601 : ℝ) / 100000000) = Real.log ((63618601 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63618601 : ℝ) / 100000000) = ((63618601 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1716 : RB (Real.log ((63620243 : ℝ) / 100000000)) ((-45223849 : ℝ) / 100000000) ((-45223847 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63620243 : ℝ) / 50000000)) (t := ((13620243 : ℝ) / 113620243))
    (lo := ((2409087 : ℝ) / 10000000)) (hi := ((24090871 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63620243 : ℝ) / 100000000) = Real.log ((63620243 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63620243 : ℝ) / 100000000) = ((63620243 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1717 : RB (Real.log ((19464919 : ℝ) / 50000000)) ((-2358523 : ℝ) / 2500000) ((-47170459 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19464919 : ℝ) / 25000000)) (t := ((-5535081 : ℝ) / 44464919))
    (lo := ((-25026201 : ℝ) / 100000000)) (hi := ((-125131 : ℝ) / 500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19464919 : ℝ) / 50000000) = Real.log ((19464919 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19464919 : ℝ) / 50000000) = ((19464919 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1718 : RB (Real.log ((39731391 : ℝ) / 10000000)) ((2155557 : ℝ) / 1562500) ((137955651 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39731391 : ℝ) / 40000000)) (t := ((-268609 : ℝ) / 79731391))
    (lo := ((-168447 : ℝ) / 25000000)) (hi := ((-673787 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39731391 : ℝ) / 10000000) = Real.log ((39731391 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((39731391 : ℝ) / 10000000) = ((39731391 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1719 : RB (Real.log ((99329223 : ℝ) / 25000000)) ((137956399 : ℝ) / 100000000) ((68978201 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((99329223 : ℝ) / 100000000)) (t := ((-670777 : ℝ) / 199329223))
    (lo := ((-673037 : ℝ) / 100000000)) (hi := ((-168259 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((99329223 : ℝ) / 25000000) = Real.log ((99329223 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((99329223 : ℝ) / 25000000) = ((99329223 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1720 : RB (Real.log ((66804149 : ℝ) / 50000000)) ((14487109 : ℝ) / 50000000) ((1448711 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((66804149 : ℝ) / 100000000)) (t := ((-33195851 : ℝ) / 166804149))
    (lo := ((-80681 : ℝ) / 200000)) (hi := ((-40340499 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66804149 : ℝ) / 50000000) = Real.log ((66804149 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((66804149 : ℝ) / 50000000) = ((66804149 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1721 : RB (Real.log ((396018023 : ℝ) / 100000000)) ((137628953 : ℝ) / 100000000) ((34407239 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((396018023 : ℝ) / 400000000)) (t := ((-3981977 : ℝ) / 796018023))
    (lo := ((-1000483 : ℝ) / 100000000)) (hi := ((-500241 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((396018023 : ℝ) / 100000000) = Real.log ((396018023 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((396018023 : ℝ) / 100000000) = ((396018023 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1722 : RB (Real.log ((396020993 : ℝ) / 100000000)) ((137629703 : ℝ) / 100000000) ((68814853 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((396020993 : ℝ) / 400000000)) (t := ((-3979007 : ℝ) / 796020993))
    (lo := ((-999733 : ℝ) / 100000000)) (hi := ((-249933 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((396020993 : ℝ) / 100000000) = Real.log ((396020993 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((396020993 : ℝ) / 100000000) = ((396020993 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1723 : RB (Real.log ((66877713 : ℝ) / 50000000)) ((7271069 : ℝ) / 25000000) ((14542139 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((66877713 : ℝ) / 100000000)) (t := ((-33122287 : ℝ) / 166877713))
    (lo := ((-20115221 : ℝ) / 50000000)) (hi := ((-40230441 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66877713 : ℝ) / 50000000) = Real.log ((66877713 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((66877713 : ℝ) / 50000000) = ((66877713 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1724 : RB (Real.log ((6632007 : ℝ) / 50000000)) ((-202011557 : ℝ) / 100000000) ((-202011553 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6632007 : ℝ) / 6250000)) (t := ((382007 : ℝ) / 12882007))
    (lo := ((29663 : ℝ) / 500000)) (hi := ((5932601 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6632007 : ℝ) / 50000000) = Real.log ((6632007 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6632007 : ℝ) / 50000000) = ((6632007 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1725 : RB (Real.log ((14047833 : ℝ) / 100000000)) ((-196270207 : ℝ) / 100000000) ((-196270203 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((14047833 : ℝ) / 12500000)) (t := ((1547833 : ℝ) / 26547833))
    (lo := ((233479 : ℝ) / 2000000)) (hi := ((11673951 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14047833 : ℝ) / 100000000) = Real.log ((14047833 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((14047833 : ℝ) / 100000000) = ((14047833 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1726 : RB (Real.log ((209903 : ℝ) / 4000000)) ((-4605319 : ℝ) / 1562500) ((-294740411 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((209903 : ℝ) / 250000)) (t := ((-40097 : ℝ) / 459903))
    (lo := ((-874077 : ℝ) / 5000000)) (hi := ((-17481539 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((209903 : ℝ) / 4000000) = Real.log ((209903 : ℝ) / 250000) - 4 * Real.log 2 := by
    rw [show ((209903 : ℝ) / 4000000) = ((209903 : ℝ) / 250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1727 : RB (Real.log ((5283493 : ℝ) / 100000000)) ((-7351457 : ℝ) / 2500000) ((-11762331 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((5283493 : ℝ) / 6250000)) (t := ((-966507 : ℝ) / 11533493))
    (lo := ((-4199851 : ℝ) / 25000000)) (hi := ((-16799403 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5283493 : ℝ) / 100000000) = Real.log ((5283493 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5283493 : ℝ) / 100000000) = ((5283493 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1728 : RB (Real.log ((62819169 : ℝ) / 100000000)) ((-46490993 : ℝ) / 100000000) ((-46490991 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((62819169 : ℝ) / 50000000)) (t := ((12819169 : ℝ) / 112819169))
    (lo := ((11411863 : ℝ) / 50000000)) (hi := ((22823727 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62819169 : ℝ) / 100000000) = Real.log ((62819169 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62819169 : ℝ) / 100000000) = ((62819169 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1729 : RB (Real.log ((3926301 : ℝ) / 6250000)) ((-11622093 : ℝ) / 25000000) ((-4648837 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((3926301 : ℝ) / 3125000)) (t := ((801301 : ℝ) / 7051301))
    (lo := ((22826347 : ℝ) / 100000000)) (hi := ((5706587 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3926301 : ℝ) / 6250000) = Real.log ((3926301 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((3926301 : ℝ) / 6250000) = ((3926301 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1730 : RB (Real.log ((38630607 : ℝ) / 100000000)) ((-95112531 : ℝ) / 100000000) ((-95112529 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38630607 : ℝ) / 50000000)) (t := ((-11369393 : ℝ) / 88630607))
    (lo := ((-6449453 : ℝ) / 25000000)) (hi := ((-25797811 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38630607 : ℝ) / 100000000) = Real.log ((38630607 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38630607 : ℝ) / 100000000) = ((38630607 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1731 : RB (Real.log ((189223037 : ℝ) / 100000000)) ((31887811 : ℝ) / 50000000) ((7971953 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((189223037 : ℝ) / 200000000)) (t := ((-10776963 : ℝ) / 389223037))
    (lo := ((-692387 : ℝ) / 12500000)) (hi := ((-1107819 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189223037 : ℝ) / 100000000) = Real.log ((189223037 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189223037 : ℝ) / 100000000) = ((189223037 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1732 : RB (Real.log ((3785787 : ℝ) / 2000000)) ((63810661 : ℝ) / 100000000) ((63810663 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3785787 : ℝ) / 4000000)) (t := ((-214213 : ℝ) / 7785787))
    (lo := ((-5504057 : ℝ) / 100000000)) (hi := ((-688007 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3785787 : ℝ) / 2000000) = Real.log ((3785787 : ℝ) / 4000000) + 1 * Real.log 2 := by
    rw [show ((3785787 : ℝ) / 2000000) = ((3785787 : ℝ) / 4000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1733 : RB (Real.log ((15883329 : ℝ) / 25000000)) ((-45360577 : ℝ) / 100000000) ((-1814423 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((15883329 : ℝ) / 12500000)) (t := ((3383329 : ℝ) / 28383329))
    (lo := ((11977071 : ℝ) / 50000000)) (hi := ((23954143 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15883329 : ℝ) / 25000000) = Real.log ((15883329 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((15883329 : ℝ) / 25000000) = ((15883329 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1734 : RB (Real.log ((6353497 : ℝ) / 10000000)) ((-22678987 : ℝ) / 50000000) ((-11339493 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((6353497 : ℝ) / 5000000)) (t := ((1353497 : ℝ) / 11353497))
    (lo := ((4791349 : ℝ) / 20000000)) (hi := ((11978373 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6353497 : ℝ) / 10000000) = Real.log ((6353497 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((6353497 : ℝ) / 10000000) = ((6353497 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1735 : RB (Real.log ((19449303 : ℝ) / 50000000)) ((-94421179 : ℝ) / 100000000) ((-94421177 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19449303 : ℝ) / 25000000)) (t := ((-5550697 : ℝ) / 44449303))
    (lo := ((-1255323 : ℝ) / 5000000)) (hi := ((-25106459 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19449303 : ℝ) / 50000000) = Real.log ((19449303 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19449303 : ℝ) / 50000000) = ((19449303 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1736 : RB (Real.log ((99219217 : ℝ) / 25000000)) ((34461397 : ℝ) / 25000000) ((137845591 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((99219217 : ℝ) / 100000000)) (t := ((-780783 : ℝ) / 199219217))
    (lo := ((-97981 : ℝ) / 12500000)) (hi := ((-783847 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((99219217 : ℝ) / 25000000) = Real.log ((99219217 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((99219217 : ℝ) / 25000000) = ((99219217 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1737 : RB (Real.log ((39687987 : ℝ) / 10000000)) ((27569269 : ℝ) / 20000000) ((34461587 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((39687987 : ℝ) / 40000000)) (t := ((-312013 : ℝ) / 79687987))
    (lo := ((-783091 : ℝ) / 100000000)) (hi := ((-78309 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39687987 : ℝ) / 10000000) = Real.log ((39687987 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((39687987 : ℝ) / 10000000) = ((39687987 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1738 : RB (Real.log ((66828717 : ℝ) / 50000000)) ((29010987 : ℝ) / 100000000) ((29010989 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66828717 : ℝ) / 100000000)) (t := ((-33171283 : ℝ) / 166828717))
    (lo := ((-40303731 : ℝ) / 100000000)) (hi := ((-4030373 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66828717 : ℝ) / 50000000) = Real.log ((66828717 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((66828717 : ℝ) / 50000000) = ((66828717 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1739 : RB (Real.log ((395587233 : ℝ) / 100000000)) ((137520113 : ℝ) / 100000000) ((34380029 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((395587233 : ℝ) / 400000000)) (t := ((-4412767 : ℝ) / 795587233))
    (lo := ((-1109323 : ℝ) / 100000000)) (hi := ((-554661 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((395587233 : ℝ) / 100000000) = Real.log ((395587233 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((395587233 : ℝ) / 100000000) = ((395587233 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1740 : RB (Real.log ((197795111 : ℝ) / 50000000)) ((137520869 : ℝ) / 100000000) ((17190109 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((197795111 : ℝ) / 200000000)) (t := ((-2204889 : ℝ) / 397795111))
    (lo := ((-1108567 : ℝ) / 100000000)) (hi := ((-554283 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197795111 : ℝ) / 50000000) = Real.log ((197795111 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((197795111 : ℝ) / 50000000) = ((197795111 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1741 : RB (Real.log ((3345107 : ℝ) / 2500000)) ((14560397 : ℝ) / 50000000) ((7280199 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((3345107 : ℝ) / 5000000)) (t := ((-1654893 : ℝ) / 8345107))
    (lo := ((-10048481 : ℝ) / 25000000)) (hi := ((-40193923 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3345107 : ℝ) / 2500000) = Real.log ((3345107 : ℝ) / 5000000) + 1 * Real.log 2 := by
    rw [show ((3345107 : ℝ) / 2500000) = ((3345107 : ℝ) / 5000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1742 : RB (Real.log ((6660801 : ℝ) / 50000000)) ((-201578329 : ℝ) / 100000000) ((-8063133 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((6660801 : ℝ) / 6250000)) (t := ((410801 : ℝ) / 12910801))
    (lo := ((1591457 : ℝ) / 25000000)) (hi := ((6365829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6660801 : ℝ) / 50000000) = Real.log ((6660801 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6660801 : ℝ) / 50000000) = ((6660801 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1743 : RB (Real.log ((14103961 : ℝ) / 100000000)) ((-97935727 : ℝ) / 50000000) ((-3917429 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((14103961 : ℝ) / 12500000)) (t := ((1603961 : ℝ) / 26603961))
    (lo := ((12072703 : ℝ) / 100000000)) (hi := ((47159 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14103961 : ℝ) / 100000000) = Real.log ((14103961 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((14103961 : ℝ) / 100000000) = ((14103961 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1744 : RB (Real.log ((1319947 : ℝ) / 25000000)) ((-73532107 : ℝ) / 25000000) ((-294128423 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1319947 : ℝ) / 1562500)) (t := ((-242553 : ℝ) / 2882447))
    (lo := ((-1054347 : ℝ) / 6250000)) (hi := ((-16869551 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1319947 : ℝ) / 25000000) = Real.log ((1319947 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1319947 : ℝ) / 25000000) = ((1319947 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1745 : RB (Real.log ((1328933 : ℝ) / 25000000)) ((-5868999 : ℝ) / 2000000) ((-58689989 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1328933 : ℝ) / 1562500)) (t := ((-233567 : ℝ) / 2891433))
    (lo := ((-8095537 : ℝ) / 50000000)) (hi := ((-16191073 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1328933 : ℝ) / 25000000) = Real.log ((1328933 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1328933 : ℝ) / 25000000) = ((1328933 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1746 : RB (Real.log ((31368313 : ℝ) / 50000000)) ((-23311239 : ℝ) / 50000000) ((-11655619 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((31368313 : ℝ) / 25000000)) (t := ((6368313 : ℝ) / 56368313))
    (lo := ((22692241 : ℝ) / 100000000)) (hi := ((11346121 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31368313 : ℝ) / 50000000) = Real.log ((31368313 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31368313 : ℝ) / 50000000) = ((31368313 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1747 : RB (Real.log ((62738283 : ℝ) / 100000000)) ((-11654959 : ℝ) / 25000000) ((-23309917 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((62738283 : ℝ) / 50000000)) (t := ((12738283 : ℝ) / 112738283))
    (lo := ((22694883 : ℝ) / 100000000)) (hi := ((5673721 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62738283 : ℝ) / 100000000) = Real.log ((62738283 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62738283 : ℝ) / 100000000) = ((62738283 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1748 : RB (Real.log ((38600103 : ℝ) / 100000000)) ((-47595763 : ℝ) / 50000000) ((-23797881 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((38600103 : ℝ) / 50000000)) (t := ((-11399897 : ℝ) / 88600103))
    (lo := ((-25876807 : ℝ) / 100000000)) (hi := ((-12938403 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38600103 : ℝ) / 100000000) = Real.log ((38600103 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38600103 : ℝ) / 100000000) = ((38600103 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1749 : RB (Real.log ((37831343 : ℝ) / 20000000)) ((31870283 : ℝ) / 50000000) ((7967571 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((37831343 : ℝ) / 40000000)) (t := ((-2168657 : ℝ) / 77831343))
    (lo := ((-696769 : ℝ) / 12500000)) (hi := ((-5574151 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37831343 : ℝ) / 20000000) = Real.log ((37831343 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((37831343 : ℝ) / 20000000) = ((37831343 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1750 : RB (Real.log ((189223041 : ℝ) / 100000000)) ((7971953 : ℝ) / 12500000) ((31887813 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((189223041 : ℝ) / 200000000)) (t := ((-10776959 : ℝ) / 389223041))
    (lo := ((-2769547 : ℝ) / 50000000)) (hi := ((-5539093 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189223041 : ℝ) / 100000000) = Real.log ((189223041 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189223041 : ℝ) / 100000000) = ((189223041 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1751 : RB (Real.log ((6344833 : ℝ) / 10000000)) ((-45494433 : ℝ) / 100000000) ((-45494431 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6344833 : ℝ) / 5000000)) (t := ((1344833 : ℝ) / 11344833))
    (lo := ((11910143 : ℝ) / 50000000)) (hi := ((23820287 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6344833 : ℝ) / 10000000) = Real.log ((6344833 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((6344833 : ℝ) / 10000000) = ((6344833 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1752 : RB (Real.log ((12689999 : ℝ) / 20000000)) ((-45491809 : ℝ) / 100000000) ((-45491807 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12689999 : ℝ) / 10000000)) (t := ((2689999 : ℝ) / 22689999))
    (lo := ((2382291 : ℝ) / 10000000)) (hi := ((23822911 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12689999 : ℝ) / 20000000) = Real.log ((12689999 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((12689999 : ℝ) / 20000000) = ((12689999 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1753 : RB (Real.log ((38867457 : ℝ) / 100000000)) ((-11812661 : ℝ) / 12500000) ((-47250643 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((38867457 : ℝ) / 50000000)) (t := ((-11132543 : ℝ) / 88867457))
    (lo := ((-25186569 : ℝ) / 100000000)) (hi := ((-3148321 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38867457 : ℝ) / 100000000) = Real.log ((38867457 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38867457 : ℝ) / 100000000) = ((38867457 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1754 : RB (Real.log ((396441909 : ℝ) / 100000000)) ((137735933 : ℝ) / 100000000) ((538031 : ℝ) / 390625) := by
  have hm := log_bounds_of_series (x := ((396441909 : ℝ) / 400000000)) (t := ((-3558091 : ℝ) / 796441909))
    (lo := ((-893503 : ℝ) / 100000000)) (hi := ((-446751 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((396441909 : ℝ) / 100000000) = Real.log ((396441909 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((396441909 : ℝ) / 100000000) = ((396441909 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1755 : RB (Real.log ((396444927 : ℝ) / 100000000)) ((68868347 : ℝ) / 50000000) ((137736697 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((396444927 : ℝ) / 400000000)) (t := ((-3555073 : ℝ) / 796444927))
    (lo := ((-446371 : ℝ) / 50000000)) (hi := ((-892741 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((396444927 : ℝ) / 100000000) = Real.log ((396444927 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((396444927 : ℝ) / 100000000) = ((396444927 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1756 : RB (Real.log ((33426619 : ℝ) / 25000000)) ((29047673 : ℝ) / 100000000) ((1161907 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((33426619 : ℝ) / 50000000)) (t := ((-16573381 : ℝ) / 83426619))
    (lo := ((-8053409 : ℝ) / 20000000)) (hi := ((-10066761 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33426619 : ℝ) / 25000000) = Real.log ((33426619 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33426619 : ℝ) / 25000000) = ((33426619 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1757 : RB (Real.log ((395158479 : ℝ) / 100000000)) ((13741167 : ℝ) / 10000000) ((137411673 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((395158479 : ℝ) / 400000000)) (t := ((-4841521 : ℝ) / 795158479))
    (lo := ((-608883 : ℝ) / 50000000)) (hi := ((-243553 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((395158479 : ℝ) / 100000000) = Real.log ((395158479 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((395158479 : ℝ) / 100000000) = ((395158479 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1758 : RB (Real.log ((98790371 : ℝ) / 25000000)) ((137412431 : ℝ) / 100000000) ((68706217 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((98790371 : ℝ) / 100000000)) (t := ((-1209629 : ℝ) / 198790371))
    (lo := ((-243401 : ℝ) / 20000000)) (hi := ((-304251 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98790371 : ℝ) / 25000000) = Real.log ((98790371 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((98790371 : ℝ) / 25000000) = ((98790371 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1759 : RB (Real.log ((133853041 : ℝ) / 100000000)) ((2915723 : ℝ) / 10000000) ((1822327 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((133853041 : ℝ) / 200000000)) (t := ((-66146959 : ℝ) / 333853041))
    (lo := ((-2509843 : ℝ) / 6250000)) (hi := ((-40157487 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133853041 : ℝ) / 100000000) = Real.log ((133853041 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133853041 : ℝ) / 100000000) = ((133853041 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
