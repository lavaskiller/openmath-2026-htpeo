import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk14
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_52 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((612103650724987907323467269144575 : ℝ) / 5192296858534827628530496329220096) ((154519509324459885838904709034803 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((117886874999 : ℝ) / 1000000000000) ((9523 : ℝ) / 80000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1117886874999 : ℝ) / 1000000000000) ((89523 : ℝ) / 80000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((5572009223 : ℝ) / 50000000000) ((112468940833 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_679.1 dlower_log_680.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((5572009223 : ℝ) / 25000000000) ((112468940833 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((468209298893 : ℝ) / 1000000000000) ((11756670291 : ℝ) / 25000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2672537251 : ℝ) / 1250000000) ((-2128316709461 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_681.1 dlower_log_682.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2128316709461 : ℝ) / 1000000000000) ((2672537251 : ℝ) / 1250000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((43798201383 : ℝ) / 200000000000) ((220957158091 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779042841909 : ℝ) / 1000000000000) ((156201798617 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((13897315297 : ℝ) / 1000000000000) ((14169926407 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((279551850363 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((66345480989 : ℝ) / 250000000000) ((132827267533 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((279551850363 : ℝ) / 1000000000000) ((279551850363 : ℝ) / 1000000000000) ((279551850363 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((720448149637 : ℝ) / 1000000000000))
  have h11 : RB z11 ((92089182299 : ℝ) / 250000000000) ((368735120217 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((720448149637 : ℝ) / 1000000000000) ((720448149637 : ℝ) / 1000000000000) ((720448149637 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-998703437537 : ℝ) / 1000000000000) ((-199535344819 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_683.1 dlower_log_684.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-389998183071 : ℝ) / 500000000000) ((-155446582089 : ℝ) / 200000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((279551850363 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-254913498491 : ℝ) / 200000000000) ((-1274567492453 : ℝ) / 1000000000000) := rb_log (show RB ((279551850363 : ℝ) / 1000000000000) ((279551850363 : ℝ) / 1000000000000) ((279551850363 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_685.1 dlower_log_685.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((494571126311 : ℝ) / 1000000000000) ((49733458201 : ℝ) / 100000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((24304314671 : ℝ) / 1000000000000) ((29125283117 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((13897315297 : ℝ) / 1000000000000) ((14169926407 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1481165420677 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((146699549427 : ℝ) / 100000000000) ((73363405269 : ℝ) / 50000000000) := rb_widen (rb_sub (show RB ((1481165420677 : ℝ) / 1000000000000) ((1481165420677 : ℝ) / 1000000000000) ((1481165420677 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((481165420677 : ℝ) / 1000000000000))
  have h19 : RB z19 ((190552384797 : ℝ) / 62500000000) ((3049404720971 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((481165420677 : ℝ) / 1000000000000) ((481165420677 : ℝ) / 1000000000000) ((481165420677 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((139345073229 : ℝ) / 125000000000) ((1114946398119 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_686.1 dlower_log_687.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((434223127417 : ℝ) / 500000000000) ((870783163739 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1481165420677 : ℝ) / 1000000000000))
  have h22 : RB z22 ((78565844861 : ℝ) / 200000000000) ((392829224307 : ℝ) / 1000000000000) := rb_log (show RB ((1481165420677 : ℝ) / 1000000000000) ((1481165420677 : ℝ) / 1000000000000) ((1481165420677 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_688.1 dlower_log_688.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((475617030527 : ℝ) / 1000000000000) ((238976969717 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5350218887 : ℝ) / 1000000000000) ((9744640541 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1117886874999 : ℝ) / 1000000000000) ((89523 : ℝ) / 80000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((249934213059 : ℝ) / 200000000000) ((1252244926407 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((798565822797 : ℝ) / 500000000000) ((1600421147247 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((600806785157 : ℝ) / 500000000000))
  have h28 : RB z28 ((1919135058923 : ℝ) / 1000000000000) ((307694043 : ℝ) / 160000000) := rb_widen (rb_mul h27 (show RB ((600806785157 : ℝ) / 500000000000) ((600806785157 : ℝ) / 500000000000) ((600806785157 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((13897315297 : ℝ) / 1000000000000) ((14169926407 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((414062534043946650155751 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((134253299 : ℝ) / 4000000000) ((6844341249 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((414062534043946650155751 : ℝ) / 1000000000000000000000000) ((414062534043946650155751 : ℝ) / 1000000000000000000000000) ((414062534043946650155751 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((193155658751 : ℝ) / 200000000000) ((3865746701 : ℝ) / 4000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((463364745673 : ℝ) / 250000000000) ((371708509889 : ℝ) / 200000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((279551850363 : ℝ) / 1000000000000)) ((24304314671 : ℝ) / 1000000000000) ((29125283117 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1481165420677 : ℝ) / 1000000000000)) ((5350218887 : ℝ) / 1000000000000) ((9744640541 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((279551850363 : ℝ) / 1000000000000)) (wl := ((1481165420677 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((463364745673 : ℝ) / 250000000000) ≤ D0q (q) * (((1481165420677 : ℝ) / 1000000000000) - ((279551850363 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1481165420677 : ℝ) / 1000000000000) * ((279551850363 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_53 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((154519509324459885838904709034803 : ℝ) / 1298074214633706907132624082305024) ((310532615292132680685847309818265 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((119037499999 : ℝ) / 1000000000000) ((382761 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1119037499999 : ℝ) / 1000000000000) ((3582761 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((112468940831 : ℝ) / 1000000000000) ((112982922413 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_689.1 dlower_log_690.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((112468940831 : ℝ) / 500000000000) ((112982922413 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((467181335733 : ℝ) / 1000000000000) ((234104649449 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2128316709471 : ℝ) / 1000000000000) ((-530873828819 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_691.1 dlower_log_692.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((530873828819 : ℝ) / 250000000000) ((2128316709471 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((109753716083 : ℝ) / 500000000000) ((220489913743 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779510086257 : ℝ) / 1000000000000) ((390246283917 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7084963203 : ℝ) / 500000000000) ((2861444983 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((46677600619 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((10954038909 : ℝ) / 50000000000) ((219218076689 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((46677600619 : ℝ) / 200000000000) ((46677600619 : ℝ) / 200000000000) ((46677600619 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((153322399381 : ℝ) / 200000000000))
  have h11 : RB z11 ((142888957559 : ℝ) / 500000000000) ((285957012901 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((153322399381 : ℝ) / 200000000000) ((153322399381 : ℝ) / 200000000000) ((153322399381 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-626270145189 : ℝ) / 500000000000) ((-156489223 : ℝ) / 125000000) := rb_log h11 (by norm_num) dlower_log_693.1 dlower_log_694.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-977598387553 : ℝ) / 1000000000000) ((-121984927719 : ℝ) / 125000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((46677600619 : ℝ) / 200000000000))
  have h14 : RB z14 ((-1455052961073 : ℝ) / 1000000000000) ((-1455052961071 : ℝ) / 1000000000000) := rb_log (show RB ((46677600619 : ℝ) / 200000000000) ((46677600619 : ℝ) / 200000000000) ((46677600619 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_695.1 dlower_log_695.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((238727286759 : ℝ) / 500000000000) ((479173539321 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((462263731 : ℝ) / 50000000000) ((2998050897 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7084963203 : ℝ) / 500000000000) ((2861444983 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((742058137773 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1469809050631 : ℝ) / 1000000000000) ((73497317457 : ℝ) / 50000000000) := rb_widen (rb_sub (show RB ((742058137773 : ℝ) / 500000000000) ((742058137773 : ℝ) / 500000000000) ((742058137773 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((242058137773 : ℝ) / 500000000000))
  have h19 : RB z19 ((3036066178467 : ℝ) / 1000000000000) ((151817489247 : ℝ) / 50000000000) := rb_div_signed h18 (show RB ((242058137773 : ℝ) / 500000000000) ((242058137773 : ℝ) / 500000000000) ((242058137773 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((138820332151 : ℝ) / 125000000000) ((69416004083 : ℝ) / 62500000000) := rb_log h19 (by norm_num) dlower_log_696.1 dlower_log_697.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((432847396357 : ℝ) / 500000000000) ((866858804409 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((742058137773 : ℝ) / 500000000000))
  have h22 : RB z22 ((98704873617 : ℝ) / 250000000000) ((39481949447 : ℝ) / 100000000000) := rb_log (show RB ((742058137773 : ℝ) / 500000000000) ((742058137773 : ℝ) / 500000000000) ((742058137773 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_698.1 dlower_log_698.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((117718824561 : ℝ) / 250000000000) ((472039309941 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1332999673 : ℝ) / 500000000000) ((75905847 : ℝ) / 15625000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1119037499999 : ℝ) / 1000000000000) ((3582761 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((313061231601 : ℝ) / 250000000000) ((250706569983 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((797745348331 : ℝ) / 500000000000) ((1597131645599 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1250728272451 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1995525322747 : ℝ) / 1000000000000) ((1997577703977 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1250728272451 : ℝ) / 1000000000000) ((1250728272451 : ℝ) / 1000000000000) ((1250728272451 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7084963203 : ℝ) / 500000000000) ((2861444983 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((34637493391046972081487 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((20454607159 : ℝ) / 500000000000) ((8261120257 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((34637493391046972081487 : ℝ) / 100000000000000000000000) ((34637493391046972081487 : ℝ) / 100000000000000000000000) ((34637493391046972081487 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((191738879743 : ℝ) / 200000000000) ((479545392841 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1913098949411 : ℝ) / 1000000000000) ((1915858369569 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((46677600619 : ℝ) / 200000000000)) ((462263731 : ℝ) / 50000000000) ((2998050897 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((742058137773 : ℝ) / 500000000000)) ((1332999673 : ℝ) / 500000000000) ((75905847 : ℝ) / 15625000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((46677600619 : ℝ) / 200000000000)) (wl := ((742058137773 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1913098949411 : ℝ) / 1000000000000) ≤ D0q (q) * (((742058137773 : ℝ) / 500000000000) - ((46677600619 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((742058137773 : ℝ) / 500000000000) * ((46677600619 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_54 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((310532615292132680685847309818265 : ℝ) / 2596148429267413814265248164610048) ((624052423870691179387770403133849 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((119612812499 : ℝ) / 1000000000000) ((192301 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1119612812499 : ℝ) / 1000000000000) ((1792301 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((28245730603 : ℝ) / 250000000000) ((7093539997 : ℝ) / 62500000000) := rb_log h1 (by norm_num) dlower_log_699.1 dlower_log_700.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((28245730603 : ℝ) / 125000000000) ((7093539997 : ℝ) / 31250000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((93230780131 : ℝ) / 200000000000) ((58397666967 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1061747657643 : ℝ) / 500000000000) ((-2118697055437 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_701.1 dlower_log_702.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2118697055437 : ℝ) / 1000000000000) ((1061747657643 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((219521982129 : ℝ) / 1000000000000) ((27563009453 : ℝ) / 125000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((97436990547 : ℝ) / 125000000000) ((780478017871 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((14307224913 : ℝ) / 1000000000000) ((902824087 : ℝ) / 62500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((7421469237 : ℝ) / 31250000000)) - (z9)
  have h10 : RB z10 ((13940114387 : ℝ) / 62500000000) ((223179790671 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((7421469237 : ℝ) / 31250000000) ((7421469237 : ℝ) / 31250000000) ((7421469237 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((23828530763 : ℝ) / 31250000000))
  have h11 : RB z11 ((292508894603 : ℝ) / 1000000000000) ((146344911649 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((23828530763 : ℝ) / 31250000000) ((23828530763 : ℝ) / 31250000000) ((23828530763 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-614630101937 : ℝ) / 500000000000) ((-614320927129 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_703.1 dlower_log_704.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-119926320921 : ℝ) / 125000000000) ((-957721317911 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((7421469237 : ℝ) / 31250000000))
  have h14 : RB z14 ((-359410582057 : ℝ) / 250000000000) ((-718821164113 : ℝ) / 500000000000) := rb_log (show RB ((7421469237 : ℝ) / 31250000000) ((7421469237 : ℝ) / 31250000000) ((7421469237 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_705.1 dlower_log_705.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((239115880429 : ℝ) / 500000000000) ((479921010317 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((5525212561 : ℝ) / 500000000000) ((6883554831 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((14307224913 : ℝ) / 1000000000000) ((902824087 : ℝ) / 62500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1484652487983 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1470207302591 : ℝ) / 1000000000000) ((147034526307 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((1484652487983 : ℝ) / 1000000000000) ((1484652487983 : ℝ) / 1000000000000) ((1484652487983 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((484652487983 : ℝ) / 1000000000000))
  have h19 : RB z19 ((1516764423009 : ℝ) / 500000000000) ((1516906752289 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((484652487983 : ℝ) / 1000000000000) ((484652487983 : ℝ) / 1000000000000) ((484652487983 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1109726577507 : ℝ) / 1000000000000) ((55491020527 : ℝ) / 50000000000) := rb_log h19 (by norm_num) dlower_log_706.1 dlower_log_707.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((432513672169 : ℝ) / 500000000000) ((216547608553 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1484652487983 : ℝ) / 1000000000000))
  have h22 : RB z22 ((395180730041 : ℝ) / 1000000000000) ((395180730043 : ℝ) / 1000000000000) := rb_log (show RB ((1484652487983 : ℝ) / 1000000000000) ((1484652487983 : ℝ) / 1000000000000) ((1484652487983 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_708.1 dlower_log_708.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((93969322859 : ℝ) / 200000000000) ((471009704171 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2665278559 : ℝ) / 1000000000000) ((1213950879 : ℝ) / 250000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1119612812499 : ℝ) / 1000000000000) ((1792301 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1253532849911 : ℝ) / 1000000000000) ((612705779 : ℝ) / 488281250) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1593852275383 : ℝ) / 1000000000000) ((398872674167 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1247165472399 : ℝ) / 1000000000000))
  have h28 : RB z28 ((993898762981 : ℝ) / 500000000000) ((1989840908419 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1247165472399 : ℝ) / 1000000000000) ((1247165472399 : ℝ) / 1000000000000) ((1247165472399 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((14307224913 : ℝ) / 1000000000000) ((902824087 : ℝ) / 62500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((11018302767201346678971 : ℝ) / 31250000000000000000000))
  have h30 : RB z30 ((40578008063 : ℝ) / 1000000000000) ((40969290193 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((11018302767201346678971 : ℝ) / 31250000000000000000000) ((11018302767201346678971 : ℝ) / 31250000000000000000000) ((11018302767201346678971 : ℝ) / 31250000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((959030709807 : ℝ) / 1000000000000) ((959421991937 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((76254354891 : ℝ) / 40000000000) ((954548563997 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((7421469237 : ℝ) / 31250000000)) ((5525212561 : ℝ) / 500000000000) ((6883554831 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1484652487983 : ℝ) / 1000000000000)) ((2665278559 : ℝ) / 1000000000000) ((1213950879 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((7421469237 : ℝ) / 31250000000)) (wl := ((1484652487983 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((76254354891 : ℝ) / 40000000000) ≤ D0q (q) * (((1484652487983 : ℝ) / 1000000000000) - ((7421469237 : ℝ) / 31250000000)) * (1 - (q) ^ 2 / (((1484652487983 : ℝ) / 1000000000000) * ((7421469237 : ℝ) / 31250000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_55 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((624052423870691179387770403133849 : ℝ) / 5192296858534827628530496329220096) ((627039617157116997403846186631167 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((120188124999 : ℝ) / 1000000000000) ((386443 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1120188124999 : ℝ) / 1000000000000) ((3586443 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((2269932799 : ℝ) / 20000000000) ((114010093721 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_709.1 dlower_log_710.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((2269932799 : ℝ) / 10000000000) ((114010093721 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((465126993117 : ℝ) / 1000000000000) ((23307695033 : ℝ) / 50000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-264837131931 : ℝ) / 125000000000) ((-528480427249 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_711.1 dlower_log_712.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((528480427249 : ℝ) / 250000000000) ((264837131931 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((54883612539 : ℝ) / 250000000000) ((220516161349 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779483838651 : ℝ) / 1000000000000) ((195116387461 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1444518539 : ℝ) / 100000000000) ((14583807837 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((244533086667 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((22994927883 : ℝ) / 100000000000) ((230087901277 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((244533086667 : ℝ) / 1000000000000) ((244533086667 : ℝ) / 1000000000000) ((244533086667 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((755466913333 : ℝ) / 1000000000000))
  have h11 : RB z11 ((152190171913 : ℝ) / 500000000000) ((3807047953 : ℝ) / 12500000000) := rb_div_signed h10 (show RB ((755466913333 : ℝ) / 1000000000000) ((755466913333 : ℝ) / 1000000000000) ((755466913333 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-594738614291 : ℝ) / 500000000000) ((-594437285489 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_713.1 dlower_log_714.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-928345999233 : ℝ) / 1000000000000) ((-46335425713 : ℝ) / 50000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((244533086667 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-176050581929 : ℝ) / 125000000000) ((-140840465543 : ℝ) / 100000000000) := rb_log (show RB ((244533086667 : ℝ) / 1000000000000) ((244533086667 : ℝ) / 1000000000000) ((244533086667 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_715.1 dlower_log_715.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((480058656197 : ℝ) / 1000000000000) ((120424035293 : ℝ) / 250000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((13904755537 : ℝ) / 1000000000000) ((3313829611 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1444518539 : ℝ) / 100000000000) ((14583807837 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((742595057133 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1470606306429 : ℝ) / 1000000000000) ((367686232219 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((742595057133 : ℝ) / 500000000000) ((742595057133 : ℝ) / 500000000000) ((742595057133 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((242595057133 : ℝ) / 500000000000))
  have h19 : RB z19 ((3030989839217 : ℝ) / 1000000000000) ((1515637773351 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((242595057133 : ℝ) / 500000000000) ((242595057133 : ℝ) / 500000000000) ((242595057133 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1108889245781 : ℝ) / 1000000000000) ((1108983503447 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_716.1 dlower_log_717.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((43218062297 : ℝ) / 50000000000) ((432761709893 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((742595057133 : ℝ) / 500000000000))
  have h22 : RB z22 ((197771393567 : ℝ) / 500000000000) ((6180356049 : ℝ) / 15625000000) := rb_log (show RB ((742595057133 : ℝ) / 500000000000) ((742595057133 : ℝ) / 500000000000) ((742595057133 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_718.1 dlower_log_718.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((117204614701 : ℝ) / 250000000000) ((117495158163 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41633721 : ℝ) / 15625000000) ((970727907 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1120188124999 : ℝ) / 1000000000000) ((3586443 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((313705358847 : ℝ) / 250000000000) ((1256110682837 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1592216376571 : ℝ) / 1000000000000) ((1593852275389 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1240657027599 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1975394437051 : ℝ) / 1000000000000) ((1977424026417 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1240657027599 : ℝ) / 1000000000000) ((1240657027599 : ℝ) / 1000000000000) ((1240657027599 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1444518539 : ℝ) / 100000000000) ((14583807837 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((181589061464389705545711 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((7954876397 : ℝ) / 200000000000) ((40156074709 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((181589061464389705545711 : ℝ) / 500000000000000000000000) ((181589061464389705545711 : ℝ) / 500000000000000000000000) ((181589061464389705545711 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((959843925291 : ℝ) / 1000000000000) ((192045123603 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1896070350457 : ℝ) / 1000000000000) ((474693301961 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((244533086667 : ℝ) / 1000000000000)) ((13904755537 : ℝ) / 1000000000000) ((3313829611 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((742595057133 : ℝ) / 500000000000)) ((41633721 : ℝ) / 15625000000) ((970727907 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((244533086667 : ℝ) / 1000000000000)) (wl := ((742595057133 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1896070350457 : ℝ) / 1000000000000) ≤ D0q (q) * (((742595057133 : ℝ) / 500000000000) - ((244533086667 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((742595057133 : ℝ) / 500000000000) * ((244533086667 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
