import LeanProject.Stage10C5

/-!
# EP-1038, Stage 10 Part (c), N1: the series of `φ_S` and `Ψ_S = y / φ_S(y)`

* `muS k S ℓ = m_ℓ(S)/(kℓ)` (`μ₀ = 0`), `HS = Σ μ_ℓ X^ℓ`;
* `phiS k S j = Σ_{i ≤ j} [X^j] HS^i / i!` (nonnegative);
* `ev_HS` : `Σ μ_ℓ y^ℓ = -(1/k) ∫_0^1 log(1 - y/S)` for `|y| < a` (termwise integration);
* `phiv_phiS` : `Σ φ_j yʲ = exp(Σ μ_ℓ y^ℓ)` for `|y| < a` (composition with `exp`);
* `PsiS_eq_div` : `Ψ_S(y) = y / φ_S(y)` for `|y| < a`.
-/

open Real Set Filter Topology PowerSeries Finset MeasureTheory intervalIntegral
open scoped Nat

namespace EP1038.Stage10

/-- `μ_ℓ = m_ℓ(S)/(kℓ)`, `μ₀ = 0`. -/
noncomputable def muS (k : ℝ) (S : ℝ → ℝ) (ℓ : ℕ) : ℝ := if ℓ = 0 then 0 else mom ℓ S / (k * ℓ)

/-- `H = Σ μ_ℓ X^ℓ`. -/
noncomputable def HS (k : ℝ) (S : ℝ → ℝ) : PowerSeries ℝ := PowerSeries.mk (muS k S)

/-- `φ_j = Σ_{i ≤ j} [X^j] H^i / i!`. -/
noncomputable def phiS (k : ℝ) (S : ℝ → ℝ) (j : ℕ) : ℝ :=
  ∑ i ∈ range (j + 1), (1 / (i ! : ℝ)) * coeff j (HS k S ^ i)

section series

variable {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
  (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
include hSm ha hSa hS2 hk

theorem ii_inv_powS (ℓ : ℕ) : IntervalIntegrable (fun u => 1 / S u ^ ℓ) volume 0 1 := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le zero_le_one]
  refine Measure.integrableOn_of_bounded (M := 1 / a ^ ℓ) measure_Ioc_lt_top.ne
    ((measurable_const.div (hSm.pow_const ℓ)).aestronglyMeasurable) ?_
  refine Eventually.of_forall fun u => ?_
  have hpos : 0 < S u := by linarith [hSa u]
  rw [Real.norm_eq_abs, abs_of_pos (by positivity)]
  exact one_div_le_one_div_of_le (by positivity) (pow_le_pow_left₀ ha.le (hSa u) ℓ)

theorem mom_nonneg (ℓ : ℕ) : 0 ≤ mom ℓ S :=
  intervalIntegral.integral_nonneg zero_le_one fun u _ => by
    have : 0 < S u := by linarith [hSa u]
    positivity

theorem mom_le (ℓ : ℕ) : mom ℓ S ≤ 1 / a ^ ℓ := by
  have h : mom ℓ S ≤ ∫ _ in (0 : ℝ)..1, 1 / a ^ ℓ := by
    refine intervalIntegral.integral_mono_on zero_le_one (ii_inv_powS hSm ha hSa hS2 hk ℓ)
      intervalIntegrable_const fun u _ => ?_
    exact one_div_le_one_div_of_le (by positivity) (pow_le_pow_left₀ ha.le (hSa u) ℓ)
  simpa using h

theorem muS_nonneg (ℓ : ℕ) : 0 ≤ muS k S ℓ := by
  unfold muS
  split_ifs
  · exact le_rfl
  · exact div_nonneg (mom_nonneg hSm ha hSa hS2 hk ℓ) (by positivity)

theorem muS_le (ℓ : ℕ) : muS k S ℓ ≤ (1 / k) * (1 / a) ^ ℓ := by
  unfold muS
  split_ifs with h
  · positivity
  · have hℓ : (1 : ℝ) ≤ ℓ := by exact_mod_cast Nat.one_le_iff_ne_zero.mpr h
    rw [div_le_iff₀ (by positivity), one_div_pow]
    have := mom_le hSm ha hSa hS2 hk ℓ
    calc mom ℓ S ≤ 1 / a ^ ℓ := this
      _ ≤ 1 / k * (1 / a ^ ℓ) * (k * ℓ) := by
          rw [show 1 / k * (1 / a ^ ℓ) * (k * ℓ) = 1 / a ^ ℓ * ℓ by field_simp]
          exact le_mul_of_one_le_right (by positivity) hℓ

theorem NN_HS : NN (HS k S) := fun n => by
  simp only [HS, coeff_mk]; exact muS_nonneg hSm ha hSa hS2 hk n

theorem AC_HS {y : ℝ} (hy : |y| < a) : AC (HS k S) y := by
  rw [AC_abs_iff (NN_HS hSm ha hSa hS2 hk)]
  have hq : |y| / a < 1 := by rw [div_lt_one ha]; exact hy
  have hgeo : Summable fun n => (1 / k) * (|y| / a) ^ n :=
    (summable_geometric_of_lt_one (by positivity) hq).mul_left _
  refine hgeo.of_nonneg_of_le (fun n => mul_nonneg ((NN_HS hSm ha hSa hS2 hk) n)
    (pow_nonneg (abs_nonneg y) n)) fun n => ?_
  simp only [HS, coeff_mk]
  calc muS k S n * |y| ^ n ≤ (1 / k) * (1 / a) ^ n * |y| ^ n :=
        mul_le_mul_of_nonneg_right (muS_le hSm ha hSa hS2 hk n) (pow_nonneg (abs_nonneg y) n)
    _ = (1 / k) * (|y| / a) ^ n := by rw [mul_assoc, ← mul_pow]; congr 2; ring

theorem phiS_nonneg (j : ℕ) : 0 ≤ phiS k S j :=
  Finset.sum_nonneg fun i _ => mul_nonneg (by positivity) (NN_pow (NN_HS hSm ha hSa hS2 hk) i j)

omit hSm ha hSa hS2 hk in
theorem phiS_eq_tsum (j : ℕ) :
    phiS k S j = ∑' i, (1 / (i ! : ℝ)) * coeff j (HS k S ^ i) := by
  unfold phiS
  rw [tsum_eq_sum (s := range (j + 1))]
  intro i hi
  rw [Finset.mem_range, not_lt] at hi
  have h0 : coeff 0 (HS k S) = 0 := by simp [HS, muS]
  rw [coeff_pow_lt h0 i j (by omega), mul_zero]

omit hSm ha hSa hS2 hk in
theorem exp_eq_tsum' (x : ℝ) : Real.exp x = ∑' i, (1 / (i ! : ℝ)) * x ^ i := by
  rw [Real.exp_eq_exp_ℝ, congrFun NormedSpace.exp_eq_tsum_div x]
  congr 1; funext i; ring

/-- `Σ φ_j yʲ = exp(H(y))` for `|y| < a`, with summability. -/
theorem phiv_phiS {y : ℝ} (hy : |y| < a) :
    Summable (fun j => phiS k S j * y ^ j) ∧ phiv (phiS k S) y = Real.exp (ev (HS k S) y) := by
  have hNN := NN_HS hSm ha hSa hS2 hk
  have hb : ∀ i, 0 ≤ 1 / (i ! : ℝ) := fun i => by positivity
  have hs : Summable fun i => 1 / (i ! : ℝ) * ev (HS k S) |y| ^ i := by
    have := Real.summable_pow_div_factorial (ev (HS k S) |y|)
    exact this.congr fun i => by ring
  obtain ⟨hsum, heq⟩ := comp_ev hNN hb (AC_HS hSm ha hSa hS2 hk hy) hs
  have e : ∀ j, phiS k S j * y ^ j = (∑' i, 1 / (i ! : ℝ) * coeff j (HS k S ^ i)) * y ^ j :=
    fun j => by rw [phiS_eq_tsum]
  refine ⟨hsum.congr fun j => (e j).symm, ?_⟩
  unfold phiv
  simp_rw [e]
  rw [heq, exp_eq_tsum']

/-- Termwise integration: `∫_0^1 log(1 - y/S) = -k Σ μ_ℓ y^ℓ` for `|y| < a`. -/
theorem integral_log_one_sub {y : ℝ} (hy : |y| < a) :
    ∫ u in (0 : ℝ)..1, Real.log (1 - y / S u) = -(k * ev (HS k S) y) := by
  have hq : |y| / a < 1 := by rw [div_lt_one ha]; exact hy
  set F : ℕ → ℝ → ℝ := fun n u => (y / S u) ^ (n + 1) / (n + 1) with hF
  have habs : ∀ u, |y / S u| ≤ |y| / a := fun u => by
    have hS : 0 < S u := by linarith [hSa u]
    rw [abs_div, abs_of_pos hS]
    exact div_le_div_of_nonneg_left (abs_nonneg y) ha (hSa u)
  have hpt : ∀ u, ∑' n, F n u = -Real.log (1 - y / S u) := fun u =>
    (Real.hasSum_pow_div_log_of_abs_lt_one (lt_of_le_of_lt (habs u) hq)).tsum_eq
  have hFmeas : ∀ n, Measurable (F n) := fun n =>
    ((measurable_const.div hSm).pow_const _).div_const _
  have hFbound : ∀ n u, ‖F n u‖ ≤ (|y| / a) ^ (n + 1) := fun n u => by
    have h2 := habs u
    simp only [hF, Real.norm_eq_abs, abs_div, abs_pow]
    rw [abs_div] at h2
    have h1 : (1 : ℝ) ≤ |(n : ℝ) + 1| := by rw [abs_of_pos (by positivity)]; linarith [n.cast_nonneg (α := ℝ)]
    calc (|y| / |S u|) ^ (n + 1) / |(n : ℝ) + 1| ≤ (|y| / |S u|) ^ (n + 1) :=
          div_le_self (by positivity) h1
      _ ≤ (|y| / a) ^ (n + 1) := pow_le_pow_left₀ (by positivity) h2 _
  have hint : ∀ n, Integrable (F n) (volume.restrict (Ioc (0 : ℝ) 1)) := fun n =>
    Measure.integrableOn_of_bounded (M := (|y| / a) ^ (n + 1)) measure_Ioc_lt_top.ne
      (hFmeas n).aestronglyMeasurable (Eventually.of_forall fun u => hFbound n u)
  have hsumint : Summable fun n => ∫ u in Ioc (0 : ℝ) 1, ‖F n u‖ := by
    refine (summable_geometric_of_lt_one (by positivity) hq |>.mul_left (|y| / a)).of_nonneg_of_le
      (fun n => integral_nonneg fun _ => norm_nonneg _) fun n => ?_
    calc ∫ u in Ioc (0 : ℝ) 1, ‖F n u‖ ≤ ∫ _ in Ioc (0 : ℝ) 1, (|y| / a) ^ (n + 1) :=
          setIntegral_mono_on (hint n).norm (integrableOn_const measure_Ioc_lt_top.ne)
            measurableSet_Ioc fun u _ => hFbound n u
      _ = |y| / a * (|y| / a) ^ n := by
          rw [setIntegral_const, measureReal_def, Real.volume_Ioc, sub_zero,
            ENNReal.toReal_ofReal zero_le_one, one_smul, pow_succ]; ring
  have hswap := integral_tsum_of_summable_integral_norm hint hsumint
  have hintF : ∀ n, ∫ u in Ioc (0 : ℝ) 1, F n u = y ^ (n + 1) * mom (n + 1) S / (n + 1) := by
    intro n
    unfold mom
    rw [intervalIntegral.integral_of_le zero_le_one, ← MeasureTheory.integral_const_mul,
      ← MeasureTheory.integral_div]
    refine setIntegral_congr_fun measurableSet_Ioc fun u _ => ?_
    simp only [hF, div_pow]
    ring
  rw [intervalIntegral.integral_of_le zero_le_one]
  have hlog : ∫ u in Ioc (0 : ℝ) 1, Real.log (1 - y / S u) = -∫ u in Ioc (0 : ℝ) 1, ∑' n, F n u := by
    rw [← MeasureTheory.integral_neg]
    refine setIntegral_congr_fun measurableSet_Ioc fun u _ => ?_
    simp only [hpt]; ring
  rw [hlog, ← hswap]
  simp_rw [hintF]
  -- `ev H y = Σ_{n} μ_{n+1} y^{n+1}`
  have hHsum : Summable fun n => coeff n (HS k S) * y ^ n := (AC_HS hSm ha hSa hS2 hk hy).of_norm
  unfold ev
  rw [hHsum.tsum_eq_zero_add]
  simp only [HS, coeff_mk, muS, if_pos, pow_zero, mul_one, zero_add, Nat.succ_ne_zero, if_false]
  rw [← tsum_mul_left]
  congr 1
  refine tsum_congr fun n => ?_
  push_cast
  field_simp

/-- `L_S(y) - L_S(0) = -k H(y)` for `|y| < a`. -/
theorem LS_sub_eq {y : ℝ} (hy : |y| < a) : LS S y - LS S 0 = -(k * ev (HS k S) y) := by
  have hya : y < a := lt_of_le_of_lt (le_abs_self y) hy
  rw [← integral_log_one_sub hSm ha hSa hS2 hk hy]
  unfold LS
  rw [← intervalIntegral.integral_sub (ii_log hSm ha hSa hS2 hya) (ii_log hSm ha hSa hS2 ha)]
  refine intervalIntegral.integral_congr fun u _ => ?_
  have hS : 0 < S u := by linarith [hSa u]
  simp only [sub_zero]
  rw [← Real.log_div (by linarith [hSa u]) hS.ne']
  congr 1
  field_simp

/-- `Ψ_S(y) = y / φ_S(y)` for `|y| < a`. -/
theorem PsiS_eq_div {y : ℝ} (hy : |y| < a) : PsiS k S y = y / phiv (phiS k S) y := by
  rw [(phiv_phiS hSm ha hSa hS2 hk hy).2]
  unfold PsiS
  rw [LS_sub_eq hSm ha hSa hS2 hk hy, show y / Real.exp (ev (HS k S) y) =
    y * Real.exp (-(ev (HS k S) y)) by rw [Real.exp_neg, div_eq_mul_inv]]
  congr 2
  field_simp

end series

end EP1038.Stage10
