import LeanProject.Stage10C2
import Mathlib.RingTheory.PowerSeries.Trunc
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# EP-1038, Stage 10 Part (c): evaluation of power series with nonnegative coefficients

`ev A x = ∑' n, [Xⁿ]A · xⁿ`, `AC A x` = absolute convergence of that series.
* `AC_mul`, `AC_pow`: Cauchy products; `ev (A^j) x = (ev A x)^j`.
* `NN` (nonnegative coefficients) is stable under products and powers.
* `comp_ev`: for `b_j ≥ 0` with `∑ b_j (ev A |x|)^j < ∞`,
  `∑_n (∑_j b_j [Xⁿ]A^j) xⁿ = ∑_j b_j (ev A x)^j` (Tonelli/Fubini for the absolutely convergent
  double series).
-/

open Real Set Filter Topology PowerSeries Finset

namespace EP1038.Stage10

/-- Evaluation of a power series at a real point (as a `tsum`). -/
noncomputable def ev (A : PowerSeries ℝ) (x : ℝ) : ℝ := ∑' n, coeff n A * x ^ n

/-- Absolute convergence of `∑ [Xⁿ]A xⁿ`. -/
def AC (A : PowerSeries ℝ) (x : ℝ) : Prop := Summable fun n => ‖coeff n A * x ^ n‖

/-- Nonnegative coefficients. -/
def NN (A : PowerSeries ℝ) : Prop := ∀ n, 0 ≤ coeff n A

theorem coeff_mul_pow_eq (A B : PowerSeries ℝ) (x : ℝ) (n : ℕ) :
    coeff n (A * B) * x ^ n =
      ∑ kl ∈ antidiagonal n, (coeff kl.1 A * x ^ kl.1) * (coeff kl.2 B * x ^ kl.2) := by
  rw [coeff_mul, Finset.sum_mul]
  refine Finset.sum_congr rfl fun kl hkl => ?_
  rw [Finset.mem_antidiagonal] at hkl
  rw [← hkl, pow_add]
  ring

theorem AC_mul {A B : PowerSeries ℝ} {x : ℝ} (hA : AC A x) (hB : AC B x) :
    AC (A * B) x ∧ ev (A * B) x = ev A x * ev B x := by
  refine ⟨?_, ?_⟩
  · have h := summable_norm_sum_mul_antidiagonal_of_summable_norm
      (f := fun n => coeff n A * x ^ n) (g := fun n => coeff n B * x ^ n) hA hB
    exact h.congr fun n => by rw [coeff_mul_pow_eq]
  · have h := tsum_mul_tsum_eq_tsum_sum_antidiagonal_of_summable_norm
      (f := fun n => coeff n A * x ^ n) (g := fun n => coeff n B * x ^ n) hA hB
    unfold ev
    rw [h]
    exact tsum_congr fun n => coeff_mul_pow_eq A B x n

theorem AC_one (x : ℝ) : AC 1 x ∧ ev 1 x = 1 := by
  have h : ∀ n, coeff n (1 : PowerSeries ℝ) * x ^ n = if n = 0 then 1 else 0 := by
    intro n
    rw [coeff_one]
    split_ifs with h <;> simp [h]
  refine ⟨?_, ?_⟩
  · unfold AC
    simp_rw [h]
    exact summable_of_ne_finset_zero (s := {0}) fun n hn => by
      simp only [Finset.mem_singleton] at hn; simp [hn]
  · unfold ev
    simp_rw [h]
    rw [tsum_eq_single 0 fun n hn => by simp [hn]]
    simp

theorem AC_pow {A : PowerSeries ℝ} {x : ℝ} (hA : AC A x) (j : ℕ) :
    AC (A ^ j) x ∧ ev (A ^ j) x = ev A x ^ j := by
  induction j with
  | zero => simpa using AC_one x
  | succ j ih =>
    obtain ⟨h1, h2⟩ := AC_mul ih.1 hA
    rw [pow_succ, pow_succ]
    exact ⟨h1, by rw [h2, ih.2]⟩

theorem NN_mul {A B : PowerSeries ℝ} (hA : NN A) (hB : NN B) : NN (A * B) := fun n => by
  rw [coeff_mul]
  exact Finset.sum_nonneg fun kl _ => mul_nonneg (hA _) (hB _)

theorem NN_one : NN (1 : PowerSeries ℝ) := fun n => by
  rw [coeff_one]; split_ifs <;> norm_num

theorem NN_pow {A : PowerSeries ℝ} (hA : NN A) (j : ℕ) : NN (A ^ j) := by
  induction j with
  | zero => simpa using NN_one
  | succ j ih => rw [pow_succ]; exact NN_mul ih hA

theorem AC_abs_iff {A : PowerSeries ℝ} (hA : NN A) (x : ℝ) :
    AC A x ↔ Summable fun n => coeff n A * |x| ^ n := by
  unfold AC
  have : ∀ n, ‖coeff n A * x ^ n‖ = coeff n A * |x| ^ n := fun n => by
    rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg (hA n), abs_pow]
  simp_rw [this]

theorem AC_abs {A : PowerSeries ℝ} (hA : NN A) {x : ℝ} (h : AC A x) : AC A |x| := by
  rw [AC_abs_iff hA] at h ⊢
  simpa [abs_abs] using h

theorem ev_abs_le {A : PowerSeries ℝ} (hA : NN A) {x : ℝ} (h : AC A x) :
    |ev A x| ≤ ev A |x| := by
  unfold ev
  have hs := (AC_abs_iff hA x).mp h
  calc |∑' n, coeff n A * x ^ n| = ‖∑' n, coeff n A * x ^ n‖ := (Real.norm_eq_abs _).symm
    _ ≤ ∑' n, ‖coeff n A * x ^ n‖ := norm_tsum_le_tsum_norm h
    _ = ∑' n, coeff n A * |x| ^ n := by
        congr 1; funext n
        rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg (hA n), abs_pow]

theorem ev_nonneg {A : PowerSeries ℝ} (hA : NN A) {x : ℝ} (hx : 0 ≤ x) : 0 ≤ ev A x :=
  tsum_nonneg fun n => mul_nonneg (hA n) (pow_nonneg hx n)

/-- **Composition.** For `b_j ≥ 0` and `∑_j b_j (ev A |x|)^j < ∞`:
`∑_n (∑'_j b_j [Xⁿ]A^j) xⁿ = ∑'_j b_j (ev A x)^j`. -/
theorem comp_ev {A : PowerSeries ℝ} {b : ℕ → ℝ} (hA : NN A) (hb : ∀ j, 0 ≤ b j) {x : ℝ}
    (hAx : AC A x) (hs : Summable fun j => b j * ev A |x| ^ j) :
    Summable (fun n => (∑' j, b j * coeff n (A ^ j)) * x ^ n) ∧
      ∑' n, (∑' j, b j * coeff n (A ^ j)) * x ^ n = ∑' j, b j * ev A x ^ j := by
  set f : ℕ → ℕ → ℝ := fun j n => b j * coeff n (A ^ j) * x ^ n with hf
  have hAabs := AC_abs hA hAx
  have hnorm : ∀ j n, ‖f j n‖ = b j * (coeff n (A ^ j) * |x| ^ n) := fun j n => by
    simp only [hf, Real.norm_eq_abs, abs_mul, abs_of_nonneg (hb j), abs_of_nonneg (NN_pow hA j n),
      abs_pow]; ring
  have hrow : ∀ j, Summable fun n => coeff n (A ^ j) * |x| ^ n := fun j =>
    (AC_abs_iff (NN_pow hA j) x).mp (AC_pow hAx j).1
  have hrowsum : ∀ j, ∑' n, coeff n (A ^ j) * |x| ^ n = ev A |x| ^ j := fun j => by
    have := (AC_pow hAabs j).2
    unfold ev at this ⊢
    simpa [abs_abs] using this
  have hprod : Summable (fun p : ℕ × ℕ => ‖f p.1 p.2‖) := by
    rw [summable_prod_of_nonneg (fun p => norm_nonneg _)]
    refine ⟨fun j => ?_, ?_⟩
    · simp_rw [hnorm]; exact (hrow j).mul_left _
    · simp_rw [hnorm, tsum_mul_left, hrowsum]; exact hs
  have hsum : Summable (Function.uncurry f) := (hprod.of_norm : Summable fun p : ℕ × ℕ => f p.1 p.2)
  have hcomm := hsum.tsum_comm
  have hinner : ∀ j, ∑' n, f j n = b j * ev A x ^ j := fun j => by
    simp only [hf, mul_assoc]
    rw [tsum_mul_left]
    congr 1
    have := (AC_pow hAx j).2
    unfold ev at this
    exact this
  have hinner2 : ∀ n, ∑' j, f j n = (∑' j, b j * coeff n (A ^ j)) * x ^ n := fun n => by
    simp only [hf]
    exact tsum_mul_right
  refine ⟨?_, ?_⟩
  · have := hsum.prod_symm.prod
    simp only [Function.uncurry, Prod.swap] at this
    simpa [hinner2] using this
  · calc ∑' n, (∑' j, b j * coeff n (A ^ j)) * x ^ n = ∑' n, ∑' j, f j n :=
          tsum_congr fun n => (hinner2 n).symm
      _ = ∑' j, ∑' n, f j n := hcomm
      _ = ∑' j, b j * ev A x ^ j := tsum_congr hinner

end EP1038.Stage10
