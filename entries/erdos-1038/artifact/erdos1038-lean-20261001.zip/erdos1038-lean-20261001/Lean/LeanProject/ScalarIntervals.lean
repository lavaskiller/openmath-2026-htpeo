import LeanProject.R1PilotRoots
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds

/-! Sound rational interval arithmetic used by the actual scalar certificates. -/
open Real Set Finset
namespace EP1038.ReferenceCert

def RB (x lo hi : ℝ) : Prop := lo ≤ x ∧ x ≤ hi

theorem rb_widen {x lo hi l u : ℝ} (h : RB x lo hi) (hl : l ≤ lo) (hu : hi ≤ u) :
    RB x l u := ⟨hl.trans h.1, h.2.trans hu⟩

theorem rb_add {x y l u a b : ℝ} (hx : RB x l u) (hy : RB y a b) :
    RB (x + y) (l + a) (u + b) := ⟨add_le_add hx.1 hy.1, add_le_add hx.2 hy.2⟩

theorem rb_sub {x y l u a b : ℝ} (hx : RB x l u) (hy : RB y a b) :
    RB (x - y) (l - b) (u - a) := ⟨sub_le_sub hx.1 hy.2, sub_le_sub hx.2 hy.1⟩

theorem rb_mul {x y l u a b : ℝ} (hx : RB x l u) (hy : RB y a b)
    (hl : 0 ≤ l) (ha : 0 ≤ a) : RB (x * y) (l * a) (u * b) := by
  have hx0 := hl.trans hx.1
  have hy0 := ha.trans hy.1
  exact ⟨mul_le_mul hx.1 hy.1 ha hx0,
    mul_le_mul hx.2 hy.2 hy0 (hx0.trans hx.2)⟩

theorem rb_div {x y l u a b : ℝ} (hx : RB x l u) (hy : RB y a b)
    (hl : 0 ≤ l) (ha : 0 < a) : RB (x / y) (l / b) (u / a) := by
  have hy0 := ha.trans_le hy.1
  constructor
  · exact (div_le_div_of_nonneg_left hl hy0 hy.2).trans
      (div_le_div_of_nonneg_right hx.1 hy0.le)
  · exact (div_le_div_of_nonneg_right hx.2 hy0.le).trans
      (div_le_div_of_nonneg_left (hl.trans (hx.1.trans hx.2)) ha hy.1)

theorem rb_sq {x l u : ℝ} (hx : RB x l u) (hl : 0 ≤ l) : RB (x ^ 2) (l ^ 2) (u ^ 2) := by
  have h := rb_mul hx hx hl hl
  simpa only [← sq] using h

end EP1038.ReferenceCert
