import LeanProject.DLowerMLogs
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_param_1_point {q : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400)) :
    RB (delta (q)) ((131689980778143861 : ℝ) / 200000000000000000) ((65844990389071931 : ℝ) / 100000000000000000) ∧
    RB (delta1 (q)) ((-491400491400491401 : ℝ) / 250000000000000000) ((-1965601965601965601 : ℝ) / 1000000000000000000) ∧
    RB (delta2 (q)) ((965897771794577691 : ℝ) / 500000000000000000) ((1931795543589155389 : ℝ) / 1000000000000000000) ∧
    RB (aval (q)) ((104655139966488129 : ℝ) / 125000000000000000) ((837241119731905037 : ℝ) / 1000000000000000000) ∧
    RB (aval1 (q)) ((-1813077950903302509 : ℝ) / 1000000000000000000) ((-906538975451651141 : ℝ) / 500000000000000000) ∧
    RB (aval2 (q)) ((39835932518821908803 : ℝ) / 500000000000000000) ((39835932518822026941 : ℝ) / 500000000000000000) ∧
    RB (D0q (q)) ((965897771794577691 : ℝ) / 500000000000000000) ((1931795543589155389 : ℝ) / 1000000000000000000) ∧
    RB (d01 (q)) ((-3797141117619961459 : ℝ) / 1000000000000000000) ((-23732131985124759 : ℝ) / 6250000000000000) ∧
    RB (d02 (q)) ((11195502066692761003 : ℝ) / 1000000000000000000) ((11195502066692761077 : ℝ) / 1000000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1017499999999999999 : ℝ) / 1000000000000000000) ((407 : ℝ) / 400) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-202277719902633437 : ℝ) / 50000000000000000) ((-4045554398052668681 : ℝ) / 1000000000000000000) := rb_log hq (by norm_num) dlower_m_log_48.1 dlower_m_log_49.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((17348638334613 : ℝ) / 1000000000000000) ((8674319167306501 : ℝ) / 500000000000000000) := rb_log h1 (by norm_num) dlower_m_log_50.1 dlower_m_log_51.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((17348638334613 : ℝ) / 500000000000000) ((8674319167306501 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((131689980778143861 : ℝ) / 200000000000000000) ((65844990389071931 : ℝ) / 100000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((131689980778143861 : ℝ) / 200000000000000000) ((65844990389071931 : ℝ) / 100000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-491400491400491401 : ℝ) / 250000000000000000) ((-1965601965601965601 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-491400491400491401 : ℝ) / 250000000000000000) ((-1965601965601965601 : ℝ) / 1000000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((1035306249999999997 : ℝ) / 1000000000000000000) ((165649 : ℝ) / 160000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((965897771794577691 : ℝ) / 500000000000000000) ((1931795543589155389 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((965897771794577691 : ℝ) / 500000000000000000) ((1931795543589155389 : ℝ) / 1000000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-65844990389071931 : ℝ) / 100000000000000000) ((-131689980778143861 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((4045554398052668681 : ℝ) / 1000000000000000000) ((202277719902633437 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-20344860033511871 : ℝ) / 125000000000000000) ((-162758880268094963 : ℝ) / 1000000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((104655139966488129 : ℝ) / 125000000000000000) ((837241119731905037 : ℝ) / 1000000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((104655139966488129 : ℝ) / 125000000000000000) ((837241119731905037 : ℝ) / 1000000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((1965601965601965601 : ℝ) / 1000000000000000000) ((491400491400491401 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((4045554398052668681 : ℝ) / 1000000000000000000) ((202277719902633437 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((97173429013739619 : ℝ) / 200000000000000000) ((485867145068698103 : ℝ) / 1000000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((4045554398052668681 : ℝ) / 1000000000000000000) ((202277719902633437 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((255726724806301413 : ℝ) / 15625000000000000) ((1636651038760329091 : ℝ) / 100000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((143206965891528783 : ℝ) / 500000000000000000) ((286413931783057591 : ℝ) / 1000000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((459789019194400077 : ℝ) / 200000000000000000) ((574736273993000151 : ℝ) / 250000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-1813077950903302509 : ℝ) / 1000000000000000000) ((-906538975451651141 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-1813077950903302509 : ℝ) / 1000000000000000000) ((-906538975451651141 : ℝ) / 500000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-1931795543589155389 : ℝ) / 1000000000000000000) ((-965897771794577691 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((4045554398052668681 : ℝ) / 1000000000000000000) ((202277719902633437 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-477510707684224181 : ℝ) / 1000000000000000000) ((-119377676921056043 : ℝ) / 250000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-491400491400491401 : ℝ) / 125000000000000000) ((-1965601965601965601 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((4045554398052668681 : ℝ) / 1000000000000000000) ((202277719902633437 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((255726724806301413 : ℝ) / 15625000000000000) ((1636651038760329091 : ℝ) / 100000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((143206965891528783 : ℝ) / 500000000000000000) ((286413931783057591 : ℝ) / 1000000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-13725603034497626807 : ℝ) / 1000000000000000000) ((-13725603034497625587 : ℝ) / 1000000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((6624046163406700703 : ℝ) / 500000000000000000) ((2649618465362680527 : ℝ) / 200000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-102277719902633437 : ℝ) / 50000000000000000) ((-2045554398052668681 : ℝ) / 1000000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-1346895096801017923 : ℝ) / 1000000000000000000) ((-1346895096801017873 : ℝ) / 1000000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((4045554398052668681 : ℝ) / 1000000000000000000) ((202277719902633437 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((255726724806301413 : ℝ) / 15625000000000000) ((1636651038760329091 : ℝ) / 100000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((5012243806203491 : ℝ) / 1000000000000000000) ((1253060951550877 : ℝ) / 250000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-20277304974298851 : ℝ) / 1000000000000000000) ((-1013865248714939 : ℝ) / 50000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((1346895096801017873 : ℝ) / 1000000000000000000) ((1346895096801017923 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((1013865248714939 : ℝ) / 50000000000000000) ((20277304974298851 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((332118863554152081 : ℝ) / 5000000000000000) ((66423772710830651247 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((39835932518821908803 : ℝ) / 500000000000000000) ((39835932518822026941 : ℝ) / 500000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((39835932518821908803 : ℝ) / 500000000000000000) ((39835932518822026941 : ℝ) / 500000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((1035306249999999997 : ℝ) / 1000000000000000000) ((165649 : ℝ) / 160000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((965897771794577691 : ℝ) / 500000000000000000) ((1931795543589155389 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((965897771794577691 : ℝ) / 500000000000000000) ((1931795543589155389 : ℝ) / 1000000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((1035306249999999997 : ℝ) / 1000000000000000000) ((165649 : ℝ) / 160000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((210684821874999999 : ℝ) / 200000000000000000) ((67419143 : ℝ) / 64000000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-3797141117619961459 : ℝ) / 1000000000000000000) ((-23732131985124759 : ℝ) / 6250000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-3797141117619961459 : ℝ) / 1000000000000000000) ((-23732131985124759 : ℝ) / 6250000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((1035306249999999997 : ℝ) / 1000000000000000000) ((165649 : ℝ) / 160000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((1071859031289062493 : ℝ) / 1000000000000000000) ((27439591201 : ℝ) / 25600000000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((11195502066692761003 : ℝ) / 1000000000000000000) ((11195502066692761077 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((11195502066692761003 : ℝ) / 1000000000000000000) ((11195502066692761077 : ℝ) / 1000000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_param_1_slab {q : ℝ} (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50)) :
    RB (delta (q)) ((653541925967585881 : ℝ) / 1000000000000000000) ((165842488893111001 : ℝ) / 250000000000000000) ∧
    RB (delta1 (q)) ((-246305418719211823 : ℝ) / 125000000000000000) ((-490196078431372549 : ℝ) / 250000000000000000) ∧
    RB (delta2 (q)) ((96116878123798539 : ℝ) / 50000000000000000) ((970661748647140191 : ℝ) / 500000000000000000) ∧
    RB (aval (q)) ((166085580036110121 : ℝ) / 200000000000000000) ((844383852235285183 : ℝ) / 1000000000000000000) ∧
    RB (aval1 (q)) ((-484574713146125583 : ℝ) / 200000000000000000) ((-1349014182911208837 : ℝ) / 1000000000000000000) ∧
    RB (aval2 (q)) ((52795397716680738339 : ℝ) / 1000000000000000000) ((15629461533391577821 : ℝ) / 125000000000000000) ∧
    RB (D0q (q)) ((96116878123798539 : ℝ) / 50000000000000000) ((970661748647140191 : ℝ) / 500000000000000000) ∧
    RB (d01 (q)) ((-3825267974964099281 : ℝ) / 1000000000000000000) ((-1884644669094089 : ℝ) / 500000000000000) ∧
    RB (d02 (q)) ((1108614511231817059 : ℝ) / 100000000000000000) ((226124215268813751 : ℝ) / 20000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1014999999999999999 : ℝ) / 1000000000000000000) ((51 : ℝ) / 50) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-2099852538939963527 : ℝ) / 500000000000000000) ((-1956011502714073029 : ℝ) / 500000000000000000) := rb_log hq (by norm_num) dlower_m_log_52.1 dlower_m_log_53.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((14888612493750653 : ℝ) / 1000000000000000000) ((9901313648089857 : ℝ) / 500000000000000000) := rb_log h1 (by norm_num) dlower_m_log_54.1 dlower_m_log_55.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((14888612493750653 : ℝ) / 500000000000000000) ((9901313648089857 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((653541925967585881 : ℝ) / 1000000000000000000) ((165842488893111001 : ℝ) / 250000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((653541925967585881 : ℝ) / 1000000000000000000) ((165842488893111001 : ℝ) / 250000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-246305418719211823 : ℝ) / 125000000000000000) ((-490196078431372549 : ℝ) / 250000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-246305418719211823 : ℝ) / 125000000000000000) ((-490196078431372549 : ℝ) / 250000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((1030224999999999997 : ℝ) / 1000000000000000000) ((2601 : ℝ) / 2500) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((96116878123798539 : ℝ) / 50000000000000000) ((970661748647140191 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((96116878123798539 : ℝ) / 50000000000000000) ((970661748647140191 : ℝ) / 500000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-165842488893111001 : ℝ) / 250000000000000000) ((-653541925967585881 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((1956011502714073029 : ℝ) / 500000000000000000) ((2099852538939963527 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-33914419963889879 : ℝ) / 200000000000000000) ((-155616147764714817 : ℝ) / 1000000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((166085580036110121 : ℝ) / 200000000000000000) ((844383852235285183 : ℝ) / 1000000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((166085580036110121 : ℝ) / 200000000000000000) ((844383852235285183 : ℝ) / 1000000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((490196078431372549 : ℝ) / 250000000000000000) ((246305418719211823 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((1956011502714073029 : ℝ) / 500000000000000000) ((2099852538939963527 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((466886192569341793 : ℝ) / 1000000000000000000) ((503689100759273803 : ℝ) / 1000000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((1956011502714073029 : ℝ) / 500000000000000000) ((2099852538939963527 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((15303923994999064481 : ℝ) / 1000000000000000000) ((8818761370585222081 : ℝ) / 500000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((229558859924985951 : ℝ) / 1000000000000000000) ((88187613705852221 : ℝ) / 250000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((23158791045881033 : ℝ) / 12500000000000000) ((722439939574992427 : ℝ) / 250000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-484574713146125583 : ℝ) / 200000000000000000) ((-1349014182911208837 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-484574713146125583 : ℝ) / 200000000000000000) ((-1349014182911208837 : ℝ) / 1000000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-970661748647140191 : ℝ) / 500000000000000000) ((-96116878123798539 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((1956011502714073029 : ℝ) / 500000000000000000) ((2099852538939963527 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-496245419467264831 : ℝ) / 1000000000000000000) ((-228865780671245977 : ℝ) / 500000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-246305418719211823 : ℝ) / 62500000000000000) ((-490196078431372549 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((1956011502714073029 : ℝ) / 500000000000000000) ((2099852538939963527 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((15303923994999064481 : ℝ) / 1000000000000000000) ((8818761370585222081 : ℝ) / 500000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((229558859924985951 : ℝ) / 1000000000000000000) ((88187613705852221 : ℝ) / 250000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-8583608362568039423 : ℝ) / 500000000000000000) ((-2779279639351680471 : ℝ) / 250000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((10620873137939457053 : ℝ) / 1000000000000000000) ((4177371290948396723 : ℝ) / 250000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-1099852538939963527 : ℝ) / 500000000000000000) ((-956011502714073029 : ℝ) / 500000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-45600570618302709 : ℝ) / 31250000000000000) ((-156198399682730311 : ℝ) / 125000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((1956011502714073029 : ℝ) / 500000000000000000) ((2099852538939963527 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((15303923994999064481 : ℝ) / 1000000000000000000) ((8818761370585222081 : ℝ) / 500000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((1721691449437387 : ℝ) / 500000000000000000) ((3527504548234089 : ℝ) / 500000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-7407239381731621 : ℝ) / 250000000000000000) ((-538823724675839 : ℝ) / 40000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((156198399682730311 : ℝ) / 125000000000000000) ((45600570618302709 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((538823724675839 : ℝ) / 40000000000000000) ((7407239381731621 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((21087262289370640643 : ℝ) / 500000000000000000) ((27081551775834758919 : ℝ) / 250000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((52795397716680738339 : ℝ) / 1000000000000000000) ((15629461533391577821 : ℝ) / 125000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((52795397716680738339 : ℝ) / 1000000000000000000) ((15629461533391577821 : ℝ) / 125000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((1030224999999999997 : ℝ) / 1000000000000000000) ((2601 : ℝ) / 2500) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((96116878123798539 : ℝ) / 50000000000000000) ((970661748647140191 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((96116878123798539 : ℝ) / 50000000000000000) ((970661748647140191 : ℝ) / 500000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((1030224999999999997 : ℝ) / 1000000000000000000) ((2601 : ℝ) / 2500) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((209135674999999999 : ℝ) / 200000000000000000) ((132651 : ℝ) / 125000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-3825267974964099281 : ℝ) / 1000000000000000000) ((-1884644669094089 : ℝ) / 500000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-3825267974964099281 : ℝ) / 1000000000000000000) ((-1884644669094089 : ℝ) / 500000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((1030224999999999997 : ℝ) / 1000000000000000000) ((2601 : ℝ) / 2500) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((1061363550624999993 : ℝ) / 1000000000000000000) ((6765201 : ℝ) / 6250000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((1108614511231817059 : ℝ) / 100000000000000000) ((226124215268813751 : ℝ) / 20000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((1108614511231817059 : ℝ) / 100000000000000000) ((226124215268813751 : ℝ) / 20000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_1_point_plus_branch {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((473675504861127 : ℝ) / 1000000000000000) ((47367550486113 : ℝ) / 100000000000000)) :
    RB (phi q (v)) ((474322044521415711 : ℝ) / 1000000000000000000) ((237161022260709359 : ℝ) / 500000000000000000) ∧
    RB (psi1 q (v)) ((-1602914444476016451 : ℝ) / 1000000000000000000) ((-400728611118988223 : ℝ) / 250000000000000000) ∧
    RB (psi2 q (v)) ((-1493740608233957299 : ℝ) / 125000000000000000) ((-11949924865868551879 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((473369254861127 : ℝ) / 1000000000000000) ((473369254861130001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((52632449513887 : ℝ) / 100000000000000) ((526324495138873 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-3739397646914029 : ℝ) / 5000000000000000) ((-747879529382799459 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_56.1 dlower_m_log_57.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-641837345545338703 : ℝ) / 1000000000000000000) ((-641837345545333001 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_58.1 dlower_m_log_59.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-106042183837472799 : ℝ) / 1000000000000000000) ((-26510545959365189 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-88782876734902249 : ℝ) / 1000000000000000000) ((-17756575346978433 : ℝ) / 200000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-74723278062561977 : ℝ) / 100000000000000000) ((-149446556125122687 : ℝ) / 200000000000000000) := rb_log hv (by norm_num) dlower_m_log_60.1 dlower_m_log_61.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((329224951945355593 : ℝ) / 500000000000000000) ((131689980778145521 : ℝ) / 200000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-2031 : ℝ) / 250000000000000000) ((83 : ℝ) / 10000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-2031 : ℝ) / 250000000000000000) ((83 : ℝ) / 10000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((192262745381334627 : ℝ) / 1000000000000000000) ((192262745381356487 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-73938050772367967 : ℝ) / 1000000000000000000) ((-73938050772367493 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-61903976419451803 : ℝ) / 1000000000000000000) ((-12380795283890281 : ℝ) / 200000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((16294846120235353 : ℝ) / 125000000000000000) ((65179384480952541 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((83838429382553937 : ℝ) / 40000000000000000) ((1047980367281935343 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((83838429382553937 : ℝ) / 40000000000000000) ((1047980367281935343 : ℝ) / 500000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((2112515736353357081 : ℝ) / 1000000000000000000) ((1056257868176685237 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((949984286534246961 : ℝ) / 500000000000000000) ((1899968573068504753 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((4012484309421851003 : ℝ) / 1000000000000000000) ((4012484309421875227 : ℝ) / 1000000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((3359416856127050233 : ℝ) / 1000000000000000000) ((419927107015883817 : ℝ) / 125000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((2111149911146820623 : ℝ) / 1000000000000000000) ((422229982229366799 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((624133472490108119 : ℝ) / 500000000000000000) ((1248266944980249913 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((624133472490108119 : ℝ) / 500000000000000000) ((1248266944980249913 : ℝ) / 1000000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((27701747418318639 : ℝ) / 100000000000000000) ((277017474183189549 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((90247014466198223 : ℝ) / 25000000000000000) ((3609880578647970087 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((224078451447778607 : ℝ) / 1000000000000000000) ((4481569028955629 : ℝ) / 20000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((2231361368170283233 : ℝ) / 500000000000000000) ((4462722736340623087 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-852842157692694167 : ℝ) / 1000000000000000000) ((-852842157692596379 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-357017261530602597 : ℝ) / 500000000000000000) ((-714034523061123317 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((56092120976360887 : ℝ) / 250000000000000000) ((224368483905446391 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((22284769736676143 : ℝ) / 5000000000000000) ((1114238486833821269 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((1871459712137011703 : ℝ) / 500000000000000000) ((3742919424274161759 : ℝ) / 1000000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((1871459712137011703 : ℝ) / 500000000000000000) ((3742919424274161759 : ℝ) / 1000000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((2112515736353357081 : ℝ) / 1000000000000000000) ((1056257868176685237 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((949984286534246961 : ℝ) / 500000000000000000) ((1899968573068504753 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((4012484309421851003 : ℝ) / 1000000000000000000) ((4012484309421875227 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-3637473414879133183 : ℝ) / 500000000000000000) ((-3637473414879110767 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((17499999999999999 : ℝ) / 500000000000000000) ((7 : ℝ) / 200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((224078451447778607 : ℝ) / 1000000000000000000) ((4481569028955629 : ℝ) / 20000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((156195295771919817 : ℝ) / 1000000000000000000) ((156195295771921809 : ℝ) / 1000000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((130773124328938239 : ℝ) / 1000000000000000000) ((32693281082234977 : ℝ) / 250000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-7144173705429328127 : ℝ) / 1000000000000000000) ((-3572086852714640813 : ℝ) / 500000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-7144173705429328127 : ℝ) / 1000000000000000000) ((-3572086852714640813 : ℝ) / 500000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-4224289279498086233 : ℝ) / 500000000000000000) ((-8448578558995187921 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-1813077950903302509 : ℝ) / 500000000000000000) ((-906538975451651141 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-73938050772367967 : ℝ) / 1000000000000000000) ((-73938050772367493 : ℝ) / 1000000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((268110899176296761 : ℝ) / 1000000000000000000) ((53622179835259703 : ℝ) / 200000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-1636093531963975141 : ℝ) / 200000000000000000) ((-4090233829909444703 : ℝ) / 500000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-1056257868176685237 : ℝ) / 250000000000000000) ((-2112515736353357081 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((306249999999999 : ℝ) / 250000000000000000) ((49 : ℝ) / 40000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((224078451447778607 : ℝ) / 1000000000000000000) ((4481569028955629 : ℝ) / 20000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((683354419002147 : ℝ) / 125000000000000000) ((341677209501079 : ℝ) / 62500000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-1057624577014689553 : ℝ) / 250000000000000000) ((-2115249154029365669 : ℝ) / 500000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-221371696278940279 : ℝ) / 62500000000000000) ((-1770973570231510971 : ℝ) / 500000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-11722414800282920169 : ℝ) / 1000000000000000000) ((-2930603700070477837 : ℝ) / 250000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-6827105171936037779 : ℝ) / 500000000000000000) ((-1365421034387106673 : ℝ) / 100000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-6827105171936037779 : ℝ) / 500000000000000000) ((-1365421034387106673 : ℝ) / 100000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-1047980367281935343 : ℝ) / 500000000000000000) ((-83838429382553937 : ℝ) / 40000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-209887070128766561 : ℝ) / 125000000000000000) ((-419774140257517339 : ℝ) / 250000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-209887070128766561 : ℝ) / 125000000000000000) ((-419774140257517339 : ℝ) / 250000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((419774140257517339 : ℝ) / 250000000000000000) ((209887070128766561 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((112774610450520217 : ℝ) / 40000000000000000) ((563873052252643487 : ℝ) / 200000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((10552657000504709849 : ℝ) / 1000000000000000000) ((5276328500252946727 : ℝ) / 500000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-7144173705429328127 : ℝ) / 500000000000000000) ((-3572086852714640813 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((11995757500187754509 : ℝ) / 500000000000000000) ((23991515000376567231 : ℝ) / 1000000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((34544172000880218867 : ℝ) / 1000000000000000000) ((6908834400176492137 : ℝ) / 200000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((20889961657008143309 : ℝ) / 1000000000000000000) ((4177992331402278791 : ℝ) / 200000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-4177992331402278791 : ℝ) / 200000000000000000) ((-20889961657008143309 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-16735171704272341049 : ℝ) / 1000000000000000000) ((-334703434085385709 : ℝ) / 20000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-16735171704272341049 : ℝ) / 1000000000000000000) ((-334703434085385709 : ℝ) / 20000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((646539660288711 : ℝ) / 1000000000000000000) ((323269830144359 : ℝ) / 500000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((474322044521415711 : ℝ) / 1000000000000000000) ((237161022260709359 : ℝ) / 500000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((474322044521415711 : ℝ) / 1000000000000000000) ((237161022260709359 : ℝ) / 500000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((56092120976360887 : ℝ) / 250000000000000000) ((224368483905446391 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((1364942146371409 : ℝ) / 1000000000000000000) ((170617768296429 : ℝ) / 125000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((124829382231703571 : ℝ) / 125000000000000000) ((998635057853628591 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-52400146605192349 : ℝ) / 31250000000000000) ((-838402345683046041 : ℝ) / 500000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((17499999999999999 : ℝ) / 500000000000000000) ((7 : ℝ) / 200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((73890246890138717 : ℝ) / 1000000000000000000) ((7389024689013919 : ℝ) / 100000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-1602914444476016451 : ℝ) / 1000000000000000000) ((-400728611118988223 : ℝ) / 250000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-1602914444476016451 : ℝ) / 1000000000000000000) ((-400728611118988223 : ℝ) / 250000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((306249999999999 : ℝ) / 500000000000000000) ((49 : ℝ) / 80000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((56092120976360887 : ℝ) / 250000000000000000) ((224368483905446391 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((5313892744441831 : ℝ) / 50000000000000000) ((106277854888838641 : ℝ) / 1000000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((2881597491032551 : ℝ) / 500000000000000000) ((360199686379077 : ℝ) / 62500000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((419774140257517339 : ℝ) / 250000000000000000) ((209887070128766561 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((112774610450520217 : ℝ) / 40000000000000000) ((563873052252643487 : ℝ) / 200000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((8124275863159809 : ℝ) / 500000000000000000) ((16248551726321207 : ℝ) / 1000000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((17499999999999999 : ℝ) / 250000000000000000) ((7 : ℝ) / 100) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((56092120976360887 : ℝ) / 250000000000000000) ((224368483905446391 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((2437396689948953 : ℝ) / 7812500000000000) ((77996694078367489 : ℝ) / 250000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-523855923194824599 : ℝ) / 1000000000000000000) ((-523855923194798233 : ℝ) / 1000000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((540104474921117851 : ℝ) / 1000000000000000000) ((270052237460572903 : ℝ) / 500000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((4222299822293641247 : ℝ) / 1000000000000000000) ((422229982229366799 : ℝ) / 100000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((2381202148607379549 : ℝ) / 500000000000000000) ((1190601074303703449 : ℝ) / 250000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((56092120976360887 : ℝ) / 250000000000000000) ((224368483905446391 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((1364942146371409 : ℝ) / 1000000000000000000) ((170617768296429 : ℝ) / 125000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((124829382231703571 : ℝ) / 125000000000000000) ((998635057853628591 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-1671232916308641749 : ℝ) / 100000000000000000) ((-668493166523334627 : ℝ) / 40000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-1493740608233957299 : ℝ) / 125000000000000000) ((-11949924865868551879 : ℝ) / 1000000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-1493740608233957299 : ℝ) / 125000000000000000) ((-11949924865868551879 : ℝ) / 1000000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_1_point_plus_lo_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((473675504861127 : ℝ) / 1000000000000000) ((473675504861127 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-1791 : ℝ) / 1000000000000000000) ((-889 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((2095960734563870249 : ℝ) / 1000000000000000000) ((2095960734563870293 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((473369254861127 : ℝ) / 1000000000000000) ((473369254861127001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((526324495138873 : ℝ) / 1000000000000000) ((526324495138873 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-3739397646914029 : ℝ) / 5000000000000000) ((-186969882345701449 : ℝ) / 250000000000000000) := rb_log h2 (by norm_num) dlower_m_log_56.1 dlower_m_log_62.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-641837345545333003 : ℝ) / 1000000000000000000) ((-641837345545333001 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_59.1 dlower_m_log_59.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-106042183837472799 : ℝ) / 1000000000000000000) ((-106042183837472793 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-88782876734902249 : ℝ) / 1000000000000000000) ((-88782876734902243 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-74723278062561977 : ℝ) / 100000000000000000) ((-93404097578202471 : ℝ) / 125000000000000000) := rb_log hv (by norm_num) dlower_m_log_60.1 dlower_m_log_60.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((658449903890717519 : ℝ) / 1000000000000000000) ((658449903890717527 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-1791 : ℝ) / 1000000000000000000) ((-889 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-1791 : ℝ) / 1000000000000000000) ((-889 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((192262745381356451 : ℝ) / 1000000000000000000) ((192262745381356487 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-73938050772367967 : ℝ) / 1000000000000000000) ((-36969025386183981 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-61903976419451803 : ℝ) / 1000000000000000000) ((-30951988209725899 : ℝ) / 500000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((16294846120238081 : ℝ) / 125000000000000000) ((130358768961904689 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2095960734563870249 : ℝ) / 1000000000000000000) ((2095960734563870293 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2095960734563870249 : ℝ) / 1000000000000000000) ((2095960734563870293 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_1_point_plus_hi_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((47367550486113 : ℝ) / 100000000000000) ((47367550486113 : ℝ) / 100000000000000)) :
    RB (E q (v)) ((977 : ℝ) / 500000000000000000) ((1967 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((2095960734563848817 : ℝ) / 1000000000000000000) ((1047980367281924431 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((47336925486113 : ℝ) / 100000000000000) ((473369254861130001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((52632449513887 : ℝ) / 100000000000000) ((52632449513887 : ℝ) / 100000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-747879529382799463 : ℝ) / 1000000000000000000) ((-747879529382799459 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_63.1 dlower_m_log_57.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-641837345545338703 : ℝ) / 1000000000000000000) ((-641837345545338701 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_58.1 dlower_m_log_58.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-53021091918730381 : ℝ) / 500000000000000000) ((-26510545959365189 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-88782876734892171 : ℝ) / 1000000000000000000) ((-17756575346978433 : ℝ) / 200000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-747232780625613437 : ℝ) / 1000000000000000000) ((-149446556125122687 : ℝ) / 200000000000000000) := rb_log hv (by norm_num) dlower_m_log_61.1 dlower_m_log_61.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((41153118993170079 : ℝ) / 62500000000000000) ((82306237986340159 : ℝ) / 125000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((977 : ℝ) / 500000000000000000) ((1967 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((977 : ℝ) / 500000000000000000) ((1967 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((192262745381334627 : ℝ) / 1000000000000000000) ((192262745381334663 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-36969025386183749 : ℝ) / 500000000000000000) ((-73938050772367493 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-61903976419451411 : ℝ) / 1000000000000000000) ((-12380795283890281 : ℝ) / 200000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((8147423060117701 : ℝ) / 62500000000000000) ((65179384480941629 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2095960734563848817 : ℝ) / 1000000000000000000) ((1047980367281924431 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2095960734563848817 : ℝ) / 1000000000000000000) ((1047980367281924431 : ℝ) / 500000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_1_point_minus_branch {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((1425059689010159 : ℝ) / 1000000000000000) ((712529844505081 : ℝ) / 500000000000000)) :
    RB (phi q (v)) ((1425274592289201801 : ℝ) / 1000000000000000000) ((1425274592289204803 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((-5900057302056181 : ℝ) / 62500000000000000) ((-47200458416444879 : ℝ) / 500000000000000000) ∧
    RB (psi2 q (v)) ((45886017702637188809 : ℝ) / 1000000000000000000) ((45886017702638071433 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424753439010159 : ℝ) / 1000000000000000) ((1424753439010162001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-212529844505081 : ℝ) / 500000000000000) ((-425059689010159 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((176999386746994289 : ℝ) / 500000000000000000) ((176999386746995343 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_64.1 dlower_m_log_65.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425059689010159 : ℝ) / 1000000000000000) ((212529844505081 : ℝ) / 500000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-85552567518937209 : ℝ) / 100000000000000000) ((-85552567518936503 : ℝ) / 100000000000000000) := rb_log h5 (by norm_num) dlower_m_log_66.1 dlower_m_log_67.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((151190556085419201 : ℝ) / 125000000000000000) ((151190556085420347 : ℝ) / 125000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((1012663603758766081 : ℝ) / 1000000000000000000) ((253165900939693441 : ℝ) / 250000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354213699868049909 : ℝ) / 1000000000000000000) ((22138356241753251 : ℝ) / 62500000000000000) := rb_log hv (by norm_num) dlower_m_log_68.1 dlower_m_log_69.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((131689980778142813 : ℝ) / 200000000000000000) ((131689980778144771 : ℝ) / 200000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-1049 : ℝ) / 200000000000000000) ((91 : ℝ) / 20000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-1049 : ℝ) / 200000000000000000) ((91 : ℝ) / 20000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-2192962108986278051 : ℝ) / 1000000000000000000) ((-2192962108986261153 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-4913130797468521 : ℝ) / 200000000000000000) ((-491313079746851 : ℝ) / 20000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-20567375651309261 : ℝ) / 1000000000000000000) ((-10283687825654607 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-138345592789849207 : ℝ) / 62500000000000000) ((-2213529484637570367 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-247927519035621711 : ℝ) / 1000000000000000000) ((-247927519035604763 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-247927519035621711 : ℝ) / 1000000000000000000) ((-247927519035604763 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((701875828209787207 : ℝ) / 1000000000000000000) ((350937914104894343 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((425059689010159 : ℝ) / 1000000000000000) ((212529844505081 : ℝ) / 500000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-2352610764687450349 : ℝ) / 1000000000000000000) ((-2352610764687433743 : ℝ) / 1000000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-825367468238831571 : ℝ) / 500000000000000000) ((-1650734936477645057 : ℝ) / 1000000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-1382063166597133823 : ℝ) / 1000000000000000000) ((-86378947912319917 : ℝ) / 62500000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((701724992792824041 : ℝ) / 1000000000000000000) ((8771562409910319 : ℝ) / 12500000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-2083788159389959343 : ℝ) / 1000000000000000000) ((-2083788159389942713 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-2083788159389959343 : ℝ) / 1000000000000000000) ((-2083788159389942713 : ℝ) / 1000000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((425059689010159 : ℝ) / 1000000000000000) ((212529844505081 : ℝ) / 500000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((180675739221413083 : ℝ) / 1000000000000000000) ((36135147844283127 : ℝ) / 200000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((138369435253079793 : ℝ) / 25000000000000000) ((2767388705061634949 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((2029922361971274861 : ℝ) / 1000000000000000000) ((2029922361971283413 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((492629678225174723 : ℝ) / 1000000000000000000) ((615787097781471 : ℝ) / 1250000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((126053693297450373 : ℝ) / 25000000000000000) ((201685909275923807 : ℝ) / 40000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((2110746706453989651 : ℝ) / 500000000000000000) ((4221493412908046521 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((2030795117241731083 : ℝ) / 1000000000000000000) ((406159023448347927 : ℝ) / 200000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((492417965510088953 : ℝ) / 1000000000000000000) ((123104491377522757 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((942782275683613651 : ℝ) / 200000000000000000) ((4713911378418137549 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((942782275683613651 : ℝ) / 200000000000000000) ((4713911378418137549 : ℝ) / 1000000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((701875828209787207 : ℝ) / 1000000000000000000) ((350937914104894343 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((425059689010159 : ℝ) / 1000000000000000) ((212529844505081 : ℝ) / 500000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-2352610764687450349 : ℝ) / 1000000000000000000) ((-2352610764687433743 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-825367468238831571 : ℝ) / 500000000000000000) ((-1650734936477645057 : ℝ) / 1000000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((598582223222676311 : ℝ) / 200000000000000000) ((2992911116113414721 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((17499999999999999 : ℝ) / 500000000000000000) ((7 : ℝ) / 200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((2029922361971274861 : ℝ) / 1000000000000000000) ((2029922361971283413 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((8621019368940557 : ℝ) / 500000000000000000) ((4310509684470297 : ℝ) / 250000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((7217871909682233 : ℝ) / 500000000000000000) ((14435743819364529 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((3007346859932746021 : ℝ) / 1000000000000000000) ((12029387439731117 : ℝ) / 4000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((3007346859932746021 : ℝ) / 1000000000000000000) ((12029387439731117 : ℝ) / 4000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((4818253431761534707 : ℝ) / 50000000000000000) ((48182534317615855177 : ℝ) / 500000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-1813077950903302509 : ℝ) / 500000000000000000) ((-906538975451651141 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-4913130797468521 : ℝ) / 200000000000000000) ((-491313079746851 : ℝ) / 20000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((17815778237588227 : ℝ) / 200000000000000000) ((89078891187941347 : ℝ) / 1000000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((3858165901056745411 : ℝ) / 40000000000000000) ((96454147526419651701 : ℝ) / 1000000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-350937914104894343 : ℝ) / 250000000000000000) ((-701875828209787207 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((306249999999999 : ℝ) / 250000000000000000) ((49 : ℝ) / 40000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((2029922361971274861 : ℝ) / 1000000000000000000) ((2029922361971283413 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((603471355825837 : ℝ) / 1000000000000000000) ((301735677912921 : ℝ) / 500000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-702177563887701607 : ℝ) / 500000000000000000) ((-1404355127775400251 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-29394596491998029 : ℝ) / 25000000000000000) ((-1175783859679918671 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((19055672733347742823 : ℝ) / 200000000000000000) ((9527836366673973303 : ℝ) / 100000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((46673284061574779363 : ℝ) / 500000000000000000) ((5834160507696911103 : ℝ) / 62500000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((46673284061574779363 : ℝ) / 500000000000000000) ((5834160507696911103 : ℝ) / 62500000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((247927519035604763 : ℝ) / 1000000000000000000) ((247927519035621711 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((-247927519035621711 : ℝ) / 1000000000000000000) ((-247927519035604763 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((2083788159389942713 : ℝ) / 1000000000000000000) ((2083788159389959343 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((-59489617003152053 : ℝ) / 500000000000000000) ((-59489617003147511 : ℝ) / 500000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((-59489617003152053 : ℝ) / 500000000000000000) ((-59489617003147511 : ℝ) / 500000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h66 : RB z66 ((59489617003147511 : ℝ) / 500000000000000000) ((59489617003152053 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_65) (by norm_num) (by norm_num)
  let z67 : ℝ := (z66) ^ 2
  have h67 : RB z67 ((14156058124724709 : ℝ) / 1000000000000000000) ((1769507265590859 : ℝ) / 125000000000000000) := rb_widen (rb_sq h66 (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (Evv q (v)) * (z67)
  have h68 : RB z68 ((66730403467687347 : ℝ) / 1000000000000000000) ((2669216138707941 : ℝ) / 40000000000000000) := rb_mul_four bound_Evv_35 h67 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h69 : RB z69 ((3007346859932746021 : ℝ) / 500000000000000000) ((12029387439731117 : ℝ) / 2000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z69) * (rootSlope q (v))
  have h70 : RB z70 ((-715623651572132001 : ℝ) / 1000000000000000000) ((-143124730314413891 : ℝ) / 200000000000000000) := rb_mul_four h69 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z71 : ℝ := (z68) + (z70)
  have h71 : RB z71 ((-324446624052222327 : ℝ) / 500000000000000000) ((-64889324810437093 : ℝ) / 100000000000000000) := rb_widen (rb_add h68 h70) (by norm_num) (by norm_num)
  let z72 : ℝ := (z71) + (Eqq q (v))
  have h72 : RB z72 ((11587209359380639259 : ℝ) / 125000000000000000) ((46348837437523103359 : ℝ) / 500000000000000000) := rb_widen (rb_add h71 bound_Eqq_61) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((-46348837437523103359 : ℝ) / 500000000000000000) ((-11587209359380639259 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (z73)
  have h74 : RB z74 ((11587209359380639259 : ℝ) / 125000000000000000) ((46348837437523103359 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h73) (by norm_num) (by norm_num)
  let z75 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h75 : RB z75 ((2083788159389942713 : ℝ) / 1000000000000000000) ((2083788159389959343 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z76 : ℝ := (z74) / (z75)
  have h76 : RB z76 ((8897034418525813841 : ℝ) / 200000000000000000) ((22242586046314974291 : ℝ) / 500000000000000000) := rb_div_signed h74 h75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_76 : RB (rootCurvature q (v)) ((8897034418525813841 : ℝ) / 200000000000000000) ((22242586046314974291 : ℝ) / 500000000000000000) := by
    have hh := h76
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z77 : ℝ := (q) ^ 2
  have h77 : RB z77 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z78 : ℝ := (z77) / (v)
  have h78 : RB z78 ((214903279042801 : ℝ) / 1000000000000000000) ((214903279042803 : ℝ) / 1000000000000000000) := rb_div_signed h77 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z79 : ℝ := (v) + (z78)
  have h79 : RB z79 ((1425274592289201801 : ℝ) / 1000000000000000000) ((1425274592289204803 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h78) (by norm_num) (by norm_num)
  have bound_p_79 : RB (phi q (v)) ((1425274592289201801 : ℝ) / 1000000000000000000) ((1425274592289204803 : ℝ) / 1000000000000000000) := by
    have hh := h79
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z80 : ℝ := (q) ^ 2
  have h80 : RB z80 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (v) ^ 2
  have h81 : RB z81 ((2030795117241731083 : ℝ) / 1000000000000000000) ((406159023448347927 : ℝ) / 200000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z82 : ℝ := (z80) / (z81)
  have h82 : RB z82 ((18850375242183 : ℝ) / 125000000000000000) ((75401500968733 : ℝ) / 500000000000000000) := rb_div_signed h80 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((1 : ℝ)) - (z82)
  have h83 : RB z83 ((499924598499031267 : ℝ) / 500000000000000000) ((124981149624757817 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h82) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) * (rootSlope q (v))
  have h84 : RB z84 ((-14870161447580967 : ℝ) / 125000000000000000) ((-29740322895159663 : ℝ) / 250000000000000000) := rb_mul_four h83 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := ((2 : ℝ)) * (q)
  have h85 : RB z85 ((17499999999999999 : ℝ) / 500000000000000000) ((7 : ℝ) / 200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z85) / (v)
  have h86 : RB z86 ((614009368693721 : ℝ) / 25000000000000000) ((12280187373874447 : ℝ) / 500000000000000000) := rb_div_signed h85 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (z84) + (z86)
  have h87 : RB z87 ((-5900057302056181 : ℝ) / 62500000000000000) ((-47200458416444879 : ℝ) / 500000000000000000) := rb_widen (rb_add h84 h86) (by norm_num) (by norm_num)
  have bound_p1_87 : RB (psi1 q (v)) ((-5900057302056181 : ℝ) / 62500000000000000) ((-47200458416444879 : ℝ) / 500000000000000000) := by
    have hh := h87
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z88 : ℝ := (q) ^ 2
  have h88 : RB z88 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z89 : ℝ := ((2 : ℝ)) * (z88)
  have h89 : RB z89 ((306249999999999 : ℝ) / 500000000000000000) ((49 : ℝ) / 80000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h88 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (v) ^ 2
  have h90 : RB z90 ((2030795117241731083 : ℝ) / 1000000000000000000) ((406159023448347927 : ℝ) / 200000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z91 : ℝ := (z90) * (v)
  have h91 : RB z91 ((1447002129109925341 : ℝ) / 500000000000000000) ((2894004258219868963 : ℝ) / 1000000000000000000) := rb_mul_four h90 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z89) / (z91)
  have h92 : RB z92 ((105822235447703 : ℝ) / 500000000000000000) ((211644470895409 : ℝ) / 1000000000000000000) := rb_div_signed h89 h91 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z93 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h93 : RB z93 ((59489617003147511 : ℝ) / 500000000000000000) ((59489617003152053 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_65) (by norm_num) (by norm_num)
  let z94 : ℝ := (z93) ^ 2
  have h94 : RB z94 ((14156058124724709 : ℝ) / 1000000000000000000) ((1769507265590859 : ℝ) / 125000000000000000) := rb_widen (rb_sq h93 (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z92) * (z94)
  have h95 : RB z95 ((2996051431771 : ℝ) / 1000000000000000000) ((2996051431773 : ℝ) / 1000000000000000000) := rb_mul_four h92 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((4 : ℝ)) * (q)
  have h96 : RB z96 ((17499999999999999 : ℝ) / 250000000000000000) ((7 : ℝ) / 100) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (v) ^ 2
  have h97 : RB z97 ((2030795117241731083 : ℝ) / 1000000000000000000) ((406159023448347927 : ℝ) / 200000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z98 : ℝ := (z96) / (z97)
  have h98 : RB z98 ((2154328599106639 : ℝ) / 62500000000000000) ((8617314396426593 : ℝ) / 250000000000000000) := rb_div_signed h96 h97 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z99 : ℝ := (z98) * (rootSlope q (v))
  have h99 : RB z99 ((-1025281466078333 : ℝ) / 250000000000000000) ((-4101125864313 : ℝ) / 1000000000000000) := rb_mul_four h98 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z95) - (z99)
  have h100 : RB z100 ((4104121915744771 : ℝ) / 1000000000000000000) ((820824383149021 : ℝ) / 200000000000000000) := rb_widen (rb_sub h95 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := ((2 : ℝ)) / (v)
  have h101 : RB z101 ((1403449985585648083 : ℝ) / 1000000000000000000) ((1403449985585651039 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z102 : ℝ := (z100) + (z101)
  have h102 : RB z102 ((703777053750696427 : ℝ) / 500000000000000000) ((87972131718837259 : ℝ) / 62500000000000000) := rb_widen (rb_add h100 h101) (by norm_num) (by norm_num)
  let z103 : ℝ := (q) ^ 2
  have h103 : RB z103 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z104 : ℝ := (v) ^ 2
  have h104 : RB z104 ((2030795117241731083 : ℝ) / 1000000000000000000) ((406159023448347927 : ℝ) / 200000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z105 : ℝ := (z103) / (z104)
  have h105 : RB z105 ((18850375242183 : ℝ) / 125000000000000000) ((75401500968733 : ℝ) / 500000000000000000) := rb_div_signed h103 h104 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := ((1 : ℝ)) - (z105)
  have h106 : RB z106 ((499924598499031267 : ℝ) / 500000000000000000) ((124981149624757817 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h105) (by norm_num) (by norm_num)
  let z107 : ℝ := (z106) * (rootCurvature q (v))
  have h107 : RB z107 ((8895692719027159191 : ℝ) / 200000000000000000) ((44478463595136675289 : ℝ) / 1000000000000000000) := rb_mul_four h106 bound_r2_76 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z108 : ℝ := (z102) + (z107)
  have h108 : RB z108 ((45886017702637188809 : ℝ) / 1000000000000000000) ((45886017702638071433 : ℝ) / 1000000000000000000) := rb_widen (rb_add h102 h107) (by norm_num) (by norm_num)
  have bound_p2_108 : RB (psi2 q (v)) ((45886017702637188809 : ℝ) / 1000000000000000000) ((45886017702638071433 : ℝ) / 1000000000000000000) := by
    have hh := h108
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, z107, z108, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_79, bound_p1_87, bound_p2_108⟩

theorem dlower_m_1_point_minus_lo_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((1425059689010159 : ℝ) / 1000000000000000) ((1425059689010159 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((277 : ℝ) / 100000000000000000) ((697 : ℝ) / 250000000000000000) ∧
    RB (Eq q (v)) ((-123963759517808947 : ℝ) / 500000000000000000) ((-247927519035617603 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424753439010159 : ℝ) / 1000000000000000) ((1424753439010159001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425059689010159 : ℝ) / 1000000000000000) ((-425059689010159 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((176999386746994289 : ℝ) / 500000000000000000) ((353998773493988581 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_64.1 dlower_m_log_70.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425059689010159 : ℝ) / 1000000000000000) ((425059689010159 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-85552567518937209 : ℝ) / 100000000000000000) ((-106940709398671511 : ℝ) / 125000000000000000) := rb_log h5 (by norm_num) dlower_m_log_66.1 dlower_m_log_66.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604762224341680333 : ℝ) / 500000000000000000) ((1209524448683360671 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((1012663603758771991 : ℝ) / 1000000000000000000) ((506331801879386001 : ℝ) / 500000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354213699868049909 : ℝ) / 1000000000000000000) ((354213699868049911 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_68.1 dlower_m_log_68.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((4115311899317013 : ℝ) / 6250000000000000) ((658449903890722093 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((277 : ℝ) / 100000000000000000) ((697 : ℝ) / 250000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((277 : ℝ) / 100000000000000000) ((697 : ℝ) / 250000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1096481054493137117 : ℝ) / 500000000000000000) ((-43859242179725479 : ℝ) / 20000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-4913130797468521 : ℝ) / 200000000000000000) ((-12282826993671301 : ℝ) / 500000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-20567375651309261 : ℝ) / 1000000000000000000) ((-20567375651309257 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-442705896927516699 : ℝ) / 200000000000000000) ((-2213529484637583207 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-123963759517808947 : ℝ) / 500000000000000000) ((-247927519035617603 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-123963759517808947 : ℝ) / 500000000000000000) ((-247927519035617603 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_1_point_minus_hi_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((712529844505081 : ℝ) / 500000000000000) ((712529844505081 : ℝ) / 500000000000000)) :
    RB (E q (v)) ((-1741 : ℝ) / 500000000000000000) ((-433 : ℝ) / 125000000000000000) ∧
    RB (Eq q (v)) ((-24792751903560887 : ℝ) / 100000000000000000) ((-247927519035608581 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712376719505081 : ℝ) / 500000000000000) ((1424753439010162001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-212529844505081 : ℝ) / 500000000000000) ((-212529844505081 : ℝ) / 500000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((88499693373497671 : ℝ) / 250000000000000000) ((176999386746995343 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_71.1 dlower_m_log_65.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((212529844505081 : ℝ) / 500000000000000) ((212529844505081 : ℝ) / 500000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-106940709398670629 : ℝ) / 125000000000000000) ((-85552567518936503 : ℝ) / 100000000000000000) := rb_log h5 (by norm_num) dlower_m_log_67.1 dlower_m_log_67.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604762224341677857 : ℝ) / 500000000000000000) ((604762224341677859 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((253165900939691961 : ℝ) / 250000000000000000) ((202532720751753571 : ℝ) / 200000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((177106849934026007 : ℝ) / 500000000000000000) ((22138356241753251 : ℝ) / 62500000000000000) := rb_log hv (by norm_num) dlower_m_log_69.1 dlower_m_log_69.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((164612475972678957 : ℝ) / 250000000000000000) ((658449903890715841 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-1741 : ℝ) / 500000000000000000) ((-433 : ℝ) / 125000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-1741 : ℝ) / 500000000000000000) ((-433 : ℝ) / 125000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1096481054493132627 : ℝ) / 500000000000000000) ((-2192962108986264971 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-24565653987342553 : ℝ) / 1000000000000000000) ((-491313079746851 : ℝ) / 20000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-20567375651309217 : ℝ) / 1000000000000000000) ((-10283687825654607 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-2213529484637574471 : ℝ) / 1000000000000000000) ((-442705896927514837 : ℝ) / 200000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-24792751903560887 : ℝ) / 100000000000000000) ((-247927519035608581 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-24792751903560887 : ℝ) / 100000000000000000) ((-247927519035608581 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_1_slab_plus_branch {q v : ℝ} (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50))
    (hv : RB v ((468428328107909361 : ℝ) / 1000000000000000000) ((478922681614347497 : ℝ) / 1000000000000000000)) :
    RB (phi q (v)) ((468898132543234017 : ℝ) / 1000000000000000000) ((95955320187122839 : ℝ) / 200000000000000000) ∧
    RB (psi1 q (v)) ((-925791331748918899 : ℝ) / 500000000000000000) ((-1410531559141914213 : ℝ) / 1000000000000000000) ∧
    RB (psi2 q (v)) ((-31901856179244455499 : ℝ) / 1000000000000000000) ((1702228220057735067 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((468028328107909361 : ℝ) / 1000000000000000000) ((239348840807173749 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((521077318385652503 : ℝ) / 1000000000000000000) ((531571671892090639 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-379613227375630077 : ℝ) / 500000000000000000) ((-736686025682204293 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_72.1 dlower_m_log_73.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-651856844428293173 : ℝ) / 1000000000000000000) ((-315958620976259851 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_74.1 dlower_m_log_75.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-31827303199685113 : ℝ) / 250000000000000000) ((-1060364765673889 : ℝ) / 12500000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-13437230441005267 : ℝ) / 125000000000000000) ((-35222259431360369 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-94796521329150463 : ℝ) / 125000000000000000) ((-736216110854199243 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_76.1 dlower_m_log_77.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((628718267326157107 : ℝ) / 1000000000000000000) ((343963825885241483 : ℝ) / 500000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-34651688246286897 : ℝ) / 1000000000000000000) ((6877145160579417 : ℝ) / 200000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-34651688246286897 : ℝ) / 1000000000000000000) ((6877145160579417 : ℝ) / 200000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((114435768636271743 : ℝ) / 1000000000000000000) ((77113531591010893 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-1709298245330891 : ℝ) / 20000000000000000) ((-15667508509143383 : ℝ) / 250000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-36082595925287783 : ℝ) / 500000000000000000) ((-52042944769235393 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((42270576785696177 : ℝ) / 1000000000000000000) ((256411181594808179 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2003054890511186373 : ℝ) / 1000000000000000000) ((2226854531348502763 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2003054890511186373 : ℝ) / 1000000000000000000) ((2226854531348502763 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((522250283638112809 : ℝ) / 250000000000000000) ((2136622806663613743 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((235151733265001889 : ℝ) / 125000000000000000) ((959550497321679523 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((992553750168116587 : ℝ) / 250000000000000000) ((4055723801306972789 : ℝ) / 1000000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((3296977306273759537 : ℝ) / 1000000000000000000) ((684917537389983207 : ℝ) / 200000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((1044009856277020127 : ℝ) / 500000000000000000) ((2134798303166744603 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((581089501553507467 : ℝ) / 500000000000000000) ((1336567974395875781 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((581089501553507467 : ℝ) / 500000000000000000) ((1336567974395875781 : ℝ) / 1000000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((67880392933995667 : ℝ) / 250000000000000000) ((141284221179076233 : ℝ) / 500000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((3538965610082214133 : ℝ) / 1000000000000000000) ((736589725528226001 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((219050515911484859 : ℝ) / 1000000000000000000) ((229151470382951207 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((4363925740161428467 : ℝ) / 1000000000000000000) ((2282578508977549081 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-1026191407872884029 : ℝ) / 1000000000000000000) ((-340488556260149231 : ℝ) / 500000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-3384763492618971 : ℝ) / 3906250000000000) ((-141375598405311497 : ℝ) / 250000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((219425098573971187 : ℝ) / 1000000000000000000) ((229366934964677663 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((4359826320014256869 : ℝ) / 1000000000000000000) ((1139340948800903 : ℝ) / 250000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((3493326865903800293 : ℝ) / 1000000000000000000) ((997965350395591503 : ℝ) / 250000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((3493326865903800293 : ℝ) / 1000000000000000000) ((997965350395591503 : ℝ) / 250000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((522250283638112809 : ℝ) / 250000000000000000) ((2136622806663613743 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((235151733265001889 : ℝ) / 125000000000000000) ((959550497321679523 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((992553750168116587 : ℝ) / 250000000000000000) ((4055723801306972789 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-4913252994045600923 : ℝ) / 500000000000000000) ((-5355876345113991633 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((14999999999999999 : ℝ) / 500000000000000000) ((1 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((219050515911484859 : ℝ) / 1000000000000000000) ((229151470382951207 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((26183554440968569 : ℝ) / 200000000000000000) ((182606280718203927 : ℝ) / 1000000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((1698715166693489 : ℝ) / 15625000000000000) ((154189794755194911 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-194355764348456371 : ℝ) / 20000000000000000) ((-2600843275179398361 : ℝ) / 500000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-194355764348456371 : ℝ) / 20000000000000000) ((-2600843275179398361 : ℝ) / 500000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-15918195554274213037 : ℝ) / 1000000000000000000) ((-1119647590570158909 : ℝ) / 250000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-484574713146125583 : ℝ) / 100000000000000000) ((-1349014182911208837 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-1709298245330891 : ℝ) / 20000000000000000) ((-15667508509143383 : ℝ) / 250000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((8454276475886589 : ℝ) / 50000000000000000) ((8282827069123923 : ℝ) / 20000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-15749110024756481257 : ℝ) / 1000000000000000000) ((-2032224504412219743 : ℝ) / 500000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-854649122665445497 : ℝ) / 200000000000000000) ((-522250283638112809 : ℝ) / 125000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((224999999999999 : ℝ) / 250000000000000000) ((1 : ℝ) / 625) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((219050515911484859 : ℝ) / 1000000000000000000) ((229151470382951207 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((981883291536317 : ℝ) / 250000000000000000) ((3652125614364079 : ℝ) / 500000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-4280549864555955643 : ℝ) / 1000000000000000000) ((-209096490113552387 : ℝ) / 50000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-1807213592159493027 : ℝ) / 500000000000000000) ((-3472791184402411361 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-19363537209075467311 : ℝ) / 1000000000000000000) ((-7537240193226850847 : ℝ) / 1000000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-21304860706369747693 : ℝ) / 1000000000000000000) ((-9459577755702821627 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-21304860706369747693 : ℝ) / 1000000000000000000) ((-9459577755702821627 : ℝ) / 1000000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-2226854531348502763 : ℝ) / 1000000000000000000) ((-2003054890511186373 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-958051438459627351 : ℝ) / 500000000000000000) ((-374663864629960259 : ℝ) / 250000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-958051438459627351 : ℝ) / 500000000000000000) ((-374663864629960259 : ℝ) / 250000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((374663864629960259 : ℝ) / 250000000000000000) ((958051438459627351 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((70186505729728593 : ℝ) / 31250000000000000) ((1835725117469122267 : ℝ) / 500000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((98073762435828763 : ℝ) / 12500000000000000) ((7327960240340243903 : ℝ) / 500000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-194355764348456371 : ℝ) / 10000000000000000) ((-2600843275179398361 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((7795535942204452691 : ℝ) / 500000000000000000) ((4655070490173974611 : ℝ) / 125000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((11718486439637603211 : ℝ) / 500000000000000000) ((25948242201036142347 : ℝ) / 500000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((2132112172905458729 : ℝ) / 1000000000000000000) ((42436906646369463067 : ℝ) / 1000000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-42436906646369463067 : ℝ) / 1000000000000000000) ((-2132112172905458729 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-18257474336103548691 : ℝ) / 500000000000000000) ((-797607085366969923 : ℝ) / 500000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-18257474336103548691 : ℝ) / 500000000000000000) ((-797607085366969923 : ℝ) / 500000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((29362777207791 : ℝ) / 62500000000000000) ((426959660633349 : ℝ) / 500000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((468898132543234017 : ℝ) / 1000000000000000000) ((95955320187122839 : ℝ) / 200000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((468898132543234017 : ℝ) / 1000000000000000000) ((95955320187122839 : ℝ) / 200000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((219425098573971187 : ℝ) / 1000000000000000000) ((229366934964677663 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((980960922003203 : ℝ) / 1000000000000000000) ((364589103616289 : ℝ) / 200000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((199635410896383711 : ℝ) / 200000000000000000) ((999019039077996797 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-1914223254874459001 : ℝ) / 1000000000000000000) ((-747961745634291999 : ℝ) / 500000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((14999999999999999 : ℝ) / 500000000000000000) ((1 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((62640591376621203 : ℝ) / 1000000000000000000) ((17078386425333957 : ℝ) / 200000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-925791331748918899 : ℝ) / 500000000000000000) ((-1410531559141914213 : ℝ) / 1000000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-925791331748918899 : ℝ) / 500000000000000000) ((-1410531559141914213 : ℝ) / 1000000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((224999999999999 : ℝ) / 500000000000000000) ((1 : ℝ) / 1250) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((219425098573971187 : ℝ) / 1000000000000000000) ((229366934964677663 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((102784932069918529 : ℝ) / 1000000000000000000) ((10984902756694707 : ℝ) / 100000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((16386125939103 : ℝ) / 4000000000000000) ((3891620998765691 : ℝ) / 500000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((374663864629960259 : ℝ) / 250000000000000000) ((958051438459627351 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((70186505729728593 : ℝ) / 31250000000000000) ((1835725117469122267 : ℝ) / 500000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((1150084922112907 : ℝ) / 125000000000000000) ((5715157132083561 : ℝ) / 200000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((14999999999999999 : ℝ) / 250000000000000000) ((2 : ℝ) / 25) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((219425098573971187 : ℝ) / 1000000000000000000) ((229366934964677663 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((130794789600427697 : ℝ) / 500000000000000000) ((1139340948800903 : ℝ) / 3125000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-27943609213303341 : ℝ) / 40000000000000000) ((-98008162690317553 : ℝ) / 250000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((100308332534543367 : ℝ) / 250000000000000000) ((72716601599300133 : ℝ) / 100000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((1044009856277020127 : ℝ) / 250000000000000000) ((853919321266697841 : ℝ) / 200000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((572159094405781747 : ℝ) / 125000000000000000) ((999352524465298107 : ℝ) / 200000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((219425098573971187 : ℝ) / 1000000000000000000) ((229366934964677663 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((980960922003203 : ℝ) / 1000000000000000000) ((364589103616289 : ℝ) / 200000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((199635410896383711 : ℝ) / 200000000000000000) ((999019039077996797 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-1459165157379628379 : ℝ) / 40000000000000000) ((-1592306182211020401 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-31901856179244455499 : ℝ) / 1000000000000000000) ((1702228220057735067 : ℝ) / 500000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-31901856179244455499 : ℝ) / 1000000000000000000) ((1702228220057735067 : ℝ) / 500000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_1_slab_plus_lo_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((468428328107909361 : ℝ) / 1000000000000000000) ((468428328107909361 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-6498551508413813 : ℝ) / 1000000000000000000) ((-6498551508413799 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((1066731248154274993 : ℝ) / 500000000000000000) ((426692499261710007 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((468122078107909361 : ℝ) / 1000000000000000000) ((234061039053954681 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((531571671892090639 : ℝ) / 1000000000000000000) ((531571671892090639 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-379513083211090999 : ℝ) / 500000000000000000) ((-379513083211090997 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_78.1 dlower_m_log_79.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-78989655244064963 : ℝ) / 125000000000000000) ((-315958620976259851 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_75.1 dlower_m_log_75.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-15888615558707787 : ℝ) / 125000000000000000) ((-12710892446966229 : ℝ) / 100000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-21284163650179641 : ℝ) / 200000000000000000) ((-53210409125449099 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-94796521329150463 : ℝ) / 125000000000000000) ((-379186085316601851 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_76.1 dlower_m_log_76.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((651951352382305497 : ℝ) / 1000000000000000000) ((325975676191152753 : ℝ) / 500000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-6498551508413813 : ℝ) / 1000000000000000000) ((-6498551508413799 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-6498551508413813 : ℝ) / 1000000000000000000) ((-6498551508413799 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((230458388318977923 : ℝ) / 1000000000000000000) ((57614597079744491 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-74766821811664179 : ℝ) / 1000000000000000000) ((-37383410905832087 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-31298928806196769 : ℝ) / 500000000000000000) ((-62597857612393533 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((33572106141316877 : ℝ) / 200000000000000000) ((167860530706584431 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((1066731248154274993 : ℝ) / 500000000000000000) ((426692499261710007 : ℝ) / 200000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((1066731248154274993 : ℝ) / 500000000000000000) ((426692499261710007 : ℝ) / 200000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_1_slab_plus_lo_slope {q v : ℝ} (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50))
    (hv : RB v ((468428328107909361 : ℝ) / 1000000000000000000) ((468428328107909361 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-6247814233641219 : ℝ) / 500000000000000000) ((-580431169824487 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((2059856741301418073 : ℝ) / 1000000000000000000) ((556422008970347817 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((468028328107909361 : ℝ) / 1000000000000000000) ((234101664053954681 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((531571671892090639 : ℝ) / 1000000000000000000) ((531571671892090639 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-379613227375630077 : ℝ) / 500000000000000000) ((-758852615646640593 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_72.1 dlower_m_log_80.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-78989655244064963 : ℝ) / 125000000000000000) ((-315958620976259851 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_75.1 dlower_m_log_75.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-31827303199685113 : ℝ) / 250000000000000000) ((-126935373694120889 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-13437230441005267 : ℝ) / 125000000000000000) ((-10541067583544231 : ℝ) / 100000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-94796521329150463 : ℝ) / 125000000000000000) ((-379186085316601851 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_76.1 dlower_m_log_76.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((325437163552580783 : ℝ) / 500000000000000000) ((326480747398880697 : ℝ) / 500000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-6247814233641219 : ℝ) / 500000000000000000) ((-580431169824487 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-6247814233641219 : ℝ) / 500000000000000000) ((-580431169824487 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((171237619426503443 : ℝ) / 1000000000000000000) ((77113531591010893 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-1709298245330891 : ℝ) / 20000000000000000) ((-32037363041859599 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-36082595925287783 : ℝ) / 500000000000000000) ((-6651180029543361 : ℝ) / 125000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((99072427575927877 : ℝ) / 1000000000000000000) ((63811171531924171 : ℝ) / 250000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2059856741301418073 : ℝ) / 1000000000000000000) ((556422008970347817 : ℝ) / 250000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2059856741301418073 : ℝ) / 1000000000000000000) ((556422008970347817 : ℝ) / 250000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_1_slab_plus_hi_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((478922681614347497 : ℝ) / 1000000000000000000) ((478922681614347497 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((3300805072120703 : ℝ) / 500000000000000000) ((6601610144241419 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((1029243168215217361 : ℝ) / 500000000000000000) ((1029243168215217381 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((478616431614347497 : ℝ) / 1000000000000000000) ((239308215807173749 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((521077318385652503 : ℝ) / 1000000000000000000) ((521077318385652503 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-147371154286076213 : ℝ) / 200000000000000000) ((-736855771430381061 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_81.1 dlower_m_log_82.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-651856844428293173 : ℝ) / 1000000000000000000) ((-651856844428293171 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_74.1 dlower_m_log_74.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-42499463501043947 : ℝ) / 500000000000000000) ((-5312432937630493 : ℝ) / 62500000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-71164596819238527 : ℝ) / 1000000000000000000) ((-71164596819238521 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-147243222170839849 : ℝ) / 200000000000000000) ((-736216110854199243 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_77.1 dlower_m_log_77.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((166262878508740179 : ℝ) / 250000000000000000) ((166262878508740181 : ℝ) / 250000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((3300805072120703 : ℝ) / 500000000000000000) ((6601610144241419 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((3300805072120703 : ℝ) / 500000000000000000) ((6601610144241419 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((77054840198962439 : ℝ) / 500000000000000000) ((154109680397924909 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-36563725864934141 : ℝ) / 500000000000000000) ((-73127451729868277 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-61225309569455757 : ℝ) / 1000000000000000000) ((-61225309569455751 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((92884370828469121 : ℝ) / 1000000000000000000) ((46442185414234579 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((1029243168215217361 : ℝ) / 500000000000000000) ((1029243168215217381 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((1029243168215217361 : ℝ) / 500000000000000000) ((1029243168215217381 : ℝ) / 500000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_1_slab_plus_hi_slope {q v : ℝ} (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50))
    (hv : RB v ((478922681614347497 : ℝ) / 1000000000000000000) ((478922681614347497 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((56813887530717 : ℝ) / 62500000000000000) ((6114833011946313 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((400927505223411529 : ℝ) / 200000000000000000) ((2124816690274189673 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((478522681614347497 : ℝ) / 1000000000000000000) ((239348840807173749 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((521077318385652503 : ℝ) / 1000000000000000000) ((521077318385652503 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-184262916929913533 : ℝ) / 250000000000000000) ((-736686025682204293 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_83.1 dlower_m_log_73.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-651856844428293173 : ℝ) / 1000000000000000000) ((-651856844428293171 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_74.1 dlower_m_log_74.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-85194823291360961 : ℝ) / 1000000000000000000) ((-1060364765673889 : ℝ) / 12500000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-71937133081263767 : ℝ) / 1000000000000000000) ((-35222259431360369 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-147243222170839849 : ℝ) / 200000000000000000) ((-736216110854199243 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_77.1 dlower_m_log_77.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((166069744443233869 : ℝ) / 250000000000000000) ((665771591991478507 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((56813887530717 : ℝ) / 62500000000000000) ((6114833011946313 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((56813887530717 : ℝ) / 62500000000000000) ((6114833011946313 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((114435768636271743 : ℝ) / 1000000000000000000) ((103208142644865241 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-8359060403376433 : ℝ) / 100000000000000000) ((-15667508509143383 : ℝ) / 250000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-35291278122352147 : ℝ) / 500000000000000000) ((-52042944769235393 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((43853212391567449 : ℝ) / 1000000000000000000) ((154373340520495089 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((400927505223411529 : ℝ) / 200000000000000000) ((2124816690274189673 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((400927505223411529 : ℝ) / 200000000000000000) ((2124816690274189673 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_1_slab_minus_branch {q v : ℝ} (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50))
    (hv : RB v ((711786224292540793 : ℝ) / 500000000000000000) ((1426546929435239081 : ℝ) / 1000000000000000000)) :
    RB (phi q (v)) ((177966271512858681 : ℝ) / 125000000000000000) ((2282924660281531 : ℝ) / 1600000000000000) ∧
    RB (psi1 q (v)) ((-465573614052523611 : ℝ) / 1000000000000000000) ((93368209414075237 : ℝ) / 500000000000000000) ∧
    RB (psi2 q (v)) ((28298095284538857069 : ℝ) / 1000000000000000000) ((74694900290732310433 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((711586224292540793 : ℝ) / 500000000000000000) ((713160964717619541 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-426546929435239081 : ℝ) / 1000000000000000000) ((-211786224292540793 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((35288849840265111 : ℝ) / 100000000000000000) ((177549526740021541 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_84.1 dlower_m_log_85.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((211786224292540793 : ℝ) / 500000000000000000) ((426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-859030708481855901 : ℝ) / 1000000000000000000) ((-426016442128935099 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_86.1 dlower_m_log_87.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((301230345665130327 : ℝ) / 250000000000000000) ((1214129761961898983 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((1000600333685422407 : ℝ) / 1000000000000000000) ((256297891379724521 : ℝ) / 250000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70633904225311187 : ℝ) / 200000000000000000) ((355256789437493011 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_88.1 dlower_m_log_89.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((161335886061982349 : ℝ) / 250000000000000000) ((672022044392342149 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-1126650707782163 : ℝ) / 62500000000000000) ((4620029606189067 : ℝ) / 250000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-1126650707782163 : ℝ) / 62500000000000000) ((4620029606189067 : ℝ) / 250000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-73542072640607617 : ℝ) / 25000000000000000) ((-1625456034502027147 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-5621244289793273 : ℝ) / 200000000000000000) ((-2103311978935827 : ℝ) / 100000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-23732439538856219 : ℝ) / 1000000000000000000) ((-17466489500922773 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-2965415345163160899 : ℝ) / 1000000000000000000) ((-10268265775018437 : ℝ) / 6250000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-1004631031437670703 : ℝ) / 1000000000000000000) ((40940103218843083 : ℝ) / 125000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-1004631031437670703 : ℝ) / 1000000000000000000) ((40940103218843083 : ℝ) / 125000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((175275998244652267 : ℝ) / 250000000000000000) ((702655536224159101 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((211786224292540793 : ℝ) / 500000000000000000) ((426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-2360871211856295543 : ℝ) / 1000000000000000000) ((-2344407920891682357 : ℝ) / 1000000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-66390688755107459 : ℝ) / 40000000000000000) ((-205219048083440407 : ℝ) / 125000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-1401480638089786657 : ℝ) / 1000000000000000000) ((-1363356985415862921 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((140198682478100273 : ℝ) / 200000000000000000) ((702458101794482539 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-525984684971067299 : ℝ) / 250000000000000000) ((-1032175198903182143 : ℝ) / 500000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-525984684971067299 : ℝ) / 250000000000000000) ((-1032175198903182143 : ℝ) / 500000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((211786224292540793 : ℝ) / 500000000000000000) ((426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((179413619200361583 : ℝ) / 1000000000000000000) ((45485570752657707 : ℝ) / 250000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((5496248499539660759 : ℝ) / 1000000000000000000) ((557371287897181353 : ℝ) / 100000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((202541981841165669 : ℝ) / 100000000000000000) ((63574820199620723 : ℝ) / 31250000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((491546808970549513 : ℝ) / 1000000000000000000) ((493724802586460563 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((1250630924238300049 : ℝ) / 250000000000000000) ((5082166070001264017 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((4154235249264291117 : ℝ) / 1000000000000000000) ((429129896388712733 : ℝ) / 100000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((405311703274104951 : ℝ) / 200000000000000000) ((203503614188110899 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((491391764214879513 : ℝ) / 1000000000000000000) ((61680923097088449 : ℝ) / 125000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((464562701347917063 : ℝ) / 100000000000000000) ((2392373174331917461 : ℝ) / 500000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((464562701347917063 : ℝ) / 100000000000000000) ((2392373174331917461 : ℝ) / 500000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((175275998244652267 : ℝ) / 250000000000000000) ((702655536224159101 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((211786224292540793 : ℝ) / 500000000000000000) ((426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-2360871211856295543 : ℝ) / 1000000000000000000) ((-2344407920891682357 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-66390688755107459 : ℝ) / 40000000000000000) ((-205219048083440407 : ℝ) / 125000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((553686812936196877 : ℝ) / 250000000000000000) ((251337882492811737 : ℝ) / 62500000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((14999999999999999 : ℝ) / 500000000000000000) ((1 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((202541981841165669 : ℝ) / 100000000000000000) ((63574820199620723 : ℝ) / 31250000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((3686601067279121 : ℝ) / 250000000000000000) ((19748992103458423 : ℝ) / 1000000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((3061456383103977 : ℝ) / 250000000000000000) ((16675730030082451 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((278374134659650427 : ℝ) / 125000000000000000) ((4038081849915070243 : ℝ) / 1000000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((278374134659650427 : ℝ) / 125000000000000000) ((4038081849915070243 : ℝ) / 1000000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((3975893975930942803 : ℝ) / 62500000000000000) ((6072382211561399377 : ℝ) / 40000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-484574713146125583 : ℝ) / 100000000000000000) ((-1349014182911208837 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-5621244289793273 : ℝ) / 200000000000000000) ((-2103311978935827 : ℝ) / 100000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((56747953813429447 : ℝ) / 1000000000000000000) ((27239128392508717 : ℝ) / 200000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((12734210313741702859 : ℝ) / 200000000000000000) ((15194575093099752801 : ℝ) / 100000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-702655536224159101 : ℝ) / 500000000000000000) ((-175275998244652267 : ℝ) / 125000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((224999999999999 : ℝ) / 250000000000000000) ((1 : ℝ) / 625) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((202541981841165669 : ℝ) / 100000000000000000) ((63574820199620723 : ℝ) / 31250000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((110598032018373 : ℝ) / 250000000000000000) ((789959684138337 : ℝ) / 1000000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-1406101032132456539 : ℝ) / 1000000000000000000) ((-350662594521322907 : ℝ) / 250000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-593644503072007083 : ℝ) / 500000000000000000) ((-1164800008160824121 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((62483762562564500129 : ℝ) / 1000000000000000000) ((150780950922836703889 : ℝ) / 1000000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((60542439065270219747 : ℝ) / 1000000000000000000) ((148858613360360733109 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((60542439065270219747 : ℝ) / 1000000000000000000) ((148858613360360733109 : ℝ) / 1000000000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-40940103218843083 : ℝ) / 125000000000000000) ((1004631031437670703 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((-1004631031437670703 : ℝ) / 1000000000000000000) ((40940103218843083 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((1032175198903182143 : ℝ) / 500000000000000000) ((525984684971067299 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((-243328611389137079 : ℝ) / 500000000000000000) ((4957988631962283 : ℝ) / 31250000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((-243328611389137079 : ℝ) / 500000000000000000) ((4957988631962283 : ℝ) / 31250000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 (0 : ℝ) ((59208813120565691 : ℝ) / 250000000000000000) := rb_sq_cross bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 (0 : ℝ) ((1133196609549384207 : ℝ) / 1000000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((278374134659650427 : ℝ) / 62500000000000000) ((4038081849915070243 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((-786064679372409509 : ℝ) / 200000000000000000) ((1281328890035977223 : ℝ) / 1000000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((-786064679372409509 : ℝ) / 200000000000000000) ((241452549958536143 : ℝ) / 100000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((28306057834204086101 : ℝ) / 500000000000000000) ((151273138859946094539 : ℝ) / 1000000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-151273138859946094539 : ℝ) / 1000000000000000000) ((-28306057834204086101 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((28306057834204086101 : ℝ) / 500000000000000000) ((151273138859946094539 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((1032175198903182143 : ℝ) / 500000000000000000) ((525984684971067299 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((26907682526689070773 : ℝ) / 1000000000000000000) ((18319702292388577469 : ℝ) / 250000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((26907682526689070773 : ℝ) / 1000000000000000000) ((18319702292388577469 : ℝ) / 250000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((78861758893931 : ℝ) / 500000000000000000) ((140491620358897 : ℝ) / 500000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((177966271512858681 : ℝ) / 125000000000000000) ((2282924660281531 : ℝ) / 1600000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((177966271512858681 : ℝ) / 125000000000000000) ((2282924660281531 : ℝ) / 1600000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((405311703274104951 : ℝ) / 200000000000000000) ((203503614188110899 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((110563146948347 : ℝ) / 1000000000000000000) ((49344738477671 : ℝ) / 250000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((249950655261522329 : ℝ) / 250000000000000000) ((999889436853051653 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((-9732068328484773 : ℝ) / 20000000000000000) ((39659523689092793 : ℝ) / 250000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((14999999999999999 : ℝ) / 500000000000000000) ((1 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((21029802371715039 : ℝ) / 1000000000000000000) ((14049162035889651 : ℝ) / 500000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((-465573614052523611 : ℝ) / 1000000000000000000) ((93368209414075237 : ℝ) / 500000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((-465573614052523611 : ℝ) / 1000000000000000000) ((93368209414075237 : ℝ) / 500000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((224999999999999 : ℝ) / 500000000000000000) ((1 : ℝ) / 1250) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((405311703274104951 : ℝ) / 200000000000000000) ((203503614188110899 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((2884952869350538071 : ℝ) / 1000000000000000000) ((2903074559490231573 : ℝ) / 1000000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((38752018831977 : ℝ) / 250000000000000000) ((277300890596559 : ℝ) / 1000000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 (0 : ℝ) ((59208813120565691 : ℝ) / 250000000000000000) := rb_sq_cross bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 (0 : ℝ) ((65674626437993 : ℝ) / 1000000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((14999999999999999 : ℝ) / 250000000000000000) ((2 : ℝ) / 25) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((405311703274104951 : ℝ) / 200000000000000000) ((203503614188110899 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((921359557902899 : ℝ) / 31250000000000000) ((1233618461941769 : ℝ) / 31250000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((-19211178709010797 : ℝ) / 1000000000000000000) ((3131528350968877 : ℝ) / 500000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-3131528350968877 : ℝ) / 500000000000000000) ((1927685333544879 : ℝ) / 100000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((140198682478100273 : ℝ) / 100000000000000000) ((1404916203588965077 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((87232735504941561 : ℝ) / 62500000000000000) ((1424193056924413867 : ℝ) / 1000000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((405311703274104951 : ℝ) / 200000000000000000) ((203503614188110899 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((110563146948347 : ℝ) / 1000000000000000000) ((49344738477671 : ℝ) / 250000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((249950655261522329 : ℝ) / 250000000000000000) ((999889436853051653 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((26902371516459792093 : ℝ) / 1000000000000000000) ((36635353616903948283 : ℝ) / 500000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((28298095284538857069 : ℝ) / 1000000000000000000) ((74694900290732310433 : ℝ) / 1000000000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((28298095284538857069 : ℝ) / 1000000000000000000) ((74694900290732310433 : ℝ) / 1000000000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_1_slab_minus_lo_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((711786224292540793 : ℝ) / 500000000000000000) ((711786224292540793 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((1552159673978679 : ℝ) / 500000000000000000) ((24252494905917 : ℝ) / 7812500000000000) ∧
    RB (Eq q (v)) ((-252410324868548059 : ℝ) / 1000000000000000000) ((-252410324868547769 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((711633099292540793 : ℝ) / 500000000000000000) ((1423266198585081587 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-211786224292540793 : ℝ) / 500000000000000000) ((-211786224292540793 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((352954370189578331 : ℝ) / 1000000000000000000) ((352954370189578333 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_90.1 dlower_m_log_91.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((211786224292540793 : ℝ) / 500000000000000000) ((211786224292540793 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-859030708481855901 : ℝ) / 1000000000000000000) ((-859030708481855899 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_86.1 dlower_m_log_86.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((121198507867143423 : ℝ) / 100000000000000000) ((605992539335717117 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((202944748873046521 : ℝ) / 200000000000000000) ((126840468045654077 : ℝ) / 125000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70633904225311187 : ℝ) / 200000000000000000) ((353169521126555937 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_88.1 dlower_m_log_88.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((165388555809669167 : ℝ) / 250000000000000000) ((661554223238676681 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((1552159673978679 : ℝ) / 500000000000000000) ((24252494905917 : ℝ) / 7812500000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((1552159673978679 : ℝ) / 500000000000000000) ((24252494905917 : ℝ) / 7812500000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-2197423422962981867 : ℝ) / 1000000000000000000) ((-137338963935186349 : ℝ) / 62500000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-3073915480006017 : ℝ) / 125000000000000000) ((-24591323840048133 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-20588867507531793 : ℝ) / 1000000000000000000) ((-20588867507531789 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-110900614523525683 : ℝ) / 50000000000000000) ((-2218012290470513373 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-252410324868548059 : ℝ) / 1000000000000000000) ((-252410324868547769 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-252410324868548059 : ℝ) / 1000000000000000000) ((-252410324868547769 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_1_slab_minus_lo_slope {q v : ℝ} (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50))
    (hv : RB v ((711786224292540793 : ℝ) / 500000000000000000) ((711786224292540793 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-10127954537420497 : ℝ) / 1000000000000000000) ((8358692226378813 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((-999573045626046259 : ℝ) / 1000000000000000000) ((79511040132350599 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((711586224292540793 : ℝ) / 500000000000000000) ((1423347448585081587 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-211786224292540793 : ℝ) / 500000000000000000) ((-211786224292540793 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((35288849840265111 : ℝ) / 100000000000000000) ((353011455561949 : ℝ) / 1000000000000000) := rb_log h2 (by norm_num) dlower_m_log_84.1 dlower_m_log_92.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((211786224292540793 : ℝ) / 500000000000000000) ((211786224292540793 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-859030708481855901 : ℝ) / 1000000000000000000) ((-859030708481855899 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_86.1 dlower_m_log_86.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1211919206884507009 : ℝ) / 1000000000000000000) ((1212042164043804901 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((251602880540394861 : ℝ) / 250000000000000000) ((511714415773449721 : ℝ) / 500000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70633904225311187 : ℝ) / 200000000000000000) ((353169521126555937 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_88.1 dlower_m_log_88.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((653242001035023507 : ℝ) / 1000000000000000000) ((670259310420343507 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-10127954537420497 : ℝ) / 1000000000000000000) ((8358692226378813 : ℝ) / 500000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-10127954537420497 : ℝ) / 1000000000000000000) ((8358692226378813 : ℝ) / 500000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-734156229953170059 : ℝ) / 250000000000000000) ((-817448099314851741 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-5621244289793273 : ℝ) / 200000000000000000) ((-4215414870040669 : ℝ) / 200000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-23732439538856219 : ℝ) / 1000000000000000000) ((-8751495297294353 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-592071471870307291 : ℝ) / 200000000000000000) ((-413099797306073047 : ℝ) / 250000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-999573045626046259 : ℝ) / 1000000000000000000) ((79511040132350599 : ℝ) / 250000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-999573045626046259 : ℝ) / 1000000000000000000) ((79511040132350599 : ℝ) / 250000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_1_slab_minus_hi_center {q v : ℝ} (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hv : RB v ((1426546929435239081 : ℝ) / 1000000000000000000) ((1426546929435239081 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-3093892659578767 : ℝ) / 1000000000000000000) ((-3093892659578749 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((-6086624469417331 : ℝ) / 25000000000000000) ((-243464978776692951 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((306249999999999 : ℝ) / 1000000000000000000) ((49 : ℝ) / 160000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1426240679435239081 : ℝ) / 1000000000000000000) ((713120339717619541 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-426546929435239081 : ℝ) / 1000000000000000000) ((-426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((177521043579031729 : ℝ) / 500000000000000000) ((355042087158063461 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_93.1 dlower_m_log_94.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((426546929435239081 : ℝ) / 1000000000000000000) ((426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-4260164421289351 : ℝ) / 5000000000000000) ((-426016442128935099 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_87.1 dlower_m_log_87.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((150884371426991707 : ℝ) / 125000000000000000) ((1207074971415933661 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((505306400334316777 : ℝ) / 500000000000000000) ((202122560133726713 : ℝ) / 200000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((355256789437493009 : ℝ) / 1000000000000000000) ((355256789437493011 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_89.1 dlower_m_log_89.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((655356011231140543 : ℝ) / 1000000000000000000) ((163839002807785139 : ℝ) / 250000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-3093892659578767 : ℝ) / 1000000000000000000) ((-3093892659578749 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-3093892659578767 : ℝ) / 1000000000000000000) ((-3093892659578749 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-43770420315229269 : ℝ) / 20000000000000000) ((-1094260507880731583 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-7 : ℝ) / 200) ((-17499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-4908007534024237 : ℝ) / 200000000000000000) ((-24540037670121183 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-20545928617195391 : ℝ) / 1000000000000000000) ((-20545928617195389 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-2209066944378658841 : ℝ) / 1000000000000000000) ((-441813388875731711 : ℝ) / 200000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-6086624469417331 : ℝ) / 25000000000000000) ((-243464978776692951 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-6086624469417331 : ℝ) / 25000000000000000) ((-243464978776692951 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_1_slab_minus_hi_slope {q v : ℝ} (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50))
    (hv : RB v ((1426546929435239081 : ℝ) / 1000000000000000000) ((1426546929435239081 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-8146299409884673 : ℝ) / 500000000000000000) ((10484000338304753 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((-246906672480268407 : ℝ) / 250000000000000000) ((324704280619130423 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 2500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1426146929435239081 : ℝ) / 1000000000000000000) ((713160964717619541 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-426546929435239081 : ℝ) / 1000000000000000000) ((-426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((70995270550769119 : ℝ) / 200000000000000000) ((177549526740021541 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_95.1 dlower_m_log_85.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((426546929435239081 : ℝ) / 1000000000000000000) ((426546929435239081 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-4260164421289351 : ℝ) / 5000000000000000) ((-426016442128935099 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_87.1 dlower_m_log_87.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1207009237011715793 : ℝ) / 1000000000000000000) ((603565968868956641 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((1002334146190167669 : ℝ) / 1000000000000000000) ((1019282715743383643 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((355256789437493009 : ℝ) / 1000000000000000000) ((355256789437493011 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_89.1 dlower_m_log_89.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((323538678376337329 : ℝ) / 500000000000000000) ((332012963152945317 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-8146299409884673 : ℝ) / 500000000000000000) ((10484000338304753 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-8146299409884673 : ℝ) / 500000000000000000) ((10484000338304753 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-2924728062294380281 : ℝ) / 1000000000000000000) ((-407068144908410347 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1 : ℝ) / 25) ((-14999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-28047600969025113 : ℝ) / 1000000000000000000) ((-2103311978935827 : ℝ) / 100000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-23682941352183543 : ℝ) / 1000000000000000000) ((-17466489500922773 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-184275687727910239 : ℝ) / 62500000000000000) ((-1645739069134564161 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((-246906672480268407 : ℝ) / 250000000000000000) ((324704280619130423 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((-246906672480268407 : ℝ) / 250000000000000000) ((324704280619130423 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_1_point_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((17499999999999999 : ℝ) / 1000000000000000000) ((7 : ℝ) / 400))
    (hplus : RB (vPlus q) ((473675504861127 : ℝ) / 1000000000000000) ((47367550486113 : ℝ) / 100000000000000))
    (hminus : RB (vMinus q) ((1425059689010159 : ℝ) / 1000000000000000) ((712529844505081 : ℝ) / 500000000000000)) :
RB (Lam q) ((183704589394255677 : ℝ) / 100000000000000000) ((918522946971284193 : ℝ) / 500000000000000000) ∧
    RB (lam1 q) ((-696761309889724591 : ℝ) / 1000000000000000000) ((-174190327472390327 : ℝ) / 250000000000000000) ∧
    RB (lam2 q) ((11091752984237937547 : ℝ) / 100000000000000000) ((110917529842387701557 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_point hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_1_point_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_1_point_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((950952547767783083 : ℝ) / 1000000000000000000) ((237738136941947273 : ℝ) / 250000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((377128381910763499 : ℝ) / 250000000000000000) ((1508513527643126693 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((3614746410531608793 : ℝ) / 62500000000000000) ((2313437702740389193 : ℝ) / 40000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((183704589394255677 : ℝ) / 100000000000000000) ((918522946971284193 : ℝ) / 500000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-3610901020034532459 : ℝ) / 1000000000000000000) ((-3610901020034509623 : ℝ) / 1000000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((728534927536201967 : ℝ) / 250000000000000000) ((582827942028989663 : ℝ) / 200000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((-696761309889724591 : ℝ) / 1000000000000000000) ((-174190327472390327 : ℝ) / 250000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((5323195606930481017 : ℝ) / 500000000000000000) ((10646391213861029379 : ℝ) / 1000000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-3797141117619961459 : ℝ) / 500000000000000000) ((-23732131985124759 : ℝ) / 3125000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-1432009685574913179 : ℝ) / 125000000000000000) ((-11456077484598753293 : ℝ) / 1000000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-404843135369171699 : ℝ) / 500000000000000000) ((-404843135368861957 : ℝ) / 500000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((27931804028279429717 : ℝ) / 250000000000000000) ((111727216113125425471 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((11091752984237937547 : ℝ) / 100000000000000000) ((110917529842387701557 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((183704589394255677 : ℝ) / 100000000000000000) ((918522946971284193 : ℝ) / 500000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((-696761309889724591 : ℝ) / 1000000000000000000) ((-174190327472390327 : ℝ) / 250000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((11091752984237937547 : ℝ) / 100000000000000000) ((110917529842387701557 : ℝ) / 1000000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

theorem dlower_m_1_slab_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((14999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 50))
    (hplus : RB (vPlus q) ((468428328107909361 : ℝ) / 1000000000000000000) ((478922681614347497 : ℝ) / 1000000000000000000))
    (hminus : RB (vMinus q) ((711786224292540793 : ℝ) / 500000000000000000) ((1426546929435239081 : ℝ) / 1000000000000000000)) :
RB (Lam q) ((907298703544074637 : ℝ) / 500000000000000000) ((371930318185919721 : ℝ) / 200000000000000000) ∧
    RB (lam1 q) ((-1847809957400664259 : ℝ) / 1000000000000000000) ((399002597957365031 : ℝ) / 1000000000000000000) ∧
    RB (lam2 q) ((21362274934918758101 : ℝ) / 500000000000000000) ((105322852123177833969 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_1_slab hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_1_slab_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_1_slab_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((943953571167255253 : ℝ) / 1000000000000000000) ((478964890066361429 : ℝ) / 500000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((472478972544695301 : ℝ) / 500000000000000000) ((127394942645374267 : ℝ) / 62500000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((4978727768884677387 : ℝ) / 200000000000000000) ((26649189117494191483 : ℝ) / 250000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((907298703544074637 : ℝ) / 500000000000000000) ((371930318185919721 : ℝ) / 200000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-3664338110206105631 : ℝ) / 1000000000000000000) ((-1779017065772695367 : ℝ) / 500000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((454132038201360343 : ℝ) / 250000000000000000) ((791407345900551153 : ℝ) / 200000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((-1847809957400664259 : ℝ) / 1000000000000000000) ((399002597957365031 : ℝ) / 1000000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((5232403134625574611 : ℝ) / 500000000000000000) ((5415277995378481237 : ℝ) / 500000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-3825267974964099281 : ℝ) / 500000000000000000) ((-1884644669094089 : ℝ) / 250000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-7797116708379814327 : ℝ) / 500000000000000000) ((-3561819907461649749 : ℝ) / 500000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-641178393438559929 : ℝ) / 125000000000000000) ((7240070655925123 : ℝ) / 1953125000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((23926988508672997817 : ℝ) / 500000000000000000) ((103469394035261002481 : ℝ) / 500000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((21362274934918758101 : ℝ) / 500000000000000000) ((105322852123177833969 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((907298703544074637 : ℝ) / 500000000000000000) ((371930318185919721 : ℝ) / 200000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((-1847809957400664259 : ℝ) / 1000000000000000000) ((399002597957365031 : ℝ) / 1000000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((21362274934918758101 : ℝ) / 500000000000000000) ((105322852123177833969 : ℝ) / 500000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

end EP1038.DLowerCert
