import LeanProject.COVLogTwo
import LeanProject.COVLogBounds16
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1600 : RB (Real.log ((5022073 : ℝ) / 100000000)) ((-299132743 : ℝ) / 100000000) ((-149566369 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5022073 : ℝ) / 6250000)) (t := ((-1227927 : ℝ) / 11272073))
    (lo := ((-21873867 : ℝ) / 100000000)) (hi := ((-10936933 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5022073 : ℝ) / 100000000) = Real.log ((5022073 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5022073 : ℝ) / 100000000) = ((5022073 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1601 : RB (Real.log ((2528911 : ℝ) / 50000000)) ((-298423427 : ℝ) / 100000000) ((-149211711 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2528911 : ℝ) / 3125000)) (t := ((-596089 : ℝ) / 5653911))
    (lo := ((-21164551 : ℝ) / 100000000)) (hi := ((-423291 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2528911 : ℝ) / 50000000) = Real.log ((2528911 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2528911 : ℝ) / 50000000) = ((2528911 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1602 : RB (Real.log ((63404269 : ℝ) / 100000000)) ((-45563901 : ℝ) / 100000000) ((-45563899 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63404269 : ℝ) / 50000000)) (t := ((13404269 : ℝ) / 113404269))
    (lo := ((11875409 : ℝ) / 50000000)) (hi := ((23750819 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63404269 : ℝ) / 100000000) = Real.log ((63404269 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63404269 : ℝ) / 100000000) = ((63404269 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1603 : RB (Real.log ((792573 : ℝ) / 1250000)) ((-45561423 : ℝ) / 100000000) ((-45561421 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((792573 : ℝ) / 625000)) (t := ((167573 : ℝ) / 1417573))
    (lo := ((1484581 : ℝ) / 6250000)) (hi := ((23753297 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((792573 : ℝ) / 1250000) = Real.log ((792573 : ℝ) / 625000) - 1 * Real.log 2 := by
    rw [show ((792573 : ℝ) / 1250000) = ((792573 : ℝ) / 625000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1604 : RB (Real.log ((310769 : ℝ) / 800000)) ((-94556187 : ℝ) / 100000000) ((-18911237 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((310769 : ℝ) / 400000)) (t := ((-89231 : ℝ) / 710769))
    (lo := ((-6310367 : ℝ) / 25000000)) (hi := ((-25241467 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((310769 : ℝ) / 800000) = Real.log ((310769 : ℝ) / 400000) - 1 * Real.log 2 := by
    rw [show ((310769 : ℝ) / 800000) = ((310769 : ℝ) / 400000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1605 : RB (Real.log ((37937389 : ℝ) / 20000000)) ((32010243 : ℝ) / 50000000) ((8002561 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((37937389 : ℝ) / 40000000)) (t := ((-2062611 : ℝ) / 77937389))
    (lo := ((-661779 : ℝ) / 12500000)) (hi := ((-5294231 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37937389 : ℝ) / 20000000) = Real.log ((37937389 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((37937389 : ℝ) / 20000000) = ((37937389 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1606 : RB (Real.log ((94876587 : ℝ) / 50000000)) ((12811079 : ℝ) / 20000000) ((64055397 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((94876587 : ℝ) / 100000000)) (t := ((-5123413 : ℝ) / 194876587))
    (lo := ((-5259323 : ℝ) / 100000000)) (hi := ((-2629661 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94876587 : ℝ) / 50000000) = Real.log ((94876587 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94876587 : ℝ) / 50000000) = ((94876587 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1607 : RB (Real.log ((1603421 : ℝ) / 2500000)) ((-44415127 : ℝ) / 100000000) ((-355321 : ℝ) / 800000) := by
  have hm := log_bounds_of_series (x := ((1603421 : ℝ) / 1250000)) (t := ((353421 : ℝ) / 2853421))
    (lo := ((3112449 : ℝ) / 12500000)) (hi := ((24899593 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1603421 : ℝ) / 2500000) = Real.log ((1603421 : ℝ) / 1250000) - 1 * Real.log 2 := by
    rw [show ((1603421 : ℝ) / 2500000) = ((1603421 : ℝ) / 1250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1608 : RB (Real.log ((32069209 : ℝ) / 50000000)) ((-44412667 : ℝ) / 100000000) ((-8882533 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((32069209 : ℝ) / 25000000)) (t := ((7069209 : ℝ) / 57069209))
    (lo := ((6225513 : ℝ) / 25000000)) (hi := ((24902053 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32069209 : ℝ) / 50000000) = Real.log ((32069209 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32069209 : ℝ) / 50000000) = ((32069209 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1609 : RB (Real.log ((7823813 : ℝ) / 20000000)) ((-46928013 : ℝ) / 50000000) ((-11732003 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((7823813 : ℝ) / 10000000)) (t := ((-2176187 : ℝ) / 17823813))
    (lo := ((-24541307 : ℝ) / 100000000)) (hi := ((-12270653 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7823813 : ℝ) / 20000000) = Real.log ((7823813 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((7823813 : ℝ) / 20000000) = ((7823813 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1610 : RB (Real.log ((399980949 : ℝ) / 100000000)) ((138624673 : ℝ) / 100000000) ((34656169 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((399980949 : ℝ) / 400000000)) (t := ((-19051 : ℝ) / 799980949))
    (lo := ((-4763 : ℝ) / 100000000)) (hi := ((-2381 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((399980949 : ℝ) / 100000000) = Real.log ((399980949 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((399980949 : ℝ) / 100000000) = ((399980949 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1611 : RB (Real.log ((49997979 : ℝ) / 12500000)) ((138625393 : ℝ) / 100000000) ((34656349 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((49997979 : ℝ) / 50000000)) (t := ((-2021 : ℝ) / 99997979))
    (lo := ((-4043 : ℝ) / 100000000)) (hi := ((-2021 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((49997979 : ℝ) / 12500000) = Real.log ((49997979 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((49997979 : ℝ) / 12500000) = ((49997979 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1612 : RB (Real.log ((133311463 : ℝ) / 100000000)) ((28751803 : ℝ) / 100000000) ((7187951 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((133311463 : ℝ) / 100000000)) (t := ((33311463 : ℝ) / 233311463))
    (lo := ((28751803 : ℝ) / 100000000)) (hi := ((7187951 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1613 : RB (Real.log ((199323207 : ℝ) / 50000000)) ((27658093 : ℝ) / 20000000) ((34572617 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((199323207 : ℝ) / 200000000)) (t := ((-676793 : ℝ) / 399323207))
    (lo := ((-338971 : ℝ) / 100000000)) (hi := ((-33897 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((199323207 : ℝ) / 50000000) = Real.log ((199323207 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((199323207 : ℝ) / 50000000) = ((199323207 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1614 : RB (Real.log ((99662321 : ℝ) / 25000000)) ((27658237 : ℝ) / 20000000) ((34572797 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((99662321 : ℝ) / 100000000)) (t := ((-337679 : ℝ) / 199662321))
    (lo := ((-338251 : ℝ) / 100000000)) (hi := ((-1353 : ℝ) / 400000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((99662321 : ℝ) / 25000000) = Real.log ((99662321 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((99662321 : ℝ) / 25000000) = ((99662321 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1615 : RB (Real.log ((133460319 : ℝ) / 100000000)) ((28863401 : ℝ) / 100000000) ((28863403 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133460319 : ℝ) / 200000000)) (t := ((-66539681 : ℝ) / 333460319))
    (lo := ((-40451317 : ℝ) / 100000000)) (hi := ((-10112829 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133460319 : ℝ) / 100000000) = Real.log ((133460319 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133460319 : ℝ) / 100000000) = ((133460319 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1616 : RB (Real.log ((2582649 : ℝ) / 20000000)) ((-204691669 : ℝ) / 100000000) ((-40938333 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((2582649 : ℝ) / 2500000)) (t := ((82649 : ℝ) / 5082649))
    (lo := ((406561 : ℝ) / 12500000)) (hi := ((3252489 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2582649 : ℝ) / 20000000) = Real.log ((2582649 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((2582649 : ℝ) / 20000000) = ((2582649 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1617 : RB (Real.log ((548263 : ℝ) / 4000000)) ((-198729457 : ℝ) / 100000000) ((-198729453 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((548263 : ℝ) / 500000)) (t := ((48263 : ℝ) / 1048263))
    (lo := ((92147 : ℝ) / 1000000)) (hi := ((9214701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((548263 : ℝ) / 4000000) = Real.log ((548263 : ℝ) / 500000) - 3 * Real.log 2 := by
    rw [show ((548263 : ℝ) / 4000000) = ((548263 : ℝ) / 500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1618 : RB (Real.log ((315893 : ℝ) / 6250000)) ((-74623331 : ℝ) / 25000000) ((-298493319 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((315893 : ℝ) / 390625)) (t := ((-37366 : ℝ) / 353259))
    (lo := ((-1327153 : ℝ) / 6250000)) (hi := ((-21234447 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((315893 : ℝ) / 6250000) = Real.log ((315893 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((315893 : ℝ) / 6250000) = ((315893 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1619 : RB (Real.log ((5090059 : ℝ) / 100000000)) ((-297788081 : ℝ) / 100000000) ((-74447019 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5090059 : ℝ) / 6250000)) (t := ((-1159941 : ℝ) / 11340059))
    (lo := ((-4105841 : ℝ) / 20000000)) (hi := ((-5132301 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5090059 : ℝ) / 100000000) = Real.log ((5090059 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5090059 : ℝ) / 100000000) = ((5090059 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1620 : RB (Real.log ((6331987 : ℝ) / 10000000)) ((-22848551 : ℝ) / 50000000) ((-456971 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((6331987 : ℝ) / 5000000)) (t := ((1331987 : ℝ) / 11331987))
    (lo := ((23617617 : ℝ) / 100000000)) (hi := ((11808809 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6331987 : ℝ) / 10000000) = Real.log ((6331987 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((6331987 : ℝ) / 10000000) = ((6331987 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1621 : RB (Real.log ((63321449 : ℝ) / 100000000)) ((-2855913 : ℝ) / 6250000) ((-22847303 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((63321449 : ℝ) / 50000000)) (t := ((13321449 : ℝ) / 113321449))
    (lo := ((23620111 : ℝ) / 100000000)) (hi := ((1476257 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63321449 : ℝ) / 100000000) = Real.log ((63321449 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63321449 : ℝ) / 100000000) = ((63321449 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1622 : RB (Real.log ((38815113 : ℝ) / 100000000)) ((-23659013 : ℝ) / 25000000) ((-1892721 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((38815113 : ℝ) / 50000000)) (t := ((-11184887 : ℝ) / 88815113))
    (lo := ((-25321333 : ℝ) / 100000000)) (hi := ((-6330333 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38815113 : ℝ) / 100000000) = Real.log ((38815113 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38815113 : ℝ) / 100000000) = ((38815113 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1623 : RB (Real.log ((189620707 : ℝ) / 100000000)) ((63985561 : ℝ) / 100000000) ((63985563 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((189620707 : ℝ) / 200000000)) (t := ((-10379293 : ℝ) / 389620707))
    (lo := ((-5329157 : ℝ) / 100000000)) (hi := ((-1332289 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189620707 : ℝ) / 100000000) = Real.log ((189620707 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189620707 : ℝ) / 100000000) = ((189620707 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1624 : RB (Real.log ((189686949 : ℝ) / 100000000)) ((8002561 : ℝ) / 12500000) ((6402049 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((189686949 : ℝ) / 200000000)) (t := ((-10313051 : ℝ) / 389686949))
    (lo := ((-529423 : ℝ) / 10000000)) (hi := ((-5294229 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189686949 : ℝ) / 100000000) = Real.log ((189686949 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189686949 : ℝ) / 100000000) = ((189686949 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1625 : RB (Real.log ((12809931 : ℝ) / 20000000)) ((-11137789 : ℝ) / 25000000) ((-22275577 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12809931 : ℝ) / 10000000)) (t := ((2809931 : ℝ) / 22809931))
    (lo := ((24763563 : ℝ) / 100000000)) (hi := ((6190891 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12809931 : ℝ) / 20000000) = Real.log ((12809931 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((12809931 : ℝ) / 20000000) = ((12809931 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1626 : RB (Real.log ((32025621 : ℝ) / 50000000)) ((-22274339 : ℝ) / 50000000) ((-11137169 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((32025621 : ℝ) / 25000000)) (t := ((7025621 : ℝ) / 57025621))
    (lo := ((24766041 : ℝ) / 100000000)) (hi := ((12383021 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32025621 : ℝ) / 50000000) = Real.log ((32025621 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32025621 : ℝ) / 50000000) = ((32025621 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1627 : RB (Real.log ((19543649 : ℝ) / 50000000)) ((-18787453 : ℝ) / 20000000) ((-93937263 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19543649 : ℝ) / 25000000)) (t := ((-5456351 : ℝ) / 44543649))
    (lo := ((-12311273 : ℝ) / 50000000)) (hi := ((-4924509 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19543649 : ℝ) / 50000000) = Real.log ((19543649 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19543649 : ℝ) / 50000000) = ((19543649 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1628 : RB (Real.log ((199765507 : ℝ) / 50000000)) ((3462803 : ℝ) / 2500000) ((138512123 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((199765507 : ℝ) / 200000000)) (t := ((-234493 : ℝ) / 399765507))
    (lo := ((-29329 : ℝ) / 25000000)) (hi := ((-23463 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((199765507 : ℝ) / 50000000) = Real.log ((199765507 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((199765507 : ℝ) / 50000000) = ((199765507 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1629 : RB (Real.log ((399533911 : ℝ) / 100000000)) ((27702569 : ℝ) / 20000000) ((8657053 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((399533911 : ℝ) / 400000000)) (t := ((-466089 : ℝ) / 799533911))
    (lo := ((-116591 : ℝ) / 100000000)) (hi := ((-11659 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((399533911 : ℝ) / 100000000) = Real.log ((399533911 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((399533911 : ℝ) / 100000000) = ((399533911 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1630 : RB (Real.log ((133361179 : ℝ) / 100000000)) ((28789089 : ℝ) / 100000000) ((28789091 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133361179 : ℝ) / 200000000)) (t := ((-66638821 : ℝ) / 333361179))
    (lo := ((-40525629 : ℝ) / 100000000)) (hi := ((-10131407 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133361179 : ℝ) / 100000000) = Real.log ((133361179 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133361179 : ℝ) / 100000000) = ((133361179 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1631 : RB (Real.log ((79640613 : ℝ) / 20000000)) ((13817919 : ℝ) / 10000000) ((138179193 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((79640613 : ℝ) / 80000000)) (t := ((-359387 : ℝ) / 159640613))
    (lo := ((-225123 : ℝ) / 50000000)) (hi := ((-90049 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((79640613 : ℝ) / 20000000) = Real.log ((79640613 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((79640613 : ℝ) / 20000000) = ((79640613 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1632 : RB (Real.log ((398205949 : ℝ) / 100000000)) ((69089957 : ℝ) / 50000000) ((138179917 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((398205949 : ℝ) / 400000000)) (t := ((-1794051 : ℝ) / 798205949))
    (lo := ((-224761 : ℝ) / 50000000)) (hi := ((-449521 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((398205949 : ℝ) / 100000000) = Real.log ((398205949 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((398205949 : ℝ) / 100000000) = ((398205949 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1633 : RB (Real.log ((66754871 : ℝ) / 50000000)) ((14450213 : ℝ) / 50000000) ((7225107 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((66754871 : ℝ) / 100000000)) (t := ((-33245129 : ℝ) / 166754871))
    (lo := ((-10103573 : ℝ) / 25000000)) (hi := ((-40414291 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66754871 : ℝ) / 50000000) = Real.log ((66754871 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((66754871 : ℝ) / 50000000) = ((66754871 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1634 : RB (Real.log ((12972323 : ℝ) / 100000000)) ((-204235213 : ℝ) / 100000000) ((-204235209 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12972323 : ℝ) / 12500000)) (t := ((472323 : ℝ) / 25472323))
    (lo := ((231809 : ℝ) / 6250000)) (hi := ((741789 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12972323 : ℝ) / 100000000) = Real.log ((12972323 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12972323 : ℝ) / 100000000) = ((12972323 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1635 : RB (Real.log ((6881987 : ℝ) / 50000000)) ((-99155781 : ℝ) / 50000000) ((-99155779 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6881987 : ℝ) / 6250000)) (t := ((631987 : ℝ) / 13131987))
    (lo := ((1926519 : ℝ) / 20000000)) (hi := ((2408149 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6881987 : ℝ) / 50000000) = Real.log ((6881987 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6881987 : ℝ) / 50000000) = ((6881987 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1636 : RB (Real.log ((5086503 : ℝ) / 100000000)) ((-297857967 : ℝ) / 100000000) ((-148928981 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5086503 : ℝ) / 6250000)) (t := ((-1163497 : ℝ) / 11336503))
    (lo := ((-20599091 : ℝ) / 100000000)) (hi := ((-2059909 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5086503 : ℝ) / 100000000) = Real.log ((5086503 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5086503 : ℝ) / 100000000) = ((5086503 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1637 : RB (Real.log ((5122297 : ℝ) / 100000000)) ((-148578363 : ℝ) / 50000000) ((-297156721 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5122297 : ℝ) / 6250000)) (t := ((-1127703 : ℝ) / 11372297))
    (lo := ((-397957 : ℝ) / 2000000)) (hi := ((-19897849 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5122297 : ℝ) / 100000000) = Real.log ((5122297 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5122297 : ℝ) / 100000000) = ((5122297 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1638 : RB (Real.log ((63235749 : ℝ) / 100000000)) ((-45830041 : ℝ) / 100000000) ((-45830039 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63235749 : ℝ) / 50000000)) (t := ((13235749 : ℝ) / 113235749))
    (lo := ((11742339 : ℝ) / 50000000)) (hi := ((23484679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63235749 : ℝ) / 100000000) = Real.log ((63235749 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63235749 : ℝ) / 100000000) = ((63235749 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1639 : RB (Real.log ((3161867 : ℝ) / 5000000)) ((-1833101 : ℝ) / 4000000) ((-45827523 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3161867 : ℝ) / 2500000)) (t := ((661867 : ℝ) / 5661867))
    (lo := ((11743597 : ℝ) / 50000000)) (hi := ((4697439 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3161867 : ℝ) / 5000000) = Real.log ((3161867 : ℝ) / 2500000) - 1 * Real.log 2 := by
    rw [show ((3161867 : ℝ) / 5000000) = ((3161867 : ℝ) / 2500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1640 : RB (Real.log ((19392089 : ℝ) / 50000000)) ((-47357891 : ℝ) / 50000000) ((-4735789 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((19392089 : ℝ) / 25000000)) (t := ((-5607911 : ℝ) / 44392089))
    (lo := ((-25401063 : ℝ) / 100000000)) (hi := ((-12700531 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19392089 : ℝ) / 50000000) = Real.log ((19392089 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19392089 : ℝ) / 50000000) = ((19392089 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1641 : RB (Real.log ((189554459 : ℝ) / 100000000)) ((63950617 : ℝ) / 100000000) ((63950619 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((189554459 : ℝ) / 200000000)) (t := ((-10445541 : ℝ) / 389554459))
    (lo := ((-5364101 : ℝ) / 100000000)) (hi := ((-53641 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189554459 : ℝ) / 100000000) = Real.log ((189554459 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189554459 : ℝ) / 100000000) = ((189554459 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1642 : RB (Real.log ((94810357 : ℝ) / 50000000)) ((15996391 : ℝ) / 25000000) ((31992783 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((94810357 : ℝ) / 100000000)) (t := ((-5189643 : ℝ) / 194810357))
    (lo := ((-2664577 : ℝ) / 50000000)) (hi := ((-5329153 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94810357 : ℝ) / 50000000) = Real.log ((94810357 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94810357 : ℝ) / 50000000) = ((94810357 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1643 : RB (Real.log ((31981403 : ℝ) / 50000000)) ((-11171711 : ℝ) / 25000000) ((-22343421 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((31981403 : ℝ) / 25000000)) (t := ((6981403 : ℝ) / 56981403))
    (lo := ((197023 : ℝ) / 800000)) (hi := ((6156969 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31981403 : ℝ) / 50000000) = Real.log ((31981403 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31981403 : ℝ) / 50000000) = ((31981403 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1644 : RB (Real.log ((15991101 : ℝ) / 25000000)) ((-22342173 : ℝ) / 50000000) ((-5585543 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((15991101 : ℝ) / 12500000)) (t := ((3491101 : ℝ) / 28491101))
    (lo := ((24630373 : ℝ) / 100000000)) (hi := ((12315187 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15991101 : ℝ) / 25000000) = Real.log ((15991101 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((15991101 : ℝ) / 25000000) = ((15991101 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1645 : RB (Real.log ((19527813 : ℝ) / 50000000)) ((-47009163 : ℝ) / 50000000) ((-23504581 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((19527813 : ℝ) / 25000000)) (t := ((-5472187 : ℝ) / 44527813))
    (lo := ((-24703607 : ℝ) / 100000000)) (hi := ((-12351803 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19527813 : ℝ) / 50000000) = Real.log ((19527813 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19527813 : ℝ) / 50000000) = ((19527813 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1646 : RB (Real.log ((99770821 : ℝ) / 25000000)) ((138399993 : ℝ) / 100000000) ((34599999 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((99770821 : ℝ) / 100000000)) (t := ((-229179 : ℝ) / 199770821))
    (lo := ((-229443 : ℝ) / 100000000)) (hi := ((-114721 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((99770821 : ℝ) / 25000000) = Real.log ((99770821 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((99770821 : ℝ) / 25000000) = ((99770821 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1647 : RB (Real.log ((399086197 : ℝ) / 100000000)) ((138400723 : ℝ) / 100000000) ((69200363 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((399086197 : ℝ) / 400000000)) (t := ((-913803 : ℝ) / 799086197))
    (lo := ((-228713 : ℝ) / 100000000)) (hi := ((-28589 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((399086197 : ℝ) / 100000000) = Real.log ((399086197 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((399086197 : ℝ) / 100000000) = ((399086197 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1648 : RB (Real.log ((33352699 : ℝ) / 25000000)) ((28826287 : ℝ) / 100000000) ((28826289 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33352699 : ℝ) / 50000000)) (t := ((-16647301 : ℝ) / 83352699))
    (lo := ((-40488431 : ℝ) / 100000000)) (hi := ((-4048843 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33352699 : ℝ) / 25000000) = Real.log ((33352699 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33352699 : ℝ) / 25000000) = ((33352699 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1649 : RB (Real.log ((397761853 : ℝ) / 100000000)) ((138068327 : ℝ) / 100000000) ((13806833 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((397761853 : ℝ) / 400000000)) (t := ((-2238147 : ℝ) / 797761853))
    (lo := ((-561109 : ℝ) / 100000000)) (hi := ((-140277 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((397761853 : ℝ) / 100000000) = Real.log ((397761853 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((397761853 : ℝ) / 100000000) = ((397761853 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1650 : RB (Real.log ((198882377 : ℝ) / 50000000)) ((138069057 : ℝ) / 100000000) ((6903453 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((198882377 : ℝ) / 200000000)) (t := ((-1117623 : ℝ) / 398882377))
    (lo := ((-560379 : ℝ) / 100000000)) (hi := ((-280189 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((198882377 : ℝ) / 50000000) = Real.log ((198882377 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((198882377 : ℝ) / 50000000) = ((198882377 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1651 : RB (Real.log ((133559069 : ℝ) / 100000000)) ((5787473 : ℝ) / 20000000) ((28937367 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133559069 : ℝ) / 200000000)) (t := ((-66440931 : ℝ) / 333559069))
    (lo := ((-40377353 : ℝ) / 100000000)) (hi := ((-5047169 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133559069 : ℝ) / 100000000) = Real.log ((133559069 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133559069 : ℝ) / 100000000) = ((133559069 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1652 : RB (Real.log ((13031153 : ℝ) / 100000000)) ((-101891367 : ℝ) / 50000000) ((-20378273 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((13031153 : ℝ) / 12500000)) (t := ((531153 : ℝ) / 25531153))
    (lo := ((4161423 : ℝ) / 100000000)) (hi := ((260089 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13031153 : ℝ) / 100000000) = Real.log ((13031153 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13031153 : ℝ) / 100000000) = ((13031153 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1653 : RB (Real.log ((13821169 : ℝ) / 100000000)) ((-98948441 : ℝ) / 50000000) ((-98948439 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((13821169 : ℝ) / 12500000)) (t := ((1321169 : ℝ) / 26321169))
    (lo := ((401891 : ℝ) / 4000000)) (hi := ((2511819 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13821169 : ℝ) / 100000000) = Real.log ((13821169 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13821169 : ℝ) / 100000000) = ((13821169 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1654 : RB (Real.log ((5118717 : ℝ) / 100000000)) ((-297226641 : ℝ) / 100000000) ((-74306659 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5118717 : ℝ) / 6250000)) (t := ((-1131283 : ℝ) / 11368717))
    (lo := ((-3993553 : ℝ) / 20000000)) (hi := ((-4991941 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5118717 : ℝ) / 100000000) = Real.log ((5118717 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5118717 : ℝ) / 100000000) = ((5118717 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1655 : RB (Real.log ((2577269 : ℝ) / 50000000)) ((-148264637 : ℝ) / 50000000) ((-296529269 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2577269 : ℝ) / 3125000)) (t := ((-547731 : ℝ) / 5702269))
    (lo := ((-9635199 : ℝ) / 50000000)) (hi := ((-19270397 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2577269 : ℝ) / 50000000) = Real.log ((2577269 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2577269 : ℝ) / 50000000) = ((2577269 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1656 : RB (Real.log ((63151903 : ℝ) / 100000000)) ((-22981361 : ℝ) / 50000000) ((-287267 : ℝ) / 625000) := by
  have hm := log_bounds_of_series (x := ((63151903 : ℝ) / 50000000)) (t := ((13151903 : ℝ) / 113151903))
    (lo := ((23351997 : ℝ) / 100000000)) (hi := ((11675999 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63151903 : ℝ) / 100000000) = Real.log ((63151903 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63151903 : ℝ) / 100000000) = ((63151903 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1657 : RB (Real.log ((31576753 : ℝ) / 50000000)) ((-45960183 : ℝ) / 100000000) ((-45960181 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((31576753 : ℝ) / 25000000)) (t := ((6576753 : ℝ) / 56576753))
    (lo := ((2919317 : ℝ) / 12500000)) (hi := ((23354537 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31576753 : ℝ) / 50000000) = Real.log ((31576753 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31576753 : ℝ) / 50000000) = ((31576753 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1658 : RB (Real.log ((38753319 : ℝ) / 100000000)) ((-4739769 : ℝ) / 5000000) ((-47397689 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((38753319 : ℝ) / 50000000)) (t := ((-11246681 : ℝ) / 88753319))
    (lo := ((-25480661 : ℝ) / 100000000)) (hi := ((-1274033 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38753319 : ℝ) / 100000000) = Real.log ((38753319 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38753319 : ℝ) / 100000000) = ((38753319 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1659 : RB (Real.log ((947441 : ℝ) / 500000)) ((7989457 : ℝ) / 12500000) ((31957829 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((947441 : ℝ) / 1000000)) (t := ((-52559 : ℝ) / 1947441))
    (lo := ((-2699531 : ℝ) / 50000000)) (hi := ((-5399061 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((947441 : ℝ) / 500000) = Real.log ((947441 : ℝ) / 1000000) + 1 * Real.log 2 := by
    rw [show ((947441 : ℝ) / 500000) = ((947441 : ℝ) / 1000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1660 : RB (Real.log ((37910893 : ℝ) / 20000000)) ((63950621 : ℝ) / 100000000) ((63950623 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37910893 : ℝ) / 40000000)) (t := ((-2089107 : ℝ) / 77910893))
    (lo := ((-5364097 : ℝ) / 100000000)) (hi := ((-41907 : ℝ) / 781250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37910893 : ℝ) / 20000000) = Real.log ((37910893 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((37910893 : ℝ) / 20000000) = ((37910893 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1661 : RB (Real.log ((63876281 : ℝ) / 100000000)) ((-4482221 : ℝ) / 10000000) ((-700347 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((63876281 : ℝ) / 50000000)) (t := ((13876281 : ℝ) / 113876281))
    (lo := ((24492509 : ℝ) / 100000000)) (hi := ((2449251 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63876281 : ℝ) / 100000000) = Real.log ((63876281 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63876281 : ℝ) / 100000000) = ((63876281 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1662 : RB (Real.log ((63877891 : ℝ) / 100000000)) ((-44819689 : ℝ) / 100000000) ((-44819687 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63877891 : ℝ) / 50000000)) (t := ((13877891 : ℝ) / 113877891))
    (lo := ((2449503 : ℝ) / 10000000)) (hi := ((24495031 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63877891 : ℝ) / 100000000) = Real.log ((63877891 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63877891 : ℝ) / 100000000) = ((63877891 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1663 : RB (Real.log ((19512023 : ℝ) / 50000000)) ((-47049609 : ℝ) / 50000000) ((-5881201 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((19512023 : ℝ) / 25000000)) (t := ((-5487977 : ℝ) / 44512023))
    (lo := ((-24784499 : ℝ) / 100000000)) (hi := ((-12392249 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19512023 : ℝ) / 50000000) = Real.log ((19512023 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19512023 : ℝ) / 50000000) = ((19512023 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1664 : RB (Real.log ((199318857 : ℝ) / 50000000)) ((138288283 : ℝ) / 100000000) ((69144143 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((199318857 : ℝ) / 200000000)) (t := ((-681143 : ℝ) / 399318857))
    (lo := ((-341153 : ℝ) / 100000000)) (hi := ((-10661 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((199318857 : ℝ) / 50000000) = Real.log ((199318857 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((199318857 : ℝ) / 50000000) = ((199318857 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1665 : RB (Real.log ((398640647 : ℝ) / 100000000)) ((69144509 : ℝ) / 50000000) ((138289021 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((398640647 : ℝ) / 400000000)) (t := ((-1359353 : ℝ) / 798640647))
    (lo := ((-170209 : ℝ) / 50000000)) (hi := ((-340417 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((398640647 : ℝ) / 100000000) = Real.log ((398640647 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((398640647 : ℝ) / 100000000) = ((398640647 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1666 : RB (Real.log ((133460317 : ℝ) / 100000000)) ((28863399 : ℝ) / 100000000) ((28863401 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133460317 : ℝ) / 200000000)) (t := ((-66539683 : ℝ) / 333460317))
    (lo := ((-40451319 : ℝ) / 100000000)) (hi := ((-20225659 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133460317 : ℝ) / 100000000) = Real.log ((133460317 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133460317 : ℝ) / 100000000) = ((133460317 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1667 : RB (Real.log ((397322753 : ℝ) / 100000000)) ((68978937 : ℝ) / 50000000) ((137957877 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((397322753 : ℝ) / 400000000)) (t := ((-2677247 : ℝ) / 797322753))
    (lo := ((-335781 : ℝ) / 50000000)) (hi := ((-671561 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((397322753 : ℝ) / 100000000) = Real.log ((397322753 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((397322753 : ℝ) / 100000000) = ((397322753 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1668 : RB (Real.log ((397325673 : ℝ) / 100000000)) ((137958609 : ℝ) / 100000000) ((34489653 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((397325673 : ℝ) / 400000000)) (t := ((-2674327 : ℝ) / 797325673))
    (lo := ((-670827 : ℝ) / 100000000)) (hi := ((-335413 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((397325673 : ℝ) / 100000000) = Real.log ((397325673 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((397325673 : ℝ) / 100000000) = ((397325673 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1669 : RB (Real.log ((133608301 : ℝ) / 100000000)) ((1448711 : ℝ) / 5000000) ((14487111 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((133608301 : ℝ) / 200000000)) (t := ((-66391699 : ℝ) / 333608301))
    (lo := ((-20170249 : ℝ) / 50000000)) (hi := ((-40340497 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133608301 : ℝ) / 100000000) = Real.log ((133608301 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133608301 : ℝ) / 100000000) = ((133608301 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1670 : RB (Real.log ((6544869 : ℝ) / 50000000)) ((-40666833 : ℝ) / 20000000) ((-203334161 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6544869 : ℝ) / 6250000)) (t := ((294869 : ℝ) / 12794869))
    (lo := ((576249 : ℝ) / 12500000)) (hi := ((4609993 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6544869 : ℝ) / 50000000) = Real.log ((6544869 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6544869 : ℝ) / 50000000) = ((6544869 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1671 : RB (Real.log ((13878157 : ℝ) / 100000000)) ((-39497081 : ℝ) / 20000000) ((-197485401 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13878157 : ℝ) / 12500000)) (t := ((1378157 : ℝ) / 26378157))
    (lo := ((81709 : ℝ) / 781250)) (hi := ((10458753 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13878157 : ℝ) / 100000000) = Real.log ((13878157 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13878157 : ℝ) / 100000000) = ((13878157 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1672 : RB (Real.log ((5150931 : ℝ) / 100000000)) ((-11863971 : ℝ) / 4000000) ((-29659927 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((5150931 : ℝ) / 6250000)) (t := ((-1099069 : ℝ) / 11400931))
    (lo := ((-19340399 : ℝ) / 100000000)) (hi := ((-9670199 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5150931 : ℝ) / 100000000) = Real.log ((5150931 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5150931 : ℝ) / 100000000) = ((5150931 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1673 : RB (Real.log ((648347 : ℝ) / 12500000)) ((-1155882 : ℝ) / 390625) ((-295905787 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((648347 : ℝ) / 781250)) (t := ((-132903 : ℝ) / 1429597))
    (lo := ((-4661729 : ℝ) / 25000000)) (hi := ((-3729383 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((648347 : ℝ) / 12500000) = Real.log ((648347 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((648347 : ℝ) / 12500000) = ((648347 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1674 : RB (Real.log ((31534163 : ℝ) / 50000000)) ((-2880947 : ℝ) / 6250000) ((-921903 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((31534163 : ℝ) / 25000000)) (t := ((6534163 : ℝ) / 56534163))
    (lo := ((23219567 : ℝ) / 100000000)) (hi := ((1451223 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31534163 : ℝ) / 50000000) = Real.log ((31534163 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31534163 : ℝ) / 50000000) = ((31534163 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1675 : RB (Real.log ((31534969 : ℝ) / 50000000)) ((-11523149 : ℝ) / 25000000) ((-23046297 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((31534969 : ℝ) / 25000000)) (t := ((6534969 : ℝ) / 56534969))
    (lo := ((23222123 : ℝ) / 100000000)) (hi := ((5805531 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31534969 : ℝ) / 50000000) = Real.log ((31534969 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31534969 : ℝ) / 50000000) = ((31534969 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1676 : RB (Real.log ((38722533 : ℝ) / 100000000)) ((-23718713 : ℝ) / 25000000) ((-1897497 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((38722533 : ℝ) / 50000000)) (t := ((-11277467 : ℝ) / 88722533))
    (lo := ((-25560133 : ℝ) / 100000000)) (hi := ((-6390033 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38722533 : ℝ) / 100000000) = Real.log ((38722533 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38722533 : ℝ) / 100000000) = ((38722533 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1677 : RB (Real.log ((189421927 : ℝ) / 100000000)) ((2555227 : ℝ) / 4000000) ((63880677 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((189421927 : ℝ) / 200000000)) (t := ((-10578073 : ℝ) / 389421927))
    (lo := ((-5434043 : ℝ) / 100000000)) (hi := ((-2717021 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189421927 : ℝ) / 100000000) = Real.log ((189421927 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189421927 : ℝ) / 100000000) = ((189421927 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1678 : RB (Real.log ((94744103 : ℝ) / 50000000)) ((63915659 : ℝ) / 100000000) ((63915661 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((94744103 : ℝ) / 100000000)) (t := ((-5255897 : ℝ) / 194744103))
    (lo := ((-5399059 : ℝ) / 100000000)) (hi := ((-2699529 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94744103 : ℝ) / 50000000) = Real.log ((94744103 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94744103 : ℝ) / 50000000) = ((94744103 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1679 : RB (Real.log ((63790077 : ℝ) / 100000000)) ((-5619657 : ℝ) / 12500000) ((-22478627 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((63790077 : ℝ) / 50000000)) (t := ((13790077 : ℝ) / 113790077))
    (lo := ((24357463 : ℝ) / 100000000)) (hi := ((3044683 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63790077 : ℝ) / 100000000) = Real.log ((63790077 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63790077 : ℝ) / 100000000) = ((63790077 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
