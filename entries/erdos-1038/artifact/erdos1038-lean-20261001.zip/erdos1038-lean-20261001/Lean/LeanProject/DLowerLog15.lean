import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog12
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_900 : RB (Real.log ((1123604042969 : ℝ) / 1000000000000)) ((116541414469 : ℝ) / 1000000000000) ((11654141447 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((1123604042969 : ℝ) / 1000000000000)) (t := ((123604042969 : ℝ) / 2123604042969))
    (lo := ((116541414469 : ℝ) / 1000000000000)) (hi := ((11654141447 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_901 : RB (Real.log ((12359505371 : ℝ) / 100000000000)) ((-2090744753287 : ℝ) / 1000000000000) ((-418148950657 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((12359505371 : ℝ) / 12500000000)) (t := ((-140494629 : ℝ) / 24859505371))
    (lo := ((-11303211607 : ℝ) / 1000000000000)) (hi := ((-5651605803 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12359505371 : ℝ) / 100000000000) = Real.log ((12359505371 : ℝ) / 12500000000) - 3 * Real.log 2 := by
    rw [show ((12359505371 : ℝ) / 100000000000) = ((12359505371 : ℝ) / 12500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_902 : RB (Real.log ((123604042969 : ℝ) / 1000000000000)) ((-2090672024389 : ℝ) / 1000000000000) ((-2090672024387 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123604042969 : ℝ) / 125000000000)) (t := ((-1395957031 : ℝ) / 248604042969))
    (lo := ((-11230482709 : ℝ) / 1000000000000)) (hi := ((-2807620677 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123604042969 : ℝ) / 1000000000000) = Real.log ((123604042969 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123604042969 : ℝ) / 1000000000000) = ((123604042969 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_903 : RB (Real.log ((10639170177 : ℝ) / 40000000000)) ((-662168482063 : ℝ) / 500000000000) ((-331084241031 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((10639170177 : ℝ) / 10000000000)) (t := ((639170177 : ℝ) / 20639170177))
    (lo := ((30978698497 : ℝ) / 500000000000)) (hi := ((12391479399 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10639170177 : ℝ) / 40000000000) = Real.log ((10639170177 : ℝ) / 10000000000) - 2 * Real.log 2 := by
    rw [show ((10639170177 : ℝ) / 40000000000) = ((10639170177 : ℝ) / 10000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_904 : RB (Real.log ((265982111253 : ℝ) / 1000000000000)) ((-1324326223391 : ℝ) / 1000000000000) ((-1324326223389 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((265982111253 : ℝ) / 250000000000)) (t := ((15982111253 : ℝ) / 515982111253))
    (lo := ((61968137729 : ℝ) / 1000000000000)) (hi := ((6196813773 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((265982111253 : ℝ) / 1000000000000) = Real.log ((265982111253 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((265982111253 : ℝ) / 1000000000000) = ((265982111253 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_905 : RB (Real.log ((8886629473 : ℝ) / 40000000000)) ((-12034652907 : ℝ) / 8000000000) ((-1504331613373 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((8886629473 : ℝ) / 10000000000)) (t := ((-1113370527 : ℝ) / 18886629473))
    (lo := ((-23607450451 : ℝ) / 200000000000)) (hi := ((-59018626127 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8886629473 : ℝ) / 40000000000) = Real.log ((8886629473 : ℝ) / 10000000000) - 2 * Real.log 2 := by
    rw [show ((8886629473 : ℝ) / 40000000000) = ((8886629473 : ℝ) / 10000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_906 : RB (Real.log ((3008569475179 : ℝ) / 1000000000000)) ((1101464708373 : ℝ) / 1000000000000) ((8811717667 : ℝ) / 8000000000) := by
  have hm := log_bounds_of_series (x := ((3008569475179 : ℝ) / 4000000000000)) (t := ((-991430524821 : ℝ) / 7008569475179))
    (lo := ((-142414826373 : ℝ) / 500000000000)) (hi := ((-56965930549 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008569475179 : ℝ) / 1000000000000) = Real.log ((3008569475179 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008569475179 : ℝ) / 1000000000000) = ((3008569475179 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_907 : RB (Real.log ((1504287003873 : ℝ) / 500000000000)) ((275366553731 : ℝ) / 250000000000) ((550733107463 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1504287003873 : ℝ) / 2000000000000)) (t := ((-495712996127 : ℝ) / 3504287003873))
    (lo := ((-56965629239 : ℝ) / 200000000000)) (hi := ((-142414073097 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1504287003873 : ℝ) / 500000000000) = Real.log ((1504287003873 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1504287003873 : ℝ) / 500000000000) = ((1504287003873 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_908 : RB (Real.log ((372565095797 : ℝ) / 250000000000)) ((199475429253 : ℝ) / 500000000000) ((99737714627 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((372565095797 : ℝ) / 500000000000)) (t := ((-127434904203 : ℝ) / 872565095797))
    (lo := ((-294196322053 : ℝ) / 1000000000000)) (hi := ((-73549080513 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((372565095797 : ℝ) / 250000000000) = Real.log ((372565095797 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((372565095797 : ℝ) / 250000000000) = ((372565095797 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_909 : RB (Real.log ((140450505371 : ℝ) / 125000000000)) ((29135353617 : ℝ) / 250000000000) ((116541414469 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((140450505371 : ℝ) / 125000000000)) (t := ((15450505371 : ℝ) / 265450505371))
    (lo := ((29135353617 : ℝ) / 250000000000)) (hi := ((116541414469 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_910 : RB (Real.log ((1123613032227 : ℝ) / 1000000000000)) ((3642169213 : ℝ) / 31250000000) ((116549414817 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1123613032227 : ℝ) / 1000000000000)) (t := ((123613032227 : ℝ) / 2123613032227))
    (lo := ((3642169213 : ℝ) / 31250000000)) (hi := ((116549414817 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_911 : RB (Real.log ((15450505371 : ℝ) / 125000000000)) ((-2090672024397 : ℝ) / 1000000000000) ((-418134404879 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((15450505371 : ℝ) / 15625000000)) (t := ((-174494629 : ℝ) / 31075505371))
    (lo := ((-11230482717 : ℝ) / 1000000000000)) (hi := ((-2807620679 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15450505371 : ℝ) / 125000000000) = Real.log ((15450505371 : ℝ) / 15625000000) - 3 * Real.log 2 := by
    rw [show ((15450505371 : ℝ) / 125000000000) = ((15450505371 : ℝ) / 15625000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_912 : RB (Real.log ((123613032227 : ℝ) / 1000000000000)) ((-522649825197 : ℝ) / 250000000000) ((-1045299650393 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((123613032227 : ℝ) / 125000000000)) (t := ((-1386967773 : ℝ) / 248613032227))
    (lo := ((-2789439777 : ℝ) / 250000000000)) (hi := ((-11157759107 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123613032227 : ℝ) / 1000000000000) = Real.log ((123613032227 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123613032227 : ℝ) / 1000000000000) = ((123613032227 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_913 : RB (Real.log ((265404332023 : ℝ) / 1000000000000)) ((-1326500834599 : ℝ) / 1000000000000) ((-1326500834597 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((265404332023 : ℝ) / 250000000000)) (t := ((15404332023 : ℝ) / 515404332023))
    (lo := ((59793526521 : ℝ) / 1000000000000)) (hi := ((29896763261 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((265404332023 : ℝ) / 1000000000000) = Real.log ((265404332023 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((265404332023 : ℝ) / 1000000000000) = ((265404332023 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_914 : RB (Real.log ((33175898471 : ℝ) / 125000000000)) ((-663245037339 : ℝ) / 500000000000) ((-331622518669 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((33175898471 : ℝ) / 31250000000)) (t := ((1925898471 : ℝ) / 64425898471))
    (lo := ((29902143221 : ℝ) / 500000000000)) (hi := ((59804286443 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33175898471 : ℝ) / 125000000000) = Real.log ((33175898471 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((33175898471 : ℝ) / 125000000000) = ((33175898471 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_915 : RB (Real.log ((27726761583 : ℝ) / 125000000000)) ((-12047325347 : ℝ) / 8000000000) ((-1505915668373 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((27726761583 : ℝ) / 31250000000)) (t := ((-3523238417 : ℝ) / 58976761583))
    (lo := ((-23924261451 : ℝ) / 200000000000)) (hi := ((-59810653627 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((27726761583 : ℝ) / 125000000000) = Real.log ((27726761583 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((27726761583 : ℝ) / 125000000000) = ((27726761583 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_916 : RB (Real.log ((1504264949517 : ℝ) / 500000000000)) ((550725776907 : ℝ) / 500000000000) ((137681444227 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((1504264949517 : ℝ) / 2000000000000)) (t := ((-495735050483 : ℝ) / 3504264949517))
    (lo := ((-56968561461 : ℝ) / 200000000000)) (hi := ((-35605350913 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1504264949517 : ℝ) / 500000000000) = Real.log ((1504264949517 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1504264949517 : ℝ) / 500000000000) = ((1504264949517 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_917 : RB (Real.log ((3008534431851 : ℝ) / 1000000000000)) ((275363265117 : ℝ) / 250000000000) ((110145306047 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((3008534431851 : ℝ) / 4000000000000)) (t := ((-991465568149 : ℝ) / 7008534431851))
    (lo := ((-284841300651 : ℝ) / 1000000000000)) (hi := ((-5696826013 : ℝ) / 20000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008534431851 : ℝ) / 1000000000000) = Real.log ((3008534431851 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008534431851 : ℝ) / 1000000000000) = ((3008534431851 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_918 : RB (Real.log ((745134468433 : ℝ) / 500000000000)) ((39895659821 : ℝ) / 100000000000) ((99739149553 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((745134468433 : ℝ) / 1000000000000)) (t := ((-254865531567 : ℝ) / 1745134468433))
    (lo := ((-294190582349 : ℝ) / 1000000000000)) (hi := ((-73547645587 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((745134468433 : ℝ) / 500000000000) = Real.log ((745134468433 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((745134468433 : ℝ) / 500000000000) = ((745134468433 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_919 : RB (Real.log ((561806516113 : ℝ) / 500000000000)) ((23309882963 : ℝ) / 200000000000) ((3642169213 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((561806516113 : ℝ) / 500000000000)) (t := ((61806516113 : ℝ) / 1061806516113))
    (lo := ((23309882963 : ℝ) / 200000000000)) (hi := ((3642169213 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_920 : RB (Real.log ((224724404297 : ℝ) / 200000000000)) ((116557415099 : ℝ) / 1000000000000) ((1165574151 : ℝ) / 10000000000) := by
  have hm := log_bounds_of_series (x := ((224724404297 : ℝ) / 200000000000)) (t := ((24724404297 : ℝ) / 424724404297))
    (lo := ((116557415099 : ℝ) / 1000000000000)) (hi := ((1165574151 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_921 : RB (Real.log ((61806516113 : ℝ) / 500000000000)) ((-522649825199 : ℝ) / 250000000000) ((-1045299650397 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((61806516113 : ℝ) / 62500000000)) (t := ((-693483887 : ℝ) / 124306516113))
    (lo := ((-2789439779 : ℝ) / 250000000000)) (hi := ((-2231551823 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61806516113 : ℝ) / 500000000000) = Real.log ((61806516113 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61806516113 : ℝ) / 500000000000) = ((61806516113 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_922 : RB (Real.log ((24724404297 : ℝ) / 200000000000)) ((-83621063299 : ℝ) / 40000000000) ((-2090526582473 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((24724404297 : ℝ) / 25000000000)) (t := ((-275595703 : ℝ) / 49724404297))
    (lo := ((-2217008159 : ℝ) / 200000000000)) (hi := ((-5542520397 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24724404297 : ℝ) / 200000000000) = Real.log ((24724404297 : ℝ) / 25000000000) - 3 * Real.log 2 := by
    rw [show ((24724404297 : ℝ) / 200000000000) = ((24724404297 : ℝ) / 25000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_923 : RB (Real.log ((264728085629 : ℝ) / 1000000000000)) ((-265810414351 : ℝ) / 200000000000) ((-1329052071753 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((264728085629 : ℝ) / 250000000000)) (t := ((14728085629 : ℝ) / 514728085629))
    (lo := ((11448457873 : ℝ) / 200000000000)) (hi := ((28621144683 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((264728085629 : ℝ) / 1000000000000) = Real.log ((264728085629 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((264728085629 : ℝ) / 1000000000000) = ((264728085629 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_924 : RB (Real.log ((264730940061 : ℝ) / 1000000000000)) ((-332260322327 : ℝ) / 250000000000) ((-664520644653 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((264730940061 : ℝ) / 250000000000)) (t := ((14730940061 : ℝ) / 514730940061))
    (lo := ((14313267953 : ℝ) / 250000000000)) (hi := ((57253071813 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((264730940061 : ℝ) / 1000000000000) = Real.log ((264730940061 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((264730940061 : ℝ) / 1000000000000) = ((264730940061 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_925 : RB (Real.log ((221399756207 : ℝ) / 1000000000000)) ((-376946339963 : ℝ) / 250000000000) ((-30155707197 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((221399756207 : ℝ) / 250000000000)) (t := ((-28600243793 : ℝ) / 471399756207))
    (lo := ((-30372749683 : ℝ) / 250000000000)) (hi := ((-121490998731 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((221399756207 : ℝ) / 1000000000000) = Real.log ((221399756207 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((221399756207 : ℝ) / 1000000000000) = ((221399756207 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_926 : RB (Real.log ((60169806451 : ℝ) / 20000000000)) ((1101438398969 : ℝ) / 1000000000000) ((1101438398971 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((60169806451 : ℝ) / 80000000000)) (t := ((-19830193549 : ℝ) / 140169806451))
    (lo := ((-5697119243 : ℝ) / 20000000000)) (hi := ((-284855962149 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((60169806451 : ℝ) / 20000000000) = Real.log ((60169806451 : ℝ) / 80000000000) + 2 * Real.log 2 := by
    rw [show ((60169806451 : ℝ) / 20000000000) = ((60169806451 : ℝ) / 80000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_927 : RB (Real.log ((3008494855619 : ℝ) / 1000000000000)) ((1101439905727 : ℝ) / 1000000000000) ((1101439905729 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3008494855619 : ℝ) / 4000000000000)) (t := ((-991505144381 : ℝ) / 7008494855619))
    (lo := ((-8901701731 : ℝ) / 31250000000)) (hi := ((-284854455391 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008494855619 : ℝ) / 1000000000000) = Real.log ((3008494855619 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008494855619 : ℝ) / 1000000000000) = ((3008494855619 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_928 : RB (Real.log ((1490277490883 : ℝ) / 1000000000000)) ((99740584527 : ℝ) / 250000000000) ((39896233811 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((1490277490883 : ℝ) / 2000000000000)) (t := ((-509722509117 : ℝ) / 3490277490883))
    (lo := ((-294184842451 : ℝ) / 1000000000000)) (hi := ((-5883696849 : ℝ) / 20000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1490277490883 : ℝ) / 1000000000000) = Real.log ((1490277490883 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1490277490883 : ℝ) / 1000000000000) = ((1490277490883 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_929 : RB (Real.log ((280905505371 : ℝ) / 250000000000)) ((58278707549 : ℝ) / 500000000000) ((116557415099 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((280905505371 : ℝ) / 250000000000)) (t := ((30905505371 : ℝ) / 530905505371))
    (lo := ((58278707549 : ℝ) / 500000000000)) (hi := ((116557415099 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_930 : RB (Real.log ((1123631010743 : ℝ) / 1000000000000)) ((116565415317 : ℝ) / 1000000000000) ((58282707659 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1123631010743 : ℝ) / 1000000000000)) (t := ((123631010743 : ℝ) / 2123631010743))
    (lo := ((116565415317 : ℝ) / 1000000000000)) (hi := ((58282707659 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_931 : RB (Real.log ((30905505371 : ℝ) / 250000000000)) ((-2090526582483 : ℝ) / 1000000000000) ((-2090526582481 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((30905505371 : ℝ) / 31250000000)) (t := ((-344494629 : ℝ) / 62155505371))
    (lo := ((-11085040803 : ℝ) / 1000000000000)) (hi := ((-5542520401 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((30905505371 : ℝ) / 250000000000) = Real.log ((30905505371 : ℝ) / 31250000000) - 3 * Real.log 2 := by
    rw [show ((30905505371 : ℝ) / 250000000000) = ((30905505371 : ℝ) / 31250000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_932 : RB (Real.log ((123631010743 : ℝ) / 1000000000000)) ((-2090453869449 : ℝ) / 1000000000000) ((-2090453869447 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123631010743 : ℝ) / 125000000000)) (t := ((-1368989257 : ℝ) / 248631010743))
    (lo := ((-11012327769 : ℝ) / 1000000000000)) (hi := ((-1376540971 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123631010743 : ℝ) / 1000000000000) = Real.log ((123631010743 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123631010743 : ℝ) / 1000000000000) = ((123631010743 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_933 : RB (Real.log ((65963437947 : ℝ) / 250000000000)) ((-266472059967 : ℝ) / 200000000000) ((-1332360299833 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((65963437947 : ℝ) / 62500000000)) (t := ((3463437947 : ℝ) / 128463437947))
    (lo := ((10786812257 : ℝ) / 200000000000)) (hi := ((26967030643 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65963437947 : ℝ) / 250000000000) = Real.log ((65963437947 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((65963437947 : ℝ) / 250000000000) = ((65963437947 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_934 : RB (Real.log ((263856604461 : ℝ) / 1000000000000)) ((-333087372081 : ℝ) / 250000000000) ((-666174744161 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((263856604461 : ℝ) / 250000000000)) (t := ((13856604461 : ℝ) / 513856604461))
    (lo := ((13486218199 : ℝ) / 250000000000)) (hi := ((53944872797 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((263856604461 : ℝ) / 1000000000000) = Real.log ((263856604461 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((263856604461 : ℝ) / 1000000000000) = ((263856604461 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_935 : RB (Real.log ((110431439639 : ℝ) / 500000000000)) ((-1510213225783 : ℝ) / 1000000000000) ((-1510213225781 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((110431439639 : ℝ) / 125000000000)) (t := ((-14568560361 : ℝ) / 235431439639))
    (lo := ((-123918864663 : ℝ) / 1000000000000)) (hi := ((-61959432331 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((110431439639 : ℝ) / 500000000000) = Real.log ((110431439639 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((110431439639 : ℝ) / 500000000000) = ((110431439639 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_936 : RB (Real.log ((3008450745731 : ℝ) / 1000000000000)) ((3441953887 : ℝ) / 3125000000) ((550712621921 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3008450745731 : ℝ) / 4000000000000)) (t := ((-991549254269 : ℝ) / 7008450745731))
    (lo := ((-284869117279 : ℝ) / 1000000000000)) (hi := ((-142434558639 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008450745731 : ℝ) / 1000000000000) = Real.log ((3008450745731 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008450745731 : ℝ) / 1000000000000) = ((3008450745731 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_937 : RB (Real.log ((3008455279051 : ℝ) / 1000000000000)) ((1101426750701 : ℝ) / 1000000000000) ((1101426750703 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3008455279051 : ℝ) / 4000000000000)) (t := ((-991544720949 : ℝ) / 7008455279051))
    (lo := ((-142433805209 : ℝ) / 500000000000)) (hi := ((-284867610417 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008455279051 : ℝ) / 1000000000000) = Real.log ((3008455279051 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008455279051 : ℝ) / 1000000000000) = ((3008455279051 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_938 : RB (Real.log ((1490286045239 : ℝ) / 1000000000000)) ((398968078201 : ℝ) / 1000000000000) ((398968078203 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1490286045239 : ℝ) / 2000000000000)) (t := ((-509713954761 : ℝ) / 3490286045239))
    (lo := ((-147089551179 : ℝ) / 500000000000)) (hi := ((-294179102357 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1490286045239 : ℝ) / 1000000000000) = Real.log ((1490286045239 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1490286045239 : ℝ) / 1000000000000) = ((1490286045239 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_939 : RB (Real.log ((561815505371 : ℝ) / 500000000000)) ((116565415317 : ℝ) / 1000000000000) ((58282707659 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((561815505371 : ℝ) / 500000000000)) (t := ((61815505371 : ℝ) / 1061815505371))
    (lo := ((116565415317 : ℝ) / 1000000000000)) (hi := ((58282707659 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_940 : RB (Real.log ((28091 : ℝ) / 25000)) ((116573415471 : ℝ) / 1000000000000) ((7285838467 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((28091 : ℝ) / 25000)) (t := ((3091 : ℝ) / 53091))
    (lo := ((116573415471 : ℝ) / 1000000000000)) (hi := ((7285838467 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_941 : RB (Real.log ((61815505371 : ℝ) / 500000000000)) ((-2090453869457 : ℝ) / 1000000000000) ((-418090773891 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((61815505371 : ℝ) / 62500000000)) (t := ((-684494629 : ℝ) / 124315505371))
    (lo := ((-11012327777 : ℝ) / 1000000000000)) (hi := ((-344135243 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61815505371 : ℝ) / 500000000000) = Real.log ((61815505371 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61815505371 : ℝ) / 500000000000) = ((61815505371 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_942 : RB (Real.log ((3091 : ℝ) / 25000)) ((-2090381161719 : ℝ) / 1000000000000) ((-2090381161717 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3091 : ℝ) / 3125)) (t := ((-17 : ℝ) / 3108))
    (lo := ((-10939620039 : ℝ) / 1000000000000)) (hi := ((-5469810019 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3091 : ℝ) / 25000) = Real.log ((3091 : ℝ) / 3125) - 3 * Real.log 2 := by
    rw [show ((3091 : ℝ) / 25000) = ((3091 : ℝ) / 3125) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_943 : RB (Real.log ((130934524469 : ℝ) / 500000000000)) ((-167488839173 : ℝ) / 125000000000) ((-669955356691 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((130934524469 : ℝ) / 125000000000)) (t := ((5934524469 : ℝ) / 255934524469))
    (lo := ((5797955967 : ℝ) / 125000000000)) (hi := ((46383647737 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((130934524469 : ℝ) / 500000000000) = Real.log ((130934524469 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((130934524469 : ℝ) / 500000000000) = ((130934524469 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_944 : RB (Real.log ((261871897343 : ℝ) / 1000000000000)) ((-1339899836231 : ℝ) / 1000000000000) ((-1339899836229 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((261871897343 : ℝ) / 250000000000)) (t := ((11871897343 : ℝ) / 511871897343))
    (lo := ((46394524889 : ℝ) / 1000000000000)) (hi := ((4639452489 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((261871897343 : ℝ) / 1000000000000) = Real.log ((261871897343 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((261871897343 : ℝ) / 1000000000000) = ((261871897343 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_945 : RB (Real.log ((109819596087 : ℝ) / 500000000000)) ((-757884557267 : ℝ) / 500000000000) ((-378942278633 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((109819596087 : ℝ) / 125000000000)) (t := ((-15180403913 : ℝ) / 234819596087))
    (lo := ((-64737376707 : ℝ) / 500000000000)) (hi := ((-129474753413 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((109819596087 : ℝ) / 500000000000) = Real.log ((109819596087 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((109819596087 : ℝ) / 500000000000) = ((109819596087 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_946 : RB (Real.log ((752102792143 : ℝ) / 250000000000)) ((137676511053 : ℝ) / 125000000000) ((550706044213 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((752102792143 : ℝ) / 1000000000000)) (t := ((-247897207857 : ℝ) / 1752102792143))
    (lo := ((-56976454539 : ℝ) / 200000000000)) (hi := ((-142441136347 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((752102792143 : ℝ) / 250000000000) = Real.log ((752102792143 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((752102792143 : ℝ) / 250000000000) = ((752102792143 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_947 : RB (Real.log ((3008415702139 : ℝ) / 1000000000000)) ((1101413595387 : ℝ) / 1000000000000) ((1101413595389 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3008415702139 : ℝ) / 4000000000000)) (t := ((-991584297861 : ℝ) / 7008415702139))
    (lo := ((-71220191433 : ℝ) / 250000000000)) (hi := ((-284880765731 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008415702139 : ℝ) / 1000000000000) = Real.log ((3008415702139 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008415702139 : ℝ) / 1000000000000) = ((3008415702139 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_948 : RB (Real.log ((298058919987 : ℝ) / 200000000000)) ((398973818489 : ℝ) / 1000000000000) ((398973818491 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((298058919987 : ℝ) / 400000000000)) (t := ((-101941080013 : ℝ) / 698058919987))
    (lo := ((-29417336207 : ℝ) / 100000000000)) (hi := ((-294173362069 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((298058919987 : ℝ) / 200000000000) = Real.log ((298058919987 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((298058919987 : ℝ) / 200000000000) = ((298058919987 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
