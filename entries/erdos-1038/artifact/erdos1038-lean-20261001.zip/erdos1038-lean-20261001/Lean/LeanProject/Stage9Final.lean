import LeanProject.Stage9D4

/-!
# EP-1038, Stage 9: Theorem 9.4 in polynomial language, and `√2 ≤ D`

* `inf_le_D_poly`: for every `ε > 0` there is a monic real polynomial of degree `≥ 1`, split over `ℝ`,
  with all roots in `[-1, 1]` and `|{x : |f(x)| < 1}| < D + ε` (Theorem 9.4 via `Stage7.bridge_vec`).
* `sqrt2_le_Dval`: combined with the elementary lower bound `Atom.sqrt2_le`, `√2 ≤ D`
  (a consistency check that the infimum in `iInf_le_D` is not trivial; Lean RED L-248/L-249).
-/

open Real Set Filter Topology MeasureTheory
open scoped ENNReal

namespace EP1038.Stage9

/-- **Theorem 9.4**, polynomial form: `inf_{f ∈ 𝒫} |S_f| ≤ D`. -/
theorem inf_le_D_poly {ε : ℝ} (hε : 0 < ε) :
    ∃ p : Polynomial ℝ, p.Monic ∧ 1 ≤ p.natDegree ∧ Multiset.card p.roots = p.natDegree ∧
      (∀ x ∈ p.roots, x ∈ Icc (-1 : ℝ) 1) ∧
      volume {x : ℝ | |p.eval x| < 1} < ENNReal.ofReal (Dval + ε) := by
  obtain ⟨n, r, hn, hr, hv⟩ := inf_le_D hε
  obtain ⟨h1, h2, h3, h4, h5⟩ := EP1038.Stage7.bridge_vec hn r hr
  exact ⟨_, h1, h2, h3, h4, by rw [h5]; exact hv⟩

/-- `√2 ≤ D`. -/
theorem sqrt2_le_Dval : √2 ≤ Dval := by
  have h1 : ENNReal.ofReal √2 ≤
      (⨅ (n : ℕ) (_ : 0 < n) (r : Fin n → ℝ) (_ : ∀ i, r i ∈ Icc (-1 : ℝ) 1),
        volume (sublevel r)) :=
    le_iInf fun n => le_iInf fun hn => le_iInf fun r => le_iInf fun hr =>
      EP1038.Atom.sqrt2_le hn r hr
  exact (ENNReal.ofReal_le_ofReal_iff Dval_nonneg).mp (h1.trans iInf_le_D)

end EP1038.Stage9
