import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk03
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_8 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((31476198227647681 : ℝ) / 576460752303423488) ((143249791252286871785603433968435 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((54602499999 : ℝ) / 1000000000000) ((176569 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1054602499999 : ℝ) / 1000000000000) ((3376569 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((53163918677 : ℝ) / 1000000000000) ((53709295381 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_239.1 dlower_log_240.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((53163918677 : ℝ) / 500000000000) ((53709295381 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((585728589797 : ℝ) / 1000000000000) ((293409671603 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2907675609753 : ℝ) / 1000000000000) ((-724298588491 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_241.1 dlower_log_242.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((724298588491 : ℝ) / 250000000000) ((2907675609753 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((100721103109 : ℝ) / 500000000000) ((202547455059 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((797452544941 : ℝ) / 1000000000000) ((399278896891 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1490716503 : ℝ) / 500000000000) ((3044590993 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((403164904703 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((40012031371 : ℝ) / 100000000000) ((400183471697 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((403164904703 : ℝ) / 1000000000000) ((403164904703 : ℝ) / 1000000000000) ((403164904703 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((596835095297 : ℝ) / 1000000000000))
  have h11 : RB z11 ((134080692259 : ℝ) / 200000000000) ((1676273207 : ℝ) / 2500000000) := rb_div_signed h10 (show RB ((596835095297 : ℝ) / 1000000000000) ((596835095297 : ℝ) / 1000000000000) ((596835095297 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-399875566801 : ℝ) / 1000000000000) ((-4996471647 : ℝ) / 12500000000) := rb_log h11 (by norm_num) dlower_log_243.1 dlower_log_244.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-79830937603 : ℝ) / 250000000000) ((-6375118449 : ℝ) / 20000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((403164904703 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-908409607921 : ℝ) / 1000000000000) ((-908409607919 : ℝ) / 1000000000000) := rb_log (show RB ((403164904703 : ℝ) / 1000000000000) ((403164904703 : ℝ) / 1000000000000) ((403164904703 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_245.1 dlower_log_245.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((589085857507 : ℝ) / 1000000000000) ((589653685471 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2266514301 : ℝ) / 1000000000000) ((1962547837 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1490716503 : ℝ) / 500000000000) ((3044590993 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((358670849103 : ℝ) / 250000000000)) - (z17)
  have h18 : RB z18 ((1431638805419 : ℝ) / 1000000000000) ((715850981703 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((358670849103 : ℝ) / 250000000000) ((358670849103 : ℝ) / 250000000000) ((358670849103 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((108670849103 : ℝ) / 250000000000))
  have h19 : RB z19 ((1646760397609 : ℝ) / 500000000000) ((102927065367 : ℝ) / 31250000000) := rb_div_signed h18 (show RB ((108670849103 : ℝ) / 250000000000) ((108670849103 : ℝ) / 250000000000) ((108670849103 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((238391428619 : ℝ) / 200000000000) ((1192001257991 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_246.1 dlower_log_247.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((950529257221 : ℝ) / 1000000000000) ((951881894767 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((358670849103 : ℝ) / 250000000000))
  have h22 : RB z22 ((36094419519 : ℝ) / 100000000000) ((45118024399 : ℝ) / 125000000000) := rb_log (show RB ((358670849103 : ℝ) / 250000000000) ((358670849103 : ℝ) / 250000000000) ((358670849103 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_248.1 dlower_log_248.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((589585062029 : ℝ) / 1000000000000) ((590937699577 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2765718823 : ℝ) / 1000000000000) ((260455489 : ℝ) / 50000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1054602499999 : ℝ) / 1000000000000) ((3376569 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((278046608251 : ℝ) / 250000000000) ((1113400215993 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((359259854861 : ℝ) / 200000000000) ((899129831407 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1031518491709 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1852915918089 : ℝ) / 1000000000000) ((115933630943 : ℝ) / 62500000000) := rb_widen (rb_mul h27 (show RB ((1031518491709 : ℝ) / 1000000000000) ((1031518491709 : ℝ) / 1000000000000) ((1031518491709 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1490716503 : ℝ) / 500000000000) ((3044590993 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((144603498698355088031409 : ℝ) / 250000000000000000000000))
  have h30 : RB z30 ((5154496663 : ℝ) / 1000000000000) ((657961041 : ℝ) / 125000000000) := rb_div_signed h29 (show RB ((144603498698355088031409 : ℝ) / 250000000000000000000000) ((144603498698355088031409 : ℝ) / 250000000000000000000000) ((144603498698355088031409 : ℝ) / 250000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((124342038959 : ℝ) / 125000000000) ((994845503337 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((921581373099 : ℝ) / 500000000000) ((1845376822867 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((403164904703 : ℝ) / 1000000000000)) ((2266514301 : ℝ) / 1000000000000) ((1962547837 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((358670849103 : ℝ) / 250000000000)) ((2765718823 : ℝ) / 1000000000000) ((260455489 : ℝ) / 50000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((403164904703 : ℝ) / 1000000000000)) (wl := ((358670849103 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((921581373099 : ℝ) / 500000000000) ≤ D0q (q) * (((358670849103 : ℝ) / 250000000000) - ((403164904703 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((358670849103 : ℝ) / 250000000000) * ((403164904703 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_9 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((143249791252286871785603433968435 : ℝ) / 2596148429267413814265248164610048) ((72371693947749890396820662858547 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((55177812499 : ℝ) / 1000000000000) ((17841 : ℝ) / 320000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1055177812499 : ℝ) / 1000000000000) ((337841 : ℝ) / 320000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((53709295379 : ℝ) / 1000000000000) ((54254374809 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_249.1 dlower_log_250.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((53709295379 : ℝ) / 500000000000) ((54254374809 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((584638430941 : ℝ) / 1000000000000) ((292864294901 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-45268661781 : ℝ) / 15625000000) ((-7217054541 : ℝ) / 2500000000) := rb_log hqr (by norm_num) dlower_log_251.1 dlower_log_252.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((7217054541 : ℝ) / 2500000000) ((45268661781 : ℝ) / 15625000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((20179468807 : ℝ) / 100000000000) ((202897382331 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((797102617669 : ℝ) / 1000000000000) ((79820531193 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((190286937 : ℝ) / 62500000000) ((777102737 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((50234065179 : ℝ) / 125000000000)) - (z9)
  have h10 : RB z10 ((99691027621 : ℝ) / 250000000000) ((9970698261 : ℝ) / 25000000000) := rb_widen (rb_sub (show RB ((50234065179 : ℝ) / 125000000000) ((50234065179 : ℝ) / 125000000000) ((50234065179 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((74765934821 : ℝ) / 125000000000))
  have h11 : RB z11 ((333343747589 : ℝ) / 500000000000) ((41674637173 : ℝ) / 62500000000) := rb_div_signed h10 (show RB ((74765934821 : ℝ) / 125000000000) ((74765934821 : ℝ) / 125000000000) ((74765934821 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-50679233229 : ℝ) / 125000000000) ((-405273834247 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_253.1 dlower_log_254.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-2528277073 : ℝ) / 7812500000) ((-323044834151 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((50234065179 : ℝ) / 125000000000))
  have h14 : RB z14 ((-5697627197 : ℝ) / 6250000000) ((-455810175759 : ℝ) / 500000000000) := rb_log (show RB ((50234065179 : ℝ) / 125000000000) ((50234065179 : ℝ) / 125000000000) ((50234065179 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_255.1 dlower_log_255.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((294000443087 : ℝ) / 500000000000) ((588575517369 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((568074093 : ℝ) / 250000000000) ((984271607 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((190286937 : ℝ) / 62500000000) ((777102737 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((717503742319 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((143189907369 : ℝ) / 100000000000) ((715981446823 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((717503742319 : ℝ) / 500000000000) ((717503742319 : ℝ) / 500000000000) ((717503742319 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((217503742319 : ℝ) / 500000000000))
  have h19 : RB z19 ((822916342969 : ℝ) / 250000000000) ((658362416379 : ℝ) / 200000000000) := rb_div_signed h18 (show RB ((217503742319 : ℝ) / 500000000000) ((217503742319 : ℝ) / 500000000000) ((217503742319 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1191393628763 : ℝ) / 1000000000000) ((595719098961 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_256.1 dlower_log_257.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((949662980161 : ℝ) / 1000000000000) ((475506149209 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((717503742319 : ℝ) / 500000000000))
  have h22 : RB z22 ((90292516243 : ℝ) / 250000000000) ((180585032487 : ℝ) / 500000000000) := rb_log (show RB ((717503742319 : ℝ) / 500000000000) ((717503742319 : ℝ) / 500000000000) ((717503742319 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_258.1 dlower_log_258.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((588492915187 : ℝ) / 1000000000000) ((294921116723 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((552865077 : ℝ) / 200000000000) ((1040760501 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1055177812499 : ℝ) / 1000000000000) ((337841 : ℝ) / 320000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((111340021599 : ℝ) / 100000000000) ((278653665237 : ℝ) / 250000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1794342089757 : ℝ) / 1000000000000) ((1796299274311 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((516567481603 : ℝ) / 500000000000))
  have h28 : RB z28 ((23172469361 : ℝ) / 12500000000) ((1855819584673 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((516567481603 : ℝ) / 500000000000) ((516567481603 : ℝ) / 500000000000) ((516567481603 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((190286937 : ℝ) / 62500000000) ((777102737 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((36043129757829066610101 : ℝ) / 62500000000000000000000))
  have h30 : RB z30 ((5279423243 : ℝ) / 1000000000000) ((1078017839 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((36043129757829066610101 : ℝ) / 62500000000000000000000) ((36043129757829066610101 : ℝ) / 62500000000000000000000) ((36043129757829066610101 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((198921982161 : ℝ) / 200000000000) ((994720576757 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((921902707371 : ℝ) / 500000000000) ((1846021927623 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((50234065179 : ℝ) / 125000000000)) ((568074093 : ℝ) / 250000000000) ((984271607 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((717503742319 : ℝ) / 500000000000)) ((552865077 : ℝ) / 200000000000) ((1040760501 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((50234065179 : ℝ) / 125000000000)) (wl := ((717503742319 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((921902707371 : ℝ) / 500000000000) ≤ D0q (q) * (((717503742319 : ℝ) / 500000000000) - ((50234065179 : ℝ) / 125000000000)) * (1 - (q) ^ 2 / (((717503742319 : ℝ) / 500000000000) * ((50234065179 : ℝ) / 125000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_10 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((72371693947749890396820662858547 : ℝ) / 1298074214633706907132624082305024) ((146236984538712689801679217465753 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((55753124999 : ℝ) / 1000000000000) ((180251 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1055753124999 : ℝ) / 1000000000000) ((3380251 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((54254374807 : ℝ) / 1000000000000) ((6849894661 : ℝ) / 125000000000) := rb_log h1 (by norm_num) dlower_log_259.1 dlower_log_260.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((54254374807 : ℝ) / 500000000000) ((6849894661 : ℝ) / 62500000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((583548865983 : ℝ) / 1000000000000) ((292319215473 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-144341090821 : ℝ) / 50000000000) ((-2876555764787 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_261.1 dlower_log_262.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2876555764787 : ℝ) / 1000000000000) ((144341090821 : ℝ) / 50000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((202142322281 : ℝ) / 1000000000000) ((50810628991 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((199189371009 : ℝ) / 250000000000) ((797857677719 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3108410947 : ℝ) / 1000000000000) ((396611609 : ℝ) / 125000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((400574447017 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((79480310829 : ℝ) / 200000000000) ((39746603607 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((400574447017 : ℝ) / 1000000000000) ((400574447017 : ℝ) / 1000000000000) ((400574447017 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((599425552983 : ℝ) / 1000000000000))
  have h11 : RB z11 ((662970659437 : ℝ) / 1000000000000) ((132615646461 : ℝ) / 200000000000) := rb_div_signed h10 (show RB ((599425552983 : ℝ) / 1000000000000) ((599425552983 : ℝ) / 1000000000000) ((599425552983 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-411024544019 : ℝ) / 1000000000000) ((-410862298313 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_263.1 dlower_log_264.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-327939088177 : ℝ) / 1000000000000) ((-327357611089 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((400574447017 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-914855644563 : ℝ) / 1000000000000) ((-914855644561 : ℝ) / 1000000000000) := rb_log (show RB ((400574447017 : ℝ) / 1000000000000) ((400574447017 : ℝ) / 1000000000000) ((400574447017 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_265.1 dlower_log_265.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((18341142387 : ℝ) / 31250000000) ((293749016737 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1139062719 : ℝ) / 500000000000) ((3949167491 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3108410947 : ℝ) / 1000000000000) ((396611609 : ℝ) / 125000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((71766720343 : ℝ) / 50000000000)) - (z17)
  have h18 : RB z18 ((358040378497 : ℝ) / 250000000000) ((1432225995913 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((71766720343 : ℝ) / 50000000000) ((71766720343 : ℝ) / 50000000000) ((71766720343 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((21766720343 : ℝ) / 50000000000))
  have h19 : RB z19 ((1644898142003 : ℝ) / 500000000000) ((3289944404449 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((21766720343 : ℝ) / 50000000000) ((21766720343 : ℝ) / 50000000000) ((21766720343 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((37213301347 : ℝ) / 31250000000) ((1190870666291 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_266.1 dlower_log_267.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((37951969733 : ℝ) / 40000000000) ((950145304271 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((71766720343 : ℝ) / 50000000000))
  have h22 : RB z22 ((361397858201 : ℝ) / 1000000000000) ((361397858203 : ℝ) / 1000000000000) := rb_log (show RB ((71766720343 : ℝ) / 50000000000) ((71766720343 : ℝ) / 50000000000) ((71766720343 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_268.1 dlower_log_268.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((293700692561 : ℝ) / 500000000000) ((58874744607 : ℝ) / 100000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((43171159 : ℝ) / 15625000000) ((5198580087 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1055753124999 : ℝ) / 1000000000000) ((3380251 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((222922932189 : ℝ) / 200000000000) ((17434840123 : ℝ) / 15625000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1792388102187 : ℝ) / 1000000000000) ((1794342089763 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1034759959843 : ℝ) / 1000000000000))
  have h28 : RB z28 ((927345720321 : ℝ) / 500000000000) ((464178337187 : ℝ) / 250000000000) := rb_widen (rb_mul h27 (show RB ((1034759959843 : ℝ) / 1000000000000) ((1034759959843 : ℝ) / 1000000000000) ((1034759959843 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3108410947 : ℝ) / 1000000000000) ((396611609 : ℝ) / 125000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((28747914315620909566831 : ℝ) / 50000000000000000000000))
  have h30 : RB z30 ((2703162143 : ℝ) / 500000000000) ((5518474901 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((28747914315620909566831 : ℝ) / 50000000000000000000000) ((28747914315620909566831 : ℝ) / 50000000000000000000000) ((28747914315620909566831 : ℝ) / 50000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((994481525099 : ℝ) / 1000000000000) ((497296837857 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1844456372477 : ℝ) / 1000000000000) ((1846675354279 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((400574447017 : ℝ) / 1000000000000)) ((1139062719 : ℝ) / 500000000000) ((3949167491 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((71766720343 : ℝ) / 50000000000)) ((43171159 : ℝ) / 15625000000) ((5198580087 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((400574447017 : ℝ) / 1000000000000)) (wl := ((71766720343 : ℝ) / 50000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1844456372477 : ℝ) / 1000000000000) ≤ D0q (q) * (((71766720343 : ℝ) / 50000000000) - ((400574447017 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((71766720343 : ℝ) / 50000000000) * ((400574447017 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_11 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((146236984538712689801679217465753 : ℝ) / 2596148429267413814265248164610048) ((295461162363851197619434218428825 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((56328437499 : ℝ) / 1000000000000) ((45523 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1056328437499 : ℝ) / 1000000000000) ((845523 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((27399578643 : ℝ) / 500000000000) ((2767182157 : ℝ) / 50000000000) := rb_log h1 (by norm_num) dlower_log_269.1 dlower_log_270.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((27399578643 : ℝ) / 250000000000) ((2767182157 : ℝ) / 25000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((582459894279 : ℝ) / 1000000000000) ((145887216497 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1438277882403 : ℝ) / 500000000000) ((-716598508731 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_271.1 dlower_log_272.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((716598508731 : ℝ) / 250000000000) ((1438277882403 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((202485173903 : ℝ) / 1000000000000) ((203582919473 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((796417080527 : ℝ) / 1000000000000) ((797514826097 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3172892871 : ℝ) / 1000000000000) ((647607353 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((79854130803 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((1584130469 : ℝ) / 4000000000) ((49512220143 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((79854130803 : ℝ) / 200000000000) ((79854130803 : ℝ) / 200000000000) ((79854130803 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((120145869197 : ℝ) / 200000000000))
  have h11 : RB z11 ((164813247387 : ℝ) / 250000000000) ((659361430887 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((120145869197 : ℝ) / 200000000000) ((120145869197 : ℝ) / 200000000000) ((120145869197 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-104161979747 : ℝ) / 250000000000) ((-208241720639 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_273.1 dlower_log_274.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-20767680791 : ℝ) / 62500000000) ((-33169452639 : ℝ) / 100000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((79854130803 : ℝ) / 200000000000))
  have h14 : RB z14 ((-918115761191 : ℝ) / 1000000000000) ((-918115761189 : ℝ) / 1000000000000) := rb_log (show RB ((79854130803 : ℝ) / 200000000000) ((79854130803 : ℝ) / 200000000000) ((79854130803 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_275.1 dlower_log_275.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((585832868533 : ℝ) / 1000000000000) ((586421234801 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((456800509 : ℝ) / 200000000000) ((1980670261 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3172892871 : ℝ) / 1000000000000) ((647607353 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1435664129533 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((44763315399 : ℝ) / 31250000000) ((716245618331 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((1435664129533 : ℝ) / 1000000000000) ((1435664129533 : ℝ) / 1000000000000) ((1435664129533 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((435664129533 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3287913775007 : ℝ) / 1000000000000) ((822015825699 : ℝ) / 250000000000) := rb_div_signed h18 (show RB ((435664129533 : ℝ) / 1000000000000) ((435664129533 : ℝ) / 1000000000000) ((435664129533 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((595126626351 : ℝ) / 500000000000) ((297574682421 : ℝ) / 250000000000) := rb_log h19 (by norm_num) dlower_log_276.1 dlower_log_277.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((236984505151 : ℝ) / 250000000000) ((118660110551 : ℝ) / 125000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1435664129533 : ℝ) / 1000000000000))
  have h22 : RB z22 ((45203443773 : ℝ) / 125000000000) ((361627550187 : ℝ) / 1000000000000) := rb_log (show RB ((1435664129533 : ℝ) / 1000000000000) ((1435664129533 : ℝ) / 1000000000000) ((1435664129533 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_278.1 dlower_log_278.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((586310470417 : ℝ) / 1000000000000) ((36728333389 : ℝ) / 62500000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2761604429 : ℝ) / 1000000000000) ((1038687989 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1056328437499 : ℝ) / 1000000000000) ((845523 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1115829767869 : ℝ) / 1000000000000) ((223409107353 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((895218652317 : ℝ) / 500000000000) ((112024256387 : ℝ) / 62500000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((518196737759 : ℝ) / 500000000000))
  have h28 : RB z28 ((927798770423 : ℝ) / 500000000000) ((464404833677 : ℝ) / 250000000000) := rb_widen (rb_mul h27 (show RB ((518196737759 : ℝ) / 500000000000) ((518196737759 : ℝ) / 500000000000) ((518196737759 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3172892871 : ℝ) / 1000000000000) ((647607353 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((114643711188903317304999 : ℝ) / 200000000000000000000000))
  have h30 : RB z30 ((2767611793 : ℝ) / 500000000000) ((5648869409 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((114643711188903317304999 : ℝ) / 200000000000000000000000) ((114643711188903317304999 : ℝ) / 200000000000000000000000) ((114643711188903317304999 : ℝ) / 200000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((994351130591 : ℝ) / 1000000000000) ((497232388207 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((922557756331 : ℝ) / 500000000000) ((1847336996353 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((79854130803 : ℝ) / 200000000000)) ((456800509 : ℝ) / 200000000000) ((1980670261 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1435664129533 : ℝ) / 1000000000000)) ((2761604429 : ℝ) / 1000000000000) ((1038687989 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((79854130803 : ℝ) / 200000000000)) (wl := ((1435664129533 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((922557756331 : ℝ) / 500000000000) ≤ D0q (q) * (((1435664129533 : ℝ) / 1000000000000) - ((79854130803 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((1435664129533 : ℝ) / 1000000000000) * ((79854130803 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
