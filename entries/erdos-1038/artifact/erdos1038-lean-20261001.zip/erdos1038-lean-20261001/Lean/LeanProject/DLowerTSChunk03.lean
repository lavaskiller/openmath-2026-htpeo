import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk00
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_T_12 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((238676368731828707 : ℝ) / 1152921504606846976) ((121294548044044097 : ℝ) / 576460752303423488)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((431474721779 : ℝ) / 50000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((121294548044044097 : ℝ) / 576460752303423488) ≤ ((-297035584863 : ℝ) / 62500000000) by norm_num).trans dlower_log_119.1)
  have hql : ((31930744057 : ℝ) / 4000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_120.2.trans (show ((-483048033089 : ℝ) / 100000000000) ≤ -1 / ((238676368731828707 : ℝ) / 1152921504606846976) by norm_num))
  have hqr : RB (tailQ r) ((31930744057 : ℝ) / 4000000000000) ((431474721779 : ℝ) / 50000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((503991343007 : ℝ) / 500000000000) ((252157373609 : ℝ) / 250000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((248468529 : ℝ) / 31250000000) ((429623659 : ℝ) / 50000000000) := rb_log h1 (by norm_num) dlower_log_121.1 dlower_log_122.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((248468529 : ℝ) / 15625000000) ((429623659 : ℝ) / 25000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((675962234199 : ℝ) / 1000000000000) ((42327824669 : ℝ) / 62500000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((139936856771 : ℝ) / 1000000000000) ((142500854531 : ℝ) / 1000000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((857499145469 : ℝ) / 1000000000000) ((860063143229 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((15930819 : ℝ) / 250000000000) ((2978727 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((122598368311 : ℝ) / 250000000000)) - (z7)
  have h8 : RB z8 ((490319005069 : ℝ) / 1000000000000) ((30645609373 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB ((122598368311 : ℝ) / 250000000000) ((122598368311 : ℝ) / 250000000000) ((122598368311 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((127401631689 : ℝ) / 250000000000))
  have h9 : RB z9 ((962152129781 : ℝ) / 1000000000000) ((962173214479 : ℝ) / 1000000000000) := rb_div_signed h8 (show RB ((127401631689 : ℝ) / 250000000000) ((127401631689 : ℝ) / 250000000000) ((127401631689 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-19291350877 : ℝ) / 500000000000) ((-38560787893 : ℝ) / 1000000000000) := rb_log h9 (by norm_num) dlower_log_123.1 dlower_log_124.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-6636711949 : ℝ) / 200000000000) ((-16532921333 : ℝ) / 500000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((122598368311 : ℝ) / 250000000000))
  have h12 : RB z12 ((-142509440699 : ℝ) / 200000000000) ((-712547203493 : ℝ) / 1000000000000) := rb_log (show RB ((122598368311 : ℝ) / 250000000000) ((122598368311 : ℝ) / 250000000000) ((122598368311 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_125.1 dlower_log_125.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((169840910937 : ℝ) / 250000000000) ((679481360829 : ℝ) / 1000000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((529612261 : ℝ) / 250000000000) ((351912663 : ℝ) / 100000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((15930819 : ℝ) / 250000000000) ((2978727 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((22272970467 : ℝ) / 15625000000)) - (z15)
  have h16 : RB z16 ((1425395641713 : ℝ) / 1000000000000) ((356351596653 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((22272970467 : ℝ) / 15625000000) ((22272970467 : ℝ) / 15625000000) ((22272970467 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((6647970467 : ℝ) / 15625000000))
  have h17 : RB z17 ((837541585523 : ℝ) / 250000000000) ((3350191596273 : ℝ) / 1000000000000) := rb_div_signed h16 (show RB ((6647970467 : ℝ) / 15625000000) ((6647970467 : ℝ) / 15625000000) ((6647970467 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((1209009998959 : ℝ) / 1000000000000) ((1209017537119 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_126.1 dlower_log_127.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((103672504097 : ℝ) / 100000000000) ((519915711597 : ℝ) / 500000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((22272970467 : ℝ) / 15625000000))
  have h20 : RB z20 ((354501660989 : ℝ) / 1000000000000) ((5539088453 : ℝ) / 15625000000) := rb_log (show RB ((22272970467 : ℝ) / 15625000000) ((22272970467 : ℝ) / 15625000000) ((22272970467 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_128.1 dlower_log_128.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((341111689989 : ℝ) / 500000000000) ((137065952441 : ℝ) / 200000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((2489092637 : ℝ) / 500000000000) ((4683764003 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((503991343007 : ℝ) / 500000000000) ((252157373609 : ℝ) / 250000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1016029095303 : ℝ) / 1000000000000) ((1017333457047 : ℝ) / 1000000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((491480936301 : ℝ) / 250000000000) ((49211189159 : ℝ) / 25000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((233769159161 : ℝ) / 250000000000))
  have h26 : RB z26 ((1838289363563 : ℝ) / 1000000000000) ((920324664881 : ℝ) / 500000000000) := rb_widen (rb_mul h25 (show RB ((233769159161 : ℝ) / 250000000000) ((233769159161 : ℝ) / 250000000000) ((233769159161 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((15930819 : ℝ) / 250000000000) ((2978727 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((2730629836693291671237 : ℝ) / 3906250000000000000000))
  have h28 : RB z28 ((91158107 : ℝ) / 1000000000000) ((13316127 : ℝ) / 125000000000) := rb_div_signed h27 (show RB ((2730629836693291671237 : ℝ) / 3906250000000000000000) ((2730629836693291671237 : ℝ) / 3906250000000000000000) ((2730629836693291671237 : ℝ) / 3906250000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((124986683873 : ℝ) / 125000000000) ((999908841893 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((367618706481 : ℝ) / 200000000000) ((920240769827 : ℝ) / 500000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((122598368311 : ℝ) / 250000000000)) ((529612261 : ℝ) / 250000000000) ((351912663 : ℝ) / 100000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((22272970467 : ℝ) / 15625000000)) ((2489092637 : ℝ) / 500000000000) ((4683764003 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((122598368311 : ℝ) / 250000000000)) (wl := ((22272970467 : ℝ) / 15625000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((367618706481 : ℝ) / 200000000000) ≤ D0q (tailQ r) * (((22272970467 : ℝ) / 15625000000) - ((122598368311 : ℝ) / 250000000000)) * (1 - (tailQ r) ^ 2 / (((22272970467 : ℝ) / 15625000000) * ((122598368311 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_13 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((121294548044044097 : ℝ) / 576460752303423488) ((246501823444347681 : ℝ) / 1152921504606846976)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((232641665837 : ℝ) / 25000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((246501823444347681 : ℝ) / 1152921504606846976) ≤ ((-4677131748953 : ℝ) / 1000000000000) by norm_num).trans dlower_log_129.1)
  have hql : ((862949443553 : ℝ) / 100000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_130.2.trans (show ((-4752569357811 : ℝ) / 1000000000000) ≤ -1 / ((121294548044044097 : ℝ) / 576460752303423488) by norm_num))
  have hqr : RB (tailQ r) ((862949443553 : ℝ) / 100000000000000) ((232641665837 : ℝ) / 25000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((201725898887 : ℝ) / 200000000000) ((504652833317 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((4296236589 : ℝ) / 500000000000) ((9262635667 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_131.1 dlower_log_132.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((4296236589 : ℝ) / 250000000000) ((9262635667 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((26984876369 : ℝ) / 40000000000) ((168990558551 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((70974441237 : ℝ) / 500000000000) ((144524950437 : ℝ) / 1000000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((855475049563 : ℝ) / 1000000000000) ((429025558763 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((37234087 : ℝ) / 500000000000) ((10824429 : ℝ) / 125000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((7648533649 : ℝ) / 15625000000)) - (z7)
  have h8 : RB z8 ((61177444763 : ℝ) / 125000000000) ((244715842681 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((7648533649 : ℝ) / 15625000000) ((7648533649 : ℝ) / 15625000000) ((7648533649 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((7976466351 : ℝ) / 15625000000))
  have h9 : RB z9 ((191743568113 : ℝ) / 200000000000) ((1917483193 : ℝ) / 2000000000) := rb_div_signed h8 (show RB ((7976466351 : ℝ) / 15625000000) ((7976466351 : ℝ) / 15625000000) ((7976466351 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-42158469951 : ℝ) / 1000000000000) ((-42133691397 : ℝ) / 1000000000000) := rb_log h9 (by norm_num) dlower_log_133.1 dlower_log_134.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-7234824451 : ℝ) / 200000000000) ((-4505540217 : ℝ) / 125000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((7648533649 : ℝ) / 15625000000))
  have h12 : RB z12 ((-714358246027 : ℝ) / 1000000000000) ((-28574329841 : ℝ) / 40000000000) := rb_log (show RB ((7648533649 : ℝ) / 15625000000) ((7648533649 : ℝ) / 15625000000) ((7648533649 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_135.1 dlower_log_135.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((67818412377 : ℝ) / 100000000000) ((678313924291 : ℝ) / 1000000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((1110944783 : ℝ) / 500000000000) ((1846007533 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((37234087 : ℝ) / 500000000000) ((10824429 : ℝ) / 125000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((712449523201 : ℝ) / 500000000000)) - (z15)
  have h16 : RB z16 ((142481245097 : ℝ) / 100000000000) ((356206144557 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((712449523201 : ℝ) / 500000000000) ((712449523201 : ℝ) / 500000000000) ((712449523201 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((212449523201 : ℝ) / 500000000000))
  have h17 : RB z17 ((3353296419549 : ℝ) / 1000000000000) ((670664992211 : ℝ) / 200000000000) := rb_div_signed h16 (show RB ((212449523201 : ℝ) / 500000000000) ((212449523201 : ℝ) / 500000000000) ((212449523201 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((241988773571 : ℝ) / 200000000000) ((604976189649 : ℝ) / 500000000000) := rb_log h17 (by norm_num) dlower_log_136.1 dlower_log_137.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1035076790321 : ℝ) / 1000000000000) ((103820099121 : ℝ) / 100000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((712449523201 : ℝ) / 500000000000))
  have h20 : RB z20 ((354100966579 : ℝ) / 1000000000000) ((177050483291 : ℝ) / 500000000000) := rb_log (show RB ((712449523201 : ℝ) / 500000000000) ((712449523201 : ℝ) / 500000000000) ((712449523201 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_138.1 dlower_log_138.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((680975823739 : ℝ) / 1000000000000) ((684100024631 : ℝ) / 1000000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((1002717907 : ℝ) / 200000000000) ((4739057703 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((201725898887 : ℝ) / 200000000000) ((504652833317 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((254333364261 : ℝ) / 250000000000) ((10186979287 : ℝ) / 10000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((392658106717 : ℝ) / 200000000000) ((1965923745211 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((467696446433 : ℝ) / 500000000000))
  have h26 : RB z26 ((918224005873 : ℝ) / 500000000000) ((1838911099187 : ℝ) / 1000000000000) := rb_widen (rb_mul h25 (show RB ((467696446433 : ℝ) / 500000000000) ((467696446433 : ℝ) / 500000000000) ((467696446433 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((37234087 : ℝ) / 500000000000) ((10824429 : ℝ) / 125000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((5449194151416854690449 : ℝ) / 7812500000000000000000))
  have h28 : RB z28 ((106764889 : ℝ) / 1000000000000) ((62075859 : ℝ) / 500000000000) := rb_div_signed h27 (show RB ((5449194151416854690449 : ℝ) / 7812500000000000000000) ((5449194151416854690449 : ℝ) / 7812500000000000000000) ((5449194151416854690449 : ℝ) / 7812500000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((499937924141 : ℝ) / 500000000000) ((999893235111 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((183622001357 : ℝ) / 100000000000) ((114919673003 : ℝ) / 62500000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((7648533649 : ℝ) / 15625000000)) ((1110944783 : ℝ) / 500000000000) ((1846007533 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((712449523201 : ℝ) / 500000000000)) ((1002717907 : ℝ) / 200000000000) ((4739057703 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((7648533649 : ℝ) / 15625000000)) (wl := ((712449523201 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((183622001357 : ℝ) / 100000000000) ≤ D0q (tailQ r) * (((712449523201 : ℝ) / 500000000000) - ((7648533649 : ℝ) / 15625000000)) * (1 - (tailQ r) ^ 2 / (((712449523201 : ℝ) / 500000000000) * ((7648533649 : ℝ) / 15625000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_14 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((246501823444347681 : ℝ) / 1152921504606846976) ((496916374244954849 : ℝ) / 2305843009213693952)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((241369067847 : ℝ) / 25000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((496916374244954849 : ℝ) / 2305843009213693952) ≤ ((-2320151969953 : ℝ) / 500000000000) by norm_num).trans dlower_log_139.1)
  have hql : ((930566663343 : ℝ) / 100000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_140.2.trans (show ((-1169282937239 : ℝ) / 250000000000) ≤ -1 / ((246501823444347681 : ℝ) / 1152921504606846976) by norm_num))
  have hqr : RB (tailQ r) ((930566663343 : ℝ) / 100000000000000) ((241369067847 : ℝ) / 25000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((1009305666633 : ℝ) / 1000000000000) ((504827381357 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((1852527133 : ℝ) / 200000000000) ((384338133 : ℝ) / 40000000000) := rb_log h1 (by norm_num) dlower_log_141.1 dlower_log_142.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((1852527133 : ℝ) / 100000000000) ((384338133 : ℝ) / 20000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((673930273909 : ℝ) / 1000000000000) ((67462190923 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((1152724037 : ℝ) / 8000000000) ((145383129633 : ℝ) / 1000000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((854616870367 : ℝ) / 1000000000000) ((6847275963 : ℝ) / 8000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((86595431 : ℝ) / 1000000000000) ((23303611 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((487696213407 : ℝ) / 1000000000000)) - (z7)
  have h8 : RB z8 ((487602998963 : ℝ) / 1000000000000) ((60951202247 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((487696213407 : ℝ) / 1000000000000) ((487696213407 : ℝ) / 1000000000000) ((487696213407 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((512303786593 : ℝ) / 1000000000000))
  have h9 : RB z9 ((95178488179 : ℝ) / 100000000000) ((237949450471 : ℝ) / 250000000000) := rb_div_signed h8 (show RB ((512303786593 : ℝ) / 1000000000000) ((512303786593 : ℝ) / 1000000000000) ((512303786593 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-49416234231 : ℝ) / 1000000000000) ((-3087666233 : ℝ) / 62500000000) := rb_log h9 (by norm_num) dlower_log_143.1 dlower_log_144.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-5286978013 : ℝ) / 125000000000) ((-10555086611 : ℝ) / 250000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((487696213407 : ℝ) / 1000000000000))
  have h12 : RB z12 ((-359031290241 : ℝ) / 500000000000) ((-560986391 : ℝ) / 781250000) := rb_log (show RB ((487696213407 : ℝ) / 1000000000000) ((487696213407 : ℝ) / 1000000000000) ((487696213407 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_145.1 dlower_log_145.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((84470844547 : ℝ) / 125000000000) ((337921117019 : ℝ) / 500000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((572423573 : ℝ) / 500000000000) ((1911960129 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((86595431 : ℝ) / 1000000000000) ((23303611 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((89139035193 : ℝ) / 62500000000)) - (z15)
  have h16 : RB z16 ((356532837161 : ℝ) / 250000000000) ((1426137967657 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((89139035193 : ℝ) / 62500000000) ((89139035193 : ℝ) / 62500000000) ((89139035193 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((26639035193 : ℝ) / 62500000000))
  have h17 : RB z17 ((3345962368549 : ℝ) / 1000000000000) ((3345977897953 : ℝ) / 1000000000000) := rb_div_signed h16 (show RB ((26639035193 : ℝ) / 62500000000) ((26639035193 : ℝ) / 62500000000) ((26639035193 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((603877177901 : ℝ) / 500000000000) ((120775899703 : ℝ) / 100000000000) := rb_log h17 (by norm_num) dlower_log_146.1 dlower_log_147.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1032167247727 : ℝ) / 1000000000000) ((1033732393683 : ℝ) / 1000000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((89139035193 : ℝ) / 62500000000))
  have h20 : RB z20 ((177515393607 : ℝ) / 500000000000) ((22189424201 : ℝ) / 62500000000) := rb_log (show RB ((89139035193 : ℝ) / 62500000000) ((89139035193 : ℝ) / 62500000000) ((89139035193 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_148.1 dlower_log_148.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((677136460511 : ℝ) / 1000000000000) ((678701606469 : ℝ) / 1000000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((2514551281 : ℝ) / 1000000000000) ((59641657 : ℝ) / 12500000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((1009305666633 : ℝ) / 1000000000000) ((504827381357 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1018697928697 : ℝ) / 1000000000000) ((31856335621 : ℝ) / 31250000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((1961933121987 : ℝ) / 1000000000000) ((245411316699 : ℝ) / 125000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((938528349681 : ℝ) / 1000000000000))
  have h26 : RB z26 ((920664927581 : ℝ) / 500000000000) ((1842603824437 : ℝ) / 1000000000000) := rb_widen (rb_mul h25 (show RB ((938528349681 : ℝ) / 1000000000000) ((938528349681 : ℝ) / 1000000000000) ((938528349681 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((86595431 : ℝ) / 1000000000000) ((23303611 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((43472769930379411432551 : ℝ) / 62500000000000000000000))
  have h28 : RB z28 ((62248327 : ℝ) / 500000000000) ((8375793 : ℝ) / 62500000000) := rb_div_signed h27 (show RB ((43472769930379411432551 : ℝ) / 62500000000000000000000) ((43472769930379411432551 : ℝ) / 62500000000000000000000) ((43472769930379411432551 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((62491624207 : ℝ) / 62500000000) ((499937751673 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((920541546799 : ℝ) / 500000000000) ((1842374426427 : ℝ) / 1000000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((487696213407 : ℝ) / 1000000000000)) ((572423573 : ℝ) / 500000000000) ((1911960129 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((89139035193 : ℝ) / 62500000000)) ((2514551281 : ℝ) / 1000000000000) ((59641657 : ℝ) / 12500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((487696213407 : ℝ) / 1000000000000)) (wl := ((89139035193 : ℝ) / 62500000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((920541546799 : ℝ) / 500000000000) ≤ D0q (tailQ r) * (((89139035193 : ℝ) / 62500000000) - ((487696213407 : ℝ) / 1000000000000)) * (1 - (tailQ r) ^ 2 / (((89139035193 : ℝ) / 62500000000) * ((487696213407 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_15 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((496916374244954849 : ℝ) / 2305843009213693952) ((3912727356259487 : ℝ) / 18014398509481984)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((500559623251 : ℝ) / 50000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((3912727356259487 : ℝ) / 18014398509481984) ≤ ((-71938305709 : ℝ) / 15625000000) by norm_num).trans dlower_log_149.1)
  have hql : ((965476271383 : ℝ) / 100000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_150.2.trans (show ((-4640303939909 : ℝ) / 1000000000000) ≤ -1 / ((496916374244954849 : ℝ) / 2305843009213693952) by norm_num))
  have hqr : RB (tailQ r) ((965476271383 : ℝ) / 100000000000000) ((500559623251 : ℝ) / 50000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((1009654762713 : ℝ) / 1000000000000) ((505005596233 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((9608453323 : ℝ) / 1000000000000) ((4980706221 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_151.1 dlower_log_152.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((9608453323 : ℝ) / 500000000000) ((4980706221 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((26928974227 : ℝ) / 40000000000) ((336965136957 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((72540976237 : ℝ) / 500000000000) ((29275531099 : ℝ) / 200000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((170724468901 : ℝ) / 200000000000) ((427459023763 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((93214443 : ℝ) / 1000000000000) ((4008959 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((243591875179 : ℝ) / 500000000000)) - (z7)
  have h8 : RB z8 ((487083526383 : ℝ) / 1000000000000) ((97418107183 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((243591875179 : ℝ) / 500000000000) ((243591875179 : ℝ) / 500000000000) ((243591875179 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((256408124821 : ℝ) / 500000000000))
  have h9 : RB z9 ((189964154499 : ℝ) / 200000000000) ((949834441197 : ℝ) / 1000000000000) := rb_div_signed h8 (show RB ((256408124821 : ℝ) / 500000000000) ((256408124821 : ℝ) / 500000000000) ((256408124821 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-25740986359 : ℝ) / 500000000000) ((-25733790999 : ℝ) / 500000000000) := rb_log h9 (by norm_num) dlower_log_153.1 dlower_log_154.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-44012867599 : ℝ) / 1000000000000) ((-43933878011 : ℝ) / 1000000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((243591875179 : ℝ) / 500000000000))
  have h12 : RB z12 ((-719113916267 : ℝ) / 1000000000000) ((-143822783253 : ℝ) / 200000000000) := rb_log (show RB ((243591875179 : ℝ) / 500000000000) ((243591875179 : ℝ) / 500000000000) ((243591875179 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_155.1 dlower_log_155.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((337550524333 : ℝ) / 500000000000) ((42198752391 : ℝ) / 62500000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((36586711 : ℝ) / 31250000000) ((1955682581 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((93214443 : ℝ) / 1000000000000) ((4008959 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((285195303317 : ℝ) / 200000000000)) - (z15)
  have h16 : RB z16 ((142587629261 : ℝ) / 100000000000) ((712941651071 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((285195303317 : ℝ) / 200000000000) ((285195303317 : ℝ) / 200000000000) ((285195303317 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((85195303317 : ℝ) / 200000000000))
  have h17 : RB z17 ((334731196931 : ℝ) / 100000000000) ((1673664212259 : ℝ) / 500000000000) := rb_div_signed h16 (show RB ((85195303317 : ℝ) / 200000000000) ((85195303317 : ℝ) / 200000000000) ((85195303317 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((604078813261 : ℝ) / 500000000000) ((1208162542459 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_156.1 dlower_log_157.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1031310345683 : ℝ) / 1000000000000) ((516439980947 : ℝ) / 500000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((285195303317 : ℝ) / 200000000000))
  have h20 : RB z20 ((177428426911 : ℝ) / 500000000000) ((5544638341 : ℝ) / 15625000000) := rb_log (show RB ((285195303317 : ℝ) / 200000000000) ((285195303317 : ℝ) / 200000000000) ((285195303317 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_158.1 dlower_log_158.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((676453491859 : ℝ) / 1000000000000) ((84752888509 : ℝ) / 125000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((504643589 : ℝ) / 200000000000) ((4798752397 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((1009654762713 : ℝ) / 1000000000000) ((505005596233 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1019402739869 : ℝ) / 1000000000000) ((1020122608907 : ℝ) / 1000000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((980274323173 : ℝ) / 500000000000) ((980966560997 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((938792766227 : ℝ) / 1000000000000))
  have h26 : RB z26 ((73621955481 : ℝ) / 40000000000) ((7367394491 : ℝ) / 4000000000) := rb_widen (rb_mul h25 (show RB ((938792766227 : ℝ) / 1000000000000) ((938792766227 : ℝ) / 1000000000000) ((938792766227 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((93214443 : ℝ) / 1000000000000) ((4008959 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((69471258727231708668743 : ℝ) / 100000000000000000000000))
  have h28 : RB z28 ((33544247 : ℝ) / 250000000000) ((144266819 : ℝ) / 1000000000000) := rb_div_signed h27 (show RB ((69471258727231708668743 : ℝ) / 100000000000000000000000) ((69471258727231708668743 : ℝ) / 100000000000000000000000) ((69471258727231708668743 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((999855733181 : ℝ) / 1000000000000) ((249966455753 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1840283356891 : ℝ) / 1000000000000) ((36832029781 : ℝ) / 20000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((243591875179 : ℝ) / 500000000000)) ((36586711 : ℝ) / 31250000000) ((1955682581 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((285195303317 : ℝ) / 200000000000)) ((504643589 : ℝ) / 200000000000) ((4798752397 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((243591875179 : ℝ) / 500000000000)) (wl := ((285195303317 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1840283356891 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((285195303317 : ℝ) / 200000000000) - ((243591875179 : ℝ) / 500000000000)) * (1 - (tailQ r) ^ 2 / (((285195303317 : ℝ) / 200000000000) * ((243591875179 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
