import LeanProject.DLowerCoverage

/-! The actual terminal-family roots, in the replay variable v=q/p.
No root, sign, width or derivative certificate is assumed in this module. -/
open Real Set Filter Topology
namespace EP1038.DLowerCert
open EP1038.Stage9
open scoped Classical

noncomputable def delta (q : ℝ) : ℝ := Real.log 2 - 2 * Real.log (1 + q)
noncomputable def aval (q : ℝ) : ℝ := 1 + delta q / Real.log q
noncomputable def E (q v : ℝ) : ℝ :=
  aval q * (Real.log (v - q ^ 2) - Real.log (1 - v)) - Real.log v - delta q
noncomputable def phi (q v : ℝ) : ℝ := v + q ^ 2 / v

theorem delta_eq_log_D0 {q : ℝ} (hq : 0 < q) : delta q = Real.log (D0q q) := by
  unfold delta D0q
  rw [Real.log_div (by norm_num) (by positivity), Real.log_pow]
  norm_num

theorem aval_eq_Aq {q : ℝ} (hq : 0 < q) (hq1 : q < 1) : aval q = Aq q := by
  rw [aval, delta_eq_log_D0 hq]
  unfold Aq
  rw [log_H_eq hq]
  change 1 + Real.log (D0q q) / Real.log q = _
  field_simp [(log_q_neg hq hq1).ne]
  change Real.log q + Real.log (D0q q) = Real.log (D0q q) + Real.log q
  ring

theorem E_eq_GA {q v : ℝ} (hq : 0 < q) (hq1 : q < 1)
    (hvq : q < v) (hv1 : v ≠ 1) : E q v = GA (Aq q) q (q / v) := by
  have hv0 := hq.trans hvq
  have hx : 0 < v - q ^ 2 := by nlinarith
  have hd : 0 < |1 - v| := abs_pos.mpr (sub_ne_zero.mpr hv1.symm)
  have hab : |q / v - q| = (q / v) * |1 - v| := by
    rw [show q / v - q = (q / v) * (1 - v) by field_simp <;> ring,
      abs_mul, abs_of_pos (div_pos hq hv0)]
  have hr : (1 - q * (q / v)) / |q / v - q| = ((v - q ^ 2) / |1 - v|) / q := by
    rw [hab]
    field_simp [hq.ne', hv0.ne', hd.ne']
    <;> ring
  unfold E GA
  rw [aval_eq_Aq hq hq1, hr, Real.log_div (div_pos hx hd).ne' hq.ne',
    Real.log_div hx.ne' hd.ne', Real.log_abs, Real.log_div hq.ne' hv0.ne',
    delta_eq_log_D0 hq]
  have hc := CA_Aq hq hq1
  unfold CA at hc
  rw [log_H_eq hq] at hc
  change Real.log (D0q q) + Real.log q - Aq q * Real.log q = 0 at hc
  linear_combination -hc

noncomputable def pPlus (q : ℝ) : ℝ :=
  if h : q ∈ Qadm then Classical.choose (exists_pplus h.1 h.2.1
    (Aq_pos h.1 h.2.1) ((Aq_lt_s_iff h.1 h.2.1).mpr h.2.2) (C := 0) le_rfl) else 0
noncomputable def pMinus (q : ℝ) : ℝ :=
  if h : q ∈ Qadm then Classical.choose (exists_pminus h.1 h.2.1
    (Aq_pos h.1 h.2.1) ((Aq_lt_s_iff h.1 h.2.1).mpr h.2.2) 0) else 0
noncomputable def vPlus (q : ℝ) : ℝ := q / pPlus q
noncomputable def vMinus (q : ℝ) : ℝ := q / pMinus q

theorem pPlus_spec {q : ℝ} (hq : q ∈ Qadm) :
    q < pPlus q ∧ pPlus q < 1 ∧ GA (Aq q) q (pPlus q) = 0 ∧
    (∀ p, q < p → p < 1 → (0 < GA (Aq q) q p ↔ p < pPlus q)) ∧
    (∀ p, q < p → p < 1 → (GA (Aq q) q p < 0 ↔ pPlus q < p)) := by
  simpa only [pPlus, dif_pos hq] using Classical.choose_spec
    (exists_pplus hq.1 hq.2.1 (Aq_pos hq.1 hq.2.1)
      ((Aq_lt_s_iff hq.1 hq.2.1).mpr hq.2.2) (C := 0) le_rfl)

theorem pMinus_spec {q : ℝ} (hq : q ∈ Qadm) :
    0 < pMinus q ∧ pMinus q < q ∧ GA (Aq q) q (pMinus q) = 0 ∧
    (∀ p, 0 < p → p < q → (0 < GA (Aq q) q p ↔ pMinus q < p)) ∧
    (∀ p, 0 < p → p < q → (GA (Aq q) q p < 0 ↔ p < pMinus q)) := by
  simpa only [pMinus, dif_pos hq] using Classical.choose_spec
    (exists_pminus hq.1 hq.2.1 (Aq_pos hq.1 hq.2.1)
      ((Aq_lt_s_iff hq.1 hq.2.1).mpr hq.2.2) 0)

theorem vPlus_mem {q : ℝ} (hq : q ∈ Qadm) : q < vPlus q ∧ vPlus q < 1 := by
  have hp := pPlus_spec hq
  have hp0 := hq.1.trans hp.1
  unfold vPlus
  constructor
  · apply (lt_div_iff₀ hp0).mpr
    nlinarith [mul_pos hq.1 (sub_pos.mpr hp.2.1)]
  · exact (div_lt_one hp0).mpr hp.1

theorem vMinus_mem {q : ℝ} (hq : q ∈ Qadm) : 1 < vMinus q := by
  have hp := pMinus_spec hq
  exact (one_lt_div hp.1).mpr hp.2.1

theorem E_vPlus {q : ℝ} (hq : q ∈ Qadm) : E q (vPlus q) = 0 := by
  rw [E_eq_GA hq.1 hq.2.1 (vPlus_mem hq).1 (vPlus_mem hq).2.ne]
  have hp := pPlus_spec hq
  rw [vPlus, div_div_cancel₀ hq.1.ne']
  exact hp.2.2.1

theorem E_vMinus {q : ℝ} (hq : q ∈ Qadm) : E q (vMinus q) = 0 := by
  rw [E_eq_GA hq.1 hq.2.1 (hq.2.1.trans (vMinus_mem hq)) (vMinus_mem hq).ne']
  rw [vMinus, div_div_cancel₀ hq.1.ne']
  exact (pMinus_spec hq).2.2.1

theorem pPlus_unique {q p : ℝ} (hq : q ∈ Qadm) (hpq : q < p) (hp1 : p < 1)
    (he : GA (Aq q) q p = 0) : p = pPlus q := by
  have hs := pPlus_spec hq
  rcases lt_trichotomy p (pPlus q) with h | h | h
  · have hh := (hs.2.2.2.1 p hpq hp1).mpr h; linarith
  · exact h
  · have hh := (hs.2.2.2.2 p hpq hp1).mpr h; linarith

theorem pMinus_unique {q p : ℝ} (hq : q ∈ Qadm) (hp0 : 0 < p) (hpq : p < q)
    (he : GA (Aq q) q p = 0) : p = pMinus q := by
  have hs := pMinus_spec hq
  rcases lt_trichotomy p (pMinus q) with h | h | h
  · have hh := (hs.2.2.2.2 p hp0 hpq).mpr h; linarith
  · exact h
  · have hh := (hs.2.2.2.1 p hp0 hpq).mpr h; linarith

theorem Lam_eq_actual_roots {q : ℝ} (hq : q ∈ Qadm) :
    Lam q = D0q q * (phi q (vMinus q) - phi q (vPlus q)) := by
  obtain ⟨pm, pp, hm0, hmq, hqp, hp1, hem, hep, hw⟩ := Lam_eq hq
  rw [pMinus_unique hq hm0 hmq hem, pPlus_unique hq hqp hp1 hep] at hw
  rw [hw]
  unfold phi vMinus vPlus
  field_simp [hq.1.ne', (pMinus_spec hq).1.ne', (hq.1.trans (pPlus_spec hq).1).ne']
  <;> ring

theorem plus_sign_pos {q v : ℝ} (hq : q ∈ Qadm) (hvq : q < v) (hv1 : v < 1) :
    0 < E q v ↔ vPlus q < v := by
  have hv0 := hq.1.trans hvq
  have hp0 := hq.1.trans (pPlus_spec hq).1
  have hqp : q < q / v := (lt_div_iff₀ hv0).mpr (by
    nlinarith [mul_pos hq.1 (sub_pos.mpr hv1)])
  have hp1 : q / v < 1 := (div_lt_one hv0).mpr hvq
  rw [E_eq_GA hq.1 hq.2.1 hvq hv1.ne, (pPlus_spec hq).2.2.2.1 _ hqp hp1]
  rw [div_lt_iff₀ hv0, vPlus, div_lt_iff₀ hp0]
  constructor <;> intro h <;> nlinarith

theorem minus_sign_pos {q v : ℝ} (hq : q ∈ Qadm) (hv1 : 1 < v) :
    0 < E q v ↔ v < vMinus q := by
  have hv0 := zero_lt_one.trans hv1
  have hp := pMinus_spec hq
  have hpq : q / v < q := (div_lt_iff₀ hv0).mpr (by nlinarith)
  rw [E_eq_GA hq.1 hq.2.1 (hq.2.1.trans hv1) hv1.ne',
    hp.2.2.2.1 _ (div_pos hq.1 hv0) hpq, vMinus,
    lt_div_iff₀ hp.1, lt_div_iff₀ hv0]
  constructor <;> intro h <;> nlinarith

theorem phi_strictMonoOn {q : ℝ} (hq : 0 < q) : StrictMonoOn (phi q) (Ioi q) := by
  intro v hv w hw hvw
  have hv0 := hq.trans hv
  have hw0 := hq.trans hw
  have he : phi q w - phi q v = (w - v) * (1 - q ^ 2 / (w * v)) := by
    unfold phi
    field_simp
    <;> ring
  have hh : q ^ 2 / (w * v) < 1 := (div_lt_one (mul_pos hw0 hv0)).mpr (by
    have h1 := mul_lt_mul_of_pos_left (show q < w from hw) hq
    have h2 := mul_lt_mul_of_pos_left (show q < v from hv) hw0
    nlinarith)
  have := mul_pos (sub_pos.mpr hvw) (sub_pos.mpr hh)
  linarith

/-- The one-sided root bound used by every T/S certificate leaf. -/
theorem width_lower_of_positive_signs {q vh wl L : ℝ} (hq : q ∈ Qadm)
    (hvhq : q < vh) (hvh1 : vh < 1) (hwl : 1 < wl)
    (hep : 0 < E q vh) (hem : 0 < E q wl)
    (hnum : L ≤ D0q q * (wl - vh) * (1 - q ^ 2 / (wl * vh))) : L ≤ Lam q := by
  have hp := (plus_sign_pos hq hvhq hvh1).mp hep
  have hm := (minus_sign_pos hq hwl).mp hem
  have hpp := phi_strictMonoOn hq.1 (vPlus_mem hq).1 hvhq hp
  have hmm := phi_strictMonoOn hq.1 (hq.2.1.trans hwl) (hq.2.1.trans (vMinus_mem hq)) hm
  have hid : (wl - vh) * (1 - q ^ 2 / (wl * vh)) = phi q wl - phi q vh := by
    unfold phi
    field_simp [(hq.1.trans hvhq).ne', (zero_lt_one.trans hwl).ne']
    <;> ring
  rw [Lam_eq_actual_roots hq]
  rw [mul_assoc, hid] at hnum
  exact hnum.trans (mul_le_mul_of_nonneg_left (by linarith) (D0q_pos q hq.1.le).le)

end EP1038.DLowerCert
