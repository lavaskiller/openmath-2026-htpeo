import LeanProject.COVLogTwo
import LeanProject.COVLogBounds13
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1360 : RB (Real.log ((13239941 : ℝ) / 10000000)) ((280653 : ℝ) / 1000000) ((28065301 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13239941 : ℝ) / 10000000)) (t := ((3239941 : ℝ) / 23239941))
    (lo := ((280653 : ℝ) / 1000000)) (hi := ((28065301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1361 : RB (Real.log ((101391567 : ℝ) / 25000000)) ((140011409 : ℝ) / 100000000) ((35002853 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((101391567 : ℝ) / 100000000)) (t := ((1391567 : ℝ) / 201391567))
    (lo := ((1381973 : ℝ) / 100000000)) (hi := ((690987 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((101391567 : ℝ) / 25000000) = Real.log ((101391567 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((101391567 : ℝ) / 25000000) = ((101391567 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1362 : RB (Real.log ((202785713 : ℝ) / 50000000)) ((140012681 : ℝ) / 100000000) ((35003171 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((202785713 : ℝ) / 200000000)) (t := ((2785713 : ℝ) / 402785713))
    (lo := ((276649 : ℝ) / 20000000)) (hi := ((691623 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((202785713 : ℝ) / 50000000) = Real.log ((202785713 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((202785713 : ℝ) / 50000000) = ((202785713 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1363 : RB (Real.log ((66353659 : ℝ) / 50000000)) ((2829759 : ℝ) / 10000000) ((28297591 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66353659 : ℝ) / 50000000)) (t := ((16353659 : ℝ) / 116353659))
    (lo := ((2829759 : ℝ) / 10000000)) (hi := ((28297591 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1364 : RB (Real.log ((5747937 : ℝ) / 50000000)) ((-216318203 : ℝ) / 100000000) ((-216318199 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5747937 : ℝ) / 6250000)) (t := ((-502063 : ℝ) / 11997937))
    (lo := ((-4187023 : ℝ) / 50000000)) (hi := ((-1674809 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5747937 : ℝ) / 50000000) = Real.log ((5747937 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5747937 : ℝ) / 50000000) = ((5747937 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1365 : RB (Real.log ((2630061 : ℝ) / 20000000)) ((-202872527 : ℝ) / 100000000) ((-202872523 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2630061 : ℝ) / 2500000)) (t := ((130061 : ℝ) / 5130061))
    (lo := ((507163 : ℝ) / 10000000)) (hi := ((5071631 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2630061 : ℝ) / 20000000) = Real.log ((2630061 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((2630061 : ℝ) / 20000000) = ((2630061 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1366 : RB (Real.log ((4505083 : ℝ) / 100000000)) ((-309996391 : ℝ) / 100000000) ((-154998193 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4505083 : ℝ) / 6250000)) (t := ((-1744917 : ℝ) / 10755083))
    (lo := ((-6547503 : ℝ) / 20000000)) (hi := ((-16368757 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4505083 : ℝ) / 100000000) = Real.log ((4505083 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4505083 : ℝ) / 100000000) = ((4505083 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1367 : RB (Real.log ((4575823 : ℝ) / 100000000)) ((-154219183 : ℝ) / 50000000) ((-308438361 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4575823 : ℝ) / 6250000)) (t := ((-1674177 : ℝ) / 10825823))
    (lo := ((-3117949 : ℝ) / 10000000)) (hi := ((-31179489 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4575823 : ℝ) / 100000000) = Real.log ((4575823 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4575823 : ℝ) / 100000000) = ((4575823 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1368 : RB (Real.log ((64275541 : ℝ) / 100000000)) ((-44199103 : ℝ) / 100000000) ((-44199101 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64275541 : ℝ) / 50000000)) (t := ((14275541 : ℝ) / 114275541))
    (lo := ((784863 : ℝ) / 3125000)) (hi := ((25115617 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64275541 : ℝ) / 100000000) = Real.log ((64275541 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64275541 : ℝ) / 100000000) = ((64275541 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1369 : RB (Real.log ((64278361 : ℝ) / 100000000)) ((-11048679 : ℝ) / 25000000) ((-22097357 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((64278361 : ℝ) / 50000000)) (t := ((14278361 : ℝ) / 114278361))
    (lo := ((25120003 : ℝ) / 100000000)) (hi := ((6280001 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64278361 : ℝ) / 100000000) = Real.log ((64278361 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64278361 : ℝ) / 100000000) = ((64278361 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1370 : RB (Real.log ((9790673 : ℝ) / 25000000)) ((-23436141 : ℝ) / 25000000) ((-46872281 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9790673 : ℝ) / 12500000)) (t := ((-2709327 : ℝ) / 22290673))
    (lo := ((-4885969 : ℝ) / 20000000)) (hi := ((-6107461 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9790673 : ℝ) / 25000000) = Real.log ((9790673 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9790673 : ℝ) / 25000000) = ((9790673 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1371 : RB (Real.log ((190612969 : ℝ) / 100000000)) ((16126871 : ℝ) / 25000000) ((32253743 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((190612969 : ℝ) / 200000000)) (t := ((-9387031 : ℝ) / 390612969))
    (lo := ((-2403617 : ℝ) / 50000000)) (hi := ((-4807233 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((190612969 : ℝ) / 100000000) = Real.log ((190612969 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((190612969 : ℝ) / 100000000) = ((190612969 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1372 : RB (Real.log ((11921567 : ℝ) / 6250000)) ((16144191 : ℝ) / 25000000) ((32288383 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((11921567 : ℝ) / 12500000)) (t := ((-578433 : ℝ) / 24421567))
    (lo := ((-2368977 : ℝ) / 50000000)) (hi := ((-4737953 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11921567 : ℝ) / 6250000) = Real.log ((11921567 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((11921567 : ℝ) / 6250000) = ((11921567 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1373 : RB (Real.log ((65835169 : ℝ) / 100000000)) ((-20900801 : ℝ) / 50000000) ((-13063 : ℝ) / 31250) := by
  have hm := log_bounds_of_series (x := ((65835169 : ℝ) / 50000000)) (t := ((15835169 : ℝ) / 115835169))
    (lo := ((27513117 : ℝ) / 100000000)) (hi := ((13756559 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65835169 : ℝ) / 100000000) = Real.log ((65835169 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65835169 : ℝ) / 100000000) = ((65835169 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1374 : RB (Real.log ((1028719 : ℝ) / 1562500)) ((-20898639 : ℝ) / 50000000) ((-10449319 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1028719 : ℝ) / 781250)) (t := ((247469 : ℝ) / 1809969))
    (lo := ((27517441 : ℝ) / 100000000)) (hi := ((13758721 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1028719 : ℝ) / 1562500) = Real.log ((1028719 : ℝ) / 781250) - 1 * Real.log 2 := by
    rw [show ((1028719 : ℝ) / 1562500) = ((1028719 : ℝ) / 781250) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1375 : RB (Real.log ((620857 : ℝ) / 1562500)) ((-92294161 : ℝ) / 100000000) ((-92294159 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((620857 : ℝ) / 781250)) (t := ((-160393 : ℝ) / 1402107))
    (lo := ((-11489721 : ℝ) / 50000000)) (hi := ((-22979441 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((620857 : ℝ) / 1562500) = Real.log ((620857 : ℝ) / 781250) - 1 * Real.log 2 := by
    rw [show ((620857 : ℝ) / 1562500) = ((620857 : ℝ) / 781250) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1376 : RB (Real.log ((20374339 : ℝ) / 5000000)) ((14048383 : ℝ) / 10000000) ((140483833 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20374339 : ℝ) / 20000000)) (t := ((374339 : ℝ) / 40374339))
    (lo := ((927197 : ℝ) / 50000000)) (hi := ((370879 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20374339 : ℝ) / 5000000) = Real.log ((20374339 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((20374339 : ℝ) / 5000000) = ((20374339 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1377 : RB (Real.log ((407492057 : ℝ) / 100000000)) ((1123881 : ℝ) / 800000) ((17560641 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((407492057 : ℝ) / 400000000)) (t := ((7492057 : ℝ) / 807492057))
    (lo := ((1855689 : ℝ) / 100000000)) (hi := ((185569 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((407492057 : ℝ) / 100000000) = Real.log ((407492057 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((407492057 : ℝ) / 100000000) = ((407492057 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1378 : RB (Real.log ((33125619 : ℝ) / 25000000)) ((14071557 : ℝ) / 50000000) ((5628623 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((33125619 : ℝ) / 25000000)) (t := ((8125619 : ℝ) / 58125619))
    (lo := ((14071557 : ℝ) / 50000000)) (hi := ((5628623 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1379 : RB (Real.log ((202306583 : ℝ) / 50000000)) ((139776127 : ℝ) / 100000000) ((13977613 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((202306583 : ℝ) / 200000000)) (t := ((2306583 : ℝ) / 402306583))
    (lo := ((1146691 : ℝ) / 100000000)) (hi := ((286673 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((202306583 : ℝ) / 50000000) = Real.log ((202306583 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((202306583 : ℝ) / 50000000) = ((202306583 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1380 : RB (Real.log ((202309197 : ℝ) / 50000000)) ((139777419 : ℝ) / 100000000) ((69888711 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((202309197 : ℝ) / 200000000)) (t := ((2309197 : ℝ) / 402309197))
    (lo := ((1147983 : ℝ) / 100000000)) (hi := ((71749 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((202309197 : ℝ) / 50000000) = Real.log ((202309197 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((202309197 : ℝ) / 50000000) = ((202309197 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1381 : RB (Real.log ((132809093 : ℝ) / 100000000)) ((7093563 : ℝ) / 25000000) ((28374253 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((132809093 : ℝ) / 100000000)) (t := ((32809093 : ℝ) / 232809093))
    (lo := ((7093563 : ℝ) / 25000000)) (hi := ((28374253 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1382 : RB (Real.log ((1162333 : ℝ) / 10000000)) ((-215215593 : ℝ) / 100000000) ((-215215589 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1162333 : ℝ) / 1250000)) (t := ((-87667 : ℝ) / 2412333))
    (lo := ((-1817859 : ℝ) / 25000000)) (hi := ((-1454287 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1162333 : ℝ) / 10000000) = Real.log ((1162333 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((1162333 : ℝ) / 10000000) = ((1162333 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1383 : RB (Real.log ((6634043 : ℝ) / 50000000)) ((-100990431 : ℝ) / 50000000) ((-100990429 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6634043 : ℝ) / 6250000)) (t := ((384043 : ℝ) / 12884043))
    (lo := ((1192659 : ℝ) / 20000000)) (hi := ((186353 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6634043 : ℝ) / 50000000) = Real.log ((6634043 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6634043 : ℝ) / 50000000) = ((6634043 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1384 : RB (Real.log ((285593 : ℝ) / 6250000)) ((-308576907 : ℝ) / 100000000) ((-154288451 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((285593 : ℝ) / 390625)) (t := ((-52516 : ℝ) / 338109))
    (lo := ((-31318031 : ℝ) / 100000000)) (hi := ((-3131803 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285593 : ℝ) / 6250000) = Real.log ((285593 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((285593 : ℝ) / 6250000) = ((285593 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1385 : RB (Real.log ((185613 : ℝ) / 4000000)) ((-153519291 : ℝ) / 50000000) ((-307038577 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((185613 : ℝ) / 250000)) (t := ((-64387 : ℝ) / 435613))
    (lo := ((-14889853 : ℝ) / 50000000)) (hi := ((-5955941 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((185613 : ℝ) / 4000000) = Real.log ((185613 : ℝ) / 250000) - 4 * Real.log 2 := by
    rw [show ((185613 : ℝ) / 4000000) = ((185613 : ℝ) / 250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1386 : RB (Real.log ((64101231 : ℝ) / 100000000)) ((-44470663 : ℝ) / 100000000) ((-44470661 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64101231 : ℝ) / 50000000)) (t := ((14101231 : ℝ) / 114101231))
    (lo := ((3105507 : ℝ) / 12500000)) (hi := ((24844057 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64101231 : ℝ) / 100000000) = Real.log ((64101231 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64101231 : ℝ) / 100000000) = ((64101231 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1387 : RB (Real.log ((32052047 : ℝ) / 50000000)) ((-44466197 : ℝ) / 100000000) ((-8893239 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((32052047 : ℝ) / 25000000)) (t := ((7052047 : ℝ) / 57052047))
    (lo := ((12424261 : ℝ) / 50000000)) (hi := ((24848523 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32052047 : ℝ) / 50000000) = Real.log ((32052047 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32052047 : ℝ) / 50000000) = ((32052047 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1388 : RB (Real.log ((39099131 : ℝ) / 100000000)) ((-23476749 : ℝ) / 25000000) ((-46953497 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39099131 : ℝ) / 50000000)) (t := ((-10900869 : ℝ) / 89099131))
    (lo := ((-24592277 : ℝ) / 100000000)) (hi := ((-6148069 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39099131 : ℝ) / 100000000) = Real.log ((39099131 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39099131 : ℝ) / 100000000) = ((39099131 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1389 : RB (Real.log ((7619233 : ℝ) / 4000000)) ((32219067 : ℝ) / 50000000) ((8054767 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((7619233 : ℝ) / 8000000)) (t := ((-380767 : ℝ) / 15619233))
    (lo := ((-609573 : ℝ) / 12500000)) (hi := ((-4876583 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7619233 : ℝ) / 4000000) = Real.log ((7619233 : ℝ) / 8000000) + 1 * Real.log 2 := by
    rw [show ((7619233 : ℝ) / 4000000) = ((7619233 : ℝ) / 8000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1390 : RB (Real.log ((11913311 : ℝ) / 6250000)) ((2015859 : ℝ) / 3125000) ((6450749 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((11913311 : ℝ) / 12500000)) (t := ((-586689 : ℝ) / 24413311))
    (lo := ((-480723 : ℝ) / 10000000)) (hi := ((-4807229 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11913311 : ℝ) / 6250000) = Real.log ((11913311 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((11913311 : ℝ) / 6250000) = ((11913311 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1391 : RB (Real.log ((32823043 : ℝ) / 50000000)) ((-21044611 : ℝ) / 50000000) ((-2104461 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((32823043 : ℝ) / 25000000)) (t := ((7823043 : ℝ) / 57823043))
    (lo := ((27225497 : ℝ) / 100000000)) (hi := ((13612749 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32823043 : ℝ) / 50000000) = Real.log ((32823043 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32823043 : ℝ) / 50000000) = ((32823043 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1392 : RB (Real.log ((4103061 : ℝ) / 6250000)) ((-2104241 : ℝ) / 5000000) ((-21042409 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4103061 : ℝ) / 3125000)) (t := ((978061 : ℝ) / 7228061))
    (lo := ((27229899 : ℝ) / 100000000)) (hi := ((272299 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4103061 : ℝ) / 6250000) = Real.log ((4103061 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((4103061 : ℝ) / 6250000) = ((4103061 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1393 : RB (Real.log ((39667107 : ℝ) / 100000000)) ((-9246479 : ℝ) / 10000000) ((-23116197 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((39667107 : ℝ) / 50000000)) (t := ((-10332893 : ℝ) / 89667107))
    (lo := ((-23150071 : ℝ) / 100000000)) (hi := ((-2315007 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39667107 : ℝ) / 100000000) = Real.log ((39667107 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39667107 : ℝ) / 100000000) = ((39667107 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1394 : RB (Real.log ((81302713 : ℝ) / 20000000)) ((140244711 : ℝ) / 100000000) ((70122357 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((81302713 : ℝ) / 80000000)) (t := ((1302713 : ℝ) / 161302713))
    (lo := ((64611 : ℝ) / 4000000)) (hi := ((403819 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((81302713 : ℝ) / 20000000) = Real.log ((81302713 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((81302713 : ℝ) / 20000000) = ((81302713 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1395 : RB (Real.log ((3175929 : ℝ) / 781250)) ((70123013 : ℝ) / 50000000) ((140246029 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3175929 : ℝ) / 3125000)) (t := ((50929 : ℝ) / 6300929))
    (lo := ((161659 : ℝ) / 10000000)) (hi := ((1616591 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3175929 : ℝ) / 781250) = Real.log ((3175929 : ℝ) / 3125000) + 2 * Real.log 2 := by
    rw [show ((3175929 : ℝ) / 781250) = ((3175929 : ℝ) / 3125000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1396 : RB (Real.log ((132605107 : ℝ) / 100000000)) ((1411027 : ℝ) / 5000000) ((28220541 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((132605107 : ℝ) / 100000000)) (t := ((32605107 : ℝ) / 232605107))
    (lo := ((1411027 : ℝ) / 5000000)) (hi := ((28220541 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1397 : RB (Real.log ((403669761 : ℝ) / 100000000)) ((139542693 : ℝ) / 100000000) ((17442837 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((403669761 : ℝ) / 400000000)) (t := ((3669761 : ℝ) / 803669761))
    (lo := ((913257 : ℝ) / 100000000)) (hi := ((456629 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((403669761 : ℝ) / 100000000) = Real.log ((403669761 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((403669761 : ℝ) / 100000000) = ((403669761 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1398 : RB (Real.log ((201837529 : ℝ) / 50000000)) ((27908801 : ℝ) / 20000000) ((17443001 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((201837529 : ℝ) / 200000000)) (t := ((1837529 : ℝ) / 401837529))
    (lo := ((914569 : ℝ) / 100000000)) (hi := ((91457 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((201837529 : ℝ) / 50000000) = Real.log ((201837529 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((201837529 : ℝ) / 50000000) = ((201837529 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1399 : RB (Real.log ((132910447 : ℝ) / 100000000)) ((14225269 : ℝ) / 50000000) ((28450539 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((132910447 : ℝ) / 100000000)) (t := ((32910447 : ℝ) / 232910447))
    (lo := ((14225269 : ℝ) / 50000000)) (hi := ((28450539 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1400 : RB (Real.log ((1174991 : ℝ) / 10000000)) ((-13383279 : ℝ) / 6250000) ((-10706623 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((1174991 : ℝ) / 1250000)) (t := ((-75009 : ℝ) / 2424991))
    (lo := ((-6188307 : ℝ) / 100000000)) (hi := ((-3094153 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1174991 : ℝ) / 10000000) = Real.log ((1174991 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((1174991 : ℝ) / 10000000) = ((1174991 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1401 : RB (Real.log ((6692721 : ℝ) / 50000000)) ((-50275063 : ℝ) / 25000000) ((-25137531 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((6692721 : ℝ) / 6250000)) (t := ((442721 : ℝ) / 12942721))
    (lo := ((1368781 : ℝ) / 20000000)) (hi := ((3421953 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6692721 : ℝ) / 50000000) = Real.log ((6692721 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6692721 : ℝ) / 50000000) = ((6692721 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1402 : RB (Real.log ((4633893 : ℝ) / 100000000)) ((-307177289 : ℝ) / 100000000) ((-76794321 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4633893 : ℝ) / 6250000)) (t := ((-1616107 : ℝ) / 10883893))
    (lo := ((-29918413 : ℝ) / 100000000)) (hi := ((-7479603 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4633893 : ℝ) / 100000000) = Real.log ((4633893 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4633893 : ℝ) / 100000000) = ((4633893 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1403 : RB (Real.log ((2352413 : ℝ) / 50000000)) ((-9551817 : ℝ) / 3125000) ((-305658139 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2352413 : ℝ) / 3125000)) (t := ((-772587 : ℝ) / 5477413))
    (lo := ((-7099817 : ℝ) / 25000000)) (hi := ((-28399267 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2352413 : ℝ) / 50000000) = Real.log ((2352413 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2352413 : ℝ) / 50000000) = ((2352413 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1404 : RB (Real.log ((32176427 : ℝ) / 50000000)) ((-11019723 : ℝ) / 25000000) ((-4407889 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((32176427 : ℝ) / 25000000)) (t := ((7176427 : ℝ) / 57176427))
    (lo := ((25235827 : ℝ) / 100000000)) (hi := ((6308957 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32176427 : ℝ) / 50000000) = Real.log ((32176427 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32176427 : ℝ) / 50000000) = ((32176427 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1405 : RB (Real.log ((32177153 : ℝ) / 50000000)) ((-8815327 : ℝ) / 20000000) ((-44076633 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32177153 : ℝ) / 25000000)) (t := ((7177153 : ℝ) / 57177153))
    (lo := ((6309521 : ℝ) / 25000000)) (hi := ((5047617 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32177153 : ℝ) / 50000000) = Real.log ((32177153 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32177153 : ℝ) / 50000000) = ((32177153 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1406 : RB (Real.log ((19596453 : ℝ) / 50000000)) ((-23416861 : ℝ) / 25000000) ((-46833721 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19596453 : ℝ) / 25000000)) (t := ((-5403547 : ℝ) / 44596453))
    (lo := ((-974109 : ℝ) / 4000000)) (hi := ((-6088181 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19596453 : ℝ) / 50000000) = Real.log ((19596453 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19596453 : ℝ) / 50000000) = ((19596453 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1407 : RB (Real.log ((38082947 : ℝ) / 20000000)) ((8050429 : ℝ) / 12500000) ((32201717 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((38082947 : ℝ) / 40000000)) (t := ((-1917053 : ℝ) / 78082947))
    (lo := ((-2455643 : ℝ) / 50000000)) (hi := ((-982257 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38082947 : ℝ) / 20000000) = Real.log ((38082947 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38082947 : ℝ) / 20000000) = ((38082947 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1408 : RB (Real.log ((190480831 : ℝ) / 100000000)) ((64438137 : ℝ) / 100000000) ((64438139 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((190480831 : ℝ) / 200000000)) (t := ((-9519169 : ℝ) / 390480831))
    (lo := ((-4876581 : ℝ) / 100000000)) (hi := ((-243829 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((190480831 : ℝ) / 100000000) = Real.log ((190480831 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((190480831 : ℝ) / 100000000) = ((190480831 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1409 : RB (Real.log ((65119929 : ℝ) / 100000000)) ((-42893957 : ℝ) / 100000000) ((-8578791 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((65119929 : ℝ) / 50000000)) (t := ((15119929 : ℝ) / 115119929))
    (lo := ((13210381 : ℝ) / 50000000)) (hi := ((26420763 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65119929 : ℝ) / 100000000) = Real.log ((65119929 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65119929 : ℝ) / 100000000) = ((65119929 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1410 : RB (Real.log ((65121387 : ℝ) / 100000000)) ((-21445859 : ℝ) / 50000000) ((-10722929 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((65121387 : ℝ) / 50000000)) (t := ((15121387 : ℝ) / 115121387))
    (lo := ((26423001 : ℝ) / 100000000)) (hi := ((13211501 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65121387 : ℝ) / 100000000) = Real.log ((65121387 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65121387 : ℝ) / 100000000) = ((65121387 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1411 : RB (Real.log ((39475389 : ℝ) / 100000000)) ((-92949279 : ℝ) / 100000000) ((-92949277 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39475389 : ℝ) / 50000000)) (t := ((-10524611 : ℝ) / 89475389))
    (lo := ((-36929 : ℝ) / 156250)) (hi := ((-23634559 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39475389 : ℝ) / 100000000) = Real.log ((39475389 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39475389 : ℝ) / 100000000) = ((39475389 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1412 : RB (Real.log ((81016177 : ℝ) / 20000000)) ((139891657 : ℝ) / 100000000) ((6994583 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((81016177 : ℝ) / 80000000)) (t := ((1016177 : ℝ) / 161016177))
    (lo := ((1262221 : ℝ) / 100000000)) (hi := ((631111 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((81016177 : ℝ) / 20000000) = Real.log ((81016177 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((81016177 : ℝ) / 20000000) = ((81016177 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1413 : RB (Real.log ((202541789 : ℝ) / 50000000)) ((69946161 : ℝ) / 50000000) ((5595693 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((202541789 : ℝ) / 200000000)) (t := ((2541789 : ℝ) / 402541789))
    (lo := ((631443 : ℝ) / 50000000)) (hi := ((1262887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((202541789 : ℝ) / 50000000) = Real.log ((202541789 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((202541789 : ℝ) / 50000000) = ((202541789 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1414 : RB (Real.log ((66378967 : ℝ) / 50000000)) ((28335723 : ℝ) / 100000000) ((7083931 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((66378967 : ℝ) / 50000000)) (t := ((16378967 : ℝ) / 116378967))
    (lo := ((28335723 : ℝ) / 100000000)) (hi := ((7083931 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1415 : RB (Real.log ((40367 : ℝ) / 10000)) ((4360711 : ℝ) / 3125000) ((27908551 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((40367 : ℝ) / 40000)) (t := ((367 : ℝ) / 80367))
    (lo := ((228329 : ℝ) / 25000000)) (hi := ((913317 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40367 : ℝ) / 10000) = Real.log ((40367 : ℝ) / 40000) + 2 * Real.log 2 := by
    rw [show ((40367 : ℝ) / 10000) = ((40367 : ℝ) / 40000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1416 : RB (Real.log ((403672681 : ℝ) / 100000000)) ((17442927 : ℝ) / 12500000) ((139543419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((403672681 : ℝ) / 400000000)) (t := ((3672681 : ℝ) / 803672681))
    (lo := ((45699 : ℝ) / 5000000)) (hi := ((913981 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((403672681 : ℝ) / 100000000) = Real.log ((403672681 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((403672681 : ℝ) / 100000000) = ((403672681 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1417 : RB (Real.log ((132910131 : ℝ) / 100000000)) ((284503 : ℝ) / 1000000) ((28450301 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((132910131 : ℝ) / 100000000)) (t := ((32910131 : ℝ) / 232910131))
    (lo := ((284503 : ℝ) / 1000000)) (hi := ((28450301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1418 : RB (Real.log ((12248269 : ℝ) / 100000000)) ((-656183 : ℝ) / 312500) ((-52494639 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((12248269 : ℝ) / 12500000)) (t := ((-251731 : ℝ) / 24748269))
    (lo := ((-2034403 : ℝ) / 100000000)) (hi := ((-1017201 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12248269 : ℝ) / 100000000) = Real.log ((12248269 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12248269 : ℝ) / 100000000) = ((12248269 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1419 : RB (Real.log ((13062703 : ℝ) / 100000000)) ((-40708183 : ℝ) / 20000000) ((-203540911 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13062703 : ℝ) / 12500000)) (t := ((562703 : ℝ) / 25562703))
    (lo := ((2201621 : ℝ) / 50000000)) (hi := ((4403243 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13062703 : ℝ) / 100000000) = Real.log ((13062703 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13062703 : ℝ) / 100000000) = ((13062703 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1420 : RB (Real.log ((587491 : ℝ) / 12500000)) ((-1194384 : ℝ) / 390625) ((-305762299 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((587491 : ℝ) / 781250)) (t := ((-193759 : ℝ) / 1368741))
    (lo := ((-7125857 : ℝ) / 25000000)) (hi := ((-28503427 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((587491 : ℝ) / 12500000) = Real.log ((587491 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((587491 : ℝ) / 12500000) = ((587491 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1421 : RB (Real.log ((2367717 : ℝ) / 50000000)) ((-61001937 : ℝ) / 20000000) ((-3812621 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((2367717 : ℝ) / 3125000)) (t := ((-757283 : ℝ) / 5492717))
    (lo := ((-27750809 : ℝ) / 100000000)) (hi := ((-3468851 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2367717 : ℝ) / 50000000) = Real.log ((2367717 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2367717 : ℝ) / 50000000) = ((2367717 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1422 : RB (Real.log ((32132489 : ℝ) / 50000000)) ((-22107769 : ℝ) / 50000000) ((-2763471 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((32132489 : ℝ) / 25000000)) (t := ((7132489 : ℝ) / 57132489))
    (lo := ((25099181 : ℝ) / 100000000)) (hi := ((12549591 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32132489 : ℝ) / 50000000) = Real.log ((32132489 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32132489 : ℝ) / 50000000) = ((32132489 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1423 : RB (Real.log ((1606661 : ℝ) / 2500000)) ((-44213263 : ℝ) / 100000000) ((-44213261 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1606661 : ℝ) / 1250000)) (t := ((356661 : ℝ) / 2856661))
    (lo := ((1568841 : ℝ) / 6250000)) (hi := ((25101457 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1606661 : ℝ) / 2500000) = Real.log ((1606661 : ℝ) / 1250000) - 1 * Real.log 2 := by
    rw [show ((1606661 : ℝ) / 2500000) = ((1606661 : ℝ) / 1250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1424 : RB (Real.log ((9790229 : ℝ) / 25000000)) ((-93749099 : ℝ) / 100000000) ((-93749097 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9790229 : ℝ) / 12500000)) (t := ((-2709771 : ℝ) / 22290229))
    (lo := ((-1221719 : ℝ) / 5000000)) (hi := ((-24434379 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9790229 : ℝ) / 25000000) = Real.log ((9790229 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9790229 : ℝ) / 25000000) = ((9790229 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1425 : RB (Real.log ((23793579 : ℝ) / 12500000)) ((6436871 : ℝ) / 10000000) ((8046089 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((23793579 : ℝ) / 25000000)) (t := ((-1206421 : ℝ) / 48793579))
    (lo := ((-618251 : ℝ) / 12500000)) (hi := ((-4946007 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23793579 : ℝ) / 12500000) = Real.log ((23793579 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((23793579 : ℝ) / 12500000) = ((23793579 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1426 : RB (Real.log ((95207371 : ℝ) / 50000000)) ((12880687 : ℝ) / 20000000) ((64403437 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((95207371 : ℝ) / 100000000)) (t := ((-4792629 : ℝ) / 195207371))
    (lo := ((-4911283 : ℝ) / 100000000)) (hi := ((-2455641 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95207371 : ℝ) / 50000000) = Real.log ((95207371 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95207371 : ℝ) / 50000000) = ((95207371 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1427 : RB (Real.log ((13005717 : ℝ) / 20000000)) ((-21517163 : ℝ) / 50000000) ((-10758581 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((13005717 : ℝ) / 10000000)) (t := ((3005717 : ℝ) / 23005717))
    (lo := ((26280393 : ℝ) / 100000000)) (hi := ((13140197 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13005717 : ℝ) / 20000000) = Real.log ((13005717 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((13005717 : ℝ) / 20000000) = ((13005717 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1428 : RB (Real.log ((32515027 : ℝ) / 50000000)) ((-43032067 : ℝ) / 100000000) ((-8606413 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((32515027 : ℝ) / 25000000)) (t := ((7515027 : ℝ) / 57515027))
    (lo := ((6570663 : ℝ) / 25000000)) (hi := ((26282653 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32515027 : ℝ) / 50000000) = Real.log ((32515027 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32515027 : ℝ) / 50000000) = ((32515027 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1429 : RB (Real.log ((19721213 : ℝ) / 50000000)) ((-5814551 : ℝ) / 6250000) ((-46516407 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19721213 : ℝ) / 25000000)) (t := ((-5278787 : ℝ) / 44721213))
    (lo := ((-23718097 : ℝ) / 100000000)) (hi := ((-1482381 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19721213 : ℝ) / 50000000) = Real.log ((19721213 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19721213 : ℝ) / 50000000) = ((19721213 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1430 : RB (Real.log ((20230273 : ℝ) / 5000000)) ((139774223 : ℝ) / 100000000) ((69887113 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((20230273 : ℝ) / 20000000)) (t := ((230273 : ℝ) / 40230273))
    (lo := ((1144787 : ℝ) / 100000000)) (hi := ((286197 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20230273 : ℝ) / 5000000) = Real.log ((20230273 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((20230273 : ℝ) / 5000000) = ((20230273 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1431 : RB (Real.log ((404608171 : ℝ) / 100000000)) ((139774893 : ℝ) / 100000000) ((8735931 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((404608171 : ℝ) / 400000000)) (t := ((4608171 : ℝ) / 804608171))
    (lo := ((1145457 : ℝ) / 100000000)) (hi := ((572729 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((404608171 : ℝ) / 100000000) = Real.log ((404608171 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((404608171 : ℝ) / 100000000) = ((404608171 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1432 : RB (Real.log ((132808771 : ℝ) / 100000000)) ((28374009 : ℝ) / 100000000) ((2837401 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((132808771 : ℝ) / 100000000)) (t := ((32808771 : ℝ) / 232808771))
    (lo := ((28374009 : ℝ) / 100000000)) (hi := ((2837401 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1433 : RB (Real.log ((80640367 : ℝ) / 20000000)) ((34856677 : ℝ) / 25000000) ((139426711 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((80640367 : ℝ) / 80000000)) (t := ((640367 : ℝ) / 160640367))
    (lo := ((99659 : ℝ) / 12500000)) (hi := ((797273 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((80640367 : ℝ) / 20000000) = Real.log ((80640367 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((80640367 : ℝ) / 20000000) = ((80640367 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1434 : RB (Real.log ((403204533 : ℝ) / 100000000)) ((139427377 : ℝ) / 100000000) ((6971369 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((403204533 : ℝ) / 400000000)) (t := ((3204533 : ℝ) / 803204533))
    (lo := ((797941 : ℝ) / 100000000)) (hi := ((398971 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((403204533 : ℝ) / 100000000) = Real.log ((403204533 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((403204533 : ℝ) / 100000000) = ((403204533 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1435 : RB (Real.log ((66480327 : ℝ) / 50000000)) ((14244153 : ℝ) / 50000000) ((28488307 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66480327 : ℝ) / 50000000)) (t := ((16480327 : ℝ) / 116480327))
    (lo := ((14244153 : ℝ) / 50000000)) (hi := ((28488307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1436 : RB (Real.log ((12309813 : ℝ) / 100000000)) ((-209477347 : ℝ) / 100000000) ((-209477343 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12309813 : ℝ) / 12500000)) (t := ((-190187 : ℝ) / 24809813))
    (lo := ((-153319 : ℝ) / 10000000)) (hi := ((-1533189 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12309813 : ℝ) / 100000000) = Real.log ((12309813 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12309813 : ℝ) / 100000000) = ((12309813 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1437 : RB (Real.log ((6561051 : ℝ) / 50000000)) ((-25385903 : ℝ) / 12500000) ((-10154361 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((6561051 : ℝ) / 6250000)) (t := ((311051 : ℝ) / 12811051))
    (lo := ((4856933 : ℝ) / 100000000)) (hi := ((2428467 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6561051 : ℝ) / 50000000) = Real.log ((6561051 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6561051 : ℝ) / 50000000) = ((6561051 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1438 : RB (Real.log ((946429 : ℝ) / 20000000)) ((-76269791 : ℝ) / 25000000) ((-305079159 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((946429 : ℝ) / 1250000)) (t := ((-303571 : ℝ) / 2196429))
    (lo := ((-108673 : ℝ) / 390625)) (hi := ((-27820287 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((946429 : ℝ) / 20000000) = Real.log ((946429 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((946429 : ℝ) / 20000000) = ((946429 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1439 : RB (Real.log ((4767673 : ℝ) / 100000000)) ((-76082797 : ℝ) / 25000000) ((-304331183 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4767673 : ℝ) / 6250000)) (t := ((-1482327 : ℝ) / 11017673))
    (lo := ((-3384039 : ℝ) / 12500000)) (hi := ((-27072311 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4767673 : ℝ) / 100000000) = Real.log ((4767673 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4767673 : ℝ) / 100000000) = ((4767673 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
