import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk06
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_20 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((343256254946664285876646754385919 : ℝ) / 5192296858534827628530496329220096) ((87307660379878980477199580345139 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((66108749999 : ℝ) / 1000000000000) ((21523 : ℝ) / 320000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1066108749999 : ℝ) / 1000000000000) ((341523 : ℝ) / 320000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((4000958589 : ℝ) / 62500000000) ((16273507719 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_359.1 dlower_log_360.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((4000958589 : ℝ) / 31250000000) ((16273507719 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((562959118807 : ℝ) / 1000000000000) ((35319781607 : ℝ) / 62500000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-169778385357 : ℝ) / 62500000000) ((-269919886501 : ℝ) / 100000000000) := rb_log hqr (by norm_num) dlower_log_361.1 dlower_log_362.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((269919886501 : ℝ) / 100000000000) ((169778385357 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((51810106527 : ℝ) / 250000000000) ((209364531469 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((790635468531 : ℝ) / 1000000000000) ((198189893473 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2185183413 : ℝ) / 500000000000) ((2261911763 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((47502091159 : ℝ) / 125000000000)) - (z9)
  have h10 : RB z10 ((187746452873 : ℝ) / 500000000000) ((187823181223 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((47502091159 : ℝ) / 125000000000) ((47502091159 : ℝ) / 125000000000) ((47502091159 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((77497908841 : ℝ) / 125000000000))
  have h11 : RB z11 ((605650061017 : ℝ) / 1000000000000) ((605897578503 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((77497908841 : ℝ) / 125000000000) ((77497908841 : ℝ) / 125000000000) ((77497908841 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-250726458387 : ℝ) / 500000000000) ((-501044319567 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_363.1 dlower_log_364.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-397531600629 : ℝ) / 1000000000000) ((-79228682071 : ℝ) / 200000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((47502091159 : ℝ) / 125000000000))
  have h14 : RB z14 ((-967540002831 : ℝ) / 1000000000000) ((-967540002829 : ℝ) / 1000000000000) := rb_log (show RB ((47502091159 : ℝ) / 125000000000) ((47502091159 : ℝ) / 125000000000) ((47502091159 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_365.1 dlower_log_365.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((2850042011 : ℝ) / 5000000000) ((142849148119 : ℝ) / 250000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((611487061 : ℝ) / 125000000000) ((8437473669 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2185183413 : ℝ) / 500000000000) ((2261911763 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((719909964171 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((89706006551 : ℝ) / 62500000000) ((358862390379 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((719909964171 : ℝ) / 500000000000) ((719909964171 : ℝ) / 500000000000) ((719909964171 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((219909964171 : ℝ) / 500000000000))
  have h19 : RB z19 ((3263372149203 : ℝ) / 1000000000000) ((3263721057223 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((219909964171 : ℝ) / 500000000000) ((219909964171 : ℝ) / 500000000000) ((219909964171 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1182761062349 : ℝ) / 1000000000000) ((1182867973041 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_366.1 dlower_log_367.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((93513284669 : ℝ) / 100000000000) ((937729910279 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((719909964171 : ℝ) / 500000000000))
  have h22 : RB z22 ((72903611201 : ℝ) / 200000000000) ((364518056007 : ℝ) / 1000000000000) := rb_log (show RB ((719909964171 : ℝ) / 500000000000) ((719909964171 : ℝ) / 500000000000) ((719909964171 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_368.1 dlower_log_368.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((570614790683 : ℝ) / 1000000000000) ((286605927137 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5498284971 : ℝ) / 1000000000000) ((10252735467 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1066108749999 : ℝ) / 1000000000000) ((341523 : ℝ) / 320000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((142073483353 : ℝ) / 125000000000) ((569521286763 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1755860620563 : ℝ) / 1000000000000) ((879826390189 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((105980319907 : ℝ) / 100000000000))
  have h28 : RB z28 ((1860866702793 : ℝ) / 1000000000000) ((932442822949 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((105980319907 : ℝ) / 100000000000) ((105980319907 : ℝ) / 100000000000) ((105980319907 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2185183413 : ℝ) / 500000000000) ((2261911763 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((34197228744323265864189 : ℝ) / 62500000000000000000000))
  have h30 : RB z30 ((1996857177 : ℝ) / 250000000000) ((8267891311 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((34197228744323265864189 : ℝ) / 62500000000000000000000) ((34197228744323265864189 : ℝ) / 62500000000000000000000) ((34197228744323265864189 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((991732108689 : ℝ) / 1000000000000) ((248003142823 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((36909625183 : ℝ) / 20000000000) ((1849990004753 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((47502091159 : ℝ) / 125000000000)) ((611487061 : ℝ) / 125000000000) ((8437473669 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((719909964171 : ℝ) / 500000000000)) ((5498284971 : ℝ) / 1000000000000) ((10252735467 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((47502091159 : ℝ) / 125000000000)) (wl := ((719909964171 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((36909625183 : ℝ) / 20000000000) ≤ D0q (q) * (((719909964171 : ℝ) / 500000000000) - ((47502091159 : ℝ) / 125000000000)) * (1 - (q) ^ 2 / (((719909964171 : ℝ) / 500000000000) * ((47502091159 : ℝ) / 125000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_21 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((87307660379878980477199580345139 : ℝ) / 1298074214633706907132624082305024) ((355205028092367557940949888375193 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((67259374999 : ℝ) / 1000000000000) ((6841 : ℝ) / 100000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1067259374999 : ℝ) / 1000000000000) ((106841 : ℝ) / 100000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((520752247 : ℝ) / 8000000000) ((66171562001 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_369.1 dlower_log_370.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((520752247 : ℝ) / 4000000000) ((66171562001 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((560804056557 : ℝ) / 1000000000000) ((56295911881 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2699198865027 : ℝ) / 1000000000000) ((-83819883319 : ℝ) / 31250000000) := rb_log hqr (by norm_num) dlower_log_371.1 dlower_log_372.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((83819883319 : ℝ) / 31250000000) ((2699198865027 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((103883427009 : ℝ) / 500000000000) ((20988423947 : ℝ) / 100000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((79011576053 : ℝ) / 100000000000) ((396116572991 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((180952941 : ℝ) / 40000000000) ((46799281 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((94319865699 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((46574941837 : ℝ) / 125000000000) ((372755639271 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((94319865699 : ℝ) / 250000000000) ((94319865699 : ℝ) / 250000000000) ((94319865699 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((155680134301 : ℝ) / 250000000000))
  have h11 : RB z11 ((299170745491 : ℝ) / 500000000000) ((299296086287 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((155680134301 : ℝ) / 250000000000) ((155680134301 : ℝ) / 250000000000) ((155680134301 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-128398408217 : ℝ) / 250000000000) ((-513174759869 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_373.1 dlower_log_374.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-101721474881 : ℝ) / 250000000000) ((-202733732839 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((94319865699 : ℝ) / 250000000000))
  have h14 : RB z14 ((-974769085521 : ℝ) / 1000000000000) ((-974769085519 : ℝ) / 1000000000000) := rb_log (show RB ((94319865699 : ℝ) / 250000000000) ((94319865699 : ℝ) / 250000000000) ((94319865699 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_375.1 dlower_log_375.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((113576637199 : ℝ) / 200000000000) ((569301619843 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((984813437 : ℝ) / 200000000000) ((4248781643 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((180952941 : ℝ) / 40000000000) ((46799281 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1440573455627 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1435893527527 : ℝ) / 1000000000000) ((718024816051 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((1440573455627 : ℝ) / 1000000000000) ((1440573455627 : ℝ) / 1000000000000) ((1440573455627 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((440573455627 : ℝ) / 1000000000000))
  have h19 : RB z19 ((814786676993 : ℝ) / 250000000000) ((3259501029309 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((440573455627 : ℝ) / 1000000000000) ((440573455627 : ℝ) / 1000000000000) ((440573455627 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((236293083019 : ℝ) / 200000000000) ((118157412517 : ℝ) / 100000000000) := rb_log h19 (by norm_num) dlower_log_376.1 dlower_log_377.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((933494444987 : ℝ) / 1000000000000) ((187216437279 : ℝ) / 200000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1440573455627 : ℝ) / 1000000000000))
  have h22 : RB z22 ((365041267387 : ℝ) / 1000000000000) ((365041267389 : ℝ) / 1000000000000) := rb_log (show RB ((1440573455627 : ℝ) / 1000000000000) ((1440573455627 : ℝ) / 1000000000000) ((1440573455627 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_378.1 dlower_log_378.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((284226588799 : ℝ) / 500000000000) ((17845028719 : ℝ) / 31250000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1373514697 : ℝ) / 250000000000) ((10236862451 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1067259374999 : ℝ) / 1000000000000) ((106841 : ℝ) / 100000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1139042573523 : ℝ) / 1000000000000) ((11414999281 : ℝ) / 10000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((876040353033 : ℝ) / 500000000000) ((1755860620569 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1063293992831 : ℝ) / 1000000000000))
  have h28 : RB z28 ((372595377943 : ℝ) / 200000000000) ((18669960501 : ℝ) / 10000000000) := rb_widen (rb_mul h27 (show RB ((1063293992831 : ℝ) / 1000000000000) ((1063293992831 : ℝ) / 1000000000000) ((1063293992831 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((180952941 : ℝ) / 40000000000) ((46799281 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((135874694864282975838273 : ℝ) / 250000000000000000000000))
  have h30 : RB z30 ((4161760519 : ℝ) / 500000000000) ((8610742613 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((135874694864282975838273 : ℝ) / 250000000000000000000000) ((135874694864282975838273 : ℝ) / 250000000000000000000000) ((135874694864282975838273 : ℝ) / 250000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((991389257387 : ℝ) / 1000000000000) ((495838239481 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1846935275223 : ℝ) / 1000000000000) ((4628640173 : ℝ) / 2500000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((94319865699 : ℝ) / 250000000000)) ((984813437 : ℝ) / 200000000000) ((4248781643 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1440573455627 : ℝ) / 1000000000000)) ((1373514697 : ℝ) / 250000000000) ((10236862451 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((94319865699 : ℝ) / 250000000000)) (wl := ((1440573455627 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1846935275223 : ℝ) / 1000000000000) ≤ D0q (q) * (((1440573455627 : ℝ) / 1000000000000) - ((94319865699 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((1440573455627 : ℝ) / 1000000000000) * ((94319865699 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_22 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((355205028092367557940949888375193 : ℝ) / 5192296858534827628530496329220096) ((361179414665219193973101455369829 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((68409999999 : ℝ) / 1000000000000) ((111297 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1068409999999 : ℝ) / 1000000000000) ((1711297 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((66171561999 : ℝ) / 1000000000000) ((67247933301 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_379.1 dlower_log_380.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((66171561999 : ℝ) / 500000000000) ((67247933301 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((558651313957 : ℝ) / 1000000000000) ((280402028281 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-107289450649 : ℝ) / 40000000000) ((-1332778302243 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_381.1 dlower_log_382.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1332778302243 : ℝ) / 500000000000) ((107289450649 : ℝ) / 40000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((208278189729 : ℝ) / 1000000000000) ((10519455029 : ℝ) / 50000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((39480544971 : ℝ) / 50000000000) ((791721810271 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((4679928099 : ℝ) / 1000000000000) ((4838680551 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((374520265291 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((18484079237 : ℝ) / 50000000000) ((46230042149 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((374520265291 : ℝ) / 1000000000000) ((374520265291 : ℝ) / 1000000000000) ((374520265291 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((625479734709 : ℝ) / 1000000000000))
  have h11 : RB z11 ((295518435071 : ℝ) / 500000000000) ((591290679249 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((625479734709 : ℝ) / 1000000000000) ((625479734709 : ℝ) / 1000000000000) ((625479734709 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-105175375499 : ℝ) / 200000000000) ((-525447539429 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_383.1 dlower_log_384.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-416348193431 : ℝ) / 1000000000000) ((-207449552103 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((374520265291 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-982109364563 : ℝ) / 1000000000000) ((-982109364561 : ℝ) / 1000000000000) := rb_log (show RB ((374520265291 : ℝ) / 1000000000000) ((374520265291 : ℝ) / 1000000000000) ((374520265291 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_385.1 dlower_log_385.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((56576117113 : ℝ) / 100000000000) ((567210260357 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((619639321 : ℝ) / 125000000000) ((10698683 : ℝ) / 1250000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((4679928099 : ℝ) / 1000000000000) ((4838680551 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((288267201623 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((359124331891 : ℝ) / 250000000000) ((89791005001 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB ((288267201623 : ℝ) / 200000000000) ((288267201623 : ℝ) / 200000000000) ((288267201623 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((88267201623 : ℝ) / 200000000000))
  have h19 : RB z19 ((325488358337 : ℝ) / 100000000000) ((651048658437 : ℝ) / 200000000000) := rb_div_signed h18 (show RB ((88267201623 : ℝ) / 200000000000) ((88267201623 : ℝ) / 200000000000) ((88267201623 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((590078254771 : ℝ) / 500000000000) ((1180267017011 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_386.1 dlower_log_387.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((186372888591 : ℝ) / 200000000000) ((58402696207 : ℝ) / 62500000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((288267201623 : ℝ) / 200000000000))
  have h22 : RB z22 ((584912747 : ℝ) / 1600000000) ((365570466877 : ℝ) / 1000000000000) := rb_log (show RB ((288267201623 : ℝ) / 200000000000) ((288267201623 : ℝ) / 200000000000) ((288267201623 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_388.1 dlower_log_388.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((283146988039 : ℝ) / 500000000000) ((568872672437 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1372479879 : ℝ) / 250000000000) ((127766981 : ℝ) / 12500000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1068409999999 : ℝ) / 1000000000000) ((1711297 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1141499928097 : ℝ) / 1000000000000) ((1143959930551 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1748312984211 : ℝ) / 1000000000000) ((1752080706071 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((133351967853 : ℝ) / 125000000000))
  have h28 : RB z28 ((1865127814939 : ℝ) / 1000000000000) ((373829455987 : ℝ) / 200000000000) := rb_widen (rb_mul h27 (show RB ((133351967853 : ℝ) / 125000000000) ((133351967853 : ℝ) / 125000000000) ((133351967853 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((4679928099 : ℝ) / 1000000000000) ((4838680551 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((107961908826540145767293 : ℝ) / 200000000000000000000000))
  have h30 : RB z30 ((8669591247 : ℝ) / 1000000000000) ((4481840497 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((107961908826540145767293 : ℝ) / 200000000000000000000000) ((107961908826540145767293 : ℝ) / 200000000000000000000000) ((107961908826540145767293 : ℝ) / 200000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((495518159503 : ℝ) / 500000000000) ((991330408753 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((57762793881 : ℝ) / 31250000000) ((926471268519 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((374520265291 : ℝ) / 1000000000000)) ((619639321 : ℝ) / 125000000000) ((10698683 : ℝ) / 1250000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((288267201623 : ℝ) / 200000000000)) ((1372479879 : ℝ) / 250000000000) ((127766981 : ℝ) / 12500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((374520265291 : ℝ) / 1000000000000)) (wl := ((288267201623 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((57762793881 : ℝ) / 31250000000) ≤ D0q (q) * (((288267201623 : ℝ) / 200000000000) - ((374520265291 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((288267201623 : ℝ) / 200000000000) * ((374520265291 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_23 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((361179414665219193973101455369829 : ℝ) / 5192296858534827628530496329220096) ((183576900619035415002626511182233 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((69560624999 : ℝ) / 1000000000000) ((56569 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1069560624999 : ℝ) / 1000000000000) ((856569 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((67247933299 : ℝ) / 1000000000000) ((8540393409 : ℝ) / 125000000000) := rb_log h1 (by norm_num) dlower_log_389.1 dlower_log_390.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((67247933299 : ℝ) / 500000000000) ((8540393409 : ℝ) / 62500000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((111300177203 : ℝ) / 200000000000) ((279325656981 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2665556604503 : ℝ) / 1000000000000) ((-1324575297841 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_391.1 dlower_log_392.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1324575297841 : ℝ) / 500000000000) ((2665556604503 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((208774739607 : ℝ) / 1000000000000) ((210879409753 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((789120590247 : ℝ) / 1000000000000) ((791225260393 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((96773611 : ℝ) / 20000000000) ((5000080877 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((371739027723 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((183369473423 : ℝ) / 500000000000) ((366900347173 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((371739027723 : ℝ) / 1000000000000) ((371739027723 : ℝ) / 1000000000000) ((371739027723 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((628260972277 : ℝ) / 1000000000000))
  have h11 : RB z11 ((583736636571 : ℝ) / 1000000000000) ((9124899011 : ℝ) / 15625000000) := rb_div_signed h10 (show RB ((628260972277 : ℝ) / 1000000000000) ((628260972277 : ℝ) / 1000000000000) ((628260972277 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-107661072529 : ℝ) / 200000000000) ((-537865363501 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_393.1 dlower_log_394.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-42592080073 : ℝ) / 100000000000) ((-424440633119 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((371739027723 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-494781604641 : ℝ) / 500000000000) ((-3092385029 : ℝ) / 3125000000) := rb_log (show RB ((371739027723 : ℝ) / 1000000000000) ((371739027723 : ℝ) / 1000000000000) ((371739027723 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_395.1 dlower_log_395.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((11272848171 : ℝ) / 20000000000) ((565122576163 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1247773647 : ℝ) / 250000000000) ((2155422537 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((96773611 : ℝ) / 20000000000) ((5000080877 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((360526858277 : ℝ) / 250000000000)) - (z17)
  have h18 : RB z18 ((1437107352231 : ℝ) / 1000000000000) ((718634376279 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((360526858277 : ℝ) / 250000000000) ((360526858277 : ℝ) / 250000000000) ((360526858277 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((110526858277 : ℝ) / 250000000000))
  have h19 : RB z19 ((812646002199 : ℝ) / 250000000000) ((1625474539587 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((110526858277 : ℝ) / 250000000000) ((110526858277 : ℝ) / 250000000000) ((110526858277 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1178834675211 : ℝ) / 1000000000000) ((1178946978073 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_396.1 dlower_log_397.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((465121357353 : ℝ) / 500000000000) ((233203157429 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((360526858277 : ℝ) / 250000000000))
  have h22 : RB z22 ((73221107787 : ℝ) / 200000000000) ((366105538937 : ℝ) / 1000000000000) := rb_log (show RB ((360526858277 : ℝ) / 250000000000) ((360526858277 : ℝ) / 250000000000) ((360526858277 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_398.1 dlower_log_398.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((564137175769 : ℝ) / 1000000000000) ((566707090781 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5485861807 : ℝ) / 1000000000000) ((5103102383 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1069560624999 : ℝ) / 1000000000000) ((856569 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((285989982637 : ℝ) / 250000000000) ((1146422580877 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((87227870131 : ℝ) / 50000000000) ((1748312984217 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((214073681077 : ℝ) / 200000000000))
  have h28 : RB z28 ((233414890643 : ℝ) / 125000000000) ((1871338981031 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((214073681077 : ℝ) / 200000000000) ((214073681077 : ℝ) / 200000000000) ((214073681077 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((96773611 : ℝ) / 20000000000) ((5000080877 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((134021903763919795013271 : ℝ) / 250000000000000000000000))
  have h30 : RB z30 ((9025913701 : ℝ) / 1000000000000) ((4663492251 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((134021903763919795013271 : ℝ) / 250000000000000000000000) ((134021903763919795013271 : ℝ) / 250000000000000000000000) ((134021903763919795013271 : ℝ) / 250000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((495336507749 : ℝ) / 500000000000) ((990974086299 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1849902668603 : ℝ) / 1000000000000) ((1854448436883 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((371739027723 : ℝ) / 1000000000000)) ((1247773647 : ℝ) / 250000000000) ((2155422537 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((360526858277 : ℝ) / 250000000000)) ((5485861807 : ℝ) / 1000000000000) ((5103102383 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((371739027723 : ℝ) / 1000000000000)) (wl := ((360526858277 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1849902668603 : ℝ) / 1000000000000) ≤ D0q (q) * (((360526858277 : ℝ) / 250000000000) - ((371739027723 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((360526858277 : ℝ) / 250000000000) * ((371739027723 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
