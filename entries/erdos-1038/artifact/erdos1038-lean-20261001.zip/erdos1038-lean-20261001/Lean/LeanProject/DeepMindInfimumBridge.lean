import LeanProject.DeepMindModelBridge
import LeanProject.Stage9Final

/-!
# The official infimum and the existing root-vector model

These statements transfer proved results between the polynomial admissibility
contract used by DeepMind's formal-conjectures problem 1038 and the existing
root-vector model. The final exact-infimum and nonattainment statements take the
still-unproved sharp lower bound as an explicit hypothesis.
-/

open Set MeasureTheory Polynomial
open scoped ENNReal

namespace EP1038.DeepMind

/-- The official polynomial infimum equals the existing positive-length root-vector infimum. -/
theorem officialInf_eq_rootVectorInf :
    officialInf =
      (⨅ (n : ℕ) (_ : 0 < n) (r : Fin n → ℝ)
        (_ : ∀ i, r i ∈ Icc (-1 : ℝ) 1), volume (sublevel r)) := by
  rw [officialInf_eq_localInf]
  apply le_antisymm
  · refine le_iInf fun n => le_iInf fun hn => le_iInf fun r => le_iInf fun hr => ?_
    obtain ⟨p, hp, hset⟩ := root_vector_polynomial hn r hr
    calc localInf ≤ sublevelMeasure p :=
        iInf_le (fun p : {p : ℝ[X] // Admissible p} => sublevelMeasure p.1) ⟨p, hp⟩
      _ = volume (sublevel r) := by simp only [sublevelMeasure, hset]
  · refine le_iInf fun p => ?_
    obtain ⟨n, r, hn, hr, hset⟩ := polynomial_root_vector p.2
    calc (⨅ (n : ℕ) (_ : 0 < n) (r : Fin n → ℝ)
            (_ : ∀ i, r i ∈ Icc (-1 : ℝ) 1), volume (sublevel r))
        ≤ volume (sublevel r) := iInf₂_le_of_le n hn (iInf₂_le_of_le r hr le_rfl)
      _ = sublevelMeasure p.1 := by simp only [sublevelMeasure, hset]

/-- The already-proved approximation theorem supplies the upper direction of the exact infimum. -/
theorem officialInf_le_D : officialInf ≤ ENNReal.ofReal Stage9.Dval := by
  rw [officialInf_eq_rootVectorInf]
  exact Stage9.iInf_le_D

/-- A strict infimum bound is equivalent to one admissible polynomial witness. -/
theorem officialInf_lt_iff (c : ℝ≥0∞) :
    officialInf < c ↔
      ∃ p : ℝ[X], InfAdmissible p ∧ volume {x : ℝ | |p.eval x| < 1} < c := by
  change (⨅ p : {p : ℝ[X] // InfAdmissible p},
    volume {x : ℝ | |p.1.eval x| < 1}) < c ↔ _
  rw [iInf_lt_iff]
  constructor
  · rintro ⟨p, hp⟩
    exact ⟨p.1, p.2, hp⟩
  · rintro ⟨p, hp, hmeasure⟩
    exact ⟨⟨p, hp⟩, hmeasure⟩

/-- The `infimum < 1.835` variant needs just one polynomial below that threshold. -/
theorem officialInf_lt_1835_iff :
    officialInf < ENNReal.ofReal (1835 / 1000 : ℝ) ↔
      ∃ p : ℝ[X], InfAdmissible p ∧
        volume {x : ℝ | |p.eval x| < 1} < ENNReal.ofReal (1835 / 1000 : ℝ) :=
  officialInf_lt_iff _

/-- The proved upper direction makes exactness equivalent to the universal sharp lower bound. -/
theorem officialInf_eq_D_iff :
    officialInf = ENNReal.ofReal Stage9.Dval ↔
      ∀ p : ℝ[X], InfAdmissible p →
        ENNReal.ofReal Stage9.Dval ≤ volume {x : ℝ | |p.eval x| < 1} := by
  constructor
  · intro heq p hp
    rw [← heq]
    exact iInf_le (fun p : {p : ℝ[X] // InfAdmissible p} =>
      volume {x : ℝ | |p.1.eval x| < 1}) ⟨p, hp⟩
  · intro hbound
    apply le_antisymm officialInf_le_D
    exact le_iInf fun p => hbound p.1 p.2

/-- The strict sharp lower bound implies exactness, but is a hypothesis of this theorem. -/
theorem officialInf_eq_D_of_strict_lower
    (hstrict : ∀ p : ℝ[X], InfAdmissible p →
      ENNReal.ofReal Stage9.Dval < volume {x : ℝ | |p.eval x| < 1}) :
    officialInf = ENNReal.ofReal Stage9.Dval :=
  officialInf_eq_D_iff.mpr fun p hp => (hstrict p hp).le

/-- Under the strict sharp lower bound, no admissible polynomial attains the infimum. -/
theorem officialInf_not_attained_of_strict_lower
    (hstrict : ∀ p : ℝ[X], InfAdmissible p →
      ENNReal.ofReal Stage9.Dval < volume {x : ℝ | |p.eval x| < 1}) :
    ∀ p : ℝ[X], InfAdmissible p →
      volume {x : ℝ | |p.eval x| < 1} ≠ officialInf := by
  intro p hp
  rw [officialInf_eq_D_of_strict_lower hstrict]
  exact ne_of_gt (hstrict p hp)

/-- Exact infimum and nonattainment follow from the explicitly assumed strict lower bound. -/
theorem strict_lower_implies_exact_inf_and_nonattainment
    (hstrict : ∀ p : ℝ[X], InfAdmissible p →
      ENNReal.ofReal Stage9.Dval < volume {x : ℝ | |p.eval x| < 1}) :
    officialInf = ENNReal.ofReal Stage9.Dval ∧
      ∀ p : ℝ[X], InfAdmissible p →
        volume {x : ℝ | |p.eval x| < 1} ≠ officialInf :=
  ⟨officialInf_eq_D_of_strict_lower hstrict,
    officialInf_not_attained_of_strict_lower hstrict⟩

end EP1038.DeepMind
