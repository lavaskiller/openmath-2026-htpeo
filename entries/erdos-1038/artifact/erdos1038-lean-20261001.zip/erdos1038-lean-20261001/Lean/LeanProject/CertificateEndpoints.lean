import LeanProject.CertificateExterior

/-! Identification of certificate roots with the constructed reference endpoints. -/

open Real Set

namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

theorem separated_positive_root_unique (R : SeparatedReference) {x : ℝ}
    (hx0 : 0 < x) (hxr : x < R.separator)
    (hW : Stage10.WS R.angles.k R.quantile x = 0) :
    x = Stage10.xpS R.angles.k R.quantile := by
  obtain ⟨hp, _, _, hm, _⟩ := Stage10.sep_series R.quantile_measurable R.left_pos
    R.quantile_lower R.quantile_upper R.angles.k_pos R.separator_pos R.separator_lt_left R.separation
  rcases lt_trichotomy x (Stage10.xpS R.angles.k R.quantile) with h | h | h
  · have := Stage10.W_mid_neg R.quantile_measurable R.left_pos R.quantile_lower
      R.quantile_upper R.angles.k_pos R.separator_pos R.separator_lt_left R.separation
      (hm.trans hx0) h hx0.ne'
    linarith
  · exact h
  · have := Stage10.W_right_pos R.quantile_measurable R.left_pos R.quantile_lower
      R.quantile_upper R.angles.k_pos R.separator_pos R.separator_lt_left R.separation h hxr.le
    linarith

theorem separated_negative_root_unique (R : SeparatedReference) {x : ℝ}
    (hx : x < 0) (hW : Stage10.WS R.angles.k R.quantile x = 0) :
    x = Stage10.xmS R.angles.k R.quantile := by
  obtain ⟨hp, _, _, _, _⟩ := Stage10.sep_series R.quantile_measurable R.left_pos
    R.quantile_lower R.quantile_upper R.angles.k_pos R.separator_pos R.separator_lt_left R.separation
  rcases lt_trichotomy x (Stage10.xmS R.angles.k R.quantile) with h | h | h
  · have := Stage10.W_left_pos R.quantile_measurable R.left_pos R.quantile_lower
      R.quantile_upper R.angles.k_pos R.separator_pos R.separator_lt_left R.separation h
    linarith
  · exact h
  · have := Stage10.W_mid_neg R.quantile_measurable R.left_pos R.quantile_lower
      R.quantile_upper R.angles.k_pos R.separator_pos R.separator_lt_left R.separation h
      (hx.trans hp) hx.ne
    linarith

theorem exterior_parameter_unique {c r p q : ℝ} (hr : 0 < r)
    (hp : p ∈ Ioo 0 1) (hq : q ∈ Ioo 0 1)
    (heq : c - r / 2 * (p + 1 / p) = c - r / 2 * (q + 1 / q)) : p = q := by
  have hsum : p + 1 / p = q + 1 / q := by nlinarith
  have hprod : p * q < 1 := by
    calc p * q < 1 * q := mul_lt_mul_of_pos_right hp.2 hq.1
      _ < 1 := by simpa using hq.2
  have he : (p - q) * (p * q - 1) = 0 := by
    have h := hsum
    field_simp [hp.1.ne', hq.1.ne'] at h
    nlinarith [h]
  exact sub_eq_zero.mp ((mul_eq_zero.mp he).resolve_right (by linarith))

section constructed
variable {k a v0 : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
  (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hv0 : qa a < v0) (hv01 : v0 < 1)
  (hE0 : certE k a v0 < 0)
include hk ha ha2 hH1 hv0 hv01 hE0
local notation "R" => referenceOfCertificate hk ha ha2 hH1 hv0 hv01 hE0

theorem certificate_reference_quantile : (R).quantile = intervalQuantile k a hk ha ha2 hH1 := rfl

theorem certificate_root_plus {v : ℝ} (hv0v : v0 < v) (hv1 : v < 1)
    (hE : certE k a v = 0) : certPoint a v = Stage10.xpS (R).angles.k (R).quantile := by
  have hvq := hv0.trans hv0v
  apply separated_positive_root_unique R (certPoint_bounds ha ha2 hvq hv1).1
  · exact certPoint_strictAntiOn ha ha2 hv0 hvq hv0v
  · change Stage10.WS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) = 0
    rw [certificate_potential_eq_exterior hk ha ha2 hH1 hvq hv1.ne, hE, mul_zero]

theorem certificate_root_minus {v : ℝ} (hv1 : 1 < v) (hE : certE k a v = 0) :
    certPoint a v = Stage10.xmS (R).angles.k (R).quantile := by
  apply separated_negative_root_unique R (certPoint_neg ha ha2 hv1)
  change Stage10.WS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) = 0
  rw [certificate_potential_eq_exterior hk ha ha2 hH1 ((qa_lt_one ha).trans hv1) hv1.ne',
    hE, mul_zero]

theorem certPoint_poisson {v : ℝ} (hvq : qa a < v) :
    certPoint a v = (R).c - (R).r / 2 * (qa a / v + 1 / (qa a / v)) := by
  have hq := qa_pos ha ha2
  have hv := hq.trans hvq
  have h := D0a_mul_qa ha
  change certPoint a v = (a + 2) / 2 - ((2 - a) / 2) / 2 * _
  rw [certPoint_eq_xoff ha ha2 hv]
  unfold xoff
  rw [D0a_mul_one_add ha]
  linear_combination -h * (qa a / v + 1 / (qa a / v))

theorem certificate_rho_plus {v : ℝ} (hv0v : v0 < v) (hv1 : v < 1)
    (hE : certE k a v = 0) : (R).rhoPlus = qa a / v := by
  have hvq := hv0.trans hv0v
  obtain ⟨_, _, hp, hp1⟩ := exterior_parameter_bounds ha ha2 hvq
  apply exterior_parameter_unique (R).radius_pos ⟨(R).rhoPlus_spec.1, (R).rhoPlus_spec.2.1⟩ ⟨hp, hp1⟩
  rw [← (R).rhoPlus_spec.2.2, ← certPoint_poisson hk ha ha2 hH1 hv0 hv01 hE0 hvq]
  exact (certificate_root_plus hk ha ha2 hH1 hv0 hv01 hE0 hv0v hv1 hE).symm

theorem certificate_rho_minus {v : ℝ} (hv1 : 1 < v) (hE : certE k a v = 0) :
    (R).rhoMinus = qa a / v := by
  have hvq := (qa_lt_one ha).trans hv1
  obtain ⟨_, _, hp, hp1⟩ := exterior_parameter_bounds ha ha2 hvq
  apply exterior_parameter_unique (R).radius_pos ⟨(R).rhoMinus_spec.1, (R).rhoMinus_spec.2.1⟩ ⟨hp, hp1⟩
  rw [← (R).rhoMinus_spec.2.2, ← certPoint_poisson hk ha ha2 hH1 hv0 hv01 hE0 hvq]
  exact (certificate_root_minus hk ha ha2 hH1 hv0 hv01 hE0 hv1 hE).symm

theorem certificate_slope_plus {v : ℝ} (hv0v : v0 < v) (hv1 : v < 1)
    (hE : certE k a v = 0) :
    (R).angles.k * Stage10.GS (R).angles.k (R).quantile (Stage10.xpS (R).angles.k (R).quantile) =
      (k + 1) * certEprime k a v / (D0a a * (1 - (qa a) ^ 2 / v ^ 2)) := by
  rw [← certificate_root_plus hk ha ha2 hH1 hv0 hv01 hE0 hv0v hv1 hE]
  exact certificate_slope_eq hk ha ha2 hH1 (hv0.trans hv0v) hv1.ne

theorem certificate_slope_minus {v : ℝ} (hv1 : 1 < v) (hE : certE k a v = 0) :
    (R).angles.k * Stage10.GS (R).angles.k (R).quantile (Stage10.xmS (R).angles.k (R).quantile) =
      (k + 1) * certEprime k a v / (D0a a * (1 - (qa a) ^ 2 / v ^ 2)) := by
  rw [← certificate_root_minus hk ha ha2 hH1 hv0 hv01 hE0 hv1 hE]
  exact certificate_slope_eq hk ha ha2 hH1 ((qa_lt_one ha).trans hv1) hv1.ne'

theorem certificate_Eprime_plus_pos {v : ℝ} (hv0v : v0 < v) (hv1 : v < 1)
    (hE : certE k a v = 0) : 0 < certEprime k a v := by
  have h := (R).slope_plus_pos
  rw [certificate_slope_plus hk ha ha2 hH1 hv0 hv01 hE0 hv0v hv1 hE] at h
  have hd : 0 < D0a a * (1 - (qa a) ^ 2 / v ^ 2) := by
    have := certPoint_derivative_neg ha ha2 (hv0.trans hv0v); linarith
  have hn := (div_pos_iff_of_pos_right hd).mp h
  exact (mul_pos_iff_of_pos_left (show (0 : ℝ) < k + 1 by linarith)).mp hn

theorem certificate_Eprime_minus_neg {v : ℝ} (hv1 : 1 < v) (hE : certE k a v = 0) :
    certEprime k a v < 0 := by
  have h := (R).slope_minus_neg
  rw [certificate_slope_minus hk ha ha2 hH1 hv0 hv01 hE0 hv1 hE] at h
  have hd : 0 < D0a a * (1 - (qa a) ^ 2 / v ^ 2) := by
    have := certPoint_derivative_neg ha ha2 ((qa_lt_one ha).trans hv1); linarith
  have hn : (k + 1) * certEprime k a v < 0 := by
    simpa only [zero_mul] using (div_lt_iff₀ hd).mp h
  by_contra hprime
  have hnn := mul_nonneg (show (0 : ℝ) ≤ k + 1 by linarith) (le_of_not_gt hprime)
  linarith

theorem certificate_sigma_plus {v : ℝ} (hv0v : v0 < v) (hv1 : v < 1)
    (hE : certE k a v = 0) :
    (R).sigmaPlus = D0a a * (1 - (qa a) ^ 2 / v ^ 2) / ((k + 1) * certEprime k a v) := by
  unfold SeparatedReference.sigmaPlus
  rw [certificate_slope_plus hk ha ha2 hH1 hv0 hv01 hE0 hv0v hv1 hE, one_div_div]

theorem certificate_sigma_minus {v : ℝ} (hv1 : 1 < v) (hE : certE k a v = 0) :
    (R).sigmaMinus = -(D0a a * (1 - (qa a) ^ 2 / v ^ 2) / ((k + 1) * certEprime k a v)) := by
  unfold SeparatedReference.sigmaMinus
  rw [certificate_slope_minus hk ha ha2 hH1 hv0 hv01 hE0 hv1 hE, one_div_div]

theorem certificate_width {vp vm : ℝ} (hvp0 : v0 < vp) (hvp1 : vp < 1)
    (hEp : certE k a vp = 0) (hvm1 : 1 < vm) (hEm : certE k a vm = 0) :
    referenceWidth R = certPoint a vp - certPoint a vm := by
  rw [referenceWidth, Stage10.volume_correctedNegSet_sep (R).quantile_measurable (R).left_pos
    (R).quantile_lower (R).quantile_upper (R).angles.k_pos (R).separator_pos (R).separator_lt_left (R).separation,
    ← certificate_root_plus hk ha ha2 hH1 hv0 hv01 hE0 hvp0 hvp1 hEp,
    ← certificate_root_minus hk ha ha2 hH1 hv0 hv01 hE0 hvm1 hEm]

theorem certificate_plus_bracket {lo hi : ℝ} (hlo : v0 < lo) (hhi : hi < 1)
    (horder : lo < hi) (hEl : certE k a lo < 0) (hEh : 0 < certE k a hi) :
    ∃ v ∈ Ioo lo hi, certE k a v = 0 ∧
      certPoint a v = Stage10.xpS (R).angles.k (R).quantile := by
  have hc : ContinuousOn (certE k a) (Icc lo hi) := by
    intro v hv
    exact (hasDerivAt_certE ha ha2 (hv0.trans (hlo.trans_le hv.1))
      (hv.2.trans_lt hhi).ne).continuousAt.continuousWithinAt
  obtain ⟨v, hv, hE⟩ := intermediate_value_Icc horder.le hc ⟨hEl.le, hEh.le⟩
  have hlv : lo < v := by
    rcases hv.1.lt_or_eq with h | h
    · exact h
    · rw [← h] at hE; linarith
  have hvh : v < hi := by
    rcases hv.2.lt_or_eq with h | h
    · exact h
    · rw [h] at hE; linarith
  exact ⟨v, ⟨hlv, hvh⟩, hE,
    certificate_root_plus hk ha ha2 hH1 hv0 hv01 hE0 (hlo.trans hlv) (hvh.trans hhi) hE⟩

theorem certificate_minus_bracket {lo hi : ℝ} (hlo : 1 < lo) (horder : lo < hi)
    (hEl : 0 < certE k a lo) (hEh : certE k a hi < 0) :
    ∃ v ∈ Ioo lo hi, certE k a v = 0 ∧
      certPoint a v = Stage10.xmS (R).angles.k (R).quantile := by
  have hc : ContinuousOn (fun v => -certE k a v) (Icc lo hi) := by
    intro v hv
    have hv1 := hlo.trans_le hv.1
    exact (hasDerivAt_certE ha ha2 ((qa_lt_one ha).trans hv1) hv1.ne').neg.continuousAt.continuousWithinAt
  obtain ⟨v, hv, hE⟩ := intermediate_value_Icc horder.le hc
    (show (0 : ℝ) ∈ Icc (-certE k a lo) (-certE k a hi) from ⟨by linarith, by linarith⟩)
  have hzero : certE k a v = 0 := by linarith
  have hlv : lo < v := by
    rcases hv.1.lt_or_eq with h | h
    · exact h
    · rw [← h] at hzero; linarith
  have hvh : v < hi := by
    rcases hv.2.lt_or_eq with h | h
    · exact h
    · rw [h] at hzero; linarith
  exact ⟨v, ⟨hlv, hvh⟩, hzero,
    certificate_root_minus hk ha ha2 hH1 hv0 hv01 hE0 (hlo.trans hlv) hzero⟩

end constructed
end EP1038.ReferenceCert
