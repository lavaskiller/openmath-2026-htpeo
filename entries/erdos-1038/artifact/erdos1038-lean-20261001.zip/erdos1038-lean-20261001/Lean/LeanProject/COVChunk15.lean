import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk11
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_75 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((249 : ℝ) / 377) ((3129 : ℝ) / 4729))
    (hq : RB (qa a) ((472367 : ℝ) / 20000000) ((2397261 : ℝ) / 100000000))
    (hd : RB (D0a a) ((95372533 : ℝ) / 50000000) ((596491 : ℝ) / 312500))
    : certE k a ((9806661 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((19901593 : ℝ) / 50000000) ∧ 0 < certE k a ((13239941 : ℝ) / 10000000) ∧ certE k a ((66353659 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((27891 : ℝ) / 50000000) ((57469 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((9806661 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((1566767 : ℝ) / 4000000) ((19585431 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((9806661 : ℝ) / 25000000) ((9806661 : ℝ) / 25000000) ((9806661 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((15193339 : ℝ) / 25000000))
  have h3 : RB z3 ((64451229 : ℝ) / 100000000) ((32227003 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((15193339 : ℝ) / 25000000) ((15193339 : ℝ) / 25000000) ((15193339 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2196307 : ℝ) / 5000000) ((-4392183 : ℝ) / 10000000) := rb_log h3 (by norm_num) cov_log_1350.1 cov_log_1351.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-14532131 : ℝ) / 50000000) ((-14504689 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((9806661 : ℝ) / 25000000))
  have h6 : RB z6 ((-93581399 : ℝ) / 100000000) ((-93581397 : ℝ) / 100000000) := rb_log (show RB ((9806661 : ℝ) / 25000000) ((9806661 : ℝ) / 25000000) ((9806661 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1352.1 cov_log_1352.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((12903427 : ℝ) / 20000000) ((64572021 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64576761 : ℝ) / 100000000) ((6464597 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1353.1 cov_log_1354.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-25767 : ℝ) / 20000000) ((-237 : ℝ) / 5000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((27891 : ℝ) / 50000000) ((57469 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19901593 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((39745717 : ℝ) / 100000000) ((9936851 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((19901593 : ℝ) / 50000000) ((19901593 : ℝ) / 50000000) ((19901593 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30098407 : ℝ) / 50000000))
  have h12 : RB z12 ((1650657 : ℝ) / 2500000) ((66029083 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((30098407 : ℝ) / 50000000) ((30098407 : ℝ) / 50000000) ((30098407 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-5188967 : ℝ) / 12500000) ((-1297109 : ℝ) / 3125000) := rb_log h12 (by norm_num) cov_log_1355.1 cov_log_1356.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-13733371 : ℝ) / 50000000) ((-27414759 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19901593 : ℝ) / 50000000))
  have h15 : RB z15 ((-23030581 : ℝ) / 25000000) ((-46061161 : ℝ) / 50000000) := rb_log (show RB ((19901593 : ℝ) / 50000000) ((19901593 : ℝ) / 50000000) ((19901593 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1357.1 cov_log_1357.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((3232779 : ℝ) / 5000000) ((12941513 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64576761 : ℝ) / 100000000) ((6464597 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1353.1 cov_log_1354.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((961 : ℝ) / 10000000) ((32701 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((27891 : ℝ) / 50000000) ((57469 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((13239941 : ℝ) / 10000000)) - (z19)
  have h20 : RB z20 ((132341941 : ℝ) / 100000000) ((33085907 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((13239941 : ℝ) / 10000000) ((13239941 : ℝ) / 10000000) ((13239941 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((3239941 : ℝ) / 10000000))
  have h21 : RB z21 ((408470219 : ℝ) / 100000000) ((204237713 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((3239941 : ℝ) / 10000000) ((3239941 : ℝ) / 10000000) ((3239941 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((70362441 : ℝ) / 50000000) ((140726159 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1358.1 cov_log_1359.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92945611 : ℝ) / 100000000) ((23278291 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((13239941 : ℝ) / 10000000))
  have h24 : RB z24 ((280653 : ℝ) / 1000000) ((28065301 : ℝ) / 100000000) := rb_log (show RB ((13239941 : ℝ) / 10000000) ((13239941 : ℝ) / 10000000) ((13239941 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1360.1 cov_log_1360.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((6488031 : ℝ) / 10000000) ((8130983 : ℝ) / 12500000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64576761 : ℝ) / 100000000) ((6464597 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1353.1 cov_log_1354.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((11717 : ℝ) / 5000000) ((471103 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((27891 : ℝ) / 50000000) ((57469 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((66353659 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((132649849 : ℝ) / 100000000) ((8290721 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((66353659 : ℝ) / 50000000) ((66353659 : ℝ) / 50000000) ((66353659 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((16353659 : ℝ) / 50000000))
  have h30 : RB z30 ((101391567 : ℝ) / 25000000) ((202785713 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((16353659 : ℝ) / 50000000) ((16353659 : ℝ) / 50000000) ((16353659 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((140011409 : ℝ) / 100000000) ((35003171 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_1361.1 cov_log_1362.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46237189 : ℝ) / 50000000) ((18528217 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((66353659 : ℝ) / 50000000))
  have h33 : RB z33 ((2829759 : ℝ) / 10000000) ((28297591 : ℝ) / 100000000) := rb_log (show RB ((66353659 : ℝ) / 50000000) ((66353659 : ℝ) / 50000000) ((66353659 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1363.1 cov_log_1363.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((64176787 : ℝ) / 100000000) ((12868699 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64576761 : ℝ) / 100000000) ((6464597 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1353.1 cov_log_1354.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-469183 : ℝ) / 100000000) ((-116633 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((9806661 : ℝ) / 25000000)) ((-25767 : ℝ) / 20000000) ((-237 : ℝ) / 5000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19901593 : ℝ) / 50000000)) ((961 : ℝ) / 10000000) ((32701 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((13239941 : ℝ) / 10000000)) ((11717 : ℝ) / 5000000) ((471103 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((66353659 : ℝ) / 50000000)) ((-469183 : ℝ) / 100000000) ((-116633 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_75 {k A q d vp vm : ℝ}
    (hk : RB k ((249 : ℝ) / 128) ((3129 : ℝ) / 1600))
    (hA : RB A ((249 : ℝ) / 377) ((3129 : ℝ) / 4729))
    (hq : RB q ((472367 : ℝ) / 20000000) ((2397261 : ℝ) / 100000000))
    (hd : RB d ((95372533 : ℝ) / 50000000) ((596491 : ℝ) / 312500))
    (hp : RB vp ((9806661 : ℝ) / 25000000) ((19901593 : ℝ) / 50000000))
    (hm : RB vm ((13239941 : ℝ) / 10000000) ((66353659 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((27891 : ℝ) / 50000000) ((57469 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99942531 : ℝ) / 100000000) ((49972109 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((16502447 : ℝ) / 25000000) ((661293 : ℝ) / 1000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((8759 : ℝ) / 6250000) ((73253 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49926747 : ℝ) / 50000000) ((6241241 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30098407 : ℝ) / 50000000) ((15193339 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((30054311 : ℝ) / 50000000) ((30344093 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((108768761 : ℝ) / 100000000) ((110016331 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((8768761 : ℝ) / 100000000) ((10016331 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99942531 : ℝ) / 100000000) ((49972109 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((16502447 : ℝ) / 25000000) ((661293 : ℝ) / 1000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((42033 : ℝ) / 100000000) ((21703 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49978297 : ℝ) / 50000000) ((99957967 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((3239941 : ℝ) / 10000000) ((16353659 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((16192673 : ℝ) / 50000000) ((32693571 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((20190449 : ℝ) / 10000000) ((51048783 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((30190449 : ℝ) / 10000000) ((76048783 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((499184781 : ℝ) / 50000000) ((114041197 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6574727 : ℝ) / 20000000) ((33123059 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((249 : ℝ) / 64) ((3129 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4594507 : ℝ) / 50000000) ((293009 : ℝ) / 3125000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((20472367 : ℝ) / 20000000) ((102397261 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4486943 : ℝ) / 50000000) ((4579973 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((54486943 : ℝ) / 50000000) ((54579973 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((361704 : ℝ) / 390625) ((46740337 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((22077841 : ℝ) / 12500000) ((178433219 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((10387169 : ℝ) / 20000000) ((52821741 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((26401 : ℝ) / 25000000) ((55327 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49944673 : ℝ) / 50000000) ((24973599 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((176427287 : ℝ) / 100000000) ((178244787 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((95372533 : ℝ) / 25000000) ((596491 : ℝ) / 156250) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((9010167 : ℝ) / 100000000) ((4575823 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((377 : ℝ) / 128) ((4729 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((3048481 : ℝ) / 100000000) ((3107191 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5933783 : ℝ) / 100000000) ((1527827 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105933783 : ℝ) / 100000000) ((26527827 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((211522129 : ℝ) / 20000000) ((605053029 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((444933 : ℝ) / 25000000) ((1810629 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25444933 : ℝ) / 25000000) ((101810629 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33458697 : ℝ) / 100000000) ((6744559 : ℝ) / 20000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((545534671 : ℝ) / 50000000) ((1243828853 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((33261041 : ℝ) / 100000000) ((38648139 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((377 : ℝ) / 128) ((4729 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((54486943 : ℝ) / 25000000) ((54579973 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1031243197 : ℝ) / 100000000) ((1173535029 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2247571571 : ℝ) / 100000000) ((320257551 : ℝ) / 12500000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((5747937 : ℝ) / 50000000) ((2630061 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-216318203 : ℝ) / 100000000) ((-202872523 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1364.1 cov_log_1365.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((4505083 : ℝ) / 100000000) ((4575823 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-309996391 : ℝ) / 100000000) ((-308438361 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1366.1 cov_log_1367.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64576761 : ℝ) / 100000000) ((6464597 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1353.1 cov_log_1354.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((6281099 : ℝ) / 5000000) ((31605819 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-184374411 : ℝ) / 100000000) ((-36403017 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((259913 : ℝ) / 5000000) ((7015761 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((672511 : ℝ) / 5000000) ((21093029 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-170924191 : ℝ) / 100000000) ((-20115257 : ℝ) / 12500000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((54486943 : ℝ) / 50000000) ((54579973 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-216318203 : ℝ) / 100000000) ((-202872523 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-170924191 : ℝ) / 100000000) ((-20115257 : ℝ) / 12500000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((289 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5933783 : ℝ) / 100000000) ((1527827 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((26527827 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((289 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-184012657 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((289 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_29, cov_h_25]
  have hP : ((115778877 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((20115257 : ℝ) / 12500000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((20115257 : ℝ) / 12500000))
    linarith [hap.2]
  have hS : ((1862041 : ℝ) / 3125000) ≤ EP1038.Arc.sinc ((167 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((397 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2511 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2511 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2551 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2551 : ℝ) / 1000)) (lo := ((2511 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2591 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2591 : ℝ) / 1000)) (lo := ((2551 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2631 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2631 : ℝ) / 1000)) (lo := ((2591 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2671 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2671 : ℝ) / 1000)) (lo := ((2631 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2711 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2711 : ℝ) / 1000)) (lo := ((2671 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2751 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2751 : ℝ) / 1000)) (lo := ((2711 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2791 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2791 : ℝ) / 1000)) (lo := ((2751 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2831 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2831 : ℝ) / 1000)) (lo := ((2791 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2871 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2871 : ℝ) / 1000)) (lo := ((2831 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((289 : ℝ) / 100)) (lo := ((2871 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_75 {k : ℝ} (hk : RB k ((249 : ℝ) / 128) ((3129 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((249 : ℝ) / 377) ((3129 : ℝ) / 4729) ∧
    RB (qa (r1A k)) ((472367 : ℝ) / 20000000) ((2397261 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((95372533 : ℝ) / 50000000) ((596491 : ℝ) / 312500) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((12158203 : ℝ) / 25000000) ((3129 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((58147 : ℝ) / 32000) ((45491797 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((134799619 : ℝ) / 100000000) ((26979043 : ℝ) / 20000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((11048839 : ℝ) / 4000000) ((69079143 : ℝ) / 25000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((138110487 : ℝ) / 100000000) ((69079143 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((95372533 : ℝ) / 50000000) ((596491 : ℝ) / 312500) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4508203 : ℝ) / 25000000) ((5853 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((4508203 : ℝ) / 100000000) ((4572657 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((472367 : ℝ) / 20000000) ((2397261 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((95372533 : ℝ) / 50000000) ((596491 : ℝ) / 312500) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((472367 : ℝ) / 20000000) ((2397261 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((249 : ℝ) / 377) ((3129 : ℝ) / 4729) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_75 {k : ℝ} (hk : RB k ((249 : ℝ) / 128) ((3129 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_75 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_75 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((9806661 : ℝ) / 25000000)) (ph := ((19901593 : ℝ) / 50000000)) (ml := ((13239941 : ℝ) / 10000000)) (mh := ((66353659 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_75 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_76 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((3129 : ℝ) / 4729) ((6291 : ℝ) / 9491))
    (hq : RB (qa a) ((119863 : ℝ) / 5000000) ((76023 : ℝ) / 3125000))
    (hd : RB (D0a a) ((190612969 : ℝ) / 100000000) ((11921567 : ℝ) / 6250000))
    : certE k a ((9790673 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((620857 : ℝ) / 1562500) ∧ 0 < certE k a ((33125619 : ℝ) / 25000000) ∧ certE k a ((132809093 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((14367 : ℝ) / 25000000) ((59183 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((9790673 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((39103509 : ℝ) / 100000000) ((4888153 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((9790673 : ℝ) / 25000000) ((9790673 : ℝ) / 25000000) ((9790673 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((15209327 : ℝ) / 25000000))
  have h3 : RB z3 ((64275541 : ℝ) / 100000000) ((64278361 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((15209327 : ℝ) / 25000000) ((15209327 : ℝ) / 25000000) ((15209327 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-44199103 : ℝ) / 100000000) ((-22097357 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_1368.1 cov_log_1369.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-29296867 : ℝ) / 100000000) ((-14620983 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((9790673 : ℝ) / 25000000))
  have h6 : RB z6 ((-23436141 : ℝ) / 25000000) ((-46872281 : ℝ) / 50000000) := rb_log (show RB ((9790673 : ℝ) / 25000000) ((9790673 : ℝ) / 25000000) ((9790673 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1370.1 cov_log_1370.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((12889539 : ℝ) / 20000000) ((32251299 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16126871 : ℝ) / 25000000) ((32288383 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1371.1 cov_log_1372.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-129071 : ℝ) / 100000000) ((-2443 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((14367 : ℝ) / 25000000) ((59183 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((620857 : ℝ) / 1562500)) - (z10)
  have h11 : RB z11 ((7935133 : ℝ) / 20000000) ((1983869 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((620857 : ℝ) / 1562500) ((620857 : ℝ) / 1562500) ((620857 : ℝ) / 1562500) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((941643 : ℝ) / 1562500))
  have h12 : RB z12 ((65835169 : ℝ) / 100000000) ((1028719 : ℝ) / 1562500) := rb_div_signed h11 (show RB ((941643 : ℝ) / 1562500) ((941643 : ℝ) / 1562500) ((941643 : ℝ) / 1562500) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-20900801 : ℝ) / 50000000) ((-10449319 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1373.1 cov_log_1374.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-27707711 : ℝ) / 100000000) ((-3456959 : ℝ) / 12500000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((620857 : ℝ) / 1562500))
  have h15 : RB z15 ((-92294161 : ℝ) / 100000000) ((-92294159 : ℝ) / 100000000) := rb_log (show RB ((620857 : ℝ) / 1562500) ((620857 : ℝ) / 1562500) ((620857 : ℝ) / 1562500) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1375.1 cov_log_1375.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((4036653 : ℝ) / 6250000) ((64638489 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16126871 : ℝ) / 25000000) ((32288383 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1371.1 cov_log_1372.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4841 : ℝ) / 50000000) ((26201 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((14367 : ℝ) / 25000000) ((59183 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((33125619 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((132443293 : ℝ) / 100000000) ((8277813 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((33125619 : ℝ) / 25000000) ((33125619 : ℝ) / 25000000) ((33125619 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((8125619 : ℝ) / 25000000))
  have h21 : RB z21 ((20374339 : ℝ) / 5000000) ((407492057 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((8125619 : ℝ) / 25000000) ((8125619 : ℝ) / 25000000) ((8125619 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((14048383 : ℝ) / 10000000) ((17560641 : ℝ) / 12500000) := rb_log h21 (by norm_num) cov_log_1376.1 cov_log_1377.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92952823 : ℝ) / 100000000) ((93118949 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((33125619 : ℝ) / 25000000))
  have h24 : RB z24 ((14071557 : ℝ) / 50000000) ((5628623 : ℝ) / 20000000) := rb_log (show RB ((33125619 : ℝ) / 25000000) ((33125619 : ℝ) / 25000000) ((33125619 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1378.1 cov_log_1378.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16202427 : ℝ) / 25000000) ((12995167 : ℝ) / 20000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16126871 : ℝ) / 25000000) ((32288383 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1371.1 cov_log_1372.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((116471 : ℝ) / 50000000) ((468351 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((14367 : ℝ) / 25000000) ((59183 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((132809093 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((13274991 : ℝ) / 10000000) ((1062013 : ℝ) / 800000) := rb_widen (rb_sub (show RB ((132809093 : ℝ) / 100000000) ((132809093 : ℝ) / 100000000) ((132809093 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((32809093 : ℝ) / 100000000))
  have h30 : RB z30 ((202306583 : ℝ) / 50000000) ((202309197 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((32809093 : ℝ) / 100000000) ((32809093 : ℝ) / 100000000) ((32809093 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((139776127 : ℝ) / 100000000) ((69888711 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_1379.1 cov_log_1380.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92484563 : ℝ) / 100000000) ((46324927 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((132809093 : ℝ) / 100000000))
  have h33 : RB z33 ((7093563 : ℝ) / 25000000) ((28374253 : ℝ) / 100000000) := rb_log (show RB ((132809093 : ℝ) / 100000000) ((132809093 : ℝ) / 100000000) ((132809093 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1381.1 cov_log_1381.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6411031 : ℝ) / 10000000) ((32137801 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16126871 : ℝ) / 25000000) ((32288383 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1371.1 cov_log_1372.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-58307 : ℝ) / 12500000) ((-115941 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((9790673 : ℝ) / 25000000)) ((-129071 : ℝ) / 100000000) ((-2443 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((620857 : ℝ) / 1562500)) ((4841 : ℝ) / 50000000) ((26201 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((33125619 : ℝ) / 25000000)) ((116471 : ℝ) / 50000000) ((468351 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((132809093 : ℝ) / 100000000)) ((-58307 : ℝ) / 12500000) ((-115941 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_76 {k A q d vp vm : ℝ}
    (hk : RB k ((3129 : ℝ) / 1600) ((6291 : ℝ) / 3200))
    (hA : RB A ((3129 : ℝ) / 4729) ((6291 : ℝ) / 9491))
    (hq : RB q ((119863 : ℝ) / 5000000) ((76023 : ℝ) / 3125000))
    (hd : RB d ((190612969 : ℝ) / 100000000) ((11921567 : ℝ) / 6250000))
    (hp : RB vp ((9790673 : ℝ) / 25000000) ((620857 : ℝ) / 1562500))
    (hm : RB vm ((33125619 : ℝ) / 25000000) ((132809093 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((14367 : ℝ) / 25000000) ((59183 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99940817 : ℝ) / 100000000) ((24985633 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((66127049 : ℝ) / 100000000) ((16561439 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((36157 : ℝ) / 25000000) ((151121 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99848879 : ℝ) / 100000000) ((24963843 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((941643 : ℝ) / 1562500) ((15209327 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((30087039 : ℝ) / 50000000) ((60749321 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((54426163 : ℝ) / 50000000) ((110090189 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((4426163 : ℝ) / 50000000) ((10090189 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99940817 : ℝ) / 100000000) ((24985633 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((66127049 : ℝ) / 100000000) ((16561439 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((43271 : ℝ) / 100000000) ((22333 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49977667 : ℝ) / 50000000) ((99956729 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((8125619 : ℝ) / 25000000) ((32809093 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((16243979 : ℝ) / 50000000) ((32794897 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((201638227 : ℝ) / 100000000) ((203908649 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((301638227 : ℝ) / 100000000) ((303908649 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((991061713 : ℝ) / 100000000) ((282411651 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((2056539 : ℝ) / 6250000) ((33152297 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((3129 : ℝ) / 800) ((6291 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((9376283 : ℝ) / 100000000) ((4782607 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((5119863 : ℝ) / 5000000) ((3201023 : ℝ) / 3125000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5721 : ℝ) / 62500) ((58383 : ℝ) / 625000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((68221 : ℝ) / 62500) ((683383 : ℝ) / 625000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((23191907 : ℝ) / 25000000) ((93646401 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((17682713 : ℝ) / 10000000) ((22328237 : ℝ) / 12500000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((3243221 : ℝ) / 6250000) ((13192873 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((108899 : ℝ) / 100000000) ((28513 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24971487 : ℝ) / 25000000) ((99891101 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((35325091 : ℝ) / 20000000) ((1427451 : ℝ) / 800000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((190612969 : ℝ) / 50000000) ((11921567 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((285593 : ℝ) / 3125000) ((9280649 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4729 : ℝ) / 1600) ((9491 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((3081311 : ℝ) / 100000000) ((784999 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3016571 : ℝ) / 50000000) ((194121 : ℝ) / 3125000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((53016571 : ℝ) / 50000000) ((3319121 : ℝ) / 3125000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1050853873 : ℝ) / 100000000) ((599909403 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((902521 : ℝ) / 50000000) ((1835993 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50902521 : ℝ) / 50000000) ((101835993 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16749283 : ℝ) / 50000000) ((33760971 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1084352439 : ℝ) / 100000000) ((1233579777 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((3341227 : ℝ) / 10000000) ((9683589 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4729 : ℝ) / 1600) ((9491 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((68221 : ℝ) / 31250) ((683383 : ℝ) / 312500) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1023966337 : ℝ) / 100000000) ((1162798901 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2235392239 : ℝ) / 100000000) ((508567681 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1162333 : ℝ) / 10000000) ((6634043 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-215215593 : ℝ) / 100000000) ((-100990429 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1382.1 cov_log_1383.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((285593 : ℝ) / 6250000) ((185613 : ℝ) / 4000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-308576907 : ℝ) / 100000000) ((-307038577 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1384.1 cov_log_1385.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16126871 : ℝ) / 25000000) ((32288383 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1371.1 cov_log_1372.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((492783 : ℝ) / 390625) ((63476943 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-182424459 : ℝ) / 100000000) ((-180084691 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((626459 : ℝ) / 12500000) ((6817593 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1293857 : ℝ) / 10000000) ((1020223 : ℝ) / 5000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-169485889 : ℝ) / 100000000) ((-159680231 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((68221 : ℝ) / 62500) ((683383 : ℝ) / 625000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-215215593 : ℝ) / 100000000) ((-100990429 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-169485889 : ℝ) / 100000000) ((-159680231 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((72 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3016571 : ℝ) / 50000000) ((194121 : ℝ) / 3125000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((3319121 : ℝ) / 6250000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((72 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-9133859 : ℝ) / 5000000) ≤ formC0 k A q vp vm + hfun ((72 : ℝ) / 25) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_31, cov_h_25]
  have hP : ((229389781 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((159680231 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((159680231 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((1862041 : ℝ) / 3125000) ≤ EP1038.Arc.sinc ((167 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((397 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1253 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1253 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1273 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1273 : ℝ) / 500)) (lo := ((1253 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1293 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1293 : ℝ) / 500)) (lo := ((1273 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1313 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1313 : ℝ) / 500)) (lo := ((1293 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1333 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1333 : ℝ) / 500)) (lo := ((1313 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1353 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1353 : ℝ) / 500)) (lo := ((1333 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1373 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1373 : ℝ) / 500)) (lo := ((1353 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1393 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1393 : ℝ) / 500)) (lo := ((1373 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1413 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1413 : ℝ) / 500)) (lo := ((1393 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1433 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1433 : ℝ) / 500)) (lo := ((1413 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((72 : ℝ) / 25)) (lo := ((1433 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_76 {k : ℝ} (hk : RB k ((3129 : ℝ) / 1600) ((6291 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((3129 : ℝ) / 4729) ((6291 : ℝ) / 9491) ∧
    RB (qa (r1A k)) ((119863 : ℝ) / 5000000) ((76023 : ℝ) / 3125000) ∧ RB (D0a (r1A k)) ((190612969 : ℝ) / 100000000) ((11921567 : ℝ) / 6250000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((3129 : ℝ) / 6400) ((24574219 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((90725781 : ℝ) / 50000000) ((58147 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((134703957 : ℝ) / 100000000) ((6739981 : ℝ) / 5000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((276125313 : ℝ) / 100000000) ((276220977 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((2157229 : ℝ) / 1562500) ((138110489 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((190612969 : ℝ) / 100000000) ((11921567 : ℝ) / 6250000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((5853 : ℝ) / 32000) ((9274219 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((285791 : ℝ) / 6250000) ((463711 : ℝ) / 10000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((119863 : ℝ) / 5000000) ((76023 : ℝ) / 3125000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((190612969 : ℝ) / 100000000) ((11921567 : ℝ) / 6250000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((119863 : ℝ) / 5000000) ((76023 : ℝ) / 3125000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((3129 : ℝ) / 4729) ((6291 : ℝ) / 9491) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_76 {k : ℝ} (hk : RB k ((3129 : ℝ) / 1600) ((6291 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_76 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_76 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((9790673 : ℝ) / 25000000)) (ph := ((620857 : ℝ) / 1562500)) (ml := ((33125619 : ℝ) / 25000000)) (mh := ((132809093 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_76 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_77 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((6291 : ℝ) / 9491) ((1581 : ℝ) / 2381))
    (hq : RB (qa a) ((486547 : ℝ) / 20000000) ((2468261 : ℝ) / 100000000))
    (hd : RB (D0a a) ((7619233 : ℝ) / 4000000) ((11913311 : ℝ) / 6250000))
    : certE k a ((39099131 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((39667107 : ℝ) / 100000000) ∧ 0 < certE k a ((132605107 : ℝ) / 100000000) ∧ certE k a ((132910447 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((59181 : ℝ) / 100000000) ((15231 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((39099131 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((39038207 : ℝ) / 100000000) ((780799 : ℝ) / 2000000) := rb_widen (rb_sub (show RB ((39099131 : ℝ) / 100000000) ((39099131 : ℝ) / 100000000) ((39099131 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((60900869 : ℝ) / 100000000))
  have h3 : RB z3 ((64101231 : ℝ) / 100000000) ((32052047 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((60900869 : ℝ) / 100000000) ((60900869 : ℝ) / 100000000) ((60900869 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-44470663 : ℝ) / 100000000) ((-8893239 : ℝ) / 20000000) := rb_log h3 (by norm_num) cov_log_1386.1 cov_log_1387.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1476441 : ℝ) / 5000000) ((-5894781 : ℝ) / 20000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((39099131 : ℝ) / 100000000))
  have h6 : RB z6 ((-23476749 : ℝ) / 25000000) ((-46953497 : ℝ) / 50000000) := rb_log (show RB ((39099131 : ℝ) / 100000000) ((39099131 : ℝ) / 100000000) ((39099131 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1388.1 cov_log_1388.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((32189087 : ℝ) / 50000000) ((64433091 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((32219067 : ℝ) / 50000000) ((6450749 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1389.1 cov_log_1390.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-32329 : ℝ) / 25000000) ((-5043 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((59181 : ℝ) / 100000000) ((15231 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((39667107 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((39606183 : ℝ) / 100000000) ((19803963 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((39667107 : ℝ) / 100000000) ((39667107 : ℝ) / 100000000) ((39667107 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((60332893 : ℝ) / 100000000))
  have h12 : RB z12 ((32823043 : ℝ) / 50000000) ((4103061 : ℝ) / 6250000) := rb_div_signed h11 (show RB ((60332893 : ℝ) / 100000000) ((60332893 : ℝ) / 100000000) ((60332893 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-21044611 : ℝ) / 50000000) ((-21042409 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_1391.1 cov_log_1392.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-27947527 : ℝ) / 100000000) ((-6973859 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((39667107 : ℝ) / 100000000))
  have h15 : RB z15 ((-9246479 : ℝ) / 10000000) ((-23116197 : ℝ) / 25000000) := rb_log (show RB ((39667107 : ℝ) / 100000000) ((39667107 : ℝ) / 100000000) ((39667107 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1393.1 cov_log_1393.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64517261 : ℝ) / 100000000) ((32284677 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((32219067 : ℝ) / 50000000) ((6450749 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1389.1 cov_log_1390.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((9771 : ℝ) / 100000000) ((6561 : ℝ) / 5000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((59181 : ℝ) / 100000000) ((15231 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((132605107 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((132544183 : ℝ) / 100000000) ((66272963 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((132605107 : ℝ) / 100000000) ((132605107 : ℝ) / 100000000) ((132605107 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((32605107 : ℝ) / 100000000))
  have h21 : RB z21 ((81302713 : ℝ) / 20000000) ((3175929 : ℝ) / 781250) := rb_div_signed h20 (show RB ((32605107 : ℝ) / 100000000) ((32605107 : ℝ) / 100000000) ((32605107 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((140244711 : ℝ) / 100000000) ((140246029 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1394.1 cov_log_1395.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((9295959 : ℝ) / 10000000) ((46562153 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((132605107 : ℝ) / 100000000))
  have h24 : RB z24 ((1411027 : ℝ) / 5000000) ((28220541 : ℝ) / 100000000) := rb_log (show RB ((132605107 : ℝ) / 100000000) ((132605107 : ℝ) / 100000000) ((132605107 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1396.1 cov_log_1396.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64739049 : ℝ) / 100000000) ((32451883 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((32219067 : ℝ) / 50000000) ((6450749 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1389.1 cov_log_1390.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((231559 : ℝ) / 100000000) ((14551 : ℝ) / 3125000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((59181 : ℝ) / 100000000) ((15231 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((132910447 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((132849523 : ℝ) / 100000000) ((66425633 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((132910447 : ℝ) / 100000000) ((132910447 : ℝ) / 100000000) ((132910447 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((32910447 : ℝ) / 100000000))
  have h30 : RB z30 ((403669761 : ℝ) / 100000000) ((201837529 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((32910447 : ℝ) / 100000000) ((32910447 : ℝ) / 100000000) ((32910447 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((139542693 : ℝ) / 100000000) ((17443001 : ℝ) / 12500000) := rb_log h30 (by norm_num) cov_log_1397.1 cov_log_1398.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46247133 : ℝ) / 50000000) ((1158227 : ℝ) / 1250000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((132910447 : ℝ) / 100000000))
  have h33 : RB z33 ((14225269 : ℝ) / 50000000) ((28450539 : ℝ) / 100000000) := rb_log (show RB ((132910447 : ℝ) / 100000000) ((132910447 : ℝ) / 100000000) ((132910447 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1399.1 cov_log_1399.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((64043727 : ℝ) / 100000000) ((32103811 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((32219067 : ℝ) / 50000000) ((6450749 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1389.1 cov_log_1390.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-463763 : ℝ) / 100000000) ((-14407 : ℝ) / 6250000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((39099131 : ℝ) / 100000000)) ((-32329 : ℝ) / 25000000) ((-5043 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((39667107 : ℝ) / 100000000)) ((9771 : ℝ) / 100000000) ((6561 : ℝ) / 5000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((132605107 : ℝ) / 100000000)) ((231559 : ℝ) / 100000000) ((14551 : ℝ) / 3125000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((132910447 : ℝ) / 100000000)) ((-463763 : ℝ) / 100000000) ((-14407 : ℝ) / 6250000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_77 {k A q d vp vm : ℝ}
    (hk : RB k ((6291 : ℝ) / 3200) ((1581 : ℝ) / 800))
    (hA : RB A ((6291 : ℝ) / 9491) ((1581 : ℝ) / 2381))
    (hq : RB q ((486547 : ℝ) / 20000000) ((2468261 : ℝ) / 100000000))
    (hd : RB d ((7619233 : ℝ) / 4000000) ((11913311 : ℝ) / 6250000))
    (hp : RB vp ((39099131 : ℝ) / 100000000) ((39667107 : ℝ) / 100000000))
    (hm : RB vm ((132605107 : ℝ) / 100000000) ((132910447 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((59181 : ℝ) / 100000000) ((15231 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((24984769 : ℝ) / 25000000) ((99940819 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((13248693 : ℝ) / 20000000) ((2073793 : ℝ) / 3125000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((74597 : ℝ) / 50000000) ((7791 : ℝ) / 5000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((4992209 : ℝ) / 5000000) ((49925403 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((60332893 : ℝ) / 100000000) ((60900869 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((30119441 : ℝ) / 50000000) ((60810009 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((54467567 : ℝ) / 50000000) ((27540923 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((4467567 : ℝ) / 50000000) ((2540923 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((24984769 : ℝ) / 25000000) ((99940819 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((13248693 : ℝ) / 20000000) ((2073793 : ℝ) / 3125000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((22263 : ℝ) / 50000000) ((5743 : ℝ) / 12500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((12494257 : ℝ) / 12500000) ((49977737 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((32605107 : ℝ) / 100000000) ((32910447 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((16295063 : ℝ) / 50000000) ((16447897 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((201373661 : ℝ) / 100000000) ((101812089 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((301373661 : ℝ) / 100000000) ((151812089 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((196778887 : ℝ) / 20000000) ((279794349 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((32935453 : ℝ) / 100000000) ((33181401 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((6291 : ℝ) / 1600) ((1581 : ℝ) / 400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((9565209 : ℝ) / 100000000) ((4877901 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((20486547 : ℝ) / 20000000) ((102468261 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((9334801 : ℝ) / 100000000) ((4762053 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((109334801 : ℝ) / 100000000) ((54762053 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((46469 : ℝ) / 50000) ((23452829 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((177029069 : ℝ) / 100000000) ((89408271 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((12961861 : ℝ) / 25000000) ((5272173 : ℝ) / 10000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((112251 : ℝ) / 100000000) ((117507 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99882493 : ℝ) / 100000000) ((99887749 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((176821047 : ℝ) / 100000000) ((178615819 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((7619233 : ℝ) / 2000000) ((11913311 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((9267787 : ℝ) / 100000000) ((2352413 : ℝ) / 25000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((9491 : ℝ) / 3200) ((2381 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1556957 : ℝ) / 50000000) ((3172573 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((6132877 : ℝ) / 100000000) ((6312829 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((106132877 : ℝ) / 100000000) ((106312829 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((104423547 : ℝ) / 10000000) ((37182161 : ℝ) / 3125000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((457589 : ℝ) / 25000000) ((930681 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25457589 : ℝ) / 25000000) ((50930681 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33538289 : ℝ) / 100000000) ((33799027 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1077773759 : ℝ) / 100000000) ((1223628179 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((33560947 : ℝ) / 100000000) ((19410249 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((9491 : ℝ) / 3200) ((2381 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((109334801 : ℝ) / 50000000) ((54762053 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((15887967 : ℝ) / 1562500) ((1152358797 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2223497869 : ℝ) / 100000000) ((2524221341 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1174991 : ℝ) / 10000000) ((6692721 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-13383279 : ℝ) / 6250000) ((-25137531 : ℝ) / 12500000) := rb_log h47 (by norm_num) cov_log_1400.1 cov_log_1401.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((4633893 : ℝ) / 100000000) ((2352413 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-307177289 : ℝ) / 100000000) ((-305658139 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1402.1 cov_log_1403.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((32219067 : ℝ) / 50000000) ((6450749 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1389.1 cov_log_1390.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((494849 : ℝ) / 390625) ((7967683 : ℝ) / 6250000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-36099189 : ℝ) / 20000000) ((-178175211 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1206807 : ℝ) / 25000000) ((6622001 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((621737 : ℝ) / 5000000) ((1973127 : ℝ) / 10000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-33612241 : ℝ) / 20000000) ((-158443941 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((109334801 : ℝ) / 100000000) ((54762053 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-13383279 : ℝ) / 6250000) ((-25137531 : ℝ) / 12500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-33612241 : ℝ) / 20000000) ((-158443941 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((72 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((6132877 : ℝ) / 100000000) ((6312829 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((106312829 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((72 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-181594051 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((72 : ℝ) / 25) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_31, cov_h_25]
  have hP : ((454467659 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((158443941 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((158443941 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((1862041 : ℝ) / 3125000) ≤ EP1038.Arc.sinc ((167 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((397 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2497 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2497 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2537 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2537 : ℝ) / 1000)) (lo := ((2497 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2577 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2577 : ℝ) / 1000)) (lo := ((2537 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2617 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2617 : ℝ) / 1000)) (lo := ((2577 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2657 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2657 : ℝ) / 1000)) (lo := ((2617 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2697 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2697 : ℝ) / 1000)) (lo := ((2657 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2737 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2737 : ℝ) / 1000)) (lo := ((2697 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2777 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2777 : ℝ) / 1000)) (lo := ((2737 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2817 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2817 : ℝ) / 1000)) (lo := ((2777 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2857 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2857 : ℝ) / 1000)) (lo := ((2817 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((72 : ℝ) / 25)) (lo := ((2857 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_77 {k : ℝ} (hk : RB k ((6291 : ℝ) / 3200) ((1581 : ℝ) / 800)) :
    RB (k / (k + 1)) ((6291 : ℝ) / 9491) ((1581 : ℝ) / 2381) ∧
    RB (qa (r1A k)) ((486547 : ℝ) / 20000000) ((2468261 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((7619233 : ℝ) / 4000000) ((11913311 : ℝ) / 6250000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((49148437 : ℝ) / 100000000) ((1581 : ℝ) / 3200) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((28991 : ℝ) / 16000) ((181451563 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((134608227 : ℝ) / 100000000) ((67351979 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((276029583 : ℝ) / 100000000) ((55225063 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((138014791 : ℝ) / 100000000) ((69031329 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((7619233 : ℝ) / 4000000) ((11913311 : ℝ) / 6250000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((18548437 : ℝ) / 100000000) ((3009 : ℝ) / 16000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((4637109 : ℝ) / 100000000) ((4701563 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((486547 : ℝ) / 20000000) ((2468261 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((7619233 : ℝ) / 4000000) ((11913311 : ℝ) / 6250000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((486547 : ℝ) / 20000000) ((2468261 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((6291 : ℝ) / 9491) ((1581 : ℝ) / 2381) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_77 {k : ℝ} (hk : RB k ((6291 : ℝ) / 3200) ((1581 : ℝ) / 800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_77 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_77 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((39099131 : ℝ) / 100000000)) (ph := ((39667107 : ℝ) / 100000000)) (ml := ((132605107 : ℝ) / 100000000)) (mh := ((132910447 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_77 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_78 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1581 : ℝ) / 2381) ((12681 : ℝ) / 19081))
    (hq : RB (qa a) ((2468259 : ℝ) / 100000000) ((1243021 : ℝ) / 50000000))
    (hd : RB (D0a a) ((38082947 : ℝ) / 20000000) ((190480831 : ℝ) / 100000000))
    : certE k a ((19596453 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((39475389 : ℝ) / 100000000) ∧ 0 < certE k a ((66378967 : ℝ) / 50000000) ∧ certE k a ((132910131 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((60923 : ℝ) / 100000000) ((12361 : ℝ) / 20000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((19596453 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((39131101 : ℝ) / 100000000) ((39131983 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((19596453 : ℝ) / 50000000) ((19596453 : ℝ) / 50000000) ((19596453 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((30403547 : ℝ) / 50000000))
  have h3 : RB z3 ((32176427 : ℝ) / 50000000) ((32177153 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((30403547 : ℝ) / 50000000) ((30403547 : ℝ) / 50000000) ((30403547 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-11019723 : ℝ) / 25000000) ((-44076633 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1404.1 cov_log_1405.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-5858859 : ℝ) / 20000000) ((-1463359 : ℝ) / 5000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((19596453 : ℝ) / 50000000))
  have h6 : RB z6 ((-23416861 : ℝ) / 25000000) ((-46833721 : ℝ) / 50000000) := rb_log (show RB ((19596453 : ℝ) / 50000000) ((19596453 : ℝ) / 50000000) ((19596453 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1406.1 cov_log_1406.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((64373147 : ℝ) / 100000000) ((8050033 : ℝ) / 12500000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((8050429 : ℝ) / 12500000) ((64438139 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1407.1 cov_log_1408.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-2031 : ℝ) / 3125000) ((-99 : ℝ) / 3125000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((60923 : ℝ) / 100000000) ((12361 : ℝ) / 20000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((39475389 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((2463349 : ℝ) / 6250000) ((19707233 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((39475389 : ℝ) / 100000000) ((39475389 : ℝ) / 100000000) ((39475389 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((60524611 : ℝ) / 100000000))
  have h12 : RB z12 ((65119929 : ℝ) / 100000000) ((65121387 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((60524611 : ℝ) / 100000000) ((60524611 : ℝ) / 100000000) ((60524611 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-42893957 : ℝ) / 100000000) ((-10722929 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1409.1 cov_log_1410.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-28506801 : ℝ) / 100000000) ((-28480387 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((39475389 : ℝ) / 100000000))
  have h15 : RB z15 ((-92949279 : ℝ) / 100000000) ((-92949277 : ℝ) / 100000000) := rb_log (show RB ((39475389 : ℝ) / 100000000) ((39475389 : ℝ) / 100000000) ((39475389 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1411.1 cov_log_1411.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16110619 : ℝ) / 25000000) ((16117223 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((8050429 : ℝ) / 12500000) ((64438139 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1407.1 cov_log_1408.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4337 : ℝ) / 100000000) ((3273 : ℝ) / 5000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((60923 : ℝ) / 100000000) ((12361 : ℝ) / 20000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((66378967 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((132696129 : ℝ) / 100000000) ((132697011 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((66378967 : ℝ) / 50000000) ((66378967 : ℝ) / 50000000) ((66378967 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((16378967 : ℝ) / 50000000))
  have h21 : RB z21 ((81016177 : ℝ) / 20000000) ((202541789 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((16378967 : ℝ) / 50000000) ((16378967 : ℝ) / 50000000) ((16378967 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((139891657 : ℝ) / 100000000) ((5595693 : ℝ) / 4000000) := rb_log h21 (by norm_num) cov_log_1412.1 cov_log_1413.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92889 : ℝ) / 100000) ((46485367 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((66378967 : ℝ) / 50000000))
  have h24 : RB z24 ((28335723 : ℝ) / 100000000) ((7083931 : ℝ) / 25000000) := rb_log (show RB ((66378967 : ℝ) / 50000000) ((66378967 : ℝ) / 50000000) ((66378967 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1414.1 cov_log_1414.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16138319 : ℝ) / 25000000) ((64635011 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((8050429 : ℝ) / 12500000) ((64438139 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1407.1 cov_log_1408.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((115137 : ℝ) / 100000000) ((231579 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((60923 : ℝ) / 100000000) ((12361 : ℝ) / 20000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((132910131 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((66424163 : ℝ) / 50000000) ((16606151 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((132910131 : ℝ) / 100000000) ((132910131 : ℝ) / 100000000) ((132910131 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((32910131 : ℝ) / 100000000))
  have h30 : RB z30 ((40367 : ℝ) / 10000) ((403672681 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((32910131 : ℝ) / 100000000) ((32910131 : ℝ) / 100000000) ((32910131 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((4360711 : ℝ) / 3125000) ((139543419 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1415.1 cov_log_1416.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((3706293 : ℝ) / 4000000) ((11592357 : ℝ) / 12500000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((132910131 : ℝ) / 100000000))
  have h33 : RB z33 ((284503 : ℝ) / 1000000) ((28450301 : ℝ) / 100000000) := rb_log (show RB ((132910131 : ℝ) / 100000000) ((132910131 : ℝ) / 100000000) ((132910131 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1417.1 cov_log_1417.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((4012939 : ℝ) / 6250000) ((16072139 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((8050429 : ℝ) / 12500000) ((64438139 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1407.1 cov_log_1408.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-46223 : ℝ) / 20000000) ((-28719 : ℝ) / 25000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((19596453 : ℝ) / 50000000)) ((-2031 : ℝ) / 3125000) ((-99 : ℝ) / 3125000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((39475389 : ℝ) / 100000000)) ((4337 : ℝ) / 100000000) ((3273 : ℝ) / 5000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((66378967 : ℝ) / 50000000)) ((115137 : ℝ) / 100000000) ((231579 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((132910131 : ℝ) / 100000000)) ((-46223 : ℝ) / 20000000) ((-28719 : ℝ) / 25000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_78 {k A q d vp vm : ℝ}
    (hk : RB k ((1581 : ℝ) / 800) ((12681 : ℝ) / 6400))
    (hA : RB A ((1581 : ℝ) / 2381) ((12681 : ℝ) / 19081))
    (hq : RB q ((2468259 : ℝ) / 100000000) ((1243021 : ℝ) / 50000000))
    (hd : RB d ((38082947 : ℝ) / 20000000) ((190480831 : ℝ) / 100000000))
    (hp : RB vp ((19596453 : ℝ) / 50000000) ((39475389 : ℝ) / 100000000))
    (hm : RB vm ((66378967 : ℝ) / 50000000) ((132910131 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((60923 : ℝ) / 100000000) ((12361 : ℝ) / 20000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((19987639 : ℝ) / 20000000) ((99939077 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((66359633 : ℝ) / 100000000) ((66418293 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((154331 : ℝ) / 100000000) ((31539 : ℝ) / 20000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((19968461 : ℝ) / 20000000) ((99845669 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((60524611 : ℝ) / 100000000) ((30403547 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((30214583 : ℝ) / 50000000) ((242853 : ℝ) / 400000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((109300083 : ℝ) / 100000000) ((27477747 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((9300083 : ℝ) / 100000000) ((2477747 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((19987639 : ℝ) / 20000000) ((99939077 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((66359633 : ℝ) / 100000000) ((66418293 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((45837 : ℝ) / 100000000) ((9311 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19990689 : ℝ) / 20000000) ((99954163 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((16378967 : ℝ) / 50000000) ((32910131 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((32742683 : ℝ) / 100000000) ((16447523 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((50432847 : ℝ) / 25000000) ((202849269 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((75432847 : ℝ) / 25000000) ((302849269 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((504490571 : ℝ) / 50000000) ((1075259221 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16509863 : ℝ) / 50000000) ((33142061 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1581 : ℝ) / 400) ((12681 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((9755793 : ℝ) / 100000000) ((9851719 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102468259 : ℝ) / 100000000) ((51243021 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((9519143 : ℝ) / 100000000) ((9614411 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((109519143 : ℝ) / 100000000) ((109614411 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((18656509 : ℝ) / 20000000) ((3748689 : ℝ) / 4000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((17762371 : ℝ) / 10000000) ((178513349 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13007923 : ℝ) / 25000000) ((6558349 : ℝ) / 12500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((116117 : ℝ) / 100000000) ((464 : ℝ) / 390625) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((390161 : ℝ) / 390625) ((99883883 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((177412721 : ℝ) / 100000000) ((35661213 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((38082947 : ℝ) / 10000000) ((190480831 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((9399857 : ℝ) / 100000000) ((9470867 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((2381 : ℝ) / 800) ((19081 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1576413 : ℝ) / 50000000) ((795537 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1563163 : ℝ) / 25000000) ((1585773 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((26563163 : ℝ) / 25000000) ((26585773 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1072069221 : ℝ) / 100000000) ((1143463903 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((29017 : ℝ) / 1562500) ((1872613 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((1591517 : ℝ) / 1562500) ((101872613 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33632931 : ℝ) / 100000000) ((8440671 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((138212769 : ℝ) / 12500000) ((1177226587 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((544701 : ℝ) / 1562500) ((37461093 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((2381 : ℝ) / 800) ((19081 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((109519143 : ℝ) / 50000000) ((109614411 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((260500217 : ℝ) / 25000000) ((554200641 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2282380841 : ℝ) / 100000000) ((1214967537 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((12248269 : ℝ) / 100000000) ((13062703 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-656183 : ℝ) / 312500) ((-203540911 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1418.1 cov_log_1419.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((587491 : ℝ) / 12500000) ((2367717 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-1194384 : ℝ) / 390625) ((-3812621 : ℝ) / 1250000) := rb_log h49 (by norm_num) cov_log_1420.1 cov_log_1421.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((8050429 : ℝ) / 12500000) ((64438139 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1407.1 cov_log_1408.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((63638641 : ℝ) / 50000000) ((31919533 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-89242511 : ℝ) / 50000000) ((-44332887 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2568491 : ℝ) / 50000000) ((6030327 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((6856423 : ℝ) / 50000000) ((540571 : ℝ) / 3125000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-10298261 : ℝ) / 6250000) ((-40008319 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((109519143 : ℝ) / 100000000) ((109614411 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-656183 : ℝ) / 312500) ((-203540911 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-10298261 : ℝ) / 6250000) ((-40008319 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((287 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1563163 : ℝ) / 25000000) ((1585773 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((26585773 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((287 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-177312357 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((287 : ℝ) / 100) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_32, cov_h_24]
  have hP : ((114662053 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((40008319 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((40008319 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2581 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2581 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2621 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2621 : ℝ) / 1000)) (lo := ((2581 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2661 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2661 : ℝ) / 1000)) (lo := ((2621 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2701 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2701 : ℝ) / 1000)) (lo := ((2661 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2741 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2741 : ℝ) / 1000)) (lo := ((2701 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2781 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2781 : ℝ) / 1000)) (lo := ((2741 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2821 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2821 : ℝ) / 1000)) (lo := ((2781 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2861 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2861 : ℝ) / 1000)) (lo := ((2821 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((2861 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_78 {k : ℝ} (hk : RB k ((1581 : ℝ) / 800) ((12681 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((1581 : ℝ) / 2381) ((12681 : ℝ) / 19081) ∧
    RB (qa (r1A k)) ((2468259 : ℝ) / 100000000) ((1243021 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((38082947 : ℝ) / 20000000) ((190480831 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((1581 : ℝ) / 3200) ((49535157 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((181064843 : ℝ) / 100000000) ((28991 : ℝ) / 16000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((134560337 : ℝ) / 100000000) ((33652057 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275981693 : ℝ) / 100000000) ((55205917 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((68995423 : ℝ) / 50000000) ((138014793 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((38082947 : ℝ) / 20000000) ((190480831 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3009 : ℝ) / 16000) ((18935157 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2350781 : ℝ) / 50000000) ((473379 : ℝ) / 10000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((2468259 : ℝ) / 100000000) ((1243021 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((38082947 : ℝ) / 20000000) ((190480831 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((2468259 : ℝ) / 100000000) ((1243021 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1581 : ℝ) / 2381) ((12681 : ℝ) / 19081) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_78 {k : ℝ} (hk : RB k ((1581 : ℝ) / 800) ((12681 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_78 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_78 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((19596453 : ℝ) / 50000000)) (ph := ((39475389 : ℝ) / 100000000)) (ml := ((66378967 : ℝ) / 50000000)) (mh := ((132910131 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_78 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_79 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((12681 : ℝ) / 19081) ((6357 : ℝ) / 9557))
    (hq : RB (qa a) ((2486041 : ℝ) / 100000000) ((625959 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23793579 : ℝ) / 12500000) ((95207371 : ℝ) / 50000000))
    : certE k a ((9790229 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((19721213 : ℝ) / 50000000) ∧ 0 < certE k a ((132808771 : ℝ) / 100000000) ∧ certE k a ((66480327 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((61803 : ℝ) / 100000000) ((15673 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((9790229 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((2443639 : ℝ) / 6250000) ((39099113 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((9790229 : ℝ) / 25000000) ((9790229 : ℝ) / 25000000) ((9790229 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((15209771 : ℝ) / 25000000))
  have h3 : RB z3 ((32132489 : ℝ) / 50000000) ((1606661 : ℝ) / 2500000) := rb_div_signed h2 (show RB ((15209771 : ℝ) / 25000000) ((15209771 : ℝ) / 25000000) ((15209771 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22107769 : ℝ) / 50000000) ((-44213261 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1422.1 cov_log_1423.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-29410713 : ℝ) / 100000000) ((-14691797 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((9790229 : ℝ) / 25000000))
  have h6 : RB z6 ((-93749099 : ℝ) / 100000000) ((-93749097 : ℝ) / 100000000) := rb_log (show RB ((9790229 : ℝ) / 25000000) ((9790229 : ℝ) / 25000000) ((9790229 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1424.1 cov_log_1424.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((4021149 : ℝ) / 6250000) ((12873101 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((6436871 : ℝ) / 10000000) ((64403437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1425.1 cov_log_1426.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-65053 : ℝ) / 100000000) ((-641 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((61803 : ℝ) / 100000000) ((15673 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19721213 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((19689867 : ℝ) / 50000000) ((39380623 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((19721213 : ℝ) / 50000000) ((19721213 : ℝ) / 50000000) ((19721213 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30278787 : ℝ) / 50000000))
  have h12 : RB z12 ((13005717 : ℝ) / 20000000) ((32515027 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((30278787 : ℝ) / 50000000) ((30278787 : ℝ) / 50000000) ((30278787 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-21517163 : ℝ) / 50000000) ((-8606413 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_1427.1 cov_log_1428.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-28625009 : ℝ) / 100000000) ((-5719717 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19721213 : ℝ) / 50000000))
  have h15 : RB z15 ((-5814551 : ℝ) / 6250000) ((-46516407 : ℝ) / 50000000) := rb_log (show RB ((19721213 : ℝ) / 50000000) ((19721213 : ℝ) / 50000000) ((19721213 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1429.1 cov_log_1429.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((12881561 : ℝ) / 20000000) ((64434231 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((6436871 : ℝ) / 10000000) ((64403437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1425.1 cov_log_1426.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((273 : ℝ) / 6250000) ((65521 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((61803 : ℝ) / 100000000) ((15673 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((132808771 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((132746079 : ℝ) / 100000000) ((16593371 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((132808771 : ℝ) / 100000000) ((132808771 : ℝ) / 100000000) ((132808771 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((32808771 : ℝ) / 100000000))
  have h21 : RB z21 ((20230273 : ℝ) / 5000000) ((404608171 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((32808771 : ℝ) / 100000000) ((32808771 : ℝ) / 100000000) ((32808771 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((139774223 : ℝ) / 100000000) ((8735931 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_1430.1 cov_log_1431.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23223061 : ℝ) / 25000000) ((46486817 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((132808771 : ℝ) / 100000000))
  have h24 : RB z24 ((28374009 : ℝ) / 100000000) ((2837401 : ℝ) / 10000000) := rb_log (show RB ((132808771 : ℝ) / 100000000) ((132808771 : ℝ) / 100000000) ((132808771 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1432.1 cov_log_1432.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((32259117 : ℝ) / 50000000) ((516797 : ℝ) / 800000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((6436871 : ℝ) / 10000000) ((64403437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1425.1 cov_log_1426.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((114797 : ℝ) / 100000000) ((46183 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((61803 : ℝ) / 100000000) ((15673 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((66480327 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((66448981 : ℝ) / 50000000) ((132898851 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((66480327 : ℝ) / 50000000) ((66480327 : ℝ) / 50000000) ((66480327 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((16480327 : ℝ) / 50000000))
  have h30 : RB z30 ((80640367 : ℝ) / 20000000) ((403204533 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((16480327 : ℝ) / 50000000) ((16480327 : ℝ) / 50000000) ((16480327 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((34856677 : ℝ) / 25000000) ((6971369 : ℝ) / 5000000) := rb_log h30 (by norm_num) cov_log_1433.1 cov_log_1434.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((9266129 : ℝ) / 10000000) ((46371239 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((66480327 : ℝ) / 50000000))
  have h33 : RB z33 ((14244153 : ℝ) / 50000000) ((28488307 : ℝ) / 100000000) := rb_log (show RB ((66480327 : ℝ) / 50000000) ((66480327 : ℝ) / 50000000) ((66480327 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1435.1 cov_log_1435.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((64172983 : ℝ) / 100000000) ((16063543 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((6436871 : ℝ) / 10000000) ((64403437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1425.1 cov_log_1426.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-115227 : ℝ) / 50000000) ((-57269 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((9790229 : ℝ) / 25000000)) ((-65053 : ℝ) / 100000000) ((-641 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19721213 : ℝ) / 50000000)) ((273 : ℝ) / 6250000) ((65521 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((132808771 : ℝ) / 100000000)) ((114797 : ℝ) / 100000000) ((46183 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((66480327 : ℝ) / 50000000)) ((-115227 : ℝ) / 50000000) ((-57269 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_79 {k A q d vp vm : ℝ}
    (hk : RB k ((12681 : ℝ) / 6400) ((6357 : ℝ) / 3200))
    (hA : RB A ((12681 : ℝ) / 19081) ((6357 : ℝ) / 9557))
    (hq : RB q ((2486041 : ℝ) / 100000000) ((625959 : ℝ) / 25000000))
    (hd : RB d ((23793579 : ℝ) / 12500000) ((95207371 : ℝ) / 50000000))
    (hp : RB vp ((9790229 : ℝ) / 25000000) ((19721213 : ℝ) / 50000000))
    (hm : RB vm ((132808771 : ℝ) / 100000000) ((66480327 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((61803 : ℝ) / 100000000) ((15673 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((24984327 : ℝ) / 25000000) ((99938197 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((16604279 : ℝ) / 25000000) ((66475581 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((156691 : ℝ) / 100000000) ((160089 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99839911 : ℝ) / 100000000) ((99843309 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30278787 : ℝ) / 50000000) ((15209771 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((60460627 : ℝ) / 100000000) ((12148751 : ℝ) / 20000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((4373593 : ℝ) / 4000000) ((27487137 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((373593 : ℝ) / 4000000) ((2487137 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((24984327 : ℝ) / 25000000) ((99938197 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((16604279 : ℝ) / 25000000) ((66475581 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((23241 : ℝ) / 50000000) ((9441 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19990559 : ℝ) / 20000000) ((49976759 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((32808771 : ℝ) / 100000000) ((16480327 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((32793283 : ℝ) / 100000000) ((16472667 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((25199743 : ℝ) / 12500000) ((202710967 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((37699743 : ℝ) / 12500000) ((302710967 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1005171809 : ℝ) / 100000000) ((1070683873 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((8258703 : ℝ) / 25000000) ((1326269 : ℝ) / 4000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((12681 : ℝ) / 3200) ((6357 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4925857 : ℝ) / 50000000) ((4974027 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102486041 : ℝ) / 100000000) ((25625959 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2402767 : ℝ) / 25000000) ((9706741 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((27402767 : ℝ) / 25000000) ((109706741 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((18673269 : ℝ) / 20000000) ((46899869 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((4443039 : ℝ) / 2500000) ((17860853 : ℝ) / 10000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52009131 : ℝ) / 100000000) ((13110727 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((14731 : ℝ) / 12500000) ((120541 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99879459 : ℝ) / 100000000) ((12485269 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((44376833 : ℝ) / 25000000) ((44599511 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23793579 : ℝ) / 6250000) ((95207371 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((946429 : ℝ) / 10000000) ((4767673 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((19081 : ℝ) / 6400) ((9557 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((3168957 : ℝ) / 100000000) ((49973 : ℝ) / 1562500) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((6302961 : ℝ) / 100000000) ((399607 : ℝ) / 6250000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((106302961 : ℝ) / 100000000) ((6649607 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((267131849 : ℝ) / 25000000) ((1139140317 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((467439 : ℝ) / 25000000) ((377059 : ℝ) / 20000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25467439 : ℝ) / 25000000) ((20377059 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16826241 : ℝ) / 50000000) ((8445457 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((551089939 : ℝ) / 50000000) ((234584429 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17463803 : ℝ) / 50000000) ((37513241 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((19081 : ℝ) / 6400) ((9557 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((27402767 : ℝ) / 12500000) ((109706741 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1038206621 : ℝ) / 100000000) ((551920299 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((227597873 : ℝ) / 10000000) ((605493773 : ℝ) / 25000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((12309813 : ℝ) / 100000000) ((6561051 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-209477347 : ℝ) / 100000000) ((-10154361 : ℝ) / 5000000) := rb_log h47 (by norm_num) cov_log_1436.1 cov_log_1437.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((946429 : ℝ) / 20000000) ((4767673 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-76269791 : ℝ) / 25000000) ((-304331183 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1438.1 cov_log_1439.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((6436871 : ℝ) / 10000000) ((64403437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1425.1 cov_log_1426.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((31885141 : ℝ) / 25000000) ((127941453 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-887693 : ℝ) / 500000) ((-17638973 : ℝ) / 10000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((5045003 : ℝ) / 100000000) ((1483929 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((840537 : ℝ) / 6250000) ((849717 : ℝ) / 5000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-20511251 : ℝ) / 12500000) ((-15939539 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((27402767 : ℝ) / 25000000) ((109706741 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-209477347 : ℝ) / 100000000) ((-10154361 : ℝ) / 5000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-20511251 : ℝ) / 12500000) ((-15939539 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((287 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((6302961 : ℝ) / 100000000) ((399607 : ℝ) / 6250000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((6649607 : ℝ) / 12500000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((287 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-22101393 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((287 : ℝ) / 100) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_32, cov_h_24]
  have hP : ((114108899 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((15939539 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((15939539 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((322 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((322 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((327 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((327 : ℝ) / 125)) (lo := ((322 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((332 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((332 : ℝ) / 125)) (lo := ((327 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((337 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((337 : ℝ) / 125)) (lo := ((332 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((342 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((342 : ℝ) / 125)) (lo := ((337 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((347 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((347 : ℝ) / 125)) (lo := ((342 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((352 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((352 : ℝ) / 125)) (lo := ((347 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((357 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((357 : ℝ) / 125)) (lo := ((352 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((357 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_79 {k : ℝ} (hk : RB k ((12681 : ℝ) / 6400) ((6357 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((12681 : ℝ) / 19081) ((6357 : ℝ) / 9557) ∧
    RB (qa (r1A k)) ((2486041 : ℝ) / 100000000) ((625959 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((23793579 : ℝ) / 12500000) ((95207371 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((12383789 : ℝ) / 25000000) ((49664063 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((180935937 : ℝ) / 100000000) ((45266211 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((134512429 : ℝ) / 100000000) ((67280169 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((55186757 : ℝ) / 20000000) ((55196339 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((34491723 : ℝ) / 25000000) ((2156107 : ℝ) / 1562500) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((23793579 : ℝ) / 12500000) ((95207371 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4733789 : ℝ) / 25000000) ((19064063 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((4733789 : ℝ) / 100000000) ((74469 : ℝ) / 1562500) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((2486041 : ℝ) / 100000000) ((625959 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((23793579 : ℝ) / 12500000) ((95207371 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((2486041 : ℝ) / 100000000) ((625959 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((12681 : ℝ) / 19081) ((6357 : ℝ) / 9557) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_79 {k : ℝ} (hk : RB k ((12681 : ℝ) / 6400) ((6357 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_79 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_79 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((9790229 : ℝ) / 25000000)) (ph := ((19721213 : ℝ) / 50000000)) (ml := ((132808771 : ℝ) / 100000000)) (mh := ((66480327 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_79 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
