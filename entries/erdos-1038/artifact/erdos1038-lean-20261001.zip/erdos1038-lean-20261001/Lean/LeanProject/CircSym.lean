import LeanProject.Elementary
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

/-!
# EP-1038, Stage 12 / 12b: symmetric decreasing functions on the circle

Functions on `𝕋 = ℝ/2πℤ` are modelled as `2π`-periodic functions on `ℝ`; `∫_𝕋` is `∫ u in -π..π`.

* `SymDecC F`: `F` is `2π`-periodic, even and nonincreasing on `[0, π]` (symmetric decreasing).
* `Bdd F`: measurable and bounded.
* `conv_anti`, `conv_symDec`: **Lemma 12.6(a)** — the convolution `(F * G)(x) = ∫ F(x - u) G(u) du`
  of two bounded symmetric decreasing functions is symmetric decreasing. The proof pairs `u` with
  its reflection `x + y - u` (the continuous form of Stage 12b Lemma 1.3); no layer cake is needed.
* `bathtub`: **Lemma 12.6(b)** — if `Ψ` is bounded symmetric decreasing, `0 ≤ p ≤ 1` and
  `∫ p = 2Q` with `0 ≤ Q ≤ π`, then `∫ p Ψ ≤ ∫_{-Q}^{Q} Ψ`.
-/

open Real MeasureTheory Set

namespace EP1038.Circ

/-- `F` is symmetric decreasing on the circle. -/
structure SymDecC (F : ℝ → ℝ) : Prop where
  per : Function.Periodic F (2 * π)
  even : ∀ x, F (-x) = F x
  anti : AntitoneOn F (Icc 0 π)

/-- `F` is measurable and bounded. -/
structure Bdd (F : ℝ → ℝ) : Prop where
  meas : Measurable F
  bdd : ∃ M, ∀ x, |F x| ≤ M

theorem Bdd.ii {F : ℝ → ℝ} (hF : Bdd F) (a b : ℝ) : IntervalIntegrable F volume a b := by
  obtain ⟨M, hM⟩ := hF.bdd
  refine (intervalIntegrable_const (c := M)).mono_fun hF.meas.aestronglyMeasurable ?_
  exact Filter.Eventually.of_forall fun x => by
    simp only [Real.norm_eq_abs]
    exact (hM x).trans (le_abs_self M)

theorem Bdd.mul {F G : ℝ → ℝ} (hF : Bdd F) (hG : Bdd G) : Bdd (fun u => F u * G u) := by
  obtain ⟨M, hM⟩ := hF.bdd
  obtain ⟨N, hN⟩ := hG.bdd
  refine ⟨hF.meas.mul hG.meas, M * N, fun u => ?_⟩
  rw [abs_mul]
  exact mul_le_mul (hM u) (hN u) (abs_nonneg _) ((abs_nonneg _).trans (hM u))

theorem Bdd.comp_sub {F : ℝ → ℝ} (hF : Bdd F) (c : ℝ) : Bdd (fun u => F (c - u)) := by
  obtain ⟨M, hM⟩ := hF.bdd
  exact ⟨hF.meas.comp (measurable_const.sub measurable_id), M, fun u => hM _⟩

variable {F G Ψ : ℝ → ℝ}

theorem SymDecC.eq_abs (hF : SymDecC F) (x : ℝ) : F x = F |x| := by
  rcases le_or_gt 0 x with h | h
  · rw [abs_of_nonneg h]
  · rw [abs_of_neg h, hF.even]

theorem SymDecC.eq_sub (hF : SymDecC F) (x : ℝ) : F x = F (2 * π - x) := by
  rw [← hF.even (2 * π - x), neg_sub, hF.per.sub_eq]

/-- Comparison by circular distance: `dist(a, 0) = |a|` for `|a| ≤ π`, and
`dist(b, 0) = min(b, 2π - b)` for `0 ≤ b ≤ 2π`. -/
theorem SymDecC.le_of (hF : SymDecC F) {a b : ℝ} (ha : |a| ≤ π) (hb0 : 0 ≤ b) (hb1 : b ≤ 2 * π)
    (h1 : |a| ≤ b) (h2 : |a| ≤ 2 * π - b) : F b ≤ F a := by
  rw [hF.eq_abs a]
  rcases le_total b π with hb | hb
  · exact hF.anti ⟨abs_nonneg a, ha⟩ ⟨hb0, hb⟩ h1
  · rw [hF.eq_sub b]
    exact hF.anti ⟨abs_nonneg a, ha⟩ ⟨by linarith, by linarith⟩ h2

/-- The convolution on the circle. -/
noncomputable def conv (F G : ℝ → ℝ) (x : ℝ) : ℝ := ∫ u in (-π)..π, F (x - u) * G u

theorem conv_periodic (hF : SymDecC F) (G : ℝ → ℝ) : Function.Periodic (conv F G) (2 * π) := by
  intro x
  unfold conv
  refine intervalIntegral.integral_congr (fun u _ => ?_)
  rw [show x + 2 * π - u = (x - u) + 2 * π by ring, hF.per]

theorem conv_even (hF : SymDecC F) (hG : SymDecC G) (x : ℝ) : conv F G (-x) = conv F G x := by
  unfold conv
  have h := intervalIntegral.integral_comp_neg (a := -π) (b := π) (fun u => F (-x - u) * G u)
  rw [neg_neg] at h
  rw [← h]
  refine intervalIntegral.integral_congr (fun u _ => ?_)
  rw [show -x - -u = -(x - u) by ring, hF.even, hG.even]

/-- **Lemma 12.6(a)**, monotone part: `F * G` is nonincreasing on `[0, π]`. -/
theorem conv_anti (hF : SymDecC F) (hG : SymDecC G) (hFb : Bdd F) (hGb : Bdd G) :
    AntitoneOn (conv F G) (Icc 0 π) := by
  intro x hx y hy hxy
  obtain ⟨hx0, hxπ⟩ := hx
  obtain ⟨hy0, hyπ⟩ := hy
  have hπ := Real.pi_pos
  set m := (x + y) / 2 with hm
  have hper : ∀ z, Function.Periodic (fun u => F (z - u) * G u) (2 * π) := by
    intro z u
    dsimp only
    rw [show z - (u + 2 * π) = (z - u) - 2 * π by ring, hF.per.sub_eq, hG.per]
  have hint : ∀ z a b, IntervalIntegrable (fun u => F (z - u) * G u) volume a b :=
    fun z a b => ((hFb.comp_sub z).mul hGb).ii a b
  have hint2 : ∀ z a b,
      IntervalIntegrable (fun u => F (z - (2 * m - u)) * G (2 * m - u)) volume a b := by
    intro z a b
    refine Bdd.ii ⟨?_, ?_⟩ a b
    · exact (hFb.meas.comp (measurable_const.sub (measurable_const.sub measurable_id))).mul
        (hGb.meas.comp (measurable_const.sub measurable_id))
    · obtain ⟨M, hM⟩ := hFb.bdd
      obtain ⟨N, hN⟩ := hGb.bdd
      exact ⟨M * N, fun u => by
        rw [abs_mul]
        exact mul_le_mul (hM _) (hN _) (abs_nonneg _) ((abs_nonneg _).trans (hM 0))⟩
  -- shift the window to `[m - π, m + π]`
  have hshift : ∀ z, conv F G z = ∫ u in (m - π)..(m + π), F (z - u) * G u := by
    intro z
    unfold conv
    have := (hper z).intervalIntegral_add_eq (-π) (m - π)
    rw [show -π + 2 * π = π by ring, show m - π + 2 * π = m + π by ring] at this
    exact this
  -- split at `m` and reflect the right half
  have hsplit : ∀ z, ∫ u in (m - π)..(m + π), F (z - u) * G u =
      (∫ u in (m - π)..m, F (z - u) * G u) +
        ∫ u in (m - π)..m, F (z - (2 * m - u)) * G (2 * m - u) := by
    intro z
    rw [← intervalIntegral.integral_add_adjacent_intervals (hint z (m - π) m) (hint z m (m + π))]
    congr 1
    have := intervalIntegral.integral_comp_sub_left (a := m - π) (b := m)
      (fun u => F (z - u) * G u) (2 * m)
    rw [show 2 * m - m = m by ring, show 2 * m - (m - π) = m + π by ring] at this
    exact this.symm
  have key : ∀ v ∈ Icc (m - π) m,
      F (y - v) * G v + F (y - (2 * m - v)) * G (2 * m - v) ≤
        F (x - v) * G v + F (x - (2 * m - v)) * G (2 * m - v) := by
    intro v hv
    obtain ⟨hv1, hv2⟩ := hv
    have e1 : F (y - (2 * m - v)) = F (x - v) := by
      rw [show y - (2 * m - v) = -(x - v) by rw [hm]; ring, hF.even]
    have e2 : F (x - (2 * m - v)) = F (y - v) := by
      rw [show x - (2 * m - v) = -(y - v) by rw [hm]; ring, hF.even]
    rw [e1, e2]
    have hGv : G (2 * m - v) ≤ G v :=
      hG.le_of (abs_le.mpr ⟨by linarith, by linarith⟩) (by linarith) (by linarith)
        (abs_le.mpr ⟨by linarith, by linarith⟩) (abs_le.mpr ⟨by linarith, by linarith⟩)
    have hFv : F (y - v) ≤ F (x - v) :=
      hF.le_of (abs_le.mpr ⟨by linarith, by linarith⟩) (by linarith) (by linarith)
        (abs_le.mpr ⟨by linarith, by linarith⟩) (abs_le.mpr ⟨by linarith, by linarith⟩)
    nlinarith [mul_nonneg (sub_nonneg.mpr hFv) (sub_nonneg.mpr hGv)]
  rw [hshift x, hshift y, hsplit x, hsplit y,
    ← intervalIntegral.integral_add (hint y _ _) (hint2 y _ _),
    ← intervalIntegral.integral_add (hint x _ _) (hint2 x _ _)]
  exact intervalIntegral.integral_mono_on (by linarith) ((hint y _ _).add (hint2 y _ _))
    ((hint x _ _).add (hint2 x _ _)) key

/-- **Lemma 12.6(a)**: the convolution of bounded symmetric decreasing functions is symmetric
decreasing. -/
theorem conv_symDec (hF : SymDecC F) (hG : SymDecC G) (hFb : Bdd F) (hGb : Bdd G) :
    SymDecC (conv F G) :=
  ⟨conv_periodic hF G, conv_even hF hG, conv_anti hF hG hFb hGb⟩

/-- **Lemma 12.6(b) (bathtub)**. -/
theorem bathtub (hΨ : SymDecC Ψ) (hΨb : Bdd Ψ) {p : ℝ → ℝ} (hpm : Measurable p)
    (hp0 : ∀ x, 0 ≤ p x) (hp1 : ∀ x, p x ≤ 1) {Q : ℝ} (hQ0 : 0 ≤ Q) (hQ : Q ≤ π)
    (hmass : ∫ u in (-π)..π, p u = 2 * Q) :
    ∫ u in (-π)..π, p u * Ψ u ≤ ∫ u in (-Q)..Q, Ψ u := by
  have hpB : Bdd p := ⟨hpm, 1, fun x => abs_le.mpr ⟨by linarith [hp0 x], hp1 x⟩⟩
  set t := Ψ Q with ht
  have hpΨ : ∀ a b, IntervalIntegrable (fun u => p u * Ψ u) volume a b :=
    fun a b => (hpB.mul hΨb).ii a b
  have hp : ∀ a b, IntervalIntegrable p volume a b := fun a b => hpB.ii a b
  have hΨi : ∀ a b, IntervalIntegrable Ψ volume a b := fun a b => hΨb.ii a b
  have hout1 : ∫ u in (-π)..(-Q), p u * Ψ u ≤ ∫ u in (-π)..(-Q), t * p u := by
    refine intervalIntegral.integral_mono_on (by linarith) (hpΨ _ _) ((hp _ _).const_mul t)
      (fun u hu => ?_)
    have h : Ψ u ≤ t := by
      rw [hΨ.eq_abs u, abs_of_nonpos (by linarith [hu.2])]
      exact hΨ.anti ⟨hQ0, hQ⟩ ⟨by linarith [hu.2], by linarith [hu.1]⟩ (by linarith [hu.2])
    nlinarith [mul_nonneg (hp0 u) (sub_nonneg.mpr h)]
  have hout2 : ∫ u in Q..π, p u * Ψ u ≤ ∫ u in Q..π, t * p u := by
    refine intervalIntegral.integral_mono_on hQ (hpΨ _ _) ((hp _ _).const_mul t)
      (fun u hu => ?_)
    have h : Ψ u ≤ t := hΨ.anti ⟨hQ0, hQ⟩ ⟨by linarith [hu.1], hu.2⟩ hu.1
    nlinarith [mul_nonneg (hp0 u) (sub_nonneg.mpr h)]
  have hin : ∫ u in (-Q)..Q, p u * Ψ u ≤ ∫ u in (-Q)..Q, (Ψ u - t + t * p u) := by
    refine intervalIntegral.integral_mono_on (by linarith) (hpΨ _ _)
      (((hΨi _ _).sub intervalIntegrable_const).add ((hp _ _).const_mul t)) (fun u hu => ?_)
    have h : t ≤ Ψ u := by
      rw [hΨ.eq_abs u]
      exact hΨ.anti ⟨abs_nonneg u, by linarith [abs_le.mpr hu]⟩ ⟨hQ0, hQ⟩ (abs_le.mpr hu)
    nlinarith [mul_nonneg (sub_nonneg.mpr (hp1 u)) (sub_nonneg.mpr h)]
  have hsplitpΨ : ∫ u in (-π)..π, p u * Ψ u = (∫ u in (-π)..(-Q), p u * Ψ u) +
      (∫ u in (-Q)..Q, p u * Ψ u) + ∫ u in Q..π, p u * Ψ u := by
    rw [intervalIntegral.integral_add_adjacent_intervals (hpΨ _ _) (hpΨ _ _),
      intervalIntegral.integral_add_adjacent_intervals (hpΨ _ _) (hpΨ _ _)]
  have hsplitp : ∫ u in (-π)..π, p u = (∫ u in (-π)..(-Q), p u) +
      (∫ u in (-Q)..Q, p u) + ∫ u in Q..π, p u := by
    rw [intervalIntegral.integral_add_adjacent_intervals (hp _ _) (hp _ _),
      intervalIntegral.integral_add_adjacent_intervals (hp _ _) (hp _ _)]
  have hinner : ∫ u in (-Q)..Q, (Ψ u - t + t * p u) =
      (∫ u in (-Q)..Q, Ψ u) - 2 * Q * t + t * ∫ u in (-Q)..Q, p u := by
    rw [intervalIntegral.integral_add ((hΨi _ _).sub intervalIntegrable_const)
      ((hp _ _).const_mul t), intervalIntegral.integral_sub (hΨi _ _) intervalIntegrable_const,
      intervalIntegral.integral_const, intervalIntegral.integral_const_mul, smul_eq_mul]
    ring
  rw [intervalIntegral.integral_const_mul] at hout1 hout2
  have hlin : t * (∫ u in (-π)..(-Q), p u) + t * (∫ u in (-Q)..Q, p u) +
      t * (∫ u in Q..π, p u) = t * (2 * Q) := by
    rw [← hmass, hsplitp]; ring
  linarith

end EP1038.Circ
