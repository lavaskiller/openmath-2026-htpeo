import LeanProject.DLowerArithmetic
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_0 : RB (Real.log ((1004487 : ℝ) / 100000000000000)) ((-1151012736283 : ℝ) / 62500000000) ((-9208101890261 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((4114378752 : ℝ) / 6103515625)) (t := ((-1989136873 : ℝ) / 10217894377))
    (lo := ((-394377085969 : ℝ) / 1000000000000)) (hi := ((-98594271491 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1004487 : ℝ) / 100000000000000) = Real.log ((4114378752 : ℝ) / 6103515625) - 26 * Real.log 2 := by
    rw [show ((1004487 : ℝ) / 100000000000000) = ((4114378752 : ℝ) / 6103515625) / (2 : ℝ) ^ 26 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_1 : RB (Real.log (1 : ℝ)) (0 : ℝ) (0 : ℝ) := by
  have hm := log_bounds_of_series (x := (1 : ℝ)) (t := (0 : ℝ))
    (lo := (0 : ℝ)) (hi := (0 : ℝ)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_2 : RB (Real.log ((200000002009 : ℝ) / 200000000000)) ((2511 : ℝ) / 250000000000) ((2009 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((200000002009 : ℝ) / 200000000000)) (t := ((2009 : ℝ) / 400000002009))
    (lo := ((2511 : ℝ) / 250000000000)) (hi := ((2009 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_3 : RB (Real.log ((500000032587 : ℝ) / 500000000000)) ((65173 : ℝ) / 1000000000000) ((32587 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((500000032587 : ℝ) / 500000000000)) (t := ((32587 : ℝ) / 1000000032587))
    (lo := ((65173 : ℝ) / 1000000000000)) (hi := ((32587 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_4 : RB (Real.log ((1000000065177 : ℝ) / 1000000000000)) ((8147 : ℝ) / 125000000000) ((65177 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1000000065177 : ℝ) / 1000000000000)) (t := ((65177 : ℝ) / 2000000065177))
    (lo := ((8147 : ℝ) / 125000000000)) (hi := ((65177 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_5 : RB (Real.log ((250000008147 : ℝ) / 500000000000)) ((-693147147973 : ℝ) / 1000000000000) ((-693147147971 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((250000008147 : ℝ) / 250000000000)) (t := ((8147 : ℝ) / 500000008147))
    (lo := ((32587 : ℝ) / 1000000000000)) (hi := ((8147 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((250000008147 : ℝ) / 500000000000) = Real.log ((250000008147 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((250000008147 : ℝ) / 500000000000) = ((250000008147 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_6 : RB (Real.log ((3235052036517 : ℝ) / 1000000000000)) ((1174045013299 : ℝ) / 1000000000000) ((1174045013301 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3235052036517 : ℝ) / 4000000000000)) (t := ((-764947963483 : ℝ) / 7235052036517))
    (lo := ((-10612467391 : ℝ) / 50000000000)) (hi := ((-212249347819 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3235052036517 : ℝ) / 1000000000000) = Real.log ((3235052036517 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3235052036517 : ℝ) / 1000000000000) = ((3235052036517 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_7 : RB (Real.log ((80876300913 : ℝ) / 25000000000)) ((11740450133 : ℝ) / 10000000000) ((587022506651 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((80876300913 : ℝ) / 100000000000)) (t := ((-19123699087 : ℝ) / 180876300913))
    (lo := ((-212249347819 : ℝ) / 1000000000000)) (hi := ((-106124673909 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((80876300913 : ℝ) / 25000000000) = Real.log ((80876300913 : ℝ) / 100000000000) + 2 * Real.log 2 := by
    rw [show ((80876300913 : ℝ) / 25000000000) = ((80876300913 : ℝ) / 100000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_8 : RB (Real.log ((289483375211 : ℝ) / 200000000000)) ((184890251473 : ℝ) / 500000000000) ((92445125737 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((289483375211 : ℝ) / 400000000000)) (t := ((-110516624789 : ℝ) / 689483375211))
    (lo := ((-323366677613 : ℝ) / 1000000000000)) (hi := ((-80841669403 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((289483375211 : ℝ) / 200000000000) = Real.log ((289483375211 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((289483375211 : ℝ) / 200000000000) = ((289483375211 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_9 : RB (Real.log ((501119873 : ℝ) / 5000000000000)) ((-920810313047 : ℝ) / 100000000000) ((-2302025782617 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1002239746 : ℝ) / 1220703125)) (t := ((-218463379 : ℝ) / 2222942871))
    (lo := ((-19718978319 : ℝ) / 100000000000)) (hi := ((-197189783189 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((501119873 : ℝ) / 5000000000000) = Real.log ((1002239746 : ℝ) / 1220703125) - 13 * Real.log 2 := by
    rw [show ((501119873 : ℝ) / 5000000000000) = ((1002239746 : ℝ) / 1220703125) / (2 : ℝ) ^ 13 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_10 : RB (Real.log ((502241 : ℝ) / 50000000000000)) ((-3683241751641 : ℝ) / 200000000000) ((-92081043791 : ℝ) / 5000000000) := by
  have hm := log_bounds_of_series (x := ((4114358272 : ℝ) / 6103515625)) (t := ((-1989157353 : ℝ) / 10217873897))
    (lo := ((-197191031823 : ℝ) / 500000000000)) (hi := ((-197191031821 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((502241 : ℝ) / 50000000000000) = Real.log ((4114358272 : ℝ) / 6103515625) - 26 * Real.log 2 := by
    rw [show ((502241 : ℝ) / 50000000000000) = ((4114358272 : ℝ) / 6103515625) / (2 : ℝ) ^ 26 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_11 : RB (Real.log ((250000002511 : ℝ) / 250000000000)) ((10043 : ℝ) / 1000000000000) ((2511 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((250000002511 : ℝ) / 250000000000)) (t := ((2511 : ℝ) / 500000002511))
    (lo := ((10043 : ℝ) / 1000000000000)) (hi := ((2511 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_12 : RB (Real.log ((40004008959 : ℝ) / 40000000000)) ((12527369 : ℝ) / 125000000000) ((100218953 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((40004008959 : ℝ) / 40000000000)) (t := ((4008959 : ℝ) / 80004008959))
    (lo := ((12527369 : ℝ) / 125000000000)) (hi := ((100218953 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_13 : RB (Real.log ((250177059469 : ℝ) / 250000000000)) ((707987193 : ℝ) / 1000000000000) ((353993597 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((250177059469 : ℝ) / 250000000000)) (t := ((177059469 : ℝ) / 500177059469))
    (lo := ((707987193 : ℝ) / 1000000000000)) (hi := ((353993597 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_14 : RB (Real.log ((500354128987 : ℝ) / 500000000000)) ((708007277 : ℝ) / 1000000000000) ((354003639 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((500354128987 : ℝ) / 500000000000)) (t := ((354128987 : ℝ) / 1000354128987))
    (lo := ((708007277 : ℝ) / 1000000000000)) (hi := ((354003639 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_15 : RB (Real.log ((125044250453 : ℝ) / 250000000000)) ((-692793239581 : ℝ) / 1000000000000) ((-692793239579 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((125044250453 : ℝ) / 125000000000)) (t := ((44250453 : ℝ) / 250044250453))
    (lo := ((353940979 : ℝ) / 1000000000000)) (hi := ((17697049 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((125044250453 : ℝ) / 250000000000) = Real.log ((125044250453 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((125044250453 : ℝ) / 250000000000) = ((125044250453 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_16 : RB (Real.log ((3346881424347 : ℝ) / 1000000000000)) ((1208028994157 : ℝ) / 1000000000000) ((1208028994159 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3346881424347 : ℝ) / 4000000000000)) (t := ((-653118575653 : ℝ) / 7346881424347))
    (lo := ((-89132683481 : ℝ) / 500000000000)) (hi := ((-178265366961 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3346881424347 : ℝ) / 1000000000000) = Real.log ((3346881424347 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3346881424347 : ℝ) / 1000000000000) = ((3346881424347 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_17 : RB (Real.log ((3346881447923 : ℝ) / 1000000000000)) ((1208029001201 : ℝ) / 1000000000000) ((1208029001203 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3346881447923 : ℝ) / 4000000000000)) (t := ((-653118552077 : ℝ) / 7346881447923))
    (lo := ((-89132679959 : ℝ) / 500000000000)) (hi := ((-178265359917 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3346881447923 : ℝ) / 1000000000000) = Real.log ((3346881447923 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3346881447923 : ℝ) / 1000000000000) = ((3346881447923 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_18 : RB (Real.log ((285219472921 : ℝ) / 200000000000)) ((44367699723 : ℝ) / 125000000000) ((177470798893 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((285219472921 : ℝ) / 400000000000)) (t := ((-114780527079 : ℝ) / 685219472921))
    (lo := ((-13528223311 : ℝ) / 40000000000)) (hi := ((-169102791387 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285219472921 : ℝ) / 200000000000) = Real.log ((285219472921 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((285219472921 : ℝ) / 200000000000) = ((285219472921 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_19 : RB (Real.log ((1975273871 : ℝ) / 3125000000000)) ((-7366482504571 : ℝ) / 1000000000000) ((-7366482504569 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((7901095484 : ℝ) / 6103515625)) (t := ((1797579859 : ℝ) / 14004611109))
    (lo := ((258136481589 : ℝ) / 1000000000000)) (hi := ((25813648159 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1975273871 : ℝ) / 3125000000000) = Real.log ((7901095484 : ℝ) / 6103515625) - 11 * Real.log 2 := by
    rw [show ((1975273871 : ℝ) / 3125000000000) = ((7901095484 : ℝ) / 6103515625) / (2 : ℝ) ^ 11 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_20 : RB (Real.log ((2004479491 : ℝ) / 20000000000000)) ((-1151012891371 : ℝ) / 125000000000) ((-4604051565483 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((2004479491 : ℝ) / 2441406250)) (t := ((-436926759 : ℝ) / 4445885741))
    (lo := ((-24648722961 : ℝ) / 125000000000)) (hi := ((-197189783687 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2004479491 : ℝ) / 20000000000000) = Real.log ((2004479491 : ℝ) / 2441406250) - 13 * Real.log 2 := by
    rw [show ((2004479491 : ℝ) / 20000000000000) = ((2004479491 : ℝ) / 2441406250) / (2 : ℝ) ^ 13 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_21 : RB (Real.log ((500050111987 : ℝ) / 500000000000)) ((100218951 : ℝ) / 1000000000000) ((12527369 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((500050111987 : ℝ) / 500000000000)) (t := ((50111987 : ℝ) / 1000050111987))
    (lo := ((100218951 : ℝ) / 1000000000000)) (hi := ((12527369 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_22 : RB (Real.log ((1000632087639 : ℝ) / 1000000000000)) ((126377591 : ℝ) / 200000000000) ((157971989 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1000632087639 : ℝ) / 1000000000000)) (t := ((632087639 : ℝ) / 2000632087639))
    (lo := ((126377591 : ℝ) / 200000000000)) (hi := ((157971989 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_23 : RB (Real.log ((1003504514537 : ℝ) / 1000000000000)) ((699677607 : ℝ) / 200000000000) ((874597009 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1003504514537 : ℝ) / 1000000000000)) (t := ((3504514537 : ℝ) / 2003504514537))
    (lo := ((699677607 : ℝ) / 200000000000)) (hi := ((874597009 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_24 : RB (Real.log ((200701058977 : ℝ) / 200000000000)) ((3499165657 : ℝ) / 1000000000000) ((1749582829 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((200701058977 : ℝ) / 200000000000)) (t := ((701058977 : ℝ) / 400701058977))
    (lo := ((3499165657 : ℝ) / 1000000000000)) (hi := ((1749582829 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_25 : RB (Real.log ((100174959107 : ℝ) / 200000000000)) ((-345699559121 : ℝ) / 500000000000) ((-4321244489 : ℝ) / 6250000000) := by
  have hm := log_bounds_of_series (x := ((100174959107 : ℝ) / 100000000000)) (t := ((174959107 : ℝ) / 200174959107))
    (lo := ((874031159 : ℝ) / 500000000000)) (hi := ((1748062319 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((100174959107 : ℝ) / 200000000000) = Real.log ((100174959107 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((100174959107 : ℝ) / 200000000000) = ((100174959107 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_26 : RB (Real.log ((663427837051 : ℝ) / 200000000000)) ((1199102720269 : ℝ) / 1000000000000) ((1199102720271 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((663427837051 : ℝ) / 800000000000)) (t := ((-136572162949 : ℝ) / 1463427837051))
    (lo := ((-3743832817 : ℝ) / 20000000000)) (hi := ((-187191640849 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((663427837051 : ℝ) / 200000000000) = Real.log ((663427837051 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((663427837051 : ℝ) / 200000000000) = ((663427837051 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_27 : RB (Real.log ((3317140087761 : ℝ) / 1000000000000)) ((1199102992343 : ℝ) / 1000000000000) ((239820598469 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3317140087761 : ℝ) / 4000000000000)) (t := ((-682859912239 : ℝ) / 7317140087761))
    (lo := ((-23398921097 : ℝ) / 125000000000)) (hi := ((-7487654751 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3317140087761 : ℝ) / 1000000000000) = Real.log ((3317140087761 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3317140087761 : ℝ) / 1000000000000) = ((3317140087761 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_28 : RB (Real.log ((715783239701 : ℝ) / 500000000000)) ((71753856971 : ℝ) / 200000000000) ((358769284857 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((715783239701 : ℝ) / 1000000000000)) (t := ((-284216760299 : ℝ) / 1715783239701))
    (lo := ((-41797236963 : ℝ) / 125000000000)) (hi := ((-334377895703 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((715783239701 : ℝ) / 500000000000) = Real.log ((715783239701 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((715783239701 : ℝ) / 500000000000) = ((715783239701 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_29 : RB (Real.log ((123485431813 : ℝ) / 100000000000000)) ((-669680227689 : ℝ) / 100000000000) ((-837100284611 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((123485431813 : ℝ) / 97656250000)) (t := ((25829181813 : ℝ) / 221141681813))
    (lo := ((23466952871 : ℝ) / 100000000000)) (hi := ((234669528711 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123485431813 : ℝ) / 100000000000000) = Real.log ((123485431813 : ℝ) / 97656250000) - 10 * Real.log 2 := by
    rw [show ((123485431813 : ℝ) / 100000000000000) = ((123485431813 : ℝ) / 97656250000) / (2 : ℝ) ^ 10 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_30 : RB (Real.log ((63208763867 : ℝ) / 100000000000000)) ((-7366482504651 : ℝ) / 1000000000000) ((-920810313081 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((63208763867 : ℝ) / 48828125000)) (t := ((14380638867 : ℝ) / 112036888867))
    (lo := ((258136481509 : ℝ) / 1000000000000)) (hi := ((258136481511 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63208763867 : ℝ) / 100000000000000) = Real.log ((63208763867 : ℝ) / 48828125000) - 11 * Real.log 2 := by
    rw [show ((63208763867 : ℝ) / 100000000000000) = ((63208763867 : ℝ) / 48828125000) / (2 : ℝ) ^ 11 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_31 : RB (Real.log ((500316043819 : ℝ) / 500000000000)) ((315943977 : ℝ) / 500000000000) ((126377591 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((500316043819 : ℝ) / 500000000000)) (t := ((316043819 : ℝ) / 1000316043819))
    (lo := ((315943977 : ℝ) / 500000000000)) (hi := ((126377591 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_32 : RB (Real.log ((1001234854319 : ℝ) / 1000000000000)) ((1234092513 : ℝ) / 1000000000000) ((617046257 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1001234854319 : ℝ) / 1000000000000)) (t := ((1234854319 : ℝ) / 2001234854319))
    (lo := ((1234092513 : ℝ) / 1000000000000)) (hi := ((617046257 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_33 : RB (Real.log ((1001575584921 : ℝ) / 1000000000000)) ((1574344989 : ℝ) / 1000000000000) ((157434499 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((1001575584921 : ℝ) / 1000000000000)) (t := ((1575584921 : ℝ) / 2001575584921))
    (lo := ((1574344989 : ℝ) / 1000000000000)) (hi := ((157434499 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_34 : RB (Real.log ((1001577837363 : ℝ) / 1000000000000)) ((315318777 : ℝ) / 200000000000) ((788296943 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1001577837363 : ℝ) / 1000000000000)) (t := ((1577837363 : ℝ) / 2001577837363))
    (lo := ((315318777 : ℝ) / 200000000000)) (hi := ((788296943 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_35 : RB (Real.log ((500394347999 : ℝ) / 1000000000000)) ((-34617939771 : ℝ) / 50000000000) ((-346179397709 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((500394347999 : ℝ) / 500000000000)) (t := ((394347999 : ℝ) / 1000394347999))
    (lo := ((39419257 : ℝ) / 50000000000)) (hi := ((788385141 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((500394347999 : ℝ) / 1000000000000) = Real.log ((500394347999 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((500394347999 : ℝ) / 1000000000000) = ((500394347999 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_36 : RB (Real.log ((1649839743717 : ℝ) / 500000000000)) ((596912669367 : ℝ) / 500000000000) ((74614083671 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((1649839743717 : ℝ) / 2000000000000)) (t := ((-350160256283 : ℝ) / 3649839743717))
    (lo := ((-38493804477 : ℝ) / 200000000000)) (hi := ((-12029313899 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1649839743717 : ℝ) / 500000000000) = Real.log ((1649839743717 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1649839743717 : ℝ) / 500000000000) = ((1649839743717 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_37 : RB (Real.log ((1649841037671 : ℝ) / 500000000000)) ((47753044921 : ℝ) / 40000000000) ((1193826123027 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1649841037671 : ℝ) / 2000000000000)) (t := ((-350158962329 : ℝ) / 3649841037671))
    (lo := ((-96234119047 : ℝ) / 500000000000)) (hi := ((-192468238093 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1649841037671 : ℝ) / 500000000000) = Real.log ((1649841037671 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1649841037671 : ℝ) / 500000000000) = ((1649841037671 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_38 : RB (Real.log ((1434842542449 : ℝ) / 1000000000000)) ((361055116673 : ℝ) / 1000000000000) ((14442204667 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((1434842542449 : ℝ) / 2000000000000)) (t := ((-565157457551 : ℝ) / 3434842542449))
    (lo := ((-166046031943 : ℝ) / 500000000000)) (hi := ((-66418412777 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1434842542449 : ℝ) / 1000000000000) = Real.log ((1434842542449 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1434842542449 : ℝ) / 1000000000000) = ((1434842542449 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_39 : RB (Real.log ((215765041431 : ℝ) / 100000000000000)) ((-1534683855123 : ℝ) / 250000000000) ((-613873542049 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((215765041431 : ℝ) / 195312500000)) (t := ((20452541431 : ℝ) / 411077541431))
    (lo := ((24897301137 : ℝ) / 250000000000)) (hi := ((99589204549 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((215765041431 : ℝ) / 100000000000000) = Real.log ((215765041431 : ℝ) / 195312500000) - 9 * Real.log 2 := by
    rw [show ((215765041431 : ℝ) / 100000000000000) = ((215765041431 : ℝ) / 195312500000) / (2 : ℝ) ^ 9 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_40 : RB (Real.log ((60295621 : ℝ) / 48828125000)) ((-669680227693 : ℝ) / 100000000000) ((-104637535577 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((7717839488 : ℝ) / 6103515625)) (t := ((1614323863 : ℝ) / 13821355113))
    (lo := ((23466952867 : ℝ) / 100000000000)) (hi := ((234669528671 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((60295621 : ℝ) / 48828125000) = Real.log ((7717839488 : ℝ) / 6103515625) - 10 * Real.log 2 := by
    rw [show ((60295621 : ℝ) / 48828125000) = ((7717839488 : ℝ) / 6103515625) / (2 : ℝ) ^ 10 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_41 : RB (Real.log ((500617427159 : ℝ) / 500000000000)) ((38565391 : ℝ) / 31250000000) ((1234092513 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((500617427159 : ℝ) / 500000000000)) (t := ((617427159 : ℝ) / 1000617427159))
    (lo := ((38565391 : ℝ) / 31250000000)) (hi := ((1234092513 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_42 : RB (Real.log ((200431530083 : ℝ) / 200000000000)) ((215532603 : ℝ) / 100000000000) ((2155326031 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((200431530083 : ℝ) / 200000000000)) (t := ((431530083 : ℝ) / 400431530083))
    (lo := ((215532603 : ℝ) / 100000000000)) (hi := ((2155326031 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_43 : RB (Real.log ((250300271799 : ℝ) / 250000000000)) ((1200366467 : ℝ) / 1000000000000) ((300091617 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((250300271799 : ℝ) / 250000000000)) (t := ((300271799 : ℝ) / 500300271799))
    (lo := ((1200366467 : ℝ) / 1000000000000)) (hi := ((300091617 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_44 : RB (Real.log ((125150919021 : ℝ) / 125000000000)) ((37706997 : ℝ) / 31250000000) ((241324781 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((125150919021 : ℝ) / 125000000000)) (t := ((150919021 : ℝ) / 250150919021))
    (lo := ((37706997 : ℝ) / 31250000000)) (hi := ((241324781 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_45 : RB (Real.log ((62537802239 : ℝ) / 125000000000)) ((-86567815947 : ℝ) / 125000000000) ((-346271263787 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((62537802239 : ℝ) / 62500000000)) (t := ((37802239 : ℝ) / 125037802239))
    (lo := ((75581623 : ℝ) / 125000000000)) (hi := ((120930597 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62537802239 : ℝ) / 125000000000) = Real.log ((62537802239 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((62537802239 : ℝ) / 125000000000) = ((62537802239 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_46 : RB (Real.log ((3325352146211 : ℝ) / 1000000000000)) ((1201575577133 : ℝ) / 1000000000000) ((240315115427 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3325352146211 : ℝ) / 4000000000000)) (t := ((-674647853789 : ℝ) / 7325352146211))
    (lo := ((-92359391993 : ℝ) / 500000000000)) (hi := ((-36943756797 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3325352146211 : ℝ) / 1000000000000) = Real.log ((3325352146211 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3325352146211 : ℝ) / 1000000000000) = ((3325352146211 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_47 : RB (Real.log ((831339856493 : ℝ) / 250000000000)) ((1201577766301 : ℝ) / 1000000000000) ((1201577766303 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((831339856493 : ℝ) / 1000000000000)) (t := ((-168660143507 : ℝ) / 1831339856493))
    (lo := ((-92358297409 : ℝ) / 500000000000)) (hi := ((-184716594817 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((831339856493 : ℝ) / 250000000000) = Real.log ((831339856493 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((831339856493 : ℝ) / 250000000000) = ((831339856493 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_48 : RB (Real.log ((1430040390301 : ℝ) / 1000000000000)) ((357702688837 : ℝ) / 1000000000000) ((357702688839 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1430040390301 : ℝ) / 2000000000000)) (t := ((-569959609699 : ℝ) / 3430040390301))
    (lo := ((-167722245861 : ℝ) / 500000000000)) (hi := ((-335444491721 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1430040390301 : ℝ) / 1000000000000) = Real.log ((1430040390301 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1430040390301 : ℝ) / 1000000000000) = ((1430040390301 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_49 : RB (Real.log ((345986743741 : ℝ) / 100000000000000)) ((-1133305000707 : ℝ) / 200000000000) ((-5666525003533 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((345986743741 : ℝ) / 390625000000)) (t := ((-44638256259 : ℝ) / 736611743741))
    (lo := ((-24269511811 : ℝ) / 200000000000)) (hi := ((-60673779527 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((345986743741 : ℝ) / 100000000000000) = Real.log ((345986743741 : ℝ) / 390625000000) - 8 * Real.log 2 := by
    rw [show ((345986743741 : ℝ) / 100000000000000) = ((345986743741 : ℝ) / 390625000000) / (2 : ℝ) ^ 8 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_50 : RB (Real.log ((107882520713 : ℝ) / 50000000000000)) ((-1227747084103 : ℝ) / 200000000000) ((-6138735420513 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((107882520713 : ℝ) / 97656250000)) (t := ((10226270713 : ℝ) / 205538770713))
    (lo := ((3983568181 : ℝ) / 40000000000)) (hi := ((49794602263 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((107882520713 : ℝ) / 50000000000000) = Real.log ((107882520713 : ℝ) / 97656250000) - 9 * Real.log 2 := by
    rw [show ((107882520713 : ℝ) / 50000000000000) = ((107882520713 : ℝ) / 97656250000) / (2 : ℝ) ^ 9 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_51 : RB (Real.log ((501078825207 : ℝ) / 500000000000)) ((2155326029 : ℝ) / 1000000000000) ((215532603 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((501078825207 : ℝ) / 500000000000)) (t := ((1078825207 : ℝ) / 1001078825207))
    (lo := ((2155326029 : ℝ) / 1000000000000)) (hi := ((215532603 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_52 : RB (Real.log ((501729933719 : ℝ) / 500000000000)) ((1726947933 : ℝ) / 500000000000) ((3453895867 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((501729933719 : ℝ) / 500000000000)) (t := ((1729933719 : ℝ) / 1001729933719))
    (lo := ((1726947933 : ℝ) / 500000000000)) (hi := ((3453895867 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_53 : RB (Real.log ((999736605449 : ℝ) / 1000000000000)) ((-131714623 : ℝ) / 500000000000) ((-52685849 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((999736605449 : ℝ) / 1000000000000)) (t := ((-263394551 : ℝ) / 1999736605449))
    (lo := ((-131714623 : ℝ) / 500000000000)) (hi := ((-52685849 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_54 : RB (Real.log ((499875617077 : ℝ) / 500000000000)) ((-124398397 : ℝ) / 500000000000) ((-248796793 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((499875617077 : ℝ) / 500000000000)) (t := ((-124382923 : ℝ) / 999875617077))
    (lo := ((-124398397 : ℝ) / 500000000000)) (hi := ((-248796793 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_55 : RB (Real.log ((499940128819 : ℝ) / 1000000000000)) ((-173316732523 : ℝ) / 250000000000) ((-69326693009 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((499940128819 : ℝ) / 500000000000)) (t := ((-59871181 : ℝ) / 999940128819))
    (lo := ((-29937383 : ℝ) / 250000000000)) (hi := ((-119749531 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((499940128819 : ℝ) / 1000000000000) = Real.log ((499940128819 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((499940128819 : ℝ) / 1000000000000) = ((499940128819 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_56 : RB (Real.log ((837434614041 : ℝ) / 250000000000)) ((1208882270001 : ℝ) / 1000000000000) ((1208882270003 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((837434614041 : ℝ) / 1000000000000)) (t := ((-162565385959 : ℝ) / 1837434614041))
    (lo := ((-88706045559 : ℝ) / 500000000000)) (hi := ((-177412091117 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((837434614041 : ℝ) / 250000000000) = Real.log ((837434614041 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((837434614041 : ℝ) / 250000000000) = ((837434614041 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_57 : RB (Real.log ((3349755645243 : ℝ) / 1000000000000)) ((1208887401457 : ℝ) / 1000000000000) ((1208887401459 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3349755645243 : ℝ) / 4000000000000)) (t := ((-650244354757 : ℝ) / 7349755645243))
    (lo := ((-88703479831 : ℝ) / 500000000000)) (hi := ((-177406959661 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3349755645243 : ℝ) / 1000000000000) = Real.log ((3349755645243 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3349755645243 : ℝ) / 1000000000000) = ((3349755645243 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_58 : RB (Real.log ((1425574185371 : ℝ) / 1000000000000)) ((11080458427 : ℝ) / 31250000000) ((177287334833 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1425574185371 : ℝ) / 2000000000000)) (t := ((-574425814629 : ℝ) / 3425574185371))
    (lo := ((-67714502179 : ℝ) / 200000000000)) (hi := ((-169286255447 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425574185371 : ℝ) / 1000000000000) = Real.log ((1425574185371 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1425574185371 : ℝ) / 1000000000000) = ((1425574185371 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_59 : RB (Real.log ((106695330743 : ℝ) / 25000000000000)) ((-545665370711 : ℝ) / 100000000000) ((-1364163426777 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((106695330743 : ℝ) / 97656250000)) (t := ((9039080743 : ℝ) / 204351580743))
    (lo := ((8852373737 : ℝ) / 100000000000)) (hi := ((88523737371 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((106695330743 : ℝ) / 25000000000000) = Real.log ((106695330743 : ℝ) / 97656250000) - 8 * Real.log 2 := by
    rw [show ((106695330743 : ℝ) / 25000000000000) = ((106695330743 : ℝ) / 97656250000) / (2 : ℝ) ^ 8 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
