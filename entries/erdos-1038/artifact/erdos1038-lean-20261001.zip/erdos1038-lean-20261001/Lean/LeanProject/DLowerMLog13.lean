import LeanProject.DLowerMTools
import LeanProject.DLowerMLog10
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_520 : RB (Real.log ((712675357554005651 : ℝ) / 500000000000000000)) ((177208949652171889 : ℝ) / 500000000000000000) ((17720894965217189 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((712675357554005651 : ℝ) / 1000000000000000000)) (t := ((-287324642445994349 : ℝ) / 1712675357554005651))
    (lo := ((-338729281255601531 : ℝ) / 1000000000000000000)) (hi := ((-33872928125560153 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712675357554005651 : ℝ) / 500000000000000000) = Real.log ((712675357554005651 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712675357554005651 : ℝ) / 500000000000000000) = ((712675357554005651 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_521 : RB (Real.log ((712814557917030403 : ℝ) / 500000000000000000)) ((354613201090707117 : ℝ) / 1000000000000000000) ((354613201090707119 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712814557917030403 : ℝ) / 1000000000000000000)) (t := ((-287185442082969597 : ℝ) / 1712814557917030403))
    (lo := ((-21158373716827387 : ℝ) / 62500000000000000)) (hi := ((-338533979469238191 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712814557917030403 : ℝ) / 500000000000000000) = Real.log ((712814557917030403 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712814557917030403 : ℝ) / 500000000000000000) = ((712814557917030403 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_522 : RB (Real.log ((712314224741505651 : ℝ) / 500000000000000000)) ((353911042517854689 : ℝ) / 1000000000000000000) ((353911042517854691 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712314224741505651 : ℝ) / 1000000000000000000)) (t := ((-287685775258494349 : ℝ) / 1712314224741505651))
    (lo := ((-16961806902104531 : ℝ) / 50000000000000000)) (hi := ((-339236138042090619 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712314224741505651 : ℝ) / 500000000000000000) = Real.log ((712314224741505651 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712314224741505651 : ℝ) / 500000000000000000) = ((712314224741505651 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_523 : RB (Real.log ((1424628449483011303 : ℝ) / 1000000000000000000)) ((353911042517854689 : ℝ) / 1000000000000000000) ((353911042517854691 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424628449483011303 : ℝ) / 2000000000000000000)) (t := ((-575371550516988697 : ℝ) / 3424628449483011303))
    (lo := ((-16961806902104531 : ℝ) / 50000000000000000)) (hi := ((-339236138042090619 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424628449483011303 : ℝ) / 1000000000000000000) = Real.log ((1424628449483011303 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424628449483011303 : ℝ) / 1000000000000000000) = ((1424628449483011303 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_524 : RB (Real.log ((1424661652608011303 : ℝ) / 1000000000000000000)) ((353934348761734269 : ℝ) / 1000000000000000000) ((353934348761734271 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424661652608011303 : ℝ) / 2000000000000000000)) (t := ((-575338347391988697 : ℝ) / 3424661652608011303))
    (lo := ((-2120080198738819 : ℝ) / 6250000000000000)) (hi := ((-339212831798211039 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424661652608011303 : ℝ) / 1000000000000000000) = Real.log ((1424661652608011303 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424661652608011303 : ℝ) / 1000000000000000000) = ((1424661652608011303 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_525 : RB (Real.log ((712453425104530403 : ℝ) / 500000000000000000)) ((354106443309671797 : ℝ) / 1000000000000000000) ((354106443309671799 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712453425104530403 : ℝ) / 1000000000000000000)) (t := ((-287546574895469597 : ℝ) / 1712453425104530403))
    (lo := ((-42380092156284189 : ℝ) / 125000000000000000)) (hi := ((-339040737250273511 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712453425104530403 : ℝ) / 500000000000000000) = Real.log ((712453425104530403 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712453425104530403 : ℝ) / 500000000000000000) = ((712453425104530403 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_526 : RB (Real.log ((1424906850209060807 : ℝ) / 1000000000000000000)) ((177053221654835899 : ℝ) / 500000000000000000) ((1770532216548359 : ℝ) / 5000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424906850209060807 : ℝ) / 2000000000000000000)) (t := ((-575093149790939193 : ℝ) / 3424906850209060807))
    (lo := ((-339040737250273511 : ℝ) / 1000000000000000000)) (hi := ((-33904073725027351 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424906850209060807 : ℝ) / 1000000000000000000) = Real.log ((1424906850209060807 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424906850209060807 : ℝ) / 1000000000000000000) = ((1424906850209060807 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_527 : RB (Real.log ((712436432917030403 : ℝ) / 500000000000000000)) ((88520648195497613 : ℝ) / 250000000000000000) ((177041296390995227 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((712436432917030403 : ℝ) / 1000000000000000000)) (t := ((-287563567082969597 : ℝ) / 1712436432917030403))
    (lo := ((-339064587777954857 : ℝ) / 1000000000000000000)) (hi := ((-42383073472244357 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712436432917030403 : ℝ) / 500000000000000000) = Real.log ((712436432917030403 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712436432917030403 : ℝ) / 500000000000000000) = ((712436432917030403 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_528 : RB (Real.log ((28749999999999999 : ℝ) / 1000000000000000000)) ((-1774558755869388821 : ℝ) / 500000000000000000) ((-88727937793469441 : ℝ) / 25000000000000000) := by
  have hm := log_bounds_of_series (x := ((28749999999999999 : ℝ) / 31250000000000000)) (t := ((-2500000000000001 : ℝ) / 59999999999999999))
    (lo := ((-41690804469525547 : ℝ) / 500000000000000000)) (hi := ((-83381608939051093 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28749999999999999 : ℝ) / 1000000000000000000) = Real.log ((28749999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((28749999999999999 : ℝ) / 1000000000000000000) = ((28749999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_529 : RB (Real.log ((23 : ℝ) / 800)) ((-3549117511738777607 : ℝ) / 1000000000000000000) ((-709823502347755521 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((23 : ℝ) / 25)) (t := ((-1 : ℝ) / 24))
    (lo := ((-83381608939051059 : ℝ) / 1000000000000000000)) (hi := ((-41690804469525529 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23 : ℝ) / 800) = Real.log ((23 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((23 : ℝ) / 800) = ((23 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_530 : RB (Real.log ((1028749999999999999 : ℝ) / 1000000000000000000)) ((14172236504571257 : ℝ) / 500000000000000000) ((5668894601828503 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1028749999999999999 : ℝ) / 1000000000000000000)) (t := ((28749999999999999 : ℝ) / 2028749999999999999))
    (lo := ((14172236504571257 : ℝ) / 500000000000000000)) (hi := ((5668894601828503 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_531 : RB (Real.log ((823 : ℝ) / 800)) ((5668894601828503 : ℝ) / 200000000000000000) ((7086118252285629 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((823 : ℝ) / 800)) (t := ((23 : ℝ) / 1623))
    (lo := ((5668894601828503 : ℝ) / 200000000000000000)) (hi := ((7086118252285629 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_532 : RB (Real.log ((27499999999999999 : ℝ) / 1000000000000000000)) ((-3593569274309611481 : ℝ) / 1000000000000000000) ((-3593569274309611479 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((27499999999999999 : ℝ) / 31250000000000000)) (t := ((-3750000000000001 : ℝ) / 58749999999999999))
    (lo := ((-127833371509884933 : ℝ) / 1000000000000000000)) (hi := ((-31958342877471233 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((27499999999999999 : ℝ) / 1000000000000000000) = Real.log ((27499999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((27499999999999999 : ℝ) / 1000000000000000000) = ((27499999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_533 : RB (Real.log ((3 : ℝ) / 100)) ((-1753278948659990839 : ℝ) / 500000000000000000) ((-876639474329995419 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((24 : ℝ) / 25)) (t := ((-1 : ℝ) / 49))
    (lo := ((-4082199452025513 : ℝ) / 100000000000000000)) (hi := ((-40821994520255129 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3 : ℝ) / 100) = Real.log ((24 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((3 : ℝ) / 100) = ((24 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_534 : RB (Real.log ((1027499999999999999 : ℝ) / 1000000000000000000)) ((13564333694126309 : ℝ) / 500000000000000000) ((27128667388252619 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1027499999999999999 : ℝ) / 1000000000000000000)) (t := ((27499999999999999 : ℝ) / 2027499999999999999))
    (lo := ((13564333694126309 : ℝ) / 500000000000000000)) (hi := ((27128667388252619 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_535 : RB (Real.log ((103 : ℝ) / 100)) ((14779401120772201 : ℝ) / 500000000000000000) ((29558802241544403 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((103 : ℝ) / 100)) (t := ((3 : ℝ) / 203))
    (lo := ((14779401120772201 : ℝ) / 500000000000000000)) (hi := ((29558802241544403 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_536 : RB (Real.log ((226464025580419 : ℝ) / 500000000000000)) ((-19800549839325961 : ℝ) / 25000000000000000) ((-396010996786519219 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((226464025580419 : ℝ) / 250000000000000)) (t := ((-23535974419581 : ℝ) / 476464025580419))
    (lo := ((-9887481301309313 : ℝ) / 100000000000000000)) (hi := ((-98874813013093129 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((226464025580419 : ℝ) / 500000000000000) = Real.log ((226464025580419 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((226464025580419 : ℝ) / 500000000000000) = ((226464025580419 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_537 : RB (Real.log ((452928051160841001 : ℝ) / 1000000000000000000)) ((-396010996786515907 : ℝ) / 500000000000000000) ((-198005498393257953 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((452928051160841001 : ℝ) / 500000000000000000)) (t := ((-47071948839158999 : ℝ) / 952928051160841001))
    (lo := ((-12359351626635813 : ℝ) / 125000000000000000)) (hi := ((-98874813013086503 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((452928051160841001 : ℝ) / 1000000000000000000) = Real.log ((452928051160841001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((452928051160841001 : ℝ) / 1000000000000000000) = ((452928051160841001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_538 : RB (Real.log ((546245386339159 : ℝ) / 1000000000000000)) ((-604686978669041477 : ℝ) / 1000000000000000000) ((-24187479146761659 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((546245386339159 : ℝ) / 500000000000000)) (t := ((46245386339159 : ℝ) / 1046245386339159))
    (lo := ((88460201890903833 : ℝ) / 1000000000000000000)) (hi := ((44230100945451917 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((546245386339159 : ℝ) / 1000000000000000) = Real.log ((546245386339159 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((546245386339159 : ℝ) / 1000000000000000) = ((546245386339159 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_539 : RB (Real.log ((273122693169581 : ℝ) / 500000000000000)) ((-37792936166814749 : ℝ) / 62500000000000000) ((-302343489334517991 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((273122693169581 : ℝ) / 250000000000000)) (t := ((23122693169581 : ℝ) / 523122693169581))
    (lo := ((44230100945454663 : ℝ) / 500000000000000000)) (hi := ((88460201890909327 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((273122693169581 : ℝ) / 500000000000000) = Real.log ((273122693169581 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((273122693169581 : ℝ) / 500000000000000) = ((273122693169581 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_540 : RB (Real.log ((226877306830419 : ℝ) / 500000000000000)) ((-79019872560719187 : ℝ) / 100000000000000000) ((-197549681401797967 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((226877306830419 : ℝ) / 250000000000000)) (t := ((-23122693169581 : ℝ) / 476877306830419))
    (lo := ((-606572156545291 : ℝ) / 6250000000000000)) (hi := ((-97051545047246559 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((226877306830419 : ℝ) / 500000000000000) = Real.log ((226877306830419 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((226877306830419 : ℝ) / 500000000000000) = ((226877306830419 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_541 : RB (Real.log ((453754613660841 : ℝ) / 1000000000000000)) ((-790198725607185259 : ℝ) / 1000000000000000000) ((-790198725607185257 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((453754613660841 : ℝ) / 500000000000000)) (t := ((-46245386339159 : ℝ) / 953754613660841))
    (lo := ((-97051545047239949 : ℝ) / 1000000000000000000)) (hi := ((-24262886261809987 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((453754613660841 : ℝ) / 1000000000000000) = Real.log ((453754613660841 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((453754613660841 : ℝ) / 1000000000000000) = ((453754613660841 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_542 : RB (Real.log ((452928051160838001 : ℝ) / 1000000000000000000)) ((-396010996786519219 : ℝ) / 500000000000000000) ((-198005498393259609 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((452928051160838001 : ℝ) / 500000000000000000)) (t := ((-47071948839161999 : ℝ) / 952928051160838001))
    (lo := ((-12359351626636641 : ℝ) / 125000000000000000)) (hi := ((-98874813013093127 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((452928051160838001 : ℝ) / 1000000000000000000) = Real.log ((452928051160838001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((452928051160838001 : ℝ) / 1000000000000000000) = ((452928051160838001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_543 : RB (Real.log ((452928051160841 : ℝ) / 1000000000000000)) ((-792021993573031817 : ℝ) / 1000000000000000000) ((-158404398714606363 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((452928051160841 : ℝ) / 500000000000000)) (t := ((-47071948839159 : ℝ) / 952928051160841))
    (lo := ((-98874813013086507 : ℝ) / 1000000000000000000)) (hi := ((-49437406506543253 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((452928051160841 : ℝ) / 1000000000000000) = Real.log ((452928051160841 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((452928051160841 : ℝ) / 1000000000000000) = ((452928051160841 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_544 : RB (Real.log ((1425036508500823 : ℝ) / 1000000000000000)) ((177098716696502391 : ℝ) / 500000000000000000) ((22137339587062799 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((1425036508500823 : ℝ) / 2000000000000000)) (t := ((-574963491499177 : ℝ) / 3425036508500823))
    (lo := ((-338949747166940527 : ℝ) / 1000000000000000000)) (hi := ((-169474873583470263 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425036508500823 : ℝ) / 1000000000000000) = Real.log ((1425036508500823 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425036508500823 : ℝ) / 1000000000000000) = ((1425036508500823 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_545 : RB (Real.log ((1425036508500826001 : ℝ) / 1000000000000000000)) ((44274679174125861 : ℝ) / 125000000000000000) ((35419743339300689 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425036508500826001 : ℝ) / 2000000000000000000)) (t := ((-574963491499173999 : ℝ) / 3425036508500826001))
    (lo := ((-338949747166938421 : ℝ) / 1000000000000000000)) (hi := ((-16947487358346921 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425036508500826001 : ℝ) / 1000000000000000000) = Real.log ((1425036508500826001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425036508500826001 : ℝ) / 1000000000000000000) = ((1425036508500826001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_546 : RB (Real.log ((425863071000823 : ℝ) / 1000000000000000)) ((-26676169186183059 : ℝ) / 31250000000000000) ((-426818706978928943 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((425863071000823 : ℝ) / 500000000000000)) (t := ((-74136928999177 : ℝ) / 925863071000823))
    (lo := ((-80245116698956289 : ℝ) / 500000000000000000)) (hi := ((-160490233397912577 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425863071000823 : ℝ) / 1000000000000000) = Real.log ((425863071000823 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425863071000823 : ℝ) / 1000000000000000) = ((425863071000823 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_547 : RB (Real.log ((212931535500413 : ℝ) / 500000000000000)) ((-853637413957850843 : ℝ) / 1000000000000000000) ((-853637413957850841 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((212931535500413 : ℝ) / 250000000000000)) (t := ((-37068464499587 : ℝ) / 462931535500413))
    (lo := ((-160490233397905533 : ℝ) / 1000000000000000000)) (hi := ((-40122558349476383 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212931535500413 : ℝ) / 500000000000000) = Real.log ((212931535500413 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212931535500413 : ℝ) / 500000000000000) = ((212931535500413 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_548 : RB (Real.log ((1425863071000823 : ℝ) / 1000000000000000)) ((70955458848101879 : ℝ) / 200000000000000000) ((354777294240509397 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425863071000823 : ℝ) / 2000000000000000)) (t := ((-574136928999177 : ℝ) / 3425863071000823))
    (lo := ((-169184943159717957 : ℝ) / 500000000000000000)) (hi := ((-338369886319435913 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425863071000823 : ℝ) / 1000000000000000) = Real.log ((1425863071000823 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425863071000823 : ℝ) / 1000000000000000) = ((1425863071000823 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_549 : RB (Real.log ((712931535500413 : ℝ) / 500000000000000)) ((354777294240511499 : ℝ) / 1000000000000000000) ((354777294240511501 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712931535500413 : ℝ) / 1000000000000000)) (t := ((-287068464499587 : ℝ) / 1712931535500413))
    (lo := ((-33836988631943381 : ℝ) / 100000000000000000)) (hi := ((-338369886319433809 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712931535500413 : ℝ) / 500000000000000) = Real.log ((712931535500413 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712931535500413 : ℝ) / 500000000000000) = ((712931535500413 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_550 : RB (Real.log ((1425036508500823001 : ℝ) / 1000000000000000000)) ((354197433393004783 : ℝ) / 1000000000000000000) ((70839486678600957 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425036508500823001 : ℝ) / 2000000000000000000)) (t := ((-574963491499176999 : ℝ) / 3425036508500823001))
    (lo := ((-169474873583470263 : ℝ) / 500000000000000000)) (hi := ((-13557989886677621 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425036508500823001 : ℝ) / 1000000000000000000) = Real.log ((1425036508500823001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425036508500823001 : ℝ) / 1000000000000000000) = ((1425036508500823001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_551 : RB (Real.log ((712518254250413 : ℝ) / 500000000000000)) ((354197433393006887 : ℝ) / 1000000000000000000) ((354197433393006889 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712518254250413 : ℝ) / 1000000000000000)) (t := ((-287481745749587 : ℝ) / 1712518254250413))
    (lo := ((-169474873583469211 : ℝ) / 500000000000000000)) (hi := ((-338949747166938421 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712518254250413 : ℝ) / 500000000000000) = Real.log ((712518254250413 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712518254250413 : ℝ) / 500000000000000) = ((712518254250413 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_552 : RB (Real.log ((224973438127638807 : ℝ) / 500000000000000000)) ((-159725151190519521 : ℝ) / 200000000000000000) ((-798625755952597603 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((224973438127638807 : ℝ) / 250000000000000000)) (t := ((-25026561872361193 : ℝ) / 474973438127638807))
    (lo := ((-21095715078530459 : ℝ) / 200000000000000000)) (hi := ((-52739287696326147 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((224973438127638807 : ℝ) / 500000000000000000) = Real.log ((224973438127638807 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((224973438127638807 : ℝ) / 500000000000000000) = ((224973438127638807 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_553 : RB (Real.log ((227953050533200651 : ℝ) / 500000000000000000)) ((-39273420469297627 : ℝ) / 50000000000000000) ((-392734204692976269 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((227953050533200651 : ℝ) / 250000000000000000)) (t := ((-22046949466799349 : ℝ) / 477953050533200651))
    (lo := ((-9232122882600723 : ℝ) / 100000000000000000)) (hi := ((-92321228826007229 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((227953050533200651 : ℝ) / 500000000000000000) = Real.log ((227953050533200651 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((227953050533200651 : ℝ) / 500000000000000000) = ((227953050533200651 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_554 : RB (Real.log ((543337648933598699 : ℝ) / 1000000000000000000)) ((-305012165529204241 : ℝ) / 500000000000000000) ((-3812652069115053 : ℝ) / 6250000000000000) := by
  have hm := log_bounds_of_series (x := ((543337648933598699 : ℝ) / 500000000000000000)) (t := ((43337648933598699 : ℝ) / 1043337648933598699))
    (lo := ((20780712375384207 : ℝ) / 250000000000000000)) (hi := ((83122849501536829 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((543337648933598699 : ℝ) / 1000000000000000000) = Real.log ((543337648933598699 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((543337648933598699 : ℝ) / 1000000000000000000) = ((543337648933598699 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_555 : RB (Real.log ((274576561872361193 : ℝ) / 500000000000000000)) ((-599377962437051057 : ℝ) / 1000000000000000000) ((-119875592487410211 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((274576561872361193 : ℝ) / 250000000000000000)) (t := ((24576561872361193 : ℝ) / 524576561872361193))
    (lo := ((93769218122894253 : ℝ) / 1000000000000000000)) (hi := ((46884609061447127 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((274576561872361193 : ℝ) / 500000000000000000) = Real.log ((274576561872361193 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((274576561872361193 : ℝ) / 500000000000000000) = ((274576561872361193 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_556 : RB (Real.log ((225423438127638807 : ℝ) / 500000000000000000)) ((-99578439703483523 : ℝ) / 125000000000000000) ((-398313758813934091 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((225423438127638807 : ℝ) / 250000000000000000)) (t := ((-24576561872361193 : ℝ) / 475423438127638807))
    (lo := ((-51740168533961437 : ℝ) / 500000000000000000)) (hi := ((-103480337067922873 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((225423438127638807 : ℝ) / 500000000000000000) = Real.log ((225423438127638807 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((225423438127638807 : ℝ) / 500000000000000000) = ((225423438127638807 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_557 : RB (Real.log ((456662351066401301 : ℝ) / 1000000000000000000)) ((-391905499546144473 : ℝ) / 500000000000000000) ((-48988187443268059 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((456662351066401301 : ℝ) / 500000000000000000)) (t := ((-43337648933598699 : ℝ) / 956662351066401301))
    (lo := ((-22665954633085909 : ℝ) / 250000000000000000)) (hi := ((-18132763706468727 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((456662351066401301 : ℝ) / 1000000000000000000) = Real.log ((456662351066401301 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((456662351066401301 : ℝ) / 1000000000000000000) = ((456662351066401301 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_558 : RB (Real.log ((225010156877638807 : ℝ) / 500000000000000000)) ((-99807819444778977 : ℝ) / 125000000000000000) ((-399231277779115907 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((225010156877638807 : ℝ) / 250000000000000000)) (t := ((-24989843122361193 : ℝ) / 475010156877638807))
    (lo := ((-52657687499143253 : ℝ) / 500000000000000000)) (hi := ((-21063074999657301 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((225010156877638807 : ℝ) / 500000000000000000) = Real.log ((225010156877638807 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((225010156877638807 : ℝ) / 500000000000000000) = ((225010156877638807 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_559 : RB (Real.log ((90004062751055523 : ℝ) / 200000000000000000)) ((-399231277779115907 : ℝ) / 500000000000000000) ((-199615638889557953 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((90004062751055523 : ℝ) / 100000000000000000)) (t := ((-9995937248944477 : ℝ) / 190004062751055523))
    (lo := ((-13164421874785813 : ℝ) / 125000000000000000)) (hi := ((-105315374998286503 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((90004062751055523 : ℝ) / 200000000000000000) = Real.log ((90004062751055523 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((90004062751055523 : ℝ) / 200000000000000000) = ((90004062751055523 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
