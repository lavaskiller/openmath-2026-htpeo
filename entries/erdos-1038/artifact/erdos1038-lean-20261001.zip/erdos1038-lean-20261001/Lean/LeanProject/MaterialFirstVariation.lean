import LeanProject.ActualMaterialDerivative
import LeanProject.PrincipalValue
import LeanProject.AtomicAdjointEquality

/-! The original material derivative/PV statement and the exact jump adjoint identity.

The function `g` is the existing independently defined spatial material expression.
Its interpretation as the derivative of `WS(T_s, T_s(u))`, and as both raw principal
values, is proved at every interior root-block point and almost everywhere.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset

namespace EP1038.Stage11
open EP1038.Arc AngleReference

theorem jump_eventually_constant {z θ : ℝ} (hne : cos θ ≠ z) :
    ∀ᶠ φ in 𝓝 θ, jump z φ = jump z θ := by
  rcases lt_or_gt_of_ne hne with hl | hr
  · have he : ∀ᶠ φ in 𝓝 θ, cos φ < z :=
      Real.continuous_cos.continuousAt.eventually (Iio_mem_nhds hl)
    filter_upwards [he] with φ hφ
    simp only [jump, if_pos hφ, if_pos hl]
  · have he : ∀ᶠ φ in 𝓝 θ, z < cos φ :=
      Real.continuous_cos.continuousAt.eventually (Ioi_mem_nhds hr)
    filter_upwards [he] with φ hφ
    simp only [jump, if_neg (not_lt.mpr hφ.le), if_neg (not_lt.mpr hr.le)]

theorem stepPosition_eventually_constant {ι : Type*} (s : Finset ι) (d0 : ℝ)
    (δ z : ι → ℝ) {θ : ℝ} (hne : ∀ i ∈ s, cos θ ≠ z i) :
    ∀ᶠ φ in 𝓝 θ, stepPosition s d0 δ z φ = stepPosition s d0 δ z θ := by
  have hj : ∀ᶠ φ in 𝓝 θ, ∀ i ∈ s, jump (z i) φ = jump (z i) θ :=
    (Filter.eventually_all_finset s).mpr (fun i hi => jump_eventually_constant (hne i hi))
  filter_upwards [hj] with φ hφ
  unfold stepPosition
  congr 1
  apply Finset.sum_congr rfl
  intro i hi
  rw [hφ i hi]

theorem residual_velocity_measurable {n : ℕ} (R : SeparatedReference)
    (a : EP1038.NormalForm.NormalData n) (hres : 0 < a.residualCount) :
    Measurable (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) := by
  have hd := R.angles.angularDrift_measurable R.c R.r
    (EP1038.NormalForm.measurable_residualQuantile a hres)
  have hα := (alpha_cont R.angles.k R.angles.ρ R.angles.rho_pos.le R.angles.rho_lt_one).measurable
  convert hα.mul hd using 1
  funext φ
  rfl

end EP1038.Stage11

namespace EP1038.Stage12
open EP1038.Arc EP1038.Stage11 EP1038.NormalForm NormalData AngleReference

theorem residual_block_first_variation {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) {v θ : ℝ}
    (hθ : θ ∈ interior (blockSet R.angles a hres v))
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    HasDerivAt (fun s => Stage10.WS R.angles.k
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s)
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s (R.angles.cdf θ)))
      (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ) 0 ∧
    Tendsto (fun ε => angularPVTrunc
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) θ ε / R.r)
      (𝓝[>] (0 : ℝ)) (𝓝 (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ)) ∧
    Tendsto (spatialPVTrunc R.c R.r
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) (position R.c R.r θ))
      (𝓝[>] (0 : ℝ)) (𝓝 (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ)) := by
  have hi : θ ∈ Ioo (0 : ℝ) π := by
    have hh := (interior_mono (inter_subset_left : blockSet R.angles a hres v ⊆ Icc 0 π)) hθ
    simpa only [interior_Icc] using hh
  have hfi := residual_block_velocity_dq_integrable R a hres hθ
  have heq := residual_block_material_eq_HT R a hres hθ hzero
  refine ⟨residual_block_WS_derivative R a hres hθ hzero, ?_, ?_⟩
  · rw [heq]
    exact (tendsto_angularPVTrunc hi hfi).div_const R.r
  · rw [heq]
    exact tendsto_spatialPVTrunc R.radius_pos (residual_velocity_measurable R a hres) hi hfi

/-- Only a finite set of quantile cuts and the interval endpoints are excluded. -/
theorem ae_residual_block_interior {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) :
    ∀ᵐ θ ∂angleMeasure, ∃ v ∈ a.residualValues, θ ∈ interior (blockSet R.angles a hres v) := by
  have hn := sorted_length_pos a hres
  have hj : ∀ᵐ θ ∂angleMeasure, ∀ i ∈ range (a.sortedLocations.length - 1),
      cos θ ≠ R.angles.threshold a.sortedLocations.length i :=
    (Filter.eventually_all_finset _).mpr (fun i hi => ae_cos_ne_interior _
      (R.angles.threshold_interior hn hi))
  filter_upwards [hj, ae_restrict_mem measurableSet_Ioc,
    ae_restrict_of_ae (EP1038.Stage9.ae_ne_real π)] with θ hcuts hθ hneπ
  have hi : θ ∈ Ioo (0 : ℝ) π := ⟨hθ.1, lt_of_le_of_ne hθ.2 hneπ⟩
  have he : ∀ᶠ φ in 𝓝 θ,
      R.angles.angularTarget (a.residualQuantile hres) φ =
        R.angles.angularTarget (a.residualQuantile hres) θ := by
    change ∀ᶠ φ in 𝓝 θ,
      R.angles.angularTarget (EP1038.AtomicQuantile.step hn a.orderedAtoms) φ =
        R.angles.angularTarget (EP1038.AtomicQuantile.step hn a.orderedAtoms) θ
    rw [R.angles.angularTarget_step hn a.orderedAtoms]
    exact stepPosition_eventually_constant _ _ _ _ hcuts
  obtain ⟨v, hv, hvθ⟩ := residualQuantile_original a hres (R.angles.cdf (foldedAngle θ))
  refine ⟨v, hv, mem_interior_iff_mem_nhds.mpr ?_⟩
  have hiv : ∀ᶠ φ in 𝓝 θ, φ ∈ Icc (0 : ℝ) π := Icc_mem_nhds hi.1 hi.2
  filter_upwards [he, hiv] with φ hφ hm
  exact ⟨hm, hφ.trans hvθ⟩

/-- The derivative and both PV conventions hold almost everywhere for the actual normal form. -/
theorem residual_material_first_variation_ae {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    ∀ᵐ θ ∂angleMeasure,
    HasDerivAt (fun s => Stage10.WS R.angles.k
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s)
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s (R.angles.cdf θ)))
      (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ) 0 ∧
    Tendsto (fun ε => angularPVTrunc
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) θ ε / R.r)
      (𝓝[>] (0 : ℝ)) (𝓝 (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ)) ∧
    Tendsto (spatialPVTrunc R.c R.r
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) (position R.c R.r θ))
      (𝓝[>] (0 : ℝ)) (𝓝 (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ)) := by
  filter_upwards [ae_residual_block_interior R a hres] with θ hθ
  obtain ⟨v, _, hi⟩ := hθ
  exact residual_block_first_variation R a hres hi hzero

/-- Block interiors cover almost every spatial point for any angular density `B`. -/
theorem ae_spatial_residual_block_interior {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) (B : ℝ → ℝ) :
    ∀ᵐ d ∂spatialAdjointMeasure R.c R.r B,
      position R.c R.r (physicalAngle R.c R.r d) = d ∧
        ∃ v ∈ a.residualValues, physicalAngle R.c R.r d ∈ interior (blockSet R.angles a hres v) := by
  let G : Set ℝ := ⋃ v ∈ a.residualValues, interior (blockSet R.angles a hres v)
  have hG : MeasurableSet G := by
    exact (isOpen_iUnion (fun v => isOpen_iUnion (fun _ =>
      isOpen_interior (s := blockSet R.angles a hres v)))).measurableSet
  have hpa : Continuous (physicalAngle R.c R.r) := by unfold physicalAngle; fun_prop
  have hpos : Continuous (position R.c R.r) := by unfold position; fun_prop
  have hset : MeasurableSet {d : ℝ |
      position R.c R.r (physicalAngle R.c R.r d) = d ∧ physicalAngle R.c R.r d ∈ G} :=
    (isClosed_eq (hpos.comp hpa) continuous_id).measurableSet.inter (hG.preimage hpa.measurable)
  have hh : ∀ᵐ d ∂spatialAdjointMeasure R.c R.r B,
      position R.c R.r (physicalAngle R.c R.r d) = d ∧ physicalAngle R.c R.r d ∈ G := by
    rw [spatialAdjointMeasure]
    apply (ae_map_iff hpos.measurable.aemeasurable hset).mpr
    have hbase : ∀ᵐ θ ∂angleMeasure, position R.c R.r (physicalAngle R.c R.r (position R.c R.r θ)) =
        position R.c R.r θ ∧ physicalAngle R.c R.r (position R.c R.r θ) ∈ G := by
      filter_upwards [ae_residual_block_interior R a hres,
        ae_restrict_mem measurableSet_Ioc] with θ hθ hi
      rw [physicalAngle_position R.radius_pos ⟨hi.1.le, hi.2⟩]
      refine ⟨rfl, ?_⟩
      simpa only [G, mem_iUnion, exists_prop] using hθ
    exact hbase.filter_mono (withDensity_absolutelyContinuous angleMeasure
      (fun θ => ENNReal.ofReal (B θ / π))).ae_le
  filter_upwards [hh] with d hd
  exact ⟨hd.1, by simpa only [G, mem_iUnion, exists_prop] using hd.2⟩

/-- The actual spatial `g` is the moving-potential derivative and both raw PV limits
almost everywhere with respect to the actual adjoint measure `dξ`. -/
theorem residual_spatial_first_variation_ae {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) (B : ℝ → ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    ∀ᵐ d ∂spatialAdjointMeasure R.c R.r B,
    HasDerivAt (fun s => Stage10.WS R.angles.k
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s)
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s
        (R.angles.cdf (physicalAngle R.c R.r d))))
      (R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d) 0 ∧
    Tendsto (fun ε => angularPVTrunc
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) (physicalAngle R.c R.r d) ε / R.r)
      (𝓝[>] (0 : ℝ)) (𝓝 (R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d)) ∧
    Tendsto (spatialPVTrunc R.c R.r
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) d)
      (𝓝[>] (0 : ℝ)) (𝓝 (R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d)) := by
  filter_upwards [ae_spatial_residual_block_interior R a hres B] with d hd
  obtain ⟨v, _, hθ⟩ := hd.2
  have hh := residual_block_first_variation R a hres hθ hzero
  rw [hd.1] at hh
  exact hh

end EP1038.Stage12

namespace EP1038.Stage11.SeparatedReference
open EP1038.Arc EP1038.Stage11 EP1038.NormalForm EP1038.AtomicQuantile AngleReference

/-- Original exact adjoint equality, with `g` now certified as the actual first variation/PV. -/
theorem original_jump_adjoint_identity {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    Integrable (R.angles.spatialMaterial R.c R.r (a.residualQuantile hres))
      (spatialAdjointMeasure R.c R.r (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)) ∧
    Stage10.Mdot R.angles.k R.quantile (a.residualQuantile hres) -
      (∫ d, R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d
        ∂spatialAdjointMeasure R.c R.r (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)) =
      -Gam R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus *
        alpha R.angles.k R.angles.ρ π *
          (entry (sorted_length_pos a hres) a.orderedAtoms (a.sortedLocations.length - 1) - 2) :=
  ⟨(R.residual_material_dictionary a hres hzero).1, R.residual_exact_material_adjoint a hres hzero⟩

end EP1038.Stage11.SeparatedReference
