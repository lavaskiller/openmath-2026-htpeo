import LeanProject.Stage9A

/-!
# EP-1038, Stage 9, Lemma 9.2(iv), (v): the shape of `G_A` and the roots `p±`

With `p = 1/u` (so `p ∈ (q, 1) ↔ u ∈ (1, 1/q)` and `p ∈ (0, q) ↔ u > 1/q`),
`G_A(p) = F_A(1/p) = A log((1 - qp)/|p - q|) + log p`. For `0 < A < s = (1-q)/(1+q)`:
* on `(q, 1)`: `G_A' = -Q(p)/(p(1 - qp)(p - q))` with `Q(p) = qp² - Bp + q`,
  `B = 1 + q² - A(1 - q²)`; `Q > 0` on `(q, r₁)` and `Q < 0` on `(r₁, 1)`, where `q < r₁ < 1`. So `G_A`
  decreases from `+∞` to a negative minimum and increases to `G_A(1) = 0`.
* on `(0, q)`: `G_A' > 0`, and `G_A` increases from `-∞` to `+∞`.
* `exists_pplus`, `exists_pminus` (**Lemma 9.2(v)**): for `C ≥ 0` there are unique `p₊ ∈ (q, 1)` and
  `p₋ ∈ (0, q)` with `G_A(p±) = C`, and `{G_A > C} ∩ (q, 1) = (q, p₊)`, `{G_A > C} ∩ (0, q) = (p₋, q)`.
-/

open Real Set Filter Topology

namespace EP1038.Stage9

open Arc

/-- `B = 1 + q² - A(1 - q²)`. -/
noncomputable def BA (A q : ℝ) : ℝ := 1 + q ^ 2 - A * (1 - q ^ 2)

/-- `Q(p) = qp² - Bp + q`. -/
noncomputable def Qf (A q p : ℝ) : ℝ := q * p ^ 2 - BA A q * p + q

/-- The smaller root `r₁ = (B - √(B² - 4q²))/(2q)` of `Q`. -/
noncomputable def r1 (A q : ℝ) : ℝ := (BA A q - √(BA A q ^ 2 - 4 * q ^ 2)) / (2 * q)

section shape

variable {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A) (hAs : A * (1 + q) < 1 - q)
include hq hq1 hA0 hAs

theorem two_q_lt_B : 2 * q < BA A q := by
  unfold BA
  nlinarith

theorem A_lt_one : A < 1 := by nlinarith

theorem r1_lt_one : r1 A q < 1 := by
  have hB := two_q_lt_B hq hq1 hA0 hAs
  have hlt : BA A q - 2 * q < √(BA A q ^ 2 - 4 * q ^ 2) := by
    rw [Real.lt_sqrt (by linarith)]
    nlinarith
  unfold r1
  rw [div_lt_one (by linarith)]
  linarith

theorem q_lt_r1 : q < r1 A q := by
  have hA1 := A_lt_one hq hq1 hA0 hAs
  have hpos : 0 < BA A q - 2 * q ^ 2 := by
    unfold BA; nlinarith [mul_pos (sub_pos.mpr hA1) (show 0 < 1 - q ^ 2 by nlinarith)]
  have hlt : √(BA A q ^ 2 - 4 * q ^ 2) < BA A q - 2 * q ^ 2 := by
    rw [Real.sqrt_lt' hpos]
    have : BA A q < 1 + q ^ 2 := by unfold BA; nlinarith [mul_pos hA0 (show 0 < 1 - q ^ 2 by nlinarith)]
    nlinarith [mul_pos (show 0 < q ^ 2 by positivity) (show 0 < 1 + q ^ 2 - BA A q by linarith)]
  unfold r1
  rw [lt_div_iff₀ (by linarith)]
  linarith

theorem Qf_r1 : Qf A q (r1 A q) = 0 := by
  have hB := two_q_lt_B hq hq1 hA0 hAs
  have hΔ : 0 ≤ BA A q ^ 2 - 4 * q ^ 2 := by nlinarith
  have hsq := Real.sq_sqrt hΔ
  have e : Qf A q (r1 A q) = (√(BA A q ^ 2 - 4 * q ^ 2) ^ 2 - (BA A q ^ 2 - 4 * q ^ 2)) / (4 * q) := by
    unfold Qf r1
    have := hq.ne'
    field_simp
    ring
  rw [e, hsq, sub_self, zero_div]

/-- On `(q, 1)`: `Q(p) > 0 ↔ p < r₁`. -/
theorem Qf_pos_iff {p : ℝ} (hp1 : p < 1) : 0 < Qf A q p ↔ p < r1 A q := by
  have hB := two_q_lt_B hq hq1 hA0 hAs
  have hr1 := r1_lt_one hq hq1 hA0 hAs
  have hdiff : Qf A q p = (p - r1 A q) * (q * (p + r1 A q) - BA A q) := by
    have h0 := Qf_r1 hq hq1 hA0 hAs
    unfold Qf at h0 ⊢
    linear_combination h0
  have hneg : q * (p + r1 A q) - BA A q < 0 := by nlinarith
  rw [hdiff]
  constructor
  · intro h
    by_contra hc
    push Not at hc
    have : 0 ≤ p - r1 A q := by linarith
    nlinarith
  · intro h
    exact mul_pos_of_neg_of_neg (by linarith) hneg

/-- `G_A` on `(q, 1)` in split form. -/
noncomputable def Gr (A q p : ℝ) : ℝ := A * (Real.log (1 - q * p) - Real.log (p - q)) + Real.log p

omit hA0 hAs in
theorem GA_eq_Gr {p : ℝ} (hqp : q < p) (hp1 : p < 1) : GA A q p = Gr A q p := by
  have h1 : 0 < 1 - q * p := by nlinarith
  unfold GA Gr
  rw [abs_of_pos (by linarith), Real.log_div h1.ne' (by linarith)]

omit hA0 hAs in
theorem hasDerivAt_Gr {p : ℝ} (hqp : q < p) (hp1 : p ≤ 1) :
    HasDerivAt (Gr A q) (A * (-q / (1 - q * p) - 1 / (p - q)) + 1 / p) p := by
  have h1 : 0 < 1 - q * p := by nlinarith
  have hp0 : 0 < p := by linarith
  have d1 : HasDerivAt (fun x => 1 - q * x) (-q) p := by
    simpa using ((hasDerivAt_id p).const_mul q).const_sub 1
  have d2 : HasDerivAt (fun x => x - q) 1 p := by simpa using (hasDerivAt_id p).sub_const q
  have := ((d1.log h1.ne').sub (d2.log (by linarith))).const_mul A |>.add (Real.hasDerivAt_log hp0.ne')
  convert this using 1
  · funext x; simp only [Gr, Pi.add_apply, Pi.sub_apply]
  · simp only [one_div]

omit hA0 hAs in
theorem deriv_Gr_eq {p : ℝ} (hqp : q < p) (hp1 : p < 1) :
    A * (-q / (1 - q * p) - 1 / (p - q)) + 1 / p = -Qf A q p / (p * (1 - q * p) * (p - q)) := by
  have h1 : 0 < 1 - q * p := by nlinarith
  have hp0 : 0 < p := by linarith
  have h2 : 0 < p - q := by linarith
  unfold Qf BA
  field_simp
  ring

/-- `G_A` is strictly decreasing on `(q, r₁]`. -/
theorem Gr_anti : StrictAntiOn (Gr A q) (Ioc q (r1 A q)) := by
  have hr1 := r1_lt_one hq hq1 hA0 hAs
  refine strictAntiOn_of_deriv_neg (convex_Ioc _ _) ?_ ?_
  · intro p hp
    have hqp := hp.1
    have hp1 : p < 1 := by linarith [hp.2]
    exact (hasDerivAt_Gr hq hq1 hqp hp1.le).continuousAt.continuousWithinAt
  · intro p hp
    rw [interior_Ioc] at hp
    have hp1 : p < 1 := by linarith [hp.2]
    rw [(hasDerivAt_Gr hq hq1 hp.1 hp1.le).deriv, deriv_Gr_eq hq hq1 hp.1 hp1]
    have hQ := (Qf_pos_iff hq hq1 hA0 hAs hp1).mpr hp.2
    have h1 : 0 < 1 - q * p := by nlinarith
    have : 0 < p * (1 - q * p) * (p - q) :=
      mul_pos (mul_pos (by linarith [hp.1]) h1) (by linarith [hp.1])
    exact div_neg_of_neg_of_pos (by linarith) this

/-- `G_A` is strictly increasing on `[r₁, 1]`. -/
theorem Gr_mono : StrictMonoOn (Gr A q) (Icc (r1 A q) 1) := by
  have hqr := q_lt_r1 hq hq1 hA0 hAs
  refine strictMonoOn_of_deriv_pos (convex_Icc _ _) ?_ ?_
  · intro p hp
    have hqp : q < p := by linarith [hp.1]
    exact (hasDerivAt_Gr hq hq1 hqp hp.2).continuousAt.continuousWithinAt
  · intro p hp
    rw [interior_Icc] at hp
    have hqp : q < p := by linarith [hp.1]
    rw [(hasDerivAt_Gr hq hq1 hqp hp.2.le).deriv, deriv_Gr_eq hq hq1 hqp hp.2]
    have hQ : Qf A q p < 0 := by
      by_contra hc
      push Not at hc
      rcases hc.lt_or_eq with h | h
      · exact absurd ((Qf_pos_iff hq hq1 hA0 hAs hp.2).mp h) (not_lt.mpr hp.1.le)
      · have e : Qf A q p = Qf A q (r1 A q) := by rw [← h, Qf_r1 hq hq1 hA0 hAs]
        have hB := two_q_lt_B hq hq1 hA0 hAs
        have hr1 := r1_lt_one hq hq1 hA0 hAs
        have hdiff : Qf A q p - Qf A q (r1 A q) = (p - r1 A q) * (q * (p + r1 A q) - BA A q) := by
          unfold Qf; ring
        have hqp2 : q * (p + r1 A q) < q * 2 := mul_lt_mul_of_pos_left (by linarith [hp.2]) hq
        have hneg : q * (p + r1 A q) - BA A q < 0 := by linarith
        have : (p - r1 A q) * (q * (p + r1 A q) - BA A q) < 0 :=
          mul_neg_of_pos_of_neg (by linarith [hp.1]) hneg
        linarith
    have h1 : 0 < 1 - q * p := by nlinarith [hp.2]
    have : 0 < p * (1 - q * p) * (p - q) := mul_pos (mul_pos (by linarith) h1) (by linarith)
    exact div_pos (by linarith) this

theorem Gr_one : Gr A q 1 = 0 := by
  unfold Gr
  rw [mul_one, show 1 - q = 1 - q by rfl, sub_self, mul_zero, Real.log_one, add_zero]

/-- `G_A < 0` on `[r₁, 1)`. -/
theorem Gr_neg {p : ℝ} (hp : r1 A q ≤ p) (hp1 : p < 1) : Gr A q p < 0 := by
  have h := Gr_mono hq hq1 hA0 hAs ⟨hp, hp1.le⟩ ⟨(r1_lt_one hq hq1 hA0 hAs).le, le_rfl⟩ hp1
  rwa [Gr_one hq hq1 hA0 hAs] at h

omit hAs in
/-- `G_A → +∞` as `p ↓ q`. -/
theorem Gr_tendsto_top : Tendsto (Gr A q) (𝓝[>] q) atTop := by
  have h1 : Tendsto (fun p => p - q) (𝓝[>] q) (𝓝[>] 0) := by
    have hc : Tendsto (fun p => p - q) (𝓝 q) (𝓝 0) := by
      exact (by fun_prop : Continuous (fun p : ℝ => p - q)).tendsto' q 0 (by simp)
    refine tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within _ (hc.mono_left nhdsWithin_le_nhds) ?_
    filter_upwards [self_mem_nhdsWithin] with p hp
    exact sub_pos.mpr (Set.mem_Ioi.mp hp)
  have hlog : Tendsto (fun p => -Real.log (p - q)) (𝓝[>] q) atTop :=
    tendsto_neg_atBot_atTop.comp (Real.tendsto_log_nhdsGT_zero.comp h1)
  have hrest : Tendsto (fun p => A * Real.log (1 - q * p) + Real.log p) (𝓝[>] q)
      (𝓝 (A * Real.log (1 - q * q) + Real.log q)) := by
    have hc : ContinuousAt (fun p => A * Real.log (1 - q * p) + Real.log p) q := by
      have h1q : 0 < 1 - q * q := by nlinarith
      exact ((continuous_const.sub (continuous_const.mul continuous_id)).continuousAt.log
        h1q.ne').const_mul A |>.add (continuous_id.continuousAt.log hq.ne')
    exact hc.tendsto.mono_left nhdsWithin_le_nhds
  have := (hlog.const_mul_atTop hA0).atTop_add hrest
  refine this.congr' ?_
  filter_upwards with p
  unfold Gr
  ring

/-- **Lemma 9.2(v)** on `(q, 1)`: for `C ≥ 0` there is a unique `p₊ ∈ (q, 1)` with `G_A(p₊) = C`,
and `{p ∈ (q, 1) : G_A(p) > C} = (q, p₊)`. -/
theorem exists_pplus {C : ℝ} (hC : 0 ≤ C) :
    ∃ pp, q < pp ∧ pp < 1 ∧ GA A q pp = C ∧
      (∀ p, q < p → p < 1 → (C < GA A q p ↔ p < pp)) ∧
      (∀ p, q < p → p < 1 → (GA A q p < C ↔ pp < p)) := by
  have hqr := q_lt_r1 hq hq1 hA0 hAs
  have hr1 := r1_lt_one hq hq1 hA0 hAs
  -- a point near `q` with `G > C`
  obtain ⟨p1, hp1C, hp1I⟩ := ((Gr_tendsto_top hq hq1 hA0).eventually (eventually_gt_atTop C)).and
    (Ioo_mem_nhdsGT hqr) |>.exists
  have hr1neg := Gr_neg hq hq1 hA0 hAs le_rfl hr1
  have hcont : ContinuousOn (Gr A q) (Icc p1 (r1 A q)) := by
    intro p hp
    have hqp : q < p := lt_of_lt_of_le hp1I.1 hp.1
    exact (hasDerivAt_Gr hq hq1 hqp (by linarith [hp.2])).continuousAt.continuousWithinAt
  obtain ⟨pp, hppI, hppC⟩ := intermediate_value_Icc' hp1I.2.le hcont ⟨by linarith, hp1C.le⟩
  have hqpp : q < pp := lt_of_lt_of_le hp1I.1 hppI.1
  have hpp1 : pp < 1 := lt_of_le_of_lt hppI.2 hr1
  refine ⟨pp, hqpp, hpp1, by rw [GA_eq_Gr hq hq1 hqpp hpp1]; exact hppC, fun p hqp hp1 => ?_,
    fun p hqp hp1 => ?_⟩
  swap
  · rw [GA_eq_Gr hq hq1 hqp hp1]
    constructor
    · intro h
      by_contra hc
      push Not at hc
      rcases hc.lt_or_eq with h' | h'
      · have := Gr_anti hq hq1 hA0 hAs ⟨hqp, by linarith [hppI.2]⟩ ⟨hqpp, hppI.2⟩ h'
        linarith
      · rw [h'] at h
        linarith
    · intro h
      rcases le_or_gt p (r1 A q) with hpr | hpr
      · have := Gr_anti hq hq1 hA0 hAs ⟨hqpp, hppI.2⟩ ⟨hqp, hpr⟩ h
        linarith
      · have := Gr_neg hq hq1 hA0 hAs hpr.le hp1
        linarith
  rw [GA_eq_Gr hq hq1 hqp hp1]
  constructor
  · intro h
    by_contra hc
    push Not at hc
    rcases le_or_gt p (r1 A q) with hpr | hpr
    · have := (Gr_anti hq hq1 hA0 hAs).antitoneOn ⟨hqpp, hppI.2⟩ ⟨hqp, hpr⟩ hc
      linarith
    · have := Gr_neg hq hq1 hA0 hAs hpr.le hp1
      linarith
  · intro h
    have := Gr_anti hq hq1 hA0 hAs ⟨hqp, by linarith [hppI.2]⟩ ⟨hqpp, hppI.2⟩ h
    linarith

/-- `G_A` on `(0, q)` in split form. -/
noncomputable def Gl (A q p : ℝ) : ℝ := A * (Real.log (1 - q * p) - Real.log (q - p)) + Real.log p

omit hA0 hAs in
theorem GA_eq_Gl {p : ℝ} (hp0 : 0 < p) (hpq : p < q) : GA A q p = Gl A q p := by
  have h1 : 0 < 1 - q * p := by nlinarith
  unfold GA Gl
  rw [abs_of_neg (by linarith), neg_sub, Real.log_div h1.ne' (by linarith)]

omit hA0 hAs in
theorem hasDerivAt_Gl {p : ℝ} (hp0 : 0 < p) (hpq : p < q) :
    HasDerivAt (Gl A q) (A * (-q / (1 - q * p) + 1 / (q - p)) + 1 / p) p := by
  have h1 : 0 < 1 - q * p := by nlinarith
  have d1 : HasDerivAt (fun x => 1 - q * x) (-q) p := by
    simpa using ((hasDerivAt_id p).const_mul q).const_sub 1
  have d2 : HasDerivAt (fun x => q - x) (-1) p := by simpa using (hasDerivAt_id p).const_sub q
  have := ((d1.log h1.ne').sub (d2.log (by linarith))).const_mul A |>.add (Real.hasDerivAt_log hp0.ne')
  convert this using 1
  · funext x; simp only [Gl, Pi.add_apply, Pi.sub_apply]
  · simp only [one_div]; ring

/-- `G_A` is strictly increasing on `(0, q)`. -/
theorem Gl_mono : StrictMonoOn (Gl A q) (Ioo 0 q) := by
  refine strictMonoOn_of_deriv_pos (convex_Ioo _ _) ?_ ?_
  · intro p hp
    exact (hasDerivAt_Gl hq hq1 hp.1 hp.2).continuousAt.continuousWithinAt
  · intro p hp
    rw [interior_Ioo] at hp
    rw [(hasDerivAt_Gl hq hq1 hp.1 hp.2).deriv]
    have h1 : 0 < 1 - q * p := by nlinarith [hp.2]
    have h2 : 0 < q - p := by linarith [hp.2]
    have key : -q / (1 - q * p) + 1 / (q - p) = (1 - q ^ 2) / ((1 - q * p) * (q - p)) := by
      field_simp; ring
    rw [key]
    have : 0 < (1 - q ^ 2) / ((1 - q * p) * (q - p)) := div_pos (by nlinarith) (by positivity)
    have : 0 < 1 / p := by have := hp.1; positivity
    positivity

omit hAs in
theorem Gl_tendsto_bot : Tendsto (Gl A q) (𝓝[>] 0) atBot := by
  have hrest : Tendsto (fun p => A * (Real.log (1 - q * p) - Real.log (q - p))) (𝓝[>] 0)
      (𝓝 (A * (Real.log (1 - q * 0) - Real.log (q - 0)))) := by
    have hc : ContinuousAt (fun p => A * (Real.log (1 - q * p) - Real.log (q - p))) 0 := by
      refine ContinuousAt.const_mul ?_ A
      exact ((continuous_const.sub (continuous_const.mul continuous_id)).continuousAt.log
        (by simp)).sub ((continuous_const.sub continuous_id).continuousAt.log (by simp; exact hq.ne'))
    exact hc.tendsto.mono_left nhdsWithin_le_nhds
  have := hrest.add_atBot Real.tendsto_log_nhdsGT_zero
  exact this.congr' (Eventually.of_forall fun p => by unfold Gl; ring)

omit hAs in
theorem Gl_tendsto_top : Tendsto (Gl A q) (𝓝[<] q) atTop := by
  have h1 : Tendsto (fun p => q - p) (𝓝[<] q) (𝓝[>] 0) := by
    have hc : Tendsto (fun p => q - p) (𝓝 q) (𝓝 0) := by
      exact (by fun_prop : Continuous (fun p : ℝ => q - p)).tendsto' q 0 (by simp)
    refine tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within _ (hc.mono_left nhdsWithin_le_nhds) ?_
    filter_upwards [self_mem_nhdsWithin] with p hp
    exact sub_pos.mpr (Set.mem_Iio.mp hp)
  have hlog : Tendsto (fun p => -Real.log (q - p)) (𝓝[<] q) atTop :=
    tendsto_neg_atBot_atTop.comp (Real.tendsto_log_nhdsGT_zero.comp h1)
  have hrest : Tendsto (fun p => A * Real.log (1 - q * p) + Real.log p) (𝓝[<] q)
      (𝓝 (A * Real.log (1 - q * q) + Real.log q)) := by
    have hc : ContinuousAt (fun p => A * Real.log (1 - q * p) + Real.log p) q := by
      have h1q : 0 < 1 - q * q := by nlinarith
      exact ((continuous_const.sub (continuous_const.mul continuous_id)).continuousAt.log
        h1q.ne').const_mul A |>.add (continuous_id.continuousAt.log hq.ne')
    exact hc.tendsto.mono_left nhdsWithin_le_nhds
  have := (hlog.const_mul_atTop hA0).atTop_add hrest
  refine this.congr' ?_
  filter_upwards with p
  unfold Gl
  ring

/-- **Lemma 9.2(v)** on `(0, q)`: there is a unique `p₋ ∈ (0, q)` with `G_A(p₋) = C`, and
`{p ∈ (0, q) : G_A(p) > C} = (p₋, q)`. -/
theorem exists_pminus (C : ℝ) :
    ∃ pm, 0 < pm ∧ pm < q ∧ GA A q pm = C ∧
      (∀ p, 0 < p → p < q → (C < GA A q p ↔ pm < p)) ∧
      (∀ p, 0 < p → p < q → (GA A q p < C ↔ p < pm)) := by
  obtain ⟨p1, hp1C, hp1I⟩ := ((Gl_tendsto_bot hq hq1 hA0).eventually (eventually_lt_atBot C)).and
    (Ioo_mem_nhdsGT hq) |>.exists
  obtain ⟨p2, hp2C, hp2I⟩ := ((Gl_tendsto_top hq hq1 hA0).eventually (eventually_gt_atTop C)).and
    (Ioo_mem_nhdsLT hp1I.2) |>.exists
  have hcont : ContinuousOn (Gl A q) (Icc p1 p2) := by
    intro p hp
    exact (hasDerivAt_Gl hq hq1 (by linarith [hp1I.1, hp.1]) (by linarith [hp.2, hp2I.2])).continuousAt.continuousWithinAt
  obtain ⟨pm, hpmI, hpmC⟩ := intermediate_value_Icc hp2I.1.le hcont ⟨hp1C.le, hp2C.le⟩
  have hpm0 : 0 < pm := lt_of_lt_of_le hp1I.1 hpmI.1
  have hpmq : pm < q := lt_of_le_of_lt hpmI.2 hp2I.2
  refine ⟨pm, hpm0, hpmq, by rw [GA_eq_Gl hq hq1 hpm0 hpmq]; exact hpmC, fun p hp0 hpq => ?_,
    fun p hp0 hpq => ?_⟩
  · rw [GA_eq_Gl hq hq1 hp0 hpq, ← hpmC]
    exact (Gl_mono hq hq1 hA0 hAs).lt_iff_lt ⟨hpm0, hpmq⟩ ⟨hp0, hpq⟩
  · rw [GA_eq_Gl hq hq1 hp0 hpq, ← hpmC]
    exact (Gl_mono hq hq1 hA0 hAs).lt_iff_lt ⟨hp0, hpq⟩ ⟨hpm0, hpmq⟩

end shape

/-! ### The three `y`-regions are exhausted by `xoff`, `dth`, `yR` -/

theorem exists_p_of_gt_two {t : ℝ} (ht : 2 < t) : ∃ p, 0 < p ∧ p < 1 ∧ p + 1 / p = t := by
  have hΔ : 0 ≤ t ^ 2 - 4 := by nlinarith
  have hs := Real.sq_sqrt hΔ
  have hlt : √(t ^ 2 - 4) < t := by
    rw [Real.sqrt_lt' (by linarith)]; nlinarith
  have hgt : t - 2 < √(t ^ 2 - 4) := by
    rw [Real.lt_sqrt (by linarith)]; nlinarith
  refine ⟨(t - √(t ^ 2 - 4)) / 2, by linarith, by linarith, ?_⟩
  have hp0 : 0 < (t - √(t ^ 2 - 4)) / 2 := by linarith
  have key : (t - √(t ^ 2 - 4)) / 2 * (t - (t - √(t ^ 2 - 4)) / 2) = 1 := by
    linear_combination (-1 / 4 : ℝ) * hs
  have : 1 / ((t - √(t ^ 2 - 4)) / 2) = t - (t - √(t ^ 2 - 4)) / 2 := by
    rw [div_eq_iff hp0.ne']
    linear_combination -key
  rw [this]
  ring

theorem two_lt_add_inv {p : ℝ} (hp0 : 0 < p) (hp1 : p < 1) : 2 < p + 1 / p := by
  have e : p + 1 / p - 2 = (1 - p) ^ 2 / p := by field_simp; ring
  have : 0 < (1 - p) ^ 2 / p := div_pos (by nlinarith) hp0
  linarith

theorem xoff_strictMonoOn {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) :
    StrictMonoOn (xoff D0 q) (Ioo 0 1) := by
  intro a ha b hb hab
  have h : b + 1 / b < a + 1 / a := by
    have e : (a + 1 / a) - (b + 1 / b) = (b - a) * (1 - a * b) / (a * b) := by
      have := ha.1.ne'; have := hb.1.ne'
      field_simp; ring
    have : 0 < (b - a) * (1 - a * b) / (a * b) :=
      div_pos (mul_pos (by linarith) (by nlinarith [ha.1, ha.2, hb.1, hb.2])) (mul_pos ha.1 hb.1)
    linarith
  have := mul_lt_mul_of_pos_left h (mul_pos hD hq)
  unfold xoff
  linarith

theorem xoff_lt {D0 q p : ℝ} (hD : 0 < D0) (hq : 0 < q) (hp0 : 0 < p) (hp1 : p < 1) :
    xoff D0 q p < D0 * (1 - q) ^ 2 := by
  have := mul_lt_mul_of_pos_left (two_lt_add_inv hp0 hp1) (mul_pos hD hq)
  unfold xoff
  nlinarith

theorem xoff_self {D0 q : ℝ} (hq : 0 < q) : xoff D0 q q = 0 := by
  rw [xoff_eq hq.ne']
  simp

theorem exists_xoff {D0 q y : ℝ} (hD : 0 < D0) (hq : 0 < q) (hy : y < D0 * (1 - q) ^ 2) :
    ∃ p, 0 < p ∧ p < 1 ∧ xoff D0 q p = y := by
  have hDq : 0 < D0 * q := mul_pos hD hq
  have ht : 2 < (D0 * (1 + q ^ 2) - y) / (D0 * q) := by
    rw [lt_div_iff₀ hDq]; nlinarith
  obtain ⟨p, hp0, hp1, hp⟩ := exists_p_of_gt_two ht
  refine ⟨p, hp0, hp1, ?_⟩
  unfold xoff
  rw [hp]
  field_simp
  ring

theorem exists_yR {D0 q y : ℝ} (hD : 0 < D0) (hq : 0 < q) (hy : D0 * (1 + q) ^ 2 < y) :
    ∃ p, 0 < p ∧ p < 1 ∧ yR D0 q p = y := by
  have hDq : 0 < D0 * q := mul_pos hD hq
  have ht : 2 < (y - D0 * (1 + q ^ 2)) / (D0 * q) := by
    rw [lt_div_iff₀ hDq]; nlinarith
  obtain ⟨p, hp0, hp1, hp⟩ := exists_p_of_gt_two ht
  refine ⟨p, hp0, hp1, ?_⟩
  unfold yR
  rw [hp]
  field_simp
  ring

theorem exists_dth {D0 q y : ℝ} (hD : 0 < D0) (hq : 0 < q) (hy1 : D0 * (1 - q) ^ 2 ≤ y)
    (hy2 : y ≤ D0 * (1 + q) ^ 2) : ∃ θ, dth D0 q θ = y := by
  have hDq : 0 < 2 * D0 * q := by positivity
  have c1 : -1 ≤ (D0 * (1 + q ^ 2) - y) / (2 * D0 * q) := by
    rw [le_div_iff₀ hDq]; nlinarith
  have c2 : (D0 * (1 + q ^ 2) - y) / (2 * D0 * q) ≤ 1 := by
    rw [div_le_iff₀ hDq]; nlinarith
  refine ⟨Real.arccos ((D0 * (1 + q ^ 2) - y) / (2 * D0 * q)), ?_⟩
  unfold dth
  rw [Real.cos_arccos c1 c2]
  field_simp
  ring

/-- **Lemma 9.2(v)**: for `0 < A < s` and `C(A) ≥ 0`, the sublevel set of `V_{μ_A}` is, up to the
point `y = 0`, the interval `(y(p₋), y(p₊))`; when `C(A) > 0`, the zero set of `V_{μ_A}` is contained
in `{0, y(p₋), y(p₊)}`. -/
theorem sublevel_VA {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A) (hAs : A * (1 + q) < 1 - q)
    (hC : 0 ≤ CA A q) :
    ∃ pm pp, 0 < pm ∧ pm < q ∧ q < pp ∧ pp < 1 ∧ GA A q pm = CA A q ∧ GA A q pp = CA A q ∧
      (∀ y, y ≠ 0 → (VA A q y < 0 ↔ xoff (D0q q) q pm < y ∧ y < xoff (D0q q) q pp)) ∧
      (0 < CA A q → ∀ y, y ≠ 0 → VA A q y = 0 → y = xoff (D0q q) q pm ∨ y = xoff (D0q q) q pp) := by
  obtain ⟨pp, hqpp, hpp1, hGpp, hpp, hpp'⟩ := exists_pplus hq hq1 hA0 hAs hC
  obtain ⟨pm, hpm0, hpmq, hGpm, hpm, hpm'⟩ := exists_pminus hq hq1 hA0 hAs (CA A q)
  have hD := D0q_pos q hq.le
  have hmono := xoff_strictMonoOn hD hq
  have hA1 : A ≤ 1 := (A_lt_one hq hq1 hA0 hAs).le
  refine ⟨pm, pp, hpm0, hpmq, hqpp, hpp1, hGpm, hGpp, fun y hy0 => ?_, fun hCp y hy0 hV => ?_⟩
  · rcases lt_or_ge y (D0q q * (1 - q) ^ 2) with hyl | hyl
    · obtain ⟨p, hp0, hp1, rfl⟩ := exists_xoff hD hq hyl
      have hpq : p ≠ q := by
        rintro rfl
        exact hy0 (xoff_self hq)
      rw [VA_left hq hq1 hp0 hp1 hpq, sub_neg]
      rcases lt_or_gt_of_ne hpq with h | h
      · rw [hpm p hp0 h, hmono.lt_iff_lt ⟨hpm0, by linarith⟩ ⟨hp0, hp1⟩]
        have : xoff (D0q q) q p < xoff (D0q q) q pp :=
          hmono ⟨hp0, hp1⟩ ⟨by linarith, hpp1⟩ (by linarith)
        tauto
      · rw [hpp p h hp1, hmono.lt_iff_lt ⟨hp0, hp1⟩ ⟨by linarith, hpp1⟩]
        have : xoff (D0q q) q pm < xoff (D0q q) q p :=
          hmono ⟨hpm0, by linarith⟩ ⟨hp0, hp1⟩ (by linarith)
        tauto
    · have hR : ¬ (y < xoff (D0q q) q pp) :=
        not_lt.mpr ((xoff_lt hD hq (by linarith) hpp1).le.trans hyl)
      simp only [hR, and_false, iff_false, not_lt]
      rcases le_or_gt y (D0q q * (1 + q) ^ 2) with hyr | hyr
      · obtain ⟨θ, rfl⟩ := exists_dth hD hq hyl hyr
        rw [VA_platform hq hq1]
        exact hC
      · obtain ⟨p, hp0, hp1, rfl⟩ := exists_yR hD hq hyr
        exact hC.trans (VA_right hA0.le hA1 hq hq1 hp0 hp1).le
  · rcases lt_or_ge y (D0q q * (1 - q) ^ 2) with hyl | hyl
    · obtain ⟨p, hp0, hp1, rfl⟩ := exists_xoff hD hq hyl
      have hpq : p ≠ q := by
        rintro rfl
        exact hy0 (xoff_self hq)
      rw [VA_left hq hq1 hp0 hp1 hpq, sub_eq_zero] at hV
      rcases lt_or_gt_of_ne hpq with h | h
      · rcases lt_trichotomy p pm with h' | h' | h'
        · have := (hpm' p hp0 h).mpr h'
          linarith
        · exact Or.inl (by rw [h'])
        · have := (hpm p hp0 h).mpr h'
          linarith
      · rcases lt_trichotomy p pp with h' | h' | h'
        · have := (hpp p h hp1).mpr h'
          linarith
        · exact Or.inr (by rw [h'])
        · have := (hpp' p h hp1).mpr h'
          linarith
    · rcases le_or_gt y (D0q q * (1 + q) ^ 2) with hyr | hyr
      · obtain ⟨θ, rfl⟩ := exists_dth hD hq hyl hyr
        rw [VA_platform hq hq1] at hV
        linarith
      · obtain ⟨p, hp0, hp1, rfl⟩ := exists_yR hD hq hyr
        have := VA_right hA0.le hA1 hq hq1 hp0 hp1
        linarith

open MeasureTheory in
/-- **Lemma 9.2(v)**, volume form: `|E_{μ_A}| = y(p₊) - y(p₋) = H(p₋ + 1/p₋ - p₊ - 1/p₊)`, and the zero set of
`V_{μ_A}` is null when `C(A) > 0`. -/
theorem volume_sublevel_VA {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A)
    (hAs : A * (1 + q) < 1 - q) (hC : 0 ≤ CA A q) :
    ∃ pm pp, 0 < pm ∧ pm < q ∧ q < pp ∧ pp < 1 ∧ GA A q pm = CA A q ∧ GA A q pp = CA A q ∧
      volume {y | VA A q y < 0} =
        ENNReal.ofReal (D0q q * q * (pm + 1 / pm - pp - 1 / pp)) ∧
      (0 < CA A q → volume {y | VA A q y = 0} = 0) := by
  obtain ⟨pm, pp, hpm0, hpmq, hqpp, hpp1, hGpm, hGpp, hE, hZ⟩ := sublevel_VA hq hq1 hA0 hAs hC
  refine ⟨pm, pp, hpm0, hpmq, hqpp, hpp1, hGpm, hGpp, ?_, fun hCp => ?_⟩
  · have hlen : xoff (D0q q) q pp - xoff (D0q q) q pm =
        D0q q * q * (pm + 1 / pm - pp - 1 / pp) := by
      unfold xoff; ring
    rw [← hlen]
    set a := xoff (D0q q) q pm
    set b := xoff (D0q q) q pp
    have hsub : {y | VA A q y < 0} ⊆ Ioo a b ∪ {0} := by
      intro y hy
      by_cases h : y = 0
      · exact Or.inr h
      · exact Or.inl ((hE y h).mp hy)
    have hsup : Ioo a b \ {0} ⊆ {y | VA A q y < 0} := fun y hy => (hE y hy.2).mpr hy.1
    apply le_antisymm
    · calc volume {y | VA A q y < 0} ≤ volume (Ioo a b ∪ {0}) := measure_mono hsub
        _ ≤ volume (Ioo a b) + volume ({0} : Set ℝ) := measure_union_le _ _
        _ = ENNReal.ofReal (b - a) := by rw [Real.volume_Ioo, measure_singleton, add_zero]
    · calc ENNReal.ofReal (b - a) = volume (Ioo a b \ {0}) := by
            rw [measure_sdiff_null (measure_singleton 0), Real.volume_Ioo]
        _ ≤ volume {y | VA A q y < 0} := measure_mono hsup
  · refine measure_mono_null (t := {0, xoff (D0q q) q pm, xoff (D0q q) q pp}) ?_
      ((Set.toFinite _).measure_zero _)
    intro y hy
    by_cases h : y = 0
    · exact Or.inl h
    · exact Or.inr (hZ hCp y h hy)

end EP1038.Stage9
