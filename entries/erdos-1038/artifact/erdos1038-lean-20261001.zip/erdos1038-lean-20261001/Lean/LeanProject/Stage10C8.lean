import LeanProject.Stage10C7

/-!
# EP-1038, Stage 10 Part (c), N5 + N6(iii): Lemma 10.11 and the chord inequality for the width series

Along `S_t = (1-t) S₀ + t S₁`:
* `LC_cS`: every coefficient `t ↦ c_n(S_t)` is log-convex (it is a nonnegative polynomial in the
  `μ_ℓ(S_t)`, built through `phiS` and the recursion `Pinv`);
* `LC_F`: `F_n(S_t) = c_n(S_t) R(S_t)ⁿ` is log-convex, hence convex (**Lemma 10.11**);
* `wser` = `Σ c_n (Rⁿ - (-R)ⁿ)` (the width series, `= 2 Σ_odd F_n`);
* `wser_chord` (**N6(iii)**): `wser(S_s) ≤ (1-s) wser(S₀) + s wser(S₁)` for `s ∈ [0,1]` whenever the
  two end series converge; `wser_slope`: `(wser(S_s) - wser(S₀))/s ≤ wser(S₁) - wser(S₀)`.
-/

open Real Set Filter Topology PowerSeries Finset MeasureTheory

namespace EP1038.Stage10

/-- The width series `Σ c_n (Rⁿ - (-R)ⁿ)`. -/
noncomputable def wser (k : ℝ) (S : ℝ → ℝ) : ℝ :=
  ∑' n, coeff n (cS k S) * (RS k S ^ n - (-RS k S) ^ n)

theorem Seg_zero (S0 S1 : ℝ → ℝ) : Seg S0 S1 0 = S0 := by funext u; simp [Seg]
theorem Seg_one (S0 S1 : ℝ → ℝ) : Seg S0 S1 1 = S1 := by funext u; simp [Seg]

/-- Coefficients of powers of a family with LC coefficients are LC. -/
theorem LC_coeff_pow {A : ℝ → PowerSeries ℝ} (h : ∀ n, LCOn fun t => coeff n (A t)) :
    ∀ j n, LCOn fun t => coeff n (A t ^ j)
  | 0, n => by
    simp only [pow_zero, coeff_one]
    split_ifs
    · exact LCOn_const zero_le_one
    · exact LCOn_const le_rfl
  | j + 1, n => by
    simp only [pow_succ, coeff_mul]
    exact LCOn_sum _ fun kl _ => (LC_coeff_pow h j kl.1).mul (h kl.2)

/-- Coefficients of `Pinv` are LC when the `φ_j` are. -/
theorem LC_Pinv {φ : ℝ → ℕ → ℝ} (hφ : ∀ j, LCOn fun t => φ t j) :
    ∀ N n, LCOn fun t => coeff n (Pinv (φ t) N)
  | 0, n => by simpa [Pinv] using LCOn_zero
  | N + 1, n => by
    simp only [Pinv, map_add, coeff_monomial]
    by_cases h : n = N + 1
    · simp only [h, if_true]
      refine (LC_Pinv hφ N (N + 1)).add ?_
      unfold newc
      exact LCOn_sum _ fun j _ => (hφ j).mul (LC_coeff_pow (LC_Pinv hφ N) j N)
    · simp only [h, if_false, add_zero]
      exact LC_Pinv hφ N n

section seg

variable {S0 S1 : ℝ → ℝ} {a k : ℝ} (hm0 : Measurable S0) (hm1 : Measurable S1) (ha : 0 < a)
  (h0a : ∀ u, a ≤ S0 u) (h1a : ∀ u, a ≤ S1 u) (h02 : ∀ u, S0 u ≤ 2) (h12 : ∀ u, S1 u ≤ 2)
  (hk : 0 < k)
include hm0 hm1 ha h0a h1a h02 h12 hk

theorem LC_muS (ℓ : ℕ) : LCOn fun t => muS k (Seg S0 S1 t) ℓ := by
  unfold muS
  by_cases h : ℓ = 0
  · simp only [h, if_true]; exact LCOn_zero
  · simp only [h, if_false]
    have := (LCOn_mom hm0 hm1 ha h0a h1a h02 h12 ℓ).smul (c := 1 / (k * ℓ)) (by positivity)
    refine ⟨fun t ht => by have := this.1 t ht; simpa [div_eq_mul_inv, mul_comm] using this,
      fun t0 h0 t1 h1 l hl => ?_⟩
    have e := this.2 t0 h0 t1 h1 l hl
    simp only [one_div] at e
    simpa [div_eq_mul_inv, mul_comm] using e

theorem LC_HS (n : ℕ) : LCOn fun t => coeff n (HS k (Seg S0 S1 t)) := by
  simp only [HS, coeff_mk]; exact LC_muS hm0 hm1 ha h0a h1a h02 h12 hk n

theorem LC_phiS (j : ℕ) : LCOn fun t => phiS k (Seg S0 S1 t) j := by
  unfold phiS
  exact LCOn_sum _ fun i _ =>
    (LC_coeff_pow (LC_HS hm0 hm1 ha h0a h1a h02 h12 hk) i j).smul (by positivity)

theorem LC_cS (n : ℕ) : LCOn fun t => coeff n (cS k (Seg S0 S1 t)) := by
  unfold cS PhiS
  simp only [coeff_mk]
  exact LC_Pinv (LC_phiS hm0 hm1 ha h0a h1a h02 h12 hk) n n

/-- **Lemma 10.11**: `t ↦ F_n(S_t)` is log-convex. -/
theorem LC_F (n : ℕ) : LCOn fun t => coeff n (cS k (Seg S0 S1 t)) * RS k (Seg S0 S1 t) ^ n :=
  (LC_cS hm0 hm1 ha h0a h1a h02 h12 hk n).mul ((LCOn_RS hm0 hm1 ha h0a h1a h02 h12 hk).pow n)

/-- The width-series term `g_n(t) = c_n (Rⁿ - (-R)ⁿ) = (1 - (-1)ⁿ) F_n(t)` is convex. -/
theorem g_chord (n : ℕ) {s : ℝ} (hs : s ∈ Icc (0 : ℝ) 1) :
    coeff n (cS k (Seg S0 S1 s)) * (RS k (Seg S0 S1 s) ^ n - (-RS k (Seg S0 S1 s)) ^ n) ≤
      (1 - s) * (coeff n (cS k S0) * (RS k S0 ^ n - (-RS k S0) ^ n)) +
        s * (coeff n (cS k S1) * (RS k S1 ^ n - (-RS k S1) ^ n)) := by
  have hF := (LC_F hm0 hm1 ha h0a h1a h02 h12 hk n).convex_ineq
    (show (0 : ℝ) ∈ Icc (0 : ℝ) 1 from ⟨le_rfl, zero_le_one⟩)
    (show (1 : ℝ) ∈ Icc (0 : ℝ) 1 from ⟨zero_le_one, le_rfl⟩) hs
  simp only [mul_zero, zero_add, mul_one, Seg_zero, Seg_one] at hF
  have e : ∀ (c R : ℝ), c * (R ^ n - (-R) ^ n) = (1 - (-1) ^ n) * (c * R ^ n) := fun c R => by
    rw [neg_pow]; ring
  rw [e, e, e]
  have hc : 0 ≤ 1 - (-1 : ℝ) ^ n := by
    rcases neg_one_pow_eq_or ℝ n with h | h <;> rw [h] <;> norm_num
  nlinarith [mul_le_mul_of_nonneg_left hF hc]

theorem g_nonneg (n : ℕ) {s : ℝ} (hs : s ∈ Icc (0 : ℝ) 1) :
    0 ≤ coeff n (cS k (Seg S0 S1 s)) * (RS k (Seg S0 S1 s) ^ n - (-RS k (Seg S0 S1 s)) ^ n) := by
  have hF := (LC_F hm0 hm1 ha h0a h1a h02 h12 hk n).1 s hs
  have e : coeff n (cS k (Seg S0 S1 s)) * (RS k (Seg S0 S1 s) ^ n - (-RS k (Seg S0 S1 s)) ^ n) =
      (1 - (-1) ^ n) * (coeff n (cS k (Seg S0 S1 s)) * RS k (Seg S0 S1 s) ^ n) := by
    rw [neg_pow]; ring
  rw [e]
  have hc : 0 ≤ 1 - (-1 : ℝ) ^ n := by
    rcases neg_one_pow_eq_or ℝ n with h | h <;> rw [h] <;> norm_num
  exact mul_nonneg hc hF

/-- **N6(iii)**: the chord inequality for the width series. -/
theorem wser_chord (hsum0 : Summable fun n => coeff n (cS k S0) * (RS k S0 ^ n - (-RS k S0) ^ n))
    (hsum1 : Summable fun n => coeff n (cS k S1) * (RS k S1 ^ n - (-RS k S1) ^ n))
    {s : ℝ} (hs : s ∈ Icc (0 : ℝ) 1) :
    wser k (Seg S0 S1 s) ≤ (1 - s) * wser k S0 + s * wser k S1 := by
  have hR : Summable fun n => (1 - s) * (coeff n (cS k S0) * (RS k S0 ^ n - (-RS k S0) ^ n)) +
      s * (coeff n (cS k S1) * (RS k S1 ^ n - (-RS k S1) ^ n)) :=
    (hsum0.mul_left _).add (hsum1.mul_left _)
  have hL := hR.of_nonneg_of_le (fun n => g_nonneg hm0 hm1 ha h0a h1a h02 h12 hk n hs)
    (fun n => g_chord hm0 hm1 ha h0a h1a h02 h12 hk n hs)
  unfold wser
  rw [← tsum_mul_left, ← tsum_mul_left, ← (hsum0.mul_left _).tsum_add (hsum1.mul_left _)]
  exact hL.tsum_le_tsum (fun n => g_chord hm0 hm1 ha h0a h1a h02 h12 hk n hs) hR

theorem wser_slope (hsum0 : Summable fun n => coeff n (cS k S0) * (RS k S0 ^ n - (-RS k S0) ^ n))
    (hsum1 : Summable fun n => coeff n (cS k S1) * (RS k S1 ^ n - (-RS k S1) ^ n))
    {s : ℝ} (hs0 : 0 < s) (hs1 : s ≤ 1) :
    (wser k (Seg S0 S1 s) - wser k S0) / s ≤ wser k S1 - wser k S0 := by
  have h := wser_chord hm0 hm1 ha h0a h1a h02 h12 hk hsum0 hsum1 ⟨hs0.le, hs1⟩
  rw [div_le_iff₀ hs0]
  linarith

end seg

end EP1038.Stage10
