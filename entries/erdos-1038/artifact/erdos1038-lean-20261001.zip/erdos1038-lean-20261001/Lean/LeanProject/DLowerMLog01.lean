import LeanProject.DLowerMTools
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_40 : RB (Real.log ((710599414709594343 : ℝ) / 500000000000000000)) ((175750380753879799 : ℝ) / 500000000000000000) ((878751903769399 : ℝ) / 2500000000000000) := by
  have hm := log_bounds_of_series (x := ((710599414709594343 : ℝ) / 1000000000000000000)) (t := ((-289400585290405657 : ℝ) / 1710599414709594343))
    (lo := ((-341646419052185711 : ℝ) / 1000000000000000000)) (hi := ((-34164641905218571 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((710599414709594343 : ℝ) / 500000000000000000) = Real.log ((710599414709594343 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((710599414709594343 : ℝ) / 500000000000000000) = ((710599414709594343 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_41 : RB (Real.log ((28628625098872273 : ℝ) / 20000000000000000)) ((179337410655377753 : ℝ) / 500000000000000000) ((89668705327688877 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((28628625098872273 : ℝ) / 40000000000000000)) (t := ((-11371374901127727 : ℝ) / 68628625098872273))
    (lo := ((-334472359249189803 : ℝ) / 1000000000000000000)) (hi := ((-167236179624594901 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28628625098872273 : ℝ) / 20000000000000000) = Real.log ((28628625098872273 : ℝ) / 40000000000000000) + 1 * Real.log 2 := by
    rw [show ((28628625098872273 : ℝ) / 20000000000000000) = ((28628625098872273 : ℝ) / 40000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_42 : RB (Real.log ((710521289709594343 : ℝ) / 500000000000000000)) ((43923851633852147 : ℝ) / 125000000000000000) ((175695406535408589 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((710521289709594343 : ℝ) / 1000000000000000000)) (t := ((-289478710290405657 : ℝ) / 1710521289709594343))
    (lo := ((-341756367489128133 : ℝ) / 1000000000000000000)) (hi := ((-85439091872282033 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((710521289709594343 : ℝ) / 500000000000000000) = Real.log ((710521289709594343 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((710521289709594343 : ℝ) / 500000000000000000) = ((710521289709594343 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_43 : RB (Real.log ((1421042579419188687 : ℝ) / 1000000000000000000)) ((351390813070817177 : ℝ) / 1000000000000000000) ((351390813070817179 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1421042579419188687 : ℝ) / 2000000000000000000)) (t := ((-578957420580811313 : ℝ) / 3421042579419188687))
    (lo := ((-85439091872282033 : ℝ) / 250000000000000000)) (hi := ((-341756367489128131 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1421042579419188687 : ℝ) / 1000000000000000000) = Real.log ((1421042579419188687 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1421042579419188687 : ℝ) / 1000000000000000000) = ((1421042579419188687 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_44 : RB (Real.log ((1421098829419188687 : ℝ) / 1000000000000000000)) ((351430395900744231 : ℝ) / 1000000000000000000) ((351430395900744233 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1421098829419188687 : ℝ) / 2000000000000000000)) (t := ((-578901170580811313 : ℝ) / 3421098829419188687))
    (lo := ((-170858392329600539 : ℝ) / 500000000000000000)) (hi := ((-341716784659201077 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1421098829419188687 : ℝ) / 1000000000000000000) = Real.log ((1421098829419188687 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1421098829419188687 : ℝ) / 1000000000000000000) = ((1421098829419188687 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_45 : RB (Real.log ((28625500098872273 : ℝ) / 20000000000000000)) ((14342626354830531 : ℝ) / 40000000000000000) ((358565658870763277 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28625500098872273 : ℝ) / 40000000000000000)) (t := ((-11374499901127727 : ℝ) / 68625500098872273))
    (lo := ((-167290760844591017 : ℝ) / 500000000000000000)) (hi := ((-334581521689182033 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28625500098872273 : ℝ) / 20000000000000000) = Real.log ((28625500098872273 : ℝ) / 40000000000000000) + 1 * Real.log 2 := by
    rw [show ((28625500098872273 : ℝ) / 20000000000000000) = ((28625500098872273 : ℝ) / 40000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_46 : RB (Real.log ((1431275004943613651 : ℝ) / 1000000000000000000)) ((14342626354830531 : ℝ) / 40000000000000000) ((358565658870763277 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1431275004943613651 : ℝ) / 2000000000000000000)) (t := ((-568724995056386349 : ℝ) / 3431275004943613651))
    (lo := ((-167290760844591017 : ℝ) / 500000000000000000)) (hi := ((-334581521689182033 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1431275004943613651 : ℝ) / 1000000000000000000) = Real.log ((1431275004943613651 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1431275004943613651 : ℝ) / 1000000000000000000) = ((1431275004943613651 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_47 : RB (Real.log ((28624125098872273 : ℝ) / 20000000000000000)) ((358517623621780769 : ℝ) / 1000000000000000000) ((358517623621780771 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28624125098872273 : ℝ) / 40000000000000000)) (t := ((-11375874901127727 : ℝ) / 68624125098872273))
    (lo := ((-16731477846908227 : ℝ) / 50000000000000000)) (hi := ((-334629556938164539 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28624125098872273 : ℝ) / 20000000000000000) = Real.log ((28624125098872273 : ℝ) / 40000000000000000) + 1 * Real.log 2 := by
    rw [show ((28624125098872273 : ℝ) / 20000000000000000) = ((28624125098872273 : ℝ) / 40000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_48 : RB (Real.log ((17499999999999999 : ℝ) / 1000000000000000000)) ((-202277719902633437 : ℝ) / 50000000000000000) ((-2022777199026334369 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((17499999999999999 : ℝ) / 15625000000000000)) (t := ((1874999999999999 : ℝ) / 33124999999999999))
    (lo := ((113328685307003117 : ℝ) / 1000000000000000000)) (hi := ((56664342653501559 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17499999999999999 : ℝ) / 1000000000000000000) = Real.log ((17499999999999999 : ℝ) / 15625000000000000) - 6 * Real.log 2 := by
    rw [show ((17499999999999999 : ℝ) / 1000000000000000000) = ((17499999999999999 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_49 : RB (Real.log ((7 : ℝ) / 400)) ((-4045554398052668683 : ℝ) / 1000000000000000000) ((-4045554398052668681 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28 : ℝ) / 25)) (t := ((3 : ℝ) / 53))
    (lo := ((56664342653501587 : ℝ) / 500000000000000000)) (hi := ((4533147412280127 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7 : ℝ) / 400) = Real.log ((28 : ℝ) / 25) - 6 * Real.log 2 := by
    rw [show ((7 : ℝ) / 400) = ((28 : ℝ) / 25) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_50 : RB (Real.log ((1017499999999999999 : ℝ) / 1000000000000000000)) ((17348638334613 : ℝ) / 1000000000000000) ((17348638334613001 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1017499999999999999 : ℝ) / 1000000000000000000)) (t := ((17499999999999999 : ℝ) / 2017499999999999999))
    (lo := ((17348638334613 : ℝ) / 1000000000000000)) (hi := ((17348638334613001 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_51 : RB (Real.log ((407 : ℝ) / 400)) ((17348638334613001 : ℝ) / 1000000000000000000) ((8674319167306501 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((407 : ℝ) / 400)) (t := ((7 : ℝ) / 807))
    (lo := ((17348638334613001 : ℝ) / 1000000000000000000)) (hi := ((8674319167306501 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_52 : RB (Real.log ((14999999999999999 : ℝ) / 1000000000000000000)) ((-2099852538939963527 : ℝ) / 500000000000000000) ((-1049926269469981763 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((14999999999999999 : ℝ) / 15625000000000000)) (t := ((-625000000000001 : ℝ) / 30624999999999999))
    (lo := ((-40821994520255197 : ℝ) / 1000000000000000000)) (hi := ((-10205498630063799 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14999999999999999 : ℝ) / 1000000000000000000) = Real.log ((14999999999999999 : ℝ) / 15625000000000000) - 6 * Real.log 2 := by
    rw [show ((14999999999999999 : ℝ) / 1000000000000000000) = ((14999999999999999 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_53 : RB (Real.log ((1 : ℝ) / 50)) ((-195601150271407303 : ℝ) / 50000000000000000) ((-1956011502714073029 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((32 : ℝ) / 25)) (t := ((7 : ℝ) / 57))
    (lo := ((246860077931525797 : ℝ) / 1000000000000000000)) (hi := ((123430038965762899 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 50) = Real.log ((32 : ℝ) / 25) - 6 * Real.log 2 := by
    rw [show ((1 : ℝ) / 50) = ((32 : ℝ) / 25) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_54 : RB (Real.log ((1014999999999999999 : ℝ) / 1000000000000000000)) ((14888612493750653 : ℝ) / 1000000000000000000) ((7444306246875327 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1014999999999999999 : ℝ) / 1000000000000000000)) (t := ((14999999999999999 : ℝ) / 2014999999999999999))
    (lo := ((14888612493750653 : ℝ) / 1000000000000000000)) (hi := ((7444306246875327 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_55 : RB (Real.log ((51 : ℝ) / 50)) ((19802627296179713 : ℝ) / 1000000000000000000) ((9901313648089857 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((51 : ℝ) / 50)) (t := ((1 : ℝ) / 101))
    (lo := ((19802627296179713 : ℝ) / 1000000000000000000)) (hi := ((9901313648089857 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_56 : RB (Real.log ((473369254861127 : ℝ) / 1000000000000000)) ((-3739397646914029 : ℝ) / 5000000000000000) ((-373939764691402899 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((473369254861127 : ℝ) / 500000000000000)) (t := ((-26630745138873 : ℝ) / 973369254861127))
    (lo := ((-5473234882286049 : ℝ) / 100000000000000000)) (hi := ((-54732348822860489 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((473369254861127 : ℝ) / 1000000000000000) = Real.log ((473369254861127 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((473369254861127 : ℝ) / 1000000000000000) = ((473369254861127 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_57 : RB (Real.log ((473369254861130001 : ℝ) / 1000000000000000000)) ((-747879529382799461 : ℝ) / 1000000000000000000) ((-747879529382799459 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((473369254861130001 : ℝ) / 500000000000000000)) (t := ((-26630745138869999 : ℝ) / 973369254861130001))
    (lo := ((-54732348822854151 : ℝ) / 1000000000000000000)) (hi := ((-1094646976457083 : ℝ) / 20000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((473369254861130001 : ℝ) / 1000000000000000000) = Real.log ((473369254861130001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((473369254861130001 : ℝ) / 1000000000000000000) = ((473369254861130001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_58 : RB (Real.log ((52632449513887 : ℝ) / 100000000000000)) ((-641837345545338703 : ℝ) / 1000000000000000000) ((-641837345545338701 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((52632449513887 : ℝ) / 50000000000000)) (t := ((2632449513887 : ℝ) / 102632449513887))
    (lo := ((51309835014606607 : ℝ) / 1000000000000000000)) (hi := ((3206864688412913 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52632449513887 : ℝ) / 100000000000000) = Real.log ((52632449513887 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((52632449513887 : ℝ) / 100000000000000) = ((52632449513887 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_59 : RB (Real.log ((526324495138873 : ℝ) / 1000000000000000)) ((-641837345545333003 : ℝ) / 1000000000000000000) ((-641837345545333001 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((526324495138873 : ℝ) / 500000000000000)) (t := ((26324495138873 : ℝ) / 1026324495138873))
    (lo := ((51309835014612307 : ℝ) / 1000000000000000000)) (hi := ((12827458753653077 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((526324495138873 : ℝ) / 1000000000000000) = Real.log ((526324495138873 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((526324495138873 : ℝ) / 1000000000000000) = ((526324495138873 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_60 : RB (Real.log ((473675504861127 : ℝ) / 1000000000000000)) ((-74723278062561977 : ℝ) / 100000000000000000) ((-93404097578202471 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((473675504861127 : ℝ) / 500000000000000)) (t := ((-26324495138873 : ℝ) / 973675504861127))
    (lo := ((-2704280003283723 : ℝ) / 50000000000000000)) (hi := ((-54085600065674459 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((473675504861127 : ℝ) / 1000000000000000) = Real.log ((473675504861127 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((473675504861127 : ℝ) / 1000000000000000) = ((473675504861127 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_61 : RB (Real.log ((47367550486113 : ℝ) / 100000000000000)) ((-747232780625613437 : ℝ) / 1000000000000000000) ((-149446556125122687 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((47367550486113 : ℝ) / 50000000000000)) (t := ((-2632449513887 : ℝ) / 97367550486113))
    (lo := ((-54085600065668127 : ℝ) / 1000000000000000000)) (hi := ((-27042800032834063 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47367550486113 : ℝ) / 100000000000000) = Real.log ((47367550486113 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((47367550486113 : ℝ) / 100000000000000) = ((47367550486113 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_62 : RB (Real.log ((473369254861127001 : ℝ) / 1000000000000000000)) ((-373939764691402899 : ℝ) / 500000000000000000) ((-186969882345701449 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((473369254861127001 : ℝ) / 500000000000000000)) (t := ((-26630745138872999 : ℝ) / 973369254861127001))
    (lo := ((-6841543602857561 : ℝ) / 125000000000000000)) (hi := ((-54732348822860487 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((473369254861127001 : ℝ) / 1000000000000000000) = Real.log ((473369254861127001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((473369254861127001 : ℝ) / 1000000000000000000) = ((473369254861127001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_63 : RB (Real.log ((47336925486113 : ℝ) / 100000000000000)) ((-747879529382799463 : ℝ) / 1000000000000000000) ((-747879529382799461 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((47336925486113 : ℝ) / 50000000000000)) (t := ((-2663074513887 : ℝ) / 97336925486113))
    (lo := ((-54732348822854153 : ℝ) / 1000000000000000000)) (hi := ((-6841543602856769 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47336925486113 : ℝ) / 100000000000000) = Real.log ((47336925486113 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((47336925486113 : ℝ) / 100000000000000) = ((47336925486113 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_64 : RB (Real.log ((1424753439010159 : ℝ) / 1000000000000000)) ((176999386746994289 : ℝ) / 500000000000000000) ((17699938674699429 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424753439010159 : ℝ) / 2000000000000000)) (t := ((-575246560989841 : ℝ) / 3424753439010159))
    (lo := ((-339148407065956731 : ℝ) / 1000000000000000000)) (hi := ((-33914840706595673 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424753439010159 : ℝ) / 1000000000000000) = Real.log ((1424753439010159 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424753439010159 : ℝ) / 1000000000000000) = ((1424753439010159 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_65 : RB (Real.log ((1424753439010162001 : ℝ) / 1000000000000000000)) ((88499693373497671 : ℝ) / 250000000000000000) ((176999386746995343 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424753439010162001 : ℝ) / 2000000000000000000)) (t := ((-575246560989837999 : ℝ) / 3424753439010162001))
    (lo := ((-2713187256527637 : ℝ) / 8000000000000000)) (hi := ((-5299193860405541 : ℝ) / 15625000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424753439010162001 : ℝ) / 1000000000000000000) = Real.log ((1424753439010162001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424753439010162001 : ℝ) / 1000000000000000000) = ((1424753439010162001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_66 : RB (Real.log ((425059689010159 : ℝ) / 1000000000000000)) ((-85552567518937209 : ℝ) / 100000000000000000) ((-106940709398671511 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((425059689010159 : ℝ) / 500000000000000)) (t := ((-74940310989841 : ℝ) / 925059689010159))
    (lo := ((-8118924731471339 : ℝ) / 50000000000000000)) (hi := ((-162378494629426779 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425059689010159 : ℝ) / 1000000000000000) = Real.log ((425059689010159 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425059689010159 : ℝ) / 1000000000000000) = ((425059689010159 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_67 : RB (Real.log ((212529844505081 : ℝ) / 500000000000000)) ((-106940709398670629 : ℝ) / 125000000000000000) ((-85552567518936503 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((212529844505081 : ℝ) / 250000000000000)) (t := ((-37470155494919 : ℝ) / 462529844505081))
    (lo := ((-81189247314709861 : ℝ) / 500000000000000000)) (hi := ((-162378494629419721 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212529844505081 : ℝ) / 500000000000000) = Real.log ((212529844505081 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212529844505081 : ℝ) / 500000000000000) = ((212529844505081 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_68 : RB (Real.log ((1425059689010159 : ℝ) / 1000000000000000)) ((354213699868049909 : ℝ) / 1000000000000000000) ((354213699868049911 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425059689010159 : ℝ) / 2000000000000000)) (t := ((-574940310989841 : ℝ) / 3425059689010159))
    (lo := ((-1694667403459477 : ℝ) / 5000000000000000)) (hi := ((-338933480691895399 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425059689010159 : ℝ) / 1000000000000000) = Real.log ((1425059689010159 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425059689010159 : ℝ) / 1000000000000000) = ((1425059689010159 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_69 : RB (Real.log ((712529844505081 : ℝ) / 500000000000000)) ((177106849934026007 : ℝ) / 500000000000000000) ((22138356241753251 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((712529844505081 : ℝ) / 1000000000000000)) (t := ((-287470155494919 : ℝ) / 1712529844505081))
    (lo := ((-67786696138378659 : ℝ) / 200000000000000000)) (hi := ((-169466740345946647 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712529844505081 : ℝ) / 500000000000000) = Real.log ((712529844505081 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712529844505081 : ℝ) / 500000000000000) = ((712529844505081 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_70 : RB (Real.log ((1424753439010159001 : ℝ) / 1000000000000000000)) ((353998773493988579 : ℝ) / 1000000000000000000) ((353998773493988581 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424753439010159001 : ℝ) / 2000000000000000000)) (t := ((-575246560989840999 : ℝ) / 3424753439010159001))
    (lo := ((-33914840706595673 : ℝ) / 100000000000000000)) (hi := ((-339148407065956729 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424753439010159001 : ℝ) / 1000000000000000000) = Real.log ((1424753439010159001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424753439010159001 : ℝ) / 1000000000000000000) = ((1424753439010159001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_71 : RB (Real.log ((712376719505081 : ℝ) / 500000000000000)) ((88499693373497671 : ℝ) / 250000000000000000) ((176999386746995343 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((712376719505081 : ℝ) / 1000000000000000)) (t := ((-287623280494919 : ℝ) / 1712376719505081))
    (lo := ((-2713187256527637 : ℝ) / 8000000000000000)) (hi := ((-5299193860405541 : ℝ) / 15625000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712376719505081 : ℝ) / 500000000000000) = Real.log ((712376719505081 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712376719505081 : ℝ) / 500000000000000) = ((712376719505081 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_72 : RB (Real.log ((468028328107909361 : ℝ) / 1000000000000000000)) ((-379613227375630077 : ℝ) / 500000000000000000) ((-94903306843907519 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((468028328107909361 : ℝ) / 500000000000000000)) (t := ((-31971671892090639 : ℝ) / 968028328107909361))
    (lo := ((-16519818547828711 : ℝ) / 250000000000000000)) (hi := ((-66079274191314843 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((468028328107909361 : ℝ) / 1000000000000000000) = Real.log ((468028328107909361 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((468028328107909361 : ℝ) / 1000000000000000000) = ((468028328107909361 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_73 : RB (Real.log ((239348840807173749 : ℝ) / 500000000000000000)) ((-147337205136440859 : ℝ) / 200000000000000000) ((-736686025682204293 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((239348840807173749 : ℝ) / 250000000000000000)) (t := ((-10651159192826251 : ℝ) / 489348840807173749))
    (lo := ((-8707769024451797 : ℝ) / 200000000000000000)) (hi := ((-5442355640282373 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((239348840807173749 : ℝ) / 500000000000000000) = Real.log ((239348840807173749 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((239348840807173749 : ℝ) / 500000000000000000) = ((239348840807173749 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_74 : RB (Real.log ((521077318385652503 : ℝ) / 1000000000000000000)) ((-651856844428293173 : ℝ) / 1000000000000000000) ((-651856844428293171 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((521077318385652503 : ℝ) / 500000000000000000)) (t := ((21077318385652503 : ℝ) / 1021077318385652503))
    (lo := ((41290336131652137 : ℝ) / 1000000000000000000)) (hi := ((20645168065826069 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((521077318385652503 : ℝ) / 1000000000000000000) = Real.log ((521077318385652503 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((521077318385652503 : ℝ) / 1000000000000000000) = ((521077318385652503 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_75 : RB (Real.log ((531571671892090639 : ℝ) / 1000000000000000000)) ((-78989655244064963 : ℝ) / 125000000000000000) ((-315958620976259851 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((531571671892090639 : ℝ) / 500000000000000000)) (t := ((31571671892090639 : ℝ) / 1031571671892090639))
    (lo := ((30614969303712803 : ℝ) / 500000000000000000)) (hi := ((61229938607425607 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((531571671892090639 : ℝ) / 1000000000000000000) = Real.log ((531571671892090639 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((531571671892090639 : ℝ) / 1000000000000000000) = ((531571671892090639 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_76 : RB (Real.log ((468428328107909361 : ℝ) / 1000000000000000000)) ((-94796521329150463 : ℝ) / 125000000000000000) ((-379186085316601851 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((468428328107909361 : ℝ) / 500000000000000000)) (t := ((-31571671892090639 : ℝ) / 968428328107909361))
    (lo := ((-32612495036629197 : ℝ) / 500000000000000000)) (hi := ((-65224990073258393 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((468428328107909361 : ℝ) / 1000000000000000000) = Real.log ((468428328107909361 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((468428328107909361 : ℝ) / 1000000000000000000) = ((468428328107909361 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_77 : RB (Real.log ((478922681614347497 : ℝ) / 1000000000000000000)) ((-147243222170839849 : ℝ) / 200000000000000000) ((-736216110854199243 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((478922681614347497 : ℝ) / 500000000000000000)) (t := ((-21077318385652503 : ℝ) / 978922681614347497))
    (lo := ((-8613786058850787 : ℝ) / 200000000000000000)) (hi := ((-21534465147126967 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((478922681614347497 : ℝ) / 1000000000000000000) = Real.log ((478922681614347497 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((478922681614347497 : ℝ) / 1000000000000000000) = ((478922681614347497 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_78 : RB (Real.log ((468122078107909361 : ℝ) / 1000000000000000000)) ((-379513083211090999 : ℝ) / 500000000000000000) ((-189756541605545499 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((468122078107909361 : ℝ) / 500000000000000000)) (t := ((-31877921892090639 : ℝ) / 968122078107909361))
    (lo := ((-4117436616389793 : ℝ) / 62500000000000000)) (hi := ((-65878985862236687 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((468122078107909361 : ℝ) / 1000000000000000000) = Real.log ((468122078107909361 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((468122078107909361 : ℝ) / 1000000000000000000) = ((468122078107909361 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_79 : RB (Real.log ((234061039053954681 : ℝ) / 500000000000000000)) ((-189756541605545499 : ℝ) / 250000000000000000) ((-379513083211090997 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((234061039053954681 : ℝ) / 250000000000000000)) (t := ((-15938960946045319 : ℝ) / 484061039053954681))
    (lo := ((-32939492931118343 : ℝ) / 500000000000000000)) (hi := ((-13175797172447337 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((234061039053954681 : ℝ) / 500000000000000000) = Real.log ((234061039053954681 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((234061039053954681 : ℝ) / 500000000000000000) = ((234061039053954681 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
