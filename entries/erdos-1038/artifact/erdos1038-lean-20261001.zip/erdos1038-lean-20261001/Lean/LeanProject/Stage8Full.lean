import LeanProject.Stage7

/-!
# EP-1038, Stage 8 (the small mass-ratio range), in the root-vector language

* `prop81` (**Proposition 8.1**): for an atomized configuration with root sum `≤ 0`, least root
  `c₀` of multiplicity `a` and `b ≥ 1` other roots with `20a ≤ 29b` (`k ≥ 1` is derived):
  `∑ R_v > 1/3`, `M_k ≥ √2`, and `𝒥_k = M_k + 2∑ R_v > √2 + 2/3 > 2`, hence `|S| > 2`.
* `consequence`: the same `|S| > 2` for any root vector, via atomization.
* Corollary 8.2 (`61/40 ≤ |S_f|` for every `f ∈ 𝒫`) is `EP1038.volume_bounds_1525`
  (Residual.lean, Iteration 35).
-/

open Real MeasureTheory Set Finset

namespace EP1038.Stage8

open Resid Atom Stage7

/-- **Proposition 8.1**. -/
theorem prop81 {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, s i ≤ 0) (hcl : ∀ i j, uIcc (s i) (s j) ⊆ sublevel s → s i = s j)
    {c0 : ℝ} (hc0 : ∃ i, s i = c0) (hcle : ∀ i, c0 ≤ s i)
    (hb : 1 ≤ (univ.filter (fun i => s i ≠ c0)).card)
    (hkK : 20 * (univ.filter (fun i => s i = c0)).card ≤ 29 * (univ.filter (fun i => s i ≠ c0)).card) :
    1 / 3 < ∑ v ∈ (univ.filter (fun i => s i ≠ c0)).image s, Rv s v ∧
      √2 ≤ rhoR s c0 - ellL s c0 ∧
      √2 + 2 / 3 < (rhoR s c0 - ellL s c0) +
        2 * ∑ v ∈ (univ.filter (fun i => s i ≠ c0)).image s, Rv s v ∧
      ENNReal.ofReal 2 < volume (sublevel s) := by
  classical
  obtain ⟨i1, hi1⟩ := hc0
  have hc0l : -1 ≤ c0 := hi1 ▸ (hs i1).1
  -- the main-component data from `setup`
  obtain ⟨i0, r0, -, -, hmin0, hr0ge, -, hf1, hother, -, hab⟩ := setup hn s hs hsum hcl
  have hc0eq : s i0 = c0 := le_antisymm (hi1 ▸ hmin0 i1) (hcle i0)
  rw [hc0eq] at hr0ge hother hab
  have hf1' : |∏ i, (r0 - s i)| = 1 := hf1
  -- `∑ R_v > 1/3` (Proposition 8.1 via `prop81_link`)
  have hlink := prop81_link s hc0l hs hr0ge hf1' hother hb hab hkK
  simp only at hlink
  have hR : 1 / 3 < ∑ v ∈ (univ.filter (fun i => s i ≠ c0)).image s, Rv s v := by
    rw [sum_via_fin]
    exact hlink
  -- `M_k ≥ 1 + ρ(k) ≥ 1 + ρ(1) = √2`
  have ha1 : 1 ≤ (univ.filter (fun i => s i = c0)).card :=
    Finset.card_pos.mpr ⟨i1, Finset.mem_filter.mpr ⟨mem_univ _, hi1⟩⟩
  obtain ⟨-, hM⟩ := lemma76 hn s hs hsum hc0l hcle hb ha1 rfl
  have hbR : (0 : ℝ) < (univ.filter (fun i => s i ≠ c0)).card := by exact_mod_cast hb
  have hk1 : (1 : ℝ) ≤ ((univ.filter (fun i => s i = c0)).card : ℝ) /
      (univ.filter (fun i => s i ≠ c0)).card := by
    rw [le_div_iff₀ hbR, one_mul]; exact_mod_cast hab
  have hmono := rhoK_mono one_pos hk1
  rw [rhoK_one] at hmono
  have hMk : √2 ≤ rhoR s c0 - ellL s c0 := by linarith
  refine ⟨hR, hMk, by linarith, ?_⟩
  -- `|S| ≥ 𝒥 > 2`
  obtain ⟨i2, hmin2, -, -, -, hvol⟩ := lemma75 hn s hs hsum hcl
  have hc2 : s i2 = c0 := le_antisymm (hi1 ▸ hmin2 i1) (hcle i2)
  rw [hc2] at hvol
  have hs2 : (4 / 3 : ℝ) < √2 := by
    rw [show (4 / 3 : ℝ) = √((4 / 3) ^ 2) by rw [Real.sqrt_sq (by norm_num)]]
    exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
  refine lt_of_lt_of_le ?_ hvol
  exact ENNReal.ofReal_lt_ofReal_iff'.mpr ⟨by linarith, by linarith⟩

/-- **Stage 8, Consequence**: for an arbitrary root vector with root sum `≤ 0` whose atomization
`cmean r` has least root `c₀`, `b ≥ 1` other roots and `20a ≤ 29b`, `|S_r| > 2` (via Lemma 7.2). -/
theorem consequence {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, r i ≤ 0) {c0 : ℝ} (hc0 : ∃ i, cmean r i = c0) (hcle : ∀ i, c0 ≤ cmean r i)
    (hb : 1 ≤ (univ.filter (fun i => cmean r i ≠ c0)).card)
    (hkK : 20 * (univ.filter (fun i => cmean r i = c0)).card ≤
      29 * (univ.filter (fun i => cmean r i ≠ c0)).card) :
    ENNReal.ofReal 2 < volume (sublevel r) := by
  have h := (prop81 hn (cmean r) (cmean_mem_Icc r hr) (by rw [sum_cmean]; exact hsum)
    (fun i j h => cmean_eq_of_uIcc r h) hc0 hcle hb hkK).2.2.2
  exact h.trans_le (measure_mono (sublevel_cmean_subset r))

end EP1038.Stage8
