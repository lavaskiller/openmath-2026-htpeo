import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk14
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_90 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((3261 : ℝ) / 4861) ((13077 : ℝ) / 19477))
    (hq : RB (qa a) ((1341231 : ℝ) / 50000000) ((540079 : ℝ) / 20000000))
    (hd : RB (D0a a) ((189620707 : ℝ) / 100000000) ((189686949 : ℝ) / 100000000))
    : certE k a ((38815113 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((19543649 : ℝ) / 50000000) ∧ 0 < certE k a ((133361179 : ℝ) / 100000000) ∧ certE k a ((66754871 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17989 : ℝ) / 25000000) ((36461 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((38815113 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((38742191 : ℝ) / 100000000) ((38743157 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((38815113 : ℝ) / 100000000) ((38815113 : ℝ) / 100000000) ((38815113 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((61184887 : ℝ) / 100000000))
  have h3 : RB z3 ((6331987 : ℝ) / 10000000) ((63321449 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((61184887 : ℝ) / 100000000) ((61184887 : ℝ) / 100000000) ((61184887 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22848551 : ℝ) / 50000000) ((-22847303 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_1620.1 cov_log_1621.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-3835171 : ℝ) / 12500000) ((-30654209 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((38815113 : ℝ) / 100000000))
  have h6 : RB z6 ((-23659013 : ℝ) / 25000000) ((-1892721 : ℝ) / 2000000) := rb_log (show RB ((38815113 : ℝ) / 100000000) ((38815113 : ℝ) / 100000000) ((38815113 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1622.1 cov_log_1622.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((31977341 : ℝ) / 50000000) ((63981843 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((63985561 : ℝ) / 100000000) ((6402049 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1623.1 cov_log_1624.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-4113 : ℝ) / 6250000) ((-1859 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17989 : ℝ) / 25000000) ((36461 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19543649 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((4876797 : ℝ) / 12500000) ((19507671 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((19543649 : ℝ) / 50000000) ((19543649 : ℝ) / 50000000) ((19543649 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30456351 : ℝ) / 50000000))
  have h12 : RB z12 ((12809931 : ℝ) / 20000000) ((32025621 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((30456351 : ℝ) / 50000000) ((30456351 : ℝ) / 50000000) ((30456351 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-11137789 : ℝ) / 25000000) ((-11137169 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1625.1 cov_log_1626.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-7477993 : ℝ) / 25000000) ((-14942731 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19543649 : ℝ) / 50000000))
  have h15 : RB z15 ((-18787453 : ℝ) / 20000000) ((-93937263 : ℝ) / 100000000) := rb_log (show RB ((19543649 : ℝ) / 50000000) ((19543649 : ℝ) / 50000000) ((19543649 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1627.1 cov_log_1627.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64025291 : ℝ) / 100000000) ((64051803 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((63985561 : ℝ) / 100000000) ((6402049 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1623.1 cov_log_1624.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4801 : ℝ) / 100000000) ((33121 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17989 : ℝ) / 25000000) ((36461 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133361179 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((133288257 : ℝ) / 100000000) ((133289223 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((133361179 : ℝ) / 100000000) ((133361179 : ℝ) / 100000000) ((133361179 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33361179 : ℝ) / 100000000))
  have h21 : RB z21 ((199765507 : ℝ) / 50000000) ((399533911 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((33361179 : ℝ) / 100000000) ((33361179 : ℝ) / 100000000) ((33361179 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((3462803 : ℝ) / 2500000) ((8657053 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_1628.1 cov_log_1629.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46460401 : ℝ) / 50000000) ((46499269 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133361179 : ℝ) / 100000000))
  have h24 : RB z24 ((28789089 : ℝ) / 100000000) ((28789091 : ℝ) / 100000000) := rb_log (show RB ((133361179 : ℝ) / 100000000) ((133361179 : ℝ) / 100000000) ((133361179 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1630.1 cov_log_1630.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64131711 : ℝ) / 100000000) ((64209449 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((63985561 : ℝ) / 100000000) ((6402049 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1623.1 cov_log_1624.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((111221 : ℝ) / 100000000) ((13993 : ℝ) / 6250000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17989 : ℝ) / 25000000) ((36461 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((66754871 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((6671841 : ℝ) / 5000000) ((66718893 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((66754871 : ℝ) / 50000000) ((66754871 : ℝ) / 50000000) ((66754871 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((16754871 : ℝ) / 50000000))
  have h30 : RB z30 ((79640613 : ℝ) / 20000000) ((398205949 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((16754871 : ℝ) / 50000000) ((16754871 : ℝ) / 50000000) ((16754871 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((13817919 : ℝ) / 10000000) ((138179917 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1631.1 cov_log_1632.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92697457 : ℝ) / 100000000) ((46387503 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((66754871 : ℝ) / 50000000))
  have h33 : RB z33 ((14450213 : ℝ) / 50000000) ((7225107 : ℝ) / 25000000) := rb_log (show RB ((66754871 : ℝ) / 50000000) ((66754871 : ℝ) / 50000000) ((66754871 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1633.1 cov_log_1633.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63797029 : ℝ) / 100000000) ((3193729 : ℝ) / 5000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((63985561 : ℝ) / 100000000) ((6402049 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1623.1 cov_log_1624.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-223461 : ℝ) / 100000000) ((-110981 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((38815113 : ℝ) / 100000000)) ((-4113 : ℝ) / 6250000) ((-1859 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19543649 : ℝ) / 50000000)) ((4801 : ℝ) / 100000000) ((33121 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133361179 : ℝ) / 100000000)) ((111221 : ℝ) / 100000000) ((13993 : ℝ) / 6250000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((66754871 : ℝ) / 50000000)) ((-223461 : ℝ) / 100000000) ((-110981 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_90 {k A q d vp vm : ℝ}
    (hk : RB k ((3261 : ℝ) / 1600) ((13077 : ℝ) / 6400))
    (hA : RB A ((3261 : ℝ) / 4861) ((13077 : ℝ) / 19477))
    (hq : RB q ((1341231 : ℝ) / 50000000) ((540079 : ℝ) / 20000000))
    (hd : RB d ((189620707 : ℝ) / 100000000) ((189686949 : ℝ) / 100000000))
    (hp : RB vp ((38815113 : ℝ) / 100000000) ((19543649 : ℝ) / 50000000))
    (hm : RB vm ((133361179 : ℝ) / 100000000) ((66754871 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17989 : ℝ) / 25000000) ((36461 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49963539 : ℝ) / 50000000) ((24982011 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((33518021 : ℝ) / 50000000) ((67092419 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((18409 : ℝ) / 10000000) ((187871 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99812129 : ℝ) / 100000000) ((9981591 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30456351 : ℝ) / 50000000) ((61184887 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7599783 : ℝ) / 12500000) ((15268063 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((54882569 : ℝ) / 50000000) ((4414101 : ℝ) / 4000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((4882569 : ℝ) / 50000000) ((414101 : ℝ) / 4000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49963539 : ℝ) / 50000000) ((24982011 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((33518021 : ℝ) / 50000000) ((67092419 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((10779 : ℝ) / 20000000) ((54681 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99945319 : ℝ) / 100000000) ((19989221 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33361179 : ℝ) / 100000000) ((16754871 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((4167867 : ℝ) / 12500000) ((16745841 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((100078643 : ℝ) / 50000000) ((20121929 : ℝ) / 10000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((150078643 : ℝ) / 50000000) ((30121929 : ℝ) / 10000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((12074349 : ℝ) / 1250000) ((1024051069 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6639681 : ℝ) / 20000000) ((33315867 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((3261 : ℝ) / 800) ((13077 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2186877 : ℝ) / 20000000) ((11035333 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((51341231 : ℝ) / 50000000) ((20540079 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((10646877 : ℝ) / 100000000) ((1343381 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((110646877 : ℝ) / 100000000) ((13843381 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((94273881 : ℝ) / 100000000) ((94694629 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((178762799 : ℝ) / 100000000) ((179623353 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((12941073 : ℝ) / 25000000) ((52185351 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((27577 : ℝ) / 20000000) ((70437 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49929563 : ℝ) / 50000000) ((19972423 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((22313871 : ℝ) / 12500000) ((560549 : ℝ) / 312500) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((189620707 : ℝ) / 50000000) ((189686949 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5086503 : ℝ) / 50000000) ((5122297 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4861 : ℝ) / 1600) ((19477 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((133711 : ℝ) / 4000000) ((3372013 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3431373 : ℝ) / 50000000) ((434817 : ℝ) / 6250000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((53431373 : ℝ) / 50000000) ((6684817 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((129029809 : ℝ) / 12500000) ((3422797 : ℝ) / 312500) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((502297 : ℝ) / 25000000) ((1012437 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25502297 : ℝ) / 25000000) ((51012437 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33865423 : ℝ) / 100000000) ((4248809 : ℝ) / 12500000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((213220779 : ℝ) / 20000000) ((141160689 : ℝ) / 12500000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17818727 : ℝ) / 50000000) ((7615931 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4861 : ℝ) / 1600) ((19477 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((110646877 : ℝ) / 50000000) ((13843381 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((39965853 : ℝ) / 4000000) ((132170867 : ℝ) / 12500000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((221104841 : ℝ) / 10000000) ((2342005337 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((12972323 : ℝ) / 100000000) ((6881987 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-204235213 : ℝ) / 100000000) ((-99155779 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1634.1 cov_log_1635.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((5086503 : ℝ) / 100000000) ((5122297 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-297857967 : ℝ) / 100000000) ((-297156721 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1636.1 cov_log_1637.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((63985561 : ℝ) / 100000000) ((6402049 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1623.1 cov_log_1624.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((130410571 : ℝ) / 100000000) ((130811867 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-41861849 : ℝ) / 25000000) ((-83172427 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4067367 : ℝ) / 100000000) ((61651 : ℝ) / 1250000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((10681207 : ℝ) / 100000000) ((13839597 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-156766189 : ℝ) / 100000000) ((-152505257 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((110646877 : ℝ) / 100000000) ((13843381 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-204235213 : ℝ) / 100000000) ((-99155779 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-156766189 : ℝ) / 100000000) ((-152505257 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((71 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3431373 : ℝ) / 50000000) ((434817 : ℝ) / 6250000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((169 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((6684817 : ℝ) / 12500000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((71 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((169 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-10686803 : ℝ) / 6250000) ≤ formC0 k A q vp vm + hfun ((71 : ℝ) / 25) + hfun ((169 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_36, cov_h_30]
  have hP : ((54075399 : ℝ) / 12500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((152505257 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((152505257 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((5875087 : ℝ) / 10000000) ≤ EP1038.Arc.sinc ((169 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((477 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((631 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((631 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((641 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((641 : ℝ) / 250)) (lo := ((631 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((651 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((651 : ℝ) / 250)) (lo := ((641 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((661 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((661 : ℝ) / 250)) (lo := ((651 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((671 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((671 : ℝ) / 250)) (lo := ((661 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((681 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((681 : ℝ) / 250)) (lo := ((671 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((691 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((691 : ℝ) / 250)) (lo := ((681 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((701 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((701 : ℝ) / 250)) (lo := ((691 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((71 : ℝ) / 25)) (lo := ((701 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_90 {k : ℝ} (hk : RB k ((3261 : ℝ) / 1600) ((13077 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((3261 : ℝ) / 4861) ((13077 : ℝ) / 19477) ∧
    RB (qa (r1A k)) ((1341231 : ℝ) / 50000000) ((540079 : ℝ) / 20000000) ∧ RB (D0a (r1A k)) ((189620707 : ℝ) / 100000000) ((189686949 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((3261 : ℝ) / 6400) ((3192627 : ℝ) / 6250000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((11219873 : ℝ) / 6250000) ((57487 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((26796863 : ℝ) / 20000000) ((134032413 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275405671 : ℝ) / 100000000) ((27545377 : ℝ) / 10000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((27540567 : ℝ) / 20000000) ((27545377 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((189620707 : ℝ) / 100000000) ((189686949 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((6513 : ℝ) / 32000) ((1280127 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((5088281 : ℝ) / 100000000) ((1280127 : ℝ) / 25000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1341231 : ℝ) / 50000000) ((540079 : ℝ) / 20000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((189620707 : ℝ) / 100000000) ((189686949 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1341231 : ℝ) / 50000000) ((540079 : ℝ) / 20000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((3261 : ℝ) / 4861) ((13077 : ℝ) / 19477) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_90 {k : ℝ} (hk : RB k ((3261 : ℝ) / 1600) ((13077 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_90 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_90 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((38815113 : ℝ) / 100000000)) (ph := ((19543649 : ℝ) / 50000000)) (ml := ((133361179 : ℝ) / 100000000)) (mh := ((66754871 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_90 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_91 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((13077 : ℝ) / 19477) ((1311 : ℝ) / 1951))
    (hq : RB (qa a) ((1350197 : ℝ) / 50000000) ((2718341 : ℝ) / 100000000))
    (hd : RB (D0a a) ((189554459 : ℝ) / 100000000) ((94810357 : ℝ) / 50000000))
    : certE k a ((19392089 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((19527813 : ℝ) / 50000000) ∧ 0 < certE k a ((33352699 : ℝ) / 25000000) ∧ certE k a ((133559069 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((72921 : ℝ) / 100000000) ((36947 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((19392089 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((9677571 : ℝ) / 25000000) ((38711257 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((19392089 : ℝ) / 50000000) ((19392089 : ℝ) / 50000000) ((19392089 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((30607911 : ℝ) / 50000000))
  have h3 : RB z3 ((63235749 : ℝ) / 100000000) ((3161867 : ℝ) / 5000000) := rb_div_signed h2 (show RB ((30607911 : ℝ) / 50000000) ((30607911 : ℝ) / 50000000) ((30607911 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-45830041 : ℝ) / 100000000) ((-45827523 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1638.1 cov_log_1639.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-30796097 : ℝ) / 100000000) ((-30768933 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((19392089 : ℝ) / 50000000))
  have h6 : RB z6 ((-47357891 : ℝ) / 50000000) ((-4735789 : ℝ) / 5000000) := rb_log (show RB ((19392089 : ℝ) / 50000000) ((19392089 : ℝ) / 50000000) ((19392089 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1640.1 cov_log_1640.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63919683 : ℝ) / 100000000) ((63946849 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((63950617 : ℝ) / 100000000) ((31992783 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1641.1 cov_log_1642.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-65883 : ℝ) / 100000000) ((-471 : ℝ) / 12500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((72921 : ℝ) / 100000000) ((36947 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19527813 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((9745433 : ℝ) / 25000000) ((7796541 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((19527813 : ℝ) / 50000000) ((19527813 : ℝ) / 50000000) ((19527813 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30472187 : ℝ) / 50000000))
  have h12 : RB z12 ((31981403 : ℝ) / 50000000) ((15991101 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((30472187 : ℝ) / 50000000) ((30472187 : ℝ) / 50000000) ((30472187 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-11171711 : ℝ) / 25000000) ((-5585543 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_1643.1 cov_log_1644.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-30027911 : ℝ) / 100000000) ((-15000697 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19527813 : ℝ) / 50000000))
  have h15 : RB z15 ((-47009163 : ℝ) / 50000000) ((-23504581 : ℝ) / 25000000) := rb_log (show RB ((19527813 : ℝ) / 50000000) ((19527813 : ℝ) / 50000000) ((19527813 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1645.1 cov_log_1645.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((63990413 : ℝ) / 100000000) ((16004233 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((63950617 : ℝ) / 100000000) ((31992783 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1641.1 cov_log_1642.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4847 : ℝ) / 100000000) ((13263 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((72921 : ℝ) / 100000000) ((36947 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((33352699 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((66668451 : ℝ) / 50000000) ((1066703 : ℝ) / 800000) := rb_widen (rb_sub (show RB ((33352699 : ℝ) / 25000000) ((33352699 : ℝ) / 25000000) ((33352699 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((8352699 : ℝ) / 25000000))
  have h21 : RB z21 ((99770821 : ℝ) / 25000000) ((399086197 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((8352699 : ℝ) / 25000000) ((8352699 : ℝ) / 25000000) ((8352699 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((138399993 : ℝ) / 100000000) ((69200363 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_1646.1 cov_log_1647.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((18584553 : ℝ) / 20000000) ((93000181 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((33352699 : ℝ) / 25000000))
  have h24 : RB z24 ((28826287 : ℝ) / 100000000) ((28826289 : ℝ) / 100000000) := rb_log (show RB ((33352699 : ℝ) / 25000000) ((33352699 : ℝ) / 25000000) ((33352699 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1648.1 cov_log_1648.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16024119 : ℝ) / 25000000) ((32086947 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((63950617 : ℝ) / 100000000) ((31992783 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1641.1 cov_log_1642.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((11091 : ℝ) / 10000000) ((223277 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((72921 : ℝ) / 100000000) ((36947 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((133559069 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((5339407 : ℝ) / 4000000) ((33371537 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((133559069 : ℝ) / 100000000) ((133559069 : ℝ) / 100000000) ((133559069 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((33559069 : ℝ) / 100000000))
  have h30 : RB z30 ((397761853 : ℝ) / 100000000) ((198882377 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((33559069 : ℝ) / 100000000) ((33559069 : ℝ) / 100000000) ((33559069 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((138068327 : ℝ) / 100000000) ((6903453 : ℝ) / 5000000) := rb_log h30 (by norm_num) cov_log_1649.1 cov_log_1650.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46350041 : ℝ) / 50000000) ((92777313 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((133559069 : ℝ) / 100000000))
  have h33 : RB z33 ((5787473 : ℝ) / 20000000) ((28937367 : ℝ) / 100000000) := rb_log (show RB ((133559069 : ℝ) / 100000000) ((133559069 : ℝ) / 100000000) ((133559069 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1651.1 cov_log_1651.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((12752543 : ℝ) / 20000000) ((15959987 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((63950617 : ℝ) / 100000000) ((31992783 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1641.1 cov_log_1642.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-222851 : ℝ) / 100000000) ((-110669 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((19392089 : ℝ) / 50000000)) ((-65883 : ℝ) / 100000000) ((-471 : ℝ) / 12500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19527813 : ℝ) / 50000000)) ((4847 : ℝ) / 100000000) ((13263 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((33352699 : ℝ) / 25000000)) ((11091 : ℝ) / 10000000) ((223277 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((133559069 : ℝ) / 100000000)) ((-222851 : ℝ) / 100000000) ((-110669 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_91 {k A q d vp vm : ℝ}
    (hk : RB k ((13077 : ℝ) / 6400) ((1311 : ℝ) / 640))
    (hA : RB A ((13077 : ℝ) / 19477) ((1311 : ℝ) / 1951))
    (hq : RB q ((1350197 : ℝ) / 50000000) ((2718341 : ℝ) / 100000000))
    (hd : RB d ((189554459 : ℝ) / 100000000) ((94810357 : ℝ) / 50000000))
    (hp : RB vp ((19392089 : ℝ) / 50000000) ((19527813 : ℝ) / 50000000))
    (hm : RB vm ((33352699 : ℝ) / 25000000) ((133559069 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((72921 : ℝ) / 100000000) ((36947 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49963053 : ℝ) / 50000000) ((99927079 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((67091117 : ℝ) / 100000000) ((6714731 : ℝ) / 10000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((18671 : ℝ) / 10000000) ((190527 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99809473 : ℝ) / 100000000) ((9981329 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30472187 : ℝ) / 50000000) ((30607911 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((30414129 : ℝ) / 50000000) ((30550763 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((54901343 : ℝ) / 50000000) ((2207767 : ℝ) / 2000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((4901343 : ℝ) / 50000000) ((207767 : ℝ) / 2000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49963053 : ℝ) / 50000000) ((99927079 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((67091117 : ℝ) / 100000000) ((6714731 : ℝ) / 10000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((27299 : ℝ) / 50000000) ((55389 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99944611 : ℝ) / 100000000) ((49972701 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((8352699 : ℝ) / 25000000) ((33559069 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((3339229 : ℝ) / 10000000) ((33540747 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((20002869 : ℝ) / 10000000) ((201086269 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((30002869 : ℝ) / 10000000) ((301086269 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((962616777 : ℝ) / 100000000) ((204025713 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((2075817 : ℝ) / 6250000) ((16665073 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((13077 : ℝ) / 3200) ((1311 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((172427 : ℝ) / 1562500) ((174011 : ℝ) / 1562500) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((51350197 : ℝ) / 50000000) ((102718341 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1342911 : ℝ) / 12500000) ((10843877 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((13842911 : ℝ) / 12500000) ((110843877 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((9435517 : ℝ) / 10000000) ((94774891 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((5589201 : ℝ) / 3125000) ((89856413 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((1293557 : ℝ) / 2500000) ((52162331 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((34949 : ℝ) / 25000000) ((35703 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24964297 : ℝ) / 25000000) ((24965051 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((89299503 : ℝ) / 50000000) ((35892319 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((189554459 : ℝ) / 50000000) ((94810357 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5118717 : ℝ) / 50000000) ((2577269 : ℝ) / 25000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((19477 : ℝ) / 6400) ((1951 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((209891 : ℝ) / 6250000) ((105859 : ℝ) / 3125000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((276569 : ℝ) / 4000000) ((1752223 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((4276569 : ℝ) / 4000000) ((26752223 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((514587133 : ℝ) / 50000000) ((43665131 : ℝ) / 4000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((126367 : ℝ) / 6250000) ((509393 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((6376367 : ℝ) / 6250000) ((25509393 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33884597 : ℝ) / 100000000) ((4251159 : ℝ) / 12500000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1063058863 : ℝ) / 100000000) ((1125637547 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17850119 : ℝ) / 50000000) ((38130837 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((19477 : ℝ) / 6400) ((1951 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((13842911 : ℝ) / 6250000) ((110843877 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((995829849 : ℝ) / 100000000) ((1053458711 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((441125887 : ℝ) / 20000000) ((583847239 : ℝ) / 25000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((13031153 : ℝ) / 100000000) ((13821169 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-101891367 : ℝ) / 50000000) ((-98948439 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1652.1 cov_log_1653.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((5118717 : ℝ) / 100000000) ((2577269 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-297226641 : ℝ) / 100000000) ((-296529269 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1654.1 cov_log_1655.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((63950617 : ℝ) / 100000000) ((31992783 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1641.1 cov_log_1642.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((16333637 : ℝ) / 12500000) ((131070433 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-33311509 : ℝ) / 20000000) ((-41364709 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((995363 : ℝ) / 25000000) ((2422021 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((5220777 : ℝ) / 50000000) ((2713731 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-156115991 : ℝ) / 100000000) ((-151890181 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((13842911 : ℝ) / 12500000) ((110843877 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-101891367 : ℝ) / 50000000) ((-98948439 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-156115991 : ℝ) / 100000000) ((-151890181 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((71 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((276569 : ℝ) / 4000000) ((1752223 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((169 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((26752223 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((71 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((169 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-170536369 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((71 : ℝ) / 25) + hfun ((169 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_36, cov_h_30]
  have hP : ((215241029 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((151890181 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((151890181 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((5875087 : ℝ) / 10000000) ≤ EP1038.Arc.sinc ((169 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((477 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2519 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2519 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2559 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2559 : ℝ) / 1000)) (lo := ((2519 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2599 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2599 : ℝ) / 1000)) (lo := ((2559 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2639 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2639 : ℝ) / 1000)) (lo := ((2599 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2679 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2679 : ℝ) / 1000)) (lo := ((2639 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2719 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2719 : ℝ) / 1000)) (lo := ((2679 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2759 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2759 : ℝ) / 1000)) (lo := ((2719 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2799 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2799 : ℝ) / 1000)) (lo := ((2759 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2839 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2839 : ℝ) / 1000)) (lo := ((2799 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((71 : ℝ) / 25)) (lo := ((2839 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_91 {k : ℝ} (hk : RB k ((13077 : ℝ) / 6400) ((1311 : ℝ) / 640)) :
    RB (k / (k + 1)) ((13077 : ℝ) / 19477) ((1311 : ℝ) / 1951) ∧
    RB (qa (r1A k)) ((1350197 : ℝ) / 50000000) ((2718341 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((189554459 : ℝ) / 100000000) ((94810357 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((51082031 : ℝ) / 100000000) ((25605469 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((89694531 : ℝ) / 50000000) ((179517969 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((133936201 : ℝ) / 100000000) ((33496079 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275357557 : ℝ) / 100000000) ((275405673 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((68839389 : ℝ) / 50000000) ((137702837 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((189554459 : ℝ) / 100000000) ((94810357 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((20482031 : ℝ) / 100000000) ((10305469 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((5120507 : ℝ) / 100000000) ((1030547 : ℝ) / 20000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1350197 : ℝ) / 50000000) ((2718341 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((189554459 : ℝ) / 100000000) ((94810357 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1350197 : ℝ) / 50000000) ((2718341 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((13077 : ℝ) / 19477) ((1311 : ℝ) / 1951) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_91 {k : ℝ} (hk : RB k ((13077 : ℝ) / 6400) ((1311 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_91 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_91 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((19392089 : ℝ) / 50000000)) (ph := ((19527813 : ℝ) / 50000000)) (ml := ((33352699 : ℝ) / 25000000)) (mh := ((133559069 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_91 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_92 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1311 : ℝ) / 1951) ((13143 : ℝ) / 19543))
    (hq : RB (qa a) ((2718339 : ℝ) / 100000000) ((1368149 : ℝ) / 50000000))
    (hd : RB (D0a a) ((947441 : ℝ) / 500000) ((37910893 : ℝ) / 20000000))
    : certE k a ((38753319 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((19512023 : ℝ) / 50000000) ∧ 0 < certE k a ((133460317 : ℝ) / 100000000) ∧ certE k a ((133608301 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((73893 : ℝ) / 100000000) ((37437 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((38753319 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((7735689 : ℝ) / 20000000) ((19339713 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((38753319 : ℝ) / 100000000) ((38753319 : ℝ) / 100000000) ((38753319 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((61246681 : ℝ) / 100000000))
  have h3 : RB z3 ((63151903 : ℝ) / 100000000) ((31576753 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((61246681 : ℝ) / 100000000) ((61246681 : ℝ) / 100000000) ((61246681 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22981361 : ℝ) / 50000000) ((-45960181 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1656.1 cov_log_1657.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-30910713 : ℝ) / 100000000) ((-6176709 : ℝ) / 20000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((38753319 : ℝ) / 100000000))
  have h6 : RB z6 ((-4739769 : ℝ) / 5000000) ((-47397689 : ℝ) / 50000000) := rb_log (show RB ((38753319 : ℝ) / 100000000) ((38753319 : ℝ) / 100000000) ((38753319 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1658.1 cov_log_1658.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((12776933 : ℝ) / 20000000) ((12782367 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((7989457 : ℝ) / 12500000) ((63950623 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1659.1 cov_log_1660.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-32979 : ℝ) / 50000000) ((-3821 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((73893 : ℝ) / 100000000) ((37437 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19512023 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((9737293 : ℝ) / 25000000) ((38950153 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((19512023 : ℝ) / 50000000) ((19512023 : ℝ) / 50000000) ((19512023 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30487977 : ℝ) / 50000000))
  have h12 : RB z12 ((63876281 : ℝ) / 100000000) ((63877891 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((30487977 : ℝ) / 50000000) ((30487977 : ℝ) / 50000000) ((30487977 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-4482221 : ℝ) / 10000000) ((-44819687 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_1661.1 cov_log_1662.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-30143699 : ℝ) / 100000000) ((-1204687 : ℝ) / 4000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19512023 : ℝ) / 50000000))
  have h15 : RB z15 ((-47049609 : ℝ) / 50000000) ((-5881201 : ℝ) / 6250000) := rb_log (show RB ((19512023 : ℝ) / 50000000) ((19512023 : ℝ) / 50000000) ((19512023 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1663.1 cov_log_1663.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((63955517 : ℝ) / 100000000) ((63982043 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((7989457 : ℝ) / 12500000) ((63950623 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1659.1 cov_log_1660.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2447 : ℝ) / 50000000) ((66387 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((73893 : ℝ) / 100000000) ((37437 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133460317 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((133385443 : ℝ) / 100000000) ((16673303 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((133460317 : ℝ) / 100000000) ((133460317 : ℝ) / 100000000) ((133460317 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33460317 : ℝ) / 100000000))
  have h21 : RB z21 ((199318857 : ℝ) / 50000000) ((398640647 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((33460317 : ℝ) / 100000000) ((33460317 : ℝ) / 100000000) ((33460317 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((138288283 : ℝ) / 100000000) ((138289021 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1664.1 cov_log_1665.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46462311 : ℝ) / 50000000) ((2325043 : ℝ) / 2500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133460317 : ℝ) / 100000000))
  have h24 : RB z24 ((28863399 : ℝ) / 100000000) ((28863401 : ℝ) / 100000000) := rb_log (show RB ((133460317 : ℝ) / 100000000) ((133460317 : ℝ) / 100000000) ((133460317 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1666.1 cov_log_1666.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64061221 : ℝ) / 100000000) ((64138321 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((7989457 : ℝ) / 12500000) ((63950623 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1659.1 cov_log_1660.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((55299 : ℝ) / 50000000) ((44533 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((73893 : ℝ) / 100000000) ((37437 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((133608301 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((133533427 : ℝ) / 100000000) ((16691801 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((133608301 : ℝ) / 100000000) ((133608301 : ℝ) / 100000000) ((133608301 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((33608301 : ℝ) / 100000000))
  have h30 : RB z30 ((397322753 : ℝ) / 100000000) ((397325673 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((33608301 : ℝ) / 100000000) ((33608301 : ℝ) / 100000000) ((33608301 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((68978937 : ℝ) / 50000000) ((34489653 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_1667.1 cov_log_1668.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((463513 : ℝ) / 500000) ((46389757 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((133608301 : ℝ) / 100000000))
  have h33 : RB z33 ((1448711 : ℝ) / 5000000) ((14487111 : ℝ) / 50000000) := rb_log (show RB ((133608301 : ℝ) / 100000000) ((133608301 : ℝ) / 100000000) ((133608301 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1669.1 cov_log_1669.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((31864189 : ℝ) / 50000000) ((31902647 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((7989457 : ℝ) / 12500000) ((63950623 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1659.1 cov_log_1660.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-44449 : ℝ) / 20000000) ((-55181 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((38753319 : ℝ) / 100000000)) ((-32979 : ℝ) / 50000000) ((-3821 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19512023 : ℝ) / 50000000)) ((2447 : ℝ) / 50000000) ((66387 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133460317 : ℝ) / 100000000)) ((55299 : ℝ) / 50000000) ((44533 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((133608301 : ℝ) / 100000000)) ((-44449 : ℝ) / 20000000) ((-55181 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_92 {k A q d vp vm : ℝ}
    (hk : RB k ((1311 : ℝ) / 640) ((13143 : ℝ) / 6400))
    (hA : RB A ((1311 : ℝ) / 1951) ((13143 : ℝ) / 19543))
    (hq : RB q ((2718339 : ℝ) / 100000000) ((1368149 : ℝ) / 50000000))
    (hd : RB d ((947441 : ℝ) / 500000) ((37910893 : ℝ) / 20000000))
    (hp : RB vp ((38753319 : ℝ) / 100000000) ((19512023 : ℝ) / 50000000))
    (hm : RB vm ((133460317 : ℝ) / 100000000) ((133608301 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((73893 : ℝ) / 100000000) ((37437 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49962563 : ℝ) / 50000000) ((99926107 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((67145997 : ℝ) / 100000000) ((8400251 : ℝ) / 12500000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((23669 : ℝ) / 12500000) ((193207 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99806793 : ℝ) / 100000000) ((12476331 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30487977 : ℝ) / 50000000) ((61246681 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((1901817 : ℝ) / 3125000) ((6113071 : ℝ) / 10000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((109840041 : ℝ) / 100000000) ((110424019 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((9840041 : ℝ) / 100000000) ((10424019 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49962563 : ℝ) / 50000000) ((99926107 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((67145997 : ℝ) / 100000000) ((8400251 : ℝ) / 12500000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((11061 : ℝ) / 20000000) ((56103 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99943897 : ℝ) / 100000000) ((19988939 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33460317 : ℝ) / 100000000) ((33608301 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((4180193 : ℝ) / 12500000) ((16794857 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((24987559 : ℝ) / 12500000) ((40190733 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((37487559 : ℝ) / 12500000) ((60190733 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((479661443 : ℝ) / 50000000) ((1016255929 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16613853 : ℝ) / 50000000) ((8336099 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1311 : ℝ) / 320) ((13143 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2227339 : ℝ) / 20000000) ((11238489 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102718339 : ℝ) / 100000000) ((51368149 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5420039 : ℝ) / 50000000) ((5470537 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((55420039 : ℝ) / 50000000) ((55470537 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((94436271 : ℝ) / 100000000) ((47427491 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((17894559 : ℝ) / 10000000) ((89900927 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((25860151 : ℝ) / 50000000) ((10427873 : ℝ) / 20000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((70861 : ℝ) / 50000000) ((1131 : ℝ) / 781250) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((780119 : ℝ) / 781250) ((49929139 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((89343267 : ℝ) / 50000000) ((44886759 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((947441 : ℝ) / 250000) ((37910893 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((10301863 : ℝ) / 100000000) ((10373551 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1951 : ℝ) / 640) ((19543 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((843421 : ℝ) / 25000000) ((850727 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1393161 : ℝ) / 20000000) ((706081 : ℝ) / 10000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((21393161 : ℝ) / 20000000) ((10706081 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1026147447 : ℝ) / 100000000) ((108801183 : ℝ) / 10000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1017279 : ℝ) / 50000000) ((2050271 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((51017279 : ℝ) / 50000000) ((102050271 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16951871 : ℝ) / 50000000) ((34028047 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1060051189 : ℝ) / 100000000) ((1122039877 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((35762777 : ℝ) / 100000000) ((7636397 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1951 : ℝ) / 640) ((19543 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((55420039 : ℝ) / 25000000) ((55470537 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((15508603 : ℝ) / 1562500) ((41984013 : ℝ) / 4000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((22002877 : ℝ) / 1000000) ((2328875747 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((6544869 : ℝ) / 50000000) ((13878157 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-40666833 : ℝ) / 20000000) ((-197485401 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1670.1 cov_log_1671.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((5150931 : ℝ) / 100000000) ((648347 : ℝ) / 12500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-11863971 : ℝ) / 4000000) ((-295905787 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1672.1 cov_log_1673.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((7989457 : ℝ) / 12500000) ((63950623 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1659.1 cov_log_1660.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((65463613 : ℝ) / 50000000) ((656643 : ℝ) / 500000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-165672049 : ℝ) / 100000000) ((-164577187 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3896011 : ℝ) / 100000000) ((2378257 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((10203793 : ℝ) / 100000000) ((13300181 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-4858383 : ℝ) / 3125000) ((-75638503 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((55420039 : ℝ) / 50000000) ((55470537 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-40666833 : ℝ) / 20000000) ((-197485401 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-4858383 : ℝ) / 3125000) ((-75638503 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((71 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1393161 : ℝ) / 20000000) ((706081 : ℝ) / 10000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((169 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((10706081 : ℝ) / 20000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((71 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((169 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-850439 : ℝ) / 500000) ≤ formC0 k A q vp vm + hfun ((71 : ℝ) / 25) + hfun ((169 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_36, cov_h_30]
  have hP : ((428368589 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((75638503 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((75638503 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((5875087 : ℝ) / 10000000) ≤ EP1038.Arc.sinc ((169 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((477 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2513 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2513 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2553 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2553 : ℝ) / 1000)) (lo := ((2513 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2593 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2593 : ℝ) / 1000)) (lo := ((2553 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2633 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2633 : ℝ) / 1000)) (lo := ((2593 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2673 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2673 : ℝ) / 1000)) (lo := ((2633 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2713 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2713 : ℝ) / 1000)) (lo := ((2673 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2753 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2753 : ℝ) / 1000)) (lo := ((2713 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2793 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2793 : ℝ) / 1000)) (lo := ((2753 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2833 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2833 : ℝ) / 1000)) (lo := ((2793 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((71 : ℝ) / 25)) (lo := ((2833 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_92 {k : ℝ} (hk : RB k ((1311 : ℝ) / 640) ((13143 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((1311 : ℝ) / 1951) ((13143 : ℝ) / 19543) ∧
    RB (qa (r1A k)) ((2718339 : ℝ) / 100000000) ((1368149 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((947441 : ℝ) / 500000) ((37910893 : ℝ) / 20000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((51210937 : ℝ) / 100000000) ((12834961 : ℝ) / 25000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((44815039 : ℝ) / 25000000) ((179389063 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((133888071 : ℝ) / 100000000) ((133936203 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275309427 : ℝ) / 100000000) ((6883939 : ℝ) / 2500000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((137654713 : ℝ) / 100000000) ((6883939 : ℝ) / 5000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((947441 : ℝ) / 500000) ((37910893 : ℝ) / 20000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((20610937 : ℝ) / 100000000) ((5184961 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2576367 : ℝ) / 50000000) ((5184961 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((2718339 : ℝ) / 100000000) ((1368149 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((947441 : ℝ) / 500000) ((37910893 : ℝ) / 20000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((2718339 : ℝ) / 100000000) ((1368149 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1311 : ℝ) / 1951) ((13143 : ℝ) / 19543) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_92 {k : ℝ} (hk : RB k ((1311 : ℝ) / 640) ((13143 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_92 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_92 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((38753319 : ℝ) / 100000000)) (ph := ((19512023 : ℝ) / 50000000)) (ml := ((133460317 : ℝ) / 100000000)) (mh := ((133608301 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_92 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_93 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((13143 : ℝ) / 19543) ((1647 : ℝ) / 2447))
    (hq : RB (qa a) ((342037 : ℝ) / 12500000) ((2754269 : ℝ) / 100000000))
    (hd : RB (D0a a) ((189421927 : ℝ) / 100000000) ((94744103 : ℝ) / 50000000))
    : certE k a ((38722533 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((9748139 : ℝ) / 25000000) ∧ 0 < certE k a ((6675487 : ℝ) / 5000000) ∧ certE k a ((133657437 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((74873 : ℝ) / 100000000) ((3793 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((38722533 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((38646673 : ℝ) / 100000000) ((1932383 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((38722533 : ℝ) / 100000000) ((38722533 : ℝ) / 100000000) ((38722533 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((61277467 : ℝ) / 100000000))
  have h3 : RB z3 ((31534163 : ℝ) / 50000000) ((31534969 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((61277467 : ℝ) / 100000000) ((61277467 : ℝ) / 100000000) ((61277467 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2880947 : ℝ) / 6250000) ((-23046297 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_1674.1 cov_log_1675.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-31025221 : ℝ) / 100000000) ((-30998053 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((38722533 : ℝ) / 100000000))
  have h6 : RB z6 ((-23718713 : ℝ) / 25000000) ((-1897497 : ℝ) / 2000000) := rb_log (show RB ((38722533 : ℝ) / 100000000) ((38722533 : ℝ) / 100000000) ((38722533 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1676.1 cov_log_1676.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63849629 : ℝ) / 100000000) ((63876799 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((2555227 : ℝ) / 4000000) ((63915661 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1677.1 cov_log_1678.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-4127 : ℝ) / 6250000) ((-969 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((74873 : ℝ) / 100000000) ((3793 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((9748139 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((4864587 : ℝ) / 12500000) ((38917683 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((9748139 : ℝ) / 25000000) ((9748139 : ℝ) / 25000000) ((9748139 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((15251861 : ℝ) / 25000000))
  have h12 : RB z12 ((63790077 : ℝ) / 100000000) ((3986981 : ℝ) / 6250000) := rb_div_signed h11 (show RB ((15251861 : ℝ) / 25000000) ((15251861 : ℝ) / 25000000) ((15251861 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-5619657 : ℝ) / 12500000) ((-11238679 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1679.1 cov_log_1680.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-30259339 : ℝ) / 100000000) ((-30232811 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((9748139 : ℝ) / 25000000))
  have h15 : RB z15 ((-11772493 : ℝ) / 12500000) ((-47089971 : ℝ) / 50000000) := rb_log (show RB ((9748139 : ℝ) / 25000000) ((9748139 : ℝ) / 25000000) ((9748139 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1681.1 cov_log_1681.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((63920603 : ℝ) / 100000000) ((63947133 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((2555227 : ℝ) / 4000000) ((63915661 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1677.1 cov_log_1678.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2471 : ℝ) / 50000000) ((33229 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((74873 : ℝ) / 100000000) ((3793 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((6675487 : ℝ) / 5000000)) - (z19)
  have h20 : RB z20 ((3335847 : ℝ) / 2500000) ((133434867 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((6675487 : ℝ) / 5000000) ((6675487 : ℝ) / 5000000) ((6675487 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1675487 : ℝ) / 5000000))
  have h21 : RB z21 ((99548579 : ℝ) / 25000000) ((199098631 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((1675487 : ℝ) / 5000000) ((1675487 : ℝ) / 5000000) ((1675487 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((138176993 : ℝ) / 100000000) ((27635547 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_1682.1 cov_log_1683.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46463189 : ℝ) / 50000000) ((93003159 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((6675487 : ℝ) / 5000000))
  have h24 : RB z24 ((3612553 : ℝ) / 12500000) ((14450213 : ℝ) / 50000000) := rb_log (show RB ((6675487 : ℝ) / 5000000) ((6675487 : ℝ) / 5000000) ((6675487 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1684.1 cov_log_1684.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((2000811 : ℝ) / 3125000) ((12820547 : ℝ) / 20000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((2555227 : ℝ) / 4000000) ((63915661 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1677.1 cov_log_1678.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((110291 : ℝ) / 100000000) ((11103 : ℝ) / 5000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((74873 : ℝ) / 100000000) ((3793 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((133657437 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((133581577 : ℝ) / 100000000) ((33395641 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((133657437 : ℝ) / 100000000) ((133657437 : ℝ) / 100000000) ((133657437 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((33657437 : ℝ) / 100000000))
  have h30 : RB z30 ((396885767 : ℝ) / 100000000) ((3968887 : ℝ) / 1000000) := rb_div_signed h29 (show RB ((33657437 : ℝ) / 100000000) ((33657437 : ℝ) / 100000000) ((33657437 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((137847831 : ℝ) / 100000000) ((137848573 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1685.1 cov_log_1686.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92705011 : ℝ) / 100000000) ((92781611 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((133657437 : ℝ) / 100000000))
  have h33 : RB z33 ((29010989 : ℝ) / 100000000) ((29010991 : ℝ) / 100000000) := rb_log (show RB ((133657437 : ℝ) / 100000000) ((133657437 : ℝ) / 100000000) ((133657437 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1687.1 cov_log_1687.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((3184701 : ℝ) / 5000000) ((31885311 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((2555227 : ℝ) / 4000000) ((63915661 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1677.1 cov_log_1678.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-221641 : ℝ) / 100000000) ((-110053 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((38722533 : ℝ) / 100000000)) ((-4127 : ℝ) / 6250000) ((-969 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((9748139 : ℝ) / 25000000)) ((2471 : ℝ) / 50000000) ((33229 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((6675487 : ℝ) / 5000000)) ((110291 : ℝ) / 100000000) ((11103 : ℝ) / 5000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((133657437 : ℝ) / 100000000)) ((-221641 : ℝ) / 100000000) ((-110053 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_93 {k A q d vp vm : ℝ}
    (hk : RB k ((13143 : ℝ) / 6400) ((1647 : ℝ) / 800))
    (hA : RB A ((13143 : ℝ) / 19543) ((1647 : ℝ) / 2447))
    (hq : RB q ((342037 : ℝ) / 12500000) ((2754269 : ℝ) / 100000000))
    (hd : RB d ((189421927 : ℝ) / 100000000) ((94744103 : ℝ) / 50000000))
    (hp : RB vp ((38722533 : ℝ) / 100000000) ((9748139 : ℝ) / 25000000))
    (hm : RB vm ((6675487 : ℝ) / 5000000) ((133657437 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((74873 : ℝ) / 100000000) ((3793 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((4996207 : ℝ) / 5000000) ((99925127 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((16800171 : ℝ) / 25000000) ((1050883 : ℝ) / 1562500) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((96009 : ℝ) / 50000000) ((195907 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99804093 : ℝ) / 100000000) ((49903991 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((15251861 : ℝ) / 25000000) ((61277467 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((30443963 : ℝ) / 50000000) ((15289951 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((54938603 : ℝ) / 50000000) ((55229761 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((4938603 : ℝ) / 50000000) ((5229761 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((4996207 : ℝ) / 5000000) ((99925127 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((16800171 : ℝ) / 25000000) ((1050883 : ℝ) / 1562500) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((28009 : ℝ) / 50000000) ((2841 : ℝ) / 5000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((4997159 : ℝ) / 5000000) ((49971991 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1675487 : ℝ) / 5000000) ((33657437 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((33490699 : ℝ) / 100000000) ((33638583 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((49943159 : ℝ) / 25000000) ((25102683 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((74943159 : ℝ) / 25000000) ((37602683 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((478033317 : ℝ) / 50000000) ((1012432059 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((8310577 : ℝ) / 25000000) ((4169827 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((13143 : ℝ) / 3200) ((1647 : ℝ) / 400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((140481 : ℝ) / 1250000) ((11340703 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((12842037 : ℝ) / 12500000) ((102754269 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((10937239 : ℝ) / 100000000) ((11038653 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((110937239 : ℝ) / 100000000) ((111038653 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((1476831 : ℝ) / 1562500) ((11866863 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((179036271 : ℝ) / 100000000) ((179890447 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((51698353 : ℝ) / 100000000) ((52116451 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((8979 : ℝ) / 6250000) ((9171 : ℝ) / 6250000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((6240829 : ℝ) / 6250000) ((6241021 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((4469339 : ℝ) / 2500000) ((17963201 : ℝ) / 10000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((189421927 : ℝ) / 50000000) ((94744103 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((10366289 : ℝ) / 100000000) ((1043803 : ℝ) / 10000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((19543 : ℝ) / 6400) ((2447 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((169453 : ℝ) / 5000000) ((1709139 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((7017483 : ℝ) / 100000000) ((7112833 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((107017483 : ℝ) / 100000000) ((107112833 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1023158447 : ℝ) / 100000000) ((1084444661 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((409449 : ℝ) / 20000000) ((2062973 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20409449 : ℝ) / 20000000) ((102062973 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33922859 : ℝ) / 100000000) ((8511699 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((528540653 : ℝ) / 50000000) ((1118491457 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((35825119 : ℝ) / 100000000) ((9558287 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((19543 : ℝ) / 6400) ((2447 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((110937239 : ℝ) / 50000000) ((111038653 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((494654471 : ℝ) / 50000000) ((41831627 : ℝ) / 4000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((43900481 : ℝ) / 2000000) ((1161231879 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((13148079 : ℝ) / 100000000) ((870933 : ℝ) / 6250000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-12680591 : ℝ) / 6250000) ((-197077169 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1688.1 cov_log_1689.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((647893 : ℝ) / 12500000) ((1043803 : ℝ) / 20000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-295975841 : ℝ) / 100000000) ((-295286149 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1690.1 cov_log_1691.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((2555227 : ℝ) / 4000000) ((63915661 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1677.1 cov_log_1678.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((65592477 : ℝ) / 50000000) ((2056037 : ℝ) / 1562500) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-164790887 : ℝ) / 100000000) ((-163699781 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3811037 : ℝ) / 100000000) ((291843 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((9967887 : ℝ) / 100000000) ((6517059 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-154823 : ℝ) / 100000) ((-150665663 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((110937239 : ℝ) / 100000000) ((111038653 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-12680591 : ℝ) / 6250000) ((-197077169 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-154823 : ℝ) / 100000) ((-150665663 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((71 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((7017483 : ℝ) / 100000000) ((7112833 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((169 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((107112833 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((71 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((169 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-169643091 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((71 : ℝ) / 25) + hfun ((169 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_36, cov_h_30]
  have hP : ((426262537 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((150665663 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((150665663 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((5875087 : ℝ) / 10000000) ≤ EP1038.Arc.sinc ((169 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((477 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2507 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2507 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2547 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2547 : ℝ) / 1000)) (lo := ((2507 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2587 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2587 : ℝ) / 1000)) (lo := ((2547 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2627 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2627 : ℝ) / 1000)) (lo := ((2587 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2667 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2667 : ℝ) / 1000)) (lo := ((2627 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2707 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2707 : ℝ) / 1000)) (lo := ((2667 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2747 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2747 : ℝ) / 1000)) (lo := ((2707 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2787 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2787 : ℝ) / 1000)) (lo := ((2747 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2827 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2827 : ℝ) / 1000)) (lo := ((2787 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((71 : ℝ) / 25)) (lo := ((2827 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_93 {k : ℝ} (hk : RB k ((13143 : ℝ) / 6400) ((1647 : ℝ) / 800)) :
    RB (k / (k + 1)) ((13143 : ℝ) / 19543) ((1647 : ℝ) / 2447) ∧
    RB (qa (r1A k)) ((342037 : ℝ) / 12500000) ((2754269 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((189421927 : ℝ) / 100000000) ((94744103 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((51339843 : ℝ) / 100000000) ((1647 : ℝ) / 3200) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((28661 : ℝ) / 16000) ((179260157 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((133839923 : ℝ) / 100000000) ((16736009 : ℝ) / 12500000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275261279 : ℝ) / 100000000) ((275309429 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((137630639 : ℝ) / 100000000) ((27530943 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((189421927 : ℝ) / 100000000) ((94744103 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((20739843 : ℝ) / 100000000) ((3339 : ℝ) / 16000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((16203 : ℝ) / 312500) ((1304297 : ℝ) / 25000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((342037 : ℝ) / 12500000) ((2754269 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((189421927 : ℝ) / 100000000) ((94744103 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((342037 : ℝ) / 12500000) ((2754269 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((13143 : ℝ) / 19543) ((1647 : ℝ) / 2447) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_93 {k : ℝ} (hk : RB k ((13143 : ℝ) / 6400) ((1647 : ℝ) / 800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_93 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_93 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((38722533 : ℝ) / 100000000)) (ph := ((9748139 : ℝ) / 25000000)) (ml := ((6675487 : ℝ) / 5000000)) (mh := ((133657437 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_93 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_94 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1647 : ℝ) / 2447) ((13209 : ℝ) / 19609))
    (hq : RB (qa a) ((2754267 : ℝ) / 100000000) ((693063 : ℝ) / 25000000))
    (hd : RB (D0a a) ((94677821 : ℝ) / 50000000) ((94710967 : ℝ) / 50000000))
    : certE k a ((38691821 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((19480577 : ℝ) / 50000000) ∧ 0 < certE k a ((133559067 : ℝ) / 100000000) ∧ certE k a ((66853239 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((75859 : ℝ) / 100000000) ((38427 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((38691821 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((38614967 : ℝ) / 100000000) ((19307981 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((38691821 : ℝ) / 100000000) ((38691821 : ℝ) / 100000000) ((38691821 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((61308179 : ℝ) / 100000000))
  have h3 : RB z3 ((62985017 : ℝ) / 100000000) ((62986641 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((61308179 : ℝ) / 100000000) ((61308179 : ℝ) / 100000000) ((61308179 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-46227333 : ℝ) / 100000000) ((-2889047 : ℝ) / 6250000) := rb_log h3 (by norm_num) cov_log_1692.1 cov_log_1693.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-15569811 : ℝ) / 50000000) ((-622249 : ℝ) / 2000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((38691821 : ℝ) / 100000000))
  have h6 : RB z6 ((-94954197 : ℝ) / 100000000) ((-18990839 : ℝ) / 20000000) := rb_log (show RB ((38691821 : ℝ) / 100000000) ((38691821 : ℝ) / 100000000) ((38691821 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1694.1 cov_log_1694.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63814573 : ℝ) / 100000000) ((63841747 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((15961419 : ℝ) / 25000000) ((63880681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1695.1 cov_log_1696.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-16527 : ℝ) / 25000000) ((-3929 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((75859 : ℝ) / 100000000) ((38427 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19480577 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((388843 : ℝ) / 1000000) ((7777059 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((19480577 : ℝ) / 50000000) ((19480577 : ℝ) / 50000000) ((19480577 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30519423 : ℝ) / 50000000))
  have h12 : RB z12 ((31852093 : ℝ) / 50000000) ((63705817 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((30519423 : ℝ) / 50000000) ((30519423 : ℝ) / 50000000) ((30519423 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-45091993 : ℝ) / 100000000) ((-4508943 : ℝ) / 10000000) := rb_log h12 (by norm_num) cov_log_1697.1 cov_log_1698.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-6074967 : ℝ) / 20000000) ((-303483 : ℝ) / 1000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19480577 : ℝ) / 50000000))
  have h15 : RB z15 ((-9426051 : ℝ) / 10000000) ((-23565127 : ℝ) / 25000000) := rb_log (show RB ((19480577 : ℝ) / 50000000) ((19480577 : ℝ) / 50000000) ((19480577 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1699.1 cov_log_1699.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((63885673 : ℝ) / 100000000) ((6391221 : ℝ) / 10000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((15961419 : ℝ) / 25000000) ((63880681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1695.1 cov_log_1696.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((39 : ℝ) / 781250) ((33267 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((75859 : ℝ) / 100000000) ((38427 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133559067 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((133482213 : ℝ) / 100000000) ((16685401 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((133559067 : ℝ) / 100000000) ((133559067 : ℝ) / 100000000) ((133559067 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33559067 : ℝ) / 100000000))
  have h21 : RB z21 ((397753051 : ℝ) / 100000000) ((397756017 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((33559067 : ℝ) / 100000000) ((33559067 : ℝ) / 100000000) ((33559067 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((27613223 : ℝ) / 20000000) ((138066863 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1700.1 cov_log_1701.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((9292803 : ℝ) / 10000000) ((46502249 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133559067 : ℝ) / 100000000))
  have h24 : RB z24 ((7234341 : ℝ) / 25000000) ((14468683 : ℝ) / 50000000) := rb_log (show RB ((133559067 : ℝ) / 100000000) ((133559067 : ℝ) / 100000000) ((133559067 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1702.1 cov_log_1702.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((7998833 : ℝ) / 12500000) ((32033567 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((15961419 : ℝ) / 25000000) ((63880681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1695.1 cov_log_1696.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((109983 : ℝ) / 100000000) ((110729 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((75859 : ℝ) / 100000000) ((38427 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((66853239 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((16703703 : ℝ) / 12500000) ((133630619 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((66853239 : ℝ) / 50000000) ((66853239 : ℝ) / 50000000) ((66853239 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((16853239 : ℝ) / 50000000))
  have h30 : RB z30 ((198225433 : ℝ) / 50000000) ((396453819 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((16853239 : ℝ) / 50000000) ((16853239 : ℝ) / 50000000) ((16853239 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((8608637 : ℝ) / 6250000) ((6886947 : ℝ) / 5000000) := rb_log h30 (by norm_num) cov_log_1703.1 cov_log_1704.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18541463 : ℝ) / 20000000) ((92783603 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((66853239 : ℝ) / 50000000))
  have h33 : RB z33 ((14523837 : ℝ) / 50000000) ((7261919 : ℝ) / 25000000) := rb_log (show RB ((66853239 : ℝ) / 50000000) ((66853239 : ℝ) / 50000000) ((66853239 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1705.1 cov_log_1705.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63659639 : ℝ) / 100000000) ((63735929 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((15961419 : ℝ) / 25000000) ((63880681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1695.1 cov_log_1696.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-110521 : ℝ) / 50000000) ((-109747 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((38691821 : ℝ) / 100000000)) ((-16527 : ℝ) / 25000000) ((-3929 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19480577 : ℝ) / 50000000)) ((39 : ℝ) / 781250) ((33267 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133559067 : ℝ) / 100000000)) ((109983 : ℝ) / 100000000) ((110729 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((66853239 : ℝ) / 50000000)) ((-110521 : ℝ) / 50000000) ((-109747 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_94 {k A q d vp vm : ℝ}
    (hk : RB k ((1647 : ℝ) / 800) ((13209 : ℝ) / 6400))
    (hA : RB A ((1647 : ℝ) / 2447) ((13209 : ℝ) / 19609))
    (hq : RB q ((2754267 : ℝ) / 100000000) ((693063 : ℝ) / 25000000))
    (hd : RB d ((94677821 : ℝ) / 50000000) ((94710967 : ℝ) / 50000000))
    (hp : RB vp ((38691821 : ℝ) / 100000000) ((19480577 : ℝ) / 50000000))
    (hm : RB vm ((133559067 : ℝ) / 100000000) ((66853239 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((75859 : ℝ) / 100000000) ((38427 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49961573 : ℝ) / 50000000) ((99924141 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((33627589 : ℝ) / 50000000) ((33655413 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((12169 : ℝ) / 6250000) ((24829 : ℝ) / 12500000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((12475171 : ℝ) / 12500000) ((6237831 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30519423 : ℝ) / 50000000) ((61308179 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((60917603 : ℝ) / 100000000) ((6118881 : ℝ) / 10000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((54957089 : ℝ) / 50000000) ((11049487 : ℝ) / 10000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((4957089 : ℝ) / 50000000) ((1049487 : ℝ) / 10000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49961573 : ℝ) / 50000000) ((99924141 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((33627589 : ℝ) / 50000000) ((33655413 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((11347 : ℝ) / 20000000) ((7193 : ℝ) / 12500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((12492807 : ℝ) / 12500000) ((19988653 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33559067 : ℝ) / 100000000) ((16853239 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((6707951 : ℝ) / 20000000) ((6737471 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((49911293 : ℝ) / 25000000) ((100344839 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((74911293 : ℝ) / 25000000) ((150344839 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((190569297 : ℝ) / 20000000) ((252164123 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16628439 : ℝ) / 50000000) ((16686403 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1647 : ℝ) / 400) ((13209 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((5670347 : ℝ) / 50000000) ((11443337 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102754267 : ℝ) / 100000000) ((25693063 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5517391 : ℝ) / 50000000) ((5568303 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((55517391 : ℝ) / 50000000) ((55568303 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((94597913 : ℝ) / 100000000) ((95014657 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((35825297 : ℝ) / 20000000) ((179978601 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((10335287 : ℝ) / 20000000) ((52093587 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((7281 : ℝ) / 5000000) ((74361 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49925639 : ℝ) / 50000000) ((4992719 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((44715021 : ℝ) / 25000000) ((179716517 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((94677821 : ℝ) / 25000000) ((94710967 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((10430719 : ℝ) / 100000000) ((10502507 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((2447 : ℝ) / 800) ((19609 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((680877 : ℝ) / 20000000) ((686719 : ℝ) / 20000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((441829 : ℝ) / 6250000) ((7164957 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((6691829 : ℝ) / 6250000) ((107164957 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((510102859 : ℝ) / 50000000) ((135115787 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((411987 : ℝ) / 20000000) ((83027 : ℝ) / 4000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20411987 : ℝ) / 20000000) ((4083027 : ℝ) / 4000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((8485487 : ℝ) / 25000000) ((34065517 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((527073833 : ℝ) / 50000000) ((1114991813 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((7177449 : ℝ) / 20000000) ((2392769 : ℝ) / 6250000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((2447 : ℝ) / 800) ((19609 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((55517391 : ℝ) / 25000000) ((55568303 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((986103363 : ℝ) / 100000000) ((521014649 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1094917719 : ℝ) / 50000000) ((2316151991 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((13206171 : ℝ) / 100000000) ((13991491 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-1012243 : ℝ) / 500000) ((-98336041 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1706.1 cov_log_1707.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((5215359 : ℝ) / 100000000) ((2625627 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-29535623 : ℝ) / 10000000) ((-294670327 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1708.1 cov_log_1709.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((15961419 : ℝ) / 25000000) ((63880681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1695.1 cov_log_1696.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((26288457 : ℝ) / 20000000) ((131843737 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-32782789 : ℝ) / 20000000) ((-16282659 : ℝ) / 10000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((372653 : ℝ) / 10000000) ((1145741 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1216729 : ℝ) / 12500000) ((6385227 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-154180113 : ℝ) / 100000000) ((-18757017 : ℝ) / 12500000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((55517391 : ℝ) / 50000000) ((55568303 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-1012243 : ℝ) / 500000) ((-98336041 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-154180113 : ℝ) / 100000000) ((-18757017 : ℝ) / 12500000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((283 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((441829 : ℝ) / 6250000) ((7164957 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((169 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((107164957 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((283 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((169 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-84489709 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((283 : ℝ) / 100) + hfun ((169 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_37, cov_h_30]
  have hP : ((42416389 : ℝ) / 10000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((18757017 : ℝ) / 12500000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((18757017 : ℝ) / 12500000))
    linarith [hap.2]
  have hS : ((5875087 : ℝ) / 10000000) ≤ EP1038.Arc.sinc ((169 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((477 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((501 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((501 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((509 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((509 : ℝ) / 200)) (lo := ((501 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((517 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((517 : ℝ) / 200)) (lo := ((509 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((21 : ℝ) / 8) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((21 : ℝ) / 8)) (lo := ((517 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((533 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((533 : ℝ) / 200)) (lo := ((21 : ℝ) / 8)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((541 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((541 : ℝ) / 200)) (lo := ((533 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((549 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((549 : ℝ) / 200)) (lo := ((541 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((557 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((557 : ℝ) / 200)) (lo := ((549 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((113 : ℝ) / 40) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((113 : ℝ) / 40)) (lo := ((557 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((113 : ℝ) / 40)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_94 {k : ℝ} (hk : RB k ((1647 : ℝ) / 800) ((13209 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((1647 : ℝ) / 2447) ((13209 : ℝ) / 19609) ∧
    RB (qa (r1A k)) ((2754267 : ℝ) / 100000000) ((693063 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((94677821 : ℝ) / 50000000) ((94710967 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((1647 : ℝ) / 3200) ((51597657 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((179002343 : ℝ) / 100000000) ((28661 : ℝ) / 16000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((133791757 : ℝ) / 100000000) ((33459981 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275213113 : ℝ) / 100000000) ((275261281 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((34401639 : ℝ) / 25000000) ((137630641 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((94677821 : ℝ) / 50000000) ((94710967 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3339 : ℝ) / 16000) ((20997657 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((5217187 : ℝ) / 100000000) ((1049883 : ℝ) / 20000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((2754267 : ℝ) / 100000000) ((693063 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((94677821 : ℝ) / 50000000) ((94710967 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((2754267 : ℝ) / 100000000) ((693063 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1647 : ℝ) / 2447) ((13209 : ℝ) / 19609) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_94 {k : ℝ} (hk : RB k ((1647 : ℝ) / 800) ((13209 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_94 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_94 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((38691821 : ℝ) / 100000000)) (ph := ((19480577 : ℝ) / 50000000)) (ml := ((133559067 : ℝ) / 100000000)) (mh := ((66853239 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_94 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
