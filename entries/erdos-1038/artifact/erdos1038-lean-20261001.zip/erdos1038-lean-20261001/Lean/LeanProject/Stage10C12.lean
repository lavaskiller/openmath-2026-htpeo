import LeanProject.Stage10C11

/-!
# EP-1038, Stage 10, Lemma 10.13(4) and Theorem 10.14 (convex supporting inequality)

For `T₀` strictly separated at `r` (`a₀ ≤ T₀ ≤ 2`, `r < a₀`) and `T` with `a₁ ≤ T ≤ 2`:
* `hlin_seg`, `hD_seg`: the two hypotheses of `implicit_root_deriv` for `Ω(x,s) = W_{T_s}(x)`;
* `xp_deriv`, `xm_deriv`: `x±(s)` have right derivatives `-D±/L±` at `0`, with
  `D± = ∫ (T - T₀)/(T₀ - x±)` and `L± = W_{T₀}'(x±) = k G_{T₀}(x±)` (**Lemma 10.13(4)**);
* `wser_deriv`: `s ↦ M_k(T_s)` has right derivative `Ṁ = -D₊/L₊ + D₋/L₋` at `0`;
* `convex_supporting` (**Theorem 10.14**): if the width series of `T` converges (e.g. `T` admissible),
  `M_k(T) ≥ M_k(T₀) + Ṁ`.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

/-- `G_S` is continuous at every real `y < a`, `y ≠ 0`. -/
theorem GS_continuousAt {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a)
    (hSa : ∀ u, a ≤ S u) (hS2 : ∀ u, S u ≤ 2) {y : ℝ} (hy : y < a) (hy0 : y ≠ 0) :
    ContinuousAt (GS k S) y := by
  have hJ := (hasDerivAt_JS hSm ha hSa hS2 hy).continuousAt
  exact (continuousAt_const.div continuousAt_id hy0).sub (continuousAt_const.mul hJ)

/-- If a right derivative exists and all right slopes on `(0, 1]` are `≤ C`, then it is `≤ C`. -/
theorem deriv_le_of_slope {f : ℝ → ℝ} {D C : ℝ} (hf : HasDerivWithinAt f D (Ici 0) 0)
    (hsl : ∀ s, 0 < s → s ≤ 1 → (f s - f 0) / s ≤ C) : D ≤ C := by
  have e : (Ici (0 : ℝ) \ {0}) = Ioi 0 := by
    ext x
    simp only [mem_diff, mem_Ici, mem_singleton_iff, mem_Ioi]
    constructor
    · rintro ⟨h1, h2⟩; exact lt_of_le_of_ne h1 (Ne.symm h2)
    · intro h; exact ⟨h.le, h.ne'⟩
  rw [hasDerivWithinAt_iff_tendsto_slope, e] at hf
  refine le_of_tendsto hf ?_
  filter_upwards [self_mem_nhdsWithin, Ioo_mem_nhdsGT (zero_lt_one' ℝ)] with s hs1 hs2
  rw [slope_def_field, sub_zero]
  exact hsl s hs1 hs2.2.le

section seg

variable {T0 T : ℝ → ℝ} {a0 a1 k r : ℝ} (hm0 : Measurable T0) (hm1 : Measurable T)
  (ha0 : 0 < a0) (h0a : ∀ u, a0 ≤ T0 u) (h02 : ∀ u, T0 u ≤ 2) (ha1 : 0 < a1) (h1a : ∀ u, a1 ≤ T u)
  (h12 : ∀ u, T u ≤ 2) (hk : 0 < k) (hr0 : 0 < r) (hra : r < a0)
include hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hra

/-- Approximate linearity of `W_{T_s}` near `x₀` (uniformly for small `s`), slope `k G_{T₀}(x₀)`. -/
theorem hlin_seg {x0 : ℝ} (hx0 : x0 ≠ 0) (hx0a : x0 < (r + a0) / 2) :
    ∀ η > 0, ∃ ε > 0, ∀ᶠ s in 𝓝[Ici 0] (0 : ℝ), ∀ x ∈ Icc (x0 - ε) (x0 + ε),
      |WS k (Seg T0 T s) x - WS k (Seg T0 T s) x0 - k * GS k T0 x0 * (x - x0)| ≤ η * |x - x0| := by
  intro η hη
  have hT1 := h1nn hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hra
  set a' := (r + a0) / 2 with ha'def
  have ha' : 0 < a' := by linarith
  have ha'0 : a' < a0 := by linarith
  have h0a' : ∀ u, a' ≤ T0 u := fun u => by linarith [h0a u]
  -- continuity of `k G_{T₀}` at `x₀`
  have hGc := (GS_continuousAt (k := k) hm0 ha' h0a' h02 hx0a hx0).const_mul k
  obtain ⟨ε1, hε1, hball⟩ := Metric.continuousAt_iff.mp hGc (η / 2) (by positivity)
  have habs0 : 0 < |x0| := abs_pos.mpr hx0
  set ε := min (ε1 / 2) (min (|x0| / 2) ((a' - x0) / 2)) with hεdef
  have hε : 0 < ε := lt_min (by linarith) (lt_min (by linarith) (by linarith))
  have hε1' : ε ≤ ε1 / 2 := min_le_left _ _
  have hε2 : ε ≤ |x0| / 2 := (min_le_right _ _).trans (min_le_left _ _)
  have hε3 : ε ≤ (a' - x0) / 2 := (min_le_right _ _).trans (min_le_right _ _)
  set m := (a' - x0) / 2 with hm
  have hmpos : 0 < m := by linarith
  refine ⟨ε, hε, ?_⟩
  have hsmall : ∀ᶠ s in 𝓝[Ici 0] (0 : ℝ), 0 ≤ s ∧ s < min ((a0 - a') / 2) (η * m ^ 2 / 4) := by
    filter_upwards [self_mem_nhdsWithin, nhdsWithin_le_nhds (Iio_mem_nhds
      (show (0 : ℝ) < min ((a0 - a') / 2) (η * m ^ 2 / 4) from lt_min (by linarith) (by positivity)))]
      with s h1 h2
    exact ⟨h1, h2⟩
  filter_upwards [hsmall] with s ⟨hs0, hs⟩
  have hsδ : s ≤ (a0 - a') / 2 := (lt_of_lt_of_le hs (min_le_left _ _)).le
  have hsη : s < η * m ^ 2 / 4 := lt_of_lt_of_le hs (min_le_right _ _)
  have hs1 : s ≤ 1 := by linarith [h02 0, h0a 0]
  have hSm := Seg_measurable hm0 hm1 s
  have hSa := Seg_lower h0a h02 hT1 h12 ha' ha'0 hs0 hsδ
  have hS2 := Seg_upper h0a h02 hT1 h12 ha' ha'0 hs0 hs1
  intro x hx
  -- the MVT on `g ξ = W_{T_s}(ξ) - L ξ`
  set L := k * GS k T0 x0
  have hmem : ∀ ξ ∈ Icc (x0 - ε) (x0 + ε), ξ < a' ∧ ξ ≠ 0 ∧ m ≤ a' - ξ ∧ dist ξ x0 < ε1 := by
    intro ξ hξ
    have h1 := hξ.1; have h2 := hξ.2
    refine ⟨by linarith, ?_, by linarith, ?_⟩
    · intro h
      rw [h] at h1 h2
      rcases lt_or_gt_of_ne hx0 with hn | hp
      · rw [abs_of_neg hn] at hε2; linarith
      · rw [abs_of_pos hp] at hε2; linarith
    · rw [Real.dist_eq, abs_lt]; constructor <;> linarith
  have hderiv : ∀ ξ ∈ Icc (x0 - ε) (x0 + ε),
      HasDerivWithinAt (fun z => WS k (Seg T0 T s) z - L * z) (k * GS k (Seg T0 T s) ξ - L)
        (Icc (x0 - ε) (x0 + ε)) ξ := by
    intro ξ hξ
    obtain ⟨h1, h2, -, -⟩ := hmem ξ hξ
    have := (hasDerivAt_WS hSm ha' hSa hS2 hk h1 h2).sub ((hasDerivAt_id' ξ).const_mul L)
    exact (this.congr_deriv (by ring)).hasDerivWithinAt
  have hbound : ∀ ξ ∈ Icc (x0 - ε) (x0 + ε), ‖k * GS k (Seg T0 T s) ξ - L‖ ≤ η := by
    intro ξ hξ
    obtain ⟨h1, h2, h3, h4⟩ := hmem ξ hξ
    have hc := hball h4
    rw [Real.dist_eq] at hc
    have hJ := JS_seg_close hm0 hm1 h0a h02 hT1 h12 ha' ha'0 hs0 hsδ h1
    have hJ' : 2 * s / (a' - ξ) ^ 2 ≤ η / 2 := by
      rw [div_le_iff₀ (by positivity)]
      have : m ^ 2 ≤ (a' - ξ) ^ 2 := pow_le_pow_left₀ hmpos.le h3 2
      nlinarith
    have e1 : k * GS k (Seg T0 T s) ξ - L = (k * GS k T0 ξ - L) - (JS (Seg T0 T s) ξ - JS T0 ξ) := by
      simp only [GS, L]; field_simp; ring
    rw [Real.norm_eq_abs, e1]
    calc |k * GS k T0 ξ - L - (JS (Seg T0 T s) ξ - JS T0 ξ)|
        ≤ |k * GS k T0 ξ - L| + |JS (Seg T0 T s) ξ - JS T0 ξ| := abs_sub _ _
      _ ≤ η / 2 + η / 2 := add_le_add hc.le (hJ.trans hJ')
      _ = η := by ring
  have hx0mem : x0 ∈ Icc (x0 - ε) (x0 + ε) := ⟨by linarith, by linarith⟩
  have := (convex_Icc (x0 - ε) (x0 + ε)).norm_image_sub_le_of_norm_hasDerivWithin_le hderiv hbound
    hx0mem hx
  simp only [Real.norm_eq_abs] at this
  calc |WS k (Seg T0 T s) x - WS k (Seg T0 T s) x0 - L * (x - x0)|
      = |WS k (Seg T0 T s) x - L * x - (WS k (Seg T0 T s) x0 - L * x0)| := by ring_nf
    _ ≤ η * |x - x0| := this

/-- The right derivative of `s ↦ W_{T_s}(x₀)` at `0`: `∫ (T - T₀)/(T₀ - x₀)`. -/
theorem hD_seg {x0 : ℝ} (hx0a : x0 < (r + a0) / 2) :
    HasDerivWithinAt (fun s => WS k (Seg T0 T s) x0)
      (∫ u in (0 : ℝ)..1, (T u - T0 u) / (T0 u - x0)) (Ici 0) 0 := by
  have hT1 := h1nn hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hra
  set a' := (r + a0) / 2 with ha'def
  have ha' : 0 < a' := by linarith
  have ha'0 : a' < a0 := by linarith
  have h0a' : ∀ u, a' ≤ T0 u := fun u => by linarith [h0a u]
  set ρ := (a0 - a') / 4 with hρ
  have hρ0 : 0 < ρ := by linarith
  have hax : 0 < a' - x0 := by linarith
  -- lower bound for `T_s - x₀` on the ball
  have hlow : ∀ s ∈ Metric.ball (0 : ℝ) ρ, ∀ u, a' - x0 ≤ Seg T0 T s u - x0 := by
    intro s hs u
    rw [Metric.mem_ball, Real.dist_eq, sub_zero] at hs
    have e : Seg T0 T s u - x0 = T0 u - x0 + s * (T u - T0 u) := by unfold Seg; ring
    have hd : |T u - T0 u| ≤ 2 := by
      rw [abs_le]; constructor <;> linarith [h0a u, h02 u, h12 u, hT1 u]
    have hp : |s * (T u - T0 u)| ≤ 2 * ρ := by
      rw [abs_mul]
      calc |s| * |T u - T0 u| ≤ ρ * 2 :=
            mul_le_mul hs.le hd (abs_nonneg _) hρ0.le
        _ = 2 * ρ := by ring
    rw [e]
    have := (abs_le.mp hp).1
    have := h0a u
    linarith
  have key := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (F := fun s u => Real.log (Seg T0 T s u - x0))
    (F' := fun s u => (T u - T0 u) / (Seg T0 T s u - x0))
    (bound := fun _ => 2 / (a' - x0)) (a := 0) (b := 1) (μ := volume) (x₀ := (0 : ℝ))
    (Metric.ball_mem_nhds 0 hρ0)
    (Eventually.of_forall fun s =>
      (Real.measurable_log.comp ((Seg_measurable hm0 hm1 s).sub_const x0)).aestronglyMeasurable)
    (by
      have := ii_log hm0 ha' h0a' h02 hx0a
      refine this.congr fun u _ => ?_
      simp [Seg])
    (((hm1.sub hm0).div ((Seg_measurable hm0 hm1 0).sub_const x0)).aestronglyMeasurable)
    (Eventually.of_forall fun u _ s hs => by
      have hl := hlow s hs u
      have hpos : 0 < Seg T0 T s u - x0 := lt_of_lt_of_le hax hl
      rw [Real.norm_eq_abs, abs_div, abs_of_pos hpos]
      have hnum : |T u - T0 u| ≤ 2 := by
        rw [abs_le]; constructor <;> linarith [h0a u, h02 u, h12 u, hT1 u]
      rw [div_le_div_iff₀ hpos hax]
      nlinarith [abs_nonneg (T u - T0 u)])
    intervalIntegrable_const
    (Eventually.of_forall fun u _ s hs => by
      have hl := hlow s hs u
      have hpos : 0 < Seg T0 T s u - x0 := lt_of_lt_of_le hax hl
      have hlin : HasDerivAt (fun s => Seg T0 T s u - x0) (T u - T0 u) s := by
        have := (((hasDerivAt_id' s).const_mul (T u - T0 u)).const_add (T0 u - x0))
        refine this.congr_of_eventuallyEq (Eventually.of_forall fun z => ?_) |>.congr_deriv (by ring)
        simp only [Seg]; ring
      exact (hlin.log hpos.ne').congr_deriv (by ring))
  have e1 : (fun s => WS k (Seg T0 T s) x0) =
      fun s => k * Real.log x0 + ∫ u in (0 : ℝ)..1, Real.log (Seg T0 T s u - x0) := by
    funext s; rw [WS_eq_LS]; rfl
  have e2 : (∫ u in (0 : ℝ)..1, (T u - T0 u) / (Seg T0 T 0 u - x0)) =
      ∫ u in (0 : ℝ)..1, (T u - T0 u) / (T0 u - x0) := by
    refine intervalIntegral.integral_congr fun u _ => ?_
    simp [Seg]
  rw [e1, ← e2]
  exact (key.2.const_add _).hasDerivWithinAt

end seg

end EP1038.Stage10
