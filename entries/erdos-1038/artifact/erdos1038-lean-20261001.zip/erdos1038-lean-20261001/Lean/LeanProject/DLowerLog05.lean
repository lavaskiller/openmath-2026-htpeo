import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog02
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_300 : RB (Real.log ((1696569 : ℝ) / 1600000)) ((58604347141 : ℝ) / 1000000000000) ((29302173571 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1696569 : ℝ) / 1600000)) (t := ((96569 : ℝ) / 3296569))
    (lo := ((58604347141 : ℝ) / 1000000000000)) (hi := ((29302173571 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_301 : RB (Real.log ((59204999999 : ℝ) / 1000000000000)) ((-2826749281217 : ℝ) / 1000000000000) ((-565349856243 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((59204999999 : ℝ) / 62500000000)) (t := ((-3295000001 : ℝ) / 121704999999))
    (lo := ((-54160558977 : ℝ) / 1000000000000)) (hi := ((-423129367 : ℝ) / 7812500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((59204999999 : ℝ) / 1000000000000) = Real.log ((59204999999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((59204999999 : ℝ) / 1000000000000) = ((59204999999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_302 : RB (Real.log ((96569 : ℝ) / 1600000)) ((-1403750564743 : ℝ) / 500000000000) ((-701875282371 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((96569 : ℝ) / 100000)) (t := ((-3431 : ℝ) / 196569))
    (lo := ((-17456203623 : ℝ) / 500000000000)) (hi := ((-6982481449 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((96569 : ℝ) / 1600000) = Real.log ((96569 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((96569 : ℝ) / 1600000) = ((96569 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_303 : RB (Real.log ((649560839263 : ℝ) / 1000000000000)) ((-215729388169 : ℝ) / 500000000000) ((-26966173521 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((649560839263 : ℝ) / 500000000000)) (t := ((149560839263 : ℝ) / 1149560839263))
    (lo := ((130844202111 : ℝ) / 500000000000)) (hi := ((261688404223 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((649560839263 : ℝ) / 1000000000000) = Real.log ((649560839263 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((649560839263 : ℝ) / 1000000000000) = ((649560839263 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_304 : RB (Real.log ((129957719623 : ℝ) / 200000000000)) ((-215554101331 : ℝ) / 500000000000) ((-21555410133 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((129957719623 : ℝ) / 100000000000)) (t := ((29957719623 : ℝ) / 229957719623))
    (lo := ((131019488949 : ℝ) / 500000000000)) (hi := ((262038977899 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((129957719623 : ℝ) / 200000000000) = Real.log ((129957719623 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((129957719623 : ℝ) / 200000000000) = ((129957719623 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_305 : RB (Real.log ((197993194669 : ℝ) / 500000000000)) ((-926375438677 : ℝ) / 1000000000000) ((-37055017547 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((197993194669 : ℝ) / 250000000000)) (t := ((-52006805331 : ℝ) / 447993194669))
    (lo := ((-233228258117 : ℝ) / 1000000000000)) (hi := ((-58307064529 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197993194669 : ℝ) / 500000000000) = Real.log ((197993194669 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((197993194669 : ℝ) / 500000000000) = ((197993194669 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_306 : RB (Real.log ((3287858231407 : ℝ) / 1000000000000)) ((595118179647 : ℝ) / 500000000000) ((9298721557 : ℝ) / 7812500000) := by
  have hm := log_bounds_of_series (x := ((3287858231407 : ℝ) / 4000000000000)) (t := ((-712141768593 : ℝ) / 7287858231407))
    (lo := ((-7842320073 : ℝ) / 40000000000)) (hi := ((-6126812557 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3287858231407 : ℝ) / 1000000000000) = Real.log ((3287858231407 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3287858231407 : ℝ) / 1000000000000) = ((3287858231407 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_307 : RB (Real.log ((3288174121523 : ℝ) / 1000000000000)) ((595166216229 : ℝ) / 500000000000) ((59516621623 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((3288174121523 : ℝ) / 4000000000000)) (t := ((-711825878477 : ℝ) / 7288174121523))
    (lo := ((-195961928661 : ℝ) / 1000000000000)) (hi := ((-9798096433 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3288174121523 : ℝ) / 1000000000000) = Real.log ((3288174121523 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3288174121523 : ℝ) / 1000000000000) = ((3288174121523 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_308 : RB (Real.log ((1435497787779 : ℝ) / 1000000000000)) ((45188959937 : ℝ) / 125000000000) ((180755839749 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1435497787779 : ℝ) / 2000000000000)) (t := ((-564502212221 : ℝ) / 3435497787779))
    (lo := ((-331635501063 : ℝ) / 1000000000000)) (hi := ((-165817750531 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1435497787779 : ℝ) / 1000000000000) = Real.log ((1435497787779 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1435497787779 : ℝ) / 1000000000000) = ((1435497787779 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_309 : RB (Real.log ((1060355624999 : ℝ) / 1000000000000)) ((2930217357 : ℝ) / 50000000000) ((58604347141 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1060355624999 : ℝ) / 1000000000000)) (t := ((60355624999 : ℝ) / 2060355624999))
    (lo := ((2930217357 : ℝ) / 50000000000)) (hi := ((58604347141 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_310 : RB (Real.log ((169841 : ℝ) / 160000)) ((29844445019 : ℝ) / 500000000000) ((59688890039 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((169841 : ℝ) / 160000)) (t := ((9841 : ℝ) / 329841))
    (lo := ((29844445019 : ℝ) / 500000000000)) (hi := ((59688890039 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_311 : RB (Real.log ((60355624999 : ℝ) / 1000000000000)) ((-2807501129503 : ℝ) / 1000000000000) ((-2807501129501 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((60355624999 : ℝ) / 62500000000)) (t := ((-2144375001 : ℝ) / 122855624999))
    (lo := ((-34912407263 : ℝ) / 1000000000000)) (hi := ((-17456203631 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((60355624999 : ℝ) / 1000000000000) = Real.log ((60355624999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((60355624999 : ℝ) / 1000000000000) = ((60355624999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_312 : RB (Real.log ((9841 : ℝ) / 160000)) ((-1394308241659 : ℝ) / 500000000000) ((-697154120829 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((9841 : ℝ) / 10000)) (t := ((-159 : ℝ) / 19841))
    (lo := ((-8013880539 : ℝ) / 500000000000)) (hi := ((-16027761077 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9841 : ℝ) / 160000) = Real.log ((9841 : ℝ) / 10000) - 4 * Real.log 2 := by
    rw [show ((9841 : ℝ) / 160000) = ((9841 : ℝ) / 10000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_313 : RB (Real.log ((642237386751 : ℝ) / 1000000000000)) ((-442797282343 : ℝ) / 1000000000000) ((-442797282341 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((642237386751 : ℝ) / 500000000000)) (t := ((142237386751 : ℝ) / 1142237386751))
    (lo := ((250349898217 : ℝ) / 1000000000000)) (hi := ((125174949109 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((642237386751 : ℝ) / 1000000000000) = Real.log ((642237386751 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((642237386751 : ℝ) / 1000000000000) = ((642237386751 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_314 : RB (Real.log ((642468531303 : ℝ) / 1000000000000)) ((-44243744193 : ℝ) / 100000000000) ((-55304680241 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((642468531303 : ℝ) / 500000000000)) (t := ((142468531303 : ℝ) / 1142468531303))
    (lo := ((25070973863 : ℝ) / 100000000000)) (hi := ((250709738631 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((642468531303 : ℝ) / 1000000000000) = Real.log ((642468531303 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((642468531303 : ℝ) / 1000000000000) = ((642468531303 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_315 : RB (Real.log ((78675642237 : ℝ) / 200000000000)) ((-932983760467 : ℝ) / 1000000000000) ((-186596752093 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((78675642237 : ℝ) / 100000000000)) (t := ((-21324357763 : ℝ) / 178675642237))
    (lo := ((-239836579907 : ℝ) / 1000000000000)) (hi := ((-119918289953 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((78675642237 : ℝ) / 200000000000) = Real.log ((78675642237 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((78675642237 : ℝ) / 200000000000) = ((78675642237 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_316 : RB (Real.log ((3283887563521 : ℝ) / 1000000000000)) ((594513976671 : ℝ) / 500000000000) ((18578561771 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((3283887563521 : ℝ) / 4000000000000)) (t := ((-716112436479 : ℝ) / 7283887563521))
    (lo := ((-197266407777 : ℝ) / 1000000000000)) (hi := ((-6164575243 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3283887563521 : ℝ) / 1000000000000) = Real.log ((3283887563521 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3283887563521 : ℝ) / 1000000000000) = ((3283887563521 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_317 : RB (Real.log ((1642104510097 : ℝ) / 500000000000)) ((1189125837613 : ℝ) / 1000000000000) ((237825167523 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1642104510097 : ℝ) / 2000000000000)) (t := ((-357895489903 : ℝ) / 3642104510097))
    (lo := ((-98584261753 : ℝ) / 500000000000)) (hi := ((-39433704701 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1642104510097 : ℝ) / 500000000000) = Real.log ((1642104510097 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1642104510097 : ℝ) / 500000000000) = ((1642104510097 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_318 : RB (Real.log ((718096765603 : ℝ) / 500000000000)) ((361996232579 : ℝ) / 1000000000000) ((361996232581 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((718096765603 : ℝ) / 1000000000000)) (t := ((-281903234397 : ℝ) / 1718096765603))
    (lo := ((-16557547399 : ℝ) / 50000000000)) (hi := ((-331150947979 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((718096765603 : ℝ) / 500000000000) = Real.log ((718096765603 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((718096765603 : ℝ) / 500000000000) = ((718096765603 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_319 : RB (Real.log ((1061506249999 : ℝ) / 1000000000000)) ((59688890037 : ℝ) / 1000000000000) ((29844445019 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1061506249999 : ℝ) / 1000000000000)) (t := ((61506249999 : ℝ) / 2061506249999))
    (lo := ((59688890037 : ℝ) / 1000000000000)) (hi := ((29844445019 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_320 : RB (Real.log ((1700251 : ℝ) / 1600000)) ((7596532247 : ℝ) / 125000000000) ((60772257977 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1700251 : ℝ) / 1600000)) (t := ((100251 : ℝ) / 3300251))
    (lo := ((7596532247 : ℝ) / 125000000000)) (hi := ((60772257977 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_321 : RB (Real.log ((61506249999 : ℝ) / 1000000000000)) ((-1394308241667 : ℝ) / 500000000000) ((-697154120833 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((61506249999 : ℝ) / 62500000000)) (t := ((-993750001 : ℝ) / 124006249999))
    (lo := ((-8013880547 : ℝ) / 500000000000)) (hi := ((-16027761093 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61506249999 : ℝ) / 1000000000000) = Real.log ((61506249999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((61506249999 : ℝ) / 1000000000000) = ((61506249999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_322 : RB (Real.log ((100251 : ℝ) / 1600000)) ((-2770081867029 : ℝ) / 1000000000000) ((-2770081867027 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((100251 : ℝ) / 100000)) (t := ((251 : ℝ) / 200251))
    (lo := ((2506855211 : ℝ) / 1000000000000)) (hi := ((626713803 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((100251 : ℝ) / 1600000) = Real.log ((100251 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((100251 : ℝ) / 1600000) = ((100251 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_323 : RB (Real.log ((634915376687 : ℝ) / 1000000000000)) ((-45426355403 : ℝ) / 100000000000) ((-113565888507 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((634915376687 : ℝ) / 500000000000)) (t := ((134915376687 : ℝ) / 1134915376687))
    (lo := ((23888362653 : ℝ) / 100000000000)) (hi := ((238883626531 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((634915376687 : ℝ) / 1000000000000) = Real.log ((634915376687 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((634915376687 : ℝ) / 1000000000000) = ((634915376687 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_324 : RB (Real.log ((158787467447 : ℝ) / 250000000000)) ((-453894292523 : ℝ) / 1000000000000) ((-453894292521 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((158787467447 : ℝ) / 125000000000)) (t := ((33787467447 : ℝ) / 283787467447))
    (lo := ((239252888037 : ℝ) / 1000000000000)) (hi := ((119626444019 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((158787467447 : ℝ) / 250000000000) = Real.log ((158787467447 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((158787467447 : ℝ) / 250000000000) = ((158787467447 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_325 : RB (Real.log ((195374411967 : ℝ) / 500000000000)) ((-939690319451 : ℝ) / 1000000000000) ((-939690319449 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((195374411967 : ℝ) / 250000000000)) (t := ((-54625588033 : ℝ) / 445374411967))
    (lo := ((-246543138891 : ℝ) / 1000000000000)) (hi := ((-24654313889 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195374411967 : ℝ) / 500000000000) = Real.log ((195374411967 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((195374411967 : ℝ) / 500000000000) = ((195374411967 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_326 : RB (Real.log ((3279870746263 : ℝ) / 1000000000000)) ((1187804014991 : ℝ) / 1000000000000) ((1187804014993 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3279870746263 : ℝ) / 4000000000000)) (t := ((-720129253737 : ℝ) / 7279870746263))
    (lo := ((-12405646633 : ℝ) / 62500000000)) (hi := ((-198490346127 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3279870746263 : ℝ) / 1000000000000) = Real.log ((3279870746263 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3279870746263 : ℝ) / 1000000000000) = ((3279870746263 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_327 : RB (Real.log ((3280197744203 : ℝ) / 1000000000000)) ((296975927111 : ℝ) / 250000000000) ((593951854223 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3280197744203 : ℝ) / 4000000000000)) (t := ((-719802255797 : ℝ) / 7280197744203))
    (lo := ((-7935626107 : ℝ) / 40000000000)) (hi := ((-99195326337 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3280197744203 : ℝ) / 1000000000000) = Real.log ((3280197744203 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3280197744203 : ℝ) / 1000000000000) = ((3280197744203 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_328 : RB (Real.log ((179612422527 : ℝ) / 125000000000)) ((362487583917 : ℝ) / 1000000000000) ((362487583919 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((179612422527 : ℝ) / 250000000000)) (t := ((-70387577473 : ℝ) / 429612422527))
    (lo := ((-165329798321 : ℝ) / 500000000000)) (hi := ((-330659596641 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((179612422527 : ℝ) / 125000000000) = Real.log ((179612422527 : ℝ) / 250000000000) + 1 * Real.log 2 := by
    rw [show ((179612422527 : ℝ) / 125000000000) = ((179612422527 : ℝ) / 250000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_329 : RB (Real.log ((1062656874999 : ℝ) / 1000000000000)) ((2430890319 : ℝ) / 40000000000) ((7596532247 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((1062656874999 : ℝ) / 1000000000000)) (t := ((62656874999 : ℝ) / 2062656874999))
    (lo := ((2430890319 : ℝ) / 40000000000)) (hi := ((7596532247 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_330 : RB (Real.log ((425523 : ℝ) / 400000)) ((30927226749 : ℝ) / 500000000000) ((61854453499 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((425523 : ℝ) / 400000)) (t := ((25523 : ℝ) / 825523))
    (lo := ((30927226749 : ℝ) / 500000000000)) (hi := ((61854453499 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_331 : RB (Real.log ((62656874999 : ℝ) / 1000000000000)) ((-554016373409 : ℝ) / 200000000000) ((-2770081867043 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((62656874999 : ℝ) / 62500000000)) (t := ((156874999 : ℝ) / 125156874999))
    (lo := ((501371039 : ℝ) / 200000000000)) (hi := ((626713799 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62656874999 : ℝ) / 1000000000000) = Real.log ((62656874999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((62656874999 : ℝ) / 1000000000000) = ((62656874999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_332 : RB (Real.log ((25523 : ℝ) / 400000)) ((-1375942270341 : ℝ) / 500000000000) ((-68797113517 : ℝ) / 25000000000) := by
  have hm := log_bounds_of_series (x := ((25523 : ℝ) / 25000)) (t := ((523 : ℝ) / 50523))
    (lo := ((10352090779 : ℝ) / 500000000000)) (hi := ((20704181559 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25523 : ℝ) / 400000) = Real.log ((25523 : ℝ) / 25000) - 4 * Real.log 2 := by
    rw [show ((25523 : ℝ) / 400000) = ((25523 : ℝ) / 25000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_333 : RB (Real.log ((627595225157 : ℝ) / 1000000000000)) ((-116464966563 : ℝ) / 250000000000) ((-372687893 : ℝ) / 800000000) := by
  have hm := log_bounds_of_series (x := ((627595225157 : ℝ) / 500000000000)) (t := ((127595225157 : ℝ) / 1127595225157))
    (lo := ((56821828577 : ℝ) / 250000000000)) (hi := ((227287314309 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((627595225157 : ℝ) / 1000000000000) = Real.log ((627595225157 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((627595225157 : ℝ) / 1000000000000) = ((627595225157 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_334 : RB (Real.log ((313916514869 : ℝ) / 500000000000)) ((-465481024079 : ℝ) / 1000000000000) ((-465481024077 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((313916514869 : ℝ) / 250000000000)) (t := ((63916514869 : ℝ) / 563916514869))
    (lo := ((227666156481 : ℝ) / 1000000000000)) (hi := ((113833078241 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((313916514869 : ℝ) / 500000000000) = Real.log ((313916514869 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((313916514869 : ℝ) / 500000000000) = ((313916514869 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_335 : RB (Real.log ((388098104769 : ℝ) / 1000000000000)) ((-946497123977 : ℝ) / 1000000000000) ((-37859884959 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((388098104769 : ℝ) / 500000000000)) (t := ((-111901895231 : ℝ) / 888098104769))
    (lo := ((-253349943417 : ℝ) / 1000000000000)) (hi := ((-31668742927 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((388098104769 : ℝ) / 1000000000000) = Real.log ((388098104769 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((388098104769 : ℝ) / 1000000000000) = ((388098104769 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_336 : RB (Real.log ((204738083309 : ℝ) / 62500000000)) ((1186564963119 : ℝ) / 1000000000000) ((1186564963121 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((204738083309 : ℝ) / 250000000000)) (t := ((-45261916691 : ℝ) / 454738083309))
    (lo := ((-99864699 : ℝ) / 500000000)) (hi := ((-199729397999 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((204738083309 : ℝ) / 62500000000) = Real.log ((204738083309 : ℝ) / 250000000000) + 2 * Real.log 2 := by
    rw [show ((204738083309 : ℝ) / 62500000000) = ((204738083309 : ℝ) / 250000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_337 : RB (Real.log ((3276141846751 : ℝ) / 1000000000000)) ((148333307977 : ℝ) / 125000000000) ((593333231909 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3276141846751 : ℝ) / 4000000000000)) (t := ((-723858153249 : ℝ) / 7276141846751))
    (lo := ((-199627897303 : ℝ) / 1000000000000)) (hi := ((-99813948651 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3276141846751 : ℝ) / 1000000000000) = Real.log ((3276141846751 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3276141846751 : ℝ) / 1000000000000) = ((3276141846751 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_338 : RB (Real.log ((1437615132571 : ℝ) / 1000000000000)) ((22686598919 : ℝ) / 62500000000) ((181492791353 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1437615132571 : ℝ) / 2000000000000)) (t := ((-562384867429 : ℝ) / 3437615132571))
    (lo := ((-66032319571 : ℝ) / 200000000000)) (hi := ((-165080798927 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1437615132571 : ℝ) / 1000000000000) = Real.log ((1437615132571 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1437615132571 : ℝ) / 1000000000000) = ((1437615132571 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_339 : RB (Real.log ((1063807499999 : ℝ) / 1000000000000)) ((61854453497 : ℝ) / 1000000000000) ((30927226749 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1063807499999 : ℝ) / 1000000000000)) (t := ((63807499999 : ℝ) / 2063807499999))
    (lo := ((61854453497 : ℝ) / 1000000000000)) (hi := ((30927226749 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_340 : RB (Real.log ((1703933 : ℝ) / 1600000)) ((62935479139 : ℝ) / 1000000000000) ((3146773957 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((1703933 : ℝ) / 1600000)) (t := ((103933 : ℝ) / 3303933))
    (lo := ((62935479139 : ℝ) / 1000000000000)) (hi := ((3146773957 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_341 : RB (Real.log ((63807499999 : ℝ) / 1000000000000)) ((-1375942270349 : ℝ) / 500000000000) ((-343985567587 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((63807499999 : ℝ) / 62500000000)) (t := ((1307499999 : ℝ) / 126307499999))
    (lo := ((10352090771 : ℝ) / 500000000000)) (hi := ((20704181543 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63807499999 : ℝ) / 1000000000000) = Real.log ((63807499999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((63807499999 : ℝ) / 1000000000000) = ((63807499999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_342 : RB (Real.log ((103933 : ℝ) / 1600000)) ((-1367006223731 : ℝ) / 500000000000) ((-136700622373 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((103933 : ℝ) / 100000)) (t := ((3933 : ℝ) / 203933))
    (lo := ((19288137389 : ℝ) / 500000000000)) (hi := ((38576274779 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((103933 : ℝ) / 1600000) = Real.log ((103933 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((103933 : ℝ) / 1600000) = ((103933 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_343 : RB (Real.log ((310138672991 : ℝ) / 500000000000)) ((-238794284369 : ℝ) / 500000000000) ((-14924642773 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((310138672991 : ℝ) / 250000000000)) (t := ((60138672991 : ℝ) / 560138672991))
    (lo := ((107779305911 : ℝ) / 500000000000)) (hi := ((215558611823 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((310138672991 : ℝ) / 500000000000) = Real.log ((310138672991 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((310138672991 : ℝ) / 500000000000) = ((310138672991 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_344 : RB (Real.log ((310259212529 : ℝ) / 500000000000)) ((-47719998089 : ℝ) / 100000000000) ((-59649997611 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((310259212529 : ℝ) / 250000000000)) (t := ((60259212529 : ℝ) / 560259212529))
    (lo := ((21594719967 : ℝ) / 100000000000)) (hi := ((215947199671 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((310259212529 : ℝ) / 500000000000) = Real.log ((310259212529 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((310259212529 : ℝ) / 500000000000) = ((310259212529 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_345 : RB (Real.log ((7708518613 : ℝ) / 20000000000)) ((-59587890177 : ℝ) / 62500000000) ((-95340624283 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((7708518613 : ℝ) / 10000000000)) (t := ((-2291481387 : ℝ) / 17708518613))
    (lo := ((-508318481 : ℝ) / 1953125000)) (hi := ((-260259062271 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7708518613 : ℝ) / 20000000000) = Real.log ((7708518613 : ℝ) / 10000000000) - 1 * Real.log 2 := by
    rw [show ((7708518613 : ℝ) / 20000000000) = ((7708518613 : ℝ) / 10000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_346 : RB (Real.log ((163585240771 : ℝ) / 50000000000)) ((1185311199333 : ℝ) / 1000000000000) ((237062239867 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((163585240771 : ℝ) / 200000000000)) (t := ((-36414759229 : ℝ) / 363585240771))
    (lo := ((-100491580893 : ℝ) / 500000000000)) (hi := ((-40196632357 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((163585240771 : ℝ) / 50000000000) = Real.log ((163585240771 : ℝ) / 200000000000) + 2 * Real.log 2 := by
    rw [show ((163585240771 : ℝ) / 50000000000) = ((163585240771 : ℝ) / 200000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_347 : RB (Real.log ((818010704897 : ℝ) / 250000000000)) ((47416580213 : ℝ) / 40000000000) ((1185414505327 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((818010704897 : ℝ) / 1000000000000)) (t := ((-181989295103 : ℝ) / 1818010704897))
    (lo := ((-100439927897 : ℝ) / 500000000000)) (hi := ((-200879855793 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((818010704897 : ℝ) / 250000000000) = Real.log ((818010704897 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((818010704897 : ℝ) / 250000000000) = ((818010704897 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_348 : RB (Real.log ((719170297839 : ℝ) / 500000000000)) ((2839766289 : ℝ) / 7812500000) ((181745042497 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((719170297839 : ℝ) / 1000000000000)) (t := ((-280829702161 : ℝ) / 1719170297839))
    (lo := ((-329657095567 : ℝ) / 1000000000000)) (hi := ((-164828547783 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((719170297839 : ℝ) / 500000000000) = Real.log ((719170297839 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((719170297839 : ℝ) / 500000000000) = ((719170297839 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_349 : RB (Real.log ((1064958124999 : ℝ) / 1000000000000)) ((31467739569 : ℝ) / 500000000000) ((62935479139 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1064958124999 : ℝ) / 1000000000000)) (t := ((64958124999 : ℝ) / 2064958124999))
    (lo := ((31467739569 : ℝ) / 500000000000)) (hi := ((62935479139 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_350 : RB (Real.log ((852887 : ℝ) / 800000)) ((2560613497 : ℝ) / 40000000000) ((32007668713 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((852887 : ℝ) / 800000)) (t := ((52887 : ℝ) / 1652887))
    (lo := ((2560613497 : ℝ) / 40000000000)) (hi := ((32007668713 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_351 : RB (Real.log ((64958124999 : ℝ) / 1000000000000)) ((-1367006223739 : ℝ) / 500000000000) ((-683503111869 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((64958124999 : ℝ) / 62500000000)) (t := ((2458124999 : ℝ) / 127458124999))
    (lo := ((19288137381 : ℝ) / 500000000000)) (hi := ((38576274763 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64958124999 : ℝ) / 1000000000000) = Real.log ((64958124999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((64958124999 : ℝ) / 1000000000000) = ((64958124999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_352 : RB (Real.log ((52887 : ℝ) / 800000)) ((-2716454165697 : ℝ) / 1000000000000) ((-543290833139 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((52887 : ℝ) / 50000)) (t := ((2887 : ℝ) / 102887))
    (lo := ((56134556543 : ℝ) / 1000000000000)) (hi := ((438551223 : ℝ) / 7812500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52887 : ℝ) / 800000) = Real.log ((52887 : ℝ) / 50000) - 4 * Real.log 2 := by
    rw [show ((52887 : ℝ) / 800000) = ((52887 : ℝ) / 50000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_353 : RB (Real.log ((612962152733 : ℝ) / 1000000000000)) ((-61181510751 : ℝ) / 125000000000) ((-244726043003 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((612962152733 : ℝ) / 500000000000)) (t := ((112962152733 : ℝ) / 1112962152733))
    (lo := ((25461886819 : ℝ) / 125000000000)) (hi := ((203695094553 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((612962152733 : ℝ) / 1000000000000) = Real.log ((612962152733 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((612962152733 : ℝ) / 1000000000000) = ((612962152733 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_354 : RB (Real.log ((153301617353 : ℝ) / 250000000000)) ((-489053581793 : ℝ) / 1000000000000) ((-489053581791 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((153301617353 : ℝ) / 125000000000)) (t := ((28301617353 : ℝ) / 278301617353))
    (lo := ((204093598767 : ℝ) / 1000000000000)) (hi := ((12755849923 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((153301617353 : ℝ) / 250000000000) = Real.log ((153301617353 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((153301617353 : ℝ) / 250000000000) = ((153301617353 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_355 : RB (Real.log ((95683044781 : ℝ) / 250000000000)) ((-960419805623 : ℝ) / 1000000000000) ((-960419805621 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((95683044781 : ℝ) / 125000000000)) (t := ((-29316955219 : ℝ) / 220683044781))
    (lo := ((-267272625063 : ℝ) / 1000000000000)) (hi := ((-133636312531 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95683044781 : ℝ) / 250000000000) = Real.log ((95683044781 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((95683044781 : ℝ) / 250000000000) = ((95683044781 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_356 : RB (Real.log ((3267558627687 : ℝ) / 1000000000000)) ((296010777257 : ℝ) / 250000000000) ((118404310903 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((3267558627687 : ℝ) / 4000000000000)) (t := ((-732441372313 : ℝ) / 7267558627687))
    (lo := ((-202251252091 : ℝ) / 1000000000000)) (hi := ((-20225125209 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3267558627687 : ℝ) / 1000000000000) = Real.log ((3267558627687 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3267558627687 : ℝ) / 1000000000000) = ((3267558627687 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_357 : RB (Real.log ((3267902096623 : ℝ) / 1000000000000)) ((592074109177 : ℝ) / 500000000000) ((296037054589 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3267902096623 : ℝ) / 4000000000000)) (t := ((-732097903377 : ℝ) / 7267902096623))
    (lo := ((-40429228553 : ℝ) / 200000000000)) (hi := ((-50536535691 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3267902096623 : ℝ) / 1000000000000) = Real.log ((3267902096623 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3267902096623 : ℝ) / 1000000000000) = ((3267902096623 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_358 : RB (Real.log ((143907558597 : ℝ) / 100000000000)) ((182000476629 : ℝ) / 500000000000) ((18200047663 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((143907558597 : ℝ) / 200000000000)) (t := ((-56092441403 : ℝ) / 343907558597))
    (lo := ((-329146227301 : ℝ) / 1000000000000)) (hi := ((-3291462273 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((143907558597 : ℝ) / 100000000000) = Real.log ((143907558597 : ℝ) / 200000000000) + 1 * Real.log 2 := by
    rw [show ((143907558597 : ℝ) / 100000000000) = ((143907558597 : ℝ) / 200000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_359 : RB (Real.log ((1066108749999 : ℝ) / 1000000000000)) ((4000958589 : ℝ) / 62500000000) ((2560613497 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((1066108749999 : ℝ) / 1000000000000)) (t := ((66108749999 : ℝ) / 2066108749999))
    (lo := ((4000958589 : ℝ) / 62500000000)) (hi := ((2560613497 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
