import LeanProject.DLowerMTools
import LeanProject.DLowerMLog07
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_400 : RB (Real.log ((11397218654045003 : ℝ) / 8000000000000000)) ((353927806237858619 : ℝ) / 1000000000000000000) ((353927806237858621 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((11397218654045003 : ℝ) / 16000000000000000)) (t := ((-4602781345954997 : ℝ) / 27397218654045003))
    (lo := ((-33921937432208669 : ℝ) / 100000000000000000)) (hi := ((-339219374322086689 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11397218654045003 : ℝ) / 8000000000000000) = Real.log ((11397218654045003 : ℝ) / 16000000000000000) + 1 * Real.log 2 := by
    rw [show ((11397218654045003 : ℝ) / 8000000000000000) = ((11397218654045003 : ℝ) / 16000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_401 : RB (Real.log ((178081541469453547 : ℝ) / 125000000000000000)) ((176963903118930363 : ℝ) / 500000000000000000) ((44240975779732591 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((178081541469453547 : ℝ) / 250000000000000000)) (t := ((-71918458530546453 : ℝ) / 428081541469453547))
    (lo := ((-339219374322084583 : ℝ) / 1000000000000000000)) (hi := ((-169609687161042291 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178081541469453547 : ℝ) / 125000000000000000) = Real.log ((178081541469453547 : ℝ) / 250000000000000000) + 1 * Real.log 2 := by
    rw [show ((178081541469453547 : ℝ) / 125000000000000000) = ((178081541469453547 : ℝ) / 250000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_402 : RB (Real.log ((53165129878877 : ℝ) / 125000000000000)) ((-213727752315691039 : ℝ) / 250000000000000000) ((-427455504631382077 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((53165129878877 : ℝ) / 62500000000000)) (t := ((-9334870121123 : ℝ) / 115665129878877))
    (lo := ((-80881914351409423 : ℝ) / 500000000000000000)) (hi := ((-32352765740563769 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53165129878877 : ℝ) / 125000000000000) = Real.log ((53165129878877 : ℝ) / 62500000000000) - 1 * Real.log 2 := by
    rw [show ((53165129878877 : ℝ) / 125000000000000) = ((53165129878877 : ℝ) / 62500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_403 : RB (Real.log ((425321039031019 : ℝ) / 1000000000000000)) ((-854911009262757103 : ℝ) / 1000000000000000000) ((-854911009262757101 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((425321039031019 : ℝ) / 500000000000000)) (t := ((-74678960968981 : ℝ) / 925321039031019))
    (lo := ((-161763828702811793 : ℝ) / 1000000000000000000)) (hi := ((-10110239293925737 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425321039031019 : ℝ) / 1000000000000000) = Real.log ((425321039031019 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425321039031019 : ℝ) / 1000000000000000) = ((425321039031019 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_404 : RB (Real.log ((178165129878877 : ℝ) / 125000000000000)) ((354397078894590683 : ℝ) / 1000000000000000000) ((70879415778918137 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((178165129878877 : ℝ) / 250000000000000)) (t := ((-71834870121123 : ℝ) / 428165129878877))
    (lo := ((-169375050832677313 : ℝ) / 500000000000000000)) (hi := ((-2710000813322837 : ℝ) / 8000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178165129878877 : ℝ) / 125000000000000) = Real.log ((178165129878877 : ℝ) / 250000000000000) + 1 * Real.log 2 := by
    rw [show ((178165129878877 : ℝ) / 125000000000000) = ((178165129878877 : ℝ) / 250000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_405 : RB (Real.log ((1425321039031019 : ℝ) / 1000000000000000)) ((88599269723648197 : ℝ) / 250000000000000000) ((35439707889459279 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425321039031019 : ℝ) / 2000000000000000)) (t := ((-574678960968981 : ℝ) / 3425321039031019))
    (lo := ((-338750101665352521 : ℝ) / 1000000000000000000)) (hi := ((-8468752541633813 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425321039031019 : ℝ) / 1000000000000000) = Real.log ((1425321039031019 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425321039031019 : ℝ) / 1000000000000000) = ((1425321039031019 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_406 : RB (Real.log ((44520385367363293 : ℝ) / 31250000000000000)) ((17696390311892931 : ℝ) / 50000000000000000) ((176963903118929311 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((44520385367363293 : ℝ) / 62500000000000000)) (t := ((-17979614632636707 : ℝ) / 107020385367363293))
    (lo := ((-339219374322086689 : ℝ) / 1000000000000000000)) (hi := ((-10600605447565209 : ℝ) / 31250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44520385367363293 : ℝ) / 31250000000000000) = Real.log ((44520385367363293 : ℝ) / 62500000000000000) + 1 * Real.log 2 := by
    rw [show ((44520385367363293 : ℝ) / 31250000000000000) = ((44520385367363293 : ℝ) / 62500000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_407 : RB (Real.log ((11397218654045027 : ℝ) / 8000000000000000)) ((14157112249514429 : ℝ) / 40000000000000000) ((353927806237860727 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((11397218654045027 : ℝ) / 16000000000000000)) (t := ((-4602781345954973 : ℝ) / 27397218654045027))
    (lo := ((-42402421790260573 : ℝ) / 125000000000000000)) (hi := ((-339219374322084583 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11397218654045027 : ℝ) / 8000000000000000) = Real.log ((11397218654045027 : ℝ) / 16000000000000000) + 1 * Real.log 2 := by
    rw [show ((11397218654045027 : ℝ) / 8000000000000000) = ((11397218654045027 : ℝ) / 16000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_408 : RB (Real.log ((458217377666561697 : ℝ) / 1000000000000000000)) ((-390205791870024551 : ℝ) / 500000000000000000) ((-7804115837400491 : ℝ) / 10000000000000000) := by
  have hm := log_bounds_of_series (x := ((458217377666561697 : ℝ) / 500000000000000000)) (t := ((-41782622333438303 : ℝ) / 958217377666561697))
    (lo := ((-5454025198756487 : ℝ) / 62500000000000000)) (hi := ((-87264403180103791 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458217377666561697 : ℝ) / 1000000000000000000) = Real.log ((458217377666561697 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458217377666561697 : ℝ) / 1000000000000000000) = ((458217377666561697 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_409 : RB (Real.log ((114644982006306841 : ℝ) / 250000000000000000)) ((-779620677450700829 : ℝ) / 1000000000000000000) ((-779620677450700827 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((114644982006306841 : ℝ) / 125000000000000000)) (t := ((-10355017993693159 : ℝ) / 239644982006306841))
    (lo := ((-86473496890755519 : ℝ) / 1000000000000000000)) (hi := ((-43236748445377759 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114644982006306841 : ℝ) / 250000000000000000) = Real.log ((114644982006306841 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((114644982006306841 : ℝ) / 250000000000000000) = ((114644982006306841 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_410 : RB (Real.log ((540755399123210137 : ℝ) / 1000000000000000000)) ((-153697057422468061 : ℝ) / 250000000000000000) ((-307394114844936121 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((540755399123210137 : ℝ) / 500000000000000000)) (t := ((40755399123210137 : ℝ) / 1040755399123210137))
    (lo := ((39179475435036533 : ℝ) / 500000000000000000)) (hi := ((78358950870073067 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540755399123210137 : ℝ) / 1000000000000000000) = Real.log ((540755399123210137 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((540755399123210137 : ℝ) / 1000000000000000000) = ((540755399123210137 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_411 : RB (Real.log ((541109868427188303 : ℝ) / 1000000000000000000)) ((-307066468392744231 : ℝ) / 500000000000000000) ((-30706646839274423 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((541109868427188303 : ℝ) / 500000000000000000)) (t := ((41109868427188303 : ℝ) / 1041109868427188303))
    (lo := ((4938390235903553 : ℝ) / 62500000000000000)) (hi := ((79014243774456849 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((541109868427188303 : ℝ) / 1000000000000000000) = Real.log ((541109868427188303 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((541109868427188303 : ℝ) / 1000000000000000000) = ((541109868427188303 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_412 : RB (Real.log ((458890131572811697 : ℝ) / 1000000000000000000)) ((-155788892467805149 : ℝ) / 200000000000000000) ((-778944462339025743 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458890131572811697 : ℝ) / 500000000000000000)) (t := ((-41109868427188303 : ℝ) / 958890131572811697))
    (lo := ((-17159456355816087 : ℝ) / 200000000000000000)) (hi := ((-42898640889540217 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458890131572811697 : ℝ) / 1000000000000000000) = Real.log ((458890131572811697 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458890131572811697 : ℝ) / 1000000000000000000) = ((458890131572811697 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_413 : RB (Real.log ((459244600876789863 : ℝ) / 1000000000000000000)) ((-155634462269681979 : ℝ) / 200000000000000000) ((-778172311348409893 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((459244600876789863 : ℝ) / 500000000000000000)) (t := ((-40755399123210137 : ℝ) / 959244600876789863))
    (lo := ((-17005026157692917 : ℝ) / 200000000000000000)) (hi := ((-10628141348558073 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459244600876789863 : ℝ) / 1000000000000000000) = Real.log ((459244600876789863 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((459244600876789863 : ℝ) / 1000000000000000000) = ((459244600876789863 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_414 : RB (Real.log ((28638839018588817 : ℝ) / 62500000000000000)) ((-780402752532006123 : ℝ) / 1000000000000000000) ((-780402752532006121 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28638839018588817 : ℝ) / 31250000000000000)) (t := ((-2611160981411183 : ℝ) / 59888839018588817))
    (lo := ((-87255571972060813 : ℝ) / 1000000000000000000)) (hi := ((-21813892993015203 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28638839018588817 : ℝ) / 62500000000000000) = Real.log ((28638839018588817 : ℝ) / 31250000000000000) - 1 * Real.log 2 := by
    rw [show ((28638839018588817 : ℝ) / 62500000000000000) = ((28638839018588817 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_415 : RB (Real.log ((458221424297421073 : ℝ) / 1000000000000000000)) ((-780402752532006121 : ℝ) / 1000000000000000000) ((-780402752532006119 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458221424297421073 : ℝ) / 500000000000000000)) (t := ((-41778575702578927 : ℝ) / 958221424297421073))
    (lo := ((-87255571972060811 : ℝ) / 1000000000000000000)) (hi := ((-8725557197206081 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458221424297421073 : ℝ) / 1000000000000000000) = Real.log ((458221424297421073 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458221424297421073 : ℝ) / 1000000000000000000) = ((458221424297421073 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_416 : RB (Real.log ((229112729360624599 : ℝ) / 500000000000000000)) ((-780393948041745077 : ℝ) / 1000000000000000000) ((-31215757921669803 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((229112729360624599 : ℝ) / 250000000000000000)) (t := ((-20887270639375401 : ℝ) / 479112729360624599))
    (lo := ((-87246767481799767 : ℝ) / 1000000000000000000)) (hi := ((-43623383740899883 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229112729360624599 : ℝ) / 500000000000000000) = Real.log ((229112729360624599 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229112729360624599 : ℝ) / 500000000000000000) = ((229112729360624599 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_417 : RB (Real.log ((229287946800699619 : ℝ) / 500000000000000000)) ((-779629475135310183 : ℝ) / 1000000000000000000) ((-779629475135310181 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229287946800699619 : ℝ) / 250000000000000000)) (t := ((-20712053199300381 : ℝ) / 479287946800699619))
    (lo := ((-86482294575364873 : ℝ) / 1000000000000000000)) (hi := ((-10810286821920609 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229287946800699619 : ℝ) / 500000000000000000) = Real.log ((229287946800699619 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229287946800699619 : ℝ) / 500000000000000000) = ((229287946800699619 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_418 : RB (Real.log ((458575893601399239 : ℝ) / 1000000000000000000)) ((-779629475135310181 : ℝ) / 1000000000000000000) ((-779629475135310179 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458575893601399239 : ℝ) / 500000000000000000)) (t := ((-41424106398600761 : ℝ) / 958575893601399239))
    (lo := ((-86482294575364871 : ℝ) / 1000000000000000000)) (hi := ((-8648229457536487 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458575893601399239 : ℝ) / 1000000000000000000) = Real.log ((458575893601399239 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458575893601399239 : ℝ) / 1000000000000000000) = ((458575893601399239 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_419 : RB (Real.log ((458571846970539863 : ℝ) / 1000000000000000000)) ((-779638299516989143 : ℝ) / 1000000000000000000) ((-779638299516989141 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458571846970539863 : ℝ) / 500000000000000000)) (t := ((-41428153029460137 : ℝ) / 958571846970539863))
    (lo := ((-86491118957043833 : ℝ) / 1000000000000000000)) (hi := ((-10811389869630479 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458571846970539863 : ℝ) / 1000000000000000000) = Real.log ((458571846970539863 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458571846970539863 : ℝ) / 1000000000000000000) = ((458571846970539863 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_420 : RB (Real.log ((712316615702956193 : ℝ) / 500000000000000000)) ((176957199561391861 : ℝ) / 500000000000000000) ((88478599780695931 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((712316615702956193 : ℝ) / 1000000000000000000)) (t := ((-287683384297043807 : ℝ) / 1712316615702956193))
    (lo := ((-339232781437161587 : ℝ) / 1000000000000000000)) (hi := ((-169616390718580793 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712316615702956193 : ℝ) / 500000000000000000) = Real.log ((712316615702956193 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712316615702956193 : ℝ) / 500000000000000000) = ((712316615702956193 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_421 : RB (Real.log ((1424671419898309683 : ℝ) / 1000000000000000000)) ((353941204604873609 : ℝ) / 1000000000000000000) ((353941204604873611 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424671419898309683 : ℝ) / 2000000000000000000)) (t := ((-575328580101690317 : ℝ) / 3424671419898309683))
    (lo := ((-3392059759550717 : ℝ) / 10000000000000000)) (hi := ((-339205975955071699 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424671419898309683 : ℝ) / 1000000000000000000) = Real.log ((1424671419898309683 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424671419898309683 : ℝ) / 1000000000000000000) = ((1424671419898309683 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_422 : RB (Real.log ((212652992656081193 : ℝ) / 500000000000000000)) ((-854946403668124859 : ℝ) / 1000000000000000000) ((-854946403668124857 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((212652992656081193 : ℝ) / 250000000000000000)) (t := ((-37347007343918807 : ℝ) / 462652992656081193))
    (lo := ((-161799223108179549 : ℝ) / 1000000000000000000)) (hi := ((-40449805777044887 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212652992656081193 : ℝ) / 500000000000000000) = Real.log ((212652992656081193 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((212652992656081193 : ℝ) / 500000000000000000) = ((212652992656081193 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_423 : RB (Real.log ((212668046374936091 : ℝ) / 500000000000000000)) ((-854875616110117007 : ℝ) / 1000000000000000000) ((-170975123222023401 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((212668046374936091 : ℝ) / 250000000000000000)) (t := ((-37331953625063909 : ℝ) / 462668046374936091))
    (lo := ((-161728435550171697 : ℝ) / 1000000000000000000)) (hi := ((-10108027221885731 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212668046374936091 : ℝ) / 500000000000000000) = Real.log ((212668046374936091 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((212668046374936091 : ℝ) / 500000000000000000) = ((212668046374936091 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_424 : RB (Real.log ((712652992656081193 : ℝ) / 500000000000000000)) ((44298314650627737 : ℝ) / 125000000000000000) ((177193258602510949 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((712652992656081193 : ℝ) / 1000000000000000000)) (t := ((-287347007343918807 : ℝ) / 1712652992656081193))
    (lo := ((-338760663354923413 : ℝ) / 1000000000000000000)) (hi := ((-84690165838730853 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712652992656081193 : ℝ) / 500000000000000000) = Real.log ((712652992656081193 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712652992656081193 : ℝ) / 500000000000000000) = ((712652992656081193 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_425 : RB (Real.log ((712668046374936091 : ℝ) / 500000000000000000)) ((354407640472613163 : ℝ) / 1000000000000000000) ((70881528094522633 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((712668046374936091 : ℝ) / 1000000000000000000)) (t := ((-287331953625063909 : ℝ) / 1712668046374936091))
    (lo := ((-169369770043666073 : ℝ) / 500000000000000000)) (hi := ((-67747908017466429 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712668046374936091 : ℝ) / 500000000000000000) = Real.log ((712668046374936091 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712668046374936091 : ℝ) / 500000000000000000) = ((712668046374936091 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_426 : RB (Real.log ((1424637278036771761 : ℝ) / 1000000000000000000)) ((88479309897697101 : ℝ) / 250000000000000000) ((176958619795394203 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424637278036771761 : ℝ) / 2000000000000000000)) (t := ((-575362721963228239 : ℝ) / 3424637278036771761))
    (lo := ((-67845988193831381 : ℝ) / 200000000000000000)) (hi := ((-42403742621144613 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424637278036771761 : ℝ) / 1000000000000000000) = Real.log ((1424637278036771761 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424637278036771761 : ℝ) / 1000000000000000000) = ((1424637278036771761 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_427 : RB (Real.log ((712318639018385881 : ℝ) / 500000000000000000)) ((88479309897697101 : ℝ) / 250000000000000000) ((176958619795394203 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((712318639018385881 : ℝ) / 1000000000000000000)) (t := ((-287681360981614119 : ℝ) / 1712318639018385881))
    (lo := ((-67845988193831381 : ℝ) / 200000000000000000)) (hi := ((-42403742621144613 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712318639018385881 : ℝ) / 500000000000000000) = Real.log ((712318639018385881 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712318639018385881 : ℝ) / 500000000000000000) = ((712318639018385881 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_428 : RB (Real.log ((1424641312460599887 : ℝ) / 1000000000000000000)) ((353920071482230387 : ℝ) / 1000000000000000000) ((353920071482230389 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424641312460599887 : ℝ) / 2000000000000000000)) (t := ((-575358687539400113 : ℝ) / 3424641312460599887))
    (lo := ((-169613554538857461 : ℝ) / 500000000000000000)) (hi := ((-339227109077714921 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424641312460599887 : ℝ) / 1000000000000000000) = Real.log ((1424641312460599887 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424641312460599887 : ℝ) / 1000000000000000000) = ((1424641312460599887 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_429 : RB (Real.log ((1424667385474481557 : ℝ) / 1000000000000000000)) ((353938372773277787 : ℝ) / 1000000000000000000) ((353938372773277789 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424667385474481557 : ℝ) / 2000000000000000000)) (t := ((-575332614525518443 : ℝ) / 3424667385474481557))
    (lo := ((-169604403893333761 : ℝ) / 500000000000000000)) (hi := ((-339208807786667521 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424667385474481557 : ℝ) / 1000000000000000000) = Real.log ((1424667385474481557 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424667385474481557 : ℝ) / 1000000000000000000) = ((1424667385474481557 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_430 : RB (Real.log ((712333692737240779 : ℝ) / 500000000000000000)) ((353938372773277787 : ℝ) / 1000000000000000000) ((353938372773277789 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712333692737240779 : ℝ) / 1000000000000000000)) (t := ((-287666307262759221 : ℝ) / 1712333692737240779))
    (lo := ((-169604403893333761 : ℝ) / 500000000000000000)) (hi := ((-339208807786667521 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712333692737240779 : ℝ) / 500000000000000000) = Real.log ((712333692737240779 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712333692737240779 : ℝ) / 500000000000000000) = ((712333692737240779 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_431 : RB (Real.log ((712331669421811091 : ℝ) / 500000000000000000)) ((88483883091325171 : ℝ) / 250000000000000000) ((176967766182650343 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((712331669421811091 : ℝ) / 1000000000000000000)) (t := ((-287668330578188909 : ℝ) / 1712331669421811091))
    (lo := ((-2713693185557157 : ℝ) / 8000000000000000)) (hi := ((-21200728012165289 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712331669421811091 : ℝ) / 500000000000000000) = Real.log ((712331669421811091 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712331669421811091 : ℝ) / 500000000000000000) = ((712331669421811091 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_432 : RB (Real.log ((26093749999999999 : ℝ) / 1000000000000000000)) ((-3646059456931008157 : ℝ) / 1000000000000000000) ((-729211891386201631 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((26093749999999999 : ℝ) / 31250000000000000)) (t := ((-5156250000000001 : ℝ) / 57343749999999999))
    (lo := ((-180323554131281609 : ℝ) / 1000000000000000000)) (hi := ((-22540444266410201 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((26093749999999999 : ℝ) / 1000000000000000000) = Real.log ((26093749999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((26093749999999999 : ℝ) / 1000000000000000000) = ((26093749999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_433 : RB (Real.log ((167 : ℝ) / 6400)) ((-3646059456931008119 : ℝ) / 1000000000000000000) ((-3646059456931008117 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((167 : ℝ) / 200)) (t := ((-33 : ℝ) / 367))
    (lo := ((-180323554131281571 : ℝ) / 1000000000000000000)) (hi := ((-18032355413128157 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((167 : ℝ) / 6400) = Real.log ((167 : ℝ) / 200) - 5 * Real.log 2 := by
    rw [show ((167 : ℝ) / 6400) = ((167 : ℝ) / 200) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_434 : RB (Real.log ((1026093749999999999 : ℝ) / 1000000000000000000)) ((5151823368641881 : ℝ) / 200000000000000000) ((12879558421604703 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1026093749999999999 : ℝ) / 1000000000000000000)) (t := ((26093749999999999 : ℝ) / 2026093749999999999))
    (lo := ((5151823368641881 : ℝ) / 200000000000000000)) (hi := ((12879558421604703 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_435 : RB (Real.log ((6567 : ℝ) / 6400)) ((12879558421604703 : ℝ) / 500000000000000000) ((25759116843209407 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((6567 : ℝ) / 6400)) (t := ((167 : ℝ) / 12967))
    (lo := ((12879558421604703 : ℝ) / 500000000000000000)) (hi := ((25759116843209407 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_436 : RB (Real.log ((25937499999999999 : ℝ) / 1000000000000000000)) ((-57063523140487813 : ℝ) / 15625000000000000) ((-365206548099122003 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((25937499999999999 : ℝ) / 31250000000000000)) (t := ((-5312500000000001 : ℝ) / 57187499999999999))
    (lo := ((-46582394547873371 : ℝ) / 250000000000000000)) (hi := ((-186329578191493483 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25937499999999999 : ℝ) / 1000000000000000000) = Real.log ((25937499999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25937499999999999 : ℝ) / 1000000000000000000) = ((25937499999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_437 : RB (Real.log ((21 : ℝ) / 800)) ((-3640089289944504301 : ℝ) / 1000000000000000000) ((-3640089289944504299 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((21 : ℝ) / 25)) (t := ((-2 : ℝ) / 23))
    (lo := ((-174353387144777753 : ℝ) / 1000000000000000000)) (hi := ((-21794173393097219 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21 : ℝ) / 800) = Real.log ((21 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((21 : ℝ) / 800) = ((21 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_438 : RB (Real.log ((1025937499999999999 : ℝ) / 1000000000000000000)) ((25606828713774753 : ℝ) / 1000000000000000000) ((12803414356887377 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025937499999999999 : ℝ) / 1000000000000000000)) (t := ((25937499999999999 : ℝ) / 2025937499999999999))
    (lo := ((25606828713774753 : ℝ) / 1000000000000000000)) (hi := ((12803414356887377 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_439 : RB (Real.log ((821 : ℝ) / 800)) ((1036455271380037 : ℝ) / 40000000000000000) ((12955690892250463 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((821 : ℝ) / 800)) (t := ((21 : ℝ) / 1621))
    (lo := ((1036455271380037 : ℝ) / 40000000000000000)) (hi := ((12955690892250463 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
