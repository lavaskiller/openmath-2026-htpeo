import LeanProject.TerminalGeometry
import LeanProject.COVLogTwo

/-! A uniform analytic certificate for the unbounded terminal tail. -/
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 2000000
set_option linter.style.longLine false

noncomputable def terminalTailCut : ℝ := 1 / 100

theorem tail_log_q : -(Real.log ((1 : ℝ) / 100)) ≥ (46 : ℝ) / 10 := by
  have h := log_series_lower (x := (25 : ℝ) / 16) (t := (9 : ℝ) / 41)
    (by norm_num) (by norm_num) (by norm_num) 4
  have he : Real.log ((1 : ℝ) / 100) = -(Real.log (25 / 16) + 6 * Real.log 2) := by
    rw [show (1 : ℝ) / 100 = ((25 / 16) * 2 ^ 6)⁻¹ by norm_num,
      Real.log_inv, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  norm_num [sum_range_succ] at h
  linarith [cov_log_two.1]

theorem tail_log_D_lower : (67 : ℝ) / 100 ≤ Real.log (49 / 25) := by
  have h := log_series_lower (x := (49 : ℝ) / 25) (t := (12 : ℝ) / 37)
    (by norm_num) (by norm_num) (by norm_num) 4
  norm_num [sum_range_succ] at h
  linarith

theorem tail_D_bounds {q : ℝ} (hq : 0 < q) (hqc : q ≤ terminalTailCut) :
    RB (D0q q) (49 / 25) 2 := by
  have hu : q ≤ (1 : ℝ) / 100 := hqc
  have hp : 0 < (1 + q) ^ 2 := by positivity
  have hs : q ^ 2 ≤ (1 / 100 : ℝ) ^ 2 := (sq_le_sq₀ hq.le (by norm_num)).mpr hu
  unfold D0q
  constructor
  · apply (le_div_iff₀ hp).mpr
    nlinarith
  · apply (div_le_iff₀ hp).mpr
    nlinarith [sq_nonneg q]

theorem tail_tau_bound {q : ℝ} (hq : 0 < q) (hqc : q ≤ terminalTailCut) :
    (46 : ℝ) / 10 ≤ -Real.log q := by
  have hh := Real.log_le_log hq hqc
  exact tail_log_q.trans (neg_le_neg hh)

theorem tail_logD_bounds {q : ℝ} (hq : 0 < q) (hqc : q ≤ terminalTailCut) :
    RB (Real.log (D0q q)) (67 / 100) (694 / 1000) := by
  have hd := tail_D_bounds hq hqc
  constructor
  · exact tail_log_D_lower.trans (Real.log_le_log (by norm_num) hd.1)
  · exact (Real.log_le_log (by linarith [hd.1]) hd.2).trans (by linarith [cov_log_two.2])

theorem tail_qtau_bound {q : ℝ} (hq : 0 < q) (hqc : q ≤ terminalTailCut) :
    q * (-Real.log q) ≤ (18 : ℝ) / 100 := by
  let s := Real.sqrt q
  have hs0 : 0 < s := Real.sqrt_pos.mpr hq
  have hsq : s ^ 2 = q := Real.sq_sqrt hq.le
  have hsc : s ≤ (1 : ℝ) / 10 := by
    have hn := Real.sqrt_nonneg q
    have hh : q ≤ (1 : ℝ) / 100 := hqc
    nlinarith
  have hl := Real.log_le_sub_one_of_pos (one_div_pos.mpr hs0)
  have he : Real.log q = 2 * Real.log s := by rw [← hsq, Real.log_pow]; norm_num
  rw [Real.log_div (by norm_num) hs0.ne', Real.log_one] at hl
  have hb := mul_le_mul_of_nonneg_left hl hq.le
  have hd : q * (1 / s - 1) = s - q := by
    rw [← hsq]
    field_simp [hs0.ne']
    <;> ring
  rw [hd] at hb
  have hp := mul_nonneg (sub_nonneg.mpr hsc) (show (0 : ℝ) ≤ 9 / 10 - s by linarith)
  rw [he]
  nlinarith

theorem tail_parameter_bounds {q : ℝ} (hq : q ∈ terminalDomain) (hqc : q ≤ terminalTailCut) :
    (33 : ℝ) / 5 ≤ terminalK q + 1 ∧
    RB (terminalK q / (terminalK q + 1)) (849 / 1000) 1 ∧
    formApi (terminalK q) q ≤ 77 / 50 := by
  have ht := tail_tau_bound hq.1 hqc
  have hd := tail_logD_bounds hq.1 hqc
  have hdp := terminal_log_D0_pos hq
  have hk := terminalK_pos hq
  have hkp : 0 < terminalK q + 1 := by linarith
  have he : terminalK q + 1 = -Real.log q / Real.log (D0q q) := by unfold terminalK; ring
  have heA : terminalK q / (terminalK q + 1) = 1 - Real.log (D0q q) / (-Real.log q) := by
    rw [terminal_mass_ratio hq]
    unfold Aq
    rw [log_H_eq hq.1]
    change (Real.log (D0q q) + Real.log q) / Real.log q = _
    field_simp [(log_q_neg hq.1 (terminal_admissible hq).2.1).ne]
    <;> ring
  have hτ : 0 < -Real.log q := by linarith
  have hAb : Real.log (D0q q) / (-Real.log q) ≤ 151 / 1000 := by
    apply (div_le_iff₀ hτ).mpr
    linarith [hd.2]
  have hAn : 0 ≤ Real.log (D0q q) / (-Real.log q) := (div_pos hdp hτ).le
  have htq := tail_qtau_bound hq.1 hqc
  have hkq : terminalK q * q ≤ 27 / 100 := by
    have hh : (terminalK q + 1) * Real.log (D0q q) = -Real.log q := by
      rw [he]; field_simp [hdp.ne']
    have hm := mul_le_mul_of_nonneg_left hd.1 (mul_pos hk hq.1).le
    have hhq := congrArg (fun x : ℝ => x * q) hh
    nlinarith
  refine ⟨?_, ?_, ?_⟩
  · rw [he]
    apply (le_div_iff₀ hdp).mpr
    linarith [hd.2]
  · rw [heA]
    exact ⟨by linarith, by linarith⟩
  · unfold formApi
    have hp : 0 < 1 + q := by linarith [hq.1]
    have hb : 2 * terminalK q * q / (1 + q) ≤ 54 / 100 := by
      apply (div_le_iff₀ hp).mpr
      nlinarith [hq.1]
    linarith

end EP1038.ReferenceCert
