import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk03
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_35 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10239 : ℝ) / 16639) ((321 : ℝ) / 521))
    (hq : RB (qa a) ((601469 : ℝ) / 50000000) ((24397 : ℝ) / 2000000))
    (hd : RB (D0a a) ((195208451 : ℝ) / 100000000) ((195273699 : ℝ) / 100000000))
    : certE k a ((42153541 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((42527991 : ℝ) / 100000000) ∧ 0 < certE k a ((25742569 : ℝ) / 20000000) ∧ certE k a ((64447091 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1447 : ℝ) / 10000000) ((14881 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42153541 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((2106933 : ℝ) / 5000000) ((42139071 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((42153541 : ℝ) / 100000000) ((42153541 : ℝ) / 100000000) ((42153541 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57846459 : ℝ) / 100000000))
  have h3 : RB z3 ((72845703 : ℝ) / 100000000) ((36423207 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((57846459 : ℝ) / 100000000) ((57846459 : ℝ) / 100000000) ((57846459 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-3960333 : ℝ) / 12500000) ((-31681687 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_630.1 cov_log_631.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-19520413 : ℝ) / 100000000) ((-1949569 : ℝ) / 10000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42153541 : ℝ) / 100000000))
  have h6 : RB z6 ((-86385151 : ℝ) / 100000000) ((-86385149 : ℝ) / 100000000) := rb_log (show RB ((42153541 : ℝ) / 100000000) ((42153541 : ℝ) / 100000000) ((42153541 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_632.1 cov_log_632.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((2089523 : ℝ) / 3125000) ((66889461 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33444889 : ℝ) / 50000000) ((66923199 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_633.1 cov_log_634.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-58463 : ℝ) / 100000000) ((-317 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1447 : ℝ) / 10000000) ((14881 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42527991 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((4251311 : ℝ) / 10000000) ((42513521 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((42527991 : ℝ) / 100000000) ((42527991 : ℝ) / 100000000) ((42527991 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57472009 : ℝ) / 100000000))
  have h12 : RB z12 ((18492963 : ℝ) / 25000000) ((73972569 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((57472009 : ℝ) / 100000000) ((57472009 : ℝ) / 100000000) ((57472009 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-6029711 : ℝ) / 20000000) ((-6029517 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_635.1 cov_log_636.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-9287607 : ℝ) / 50000000) ((-18551663 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42527991 : ℝ) / 100000000))
  have h15 : RB z15 ((-85500773 : ℝ) / 100000000) ((-85500771 : ℝ) / 100000000) := rb_log (show RB ((42527991 : ℝ) / 100000000) ((42527991 : ℝ) / 100000000) ((42527991 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_637.1 cov_log_637.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66925557 : ℝ) / 100000000) ((6694911 : ℝ) / 10000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33444889 : ℝ) / 50000000) ((66923199 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_633.1 cov_log_634.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1179 : ℝ) / 50000000) ((14833 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1447 : ℝ) / 10000000) ((14881 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((25742569 : ℝ) / 20000000)) - (z19)
  have h20 : RB z20 ((32174491 : ℝ) / 25000000) ((1029587 : ℝ) / 800000) := rb_widen (rb_sub (show RB ((25742569 : ℝ) / 20000000) ((25742569 : ℝ) / 20000000) ((25742569 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((5742569 : ℝ) / 20000000))
  have h21 : RB z21 ((448224353 : ℝ) / 100000000) ((224112893 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((5742569 : ℝ) / 20000000) ((5742569 : ℝ) / 20000000) ((5742569 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((15001237 : ℝ) / 10000000) ((150012693 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_638.1 cov_log_639.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92311837 : ℝ) / 100000000) ((92426247 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((25742569 : ℝ) / 20000000))
  have h24 : RB z24 ((6310343 : ℝ) / 25000000) ((25241373 : ℝ) / 100000000) := rb_log (show RB ((25742569 : ℝ) / 20000000) ((25742569 : ℝ) / 20000000) ((25742569 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_640.1 cov_log_640.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((261994 : ℝ) / 390625) ((537479 : ℝ) / 800000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33444889 : ℝ) / 50000000) ((66923199 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_633.1 cov_log_634.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((29453 : ℝ) / 20000000) ((295097 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1447 : ℝ) / 10000000) ((14881 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((64447091 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((128879301 : ℝ) / 100000000) ((4027491 : ℝ) / 3125000) := rb_widen (rb_sub (show RB ((64447091 : ℝ) / 50000000) ((64447091 : ℝ) / 50000000) ((64447091 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((14447091 : ℝ) / 50000000))
  have h30 : RB z30 ((111509733 : ℝ) / 25000000) ((111510089 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((14447091 : ℝ) / 50000000) ((14447091 : ℝ) / 50000000) ((14447091 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((29904721 : ℝ) / 20000000) ((149523927 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_641.1 cov_log_642.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92011069 : ℝ) / 100000000) ((92125107 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((64447091 : ℝ) / 50000000))
  have h33 : RB z33 ((12691079 : ℝ) / 50000000) ((25382159 : ℝ) / 100000000) := rb_log (show RB ((64447091 : ℝ) / 50000000) ((64447091 : ℝ) / 50000000) ((64447091 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_643.1 cov_log_643.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6662891 : ℝ) / 10000000) ((66742949 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33444889 : ℝ) / 50000000) ((66923199 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_633.1 cov_log_634.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-294289 : ℝ) / 100000000) ((-146829 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42153541 : ℝ) / 100000000)) ((-58463 : ℝ) / 100000000) ((-317 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42527991 : ℝ) / 100000000)) ((1179 : ℝ) / 50000000) ((14833 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((25742569 : ℝ) / 20000000)) ((29453 : ℝ) / 20000000) ((295097 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((64447091 : ℝ) / 50000000)) ((-294289 : ℝ) / 100000000) ((-146829 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_35 {k A q d vp vm : ℝ}
    (hk : RB k ((10239 : ℝ) / 6400) ((321 : ℝ) / 200))
    (hA : RB A ((10239 : ℝ) / 16639) ((321 : ℝ) / 521))
    (hq : RB q ((601469 : ℝ) / 50000000) ((24397 : ℝ) / 2000000))
    (hd : RB d ((195208451 : ℝ) / 100000000) ((195273699 : ℝ) / 100000000))
    (hp : RB vp ((42153541 : ℝ) / 100000000) ((42527991 : ℝ) / 100000000))
    (hm : RB vm ((25742569 : ℝ) / 20000000) ((64447091 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1447 : ℝ) / 10000000) ((14881 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99985119 : ℝ) / 100000000) ((9998553 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((3845437 : ℝ) / 6250000) ((61603369 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((4253 : ℝ) / 12500000) ((17651 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49982349 : ℝ) / 50000000) ((12495747 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57472009 : ℝ) / 100000000) ((57846459 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((1436293 : ℝ) / 2500000) ((28913389 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106398789 : ℝ) / 100000000) ((107226327 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6398789 : ℝ) / 100000000) ((7226327 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99985119 : ℝ) / 100000000) ((9998553 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((3845437 : ℝ) / 6250000) ((61603369 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((5613 : ℝ) / 50000000) ((5781 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49994219 : ℝ) / 50000000) ((49994387 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((5742569 : ℝ) / 20000000) ((14447091 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1148381 : ℝ) / 4000000) ((28890939 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((26620367 : ℝ) / 12500000) ((13410917 : ℝ) / 6250000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((39120367 : ℝ) / 12500000) ((19660917 : ℝ) / 6250000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((17297861 : ℝ) / 1250000) ((1562795711 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15894477 : ℝ) / 50000000) ((15976333 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10239 : ℝ) / 3200) ((321 : ℝ) / 100) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((153961 : ℝ) / 4000000) ((3915719 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50601469 : ℝ) / 50000000) ((2024397 : ℝ) / 2000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1901319 : ℝ) / 50000000) ((483647 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((51901319 : ℝ) / 50000000) ((12983647 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((43092427 : ℝ) / 50000000) ((86740641 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((84120059 : ℝ) / 50000000) ((169381659 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((54257021 : ℝ) / 100000000) ((54816107 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((26397 : ℝ) / 100000000) ((27427 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99972573 : ℝ) / 100000000) ((99973603 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((84096987 : ℝ) / 50000000) ((42334237 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((195208451 : ℝ) / 50000000) ((195273699 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4696473 : ℝ) / 100000000) ((4764093 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16639 : ℝ) / 6400) ((521 : ℝ) / 200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((450717 : ℝ) / 25000000) ((916227 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2828579 : ℝ) / 100000000) ((1446913 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((102828579 : ℝ) / 100000000) ((51446913 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1422971573 : ℝ) / 100000000) ((16080203 : ℝ) / 1000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((37331 : ℝ) / 4000000) ((94773 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((4037331 : ℝ) / 4000000) ((10094773 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((250669 : ℝ) / 781250) ((8063873 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((291011441 : ℝ) / 20000000) ((102517237 : ℝ) / 6250000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((655819 : ℝ) / 2500000) ((300573 : ℝ) / 1000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16639 : ℝ) / 6400) ((521 : ℝ) / 200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((51901319 : ℝ) / 25000000) ((12983647 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((707808917 : ℝ) / 50000000) ((1594748377 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2938897311 : ℝ) / 100000000) ((3312903997 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7847627 : ℝ) / 100000000) ((8863869 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-7952997 : ℝ) / 3125000) ((-242318683 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_644.1 cov_log_645.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((587059 : ℝ) / 25000000) ((2382047 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-375150583 : ℝ) / 100000000) ((-186860499 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_646.1 cov_log_647.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33444889 : ℝ) / 50000000) ((66923199 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_633.1 cov_log_634.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((107013193 : ℝ) / 100000000) ((21482347 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-26813739 : ℝ) / 10000000) ((-266309263 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((14106099 : ℝ) / 100000000) ((7624537 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((11732673 : ℝ) / 25000000) ((1816559 : ℝ) / 3125000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-110603349 : ℝ) / 50000000) ((-333087 : ℝ) / 160000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((51901319 : ℝ) / 50000000) ((12983647 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-7952997 : ℝ) / 3125000) ((-242318683 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-110603349 : ℝ) / 50000000) ((-333087 : ℝ) / 160000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((303 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2828579 : ℝ) / 100000000) ((1446913 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((51446913 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((303 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-225159031 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((303 : ℝ) / 100) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_9, cov_h_6]
  have hP : ((78704233 : ℝ) / 12500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((333087 : ℝ) / 160000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((333087 : ℝ) / 160000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((279 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((283 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((287 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((283 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((291 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((291 : ℝ) / 100)) (lo := ((287 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((59 : ℝ) / 20) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((291 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((299 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((59 : ℝ) / 20)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((303 : ℝ) / 100)) (lo := ((299 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_35 {k : ℝ} (hk : RB k ((10239 : ℝ) / 6400) ((321 : ℝ) / 200)) :
    RB (k / (k + 1)) ((10239 : ℝ) / 16639) ((321 : ℝ) / 521) ∧
    RB (qa (r1A k)) ((601469 : ℝ) / 50000000) ((24397 : ℝ) / 2000000) ∧ RB (D0a (r1A k)) ((195208451 : ℝ) / 100000000) ((195273699 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((39996093 : ℝ) / 100000000) ((321 : ℝ) / 800) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((7619 : ℝ) / 4000) ((190603907 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((3450317 : ℝ) / 2500000) ((69029687 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69858509 : ℝ) / 25000000) ((279480731 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69858509 : ℝ) / 50000000) ((69870183 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((195208451 : ℝ) / 100000000) ((195273699 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((9396093 : ℝ) / 100000000) ((381 : ℝ) / 4000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2349023 : ℝ) / 100000000) ((381 : ℝ) / 16000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((601469 : ℝ) / 50000000) ((24397 : ℝ) / 2000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((195208451 : ℝ) / 100000000) ((195273699 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((601469 : ℝ) / 50000000) ((24397 : ℝ) / 2000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10239 : ℝ) / 16639) ((321 : ℝ) / 521) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_35 {k : ℝ} (hk : RB k ((10239 : ℝ) / 6400) ((321 : ℝ) / 200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_35 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_35 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((42153541 : ℝ) / 100000000)) (ph := ((42527991 : ℝ) / 100000000)) (ml := ((25742569 : ℝ) / 20000000)) (mh := ((64447091 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_35 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_36 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((321 : ℝ) / 521) ((2061 : ℝ) / 3341))
    (hq : RB (qa a) ((1219849 : ℝ) / 100000000) ((1236773 : ℝ) / 100000000))
    (hd : RB (D0a a) ((97571597 : ℝ) / 50000000) ((97604227 : ℝ) / 50000000))
    : certE k a ((1315587 : ℝ) / 3125000) < 0 ∧ 0 < certE k a ((4246811 : ℝ) / 10000000) ∧ 0 < certE k a ((128773457 : ℝ) / 100000000) ∧ certE k a ((25790859 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((93 : ℝ) / 625000) ((15297 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1315587 : ℝ) / 3125000)) - (z1)
  have h2 : RB z2 ((42083487 : ℝ) / 100000000) ((657561 : ℝ) / 1562500) := rb_widen (rb_sub (show RB ((1315587 : ℝ) / 3125000) ((1315587 : ℝ) / 3125000) ((1315587 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((1809413 : ℝ) / 3125000))
  have h3 : RB z3 ((2907261 : ℝ) / 4000000) ((36341123 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((1809413 : ℝ) / 3125000) ((1809413 : ℝ) / 3125000) ((1809413 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-31908297 : ℝ) / 100000000) ((-3988413 : ℝ) / 12500000) := rb_log h3 (by norm_num) cov_log_648.1 cov_log_649.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-4920907 : ℝ) / 25000000) ((-9829409 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((1315587 : ℝ) / 3125000))
  have h6 : RB z6 ((-43257567 : ℝ) / 50000000) ((-21628783 : ℝ) / 25000000) := rb_log (show RB ((1315587 : ℝ) / 3125000) ((1315587 : ℝ) / 3125000) ((1315587 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_650.1 cov_log_650.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((4176969 : ℝ) / 6250000) ((16714079 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66856343 : ℝ) / 100000000) ((66889781 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_651.1 cov_log_652.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-58277 : ℝ) / 100000000) ((-27 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((93 : ℝ) / 625000) ((15297 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((4246811 : ℝ) / 10000000)) - (z10)
  have h11 : RB z11 ((42452813 : ℝ) / 100000000) ((4245323 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((4246811 : ℝ) / 10000000) ((4246811 : ℝ) / 10000000) ((4246811 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((5753189 : ℝ) / 10000000))
  have h12 : RB z12 ((36895027 : ℝ) / 50000000) ((3689539 : ℝ) / 5000000) := rb_div_signed h11 (show RB ((5753189 : ℝ) / 10000000) ((5753189 : ℝ) / 10000000) ((5753189 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-118729 : ℝ) / 390625) ((-30393639 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_653.1 cov_log_654.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-1171867 : ℝ) / 6250000) ((-3745243 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((4246811 : ℝ) / 10000000))
  have h15 : RB z15 ((-21410419 : ℝ) / 25000000) ((-42820837 : ℝ) / 50000000) := rb_log (show RB ((4246811 : ℝ) / 10000000) ((4246811 : ℝ) / 10000000) ((4246811 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_655.1 cov_log_655.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33445901 : ℝ) / 50000000) ((66915461 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66856343 : ℝ) / 100000000) ((66889781 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_651.1 cov_log_652.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2021 : ℝ) / 100000000) ((29559 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((93 : ℝ) / 625000) ((15297 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((128773457 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((1609477 : ℝ) / 1250000) ((128758577 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((128773457 : ℝ) / 100000000) ((128773457 : ℝ) / 100000000) ((128773457 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((28773457 : ℝ) / 100000000))
  have h21 : RB z21 ((111872341 : ℝ) / 25000000) ((89498163 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((28773457 : ℝ) / 100000000) ((28773457 : ℝ) / 100000000) ((28773457 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((74924129 : ℝ) / 50000000) ((29969717 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_656.1 cov_log_657.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46162467 : ℝ) / 50000000) ((92438771 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((128773457 : ℝ) / 100000000))
  have h24 : RB z24 ((6322113 : ℝ) / 25000000) ((25288453 : ℝ) / 100000000) := rb_log (show RB ((128773457 : ℝ) / 100000000) ((128773457 : ℝ) / 100000000) ((128773457 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_658.1 cov_log_658.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67036481 : ℝ) / 100000000) ((67150319 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66856343 : ℝ) / 100000000) ((66889781 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_651.1 cov_log_652.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((1467 : ℝ) / 1000000) ((36747 : ℝ) / 12500000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((93 : ℝ) / 625000) ((15297 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((25790859 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((64469499 : ℝ) / 50000000) ((25787883 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((25790859 : ℝ) / 20000000) ((25790859 : ℝ) / 20000000) ((25790859 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((5790859 : ℝ) / 20000000))
  have h30 : RB z30 ((13916221 : ℝ) / 3125000) ((445320513 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((5790859 : ℝ) / 20000000) ((5790859 : ℝ) / 20000000) ((5790859 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((29872417 : ℝ) / 20000000) ((149362411 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_659.1 cov_log_660.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((5751587 : ℝ) / 6250000) ((4606943 : ℝ) / 5000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((25790859 : ℝ) / 20000000))
  have h33 : RB z33 ((5085757 : ℝ) / 20000000) ((12714393 : ℝ) / 50000000) := rb_log (show RB ((25790859 : ℝ) / 20000000) ((25790859 : ℝ) / 20000000) ((25790859 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_661.1 cov_log_661.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33298303 : ℝ) / 50000000) ((2668403 : ℝ) / 4000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66856343 : ℝ) / 100000000) ((66889781 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_651.1 cov_log_652.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-11727 : ℝ) / 4000000) ((-36567 : ℝ) / 25000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((1315587 : ℝ) / 3125000)) ((-58277 : ℝ) / 100000000) ((-27 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((4246811 : ℝ) / 10000000)) ((2021 : ℝ) / 100000000) ((29559 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((128773457 : ℝ) / 100000000)) ((1467 : ℝ) / 1000000) ((36747 : ℝ) / 12500000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((25790859 : ℝ) / 20000000)) ((-11727 : ℝ) / 4000000) ((-36567 : ℝ) / 25000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_36 {k A q d vp vm : ℝ}
    (hk : RB k ((321 : ℝ) / 200) ((2061 : ℝ) / 1280))
    (hA : RB A ((321 : ℝ) / 521) ((2061 : ℝ) / 3341))
    (hq : RB q ((1219849 : ℝ) / 100000000) ((1236773 : ℝ) / 100000000))
    (hd : RB d ((97571597 : ℝ) / 50000000) ((97604227 : ℝ) / 50000000))
    (hp : RB vp ((1315587 : ℝ) / 3125000) ((4246811 : ℝ) / 10000000))
    (hm : RB vm ((128773457 : ℝ) / 100000000) ((25790859 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((93 : ℝ) / 625000) ((15297 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99984703 : ℝ) / 100000000) ((624907 : ℝ) / 625000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((61602859 : ℝ) / 100000000) ((61678939 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((17519 : ℝ) / 50000000) ((2271 : ℝ) / 6250000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((6247729 : ℝ) / 6250000) ((49982481 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((5753189 : ℝ) / 10000000) ((1809413 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11502197 : ℝ) / 20000000) ((57880929 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106430321 : ℝ) / 100000000) ((837869 : ℝ) / 781250) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6430321 : ℝ) / 100000000) ((56619 : ℝ) / 781250) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99984703 : ℝ) / 100000000) ((624907 : ℝ) / 625000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((61602859 : ℝ) / 100000000) ((61678939 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((5769 : ℝ) / 50000000) ((297 : ℝ) / 2500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((2499703 : ℝ) / 2500000) ((49994231 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((28773457 : ℝ) / 100000000) ((5790859 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((14385019 : ℝ) / 50000000) ((5790191 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((26597939 : ℝ) / 12500000) ((214386019 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((39097939 : ℝ) / 12500000) ((314386019 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1379837157 : ℝ) / 100000000) ((777566159 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((3180803 : ℝ) / 10000000) ((6394199 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((321 : ℝ) / 100) ((2061 : ℝ) / 640) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((783143 : ℝ) / 20000000) ((995699 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101219849 : ℝ) / 100000000) ((101236773 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1933939 : ℝ) / 50000000) ((1967399 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((51933939 : ℝ) / 50000000) ((51967399 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((86305347 : ℝ) / 100000000) ((86855511 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((16841901 : ℝ) / 10000000) ((169549301 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((54212059 : ℝ) / 100000000) ((13691113 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((2717 : ℝ) / 10000000) ((28217 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99971783 : ℝ) / 100000000) ((9997283 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((168371487 : ℝ) / 100000000) ((33900647 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((97571597 : ℝ) / 25000000) ((97604227 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((595113 : ℝ) / 12500000) ((4828571 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((521 : ℝ) / 200) ((3341 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1823991 : ℝ) / 100000000) ((1853579 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((718097 : ℝ) / 25000000) ((734447 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25718097 : ℝ) / 25000000) ((25734447 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1419471433 : ℝ) / 100000000) ((1600818809 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((472977 : ℝ) / 50000000) ((480213 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50472977 : ℝ) / 50000000) ((50480213 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32108919 : ℝ) / 100000000) ((32278053 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((22680943 : ℝ) / 1562500) ((816548431 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((13238347 : ℝ) / 50000000) ((30270741 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((521 : ℝ) / 200) ((3341 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((51933939 : ℝ) / 25000000) ((51967399 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1411645187 : ℝ) / 100000000) ((1587103313 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2932491801 : ℝ) / 100000000) ((659821049 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((98701 : ℝ) / 1250000) ((4450407 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-253880379 : ℝ) / 100000000) ((-48380549 : ℝ) / 20000000) := rb_log h47 (by norm_num) cov_log_662.1 cov_log_663.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((595113 : ℝ) / 25000000) ((1207143 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-74757597 : ℝ) / 20000000) ((-372376659 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_664.1 cov_log_665.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66856343 : ℝ) / 100000000) ((66889781 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_651.1 cov_log_652.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((10730443 : ℝ) / 10000000) ((107702999 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-53296711 : ℝ) / 20000000) ((-13233683 : ℝ) / 5000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3484953 : ℝ) / 25000000) ((15071561 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2878153 : ℝ) / 6250000) ((56923879 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-220433107 : ℝ) / 100000000) ((-207749781 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((51933939 : ℝ) / 50000000) ((51967399 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-253880379 : ℝ) / 100000000) ((-48380549 : ℝ) / 20000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-220433107 : ℝ) / 100000000) ((-207749781 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((303 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((718097 : ℝ) / 25000000) ((734447 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((25734447 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((303 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-112271753 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((303 : ℝ) / 100) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_9, cov_h_6]
  have hP : ((627937851 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((207749781 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((207749781 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((279 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((283 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((287 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((283 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((291 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((291 : ℝ) / 100)) (lo := ((287 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((59 : ℝ) / 20) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((291 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((299 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((59 : ℝ) / 20)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((303 : ℝ) / 100)) (lo := ((299 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_36 {k : ℝ} (hk : RB k ((321 : ℝ) / 200) ((2061 : ℝ) / 1280)) :
    RB (k / (k + 1)) ((321 : ℝ) / 521) ((2061 : ℝ) / 3341) ∧
    RB (qa (r1A k)) ((1219849 : ℝ) / 100000000) ((1236773 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((97571597 : ℝ) / 50000000) ((97604227 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((321 : ℝ) / 800) ((40253907 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((190346093 : ℝ) / 100000000) ((7619 : ℝ) / 4000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((137965971 : ℝ) / 100000000) ((138012681 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279387327 : ℝ) / 100000000) ((139717019 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139693663 : ℝ) / 100000000) ((139717019 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((97571597 : ℝ) / 50000000) ((97604227 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((381 : ℝ) / 4000) ((9653907 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((381 : ℝ) / 16000) ((2413477 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1219849 : ℝ) / 100000000) ((1236773 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((97571597 : ℝ) / 50000000) ((97604227 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1219849 : ℝ) / 100000000) ((1236773 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((321 : ℝ) / 521) ((2061 : ℝ) / 3341) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_36 {k : ℝ} (hk : RB k ((321 : ℝ) / 200) ((2061 : ℝ) / 1280)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_36 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_36 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((1315587 : ℝ) / 3125000)) (ph := ((4246811 : ℝ) / 10000000)) (ml := ((128773457 : ℝ) / 100000000)) (mh := ((25790859 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_36 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_37 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2061 : ℝ) / 3341) ((5169 : ℝ) / 8369))
    (hq : RB (qa a) ((1236771 : ℝ) / 100000000) ((1253707 : ℝ) / 100000000))
    (hd : RB (D0a a) ((195077929 : ℝ) / 100000000) ((195143201 : ℝ) / 100000000))
    : certE k a ((20991551 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((5308839 : ℝ) / 12500000) ∧ 0 < certE k a ((128833901 : ℝ) / 100000000) ∧ certE k a ((129014243 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((239 : ℝ) / 1562500) ((7859 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((20991551 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((5245923 : ℝ) / 12500000) ((20983903 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((20991551 : ℝ) / 50000000) ((20991551 : ℝ) / 50000000) ((20991551 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((29008449 : ℝ) / 50000000))
  have h3 : RB z3 ((72336483 : ℝ) / 100000000) ((18084303 : ℝ) / 25000000) := rb_div_signed h2 (show RB ((29008449 : ℝ) / 50000000) ((29008449 : ℝ) / 50000000) ((29008449 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-16192079 : ℝ) / 50000000) ((-647663 : ℝ) / 2000000) := rb_log h3 (by norm_num) cov_log_666.1 cov_log_667.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-20001639 : ℝ) / 100000000) ((-3995311 : ℝ) / 20000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((20991551 : ℝ) / 50000000))
  have h6 : RB z6 ((-867903 : ℝ) / 1000000) ((-43395149 : ℝ) / 50000000) := rb_log (show RB ((20991551 : ℝ) / 50000000) ((20991551 : ℝ) / 50000000) ((20991551 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_668.1 cov_log_668.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66788659 : ℝ) / 100000000) ((13362749 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16705723 : ℝ) / 25000000) ((16714087 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_669.1 cov_log_670.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-67689 : ℝ) / 100000000) ((-9147 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((239 : ℝ) / 1562500) ((7859 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((5308839 : ℝ) / 12500000)) - (z10)
  have h11 : RB z11 ((21227497 : ℝ) / 50000000) ((5306927 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((5308839 : ℝ) / 12500000) ((5308839 : ℝ) / 12500000) ((5308839 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((7191161 : ℝ) / 12500000))
  have h12 : RB z12 ((73797183 : ℝ) / 100000000) ((73797917 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((7191161 : ℝ) / 12500000) ((7191161 : ℝ) / 12500000) ((7191161 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-30384963 : ℝ) / 100000000) ((-30383967 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_671.1 cov_log_672.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-18766863 : ℝ) / 100000000) ((-18743297 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((5308839 : ℝ) / 12500000))
  have h15 : RB z15 ((-85635549 : ℝ) / 100000000) ((-85635547 : ℝ) / 100000000) := rb_log (show RB ((5308839 : ℝ) / 12500000) ((5308839 : ℝ) / 12500000) ((5308839 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_673.1 cov_log_673.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16717171 : ℝ) / 25000000) ((16723063 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16705723 : ℝ) / 25000000) ((16714087 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_669.1 cov_log_670.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((771 : ℝ) / 6250000) ((867 : ℝ) / 1250000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((239 : ℝ) / 1562500) ((7859 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((128833901 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((128818183 : ℝ) / 100000000) ((25763721 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((128833901 : ℝ) / 100000000) ((128833901 : ℝ) / 100000000) ((128833901 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((28833901 : ℝ) / 100000000))
  have h21 : RB z21 ((446759469 : ℝ) / 100000000) ((446760933 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((28833901 : ℝ) / 100000000) ((28833901 : ℝ) / 100000000) ((28833901 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((18710627 : ℝ) / 12500000) ((74842673 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_674.1 cov_log_675.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23084467 : ℝ) / 25000000) ((1444549 : ℝ) / 1562500) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((128833901 : ℝ) / 100000000))
  have h24 : RB z24 ((25335379 : ℝ) / 100000000) ((1266769 : ℝ) / 5000000) := rb_log (show RB ((128833901 : ℝ) / 100000000) ((128833901 : ℝ) / 100000000) ((128833901 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_676.1 cov_log_676.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((8375311 : ℝ) / 12500000) ((67115757 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16705723 : ℝ) / 25000000) ((16714087 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_669.1 cov_log_670.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((7307 : ℝ) / 5000000) ((58573 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((239 : ℝ) / 1562500) ((7859 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129014243 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((5159941 : ℝ) / 4000000) ((128998947 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((129014243 : ℝ) / 100000000) ((129014243 : ℝ) / 100000000) ((129014243 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29014243 : ℝ) / 100000000))
  have h30 : RB z30 ((222302069 : ℝ) / 50000000) ((444605593 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((29014243 : ℝ) / 100000000) ((29014243 : ℝ) / 100000000) ((29014243 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((37300353 : ℝ) / 25000000) ((74600871 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_677.1 cov_log_678.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46019771 : ℝ) / 50000000) ((18430489 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129014243 : ℝ) / 100000000))
  have h33 : RB z33 ((12737631 : ℝ) / 50000000) ((25475263 : ℝ) / 100000000) := rb_log (show RB ((129014243 : ℝ) / 100000000) ((129014243 : ℝ) / 100000000) ((129014243 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_679.1 cov_log_679.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((66564279 : ℝ) / 100000000) ((66677183 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16705723 : ℝ) / 25000000) ((16714087 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_669.1 cov_log_670.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-292069 : ℝ) / 100000000) ((-145709 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((20991551 : ℝ) / 50000000)) ((-67689 : ℝ) / 100000000) ((-9147 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((5308839 : ℝ) / 12500000)) ((771 : ℝ) / 6250000) ((867 : ℝ) / 1250000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((128833901 : ℝ) / 100000000)) ((7307 : ℝ) / 5000000) ((58573 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129014243 : ℝ) / 100000000)) ((-292069 : ℝ) / 100000000) ((-145709 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_37 {k A q d vp vm : ℝ}
    (hk : RB k ((2061 : ℝ) / 1280) ((5169 : ℝ) / 3200))
    (hA : RB A ((2061 : ℝ) / 3341) ((5169 : ℝ) / 8369))
    (hq : RB q ((1236771 : ℝ) / 100000000) ((1253707 : ℝ) / 100000000))
    (hd : RB d ((195077929 : ℝ) / 100000000) ((195143201 : ℝ) / 100000000))
    (hp : RB vp ((20991551 : ℝ) / 50000000) ((5308839 : ℝ) / 12500000))
    (hm : RB vm ((128833901 : ℝ) / 100000000) ((129014243 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((239 : ℝ) / 1562500) ((7859 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49992141 : ℝ) / 50000000) ((1562261 : ℝ) / 1562500) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((61678421 : ℝ) / 100000000) ((12350841 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((7203 : ℝ) / 20000000) ((37439 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99962561 : ℝ) / 100000000) ((19992797 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((7191161 : ℝ) / 12500000) ((29008449 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57507749 : ℝ) / 100000000) ((14499001 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((13293679 : ℝ) / 12500000) ((53692073 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((793679 : ℝ) / 12500000) ((3692073 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49992141 : ℝ) / 50000000) ((1562261 : ℝ) / 1562500) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((61678421 : ℝ) / 100000000) ((12350841 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((741 : ℝ) / 6250000) ((12201 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99987799 : ℝ) / 100000000) ((6249259 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((28833901 : ℝ) / 100000000) ((29014243 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((14415191 : ℝ) / 50000000) ((7252701 : ℝ) / 25000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((212605003 : ℝ) / 100000000) ((214198359 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((312605003 : ℝ) / 100000000) ((314198359 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((677126373 : ℝ) / 50000000) ((1574944027 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((7956757 : ℝ) / 25000000) ((7997313 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2061 : ℝ) / 640) ((5169 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((3982789 : ℝ) / 100000000) ((2025129 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101236771 : ℝ) / 100000000) ((101253707 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1966737 : ℝ) / 50000000) ((2000389 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((51966737 : ℝ) / 50000000) ((52000389 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((86363189 : ℝ) / 100000000) ((87031141 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((263243 : ℝ) / 156250) ((33967071 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13522117 : ℝ) / 25000000) ((13698317 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((5583 : ℝ) / 20000000) ((1453 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4998547 : ℝ) / 5000000) ((19994417 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((168426561 : ℝ) / 100000000) ((84893973 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((195077929 : ℝ) / 50000000) ((195143201 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2412667 : ℝ) / 50000000) ((611631 : ℝ) / 12500000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3341 : ℝ) / 1280) ((8369 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1845031 : ℝ) / 100000000) ((1874619 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((364007 : ℝ) / 12500000) ((2986219 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((12864007 : ℝ) / 12500000) ((102986219 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((5444099 : ℝ) / 390625) ((324395061 : ℝ) / 20000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((958631 : ℝ) / 100000000) ((973119 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100958631 : ℝ) / 100000000) ((100973119 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32132131 : ℝ) / 100000000) ((16150273 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((57032859 : ℝ) / 4000000) ((1654275851 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((822089 : ℝ) / 3125000) ((3101137 : ℝ) / 10000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3341 : ℝ) / 1280) ((8369 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((51966737 : ℝ) / 25000000) ((52000389 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((693039887 : ℝ) / 50000000) ((1606933279 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2881201723 : ℝ) / 100000000) ((133697849 : ℝ) / 4000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7809119 : ℝ) / 100000000) ((9077159 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-7968369 : ℝ) / 3125000) ((-59985223 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_680.1 cov_log_681.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2412667 : ℝ) / 100000000) ((611631 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-186221873 : ℝ) / 50000000) ((-185525097 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_682.1 cov_log_683.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16705723 : ℝ) / 25000000) ((16714087 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_669.1 cov_log_670.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((107595297 : ℝ) / 100000000) ((21598779 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-264848449 : ℝ) / 100000000) ((-263056299 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((13655101 : ℝ) / 100000000) ((15016487 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((22016281 : ℝ) / 50000000) ((28541023 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-220815887 : ℝ) / 100000000) ((-205974253 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((51966737 : ℝ) / 50000000) ((52000389 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-7968369 : ℝ) / 3125000) ((-59985223 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-220815887 : ℝ) / 100000000) ((-205974253 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((303 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((364007 : ℝ) / 12500000) ((2986219 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((102986219 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((303 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-45130187 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((303 : ℝ) / 100) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_9, cov_h_6]
  have hP : ((311088113 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((205974253 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((205974253 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2751 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2751 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2791 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2791 : ℝ) / 1000)) (lo := ((2751 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2831 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2831 : ℝ) / 1000)) (lo := ((2791 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2871 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2871 : ℝ) / 1000)) (lo := ((2831 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2911 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2911 : ℝ) / 1000)) (lo := ((2871 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2951 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2951 : ℝ) / 1000)) (lo := ((2911 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2991 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2991 : ℝ) / 1000)) (lo := ((2951 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((303 : ℝ) / 100)) (lo := ((2991 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_37 {k : ℝ} (hk : RB k ((2061 : ℝ) / 1280) ((5169 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((2061 : ℝ) / 3341) ((5169 : ℝ) / 8369) ∧
    RB (qa (r1A k)) ((1236771 : ℝ) / 100000000) ((1253707 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((195077929 : ℝ) / 100000000) ((195143201 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((20126953 : ℝ) / 50000000) ((40382813 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((190217187 : ℝ) / 100000000) ((95173047 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((137919247 : ℝ) / 100000000) ((34491493 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279340603 : ℝ) / 100000000) ((279387329 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139670301 : ℝ) / 100000000) ((27938733 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((195077929 : ℝ) / 100000000) ((195143201 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4826953 : ℝ) / 50000000) ((9782813 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((603369 : ℝ) / 25000000) ((305713 : ℝ) / 12500000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1236771 : ℝ) / 100000000) ((1253707 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((195077929 : ℝ) / 100000000) ((195143201 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1236771 : ℝ) / 100000000) ((1253707 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2061 : ℝ) / 3341) ((5169 : ℝ) / 8369) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_37 {k : ℝ} (hk : RB k ((2061 : ℝ) / 1280) ((5169 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_37 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_37 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((20991551 : ℝ) / 50000000)) (ph := ((5308839 : ℝ) / 12500000)) (ml := ((128833901 : ℝ) / 100000000)) (mh := ((129014243 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_37 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_38 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5169 : ℝ) / 8369) ((10371 : ℝ) / 16771))
    (hq : RB (qa a) ((250741 : ℝ) / 20000000) ((1270651 : ℝ) / 100000000))
    (hd : RB (D0a a) ((195012653 : ℝ) / 100000000) ((12192371 : ℝ) / 6250000))
    : certE k a ((10482643 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((265073 : ℝ) / 625000) ∧ 0 < certE k a ((128894179 : ℝ) / 100000000) ∧ certE k a ((129074029 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((15717 : ℝ) / 100000000) ((8073 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((10482643 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((20957213 : ℝ) / 50000000) ((8382971 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((10482643 : ℝ) / 25000000) ((10482643 : ℝ) / 25000000) ((10482643 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((14517357 : ℝ) / 25000000))
  have h3 : RB z3 ((72179849 : ℝ) / 100000000) ((72180589 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((14517357 : ℝ) / 25000000) ((14517357 : ℝ) / 25000000) ((14517357 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-1018779 : ℝ) / 3125000) ((-16299951 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_684.1 cov_log_685.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-5040013 : ℝ) / 25000000) ((-20134889 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((10482643 : ℝ) / 25000000))
  have h6 : RB z6 ((-173831 : ℝ) / 200000) ((-43457749 : ℝ) / 50000000) := rb_log (show RB ((10482643 : ℝ) / 25000000) ((10482643 : ℝ) / 25000000) ((10482643 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_686.1 cov_log_686.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33377723 : ℝ) / 50000000) ((66780611 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((2671577 : ℝ) / 4000000) ((33411449 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_687.1 cov_log_688.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-16863 : ℝ) / 25000000) ((-4407 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((15717 : ℝ) / 100000000) ((8073 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((265073 : ℝ) / 625000)) - (z10)
  have h11 : RB z11 ((21197767 : ℝ) / 50000000) ((42395963 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((265073 : ℝ) / 625000) ((265073 : ℝ) / 625000) ((265073 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((359927 : ℝ) / 625000))
  have h12 : RB z12 ((14723657 : ℝ) / 20000000) ((73619031 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((359927 : ℝ) / 625000) ((359927 : ℝ) / 625000) ((359927 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-7656919 : ℝ) / 25000000) ((-15313331 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_689.1 cov_log_690.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3787963 : ℝ) / 20000000) ((-1182259 : ℝ) / 6250000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((265073 : ℝ) / 625000))
  have h15 : RB z15 ((-1072183 : ℝ) / 1250000) ((-42887319 : ℝ) / 50000000) := rb_log (show RB ((265073 : ℝ) / 625000) ((265073 : ℝ) / 625000) ((265073 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_691.1 cov_log_691.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66834823 : ℝ) / 100000000) ((261166 : ℝ) / 390625) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((2671577 : ℝ) / 4000000) ((33411449 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_687.1 cov_log_688.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((477 : ℝ) / 4000000) ((69071 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((15717 : ℝ) / 100000000) ((8073 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((128894179 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((128878033 : ℝ) / 100000000) ((64439231 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((128894179 : ℝ) / 100000000) ((128894179 : ℝ) / 100000000) ((128894179 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((28894179 : ℝ) / 100000000))
  have h21 : RB z21 ((44603459 : ℝ) / 10000000) ((111509019 : ℝ) / 25000000) := rb_div_signed h20 (show RB ((28894179 : ℝ) / 100000000) ((28894179 : ℝ) / 100000000) ((28894179 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((149522631 : ℝ) / 100000000) ((149522967 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_692.1 cov_log_693.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23087659 : ℝ) / 25000000) ((92463341 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((128894179 : ℝ) / 100000000))
  have h24 : RB z24 ((6345539 : ℝ) / 25000000) ((25382157 : ℝ) / 100000000) := rb_log (show RB ((128894179 : ℝ) / 100000000) ((128894179 : ℝ) / 100000000) ((128894179 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_694.1 cov_log_694.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((66968479 : ℝ) / 100000000) ((13416237 : ℝ) / 20000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((2671577 : ℝ) / 4000000) ((33411449 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_687.1 cov_log_688.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((145581 : ℝ) / 100000000) ((3647 : ℝ) / 1250000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((15717 : ℝ) / 100000000) ((8073 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129074029 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((129057883 : ℝ) / 100000000) ((16132289 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((129074029 : ℝ) / 100000000) ((129074029 : ℝ) / 100000000) ((129074029 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29074029 : ℝ) / 100000000))
  have h30 : RB z30 ((443894043 : ℝ) / 100000000) ((2774347 : ℝ) / 625000) := rb_div_signed h29 (show RB ((29074029 : ℝ) / 100000000) ((29074029 : ℝ) / 100000000) ((29074029 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((14904157 : ℝ) / 10000000) ((74520953 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_695.1 cov_log_696.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18410703 : ℝ) / 20000000) ((92165859 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129074029 : ℝ) / 100000000))
  have h33 : RB z33 ((3190199 : ℝ) / 12500000) ((25521593 : ℝ) / 100000000) := rb_log (show RB ((129074029 : ℝ) / 100000000) ((129074029 : ℝ) / 100000000) ((129074029 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_697.1 cov_log_697.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33265961 : ℝ) / 50000000) ((66644267 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((2671577 : ℝ) / 4000000) ((33411449 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_687.1 cov_log_688.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-9093 : ℝ) / 3125000) ((-72579 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((10482643 : ℝ) / 25000000)) ((-16863 : ℝ) / 25000000) ((-4407 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((265073 : ℝ) / 625000)) ((477 : ℝ) / 4000000) ((69071 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((128894179 : ℝ) / 100000000)) ((145581 : ℝ) / 100000000) ((3647 : ℝ) / 1250000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129074029 : ℝ) / 100000000)) ((-9093 : ℝ) / 3125000) ((-72579 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_38 {k A q d vp vm : ℝ}
    (hk : RB k ((5169 : ℝ) / 3200) ((10371 : ℝ) / 6400))
    (hA : RB A ((5169 : ℝ) / 8369) ((10371 : ℝ) / 16771))
    (hq : RB q ((250741 : ℝ) / 20000000) ((1270651 : ℝ) / 100000000))
    (hd : RB d ((195012653 : ℝ) / 100000000) ((12192371 : ℝ) / 6250000))
    (hp : RB vp ((10482643 : ℝ) / 25000000) ((265073 : ℝ) / 625000))
    (hm : RB vm ((128894179 : ℝ) / 100000000) ((129074029 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((15717 : ℝ) / 100000000) ((8073 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49991927 : ℝ) / 50000000) ((99984283 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((61753679 : ℝ) / 100000000) ((6182917 : ℝ) / 10000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((18529 : ℝ) / 50000000) ((38507 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99961493 : ℝ) / 100000000) ((49981471 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((359927 : ℝ) / 625000) ((14517357 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((899471 : ℝ) / 1562500) ((58047909 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((21276797 : ℝ) / 20000000) ((167821 : ℝ) / 156250) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1276797 : ℝ) / 20000000) ((11571 : ℝ) / 156250) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49991927 : ℝ) / 50000000) ((99984283 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((61753679 : ℝ) / 100000000) ((6182917 : ℝ) / 10000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((761 : ℝ) / 6250000) ((12527 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99987473 : ℝ) / 100000000) ((6249239 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((28894179 : ℝ) / 100000000) ((29074029 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28890559 : ℝ) / 100000000) ((29070489 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((106213691 : ℝ) / 50000000) ((107005839 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((156213691 : ℝ) / 50000000) ((157005839 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((270071731 : ℝ) / 20000000) ((1566419721 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31845949 : ℝ) / 100000000) ((16003719 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5169 : ℝ) / 1600) ((10371 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((16201 : ℝ) / 400000) ((4118101 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((20250741 : ℝ) / 20000000) ((101270651 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3999431 : ℝ) / 100000000) ((508389 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((103999431 : ℝ) / 100000000) ((13008389 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((86482499 : ℝ) / 100000000) ((87143457 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((33730363 : ℝ) / 20000000) ((84998829 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27023033 : ℝ) / 50000000) ((10948493 : ℝ) / 20000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((2871 : ℝ) / 10000000) ((239 : ℝ) / 800000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((799761 : ℝ) / 800000) ((9997129 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((16860143 : ℝ) / 10000000) ((42487213 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((195012653 : ℝ) / 50000000) ((12192371 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2444883 : ℝ) / 50000000) ((61969 : ℝ) / 1250000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8369 : ℝ) / 3200) ((16771 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1865989 : ℝ) / 100000000) ((75823 : ℝ) / 4000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2956037 : ℝ) / 100000000) ((3030369 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((102956037 : ℝ) / 100000000) ((103030369 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((347568939 : ℝ) / 25000000) ((1613888019 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((485653 : ℝ) / 50000000) ((98581 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50485653 : ℝ) / 50000000) ((10098581 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3215527 : ℝ) / 10000000) ((32322971 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((711215513 : ℝ) / 50000000) ((164621099 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((13271203 : ℝ) / 50000000) ((7801291 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8369 : ℝ) / 3200) ((16771 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((103999431 : ℝ) / 50000000) ((13008389 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((345551151 : ℝ) / 25000000) ((1598427159 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1437484923 : ℝ) / 50000000) ((831718491 : ℝ) / 25000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((786117 : ℝ) / 10000000) ((911477 : ℝ) / 10000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-127161739 : ℝ) / 50000000) ((-1197637 : ℝ) / 500000) := rb_log h47 (by norm_num) cov_log_698.1 cov_log_699.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2444883 : ℝ) / 100000000) ((61969 : ℝ) / 2500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-371117297 : ℝ) / 100000000) ((-184870587 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_700.1 cov_log_701.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((2671577 : ℝ) / 4000000) ((33411449 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_687.1 cov_log_688.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((107885793 : ℝ) / 100000000) ((54142209 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-16451969 : ℝ) / 6250000) ((-65364189 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2698839 : ℝ) / 20000000) ((7420809 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((43243467 : ℝ) / 100000000) ((55916627 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-219988037 : ℝ) / 100000000) ((-205540129 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((103999431 : ℝ) / 100000000) ((13008389 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-127161739 : ℝ) / 50000000) ((-1197637 : ℝ) / 500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-219988037 : ℝ) / 100000000) ((-205540129 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((303 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2956037 : ℝ) / 100000000) ((3030369 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((103030369 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((303 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-44997321 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((303 : ℝ) / 100) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_9, cov_h_6]
  have hP : ((31023457 : ℝ) / 5000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((205540129 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((205540129 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((344 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((344 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((349 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((349 : ℝ) / 125)) (lo := ((344 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((354 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((354 : ℝ) / 125)) (lo := ((349 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((359 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((359 : ℝ) / 125)) (lo := ((354 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((364 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((364 : ℝ) / 125)) (lo := ((359 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((369 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((369 : ℝ) / 125)) (lo := ((364 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((374 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((374 : ℝ) / 125)) (lo := ((369 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((303 : ℝ) / 100)) (lo := ((374 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_38 {k : ℝ} (hk : RB k ((5169 : ℝ) / 3200) ((10371 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((5169 : ℝ) / 8369) ((10371 : ℝ) / 16771) ∧
    RB (qa (r1A k)) ((250741 : ℝ) / 20000000) ((1270651 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((195012653 : ℝ) / 100000000) ((12192371 : ℝ) / 6250000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((10095703 : ℝ) / 25000000) ((40511719 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((190088281 : ℝ) / 100000000) ((47554297 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((68936253 : ℝ) / 50000000) ((8619953 : ℝ) / 6250000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139646931 : ℝ) / 50000000) ((55868121 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139646931 : ℝ) / 100000000) ((139670303 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((195012653 : ℝ) / 100000000) ((12192371 : ℝ) / 6250000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2445703 : ℝ) / 25000000) ((9911719 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2445703 : ℝ) / 100000000) ((247793 : ℝ) / 10000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((250741 : ℝ) / 20000000) ((1270651 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((195012653 : ℝ) / 100000000) ((12192371 : ℝ) / 6250000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((250741 : ℝ) / 20000000) ((1270651 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5169 : ℝ) / 8369) ((10371 : ℝ) / 16771) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_38 {k : ℝ} (hk : RB k ((5169 : ℝ) / 3200) ((10371 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_38 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_38 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((10482643 : ℝ) / 25000000)) (ph := ((265073 : ℝ) / 625000)) (ml := ((128894179 : ℝ) / 100000000)) (mh := ((129074029 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_38 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_39 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10371 : ℝ) / 16771) ((2601 : ℝ) / 4201))
    (hq : RB (qa a) ((25413 : ℝ) / 2000000) ((160951 : ℝ) / 12500000))
    (hd : RB (D0a a) ((38989473 : ℝ) / 20000000) ((195012659 : ℝ) / 100000000))
    : certE k a ((8375739 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((42353473 : ℝ) / 100000000) ∧ 0 < certE k a ((32238573 : ℝ) / 25000000) ∧ certE k a ((32283413 : ℝ) / 25000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((3229 : ℝ) / 20000000) ((829 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8375739 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((8372423 : ℝ) / 20000000) ((837251 : ℝ) / 2000000) := rb_widen (rb_sub (show RB ((8375739 : ℝ) / 20000000) ((8375739 : ℝ) / 20000000) ((8375739 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11624261 : ℝ) / 20000000))
  have h3 : RB z3 ((72025421 : ℝ) / 100000000) ((72026171 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((11624261 : ℝ) / 20000000) ((11624261 : ℝ) / 20000000) ((11624261 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-16407553 : ℝ) / 50000000) ((-2050879 : ℝ) / 6250000) := rb_log h3 (by norm_num) cov_log_702.1 cov_log_703.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-20317089 : ℝ) / 100000000) ((-5072963 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8375739 : ℝ) / 20000000))
  have h6 : RB z6 ((-43519649 : ℝ) / 50000000) ((-1359989 : ℝ) / 1562500) := rb_log (show RB ((8375739 : ℝ) / 20000000) ((8375739 : ℝ) / 20000000) ((8375739 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_704.1 cov_log_704.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66722207 : ℝ) / 100000000) ((33373723 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66755941 : ℝ) / 100000000) ((6678943 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_705.1 cov_log_706.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-67223 : ℝ) / 100000000) ((-1699 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((3229 : ℝ) / 20000000) ((829 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42353473 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((42336893 : ℝ) / 100000000) ((2646083 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((42353473 : ℝ) / 100000000) ((42353473 : ℝ) / 100000000) ((42353473 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57646527 : ℝ) / 100000000))
  have h12 : RB z12 ((36721113 : ℝ) / 50000000) ((36721491 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((57646527 : ℝ) / 100000000) ((57646527 : ℝ) / 100000000) ((57646527 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-30867113 : ℝ) / 100000000) ((-30866083 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_707.1 cov_log_708.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4777753 : ℝ) / 25000000) ((-9543621 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42353473 : ℝ) / 100000000))
  have h15 : RB z15 ((-42955989 : ℝ) / 50000000) ((-10738997 : ℝ) / 12500000) := rb_log (show RB ((42353473 : ℝ) / 100000000) ((42353473 : ℝ) / 100000000) ((42353473 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_709.1 cov_log_709.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16700241 : ℝ) / 25000000) ((2088273 : ℝ) / 3125000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66755941 : ℝ) / 100000000) ((6678943 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_705.1 cov_log_706.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((5767 : ℝ) / 50000000) ((13759 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((3229 : ℝ) / 20000000) ((829 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((32238573 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((8058607 : ℝ) / 6250000) ((128938147 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((32238573 : ℝ) / 25000000) ((32238573 : ℝ) / 25000000) ((32238573 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((7238573 : ℝ) / 25000000))
  have h21 : RB z21 ((445314677 : ℝ) / 100000000) ((22265809 : ℝ) / 5000000) := rb_div_signed h20 (show RB ((7238573 : ℝ) / 25000000) ((7238573 : ℝ) / 25000000) ((7238573 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((74680549 : ℝ) / 50000000) ((74680719 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_710.1 cov_log_711.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46181621 : ℝ) / 50000000) ((92475387 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((32238573 : ℝ) / 25000000))
  have h24 : RB z24 ((25428783 : ℝ) / 100000000) ((1589299 : ℝ) / 6250000) := rb_log (show RB ((32238573 : ℝ) / 25000000) ((32238573 : ℝ) / 25000000) ((32238573 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_712.1 cov_log_712.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33467229 : ℝ) / 50000000) ((16761651 : ℝ) / 25000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66755941 : ℝ) / 100000000) ((6678943 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_705.1 cov_log_706.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((36257 : ℝ) / 25000000) ((290663 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((3229 : ℝ) / 20000000) ((829 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((32283413 : ℝ) / 25000000)) - (z28)
  have h29 : RB z29 ((8069817 : ℝ) / 6250000) ((129117507 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((32283413 : ℝ) / 25000000) ((32283413 : ℝ) / 25000000) ((32283413 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((7283413 : ℝ) / 25000000))
  have h30 : RB z30 ((443188763 : ℝ) / 100000000) ((443190257 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((7283413 : ℝ) / 25000000) ((7283413 : ℝ) / 25000000) ((7283413 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((148882559 : ℝ) / 100000000) ((148882899 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_713.1 cov_log_714.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92067319 : ℝ) / 100000000) ((46089553 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((32283413 : ℝ) / 25000000))
  have h33 : RB z33 ((12783887 : ℝ) / 50000000) ((1022711 : ℝ) / 4000000) := rb_log (show RB ((32283413 : ℝ) / 25000000) ((32283413 : ℝ) / 25000000) ((32283413 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_715.1 cov_log_715.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((8312443 : ℝ) / 12500000) ((16652833 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66755941 : ℝ) / 100000000) ((6678943 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_705.1 cov_log_706.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-144943 : ℝ) / 50000000) ((-144609 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8375739 : ℝ) / 20000000)) ((-67223 : ℝ) / 100000000) ((-1699 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42353473 : ℝ) / 100000000)) ((5767 : ℝ) / 50000000) ((13759 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((32238573 : ℝ) / 25000000)) ((36257 : ℝ) / 25000000) ((290663 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((32283413 : ℝ) / 25000000)) ((-144943 : ℝ) / 50000000) ((-144609 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_39 {k A q d vp vm : ℝ}
    (hk : RB k ((10371 : ℝ) / 6400) ((2601 : ℝ) / 1600))
    (hA : RB A ((10371 : ℝ) / 16771) ((2601 : ℝ) / 4201))
    (hq : RB q ((25413 : ℝ) / 2000000) ((160951 : ℝ) / 12500000))
    (hd : RB d ((38989473 : ℝ) / 20000000) ((195012659 : ℝ) / 100000000))
    (hp : RB vp ((8375739 : ℝ) / 20000000) ((42353473 : ℝ) / 100000000))
    (hm : RB vm ((32238573 : ℝ) / 25000000) ((32283413 : ℝ) / 25000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((3229 : ℝ) / 20000000) ((829 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((4999171 : ℝ) / 5000000) ((19996771 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((12365727 : ℝ) / 20000000) ((12380767 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((38119 : ℝ) / 100000000) ((39591 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99960409 : ℝ) / 100000000) ((99961881 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57646527 : ℝ) / 100000000) ((11624261 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7202963 : ℝ) / 12500000) ((1161983 : ℝ) / 2000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106419173 : ℝ) / 100000000) ((107427727 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6419173 : ℝ) / 100000000) ((7427727 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((4999171 : ℝ) / 5000000) ((19996771 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((12365727 : ℝ) / 20000000) ((12380767 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((6251 : ℝ) / 50000000) ((6429 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49993571 : ℝ) / 50000000) ((49993749 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((7238573 : ℝ) / 25000000) ((7283413 : ℝ) / 25000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28950569 : ℝ) / 100000000) ((2913001 : ℝ) / 10000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((26531331 : ℝ) / 12500000) ((213825971 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((39031331 : ℝ) / 12500000) ((313825971 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((336576721 : ℝ) / 25000000) ((1557833073 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15932397 : ℝ) / 50000000) ((6405111 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10371 : ℝ) / 3200) ((2601 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4118097 : ℝ) / 100000000) ((130823 : ℝ) / 3125000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((2025413 : ℝ) / 2000000) ((12660951 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2032873 : ℝ) / 50000000) ((413381 : ℝ) / 10000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((52032873 : ℝ) / 50000000) ((10413381 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((86600819 : ℝ) / 100000000) ((87254957 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((84413007 : ℝ) / 50000000) ((42539553 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27002187 : ℝ) / 50000000) ((54692587 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((29519 : ℝ) / 100000000) ((15351 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49984649 : ℝ) / 50000000) ((99970481 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((168774181 : ℝ) / 100000000) ((170107983 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((38989473 : ℝ) / 10000000) ((195012659 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4954197 : ℝ) / 100000000) ((2510999 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16771 : ℝ) / 6400) ((4201 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1886863 : ℝ) / 100000000) ((1916451 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((750027 : ℝ) / 25000000) ((1537307 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25750027 : ℝ) / 25000000) ((51537307 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((173337193 : ℝ) / 12500000) ((1605730427 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((49199 : ℝ) / 5000000) ((1997 : ℝ) / 200000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((5049199 : ℝ) / 5000000) ((201997 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32178337 : ℝ) / 100000000) ((32345331 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1418875881 : ℝ) / 100000000) ((819037879 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((6693061 : ℝ) / 25000000) ((784823 : ℝ) / 2500000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16771 : ℝ) / 6400) ((4201 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((52032873 : ℝ) / 25000000) ((10413381 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((689085839 : ℝ) / 50000000) ((397464657 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((114736371 : ℝ) / 4000000) ((1655580363 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((123657 : ℝ) / 1562500) ((9153593 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-126826541 : ℝ) / 50000000) ((-23910237 : ℝ) / 10000000) := rb_log h47 (by norm_num) cov_log_716.1 cov_log_717.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1238549 : ℝ) / 50000000) ((2510999 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-92452063 : ℝ) / 25000000) ((-7368979 : ℝ) / 2000000) := rb_log h49 (by norm_num) cov_log_718.1 cov_log_719.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66755941 : ℝ) / 100000000) ((6678943 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_705.1 cov_log_706.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((27043979 : ℝ) / 25000000) ((13571821 : ℝ) / 12500000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-16352021 : ℝ) / 6250000) ((-129937191 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1666883 : ℝ) / 12500000) ((14668867 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((21238967 : ℝ) / 50000000) ((2191653 : ℝ) / 4000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-109577201 : ℝ) / 50000000) ((-205083057 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((52032873 : ℝ) / 50000000) ((10413381 : ℝ) / 10000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-126826541 : ℝ) / 50000000) ((-23910237 : ℝ) / 10000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-109577201 : ℝ) / 50000000) ((-205083057 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((151 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((750027 : ℝ) / 25000000) ((1537307 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((51537307 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((151 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-71697 : ℝ) / 32000) ≤ formC0 k A q vp vm + hfun ((151 : ℝ) / 50) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_11, cov_h_6]
  have hP : ((618692837 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((205083057 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((205083057 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((551 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((551 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((559 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((559 : ℝ) / 200)) (lo := ((551 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((567 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((567 : ℝ) / 200)) (lo := ((559 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((23 : ℝ) / 8) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((23 : ℝ) / 8)) (lo := ((567 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((583 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((583 : ℝ) / 200)) (lo := ((23 : ℝ) / 8)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((591 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((591 : ℝ) / 200)) (lo := ((583 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((599 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((599 : ℝ) / 200)) (lo := ((591 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((151 : ℝ) / 50)) (lo := ((599 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_39 {k : ℝ} (hk : RB k ((10371 : ℝ) / 6400) ((2601 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((10371 : ℝ) / 16771) ((2601 : ℝ) / 4201) ∧
    RB (qa (r1A k)) ((25413 : ℝ) / 2000000) ((160951 : ℝ) / 12500000) ∧ RB (D0a (r1A k)) ((38989473 : ℝ) / 20000000) ((195012659 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((20255859 : ℝ) / 50000000) ((2601 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((60787 : ℝ) / 32000) ((95044141 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((551303 : ℝ) / 400000) ((34468127 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139623553 : ℝ) / 50000000) ((55858773 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139623553 : ℝ) / 100000000) ((139646933 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((38989473 : ℝ) / 20000000) ((195012659 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4955859 : ℝ) / 50000000) ((3213 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2477929 : ℝ) / 100000000) ((2510157 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((25413 : ℝ) / 2000000) ((160951 : ℝ) / 12500000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((38989473 : ℝ) / 20000000) ((195012659 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((25413 : ℝ) / 2000000) ((160951 : ℝ) / 12500000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10371 : ℝ) / 16771) ((2601 : ℝ) / 4201) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_39 {k : ℝ} (hk : RB k ((10371 : ℝ) / 6400) ((2601 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_39 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_39 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((8375739 : ℝ) / 20000000)) (ph := ((42353473 : ℝ) / 100000000)) (ml := ((32238573 : ℝ) / 25000000)) (mh := ((32283413 : ℝ) / 25000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_39 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
