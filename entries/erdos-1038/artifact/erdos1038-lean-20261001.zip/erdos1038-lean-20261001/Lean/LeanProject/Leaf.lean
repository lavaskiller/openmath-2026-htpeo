import LeanProject.Degree2

/-!
# EP-1038: soundness of a `P` leaf of the Phase I certificates (proof.md Lemma 1.4, measure part)

`cert/check.py` accepts a leaf `P a₁ b₁ …` for a box `B = ∏ [l_i, u_i]` when each interval
`J_j = [a_j, b_j]` satisfies `P(B, J_j) = ∏_i max(|a_j-l_i|, |a_j-u_i|, |b_j-l_i|, |b_j-u_i|) < 1`,
the intervals have disjoint interiors, and `∑ |J_j| ≥ T`. This file proves that such a leaf gives
`|{x : |∏ (x - r_i)| < 1}| ≥ ∑ |J_j|` for every `r ∈ B`.
-/

open Real MeasureTheory Finset

namespace EP1038

/-- Rectangle bound, product form (Lemma 1.4): for `r ∈ B` and `x ∈ [a, b]`,
`|∏ (x - r_i)| ≤ P(B, [a, b])`. -/
theorem rect_prod_le {n : ℕ} (l u r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (l i) (u i))
    {a b x : ℝ} (hx : x ∈ Set.Icc a b) :
    |∏ i, (x - r i)| ≤ ∏ i, max (max |a - l i| |a - u i|) (max |b - l i| |b - u i|) := by
  rw [Finset.abs_prod]
  gcongr with i hi
  exact rect_factor_le hx (hr i)

/-- Soundness of a `P` leaf. -/
theorem leaf_sound {n m : ℕ} (l u r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (l i) (u i))
    (a b : Fin m → ℝ)
    (hdisj : Pairwise (Function.onFun Disjoint fun j => Set.Ioo (a j) (b j)))
    (hP : ∀ j, ∏ i, max (max |a j - l i| |a j - u i|) (max |b j - l i| |b j - u i|) < 1) :
    ∑ j, ENNReal.ofReal (b j - a j) ≤ volume {x : ℝ | |∏ i, (x - r i)| < 1} := by
  have hsub : (⋃ j, Set.Ioo (a j) (b j)) ⊆ {x : ℝ | |∏ i, (x - r i)| < 1} := by
    intro x hx
    obtain ⟨j, hj⟩ := Set.mem_iUnion.mp hx
    exact lt_of_le_of_lt (rect_prod_le l u r hr (Set.Ioo_subset_Icc_self hj)) (hP j)
  calc ∑ j, ENNReal.ofReal (b j - a j) = ∑ j, volume (Set.Ioo (a j) (b j)) := by
        simp [Real.volume_Ioo]
    _ = volume (⋃ j, Set.Ioo (a j) (b j)) := by
        rw [measure_iUnion hdisj (fun _ => measurableSet_Ioo), tsum_fintype]
    _ ≤ _ := measure_mono hsub

end EP1038
