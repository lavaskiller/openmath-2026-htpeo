import LeanProject.CircRearr
import Mathlib.Analysis.SpecialFunctions.Integrability.LogMeromorphic

/-!
# EP-1038, Stage 12, Theorem 12.8 step 3: circle rearrangement for the log-sine kernel

* `Lsin u = -log|sin(u/2)|` (the kernel `𝓛` of Theorem 12.8; `log 0 = 0` on the null set
  `2πℤ`), `LN N = min(𝓛, N)` (with the value `N` on `2πℤ`), `LN_symDec`.
* `circle_rearrangement_log`: for measurable `2π`-periodic `f, g` with values in `[0, 1]` and
  masses `2Q`, `2R`: `∬ f(θ) 𝓛(θ - φ) g(φ) ≤ ∫_{-R}^{R} ∫_{-Q}^{Q} 𝓛(φ - t) dt dφ`.
  Proof: Theorem 12.6R for each `𝓛_N`, then dominated convergence (dominated by `𝓛`).
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Circ

/-- The log-sine kernel `𝓛(u) = -log|sin(u/2)|`. -/
noncomputable def Lsin (u : ℝ) : ℝ := -Real.log |Real.sin (u / 2)|

/-- The truncation `𝓛_N = min(𝓛, N)`, with the value `N` on `2πℤ`. -/
noncomputable def LN (N : ℕ) (u : ℝ) : ℝ :=
  if Real.sin (u / 2) = 0 then (N : ℝ) else min (Lsin u) N

theorem Lsin_nonneg (u : ℝ) : 0 ≤ Lsin u := by
  unfold Lsin
  rw [neg_nonneg]
  exact Real.log_nonpos (abs_nonneg _) (Real.abs_sin_le_one _)

theorem Lsin_periodic : Function.Periodic Lsin (2 * π) := fun u => by
  unfold Lsin
  rw [show (u + 2 * π) / 2 = u / 2 + π by ring, Real.sin_add_pi, abs_neg]

theorem LN_nonneg (N : ℕ) (u : ℝ) : 0 ≤ LN N u := by
  unfold LN
  split_ifs
  · positivity
  · exact le_min (Lsin_nonneg u) (by positivity)

theorem LN_symDec (N : ℕ) : SymDecC (LN N) := by
  refine ⟨fun u => ?_, fun u => ?_, ?_⟩
  · have h1 : Real.sin ((u + 2 * π) / 2) = -Real.sin (u / 2) := by
      rw [show (u + 2 * π) / 2 = u / 2 + π by ring, Real.sin_add_pi]
    unfold LN
    simp only [h1, neg_eq_zero, Lsin_periodic u]
  · have h1 : Real.sin (-u / 2) = -Real.sin (u / 2) := by
      rw [show -u / 2 = -(u / 2) by ring, Real.sin_neg]
    have h2 : Lsin (-u) = Lsin u := by
      unfold Lsin; rw [h1, abs_neg]
    unfold LN
    simp only [h1, neg_eq_zero, h2]
  · intro x hx y hy hxy
    have hπ := Real.pi_pos
    unfold LN
    by_cases hx0 : Real.sin (x / 2) = 0
    · rw [ite_eq_left hx0]
      split_ifs
      · exact le_rfl
      · exact min_le_right _ _
    · have hxpos : 0 < x := by
        rcases lt_or_eq_of_le hx.1 with h | h
        · exact h
        · exact absurd (by rw [← h]; simp) hx0
      have hsx : 0 < Real.sin (x / 2) := Real.sin_pos_of_pos_of_lt_pi (by linarith) (by linarith [hx.2])
      have hsy : 0 < Real.sin (y / 2) := Real.sin_pos_of_pos_of_lt_pi (by linarith) (by linarith [hy.2])
      rw [ite_eq_right hx0, ite_eq_right hsy.ne']
      apply min_le_min_right
      unfold Lsin
      rw [abs_of_pos hsx, abs_of_pos hsy, neg_le_neg_iff]
      exact Real.log_le_log hsx (Real.sin_le_sin_of_le_of_le_pi_div_two (by linarith)
        (by linarith [hy.2]) (by linarith))

theorem LN_le_Lsin {N : ℕ} {u : ℝ} (h : Real.sin (u / 2) ≠ 0) : LN N u ≤ Lsin u := by
  unfold LN; rw [ite_eq_right h]; exact min_le_left _ _

theorem LN_tendsto {u : ℝ} (h : Real.sin (u / 2) ≠ 0) :
    Tendsto (fun N : ℕ => LN N u) atTop (𝓝 (Lsin u)) := by
  refine tendsto_const_nhds.congr' ?_
  filter_upwards [eventually_ge_atTop ⌈Lsin u⌉₊] with N hN
  unfold LN
  rw [ite_eq_right h, min_eq_left ((Nat.le_ceil _).trans (by exact_mod_cast hN))]

theorem Lsin_measurable : Measurable Lsin := by
  unfold Lsin
  exact (Real.measurable_log.comp
    (Real.continuous_sin.comp (continuous_id.div_const 2)).abs.measurable).neg

/-- `u ↦ 𝓛(c - u)` is integrable on every interval. -/
theorem Lsin_ii (c a b : ℝ) : IntervalIntegrable (fun u => Lsin (c - u)) volume a b := by
  have h0 : ∀ a b : ℝ, IntervalIntegrable (fun x => Real.log (Real.sin x)) volume a b :=
    fun a b => intervalIntegrable_log_sin
  -- `x ↦ log (sin (c/2 + x))` on every interval
  have h1 : ∀ a b : ℝ, IntervalIntegrable (fun x => Real.log (Real.sin (c / 2 + x))) volume a b := by
    intro a b
    have := (h0 (a + c / 2) (b + c / 2)).comp_add_left (c / 2)
    simpa using this
  -- then `u ↦ log (sin (c/2 + (-1/2) u))`
  have h2 := (h1 (-(1 / 2) * a) (-(1 / 2) * b)).comp_mul_left (c := -(1 / 2))
  have e1 : -(1 / 2) * a / -(1 / 2) = a := by field_simp
  have e2 : -(1 / 2) * b / -(1 / 2) = b := by field_simp
  rw [e1, e2] at h2
  have e : (fun u => Lsin (c - u)) = fun u => -Real.log (Real.sin (c / 2 + -(1 / 2) * u)) := by
    funext u
    unfold Lsin
    rw [Real.log_abs, show c / 2 + -(1 / 2) * u = (c - u) / 2 by ring]
  rw [e]
  exact h2.neg

/-- The zero set of `u ↦ sin((c - u)/2)` is null. -/
theorem ae_sin_ne (c : ℝ) : ∀ᵐ u ∂(volume : Measure ℝ), Real.sin ((c - u) / 2) ≠ 0 := by
  have hsub : {u : ℝ | Real.sin ((c - u) / 2) = 0} ⊆ Set.range (fun k : ℤ => c - 2 * π * k) := by
    intro u hu
    obtain ⟨k, hk⟩ := Real.sin_eq_zero_iff.mp hu
    exact ⟨k, by linarith⟩
  have hnull : volume {u : ℝ | Real.sin ((c - u) / 2) = 0} = 0 :=
    measure_mono_null hsub ((Set.countable_range _).measure_zero _)
  rw [ae_iff]
  simpa using hnull

/-- `∫_{-π}^{π} 𝓛(c - u) du` does not depend on `c`. -/
theorem int_Lsin_shift (c : ℝ) :
    ∫ u in (-π)..π, Lsin (c - u) = ∫ s in (-π)..π, Lsin s := by
  rw [intervalIntegral.integral_comp_sub_left Lsin c]
  have := Lsin_periodic.intervalIntegral_add_eq (c - π) (-π)
  rw [show c - π + 2 * π = c - -π by ring, show -π + 2 * π = π by ring] at this
  exact this

/-- **Theorem 12.8, step 3**: the circle rearrangement inequality for the log-sine kernel. -/
theorem circle_rearrangement_log {f g : ℝ → ℝ} (hfm : Measurable f) (hgm : Measurable g)
    (hfp : Function.Periodic f (2 * π)) (hgp : Function.Periodic g (2 * π))
    (hf0 : ∀ x, 0 ≤ f x) (hf1 : ∀ x, f x ≤ 1) (hg0 : ∀ x, 0 ≤ g x) (hg1 : ∀ x, g x ≤ 1)
    {Q R : ℝ} (hfmass : ∫ θ in (-π)..π, f θ = 2 * Q) (hgmass : ∫ θ in (-π)..π, g θ = 2 * R) :
    IK Lsin f g ≤ VK Lsin Q R := by
  have hπ := Real.pi_pos
  have hN : ∀ N : ℕ, IK (LN N) f g ≤ VK (LN N) Q R := fun N =>
    circle_rearrangement (LN_symDec N) hfm hgm hfp hgp hf0 hf1 hg0 hg1 hfmass hgmass
  set C := ∫ s in (-π)..π, Lsin s with hC
  have hgb : Bdd g := ⟨hgm, 1, fun x => abs_le.mpr ⟨by linarith [hg0 x], hg1 x⟩⟩
  have hfb : Bdd f := ⟨hfm, 1, fun x => abs_le.mpr ⟨by linarith [hf0 x], hf1 x⟩⟩
  -- the inner (convolution) limits, with the uniform bound `C`
  have hconv_lim : ∀ θ, Tendsto (fun N : ℕ => conv (LN N) g θ) atTop (𝓝 (conv Lsin g θ)) := by
    intro θ
    unfold conv
    refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
      (fun u => Lsin (θ - u)) (Eventually.of_forall fun N =>
        (((LN_symDec N).bdd.comp_sub θ).mul hgb).meas.aestronglyMeasurable) ?_ (Lsin_ii θ _ _) ?_
    · refine Eventually.of_forall fun N => ?_
      filter_upwards [ae_sin_ne θ] with u hu _
      rw [Real.norm_eq_abs, abs_of_nonneg (mul_nonneg (LN_nonneg _ _) (hg0 u))]
      calc LN N (θ - u) * g u ≤ LN N (θ - u) * 1 :=
            mul_le_mul_of_nonneg_left (hg1 u) (LN_nonneg _ _)
        _ ≤ Lsin (θ - u) := by rw [mul_one]; exact LN_le_Lsin hu
    · filter_upwards [ae_sin_ne θ] with u hu _
      exact (LN_tendsto hu).mul_const (g u)
  have hconv_bd : ∀ (N : ℕ) θ, 0 ≤ conv (LN N) g θ ∧ conv (LN N) g θ ≤ C := by
    intro N θ
    unfold conv
    constructor
    · exact intervalIntegral.integral_nonneg (by linarith)
        (fun u _ => mul_nonneg (LN_nonneg _ _) (hg0 u))
    · rw [hC, ← int_Lsin_shift θ]
      refine intervalIntegral.integral_mono_ae (by linarith)
        ((((LN_symDec N).bdd.comp_sub θ).mul hgb).ii _ _) (Lsin_ii θ _ _) ?_
      filter_upwards [ae_sin_ne θ] with u hu
      calc LN N (θ - u) * g u ≤ LN N (θ - u) * 1 :=
            mul_le_mul_of_nonneg_left (hg1 u) (LN_nonneg _ _)
        _ ≤ Lsin (θ - u) := by rw [mul_one]; exact LN_le_Lsin hu
  -- `I_{𝓛_N}(f, g) → I_𝓛(f, g)`
  have t1 : Tendsto (fun N : ℕ => IK (LN N) f g) atTop (𝓝 (IK Lsin f g)) := by
    unfold IK
    refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence (fun _ => C)
      (Eventually.of_forall fun N => (hfb.meas.mul (conv_measurable (LN_symDec N).bdd.meas
        hgm)).aestronglyMeasurable) ?_ intervalIntegrable_const ?_
    · refine Eventually.of_forall fun N => Eventually.of_forall fun θ _ => ?_
      obtain ⟨b0, b1⟩ := hconv_bd N θ
      rw [Real.norm_eq_abs, abs_of_nonneg (mul_nonneg (hf0 θ) b0)]
      calc f θ * conv (LN N) g θ ≤ 1 * C := mul_le_mul (hf1 θ) b1 b0 zero_le_one
        _ = C := one_mul C
    · exact Eventually.of_forall fun θ _ => (hconv_lim θ).const_mul (f θ)
  -- `V_{𝓛_N}(Q, R) → V_𝓛(Q, R)`
  have t2 : Tendsto (fun N : ℕ => VK (LN N) Q R) atTop (𝓝 (VK Lsin Q R)) := by
    unfold VK
    have hw_lim : ∀ φ, Tendsto (fun N : ℕ => win (LN N) Q φ) atTop (𝓝 (win Lsin Q φ)) := by
      intro φ
      unfold win
      refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
        (fun t => Lsin (φ - t)) (Eventually.of_forall fun N =>
          ((LN_symDec N).bdd.comp_sub φ).meas.aestronglyMeasurable) ?_ (Lsin_ii φ _ _) ?_
      · refine Eventually.of_forall fun N => ?_
        filter_upwards [ae_sin_ne φ] with t ht _
        rw [Real.norm_eq_abs, abs_of_nonneg (LN_nonneg _ _)]
        exact LN_le_Lsin ht
      · filter_upwards [ae_sin_ne φ] with t ht _
        exact LN_tendsto ht
    -- a uniform bound for `|win (LN N) Q φ|`
    refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
      (fun φ => ∫ t in (-|Q|)..|Q|, Lsin (φ - t))
      (Eventually.of_forall fun N => (win_bdd (LN_symDec N).bdd Q).meas.aestronglyMeasurable)
      ?_ ?_ (Eventually.of_forall fun φ _ => hw_lim φ)
    · refine Eventually.of_forall fun N => Eventually.of_forall fun φ _ => ?_
      unfold win
      rw [Real.norm_eq_abs]
      calc |∫ t in (-Q)..Q, LN N (φ - t)| ≤ ∫ t in (-|Q|)..|Q|, LN N (φ - t) := by
            rcases le_total 0 Q with hQ | hQ
            · rw [abs_of_nonneg hQ, abs_of_nonneg (intervalIntegral.integral_nonneg (by linarith)
                (fun t _ => LN_nonneg _ _))]
            · rw [abs_of_nonpos hQ, intervalIntegral.integral_symm, neg_neg, abs_neg,
                abs_of_nonneg (intervalIntegral.integral_nonneg (by linarith)
                  (fun t _ => LN_nonneg _ _))]
        _ ≤ ∫ t in (-|Q|)..|Q|, Lsin (φ - t) := by
            refine intervalIntegral.integral_mono_ae (by linarith [abs_nonneg Q])
              (((LN_symDec N).bdd.comp_sub φ).ii _ _) (Lsin_ii φ _ _) ?_
            filter_upwards [ae_sin_ne φ] with t ht
            exact LN_le_Lsin ht
    · -- the bound is integrable: it is `win Lsin |Q|`, continuous in `φ`
      have hcont : Continuous (fun φ => ∫ t in (-|Q|)..|Q|, Lsin (φ - t)) := by
        have hint : ∀ a b : ℝ, IntervalIntegrable Lsin volume a b := by
          intro a b
          have := Lsin_ii 0 (-b) (-a)
          have h' := this.comp_sub_left 0
          simpa using h'.symm
        have hP := intervalIntegral.continuous_primitive (μ := volume) hint 0
        have e : (fun φ => ∫ t in (-|Q|)..|Q|, Lsin (φ - t)) =
            fun φ => (∫ s in (0 : ℝ)..(φ + |Q|), Lsin s) - ∫ s in (0 : ℝ)..(φ - |Q|), Lsin s := by
          funext φ
          rw [intervalIntegral.integral_comp_sub_left Lsin φ, sub_neg_eq_add,
            intervalIntegral.integral_interval_sub_left (hint _ _) (hint _ _)]
        rw [e]
        exact (hP.comp (continuous_id.add continuous_const)).sub
          (hP.comp (continuous_id.sub continuous_const))
      exact hcont.intervalIntegrable _ _
  exact le_of_tendsto_of_tendsto' t1 t2 hN

end EP1038.Circ
