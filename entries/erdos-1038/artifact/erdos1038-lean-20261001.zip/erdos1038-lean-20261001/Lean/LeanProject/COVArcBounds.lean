import LeanProject.ArcNumerical
import LeanProject.COVLogBounds
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_h_0 : ((153189 : ℝ) / 10000000) ≤ hfun ((309 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((309 : ℝ) / 100)) ^ 2 ≤ ((133011 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((309 : ℝ) / 100)) 1]
    have hx : RB |1 * ((309 : ℝ) / 100) - (1 : ℝ) * π| ((103 : ℝ) / 2000) ((129 : ℝ) / 2500) := by
      have hz : ((-129 : ℝ) / 2500) ≤ 1 * ((309 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((309 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-103 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((133011 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((309 : ℝ) / 100)) ^ 2 ≤ ((1061271 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((309 : ℝ) / 100)) 2]
    have hx : RB |2 * ((309 : ℝ) / 100) - (2 : ℝ) * π| ((103 : ℝ) / 1000) ((129 : ℝ) / 1250) := by
      have hz : ((-129 : ℝ) / 1250) ≤ 2 * ((309 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((309 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-103 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1061271 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((309 : ℝ) / 100)) ^ 2 ≤ ((118867 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (3 * ((309 : ℝ) / 100)) 3]
    have hx : RB |3 * ((309 : ℝ) / 100) - (3 : ℝ) * π| ((309 : ℝ) / 2000) ((387 : ℝ) / 2500) := by
      have hz : ((-387 : ℝ) / 2500) ≤ 3 * ((309 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((309 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-309 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((118867 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((309 : ℝ) / 100)) ^ 2 ≤ ((4200319 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((309 : ℝ) / 100)) 4]
    have hx : RB |4 * ((309 : ℝ) / 100) - (4 : ℝ) * π| ((103 : ℝ) / 500) ((129 : ℝ) / 625) := by
      have hz : ((-129 : ℝ) / 625) ≤ 4 * ((309 : ℝ) / 100) - (4 : ℝ) * π ∧ 4 * ((309 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-103 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4200319 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((309 : ℝ) / 100)) ^ 2 ≤ ((3255479 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (5 * ((309 : ℝ) / 100)) 5]
    have hx : RB |5 * ((309 : ℝ) / 100) - (5 : ℝ) * π| ((103 : ℝ) / 400) ((129 : ℝ) / 500) := by
      have hz : ((-129 : ℝ) / 500) ≤ 5 * ((309 : ℝ) / 100) - (5 : ℝ) * π ∧ 5 * ((309 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-103 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3255479 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((309 : ℝ) / 100)) ^ 2 ≤ ((928489 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (6 * ((309 : ℝ) / 100)) 6]
    have hx : RB |6 * ((309 : ℝ) / 100) - (6 : ℝ) * π| ((309 : ℝ) / 1000) ((387 : ℝ) / 1250) := by
      have hz : ((-387 : ℝ) / 1250) ≤ 6 * ((309 : ℝ) / 100) - (6 : ℝ) * π ∧ 6 * ((309 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-309 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((928489 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((309 : ℝ) / 100)) ^ 2 ≤ ((2498581 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (7 * ((309 : ℝ) / 100)) 7]
    have hx : RB |7 * ((309 : ℝ) / 100) - (7 : ℝ) * π| ((721 : ℝ) / 2000) ((903 : ℝ) / 2500) := by
      have hz : ((-903 : ℝ) / 2500) ≤ 7 * ((309 : ℝ) / 100) - (7 : ℝ) * π ∧ 7 * ((309 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-721 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2498581 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((309 : ℝ) / 100)) ^ 2 ≤ ((16101289 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((309 : ℝ) / 100)) 8]
    have hx : RB |8 * ((309 : ℝ) / 100) - (8 : ℝ) * π| ((103 : ℝ) / 250) ((258 : ℝ) / 625) := by
      have hz : ((-258 : ℝ) / 625) ≤ 8 * ((309 : ℝ) / 100) - (8 : ℝ) * π ∧ 8 * ((309 : ℝ) / 100) - (8 : ℝ) * π ≤ ((-103 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16101289 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((309 : ℝ) / 100)) ^ 2 ≤ ((5018053 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (9 * ((309 : ℝ) / 100)) 9]
    have hx : RB |9 * ((309 : ℝ) / 100) - (9 : ℝ) * π| ((927 : ℝ) / 2000) ((1161 : ℝ) / 2500) := by
      have hz : ((-1161 : ℝ) / 2500) ≤ 9 * ((309 : ℝ) / 100) - (9 : ℝ) * π ∧ 9 * ((309 : ℝ) / 100) - (9 : ℝ) * π ≤ ((-927 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5018053 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((309 : ℝ) / 100)) ^ 2 ≤ ((24364161 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((309 : ℝ) / 100)) 10]
    have hx : RB |10 * ((309 : ℝ) / 100) - (10 : ℝ) * π| ((103 : ℝ) / 200) ((129 : ℝ) / 250) := by
      have hz : ((-129 : ℝ) / 250) ≤ 10 * ((309 : ℝ) / 100) - (10 : ℝ) * π ∧ 10 * ((309 : ℝ) / 100) - (10 : ℝ) * π ≤ ((-103 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24364161 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((309 : ℝ) / 100)) ^ 2 ≤ ((7233107 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (11 * ((309 : ℝ) / 100)) 11]
    have hx : RB |11 * ((309 : ℝ) / 100) - (11 : ℝ) * π| ((1133 : ℝ) / 2000) ((1419 : ℝ) / 2500) := by
      have hz : ((-1419 : ℝ) / 2500) ≤ 11 * ((309 : ℝ) / 100) - (11 : ℝ) * π ∧ 11 * ((309 : ℝ) / 100) - (11 : ℝ) * π ≤ ((-1133 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7233107 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((309 : ℝ) / 100)) ^ 2 ≤ ((1686481 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (12 * ((309 : ℝ) / 100)) 12]
    have hx : RB |12 * ((309 : ℝ) / 100) - (12 : ℝ) * π| ((309 : ℝ) / 500) ((387 : ℝ) / 625) := by
      have hz : ((-387 : ℝ) / 625) ≤ 12 * ((309 : ℝ) / 100) - (12 : ℝ) * π ∧ 12 * ((309 : ℝ) / 100) - (12 : ℝ) * π ≤ ((-309 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1686481 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((309 : ℝ) / 100) n) ≤ ((84673 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1652929 : ℝ) / 100000000) ≤ Real.log (π / ((309 : ℝ) / 100)) := by
    apply cov_log_2612.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((309 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_1 : ((6584279 : ℝ) / 25000000) ≤ hfun ((8 : ℝ) / 5) := by
  have s1 : Real.sin (1 * ((8 : ℝ) / 5)) ^ 2 ≤ ((49957381 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (1 * ((8 : ℝ) / 5)) 0]
    have hx : RB |1 * ((8 : ℝ) / 5) - ((1 : ℝ) / 2) * π| ((73 : ℝ) / 2500) ((117 : ℝ) / 4000) := by
      have hz : ((73 : ℝ) / 2500) ≤ 1 * ((8 : ℝ) / 5) - ((1 : ℝ) / 2) * π ∧ 1 * ((8 : ℝ) / 5) - ((1 : ℝ) / 2) * π ≤ ((117 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49957381 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((8 : ℝ) / 5)) ^ 2 ≤ ((341837 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((8 : ℝ) / 5)) 1]
    have hx : RB |2 * ((8 : ℝ) / 5) - (1 : ℝ) * π| ((73 : ℝ) / 1250) ((117 : ℝ) / 2000) := by
      have hz : ((73 : ℝ) / 1250) ≤ 2 * ((8 : ℝ) / 5) - (1 : ℝ) * π ∧ 2 * ((8 : ℝ) / 5) - (1 : ℝ) * π ≤ ((117 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((341837 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((8 : ℝ) / 5)) ^ 2 ≤ ((12404339 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (3 * ((8 : ℝ) / 5)) 1]
    have hx : RB |3 * ((8 : ℝ) / 5) - ((3 : ℝ) / 2) * π| ((219 : ℝ) / 2500) ((351 : ℝ) / 4000) := by
      have hz : ((219 : ℝ) / 2500) ≤ 3 * ((8 : ℝ) / 5) - ((3 : ℝ) / 2) * π ∧ 3 * ((8 : ℝ) / 5) - ((3 : ℝ) / 2) * π ≤ ((351 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12404339 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((8 : ℝ) / 5)) ^ 2 ≤ ((681349 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((8 : ℝ) / 5)) 2]
    have hx : RB |4 * ((8 : ℝ) / 5) - (2 : ℝ) * π| ((73 : ℝ) / 625) ((117 : ℝ) / 1000) := by
      have hz : ((73 : ℝ) / 625) ≤ 4 * ((8 : ℝ) / 5) - (2 : ℝ) * π ∧ 4 * ((8 : ℝ) / 5) - (2 : ℝ) * π ≤ ((117 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((681349 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((8 : ℝ) / 5)) ^ 2 ≤ ((3915379 : ℝ) / 4000000) := by
    rw [sin_sq_shift_half_pi (5 * ((8 : ℝ) / 5)) 2]
    have hx : RB |5 * ((8 : ℝ) / 5) - ((5 : ℝ) / 2) * π| ((73 : ℝ) / 500) ((117 : ℝ) / 800) := by
      have hz : ((73 : ℝ) / 500) ≤ 5 * ((8 : ℝ) / 5) - ((5 : ℝ) / 2) * π ∧ 5 * ((8 : ℝ) / 5) - ((5 : ℝ) / 2) * π ≤ ((117 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3915379 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((8 : ℝ) / 5)) ^ 2 ≤ ((11909 : ℝ) / 390625) := by
    rw [sin_sq_shift_pi (6 * ((8 : ℝ) / 5)) 3]
    have hx : RB |6 * ((8 : ℝ) / 5) - (3 : ℝ) * π| ((219 : ℝ) / 1250) ((351 : ℝ) / 2000) := by
      have hz : ((219 : ℝ) / 1250) ≤ 6 * ((8 : ℝ) / 5) - (3 : ℝ) * π ∧ 6 * ((8 : ℝ) / 5) - (3 : ℝ) * π ≤ ((351 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11909 : ℝ) / 390625) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((8 : ℝ) / 5)) ^ 2 ≤ ((23970907 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (7 * ((8 : ℝ) / 5)) 3]
    have hx : RB |7 * ((8 : ℝ) / 5) - ((7 : ℝ) / 2) * π| ((511 : ℝ) / 2500) ((819 : ℝ) / 4000) := by
      have hz : ((511 : ℝ) / 2500) ≤ 7 * ((8 : ℝ) / 5) - ((7 : ℝ) / 2) * π ∧ 7 * ((8 : ℝ) / 5) - ((7 : ℝ) / 2) * π ≤ ((819 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23970907 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((8 : ℝ) / 5)) ^ 2 ≤ ((1344237 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (8 * ((8 : ℝ) / 5)) 4]
    have hx : RB |8 * ((8 : ℝ) / 5) - (4 : ℝ) * π| ((146 : ℝ) / 625) ((117 : ℝ) / 500) := by
      have hz : ((146 : ℝ) / 625) ≤ 8 * ((8 : ℝ) / 5) - (4 : ℝ) * π ∧ 8 * ((8 : ℝ) / 5) - (4 : ℝ) * π ≤ ((117 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1344237 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((8 : ℝ) / 5)) ^ 2 ≤ ((93261167 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((8 : ℝ) / 5)) 4]
    have hx : RB |9 * ((8 : ℝ) / 5) - ((9 : ℝ) / 2) * π| ((657 : ℝ) / 2500) ((1053 : ℝ) / 4000) := by
      have hz : ((657 : ℝ) / 2500) ≤ 9 * ((8 : ℝ) / 5) - ((9 : ℝ) / 2) * π ∧ 9 * ((8 : ℝ) / 5) - ((9 : ℝ) / 2) * π ≤ ((1053 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((93261167 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((8 : ℝ) / 5)) ^ 2 ≤ ((2078959 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (10 * ((8 : ℝ) / 5)) 5]
    have hx : RB |10 * ((8 : ℝ) / 5) - (5 : ℝ) * π| ((73 : ℝ) / 250) ((117 : ℝ) / 400) := by
      have hz : ((73 : ℝ) / 250) ≤ 10 * ((8 : ℝ) / 5) - (5 : ℝ) * π ∧ 10 * ((8 : ℝ) / 5) - (5 : ℝ) * π ≤ ((117 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2078959 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((8 : ℝ) / 5)) ^ 2 ≤ ((90055063 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((8 : ℝ) / 5)) 5]
    have hx : RB |11 * ((8 : ℝ) / 5) - ((11 : ℝ) / 2) * π| ((803 : ℝ) / 2500) ((1287 : ℝ) / 4000) := by
      have hz : ((803 : ℝ) / 2500) ≤ 11 * ((8 : ℝ) / 5) - ((11 : ℝ) / 2) * π ∧ 11 * ((8 : ℝ) / 5) - ((11 : ℝ) / 2) * π ≤ ((1287 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((90055063 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((8 : ℝ) / 5)) ^ 2 ≤ ((5912773 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((8 : ℝ) / 5)) 6]
    have hx : RB |12 * ((8 : ℝ) / 5) - (6 : ℝ) * π| ((219 : ℝ) / 625) ((351 : ℝ) / 1000) := by
      have hz : ((219 : ℝ) / 625) ≤ 12 * ((8 : ℝ) / 5) - (6 : ℝ) * π ∧ 12 * ((8 : ℝ) / 5) - (6 : ℝ) * π ≤ ((351 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5912773 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((8 : ℝ) / 5) n) ≤ ((20498463 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((16867419 : ℝ) / 25000000) ≤ Real.log (π / ((8 : ℝ) / 5)) := by
    apply cov_log_2613.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((8 : ℝ) / 5)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_2 : ((113757 : ℝ) / 6250000) ≤ hfun ((77 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((77 : ℝ) / 25)) ^ 2 ≤ ((378979 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((77 : ℝ) / 25)) 1]
    have hx : RB |1 * ((77 : ℝ) / 25) - (1 : ℝ) * π| ((123 : ℝ) / 2000) ((77 : ℝ) / 1250) := by
      have hz : ((-77 : ℝ) / 1250) ≤ 1 * ((77 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((77 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-123 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((378979 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((77 : ℝ) / 25)) ^ 2 ≤ ((1510199 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((77 : ℝ) / 25)) 2]
    have hx : RB |2 * ((77 : ℝ) / 25) - (2 : ℝ) * π| ((123 : ℝ) / 1000) ((77 : ℝ) / 625) := by
      have hz : ((-77 : ℝ) / 625) ≤ 2 * ((77 : ℝ) / 25) - (2 : ℝ) * π ∧ 2 * ((77 : ℝ) / 25) - (2 : ℝ) * π ≤ ((-123 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1510199 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((77 : ℝ) / 25)) ^ 2 ≤ ((1688303 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (3 * ((77 : ℝ) / 25)) 3]
    have hx : RB |3 * ((77 : ℝ) / 25) - (3 : ℝ) * π| ((369 : ℝ) / 2000) ((231 : ℝ) / 1250) := by
      have hz : ((-231 : ℝ) / 1250) ≤ 3 * ((77 : ℝ) / 25) - (3 : ℝ) * π ∧ 3 * ((77 : ℝ) / 25) - (3 : ℝ) * π ≤ ((-369 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1688303 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((77 : ℝ) / 25)) ^ 2 ≤ ((1487521 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (4 * ((77 : ℝ) / 25)) 4]
    have hx : RB |4 * ((77 : ℝ) / 25) - (4 : ℝ) * π| ((123 : ℝ) / 500) ((154 : ℝ) / 625) := by
      have hz : ((-154 : ℝ) / 625) ≤ 4 * ((77 : ℝ) / 25) - (4 : ℝ) * π ∧ 4 * ((77 : ℝ) / 25) - (4 : ℝ) * π ≤ ((-123 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1487521 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((77 : ℝ) / 25)) ^ 2 ≤ ((1838383 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (5 * ((77 : ℝ) / 25)) 5]
    have hx : RB |5 * ((77 : ℝ) / 25) - (5 : ℝ) * π| ((123 : ℝ) / 400) ((77 : ℝ) / 250) := by
      have hz : ((-77 : ℝ) / 250) ≤ 5 * ((77 : ℝ) / 25) - (5 : ℝ) * π ∧ 5 * ((77 : ℝ) / 25) - (5 : ℝ) * π ≤ ((-123 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1838383 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((77 : ℝ) / 25)) ^ 2 ≤ ((13053413 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((77 : ℝ) / 25)) 6]
    have hx : RB |6 * ((77 : ℝ) / 25) - (6 : ℝ) * π| ((369 : ℝ) / 1000) ((231 : ℝ) / 625) := by
      have hz : ((-231 : ℝ) / 625) ≤ 6 * ((77 : ℝ) / 25) - (6 : ℝ) * π ∧ 6 * ((77 : ℝ) / 25) - (6 : ℝ) * π ≤ ((-369 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13053413 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((77 : ℝ) / 25)) ^ 2 ≤ ((17476717 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((77 : ℝ) / 25)) 7]
    have hx : RB |7 * ((77 : ℝ) / 25) - (7 : ℝ) * π| ((861 : ℝ) / 2000) ((539 : ℝ) / 1250) := by
      have hz : ((-539 : ℝ) / 1250) ≤ 7 * ((77 : ℝ) / 25) - (7 : ℝ) * π ∧ 7 * ((77 : ℝ) / 25) - (7 : ℝ) * π ≤ ((-861 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17476717 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((77 : ℝ) / 25)) ^ 2 ≤ ((11197871 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (8 * ((77 : ℝ) / 25)) 8]
    have hx : RB |8 * ((77 : ℝ) / 25) - (8 : ℝ) * π| ((123 : ℝ) / 250) ((308 : ℝ) / 625) := by
      have hz : ((-308 : ℝ) / 625) ≤ 8 * ((77 : ℝ) / 25) - (8 : ℝ) * π ∧ 8 * ((77 : ℝ) / 25) - (8 : ℝ) * π ≤ ((-123 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11197871 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((77 : ℝ) / 25)) ^ 2 ≤ ((6934317 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (9 * ((77 : ℝ) / 25)) 9]
    have hx : RB |9 * ((77 : ℝ) / 25) - (9 : ℝ) * π| ((1107 : ℝ) / 2000) ((693 : ℝ) / 1250) := by
      have hz : ((-693 : ℝ) / 1250) ≤ 9 * ((77 : ℝ) / 25) - (9 : ℝ) * π ∧ 9 * ((77 : ℝ) / 25) - (9 : ℝ) * π ≤ ((-1107 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6934317 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((77 : ℝ) / 25)) ^ 2 ≤ ((16711073 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (10 * ((77 : ℝ) / 25)) 10]
    have hx : RB |10 * ((77 : ℝ) / 25) - (10 : ℝ) * π| ((123 : ℝ) / 200) ((77 : ℝ) / 125) := by
      have hz : ((-77 : ℝ) / 125) ≤ 10 * ((77 : ℝ) / 25) - (10 : ℝ) * π ∧ 10 * ((77 : ℝ) / 25) - (10 : ℝ) * π ≤ ((-123 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16711073 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((77 : ℝ) / 25)) ^ 2 ≤ ((39366611 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((77 : ℝ) / 25)) 11]
    have hx : RB |11 * ((77 : ℝ) / 25) - (11 : ℝ) * π| ((1353 : ℝ) / 2000) ((847 : ℝ) / 1250) := by
      have hz : ((-847 : ℝ) / 1250) ≤ 11 * ((77 : ℝ) / 25) - (11 : ℝ) * π ∧ 11 * ((77 : ℝ) / 25) - (11 : ℝ) * π ≤ ((-1353 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((39366611 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((77 : ℝ) / 25)) ^ 2 ≤ ((45483671 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((77 : ℝ) / 25)) 12]
    have hx : RB |12 * ((77 : ℝ) / 25) - (12 : ℝ) * π| ((369 : ℝ) / 500) ((462 : ℝ) / 625) := by
      have hz : ((-462 : ℝ) / 625) ≤ 12 * ((77 : ℝ) / 25) - (12 : ℝ) * π ∧ 12 * ((77 : ℝ) / 25) - (12 : ℝ) * π ≤ ((-369 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45483671 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((77 : ℝ) / 25) n) ≤ ((30091 : ℝ) / 25000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1977079 : ℝ) / 100000000) ≤ Real.log (π / ((77 : ℝ) / 25)) := by
    apply cov_log_2614.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((77 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_4 : ((525853 : ℝ) / 25000000) ≤ hfun ((307 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((307 : ℝ) / 100)) ^ 2 ≤ ((102357 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (1 * ((307 : ℝ) / 100)) 1]
    have hx : RB |1 * ((307 : ℝ) / 100) - (1 : ℝ) * π| ((143 : ℝ) / 2000) ((179 : ℝ) / 2500) := by
      have hz : ((-179 : ℝ) / 2500) ≤ 1 * ((307 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((307 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-143 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((102357 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((307 : ℝ) / 100)) ^ 2 ≤ ((2036707 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((307 : ℝ) / 100)) 2]
    have hx : RB |2 * ((307 : ℝ) / 100) - (2 : ℝ) * π| ((143 : ℝ) / 1000) ((179 : ℝ) / 1250) := by
      have hz : ((-179 : ℝ) / 1250) ≤ 2 * ((307 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((307 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-143 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2036707 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((307 : ℝ) / 100)) ^ 2 ≤ ((4543707 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((307 : ℝ) / 100)) 3]
    have hx : RB |3 * ((307 : ℝ) / 100) - (3 : ℝ) * π| ((429 : ℝ) / 2000) ((537 : ℝ) / 2500) := by
      have hz : ((-537 : ℝ) / 2500) ≤ 3 * ((307 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((307 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-429 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4543707 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((307 : ℝ) / 100)) ^ 2 ≤ ((3990887 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((307 : ℝ) / 100)) 4]
    have hx : RB |4 * ((307 : ℝ) / 100) - (4 : ℝ) * π| ((143 : ℝ) / 500) ((179 : ℝ) / 625) := by
      have hz : ((-179 : ℝ) / 625) ≤ 4 * ((307 : ℝ) / 100) - (4 : ℝ) * π ∧ 4 * ((307 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-143 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3990887 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((307 : ℝ) / 100)) ^ 2 ≤ ((6140539 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (5 * ((307 : ℝ) / 100)) 5]
    have hx : RB |5 * ((307 : ℝ) / 100) - (5 : ℝ) * π| ((143 : ℝ) / 400) ((179 : ℝ) / 500) := by
      have hz : ((-179 : ℝ) / 500) ≤ 5 * ((307 : ℝ) / 100) - (5 : ℝ) * π ∧ 5 * ((307 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-143 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6140539 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((307 : ℝ) / 100)) ^ 2 ≤ ((8677253 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (6 * ((307 : ℝ) / 100)) 6]
    have hx : RB |6 * ((307 : ℝ) / 100) - (6 : ℝ) * π| ((429 : ℝ) / 1000) ((537 : ℝ) / 1250) := by
      have hz : ((-537 : ℝ) / 1250) ≤ 6 * ((307 : ℝ) / 100) - (6 : ℝ) * π ∧ 6 * ((307 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-429 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8677253 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((307 : ℝ) / 100)) ^ 2 ≤ ((4619919 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (7 * ((307 : ℝ) / 100)) 7]
    have hx : RB |7 * ((307 : ℝ) / 100) - (7 : ℝ) * π| ((1001 : ℝ) / 2000) ((1253 : ℝ) / 2500) := by
      have hz : ((-1253 : ℝ) / 2500) ≤ 7 * ((307 : ℝ) / 100) - (7 : ℝ) * π ∧ 7 * ((307 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-1001 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4619919 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((307 : ℝ) / 100)) ^ 2 ≤ ((7350201 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (8 * ((307 : ℝ) / 100)) 8]
    have hx : RB |8 * ((307 : ℝ) / 100) - (8 : ℝ) * π| ((143 : ℝ) / 250) ((358 : ℝ) / 625) := by
      have hz : ((-358 : ℝ) / 625) ≤ 8 * ((307 : ℝ) / 100) - (8 : ℝ) * π ∧ 8 * ((307 : ℝ) / 100) - (8 : ℝ) * π ≤ ((-143 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7350201 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((307 : ℝ) / 100)) ^ 2 ≤ ((18066047 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (9 * ((307 : ℝ) / 100)) 9]
    have hx : RB |9 * ((307 : ℝ) / 100) - (9 : ℝ) * π| ((1287 : ℝ) / 2000) ((1611 : ℝ) / 2500) := by
      have hz : ((-1611 : ℝ) / 2500) ≤ 9 * ((307 : ℝ) / 100) - (9 : ℝ) * π ∧ 9 * ((307 : ℝ) / 100) - (9 : ℝ) * π ≤ ((-1287 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18066047 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((307 : ℝ) / 100)) ^ 2 ≤ ((10789937 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (10 * ((307 : ℝ) / 100)) 10]
    have hx : RB |10 * ((307 : ℝ) / 100) - (10 : ℝ) * π| ((143 : ℝ) / 200) ((179 : ℝ) / 250) := by
      have hz : ((-179 : ℝ) / 250) ≤ 10 * ((307 : ℝ) / 100) - (10 : ℝ) * π ∧ 10 * ((307 : ℝ) / 100) - (10 : ℝ) * π ≤ ((-143 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10789937 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((307 : ℝ) / 100)) ^ 2 ≤ ((12709267 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (11 * ((307 : ℝ) / 100)) 10]
    have hx : RB |11 * ((307 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((979 : ℝ) / 1250) ((3137 : ℝ) / 4000) := by
      have hz : ((979 : ℝ) / 1250) ≤ 11 * ((307 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 11 * ((307 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((3137 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12709267 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((307 : ℝ) / 100)) ^ 2 ≤ ((7224831 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (12 * ((307 : ℝ) / 100)) 11]
    have hx : RB |12 * ((307 : ℝ) / 100) - ((23 : ℝ) / 2) * π| ((1779 : ℝ) / 2500) ((2851 : ℝ) / 4000) := by
      have hz : ((1779 : ℝ) / 2500) ≤ 12 * ((307 : ℝ) / 100) - ((23 : ℝ) / 2) * π ∧ 12 * ((307 : ℝ) / 100) - ((23 : ℝ) / 2) * π ≤ ((2851 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7224831 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((307 : ℝ) / 100) n) ≤ ((162029 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1151141 : ℝ) / 50000000) ≤ Real.log (π / ((307 : ℝ) / 100)) := by
    apply cov_log_2615.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((307 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_3 : ((26240701 : ℝ) / 100000000) ≤ hfun ((161 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((161 : ℝ) / 100)) ^ 2 ≤ ((4992321 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (1 * ((161 : ℝ) / 100)) 0]
    have hx : RB |1 * ((161 : ℝ) / 100) - ((1 : ℝ) / 2) * π| ((49 : ℝ) / 1250) ((157 : ℝ) / 4000) := by
      have hz : ((49 : ℝ) / 1250) ≤ 1 * ((161 : ℝ) / 100) - ((1 : ℝ) / 2) * π ∧ 1 * ((161 : ℝ) / 100) - ((1 : ℝ) / 2) * π ≤ ((157 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4992321 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((161 : ℝ) / 100)) ^ 2 ≤ ((307483 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (2 * ((161 : ℝ) / 100)) 1]
    have hx : RB |2 * ((161 : ℝ) / 100) - (1 : ℝ) * π| ((49 : ℝ) / 625) ((157 : ℝ) / 2000) := by
      have hz : ((49 : ℝ) / 625) ≤ 2 * ((161 : ℝ) / 100) - (1 : ℝ) * π ∧ 2 * ((161 : ℝ) / 100) - (1 : ℝ) * π ≤ ((157 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((307483 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((161 : ℝ) / 100)) ^ 2 ≤ ((19724759 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (3 * ((161 : ℝ) / 100)) 1]
    have hx : RB |3 * ((161 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((147 : ℝ) / 1250) ((471 : ℝ) / 4000) := by
      have hz : ((147 : ℝ) / 1250) ≤ 3 * ((161 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 3 * ((161 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((471 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19724759 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((161 : ℝ) / 100)) ^ 2 ≤ ((611199 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (4 * ((161 : ℝ) / 100)) 2]
    have hx : RB |4 * ((161 : ℝ) / 100) - (2 : ℝ) * π| ((98 : ℝ) / 625) ((157 : ℝ) / 1000) := by
      have hz : ((98 : ℝ) / 625) ≤ 4 * ((161 : ℝ) / 100) - (2 : ℝ) * π ∧ 4 * ((161 : ℝ) / 100) - (2 : ℝ) * π ≤ ((157 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((611199 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((161 : ℝ) / 100)) ^ 2 ≤ ((1924209 : ℝ) / 2000000) := by
    rw [sin_sq_shift_half_pi (5 * ((161 : ℝ) / 100)) 2]
    have hx : RB |5 * ((161 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((49 : ℝ) / 250) ((157 : ℝ) / 800) := by
      have hz : ((49 : ℝ) / 250) ≤ 5 * ((161 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 5 * ((161 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((157 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1924209 : ℝ) / 2000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((161 : ℝ) / 100)) ^ 2 ≤ ((5444697 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((161 : ℝ) / 100)) 3]
    have hx : RB |6 * ((161 : ℝ) / 100) - (3 : ℝ) * π| ((147 : ℝ) / 625) ((471 : ℝ) / 2000) := by
      have hz : ((147 : ℝ) / 625) ≤ 6 * ((161 : ℝ) / 100) - (3 : ℝ) * π ∧ 6 * ((161 : ℝ) / 100) - (3 : ℝ) * π ≤ ((471 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5444697 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((161 : ℝ) / 100)) ^ 2 ≤ ((92669331 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((161 : ℝ) / 100)) 3]
    have hx : RB |7 * ((161 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((343 : ℝ) / 1250) ((1099 : ℝ) / 4000) := by
      have hz : ((343 : ℝ) / 1250) ≤ 7 * ((161 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 7 * ((161 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((1099 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((92669331 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((161 : ℝ) / 100)) ^ 2 ≤ ((4770663 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (8 * ((161 : ℝ) / 100)) 4]
    have hx : RB |8 * ((161 : ℝ) / 100) - (4 : ℝ) * π| ((196 : ℝ) / 625) ((157 : ℝ) / 500) := by
      have hz : ((196 : ℝ) / 625) ≤ 8 * ((161 : ℝ) / 100) - (4 : ℝ) * π ∧ 8 * ((161 : ℝ) / 100) - (4 : ℝ) * π ≤ ((157 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4770663 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((161 : ℝ) / 100)) ^ 2 ≤ ((11011587 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (9 * ((161 : ℝ) / 100)) 4]
    have hx : RB |9 * ((161 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((441 : ℝ) / 1250) ((1413 : ℝ) / 4000) := by
      have hz : ((441 : ℝ) / 1250) ≤ 9 * ((161 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 9 * ((161 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((1413 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11011587 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((161 : ℝ) / 100)) ^ 2 ≤ ((14634739 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((161 : ℝ) / 100)) 5]
    have hx : RB |10 * ((161 : ℝ) / 100) - (5 : ℝ) * π| ((49 : ℝ) / 125) ((157 : ℝ) / 400) := by
      have hz : ((49 : ℝ) / 125) ≤ 10 * ((161 : ℝ) / 100) - (5 : ℝ) * π ∧ 10 * ((161 : ℝ) / 100) - (5 : ℝ) * π ≤ ((157 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14634739 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((161 : ℝ) / 100)) ^ 2 ≤ ((82599573 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((161 : ℝ) / 100)) 5]
    have hx : RB |11 * ((161 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((539 : ℝ) / 1250) ((1727 : ℝ) / 4000) := by
      have hz : ((539 : ℝ) / 1250) ≤ 11 * ((161 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 11 * ((161 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((1727 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((82599573 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((161 : ℝ) / 100)) ^ 2 ≤ ((10300523 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((161 : ℝ) / 100)) 6]
    have hx : RB |12 * ((161 : ℝ) / 100) - (6 : ℝ) * π| ((294 : ℝ) / 625) ((471 : ℝ) / 1000) := by
      have hz : ((294 : ℝ) / 625) ≤ 12 * ((161 : ℝ) / 100) - (6 : ℝ) * π ∧ 12 * ((161 : ℝ) / 100) - (6 : ℝ) * π ≤ ((471 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10300523 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((161 : ℝ) / 100) n) ≤ ((8094393 : ℝ) / 20000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((66846621 : ℝ) / 100000000) ≤ Real.log (π / ((161 : ℝ) / 100)) := by
    apply cov_log_2616.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((161 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_5 : ((2382143 : ℝ) / 100000000) ≤ hfun ((153 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((153 : ℝ) / 50)) ^ 2 ≤ ((132877 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (1 * ((153 : ℝ) / 50)) 1]
    have hx : RB |1 * ((153 : ℝ) / 50) - (1 : ℝ) * π| ((163 : ℝ) / 2000) ((51 : ℝ) / 625) := by
      have hz : ((-51 : ℝ) / 625) ≤ 1 * ((153 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((153 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-163 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((132877 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((153 : ℝ) / 50)) ^ 2 ≤ ((527991 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (2 * ((153 : ℝ) / 50)) 2]
    have hx : RB |2 * ((153 : ℝ) / 50) - (2 : ℝ) * π| ((163 : ℝ) / 1000) ((102 : ℝ) / 625) := by
      have hz : ((-102 : ℝ) / 625) ≤ 2 * ((153 : ℝ) / 50) - (2 : ℝ) * π ∧ 2 * ((153 : ℝ) / 50) - (2 : ℝ) * π ≤ ((-163 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((527991 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((153 : ℝ) / 50)) ^ 2 ≤ ((1174891 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (3 * ((153 : ℝ) / 50)) 3]
    have hx : RB |3 * ((153 : ℝ) / 50) - (3 : ℝ) * π| ((489 : ℝ) / 2000) ((153 : ℝ) / 625) := by
      have hz : ((-153 : ℝ) / 625) ≤ 3 * ((153 : ℝ) / 50) - (3 : ℝ) * π ∧ 3 * ((153 : ℝ) / 50) - (3 : ℝ) * π ≤ ((-489 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1174891 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((153 : ℝ) / 50)) ^ 2 ≤ ((5141229 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((153 : ℝ) / 50)) 4]
    have hx : RB |4 * ((153 : ℝ) / 50) - (4 : ℝ) * π| ((163 : ℝ) / 500) ((204 : ℝ) / 625) := by
      have hz : ((-204 : ℝ) / 625) ≤ 4 * ((153 : ℝ) / 50) - (4 : ℝ) * π ∧ 4 * ((153 : ℝ) / 50) - (4 : ℝ) * π ≤ ((-163 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5141229 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((153 : ℝ) / 50)) ^ 2 ≤ ((492119 : ℝ) / 3125000) := by
    rw [sin_sq_shift_pi (5 * ((153 : ℝ) / 50)) 5]
    have hx : RB |5 * ((153 : ℝ) / 50) - (5 : ℝ) * π| ((163 : ℝ) / 400) ((51 : ℝ) / 125) := by
      have hz : ((-51 : ℝ) / 125) ≤ 5 * ((153 : ℝ) / 50) - (5 : ℝ) * π ∧ 5 * ((153 : ℝ) / 50) - (5 : ℝ) * π ≤ ((-163 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((492119 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((153 : ℝ) / 50)) ^ 2 ≤ ((11063477 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (6 * ((153 : ℝ) / 50)) 6]
    have hx : RB |6 * ((153 : ℝ) / 50) - (6 : ℝ) * π| ((489 : ℝ) / 1000) ((306 : ℝ) / 625) := by
      have hz : ((-306 : ℝ) / 625) ≤ 6 * ((153 : ℝ) / 50) - (6 : ℝ) * π ∧ 6 * ((153 : ℝ) / 50) - (6 : ℝ) * π ≤ ((-489 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11063477 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((153 : ℝ) / 50)) ^ 2 ≤ ((2925309 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (7 * ((153 : ℝ) / 50)) 7]
    have hx : RB |7 * ((153 : ℝ) / 50) - (7 : ℝ) * π| ((1141 : ℝ) / 2000) ((357 : ℝ) / 625) := by
      have hz : ((-357 : ℝ) / 625) ≤ 7 * ((153 : ℝ) / 50) - (7 : ℝ) * π ∧ 7 * ((153 : ℝ) / 50) - (7 : ℝ) * π ≤ ((-1141 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2925309 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((153 : ℝ) / 50)) ^ 2 ≤ ((18470487 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (8 * ((153 : ℝ) / 50)) 8]
    have hx : RB |8 * ((153 : ℝ) / 50) - (8 : ℝ) * π| ((163 : ℝ) / 250) ((408 : ℝ) / 625) := by
      have hz : ((-408 : ℝ) / 625) ≤ 8 * ((153 : ℝ) / 50) - (8 : ℝ) * π ∧ 8 * ((153 : ℝ) / 50) - (8 : ℝ) * π ≤ ((-163 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18470487 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((153 : ℝ) / 50)) ^ 2 ≤ ((5624039 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (9 * ((153 : ℝ) / 50)) 9]
    have hx : RB |9 * ((153 : ℝ) / 50) - (9 : ℝ) * π| ((1467 : ℝ) / 2000) ((459 : ℝ) / 625) := by
      have hz : ((-459 : ℝ) / 625) ≤ 9 * ((153 : ℝ) / 50) - (9 : ℝ) * π ∧ 9 * ((153 : ℝ) / 50) - (9 : ℝ) * π ≤ ((-1467 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5624039 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((153 : ℝ) / 50)) ^ 2 ≤ ((10720263 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (10 * ((153 : ℝ) / 50)) 9]
    have hx : RB |10 * ((153 : ℝ) / 50) - ((19 : ℝ) / 2) * π| ((1887 : ℝ) / 2500) ((3023 : ℝ) / 4000) := by
      have hz : ((1887 : ℝ) / 2500) ≤ 10 * ((153 : ℝ) / 50) - ((19 : ℝ) / 2) * π ∧ 10 * ((153 : ℝ) / 50) - ((19 : ℝ) / 2) * π ≤ ((3023 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10720263 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((153 : ℝ) / 50)) ^ 2 ≤ ((61491491 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((153 : ℝ) / 50)) 10]
    have hx : RB |11 * ((153 : ℝ) / 50) - ((21 : ℝ) / 2) * π| ((1683 : ℝ) / 2500) ((2697 : ℝ) / 4000) := by
      have hz : ((1683 : ℝ) / 2500) ≤ 11 * ((153 : ℝ) / 50) - ((21 : ℝ) / 2) * π ∧ 11 * ((153 : ℝ) / 50) - ((21 : ℝ) / 2) * π ≤ ((2697 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((61491491 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((153 : ℝ) / 50)) ^ 2 ≤ ((34564153 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((153 : ℝ) / 50)) 11]
    have hx : RB |12 * ((153 : ℝ) / 50) - ((23 : ℝ) / 2) * π| ((1479 : ℝ) / 2500) ((2371 : ℝ) / 4000) := by
      have hz : ((1479 : ℝ) / 2500) ≤ 12 * ((153 : ℝ) / 50) - ((23 : ℝ) / 2) * π ∧ 12 * ((153 : ℝ) / 50) - ((23 : ℝ) / 2) * π ≤ ((2371 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((34564153 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((153 : ℝ) / 50) n) ≤ ((209321 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((2628547 : ℝ) / 100000000) ≤ Real.log (π / ((153 : ℝ) / 50)) := by
    apply cov_log_2617.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((153 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_7 : ((2656527 : ℝ) / 100000000) ≤ hfun ((61 : ℝ) / 20) := by
  have s1 : Real.sin (1 * ((61 : ℝ) / 20)) ^ 2 ≤ ((10459 : ℝ) / 1250000) := by
    rw [sin_sq_shift_pi (1 * ((61 : ℝ) / 20)) 1]
    have hx : RB |1 * ((61 : ℝ) / 20) - (1 : ℝ) * π| ((183 : ℝ) / 2000) ((229 : ℝ) / 2500) := by
      have hz : ((-229 : ℝ) / 2500) ≤ 1 * ((61 : ℝ) / 20) - (1 : ℝ) * π ∧ 1 * ((61 : ℝ) / 20) - (1 : ℝ) * π ≤ ((-183 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10459 : ℝ) / 1250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((61 : ℝ) / 20)) ^ 2 ≤ ((3318979 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((61 : ℝ) / 20)) 2]
    have hx : RB |2 * ((61 : ℝ) / 20) - (2 : ℝ) * π| ((183 : ℝ) / 1000) ((229 : ℝ) / 1250) := by
      have hz : ((-229 : ℝ) / 1250) ≤ 2 * ((61 : ℝ) / 20) - (2 : ℝ) * π ∧ 2 * ((61 : ℝ) / 20) - (2 : ℝ) * π ≤ ((-183 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3318979 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((61 : ℝ) / 20)) ^ 2 ≤ ((7364081 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((61 : ℝ) / 20)) 3]
    have hx : RB |3 * ((61 : ℝ) / 20) - (3 : ℝ) * π| ((549 : ℝ) / 2000) ((687 : ℝ) / 2500) := by
      have hz : ((-687 : ℝ) / 2500) ≤ 3 * ((61 : ℝ) / 20) - (3 : ℝ) * π ∧ 3 * ((61 : ℝ) / 20) - (3 : ℝ) * π ≤ ((-549 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7364081 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((61 : ℝ) / 20)) ^ 2 ≤ ((12837511 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((61 : ℝ) / 20)) 4]
    have hx : RB |4 * ((61 : ℝ) / 20) - (4 : ℝ) * π| ((183 : ℝ) / 500) ((229 : ℝ) / 625) := by
      have hz : ((-229 : ℝ) / 625) ≤ 4 * ((61 : ℝ) / 20) - (4 : ℝ) * π ∧ 4 * ((61 : ℝ) / 20) - (4 : ℝ) * π ≤ ((-183 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12837511 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((61 : ℝ) / 20)) ^ 2 ≤ ((611181 : ℝ) / 3125000) := by
    rw [sin_sq_shift_pi (5 * ((61 : ℝ) / 20)) 5]
    have hx : RB |5 * ((61 : ℝ) / 20) - (5 : ℝ) * π| ((183 : ℝ) / 400) ((229 : ℝ) / 500) := by
      have hz : ((-229 : ℝ) / 500) ≤ 5 * ((61 : ℝ) / 20) - (5 : ℝ) * π ∧ 5 * ((61 : ℝ) / 20) - (5 : ℝ) * π ≤ ((-183 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((611181 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((61 : ℝ) / 20)) ^ 2 ≤ ((27303057 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((61 : ℝ) / 20)) 6]
    have hx : RB |6 * ((61 : ℝ) / 20) - (6 : ℝ) * π| ((549 : ℝ) / 1000) ((687 : ℝ) / 1250) := by
      have hz : ((-687 : ℝ) / 1250) ≤ 6 * ((61 : ℝ) / 20) - (6 : ℝ) * π ∧ 6 * ((61 : ℝ) / 20) - (6 : ℝ) * π ≤ ((-549 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((27303057 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((61 : ℝ) / 20)) ^ 2 ≤ ((4477389 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (7 * ((61 : ℝ) / 20)) 7]
    have hx : RB |7 * ((61 : ℝ) / 20) - (7 : ℝ) * π| ((1281 : ℝ) / 2000) ((1603 : ℝ) / 2500) := by
      have hz : ((-1603 : ℝ) / 2500) ≤ 7 * ((61 : ℝ) / 20) - (7 : ℝ) * π ∧ 7 * ((61 : ℝ) / 20) - (7 : ℝ) * π ≤ ((-1281 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4477389 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((61 : ℝ) / 20)) ^ 2 ≤ ((44828731 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((61 : ℝ) / 20)) 8]
    have hx : RB |8 * ((61 : ℝ) / 20) - (8 : ℝ) * π| ((183 : ℝ) / 250) ((458 : ℝ) / 625) := by
      have hz : ((-458 : ℝ) / 625) ≤ 8 * ((61 : ℝ) / 20) - (8 : ℝ) * π ∧ 8 * ((61 : ℝ) / 20) - (8 : ℝ) * π ≤ ((-183 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44828731 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((61 : ℝ) / 20)) ^ 2 ≤ ((1700549 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (9 * ((61 : ℝ) / 20)) 8]
    have hx : RB |9 * ((61 : ℝ) / 20) - ((17 : ℝ) / 2) * π| ((933 : ℝ) / 1250) ((2989 : ℝ) / 4000) := by
      have hz : ((933 : ℝ) / 1250) ≤ 9 * ((61 : ℝ) / 20) - ((17 : ℝ) / 2) * π ∧ 9 * ((61 : ℝ) / 20) - ((17 : ℝ) / 2) * π ≤ ((2989 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1700549 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((61 : ℝ) / 20)) ^ 2 ≤ ((31621053 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((61 : ℝ) / 20)) 9]
    have hx : RB |10 * ((61 : ℝ) / 20) - ((19 : ℝ) / 2) * π| ((1637 : ℝ) / 2500) ((2623 : ℝ) / 4000) := by
      have hz : ((1637 : ℝ) / 2500) ≤ 10 * ((61 : ℝ) / 20) - ((19 : ℝ) / 2) * π ∧ 10 * ((61 : ℝ) / 20) - ((19 : ℝ) / 2) * π ≤ ((2623 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((31621053 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((61 : ℝ) / 20)) ^ 2 ≤ ((7168709 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (11 * ((61 : ℝ) / 20)) 10]
    have hx : RB |11 * ((61 : ℝ) / 20) - ((21 : ℝ) / 2) * π| ((352 : ℝ) / 625) ((2257 : ℝ) / 4000) := by
      have hz : ((352 : ℝ) / 625) ≤ 11 * ((61 : ℝ) / 20) - ((21 : ℝ) / 2) * π ∧ 11 * ((61 : ℝ) / 20) - ((21 : ℝ) / 2) * π ≤ ((2257 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7168709 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((61 : ℝ) / 20)) ^ 2 ≤ ((1986477 : ℝ) / 2500000) := by
    rw [sin_sq_shift_half_pi (12 * ((61 : ℝ) / 20)) 11]
    have hx : RB |12 * ((61 : ℝ) / 20) - ((23 : ℝ) / 2) * π| ((1179 : ℝ) / 2500) ((1891 : ℝ) / 4000) := by
      have hz : ((1179 : ℝ) / 2500) ≤ 12 * ((61 : ℝ) / 20) - ((23 : ℝ) / 2) * π ∧ 12 * ((61 : ℝ) / 20) - ((23 : ℝ) / 2) * π ≤ ((1891 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1986477 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((61 : ℝ) / 20) n) ≤ ((262027 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((73897 : ℝ) / 2500000) ≤ Real.log (π / ((61 : ℝ) / 20)) := by
    apply cov_log_2618.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((61 : ℝ) / 20)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_6 : ((13071687 : ℝ) / 50000000) ≤ hfun ((81 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((81 : ℝ) / 50)) ^ 2 ≤ ((1558721 : ℝ) / 1562500) := by
    rw [sin_sq_shift_half_pi (1 * ((81 : ℝ) / 50)) 0]
    have hx : RB |1 * ((81 : ℝ) / 50) - ((1 : ℝ) / 2) * π| ((123 : ℝ) / 2500) ((197 : ℝ) / 4000) := by
      have hz : ((123 : ℝ) / 2500) ≤ 1 * ((81 : ℝ) / 50) - ((1 : ℝ) / 2) * π ∧ 1 * ((81 : ℝ) / 50) - ((1 : ℝ) / 2) * π ≤ ((197 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1558721 : ℝ) / 1562500) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((81 : ℝ) / 50)) ^ 2 ≤ ((483551 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (2 * ((81 : ℝ) / 50)) 1]
    have hx : RB |2 * ((81 : ℝ) / 50) - (1 : ℝ) * π| ((123 : ℝ) / 1250) ((197 : ℝ) / 2000) := by
      have hz : ((123 : ℝ) / 1250) ≤ 2 * ((81 : ℝ) / 50) - (1 : ℝ) * π ∧ 2 * ((81 : ℝ) / 50) - (1 : ℝ) * π ≤ ((197 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((483551 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((81 : ℝ) / 50)) ^ 2 ≤ ((489191 : ℝ) / 500000) := by
    rw [sin_sq_shift_half_pi (3 * ((81 : ℝ) / 50)) 1]
    have hx : RB |3 * ((81 : ℝ) / 50) - ((3 : ℝ) / 2) * π| ((369 : ℝ) / 2500) ((591 : ℝ) / 4000) := by
      have hz : ((369 : ℝ) / 2500) ≤ 3 * ((81 : ℝ) / 50) - ((3 : ℝ) / 2) * π ∧ 3 * ((81 : ℝ) / 50) - ((3 : ℝ) / 2) * π ≤ ((591 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((489191 : ℝ) / 500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((81 : ℝ) / 50)) ^ 2 ≤ ((1915563 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((81 : ℝ) / 50)) 2]
    have hx : RB |4 * ((81 : ℝ) / 50) - (2 : ℝ) * π| ((123 : ℝ) / 625) ((197 : ℝ) / 1000) := by
      have hz : ((123 : ℝ) / 625) ≤ 4 * ((81 : ℝ) / 50) - (2 : ℝ) * π ∧ 4 * ((81 : ℝ) / 50) - (2 : ℝ) * π ≤ ((197 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1915563 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((81 : ℝ) / 50)) ^ 2 ≤ ((94077103 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((81 : ℝ) / 50)) 2]
    have hx : RB |5 * ((81 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((123 : ℝ) / 500) ((197 : ℝ) / 800) := by
      have hz : ((123 : ℝ) / 500) ≤ 5 * ((81 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 5 * ((81 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((197 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94077103 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((81 : ℝ) / 50)) ^ 2 ≤ ((2120447 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((81 : ℝ) / 50)) 3]
    have hx : RB |6 * ((81 : ℝ) / 50) - (3 : ℝ) * π| ((369 : ℝ) / 1250) ((591 : ℝ) / 2000) := by
      have hz : ((369 : ℝ) / 1250) ≤ 6 * ((81 : ℝ) / 50) - (3 : ℝ) * π ∧ 6 * ((81 : ℝ) / 50) - (3 : ℝ) * π ≤ ((591 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2120447 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((81 : ℝ) / 50)) ^ 2 ≤ ((44314527 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (7 * ((81 : ℝ) / 50)) 3]
    have hx : RB |7 * ((81 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((861 : ℝ) / 2500) ((1379 : ℝ) / 4000) := by
      have hz : ((861 : ℝ) / 2500) ≤ 7 * ((81 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 7 * ((81 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((1379 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44314527 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((81 : ℝ) / 50)) ^ 2 ≤ ((14740389 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((81 : ℝ) / 50)) 4]
    have hx : RB |8 * ((81 : ℝ) / 50) - (4 : ℝ) * π| ((246 : ℝ) / 625) ((197 : ℝ) / 500) := by
      have hz : ((246 : ℝ) / 625) ≤ 8 * ((81 : ℝ) / 50) - (4 : ℝ) * π ∧ 8 * ((81 : ℝ) / 50) - (4 : ℝ) * π ≤ ((197 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14740389 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((81 : ℝ) / 50)) ^ 2 ≤ ((20429249 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (9 * ((81 : ℝ) / 50)) 4]
    have hx : RB |9 * ((81 : ℝ) / 50) - ((9 : ℝ) / 2) * π| ((1107 : ℝ) / 2500) ((1773 : ℝ) / 4000) := by
      have hz : ((1107 : ℝ) / 2500) ≤ 9 * ((81 : ℝ) / 50) - ((9 : ℝ) / 2) * π ∧ 9 * ((81 : ℝ) / 50) - ((9 : ℝ) / 2) * π ≤ ((1773 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((20429249 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((81 : ℝ) / 50)) ^ 2 ≤ ((22367273 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((81 : ℝ) / 50)) 5]
    have hx : RB |10 * ((81 : ℝ) / 50) - (5 : ℝ) * π| ((123 : ℝ) / 250) ((197 : ℝ) / 400) := by
      have hz : ((123 : ℝ) / 250) ≤ 10 * ((81 : ℝ) / 50) - (5 : ℝ) * π ∧ 10 * ((81 : ℝ) / 50) - (5 : ℝ) * π ≤ ((197 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22367273 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((81 : ℝ) / 50)) ^ 2 ≤ ((3681143 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (11 * ((81 : ℝ) / 50)) 5]
    have hx : RB |11 * ((81 : ℝ) / 50) - ((11 : ℝ) / 2) * π| ((1353 : ℝ) / 2500) ((2167 : ℝ) / 4000) := by
      have hz : ((1353 : ℝ) / 2500) ≤ 11 * ((81 : ℝ) / 50) - ((11 : ℝ) / 2) * π ∧ 11 * ((81 : ℝ) / 50) - ((11 : ℝ) / 2) * π ≤ ((2167 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3681143 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((81 : ℝ) / 50)) ^ 2 ≤ ((15535937 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((81 : ℝ) / 50)) 6]
    have hx : RB |12 * ((81 : ℝ) / 50) - (6 : ℝ) * π| ((369 : ℝ) / 625) ((591 : ℝ) / 1000) := by
      have hz : ((369 : ℝ) / 625) ≤ 12 * ((81 : ℝ) / 50) - (6 : ℝ) * π ∧ 12 * ((81 : ℝ) / 50) - (6 : ℝ) * π ≤ ((591 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15535937 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((81 : ℝ) / 50) n) ≤ ((312123 : ℝ) / 781250) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((2069607 : ℝ) / 3125000) ≤ Real.log (π / ((81 : ℝ) / 50)) := by
    apply cov_log_2619.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((81 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_8 : ((1463417 : ℝ) / 50000000) ≤ hfun ((76 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((76 : ℝ) / 25)) ^ 2 ≤ ((12859 : ℝ) / 1250000) := by
    rw [sin_sq_shift_pi (1 * ((76 : ℝ) / 25)) 1]
    have hx : RB |1 * ((76 : ℝ) / 25) - (1 : ℝ) * π| ((203 : ℝ) / 2000) ((127 : ℝ) / 1250) := by
      have hz : ((-127 : ℝ) / 1250) ≤ 1 * ((76 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((76 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-203 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12859 : ℝ) / 1250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((76 : ℝ) / 25)) ^ 2 ≤ ((4072697 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((76 : ℝ) / 25)) 2]
    have hx : RB |2 * ((76 : ℝ) / 25) - (2 : ℝ) * π| ((203 : ℝ) / 1000) ((127 : ℝ) / 625) := by
      have hz : ((-127 : ℝ) / 625) ≤ 2 * ((76 : ℝ) / 25) - (2 : ℝ) * π ∧ 2 * ((76 : ℝ) / 25) - (2 : ℝ) * π ≤ ((-203 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4072697 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((76 : ℝ) / 25)) ^ 2 ≤ ((9007247 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((76 : ℝ) / 25)) 3]
    have hx : RB |3 * ((76 : ℝ) / 25) - (3 : ℝ) * π| ((609 : ℝ) / 2000) ((381 : ℝ) / 1250) := by
      have hz : ((-381 : ℝ) / 1250) ≤ 3 * ((76 : ℝ) / 25) - (3 : ℝ) * π ∧ 3 * ((76 : ℝ) / 25) - (3 : ℝ) * π ≤ ((-609 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9007247 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((76 : ℝ) / 25)) ^ 2 ≤ ((15630713 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((76 : ℝ) / 25)) 4]
    have hx : RB |4 * ((76 : ℝ) / 25) - (4 : ℝ) * π| ((203 : ℝ) / 500) ((254 : ℝ) / 625) := by
      have hz : ((-254 : ℝ) / 625) ≤ 4 * ((76 : ℝ) / 25) - (4 : ℝ) * π ∧ 4 * ((76 : ℝ) / 25) - (4 : ℝ) * π ≤ ((-203 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15630713 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((76 : ℝ) / 25)) ^ 2 ≤ ((2959177 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (5 * ((76 : ℝ) / 25)) 5]
    have hx : RB |5 * ((76 : ℝ) / 25) - (5 : ℝ) * π| ((203 : ℝ) / 400) ((127 : ℝ) / 250) := by
      have hz : ((-127 : ℝ) / 250) ≤ 5 * ((76 : ℝ) / 25) - (5 : ℝ) * π ∧ 5 * ((76 : ℝ) / 25) - (5 : ℝ) * π ≤ ((-203 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2959177 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((76 : ℝ) / 25)) ^ 2 ≤ ((4101211 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (6 * ((76 : ℝ) / 25)) 6]
    have hx : RB |6 * ((76 : ℝ) / 25) - (6 : ℝ) * π| ((609 : ℝ) / 1000) ((381 : ℝ) / 625) := by
      have hz : ((-381 : ℝ) / 625) ≤ 6 * ((76 : ℝ) / 25) - (6 : ℝ) * π ∧ 6 * ((76 : ℝ) / 25) - (6 : ℝ) * π ≤ ((-609 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4101211 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((76 : ℝ) / 25)) ^ 2 ≤ ((42672457 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((76 : ℝ) / 25)) 7]
    have hx : RB |7 * ((76 : ℝ) / 25) - (7 : ℝ) * π| ((1421 : ℝ) / 2000) ((889 : ℝ) / 1250) := by
      have hz : ((-889 : ℝ) / 1250) ≤ 7 * ((76 : ℝ) / 25) - (7 : ℝ) * π ∧ 7 * ((76 : ℝ) / 25) - (7 : ℝ) * π ≤ ((-1421 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42672457 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((76 : ℝ) / 25)) ^ 2 ≤ ((10657419 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (8 * ((76 : ℝ) / 25)) 7]
    have hx : RB |8 * ((76 : ℝ) / 25) - ((15 : ℝ) / 2) * π| ((379 : ℝ) / 500) ((607 : ℝ) / 800) := by
      have hz : ((379 : ℝ) / 500) ≤ 8 * ((76 : ℝ) / 25) - ((15 : ℝ) / 2) * π ∧ 8 * ((76 : ℝ) / 25) - ((15 : ℝ) / 2) * π ≤ ((607 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10657419 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((76 : ℝ) / 25)) ^ 2 ≤ ((3943089 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (9 * ((76 : ℝ) / 25)) 8]
    have hx : RB |9 * ((76 : ℝ) / 25) - ((17 : ℝ) / 2) * π| ((1641 : ℝ) / 2500) ((2629 : ℝ) / 4000) := by
      have hz : ((1641 : ℝ) / 2500) ≤ 9 * ((76 : ℝ) / 25) - ((17 : ℝ) / 2) * π ∧ 9 * ((76 : ℝ) / 25) - ((17 : ℝ) / 2) * π ≤ ((2629 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3943089 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((76 : ℝ) / 25)) ^ 2 ≤ ((18107871 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (10 * ((76 : ℝ) / 25)) 9]
    have hx : RB |10 * ((76 : ℝ) / 25) - ((19 : ℝ) / 2) * π| ((1387 : ℝ) / 2500) ((2223 : ℝ) / 4000) := by
      have hz : ((1387 : ℝ) / 2500) ≤ 10 * ((76 : ℝ) / 25) - ((19 : ℝ) / 2) * π ∧ 10 * ((76 : ℝ) / 25) - ((19 : ℝ) / 2) * π ≤ ((2223 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18107871 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((76 : ℝ) / 25)) ^ 2 ≤ ((16182813 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (11 * ((76 : ℝ) / 25)) 10]
    have hx : RB |11 * ((76 : ℝ) / 25) - ((21 : ℝ) / 2) * π| ((1133 : ℝ) / 2500) ((1817 : ℝ) / 4000) := by
      have hz : ((1133 : ℝ) / 2500) ≤ 11 * ((76 : ℝ) / 25) - ((21 : ℝ) / 2) * π ∧ 11 * ((76 : ℝ) / 25) - ((21 : ℝ) / 2) * π ≤ ((1817 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16182813 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((76 : ℝ) / 25)) ^ 2 ≤ ((8817119 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (12 * ((76 : ℝ) / 25)) 11]
    have hx : RB |12 * ((76 : ℝ) / 25) - ((23 : ℝ) / 2) * π| ((879 : ℝ) / 2500) ((1411 : ℝ) / 4000) := by
      have hz : ((879 : ℝ) / 2500) ≤ 12 * ((76 : ℝ) / 25) - ((23 : ℝ) / 2) * π ∧ 12 * ((76 : ℝ) / 25) - ((23 : ℝ) / 2) * π ≤ ((1411 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8817119 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((76 : ℝ) / 25) n) ≤ ((7997 : ℝ) / 2500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1642143 : ℝ) / 50000000) ≤ Real.log (π / ((76 : ℝ) / 25)) := by
    apply cov_log_2620.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((76 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_9 : ((3193499 : ℝ) / 100000000) ≤ hfun ((303 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((303 : ℝ) / 100)) ^ 2 ≤ ((1240309 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((303 : ℝ) / 100)) 1]
    have hx : RB |1 * ((303 : ℝ) / 100) - (1 : ℝ) * π| ((223 : ℝ) / 2000) ((279 : ℝ) / 2500) := by
      have hz : ((-279 : ℝ) / 2500) ≤ 1 * ((303 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((303 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-223 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1240309 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((303 : ℝ) / 100)) ^ 2 ≤ ((979981 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (2 * ((303 : ℝ) / 100)) 2]
    have hx : RB |2 * ((303 : ℝ) / 100) - (2 : ℝ) * π| ((223 : ℝ) / 1000) ((279 : ℝ) / 1250) := by
      have hz : ((-279 : ℝ) / 1250) ≤ 2 * ((303 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((303 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-223 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((979981 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((303 : ℝ) / 100)) ^ 2 ≤ ((10798071 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((303 : ℝ) / 100)) 3]
    have hx : RB |3 * ((303 : ℝ) / 100) - (3 : ℝ) * π| ((669 : ℝ) / 2000) ((837 : ℝ) / 2500) := by
      have hz : ((-837 : ℝ) / 2500) ≤ 3 * ((303 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((303 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-669 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10798071 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((303 : ℝ) / 100)) ^ 2 ≤ ((9322181 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((303 : ℝ) / 100)) 4]
    have hx : RB |4 * ((303 : ℝ) / 100) - (4 : ℝ) * π| ((223 : ℝ) / 500) ((279 : ℝ) / 625) := by
      have hz : ((-279 : ℝ) / 625) ≤ 4 * ((303 : ℝ) / 100) - (4 : ℝ) * π ∧ 4 * ((303 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-223 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9322181 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((303 : ℝ) / 100)) ^ 2 ≤ ((7013543 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (5 * ((303 : ℝ) / 100)) 5]
    have hx : RB |5 * ((303 : ℝ) / 100) - (5 : ℝ) * π| ((223 : ℝ) / 400) ((279 : ℝ) / 500) := by
      have hz : ((-279 : ℝ) / 500) ≤ 5 * ((303 : ℝ) / 100) - (5 : ℝ) * π ∧ 5 * ((303 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-223 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7013543 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((303 : ℝ) / 100)) ^ 2 ≤ ((38569447 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((303 : ℝ) / 100)) 6]
    have hx : RB |6 * ((303 : ℝ) / 100) - (6 : ℝ) * π| ((669 : ℝ) / 1000) ((837 : ℝ) / 1250) := by
      have hz : ((-837 : ℝ) / 1250) ≤ 6 * ((303 : ℝ) / 100) - (6 : ℝ) * π ∧ 6 * ((303 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-669 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((38569447 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((303 : ℝ) / 100)) ^ 2 ≤ ((49683503 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((303 : ℝ) / 100)) 7]
    have hx : RB |7 * ((303 : ℝ) / 100) - (7 : ℝ) * π| ((1561 : ℝ) / 2000) ((1953 : ℝ) / 2500) := by
      have hz : ((-1953 : ℝ) / 2500) ≤ 7 * ((303 : ℝ) / 100) - (7 : ℝ) * π ∧ 7 * ((303 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-1561 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49683503 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((303 : ℝ) / 100)) ^ 2 ≤ ((30514647 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((303 : ℝ) / 100)) 7]
    have hx : RB |8 * ((303 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((339 : ℝ) / 500) ((543 : ℝ) / 800) := by
      have hz : ((339 : ℝ) / 500) ≤ 8 * ((303 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((303 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((543 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((30514647 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((303 : ℝ) / 100)) ^ 2 ≤ ((7140049 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (9 * ((303 : ℝ) / 100)) 8]
    have hx : RB |9 * ((303 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((354 : ℝ) / 625) ((2269 : ℝ) / 4000) := by
      have hz : ((354 : ℝ) / 625) ≤ 9 * ((303 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 9 * ((303 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((2269 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7140049 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((303 : ℝ) / 100)) ^ 2 ≤ ((80788727 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((303 : ℝ) / 100)) 9]
    have hx : RB |10 * ((303 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((1137 : ℝ) / 2500) ((1823 : ℝ) / 4000) := by
      have hz : ((1137 : ℝ) / 2500) ≤ 10 * ((303 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 10 * ((303 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((1823 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((80788727 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((303 : ℝ) / 100)) ^ 2 ≤ ((22176487 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (11 * ((303 : ℝ) / 100)) 10]
    have hx : RB |11 * ((303 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((429 : ℝ) / 1250) ((1377 : ℝ) / 4000) := by
      have hz : ((429 : ℝ) / 1250) ≤ 11 * ((303 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 11 * ((303 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((1377 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22176487 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((303 : ℝ) / 100)) ^ 2 ≤ ((2960557 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (12 * ((303 : ℝ) / 100)) 11]
    have hx : RB |12 * ((303 : ℝ) / 100) - ((23 : ℝ) / 2) * π| ((579 : ℝ) / 2500) ((931 : ℝ) / 4000) := by
      have hz : ((579 : ℝ) / 2500) ≤ 12 * ((303 : ℝ) / 100) - ((23 : ℝ) / 2) * π ∧ 12 * ((303 : ℝ) / 100) - ((23 : ℝ) / 2) * π ≤ ((931 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2960557 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((303 : ℝ) / 100) n) ≤ ((47807 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((225861 : ℝ) / 6250000) ≤ Real.log (π / ((303 : ℝ) / 100)) := by
    apply cov_log_2621.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((303 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_11 : ((3456583 : ℝ) / 100000000) ≤ hfun ((151 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((151 : ℝ) / 50)) ^ 2 ≤ ((735701 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((151 : ℝ) / 50)) 1]
    have hx : RB |1 * ((151 : ℝ) / 50) - (1 : ℝ) * π| ((243 : ℝ) / 2000) ((76 : ℝ) / 625) := by
      have hz : ((-76 : ℝ) / 625) ≤ 1 * ((151 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((151 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-243 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((735701 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((151 : ℝ) / 50)) ^ 2 ≤ ((1449821 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (2 * ((151 : ℝ) / 50)) 2]
    have hx : RB |2 * ((151 : ℝ) / 50) - (2 : ℝ) * π| ((243 : ℝ) / 1000) ((152 : ℝ) / 625) := by
      have hz : ((-152 : ℝ) / 625) ≤ 2 * ((151 : ℝ) / 50) - (2 : ℝ) * π ∧ 2 * ((151 : ℝ) / 50) - (2 : ℝ) * π ≤ ((-243 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1449821 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((151 : ℝ) / 50)) ^ 2 ≤ ((254603 : ℝ) / 2000000) := by
    rw [sin_sq_shift_pi (3 * ((151 : ℝ) / 50)) 3]
    have hx : RB |3 * ((151 : ℝ) / 50) - (3 : ℝ) * π| ((729 : ℝ) / 2000) ((228 : ℝ) / 625) := by
      have hz : ((-228 : ℝ) / 625) ≤ 3 * ((151 : ℝ) / 50) - (3 : ℝ) * π ∧ 3 * ((151 : ℝ) / 50) - (3 : ℝ) * π ≤ ((-729 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((254603 : ℝ) / 2000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((151 : ℝ) / 50)) ^ 2 ≤ ((21859401 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((151 : ℝ) / 50)) 4]
    have hx : RB |4 * ((151 : ℝ) / 50) - (4 : ℝ) * π| ((243 : ℝ) / 500) ((304 : ℝ) / 625) := by
      have hz : ((-304 : ℝ) / 625) ≤ 4 * ((151 : ℝ) / 50) - (4 : ℝ) * π ∧ 4 * ((151 : ℝ) / 50) - (4 : ℝ) * π ≤ ((-243 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21859401 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((151 : ℝ) / 50)) ^ 2 ≤ ((32657099 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (5 * ((151 : ℝ) / 50)) 5]
    have hx : RB |5 * ((151 : ℝ) / 50) - (5 : ℝ) * π| ((243 : ℝ) / 400) ((76 : ℝ) / 125) := by
      have hz : ((-76 : ℝ) / 125) ≤ 5 * ((151 : ℝ) / 50) - (5 : ℝ) * π ∧ 5 * ((151 : ℝ) / 50) - (5 : ℝ) * π ≤ ((-243 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((32657099 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((151 : ℝ) / 50)) ^ 2 ≤ ((44501883 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((151 : ℝ) / 50)) 6]
    have hx : RB |6 * ((151 : ℝ) / 50) - (6 : ℝ) * π| ((729 : ℝ) / 1000) ((456 : ℝ) / 625) := by
      have hz : ((-456 : ℝ) / 625) ≤ 6 * ((151 : ℝ) / 50) - (6 : ℝ) * π ∧ 6 * ((151 : ℝ) / 50) - (6 : ℝ) * π ≤ ((-729 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44501883 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((151 : ℝ) / 50)) ^ 2 ≤ ((57018231 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((151 : ℝ) / 50)) 6]
    have hx : RB |7 * ((151 : ℝ) / 50) - ((13 : ℝ) / 2) * π| ((1799 : ℝ) / 2500) ((2881 : ℝ) / 4000) := by
      have hz : ((1799 : ℝ) / 2500) ≤ 7 * ((151 : ℝ) / 50) - ((13 : ℝ) / 2) * π ∧ 7 * ((151 : ℝ) / 50) - ((13 : ℝ) / 2) * π ≤ ((2881 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((57018231 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((151 : ℝ) / 50)) ^ 2 ≤ ((13708101 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (8 * ((151 : ℝ) / 50)) 7]
    have hx : RB |8 * ((151 : ℝ) / 50) - ((15 : ℝ) / 2) * π| ((299 : ℝ) / 500) ((479 : ℝ) / 800) := by
      have hz : ((299 : ℝ) / 500) ≤ 8 * ((151 : ℝ) / 50) - ((15 : ℝ) / 2) * π ∧ 8 * ((151 : ℝ) / 50) - ((15 : ℝ) / 2) * π ≤ ((479 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13708101 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((151 : ℝ) / 50)) ^ 2 ≤ ((19767961 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (9 * ((151 : ℝ) / 50)) 8]
    have hx : RB |9 * ((151 : ℝ) / 50) - ((17 : ℝ) / 2) * π| ((1191 : ℝ) / 2500) ((1909 : ℝ) / 4000) := by
      have hz : ((1191 : ℝ) / 2500) ≤ 9 * ((151 : ℝ) / 50) - ((17 : ℝ) / 2) * π ∧ 9 * ((151 : ℝ) / 50) - ((17 : ℝ) / 2) * π ≤ ((1909 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19767961 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((151 : ℝ) / 50)) ^ 2 ≤ ((87964271 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((151 : ℝ) / 50)) 9]
    have hx : RB |10 * ((151 : ℝ) / 50) - ((19 : ℝ) / 2) * π| ((887 : ℝ) / 2500) ((1423 : ℝ) / 4000) := by
      have hz : ((887 : ℝ) / 2500) ≤ 10 * ((151 : ℝ) / 50) - ((19 : ℝ) / 2) * π ∧ 10 * ((151 : ℝ) / 50) - ((19 : ℝ) / 2) * π ≤ ((1423 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((87964271 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((151 : ℝ) / 50)) ^ 2 ≤ ((94666227 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((151 : ℝ) / 50)) 10]
    have hx : RB |11 * ((151 : ℝ) / 50) - ((21 : ℝ) / 2) * π| ((583 : ℝ) / 2500) ((937 : ℝ) / 4000) := by
      have hz : ((583 : ℝ) / 2500) ≤ 11 * ((151 : ℝ) / 50) - ((21 : ℝ) / 2) * π ∧ 11 * ((151 : ℝ) / 50) - ((21 : ℝ) / 2) * π ≤ ((937 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94666227 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((151 : ℝ) / 50)) ^ 2 ≤ ((19752019 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (12 * ((151 : ℝ) / 50)) 11]
    have hx : RB |12 * ((151 : ℝ) / 50) - ((23 : ℝ) / 2) * π| ((279 : ℝ) / 2500) ((451 : ℝ) / 4000) := by
      have hz : ((279 : ℝ) / 2500) ≤ 12 * ((151 : ℝ) / 50) - ((23 : ℝ) / 2) * π ∧ 12 * ((151 : ℝ) / 50) - ((23 : ℝ) / 2) * π ≤ ((451 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19752019 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((151 : ℝ) / 50) n) ≤ ((449701 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((788871 : ℝ) / 20000000) ≤ Real.log (π / ((151 : ℝ) / 50)) := by
    apply cov_log_2622.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((151 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_10 : ((26045179 : ℝ) / 100000000) ≤ hfun ((163 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((163 : ℝ) / 100)) ^ 2 ≤ ((24912493 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (1 * ((163 : ℝ) / 100)) 0]
    have hx : RB |1 * ((163 : ℝ) / 100) - ((1 : ℝ) / 2) * π| ((37 : ℝ) / 625) ((237 : ℝ) / 4000) := by
      have hz : ((37 : ℝ) / 625) ≤ 1 * ((163 : ℝ) / 100) - ((1 : ℝ) / 2) * π ∧ 1 * ((163 : ℝ) / 100) - ((1 : ℝ) / 2) * π ≤ ((237 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24912493 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((163 : ℝ) / 100)) ^ 2 ≤ ((698841 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (2 * ((163 : ℝ) / 100)) 1]
    have hx : RB |2 * ((163 : ℝ) / 100) - (1 : ℝ) * π| ((74 : ℝ) / 625) ((237 : ℝ) / 2000) := by
      have hz : ((74 : ℝ) / 625) ≤ 2 * ((163 : ℝ) / 100) - (1 : ℝ) * π ∧ 2 * ((163 : ℝ) / 100) - (1 : ℝ) * π ≤ ((237 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((698841 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((163 : ℝ) / 100)) ^ 2 ≤ ((96880931 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((163 : ℝ) / 100)) 1]
    have hx : RB |3 * ((163 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((111 : ℝ) / 625) ((711 : ℝ) / 4000) := by
      have hz : ((111 : ℝ) / 625) ≤ 3 * ((163 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 3 * ((163 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((711 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((96880931 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((163 : ℝ) / 100)) ^ 2 ≤ ((2756421 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((163 : ℝ) / 100)) 2]
    have hx : RB |4 * ((163 : ℝ) / 100) - (2 : ℝ) * π| ((148 : ℝ) / 625) ((237 : ℝ) / 1000) := by
      have hz : ((148 : ℝ) / 625) ≤ 4 * ((163 : ℝ) / 100) - (2 : ℝ) * π ∧ 4 * ((163 : ℝ) / 100) - (2 : ℝ) * π ≤ ((237 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2756421 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((163 : ℝ) / 100)) ^ 2 ≤ ((1830141 : ℝ) / 2000000) := by
    rw [sin_sq_shift_half_pi (5 * ((163 : ℝ) / 100)) 2]
    have hx : RB |5 * ((163 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((37 : ℝ) / 125) ((237 : ℝ) / 800) := by
      have hz : ((37 : ℝ) / 125) ≤ 5 * ((163 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 5 * ((163 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((237 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1830141 : ℝ) / 2000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((163 : ℝ) / 100)) ^ 2 ≤ ((2423301 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (6 * ((163 : ℝ) / 100)) 3]
    have hx : RB |6 * ((163 : ℝ) / 100) - (3 : ℝ) * π| ((222 : ℝ) / 625) ((711 : ℝ) / 2000) := by
      have hz : ((222 : ℝ) / 625) ≤ 6 * ((163 : ℝ) / 100) - (3 : ℝ) * π ∧ 6 * ((163 : ℝ) / 100) - (3 : ℝ) * π ≤ ((711 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2423301 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((163 : ℝ) / 100)) ^ 2 ≤ ((83846523 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((163 : ℝ) / 100)) 3]
    have hx : RB |7 * ((163 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((259 : ℝ) / 625) ((1659 : ℝ) / 4000) := by
      have hz : ((259 : ℝ) / 625) ≤ 7 * ((163 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 7 * ((163 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((1659 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((83846523 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((163 : ℝ) / 100)) ^ 2 ≤ ((26053 : ℝ) / 125000) := by
    rw [sin_sq_shift_pi (8 * ((163 : ℝ) / 100)) 4]
    have hx : RB |8 * ((163 : ℝ) / 100) - (4 : ℝ) * π| ((296 : ℝ) / 625) ((237 : ℝ) / 500) := by
      have hz : ((296 : ℝ) / 625) ≤ 8 * ((163 : ℝ) / 100) - (4 : ℝ) * π ∧ 8 * ((163 : ℝ) / 100) - (4 : ℝ) * π ≤ ((237 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((26053 : ℝ) / 125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((163 : ℝ) / 100)) ^ 2 ≤ ((74351549 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((163 : ℝ) / 100)) 4]
    have hx : RB |9 * ((163 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((333 : ℝ) / 625) ((2133 : ℝ) / 4000) := by
      have hz : ((333 : ℝ) / 625) ≤ 9 * ((163 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 9 * ((163 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((2133 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((74351549 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((163 : ℝ) / 100)) ^ 2 ≤ ((1950569 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (10 * ((163 : ℝ) / 100)) 5]
    have hx : RB |10 * ((163 : ℝ) / 100) - (5 : ℝ) * π| ((74 : ℝ) / 125) ((237 : ℝ) / 400) := by
      have hz : ((74 : ℝ) / 125) ≤ 10 * ((163 : ℝ) / 100) - (5 : ℝ) * π ∧ 10 * ((163 : ℝ) / 100) - (5 : ℝ) * π ≤ ((237 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1950569 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((163 : ℝ) / 100)) ^ 2 ≤ ((12715883 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (11 * ((163 : ℝ) / 100)) 5]
    have hx : RB |11 * ((163 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((407 : ℝ) / 625) ((2607 : ℝ) / 4000) := by
      have hz : ((407 : ℝ) / 625) ≤ 11 * ((163 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 11 * ((163 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((2607 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12715883 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((163 : ℝ) / 100)) ^ 2 ≤ ((42649293 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((163 : ℝ) / 100)) 6]
    have hx : RB |12 * ((163 : ℝ) / 100) - (6 : ℝ) * π| ((444 : ℝ) / 625) ((711 : ℝ) / 1000) := by
      have hz : ((444 : ℝ) / 625) ≤ 12 * ((163 : ℝ) / 100) - (6 : ℝ) * π ∧ 12 * ((163 : ℝ) / 100) - (6 : ℝ) * π ≤ ((711 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42649293 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((163 : ℝ) / 100) n) ≤ ((39436171 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((65612037 : ℝ) / 100000000) ≤ Real.log (π / ((163 : ℝ) / 100)) := by
    apply cov_log_2623.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((163 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_12 : ((3716383 : ℝ) / 100000000) ≤ hfun ((301 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((301 : ℝ) / 100)) ^ 2 ≤ ((860953 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((301 : ℝ) / 100)) 1]
    have hx : RB |1 * ((301 : ℝ) / 100) - (1 : ℝ) * π| ((263 : ℝ) / 2000) ((329 : ℝ) / 2500) := by
      have hz : ((-329 : ℝ) / 2500) ≤ 1 * ((301 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((301 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-263 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((860953 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((301 : ℝ) / 100)) ^ 2 ≤ ((6769401 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((301 : ℝ) / 100)) 2]
    have hx : RB |2 * ((301 : ℝ) / 100) - (2 : ℝ) * π| ((263 : ℝ) / 1000) ((329 : ℝ) / 1250) := by
      have hz : ((-329 : ℝ) / 1250) ≤ 2 * ((301 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((301 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-263 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6769401 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((301 : ℝ) / 100)) ^ 2 ≤ ((739829 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (3 * ((301 : ℝ) / 100)) 3]
    have hx : RB |3 * ((301 : ℝ) / 100) - (3 : ℝ) * π| ((789 : ℝ) / 2000) ((987 : ℝ) / 2500) := by
      have hz : ((-987 : ℝ) / 2500) ≤ 3 * ((301 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((301 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-789 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((739829 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((301 : ℝ) / 100)) ^ 2 ≤ ((12627771 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((301 : ℝ) / 100)) 4]
    have hx : RB |4 * ((301 : ℝ) / 100) - (4 : ℝ) * π| ((263 : ℝ) / 500) ((329 : ℝ) / 625) := by
      have hz : ((-329 : ℝ) / 625) ≤ 4 * ((301 : ℝ) / 100) - (4 : ℝ) * π ∧ 4 * ((301 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-263 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12627771 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((301 : ℝ) / 100)) ^ 2 ≤ ((4679657 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (5 * ((301 : ℝ) / 100)) 5]
    have hx : RB |5 * ((301 : ℝ) / 100) - (5 : ℝ) * π| ((263 : ℝ) / 400) ((329 : ℝ) / 500) := by
      have hz : ((-329 : ℝ) / 500) ≤ 5 * ((301 : ℝ) / 100) - (5 : ℝ) * π ∧ 5 * ((301 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-263 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4679657 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((301 : ℝ) / 100)) ^ 2 ≤ ((51024671 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((301 : ℝ) / 100)) 5]
    have hx : RB |6 * ((301 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((1953 : ℝ) / 2500) ((3127 : ℝ) / 4000) := by
      have hz : ((1953 : ℝ) / 2500) ≤ 6 * ((301 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((301 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((3127 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((51024671 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((301 : ℝ) / 100)) ^ 2 ≤ ((63731711 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((301 : ℝ) / 100)) 6]
    have hx : RB |7 * ((301 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((406 : ℝ) / 625) ((2601 : ℝ) / 4000) := by
      have hz : ((406 : ℝ) / 625) ≤ 7 * ((301 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((301 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((2601 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((63731711 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((301 : ℝ) / 100)) ^ 2 ≤ ((15124419 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (8 * ((301 : ℝ) / 100)) 7]
    have hx : RB |8 * ((301 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((259 : ℝ) / 500) ((83 : ℝ) / 160) := by
      have hz : ((259 : ℝ) / 500) ≤ 8 * ((301 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((301 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((83 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15124419 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((301 : ℝ) / 100)) ^ 2 ≤ ((85843711 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((301 : ℝ) / 100)) 8]
    have hx : RB |9 * ((301 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((483 : ℝ) / 1250) ((1549 : ℝ) / 4000) := by
      have hz : ((483 : ℝ) / 1250) ≤ 9 * ((301 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 9 * ((301 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((1549 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((85843711 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((301 : ℝ) / 100)) ^ 2 ≤ ((18731239 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (10 * ((301 : ℝ) / 100)) 9]
    have hx : RB |10 * ((301 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((637 : ℝ) / 2500) ((1023 : ℝ) / 4000) := by
      have hz : ((637 : ℝ) / 2500) ≤ 10 * ((301 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 10 * ((301 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((1023 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18731239 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((301 : ℝ) / 100)) ^ 2 ≤ ((123113 : ℝ) / 125000) := by
    rw [sin_sq_shift_half_pi (11 * ((301 : ℝ) / 100)) 10]
    have hx : RB |11 * ((301 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((77 : ℝ) / 625) ((497 : ℝ) / 4000) := by
      have hz : ((77 : ℝ) / 625) ≤ 11 * ((301 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 11 * ((301 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((497 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((123113 : ℝ) / 125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((301 : ℝ) / 100)) ^ 2 ≤ ((12499343 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (12 * ((301 : ℝ) / 100)) 11]
    have hx : RB |12 * ((301 : ℝ) / 100) - ((23 : ℝ) / 2) * π| ((29 : ℝ) / 4000) ((21 : ℝ) / 2500) := by
      have hz : ((-21 : ℝ) / 2500) ≤ 12 * ((301 : ℝ) / 100) - ((23 : ℝ) / 2) * π ∧ 12 * ((301 : ℝ) / 100) - ((23 : ℝ) / 2) * π ≤ ((-29 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12499343 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((301 : ℝ) / 100) n) ≤ ((260661 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((427603 : ℝ) / 10000000) ≤ Real.log (π / ((301 : ℝ) / 100)) := by
    apply cov_log_2624.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((301 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_14 : ((1986809 : ℝ) / 50000000) ≤ hfun (3 : ℝ) := by
  have s1 : Real.sin (1 * (3 : ℝ)) ^ 2 ≤ ((995861 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * (3 : ℝ)) 1]
    have hx : RB |1 * (3 : ℝ) - (1 : ℝ) * π| ((283 : ℝ) / 2000) ((177 : ℝ) / 1250) := by
      have hz : ((-177 : ℝ) / 1250) ≤ 1 * (3 : ℝ) - (1 : ℝ) * π ∧ 1 * (3 : ℝ) - (1 : ℝ) * π ≤ ((-283 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((995861 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * (3 : ℝ)) ^ 2 ≤ ((780871 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (2 * (3 : ℝ)) 2]
    have hx : RB |2 * (3 : ℝ) - (2 : ℝ) * π| ((283 : ℝ) / 1000) ((177 : ℝ) / 625) := by
      have hz : ((-177 : ℝ) / 625) ≤ 2 * (3 : ℝ) - (2 : ℝ) * π ∧ 2 * (3 : ℝ) - (2 : ℝ) * π ≤ ((-283 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((780871 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * (3 : ℝ)) ^ 2 ≤ ((16989991 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * (3 : ℝ)) 3]
    have hx : RB |3 * (3 : ℝ) - (3 : ℝ) * π| ((849 : ℝ) / 2000) ((531 : ℝ) / 1250) := by
      have hz : ((-531 : ℝ) / 1250) ≤ 3 * (3 : ℝ) - (3 : ℝ) * π ∧ 3 * (3 : ℝ) - (3 : ℝ) * π ≤ ((-849 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16989991 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * (3 : ℝ)) ^ 2 ≤ ((14405709 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * (3 : ℝ)) 4]
    have hx : RB |4 * (3 : ℝ) - (4 : ℝ) * π| ((283 : ℝ) / 500) ((354 : ℝ) / 625) := by
      have hz : ((-354 : ℝ) / 625) ≤ 4 * (3 : ℝ) - (4 : ℝ) * π ∧ 4 * (3 : ℝ) - (4 : ℝ) * π ≤ ((-283 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14405709 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * (3 : ℝ)) ^ 2 ≤ ((10587053 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (5 * (3 : ℝ)) 5]
    have hx : RB |5 * (3 : ℝ) - (5 : ℝ) * π| ((283 : ℝ) / 400) ((177 : ℝ) / 250) := by
      have hz : ((-177 : ℝ) / 250) ≤ 5 * (3 : ℝ) - (5 : ℝ) * π ∧ 5 * (3 : ℝ) - (5 : ℝ) * π ≤ ((-283 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10587053 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * (3 : ℝ)) ^ 2 ≤ ((28430977 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (6 * (3 : ℝ)) 5]
    have hx : RB |6 * (3 : ℝ) - ((11 : ℝ) / 2) * π| ((1803 : ℝ) / 2500) ((2887 : ℝ) / 4000) := by
      have hz : ((1803 : ℝ) / 2500) ≤ 6 * (3 : ℝ) - ((11 : ℝ) / 2) * π ∧ 6 * (3 : ℝ) - ((11 : ℝ) / 2) * π ≤ ((2887 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((28430977 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * (3 : ℝ)) ^ 2 ≤ ((70213691 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * (3 : ℝ)) 6]
    have hx : RB |7 * (3 : ℝ) - ((13 : ℝ) / 2) * π| ((1449 : ℝ) / 2500) ((2321 : ℝ) / 4000) := by
      have hz : ((1449 : ℝ) / 2500) ≤ 7 * (3 : ℝ) - ((13 : ℝ) / 2) * π ∧ 7 * (3 : ℝ) - ((13 : ℝ) / 2) * π ≤ ((2321 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((70213691 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * (3 : ℝ)) ^ 2 ≤ ((41042529 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * (3 : ℝ)) 7]
    have hx : RB |8 * (3 : ℝ) - ((15 : ℝ) / 2) * π| ((219 : ℝ) / 500) ((351 : ℝ) / 800) := by
      have hz : ((219 : ℝ) / 500) ≤ 8 * (3 : ℝ) - ((15 : ℝ) / 2) * π ∧ 8 * (3 : ℝ) - ((15 : ℝ) / 2) * π ≤ ((351 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((41042529 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * (3 : ℝ)) ^ 2 ≤ ((45742713 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (9 * (3 : ℝ)) 8]
    have hx : RB |9 * (3 : ℝ) - ((17 : ℝ) / 2) * π| ((741 : ℝ) / 2500) ((1189 : ℝ) / 4000) := by
      have hz : ((741 : ℝ) / 2500) ≤ 9 * (3 : ℝ) - ((17 : ℝ) / 2) * π ∧ 9 * (3 : ℝ) - ((17 : ℝ) / 2) * π ≤ ((1189 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45742713 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * (3 : ℝ)) ^ 2 ≤ ((97624109 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * (3 : ℝ)) 9]
    have hx : RB |10 * (3 : ℝ) - ((19 : ℝ) / 2) * π| ((387 : ℝ) / 2500) ((623 : ℝ) / 4000) := by
      have hz : ((387 : ℝ) / 2500) ≤ 10 * (3 : ℝ) - ((19 : ℝ) / 2) * π ∧ 10 * (3 : ℝ) - ((19 : ℝ) / 2) * π ≤ ((623 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((97624109 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * (3 : ℝ)) ^ 2 ≤ ((49991289 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (11 * (3 : ℝ)) 10]
    have hx : RB |11 * (3 : ℝ) - ((21 : ℝ) / 2) * π| ((33 : ℝ) / 2500) ((57 : ℝ) / 4000) := by
      have hz : ((33 : ℝ) / 2500) ≤ 11 * (3 : ℝ) - ((21 : ℝ) / 2) * π ∧ 11 * (3 : ℝ) - ((21 : ℝ) / 2) * π ≤ ((57 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49991289 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * (3 : ℝ)) ^ 2 ≤ ((24597527 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (12 * (3 : ℝ)) 11]
    have hx : RB |12 * (3 : ℝ) - ((23 : ℝ) / 2) * π| ((509 : ℝ) / 4000) ((321 : ℝ) / 2500) := by
      have hz : ((-321 : ℝ) / 2500) ≤ 12 * (3 : ℝ) - ((23 : ℝ) / 2) * π ∧ 12 * (3 : ℝ) - ((23 : ℝ) / 2) * π ≤ ((-509 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24597527 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq (3 : ℝ) n) ≤ ((59661 : ℝ) / 10000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((4608809 : ℝ) / 100000000) ≤ Real.log (π / (3 : ℝ)) := by
    apply cov_log_2625.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := (3 : ℝ)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_15 : ((845637 : ℝ) / 20000000) ≤ hfun ((299 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((299 : ℝ) / 100)) ^ 2 ≤ ((1140371 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((299 : ℝ) / 100)) 1]
    have hx : RB |1 * ((299 : ℝ) / 100) - (1 : ℝ) * π| ((303 : ℝ) / 2000) ((379 : ℝ) / 2500) := by
      have hz : ((-379 : ℝ) / 2500) ≤ 1 * ((299 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((299 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-303 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1140371 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((299 : ℝ) / 100)) ^ 2 ≤ ((2228889 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (2 * ((299 : ℝ) / 100)) 2]
    have hx : RB |2 * ((299 : ℝ) / 100) - (2 : ℝ) * π| ((303 : ℝ) / 1000) ((379 : ℝ) / 1250) := by
      have hz : ((-379 : ℝ) / 1250) ≤ 2 * ((299 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((299 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-303 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2228889 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((299 : ℝ) / 100)) ^ 2 ≤ ((19302569 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((299 : ℝ) / 100)) 3]
    have hx : RB |3 * ((299 : ℝ) / 100) - (3 : ℝ) * π| ((909 : ℝ) / 2000) ((1137 : ℝ) / 2500) := by
      have hz : ((-1137 : ℝ) / 2500) ≤ 3 * ((299 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((299 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-909 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19302569 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((299 : ℝ) / 100)) ^ 2 ≤ ((32504723 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((299 : ℝ) / 100)) 4]
    have hx : RB |4 * ((299 : ℝ) / 100) - (4 : ℝ) * π| ((303 : ℝ) / 500) ((379 : ℝ) / 625) := by
      have hz : ((-379 : ℝ) / 625) ≤ 4 * ((299 : ℝ) / 100) - (4 : ℝ) * π ∧ 4 * ((299 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-303 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((32504723 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((299 : ℝ) / 100)) ^ 2 ≤ ((295891 : ℝ) / 625000) := by
    rw [sin_sq_shift_pi (5 * ((299 : ℝ) / 100)) 5]
    have hx : RB |5 * ((299 : ℝ) / 100) - (5 : ℝ) * π| ((303 : ℝ) / 400) ((379 : ℝ) / 500) := by
      have hz : ((-379 : ℝ) / 500) ≤ 5 * ((299 : ℝ) / 100) - (5 : ℝ) * π ∧ 5 * ((299 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-303 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((295891 : ℝ) / 625000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((299 : ℝ) / 100)) ^ 2 ≤ ((12526127 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (6 * ((299 : ℝ) / 100)) 5]
    have hx : RB |6 * ((299 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((1653 : ℝ) / 2500) ((2647 : ℝ) / 4000) := by
      have hz : ((1653 : ℝ) / 2500) ≤ 6 * ((299 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((299 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((2647 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12526127 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((299 : ℝ) / 100)) ^ 2 ≤ ((76332439 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((299 : ℝ) / 100)) 6]
    have hx : RB |7 * ((299 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((637 : ℝ) / 1250) ((2041 : ℝ) / 4000) := by
      have hz : ((637 : ℝ) / 1250) ≤ 7 * ((299 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((299 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((2041 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((76332439 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((299 : ℝ) / 100)) ^ 2 ≤ ((87755811 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((299 : ℝ) / 100)) 7]
    have hx : RB |8 * ((299 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((179 : ℝ) / 500) ((287 : ℝ) / 800) := by
      have hz : ((179 : ℝ) / 500) ≤ 8 * ((299 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((299 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((287 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((87755811 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((299 : ℝ) / 100)) ^ 2 ≤ ((19160817 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (9 * ((299 : ℝ) / 100)) 8]
    have hx : RB |9 * ((299 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((129 : ℝ) / 625) ((829 : ℝ) / 4000) := by
      have hz : ((129 : ℝ) / 625) ≤ 9 * ((299 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 9 * ((299 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((829 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19160817 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((299 : ℝ) / 100)) ^ 2 ≤ ((49850011 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((299 : ℝ) / 100)) 9]
    have hx : RB |10 * ((299 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((137 : ℝ) / 2500) ((223 : ℝ) / 4000) := by
      have hz : ((137 : ℝ) / 2500) ≤ 10 * ((299 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 10 * ((299 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((223 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49850011 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((299 : ℝ) / 100)) ^ 2 ≤ ((49543103 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (11 * ((299 : ℝ) / 100)) 10]
    have hx : RB |11 * ((299 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((383 : ℝ) / 4000) ((121 : ℝ) / 1250) := by
      have hz : ((-121 : ℝ) / 1250) ≤ 11 * ((299 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 11 * ((299 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((-383 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49543103 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((299 : ℝ) / 100)) ^ 2 ≤ ((1469041 : ℝ) / 1562500) := by
    rw [sin_sq_shift_half_pi (12 * ((299 : ℝ) / 100)) 11]
    have hx : RB |12 * ((299 : ℝ) / 100) - ((23 : ℝ) / 2) * π| ((989 : ℝ) / 4000) ((621 : ℝ) / 2500) := by
      have hz : ((-621 : ℝ) / 2500) ≤ 12 * ((299 : ℝ) / 100) - ((23 : ℝ) / 2) * π ∧ 12 * ((299 : ℝ) / 100) - ((23 : ℝ) / 2) * π ≤ ((-989 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1469041 : ℝ) / 1562500) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((299 : ℝ) / 100) n) ≤ ((27027 : ℝ) / 4000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((4942699 : ℝ) / 100000000) ≤ Real.log (π / ((299 : ℝ) / 100)) := by
    apply cov_log_2626.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((299 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_13 : ((25946081 : ℝ) / 100000000) ≤ hfun ((41 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((41 : ℝ) / 25)) ^ 2 ≤ ((99521949 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (1 * ((41 : ℝ) / 25)) 0]
    have hx : RB |1 * ((41 : ℝ) / 25) - ((1 : ℝ) / 2) * π| ((173 : ℝ) / 2500) ((277 : ℝ) / 4000) := by
      have hz : ((173 : ℝ) / 2500) ≤ 1 * ((41 : ℝ) / 25) - ((1 : ℝ) / 2) * π ∧ 1 * ((41 : ℝ) / 25) - ((1 : ℝ) / 2) * π ≤ ((277 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99521949 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((41 : ℝ) / 25)) ^ 2 ≤ ((95301 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (2 * ((41 : ℝ) / 25)) 1]
    have hx : RB |2 * ((41 : ℝ) / 25) - (1 : ℝ) * π| ((173 : ℝ) / 1250) ((277 : ℝ) / 2000) := by
      have hz : ((173 : ℝ) / 1250) ≤ 2 * ((41 : ℝ) / 25) - (1 : ℝ) * π ∧ 2 * ((41 : ℝ) / 25) - (1 : ℝ) * π ≤ ((277 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((95301 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((41 : ℝ) / 25)) ^ 2 ≤ ((95755647 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((41 : ℝ) / 25)) 1]
    have hx : RB |3 * ((41 : ℝ) / 25) - ((3 : ℝ) / 2) * π| ((519 : ℝ) / 2500) ((831 : ℝ) / 4000) := by
      have hz : ((519 : ℝ) / 2500) ≤ 3 * ((41 : ℝ) / 25) - ((3 : ℝ) / 2) * π ∧ 3 * ((41 : ℝ) / 25) - ((3 : ℝ) / 2) * π ≤ ((831 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((95755647 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((41 : ℝ) / 25)) ^ 2 ≤ ((3739611 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((41 : ℝ) / 25)) 2]
    have hx : RB |4 * ((41 : ℝ) / 25) - (2 : ℝ) * π| ((173 : ℝ) / 625) ((277 : ℝ) / 1000) := by
      have hz : ((173 : ℝ) / 625) ≤ 4 * ((41 : ℝ) / 25) - (2 : ℝ) * π ∧ 4 * ((41 : ℝ) / 25) - (2 : ℝ) * π ≤ ((277 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3739611 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((41 : ℝ) / 25)) ^ 2 ≤ ((17705503 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (5 * ((41 : ℝ) / 25)) 2]
    have hx : RB |5 * ((41 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((173 : ℝ) / 500) ((277 : ℝ) / 800) := by
      have hz : ((173 : ℝ) / 500) ≤ 5 * ((41 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 5 * ((41 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((277 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17705503 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((41 : ℝ) / 25)) ^ 2 ≤ ((4074229 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((41 : ℝ) / 25)) 3]
    have hx : RB |6 * ((41 : ℝ) / 25) - (3 : ℝ) * π| ((519 : ℝ) / 1250) ((831 : ℝ) / 2000) := by
      have hz : ((519 : ℝ) / 1250) ≤ 6 * ((41 : ℝ) / 25) - (3 : ℝ) * π ∧ 6 * ((41 : ℝ) / 25) - (3 : ℝ) * π ≤ ((831 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4074229 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((41 : ℝ) / 25)) ^ 2 ≤ ((4901289 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (7 * ((41 : ℝ) / 25)) 3]
    have hx : RB |7 * ((41 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((1211 : ℝ) / 2500) ((1939 : ℝ) / 4000) := by
      have hz : ((1211 : ℝ) / 2500) ≤ 7 * ((41 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 7 * ((41 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((1939 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4901289 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((41 : ℝ) / 25)) ^ 2 ≤ ((1384667 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (8 * ((41 : ℝ) / 25)) 4]
    have hx : RB |8 * ((41 : ℝ) / 25) - (4 : ℝ) * π| ((346 : ℝ) / 625) ((277 : ℝ) / 500) := by
      have hz : ((346 : ℝ) / 625) ≤ 8 * ((41 : ℝ) / 25) - (4 : ℝ) * π ∧ 8 * ((41 : ℝ) / 25) - (4 : ℝ) * π ≤ ((277 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1384667 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((41 : ℝ) / 25)) ^ 2 ≤ ((6624637 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (9 * ((41 : ℝ) / 25)) 4]
    have hx : RB |9 * ((41 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((1557 : ℝ) / 2500) ((2493 : ℝ) / 4000) := by
      have hz : ((1557 : ℝ) / 2500) ≤ 9 * ((41 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 9 * ((41 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((2493 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6624637 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((41 : ℝ) / 25)) ^ 2 ≤ ((40814669 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((41 : ℝ) / 25)) 5]
    have hx : RB |10 * ((41 : ℝ) / 25) - (5 : ℝ) * π| ((173 : ℝ) / 250) ((277 : ℝ) / 400) := by
      have hz : ((173 : ℝ) / 250) ≤ 10 * ((41 : ℝ) / 25) - (5 : ℝ) * π ∧ 10 * ((41 : ℝ) / 25) - (5 : ℝ) * π ≤ ((277 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((40814669 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((41 : ℝ) / 25)) ^ 2 ≤ ((52972779 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((41 : ℝ) / 25)) 5]
    have hx : RB |11 * ((41 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((1903 : ℝ) / 2500) ((3047 : ℝ) / 4000) := by
      have hz : ((1903 : ℝ) / 2500) ≤ 11 * ((41 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 11 * ((41 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((3047 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((52972779 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((41 : ℝ) / 25)) ^ 2 ≤ ((27530929 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((41 : ℝ) / 25)) 6]
    have hx : RB |12 * ((41 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((2959 : ℝ) / 4000) ((1851 : ℝ) / 2500) := by
      have hz : ((-1851 : ℝ) / 2500) ≤ 12 * ((41 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 12 * ((41 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((-2959 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((27530929 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((41 : ℝ) / 25) n) ≤ ((7785047 : ℝ) / 20000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((13000083 : ℝ) / 20000000) ≤ Real.log (π / ((41 : ℝ) / 25)) := by
    apply cov_log_2627.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((41 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_16 : ((447991 : ℝ) / 10000000) ≤ hfun ((149 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((149 : ℝ) / 50)) ^ 2 ≤ ((2588851 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((149 : ℝ) / 50)) 1]
    have hx : RB |1 * ((149 : ℝ) / 50) - (1 : ℝ) * π| ((323 : ℝ) / 2000) ((101 : ℝ) / 625) := by
      have hz : ((-101 : ℝ) / 625) ≤ 1 * ((149 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((149 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-323 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2588851 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((149 : ℝ) / 50)) ^ 2 ≤ ((630511 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (2 * ((149 : ℝ) / 50)) 2]
    have hx : RB |2 * ((149 : ℝ) / 50) - (2 : ℝ) * π| ((323 : ℝ) / 1000) ((202 : ℝ) / 625) := by
      have hz : ((-202 : ℝ) / 625) ≤ 2 * ((149 : ℝ) / 50) - (2 : ℝ) * π ∧ 2 * ((149 : ℝ) / 50) - (2 : ℝ) * π ≤ ((-323 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((630511 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((149 : ℝ) / 50)) ^ 2 ≤ ((21726089 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((149 : ℝ) / 50)) 3]
    have hx : RB |3 * ((149 : ℝ) / 50) - (3 : ℝ) * π| ((969 : ℝ) / 2000) ((303 : ℝ) / 625) := by
      have hz : ((-303 : ℝ) / 625) ≤ 3 * ((149 : ℝ) / 50) - (3 : ℝ) * π ∧ 3 * ((149 : ℝ) / 50) - (3 : ℝ) * π ≤ ((-969 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21726089 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((149 : ℝ) / 50)) ^ 2 ≤ ((18156187 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((149 : ℝ) / 50)) 4]
    have hx : RB |4 * ((149 : ℝ) / 50) - (4 : ℝ) * π| ((323 : ℝ) / 500) ((404 : ℝ) / 625) := by
      have hz : ((-404 : ℝ) / 625) ≤ 4 * ((149 : ℝ) / 50) - (4 : ℝ) * π ∧ 4 * ((149 : ℝ) / 50) - (4 : ℝ) * π ≤ ((-323 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18156187 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((149 : ℝ) / 50)) ^ 2 ≤ ((5281559 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (5 * ((149 : ℝ) / 50)) 4]
    have hx : RB |5 * ((149 : ℝ) / 50) - ((9 : ℝ) / 2) * π| ((1907 : ℝ) / 2500) ((3053 : ℝ) / 4000) := by
      have hz : ((1907 : ℝ) / 2500) ≤ 5 * ((149 : ℝ) / 50) - ((9 : ℝ) / 2) * π ∧ 5 * ((149 : ℝ) / 50) - ((9 : ℝ) / 2) * π ≤ ((3053 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5281559 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((149 : ℝ) / 50)) ^ 2 ≤ ((13649101 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (6 * ((149 : ℝ) / 50)) 5]
    have hx : RB |6 * ((149 : ℝ) / 50) - ((11 : ℝ) / 2) * π| ((1503 : ℝ) / 2500) ((2407 : ℝ) / 4000) := by
      have hz : ((1503 : ℝ) / 2500) ≤ 6 * ((149 : ℝ) / 50) - ((11 : ℝ) / 2) * π ∧ 6 * ((149 : ℝ) / 50) - ((11 : ℝ) / 2) * π ≤ ((2407 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13649101 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((149 : ℝ) / 50)) ^ 2 ≤ ((81962693 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((149 : ℝ) / 50)) 6]
    have hx : RB |7 * ((149 : ℝ) / 50) - ((13 : ℝ) / 2) * π| ((1099 : ℝ) / 2500) ((1761 : ℝ) / 4000) := by
      have hz : ((1099 : ℝ) / 2500) ≤ 7 * ((149 : ℝ) / 50) - ((13 : ℝ) / 2) * π ∧ 7 * ((149 : ℝ) / 50) - ((13 : ℝ) / 2) * π ≤ ((1761 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((81962693 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((149 : ℝ) / 50)) ^ 2 ≤ ((5780087 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (8 * ((149 : ℝ) / 50)) 7]
    have hx : RB |8 * ((149 : ℝ) / 50) - ((15 : ℝ) / 2) * π| ((139 : ℝ) / 500) ((223 : ℝ) / 800) := by
      have hz : ((139 : ℝ) / 500) ≤ 8 * ((149 : ℝ) / 50) - ((15 : ℝ) / 2) * π ∧ 8 * ((149 : ℝ) / 50) - ((15 : ℝ) / 2) * π ≤ ((223 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5780087 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((149 : ℝ) / 50)) ^ 2 ≤ ((98651649 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((149 : ℝ) / 50)) 8]
    have hx : RB |9 * ((149 : ℝ) / 50) - ((17 : ℝ) / 2) * π| ((291 : ℝ) / 2500) ((469 : ℝ) / 4000) := by
      have hz : ((291 : ℝ) / 2500) ≤ 9 * ((149 : ℝ) / 50) - ((17 : ℝ) / 2) * π ∧ 9 * ((149 : ℝ) / 50) - ((17 : ℝ) / 2) * π ≤ ((469 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((98651649 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((149 : ℝ) / 50)) ^ 2 ≤ ((49902167 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((149 : ℝ) / 50)) 9]
    have hx : RB |10 * ((149 : ℝ) / 50) - ((19 : ℝ) / 2) * π| ((177 : ℝ) / 4000) ((113 : ℝ) / 2500) := by
      have hz : ((-113 : ℝ) / 2500) ≤ 10 * ((149 : ℝ) / 50) - ((19 : ℝ) / 2) * π ∧ 10 * ((149 : ℝ) / 50) - ((19 : ℝ) / 2) * π ≤ ((-177 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49902167 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((149 : ℝ) / 50)) ^ 2 ≤ ((47915073 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (11 * ((149 : ℝ) / 50)) 10]
    have hx : RB |11 * ((149 : ℝ) / 50) - ((21 : ℝ) / 2) * π| ((823 : ℝ) / 4000) ((517 : ℝ) / 2500) := by
      have hz : ((-517 : ℝ) / 2500) ≤ 11 * ((149 : ℝ) / 50) - ((21 : ℝ) / 2) * π ∧ 11 * ((149 : ℝ) / 50) - ((21 : ℝ) / 2) * π ≤ ((-823 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47915073 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((149 : ℝ) / 50)) ^ 2 ≤ ((87146533 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((149 : ℝ) / 50)) 11]
    have hx : RB |12 * ((149 : ℝ) / 50) - ((23 : ℝ) / 2) * π| ((1469 : ℝ) / 4000) ((921 : ℝ) / 2500) := by
      have hz : ((-921 : ℝ) / 2500) ≤ 12 * ((149 : ℝ) / 50) - ((23 : ℝ) / 2) * π ∧ 12 * ((149 : ℝ) / 50) - ((23 : ℝ) / 2) * π ≤ ((-1469 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((87146533 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((149 : ℝ) / 50) n) ≤ ((758699 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((5277709 : ℝ) / 100000000) ≤ Real.log (π / ((149 : ℝ) / 50)) := by
    apply cov_log_2628.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((149 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_18 : ((945983 : ℝ) / 20000000) ≤ hfun ((297 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((297 : ℝ) / 100)) ^ 2 ≤ ((116637 : ℝ) / 4000000) := by
    rw [sin_sq_shift_pi (1 * ((297 : ℝ) / 100)) 1]
    have hx : RB |1 * ((297 : ℝ) / 100) - (1 : ℝ) * π| ((343 : ℝ) / 2000) ((429 : ℝ) / 2500) := by
      have hz : ((-429 : ℝ) / 2500) ≤ 1 * ((297 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((297 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-343 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((116637 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((297 : ℝ) / 100)) ^ 2 ≤ ((11324707 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((297 : ℝ) / 100)) 2]
    have hx : RB |2 * ((297 : ℝ) / 100) - (2 : ℝ) * π| ((343 : ℝ) / 1000) ((429 : ℝ) / 1250) := by
      have hz : ((-429 : ℝ) / 1250) ≤ 2 * ((297 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((297 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-343 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11324707 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((297 : ℝ) / 100)) ^ 2 ≤ ((6062987 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (3 * ((297 : ℝ) / 100)) 3]
    have hx : RB |3 * ((297 : ℝ) / 100) - (3 : ℝ) * π| ((1029 : ℝ) / 2000) ((1287 : ℝ) / 2500) := by
      have hz : ((-1287 : ℝ) / 2500) ≤ 3 * ((297 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((297 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-1029 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6062987 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((297 : ℝ) / 100)) ^ 2 ≤ ((40210671 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((297 : ℝ) / 100)) 4]
    have hx : RB |4 * ((297 : ℝ) / 100) - (4 : ℝ) * π| ((343 : ℝ) / 500) ((429 : ℝ) / 625) := by
      have hz : ((-429 : ℝ) / 625) ≤ 4 * ((297 : ℝ) / 100) - (4 : ℝ) * π ∧ 4 * ((297 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-343 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((40210671 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((297 : ℝ) / 100)) ^ 2 ≤ ((57674507 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((297 : ℝ) / 100)) 4]
    have hx : RB |5 * ((297 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((891 : ℝ) / 1250) ((2853 : ℝ) / 4000) := by
      have hz : ((891 : ℝ) / 1250) ≤ 5 * ((297 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((297 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((2853 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((57674507 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((297 : ℝ) / 100)) ^ 2 ≤ ((3681143 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (6 * ((297 : ℝ) / 100)) 5]
    have hx : RB |6 * ((297 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((1353 : ℝ) / 2500) ((2167 : ℝ) / 4000) := by
      have hz : ((1353 : ℝ) / 2500) ≤ 6 * ((297 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((297 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((2167 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3681143 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((297 : ℝ) / 100)) ^ 2 ≤ ((86988581 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((297 : ℝ) / 100)) 6]
    have hx : RB |7 * ((297 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((231 : ℝ) / 625) ((1481 : ℝ) / 4000) := by
      have hz : ((231 : ℝ) / 625) ≤ 7 * ((297 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((297 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((1481 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((86988581 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((297 : ℝ) / 100)) ^ 2 ≤ ((2403349 : ℝ) / 2500000) := by
    rw [sin_sq_shift_half_pi (8 * ((297 : ℝ) / 100)) 7]
    have hx : RB |8 * ((297 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((99 : ℝ) / 500) ((159 : ℝ) / 800) := by
      have hz : ((99 : ℝ) / 500) ≤ 8 * ((297 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((297 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((159 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2403349 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((297 : ℝ) / 100)) ^ 2 ≤ ((49965161 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (9 * ((297 : ℝ) / 100)) 8]
    have hx : RB |9 * ((297 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((33 : ℝ) / 1250) ((109 : ℝ) / 4000) := by
      have hz : ((33 : ℝ) / 1250) ≤ 9 * ((297 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 9 * ((297 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((109 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49965161 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((297 : ℝ) / 100)) ^ 2 ≤ ((97934601 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((297 : ℝ) / 100)) 9]
    have hx : RB |10 * ((297 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((577 : ℝ) / 4000) ((363 : ℝ) / 2500) := by
      have hz : ((-363 : ℝ) / 2500) ≤ 10 * ((297 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 10 * ((297 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((-577 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((97934601 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((297 : ℝ) / 100)) ^ 2 ≤ ((90378407 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((297 : ℝ) / 100)) 10]
    have hx : RB |11 * ((297 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((1263 : ℝ) / 4000) ((198 : ℝ) / 625) := by
      have hz : ((-198 : ℝ) / 625) ≤ 11 * ((297 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 11 * ((297 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((-1263 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((90378407 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((297 : ℝ) / 100)) ^ 2 ≤ ((78191079 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((297 : ℝ) / 100)) 11]
    have hx : RB |12 * ((297 : ℝ) / 100) - ((23 : ℝ) / 2) * π| ((1949 : ℝ) / 4000) ((1221 : ℝ) / 2500) := by
      have hz : ((-1221 : ℝ) / 2500) ≤ 12 * ((297 : ℝ) / 100) - ((23 : ℝ) / 2) * π ∧ 12 * ((297 : ℝ) / 100) - ((23 : ℝ) / 2) * π ≤ ((-1949 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((78191079 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((297 : ℝ) / 100) n) ≤ ((211141 : ℝ) / 25000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((5613843 : ℝ) / 100000000) ≤ Real.log (π / ((297 : ℝ) / 100)) := by
    apply cov_log_2629.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((297 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_19 : ((4977811 : ℝ) / 100000000) ≤ hfun ((74 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((74 : ℝ) / 25)) ^ 2 ≤ ((1630917 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((74 : ℝ) / 25)) 1]
    have hx : RB |1 * ((74 : ℝ) / 25) - (1 : ℝ) * π| ((363 : ℝ) / 2000) ((227 : ℝ) / 1250) := by
      have hz : ((-227 : ℝ) / 1250) ≤ 1 * ((74 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((74 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-363 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1630917 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((74 : ℝ) / 25)) ^ 2 ≤ ((12623183 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((74 : ℝ) / 25)) 2]
    have hx : RB |2 * ((74 : ℝ) / 25) - (2 : ℝ) * π| ((363 : ℝ) / 1000) ((227 : ℝ) / 625) := by
      have hz : ((-227 : ℝ) / 625) ≤ 2 * ((74 : ℝ) / 25) - (2 : ℝ) * π ∧ 2 * ((74 : ℝ) / 25) - (2 : ℝ) * π ≤ ((-363 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12623183 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((74 : ℝ) / 25)) ^ 2 ≤ ((13435599 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (3 * ((74 : ℝ) / 25)) 3]
    have hx : RB |3 * ((74 : ℝ) / 25) - (3 : ℝ) * π| ((1089 : ℝ) / 2000) ((681 : ℝ) / 1250) := by
      have hz : ((-681 : ℝ) / 1250) ≤ 3 * ((74 : ℝ) / 25) - (3 : ℝ) * π ∧ 3 * ((74 : ℝ) / 25) - (3 : ℝ) * π ≤ ((-1089 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13435599 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((74 : ℝ) / 25)) ^ 2 ≤ ((22087733 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((74 : ℝ) / 25)) 4]
    have hx : RB |4 * ((74 : ℝ) / 25) - (4 : ℝ) * π| ((363 : ℝ) / 500) ((454 : ℝ) / 625) := by
      have hz : ((-454 : ℝ) / 625) ≤ 4 * ((74 : ℝ) / 25) - (4 : ℝ) * π ∧ 4 * ((74 : ℝ) / 25) - (4 : ℝ) * π ≤ ((-363 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22087733 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((74 : ℝ) / 25)) ^ 2 ≤ ((31238731 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (5 * ((74 : ℝ) / 25)) 4]
    have hx : RB |5 * ((74 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((1657 : ℝ) / 2500) ((2653 : ℝ) / 4000) := by
      have hz : ((1657 : ℝ) / 2500) ≤ 5 * ((74 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 5 * ((74 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((2653 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((31238731 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((74 : ℝ) / 25)) ^ 2 ≤ ((39340989 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (6 * ((74 : ℝ) / 25)) 5]
    have hx : RB |6 * ((74 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((1203 : ℝ) / 2500) ((1927 : ℝ) / 4000) := by
      have hz : ((1203 : ℝ) / 2500) ≤ 6 * ((74 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 6 * ((74 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((1927 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((39340989 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((74 : ℝ) / 25)) ^ 2 ≤ ((45653141 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (7 * ((74 : ℝ) / 25)) 6]
    have hx : RB |7 * ((74 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((749 : ℝ) / 2500) ((1201 : ℝ) / 4000) := by
      have hz : ((749 : ℝ) / 2500) ≤ 7 * ((74 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 7 * ((74 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((1201 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45653141 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((74 : ℝ) / 25)) ^ 2 ≤ ((12326813 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (8 * ((74 : ℝ) / 25)) 7]
    have hx : RB |8 * ((74 : ℝ) / 25) - ((15 : ℝ) / 2) * π| ((59 : ℝ) / 500) ((19 : ℝ) / 160) := by
      have hz : ((59 : ℝ) / 500) ≤ 8 * ((74 : ℝ) / 25) - ((15 : ℝ) / 2) * π ∧ 8 * ((74 : ℝ) / 25) - ((15 : ℝ) / 2) * π ≤ ((19 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12326813 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((74 : ℝ) / 25)) ^ 2 ≤ ((49803401 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (9 * ((74 : ℝ) / 25)) 8]
    have hx : RB |9 * ((74 : ℝ) / 25) - ((17 : ℝ) / 2) * π| ((251 : ℝ) / 4000) ((159 : ℝ) / 2500) := by
      have hz : ((-159 : ℝ) / 2500) ≤ 9 * ((74 : ℝ) / 25) - ((17 : ℝ) / 2) * π ∧ 9 * ((74 : ℝ) / 25) - ((17 : ℝ) / 2) * π ≤ ((-251 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49803401 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((74 : ℝ) / 25)) ^ 2 ≤ ((47079853 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((74 : ℝ) / 25)) 9]
    have hx : RB |10 * ((74 : ℝ) / 25) - ((19 : ℝ) / 2) * π| ((977 : ℝ) / 4000) ((613 : ℝ) / 2500) := by
      have hz : ((-613 : ℝ) / 2500) ≤ 10 * ((74 : ℝ) / 25) - ((19 : ℝ) / 2) * π ∧ 10 * ((74 : ℝ) / 25) - ((19 : ℝ) / 2) * π ≤ ((-977 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47079853 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((74 : ℝ) / 25)) ^ 2 ≤ ((20752429 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (11 * ((74 : ℝ) / 25)) 10]
    have hx : RB |11 * ((74 : ℝ) / 25) - ((21 : ℝ) / 2) * π| ((1703 : ℝ) / 4000) ((1067 : ℝ) / 2500) := by
      have hz : ((-1067 : ℝ) / 2500) ≤ 11 * ((74 : ℝ) / 25) - ((21 : ℝ) / 2) * π ∧ 11 * ((74 : ℝ) / 25) - ((21 : ℝ) / 2) * π ≤ ((-1703 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((20752429 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((74 : ℝ) / 25)) ^ 2 ≤ ((33846679 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((74 : ℝ) / 25)) 11]
    have hx : RB |12 * ((74 : ℝ) / 25) - ((23 : ℝ) / 2) * π| ((2429 : ℝ) / 4000) ((1521 : ℝ) / 2500) := by
      have hz : ((-1521 : ℝ) / 2500) ≤ 12 * ((74 : ℝ) / 25) - ((23 : ℝ) / 2) * π ∧ 12 * ((74 : ℝ) / 25) - ((23 : ℝ) / 2) * π ≤ ((-2429 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((33846679 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((74 : ℝ) / 25) n) ≤ ((933669 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((5951111 : ℝ) / 100000000) ≤ Real.log (π / ((74 : ℝ) / 25)) := by
    apply cov_log_2630.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((74 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_17 : ((12923203 : ℝ) / 50000000) ≤ hfun ((33 : ℝ) / 20) := by
  have s1 : Real.sin (1 * ((33 : ℝ) / 20)) ^ 2 ≤ ((9937413 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (1 * ((33 : ℝ) / 20)) 0]
    have hx : RB |1 * ((33 : ℝ) / 20) - ((1 : ℝ) / 2) * π| ((99 : ℝ) / 1250) ((317 : ℝ) / 4000) := by
      have hz : ((99 : ℝ) / 1250) ≤ 1 * ((33 : ℝ) / 20) - ((1 : ℝ) / 2) * π ∧ 1 * ((33 : ℝ) / 20) - ((1 : ℝ) / 2) * π ≤ ((317 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9937413 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((33 : ℝ) / 20)) ^ 2 ≤ ((2491303 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((33 : ℝ) / 20)) 1]
    have hx : RB |2 * ((33 : ℝ) / 20) - (1 : ℝ) * π| ((99 : ℝ) / 625) ((317 : ℝ) / 2000) := by
      have hz : ((99 : ℝ) / 625) ≤ 2 * ((33 : ℝ) / 20) - (1 : ℝ) * π ∧ 2 * ((33 : ℝ) / 20) - (1 : ℝ) * π ≤ ((317 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2491303 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((33 : ℝ) / 20)) ^ 2 ≤ ((47233323 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((33 : ℝ) / 20)) 1]
    have hx : RB |3 * ((33 : ℝ) / 20) - ((3 : ℝ) / 2) * π| ((297 : ℝ) / 1250) ((951 : ℝ) / 4000) := by
      have hz : ((297 : ℝ) / 1250) ≤ 3 * ((33 : ℝ) / 20) - ((3 : ℝ) / 2) * π ∧ 3 * ((33 : ℝ) / 20) - ((3 : ℝ) / 2) * π ≤ ((951 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47233323 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((33 : ℝ) / 20)) ^ 2 ≤ ((485887 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (4 * ((33 : ℝ) / 20)) 2]
    have hx : RB |4 * ((33 : ℝ) / 20) - (2 : ℝ) * π| ((198 : ℝ) / 625) ((317 : ℝ) / 1000) := by
      have hz : ((198 : ℝ) / 625) ≤ 4 * ((33 : ℝ) / 20) - (2 : ℝ) * π ∧ 4 * ((33 : ℝ) / 20) - (2 : ℝ) * π ≤ ((317 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((485887 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((33 : ℝ) / 20)) ^ 2 ≤ ((42585009 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (5 * ((33 : ℝ) / 20)) 2]
    have hx : RB |5 * ((33 : ℝ) / 20) - ((5 : ℝ) / 2) * π| ((99 : ℝ) / 250) ((317 : ℝ) / 800) := by
      have hz : ((99 : ℝ) / 250) ≤ 5 * ((33 : ℝ) / 20) - ((5 : ℝ) / 2) * π ∧ 5 * ((33 : ℝ) / 20) - ((5 : ℝ) / 2) * π ≤ ((317 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42585009 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((33 : ℝ) / 20)) ^ 2 ≤ ((5240861 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((33 : ℝ) / 20)) 3]
    have hx : RB |6 * ((33 : ℝ) / 20) - (3 : ℝ) * π| ((297 : ℝ) / 625) ((951 : ℝ) / 2000) := by
      have hz : ((297 : ℝ) / 625) ≤ 6 * ((33 : ℝ) / 20) - (3 : ℝ) * π ∧ 6 * ((33 : ℝ) / 20) - (3 : ℝ) * π ≤ ((951 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5240861 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((33 : ℝ) / 20)) ^ 2 ≤ ((72463177 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((33 : ℝ) / 20)) 3]
    have hx : RB |7 * ((33 : ℝ) / 20) - ((7 : ℝ) / 2) * π| ((693 : ℝ) / 1250) ((2219 : ℝ) / 4000) := by
      have hz : ((693 : ℝ) / 1250) ≤ 7 * ((33 : ℝ) / 20) - ((7 : ℝ) / 2) * π ∧ 7 * ((33 : ℝ) / 20) - ((7 : ℝ) / 2) * π ≤ ((2219 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((72463177 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((33 : ℝ) / 20)) ^ 2 ≤ ((3512119 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (8 * ((33 : ℝ) / 20)) 4]
    have hx : RB |8 * ((33 : ℝ) / 20) - (4 : ℝ) * π| ((396 : ℝ) / 625) ((317 : ℝ) / 500) := by
      have hz : ((396 : ℝ) / 625) ≤ 8 * ((33 : ℝ) / 20) - (4 : ℝ) * π ∧ 8 * ((33 : ℝ) / 20) - (4 : ℝ) * π ≤ ((317 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3512119 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((33 : ℝ) / 20)) ^ 2 ≤ ((57674507 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((33 : ℝ) / 20)) 4]
    have hx : RB |9 * ((33 : ℝ) / 20) - ((9 : ℝ) / 2) * π| ((891 : ℝ) / 1250) ((2853 : ℝ) / 4000) := by
      have hz : ((891 : ℝ) / 1250) ≤ 9 * ((33 : ℝ) / 20) - ((9 : ℝ) / 2) * π ∧ 9 * ((33 : ℝ) / 20) - ((9 : ℝ) / 2) * π ≤ ((2853 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((57674507 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((33 : ℝ) / 20)) ^ 2 ≤ ((6413997 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (10 * ((33 : ℝ) / 20)) 5]
    have hx : RB |10 * ((33 : ℝ) / 20) - ((11 : ℝ) / 2) * π| ((3113 : ℝ) / 4000) ((1947 : ℝ) / 2500) := by
      have hz : ((-1947 : ℝ) / 2500) ≤ 10 * ((33 : ℝ) / 20) - ((11 : ℝ) / 2) * π ∧ 10 * ((33 : ℝ) / 20) - ((11 : ℝ) / 2) * π ≤ ((-3113 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6413997 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((33 : ℝ) / 20)) ^ 2 ≤ ((20759597 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (11 * ((33 : ℝ) / 20)) 6]
    have hx : RB |11 * ((33 : ℝ) / 20) - (6 : ℝ) * π| ((699 : ℝ) / 1000) ((1749 : ℝ) / 2500) := by
      have hz : ((-1749 : ℝ) / 2500) ≤ 11 * ((33 : ℝ) / 20) - (6 : ℝ) * π ∧ 11 * ((33 : ℝ) / 20) - (6 : ℝ) * π ≤ ((-699 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((20759597 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((33 : ℝ) / 20)) ^ 2 ≤ ((13306379 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (12 * ((33 : ℝ) / 20)) 6]
    have hx : RB |12 * ((33 : ℝ) / 20) - ((13 : ℝ) / 2) * π| ((2479 : ℝ) / 4000) ((1551 : ℝ) / 2500) := by
      have hz : ((-1551 : ℝ) / 2500) ≤ 12 * ((33 : ℝ) / 20) - ((13 : ℝ) / 2) * π ∧ 12 * ((33 : ℝ) / 20) - ((13 : ℝ) / 2) * π ≤ ((-2479 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13306379 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((33 : ℝ) / 20) n) ≤ ((7683713 : ℝ) / 20000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((6439251 : ℝ) / 10000000) ≤ Real.log (π / ((33 : ℝ) / 20)) := by
    apply cov_log_2631.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((33 : ℝ) / 20)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_20 : ((5223711 : ℝ) / 100000000) ≤ hfun ((59 : ℝ) / 20) := by
  have s1 : Real.sin (1 * ((59 : ℝ) / 20)) ^ 2 ≤ ((90661 : ℝ) / 2500000) := by
    rw [sin_sq_shift_pi (1 * ((59 : ℝ) / 20)) 1]
    have hx : RB |1 * ((59 : ℝ) / 20) - (1 : ℝ) * π| ((383 : ℝ) / 2000) ((479 : ℝ) / 2500) := by
      have hz : ((-479 : ℝ) / 2500) ≤ 1 * ((59 : ℝ) / 20) - (1 : ℝ) * π ∧ 1 * ((59 : ℝ) / 20) - (1 : ℝ) * π ≤ ((-383 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((90661 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((59 : ℝ) / 20)) ^ 2 ≤ ((13981541 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((59 : ℝ) / 20)) 2]
    have hx : RB |2 * ((59 : ℝ) / 20) - (2 : ℝ) * π| ((383 : ℝ) / 1000) ((479 : ℝ) / 1250) := by
      have hz : ((-479 : ℝ) / 1250) ≤ 2 * ((59 : ℝ) / 20) - (2 : ℝ) * π ∧ 2 * ((59 : ℝ) / 20) - (2 : ℝ) * π ≤ ((-383 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13981541 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((59 : ℝ) / 20)) ^ 2 ≤ ((29574579 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((59 : ℝ) / 20)) 3]
    have hx : RB |3 * ((59 : ℝ) / 20) - (3 : ℝ) * π| ((1149 : ℝ) / 2000) ((1437 : ℝ) / 2500) := by
      have hz : ((-1437 : ℝ) / 2500) ≤ 3 * ((59 : ℝ) / 20) - (3 : ℝ) * π ∧ 3 * ((59 : ℝ) / 20) - (3 : ℝ) * π ≤ ((-1149 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((29574579 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((59 : ℝ) / 20)) ^ 2 ≤ ((48182329 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((59 : ℝ) / 20)) 4]
    have hx : RB |4 * ((59 : ℝ) / 20) - (4 : ℝ) * π| ((383 : ℝ) / 500) ((479 : ℝ) / 625) := by
      have hz : ((-479 : ℝ) / 625) ≤ 4 * ((59 : ℝ) / 20) - (4 : ℝ) * π ∧ 4 * ((59 : ℝ) / 20) - (4 : ℝ) * π ≤ ((-383 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((48182329 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((59 : ℝ) / 20)) ^ 2 ≤ ((67175133 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((59 : ℝ) / 20)) 4]
    have hx : RB |5 * ((59 : ℝ) / 20) - ((9 : ℝ) / 2) * π| ((383 : ℝ) / 625) ((2453 : ℝ) / 4000) := by
      have hz : ((383 : ℝ) / 625) ≤ 5 * ((59 : ℝ) / 20) - ((9 : ℝ) / 2) * π ∧ 5 * ((59 : ℝ) / 20) - ((9 : ℝ) / 2) * π ≤ ((2453 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((67175133 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((59 : ℝ) / 20)) ^ 2 ≤ ((83346517 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((59 : ℝ) / 20)) 5]
    have hx : RB |6 * ((59 : ℝ) / 20) - ((11 : ℝ) / 2) * π| ((1053 : ℝ) / 2500) ((1687 : ℝ) / 4000) := by
      have hz : ((1053 : ℝ) / 2500) ≤ 6 * ((59 : ℝ) / 20) - ((11 : ℝ) / 2) * π ∧ 6 * ((59 : ℝ) / 20) - ((11 : ℝ) / 2) * π ≤ ((1687 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((83346517 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((59 : ℝ) / 20)) ^ 2 ≤ ((94826367 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((59 : ℝ) / 20)) 6]
    have hx : RB |7 * ((59 : ℝ) / 20) - ((13 : ℝ) / 2) * π| ((287 : ℝ) / 1250) ((921 : ℝ) / 4000) := by
      have hz : ((287 : ℝ) / 1250) ≤ 7 * ((59 : ℝ) / 20) - ((13 : ℝ) / 2) * π ∧ 7 * ((59 : ℝ) / 20) - ((13 : ℝ) / 2) * π ≤ ((921 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94826367 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((59 : ℝ) / 20)) ^ 2 ≤ ((24963919 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (8 * ((59 : ℝ) / 20)) 7]
    have hx : RB |8 * ((59 : ℝ) / 20) - ((15 : ℝ) / 2) * π| ((19 : ℝ) / 500) ((31 : ℝ) / 800) := by
      have hz : ((19 : ℝ) / 500) ≤ 8 * ((59 : ℝ) / 20) - ((15 : ℝ) / 2) * π ∧ 8 * ((59 : ℝ) / 20) - ((15 : ℝ) / 2) * π ≤ ((31 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24963919 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((59 : ℝ) / 20)) ^ 2 ≤ ((19537217 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (9 * ((59 : ℝ) / 20)) 8]
    have hx : RB |9 * ((59 : ℝ) / 20) - ((17 : ℝ) / 2) * π| ((611 : ℝ) / 4000) ((96 : ℝ) / 625) := by
      have hz : ((-96 : ℝ) / 625) ≤ 9 * ((59 : ℝ) / 20) - ((17 : ℝ) / 2) * π ∧ 9 * ((59 : ℝ) / 20) - ((17 : ℝ) / 2) * π ≤ ((-611 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19537217 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((59 : ℝ) / 20)) ^ 2 ≤ ((88639503 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((59 : ℝ) / 20)) 9]
    have hx : RB |10 * ((59 : ℝ) / 20) - ((19 : ℝ) / 2) * π| ((1377 : ℝ) / 4000) ((863 : ℝ) / 2500) := by
      have hz : ((-863 : ℝ) / 2500) ≤ 10 * ((59 : ℝ) / 20) - ((19 : ℝ) / 2) * π ∧ 10 * ((59 : ℝ) / 20) - ((19 : ℝ) / 2) * π ≤ ((-1377 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((88639503 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((59 : ℝ) / 20)) ^ 2 ≤ ((74099489 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((59 : ℝ) / 20)) 10]
    have hx : RB |11 * ((59 : ℝ) / 20) - ((21 : ℝ) / 2) * π| ((2143 : ℝ) / 4000) ((671 : ℝ) / 1250) := by
      have hz : ((-671 : ℝ) / 1250) ≤ 11 * ((59 : ℝ) / 20) - ((21 : ℝ) / 2) * π ∧ 11 * ((59 : ℝ) / 20) - ((21 : ℝ) / 2) * π ≤ ((-2143 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((74099489 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((59 : ℝ) / 20)) ^ 2 ≤ ((56282289 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((59 : ℝ) / 20)) 11]
    have hx : RB |12 * ((59 : ℝ) / 20) - ((23 : ℝ) / 2) * π| ((2909 : ℝ) / 4000) ((1821 : ℝ) / 2500) := by
      have hz : ((-1821 : ℝ) / 2500) ≤ 12 * ((59 : ℝ) / 20) - ((23 : ℝ) / 2) * π ∧ 12 * ((59 : ℝ) / 20) - ((23 : ℝ) / 2) * π ≤ ((-2909 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((56282289 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((59 : ℝ) / 20) n) ≤ ((102591 : ℝ) / 10000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((6289521 : ℝ) / 100000000) ≤ Real.log (π / ((59 : ℝ) / 20)) := by
    apply cov_log_2632.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((59 : ℝ) / 20)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_22 : ((5466923 : ℝ) / 100000000) ≤ hfun ((147 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((147 : ℝ) / 50)) ^ 2 ≤ ((4009597 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((147 : ℝ) / 50)) 1]
    have hx : RB |1 * ((147 : ℝ) / 50) - (1 : ℝ) * π| ((403 : ℝ) / 2000) ((126 : ℝ) / 625) := by
      have hz : ((-126 : ℝ) / 625) ≤ 1 * ((147 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((147 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-403 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4009597 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((147 : ℝ) / 50)) ^ 2 ≤ ((15397627 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((147 : ℝ) / 50)) 2]
    have hx : RB |2 * ((147 : ℝ) / 50) - (2 : ℝ) * π| ((403 : ℝ) / 1000) ((252 : ℝ) / 625) := by
      have hz : ((-252 : ℝ) / 625) ≤ 2 * ((147 : ℝ) / 50) - (2 : ℝ) * π ∧ 2 * ((147 : ℝ) / 50) - (2 : ℝ) * π ≤ ((-403 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15397627 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((147 : ℝ) / 50)) ^ 2 ≤ ((32352561 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((147 : ℝ) / 50)) 3]
    have hx : RB |3 * ((147 : ℝ) / 50) - (3 : ℝ) * π| ((1209 : ℝ) / 2000) ((378 : ℝ) / 625) := by
      have hz : ((-378 : ℝ) / 625) ≤ 3 * ((147 : ℝ) / 50) - (3 : ℝ) * π ∧ 3 * ((147 : ℝ) / 50) - (3 : ℝ) * π ≤ ((-1209 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((32352561 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((147 : ℝ) / 50)) ^ 2 ≤ ((52658381 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((147 : ℝ) / 50)) 3]
    have hx : RB |4 * ((147 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((1911 : ℝ) / 2500) ((3059 : ℝ) / 4000) := by
      have hz : ((1911 : ℝ) / 2500) ≤ 4 * ((147 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 4 * ((147 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((3059 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((52658381 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((147 : ℝ) / 50)) ^ 2 ≤ ((71718907 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((147 : ℝ) / 50)) 4]
    have hx : RB |5 * ((147 : ℝ) / 50) - ((9 : ℝ) / 2) * π| ((1407 : ℝ) / 2500) ((2253 : ℝ) / 4000) := by
      have hz : ((1407 : ℝ) / 2500) ≤ 5 * ((147 : ℝ) / 50) - ((9 : ℝ) / 2) * π ∧ 5 * ((147 : ℝ) / 50) - ((9 : ℝ) / 2) * π ≤ ((2253 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((71718907 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((147 : ℝ) / 50)) ^ 2 ≤ ((87545817 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((147 : ℝ) / 50)) 5]
    have hx : RB |6 * ((147 : ℝ) / 50) - ((11 : ℝ) / 2) * π| ((903 : ℝ) / 2500) ((1447 : ℝ) / 4000) := by
      have hz : ((903 : ℝ) / 2500) ≤ 6 * ((147 : ℝ) / 50) - ((11 : ℝ) / 2) * π ∧ 6 * ((147 : ℝ) / 50) - ((11 : ℝ) / 2) * π ≤ ((1447 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((87545817 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((147 : ℝ) / 50)) ^ 2 ≤ ((97475787 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((147 : ℝ) / 50)) 6]
    have hx : RB |7 * ((147 : ℝ) / 50) - ((13 : ℝ) / 2) * π| ((399 : ℝ) / 2500) ((641 : ℝ) / 4000) := by
      have hz : ((399 : ℝ) / 2500) ≤ 7 * ((147 : ℝ) / 50) - ((13 : ℝ) / 2) * π ∧ 7 * ((147 : ℝ) / 50) - ((13 : ℝ) / 2) * π ≤ ((641 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((97475787 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((147 : ℝ) / 50)) ^ 2 ≤ ((99829949 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((147 : ℝ) / 50)) 7]
    have hx : RB |8 * ((147 : ℝ) / 50) - ((15 : ℝ) / 2) * π| ((33 : ℝ) / 800) ((21 : ℝ) / 500) := by
      have hz : ((-21 : ℝ) / 500) ≤ 8 * ((147 : ℝ) / 50) - ((15 : ℝ) / 2) * π ∧ 8 * ((147 : ℝ) / 50) - ((15 : ℝ) / 2) * π ≤ ((-33 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99829949 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((147 : ℝ) / 50)) ^ 2 ≤ ((94229659 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((147 : ℝ) / 50)) 8]
    have hx : RB |9 * ((147 : ℝ) / 50) - ((17 : ℝ) / 2) * π| ((971 : ℝ) / 4000) ((609 : ℝ) / 2500) := by
      have hz : ((-609 : ℝ) / 2500) ≤ 9 * ((147 : ℝ) / 50) - ((17 : ℝ) / 2) * π ∧ 9 * ((147 : ℝ) / 50) - ((17 : ℝ) / 2) * π ≤ ((-971 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94229659 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((147 : ℝ) / 50)) ^ 2 ≤ ((102009 : ℝ) / 125000) := by
    rw [sin_sq_shift_half_pi (10 * ((147 : ℝ) / 50)) 9]
    have hx : RB |10 * ((147 : ℝ) / 50) - ((19 : ℝ) / 2) * π| ((1777 : ℝ) / 4000) ((1113 : ℝ) / 2500) := by
      have hz : ((-1113 : ℝ) / 2500) ≤ 10 * ((147 : ℝ) / 50) - ((19 : ℝ) / 2) * π ∧ 10 * ((147 : ℝ) / 50) - ((19 : ℝ) / 2) * π ≤ ((-1777 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((102009 : ℝ) / 125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((147 : ℝ) / 50)) ^ 2 ≤ ((16024767 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (11 * ((147 : ℝ) / 50)) 10]
    have hx : RB |11 * ((147 : ℝ) / 50) - ((21 : ℝ) / 2) * π| ((2583 : ℝ) / 4000) ((1617 : ℝ) / 2500) := by
      have hz : ((-1617 : ℝ) / 2500) ≤ 11 * ((147 : ℝ) / 50) - ((21 : ℝ) / 2) * π ∧ 11 * ((147 : ℝ) / 50) - ((21 : ℝ) / 2) * π ≤ ((-2583 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16024767 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((147 : ℝ) / 50)) ^ 2 ≤ ((5488817 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (12 * ((147 : ℝ) / 50)) 11]
    have hx : RB |12 * ((147 : ℝ) / 50) - (11 : ℝ) * π| ((903 : ℝ) / 1250) ((1447 : ℝ) / 2000) := by
      have hz : ((903 : ℝ) / 1250) ≤ 12 * ((147 : ℝ) / 50) - (11 : ℝ) * π ∧ 12 * ((147 : ℝ) / 50) - (11 : ℝ) * π ≤ ((1447 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5488817 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((147 : ℝ) / 50) n) ≤ ((224397 : ℝ) / 20000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((165727 : ℝ) / 2500000) ≤ Real.log (π / ((147 : ℝ) / 50)) := by
    apply cov_log_2633.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((147 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_23 : ((5709281 : ℝ) / 100000000) ≤ hfun ((293 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((293 : ℝ) / 100)) ^ 2 ≤ ((4411153 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((293 : ℝ) / 100)) 1]
    have hx : RB |1 * ((293 : ℝ) / 100) - (1 : ℝ) * π| ((423 : ℝ) / 2000) ((529 : ℝ) / 2500) := by
      have hz : ((-529 : ℝ) / 2500) ≤ 1 * ((293 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((293 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-423 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4411153 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((293 : ℝ) / 100)) ^ 2 ≤ ((3373839 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (2 * ((293 : ℝ) / 100)) 2]
    have hx : RB |2 * ((293 : ℝ) / 100) - (2 : ℝ) * π| ((423 : ℝ) / 1000) ((529 : ℝ) / 1250) := by
      have hz : ((-529 : ℝ) / 1250) ≤ 2 * ((293 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((293 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-423 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3373839 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((293 : ℝ) / 100)) ^ 2 ≤ ((2199711 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (3 * ((293 : ℝ) / 100)) 3]
    have hx : RB |3 * ((293 : ℝ) / 100) - (3 : ℝ) * π| ((1269 : ℝ) / 2000) ((1587 : ℝ) / 2500) := by
      have hz : ((-1587 : ℝ) / 2500) ≤ 3 * ((293 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((293 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-1269 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2199711 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((293 : ℝ) / 100)) ^ 2 ≤ ((2827461 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (4 * ((293 : ℝ) / 100)) 3]
    have hx : RB |4 * ((293 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((1811 : ℝ) / 2500) ((2899 : ℝ) / 4000) := by
      have hz : ((1811 : ℝ) / 2500) ≤ 4 * ((293 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((293 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((2899 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2827461 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((293 : ℝ) / 100)) ^ 2 ≤ ((3042459 : ℝ) / 4000000) := by
    rw [sin_sq_shift_half_pi (5 * ((293 : ℝ) / 100)) 4]
    have hx : RB |5 * ((293 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((641 : ℝ) / 1250) ((2053 : ℝ) / 4000) := by
      have hz : ((641 : ℝ) / 1250) ≤ 5 * ((293 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((293 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((2053 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3042459 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((293 : ℝ) / 100)) ^ 2 ≤ ((45608039 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (6 * ((293 : ℝ) / 100)) 5]
    have hx : RB |6 * ((293 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((753 : ℝ) / 2500) ((1207 : ℝ) / 4000) := by
      have hz : ((753 : ℝ) / 2500) ≤ 6 * ((293 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((293 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((1207 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45608039 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((293 : ℝ) / 100)) ^ 2 ≤ ((24799871 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (7 * ((293 : ℝ) / 100)) 6]
    have hx : RB |7 * ((293 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((56 : ℝ) / 625) ((361 : ℝ) / 4000) := by
      have hz : ((56 : ℝ) / 625) ≤ 7 * ((293 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((293 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((361 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24799871 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((293 : ℝ) / 100)) ^ 2 ≤ ((49268769 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((293 : ℝ) / 100)) 7]
    have hx : RB |8 * ((293 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((97 : ℝ) / 800) ((61 : ℝ) / 500) := by
      have hz : ((-61 : ℝ) / 500) ≤ 8 * ((293 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((293 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((-97 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49268769 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((293 : ℝ) / 100)) ^ 2 ≤ ((5584759 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (9 * ((293 : ℝ) / 100)) 8]
    have hx : RB |9 * ((293 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((1331 : ℝ) / 4000) ((417 : ℝ) / 1250) := by
      have hz : ((-417 : ℝ) / 1250) ≤ 9 * ((293 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 9 * ((293 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-1331 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5584759 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((293 : ℝ) / 100)) ^ 2 ≤ ((73358833 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((293 : ℝ) / 100)) 9]
    have hx : RB |10 * ((293 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((2177 : ℝ) / 4000) ((1363 : ℝ) / 2500) := by
      have hz : ((-1363 : ℝ) / 2500) ≤ 10 * ((293 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 10 * ((293 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((-2177 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((73358833 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((293 : ℝ) / 100)) ^ 2 ≤ ((26755073 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (11 * ((293 : ℝ) / 100)) 10]
    have hx : RB |11 * ((293 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((3023 : ℝ) / 4000) ((473 : ℝ) / 625) := by
      have hz : ((-473 : ℝ) / 625) ≤ 11 * ((293 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 11 * ((293 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((-3023 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((26755073 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((293 : ℝ) / 100)) ^ 2 ≤ ((32247273 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((293 : ℝ) / 100)) 11]
    have hx : RB |12 * ((293 : ℝ) / 100) - (11 : ℝ) * π| ((753 : ℝ) / 1250) ((1207 : ℝ) / 2000) := by
      have hz : ((753 : ℝ) / 1250) ≤ 12 * ((293 : ℝ) / 100) - (11 : ℝ) * π ∧ 12 * ((293 : ℝ) / 100) - (11 : ℝ) * π ≤ ((1207 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((32247273 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((293 : ℝ) / 100) n) ≤ ((1220069 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1742449 : ℝ) / 25000000) ≤ Real.log (π / ((293 : ℝ) / 100)) := by
    apply cov_log_2634.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((293 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_21 : ((5149293 : ℝ) / 20000000) ≤ hfun ((83 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((83 : ℝ) / 50)) ^ 2 ≤ ((49603289 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (1 * ((83 : ℝ) / 50)) 0]
    have hx : RB |1 * ((83 : ℝ) / 50) - ((1 : ℝ) / 2) * π| ((223 : ℝ) / 2500) ((357 : ℝ) / 4000) := by
      have hz : ((223 : ℝ) / 2500) ≤ 1 * ((83 : ℝ) / 50) - ((1 : ℝ) / 2) * π ∧ 1 * ((83 : ℝ) / 50) - ((1 : ℝ) / 2) * π ≤ ((357 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49603289 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((83 : ℝ) / 50)) ^ 2 ≤ ((788149 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (2 * ((83 : ℝ) / 50)) 1]
    have hx : RB |2 * ((83 : ℝ) / 50) - (1 : ℝ) * π| ((223 : ℝ) / 1250) ((357 : ℝ) / 2000) := by
      have hz : ((223 : ℝ) / 1250) ≤ 2 * ((83 : ℝ) / 50) - (1 : ℝ) * π ∧ 2 * ((83 : ℝ) / 50) - (1 : ℝ) * π ≤ ((357 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((788149 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((83 : ℝ) / 50)) ^ 2 ≤ ((1860377 : ℝ) / 2000000) := by
    rw [sin_sq_shift_half_pi (3 * ((83 : ℝ) / 50)) 1]
    have hx : RB |3 * ((83 : ℝ) / 50) - ((3 : ℝ) / 2) * π| ((669 : ℝ) / 2500) ((1071 : ℝ) / 4000) := by
      have hz : ((669 : ℝ) / 2500) ≤ 3 * ((83 : ℝ) / 50) - ((3 : ℝ) / 2) * π ∧ 3 * ((83 : ℝ) / 50) - ((3 : ℝ) / 2) * π ≤ ((1071 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1860377 : ℝ) / 2000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((83 : ℝ) / 50)) ^ 2 ≤ ((12214153 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((83 : ℝ) / 50)) 2]
    have hx : RB |4 * ((83 : ℝ) / 50) - (2 : ℝ) * π| ((223 : ℝ) / 625) ((357 : ℝ) / 1000) := by
      have hz : ((223 : ℝ) / 625) ≤ 4 * ((83 : ℝ) / 50) - (2 : ℝ) * π ∧ 4 * ((83 : ℝ) / 50) - (2 : ℝ) * π ≤ ((357 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12214153 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((83 : ℝ) / 50)) ^ 2 ≤ ((81470019 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((83 : ℝ) / 50)) 2]
    have hx : RB |5 * ((83 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((223 : ℝ) / 500) ((357 : ℝ) / 800) := by
      have hz : ((223 : ℝ) / 500) ≤ 5 * ((83 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 5 * ((83 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((357 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((81470019 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((83 : ℝ) / 50)) ^ 2 ≤ ((13024897 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (6 * ((83 : ℝ) / 50)) 3]
    have hx : RB |6 * ((83 : ℝ) / 50) - (3 : ℝ) * π| ((669 : ℝ) / 1250) ((1071 : ℝ) / 2000) := by
      have hz : ((669 : ℝ) / 1250) ≤ 6 * ((83 : ℝ) / 50) - (3 : ℝ) * π ∧ 6 * ((83 : ℝ) / 50) - (3 : ℝ) * π ≤ ((1071 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13024897 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((83 : ℝ) / 50)) ^ 2 ≤ ((16524099 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (7 * ((83 : ℝ) / 50)) 3]
    have hx : RB |7 * ((83 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((1561 : ℝ) / 2500) ((2499 : ℝ) / 4000) := by
      have hz : ((1561 : ℝ) / 2500) ≤ 7 * ((83 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 7 * ((83 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((2499 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16524099 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((83 : ℝ) / 50)) ^ 2 ≤ ((670949 : ℝ) / 1562500) := by
    rw [sin_sq_shift_pi (8 * ((83 : ℝ) / 50)) 4]
    have hx : RB |8 * ((83 : ℝ) / 50) - (4 : ℝ) * π| ((446 : ℝ) / 625) ((357 : ℝ) / 500) := by
      have hz : ((446 : ℝ) / 625) ≤ 8 * ((83 : ℝ) / 50) - (4 : ℝ) * π ∧ 8 * ((83 : ℝ) / 50) - (4 : ℝ) * π ≤ ((357 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((670949 : ℝ) / 1562500) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((83 : ℝ) / 50)) ^ 2 ≤ ((48347227 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((83 : ℝ) / 50)) 5]
    have hx : RB |9 * ((83 : ℝ) / 50) - (5 : ℝ) * π| ((307 : ℝ) / 400) ((96 : ℝ) / 125) := by
      have hz : ((-96 : ℝ) / 125) ≤ 9 * ((83 : ℝ) / 50) - (5 : ℝ) * π ∧ 9 * ((83 : ℝ) / 50) - (5 : ℝ) * π ≤ ((-307 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((48347227 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((83 : ℝ) / 50)) ^ 2 ≤ ((61003317 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((83 : ℝ) / 50)) 5]
    have hx : RB |10 * ((83 : ℝ) / 50) - ((11 : ℝ) / 2) * π| ((2713 : ℝ) / 4000) ((1697 : ℝ) / 2500) := by
      have hz : ((-1697 : ℝ) / 2500) ≤ 10 * ((83 : ℝ) / 50) - ((11 : ℝ) / 2) * π ∧ 10 * ((83 : ℝ) / 50) - ((11 : ℝ) / 2) * π ≤ ((-2713 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((61003317 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((83 : ℝ) / 50)) ^ 2 ≤ ((15471061 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (11 * ((83 : ℝ) / 50)) 6]
    have hx : RB |11 * ((83 : ℝ) / 50) - (6 : ℝ) * π| ((589 : ℝ) / 1000) ((737 : ℝ) / 1250) := by
      have hz : ((-737 : ℝ) / 1250) ≤ 11 * ((83 : ℝ) / 50) - (6 : ℝ) * π ∧ 11 * ((83 : ℝ) / 50) - (6 : ℝ) * π ≤ ((-589 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15471061 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((83 : ℝ) / 50)) ^ 2 ≤ ((38578503 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((83 : ℝ) / 50)) 6]
    have hx : RB |12 * ((83 : ℝ) / 50) - ((13 : ℝ) / 2) * π| ((1999 : ℝ) / 4000) ((1251 : ℝ) / 2500) := by
      have hz : ((-1251 : ℝ) / 2500) ≤ 12 * ((83 : ℝ) / 50) - ((13 : ℝ) / 2) * π ∧ 12 * ((83 : ℝ) / 50) - ((13 : ℝ) / 2) * π ≤ ((-1999 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((38578503 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((83 : ℝ) / 50) n) ≤ ((18957903 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((31894139 : ℝ) / 50000000) ≤ Real.log (π / ((83 : ℝ) / 50)) := by
    apply cov_log_2635.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((83 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_26 : ((1189969 : ℝ) / 20000000) ≤ hfun ((73 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((73 : ℝ) / 25)) ^ 2 ≤ ((2415473 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((73 : ℝ) / 25)) 1]
    have hx : RB |1 * ((73 : ℝ) / 25) - (1 : ℝ) * π| ((443 : ℝ) / 2000) ((277 : ℝ) / 1250) := by
      have hz : ((-277 : ℝ) / 1250) ≤ 1 * ((73 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((73 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-443 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2415473 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((73 : ℝ) / 25)) ^ 2 ≤ ((4598479 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (2 * ((73 : ℝ) / 25)) 2]
    have hx : RB |2 * ((73 : ℝ) / 25) - (2 : ℝ) * π| ((443 : ℝ) / 1000) ((277 : ℝ) / 625) := by
      have hz : ((-277 : ℝ) / 625) ≤ 2 * ((73 : ℝ) / 25) - (2 : ℝ) * π ∧ 2 * ((73 : ℝ) / 25) - (2 : ℝ) * π ≤ ((-443 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4598479 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((73 : ℝ) / 25)) ^ 2 ≤ ((38093059 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((73 : ℝ) / 25)) 3]
    have hx : RB |3 * ((73 : ℝ) / 25) - (3 : ℝ) * π| ((1329 : ℝ) / 2000) ((831 : ℝ) / 1250) := by
      have hz : ((-831 : ℝ) / 1250) ≤ 3 * ((73 : ℝ) / 25) - (3 : ℝ) * π ∧ 3 * ((73 : ℝ) / 25) - (3 : ℝ) * π ≤ ((-1329 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((38093059 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((73 : ℝ) / 25)) ^ 2 ≤ ((60411583 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((73 : ℝ) / 25)) 3]
    have hx : RB |4 * ((73 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((1711 : ℝ) / 2500) ((2739 : ℝ) / 4000) := by
      have hz : ((1711 : ℝ) / 2500) ≤ 4 * ((73 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 4 * ((73 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((2739 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((60411583 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((73 : ℝ) / 25)) ^ 2 ≤ ((2504919 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (5 * ((73 : ℝ) / 25)) 4]
    have hx : RB |5 * ((73 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((1157 : ℝ) / 2500) ((1853 : ℝ) / 4000) := by
      have hz : ((1157 : ℝ) / 2500) ≤ 5 * ((73 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 5 * ((73 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((1853 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2504919 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((73 : ℝ) / 25)) ^ 2 ≤ ((94301419 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((73 : ℝ) / 25)) 5]
    have hx : RB |6 * ((73 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((603 : ℝ) / 2500) ((967 : ℝ) / 4000) := by
      have hz : ((603 : ℝ) / 2500) ≤ 6 * ((73 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 6 * ((73 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((967 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94301419 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((73 : ℝ) / 25)) ^ 2 ≤ ((9996159 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (7 * ((73 : ℝ) / 25)) 6]
    have hx : RB |7 * ((73 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((49 : ℝ) / 2500) ((81 : ℝ) / 4000) := by
      have hz : ((49 : ℝ) / 2500) ≤ 7 * ((73 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 7 * ((73 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((81 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9996159 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((73 : ℝ) / 25)) ^ 2 ≤ ((96007847 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((73 : ℝ) / 25)) 7]
    have hx : RB |8 * ((73 : ℝ) / 25) - ((15 : ℝ) / 2) * π| ((161 : ℝ) / 800) ((101 : ℝ) / 500) := by
      have hz : ((-101 : ℝ) / 500) ≤ 8 * ((73 : ℝ) / 25) - ((15 : ℝ) / 2) * π ∧ 8 * ((73 : ℝ) / 25) - ((15 : ℝ) / 2) * π ≤ ((-161 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((96007847 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((73 : ℝ) / 25)) ^ 2 ≤ ((41616223 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (9 * ((73 : ℝ) / 25)) 8]
    have hx : RB |9 * ((73 : ℝ) / 25) - ((17 : ℝ) / 2) * π| ((1691 : ℝ) / 4000) ((1059 : ℝ) / 2500) := by
      have hz : ((-1059 : ℝ) / 2500) ≤ 9 * ((73 : ℝ) / 25) - ((17 : ℝ) / 2) * π ∧ 9 * ((73 : ℝ) / 25) - ((17 : ℝ) / 2) * π ≤ ((-1691 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((41616223 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((73 : ℝ) / 25)) ^ 2 ≤ ((16059919 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (10 * ((73 : ℝ) / 25)) 9]
    have hx : RB |10 * ((73 : ℝ) / 25) - ((19 : ℝ) / 2) * π| ((2577 : ℝ) / 4000) ((1613 : ℝ) / 2500) := by
      have hz : ((-1613 : ℝ) / 2500) ≤ 10 * ((73 : ℝ) / 25) - ((19 : ℝ) / 2) * π ∧ 10 * ((73 : ℝ) / 25) - ((19 : ℝ) / 2) * π ≤ ((-2577 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16059919 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((73 : ℝ) / 25)) ^ 2 ≤ ((4206681 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (11 * ((73 : ℝ) / 25)) 10]
    have hx : RB |11 * ((73 : ℝ) / 25) - (10 : ℝ) * π| ((88 : ℝ) / 125) ((141 : ℝ) / 200) := by
      have hz : ((88 : ℝ) / 125) ≤ 11 * ((73 : ℝ) / 25) - (10 : ℝ) * π ∧ 11 * ((73 : ℝ) / 25) - (10 : ℝ) * π ≤ ((141 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4206681 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((73 : ℝ) / 25)) ^ 2 ≤ ((21627557 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((73 : ℝ) / 25)) 11]
    have hx : RB |12 * ((73 : ℝ) / 25) - (11 : ℝ) * π| ((603 : ℝ) / 1250) ((967 : ℝ) / 2000) := by
      have hz : ((603 : ℝ) / 1250) ≤ 12 * ((73 : ℝ) / 25) - (11 : ℝ) * π ∧ 12 * ((73 : ℝ) / 25) - (11 : ℝ) * π ≤ ((967 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21627557 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((73 : ℝ) / 25) n) ≤ ((330277 : ℝ) / 25000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((7311677 : ℝ) / 100000000) ≤ Real.log (π / ((73 : ℝ) / 25)) := by
    apply cov_log_2636.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((73 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_27 : ((6188501 : ℝ) / 100000000) ≤ hfun ((291 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((291 : ℝ) / 100)) ^ 2 ≤ ((5268811 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((291 : ℝ) / 100)) 1]
    have hx : RB |1 * ((291 : ℝ) / 100) - (1 : ℝ) * π| ((463 : ℝ) / 2000) ((579 : ℝ) / 2500) := by
      have hz : ((-579 : ℝ) / 2500) ≤ 1 * ((291 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((291 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-463 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5268811 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((291 : ℝ) / 100)) ^ 2 ≤ ((19969377 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((291 : ℝ) / 100)) 2]
    have hx : RB |2 * ((291 : ℝ) / 100) - (2 : ℝ) * π| ((463 : ℝ) / 1000) ((579 : ℝ) / 1250) := by
      have hz : ((-579 : ℝ) / 1250) ≤ 2 * ((291 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((291 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-463 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19969377 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((291 : ℝ) / 100)) ^ 2 ≤ ((41035487 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((291 : ℝ) / 100)) 3]
    have hx : RB |3 * ((291 : ℝ) / 100) - (3 : ℝ) * π| ((1389 : ℝ) / 2000) ((1737 : ℝ) / 2500) := by
      have hz : ((-1737 : ℝ) / 2500) ≤ 3 * ((291 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((291 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-1389 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((41035487 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((291 : ℝ) / 100)) ^ 2 ≤ ((64220153 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((291 : ℝ) / 100)) 3]
    have hx : RB |4 * ((291 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((1611 : ℝ) / 2500) ((2579 : ℝ) / 4000) := by
      have hz : ((1611 : ℝ) / 2500) ≤ 4 * ((291 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((291 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((2579 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((64220153 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((291 : ℝ) / 100)) ^ 2 ≤ ((16792739 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (5 * ((291 : ℝ) / 100)) 4]
    have hx : RB |5 * ((291 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((258 : ℝ) / 625) ((1653 : ℝ) / 4000) := by
      have hz : ((258 : ℝ) / 625) ≤ 5 * ((291 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((291 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((1653 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16792739 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((291 : ℝ) / 100)) ^ 2 ≤ ((24188697 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (6 * ((291 : ℝ) / 100)) 5]
    have hx : RB |6 * ((291 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((453 : ℝ) / 2500) ((727 : ℝ) / 4000) := by
      have hz : ((453 : ℝ) / 2500) ≤ 6 * ((291 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((291 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((727 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24188697 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((291 : ℝ) / 100)) ^ 2 ≤ ((19950543 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (7 * ((291 : ℝ) / 100)) 6]
    have hx : RB |7 * ((291 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((199 : ℝ) / 4000) ((63 : ℝ) / 1250) := by
      have hz : ((-63 : ℝ) / 1250) ≤ 7 * ((291 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((291 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-199 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19950543 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((291 : ℝ) / 100)) ^ 2 ≤ ((5769347 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (8 * ((291 : ℝ) / 100)) 7]
    have hx : RB |8 * ((291 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((9 : ℝ) / 32) ((141 : ℝ) / 500) := by
      have hz : ((-141 : ℝ) / 500) ≤ 8 * ((291 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((291 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((-9 : ℝ) / 32) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5769347 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((291 : ℝ) / 100)) ^ 2 ≤ ((76067669 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((291 : ℝ) / 100)) 8]
    have hx : RB |9 * ((291 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((2051 : ℝ) / 4000) ((321 : ℝ) / 625) := by
      have hz : ((-321 : ℝ) / 625) ≤ 9 * ((291 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 9 * ((291 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-2051 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((76067669 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((291 : ℝ) / 100)) ^ 2 ≤ ((6828501 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (10 * ((291 : ℝ) / 100)) 9]
    have hx : RB |10 * ((291 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((2977 : ℝ) / 4000) ((1863 : ℝ) / 2500) := by
      have hz : ((-1863 : ℝ) / 2500) ≤ 10 * ((291 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 10 * ((291 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((-2977 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6828501 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((291 : ℝ) / 100)) ^ 2 ≤ ((1965709 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (11 * ((291 : ℝ) / 100)) 10]
    have hx : RB |11 * ((291 : ℝ) / 100) - (10 : ℝ) * π| ((297 : ℝ) / 500) ((119 : ℝ) / 200) := by
      have hz : ((297 : ℝ) / 500) ≤ 11 * ((291 : ℝ) / 100) - (10 : ℝ) * π ∧ 11 * ((291 : ℝ) / 100) - (10 : ℝ) * π ≤ ((119 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1965709 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((291 : ℝ) / 100)) ^ 2 ≤ ((6323667 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((291 : ℝ) / 100)) 11]
    have hx : RB |12 * ((291 : ℝ) / 100) - (11 : ℝ) * π| ((453 : ℝ) / 1250) ((727 : ℝ) / 2000) := by
      have hz : ((453 : ℝ) / 1250) ≤ 12 * ((291 : ℝ) / 100) - (11 : ℝ) * π ∧ 12 * ((291 : ℝ) / 100) - (11 : ℝ) * π ≤ ((727 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6323667 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((291 : ℝ) / 100) n) ≤ ((57009 : ℝ) / 4000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((765473 : ℝ) / 10000000) ≤ Real.log (π / ((291 : ℝ) / 100)) := by
    apply cov_log_2637.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((291 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_25 : ((25645347 : ℝ) / 100000000) ≤ hfun ((167 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((167 : ℝ) / 100)) ^ 2 ≤ ((99019363 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (1 * ((167 : ℝ) / 100)) 0]
    have hx : RB |1 * ((167 : ℝ) / 100) - ((1 : ℝ) / 2) * π| ((62 : ℝ) / 625) ((397 : ℝ) / 4000) := by
      have hz : ((62 : ℝ) / 625) ≤ 1 * ((167 : ℝ) / 100) - ((1 : ℝ) / 2) * π ∧ 1 * ((167 : ℝ) / 100) - ((1 : ℝ) / 2) * π ≤ ((397 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99019363 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((167 : ℝ) / 100)) ^ 2 ≤ ((3888843 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((167 : ℝ) / 100)) 1]
    have hx : RB |2 * ((167 : ℝ) / 100) - (1 : ℝ) * π| ((124 : ℝ) / 625) ((397 : ℝ) / 2000) := by
      have hz : ((124 : ℝ) / 625) ≤ 2 * ((167 : ℝ) / 100) - (1 : ℝ) * π ∧ 2 * ((167 : ℝ) / 100) - (1 : ℝ) * π ≤ ((397 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3888843 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((167 : ℝ) / 100)) ^ 2 ≤ ((18283557 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (3 * ((167 : ℝ) / 100)) 1]
    have hx : RB |3 * ((167 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((186 : ℝ) / 625) ((1191 : ℝ) / 4000) := by
      have hz : ((186 : ℝ) / 625) ≤ 3 * ((167 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 3 * ((167 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((1191 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18283557 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((167 : ℝ) / 100)) ^ 2 ≤ ((74763 : ℝ) / 500000) := by
    rw [sin_sq_shift_pi (4 * ((167 : ℝ) / 100)) 2]
    have hx : RB |4 * ((167 : ℝ) / 100) - (2 : ℝ) * π| ((248 : ℝ) / 625) ((397 : ℝ) / 1000) := by
      have hz : ((248 : ℝ) / 625) ≤ 4 * ((167 : ℝ) / 100) - (2 : ℝ) * π ∧ 4 * ((167 : ℝ) / 100) - (2 : ℝ) * π ≤ ((397 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((74763 : ℝ) / 500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((167 : ℝ) / 100)) ^ 2 ≤ ((19366629 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (5 * ((167 : ℝ) / 100)) 2]
    have hx : RB |5 * ((167 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((62 : ℝ) / 125) ((397 : ℝ) / 800) := by
      have hz : ((62 : ℝ) / 125) ≤ 5 * ((167 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 5 * ((167 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((397 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19366629 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((167 : ℝ) / 100)) ^ 2 ≤ ((31483993 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((167 : ℝ) / 100)) 3]
    have hx : RB |6 * ((167 : ℝ) / 100) - (3 : ℝ) * π| ((372 : ℝ) / 625) ((1191 : ℝ) / 2000) := by
      have hz : ((372 : ℝ) / 625) ≤ 6 * ((167 : ℝ) / 100) - (3 : ℝ) * π ∧ 6 * ((167 : ℝ) / 100) - (3 : ℝ) * π ≤ ((1191 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((31483993 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((167 : ℝ) / 100)) ^ 2 ≤ ((928907 : ℝ) / 1562500) := by
    rw [sin_sq_shift_half_pi (7 * ((167 : ℝ) / 100)) 3]
    have hx : RB |7 * ((167 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((434 : ℝ) / 625) ((2779 : ℝ) / 4000) := by
      have hz : ((434 : ℝ) / 625) ≤ 7 * ((167 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 7 * ((167 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((2779 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((928907 : ℝ) / 1562500) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((167 : ℝ) / 100)) ^ 2 ≤ ((1608021 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (8 * ((167 : ℝ) / 100)) 4]
    have hx : RB |8 * ((167 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((3107 : ℝ) / 4000) ((1943 : ℝ) / 2500) := by
      have hz : ((-1943 : ℝ) / 2500) ≤ 8 * ((167 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 8 * ((167 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-3107 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1608021 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((167 : ℝ) / 100)) ^ 2 ≤ ((39388581 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((167 : ℝ) / 100)) 5]
    have hx : RB |9 * ((167 : ℝ) / 100) - (5 : ℝ) * π| ((271 : ℝ) / 400) ((339 : ℝ) / 500) := by
      have hz : ((-339 : ℝ) / 500) ≤ 9 * ((167 : ℝ) / 100) - (5 : ℝ) * π ∧ 9 * ((167 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-271 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((39388581 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((167 : ℝ) / 100)) ^ 2 ≤ ((70334867 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((167 : ℝ) / 100)) 5]
    have hx : RB |10 * ((167 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((2313 : ℝ) / 4000) ((1447 : ℝ) / 2500) := by
      have hz : ((-1447 : ℝ) / 2500) ≤ 10 * ((167 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 10 * ((167 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-2313 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((70334867 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((167 : ℝ) / 100)) ^ 2 ≤ ((21301613 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((167 : ℝ) / 100)) 6]
    have hx : RB |11 * ((167 : ℝ) / 100) - (6 : ℝ) * π| ((479 : ℝ) / 1000) ((1199 : ℝ) / 2500) := by
      have hz : ((-1199 : ℝ) / 2500) ≤ 11 * ((167 : ℝ) / 100) - (6 : ℝ) * π ∧ 11 * ((167 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-479 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21301613 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((167 : ℝ) / 100)) ^ 2 ≤ ((86301417 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((167 : ℝ) / 100)) 6]
    have hx : RB |12 * ((167 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((1519 : ℝ) / 4000) ((951 : ℝ) / 2500) := by
      have hz : ((-951 : ℝ) / 2500) ≤ 12 * ((167 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 12 * ((167 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-1519 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((86301417 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((167 : ℝ) / 100) n) ≤ ((37417827 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((15796919 : ℝ) / 25000000) ≤ Real.log (π / ((167 : ℝ) / 100)) := by
    apply cov_log_2638.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((167 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_28 : ((6425343 : ℝ) / 100000000) ≤ hfun ((29 : ℝ) / 10) := by
  have s1 : Real.sin (1 * ((29 : ℝ) / 10)) ^ 2 ≤ ((1431143 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (1 * ((29 : ℝ) / 10)) 1]
    have hx : RB |1 * ((29 : ℝ) / 10) - (1 : ℝ) * π| ((483 : ℝ) / 2000) ((151 : ℝ) / 625) := by
      have hz : ((-151 : ℝ) / 625) ≤ 1 * ((29 : ℝ) / 10) - (1 : ℝ) * π ∧ 1 * ((29 : ℝ) / 10) - (1 : ℝ) * π ≤ ((-483 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1431143 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((29 : ℝ) / 10)) ^ 2 ≤ ((2159309 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (2 * ((29 : ℝ) / 10)) 2]
    have hx : RB |2 * ((29 : ℝ) / 10) - (2 : ℝ) * π| ((483 : ℝ) / 1000) ((302 : ℝ) / 625) := by
      have hz : ((-302 : ℝ) / 625) ≤ 2 * ((29 : ℝ) / 10) - (2 : ℝ) * π ∧ 2 * ((29 : ℝ) / 10) - (2 : ℝ) * π ≤ ((-483 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2159309 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((29 : ℝ) / 10)) ^ 2 ≤ ((44012421 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((29 : ℝ) / 10)) 3]
    have hx : RB |3 * ((29 : ℝ) / 10) - (3 : ℝ) * π| ((1449 : ℝ) / 2000) ((453 : ℝ) / 625) := by
      have hz : ((-453 : ℝ) / 625) ≤ 3 * ((29 : ℝ) / 10) - (3 : ℝ) * π ∧ 3 * ((29 : ℝ) / 10) - (3 : ℝ) * π ≤ ((-1449 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44012421 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((29 : ℝ) / 10)) ^ 2 ≤ ((6794979 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (4 * ((29 : ℝ) / 10)) 3]
    have hx : RB |4 * ((29 : ℝ) / 10) - ((7 : ℝ) / 2) * π| ((1511 : ℝ) / 2500) ((2419 : ℝ) / 4000) := by
      have hz : ((1511 : ℝ) / 2500) ≤ 4 * ((29 : ℝ) / 10) - ((7 : ℝ) / 2) * π ∧ 4 * ((29 : ℝ) / 10) - ((7 : ℝ) / 2) * π ≤ ((2419 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6794979 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((29 : ℝ) / 10)) ^ 2 ≤ ((10930031 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (5 * ((29 : ℝ) / 10)) 4]
    have hx : RB |5 * ((29 : ℝ) / 10) - ((9 : ℝ) / 2) * π| ((907 : ℝ) / 2500) ((1453 : ℝ) / 4000) := by
      have hz : ((907 : ℝ) / 2500) ≤ 5 * ((29 : ℝ) / 10) - ((9 : ℝ) / 2) * π ∧ 5 * ((29 : ℝ) / 10) - ((9 : ℝ) / 2) * π ≤ ((1453 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10930031 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((29 : ℝ) / 10)) ^ 2 ≤ ((98538723 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((29 : ℝ) / 10)) 5]
    have hx : RB |6 * ((29 : ℝ) / 10) - ((11 : ℝ) / 2) * π| ((303 : ℝ) / 2500) ((487 : ℝ) / 4000) := by
      have hz : ((303 : ℝ) / 2500) ≤ 6 * ((29 : ℝ) / 10) - ((11 : ℝ) / 2) * π ∧ 6 * ((29 : ℝ) / 10) - ((11 : ℝ) / 2) * π ≤ ((487 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((98538723 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((29 : ℝ) / 10)) ^ 2 ≤ ((24643327 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (7 * ((29 : ℝ) / 10)) 6]
    have hx : RB |7 * ((29 : ℝ) / 10) - ((13 : ℝ) / 2) * π| ((479 : ℝ) / 4000) ((301 : ℝ) / 2500) := by
      have hz : ((-301 : ℝ) / 2500) ≤ 7 * ((29 : ℝ) / 10) - ((13 : ℝ) / 2) * π ∧ 7 * ((29 : ℝ) / 10) - ((13 : ℝ) / 2) * π ≤ ((-479 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24643327 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((29 : ℝ) / 10)) ^ 2 ≤ ((87542899 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((29 : ℝ) / 10)) 7]
    have hx : RB |8 * ((29 : ℝ) / 10) - ((15 : ℝ) / 2) * π| ((289 : ℝ) / 800) ((181 : ℝ) / 500) := by
      have hz : ((-181 : ℝ) / 500) ≤ 8 * ((29 : ℝ) / 10) - ((15 : ℝ) / 2) * π ∧ 8 * ((29 : ℝ) / 10) - ((15 : ℝ) / 2) * π ≤ ((-289 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((87542899 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((29 : ℝ) / 10)) ^ 2 ≤ ((13621071 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (9 * ((29 : ℝ) / 10)) 8]
    have hx : RB |9 * ((29 : ℝ) / 10) - ((17 : ℝ) / 2) * π| ((2411 : ℝ) / 4000) ((1509 : ℝ) / 2500) := by
      have hz : ((-1509 : ℝ) / 2500) ≤ 9 * ((29 : ℝ) / 10) - ((17 : ℝ) / 2) * π ∧ 9 * ((29 : ℝ) / 10) - ((17 : ℝ) / 2) * π ≤ ((-2411 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13621071 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((29 : ℝ) / 10)) ^ 2 ≤ ((44202953 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((29 : ℝ) / 10)) 9]
    have hx : RB |10 * ((29 : ℝ) / 10) - (9 : ℝ) * π| ((907 : ℝ) / 1250) ((1453 : ℝ) / 2000) := by
      have hz : ((907 : ℝ) / 1250) ≤ 10 * ((29 : ℝ) / 10) - (9 : ℝ) * π ∧ 10 * ((29 : ℝ) / 10) - (9 : ℝ) * π ≤ ((1453 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44202953 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((29 : ℝ) / 10)) ^ 2 ≤ ((21750257 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((29 : ℝ) / 10)) 10]
    have hx : RB |11 * ((29 : ℝ) / 10) - (10 : ℝ) * π| ((121 : ℝ) / 250) ((97 : ℝ) / 200) := by
      have hz : ((121 : ℝ) / 250) ≤ 11 * ((29 : ℝ) / 10) - (10 : ℝ) * π ∧ 11 * ((29 : ℝ) / 10) - (10 : ℝ) * π ≤ ((97 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21750257 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((29 : ℝ) / 10)) ^ 2 ≤ ((5814597 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((29 : ℝ) / 10)) 11]
    have hx : RB |12 * ((29 : ℝ) / 10) - (11 : ℝ) * π| ((303 : ℝ) / 1250) ((487 : ℝ) / 2000) := by
      have hz : ((303 : ℝ) / 1250) ≤ 12 * ((29 : ℝ) / 10) - (11 : ℝ) * π ∧ 12 * ((29 : ℝ) / 10) - (11 : ℝ) * π ≤ ((487 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5814597 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((29 : ℝ) / 10) n) ≤ ((306467 : ℝ) / 20000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1599793 : ℝ) / 20000000) ≤ Real.log (π / ((29 : ℝ) / 10)) := by
    apply cov_log_2639.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((29 : ℝ) / 10)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_29 : ((6660199 : ℝ) / 100000000) ≤ hfun ((289 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((289 : ℝ) / 100)) ^ 2 ≤ ((6198047 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((289 : ℝ) / 100)) 1]
    have hx : RB |1 * ((289 : ℝ) / 100) - (1 : ℝ) * π| ((503 : ℝ) / 2000) ((629 : ℝ) / 2500) := by
      have hz : ((-629 : ℝ) / 2500) ≤ 1 * ((289 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((289 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-503 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6198047 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((289 : ℝ) / 100)) ^ 2 ≤ ((23262491 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((289 : ℝ) / 100)) 2]
    have hx : RB |2 * ((289 : ℝ) / 100) - (2 : ℝ) * π| ((503 : ℝ) / 1000) ((629 : ℝ) / 1250) := by
      have hz : ((-629 : ℝ) / 1250) ≤ 2 * ((289 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((289 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-503 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23262491 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((289 : ℝ) / 100)) ^ 2 ≤ ((5876693 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (3 * ((289 : ℝ) / 100)) 3]
    have hx : RB |3 * ((289 : ℝ) / 100) - (3 : ℝ) * π| ((1509 : ℝ) / 2000) ((1887 : ℝ) / 2500) := by
      have hz : ((-1887 : ℝ) / 2500) ≤ 3 * ((289 : ℝ) / 100) - (3 : ℝ) * π ∧ 3 * ((289 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-1509 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5876693 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((289 : ℝ) / 100)) ^ 2 ≤ ((3578787 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (4 * ((289 : ℝ) / 100)) 3]
    have hx : RB |4 * ((289 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((1411 : ℝ) / 2500) ((2259 : ℝ) / 4000) := by
      have hz : ((1411 : ℝ) / 2500) ≤ 4 * ((289 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((289 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((2259 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3578787 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((289 : ℝ) / 100)) ^ 2 ≤ ((2829699 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (5 * ((289 : ℝ) / 100)) 4]
    have hx : RB |5 * ((289 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((391 : ℝ) / 1250) ((1253 : ℝ) / 4000) := by
      have hz : ((391 : ℝ) / 1250) ≤ 5 * ((289 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((289 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((1253 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2829699 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((289 : ℝ) / 100)) ^ 2 ≤ ((49812979 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (6 * ((289 : ℝ) / 100)) 5]
    have hx : RB |6 * ((289 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((153 : ℝ) / 2500) ((247 : ℝ) / 4000) := by
      have hz : ((153 : ℝ) / 2500) ≤ 6 * ((289 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((289 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((247 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49812979 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((289 : ℝ) / 100)) ^ 2 ≤ ((96445347 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((289 : ℝ) / 100)) 6]
    have hx : RB |7 * ((289 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((759 : ℝ) / 4000) ((119 : ℝ) / 625) := by
      have hz : ((-119 : ℝ) / 625) ≤ 7 * ((289 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((289 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-759 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((96445347 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((289 : ℝ) / 100)) ^ 2 ≤ ((81836827 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((289 : ℝ) / 100)) 7]
    have hx : RB |8 * ((289 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((353 : ℝ) / 800) ((221 : ℝ) / 500) := by
      have hz : ((-221 : ℝ) / 500) ≤ 8 * ((289 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((289 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((-353 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((81836827 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((289 : ℝ) / 100)) ^ 2 ≤ ((29807139 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (9 * ((289 : ℝ) / 100)) 8]
    have hx : RB |9 * ((289 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((2771 : ℝ) / 4000) ((867 : ℝ) / 1250) := by
      have hz : ((-867 : ℝ) / 1250) ≤ 9 * ((289 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 9 * ((289 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-2771 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((29807139 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((289 : ℝ) / 100)) ^ 2 ≤ ((17208367 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (10 * ((289 : ℝ) / 100)) 9]
    have hx : RB |10 * ((289 : ℝ) / 100) - (9 : ℝ) * π| ((391 : ℝ) / 625) ((1253 : ℝ) / 2000) := by
      have hz : ((391 : ℝ) / 625) ≤ 10 * ((289 : ℝ) / 100) - (9 : ℝ) * π ∧ 10 * ((289 : ℝ) / 100) - (9 : ℝ) * π ≤ ((1253 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17208367 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((289 : ℝ) / 100)) ^ 2 ≤ ((2684323 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (11 * ((289 : ℝ) / 100)) 10]
    have hx : RB |11 * ((289 : ℝ) / 100) - (10 : ℝ) * π| ((187 : ℝ) / 500) ((3 : ℝ) / 8) := by
      have hz : ((187 : ℝ) / 500) ≤ 11 * ((289 : ℝ) / 100) - (10 : ℝ) * π ∧ 11 * ((289 : ℝ) / 100) - (10 : ℝ) * π ≤ ((3 : ℝ) / 8) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2684323 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((289 : ℝ) / 100)) ^ 2 ≤ ((1517693 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((289 : ℝ) / 100)) 11]
    have hx : RB |12 * ((289 : ℝ) / 100) - (11 : ℝ) * π| ((153 : ℝ) / 1250) ((247 : ℝ) / 2000) := by
      have hz : ((153 : ℝ) / 1250) ≤ 12 * ((289 : ℝ) / 100) - (11 : ℝ) * π ∧ 12 * ((289 : ℝ) / 100) - (11 : ℝ) * π ≤ ((247 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1517693 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((289 : ℝ) / 100) n) ≤ ((328523 : ℝ) / 20000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((2086097 : ℝ) / 25000000) ≤ Real.log (π / ((289 : ℝ) / 100)) := by
    apply cov_log_2640.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((289 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_31 : ((3446533 : ℝ) / 50000000) ≤ hfun ((72 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((72 : ℝ) / 25)) ^ 2 ≤ ((836131 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (1 * ((72 : ℝ) / 25)) 1]
    have hx : RB |1 * ((72 : ℝ) / 25) - (1 : ℝ) * π| ((523 : ℝ) / 2000) ((327 : ℝ) / 1250) := by
      have hz : ((-327 : ℝ) / 1250) ≤ 1 * ((72 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((72 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-523 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((836131 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((72 : ℝ) / 25)) ^ 2 ≤ ((499499 : ℝ) / 2000000) := by
    rw [sin_sq_shift_pi (2 * ((72 : ℝ) / 25)) 2]
    have hx : RB |2 * ((72 : ℝ) / 25) - (2 : ℝ) * π| ((523 : ℝ) / 1000) ((327 : ℝ) / 625) := by
      have hz : ((-327 : ℝ) / 625) ≤ 2 * ((72 : ℝ) / 25) - (2 : ℝ) * π ∧ 2 * ((72 : ℝ) / 25) - (2 : ℝ) * π ≤ ((-523 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((499499 : ℝ) / 2000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((72 : ℝ) / 25)) ^ 2 ≤ ((50028503 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (3 * ((72 : ℝ) / 25)) 3]
    have hx : RB |3 * ((72 : ℝ) / 25) - (3 : ℝ) * π| ((1569 : ℝ) / 2000) ((981 : ℝ) / 1250) := by
      have hz : ((-981 : ℝ) / 1250) ≤ 3 * ((72 : ℝ) / 25) - (3 : ℝ) * π ∧ 3 * ((72 : ℝ) / 25) - (3 : ℝ) * π ≤ ((-1569 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((50028503 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((72 : ℝ) / 25)) ^ 2 ≤ ((75073823 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((72 : ℝ) / 25)) 3]
    have hx : RB |4 * ((72 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((1311 : ℝ) / 2500) ((2099 : ℝ) / 4000) := by
      have hz : ((1311 : ℝ) / 2500) ≤ 4 * ((72 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 4 * ((72 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((2099 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((75073823 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((72 : ℝ) / 25)) ^ 2 ≤ ((93261167 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((72 : ℝ) / 25)) 4]
    have hx : RB |5 * ((72 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((657 : ℝ) / 2500) ((1053 : ℝ) / 4000) := by
      have hz : ((657 : ℝ) / 2500) ≤ 5 * ((72 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 5 * ((72 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((1053 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((93261167 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((72 : ℝ) / 25)) ^ 2 ≤ ((99999857 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((72 : ℝ) / 25)) 5]
    have hx : RB |6 * ((72 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((3 : ℝ) / 2500) ((7 : ℝ) / 4000) := by
      have hz : ((3 : ℝ) / 2500) ≤ 6 * ((72 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 6 * ((72 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((7 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99999857 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((72 : ℝ) / 25)) ^ 2 ≤ ((18682617 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (7 * ((72 : ℝ) / 25)) 6]
    have hx : RB |7 * ((72 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((1039 : ℝ) / 4000) ((651 : ℝ) / 2500) := by
      have hz : ((-651 : ℝ) / 2500) ≤ 7 * ((72 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 7 * ((72 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((-1039 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18682617 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((72 : ℝ) / 25)) ^ 2 ≤ ((37672613 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((72 : ℝ) / 25)) 7]
    have hx : RB |8 * ((72 : ℝ) / 25) - ((15 : ℝ) / 2) * π| ((417 : ℝ) / 800) ((261 : ℝ) / 500) := by
      have hz : ((-261 : ℝ) / 500) ≤ 8 * ((72 : ℝ) / 25) - ((15 : ℝ) / 2) * π ∧ 8 * ((72 : ℝ) / 25) - ((15 : ℝ) / 2) * π ≤ ((-417 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((37672613 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((72 : ℝ) / 25)) ^ 2 ≤ ((50878017 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((72 : ℝ) / 25)) 8]
    have hx : RB |9 * ((72 : ℝ) / 25) - ((17 : ℝ) / 2) * π| ((3131 : ℝ) / 4000) ((1959 : ℝ) / 2500) := by
      have hz : ((-1959 : ℝ) / 2500) ≤ 9 * ((72 : ℝ) / 25) - ((17 : ℝ) / 2) * π ∧ 9 * ((72 : ℝ) / 25) - ((17 : ℝ) / 2) * π ≤ ((-3131 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((50878017 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((72 : ℝ) / 25)) ^ 2 ≤ ((3158899 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (10 * ((72 : ℝ) / 25)) 9]
    have hx : RB |10 * ((72 : ℝ) / 25) - (9 : ℝ) * π| ((657 : ℝ) / 1250) ((1053 : ℝ) / 2000) := by
      have hz : ((657 : ℝ) / 1250) ≤ 10 * ((72 : ℝ) / 25) - (9 : ℝ) * π ∧ 10 * ((72 : ℝ) / 25) - (9 : ℝ) * π ≤ ((1053 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3158899 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((72 : ℝ) / 25)) ^ 2 ≤ ((3430797 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (11 * ((72 : ℝ) / 25)) 10]
    have hx : RB |11 * ((72 : ℝ) / 25) - (10 : ℝ) * π| ((33 : ℝ) / 125) ((53 : ℝ) / 200) := by
      have hz : ((33 : ℝ) / 125) ≤ 11 * ((72 : ℝ) / 25) - (10 : ℝ) * π ∧ 11 * ((72 : ℝ) / 25) - (10 : ℝ) * π ≤ ((53 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3430797 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((72 : ℝ) / 25)) ^ 2 ≤ ((49 : ℝ) / 4000000) := by
    rw [sin_sq_shift_pi (12 * ((72 : ℝ) / 25)) 11]
    have hx : RB |12 * ((72 : ℝ) / 25) - (11 : ℝ) * π| ((3 : ℝ) / 1250) ((7 : ℝ) / 2000) := by
      have hz : ((3 : ℝ) / 1250) ≤ 12 * ((72 : ℝ) / 25) - (11 : ℝ) * π ∧ 12 * ((72 : ℝ) / 25) - (11 : ℝ) * π ≤ ((7 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((72 : ℝ) / 25) n) ≤ ((21951 : ℝ) / 1250000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((8691009 : ℝ) / 100000000) ≤ Real.log (π / ((72 : ℝ) / 25)) := by
    apply cov_log_2641.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((72 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_32 : ((1424419 : ℝ) / 20000000) ≤ hfun ((287 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((287 : ℝ) / 100)) ^ 2 ≤ ((7197379 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((287 : ℝ) / 100)) 1]
    have hx : RB |1 * ((287 : ℝ) / 100) - (1 : ℝ) * π| ((543 : ℝ) / 2000) ((679 : ℝ) / 2500) := by
      have hz : ((-679 : ℝ) / 2500) ≤ 1 * ((287 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((287 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-543 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7197379 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((287 : ℝ) / 100)) ^ 2 ≤ ((26727773 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((287 : ℝ) / 100)) 2]
    have hx : RB |2 * ((287 : ℝ) / 100) - (2 : ℝ) * π| ((543 : ℝ) / 1000) ((679 : ℝ) / 1250) := by
      have hz : ((-679 : ℝ) / 1250) ≤ 2 * ((287 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((287 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-543 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((26727773 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((287 : ℝ) / 100)) ^ 2 ≤ ((53475247 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((287 : ℝ) / 100)) 2]
    have hx : RB |3 * ((287 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((189 : ℝ) / 250) ((121 : ℝ) / 160) := by
      have hz : ((189 : ℝ) / 250) ≤ 3 * ((287 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((287 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((121 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((53475247 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((287 : ℝ) / 100)) ^ 2 ≤ ((4901289 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (4 * ((287 : ℝ) / 100)) 3]
    have hx : RB |4 * ((287 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((1211 : ℝ) / 2500) ((1939 : ℝ) / 4000) := by
      have hz : ((1211 : ℝ) / 2500) ≤ 4 * ((287 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((287 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((1939 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4901289 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((287 : ℝ) / 100)) ^ 2 ≤ ((47771969 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (5 * ((287 : ℝ) / 100)) 4]
    have hx : RB |5 * ((287 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((133 : ℝ) / 625) ((853 : ℝ) / 4000) := by
      have hz : ((133 : ℝ) / 625) ≤ 5 * ((287 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((287 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((853 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47771969 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((287 : ℝ) / 100)) ^ 2 ≤ ((49830553 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (6 * ((287 : ℝ) / 100)) 5]
    have hx : RB |6 * ((287 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((233 : ℝ) / 4000) ((147 : ℝ) / 2500) := by
      have hz : ((-147 : ℝ) / 2500) ≤ 6 * ((287 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((287 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-233 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49830553 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((287 : ℝ) / 100)) ^ 2 ≤ ((179079 : ℝ) / 200000) := by
    rw [sin_sq_shift_half_pi (7 * ((287 : ℝ) / 100)) 6]
    have hx : RB |7 * ((287 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((1319 : ℝ) / 4000) ((413 : ℝ) / 1250) := by
      have hz : ((-413 : ℝ) / 1250) ≤ 7 * ((287 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((287 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-1319 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((179079 : ℝ) / 200000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((287 : ℝ) / 100)) ^ 2 ≤ ((13648483 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (8 * ((287 : ℝ) / 100)) 7]
    have hx : RB |8 * ((287 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((481 : ℝ) / 800) ((301 : ℝ) / 500) := by
      have hz : ((-301 : ℝ) / 500) ≤ 8 * ((287 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 8 * ((287 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((-481 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13648483 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((287 : ℝ) / 100)) ^ 2 ≤ ((8273441 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (9 * ((287 : ℝ) / 100)) 8]
    have hx : RB |9 * ((287 : ℝ) / 100) - (8 : ℝ) * π| ((1743 : ℝ) / 2500) ((349 : ℝ) / 500) := by
      have hz : ((1743 : ℝ) / 2500) ≤ 9 * ((287 : ℝ) / 100) - (8 : ℝ) * π ∧ 9 * ((287 : ℝ) / 100) - (8 : ℝ) * π ≤ ((349 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8273441 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((287 : ℝ) / 100)) ^ 2 ≤ ((17122431 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((287 : ℝ) / 100)) 9]
    have hx : RB |10 * ((287 : ℝ) / 100) - (9 : ℝ) * π| ((266 : ℝ) / 625) ((853 : ℝ) / 2000) := by
      have hz : ((266 : ℝ) / 625) ≤ 10 * ((287 : ℝ) / 100) - (9 : ℝ) * π ∧ 10 * ((287 : ℝ) / 100) - (9 : ℝ) * π ≤ ((853 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17122431 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((287 : ℝ) / 100)) ^ 2 ≤ ((476739 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (11 * ((287 : ℝ) / 100)) 10]
    have hx : RB |11 * ((287 : ℝ) / 100) - (10 : ℝ) * π| ((77 : ℝ) / 500) ((31 : ℝ) / 200) := by
      have hz : ((77 : ℝ) / 500) ≤ 11 * ((287 : ℝ) / 100) - (10 : ℝ) * π ∧ 11 * ((287 : ℝ) / 100) - (10 : ℝ) * π ≤ ((31 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((476739 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((287 : ℝ) / 100)) ^ 2 ≤ ((1376791 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((287 : ℝ) / 100)) 11]
    have hx : RB |12 * ((287 : ℝ) / 100) - (11 : ℝ) * π| ((233 : ℝ) / 2000) ((147 : ℝ) / 1250) := by
      have hz : ((-147 : ℝ) / 1250) ≤ 12 * ((287 : ℝ) / 100) - (11 : ℝ) * π ∧ 12 * ((287 : ℝ) / 100) - (11 : ℝ) * π ≤ ((-233 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1376791 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((287 : ℝ) / 100) n) ≤ ((937293 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((2259709 : ℝ) / 25000000) ≤ Real.log (π / ((287 : ℝ) / 100)) := by
    apply cov_log_2642.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((287 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_24 : ((6386027 : ℝ) / 25000000) ≤ hfun ((42 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((42 : ℝ) / 25)) ^ 2 ≤ ((98812567 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (1 * ((42 : ℝ) / 25)) 0]
    have hx : RB |1 * ((42 : ℝ) / 25) - ((1 : ℝ) / 2) * π| ((273 : ℝ) / 2500) ((437 : ℝ) / 4000) := by
      have hz : ((273 : ℝ) / 2500) ≤ 1 * ((42 : ℝ) / 25) - ((1 : ℝ) / 2) * π ∧ 1 * ((42 : ℝ) / 25) - ((1 : ℝ) / 2) * π ≤ ((437 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((98812567 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((42 : ℝ) / 25)) ^ 2 ≤ ((469887 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (2 * ((42 : ℝ) / 25)) 1]
    have hx : RB |2 * ((42 : ℝ) / 25) - (1 : ℝ) * π| ((273 : ℝ) / 1250) ((437 : ℝ) / 2000) := by
      have hz : ((273 : ℝ) / 1250) ≤ 2 * ((42 : ℝ) / 25) - (1 : ℝ) * π ∧ 2 * ((42 : ℝ) / 25) - (1 : ℝ) * π ≤ ((437 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((469887 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((42 : ℝ) / 25)) ^ 2 ≤ ((44834779 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((42 : ℝ) / 25)) 1]
    have hx : RB |3 * ((42 : ℝ) / 25) - ((3 : ℝ) / 2) * π| ((819 : ℝ) / 2500) ((1311 : ℝ) / 4000) := by
      have hz : ((819 : ℝ) / 2500) ≤ 3 * ((42 : ℝ) / 25) - ((3 : ℝ) / 2) * π ∧ 3 * ((42 : ℝ) / 25) - ((3 : ℝ) / 2) * π ≤ ((1311 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44834779 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((42 : ℝ) / 25)) ^ 2 ≤ ((279933 : ℝ) / 1562500) := by
    rw [sin_sq_shift_pi (4 * ((42 : ℝ) / 25)) 2]
    have hx : RB |4 * ((42 : ℝ) / 25) - (2 : ℝ) * π| ((273 : ℝ) / 625) ((437 : ℝ) / 1000) := by
      have hz : ((273 : ℝ) / 625) ≤ 4 * ((42 : ℝ) / 25) - (2 : ℝ) * π ∧ 4 * ((42 : ℝ) / 25) - (2 : ℝ) * π ≤ ((437 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((279933 : ℝ) / 1562500) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((42 : ℝ) / 25)) ^ 2 ≤ ((73201593 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((42 : ℝ) / 25)) 2]
    have hx : RB |5 * ((42 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((273 : ℝ) / 500) ((437 : ℝ) / 800) := by
      have hz : ((273 : ℝ) / 500) ≤ 5 * ((42 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 5 * ((42 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((437 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((73201593 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((42 : ℝ) / 25)) ^ 2 ≤ ((9297379 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((42 : ℝ) / 25)) 3]
    have hx : RB |6 * ((42 : ℝ) / 25) - (3 : ℝ) * π| ((819 : ℝ) / 1250) ((1311 : ℝ) / 2000) := by
      have hz : ((819 : ℝ) / 1250) ≤ 6 * ((42 : ℝ) / 25) - (3 : ℝ) * π ∧ 6 * ((42 : ℝ) / 25) - (3 : ℝ) * π ≤ ((1311 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9297379 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((42 : ℝ) / 25)) ^ 2 ≤ ((52658381 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((42 : ℝ) / 25)) 3]
    have hx : RB |7 * ((42 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((1911 : ℝ) / 2500) ((3059 : ℝ) / 4000) := by
      have hz : ((1911 : ℝ) / 2500) ≤ 7 * ((42 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 7 * ((42 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((3059 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((52658381 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((42 : ℝ) / 25)) ^ 2 ≤ ((59224729 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((42 : ℝ) / 25)) 4]
    have hx : RB |8 * ((42 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((2787 : ℝ) / 4000) ((1743 : ℝ) / 2500) := by
      have hz : ((-1743 : ℝ) / 2500) ≤ 8 * ((42 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 8 * ((42 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((-2787 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((59224729 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((42 : ℝ) / 25)) ^ 2 ≤ ((6158421 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (9 * ((42 : ℝ) / 25)) 5]
    have hx : RB |9 * ((42 : ℝ) / 25) - (5 : ℝ) * π| ((47 : ℝ) / 80) ((147 : ℝ) / 250) := by
      have hz : ((-147 : ℝ) / 250) ≤ 9 * ((42 : ℝ) / 25) - (5 : ℝ) * π ∧ 9 * ((42 : ℝ) / 25) - (5 : ℝ) * π ≤ ((-47 : ℝ) / 80) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6158421 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((42 : ℝ) / 25)) ^ 2 ≤ ((78921143 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((42 : ℝ) / 25)) 5]
    have hx : RB |10 * ((42 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((1913 : ℝ) / 4000) ((1197 : ℝ) / 2500) := by
      have hz : ((-1197 : ℝ) / 2500) ≤ 10 * ((42 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 10 * ((42 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((-1913 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((78921143 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((42 : ℝ) / 25)) ^ 2 ≤ ((13053413 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((42 : ℝ) / 25)) 6]
    have hx : RB |11 * ((42 : ℝ) / 25) - (6 : ℝ) * π| ((369 : ℝ) / 1000) ((231 : ℝ) / 625) := by
      have hz : ((-231 : ℝ) / 625) ≤ 11 * ((42 : ℝ) / 25) - (6 : ℝ) * π ∧ 11 * ((42 : ℝ) / 25) - (6 : ℝ) * π ≤ ((-369 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13053413 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((42 : ℝ) / 25)) ^ 2 ≤ ((18682617 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (12 * ((42 : ℝ) / 25)) 6]
    have hx : RB |12 * ((42 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((1039 : ℝ) / 4000) ((651 : ℝ) / 2500) := by
      have hz : ((-651 : ℝ) / 2500) ≤ 12 * ((42 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 12 * ((42 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((-1039 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18682617 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((42 : ℝ) / 25) n) ≤ ((36923527 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((62590659 : ℝ) / 100000000) ≤ Real.log (π / ((42 : ℝ) / 25)) := by
    apply cov_log_2643.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((42 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_33 : ((735129 : ℝ) / 10000000) ≤ hfun ((143 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((143 : ℝ) / 50)) ^ 2 ≤ ((7722837 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((143 : ℝ) / 50)) 1]
    have hx : RB |1 * ((143 : ℝ) / 50) - (1 : ℝ) * π| ((563 : ℝ) / 2000) ((176 : ℝ) / 625) := by
      have hz : ((-176 : ℝ) / 625) ≤ 1 * ((143 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((143 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-563 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7722837 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((143 : ℝ) / 50)) ^ 2 ≤ ((5703641 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (2 * ((143 : ℝ) / 50)) 2]
    have hx : RB |2 * ((143 : ℝ) / 50) - (2 : ℝ) * π| ((563 : ℝ) / 1000) ((352 : ℝ) / 625) := by
      have hz : ((-352 : ℝ) / 625) ≤ 2 * ((143 : ℝ) / 50) - (2 : ℝ) * π ∧ 2 * ((143 : ℝ) / 50) - (2 : ℝ) * π ≤ ((-563 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5703641 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((143 : ℝ) / 50)) ^ 2 ≤ ((28196383 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((143 : ℝ) / 50)) 2]
    have hx : RB |3 * ((143 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((363 : ℝ) / 500) ((581 : ℝ) / 800) := by
      have hz : ((363 : ℝ) / 500) ≤ 3 * ((143 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 3 * ((143 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((581 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((28196383 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((143 : ℝ) / 50)) ^ 2 ≤ ((81593667 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((143 : ℝ) / 50)) 3]
    have hx : RB |4 * ((143 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((1111 : ℝ) / 2500) ((1779 : ℝ) / 4000) := by
      have hz : ((1111 : ℝ) / 2500) ≤ 4 * ((143 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 4 * ((143 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((1779 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((81593667 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((143 : ℝ) / 50)) ^ 2 ≤ ((48687239 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (5 * ((143 : ℝ) / 50)) 4]
    have hx : RB |5 * ((143 : ℝ) / 50) - ((9 : ℝ) / 2) * π| ((407 : ℝ) / 2500) ((653 : ℝ) / 4000) := by
      have hz : ((407 : ℝ) / 2500) ≤ 5 * ((143 : ℝ) / 50) - ((9 : ℝ) / 2) * π ∧ 5 * ((143 : ℝ) / 50) - ((9 : ℝ) / 2) * π ≤ ((653 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((48687239 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((143 : ℝ) / 50)) ^ 2 ≤ ((98608643 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((143 : ℝ) / 50)) 5]
    have hx : RB |6 * ((143 : ℝ) / 50) - ((11 : ℝ) / 2) * π| ((473 : ℝ) / 4000) ((297 : ℝ) / 2500) := by
      have hz : ((-297 : ℝ) / 2500) ≤ 6 * ((143 : ℝ) / 50) - ((11 : ℝ) / 2) * π ∧ 6 * ((143 : ℝ) / 50) - ((11 : ℝ) / 2) * π ≤ ((-473 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((98608643 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((143 : ℝ) / 50)) ^ 2 ≤ ((42452459 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (7 * ((143 : ℝ) / 50)) 6]
    have hx : RB |7 * ((143 : ℝ) / 50) - ((13 : ℝ) / 2) * π| ((1599 : ℝ) / 4000) ((1001 : ℝ) / 2500) := by
      have hz : ((-1001 : ℝ) / 2500) ≤ 7 * ((143 : ℝ) / 50) - ((13 : ℝ) / 2) * π ∧ 7 * ((143 : ℝ) / 50) - ((13 : ℝ) / 2) * π ≤ ((-1599 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42452459 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((143 : ℝ) / 50)) ^ 2 ≤ ((12143581 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (8 * ((143 : ℝ) / 50)) 7]
    have hx : RB |8 * ((143 : ℝ) / 50) - ((15 : ℝ) / 2) * π| ((109 : ℝ) / 160) ((341 : ℝ) / 500) := by
      have hz : ((-341 : ℝ) / 500) ≤ 8 * ((143 : ℝ) / 50) - ((15 : ℝ) / 2) * π ∧ 8 * ((143 : ℝ) / 50) - ((15 : ℝ) / 2) * π ≤ ((-109 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12143581 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((143 : ℝ) / 50)) ^ 2 ≤ ((32663423 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((143 : ℝ) / 50)) 8]
    have hx : RB |9 * ((143 : ℝ) / 50) - (8 : ℝ) * π| ((759 : ℝ) / 1250) ((76 : ℝ) / 125) := by
      have hz : ((759 : ℝ) / 1250) ≤ 9 * ((143 : ℝ) / 50) - (8 : ℝ) * π ∧ 9 * ((143 : ℝ) / 50) - (8 : ℝ) * π ≤ ((76 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((32663423 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((143 : ℝ) / 50)) ^ 2 ≤ ((5145119 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (10 * ((143 : ℝ) / 50)) 9]
    have hx : RB |10 * ((143 : ℝ) / 50) - (9 : ℝ) * π| ((407 : ℝ) / 1250) ((653 : ℝ) / 2000) := by
      have hz : ((407 : ℝ) / 1250) ≤ 10 * ((143 : ℝ) / 50) - (9 : ℝ) * π ∧ 10 * ((143 : ℝ) / 50) - (9 : ℝ) * π ≤ ((653 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5145119 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((143 : ℝ) / 50)) ^ 2 ≤ ((202373 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((143 : ℝ) / 50)) 10]
    have hx : RB |11 * ((143 : ℝ) / 50) - (10 : ℝ) * π| ((11 : ℝ) / 250) ((9 : ℝ) / 200) := by
      have hz : ((11 : ℝ) / 250) ≤ 11 * ((143 : ℝ) / 50) - (10 : ℝ) * π ∧ 11 * ((143 : ℝ) / 50) - (10 : ℝ) * π ≤ ((9 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((202373 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((143 : ℝ) / 50)) ^ 2 ≤ ((5541453 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((143 : ℝ) / 50)) 11]
    have hx : RB |12 * ((143 : ℝ) / 50) - (11 : ℝ) * π| ((473 : ℝ) / 2000) ((297 : ℝ) / 1250) := by
      have hz : ((-297 : ℝ) / 1250) ≤ 12 * ((143 : ℝ) / 50) - (11 : ℝ) * π ∧ 12 * ((143 : ℝ) / 50) - (11 : ℝ) * π ≤ ((-473 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5541453 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((143 : ℝ) / 50) n) ≤ ((249267 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((2346969 : ℝ) / 25000000) ≤ Real.log (π / ((143 : ℝ) / 50)) := by
    apply cov_log_2644.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((143 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_34 : ((7578353 : ℝ) / 100000000) ≤ hfun ((57 : ℝ) / 20) := by
  have s1 : Real.sin (1 * ((57 : ℝ) / 20)) ^ 2 ≤ ((4132607 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((57 : ℝ) / 20)) 1]
    have hx : RB |1 * ((57 : ℝ) / 20) - (1 : ℝ) * π| ((583 : ℝ) / 2000) ((729 : ℝ) / 2500) := by
      have hz : ((-729 : ℝ) / 2500) ≤ 1 * ((57 : ℝ) / 20) - (1 : ℝ) * π ∧ 1 * ((57 : ℝ) / 20) - (1 : ℝ) * π ≤ ((-583 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4132607 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((57 : ℝ) / 20)) ^ 2 ≤ ((30343439 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((57 : ℝ) / 20)) 2]
    have hx : RB |2 * ((57 : ℝ) / 20) - (2 : ℝ) * π| ((583 : ℝ) / 1000) ((729 : ℝ) / 1250) := by
      have hz : ((-729 : ℝ) / 1250) ≤ 2 * ((57 : ℝ) / 20) - (2 : ℝ) * π ∧ 2 * ((57 : ℝ) / 20) - (2 : ℝ) * π ≤ ((-583 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((30343439 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((57 : ℝ) / 20)) ^ 2 ≤ ((29647417 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((57 : ℝ) / 20)) 2]
    have hx : RB |3 * ((57 : ℝ) / 20) - ((5 : ℝ) / 2) * π| ((87 : ℝ) / 125) ((557 : ℝ) / 800) := by
      have hz : ((87 : ℝ) / 125) ≤ 3 * ((57 : ℝ) / 20) - ((5 : ℝ) / 2) * π ∧ 3 * ((57 : ℝ) / 20) - ((5 : ℝ) / 2) * π ≤ ((557 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((29647417 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((57 : ℝ) / 20)) ^ 2 ≤ ((84571589 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((57 : ℝ) / 20)) 3]
    have hx : RB |4 * ((57 : ℝ) / 20) - ((7 : ℝ) / 2) * π| ((1011 : ℝ) / 2500) ((1619 : ℝ) / 4000) := by
      have hz : ((1011 : ℝ) / 2500) ≤ 4 * ((57 : ℝ) / 20) - ((7 : ℝ) / 2) * π ∧ 4 * ((57 : ℝ) / 20) - ((7 : ℝ) / 2) * π ≤ ((1619 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((84571589 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((57 : ℝ) / 20)) ^ 2 ≤ ((49366683 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (5 * ((57 : ℝ) / 20)) 4]
    have hx : RB |5 * ((57 : ℝ) / 20) - ((9 : ℝ) / 2) * π| ((141 : ℝ) / 1250) ((453 : ℝ) / 4000) := by
      have hz : ((141 : ℝ) / 1250) ≤ 5 * ((57 : ℝ) / 20) - ((9 : ℝ) / 2) * π ∧ 5 * ((57 : ℝ) / 20) - ((9 : ℝ) / 2) * π ≤ ((453 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49366683 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((57 : ℝ) / 20)) ^ 2 ≤ ((9685841 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (6 * ((57 : ℝ) / 20)) 5]
    have hx : RB |6 * ((57 : ℝ) / 20) - ((11 : ℝ) / 2) * π| ((713 : ℝ) / 4000) ((447 : ℝ) / 2500) := by
      have hz : ((-447 : ℝ) / 2500) ≤ 6 * ((57 : ℝ) / 20) - ((11 : ℝ) / 2) * π ∧ 6 * ((57 : ℝ) / 20) - ((11 : ℝ) / 2) * π ≤ ((-713 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9685841 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((57 : ℝ) / 20)) ^ 2 ≤ ((79605231 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((57 : ℝ) / 20)) 6]
    have hx : RB |7 * ((57 : ℝ) / 20) - ((13 : ℝ) / 2) * π| ((1879 : ℝ) / 4000) ((294 : ℝ) / 625) := by
      have hz : ((-294 : ℝ) / 625) ≤ 7 * ((57 : ℝ) / 20) - ((13 : ℝ) / 2) * π ∧ 7 * ((57 : ℝ) / 20) - ((13 : ℝ) / 2) * π ≤ ((-1879 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((79605231 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((57 : ℝ) / 20)) ^ 2 ≤ ((1655331 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (8 * ((57 : ℝ) / 20)) 7]
    have hx : RB |8 * ((57 : ℝ) / 20) - ((15 : ℝ) / 2) * π| ((609 : ℝ) / 800) ((381 : ℝ) / 500) := by
      have hz : ((-381 : ℝ) / 500) ≤ 8 * ((57 : ℝ) / 20) - ((15 : ℝ) / 2) * π ∧ 8 * ((57 : ℝ) / 20) - ((15 : ℝ) / 2) * π ≤ ((-609 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1655331 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((57 : ℝ) / 20)) ^ 2 ≤ ((6133419 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (9 * ((57 : ℝ) / 20)) 8]
    have hx : RB |9 * ((57 : ℝ) / 20) - (8 : ℝ) * π| ((1293 : ℝ) / 2500) ((259 : ℝ) / 500) := by
      have hz : ((1293 : ℝ) / 2500) ≤ 9 * ((57 : ℝ) / 20) - (8 : ℝ) * π ∧ 9 * ((57 : ℝ) / 20) - (8 : ℝ) * π ≤ ((259 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6133419 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((57 : ℝ) / 20)) ^ 2 ≤ ((504417 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (10 * ((57 : ℝ) / 20)) 9]
    have hx : RB |10 * ((57 : ℝ) / 20) - (9 : ℝ) * π| ((141 : ℝ) / 625) ((453 : ℝ) / 2000) := by
      have hz : ((141 : ℝ) / 625) ≤ 10 * ((57 : ℝ) / 20) - (9 : ℝ) * π ∧ 10 * ((57 : ℝ) / 20) - (9 : ℝ) * π ≤ ((453 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((504417 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((57 : ℝ) / 20)) ^ 2 ≤ ((434997 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((57 : ℝ) / 20)) 10]
    have hx : RB |11 * ((57 : ℝ) / 20) - (10 : ℝ) * π| ((13 : ℝ) / 200) ((33 : ℝ) / 500) := by
      have hz : ((-33 : ℝ) / 500) ≤ 11 * ((57 : ℝ) / 20) - (10 : ℝ) * π ∧ 11 * ((57 : ℝ) / 20) - (10 : ℝ) * π ≤ ((-13 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((434997 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((57 : ℝ) / 20)) ^ 2 ≤ ((12257497 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((57 : ℝ) / 20)) 11]
    have hx : RB |12 * ((57 : ℝ) / 20) - (11 : ℝ) * π| ((713 : ℝ) / 2000) ((447 : ℝ) / 1250) := by
      have hz : ((-447 : ℝ) / 1250) ≤ 12 * ((57 : ℝ) / 20) - (11 : ℝ) * π ∧ 12 * ((57 : ℝ) / 20) - (11 : ℝ) * π ≤ ((-713 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12257497 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((57 : ℝ) / 20) n) ≤ ((2117037 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((9738139 : ℝ) / 100000000) ≤ Real.log (π / ((57 : ℝ) / 20)) := by
    apply cov_log_2645.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((57 : ℝ) / 20)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_36 : ((3901717 : ℝ) / 50000000) ≤ hfun ((71 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((71 : ℝ) / 25)) ^ 2 ≤ ((4412147 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((71 : ℝ) / 25)) 1]
    have hx : RB |1 * ((71 : ℝ) / 25) - (1 : ℝ) * π| ((603 : ℝ) / 2000) ((377 : ℝ) / 1250) := by
      have hz : ((-377 : ℝ) / 1250) ≤ 1 * ((71 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((71 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-603 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4412147 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((71 : ℝ) / 25)) ^ 2 ≤ ((6440123 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (2 * ((71 : ℝ) / 25)) 2]
    have hx : RB |2 * ((71 : ℝ) / 25) - (2 : ℝ) * π| ((603 : ℝ) / 1000) ((377 : ℝ) / 625) := by
      have hz : ((-377 : ℝ) / 625) ≤ 2 * ((71 : ℝ) / 25) - (2 : ℝ) * π ∧ 2 * ((71 : ℝ) / 25) - (2 : ℝ) * π ≤ ((-603 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6440123 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((71 : ℝ) / 25)) ^ 2 ≤ ((62170761 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((71 : ℝ) / 25)) 2]
    have hx : RB |3 * ((71 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((333 : ℝ) / 500) ((533 : ℝ) / 800) := by
      have hz : ((333 : ℝ) / 500) ≤ 3 * ((71 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 3 * ((71 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((533 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((62170761 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((71 : ℝ) / 25)) ^ 2 ≤ ((43667149 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (4 * ((71 : ℝ) / 25)) 3]
    have hx : RB |4 * ((71 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((911 : ℝ) / 2500) ((1459 : ℝ) / 4000) := by
      have hz : ((911 : ℝ) / 2500) ≤ 4 * ((71 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 4 * ((71 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((1459 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((43667149 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((71 : ℝ) / 25)) ^ 2 ≤ ((24901543 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (5 * ((71 : ℝ) / 25)) 4]
    have hx : RB |5 * ((71 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((157 : ℝ) / 2500) ((253 : ℝ) / 4000) := by
      have hz : ((157 : ℝ) / 2500) ≤ 5 * ((71 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 5 * ((71 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((253 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24901543 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((71 : ℝ) / 25)) ^ 2 ≤ ((94437161 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((71 : ℝ) / 25)) 5]
    have hx : RB |6 * ((71 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((953 : ℝ) / 4000) ((597 : ℝ) / 2500) := by
      have hz : ((-597 : ℝ) / 2500) ≤ 6 * ((71 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 6 * ((71 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((-953 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94437161 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((71 : ℝ) / 25)) ^ 2 ≤ ((18437439 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (7 * ((71 : ℝ) / 25)) 6]
    have hx : RB |7 * ((71 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((2159 : ℝ) / 4000) ((1351 : ℝ) / 2500) := by
      have hz : ((-1351 : ℝ) / 2500) ≤ 7 * ((71 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 7 * ((71 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((-2159 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18437439 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((71 : ℝ) / 25)) ^ 2 ≤ ((44495441 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((71 : ℝ) / 25)) 7]
    have hx : RB |8 * ((71 : ℝ) / 25) - (7 : ℝ) * π| ((911 : ℝ) / 1250) ((1459 : ℝ) / 2000) := by
      have hz : ((911 : ℝ) / 1250) ≤ 8 * ((71 : ℝ) / 25) - (7 : ℝ) * π ∧ 8 * ((71 : ℝ) / 25) - (7 : ℝ) * π ≤ ((1459 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44495441 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((71 : ℝ) / 25)) ^ 2 ≤ ((8617461 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (9 * ((71 : ℝ) / 25)) 8]
    have hx : RB |9 * ((71 : ℝ) / 25) - (8 : ℝ) * π| ((267 : ℝ) / 625) ((107 : ℝ) / 250) := by
      have hz : ((267 : ℝ) / 625) ≤ 9 * ((71 : ℝ) / 25) - (8 : ℝ) * π ∧ 9 * ((71 : ℝ) / 25) - (8 : ℝ) * π ≤ ((107 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8617461 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((71 : ℝ) / 25)) ^ 2 ≤ ((159189 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (10 * ((71 : ℝ) / 25)) 9]
    have hx : RB |10 * ((71 : ℝ) / 25) - (9 : ℝ) * π| ((157 : ℝ) / 1250) ((253 : ℝ) / 2000) := by
      have hz : ((157 : ℝ) / 1250) ≤ 10 * ((71 : ℝ) / 25) - (9 : ℝ) * π ∧ 10 * ((71 : ℝ) / 25) - (9 : ℝ) * π ≤ ((253 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((159189 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((71 : ℝ) / 25)) ^ 2 ≤ ((1533149 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (11 * ((71 : ℝ) / 25)) 10]
    have hx : RB |11 * ((71 : ℝ) / 25) - (10 : ℝ) * π| ((7 : ℝ) / 40) ((22 : ℝ) / 125) := by
      have hz : ((-22 : ℝ) / 125) ≤ 11 * ((71 : ℝ) / 25) - (10 : ℝ) * π ∧ 11 * ((71 : ℝ) / 25) - (10 : ℝ) * π ≤ ((-7 : ℝ) / 40) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1533149 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((71 : ℝ) / 25)) ^ 2 ≤ ((10571573 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((71 : ℝ) / 25)) 11]
    have hx : RB |12 * ((71 : ℝ) / 25) - (11 : ℝ) * π| ((953 : ℝ) / 2000) ((597 : ℝ) / 1250) := by
      have hz : ((-597 : ℝ) / 1250) ≤ 12 * ((71 : ℝ) / 25) - (11 : ℝ) * π ∧ 12 * ((71 : ℝ) / 25) - (11 : ℝ) * π ≤ ((-953 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10571573 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((71 : ℝ) / 25) n) ≤ ((2243149 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((10089633 : ℝ) / 100000000) ≤ Real.log (π / ((71 : ℝ) / 25)) := by
    apply cov_log_2646.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((71 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_30 : ((25442931 : ℝ) / 100000000) ≤ hfun ((169 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((169 : ℝ) / 100)) ^ 2 ≤ ((3943451 : ℝ) / 4000000) := by
    rw [sin_sq_shift_half_pi (1 * ((169 : ℝ) / 100)) 0]
    have hx : RB |1 * ((169 : ℝ) / 100) - ((1 : ℝ) / 2) * π| ((149 : ℝ) / 1250) ((477 : ℝ) / 4000) := by
      have hz : ((149 : ℝ) / 1250) ≤ 1 * ((169 : ℝ) / 100) - ((1 : ℝ) / 2) * π ∧ 1 * ((169 : ℝ) / 100) - ((1 : ℝ) / 2) * π ≤ ((477 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3943451 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((169 : ℝ) / 100)) ^ 2 ≤ ((5581383 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((169 : ℝ) / 100)) 1]
    have hx : RB |2 * ((169 : ℝ) / 100) - (1 : ℝ) * π| ((149 : ℝ) / 625) ((477 : ℝ) / 2000) := by
      have hz : ((149 : ℝ) / 625) ≤ 2 * ((169 : ℝ) / 100) - (1 : ℝ) * π ∧ 2 * ((169 : ℝ) / 100) - (1 : ℝ) * π ≤ ((477 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5581383 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((169 : ℝ) / 100)) ^ 2 ≤ ((2743151 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (3 * ((169 : ℝ) / 100)) 1]
    have hx : RB |3 * ((169 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((447 : ℝ) / 1250) ((1431 : ℝ) / 4000) := by
      have hz : ((447 : ℝ) / 1250) ≤ 3 * ((169 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 3 * ((169 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((1431 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2743151 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((169 : ℝ) / 100)) ^ 2 ≤ ((21084731 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((169 : ℝ) / 100)) 2]
    have hx : RB |4 * ((169 : ℝ) / 100) - (2 : ℝ) * π| ((298 : ℝ) / 625) ((477 : ℝ) / 1000) := by
      have hz : ((298 : ℝ) / 625) ≤ 4 * ((169 : ℝ) / 100) - (2 : ℝ) * π ∧ 4 * ((169 : ℝ) / 100) - (2 : ℝ) * π ≤ ((477 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21084731 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((169 : ℝ) / 100)) ^ 2 ≤ ((68719927 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((169 : ℝ) / 100)) 2]
    have hx : RB |5 * ((169 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((149 : ℝ) / 250) ((477 : ℝ) / 800) := by
      have hz : ((149 : ℝ) / 250) ≤ 5 * ((169 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 5 * ((169 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((477 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((68719927 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((169 : ℝ) / 100)) ^ 2 ≤ ((21543251 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (6 * ((169 : ℝ) / 100)) 3]
    have hx : RB |6 * ((169 : ℝ) / 100) - (3 : ℝ) * π| ((447 : ℝ) / 625) ((1431 : ℝ) / 2000) := by
      have hz : ((447 : ℝ) / 625) ≤ 6 * ((169 : ℝ) / 100) - (3 : ℝ) * π ∧ 6 * ((169 : ℝ) / 100) - (3 : ℝ) * π ≤ ((1431 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21543251 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((169 : ℝ) / 100)) ^ 2 ≤ ((9034839 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (7 * ((169 : ℝ) / 100)) 4]
    have hx : RB |7 * ((169 : ℝ) / 100) - (4 : ℝ) * π| ((92 : ℝ) / 125) ((1841 : ℝ) / 2500) := by
      have hz : ((-1841 : ℝ) / 2500) ≤ 7 * ((169 : ℝ) / 100) - (4 : ℝ) * π ∧ 7 * ((169 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-92 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9034839 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((169 : ℝ) / 100)) ^ 2 ≤ ((66808987 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((169 : ℝ) / 100)) 4]
    have hx : RB |8 * ((169 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((2467 : ℝ) / 4000) ((1543 : ℝ) / 2500) := by
      have hz : ((-1543 : ℝ) / 2500) ≤ 8 * ((169 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 8 * ((169 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-2467 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((66808987 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((169 : ℝ) / 100)) ^ 2 ≤ ((22827747 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((169 : ℝ) / 100)) 5]
    have hx : RB |9 * ((169 : ℝ) / 100) - (5 : ℝ) * π| ((199 : ℝ) / 400) ((249 : ℝ) / 500) := by
      have hz : ((-249 : ℝ) / 500) ≤ 9 * ((169 : ℝ) / 100) - (5 : ℝ) * π ∧ 9 * ((169 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-199 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22827747 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((169 : ℝ) / 100)) ^ 2 ≤ ((17280737 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (10 * ((169 : ℝ) / 100)) 5]
    have hx : RB |10 * ((169 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((1513 : ℝ) / 4000) ((947 : ℝ) / 2500) := by
      have hz : ((-947 : ℝ) / 2500) ≤ 10 * ((169 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 10 * ((169 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-1513 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17280737 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((169 : ℝ) / 100)) ^ 2 ≤ ((6590317 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((169 : ℝ) / 100)) 6]
    have hx : RB |11 * ((169 : ℝ) / 100) - (6 : ℝ) * π| ((259 : ℝ) / 1000) ((649 : ℝ) / 2500) := by
      have hz : ((-649 : ℝ) / 2500) ≤ 11 * ((169 : ℝ) / 100) - (6 : ℝ) * π ∧ 11 * ((169 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-259 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6590317 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((169 : ℝ) / 100)) ^ 2 ≤ ((49030269 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((169 : ℝ) / 100)) 6]
    have hx : RB |12 * ((169 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((559 : ℝ) / 4000) ((351 : ℝ) / 2500) := by
      have hz : ((-351 : ℝ) / 2500) ≤ 12 * ((169 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 12 * ((169 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-559 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49030269 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((169 : ℝ) / 100) n) ≤ ((36432681 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((12399437 : ℝ) / 20000000) ≤ Real.log (π / ((169 : ℝ) / 100)) := by
    apply cov_log_2647.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((169 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_37 : ((8026251 : ℝ) / 100000000) ≤ hfun ((283 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((283 : ℝ) / 100)) ^ 2 ≤ ((9399853 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((283 : ℝ) / 100)) 1]
    have hx : RB |1 * ((283 : ℝ) / 100) - (1 : ℝ) * π| ((623 : ℝ) / 2000) ((779 : ℝ) / 2500) := by
      have hz : ((-779 : ℝ) / 2500) ≤ 1 * ((283 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((283 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-623 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9399853 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((283 : ℝ) / 100)) ^ 2 ≤ ((2130427 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (2 * ((283 : ℝ) / 100)) 2]
    have hx : RB |2 * ((283 : ℝ) / 100) - (2 : ℝ) * π| ((623 : ℝ) / 1000) ((779 : ℝ) / 1250) := by
      have hz : ((-779 : ℝ) / 1250) ≤ 2 * ((283 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((283 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-623 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2130427 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((283 : ℝ) / 100)) ^ 2 ≤ ((32504947 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((283 : ℝ) / 100)) 2]
    have hx : RB |3 * ((283 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((159 : ℝ) / 250) ((509 : ℝ) / 800) := by
      have hz : ((159 : ℝ) / 250) ≤ 3 * ((283 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((283 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((509 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((32504947 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((283 : ℝ) / 100)) ^ 2 ≤ ((44931561 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (4 * ((283 : ℝ) / 100)) 3]
    have hx : RB |4 * ((283 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((811 : ℝ) / 2500) ((1299 : ℝ) / 4000) := by
      have hz : ((811 : ℝ) / 2500) ≤ 4 * ((283 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((283 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((1299 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44931561 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((283 : ℝ) / 100)) ^ 2 ≤ ((99983617 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((283 : ℝ) / 100)) 4]
    have hx : RB |5 * ((283 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((8 : ℝ) / 625) ((53 : ℝ) / 4000) := by
      have hz : ((8 : ℝ) / 625) ≤ 5 * ((283 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((283 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((53 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99983617 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((283 : ℝ) / 100)) ^ 2 ≤ ((22845467 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (6 * ((283 : ℝ) / 100)) 5]
    have hx : RB |6 * ((283 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((1193 : ℝ) / 4000) ((747 : ℝ) / 2500) := by
      have hz : ((-747 : ℝ) / 2500) ≤ 6 * ((283 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((283 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-1193 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22845467 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((283 : ℝ) / 100)) ^ 2 ≤ ((33729377 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (7 * ((283 : ℝ) / 100)) 6]
    have hx : RB |7 * ((283 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((2439 : ℝ) / 4000) ((763 : ℝ) / 1250) := by
      have hz : ((-763 : ℝ) / 1250) ≤ 7 * ((283 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((283 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-2439 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((33729377 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((283 : ℝ) / 100)) ^ 2 ≤ ((9154801 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (8 * ((283 : ℝ) / 100)) 7]
    have hx : RB |8 * ((283 : ℝ) / 100) - (7 : ℝ) * π| ((811 : ℝ) / 1250) ((1299 : ℝ) / 2000) := by
      have hz : ((811 : ℝ) / 1250) ≤ 8 * ((283 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((283 : ℝ) / 100) - (7 : ℝ) * π ≤ ((1299 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9154801 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((283 : ℝ) / 100)) ^ 2 ≤ ((2199887 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (9 * ((283 : ℝ) / 100)) 8]
    have hx : RB |9 * ((283 : ℝ) / 100) - (8 : ℝ) * π| ((843 : ℝ) / 2500) ((169 : ℝ) / 500) := by
      have hz : ((843 : ℝ) / 2500) ≤ 9 * ((283 : ℝ) / 100) - (8 : ℝ) * π ∧ 9 * ((283 : ℝ) / 100) - (8 : ℝ) * π ≤ ((169 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2199887 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((283 : ℝ) / 100)) ^ 2 ≤ ((70211 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((283 : ℝ) / 100)) 9]
    have hx : RB |10 * ((283 : ℝ) / 100) - (9 : ℝ) * π| ((16 : ℝ) / 625) ((53 : ℝ) / 2000) := by
      have hz : ((16 : ℝ) / 625) ≤ 10 * ((283 : ℝ) / 100) - (9 : ℝ) * π ∧ 10 * ((283 : ℝ) / 100) - (9 : ℝ) * π ≤ ((53 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((70211 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((283 : ℝ) / 100)) ^ 2 ≤ ((7961481 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((283 : ℝ) / 100)) 10]
    have hx : RB |11 * ((283 : ℝ) / 100) - (10 : ℝ) * π| ((57 : ℝ) / 200) ((143 : ℝ) / 500) := by
      have hz : ((-143 : ℝ) / 500) ≤ 11 * ((283 : ℝ) / 100) - (10 : ℝ) * π ∧ 11 * ((283 : ℝ) / 100) - (10 : ℝ) * π ≤ ((-57 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7961481 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((283 : ℝ) / 100)) ^ 2 ≤ ((15847803 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((283 : ℝ) / 100)) 11]
    have hx : RB |12 * ((283 : ℝ) / 100) - (11 : ℝ) * π| ((1193 : ℝ) / 2000) ((747 : ℝ) / 1250) := by
      have hz : ((-747 : ℝ) / 1250) ≤ 12 * ((283 : ℝ) / 100) - (11 : ℝ) * π ∧ 12 * ((283 : ℝ) / 100) - (11 : ℝ) * π ≤ ((-1193 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15847803 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((283 : ℝ) / 100) n) ≤ ((2372761 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((10442367 : ℝ) / 100000000) ≤ Real.log (π / ((283 : ℝ) / 100)) := by
    apply cov_log_2648.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((283 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_38 : ((1649383 : ℝ) / 20000000) ≤ hfun ((141 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((141 : ℝ) / 50)) ^ 2 ≤ ((9991663 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((141 : ℝ) / 50)) 1]
    have hx : RB |1 * ((141 : ℝ) / 50) - (1 : ℝ) * π| ((643 : ℝ) / 2000) ((201 : ℝ) / 625) := by
      have hz : ((-201 : ℝ) / 625) ≤ 1 * ((141 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((141 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-643 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9991663 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((141 : ℝ) / 50)) ^ 2 ≤ ((35999149 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((141 : ℝ) / 50)) 2]
    have hx : RB |2 * ((141 : ℝ) / 50) - (2 : ℝ) * π| ((643 : ℝ) / 1000) ((402 : ℝ) / 625) := by
      have hz : ((-402 : ℝ) / 625) ≤ 2 * ((141 : ℝ) / 50) - (2 : ℝ) * π ∧ 2 * ((141 : ℝ) / 50) - (2 : ℝ) * π ≤ ((-643 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((35999149 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((141 : ℝ) / 50)) ^ 2 ≤ ((67801667 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((141 : ℝ) / 50)) 2]
    have hx : RB |3 * ((141 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((303 : ℝ) / 500) ((97 : ℝ) / 160) := by
      have hz : ((303 : ℝ) / 500) ≤ 3 * ((141 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 3 * ((141 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((97 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((67801667 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((141 : ℝ) / 50)) ^ 2 ≤ ((92140943 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((141 : ℝ) / 50)) 3]
    have hx : RB |4 * ((141 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((711 : ℝ) / 2500) ((1139 : ℝ) / 4000) := by
      have hz : ((711 : ℝ) / 2500) ≤ 4 * ((141 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 4 * ((141 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((1139 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((92140943 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((141 : ℝ) / 50)) ^ 2 ≤ ((9986501 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (5 * ((141 : ℝ) / 50)) 4]
    have hx : RB |5 * ((141 : ℝ) / 50) - ((9 : ℝ) / 2) * π| ((147 : ℝ) / 4000) ((93 : ℝ) / 2500) := by
      have hz : ((-93 : ℝ) / 2500) ≤ 5 * ((141 : ℝ) / 50) - ((9 : ℝ) / 2) * π ∧ 5 * ((141 : ℝ) / 50) - ((9 : ℝ) / 2) * π ≤ ((-147 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9986501 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((141 : ℝ) / 50)) ^ 2 ≤ ((10967391 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (6 * ((141 : ℝ) / 50)) 5]
    have hx : RB |6 * ((141 : ℝ) / 50) - ((11 : ℝ) / 2) * π| ((1433 : ℝ) / 4000) ((897 : ℝ) / 2500) := by
      have hz : ((-897 : ℝ) / 2500) ≤ 6 * ((141 : ℝ) / 50) - ((11 : ℝ) / 2) * π ∧ 6 * ((141 : ℝ) / 50) - ((11 : ℝ) / 2) * π ≤ ((-1433 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10967391 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((141 : ℝ) / 50)) ^ 2 ≤ ((12172129 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (7 * ((141 : ℝ) / 50)) 6]
    have hx : RB |7 * ((141 : ℝ) / 50) - ((13 : ℝ) / 2) * π| ((2719 : ℝ) / 4000) ((1701 : ℝ) / 2500) := by
      have hz : ((-1701 : ℝ) / 2500) ≤ 7 * ((141 : ℝ) / 50) - ((13 : ℝ) / 2) * π ∧ 7 * ((141 : ℝ) / 50) - ((13 : ℝ) / 2) * π ≤ ((-2719 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12172129 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((141 : ℝ) / 50)) ^ 2 ≤ ((29098267 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((141 : ℝ) / 50)) 7]
    have hx : RB |8 * ((141 : ℝ) / 50) - (7 : ℝ) * π| ((711 : ℝ) / 1250) ((1139 : ℝ) / 2000) := by
      have hz : ((711 : ℝ) / 1250) ≤ 8 * ((141 : ℝ) / 50) - (7 : ℝ) * π ∧ 8 * ((141 : ℝ) / 50) - (7 : ℝ) * π ≤ ((1139 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((29098267 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((141 : ℝ) / 50)) ^ 2 ≤ ((301331 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (9 * ((141 : ℝ) / 50)) 8]
    have hx : RB |9 * ((141 : ℝ) / 50) - (8 : ℝ) * π| ((309 : ℝ) / 1250) ((31 : ℝ) / 125) := by
      have hz : ((309 : ℝ) / 1250) ≤ 9 * ((141 : ℝ) / 50) - (8 : ℝ) * π ∧ 9 * ((141 : ℝ) / 50) - (8 : ℝ) * π ≤ ((31 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((301331 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((141 : ℝ) / 50)) ^ 2 ≤ ((552553 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((141 : ℝ) / 50)) 9]
    have hx : RB |10 * ((141 : ℝ) / 50) - (9 : ℝ) * π| ((147 : ℝ) / 2000) ((93 : ℝ) / 1250) := by
      have hz : ((-93 : ℝ) / 1250) ≤ 10 * ((141 : ℝ) / 50) - (9 : ℝ) * π ∧ 10 * ((141 : ℝ) / 50) - (9 : ℝ) * π ≤ ((-147 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((552553 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((141 : ℝ) / 50)) ^ 2 ≤ ((297723 : ℝ) / 2000000) := by
    rw [sin_sq_shift_pi (11 * ((141 : ℝ) / 50)) 10]
    have hx : RB |11 * ((141 : ℝ) / 50) - (10 : ℝ) * π| ((79 : ℝ) / 200) ((99 : ℝ) / 250) := by
      have hz : ((-99 : ℝ) / 250) ≤ 11 * ((141 : ℝ) / 50) - (10 : ℝ) * π ∧ 11 * ((141 : ℝ) / 50) - (10 : ℝ) * π ≤ ((-79 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((297723 : ℝ) / 2000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((141 : ℝ) / 50)) ^ 2 ≤ ((43322419 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((141 : ℝ) / 50)) 11]
    have hx : RB |12 * ((141 : ℝ) / 50) - (11 : ℝ) * π| ((1433 : ℝ) / 2000) ((897 : ℝ) / 1250) := by
      have hz : ((-897 : ℝ) / 1250) ≤ 12 * ((141 : ℝ) / 50) - (11 : ℝ) * π ∧ 12 * ((141 : ℝ) / 50) - (11 : ℝ) * π ≤ ((-1433 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((43322419 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((141 : ℝ) / 50) n) ≤ ((626443 : ℝ) / 25000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((215927 : ℝ) / 2000000) ≤ Real.log (π / ((141 : ℝ) / 50)) := by
    apply cov_log_2649.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((141 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_39 : ((1058179 : ℝ) / 12500000) ≤ hfun ((281 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((281 : ℝ) / 100)) ^ 2 ≤ ((165617 : ℝ) / 1562500) := by
    rw [sin_sq_shift_pi (1 * ((281 : ℝ) / 100)) 1]
    have hx : RB |1 * ((281 : ℝ) / 100) - (1 : ℝ) * π| ((663 : ℝ) / 2000) ((829 : ℝ) / 2500) := by
      have hz : ((-829 : ℝ) / 2500) ≤ 1 * ((281 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((281 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-663 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((165617 : ℝ) / 1562500) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((281 : ℝ) / 100)) ^ 2 ≤ ((37934589 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((281 : ℝ) / 100)) 2]
    have hx : RB |2 * ((281 : ℝ) / 100) - (2 : ℝ) * π| ((663 : ℝ) / 1000) ((829 : ℝ) / 1250) := by
      have hz : ((-829 : ℝ) / 1250) ≤ 2 * ((281 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((281 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-663 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((37934589 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((281 : ℝ) / 100)) ^ 2 ≤ ((70535651 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((281 : ℝ) / 100)) 2]
    have hx : RB |3 * ((281 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((72 : ℝ) / 125) ((461 : ℝ) / 800) := by
      have hz : ((72 : ℝ) / 125) ≤ 3 * ((281 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((281 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((461 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((70535651 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((281 : ℝ) / 100)) ^ 2 ≤ ((47076163 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (4 * ((281 : ℝ) / 100)) 3]
    have hx : RB |4 * ((281 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((611 : ℝ) / 2500) ((979 : ℝ) / 4000) := by
      have hz : ((611 : ℝ) / 2500) ≤ 4 * ((281 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((281 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((979 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47076163 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((281 : ℝ) / 100)) ^ 2 ≤ ((4962473 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (5 * ((281 : ℝ) / 100)) 4]
    have hx : RB |5 * ((281 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((347 : ℝ) / 4000) ((109 : ℝ) / 1250) := by
      have hz : ((-109 : ℝ) / 1250) ≤ 5 * ((281 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((281 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-347 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4962473 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((281 : ℝ) / 100)) ^ 2 ≤ ((10445551 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (6 * ((281 : ℝ) / 100)) 5]
    have hx : RB |6 * ((281 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((1673 : ℝ) / 4000) ((1047 : ℝ) / 2500) := by
      have hz : ((-1047 : ℝ) / 2500) ≤ 6 * ((281 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((281 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-1673 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10445551 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((281 : ℝ) / 100)) ^ 2 ≤ ((27044493 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (7 * ((281 : ℝ) / 100)) 6]
    have hx : RB |7 * ((281 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((2999 : ℝ) / 4000) ((469 : ℝ) / 625) := by
      have hz : ((-469 : ℝ) / 625) ≤ 7 * ((281 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 7 * ((281 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-2999 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((27044493 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((281 : ℝ) / 100)) ^ 2 ≤ ((22119769 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((281 : ℝ) / 100)) 7]
    have hx : RB |8 * ((281 : ℝ) / 100) - (7 : ℝ) * π| ((611 : ℝ) / 1250) ((979 : ℝ) / 2000) := by
      have hz : ((611 : ℝ) / 1250) ≤ 8 * ((281 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((281 : ℝ) / 100) - (7 : ℝ) * π ≤ ((979 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22119769 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((281 : ℝ) / 100)) ^ 2 ≤ ((1238007 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (9 * ((281 : ℝ) / 100)) 8]
    have hx : RB |9 * ((281 : ℝ) / 100) - (8 : ℝ) * π| ((393 : ℝ) / 2500) ((79 : ℝ) / 500) := by
      have hz : ((393 : ℝ) / 2500) ≤ 9 * ((281 : ℝ) / 100) - (8 : ℝ) * π ∧ 9 * ((281 : ℝ) / 100) - (8 : ℝ) * π ≤ ((79 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1238007 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((281 : ℝ) / 100)) ^ 2 ≤ ((3011307 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((281 : ℝ) / 100)) 9]
    have hx : RB |10 * ((281 : ℝ) / 100) - (9 : ℝ) * π| ((347 : ℝ) / 2000) ((109 : ℝ) / 625) := by
      have hz : ((-109 : ℝ) / 625) ≤ 10 * ((281 : ℝ) / 100) - (9 : ℝ) * π ∧ 10 * ((281 : ℝ) / 100) - (9 : ℝ) * π ≤ ((-347 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3011307 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((281 : ℝ) / 100)) ^ 2 ≤ ((23509611 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((281 : ℝ) / 100)) 10]
    have hx : RB |11 * ((281 : ℝ) / 100) - (10 : ℝ) * π| ((101 : ℝ) / 200) ((253 : ℝ) / 500) := by
      have hz : ((-253 : ℝ) / 500) ≤ 11 * ((281 : ℝ) / 100) - (10 : ℝ) * π ∧ 11 * ((281 : ℝ) / 100) - (10 : ℝ) * π ≤ ((-101 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23509611 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((281 : ℝ) / 100)) ^ 2 ≤ ((55703399 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((281 : ℝ) / 100)) 10]
    have hx : RB |12 * ((281 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((1833 : ℝ) / 2500) ((2937 : ℝ) / 4000) := by
      have hz : ((1833 : ℝ) / 2500) ≤ 12 * ((281 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 12 * ((281 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((2937 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((55703399 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((281 : ℝ) / 100) n) ≤ ((330273 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1115159 : ℝ) / 10000000) ≤ Real.log (π / ((281 : ℝ) / 100)) := by
    apply cov_log_2650.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((281 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_40 : ((4341079 : ℝ) / 50000000) ≤ hfun ((14 : ℝ) / 5) := by
  have s1 : Real.sin (1 * ((14 : ℝ) / 5)) ^ 2 ≤ ((701443 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (1 * ((14 : ℝ) / 5)) 1]
    have hx : RB |1 * ((14 : ℝ) / 5) - (1 : ℝ) * π| ((683 : ℝ) / 2000) ((427 : ℝ) / 1250) := by
      have hz : ((-427 : ℝ) / 1250) ≤ 1 * ((14 : ℝ) / 5) - (1 : ℝ) * π ∧ 1 * ((14 : ℝ) / 5) - (1 : ℝ) * π ≤ ((-683 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((701443 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((14 : ℝ) / 5)) ^ 2 ≤ ((39890147 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((14 : ℝ) / 5)) 2]
    have hx : RB |2 * ((14 : ℝ) / 5) - (2 : ℝ) * π| ((683 : ℝ) / 1000) ((427 : ℝ) / 625) := by
      have hz : ((-427 : ℝ) / 625) ≤ 2 * ((14 : ℝ) / 5) - (2 : ℝ) * π ∧ 2 * ((14 : ℝ) / 5) - (2 : ℝ) * π ≤ ((-683 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((39890147 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((14 : ℝ) / 5)) ^ 2 ≤ ((73201593 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((14 : ℝ) / 5)) 2]
    have hx : RB |3 * ((14 : ℝ) / 5) - ((5 : ℝ) / 2) * π| ((273 : ℝ) / 500) ((437 : ℝ) / 800) := by
      have hz : ((273 : ℝ) / 500) ≤ 3 * ((14 : ℝ) / 5) - ((5 : ℝ) / 2) * π ∧ 3 * ((14 : ℝ) / 5) - ((5 : ℝ) / 2) * π ≤ ((437 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((73201593 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((14 : ℝ) / 5)) ^ 2 ≤ ((23970907 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (4 * ((14 : ℝ) / 5)) 3]
    have hx : RB |4 * ((14 : ℝ) / 5) - ((7 : ℝ) / 2) * π| ((511 : ℝ) / 2500) ((819 : ℝ) / 4000) := by
      have hz : ((511 : ℝ) / 2500) ≤ 4 * ((14 : ℝ) / 5) - ((7 : ℝ) / 2) * π ∧ 4 * ((14 : ℝ) / 5) - ((7 : ℝ) / 2) * π ≤ ((819 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23970907 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((14 : ℝ) / 5)) ^ 2 ≤ ((12267793 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (5 * ((14 : ℝ) / 5)) 4]
    have hx : RB |5 * ((14 : ℝ) / 5) - ((9 : ℝ) / 2) * π| ((547 : ℝ) / 4000) ((343 : ℝ) / 2500) := by
      have hz : ((-343 : ℝ) / 2500) ≤ 5 * ((14 : ℝ) / 5) - ((9 : ℝ) / 2) * π ∧ 5 * ((14 : ℝ) / 5) - ((9 : ℝ) / 2) * π ≤ ((-547 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12267793 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((14 : ℝ) / 5)) ^ 2 ≤ ((78921143 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((14 : ℝ) / 5)) 5]
    have hx : RB |6 * ((14 : ℝ) / 5) - ((11 : ℝ) / 2) * π| ((1913 : ℝ) / 4000) ((1197 : ℝ) / 2500) := by
      have hz : ((-1197 : ℝ) / 2500) ≤ 6 * ((14 : ℝ) / 5) - ((11 : ℝ) / 2) * π ∧ 6 * ((14 : ℝ) / 5) - ((11 : ℝ) / 2) * π ≤ ((-1913 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((78921143 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((14 : ℝ) / 5)) ^ 2 ≤ ((23321981 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((14 : ℝ) / 5)) 6]
    have hx : RB |7 * ((14 : ℝ) / 5) - (6 : ℝ) * π| ((469 : ℝ) / 625) ((751 : ℝ) / 1000) := by
      have hz : ((469 : ℝ) / 625) ≤ 7 * ((14 : ℝ) / 5) - (6 : ℝ) * π ∧ 7 * ((14 : ℝ) / 5) - (6 : ℝ) * π ≤ ((751 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23321981 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((14 : ℝ) / 5)) ^ 2 ≤ ((126869 : ℝ) / 800000) := by
    rw [sin_sq_shift_pi (8 * ((14 : ℝ) / 5)) 7]
    have hx : RB |8 * ((14 : ℝ) / 5) - (7 : ℝ) * π| ((511 : ℝ) / 1250) ((819 : ℝ) / 2000) := by
      have hz : ((511 : ℝ) / 1250) ≤ 8 * ((14 : ℝ) / 5) - (7 : ℝ) * π ∧ 8 * ((14 : ℝ) / 5) - (7 : ℝ) * π ≤ ((819 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((126869 : ℝ) / 800000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((14 : ℝ) / 5)) ^ 2 ≤ ((461713 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((14 : ℝ) / 5)) 8]
    have hx : RB |9 * ((14 : ℝ) / 5) - (8 : ℝ) * π| ((42 : ℝ) / 625) ((17 : ℝ) / 250) := by
      have hz : ((42 : ℝ) / 625) ≤ 9 * ((14 : ℝ) / 5) - (8 : ℝ) * π ∧ 9 * ((14 : ℝ) / 5) - (8 : ℝ) * π ≤ ((17 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((461713 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((14 : ℝ) / 5)) ^ 2 ≤ ((229513 : ℝ) / 3125000) := by
    rw [sin_sq_shift_pi (10 * ((14 : ℝ) / 5)) 9]
    have hx : RB |10 * ((14 : ℝ) / 5) - (9 : ℝ) * π| ((547 : ℝ) / 2000) ((343 : ℝ) / 1250) := by
      have hz : ((-343 : ℝ) / 1250) ≤ 10 * ((14 : ℝ) / 5) - (9 : ℝ) * π ∧ 10 * ((14 : ℝ) / 5) - (9 : ℝ) * π ≤ ((-547 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((229513 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((14 : ℝ) / 5)) ^ 2 ≤ ((16711073 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (11 * ((14 : ℝ) / 5)) 10]
    have hx : RB |11 * ((14 : ℝ) / 5) - (10 : ℝ) * π| ((123 : ℝ) / 200) ((77 : ℝ) / 125) := by
      have hz : ((-77 : ℝ) / 125) ≤ 11 * ((14 : ℝ) / 5) - (10 : ℝ) * π ∧ 11 * ((14 : ℝ) / 5) - (10 : ℝ) * π ≤ ((-123 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16711073 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((14 : ℝ) / 5)) ^ 2 ≤ ((67142839 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((14 : ℝ) / 5)) 10]
    have hx : RB |12 * ((14 : ℝ) / 5) - ((21 : ℝ) / 2) * π| ((1533 : ℝ) / 2500) ((2457 : ℝ) / 4000) := by
      have hz : ((1533 : ℝ) / 2500) ≤ 12 * ((14 : ℝ) / 5) - ((21 : ℝ) / 2) * π ∧ 12 * ((14 : ℝ) / 5) - ((21 : ℝ) / 2) * π ≤ ((2457 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((67142839 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((14 : ℝ) / 5) n) ≤ ((55633 : ℝ) / 2000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((11508097 : ℝ) / 100000000) ≤ Real.log (π / ((14 : ℝ) / 5)) := by
    apply cov_log_2651.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((14 : ℝ) / 5)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_41 : ((8896723 : ℝ) / 100000000) ≤ hfun ((279 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((279 : ℝ) / 100)) ^ 2 ≤ ((11862213 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((279 : ℝ) / 100)) 1]
    have hx : RB |1 * ((279 : ℝ) / 100) - (1 : ℝ) * π| ((703 : ℝ) / 2000) ((879 : ℝ) / 2500) := by
      have hz : ((-879 : ℝ) / 2500) ≤ 1 * ((279 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((279 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-703 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11862213 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((279 : ℝ) / 100)) ^ 2 ≤ ((10465699 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (2 * ((279 : ℝ) / 100)) 2]
    have hx : RB |2 * ((279 : ℝ) / 100) - (2 : ℝ) * π| ((703 : ℝ) / 1000) ((879 : ℝ) / 1250) := by
      have hz : ((-879 : ℝ) / 1250) ≤ 2 * ((279 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((279 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-703 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10465699 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((279 : ℝ) / 100)) ^ 2 ≤ ((18947367 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (3 * ((279 : ℝ) / 100)) 2]
    have hx : RB |3 * ((279 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((129 : ℝ) / 250) ((413 : ℝ) / 800) := by
      have hz : ((129 : ℝ) / 250) ≤ 3 * ((279 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((279 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((413 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18947367 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((279 : ℝ) / 100)) ^ 2 ≤ ((97323097 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((279 : ℝ) / 100)) 3]
    have hx : RB |4 * ((279 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((411 : ℝ) / 2500) ((659 : ℝ) / 4000) := by
      have hz : ((411 : ℝ) / 2500) ≤ 4 * ((279 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((279 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((659 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((97323097 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((279 : ℝ) / 100)) ^ 2 ≤ ((48277711 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (5 * ((279 : ℝ) / 100)) 4]
    have hx : RB |5 * ((279 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((747 : ℝ) / 4000) ((117 : ℝ) / 625) := by
      have hz : ((-117 : ℝ) / 625) ≤ 5 * ((279 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((279 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-747 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((48277711 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((279 : ℝ) / 100)) ^ 2 ≤ ((73879683 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((279 : ℝ) / 100)) 5]
    have hx : RB |6 * ((279 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((2153 : ℝ) / 4000) ((1347 : ℝ) / 2500) := by
      have hz : ((-1347 : ℝ) / 2500) ≤ 6 * ((279 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((279 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-2153 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((73879683 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((279 : ℝ) / 100)) ^ 2 ≤ ((4960727 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (7 * ((279 : ℝ) / 100)) 6]
    have hx : RB |7 * ((279 : ℝ) / 100) - (6 : ℝ) * π| ((1701 : ℝ) / 2500) ((681 : ℝ) / 1000) := by
      have hz : ((1701 : ℝ) / 2500) ≤ 7 * ((279 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((279 : ℝ) / 100) - (6 : ℝ) * π ≤ ((681 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4960727 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((279 : ℝ) / 100)) ^ 2 ≤ ((10472631 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((279 : ℝ) / 100)) 7]
    have hx : RB |8 * ((279 : ℝ) / 100) - (7 : ℝ) * π| ((411 : ℝ) / 1250) ((659 : ℝ) / 2000) := by
      have hz : ((411 : ℝ) / 1250) ≤ 8 * ((279 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((279 : ℝ) / 100) - (7 : ℝ) * π ≤ ((659 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10472631 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((279 : ℝ) / 100)) ^ 2 ≤ ((6497 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (9 * ((279 : ℝ) / 100)) 8]
    have hx : RB |9 * ((279 : ℝ) / 100) - (8 : ℝ) * π| ((11 : ℝ) / 500) ((57 : ℝ) / 2500) := by
      have hz : ((-57 : ℝ) / 2500) ≤ 9 * ((279 : ℝ) / 100) - (8 : ℝ) * π ∧ 9 * ((279 : ℝ) / 100) - (8 : ℝ) * π ≤ ((-11 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6497 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((279 : ℝ) / 100)) ^ 2 ≤ ((66901 : ℝ) / 500000) := by
    rw [sin_sq_shift_pi (10 * ((279 : ℝ) / 100)) 9]
    have hx : RB |10 * ((279 : ℝ) / 100) - (9 : ℝ) * π| ((747 : ℝ) / 2000) ((234 : ℝ) / 625) := by
      have hz : ((-234 : ℝ) / 625) ≤ 10 * ((279 : ℝ) / 100) - (9 : ℝ) * π ∧ 10 * ((279 : ℝ) / 100) - (9 : ℝ) * π ≤ ((-747 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((66901 : ℝ) / 500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((279 : ℝ) / 100)) ^ 2 ≤ ((2207827 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (11 * ((279 : ℝ) / 100)) 10]
    have hx : RB |11 * ((279 : ℝ) / 100) - (10 : ℝ) * π| ((29 : ℝ) / 40) ((363 : ℝ) / 500) := by
      have hz : ((-363 : ℝ) / 500) ≤ 11 * ((279 : ℝ) / 100) - (10 : ℝ) * π ∧ 11 * ((279 : ℝ) / 100) - (10 : ℝ) * π ≤ ((-29 : ℝ) / 40) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2207827 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((279 : ℝ) / 100)) ^ 2 ≤ ((38850783 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((279 : ℝ) / 100)) 10]
    have hx : RB |12 * ((279 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((1233 : ℝ) / 2500) ((1977 : ℝ) / 4000) := by
      have hz : ((1233 : ℝ) / 2500) ≤ 12 * ((279 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 12 * ((279 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((1977 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((38850783 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((279 : ℝ) / 100) n) ≤ ((2924549 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((11865879 : ℝ) / 100000000) ≤ Real.log (π / ((279 : ℝ) / 100)) := by
    apply cov_log_2652.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((279 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_42 : ((1821863 : ℝ) / 20000000) ≤ hfun ((139 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((139 : ℝ) / 50)) ^ 2 ≤ ((12516611 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((139 : ℝ) / 50)) 1]
    have hx : RB |1 * ((139 : ℝ) / 50) - (1 : ℝ) * π| ((723 : ℝ) / 2000) ((226 : ℝ) / 625) := by
      have hz : ((-226 : ℝ) / 625) ≤ 1 * ((139 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((139 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-723 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12516611 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((139 : ℝ) / 50)) ^ 2 ≤ ((2740593 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (2 * ((139 : ℝ) / 50)) 2]
    have hx : RB |2 * ((139 : ℝ) / 50) - (2 : ℝ) * π| ((723 : ℝ) / 1000) ((452 : ℝ) / 625) := by
      have hz : ((-452 : ℝ) / 625) ≤ 2 * ((139 : ℝ) / 50) - (2 : ℝ) * π ∧ 2 * ((139 : ℝ) / 50) - (2 : ℝ) * π ≤ ((-723 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2740593 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((139 : ℝ) / 50)) ^ 2 ≤ ((39144759 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((139 : ℝ) / 50)) 2]
    have hx : RB |3 * ((139 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((243 : ℝ) / 500) ((389 : ℝ) / 800) := by
      have hz : ((243 : ℝ) / 500) ≤ 3 * ((139 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 3 * ((139 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((389 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((39144759 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((139 : ℝ) / 50)) ^ 2 ≤ ((19692191 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (4 * ((139 : ℝ) / 50)) 3]
    have hx : RB |4 * ((139 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((311 : ℝ) / 2500) ((499 : ℝ) / 4000) := by
      have hz : ((311 : ℝ) / 2500) ≤ 4 * ((139 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 4 * ((139 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((499 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19692191 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((139 : ℝ) / 50)) ^ 2 ≤ ((4725277 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (5 * ((139 : ℝ) / 50)) 4]
    have hx : RB |5 * ((139 : ℝ) / 50) - ((9 : ℝ) / 2) * π| ((947 : ℝ) / 4000) ((593 : ℝ) / 2500) := by
      have hz : ((-593 : ℝ) / 2500) ≤ 5 * ((139 : ℝ) / 50) - ((9 : ℝ) / 2) * π ∧ 5 * ((139 : ℝ) / 50) - ((9 : ℝ) / 2) * π ≤ ((-947 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4725277 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((139 : ℝ) / 50)) ^ 2 ≤ ((34258059 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (6 * ((139 : ℝ) / 50)) 5]
    have hx : RB |6 * ((139 : ℝ) / 50) - ((11 : ℝ) / 2) * π| ((2393 : ℝ) / 4000) ((1497 : ℝ) / 2500) := by
      have hz : ((-1497 : ℝ) / 2500) ≤ 6 * ((139 : ℝ) / 50) - ((11 : ℝ) / 2) * π ∧ 6 * ((139 : ℝ) / 50) - ((11 : ℝ) / 2) * π ≤ ((-2393 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((34258059 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((139 : ℝ) / 50)) ^ 2 ≤ ((16470753 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((139 : ℝ) / 50)) 6]
    have hx : RB |7 * ((139 : ℝ) / 50) - (6 : ℝ) * π| ((763 : ℝ) / 1250) ((611 : ℝ) / 1000) := by
      have hz : ((763 : ℝ) / 1250) ≤ 7 * ((139 : ℝ) / 50) - (6 : ℝ) * π ∧ 7 * ((139 : ℝ) / 50) - (6 : ℝ) * π ≤ ((611 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16470753 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((139 : ℝ) / 50)) ^ 2 ≤ ((1524519 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (8 * ((139 : ℝ) / 50)) 7]
    have hx : RB |8 * ((139 : ℝ) / 50) - (7 : ℝ) * π| ((311 : ℝ) / 1250) ((499 : ℝ) / 2000) := by
      have hz : ((311 : ℝ) / 1250) ≤ 8 * ((139 : ℝ) / 50) - (7 : ℝ) * π ∧ 8 * ((139 : ℝ) / 50) - (7 : ℝ) * π ≤ ((499 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1524519 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((139 : ℝ) / 50)) ^ 2 ≤ ((158389 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (9 * ((139 : ℝ) / 50)) 8]
    have hx : RB |9 * ((139 : ℝ) / 50) - (8 : ℝ) * π| ((14 : ℝ) / 125) ((141 : ℝ) / 1250) := by
      have hz : ((-141 : ℝ) / 1250) ≤ 9 * ((139 : ℝ) / 50) - (8 : ℝ) * π ∧ 9 * ((139 : ℝ) / 50) - (8 : ℝ) * π ≤ ((-14 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((158389 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((139 : ℝ) / 50)) ^ 2 ≤ ((2610007 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (10 * ((139 : ℝ) / 50)) 9]
    have hx : RB |10 * ((139 : ℝ) / 50) - (9 : ℝ) * π| ((947 : ℝ) / 2000) ((593 : ℝ) / 1250) := by
      have hz : ((-593 : ℝ) / 1250) ≤ 10 * ((139 : ℝ) / 50) - (9 : ℝ) * π ∧ 10 * ((139 : ℝ) / 50) - (9 : ℝ) * π ≤ ((-947 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2610007 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((139 : ℝ) / 50)) ^ 2 ≤ ((55546729 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((139 : ℝ) / 50)) 9]
    have hx : RB |11 * ((139 : ℝ) / 50) - ((19 : ℝ) / 2) * π| ((1837 : ℝ) / 2500) ((2943 : ℝ) / 4000) := by
      have hz : ((1837 : ℝ) / 2500) ≤ 11 * ((139 : ℝ) / 50) - ((19 : ℝ) / 2) * π ∧ 11 * ((139 : ℝ) / 50) - ((19 : ℝ) / 2) * π ≤ ((2943 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((55546729 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((139 : ℝ) / 50)) ^ 2 ≤ ((86747361 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((139 : ℝ) / 50)) 10]
    have hx : RB |12 * ((139 : ℝ) / 50) - ((21 : ℝ) / 2) * π| ((933 : ℝ) / 2500) ((1497 : ℝ) / 4000) := by
      have hz : ((933 : ℝ) / 2500) ≤ 12 * ((139 : ℝ) / 50) - ((21 : ℝ) / 2) * π ∧ 12 * ((139 : ℝ) / 50) - ((21 : ℝ) / 2) * π ≤ ((1497 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((86747361 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((139 : ℝ) / 50) n) ≤ ((1535351 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((6112473 : ℝ) / 50000000) ≤ Real.log (π / ((139 : ℝ) / 50)) := by
    apply cov_log_2653.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((139 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_43 : ((233003 : ℝ) / 2500000) ≤ hfun ((277 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((277 : ℝ) / 100)) ^ 2 ≤ ((659301 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (1 * ((277 : ℝ) / 100)) 1]
    have hx : RB |1 * ((277 : ℝ) / 100) - (1 : ℝ) * π| ((743 : ℝ) / 2000) ((929 : ℝ) / 2500) := by
      have hz : ((-929 : ℝ) / 2500) ≤ 1 * ((277 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((277 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-743 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((659301 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((277 : ℝ) / 100)) ^ 2 ≤ ((11461791 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (2 * ((277 : ℝ) / 100)) 2]
    have hx : RB |2 * ((277 : ℝ) / 100) - (2 : ℝ) * π| ((743 : ℝ) / 1000) ((929 : ℝ) / 1250) := by
      have hz : ((-929 : ℝ) / 1250) ≤ 2 * ((277 : ℝ) / 100) - (2 : ℝ) * π ∧ 2 * ((277 : ℝ) / 100) - (2 : ℝ) * π ≤ ((-743 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11461791 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((277 : ℝ) / 100)) ^ 2 ≤ ((80692293 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((277 : ℝ) / 100)) 2]
    have hx : RB |3 * ((277 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((57 : ℝ) / 125) ((73 : ℝ) / 160) := by
      have hz : ((57 : ℝ) / 125) ≤ 3 * ((277 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((277 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((73 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((80692293 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((277 : ℝ) / 100)) ^ 2 ≤ ((99289469 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((277 : ℝ) / 100)) 3]
    have hx : RB |4 * ((277 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((211 : ℝ) / 2500) ((339 : ℝ) / 4000) := by
      have hz : ((211 : ℝ) / 2500) ≤ 4 * ((277 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((277 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((339 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99289469 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((277 : ℝ) / 100)) ^ 2 ≤ ((2300361 : ℝ) / 2500000) := by
    rw [sin_sq_shift_half_pi (5 * ((277 : ℝ) / 100)) 4]
    have hx : RB |5 * ((277 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((1147 : ℝ) / 4000) ((359 : ℝ) / 1250) := by
      have hz : ((-359 : ℝ) / 1250) ≤ 5 * ((277 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((277 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-1147 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2300361 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((277 : ℝ) / 100)) ^ 2 ≤ ((62910987 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((277 : ℝ) / 100)) 5]
    have hx : RB |6 * ((277 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((2633 : ℝ) / 4000) ((1647 : ℝ) / 2500) := by
      have hz : ((-1647 : ℝ) / 2500) ≤ 6 * ((277 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 6 * ((277 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-2633 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((62910987 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((277 : ℝ) / 100)) ^ 2 ≤ ((26539093 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((277 : ℝ) / 100)) 6]
    have hx : RB |7 * ((277 : ℝ) / 100) - (6 : ℝ) * π| ((1351 : ℝ) / 2500) ((541 : ℝ) / 1000) := by
      have hz : ((1351 : ℝ) / 2500) ≤ 7 * ((277 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((277 : ℝ) / 100) - (6 : ℝ) * π ≤ ((541 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((26539093 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((277 : ℝ) / 100)) ^ 2 ≤ ((1422981 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (8 * ((277 : ℝ) / 100)) 7]
    have hx : RB |8 * ((277 : ℝ) / 100) - (7 : ℝ) * π| ((211 : ℝ) / 1250) ((339 : ℝ) / 2000) := by
      have hz : ((211 : ℝ) / 1250) ≤ 8 * ((277 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((277 : ℝ) / 100) - (7 : ℝ) * π ≤ ((339 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1422981 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((277 : ℝ) / 100)) ^ 2 ≤ ((4057393 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((277 : ℝ) / 100)) 8]
    have hx : RB |9 * ((277 : ℝ) / 100) - (8 : ℝ) * π| ((101 : ℝ) / 500) ((507 : ℝ) / 2500) := by
      have hz : ((-507 : ℝ) / 2500) ≤ 9 * ((277 : ℝ) / 100) - (8 : ℝ) * π ∧ 9 * ((277 : ℝ) / 100) - (8 : ℝ) * π ≤ ((-101 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4057393 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((277 : ℝ) / 100)) ^ 2 ≤ ((738719 : ℝ) / 2500000) := by
    rw [sin_sq_shift_pi (10 * ((277 : ℝ) / 100)) 9]
    have hx : RB |10 * ((277 : ℝ) / 100) - (9 : ℝ) * π| ((1147 : ℝ) / 2000) ((359 : ℝ) / 625) := by
      have hz : ((-359 : ℝ) / 625) ≤ 10 * ((277 : ℝ) / 100) - (9 : ℝ) * π ∧ 10 * ((277 : ℝ) / 100) - (9 : ℝ) * π ≤ ((-1147 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((738719 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((277 : ℝ) / 100)) ^ 2 ≤ ((8258007 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (11 * ((277 : ℝ) / 100)) 9]
    have hx : RB |11 * ((277 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((781 : ℝ) / 1250) ((2503 : ℝ) / 4000) := by
      have hz : ((781 : ℝ) / 1250) ≤ 11 * ((277 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 11 * ((277 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((2503 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8258007 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((277 : ℝ) / 100)) ^ 2 ≤ ((93733867 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((277 : ℝ) / 100)) 10]
    have hx : RB |12 * ((277 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((633 : ℝ) / 2500) ((1017 : ℝ) / 4000) := by
      have hz : ((633 : ℝ) / 2500) ≤ 12 * ((277 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 12 * ((277 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((1017 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((93733867 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((277 : ℝ) / 100) n) ≤ ((804983 : ℝ) / 25000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((6292653 : ℝ) / 50000000) ≤ Real.log (π / ((277 : ℝ) / 100)) := by
    apply cov_log_2654.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((277 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_44 : ((4764581 : ℝ) / 50000000) ≤ hfun ((69 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((69 : ℝ) / 25)) ^ 2 ≤ ((13870177 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((69 : ℝ) / 25)) 1]
    have hx : RB |1 * ((69 : ℝ) / 25) - (1 : ℝ) * π| ((763 : ℝ) / 2000) ((477 : ℝ) / 1250) := by
      have hz : ((-477 : ℝ) / 1250) ≤ 1 * ((69 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((69 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-763 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13870177 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((69 : ℝ) / 25)) ^ 2 ≤ ((47852757 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((69 : ℝ) / 25)) 2]
    have hx : RB |2 * ((69 : ℝ) / 25) - (2 : ℝ) * π| ((763 : ℝ) / 1000) ((477 : ℝ) / 625) := by
      have hz : ((-477 : ℝ) / 625) ≤ 2 * ((69 : ℝ) / 25) - (2 : ℝ) * π ∧ 2 * ((69 : ℝ) / 25) - (2 : ℝ) * π ≤ ((-763 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47852757 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((69 : ℝ) / 25)) ^ 2 ≤ ((82988697 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((69 : ℝ) / 25)) 2]
    have hx : RB |3 * ((69 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((213 : ℝ) / 500) ((341 : ℝ) / 800) := by
      have hz : ((213 : ℝ) / 500) ≤ 3 * ((69 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 3 * ((69 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((341 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((82988697 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((69 : ℝ) / 25)) ^ 2 ≤ ((99803003 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((69 : ℝ) / 25)) 3]
    have hx : RB |4 * ((69 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((111 : ℝ) / 2500) ((179 : ℝ) / 4000) := by
      have hz : ((111 : ℝ) / 2500) ≤ 4 * ((69 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 4 * ((69 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((179 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99803003 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((69 : ℝ) / 25)) ^ 2 ≤ ((44554259 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (5 * ((69 : ℝ) / 25)) 4]
    have hx : RB |5 * ((69 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((1347 : ℝ) / 4000) ((843 : ℝ) / 2500) := by
      have hz : ((-843 : ℝ) / 2500) ≤ 5 * ((69 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 5 * ((69 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((-1347 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44554259 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((69 : ℝ) / 25)) ^ 2 ≤ ((14286971 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (6 * ((69 : ℝ) / 25)) 5]
    have hx : RB |6 * ((69 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((2873 : ℝ) / 4000) ((1797 : ℝ) / 2500) := by
      have hz : ((-1797 : ℝ) / 2500) ≤ 6 * ((69 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 6 * ((69 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((-2873 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14286971 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((69 : ℝ) / 25)) ^ 2 ≤ ((10300523 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((69 : ℝ) / 25)) 6]
    have hx : RB |7 * ((69 : ℝ) / 25) - (6 : ℝ) * π| ((294 : ℝ) / 625) ((471 : ℝ) / 1000) := by
      have hz : ((294 : ℝ) / 625) ≤ 7 * ((69 : ℝ) / 25) - (6 : ℝ) * π ∧ 7 * ((69 : ℝ) / 25) - (6 : ℝ) * π ≤ ((471 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10300523 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((69 : ℝ) / 25)) ^ 2 ≤ ((798939 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((69 : ℝ) / 25)) 7]
    have hx : RB |8 * ((69 : ℝ) / 25) - (7 : ℝ) * π| ((111 : ℝ) / 1250) ((179 : ℝ) / 2000) := by
      have hz : ((111 : ℝ) / 1250) ≤ 8 * ((69 : ℝ) / 25) - (7 : ℝ) * π ∧ 8 * ((69 : ℝ) / 25) - (7 : ℝ) * π ≤ ((179 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((798939 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((69 : ℝ) / 25)) ^ 2 ≤ ((8333153 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((69 : ℝ) / 25)) 8]
    have hx : RB |9 * ((69 : ℝ) / 25) - (8 : ℝ) * π| ((73 : ℝ) / 250) ((183 : ℝ) / 625) := by
      have hz : ((-183 : ℝ) / 625) ≤ 9 * ((69 : ℝ) / 25) - (8 : ℝ) * π ∧ 9 * ((69 : ℝ) / 25) - (8 : ℝ) * π ≤ ((-73 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8333153 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((69 : ℝ) / 25)) ^ 2 ≤ ((9761819 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (10 * ((69 : ℝ) / 25)) 9]
    have hx : RB |10 * ((69 : ℝ) / 25) - (9 : ℝ) * π| ((1347 : ℝ) / 2000) ((843 : ℝ) / 1250) := by
      have hz : ((-843 : ℝ) / 1250) ≤ 10 * ((69 : ℝ) / 25) - (9 : ℝ) * π ∧ 10 * ((69 : ℝ) / 25) - (9 : ℝ) * π ≤ ((-1347 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9761819 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((69 : ℝ) / 25)) ^ 2 ≤ ((75894699 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((69 : ℝ) / 25)) 9]
    have hx : RB |11 * ((69 : ℝ) / 25) - ((19 : ℝ) / 2) * π| ((1287 : ℝ) / 2500) ((2063 : ℝ) / 4000) := by
      have hz : ((1287 : ℝ) / 2500) ≤ 11 * ((69 : ℝ) / 25) - ((19 : ℝ) / 2) * π ∧ 11 * ((69 : ℝ) / 25) - ((19 : ℝ) / 2) * π ≤ ((2063 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((75894699 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((69 : ℝ) / 25)) ^ 2 ≤ ((98237 : ℝ) / 100000) := by
    rw [sin_sq_shift_half_pi (12 * ((69 : ℝ) / 25)) 10]
    have hx : RB |12 * ((69 : ℝ) / 25) - ((21 : ℝ) / 2) * π| ((333 : ℝ) / 2500) ((537 : ℝ) / 4000) := by
      have hz : ((333 : ℝ) / 2500) ≤ 12 * ((69 : ℝ) / 25) - ((21 : ℝ) / 2) * π ∧ 12 * ((69 : ℝ) / 25) - ((21 : ℝ) / 2) * π ≤ ((537 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((98237 : ℝ) / 100000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((69 : ℝ) / 25) n) ≤ ((1686113 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1294697 : ℝ) / 10000000) ≤ Real.log (π / ((69 : ℝ) / 25)) := by
    apply cov_log_2655.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((69 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_45 : ((9736533 : ℝ) / 100000000) ≤ hfun ((11 : ℝ) / 4) := by
  have s1 : Real.sin (1 * ((11 : ℝ) / 4)) ^ 2 ≤ ((1821101 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (1 * ((11 : ℝ) / 4)) 1]
    have hx : RB |1 * ((11 : ℝ) / 4) - (1 : ℝ) * π| ((783 : ℝ) / 2000) ((979 : ℝ) / 2500) := by
      have hz : ((-979 : ℝ) / 2500) ≤ 1 * ((11 : ℝ) / 4) - (1 : ℝ) * π ∧ 1 * ((11 : ℝ) / 4) - (1 : ℝ) * π ≤ ((-783 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1821101 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((11 : ℝ) / 4)) ^ 2 ≤ ((49863197 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (2 * ((11 : ℝ) / 4)) 2]
    have hx : RB |2 * ((11 : ℝ) / 4) - (2 : ℝ) * π| ((783 : ℝ) / 1000) ((979 : ℝ) / 1250) := by
      have hz : ((-979 : ℝ) / 1250) ≤ 2 * ((11 : ℝ) / 4) - (2 : ℝ) * π ∧ 2 * ((11 : ℝ) / 4) - (2 : ℝ) * π ≤ ((-783 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49863197 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((11 : ℝ) / 4)) ^ 2 ≤ ((42585009 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((11 : ℝ) / 4)) 2]
    have hx : RB |3 * ((11 : ℝ) / 4) - ((5 : ℝ) / 2) * π| ((99 : ℝ) / 250) ((317 : ℝ) / 800) := by
      have hz : ((99 : ℝ) / 250) ≤ 3 * ((11 : ℝ) / 4) - ((5 : ℝ) / 2) * π ∧ 3 * ((11 : ℝ) / 4) - ((5 : ℝ) / 2) * π ≤ ((317 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42585009 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((11 : ℝ) / 4)) ^ 2 ≤ ((19999613 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (4 * ((11 : ℝ) / 4)) 3]
    have hx : RB |4 * ((11 : ℝ) / 4) - ((7 : ℝ) / 2) * π| ((11 : ℝ) / 2500) ((19 : ℝ) / 4000) := by
      have hz : ((11 : ℝ) / 2500) ≤ 4 * ((11 : ℝ) / 4) - ((7 : ℝ) / 2) * π ∧ 4 * ((11 : ℝ) / 4) - ((7 : ℝ) / 2) * π ≤ ((19 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19999613 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((11 : ℝ) / 4)) ^ 2 ≤ ((85818529 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((11 : ℝ) / 4)) 4]
    have hx : RB |5 * ((11 : ℝ) / 4) - ((9 : ℝ) / 2) * π| ((1547 : ℝ) / 4000) ((242 : ℝ) / 625) := by
      have hz : ((-242 : ℝ) / 625) ≤ 5 * ((11 : ℝ) / 4) - ((9 : ℝ) / 2) * π ∧ 5 * ((11 : ℝ) / 4) - ((9 : ℝ) / 2) * π ≤ ((-1547 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((85818529 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((11 : ℝ) / 4)) ^ 2 ≤ ((6413997 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (6 * ((11 : ℝ) / 4)) 5]
    have hx : RB |6 * ((11 : ℝ) / 4) - ((11 : ℝ) / 2) * π| ((3113 : ℝ) / 4000) ((1947 : ℝ) / 2500) := by
      have hz : ((-1947 : ℝ) / 2500) ≤ 6 * ((11 : ℝ) / 4) - ((11 : ℝ) / 2) * π ∧ 6 * ((11 : ℝ) / 4) - ((11 : ℝ) / 2) * π ≤ ((-3113 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6413997 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((11 : ℝ) / 4)) ^ 2 ≤ ((7620803 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((11 : ℝ) / 4)) 6]
    have hx : RB |7 * ((11 : ℝ) / 4) - (6 : ℝ) * π| ((1001 : ℝ) / 2500) ((401 : ℝ) / 1000) := by
      have hz : ((1001 : ℝ) / 2500) ≤ 7 * ((11 : ℝ) / 4) - (6 : ℝ) * π ∧ 7 * ((11 : ℝ) / 4) - (6 : ℝ) * π ≤ ((401 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7620803 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((11 : ℝ) / 4)) ^ 2 ≤ ((361 : ℝ) / 4000000) := by
    rw [sin_sq_shift_pi (8 * ((11 : ℝ) / 4)) 7]
    have hx : RB |8 * ((11 : ℝ) / 4) - (7 : ℝ) * π| ((11 : ℝ) / 1250) ((19 : ℝ) / 2000) := by
      have hz : ((11 : ℝ) / 1250) ≤ 8 * ((11 : ℝ) / 4) - (7 : ℝ) * π ∧ 8 * ((11 : ℝ) / 4) - (7 : ℝ) * π ≤ ((19 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((361 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((11 : ℝ) / 4)) ^ 2 ≤ ((13957077 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((11 : ℝ) / 4)) 8]
    have hx : RB |9 * ((11 : ℝ) / 4) - (8 : ℝ) * π| ((191 : ℝ) / 500) ((957 : ℝ) / 2500) := by
      have hz : ((-957 : ℝ) / 2500) ≤ 9 * ((11 : ℝ) / 4) - (8 : ℝ) * π ∧ 9 * ((11 : ℝ) / 4) - (8 : ℝ) * π ≤ ((-191 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13957077 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((11 : ℝ) / 4)) ^ 2 ≤ ((6125943 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (10 * ((11 : ℝ) / 4)) 9]
    have hx : RB |10 * ((11 : ℝ) / 4) - (9 : ℝ) * π| ((1547 : ℝ) / 2000) ((484 : ℝ) / 625) := by
      have hz : ((-484 : ℝ) / 625) ≤ 10 * ((11 : ℝ) / 4) - (9 : ℝ) * π ∧ 10 * ((11 : ℝ) / 4) - (9 : ℝ) * π ≤ ((-1547 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6125943 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((11 : ℝ) / 4)) ^ 2 ≤ ((135271 : ℝ) / 160000) := by
    rw [sin_sq_shift_half_pi (11 * ((11 : ℝ) / 4)) 9]
    have hx : RB |11 * ((11 : ℝ) / 4) - ((19 : ℝ) / 2) * π| ((253 : ℝ) / 625) ((1623 : ℝ) / 4000) := by
      have hz : ((253 : ℝ) / 625) ≤ 11 * ((11 : ℝ) / 4) - ((19 : ℝ) / 2) * π ∧ 11 * ((11 : ℝ) / 4) - ((19 : ℝ) / 2) * π ≤ ((1623 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((135271 : ℝ) / 160000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((11 : ℝ) / 4)) ^ 2 ≤ ((49991289 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((11 : ℝ) / 4)) 10]
    have hx : RB |12 * ((11 : ℝ) / 4) - ((21 : ℝ) / 2) * π| ((33 : ℝ) / 2500) ((57 : ℝ) / 4000) := by
      have hz : ((33 : ℝ) / 2500) ≤ 12 * ((11 : ℝ) / 4) - ((21 : ℝ) / 2) * π ∧ 12 * ((11 : ℝ) / 4) - ((21 : ℝ) / 2) * π ≤ ((57 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49991289 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((11 : ℝ) / 4) n) ≤ ((1411 : ℝ) / 40000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((13309947 : ℝ) / 100000000) ≤ Real.log (π / ((11 : ℝ) / 4)) := by
    apply cov_log_2656.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((11 : ℝ) / 4)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_46 : ((4967457 : ℝ) / 50000000) ≤ hfun ((137 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((137 : ℝ) / 50)) ^ 2 ≤ ((7640819 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((137 : ℝ) / 50)) 1]
    have hx : RB |1 * ((137 : ℝ) / 50) - (1 : ℝ) * π| ((803 : ℝ) / 2000) ((251 : ℝ) / 625) := by
      have hz : ((-251 : ℝ) / 625) ≤ 1 * ((137 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((137 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-803 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7640819 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((137 : ℝ) / 50)) ^ 2 ≤ ((52343913 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (2 * ((137 : ℝ) / 50)) 1]
    have hx : RB |2 * ((137 : ℝ) / 50) - ((3 : ℝ) / 2) * π| ((1919 : ℝ) / 2500) ((3071 : ℝ) / 4000) := by
      have hz : ((1919 : ℝ) / 2500) ≤ 2 * ((137 : ℝ) / 50) - ((3 : ℝ) / 2) * π ∧ 2 * ((137 : ℝ) / 50) - ((3 : ℝ) / 2) * π ≤ ((3071 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((52343913 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((137 : ℝ) / 50)) ^ 2 ≤ ((8722797 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (3 * ((137 : ℝ) / 50)) 2]
    have hx : RB |3 * ((137 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((183 : ℝ) / 500) ((293 : ℝ) / 800) := by
      have hz : ((183 : ℝ) / 500) ≤ 3 * ((137 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 3 * ((137 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((293 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8722797 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((137 : ℝ) / 50)) ^ 2 ≤ ((499379 : ℝ) / 500000) := by
    rw [sin_sq_shift_half_pi (4 * ((137 : ℝ) / 50)) 3]
    have hx : RB |4 * ((137 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((141 : ℝ) / 4000) ((89 : ℝ) / 2500) := by
      have hz : ((-89 : ℝ) / 2500) ≤ 4 * ((137 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 4 * ((137 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((-141 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((499379 : ℝ) / 500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((137 : ℝ) / 50)) ^ 2 ≤ ((20544809 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (5 * ((137 : ℝ) / 50)) 4]
    have hx : RB |5 * ((137 : ℝ) / 50) - ((9 : ℝ) / 2) * π| ((1747 : ℝ) / 4000) ((1093 : ℝ) / 2500) := by
      have hz : ((-1093 : ℝ) / 2500) ≤ 5 * ((137 : ℝ) / 50) - ((9 : ℝ) / 2) * π ∧ 5 * ((137 : ℝ) / 50) - ((9 : ℝ) / 2) * π ≤ ((-1747 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((20544809 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((137 : ℝ) / 50)) ^ 2 ≤ ((44787989 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((137 : ℝ) / 50)) 5]
    have hx : RB |6 * ((137 : ℝ) / 50) - (5 : ℝ) * π| ((183 : ℝ) / 250) ((293 : ℝ) / 400) := by
      have hz : ((183 : ℝ) / 250) ≤ 6 * ((137 : ℝ) / 50) - (5 : ℝ) * π ∧ 6 * ((137 : ℝ) / 50) - (5 : ℝ) * π ≤ ((293 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44787989 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((137 : ℝ) / 50)) ^ 2 ≤ ((2641087 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (7 * ((137 : ℝ) / 50)) 6]
    have hx : RB |7 * ((137 : ℝ) / 50) - (6 : ℝ) * π| ((413 : ℝ) / 1250) ((331 : ℝ) / 1000) := by
      have hz : ((413 : ℝ) / 1250) ≤ 7 * ((137 : ℝ) / 50) - (6 : ℝ) * π ∧ 7 * ((137 : ℝ) / 50) - (6 : ℝ) * π ≤ ((331 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2641087 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((137 : ℝ) / 50)) ^ 2 ≤ ((506113 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((137 : ℝ) / 50)) 7]
    have hx : RB |8 * ((137 : ℝ) / 50) - (7 : ℝ) * π| ((141 : ℝ) / 2000) ((89 : ℝ) / 1250) := by
      have hz : ((-89 : ℝ) / 1250) ≤ 8 * ((137 : ℝ) / 50) - (7 : ℝ) * π ∧ 8 * ((137 : ℝ) / 50) - (7 : ℝ) * π ≤ ((-141 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((506113 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((137 : ℝ) / 50)) ^ 2 ≤ ((2074899 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (9 * ((137 : ℝ) / 50)) 8]
    have hx : RB |9 * ((137 : ℝ) / 50) - (8 : ℝ) * π| ((59 : ℝ) / 125) ((591 : ℝ) / 1250) := by
      have hz : ((-591 : ℝ) / 1250) ≤ 9 * ((137 : ℝ) / 50) - (8 : ℝ) * π ∧ 9 * ((137 : ℝ) / 50) - (8 : ℝ) * π ≤ ((-59 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2074899 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((137 : ℝ) / 50)) ^ 2 ≤ ((59262803 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((137 : ℝ) / 50)) 8]
    have hx : RB |10 * ((137 : ℝ) / 50) - ((17 : ℝ) / 2) * π| ((1741 : ℝ) / 2500) ((2789 : ℝ) / 4000) := by
      have hz : ((1741 : ℝ) / 2500) ≤ 10 * ((137 : ℝ) / 50) - ((17 : ℝ) / 2) * π ∧ 10 * ((137 : ℝ) / 50) - ((17 : ℝ) / 2) * π ≤ ((2789 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((59262803 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((137 : ℝ) / 50)) ^ 2 ≤ ((18314873 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (11 * ((137 : ℝ) / 50)) 9]
    have hx : RB |11 * ((137 : ℝ) / 50) - ((19 : ℝ) / 2) * π| ((737 : ℝ) / 2500) ((1183 : ℝ) / 4000) := by
      have hz : ((737 : ℝ) / 2500) ≤ 11 * ((137 : ℝ) / 50) - ((19 : ℝ) / 2) * π ∧ 11 * ((137 : ℝ) / 50) - ((19 : ℝ) / 2) * π ≤ ((1183 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18314873 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((137 : ℝ) / 50)) ^ 2 ≤ ((12360771 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (12 * ((137 : ℝ) / 50)) 10]
    have hx : RB |12 * ((137 : ℝ) / 50) - ((21 : ℝ) / 2) * π| ((423 : ℝ) / 4000) ((267 : ℝ) / 2500) := by
      have hz : ((-267 : ℝ) / 2500) ≤ 12 * ((137 : ℝ) / 50) - ((21 : ℝ) / 2) * π ∧ 12 * ((137 : ℝ) / 50) - ((21 : ℝ) / 2) * π ≤ ((-423 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12360771 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((137 : ℝ) / 50) n) ≤ ((1846541 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((6837123 : ℝ) / 50000000) ≤ Real.log (π / ((137 : ℝ) / 50)) := by
    apply cov_log_2657.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((137 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_47 : ((10140367 : ℝ) / 100000000) ≤ hfun ((273 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((273 : ℝ) / 100)) ^ 2 ≤ ((16008383 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((273 : ℝ) / 100)) 1]
    have hx : RB |1 * ((273 : ℝ) / 100) - (1 : ℝ) * π| ((823 : ℝ) / 2000) ((1029 : ℝ) / 2500) := by
      have hz : ((-1029 : ℝ) / 2500) ≤ 1 * ((273 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((273 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-823 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16008383 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((273 : ℝ) / 100)) ^ 2 ≤ ((1696619 : ℝ) / 3125000) := by
    rw [sin_sq_shift_half_pi (2 * ((273 : ℝ) / 100)) 1]
    have hx : RB |2 * ((273 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((1869 : ℝ) / 2500) ((2991 : ℝ) / 4000) := by
      have hz : ((1869 : ℝ) / 2500) ≤ 2 * ((273 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((273 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((2991 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1696619 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((273 : ℝ) / 100)) ^ 2 ≤ ((89154727 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((273 : ℝ) / 100)) 2]
    have hx : RB |3 * ((273 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((42 : ℝ) / 125) ((269 : ℝ) / 800) := by
      have hz : ((42 : ℝ) / 125) ≤ 3 * ((273 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((273 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((269 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((89154727 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((273 : ℝ) / 100)) ^ 2 ≤ ((19886977 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (4 * ((273 : ℝ) / 100)) 3]
    have hx : RB |4 * ((273 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((301 : ℝ) / 4000) ((189 : ℝ) / 2500) := by
      have hz : ((-189 : ℝ) / 2500) ≤ 4 * ((273 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((273 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-301 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19886977 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((273 : ℝ) / 100)) ^ 2 ≤ ((15645803 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (5 * ((273 : ℝ) / 100)) 4]
    have hx : RB |5 * ((273 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((1947 : ℝ) / 4000) ((609 : ℝ) / 1250) := by
      have hz : ((-609 : ℝ) / 1250) ≤ 5 * ((273 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((273 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-1947 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15645803 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((273 : ℝ) / 100)) ^ 2 ≤ ((9712513 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((273 : ℝ) / 100)) 5]
    have hx : RB |6 * ((273 : ℝ) / 100) - (5 : ℝ) * π| ((84 : ℝ) / 125) ((269 : ℝ) / 400) := by
      have hz : ((84 : ℝ) / 125) ≤ 6 * ((273 : ℝ) / 100) - (5 : ℝ) * π ∧ 6 * ((273 : ℝ) / 100) - (5 : ℝ) * π ≤ ((269 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9712513 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((273 : ℝ) / 100)) ^ 2 ≤ ((3329987 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((273 : ℝ) / 100)) 6]
    have hx : RB |7 * ((273 : ℝ) / 100) - (6 : ℝ) * π| ((651 : ℝ) / 2500) ((261 : ℝ) / 1000) := by
      have hz : ((651 : ℝ) / 2500) ≤ 7 * ((273 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((273 : ℝ) / 100) - (6 : ℝ) * π ≤ ((261 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3329987 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((273 : ℝ) / 100)) ^ 2 ≤ ((113451 : ℝ) / 5000000) := by
    rw [sin_sq_shift_pi (8 * ((273 : ℝ) / 100)) 7]
    have hx : RB |8 * ((273 : ℝ) / 100) - (7 : ℝ) * π| ((301 : ℝ) / 2000) ((189 : ℝ) / 1250) := by
      have hz : ((-189 : ℝ) / 1250) ≤ 8 * ((273 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((273 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-301 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((113451 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((273 : ℝ) / 100)) ^ 2 ≤ ((7123043 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (9 * ((273 : ℝ) / 100)) 8]
    have hx : RB |9 * ((273 : ℝ) / 100) - (8 : ℝ) * π| ((281 : ℝ) / 500) ((1407 : ℝ) / 2500) := by
      have hz : ((-1407 : ℝ) / 2500) ≤ 9 * ((273 : ℝ) / 100) - (8 : ℝ) * π ∧ 9 * ((273 : ℝ) / 100) - (8 : ℝ) * π ≤ ((-281 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7123043 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((273 : ℝ) / 100)) ^ 2 ≤ ((17171933 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (10 * ((273 : ℝ) / 100)) 8]
    have hx : RB |10 * ((273 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((1491 : ℝ) / 2500) ((2389 : ℝ) / 4000) := by
      have hz : ((1491 : ℝ) / 2500) ≤ 10 * ((273 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 10 * ((273 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((2389 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17171933 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((273 : ℝ) / 100)) ^ 2 ≤ ((96626243 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((273 : ℝ) / 100)) 9]
    have hx : RB |11 * ((273 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((231 : ℝ) / 1250) ((743 : ℝ) / 4000) := by
      have hz : ((231 : ℝ) / 1250) ≤ 11 * ((273 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 11 * ((273 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((743 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((96626243 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((273 : ℝ) / 100)) ^ 2 ≤ ((47497743 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (12 * ((273 : ℝ) / 100)) 10]
    have hx : RB |12 * ((273 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((903 : ℝ) / 4000) ((567 : ℝ) / 2500) := by
      have hz : ((-567 : ℝ) / 2500) ≤ 12 * ((273 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 12 * ((273 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((-903 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47497743 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((273 : ℝ) / 100) n) ≤ ((1926461 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((7019939 : ℝ) / 50000000) ≤ Real.log (π / ((273 : ℝ) / 100)) := by
    apply cov_log_2658.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((273 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_48 : ((5172197 : ℝ) / 50000000) ≤ hfun ((68 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((68 : ℝ) / 25)) ^ 2 ≤ ((3349751 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (1 * ((68 : ℝ) / 25)) 1]
    have hx : RB |1 * ((68 : ℝ) / 25) - (1 : ℝ) * π| ((843 : ℝ) / 2000) ((527 : ℝ) / 1250) := by
      have hz : ((-527 : ℝ) / 1250) ≤ 1 * ((68 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((68 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-843 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3349751 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((68 : ℝ) / 25)) ^ 2 ≤ ((11247251 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (2 * ((68 : ℝ) / 25)) 1]
    have hx : RB |2 * ((68 : ℝ) / 25) - ((3 : ℝ) / 2) * π| ((1819 : ℝ) / 2500) ((2911 : ℝ) / 4000) := by
      have hz : ((1819 : ℝ) / 2500) ≤ 2 * ((68 : ℝ) / 25) - ((3 : ℝ) / 2) * π ∧ 2 * ((68 : ℝ) / 25) - ((3 : ℝ) / 2) * π ≤ ((2911 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11247251 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((68 : ℝ) / 25)) ^ 2 ≤ ((90942953 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((68 : ℝ) / 25)) 2]
    have hx : RB |3 * ((68 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((153 : ℝ) / 500) ((49 : ℝ) / 160) := by
      have hz : ((153 : ℝ) / 500) ≤ 3 * ((68 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 3 * ((68 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((49 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((90942953 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((68 : ℝ) / 25)) ^ 2 ≤ ((98678003 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((68 : ℝ) / 25)) 3]
    have hx : RB |4 * ((68 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((461 : ℝ) / 4000) ((289 : ℝ) / 2500) := by
      have hz : ((-289 : ℝ) / 2500) ≤ 4 * ((68 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 4 * ((68 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((-461 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((98678003 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((68 : ℝ) / 25)) ^ 2 ≤ ((9251177 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (5 * ((68 : ℝ) / 25)) 4]
    have hx : RB |5 * ((68 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((2147 : ℝ) / 4000) ((1343 : ℝ) / 2500) := by
      have hz : ((-1343 : ℝ) / 2500) ≤ 5 * ((68 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 5 * ((68 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((-2147 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9251177 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((68 : ℝ) / 25)) ^ 2 ≤ ((33080737 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((68 : ℝ) / 25)) 5]
    have hx : RB |6 * ((68 : ℝ) / 25) - (5 : ℝ) * π| ((153 : ℝ) / 250) ((49 : ℝ) / 80) := by
      have hz : ((153 : ℝ) / 250) ≤ 6 * ((68 : ℝ) / 25) - (5 : ℝ) * π ∧ 6 * ((68 : ℝ) / 25) - (5 : ℝ) * π ≤ ((49 : ℝ) / 80) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((33080737 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((68 : ℝ) / 25)) ^ 2 ≤ ((112637 : ℝ) / 3125000) := by
    rw [sin_sq_shift_pi (7 * ((68 : ℝ) / 25)) 6]
    have hx : RB |7 * ((68 : ℝ) / 25) - (6 : ℝ) * π| ((119 : ℝ) / 625) ((191 : ℝ) / 1000) := by
      have hz : ((119 : ℝ) / 625) ≤ 7 * ((68 : ℝ) / 25) - (6 : ℝ) * π ∧ 7 * ((68 : ℝ) / 25) - (6 : ℝ) * π ≤ ((191 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((112637 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((68 : ℝ) / 25)) ^ 2 ≤ ((1312921 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (8 * ((68 : ℝ) / 25)) 7]
    have hx : RB |8 * ((68 : ℝ) / 25) - (7 : ℝ) * π| ((461 : ℝ) / 2000) ((289 : ℝ) / 1250) := by
      have hz : ((-289 : ℝ) / 1250) ≤ 8 * ((68 : ℝ) / 25) - (7 : ℝ) * π ∧ 8 * ((68 : ℝ) / 25) - (7 : ℝ) * π ≤ ((-461 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1312921 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((68 : ℝ) / 25)) ^ 2 ≤ ((18470487 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (9 * ((68 : ℝ) / 25)) 8]
    have hx : RB |9 * ((68 : ℝ) / 25) - (8 : ℝ) * π| ((163 : ℝ) / 250) ((408 : ℝ) / 625) := by
      have hz : ((-408 : ℝ) / 625) ≤ 9 * ((68 : ℝ) / 25) - (8 : ℝ) * π ∧ 9 * ((68 : ℝ) / 25) - (8 : ℝ) * π ≤ ((-163 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18470487 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((68 : ℝ) / 25)) ^ 2 ≤ ((19359019 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (10 * ((68 : ℝ) / 25)) 8]
    have hx : RB |10 * ((68 : ℝ) / 25) - ((17 : ℝ) / 2) * π| ((1241 : ℝ) / 2500) ((1989 : ℝ) / 4000) := by
      have hz : ((1241 : ℝ) / 2500) ≤ 10 * ((68 : ℝ) / 25) - ((17 : ℝ) / 2) * π ∧ 10 * ((68 : ℝ) / 25) - ((17 : ℝ) / 2) * π ≤ ((1989 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19359019 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((68 : ℝ) / 25)) ^ 2 ≤ ((99441621 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((68 : ℝ) / 25)) 9]
    have hx : RB |11 * ((68 : ℝ) / 25) - ((19 : ℝ) / 2) * π| ((187 : ℝ) / 2500) ((303 : ℝ) / 4000) := by
      have hz : ((187 : ℝ) / 2500) ≤ 11 * ((68 : ℝ) / 25) - ((19 : ℝ) / 2) * π ∧ 11 * ((68 : ℝ) / 25) - ((19 : ℝ) / 2) * π ≤ ((303 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99441621 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((68 : ℝ) / 25)) ^ 2 ≤ ((17708937 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (12 * ((68 : ℝ) / 25)) 10]
    have hx : RB |12 * ((68 : ℝ) / 25) - ((21 : ℝ) / 2) * π| ((1383 : ℝ) / 4000) ((867 : ℝ) / 2500) := by
      have hz : ((-867 : ℝ) / 2500) ≤ 12 * ((68 : ℝ) / 25) - ((21 : ℝ) / 2) * π ∧ 12 * ((68 : ℝ) / 25) - ((21 : ℝ) / 2) * π ≤ ((-1383 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17708937 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((68 : ℝ) / 25) n) ≤ ((4015523 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((288137 : ℝ) / 2000000) ≤ Real.log (π / ((68 : ℝ) / 25)) := by
    apply cov_log_2659.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((68 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_49 : ((10547059 : ℝ) / 100000000) ≤ hfun ((271 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((271 : ℝ) / 100)) ^ 2 ≤ ((8751231 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((271 : ℝ) / 100)) 1]
    have hx : RB |1 * ((271 : ℝ) / 100) - (1 : ℝ) * π| ((863 : ℝ) / 2000) ((1079 : ℝ) / 2500) := by
      have hz : ((-1079 : ℝ) / 2500) ≤ 1 * ((271 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((271 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-863 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8751231 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((271 : ℝ) / 100)) ^ 2 ≤ ((7271761 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (2 * ((271 : ℝ) / 100)) 1]
    have hx : RB |2 * ((271 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((1769 : ℝ) / 2500) ((2831 : ℝ) / 4000) := by
      have hz : ((1769 : ℝ) / 2500) ≤ 2 * ((271 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((271 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((2831 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7271761 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((271 : ℝ) / 100)) ^ 2 ≤ ((46292917 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((271 : ℝ) / 100)) 2]
    have hx : RB |3 * ((271 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((69 : ℝ) / 250) ((221 : ℝ) / 800) := by
      have hz : ((69 : ℝ) / 250) ≤ 3 * ((271 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((271 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((221 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((46292917 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((271 : ℝ) / 100)) ^ 2 ≤ ((976103 : ℝ) / 1000000) := by
    rw [sin_sq_shift_half_pi (4 * ((271 : ℝ) / 100)) 3]
    have hx : RB |4 * ((271 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((621 : ℝ) / 4000) ((389 : ℝ) / 2500) := by
      have hz : ((-389 : ℝ) / 2500) ≤ 4 * ((271 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((271 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-621 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((976103 : ℝ) / 1000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((271 : ℝ) / 100)) ^ 2 ≤ ((69564673 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((271 : ℝ) / 100)) 4]
    have hx : RB |5 * ((271 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((2347 : ℝ) / 4000) ((367 : ℝ) / 625) := by
      have hz : ((-367 : ℝ) / 625) ≤ 5 * ((271 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((271 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-2347 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((69564673 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((271 : ℝ) / 100)) ^ 2 ≤ ((27560617 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((271 : ℝ) / 100)) 5]
    have hx : RB |6 * ((271 : ℝ) / 100) - (5 : ℝ) * π| ((69 : ℝ) / 125) ((221 : ℝ) / 400) := by
      have hz : ((69 : ℝ) / 125) ≤ 6 * ((271 : ℝ) / 100) - (5 : ℝ) * π ∧ 6 * ((271 : ℝ) / 100) - (5 : ℝ) * π ≤ ((221 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((27560617 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((271 : ℝ) / 100)) ^ 2 ≤ ((364269 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (7 * ((271 : ℝ) / 100)) 6]
    have hx : RB |7 * ((271 : ℝ) / 100) - (6 : ℝ) * π| ((301 : ℝ) / 2500) ((121 : ℝ) / 1000) := by
      have hz : ((301 : ℝ) / 2500) ≤ 7 * ((271 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((271 : ℝ) / 100) - (6 : ℝ) * π ≤ ((121 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((364269 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((271 : ℝ) / 100)) ^ 2 ≤ ((2344573 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (8 * ((271 : ℝ) / 100)) 7]
    have hx : RB |8 * ((271 : ℝ) / 100) - (7 : ℝ) * π| ((621 : ℝ) / 2000) ((389 : ℝ) / 1250) := by
      have hz : ((-389 : ℝ) / 1250) ≤ 8 * ((271 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((271 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-621 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2344573 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((271 : ℝ) / 100)) ^ 2 ≤ ((45829501 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((271 : ℝ) / 100)) 8]
    have hx : RB |9 * ((271 : ℝ) / 100) - (8 : ℝ) * π| ((371 : ℝ) / 500) ((1857 : ℝ) / 2500) := by
      have hz : ((-1857 : ℝ) / 2500) ≤ 9 * ((271 : ℝ) / 100) - (8 : ℝ) * π ∧ 9 * ((271 : ℝ) / 100) - (8 : ℝ) * π ≤ ((-371 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45829501 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((271 : ℝ) / 100)) ^ 2 ≤ ((8514317 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (10 * ((271 : ℝ) / 100)) 8]
    have hx : RB |10 * ((271 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((991 : ℝ) / 2500) ((1589 : ℝ) / 4000) := by
      have hz : ((991 : ℝ) / 2500) ≤ 10 * ((271 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 10 * ((271 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((1589 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8514317 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((271 : ℝ) / 100)) ^ 2 ≤ ((19976549 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (11 * ((271 : ℝ) / 100)) 9]
    have hx : RB |11 * ((271 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((137 : ℝ) / 4000) ((22 : ℝ) / 625) := by
      have hz : ((-22 : ℝ) / 625) ≤ 11 * ((271 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 11 * ((271 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((-137 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19976549 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((271 : ℝ) / 100)) ^ 2 ≤ ((79925649 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((271 : ℝ) / 100)) 10]
    have hx : RB |12 * ((271 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((1863 : ℝ) / 4000) ((1167 : ℝ) / 2500) := by
      have hz : ((-1167 : ℝ) / 2500) ≤ 12 * ((271 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 12 * ((271 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((-1863 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((79925649 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((271 : ℝ) / 100) n) ≤ ((1045209 : ℝ) / 25000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((591007 : ℝ) / 4000000) ≤ Real.log (π / ((271 : ℝ) / 100)) := by
    apply cov_log_2660.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((271 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_50 : ((10748337 : ℝ) / 100000000) ≤ hfun ((27 : ℝ) / 10) := by
  have s1 : Real.sin (1 * ((27 : ℝ) / 10)) ^ 2 ≤ ((9134603 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((27 : ℝ) / 10)) 1]
    have hx : RB |1 * ((27 : ℝ) / 10) - (1 : ℝ) * π| ((883 : ℝ) / 2000) ((276 : ℝ) / 625) := by
      have hz : ((-276 : ℝ) / 625) ≤ 1 * ((27 : ℝ) / 10) - (1 : ℝ) * π ∧ 1 * ((27 : ℝ) / 10) - (1 : ℝ) * π ≤ ((-883 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9134603 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((27 : ℝ) / 10)) ^ 2 ≤ ((60102137 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (2 * ((27 : ℝ) / 10)) 1]
    have hx : RB |2 * ((27 : ℝ) / 10) - ((3 : ℝ) / 2) * π| ((1719 : ℝ) / 2500) ((2751 : ℝ) / 4000) := by
      have hz : ((1719 : ℝ) / 2500) ≤ 2 * ((27 : ℝ) / 10) - ((3 : ℝ) / 2) * π ∧ 2 * ((27 : ℝ) / 10) - ((3 : ℝ) / 2) * π ≤ ((2751 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((60102137 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((27 : ℝ) / 10)) ^ 2 ≤ ((94077103 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((27 : ℝ) / 10)) 2]
    have hx : RB |3 * ((27 : ℝ) / 10) - ((5 : ℝ) / 2) * π| ((123 : ℝ) / 500) ((197 : ℝ) / 800) := by
      have hz : ((123 : ℝ) / 500) ≤ 3 * ((27 : ℝ) / 10) - ((5 : ℝ) / 2) * π ∧ 3 * ((27 : ℝ) / 10) - ((5 : ℝ) / 2) * π ≤ ((197 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94077103 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((27 : ℝ) / 10)) ^ 2 ≤ ((19247807 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (4 * ((27 : ℝ) / 10)) 3]
    have hx : RB |4 * ((27 : ℝ) / 10) - ((7 : ℝ) / 2) * π| ((781 : ℝ) / 4000) ((489 : ℝ) / 2500) := by
      have hz : ((-489 : ℝ) / 2500) ≤ 4 * ((27 : ℝ) / 10) - ((7 : ℝ) / 2) * π ∧ 4 * ((27 : ℝ) / 10) - ((7 : ℝ) / 2) * π ≤ ((-781 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19247807 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((27 : ℝ) / 10)) ^ 2 ≤ ((12988237 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (5 * ((27 : ℝ) / 10)) 4]
    have hx : RB |5 * ((27 : ℝ) / 10) - ((9 : ℝ) / 2) * π| ((2547 : ℝ) / 4000) ((1593 : ℝ) / 2500) := by
      have hz : ((-1593 : ℝ) / 2500) ≤ 5 * ((27 : ℝ) / 10) - ((9 : ℝ) / 2) * π ∧ 5 * ((27 : ℝ) / 10) - ((9 : ℝ) / 2) * π ≤ ((-2547 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12988237 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((27 : ℝ) / 10)) ^ 2 ≤ ((22367273 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((27 : ℝ) / 10)) 5]
    have hx : RB |6 * ((27 : ℝ) / 10) - (5 : ℝ) * π| ((123 : ℝ) / 250) ((197 : ℝ) / 400) := by
      have hz : ((123 : ℝ) / 250) ≤ 6 * ((27 : ℝ) / 10) - (5 : ℝ) * π ∧ 6 * ((27 : ℝ) / 10) - (5 : ℝ) * π ≤ ((197 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22367273 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((27 : ℝ) / 10)) ^ 2 ≤ ((259883 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((27 : ℝ) / 10)) 6]
    have hx : RB |7 * ((27 : ℝ) / 10) - (6 : ℝ) * π| ((63 : ℝ) / 1250) ((51 : ℝ) / 1000) := by
      have hz : ((63 : ℝ) / 1250) ≤ 7 * ((27 : ℝ) / 10) - (6 : ℝ) * π ∧ 7 * ((27 : ℝ) / 10) - (6 : ℝ) * π ≤ ((51 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((259883 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((27 : ℝ) / 10)) ^ 2 ≤ ((14544083 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((27 : ℝ) / 10)) 7]
    have hx : RB |8 * ((27 : ℝ) / 10) - (7 : ℝ) * π| ((781 : ℝ) / 2000) ((489 : ℝ) / 1250) := by
      have hz : ((-489 : ℝ) / 1250) ≤ 8 * ((27 : ℝ) / 10) - (7 : ℝ) * π ∧ 8 * ((27 : ℝ) / 10) - (7 : ℝ) * π ≤ ((-781 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14544083 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((27 : ℝ) / 10)) ^ 2 ≤ ((55233249 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((27 : ℝ) / 10)) 7]
    have hx : RB |9 * ((27 : ℝ) / 10) - ((15 : ℝ) / 2) * π| ((369 : ℝ) / 500) ((591 : ℝ) / 800) := by
      have hz : ((369 : ℝ) / 500) ≤ 9 * ((27 : ℝ) / 10) - ((15 : ℝ) / 2) * π ∧ 9 * ((27 : ℝ) / 10) - ((15 : ℝ) / 2) * π ≤ ((591 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((55233249 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((27 : ℝ) / 10)) ^ 2 ≤ ((45742713 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((27 : ℝ) / 10)) 8]
    have hx : RB |10 * ((27 : ℝ) / 10) - ((17 : ℝ) / 2) * π| ((741 : ℝ) / 2500) ((1189 : ℝ) / 4000) := by
      have hz : ((741 : ℝ) / 2500) ≤ 10 * ((27 : ℝ) / 10) - ((17 : ℝ) / 2) * π ∧ 10 * ((27 : ℝ) / 10) - ((17 : ℝ) / 2) * π ≤ ((1189 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45742713 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((27 : ℝ) / 10)) ^ 2 ≤ ((97934601 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((27 : ℝ) / 10)) 9]
    have hx : RB |11 * ((27 : ℝ) / 10) - ((19 : ℝ) / 2) * π| ((577 : ℝ) / 4000) ((363 : ℝ) / 2500) := by
      have hz : ((-363 : ℝ) / 2500) ≤ 11 * ((27 : ℝ) / 10) - ((19 : ℝ) / 2) * π ∧ 11 * ((27 : ℝ) / 10) - ((19 : ℝ) / 2) * π ≤ ((-577 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((97934601 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((27 : ℝ) / 10)) ^ 2 ≤ ((69659687 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((27 : ℝ) / 10)) 10]
    have hx : RB |12 * ((27 : ℝ) / 10) - ((21 : ℝ) / 2) * π| ((2343 : ℝ) / 4000) ((1467 : ℝ) / 2500) := by
      have hz : ((-1467 : ℝ) / 2500) ≤ 12 * ((27 : ℝ) / 10) - ((21 : ℝ) / 2) * π ∧ 12 * ((27 : ℝ) / 10) - ((21 : ℝ) / 2) * π ≤ ((-2343 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((69659687 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((27 : ℝ) / 10) n) ≤ ((2174447 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((15144861 : ℝ) / 100000000) ≤ Real.log (π / ((27 : ℝ) / 10)) := by
    apply cov_log_2661.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((27 : ℝ) / 10)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_51 : ((5474219 : ℝ) / 50000000) ≤ hfun ((269 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((269 : ℝ) / 100)) ^ 2 ≤ ((9524341 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((269 : ℝ) / 100)) 1]
    have hx : RB |1 * ((269 : ℝ) / 100) - (1 : ℝ) * π| ((903 : ℝ) / 2000) ((1129 : ℝ) / 2500) := by
      have hz : ((-1129 : ℝ) / 2500) ≤ 1 * ((269 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((269 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-903 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9524341 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((269 : ℝ) / 100)) ^ 2 ≤ ((12403447 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (2 * ((269 : ℝ) / 100)) 1]
    have hx : RB |2 * ((269 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((1669 : ℝ) / 2500) ((2671 : ℝ) / 4000) := by
      have hz : ((1669 : ℝ) / 2500) ≤ 2 * ((269 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((269 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((2671 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12403447 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((269 : ℝ) / 100)) ^ 2 ≤ ((9541107 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (3 * ((269 : ℝ) / 100)) 2]
    have hx : RB |3 * ((269 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((27 : ℝ) / 125) ((173 : ℝ) / 800) := by
      have hz : ((27 : ℝ) / 125) ≤ 3 * ((269 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((269 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((173 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9541107 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((269 : ℝ) / 100)) ^ 2 ≤ ((94573523 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((269 : ℝ) / 100)) 3]
    have hx : RB |4 * ((269 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((941 : ℝ) / 4000) ((589 : ℝ) / 2500) := by
      have hz : ((-589 : ℝ) / 2500) ≤ 4 * ((269 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((269 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-941 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((94573523 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((269 : ℝ) / 100)) ^ 2 ≤ ((60186959 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((269 : ℝ) / 100)) 4]
    have hx : RB |5 * ((269 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((2747 : ℝ) / 4000) ((859 : ℝ) / 1250) := by
      have hz : ((-859 : ℝ) / 1250) ≤ 5 * ((269 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 5 * ((269 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-2747 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((60186959 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((269 : ℝ) / 100)) ^ 2 ≤ ((2196759 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (6 * ((269 : ℝ) / 100)) 5]
    have hx : RB |6 * ((269 : ℝ) / 100) - (5 : ℝ) * π| ((54 : ℝ) / 125) ((173 : ℝ) / 400) := by
      have hz : ((54 : ℝ) / 125) ≤ 6 * ((269 : ℝ) / 100) - (5 : ℝ) * π ∧ 6 * ((269 : ℝ) / 100) - (5 : ℝ) * π ≤ ((173 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2196759 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((269 : ℝ) / 100)) ^ 2 ≤ ((9603 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (7 * ((269 : ℝ) / 100)) 6]
    have hx : RB |7 * ((269 : ℝ) / 100) - (6 : ℝ) * π| ((19 : ℝ) / 1000) ((49 : ℝ) / 2500) := by
      have hz : ((-49 : ℝ) / 2500) ≤ 7 * ((269 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((269 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-19 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9603 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((269 : ℝ) / 100)) ^ 2 ≤ ((4123649 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (8 * ((269 : ℝ) / 100)) 7]
    have hx : RB |8 * ((269 : ℝ) / 100) - (7 : ℝ) * π| ((941 : ℝ) / 2000) ((589 : ℝ) / 1250) := by
      have hz : ((-589 : ℝ) / 1250) ≤ 8 * ((269 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((269 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-941 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4123649 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((269 : ℝ) / 100)) ^ 2 ≤ ((15970969 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (9 * ((269 : ℝ) / 100)) 7]
    have hx : RB |9 * ((269 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((81 : ℝ) / 125) ((519 : ℝ) / 800) := by
      have hz : ((81 : ℝ) / 125) ≤ 9 * ((269 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 9 * ((269 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((519 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15970969 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((269 : ℝ) / 100)) ^ 2 ≤ ((96195367 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((269 : ℝ) / 100)) 8]
    have hx : RB |10 * ((269 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((491 : ℝ) / 2500) ((789 : ℝ) / 4000) := by
      have hz : ((491 : ℝ) / 2500) ≤ 10 * ((269 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 10 * ((269 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((789 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((96195367 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((269 : ℝ) / 100)) ^ 2 ≤ ((46841461 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (11 * ((269 : ℝ) / 100)) 9]
    have hx : RB |11 * ((269 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((1017 : ℝ) / 4000) ((319 : ℝ) / 1250) := by
      have hz : ((-319 : ℝ) / 1250) ≤ 11 * ((269 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 11 * ((269 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((-1017 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((46841461 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((269 : ℝ) / 100)) ^ 2 ≤ ((14590747 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (12 * ((269 : ℝ) / 100)) 10]
    have hx : RB |12 * ((269 : ℝ) / 100) - ((21 : ℝ) / 2) * π| ((2823 : ℝ) / 4000) ((1767 : ℝ) / 2500) := by
      have hz : ((-1767 : ℝ) / 2500) ≤ 12 * ((269 : ℝ) / 100) - ((21 : ℝ) / 2) * π ∧ 12 * ((269 : ℝ) / 100) - ((21 : ℝ) / 2) * π ≤ ((-2823 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14590747 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((269 : ℝ) / 100) n) ≤ ((564937 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((15515919 : ℝ) / 100000000) ≤ Real.log (π / ((269 : ℝ) / 100)) := by
    apply cov_log_2662.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((269 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_52 : ((1393413 : ℝ) / 12500000) ≤ hfun ((67 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((67 : ℝ) / 25)) ^ 2 ≤ ((19840583 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((67 : ℝ) / 25)) 1]
    have hx : RB |1 * ((67 : ℝ) / 25) - (1 : ℝ) * π| ((923 : ℝ) / 2000) ((577 : ℝ) / 1250) := by
      have hz : ((-577 : ℝ) / 1250) ≤ 1 * ((67 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((67 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-923 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19840583 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((67 : ℝ) / 25)) ^ 2 ≤ ((63916229 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (2 * ((67 : ℝ) / 25)) 1]
    have hx : RB |2 * ((67 : ℝ) / 25) - ((3 : ℝ) / 2) * π| ((1619 : ℝ) / 2500) ((2591 : ℝ) / 4000) := by
      have hz : ((1619 : ℝ) / 2500) ≤ 2 * ((67 : ℝ) / 25) - ((3 : ℝ) / 2) * π ∧ 2 * ((67 : ℝ) / 25) - ((3 : ℝ) / 2) * π ≤ ((2591 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((63916229 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((67 : ℝ) / 25)) ^ 2 ≤ ((96582641 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((67 : ℝ) / 25)) 2]
    have hx : RB |3 * ((67 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((93 : ℝ) / 500) ((149 : ℝ) / 800) := by
      have hz : ((93 : ℝ) / 500) ≤ 3 * ((67 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 3 * ((67 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((149 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((96582641 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((67 : ℝ) / 25)) ^ 2 ≤ ((5789067 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (4 * ((67 : ℝ) / 25)) 3]
    have hx : RB |4 * ((67 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((1101 : ℝ) / 4000) ((689 : ℝ) / 2500) := by
      have hz : ((-689 : ℝ) / 2500) ≤ 4 * ((67 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 4 * ((67 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((-1101 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5789067 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((67 : ℝ) / 25)) ^ 2 ≤ ((3459439 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (5 * ((67 : ℝ) / 25)) 4]
    have hx : RB |5 * ((67 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((2947 : ℝ) / 4000) ((1843 : ℝ) / 2500) := by
      have hz : ((-1843 : ℝ) / 2500) ≤ 5 * ((67 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 5 * ((67 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((-2947 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3459439 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((67 : ℝ) / 25)) ^ 2 ≤ ((3312253 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((67 : ℝ) / 25)) 5]
    have hx : RB |6 * ((67 : ℝ) / 25) - (5 : ℝ) * π| ((93 : ℝ) / 250) ((149 : ℝ) / 400) := by
      have hz : ((93 : ℝ) / 250) ≤ 6 * ((67 : ℝ) / 25) - (5 : ℝ) * π ∧ 6 * ((67 : ℝ) / 25) - (5 : ℝ) * π ≤ ((149 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3312253 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((67 : ℝ) / 25)) ^ 2 ≤ ((800713 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((67 : ℝ) / 25)) 6]
    have hx : RB |7 * ((67 : ℝ) / 25) - (6 : ℝ) * π| ((89 : ℝ) / 1000) ((56 : ℝ) / 625) := by
      have hz : ((-56 : ℝ) / 625) ≤ 7 * ((67 : ℝ) / 25) - (6 : ℝ) * π ∧ 7 * ((67 : ℝ) / 25) - (6 : ℝ) * π ≤ ((-89 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((800713 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((67 : ℝ) / 25)) ^ 2 ≤ ((13723767 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (8 * ((67 : ℝ) / 25)) 7]
    have hx : RB |8 * ((67 : ℝ) / 25) - (7 : ℝ) * π| ((1101 : ℝ) / 2000) ((689 : ℝ) / 1250) := by
      have hz : ((-689 : ℝ) / 1250) ≤ 8 * ((67 : ℝ) / 25) - (7 : ℝ) * π ∧ 8 * ((67 : ℝ) / 25) - (7 : ℝ) * π ≤ ((-1101 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13723767 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((67 : ℝ) / 25)) ^ 2 ≤ ((72147111 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (9 * ((67 : ℝ) / 25)) 7]
    have hx : RB |9 * ((67 : ℝ) / 25) - ((15 : ℝ) / 2) * π| ((279 : ℝ) / 500) ((447 : ℝ) / 800) := by
      have hz : ((279 : ℝ) / 500) ≤ 9 * ((67 : ℝ) / 25) - ((15 : ℝ) / 2) * π ∧ 9 * ((67 : ℝ) / 25) - ((15 : ℝ) / 2) * π ≤ ((447 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((72147111 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((67 : ℝ) / 25)) ^ 2 ≤ ((99073791 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((67 : ℝ) / 25)) 8]
    have hx : RB |10 * ((67 : ℝ) / 25) - ((17 : ℝ) / 2) * π| ((241 : ℝ) / 2500) ((389 : ℝ) / 4000) := by
      have hz : ((241 : ℝ) / 2500) ≤ 10 * ((67 : ℝ) / 25) - ((17 : ℝ) / 2) * π ∧ 10 * ((67 : ℝ) / 25) - ((17 : ℝ) / 2) * π ≤ ((389 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99073791 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((67 : ℝ) / 25)) ^ 2 ≤ ((17469073 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (11 * ((67 : ℝ) / 25)) 9]
    have hx : RB |11 * ((67 : ℝ) / 25) - ((19 : ℝ) / 2) * π| ((1457 : ℝ) / 4000) ((913 : ℝ) / 2500) := by
      have hz : ((-913 : ℝ) / 2500) ≤ 11 * ((67 : ℝ) / 25) - ((19 : ℝ) / 2) * π ∧ 11 * ((67 : ℝ) / 25) - ((19 : ℝ) / 2) * π ≤ ((-1457 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17469073 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((67 : ℝ) / 25)) ^ 2 ≤ ((46057469 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((67 : ℝ) / 25)) 10]
    have hx : RB |12 * ((67 : ℝ) / 25) - (10 : ℝ) * π| ((93 : ℝ) / 125) ((149 : ℝ) / 200) := by
      have hz : ((93 : ℝ) / 125) ≤ 12 * ((67 : ℝ) / 25) - (10 : ℝ) * π ∧ 12 * ((67 : ℝ) / 25) - (10 : ℝ) * π ≤ ((149 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((46057469 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((67 : ℝ) / 25) n) ≤ ((4692711 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((15888359 : ℝ) / 100000000) ≤ Real.log (π / ((67 : ℝ) / 25)) := by
    apply cov_log_2663.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((67 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_53 : ((5672731 : ℝ) / 50000000) ≤ hfun ((267 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((267 : ℝ) / 100)) ^ 2 ≤ ((5161149 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (1 * ((267 : ℝ) / 100)) 1]
    have hx : RB |1 * ((267 : ℝ) / 100) - (1 : ℝ) * π| ((943 : ℝ) / 2000) ((1179 : ℝ) / 2500) := by
      have hz : ((-1179 : ℝ) / 2500) ≤ 1 * ((267 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((267 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-943 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5161149 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((267 : ℝ) / 100)) ^ 2 ≤ ((65795979 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (2 * ((267 : ℝ) / 100)) 1]
    have hx : RB |2 * ((267 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((1569 : ℝ) / 2500) ((2511 : ℝ) / 4000) := by
      have hz : ((1569 : ℝ) / 2500) ≤ 2 * ((267 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((267 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((2511 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((65795979 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((267 : ℝ) / 100)) ^ 2 ≤ ((4879367 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (3 * ((267 : ℝ) / 100)) 2]
    have hx : RB |3 * ((267 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((39 : ℝ) / 250) ((5 : ℝ) / 32) := by
      have hz : ((39 : ℝ) / 250) ≤ 3 * ((267 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((267 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((5 : ℝ) / 32) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4879367 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((267 : ℝ) / 100)) ^ 2 ≤ ((904069 : ℝ) / 1000000) := by
    rw [sin_sq_shift_half_pi (4 * ((267 : ℝ) / 100)) 3]
    have hx : RB |4 * ((267 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((1261 : ℝ) / 4000) ((789 : ℝ) / 2500) := by
      have hz : ((-789 : ℝ) / 2500) ≤ 4 * ((267 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((267 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-1261 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((904069 : ℝ) / 1000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((267 : ℝ) / 100)) ^ 2 ≤ ((49952353 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (5 * ((267 : ℝ) / 100)) 4]
    have hx : RB |5 * ((267 : ℝ) / 100) - (4 : ℝ) * π| ((1959 : ℝ) / 2500) ((98 : ℝ) / 125) := by
      have hz : ((1959 : ℝ) / 2500) ≤ 5 * ((267 : ℝ) / 100) - (4 : ℝ) * π ∧ 5 * ((267 : ℝ) / 100) - (4 : ℝ) * π ≤ ((98 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49952353 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((267 : ℝ) / 100)) ^ 2 ≤ ((2363413 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((267 : ℝ) / 100)) 5]
    have hx : RB |6 * ((267 : ℝ) / 100) - (5 : ℝ) * π| ((39 : ℝ) / 125) ((5 : ℝ) / 16) := by
      have hz : ((39 : ℝ) / 125) ≤ 6 * ((267 : ℝ) / 100) - (5 : ℝ) * π ∧ 6 * ((267 : ℝ) / 100) - (5 : ℝ) * π ≤ ((5 : ℝ) / 16) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2363413 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((267 : ℝ) / 100)) ^ 2 ≤ ((252591 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (7 * ((267 : ℝ) / 100)) 6]
    have hx : RB |7 * ((267 : ℝ) / 100) - (6 : ℝ) * π| ((159 : ℝ) / 1000) ((399 : ℝ) / 2500) := by
      have hz : ((-399 : ℝ) / 2500) ≤ 7 * ((267 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((267 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-159 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((252591 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((267 : ℝ) / 100)) ^ 2 ≤ ((34860537 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((267 : ℝ) / 100)) 7]
    have hx : RB |8 * ((267 : ℝ) / 100) - (7 : ℝ) * π| ((1261 : ℝ) / 2000) ((789 : ℝ) / 1250) := by
      have hz : ((-789 : ℝ) / 1250) ≤ 8 * ((267 : ℝ) / 100) - (7 : ℝ) * π ∧ 8 * ((267 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-1261 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((34860537 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((267 : ℝ) / 100)) ^ 2 ≤ ((996817 : ℝ) / 1250000) := by
    rw [sin_sq_shift_half_pi (9 * ((267 : ℝ) / 100)) 7]
    have hx : RB |9 * ((267 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((117 : ℝ) / 250) ((15 : ℝ) / 32) := by
      have hz : ((117 : ℝ) / 250) ≤ 9 * ((267 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 9 * ((267 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((15 : ℝ) / 32) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((996817 : ℝ) / 1250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((267 : ℝ) / 100)) ^ 2 ≤ ((24999811 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (10 * ((267 : ℝ) / 100)) 8]
    have hx : RB |10 * ((267 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((11 : ℝ) / 4000) ((9 : ℝ) / 2500) := by
      have hz : ((-9 : ℝ) / 2500) ≤ 10 * ((267 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 10 * ((267 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-11 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24999811 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((267 : ℝ) / 100)) ^ 2 ≤ ((19811371 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (11 * ((267 : ℝ) / 100)) 9]
    have hx : RB |11 * ((267 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((1897 : ℝ) / 4000) ((297 : ℝ) / 625) := by
      have hz : ((-297 : ℝ) / 625) ≤ 11 * ((267 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 11 * ((267 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((-1897 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19811371 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((267 : ℝ) / 100)) ^ 2 ≤ ((17138087 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((267 : ℝ) / 100)) 10]
    have hx : RB |12 * ((267 : ℝ) / 100) - (10 : ℝ) * π| ((78 : ℝ) / 125) ((5 : ℝ) / 8) := by
      have hz : ((78 : ℝ) / 125) ≤ 12 * ((267 : ℝ) / 100) - (10 : ℝ) * π ∧ 12 * ((267 : ℝ) / 100) - (10 : ℝ) * π ≤ ((5 : ℝ) / 8) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17138087 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((267 : ℝ) / 100) n) ≤ ((4868023 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((1016387 : ℝ) / 6250000) ≤ Real.log (π / ((267 : ℝ) / 100)) := by
    apply cov_log_2664.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((267 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_54 : ((1442739 : ℝ) / 12500000) ≤ hfun ((133 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((133 : ℝ) / 50)) ^ 2 ≤ ((21460403 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((133 : ℝ) / 50)) 1]
    have hx : RB |1 * ((133 : ℝ) / 50) - (1 : ℝ) * π| ((963 : ℝ) / 2000) ((301 : ℝ) / 625) := by
      have hz : ((-301 : ℝ) / 625) ≤ 1 * ((133 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((133 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-963 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21460403 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((133 : ℝ) / 50)) ^ 2 ≤ ((6765337 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (2 * ((133 : ℝ) / 50)) 1]
    have hx : RB |2 * ((133 : ℝ) / 50) - ((3 : ℝ) / 2) * π| ((1519 : ℝ) / 2500) ((2431 : ℝ) / 4000) := by
      have hz : ((1519 : ℝ) / 2500) ≤ 2 * ((133 : ℝ) / 50) - ((3 : ℝ) / 2) * π ∧ 2 * ((133 : ℝ) / 50) - ((3 : ℝ) / 2) * π ≤ ((2431 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6765337 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((133 : ℝ) / 50)) ^ 2 ≤ ((98421327 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((133 : ℝ) / 50)) 2]
    have hx : RB |3 * ((133 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((63 : ℝ) / 500) ((101 : ℝ) / 800) := by
      have hz : ((63 : ℝ) / 500) ≤ 3 * ((133 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 3 * ((133 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((101 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((98421327 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((133 : ℝ) / 50)) ^ 2 ≤ ((43967021 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (4 * ((133 : ℝ) / 50)) 3]
    have hx : RB |4 * ((133 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((1421 : ℝ) / 4000) ((889 : ℝ) / 2500) := by
      have hz : ((-889 : ℝ) / 2500) ≤ 4 * ((133 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 4 * ((133 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((-1421 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((43967021 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((133 : ℝ) / 50)) ^ 2 ≤ ((44934281 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (5 * ((133 : ℝ) / 50)) 4]
    have hx : RB |5 * ((133 : ℝ) / 50) - (4 : ℝ) * π| ((917 : ℝ) / 1250) ((367 : ℝ) / 500) := by
      have hz : ((917 : ℝ) / 1250) ≤ 5 * ((133 : ℝ) / 50) - (4 : ℝ) * π ∧ 5 * ((133 : ℝ) / 50) - (4 : ℝ) * π ≤ ((367 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((44934281 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((133 : ℝ) / 50)) ^ 2 ≤ ((3121079 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (6 * ((133 : ℝ) / 50)) 5]
    have hx : RB |6 * ((133 : ℝ) / 50) - (5 : ℝ) * π| ((63 : ℝ) / 250) ((101 : ℝ) / 400) := by
      have hz : ((63 : ℝ) / 250) ≤ 6 * ((133 : ℝ) / 50) - (5 : ℝ) * π ∧ 6 * ((133 : ℝ) / 50) - (5 : ℝ) * π ≤ ((101 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3121079 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((133 : ℝ) / 50)) ^ 2 ≤ ((5180399 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((133 : ℝ) / 50)) 6]
    have hx : RB |7 * ((133 : ℝ) / 50) - (6 : ℝ) * π| ((229 : ℝ) / 1000) ((287 : ℝ) / 1250) := by
      have hz : ((-287 : ℝ) / 1250) ≤ 7 * ((133 : ℝ) / 50) - (6 : ℝ) * π ∧ 7 * ((133 : ℝ) / 50) - (6 : ℝ) * π ≤ ((-229 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5180399 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((133 : ℝ) / 50)) ^ 2 ≤ ((42672457 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (8 * ((133 : ℝ) / 50)) 7]
    have hx : RB |8 * ((133 : ℝ) / 50) - (7 : ℝ) * π| ((1421 : ℝ) / 2000) ((889 : ℝ) / 1250) := by
      have hz : ((-889 : ℝ) / 1250) ≤ 8 * ((133 : ℝ) / 50) - (7 : ℝ) * π ∧ 8 * ((133 : ℝ) / 50) - (7 : ℝ) * π ≤ ((-1421 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42672457 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((133 : ℝ) / 50)) ^ 2 ≤ ((17284231 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (9 * ((133 : ℝ) / 50)) 7]
    have hx : RB |9 * ((133 : ℝ) / 50) - ((15 : ℝ) / 2) * π| ((189 : ℝ) / 500) ((303 : ℝ) / 800) := by
      have hz : ((189 : ℝ) / 500) ≤ 9 * ((133 : ℝ) / 50) - ((15 : ℝ) / 2) * π ∧ 9 * ((133 : ℝ) / 50) - ((15 : ℝ) / 2) * π ≤ ((303 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17284231 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((133 : ℝ) / 50)) ^ 2 ≤ ((773033 : ℝ) / 781250) := by
    rw [sin_sq_shift_half_pi (10 * ((133 : ℝ) / 50)) 8]
    have hx : RB |10 * ((133 : ℝ) / 50) - ((17 : ℝ) / 2) * π| ((411 : ℝ) / 4000) ((259 : ℝ) / 2500) := by
      have hz : ((-259 : ℝ) / 2500) ≤ 10 * ((133 : ℝ) / 50) - ((17 : ℝ) / 2) * π ∧ 10 * ((133 : ℝ) / 50) - ((17 : ℝ) / 2) * π ≤ ((-411 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((773033 : ℝ) / 781250) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((133 : ℝ) / 50)) ^ 2 ≤ ((8724379 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (11 * ((133 : ℝ) / 50)) 9]
    have hx : RB |11 * ((133 : ℝ) / 50) - ((19 : ℝ) / 2) * π| ((2337 : ℝ) / 4000) ((1463 : ℝ) / 2500) := by
      have hz : ((-1463 : ℝ) / 2500) ≤ 11 * ((133 : ℝ) / 50) - ((19 : ℝ) / 2) * π ∧ 11 * ((133 : ℝ) / 50) - ((19 : ℝ) / 2) * π ≤ ((-2337 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8724379 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((133 : ℝ) / 50)) ^ 2 ≤ ((23424739 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((133 : ℝ) / 50)) 10]
    have hx : RB |12 * ((133 : ℝ) / 50) - (10 : ℝ) * π| ((63 : ℝ) / 125) ((101 : ℝ) / 200) := by
      have hz : ((63 : ℝ) / 125) ≤ 12 * ((133 : ℝ) / 50) - (10 : ℝ) * π ∧ 12 * ((133 : ℝ) / 50) - (10 : ℝ) * π ≤ ((101 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23424739 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((133 : ℝ) / 50) n) ≤ ((126161 : ℝ) / 2500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((8318713 : ℝ) / 50000000) ≤ Real.log (π / ((133 : ℝ) / 50)) := by
    apply cov_log_2665.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((133 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_55 : ((11736907 : ℝ) / 100000000) ≤ hfun ((53 : ℝ) / 20) := by
  have s1 : Real.sin (1 * ((53 : ℝ) / 20)) ^ 2 ≤ ((22287683 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((53 : ℝ) / 20)) 1]
    have hx : RB |1 * ((53 : ℝ) / 20) - (1 : ℝ) * π| ((983 : ℝ) / 2000) ((1229 : ℝ) / 2500) := by
      have hz : ((-1229 : ℝ) / 2500) ≤ 1 * ((53 : ℝ) / 20) - (1 : ℝ) * π ∧ 1 * ((53 : ℝ) / 20) - (1 : ℝ) * π ≤ ((-983 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22287683 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((53 : ℝ) / 20)) ^ 2 ≤ ((17371329 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (2 * ((53 : ℝ) / 20)) 1]
    have hx : RB |2 * ((53 : ℝ) / 20) - ((3 : ℝ) / 2) * π| ((1469 : ℝ) / 2500) ((2351 : ℝ) / 4000) := by
      have hz : ((1469 : ℝ) / 2500) ≤ 2 * ((53 : ℝ) / 20) - ((3 : ℝ) / 2) * π ∧ 2 * ((53 : ℝ) / 20) - ((3 : ℝ) / 2) * π ≤ ((2351 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17371329 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((53 : ℝ) / 20)) ^ 2 ≤ ((49540707 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((53 : ℝ) / 20)) 2]
    have hx : RB |3 * ((53 : ℝ) / 20) - ((5 : ℝ) / 2) * π| ((12 : ℝ) / 125) ((77 : ℝ) / 800) := by
      have hz : ((12 : ℝ) / 125) ≤ 3 * ((53 : ℝ) / 20) - ((5 : ℝ) / 2) * π ∧ 3 * ((53 : ℝ) / 20) - ((5 : ℝ) / 2) * π ≤ ((77 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49540707 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((53 : ℝ) / 20)) ^ 2 ≤ ((42611621 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (4 * ((53 : ℝ) / 20)) 3]
    have hx : RB |4 * ((53 : ℝ) / 20) - ((7 : ℝ) / 2) * π| ((1581 : ℝ) / 4000) ((989 : ℝ) / 2500) := by
      have hz : ((-989 : ℝ) / 2500) ≤ 4 * ((53 : ℝ) / 20) - ((7 : ℝ) / 2) * π ∧ 4 * ((53 : ℝ) / 20) - ((7 : ℝ) / 2) * π ≤ ((-1581 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42611621 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((53 : ℝ) / 20)) ^ 2 ≤ ((156151 : ℝ) / 390625) := by
    rw [sin_sq_shift_pi (5 * ((53 : ℝ) / 20)) 4]
    have hx : RB |5 * ((53 : ℝ) / 20) - (4 : ℝ) * π| ((1709 : ℝ) / 2500) ((171 : ℝ) / 250) := by
      have hz : ((1709 : ℝ) / 2500) ≤ 5 * ((53 : ℝ) / 20) - (4 : ℝ) * π ∧ 5 * ((53 : ℝ) / 20) - (4 : ℝ) * π ≤ ((171 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((156151 : ℝ) / 390625) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((53 : ℝ) / 20)) ^ 2 ≤ ((3660449 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((53 : ℝ) / 20)) 5]
    have hx : RB |6 * ((53 : ℝ) / 20) - (5 : ℝ) * π| ((24 : ℝ) / 125) ((77 : ℝ) / 400) := by
      have hz : ((24 : ℝ) / 125) ≤ 6 * ((53 : ℝ) / 20) - (5 : ℝ) * π ∧ 6 * ((53 : ℝ) / 20) - (5 : ℝ) * π ≤ ((77 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3660449 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((53 : ℝ) / 20)) ^ 2 ≤ ((4356237 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((53 : ℝ) / 20)) 6]
    have hx : RB |7 * ((53 : ℝ) / 20) - (6 : ℝ) * π| ((299 : ℝ) / 1000) ((749 : ℝ) / 2500) := by
      have hz : ((-749 : ℝ) / 2500) ≤ 7 * ((53 : ℝ) / 20) - (6 : ℝ) * π ∧ 7 * ((53 : ℝ) / 20) - (6 : ℝ) * π ≤ ((-299 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4356237 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((53 : ℝ) / 20)) ^ 2 ≤ ((51181909 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((53 : ℝ) / 20)) 6]
    have hx : RB |8 * ((53 : ℝ) / 20) - ((13 : ℝ) / 2) * π| ((1949 : ℝ) / 2500) ((3121 : ℝ) / 4000) := by
      have hz : ((1949 : ℝ) / 2500) ≤ 8 * ((53 : ℝ) / 20) - ((13 : ℝ) / 2) * π ∧ 8 * ((53 : ℝ) / 20) - ((13 : ℝ) / 2) * π ≤ ((3121 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((51181909 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((53 : ℝ) / 20)) ^ 2 ≤ ((11493377 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (9 * ((53 : ℝ) / 20)) 7]
    have hx : RB |9 * ((53 : ℝ) / 20) - ((15 : ℝ) / 2) * π| ((36 : ℝ) / 125) ((231 : ℝ) / 800) := by
      have hz : ((36 : ℝ) / 125) ≤ 9 * ((53 : ℝ) / 20) - ((15 : ℝ) / 2) * π ∧ 9 * ((53 : ℝ) / 20) - ((15 : ℝ) / 2) * π ≤ ((231 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11493377 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((53 : ℝ) / 20)) ^ 2 ≤ ((47974511 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((53 : ℝ) / 20)) 8]
    have hx : RB |10 * ((53 : ℝ) / 20) - ((17 : ℝ) / 2) * π| ((811 : ℝ) / 4000) ((509 : ℝ) / 2500) := by
      have hz : ((-509 : ℝ) / 2500) ≤ 10 * ((53 : ℝ) / 20) - ((17 : ℝ) / 2) * π ∧ 10 * ((53 : ℝ) / 20) - ((17 : ℝ) / 2) * π ≤ ((-811 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((47974511 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((53 : ℝ) / 20)) ^ 2 ≤ ((59470963 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((53 : ℝ) / 20)) 9]
    have hx : RB |11 * ((53 : ℝ) / 20) - ((19 : ℝ) / 2) * π| ((2777 : ℝ) / 4000) ((869 : ℝ) / 1250) := by
      have hz : ((-869 : ℝ) / 1250) ≤ 11 * ((53 : ℝ) / 20) - ((19 : ℝ) / 2) * π ∧ 11 * ((53 : ℝ) / 20) - ((19 : ℝ) / 2) * π ≤ ((-2777 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((59470963 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((53 : ℝ) / 20)) ^ 2 ≤ ((7055549 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((53 : ℝ) / 20)) 10]
    have hx : RB |12 * ((53 : ℝ) / 20) - (10 : ℝ) * π| ((48 : ℝ) / 125) ((77 : ℝ) / 200) := by
      have hz : ((48 : ℝ) / 125) ≤ 12 * ((53 : ℝ) / 20) - (10 : ℝ) * π ∧ 12 * ((53 : ℝ) / 20) - (10 : ℝ) * π ≤ ((77 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7055549 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((53 : ℝ) / 20) n) ≤ ((2613861 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((8507037 : ℝ) / 50000000) ≤ Real.log (π / ((53 : ℝ) / 20)) := by
    apply cov_log_2666.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((53 : ℝ) / 20)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_56 : ((2386163 : ℝ) / 20000000) ≤ hfun ((66 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((66 : ℝ) / 25)) ^ 2 ≤ ((2312611 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (1 * ((66 : ℝ) / 25)) 1]
    have hx : RB |1 * ((66 : ℝ) / 25) - (1 : ℝ) * π| ((1003 : ℝ) / 2000) ((627 : ℝ) / 1250) := by
      have hz : ((-627 : ℝ) / 1250) ≤ 1 * ((66 : ℝ) / 25) - (1 : ℝ) * π ∧ 1 * ((66 : ℝ) / 25) - (1 : ℝ) * π ≤ ((-1003 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2312611 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((66 : ℝ) / 25)) ^ 2 ≤ ((14257753 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (2 * ((66 : ℝ) / 25)) 1]
    have hx : RB |2 * ((66 : ℝ) / 25) - ((3 : ℝ) / 2) * π| ((1419 : ℝ) / 2500) ((2271 : ℝ) / 4000) := by
      have hz : ((1419 : ℝ) / 2500) ≤ 2 * ((66 : ℝ) / 25) - ((3 : ℝ) / 2) * π ∧ 2 * ((66 : ℝ) / 25) - ((3 : ℝ) / 2) * π ≤ ((2271 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14257753 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((66 : ℝ) / 25)) ^ 2 ≤ ((3982603 : ℝ) / 4000000) := by
    rw [sin_sq_shift_half_pi (3 * ((66 : ℝ) / 25)) 2]
    have hx : RB |3 * ((66 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((33 : ℝ) / 500) ((53 : ℝ) / 800) := by
      have hz : ((33 : ℝ) / 500) ≤ 3 * ((66 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 3 * ((66 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((53 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3982603 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((66 : ℝ) / 25)) ^ 2 ≤ ((41146413 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (4 * ((66 : ℝ) / 25)) 3]
    have hx : RB |4 * ((66 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((1741 : ℝ) / 4000) ((1089 : ℝ) / 2500) := by
      have hz : ((-1089 : ℝ) / 2500) ≤ 4 * ((66 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 4 * ((66 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((-1741 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((41146413 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((66 : ℝ) / 25)) ^ 2 ≤ ((3512119 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (5 * ((66 : ℝ) / 25)) 4]
    have hx : RB |5 * ((66 : ℝ) / 25) - (4 : ℝ) * π| ((396 : ℝ) / 625) ((317 : ℝ) / 500) := by
      have hz : ((396 : ℝ) / 625) ≤ 5 * ((66 : ℝ) / 25) - (4 : ℝ) * π ∧ 5 * ((66 : ℝ) / 25) - (4 : ℝ) * π ≤ ((317 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3512119 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((66 : ℝ) / 25)) ^ 2 ≤ ((1745493 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((66 : ℝ) / 25)) 5]
    have hx : RB |6 * ((66 : ℝ) / 25) - (5 : ℝ) * π| ((33 : ℝ) / 250) ((53 : ℝ) / 400) := by
      have hz : ((33 : ℝ) / 250) ≤ 6 * ((66 : ℝ) / 25) - (5 : ℝ) * π ∧ 6 * ((66 : ℝ) / 25) - (5 : ℝ) * π ≤ ((53 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1745493 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((66 : ℝ) / 25)) ^ 2 ≤ ((13053413 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((66 : ℝ) / 25)) 6]
    have hx : RB |7 * ((66 : ℝ) / 25) - (6 : ℝ) * π| ((369 : ℝ) / 1000) ((231 : ℝ) / 625) := by
      have hz : ((-231 : ℝ) / 625) ≤ 7 * ((66 : ℝ) / 25) - (6 : ℝ) * π ∧ 7 * ((66 : ℝ) / 25) - (6 : ℝ) * π ≤ ((-369 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13053413 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((66 : ℝ) / 25)) ^ 2 ≤ ((29476073 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((66 : ℝ) / 25)) 6]
    have hx : RB |8 * ((66 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((1749 : ℝ) / 2500) ((2801 : ℝ) / 4000) := by
      have hz : ((1749 : ℝ) / 2500) ≤ 8 * ((66 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 8 * ((66 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((2801 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((29476073 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((66 : ℝ) / 25)) ^ 2 ≤ ((2403349 : ℝ) / 2500000) := by
    rw [sin_sq_shift_half_pi (9 * ((66 : ℝ) / 25)) 7]
    have hx : RB |9 * ((66 : ℝ) / 25) - ((15 : ℝ) / 2) * π| ((99 : ℝ) / 500) ((159 : ℝ) / 800) := by
      have hz : ((99 : ℝ) / 500) ≤ 9 * ((66 : ℝ) / 25) - ((15 : ℝ) / 2) * π ∧ 9 * ((66 : ℝ) / 25) - ((15 : ℝ) / 2) * π ≤ ((159 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2403349 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((66 : ℝ) / 25)) ^ 2 ≤ ((45564367 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((66 : ℝ) / 25)) 8]
    have hx : RB |10 * ((66 : ℝ) / 25) - ((17 : ℝ) / 2) * π| ((1211 : ℝ) / 4000) ((759 : ℝ) / 2500) := by
      have hz : ((-759 : ℝ) / 2500) ≤ 10 * ((66 : ℝ) / 25) - ((17 : ℝ) / 2) * π ∧ 10 * ((66 : ℝ) / 25) - ((17 : ℝ) / 2) * π ≤ ((-1211 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45564367 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((66 : ℝ) / 25)) ^ 2 ≤ ((48212739 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((66 : ℝ) / 25)) 9]
    have hx : RB |11 * ((66 : ℝ) / 25) - (9 : ℝ) * π| ((957 : ℝ) / 1250) ((1533 : ℝ) / 2000) := by
      have hz : ((957 : ℝ) / 1250) ≤ 11 * ((66 : ℝ) / 25) - (9 : ℝ) * π ∧ 11 * ((66 : ℝ) / 25) - (9 : ℝ) * π ≤ ((1533 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((48212739 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((66 : ℝ) / 25)) ^ 2 ≤ ((3430797 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (12 * ((66 : ℝ) / 25)) 10]
    have hx : RB |12 * ((66 : ℝ) / 25) - (10 : ℝ) * π| ((33 : ℝ) / 125) ((53 : ℝ) / 200) := by
      have hz : ((33 : ℝ) / 125) ≤ 12 * ((66 : ℝ) / 25) - (10 : ℝ) * π ∧ 12 * ((66 : ℝ) / 25) - (10 : ℝ) * π ≤ ((53 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3430797 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((66 : ℝ) / 25) n) ≤ ((676439 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((17392147 : ℝ) / 100000000) ≤ Real.log (π / ((66 : ℝ) / 25)) := by
    apply cov_log_2667.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((66 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_57 : ((12123301 : ℝ) / 100000000) ≤ hfun ((263 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((263 : ℝ) / 100)) ^ 2 ≤ ((23975353 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((263 : ℝ) / 100)) 1]
    have hx : RB |1 * ((263 : ℝ) / 100) - (1 : ℝ) * π| ((1023 : ℝ) / 2000) ((1279 : ℝ) / 2500) := by
      have hz : ((-1279 : ℝ) / 2500) ≤ 1 * ((263 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((263 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-1023 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23975353 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((263 : ℝ) / 100)) ^ 2 ≤ ((73060707 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (2 * ((263 : ℝ) / 100)) 1]
    have hx : RB |2 * ((263 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((1369 : ℝ) / 2500) ((2191 : ℝ) / 4000) := by
      have hz : ((1369 : ℝ) / 2500) ≤ 2 * ((263 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((263 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((2191 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((73060707 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((263 : ℝ) / 100)) ^ 2 ≤ ((4993523 : ℝ) / 5000000) := by
    rw [sin_sq_shift_half_pi (3 * ((263 : ℝ) / 100)) 2]
    have hx : RB |3 * ((263 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((9 : ℝ) / 250) ((29 : ℝ) / 800) := by
      have hz : ((9 : ℝ) / 250) ≤ 3 * ((263 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((263 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((29 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4993523 : ℝ) / 5000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((263 : ℝ) / 100)) ^ 2 ≤ ((4947661 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (4 * ((263 : ℝ) / 100)) 3]
    have hx : RB |4 * ((263 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((1901 : ℝ) / 4000) ((1189 : ℝ) / 2500) := by
      have hz : ((-1189 : ℝ) / 2500) ≤ 4 * ((263 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((263 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-1901 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4947661 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((263 : ℝ) / 100)) ^ 2 ≤ ((3042089 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (5 * ((263 : ℝ) / 100)) 4]
    have hx : RB |5 * ((263 : ℝ) / 100) - (4 : ℝ) * π| ((1459 : ℝ) / 2500) ((73 : ℝ) / 125) := by
      have hz : ((1459 : ℝ) / 2500) ≤ 5 * ((263 : ℝ) / 100) - (4 : ℝ) * π ∧ 5 * ((263 : ℝ) / 100) - (4 : ℝ) * π ≤ ((73 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3042089 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((263 : ℝ) / 100)) ^ 2 ≤ ((131181 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (6 * ((263 : ℝ) / 100)) 5]
    have hx : RB |6 * ((263 : ℝ) / 100) - (5 : ℝ) * π| ((9 : ℝ) / 125) ((29 : ℝ) / 400) := by
      have hz : ((9 : ℝ) / 125) ≤ 6 * ((263 : ℝ) / 100) - (5 : ℝ) * π ∧ 6 * ((263 : ℝ) / 100) - (5 : ℝ) * π ≤ ((29 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((131181 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((263 : ℝ) / 100)) ^ 2 ≤ ((3623787 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (7 * ((263 : ℝ) / 100)) 6]
    have hx : RB |7 * ((263 : ℝ) / 100) - (6 : ℝ) * π| ((439 : ℝ) / 1000) ((1099 : ℝ) / 2500) := by
      have hz : ((-1099 : ℝ) / 2500) ≤ 7 * ((263 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((263 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-439 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3623787 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((263 : ℝ) / 100)) ^ 2 ≤ ((66545843 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((263 : ℝ) / 100)) 6]
    have hx : RB |8 * ((263 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((1549 : ℝ) / 2500) ((2481 : ℝ) / 4000) := by
      have hz : ((1549 : ℝ) / 2500) ≤ 8 * ((263 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 8 * ((263 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((2481 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((66545843 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((263 : ℝ) / 100)) ^ 2 ≤ ((1976769 : ℝ) / 2000000) := by
    rw [sin_sq_shift_half_pi (9 * ((263 : ℝ) / 100)) 7]
    have hx : RB |9 * ((263 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((27 : ℝ) / 250) ((87 : ℝ) / 800) := by
      have hz : ((27 : ℝ) / 250) ≤ 9 * ((263 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 9 * ((263 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((87 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1976769 : ℝ) / 2000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((263 : ℝ) / 100)) ^ 2 ≤ ((42345599 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((263 : ℝ) / 100)) 8]
    have hx : RB |10 * ((263 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((1611 : ℝ) / 4000) ((1009 : ℝ) / 2500) := by
      have hz : ((-1009 : ℝ) / 2500) ≤ 10 * ((263 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 10 * ((263 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-1611 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42345599 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((263 : ℝ) / 100)) ^ 2 ≤ ((37302219 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((263 : ℝ) / 100)) 9]
    have hx : RB |11 * ((263 : ℝ) / 100) - (9 : ℝ) * π| ((1639 : ℝ) / 2500) ((1313 : ℝ) / 2000) := by
      have hz : ((1639 : ℝ) / 2500) ≤ 11 * ((263 : ℝ) / 100) - (9 : ℝ) * π ∧ 11 * ((263 : ℝ) / 100) - (9 : ℝ) * π ≤ ((1313 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((37302219 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((263 : ℝ) / 100)) ^ 2 ≤ ((130507 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (12 * ((263 : ℝ) / 100)) 10]
    have hx : RB |12 * ((263 : ℝ) / 100) - (10 : ℝ) * π| ((18 : ℝ) / 125) ((29 : ℝ) / 200) := by
      have hz : ((18 : ℝ) / 125) ≤ 12 * ((263 : ℝ) / 100) - (10 : ℝ) * π ∧ 12 * ((263 : ℝ) / 100) - (10 : ℝ) * π ≤ ((29 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((130507 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((263 : ℝ) / 100) n) ≤ ((5598153 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((8885827 : ℝ) / 50000000) ≤ Real.log (π / ((263 : ℝ) / 100)) := by
    apply cov_log_2668.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((263 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_58 : ((2462869 : ℝ) / 20000000) ≤ hfun ((131 : ℝ) / 50) := by
  have s1 : Real.sin (1 * ((131 : ℝ) / 50)) ^ 2 ≤ ((24835077 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((131 : ℝ) / 50)) 1]
    have hx : RB |1 * ((131 : ℝ) / 50) - (1 : ℝ) * π| ((1043 : ℝ) / 2000) ((326 : ℝ) / 625) := by
      have hz : ((-326 : ℝ) / 625) ≤ 1 * ((131 : ℝ) / 50) - (1 : ℝ) * π ∧ 1 * ((131 : ℝ) / 50) - (1 : ℝ) * π ≤ ((-1043 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24835077 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((131 : ℝ) / 50)) ^ 2 ≤ ((74798179 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (2 * ((131 : ℝ) / 50)) 1]
    have hx : RB |2 * ((131 : ℝ) / 50) - ((3 : ℝ) / 2) * π| ((1319 : ℝ) / 2500) ((2111 : ℝ) / 4000) := by
      have hz : ((1319 : ℝ) / 2500) ≤ 2 * ((131 : ℝ) / 50) - ((3 : ℝ) / 2) * π ∧ 2 * ((131 : ℝ) / 50) - ((3 : ℝ) / 2) * π ≤ ((2111 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((74798179 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((131 : ℝ) / 50)) ^ 2 ≤ ((99996401 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((131 : ℝ) / 50)) 2]
    have hx : RB |3 * ((131 : ℝ) / 50) - ((5 : ℝ) / 2) * π| ((3 : ℝ) / 500) ((1 : ℝ) / 160) := by
      have hz : ((3 : ℝ) / 500) ≤ 3 * ((131 : ℝ) / 50) - ((5 : ℝ) / 2) * π ∧ 3 * ((131 : ℝ) / 50) - ((5 : ℝ) / 2) * π ≤ ((1 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99996401 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((131 : ℝ) / 50)) ^ 2 ≤ ((75853577 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (4 * ((131 : ℝ) / 50)) 3]
    have hx : RB |4 * ((131 : ℝ) / 50) - ((7 : ℝ) / 2) * π| ((2061 : ℝ) / 4000) ((1289 : ℝ) / 2500) := by
      have hz : ((-1289 : ℝ) / 2500) ≤ 4 * ((131 : ℝ) / 50) - ((7 : ℝ) / 2) * π ∧ 4 * ((131 : ℝ) / 50) - ((7 : ℝ) / 2) * π ≤ ((-2061 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((75853577 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((131 : ℝ) / 50)) ^ 2 ≤ ((1619971 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (5 * ((131 : ℝ) / 50)) 4]
    have hx : RB |5 * ((131 : ℝ) / 50) - (4 : ℝ) * π| ((667 : ℝ) / 1250) ((267 : ℝ) / 500) := by
      have hz : ((667 : ℝ) / 1250) ≤ 5 * ((131 : ℝ) / 50) - (4 : ℝ) * π ∧ 5 * ((131 : ℝ) / 50) - (4 : ℝ) * π ≤ ((267 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1619971 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((131 : ℝ) / 50)) ^ 2 ≤ ((1 : ℝ) / 6400) := by
    rw [sin_sq_shift_pi (6 * ((131 : ℝ) / 50)) 5]
    have hx : RB |6 * ((131 : ℝ) / 50) - (5 : ℝ) * π| ((3 : ℝ) / 250) ((1 : ℝ) / 80) := by
      have hz : ((3 : ℝ) / 250) ≤ 6 * ((131 : ℝ) / 50) - (5 : ℝ) * π ∧ 6 * ((131 : ℝ) / 50) - (5 : ℝ) * π ≤ ((1 : ℝ) / 80) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1 : ℝ) / 6400) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((131 : ℝ) / 50)) ^ 2 ≤ ((11905491 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((131 : ℝ) / 50)) 6]
    have hx : RB |7 * ((131 : ℝ) / 50) - (6 : ℝ) * π| ((509 : ℝ) / 1000) ((637 : ℝ) / 1250) := by
      have hz : ((-637 : ℝ) / 1250) ≤ 7 * ((131 : ℝ) / 50) - (6 : ℝ) * π ∧ 7 * ((131 : ℝ) / 50) - (6 : ℝ) * π ≤ ((-509 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((11905491 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((131 : ℝ) / 50)) ^ 2 ≤ ((36881407 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((131 : ℝ) / 50)) 6]
    have hx : RB |8 * ((131 : ℝ) / 50) - ((13 : ℝ) / 2) * π| ((1349 : ℝ) / 2500) ((2161 : ℝ) / 4000) := by
      have hz : ((1349 : ℝ) / 2500) ≤ 8 * ((131 : ℝ) / 50) - ((13 : ℝ) / 2) * π ∧ 8 * ((131 : ℝ) / 50) - ((13 : ℝ) / 2) * π ≤ ((2161 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((36881407 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((131 : ℝ) / 50)) ^ 2 ≤ ((24991901 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (9 * ((131 : ℝ) / 50)) 7]
    have hx : RB |9 * ((131 : ℝ) / 50) - ((15 : ℝ) / 2) * π| ((9 : ℝ) / 500) ((3 : ℝ) / 160) := by
      have hz : ((9 : ℝ) / 500) ≤ 9 * ((131 : ℝ) / 50) - ((15 : ℝ) / 2) * π ∧ 9 * ((131 : ℝ) / 50) - ((15 : ℝ) / 2) * π ≤ ((3 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24991901 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((131 : ℝ) / 50)) ^ 2 ≤ ((9613481 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (10 * ((131 : ℝ) / 50)) 8]
    have hx : RB |10 * ((131 : ℝ) / 50) - ((17 : ℝ) / 2) * π| ((2011 : ℝ) / 4000) ((1259 : ℝ) / 2500) := by
      have hz : ((-1259 : ℝ) / 2500) ≤ 10 * ((131 : ℝ) / 50) - ((17 : ℝ) / 2) * π ∧ 10 * ((131 : ℝ) / 50) - ((17 : ℝ) / 2) * π ≤ ((-2011 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9613481 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((131 : ℝ) / 50)) ^ 2 ≤ ((1081261 : ℝ) / 4000000) := by
    rw [sin_sq_shift_pi (11 * ((131 : ℝ) / 50)) 9]
    have hx : RB |11 * ((131 : ℝ) / 50) - (9 : ℝ) * π| ((341 : ℝ) / 625) ((1093 : ℝ) / 2000) := by
      have hz : ((341 : ℝ) / 625) ≤ 11 * ((131 : ℝ) / 50) - (9 : ℝ) * π ∧ 11 * ((131 : ℝ) / 50) - (9 : ℝ) * π ≤ ((1093 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1081261 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((131 : ℝ) / 50)) ^ 2 ≤ ((62489 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((131 : ℝ) / 50)) 10]
    have hx : RB |12 * ((131 : ℝ) / 50) - (10 : ℝ) * π| ((3 : ℝ) / 125) ((1 : ℝ) / 40) := by
      have hz : ((3 : ℝ) / 125) ≤ 12 * ((131 : ℝ) / 50) - (10 : ℝ) * π ∧ 12 * ((131 : ℝ) / 50) - (10 : ℝ) * π ≤ ((1 : ℝ) / 40) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((62489 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((131 : ℝ) / 50) n) ≤ ((2893839 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((18152607 : ℝ) / 100000000) ≤ Real.log (π / ((131 : ℝ) / 50)) := by
    apply cov_log_2669.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((131 : ℝ) / 50)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_59 : ((3125973 : ℝ) / 25000000) ≤ hfun ((261 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((261 : ℝ) / 100)) ^ 2 ≤ ((5140989 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (1 * ((261 : ℝ) / 100)) 1]
    have hx : RB |1 * ((261 : ℝ) / 100) - (1 : ℝ) * π| ((1063 : ℝ) / 2000) ((1329 : ℝ) / 2500) := by
      have hz : ((-1329 : ℝ) / 2500) ≤ 1 * ((261 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((261 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-1063 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5140989 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((261 : ℝ) / 100)) ^ 2 ≤ ((7649827 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (2 * ((261 : ℝ) / 100)) 1]
    have hx : RB |2 * ((261 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((1269 : ℝ) / 2500) ((2031 : ℝ) / 4000) := by
      have hz : ((1269 : ℝ) / 2500) ≤ 2 * ((261 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((261 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((2031 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7649827 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((261 : ℝ) / 100)) ^ 2 ≤ ((49971803 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((261 : ℝ) / 100)) 2]
    have hx : RB |3 * ((261 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((19 : ℝ) / 800) ((3 : ℝ) / 125) := by
      have hz : ((-3 : ℝ) / 125) ≤ 3 * ((261 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((261 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((-19 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49971803 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((261 : ℝ) / 100)) ^ 2 ≤ ((14477613 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (4 * ((261 : ℝ) / 100)) 3]
    have hx : RB |4 * ((261 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((2221 : ℝ) / 4000) ((1389 : ℝ) / 2500) := by
      have hz : ((-1389 : ℝ) / 2500) ≤ 4 * ((261 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((261 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-2221 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14477613 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((261 : ℝ) / 100)) ^ 2 ≤ ((84614 : ℝ) / 390625) := by
    rw [sin_sq_shift_pi (5 * ((261 : ℝ) / 100)) 4]
    have hx : RB |5 * ((261 : ℝ) / 100) - (4 : ℝ) * π| ((1209 : ℝ) / 2500) ((121 : ℝ) / 250) := by
      have hz : ((1209 : ℝ) / 2500) ≤ 5 * ((261 : ℝ) / 100) - (4 : ℝ) * π ∧ 5 * ((261 : ℝ) / 100) - (4 : ℝ) * π ≤ ((121 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((84614 : ℝ) / 390625) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((261 : ℝ) / 100)) ^ 2 ≤ ((230229 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (6 * ((261 : ℝ) / 100)) 5]
    have hx : RB |6 * ((261 : ℝ) / 100) - (5 : ℝ) * π| ((19 : ℝ) / 400) ((6 : ℝ) / 125) := by
      have hz : ((-6 : ℝ) / 125) ≤ 6 * ((261 : ℝ) / 100) - (5 : ℝ) * π ∧ 6 * ((261 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-19 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((230229 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((261 : ℝ) / 100)) ^ 2 ≤ ((938119 : ℝ) / 3125000) := by
    rw [sin_sq_shift_pi (7 * ((261 : ℝ) / 100)) 6]
    have hx : RB |7 * ((261 : ℝ) / 100) - (6 : ℝ) * π| ((579 : ℝ) / 1000) ((1449 : ℝ) / 2500) := by
      have hz : ((-1449 : ℝ) / 2500) ≤ 7 * ((261 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((261 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-579 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((938119 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((261 : ℝ) / 100)) ^ 2 ≤ ((10051357 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (8 * ((261 : ℝ) / 100)) 6]
    have hx : RB |8 * ((261 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((1149 : ℝ) / 2500) ((1841 : ℝ) / 4000) := by
      have hz : ((1149 : ℝ) / 2500) ≤ 8 * ((261 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 8 * ((261 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((1841 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10051357 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((261 : ℝ) / 100)) ^ 2 ≤ ((24873317 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (9 * ((261 : ℝ) / 100)) 7]
    have hx : RB |9 * ((261 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((57 : ℝ) / 800) ((9 : ℝ) / 125) := by
      have hz : ((-9 : ℝ) / 125) ≤ 9 * ((261 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 9 * ((261 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((-57 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24873317 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((261 : ℝ) / 100)) ^ 2 ≤ ((13621071 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (10 * ((261 : ℝ) / 100)) 8]
    have hx : RB |10 * ((261 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((2411 : ℝ) / 4000) ((1509 : ℝ) / 2500) := by
      have hz : ((-1509 : ℝ) / 2500) ≤ 10 * ((261 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 10 * ((261 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-2411 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((13621071 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((261 : ℝ) / 100)) ^ 2 ≤ ((17882987 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (11 * ((261 : ℝ) / 100)) 9]
    have hx : RB |11 * ((261 : ℝ) / 100) - (9 : ℝ) * π| ((1089 : ℝ) / 2500) ((873 : ℝ) / 2000) := by
      have hz : ((1089 : ℝ) / 2500) ≤ 11 * ((261 : ℝ) / 100) - (9 : ℝ) * π ∧ 11 * ((261 : ℝ) / 100) - (9 : ℝ) * π ≤ ((873 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17882987 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((261 : ℝ) / 100)) ^ 2 ≤ ((918861 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((261 : ℝ) / 100)) 10]
    have hx : RB |12 * ((261 : ℝ) / 100) - (10 : ℝ) * π| ((19 : ℝ) / 200) ((12 : ℝ) / 125) := by
      have hz : ((-12 : ℝ) / 125) ≤ 12 * ((261 : ℝ) / 100) - (10 : ℝ) * π ∧ 12 * ((261 : ℝ) / 100) - (10 : ℝ) * π ≤ ((-19 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((918861 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((261 : ℝ) / 100) n) ≤ ((747519 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((2316877 : ℝ) / 12500000) ≤ Real.log (π / ((261 : ℝ) / 100)) := by
    apply cov_log_2670.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((261 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_60 : ((2538383 : ℝ) / 20000000) ≤ hfun ((13 : ℝ) / 5) := by
  have s1 : Real.sin (1 * ((13 : ℝ) / 5)) ^ 2 ≤ ((5316923 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (1 * ((13 : ℝ) / 5)) 1]
    have hx : RB |1 * ((13 : ℝ) / 5) - (1 : ℝ) * π| ((1083 : ℝ) / 2000) ((677 : ℝ) / 1250) := by
      have hz : ((-677 : ℝ) / 1250) ≤ 1 * ((13 : ℝ) / 5) - (1 : ℝ) * π ∧ 1 * ((13 : ℝ) / 5) - (1 : ℝ) * π ≤ ((-1083 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5316923 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((13 : ℝ) / 5)) ^ 2 ≤ ((4884883 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (2 * ((13 : ℝ) / 5)) 1]
    have hx : RB |2 * ((13 : ℝ) / 5) - ((3 : ℝ) / 2) * π| ((1219 : ℝ) / 2500) ((1951 : ℝ) / 4000) := by
      have hz : ((1219 : ℝ) / 2500) ≤ 2 * ((13 : ℝ) / 5) - ((3 : ℝ) / 2) * π ∧ 2 * ((13 : ℝ) / 5) - ((3 : ℝ) / 2) * π ≤ ((1951 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4884883 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((13 : ℝ) / 5)) ^ 2 ≤ ((99711391 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((13 : ℝ) / 5)) 2]
    have hx : RB |3 * ((13 : ℝ) / 5) - ((5 : ℝ) / 2) * π| ((43 : ℝ) / 800) ((27 : ℝ) / 500) := by
      have hz : ((-27 : ℝ) / 500) ≤ 3 * ((13 : ℝ) / 5) - ((5 : ℝ) / 2) * π ∧ 3 * ((13 : ℝ) / 5) - ((5 : ℝ) / 2) * π ≤ ((-43 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99711391 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((13 : ℝ) / 5)) ^ 2 ≤ ((8598657 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (4 * ((13 : ℝ) / 5)) 3]
    have hx : RB |4 * ((13 : ℝ) / 5) - ((7 : ℝ) / 2) * π| ((2381 : ℝ) / 4000) ((1489 : ℝ) / 2500) := by
      have hz : ((-1489 : ℝ) / 2500) ≤ 4 * ((13 : ℝ) / 5) - ((7 : ℝ) / 2) * π ∧ 4 * ((13 : ℝ) / 5) - ((7 : ℝ) / 2) * π ≤ ((-2381 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8598657 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((13 : ℝ) / 5)) ^ 2 ≤ ((17687677 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (5 * ((13 : ℝ) / 5)) 4]
    have hx : RB |5 * ((13 : ℝ) / 5) - (4 : ℝ) * π| ((271 : ℝ) / 625) ((217 : ℝ) / 500) := by
      have hz : ((271 : ℝ) / 625) ≤ 5 * ((13 : ℝ) / 5) - (4 : ℝ) * π ∧ 5 * ((13 : ℝ) / 5) - (4 : ℝ) * π ≤ ((217 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17687677 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((13 : ℝ) / 5)) ^ 2 ≤ ((72621 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (6 * ((13 : ℝ) / 5)) 5]
    have hx : RB |6 * ((13 : ℝ) / 5) - (5 : ℝ) * π| ((43 : ℝ) / 400) ((27 : ℝ) / 250) := by
      have hz : ((-27 : ℝ) / 250) ≤ 6 * ((13 : ℝ) / 5) - (5 : ℝ) * π ∧ 6 * ((13 : ℝ) / 5) - (5 : ℝ) * π ≤ ((-43 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((72621 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((13 : ℝ) / 5)) ^ 2 ≤ ((36626319 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((13 : ℝ) / 5)) 6]
    have hx : RB |7 * ((13 : ℝ) / 5) - (6 : ℝ) * π| ((649 : ℝ) / 1000) ((406 : ℝ) / 625) := by
      have hz : ((-406 : ℝ) / 625) ≤ 7 * ((13 : ℝ) / 5) - (6 : ℝ) * π ∧ 7 * ((13 : ℝ) / 5) - (6 : ℝ) * π ≤ ((-649 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((36626319 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((13 : ℝ) / 5)) ^ 2 ≤ ((86311679 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((13 : ℝ) / 5)) 6]
    have hx : RB |8 * ((13 : ℝ) / 5) - ((13 : ℝ) / 2) * π| ((949 : ℝ) / 2500) ((1521 : ℝ) / 4000) := by
      have hz : ((949 : ℝ) / 2500) ≤ 8 * ((13 : ℝ) / 5) - ((13 : ℝ) / 2) * π ∧ 8 * ((13 : ℝ) / 5) - ((13 : ℝ) / 2) * π ≤ ((1521 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((86311679 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((13 : ℝ) / 5)) ^ 2 ≤ ((24355957 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (9 * ((13 : ℝ) / 5)) 7]
    have hx : RB |9 * ((13 : ℝ) / 5) - ((15 : ℝ) / 2) * π| ((129 : ℝ) / 800) ((81 : ℝ) / 500) := by
      have hz : ((-81 : ℝ) / 500) ≤ 9 * ((13 : ℝ) / 5) - ((15 : ℝ) / 2) * π ∧ 9 * ((13 : ℝ) / 5) - ((15 : ℝ) / 2) * π ≤ ((-129 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24355957 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((13 : ℝ) / 5)) ^ 2 ≤ ((14662607 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (10 * ((13 : ℝ) / 5)) 8]
    have hx : RB |10 * ((13 : ℝ) / 5) - ((17 : ℝ) / 2) * π| ((2811 : ℝ) / 4000) ((1759 : ℝ) / 2500) := by
      have hz : ((-1759 : ℝ) / 2500) ≤ 10 * ((13 : ℝ) / 5) - ((17 : ℝ) / 2) * π ∧ 10 * ((13 : ℝ) / 5) - ((17 : ℝ) / 2) * π ≤ ((-2811 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((14662607 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((13 : ℝ) / 5)) ^ 2 ≤ ((5145119 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (11 * ((13 : ℝ) / 5)) 9]
    have hx : RB |11 * ((13 : ℝ) / 5) - (9 : ℝ) * π| ((407 : ℝ) / 1250) ((653 : ℝ) / 2000) := by
      have hz : ((407 : ℝ) / 1250) ≤ 11 * ((13 : ℝ) / 5) - (9 : ℝ) * π ∧ 11 * ((13 : ℝ) / 5) - (9 : ℝ) * π ≤ ((653 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5145119 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((13 : ℝ) / 5)) ^ 2 ≤ ((114863 : ℝ) / 2500000) := by
    rw [sin_sq_shift_pi (12 * ((13 : ℝ) / 5)) 10]
    have hx : RB |12 * ((13 : ℝ) / 5) - (10 : ℝ) * π| ((43 : ℝ) / 200) ((27 : ℝ) / 125) := by
      have hz : ((-27 : ℝ) / 125) ≤ 12 * ((13 : ℝ) / 5) - (10 : ℝ) * π ∧ 12 * ((13 : ℝ) / 5) - (10 : ℝ) * π ≤ ((-43 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((114863 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((13 : ℝ) / 5) n) ≤ ((3087807 : ℝ) / 50000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((9459447 : ℝ) / 50000000) ≤ Real.log (π / ((13 : ℝ) / 5)) := by
    apply cov_log_2671.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((13 : ℝ) / 5)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_61 : ((1609809 : ℝ) / 12500000) ≤ hfun ((259 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((259 : ℝ) / 100)) ^ 2 ≤ ((27473741 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((259 : ℝ) / 100)) 1]
    have hx : RB |1 * ((259 : ℝ) / 100) - (1 : ℝ) * π| ((1103 : ℝ) / 2000) ((1379 : ℝ) / 2500) := by
      have hz : ((-1379 : ℝ) / 2500) ≤ 1 * ((259 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((259 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-1103 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((27473741 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((259 : ℝ) / 100)) ^ 2 ≤ ((39887481 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (2 * ((259 : ℝ) / 100)) 1]
    have hx : RB |2 * ((259 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((1169 : ℝ) / 2500) ((1871 : ℝ) / 4000) := by
      have hz : ((1169 : ℝ) / 2500) ≤ 2 * ((259 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((259 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((1871 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((39887481 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((259 : ℝ) / 100)) ^ 2 ≤ ((99300341 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((259 : ℝ) / 100)) 2]
    have hx : RB |3 * ((259 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((67 : ℝ) / 800) ((21 : ℝ) / 250) := by
      have hz : ((-21 : ℝ) / 250) ≤ 3 * ((259 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((259 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((-67 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99300341 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((259 : ℝ) / 100)) ^ 2 ≤ ((16270293 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (4 * ((259 : ℝ) / 100)) 3]
    have hx : RB |4 * ((259 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((2541 : ℝ) / 4000) ((1589 : ℝ) / 2500) := by
      have hz : ((-1589 : ℝ) / 2500) ≤ 4 * ((259 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 4 * ((259 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-2541 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((16270293 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((259 : ℝ) / 100)) ^ 2 ≤ ((7019097 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (5 * ((259 : ℝ) / 100)) 4]
    have hx : RB |5 * ((259 : ℝ) / 100) - (4 : ℝ) * π| ((959 : ℝ) / 2500) ((48 : ℝ) / 125) := by
      have hz : ((959 : ℝ) / 2500) ≤ 5 * ((259 : ℝ) / 100) - (4 : ℝ) * π ∧ 5 * ((259 : ℝ) / 100) - (4 : ℝ) * π ≤ ((48 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((7019097 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((259 : ℝ) / 100)) ^ 2 ≤ ((279619 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (6 * ((259 : ℝ) / 100)) 5]
    have hx : RB |6 * ((259 : ℝ) / 100) - (5 : ℝ) * π| ((67 : ℝ) / 400) ((21 : ℝ) / 125) := by
      have hz : ((-21 : ℝ) / 125) ≤ 6 * ((259 : ℝ) / 100) - (5 : ℝ) * π ∧ 6 * ((259 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-67 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((279619 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((259 : ℝ) / 100)) ^ 2 ≤ ((43504629 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((259 : ℝ) / 100)) 6]
    have hx : RB |7 * ((259 : ℝ) / 100) - (6 : ℝ) * π| ((719 : ℝ) / 1000) ((1799 : ℝ) / 2500) := by
      have hz : ((-1799 : ℝ) / 2500) ≤ 7 * ((259 : ℝ) / 100) - (6 : ℝ) * π ∧ 7 * ((259 : ℝ) / 100) - (6 : ℝ) * π ≤ ((-719 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((43504629 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((259 : ℝ) / 100)) ^ 2 ≤ ((45653141 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((259 : ℝ) / 100)) 6]
    have hx : RB |8 * ((259 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((749 : ℝ) / 2500) ((1201 : ℝ) / 4000) := by
      have hz : ((749 : ℝ) / 2500) ≤ 8 * ((259 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 8 * ((259 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((1201 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45653141 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((259 : ℝ) / 100)) ^ 2 ≤ ((18765531 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (9 * ((259 : ℝ) / 100)) 7]
    have hx : RB |9 * ((259 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((201 : ℝ) / 800) ((63 : ℝ) / 250) := by
      have hz : ((-63 : ℝ) / 250) ≤ 9 * ((259 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 9 * ((259 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((-201 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18765531 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((259 : ℝ) / 100)) ^ 2 ≤ ((48359511 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (10 * ((259 : ℝ) / 100)) 8]
    have hx : RB |10 * ((259 : ℝ) / 100) - (8 : ℝ) * π| ((959 : ℝ) / 1250) ((96 : ℝ) / 125) := by
      have hz : ((959 : ℝ) / 1250) ≤ 10 * ((259 : ℝ) / 100) - (8 : ℝ) * π ∧ 10 * ((259 : ℝ) / 100) - (8 : ℝ) * π ≤ ((96 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((48359511 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((259 : ℝ) / 100)) ^ 2 ≤ ((923077 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (11 * ((259 : ℝ) / 100)) 9]
    have hx : RB |11 * ((259 : ℝ) / 100) - (9 : ℝ) * π| ((539 : ℝ) / 2500) ((433 : ℝ) / 2000) := by
      have hz : ((539 : ℝ) / 2500) ≤ 11 * ((259 : ℝ) / 100) - (9 : ℝ) * π ∧ 11 * ((259 : ℝ) / 100) - (9 : ℝ) * π ≤ ((433 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((923077 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((259 : ℝ) / 100)) ^ 2 ≤ ((10875283 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((259 : ℝ) / 100)) 10]
    have hx : RB |12 * ((259 : ℝ) / 100) - (10 : ℝ) * π| ((67 : ℝ) / 200) ((42 : ℝ) / 125) := by
      have hz : ((-42 : ℝ) / 125) ≤ 12 * ((259 : ℝ) / 100) - (10 : ℝ) * π ∧ 12 * ((259 : ℝ) / 100) - (10 : ℝ) * π ≤ ((-67 : ℝ) / 200) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((10875283 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((259 : ℝ) / 100) n) ≤ ((6374017 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((19304251 : ℝ) / 100000000) ≤ Real.log (π / ((259 : ℝ) / 100)) := by
    apply cov_log_2672.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((259 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_35 : ((25340677 : ℝ) / 100000000) ≤ hfun ((17 : ℝ) / 10) := by
  have s1 : Real.sin (1 * ((17 : ℝ) / 10)) ^ 2 ≤ ((19668117 : ℝ) / 20000000) := by
    rw [sin_sq_shift_half_pi (1 * ((17 : ℝ) / 10)) 0]
    have hx : RB |1 * ((17 : ℝ) / 10) - ((1 : ℝ) / 2) * π| ((323 : ℝ) / 2500) ((517 : ℝ) / 4000) := by
      have hz : ((323 : ℝ) / 2500) ≤ 1 * ((17 : ℝ) / 10) - ((1 : ℝ) / 2) * π ∧ 1 * ((17 : ℝ) / 10) - ((1 : ℝ) / 2) * π ≤ ((517 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((19668117 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((17 : ℝ) / 10)) ^ 2 ≤ ((261399 : ℝ) / 4000000) := by
    rw [sin_sq_shift_pi (2 * ((17 : ℝ) / 10)) 1]
    have hx : RB |2 * ((17 : ℝ) / 10) - (1 : ℝ) * π| ((323 : ℝ) / 1250) ((517 : ℝ) / 2000) := by
      have hz : ((323 : ℝ) / 1250) ≤ 2 * ((17 : ℝ) / 10) - (1 : ℝ) * π ∧ 2 * ((17 : ℝ) / 10) - (1 : ℝ) * π ≤ ((517 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((261399 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((17 : ℝ) / 10)) ^ 2 ≤ ((214397 : ℝ) / 250000) := by
    rw [sin_sq_shift_half_pi (3 * ((17 : ℝ) / 10)) 1]
    have hx : RB |3 * ((17 : ℝ) / 10) - ((3 : ℝ) / 2) * π| ((969 : ℝ) / 2500) ((1551 : ℝ) / 4000) := by
      have hz : ((969 : ℝ) / 2500) ≤ 3 * ((17 : ℝ) / 10) - ((3 : ℝ) / 2) * π ∧ 3 * ((17 : ℝ) / 10) - ((3 : ℝ) / 2) * π ≤ ((1551 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((214397 : ℝ) / 250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((17 : ℝ) / 10)) ^ 2 ≤ ((6109911 : ℝ) / 25000000) := by
    rw [sin_sq_shift_pi (4 * ((17 : ℝ) / 10)) 2]
    have hx : RB |4 * ((17 : ℝ) / 10) - (2 : ℝ) * π| ((323 : ℝ) / 625) ((517 : ℝ) / 1000) := by
      have hz : ((323 : ℝ) / 625) ≤ 4 * ((17 : ℝ) / 10) - (2 : ℝ) * π ∧ 4 * ((17 : ℝ) / 10) - (2 : ℝ) * π ≤ ((517 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((6109911 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((17 : ℝ) / 10)) ^ 2 ≤ ((64068259 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (5 * ((17 : ℝ) / 10)) 2]
    have hx : RB |5 * ((17 : ℝ) / 10) - ((5 : ℝ) / 2) * π| ((323 : ℝ) / 500) ((517 : ℝ) / 800) := by
      have hz : ((323 : ℝ) / 500) ≤ 5 * ((17 : ℝ) / 10) - ((5 : ℝ) / 2) * π ∧ 5 * ((17 : ℝ) / 10) - ((5 : ℝ) / 2) * π ≤ ((517 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((64068259 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((17 : ℝ) / 10)) ^ 2 ≤ ((4909301 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (6 * ((17 : ℝ) / 10)) 3]
    have hx : RB |6 * ((17 : ℝ) / 10) - (3 : ℝ) * π| ((969 : ℝ) / 1250) ((1551 : ℝ) / 2000) := by
      have hz : ((969 : ℝ) / 1250) ≤ 6 * ((17 : ℝ) / 10) - (3 : ℝ) * π ∧ 6 * ((17 : ℝ) / 10) - (3 : ℝ) * π ≤ ((1551 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4909301 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((17 : ℝ) / 10)) ^ 2 ≤ ((38251693 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (7 * ((17 : ℝ) / 10)) 4]
    have hx : RB |7 * ((17 : ℝ) / 10) - (4 : ℝ) * π| ((333 : ℝ) / 500) ((833 : ℝ) / 1250) := by
      have hz : ((-833 : ℝ) / 1250) ≤ 7 * ((17 : ℝ) / 10) - (4 : ℝ) * π ∧ 7 * ((17 : ℝ) / 10) - (4 : ℝ) * π ≤ ((-333 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((38251693 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((17 : ℝ) / 10)) ^ 2 ≤ ((9251177 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (8 * ((17 : ℝ) / 10)) 4]
    have hx : RB |8 * ((17 : ℝ) / 10) - ((9 : ℝ) / 2) * π| ((2147 : ℝ) / 4000) ((1343 : ℝ) / 2500) := by
      have hz : ((-1343 : ℝ) / 2500) ≤ 8 * ((17 : ℝ) / 10) - ((9 : ℝ) / 2) * π ∧ 8 * ((17 : ℝ) / 10) - ((9 : ℝ) / 2) * π ≤ ((-2147 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9251177 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((17 : ℝ) / 10)) ^ 2 ≤ ((492119 : ℝ) / 3125000) := by
    rw [sin_sq_shift_pi (9 * ((17 : ℝ) / 10)) 5]
    have hx : RB |9 * ((17 : ℝ) / 10) - (5 : ℝ) * π| ((163 : ℝ) / 400) ((51 : ℝ) / 125) := by
      have hz : ((-51 : ℝ) / 125) ≤ 9 * ((17 : ℝ) / 10) - (5 : ℝ) * π ∧ 9 * ((17 : ℝ) / 10) - (5 : ℝ) * π ≤ ((-163 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((492119 : ℝ) / 3125000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((17 : ℝ) / 10)) ^ 2 ≤ ((46234031 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (10 * ((17 : ℝ) / 10)) 5]
    have hx : RB |10 * ((17 : ℝ) / 10) - ((11 : ℝ) / 2) * π| ((1113 : ℝ) / 4000) ((697 : ℝ) / 2500) := by
      have hz : ((-697 : ℝ) / 2500) ≤ 10 * ((17 : ℝ) / 10) - ((11 : ℝ) / 2) * π ∧ 10 * ((17 : ℝ) / 10) - ((11 : ℝ) / 2) * π ≤ ((-1113 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((46234031 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((17 : ℝ) / 10)) ^ 2 ≤ ((1110787 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (11 * ((17 : ℝ) / 10)) 6]
    have hx : RB |11 * ((17 : ℝ) / 10) - (6 : ℝ) * π| ((149 : ℝ) / 1000) ((187 : ℝ) / 1250) := by
      have hz : ((-187 : ℝ) / 1250) ≤ 11 * ((17 : ℝ) / 10) - (6 : ℝ) * π ∧ 11 * ((17 : ℝ) / 10) - (6 : ℝ) * π ≤ ((-149 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1110787 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((17 : ℝ) / 10)) ^ 2 ≤ ((99961 : ℝ) / 100000) := by
    rw [sin_sq_shift_half_pi (12 * ((17 : ℝ) / 10)) 6]
    have hx : RB |12 * ((17 : ℝ) / 10) - ((13 : ℝ) / 2) * π| ((79 : ℝ) / 4000) ((51 : ℝ) / 2500) := by
      have hz : ((-51 : ℝ) / 2500) ≤ 12 * ((17 : ℝ) / 10) - ((13 : ℝ) / 2) * π ∧ 12 * ((17 : ℝ) / 10) - ((13 : ℝ) / 2) * π ≤ ((-79 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99961 : ℝ) / 100000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((17 : ℝ) / 10) n) ≤ ((35946389 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((61407213 : ℝ) / 100000000) ≤ Real.log (π / ((17 : ℝ) / 10)) := by
    apply cov_log_2673.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((17 : ℝ) / 10)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_65 : ((7503397 : ℝ) / 50000000) ≤ hfun ((247 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((247 : ℝ) / 100)) ^ 2 ≤ ((38750841 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((247 : ℝ) / 100)) 1]
    have hx : RB |1 * ((247 : ℝ) / 100) - (1 : ℝ) * π| ((1343 : ℝ) / 2000) ((1679 : ℝ) / 2500) := by
      have hz : ((-1679 : ℝ) / 2500) ≤ 1 * ((247 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((247 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-1343 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((38750841 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((247 : ℝ) / 100)) ^ 2 ≤ ((23728553 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (2 * ((247 : ℝ) / 100)) 1]
    have hx : RB |2 * ((247 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((569 : ℝ) / 2500) ((911 : ℝ) / 4000) := by
      have hz : ((569 : ℝ) / 2500) ≤ 2 * ((247 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((247 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((911 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23728553 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((247 : ℝ) / 100)) ^ 2 ≤ ((5102709 : ℝ) / 6250000) := by
    rw [sin_sq_shift_half_pi (3 * ((247 : ℝ) / 100)) 2]
    have hx : RB |3 * ((247 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((71 : ℝ) / 160) ((111 : ℝ) / 250) := by
      have hz : ((-111 : ℝ) / 250) ≤ 3 * ((247 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((247 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((-71 : ℝ) / 160) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5102709 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((247 : ℝ) / 100)) ^ 2 ≤ ((9678943 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((247 : ℝ) / 100)) 3]
    have hx : RB |4 * ((247 : ℝ) / 100) - (3 : ℝ) * π| ((569 : ℝ) / 1250) ((911 : ℝ) / 2000) := by
      have hz : ((569 : ℝ) / 1250) ≤ 4 * ((247 : ℝ) / 100) - (3 : ℝ) * π ∧ 4 * ((247 : ℝ) / 100) - (3 : ℝ) * π ≤ ((911 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9678943 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((247 : ℝ) / 100)) ^ 2 ≤ ((4610689 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (5 * ((247 : ℝ) / 100)) 4]
    have hx : RB |5 * ((247 : ℝ) / 100) - (4 : ℝ) * π| ((27 : ℝ) / 125) ((541 : ℝ) / 2500) := by
      have hz : ((-541 : ℝ) / 2500) ≤ 5 * ((247 : ℝ) / 100) - (4 : ℝ) * π ∧ 5 * ((247 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-27 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4610689 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((247 : ℝ) / 100)) ^ 2 ≤ ((60566161 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (6 * ((247 : ℝ) / 100)) 4]
    have hx : RB |6 * ((247 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((1707 : ℝ) / 2500) ((2733 : ℝ) / 4000) := by
      have hz : ((1707 : ℝ) / 2500) ≤ 6 * ((247 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 6 * ((247 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((2733 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((60566161 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((247 : ℝ) / 100)) ^ 2 ≤ ((99987457 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (7 * ((247 : ℝ) / 100)) 5]
    have hx : RB |7 * ((247 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((7 : ℝ) / 625) ((47 : ℝ) / 4000) := by
      have hz : ((7 : ℝ) / 625) ≤ 7 * ((247 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 7 * ((247 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((47 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((99987457 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((247 : ℝ) / 100)) ^ 2 ≤ ((62769433 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (8 * ((247 : ℝ) / 100)) 6]
    have hx : RB |8 * ((247 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((2639 : ℝ) / 4000) ((1651 : ℝ) / 2500) := by
      have hz : ((-1651 : ℝ) / 2500) ≤ 8 * ((247 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 8 * ((247 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((-2639 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((62769433 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((247 : ℝ) / 100)) ^ 2 ≤ ((28141 : ℝ) / 500000) := by
    rw [sin_sq_shift_pi (9 * ((247 : ℝ) / 100)) 7]
    have hx : RB |9 * ((247 : ℝ) / 100) - (7 : ℝ) * π| ((597 : ℝ) / 2500) ((479 : ℝ) / 2000) := by
      have hz : ((597 : ℝ) / 2500) ≤ 9 * ((247 : ℝ) / 100) - (7 : ℝ) * π ∧ 9 * ((247 : ℝ) / 100) - (7 : ℝ) * π ≤ ((479 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((28141 : ℝ) / 500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((247 : ℝ) / 100)) ^ 2 ≤ ((8799639 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (10 * ((247 : ℝ) / 100)) 8]
    have hx : RB |10 * ((247 : ℝ) / 100) - (8 : ℝ) * π| ((54 : ℝ) / 125) ((541 : ℝ) / 1250) := by
      have hz : ((-541 : ℝ) / 1250) ≤ 10 * ((247 : ℝ) / 100) - (8 : ℝ) * π ∧ 10 * ((247 : ℝ) / 100) - (8 : ℝ) * π ≤ ((-54 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8799639 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((247 : ℝ) / 100)) ^ 2 ≤ ((79873197 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((247 : ℝ) / 100)) 8]
    have hx : RB |11 * ((247 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((583 : ℝ) / 1250) ((1869 : ℝ) / 4000) := by
      have hz : ((583 : ℝ) / 1250) ≤ 11 * ((247 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 11 * ((247 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((1869 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((79873197 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((247 : ℝ) / 100)) ^ 2 ≤ ((95889789 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((247 : ℝ) / 100)) 9]
    have hx : RB |12 * ((247 : ℝ) / 100) - ((19 : ℝ) / 2) * π| ((817 : ℝ) / 4000) ((513 : ℝ) / 2500) := by
      have hz : ((-513 : ℝ) / 2500) ≤ 12 * ((247 : ℝ) / 100) - ((19 : ℝ) / 2) * π ∧ 12 * ((247 : ℝ) / 100) - ((19 : ℝ) / 2) * π ≤ ((-817 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((95889789 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((247 : ℝ) / 100) n) ≤ ((1796903 : ℝ) / 20000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((24048223 : ℝ) / 100000000) ≤ Real.log (π / ((247 : ℝ) / 100)) := by
    apply cov_log_2674.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((247 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_66 : ((3141749 : ℝ) / 12500000) ≤ hfun ((43 : ℝ) / 25) := by
  have s1 : Real.sin (1 * ((43 : ℝ) / 25)) ^ 2 ≤ ((24447859 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (1 * ((43 : ℝ) / 25)) 0]
    have hx : RB |1 * ((43 : ℝ) / 25) - ((1 : ℝ) / 2) * π| ((373 : ℝ) / 2500) ((597 : ℝ) / 4000) := by
      have hz : ((373 : ℝ) / 2500) ≤ 1 * ((43 : ℝ) / 25) - ((1 : ℝ) / 2) * π ∧ 1 * ((43 : ℝ) / 25) - ((1 : ℝ) / 2) * π ≤ ((597 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24447859 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((43 : ℝ) / 25)) ^ 2 ≤ ((4324603 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (2 * ((43 : ℝ) / 25)) 1]
    have hx : RB |2 * ((43 : ℝ) / 25) - (1 : ℝ) * π| ((373 : ℝ) / 1250) ((597 : ℝ) / 2000) := by
      have hz : ((373 : ℝ) / 1250) ≤ 2 * ((43 : ℝ) / 25) - (1 : ℝ) * π ∧ 2 * ((43 : ℝ) / 25) - (1 : ℝ) * π ≤ ((597 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4324603 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((43 : ℝ) / 25)) ^ 2 ≤ ((81346053 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (3 * ((43 : ℝ) / 25)) 1]
    have hx : RB |3 * ((43 : ℝ) / 25) - ((3 : ℝ) / 2) * π| ((1119 : ℝ) / 2500) ((1791 : ℝ) / 4000) := by
      have hz : ((1119 : ℝ) / 2500) ≤ 3 * ((43 : ℝ) / 25) - ((3 : ℝ) / 2) * π ∧ 3 * ((43 : ℝ) / 25) - ((3 : ℝ) / 2) * π ≤ ((1791 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((81346053 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((43 : ℝ) / 25)) ^ 2 ≤ ((1976353 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (4 * ((43 : ℝ) / 25)) 2]
    have hx : RB |4 * ((43 : ℝ) / 25) - (2 : ℝ) * π| ((373 : ℝ) / 625) ((597 : ℝ) / 1000) := by
      have hz : ((373 : ℝ) / 625) ≤ 4 * ((43 : ℝ) / 25) - (2 : ℝ) * π ∧ 4 * ((43 : ℝ) / 25) - (2 : ℝ) * π ≤ ((597 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1976353 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((43 : ℝ) / 25)) ^ 2 ≤ ((5444881 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (5 * ((43 : ℝ) / 25)) 2]
    have hx : RB |5 * ((43 : ℝ) / 25) - ((5 : ℝ) / 2) * π| ((373 : ℝ) / 500) ((597 : ℝ) / 800) := by
      have hz : ((373 : ℝ) / 500) ≤ 5 * ((43 : ℝ) / 25) - ((5 : ℝ) / 2) * π ∧ 5 * ((43 : ℝ) / 25) - ((5 : ℝ) / 2) * π ≤ ((597 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((5444881 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((43 : ℝ) / 25)) ^ 2 ≤ ((15322113 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (6 * ((43 : ℝ) / 25)) 3]
    have hx : RB |6 * ((43 : ℝ) / 25) - ((7 : ℝ) / 2) * π| ((2701 : ℝ) / 4000) ((1689 : ℝ) / 2500) := by
      have hz : ((-1689 : ℝ) / 2500) ≤ 6 * ((43 : ℝ) / 25) - ((7 : ℝ) / 2) * π ∧ 6 * ((43 : ℝ) / 25) - ((7 : ℝ) / 2) * π ≤ ((-2701 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15322113 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((43 : ℝ) / 25)) ^ 2 ≤ ((12627771 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((43 : ℝ) / 25)) 4]
    have hx : RB |7 * ((43 : ℝ) / 25) - (4 : ℝ) * π| ((263 : ℝ) / 500) ((329 : ℝ) / 625) := by
      have hz : ((-329 : ℝ) / 625) ≤ 7 * ((43 : ℝ) / 25) - (4 : ℝ) * π ∧ 7 * ((43 : ℝ) / 25) - (4 : ℝ) * π ≤ ((-263 : ℝ) / 500) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12627771 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((43 : ℝ) / 25)) ^ 2 ≤ ((43252819 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((43 : ℝ) / 25)) 4]
    have hx : RB |8 * ((43 : ℝ) / 25) - ((9 : ℝ) / 2) * π| ((1507 : ℝ) / 4000) ((943 : ℝ) / 2500) := by
      have hz : ((-943 : ℝ) / 2500) ≤ 8 * ((43 : ℝ) / 25) - ((9 : ℝ) / 2) * π ∧ 8 * ((43 : ℝ) / 25) - ((9 : ℝ) / 2) * π ≤ ((-1507 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((43252819 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((43 : ℝ) / 25)) ^ 2 ≤ ((2554789 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (9 * ((43 : ℝ) / 25)) 5]
    have hx : RB |9 * ((43 : ℝ) / 25) - (5 : ℝ) * π| ((91 : ℝ) / 400) ((57 : ℝ) / 250) := by
      have hz : ((-57 : ℝ) / 250) ≤ 9 * ((43 : ℝ) / 25) - (5 : ℝ) * π ∧ 9 * ((43 : ℝ) / 25) - (5 : ℝ) * π ≤ ((-91 : ℝ) / 400) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2554789 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((43 : ℝ) / 25)) ^ 2 ≤ ((12423629 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (10 * ((43 : ℝ) / 25)) 5]
    have hx : RB |10 * ((43 : ℝ) / 25) - ((11 : ℝ) / 2) * π| ((313 : ℝ) / 4000) ((197 : ℝ) / 2500) := by
      have hz : ((-197 : ℝ) / 2500) ≤ 10 * ((43 : ℝ) / 25) - ((11 : ℝ) / 2) * π ∧ 10 * ((43 : ℝ) / 25) - ((11 : ℝ) / 2) * π ≤ ((-313 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12423629 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((43 : ℝ) / 25)) ^ 2 ≤ ((20131 : ℝ) / 4000000) := by
    rw [sin_sq_shift_pi (11 * ((43 : ℝ) / 25)) 6]
    have hx : RB |11 * ((43 : ℝ) / 25) - (6 : ℝ) * π| ((44 : ℝ) / 625) ((71 : ℝ) / 1000) := by
      have hz : ((44 : ℝ) / 625) ≤ 11 * ((43 : ℝ) / 25) - (6 : ℝ) * π ∧ 11 * ((43 : ℝ) / 25) - (6 : ℝ) * π ≤ ((71 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((20131 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((43 : ℝ) / 25)) ^ 2 ≤ ((95259647 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((43 : ℝ) / 25)) 6]
    have hx : RB |12 * ((43 : ℝ) / 25) - ((13 : ℝ) / 2) * π| ((549 : ℝ) / 2500) ((881 : ℝ) / 4000) := by
      have hz : ((549 : ℝ) / 2500) ≤ 12 * ((43 : ℝ) / 25) - ((13 : ℝ) / 2) * π ∧ 12 * ((43 : ℝ) / 25) - ((13 : ℝ) / 2) * π ≤ ((881 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((95259647 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((43 : ℝ) / 25) n) ≤ ((4373281 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((60237609 : ℝ) / 100000000) ≤ Real.log (π / ((43 : ℝ) / 25)) := by
    apply cov_log_2675.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((43 : ℝ) / 25)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_69 : ((16008337 : ℝ) / 100000000) ≤ hfun ((241 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((241 : ℝ) / 100)) ^ 2 ≤ ((22341887 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (1 * ((241 : ℝ) / 100)) 1]
    have hx : RB |1 * ((241 : ℝ) / 100) - (1 : ℝ) * π| ((1463 : ℝ) / 2000) ((1829 : ℝ) / 2500) := by
      have hz : ((-1829 : ℝ) / 2500) ≤ 1 * ((241 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((241 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-1463 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((22341887 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((241 : ℝ) / 100)) ^ 2 ≤ ((24711743 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (2 * ((241 : ℝ) / 100)) 1]
    have hx : RB |2 * ((241 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((269 : ℝ) / 2500) ((431 : ℝ) / 4000) := by
      have hz : ((269 : ℝ) / 2500) ≤ 2 * ((241 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((241 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((431 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((24711743 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((241 : ℝ) / 100)) ^ 2 ≤ ((8269523 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (3 * ((241 : ℝ) / 100)) 2]
    have hx : RB |3 * ((241 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((499 : ℝ) / 800) ((78 : ℝ) / 125) := by
      have hz : ((-78 : ℝ) / 125) ≤ 3 * ((241 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((241 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((-499 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8269523 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((241 : ℝ) / 100)) ^ 2 ≤ ((457291 : ℝ) / 10000000) := by
    rw [sin_sq_shift_pi (4 * ((241 : ℝ) / 100)) 3]
    have hx : RB |4 * ((241 : ℝ) / 100) - (3 : ℝ) * π| ((269 : ℝ) / 1250) ((431 : ℝ) / 2000) := by
      have hz : ((269 : ℝ) / 1250) ≤ 4 * ((241 : ℝ) / 100) - (3 : ℝ) * π ∧ 4 * ((241 : ℝ) / 100) - (3 : ℝ) * π ≤ ((431 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((457291 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((241 : ℝ) / 100)) ^ 2 ≤ ((609767 : ℝ) / 2500000) := by
    rw [sin_sq_shift_pi (5 * ((241 : ℝ) / 100)) 4]
    have hx : RB |5 * ((241 : ℝ) / 100) - (4 : ℝ) * π| ((129 : ℝ) / 250) ((1291 : ℝ) / 2500) := by
      have hz : ((-1291 : ℝ) / 2500) ≤ 5 * ((241 : ℝ) / 100) - (4 : ℝ) * π ∧ 5 * ((241 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-129 : ℝ) / 250) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((609767 : ℝ) / 2500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((241 : ℝ) / 100)) ^ 2 ≤ ((702807 : ℝ) / 781250) := by
    rw [sin_sq_shift_half_pi (6 * ((241 : ℝ) / 100)) 4]
    have hx : RB |6 * ((241 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((807 : ℝ) / 2500) ((1293 : ℝ) / 4000) := by
      have hz : ((807 : ℝ) / 2500) ≤ 6 * ((241 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 6 * ((241 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((1293 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((702807 : ℝ) / 781250) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((241 : ℝ) / 100)) ^ 2 ≤ ((42147269 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (7 * ((241 : ℝ) / 100)) 5]
    have hx : RB |7 * ((241 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((1633 : ℝ) / 4000) ((511 : ℝ) / 1250) := by
      have hz : ((-511 : ℝ) / 1250) ≤ 7 * ((241 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 7 * ((241 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-1633 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((42147269 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((241 : ℝ) / 100)) ^ 2 ≤ ((2182593 : ℝ) / 12500000) := by
    rw [sin_sq_shift_pi (8 * ((241 : ℝ) / 100)) 6]
    have hx : RB |8 * ((241 : ℝ) / 100) - (6 : ℝ) * π| ((269 : ℝ) / 625) ((431 : ℝ) / 1000) := by
      have hz : ((269 : ℝ) / 625) ≤ 8 * ((241 : ℝ) / 100) - (6 : ℝ) * π ∧ 8 * ((241 : ℝ) / 100) - (6 : ℝ) * π ≤ ((431 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2182593 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((241 : ℝ) / 100)) ^ 2 ≤ ((8803223 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((241 : ℝ) / 100)) 7]
    have hx : RB |9 * ((241 : ℝ) / 100) - (7 : ℝ) * π| ((601 : ℝ) / 2000) ((753 : ℝ) / 2500) := by
      have hz : ((-753 : ℝ) / 2500) ≤ 9 * ((241 : ℝ) / 100) - (7 : ℝ) * π ∧ 9 * ((241 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-601 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8803223 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((241 : ℝ) / 100)) ^ 2 ≤ ((73902531 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (10 * ((241 : ℝ) / 100)) 7]
    have hx : RB |10 * ((241 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((269 : ℝ) / 500) ((431 : ℝ) / 800) := by
      have hz : ((269 : ℝ) / 500) ≤ 10 * ((241 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 10 * ((241 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((431 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((73902531 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((241 : ℝ) / 100)) ^ 2 ≤ ((48166807 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (11 * ((241 : ℝ) / 100)) 8]
    have hx : RB |11 * ((241 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((771 : ℝ) / 4000) ((121 : ℝ) / 625) := by
      have hz : ((-121 : ℝ) / 625) ≤ 11 * ((241 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 11 * ((241 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-771 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((48166807 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((241 : ℝ) / 100)) ^ 2 ≤ ((36334587 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((241 : ℝ) / 100)) 9]
    have hx : RB |12 * ((241 : ℝ) / 100) - (9 : ℝ) * π| ((807 : ℝ) / 1250) ((1293 : ℝ) / 2000) := by
      have hz : ((807 : ℝ) / 1250) ≤ 12 * ((241 : ℝ) / 100) - (9 : ℝ) * π ∧ 12 * ((241 : ℝ) / 100) - (9 : ℝ) * π ≤ ((1293 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((36334587 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((241 : ℝ) / 100) n) ≤ ((2609811 : ℝ) / 25000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((6626841 : ℝ) / 25000000) ≤ Real.log (π / ((241 : ℝ) / 100)) := by
    apply cov_log_2676.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((241 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_70 : ((16333803 : ℝ) / 100000000) ≤ hfun ((239 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((239 : ℝ) / 100)) ^ 2 ≤ ((46684867 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (1 * ((239 : ℝ) / 100)) 1]
    have hx : RB |1 * ((239 : ℝ) / 100) - (1 : ℝ) * π| ((1503 : ℝ) / 2000) ((1879 : ℝ) / 2500) := by
      have hz : ((-1879 : ℝ) / 2500) ≤ 1 * ((239 : ℝ) / 100) - (1 : ℝ) * π ∧ 1 * ((239 : ℝ) / 100) - (1 : ℝ) * π ≤ ((-1503 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((46684867 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((239 : ℝ) / 100)) ^ 2 ≤ ((49771883 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (2 * ((239 : ℝ) / 100)) 1]
    have hx : RB |2 * ((239 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((169 : ℝ) / 2500) ((271 : ℝ) / 4000) := by
      have hz : ((169 : ℝ) / 2500) ≤ 2 * ((239 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 2 * ((239 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((271 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49771883 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((239 : ℝ) / 100)) ^ 2 ≤ ((30236467 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((239 : ℝ) / 100)) 2]
    have hx : RB |3 * ((239 : ℝ) / 100) - ((5 : ℝ) / 2) * π| ((547 : ℝ) / 800) ((171 : ℝ) / 250) := by
      have hz : ((-171 : ℝ) / 250) ≤ 3 * ((239 : ℝ) / 100) - ((5 : ℝ) / 2) * π ∧ 3 * ((239 : ℝ) / 100) - ((5 : ℝ) / 2) * π ≤ ((-547 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((30236467 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((239 : ℝ) / 100)) ^ 2 ≤ ((1824893 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (4 * ((239 : ℝ) / 100)) 3]
    have hx : RB |4 * ((239 : ℝ) / 100) - (3 : ℝ) * π| ((169 : ℝ) / 1250) ((271 : ℝ) / 2000) := by
      have hz : ((169 : ℝ) / 1250) ≤ 4 * ((239 : ℝ) / 100) - (3 : ℝ) * π ∧ 4 * ((239 : ℝ) / 100) - (3 : ℝ) * π ≤ ((271 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((1824893 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((239 : ℝ) / 100)) ^ 2 ≤ ((2090427 : ℝ) / 6250000) := by
    rw [sin_sq_shift_pi (5 * ((239 : ℝ) / 100)) 4]
    have hx : RB |5 * ((239 : ℝ) / 100) - (4 : ℝ) * π| ((77 : ℝ) / 125) ((1541 : ℝ) / 2500) := by
      have hz : ((-1541 : ℝ) / 2500) ≤ 5 * ((239 : ℝ) / 100) - (4 : ℝ) * π ∧ 5 * ((239 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-77 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((2090427 : ℝ) / 6250000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((239 : ℝ) / 100)) ^ 2 ≤ ((23986729 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (6 * ((239 : ℝ) / 100)) 4]
    have hx : RB |6 * ((239 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((507 : ℝ) / 2500) ((813 : ℝ) / 4000) := by
      have hz : ((507 : ℝ) / 2500) ≤ 6 * ((239 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 6 * ((239 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((813 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((23986729 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((239 : ℝ) / 100)) ^ 2 ≤ ((18251499 : ℝ) / 25000000) := by
    rw [sin_sq_shift_half_pi (7 * ((239 : ℝ) / 100)) 5]
    have hx : RB |7 * ((239 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((2193 : ℝ) / 4000) ((343 : ℝ) / 625) := by
      have hz : ((-343 : ℝ) / 625) ≤ 7 * ((239 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 7 * ((239 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((-2193 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((18251499 : ℝ) / 25000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((239 : ℝ) / 100)) ^ 2 ≤ ((3583687 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (8 * ((239 : ℝ) / 100)) 6]
    have hx : RB |8 * ((239 : ℝ) / 100) - (6 : ℝ) * π| ((169 : ℝ) / 625) ((271 : ℝ) / 1000) := by
      have hz : ((169 : ℝ) / 625) ≤ 8 * ((239 : ℝ) / 100) - (6 : ℝ) * π ∧ 8 * ((239 : ℝ) / 100) - (6 : ℝ) * π ≤ ((271 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((3583687 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((239 : ℝ) / 100)) ^ 2 ≤ ((21433969 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (9 * ((239 : ℝ) / 100)) 7]
    have hx : RB |9 * ((239 : ℝ) / 100) - (7 : ℝ) * π| ((961 : ℝ) / 2000) ((1203 : ℝ) / 2500) := by
      have hz : ((-1203 : ℝ) / 2500) ≤ 9 * ((239 : ℝ) / 100) - (7 : ℝ) * π ∧ 9 * ((239 : ℝ) / 100) - (7 : ℝ) * π ≤ ((-961 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((21433969 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((239 : ℝ) / 100)) ^ 2 ≤ ((8903127 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (10 * ((239 : ℝ) / 100)) 7]
    have hx : RB |10 * ((239 : ℝ) / 100) - ((15 : ℝ) / 2) * π| ((169 : ℝ) / 500) ((271 : ℝ) / 800) := by
      have hz : ((169 : ℝ) / 500) ≤ 10 * ((239 : ℝ) / 100) - ((15 : ℝ) / 2) * π ∧ 10 * ((239 : ℝ) / 100) - ((15 : ℝ) / 2) * π ≤ ((271 : ℝ) / 800) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((8903127 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((239 : ℝ) / 100)) ^ 2 ≤ ((83968421 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (11 * ((239 : ℝ) / 100)) 8]
    have hx : RB |11 * ((239 : ℝ) / 100) - ((17 : ℝ) / 2) * π| ((1651 : ℝ) / 4000) ((517 : ℝ) / 1250) := by
      have hz : ((-517 : ℝ) / 1250) ≤ 11 * ((239 : ℝ) / 100) - ((17 : ℝ) / 2) * π ∧ 11 * ((239 : ℝ) / 100) - ((17 : ℝ) / 2) * π ≤ ((-1651 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((83968421 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((239 : ℝ) / 100)) ^ 2 ≤ ((15641237 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (12 * ((239 : ℝ) / 100)) 9]
    have hx : RB |12 * ((239 : ℝ) / 100) - (9 : ℝ) * π| ((507 : ℝ) / 1250) ((813 : ℝ) / 2000) := by
      have hz : ((507 : ℝ) / 1250) ≤ 12 * ((239 : ℝ) / 100) - (9 : ℝ) * π ∧ 12 * ((239 : ℝ) / 100) - (9 : ℝ) * π ≤ ((813 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((15641237 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((239 : ℝ) / 100) n) ≤ ((10946111 : ℝ) / 100000000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((13670351 : ℝ) / 50000000) ≤ Real.log (π / ((239 : ℝ) / 100)) := by
    apply cov_log_2677.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((239 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith

theorem cov_h_68 : ((12515777 : ℝ) / 50000000) ≤ hfun ((173 : ℝ) / 100) := by
  have s1 : Real.sin (1 * ((173 : ℝ) / 100)) ^ 2 ≤ ((9748821 : ℝ) / 10000000) := by
    rw [sin_sq_shift_half_pi (1 * ((173 : ℝ) / 100)) 0]
    have hx : RB |1 * ((173 : ℝ) / 100) - ((1 : ℝ) / 2) * π| ((199 : ℝ) / 1250) ((637 : ℝ) / 4000) := by
      have hz : ((199 : ℝ) / 1250) ≤ 1 * ((173 : ℝ) / 100) - ((1 : ℝ) / 2) * π ∧ 1 * ((173 : ℝ) / 100) - ((1 : ℝ) / 2) * π ≤ ((637 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9748821 : ℝ) / 10000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s2 : Real.sin (2 * ((173 : ℝ) / 100)) ^ 2 ≤ ((4903239 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (2 * ((173 : ℝ) / 100)) 1]
    have hx : RB |2 * ((173 : ℝ) / 100) - (1 : ℝ) * π| ((199 : ℝ) / 625) ((637 : ℝ) / 2000) := by
      have hz : ((199 : ℝ) / 625) ≤ 2 * ((173 : ℝ) / 100) - (1 : ℝ) * π ∧ 2 * ((173 : ℝ) / 100) - (1 : ℝ) * π ≤ ((637 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((4903239 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s3 : Real.sin (3 * ((173 : ℝ) / 100)) ^ 2 ≤ ((39486047 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (3 * ((173 : ℝ) / 100)) 1]
    have hx : RB |3 * ((173 : ℝ) / 100) - ((3 : ℝ) / 2) * π| ((597 : ℝ) / 1250) ((1911 : ℝ) / 4000) := by
      have hz : ((597 : ℝ) / 1250) ≤ 3 * ((173 : ℝ) / 100) - ((3 : ℝ) / 2) * π ∧ 3 * ((173 : ℝ) / 100) - ((3 : ℝ) / 2) * π ≤ ((1911 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((39486047 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s4 : Real.sin (4 * ((173 : ℝ) / 100)) ^ 2 ≤ ((17701859 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (4 * ((173 : ℝ) / 100)) 2]
    have hx : RB |4 * ((173 : ℝ) / 100) - (2 : ℝ) * π| ((398 : ℝ) / 625) ((637 : ℝ) / 1000) := by
      have hz : ((398 : ℝ) / 625) ≤ 4 * ((173 : ℝ) / 100) - (2 : ℝ) * π ∧ 4 * ((173 : ℝ) / 100) - (2 : ℝ) * π ≤ ((637 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((17701859 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s5 : Real.sin (5 * ((173 : ℝ) / 100)) ^ 2 ≤ ((49022619 : ℝ) / 100000000) := by
    rw [sin_sq_shift_pi (5 * ((173 : ℝ) / 100)) 3]
    have hx : RB |5 * ((173 : ℝ) / 100) - (3 : ℝ) * π| ((1549 : ℝ) / 2000) ((1937 : ℝ) / 2500) := by
      have hz : ((-1937 : ℝ) / 2500) ≤ 5 * ((173 : ℝ) / 100) - (3 : ℝ) * π ∧ 5 * ((173 : ℝ) / 100) - (3 : ℝ) * π ≤ ((-1549 : ℝ) / 2000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((49022619 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s6 : Real.sin (6 * ((173 : ℝ) / 100)) ^ 2 ≤ ((33473673 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (6 * ((173 : ℝ) / 100)) 3]
    have hx : RB |6 * ((173 : ℝ) / 100) - ((7 : ℝ) / 2) * π| ((2461 : ℝ) / 4000) ((1539 : ℝ) / 2500) := by
      have hz : ((-1539 : ℝ) / 2500) ≤ 6 * ((173 : ℝ) / 100) - ((7 : ℝ) / 2) * π ∧ 6 * ((173 : ℝ) / 100) - ((7 : ℝ) / 2) * π ≤ ((-2461 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((33473673 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s7 : Real.sin (7 * ((173 : ℝ) / 100)) ^ 2 ≤ ((9715007 : ℝ) / 50000000) := by
    rw [sin_sq_shift_pi (7 * ((173 : ℝ) / 100)) 4]
    have hx : RB |7 * ((173 : ℝ) / 100) - (4 : ℝ) * π| ((57 : ℝ) / 125) ((1141 : ℝ) / 2500) := by
      have hz : ((-1141 : ℝ) / 2500) ≤ 7 * ((173 : ℝ) / 100) - (4 : ℝ) * π ∧ 7 * ((173 : ℝ) / 100) - (4 : ℝ) * π ≤ ((-57 : ℝ) / 125) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((9715007 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s8 : Real.sin (8 * ((173 : ℝ) / 100)) ^ 2 ≤ ((45732759 : ℝ) / 50000000) := by
    rw [sin_sq_shift_half_pi (8 * ((173 : ℝ) / 100)) 4]
    have hx : RB |8 * ((173 : ℝ) / 100) - ((9 : ℝ) / 2) * π| ((1187 : ℝ) / 4000) ((743 : ℝ) / 2500) := by
      have hz : ((-743 : ℝ) / 2500) ≤ 8 * ((173 : ℝ) / 100) - ((9 : ℝ) / 2) * π ∧ 8 * ((173 : ℝ) / 100) - ((9 : ℝ) / 2) * π ≤ ((-1187 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((45732759 : ℝ) / 50000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s9 : Real.sin (9 * ((173 : ℝ) / 100)) ^ 2 ≤ ((75699 : ℝ) / 4000000) := by
    rw [sin_sq_shift_pi (9 * ((173 : ℝ) / 100)) 5]
    have hx : RB |9 * ((173 : ℝ) / 100) - (5 : ℝ) * π| ((11 : ℝ) / 80) ((69 : ℝ) / 500) := by
      have hz : ((-69 : ℝ) / 500) ≤ 9 * ((173 : ℝ) / 100) - (5 : ℝ) * π ∧ 9 * ((173 : ℝ) / 100) - (5 : ℝ) * π ≤ ((-11 : ℝ) / 80) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonpos (by linarith [hz.2])]
      constructor <;> linarith [hz.1, hz.2]
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((75699 : ℝ) / 4000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s10 : Real.sin (10 * ((173 : ℝ) / 100)) ^ 2 ≤ ((12494383 : ℝ) / 12500000) := by
    rw [sin_sq_shift_half_pi (10 * ((173 : ℝ) / 100)) 5]
    have hx : RB |10 * ((173 : ℝ) / 100) - ((11 : ℝ) / 2) * π| ((53 : ℝ) / 2500) ((87 : ℝ) / 4000) := by
      have hz : ((53 : ℝ) / 2500) ≤ 10 * ((173 : ℝ) / 100) - ((11 : ℝ) / 2) * π ∧ 10 * ((173 : ℝ) / 100) - ((11 : ℝ) / 2) * π ≤ ((87 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((12494383 : ℝ) / 12500000) by norm_num) using 1 <;> congr 1 <;> ring
  have s11 : Real.sin (11 * ((173 : ℝ) / 100)) ^ 2 ≤ ((648169 : ℝ) / 20000000) := by
    rw [sin_sq_shift_pi (11 * ((173 : ℝ) / 100)) 6]
    have hx : RB |11 * ((173 : ℝ) / 100) - (6 : ℝ) * π| ((451 : ℝ) / 2500) ((181 : ℝ) / 1000) := by
      have hz : ((451 : ℝ) / 2500) ≤ 11 * ((173 : ℝ) / 100) - (6 : ℝ) * π ∧ 11 * ((173 : ℝ) / 100) - (6 : ℝ) * π ≤ ((181 : ℝ) / 1000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := sin_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((648169 : ℝ) / 20000000) by norm_num) using 1 <;> congr 1 <;> ring
  have s12 : Real.sin (12 * ((173 : ℝ) / 100)) ^ 2 ≤ ((88931309 : ℝ) / 100000000) := by
    rw [sin_sq_shift_half_pi (12 * ((173 : ℝ) / 100)) 6]
    have hx : RB |12 * ((173 : ℝ) / 100) - ((13 : ℝ) / 2) * π| ((849 : ℝ) / 2500) ((1361 : ℝ) / 4000) := by
      have hz : ((849 : ℝ) / 2500) ≤ 12 * ((173 : ℝ) / 100) - ((13 : ℝ) / 2) * π ∧ 12 * ((173 : ℝ) / 100) - ((13 : ℝ) / 2) * π ≤ ((1361 : ℝ) / 4000) := by
        constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
      rw [abs_of_nonneg (by linarith [hz.1])]
      exact hz
    have hh := cos_sq_upper_small hx (by norm_num) (by norm_num)
    convert hh.trans (show _ ≤ ((88931309 : ℝ) / 100000000) by norm_num) using 1 <;> congr 1 <;> ring
  have hb : (∑ n ∈ range 12, tq ((173 : ℝ) / 100) n) ≤ ((4313791 : ℝ) / 12500000) := by
    norm_num [sum_range_succ, tq, xs]
    norm_num at s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12
    nlinarith [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
  have hl : ((29828949 : ℝ) / 50000000) ≤ Real.log (π / ((173 : ℝ) / 100)) := by
    apply cov_log_2678.1.trans
    apply Real.log_le_log (by norm_num)
    apply (le_div_iff₀ (by norm_num)).mpr
    linarith [Real.pi_gt_d4]
  have hh := hfun_lower_finite (X := ((173 : ℝ) / 100)) (by norm_num) (N := 12) (by norm_num) hb hl
  linarith
end EP1038.ReferenceCert
