import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk12
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_44 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((139583542892330795758525791548211 : ℝ) / 1298074214633706907132624082305024) ((285141472357513227549203150091059 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((107531249999 : ℝ) / 1000000000000) ((43933 : ℝ) / 400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1107531249999 : ℝ) / 1000000000000) ((443933 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((51066719621 : ℝ) / 500000000000) ((104209103037 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_599.1 dlower_log_600.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((51066719621 : ℝ) / 250000000000) ((104209103037 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((96945794897 : ℝ) / 200000000000) ((122220075519 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1114986887997 : ℝ) / 500000000000) ((-2208798800989 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_601.1 dlower_log_602.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2208798800989 : ℝ) / 1000000000000) ((1114986887997 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((217369809323 : ℝ) / 1000000000000) ((55333276831 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((194666723169 : ℝ) / 250000000000) ((782630190677 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((5781484863 : ℝ) / 500000000000) ((12063178057 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((152176332223 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((292289486389 : ℝ) / 1000000000000) ((228741949 : ℝ) / 781250000) := rb_widen (rb_sub (show RB ((152176332223 : ℝ) / 500000000000) ((152176332223 : ℝ) / 500000000000) ((152176332223 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((347823667777 : ℝ) / 500000000000))
  have h11 : RB z11 ((420169059019 : ℝ) / 1000000000000) ((420888113497 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((347823667777 : ℝ) / 500000000000) ((347823667777 : ℝ) / 500000000000) ((347823667777 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-433549063611 : ℝ) / 500000000000) ((-173077648857 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_603.1 dlower_log_604.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-169654293161 : ℝ) / 250000000000) ((-134769835027 : ℝ) / 200000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((152176332223 : ℝ) / 500000000000))
  have h14 : RB z14 ((-237913633907 : ℝ) / 200000000000) ((-1189568169533 : ℝ) / 1000000000000) := rb_log (show RB ((152176332223 : ℝ) / 500000000000) ((152176332223 : ℝ) / 500000000000) ((152176332223 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_605.1 dlower_log_605.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((510950996889 : ℝ) / 1000000000000) ((644648743 : ℝ) / 1250000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((22070694813 : ℝ) / 1000000000000) ((6198003983 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((5781484863 : ℝ) / 500000000000) ((12063178057 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1468077725299 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((728007273621 : ℝ) / 500000000000) ((1456514755573 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1468077725299 : ℝ) / 1000000000000) ((1468077725299 : ℝ) / 1000000000000) ((1468077725299 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((468077725299 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3110625583201 : ℝ) / 1000000000000) ((1555847113471 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((468077725299 : ℝ) / 1000000000000) ((468077725299 : ℝ) / 1000000000000) ((468077725299 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((283705964529 : ℝ) / 250000000000) ((227033469073 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_606.1 dlower_log_607.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((883649767333 : ℝ) / 1000000000000) ((444208117977 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1468077725299 : ℝ) / 1000000000000))
  have h22 : RB z22 ((191976937589 : ℝ) / 500000000000) ((19197693759 : ℝ) / 50000000000) := rb_log (show RB ((1468077725299 : ℝ) / 1000000000000) ((1468077725299 : ℝ) / 1000000000000) ((1468077725299 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_608.1 dlower_log_608.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((499695892153 : ℝ) / 1000000000000) ((63057795097 : ℝ) / 125000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((10815590077 : ℝ) / 1000000000000) ((19733386291 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1107531249999 : ℝ) / 1000000000000) ((443933 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((306656367431 : ℝ) / 250000000000) ((1231728178057 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((202966859453 : ℝ) / 125000000000) ((1630489541727 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1163725060853 : ℝ) / 1000000000000))
  have h28 : RB z28 ((59049405217 : ℝ) / 31250000000) ((1897441541167 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1163725060853 : ℝ) / 1000000000000) ((1163725060853 : ℝ) / 1000000000000) ((1163725060853 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((5781484863 : ℝ) / 500000000000) ((12063178057 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((223406683654286756009677 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((6469686547 : ℝ) / 250000000000) ((843695247 : ℝ) / 31250000000) := rb_div_signed h29 (show RB ((223406683654286756009677 : ℝ) / 500000000000000000000000) ((223406683654286756009677 : ℝ) / 500000000000000000000000) ((223406683654286756009677 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((30406304753 : ℝ) / 31250000000) ((243530313453 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1838565591563 : ℝ) / 1000000000000) ((1848338133117 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((152176332223 : ℝ) / 500000000000)) ((22070694813 : ℝ) / 1000000000000) ((6198003983 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1468077725299 : ℝ) / 1000000000000)) ((10815590077 : ℝ) / 1000000000000) ((19733386291 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((152176332223 : ℝ) / 500000000000)) (wl := ((1468077725299 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1838565591563 : ℝ) / 1000000000000) ≤ D0q (q) * (((1468077725299 : ℝ) / 1000000000000) - ((152176332223 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((1468077725299 : ℝ) / 1000000000000) * ((152176332223 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_45 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((285141472357513227549203150091059 : ℝ) / 2596148429267413814265248164610048) ((288128665643939045565278933588377 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((109832499999 : ℝ) / 1000000000000) ((177573 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1109832499999 : ℝ) / 1000000000000) ((1777573 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((20841820607 : ℝ) / 200000000000) ((26311330381 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_609.1 dlower_log_610.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((20841820607 : ℝ) / 100000000000) ((26311330381 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((482656537511 : ℝ) / 1000000000000) ((48472897449 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2208798801 : ℝ) / 1000000000) ((-2198377116253 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_611.1 dlower_log_612.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2198377116253 : ℝ) / 1000000000000) ((2208798801 : ℝ) / 1000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((13657212047 : ℝ) / 62500000000) ((220494004831 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779505995169 : ℝ) / 1000000000000) ((48842787953 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1507897257 : ℝ) / 125000000000) ((2463450807 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((132947794779 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((253578335523 : ℝ) / 1000000000000) ((126916205751 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((132947794779 : ℝ) / 500000000000) ((132947794779 : ℝ) / 500000000000) ((132947794779 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((367052205221 : ℝ) / 500000000000))
  have h11 : RB z11 ((172712717643 : ℝ) / 500000000000) ((69154307723 : ℝ) / 200000000000) := rb_div_signed h10 (show RB ((367052205221 : ℝ) / 500000000000) ((367052205221 : ℝ) / 500000000000) ((367052205221 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-212595695179 : ℝ) / 200000000000) ((-132747126879 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_613.1 dlower_log_614.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-207675329187 : ℝ) / 250000000000) ((-827817449949 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((132947794779 : ℝ) / 500000000000))
  have h14 : RB z14 ((-331162891929 : ℝ) / 250000000000) ((-662325783857 : ℝ) / 500000000000) := rb_log (show RB ((132947794779 : ℝ) / 500000000000) ((132947794779 : ℝ) / 500000000000) ((132947794779 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_615.1 dlower_log_615.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((246975125483 : ℝ) / 500000000000) ((496834117767 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2305319119 : ℝ) / 250000000000) ((443049383 : ℝ) / 31250000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1507897257 : ℝ) / 125000000000) ((2463450807 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((294772129099 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((73077169573 : ℝ) / 50000000000) ((1461797467439 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((294772129099 : ℝ) / 200000000000) ((294772129099 : ℝ) / 200000000000) ((294772129099 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((94772129099 : ℝ) / 200000000000))
  have h19 : RB z19 ((1542165830139 : ℝ) / 500000000000) ((3084867843187 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((94772129099 : ℝ) / 200000000000) ((94772129099 : ℝ) / 200000000000) ((94772129099 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1126334992161 : ℝ) / 1000000000000) ((1126508817927 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_616.1 dlower_log_617.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((438992439479 : ℝ) / 500000000000) ((44017465057 : ℝ) / 50000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((294772129099 : ℝ) / 200000000000))
  have h22 : RB z22 ((38788524757 : ℝ) / 100000000000) ((96971311893 : ℝ) / 250000000000) := rb_log (show RB ((294772129099 : ℝ) / 200000000000) ((294772129099 : ℝ) / 200000000000) ((294772129099 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_618.1 dlower_log_618.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((245049815693 : ℝ) / 500000000000) ((49246405357 : ℝ) / 100000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41958257 : ℝ) / 7812500000) ((9807516059 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1109832499999 : ℝ) / 1000000000000) ((1777573 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((615864089027 : ℝ) / 500000000000) ((246856700807 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((202546658999 : ℝ) / 125000000000) ((405933718907 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1207965055937 : ℝ) / 1000000000000))
  have h28 : RB z28 ((97867714507 : ℝ) / 50000000000) ((392282997973 : ℝ) / 200000000000) := rb_widen (rb_mul h27 (show RB ((1207965055937 : ℝ) / 1000000000000) ((1207965055937 : ℝ) / 1000000000000) ((1207965055937 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1507897257 : ℝ) / 125000000000) ((2463450807 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((39189304526022746174121 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((480965813 : ℝ) / 15625000000) ((31430141933 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((39189304526022746174121 : ℝ) / 100000000000000000000000) ((39189304526022746174121 : ℝ) / 100000000000000000000000) ((39189304526022746174121 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((968569858067 : ℝ) / 1000000000000) ((15144034187 : ℝ) / 15625000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1895834366987 : ℝ) / 1000000000000) ((1901039082331 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((132947794779 : ℝ) / 500000000000)) ((2305319119 : ℝ) / 250000000000) ((443049383 : ℝ) / 31250000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((294772129099 : ℝ) / 200000000000)) ((41958257 : ℝ) / 7812500000) ((9807516059 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((132947794779 : ℝ) / 500000000000)) (wl := ((294772129099 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1895834366987 : ℝ) / 1000000000000) ≤ D0q (q) * (((294772129099 : ℝ) / 200000000000) - ((132947794779 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((294772129099 : ℝ) / 200000000000) * ((132947794779 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_46 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((288128665643939045565278933588377 : ℝ) / 2596148429267413814265248164610048) ((582231717860729727162709434171391 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((110983124999 : ℝ) / 1000000000000) ((89707 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1110983124999 : ℝ) / 1000000000000) ((889707 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((52622660761 : ℝ) / 500000000000) ((106280467373 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_619.1 dlower_log_620.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((52622660761 : ℝ) / 250000000000) ((106280467373 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((480586245813 : ℝ) / 1000000000000) ((120664134379 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-274797139533 : ℝ) / 125000000000) ((-2188062923743 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_621.1 dlower_log_622.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2188062923743 : ℝ) / 1000000000000) ((274797139533 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((21860955623 : ℝ) / 100000000000) ((220586223677 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779413776323 : ℝ) / 1000000000000) ((78139044377 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((6158627017 : ℝ) / 500000000000) ((1257397789 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((263941368903 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((251367391013 : ℝ) / 1000000000000) ((251624114869 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((263941368903 : ℝ) / 1000000000000) ((263941368903 : ℝ) / 1000000000000) ((263941368903 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((736058631097 : ℝ) / 1000000000000))
  have h11 : RB z11 ((42688072049 : ℝ) / 125000000000) ((85463339549 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((736058631097 : ℝ) / 1000000000000) ((736058631097 : ℝ) / 1000000000000) ((736058631097 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-134299274901 : ℝ) / 125000000000) ((-1073373411073 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_623.1 dlower_log_624.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-104940170013 : ℝ) / 125000000000) ((-836602023729 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((263941368903 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-133202828799 : ℝ) / 100000000000) ((-333007071997 : ℝ) / 250000000000) := rb_log (show RB ((263941368903 : ℝ) / 1000000000000) ((263941368903 : ℝ) / 1000000000000) ((263941368903 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_625.1 dlower_log_625.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((123126731971 : ℝ) / 250000000000) ((495426264261 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((307824699 : ℝ) / 31250000000) ((927501153 : ℝ) / 62500000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((6158627017 : ℝ) / 500000000000) ((1257397789 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((73744332019 : ℝ) / 50000000000)) - (z17)
  have h18 : RB z18 ((146231266249 : ℝ) / 100000000000) ((731284693173 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((73744332019 : ℝ) / 50000000000) ((73744332019 : ℝ) / 50000000000) ((73744332019 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((23744332019 : ℝ) / 50000000000))
  have h19 : RB z19 ((769821962837 : ℝ) / 250000000000) ((76995711291 : ℝ) / 25000000000) := rb_div_signed h18 (show RB ((23744332019 : ℝ) / 50000000000) ((23744332019 : ℝ) / 50000000000) ((23744332019 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((562349176577 : ℝ) / 500000000000) ((224974779583 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_626.1 dlower_log_627.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((13696959229 : ℝ) / 15625000000) ((439482857139 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((73744332019 : ℝ) / 50000000000))
  have h22 : RB z22 ((388581132857 : ℝ) / 1000000000000) ((388581132859 : ℝ) / 1000000000000) := rb_log (show RB ((73744332019 : ℝ) / 50000000000) ((73744332019 : ℝ) / 50000000000) ((73744332019 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_628.1 dlower_log_628.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((488024257797 : ℝ) / 1000000000000) ((490384581421 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5367720281 : ℝ) / 1000000000000) ((1224791951 : ℝ) / 125000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1110983124999 : ℝ) / 1000000000000) ((889707 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((38571359501 : ℝ) / 31250000000) ((123684147789 : ℝ) / 100000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((161702209681 : ℝ) / 100000000000) ((1620373271997 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1210945271477 : ℝ) / 1000000000000))
  have h28 : RB z28 ((391625052401 : ℝ) / 200000000000) ((1962183351753 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1210945271477 : ℝ) / 1000000000000) ((1210945271477 : ℝ) / 1000000000000) ((1210945271477 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((6158627017 : ℝ) / 500000000000) ((1257397789 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((19464179941932193805157 : ℝ) / 50000000000000000000000))
  have h30 : RB z30 ((15820412253 : ℝ) / 500000000000) ((4037537777 : ℝ) / 125000000000) := rb_div_signed h29 (show RB ((19464179941932193805157 : ℝ) / 50000000000000000000000) ((19464179941932193805157 : ℝ) / 50000000000000000000000) ((19464179941932193805157 : ℝ) / 50000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((120962462223 : ℝ) / 125000000000) ((484179587747 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((378975444853 : ℝ) / 200000000000) ((14844517599 : ℝ) / 7812500000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((263941368903 : ℝ) / 1000000000000)) ((307824699 : ℝ) / 31250000000) ((927501153 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((73744332019 : ℝ) / 50000000000)) ((5367720281 : ℝ) / 1000000000000) ((1224791951 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((263941368903 : ℝ) / 1000000000000)) (wl := ((73744332019 : ℝ) / 50000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((378975444853 : ℝ) / 200000000000) ≤ D0q (q) * (((73744332019 : ℝ) / 50000000000) - ((263941368903 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((73744332019 : ℝ) / 50000000000) * ((263941368903 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_47 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((582231717860729727162709434171391 : ℝ) / 5192296858534827628530496329220096) ((147051526108395340798715250291507 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((112133749999 : ℝ) / 1000000000000) ((36251 : ℝ) / 320000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1112133749999 : ℝ) / 1000000000000) ((356251 : ℝ) / 320000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((106280467371 : ℝ) / 1000000000000) ((107314542803 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_629.1 dlower_log_630.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((106280467371 : ℝ) / 500000000000) ((107314542803 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((478518094953 : ℝ) / 1000000000000) ((240293122909 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2188062923753 : ℝ) / 1000000000000) ((-435570805733 : ℝ) / 200000000000) := rb_log hqr (by norm_num) dlower_log_631.1 dlower_log_632.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((435570805733 : ℝ) / 200000000000) ((2188062923753 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((218694850937 : ℝ) / 1000000000000) ((27583703929 : ℝ) / 125000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((97416296071 : ℝ) / 125000000000) ((781305149063 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((392936809 : ℝ) / 31250000000) ((641667481 : ℝ) / 50000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((65626035809 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((15604424601 : ℝ) / 62500000000) ((62482541337 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((65626035809 : ℝ) / 250000000000) ((65626035809 : ℝ) / 250000000000) ((65626035809 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((184373964191 : ℝ) / 250000000000))
  have h11 : RB z11 ((338538571201 : ℝ) / 1000000000000) ((169445131831 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((184373964191 : ℝ) / 250000000000) ((184373964191 : ℝ) / 250000000000) ((184373964191 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-216623449141 : ℝ) / 200000000000) ((-216415786003 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_633.1 dlower_log_634.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-846245081109 : ℝ) / 1000000000000) ((-210824242837 : ℝ) / 250000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((65626035809 : ℝ) / 250000000000))
  have h14 : RB z14 ((-1337488413319 : ℝ) / 1000000000000) ((-1337488413317 : ℝ) / 1000000000000) := rb_log (show RB ((65626035809 : ℝ) / 250000000000) ((65626035809 : ℝ) / 250000000000) ((65626035809 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_635.1 dlower_log_635.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((30702708263 : ℝ) / 62500000000) ((494191441971 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1065708639 : ℝ) / 100000000000) ((7836673509 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((392936809 : ℝ) / 31250000000) ((641667481 : ℝ) / 50000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((737959274559 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((731542599749 : ℝ) / 500000000000) ((146334457123 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((737959274559 : ℝ) / 500000000000) ((737959274559 : ℝ) / 500000000000) ((737959274559 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((237959274559 : ℝ) / 500000000000))
  have h19 : RB z19 ((3074234450851 : ℝ) / 1000000000000) ((614955888541 : ℝ) / 200000000000) := rb_div_signed h18 (show RB ((237959274559 : ℝ) / 500000000000) ((237959274559 : ℝ) / 500000000000) ((237959274559 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1123055911189 : ℝ) / 1000000000000) ((1123233172737 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_636.1 dlower_log_637.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((875231577189 : ℝ) / 1000000000000) ((438793930729 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((737959274559 : ℝ) / 500000000000))
  have h22 : RB z22 ((38928054113 : ℝ) / 100000000000) ((97320135283 : ℝ) / 250000000000) := rb_log (show RB ((737959274559 : ℝ) / 500000000000) ((737959274559 : ℝ) / 500000000000) ((737959274559 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_638.1 dlower_log_638.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((485951036057 : ℝ) / 1000000000000) ((61038415041 : ℝ) / 125000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5364790239 : ℝ) / 1000000000000) ((78313803 : ℝ) / 8000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1112133749999 : ℝ) / 1000000000000) ((356251 : ℝ) / 320000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((618420738943 : ℝ) / 500000000000) ((61970104981 : ℝ) / 50000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1613681306989 : ℝ) / 1000000000000) ((101063881051 : ℝ) / 62500000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((606707202941 : ℝ) / 500000000000))
  have h28 : RB z28 ((979032072201 : ℝ) / 500000000000) ((1962117906907 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((606707202941 : ℝ) / 500000000000) ((606707202941 : ℝ) / 500000000000) ((606707202941 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((392936809 : ℝ) / 31250000000) ((641667481 : ℝ) / 50000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((48429341777792596683231 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((1298177657 : ℝ) / 40000000000) ((33123900587 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((48429341777792596683231 : ℝ) / 125000000000000000000000) ((48429341777792596683231 : ℝ) / 125000000000000000000000) ((48429341777792596683231 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((966876099413 : ℝ) / 1000000000000) ((38701822343 : ℝ) / 40000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1893205422339 : ℝ) / 1000000000000) ((1898438466229 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((65626035809 : ℝ) / 250000000000)) ((1065708639 : ℝ) / 100000000000) ((7836673509 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((737959274559 : ℝ) / 500000000000)) ((5364790239 : ℝ) / 1000000000000) ((78313803 : ℝ) / 8000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((65626035809 : ℝ) / 250000000000)) (wl := ((737959274559 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1893205422339 : ℝ) / 1000000000000) ≤ D0q (q) * (((737959274559 : ℝ) / 500000000000) - ((65626035809 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((737959274559 : ℝ) / 500000000000) * ((65626035809 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
