import LeanProject.COVLogTwo
import LeanProject.COVLogBounds00
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_320 : RB (Real.log ((7184649 : ℝ) / 100000000)) ((-65830589 : ℝ) / 25000000) ((-263322351 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7184649 : ℝ) / 6250000)) (t := ((934649 : ℝ) / 13434649))
    (lo := ((348413 : ℝ) / 2500000)) (hi := ((13936521 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7184649 : ℝ) / 100000000) = Real.log ((7184649 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7184649 : ℝ) / 100000000) = ((7184649 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_321 : RB (Real.log ((8465541 : ℝ) / 100000000)) ((-24691663 : ℝ) / 10000000) ((-123458313 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8465541 : ℝ) / 12500000)) (t := ((-4034459 : ℝ) / 20965541))
    (lo := ((-38972473 : ℝ) / 100000000)) (hi := ((-4871559 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8465541 : ℝ) / 100000000) = Real.log ((8465541 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8465541 : ℝ) / 100000000) = ((8465541 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_322 : RB (Real.log ((1768359 : ℝ) / 100000000)) ((-16140473 : ℝ) / 4000000) ((-201755909 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1768359 : ℝ) / 1562500)) (t := ((205859 : ℝ) / 3330859))
    (lo := ((12376489 : ℝ) / 100000000)) (hi := ((1237649 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1768359 : ℝ) / 100000000) = Real.log ((1768359 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1768359 : ℝ) / 100000000) = ((1768359 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_323 : RB (Real.log ((180177 : ℝ) / 10000000)) ((-401640073 : ℝ) / 100000000) ((-200820033 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((180177 : ℝ) / 156250)) (t := ((23927 : ℝ) / 336427))
    (lo := ((14248241 : ℝ) / 100000000)) (hi := ((7124121 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((180177 : ℝ) / 10000000) = Real.log ((180177 : ℝ) / 156250) - 6 * Real.log 2 := by
    rw [show ((180177 : ℝ) / 10000000) = ((180177 : ℝ) / 156250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_324 : RB (Real.log ((76083933 : ℝ) / 100000000)) ((-6833327 : ℝ) / 25000000) ((-27333307 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76083933 : ℝ) / 100000000)) (t := ((-23916067 : ℝ) / 176083933))
    (lo := ((-6833327 : ℝ) / 25000000)) (hi := ((-27333307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_325 : RB (Real.log ((59441 : ℝ) / 78125)) ((-27332589 : ℝ) / 100000000) ((-6833147 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((59441 : ℝ) / 78125)) (t := ((-9342 : ℝ) / 68783))
    (lo := ((-27332589 : ℝ) / 100000000)) (hi := ((-6833147 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_326 : RB (Real.log ((8642771 : ℝ) / 20000000)) ((-10487613 : ℝ) / 12500000) ((-41950451 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8642771 : ℝ) / 10000000)) (t := ((-1357229 : ℝ) / 18642771))
    (lo := ((-2917237 : ℝ) / 20000000)) (hi := ((-1823273 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8642771 : ℝ) / 20000000) = Real.log ((8642771 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8642771 : ℝ) / 20000000) = ((8642771 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_327 : RB (Real.log ((196316079 : ℝ) / 100000000)) ((33727791 : ℝ) / 50000000) ((2107987 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((196316079 : ℝ) / 200000000)) (t := ((-3683921 : ℝ) / 396316079))
    (lo := ((-29049 : ℝ) / 1562500)) (hi := ((-371827 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196316079 : ℝ) / 100000000) = Real.log ((196316079 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196316079 : ℝ) / 100000000) = ((196316079 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_328 : RB (Real.log ((9819057 : ℝ) / 5000000)) ((67488717 : ℝ) / 100000000) ((67488719 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9819057 : ℝ) / 10000000)) (t := ((-180943 : ℝ) / 19819057))
    (lo := ((-1826001 : ℝ) / 100000000)) (hi := ((-913 : ℝ) / 50000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9819057 : ℝ) / 5000000) = Real.log ((9819057 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((9819057 : ℝ) / 5000000) = ((9819057 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_329 : RB (Real.log ((38798557 : ℝ) / 50000000)) ((-6340999 : ℝ) / 25000000) ((-5072799 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((38798557 : ℝ) / 50000000)) (t := ((-11201443 : ℝ) / 88798557))
    (lo := ((-6340999 : ℝ) / 25000000)) (hi := ((-5072799 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_330 : RB (Real.log ((38798833 : ℝ) / 50000000)) ((-6340821 : ℝ) / 25000000) ((-25363283 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38798833 : ℝ) / 50000000)) (t := ((-11201167 : ℝ) / 88798833))
    (lo := ((-6340821 : ℝ) / 25000000)) (hi := ((-25363283 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_331 : RB (Real.log ((4369769 : ℝ) / 10000000)) ((-10348437 : ℝ) / 12500000) ((-41393747 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4369769 : ℝ) / 5000000)) (t := ((-630231 : ℝ) / 9369769))
    (lo := ((-13472777 : ℝ) / 100000000)) (hi := ((-1684097 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4369769 : ℝ) / 10000000) = Real.log ((4369769 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((4369769 : ℝ) / 10000000) = ((4369769 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_332 : RB (Real.log ((461557377 : ℝ) / 100000000)) ((76471809 : ℝ) / 50000000) ((152943621 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((461557377 : ℝ) / 400000000)) (t := ((61557377 : ℝ) / 861557377))
    (lo := ((7157091 : ℝ) / 50000000)) (hi := ((14314183 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((461557377 : ℝ) / 100000000) = Real.log ((461557377 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((461557377 : ℝ) / 100000000) = ((461557377 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_333 : RB (Real.log ((461558499 : ℝ) / 100000000)) ((152943861 : ℝ) / 100000000) ((19117983 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((461558499 : ℝ) / 400000000)) (t := ((61558499 : ℝ) / 861558499))
    (lo := ((572577 : ℝ) / 4000000)) (hi := ((7157213 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((461558499 : ℝ) / 100000000) = Real.log ((461558499 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((461558499 : ℝ) / 100000000) = ((461558499 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_334 : RB (Real.log ((25531143 : ℝ) / 20000000)) ((763021 : ℝ) / 3125000) ((24416673 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((25531143 : ℝ) / 20000000)) (t := ((5531143 : ℝ) / 45531143))
    (lo := ((763021 : ℝ) / 3125000)) (hi := ((24416673 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_335 : RB (Real.log ((229542929 : ℝ) / 50000000)) ((30481341 : ℝ) / 20000000) ((38101677 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((229542929 : ℝ) / 200000000)) (t := ((29542929 : ℝ) / 429542929))
    (lo := ((13777269 : ℝ) / 100000000)) (hi := ((1377727 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229542929 : ℝ) / 50000000) = Real.log ((229542929 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((229542929 : ℝ) / 50000000) = ((229542929 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_336 : RB (Real.log ((114771743 : ℝ) / 25000000)) ((38101737 : ℝ) / 25000000) ((152406951 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((114771743 : ℝ) / 100000000)) (t := ((14771743 : ℝ) / 214771743))
    (lo := ((1722189 : ℝ) / 12500000)) (hi := ((13777513 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114771743 : ℝ) / 25000000) = Real.log ((114771743 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((114771743 : ℝ) / 25000000) = ((114771743 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_337 : RB (Real.log ((7990379 : ℝ) / 6250000)) ((3070709 : ℝ) / 12500000) ((24565673 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7990379 : ℝ) / 6250000)) (t := ((1740379 : ℝ) / 14240379))
    (lo := ((3070709 : ℝ) / 12500000)) (hi := ((24565673 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_338 : RB (Real.log ((1802207 : ℝ) / 25000000)) ((-16436649 : ℝ) / 6250000) ((-262986379 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1802207 : ℝ) / 1562500)) (t := ((239707 : ℝ) / 3364707))
    (lo := ((3568123 : ℝ) / 25000000)) (hi := ((14272493 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1802207 : ℝ) / 25000000) = Real.log ((1802207 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1802207 : ℝ) / 25000000) = ((1802207 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_339 : RB (Real.log ((8471987 : ℝ) / 100000000)) ((-49368103 : ℝ) / 20000000) ((-246840511 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8471987 : ℝ) / 12500000)) (t := ((-4028013 : ℝ) / 20971987))
    (lo := ((-19448179 : ℝ) / 50000000)) (hi := ((-38896357 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8471987 : ℝ) / 100000000) = Real.log ((8471987 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8471987 : ℝ) / 100000000) = ((8471987 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_340 : RB (Real.log ((1800573 : ℝ) / 100000000)) ((-40170653 : ℝ) / 10000000) ((-401706523 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1800573 : ℝ) / 1562500)) (t := ((238073 : ℝ) / 3363073))
    (lo := ((1772723 : ℝ) / 12500000)) (hi := ((2836357 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1800573 : ℝ) / 100000000) = Real.log ((1800573 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1800573 : ℝ) / 100000000) = ((1800573 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_341 : RB (Real.log ((229251 : ℝ) / 12500000)) ((-399866651 : ℝ) / 100000000) ((-99966661 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((458502 : ℝ) / 390625)) (t := ((67877 : ℝ) / 849127))
    (lo := ((16021663 : ℝ) / 100000000)) (hi := ((500677 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229251 : ℝ) / 12500000) = Real.log ((458502 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((229251 : ℝ) / 12500000) = ((458502 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_342 : RB (Real.log ((18966523 : ℝ) / 25000000)) ((-5524007 : ℝ) / 20000000) ((-13810017 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18966523 : ℝ) / 25000000)) (t := ((-6033477 : ℝ) / 43966523))
    (lo := ((-5524007 : ℝ) / 20000000)) (hi := ((-13810017 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_343 : RB (Real.log ((75866651 : ℝ) / 100000000)) ((-13809649 : ℝ) / 50000000) ((-27619297 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((75866651 : ℝ) / 100000000)) (t := ((-24133349 : ℝ) / 175866651))
    (lo := ((-13809649 : ℝ) / 50000000)) (hi := ((-27619297 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_344 : RB (Real.log ((8628739 : ℝ) / 20000000)) ((-84063391 : ℝ) / 100000000) ((-84063389 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8628739 : ℝ) / 10000000)) (t := ((-1371261 : ℝ) / 18628739))
    (lo := ((-57612 : ℝ) / 390625)) (hi := ((-14748671 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8628739 : ℝ) / 20000000) = Real.log ((8628739 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8628739 : ℝ) / 20000000) = ((8628739 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_345 : RB (Real.log ((196251013 : ℝ) / 100000000)) ((67422433 : ℝ) / 100000000) ((13484487 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((196251013 : ℝ) / 200000000)) (t := ((-3748987 : ℝ) / 396251013))
    (lo := ((-378457 : ℝ) / 20000000)) (hi := ((-473071 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196251013 : ℝ) / 100000000) = Real.log ((196251013 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196251013 : ℝ) / 100000000) = ((196251013 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_346 : RB (Real.log ((39263217 : ℝ) / 20000000)) ((13491117 : ℝ) / 20000000) ((67455587 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39263217 : ℝ) / 40000000)) (t := ((-736783 : ℝ) / 79263217))
    (lo := ((-1859133 : ℝ) / 100000000)) (hi := ((-464783 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39263217 : ℝ) / 20000000) = Real.log ((39263217 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39263217 : ℝ) / 20000000) = ((39263217 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_347 : RB (Real.log ((2417233 : ℝ) / 3125000)) ((-25681079 : ℝ) / 100000000) ((-12840539 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2417233 : ℝ) / 3125000)) (t := ((-707767 : ℝ) / 5542233))
    (lo := ((-25681079 : ℝ) / 100000000)) (hi := ((-12840539 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_348 : RB (Real.log ((77352019 : ℝ) / 100000000)) ((-25680351 : ℝ) / 100000000) ((-513607 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((77352019 : ℝ) / 100000000)) (t := ((-22647981 : ℝ) / 177352019))
    (lo := ((-25680351 : ℝ) / 100000000)) (hi := ((-513607 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_349 : RB (Real.log ((43619881 : ℝ) / 100000000)) ((-82965717 : ℝ) / 100000000) ((-16593143 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((43619881 : ℝ) / 50000000)) (t := ((-6380119 : ℝ) / 93619881))
    (lo := ((-6825499 : ℝ) / 50000000)) (hi := ((-13650997 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43619881 : ℝ) / 100000000) = Real.log ((43619881 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43619881 : ℝ) / 100000000) = ((43619881 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_350 : RB (Real.log ((460726201 : ℝ) / 100000000)) ((1222107 : ℝ) / 800000) ((76381689 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((460726201 : ℝ) / 400000000)) (t := ((60726201 : ℝ) / 860726201))
    (lo := ((14133939 : ℝ) / 100000000)) (hi := ((706697 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((460726201 : ℝ) / 100000000) = Real.log ((460726201 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((460726201 : ℝ) / 100000000) = ((460726201 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_351 : RB (Real.log ((230363673 : ℝ) / 50000000)) ((19095453 : ℝ) / 12500000) ((152763627 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((230363673 : ℝ) / 200000000)) (t := ((30363673 : ℝ) / 430363673))
    (lo := ((3533547 : ℝ) / 25000000)) (hi := ((14134189 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((230363673 : ℝ) / 50000000) = Real.log ((230363673 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((230363673 : ℝ) / 50000000) = ((230363673 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_352 : RB (Real.log ((127719351 : ℝ) / 100000000)) ((2446651 : ℝ) / 10000000) ((24466511 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127719351 : ℝ) / 100000000)) (t := ((27719351 : ℝ) / 227719351))
    (lo := ((2446651 : ℝ) / 10000000)) (hi := ((24466511 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_353 : RB (Real.log ((229136581 : ℝ) / 50000000)) ((38057381 : ℝ) / 25000000) ((152229527 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((229136581 : ℝ) / 200000000)) (t := ((29136581 : ℝ) / 429136581))
    (lo := ((1700011 : ℝ) / 12500000)) (hi := ((13600089 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229136581 : ℝ) / 50000000) = Real.log ((229136581 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((229136581 : ℝ) / 50000000) = ((229136581 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_354 : RB (Real.log ((458274299 : ℝ) / 100000000)) ((38057443 : ℝ) / 25000000) ((6089191 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((458274299 : ℝ) / 400000000)) (t := ((58274299 : ℝ) / 858274299))
    (lo := ((850021 : ℝ) / 6250000)) (hi := ((13600337 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458274299 : ℝ) / 100000000) = Real.log ((458274299 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((458274299 : ℝ) / 100000000) = ((458274299 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_355 : RB (Real.log ((127909141 : ℝ) / 100000000)) ((12307499 : ℝ) / 50000000) ((24614999 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127909141 : ℝ) / 100000000)) (t := ((27909141 : ℝ) / 227909141))
    (lo := ((12307499 : ℝ) / 50000000)) (hi := ((24614999 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_356 : RB (Real.log ((361737 : ℝ) / 5000000)) ((-262627581 : ℝ) / 100000000) ((-32828447 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((361737 : ℝ) / 312500)) (t := ((49237 : ℝ) / 674237))
    (lo := ((2926259 : ℝ) / 20000000)) (hi := ((114307 : ℝ) / 781250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((361737 : ℝ) / 5000000) = Real.log ((361737 : ℝ) / 312500) - 4 * Real.log 2 := by
    rw [show ((361737 : ℝ) / 5000000) = ((361737 : ℝ) / 312500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_357 : RB (Real.log ((1696107 : ℝ) / 20000000)) ((-61684917 : ℝ) / 25000000) ((-15421229 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((1696107 : ℝ) / 2500000)) (t := ((-803893 : ℝ) / 4196107))
    (lo := ((-38795511 : ℝ) / 100000000)) (hi := ((-3879551 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1696107 : ℝ) / 20000000) = Real.log ((1696107 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((1696107 : ℝ) / 20000000) = ((1696107 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_358 : RB (Real.log ((183279 : ℝ) / 10000000)) ((-79986617 : ℝ) / 20000000) ((-199966539 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((183279 : ℝ) / 156250)) (t := ((27029 : ℝ) / 339529))
    (lo := ((15955229 : ℝ) / 100000000)) (hi := ((1595523 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((183279 : ℝ) / 10000000) = Real.log ((183279 : ℝ) / 156250) - 6 * Real.log 2 := by
    rw [show ((183279 : ℝ) / 10000000) = ((183279 : ℝ) / 156250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_359 : RB (Real.log ((933123 : ℝ) / 50000000)) ((-99531033 : ℝ) / 25000000) ((-3184993 : ℝ) / 800000) := by
  have hm := log_bounds_of_series (x := ((933123 : ℝ) / 781250)) (t := ((151873 : ℝ) / 1714373))
    (lo := ((8882091 : ℝ) / 50000000)) (hi := ((17764183 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((933123 : ℝ) / 50000000) = Real.log ((933123 : ℝ) / 781250) - 6 * Real.log 2 := by
    rw [show ((933123 : ℝ) / 50000000) = ((933123 : ℝ) / 781250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_360 : RB (Real.log ((15130429 : ℝ) / 20000000)) ((-697561 : ℝ) / 2500000) ((-27902439 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((15130429 : ℝ) / 20000000)) (t := ((-4869571 : ℝ) / 35130429))
    (lo := ((-697561 : ℝ) / 2500000)) (hi := ((-27902439 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_361 : RB (Real.log ((9456589 : ℝ) / 12500000)) ((-2790169 : ℝ) / 10000000) ((-27901689 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9456589 : ℝ) / 12500000)) (t := ((-3043411 : ℝ) / 21956589))
    (lo := ((-2790169 : ℝ) / 10000000)) (hi := ((-27901689 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_362 : RB (Real.log ((21537313 : ℝ) / 50000000)) ((-8422361 : ℝ) / 10000000) ((-10527951 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((21537313 : ℝ) / 25000000)) (t := ((-3462687 : ℝ) / 46537313))
    (lo := ((-14908891 : ℝ) / 100000000)) (hi := ((-1490889 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21537313 : ℝ) / 50000000) = Real.log ((21537313 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21537313 : ℝ) / 50000000) = ((21537313 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_363 : RB (Real.log ((12261621 : ℝ) / 6250000)) ((67389267 : ℝ) / 100000000) ((67389269 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12261621 : ℝ) / 12500000)) (t := ((-238379 : ℝ) / 24761621))
    (lo := ((-1925451 : ℝ) / 100000000)) (hi := ((-38509 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12261621 : ℝ) / 6250000) = Real.log ((12261621 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((12261621 : ℝ) / 6250000) = ((12261621 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_364 : RB (Real.log ((196251017 : ℝ) / 100000000)) ((13484487 : ℝ) / 20000000) ((67422437 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((196251017 : ℝ) / 200000000)) (t := ((-3748983 : ℝ) / 396251017))
    (lo := ((-1892283 : ℝ) / 100000000)) (hi := ((-946141 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196251017 : ℝ) / 100000000) = Real.log ((196251017 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196251017 : ℝ) / 100000000) = ((196251017 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_365 : RB (Real.log ((2409699 : ℝ) / 3125000)) ((-6498311 : ℝ) / 25000000) ((-25993243 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2409699 : ℝ) / 3125000)) (t := ((-715301 : ℝ) / 5534699))
    (lo := ((-6498311 : ℝ) / 25000000)) (hi := ((-25993243 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_366 : RB (Real.log ((77110939 : ℝ) / 100000000)) ((-3249063 : ℝ) / 12500000) ((-25992503 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((77110939 : ℝ) / 100000000)) (t := ((-22889061 : ℝ) / 177110939))
    (lo := ((-3249063 : ℝ) / 12500000)) (hi := ((-25992503 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_367 : RB (Real.log ((10885829 : ℝ) / 25000000)) ((-83141399 : ℝ) / 100000000) ((-83141397 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10885829 : ℝ) / 12500000)) (t := ((-1614171 : ℝ) / 23385829))
    (lo := ((-345667 : ℝ) / 2500000)) (hi := ((-13826679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10885829 : ℝ) / 25000000) = Real.log ((10885829 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10885829 : ℝ) / 25000000) = ((10885829 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_368 : RB (Real.log ((367921 : ℝ) / 80000)) ((953651 : ℝ) / 625000) ((152584163 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((367921 : ℝ) / 320000)) (t := ((47921 : ℝ) / 687921))
    (lo := ((3488681 : ℝ) / 25000000)) (hi := ((558189 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((367921 : ℝ) / 80000) = Real.log ((367921 : ℝ) / 320000) + 2 * Real.log 2 := by
    rw [show ((367921 : ℝ) / 80000) = ((367921 : ℝ) / 320000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_369 : RB (Real.log ((45990241 : ℝ) / 10000000)) ((38146103 : ℝ) / 25000000) ((30516883 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((45990241 : ℝ) / 40000000)) (t := ((5990241 : ℝ) / 85990241))
    (lo := ((436093 : ℝ) / 3125000)) (hi := ((13954977 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45990241 : ℝ) / 10000000) = Real.log ((45990241 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((45990241 : ℝ) / 10000000) = ((45990241 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_370 : RB (Real.log ((127782799 : ℝ) / 100000000)) ((980647 : ℝ) / 4000000) ((1532261 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((127782799 : ℝ) / 100000000)) (t := ((27782799 : ℝ) / 227782799))
    (lo := ((980647 : ℝ) / 4000000)) (hi := ((1532261 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_371 : RB (Real.log ((14295827 : ℝ) / 3125000)) ((152053339 : ℝ) / 100000000) ((76026671 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((14295827 : ℝ) / 12500000)) (t := ((1795827 : ℝ) / 26795827))
    (lo := ((13423903 : ℝ) / 100000000)) (hi := ((419497 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14295827 : ℝ) / 3125000) = Real.log ((14295827 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((14295827 : ℝ) / 3125000) = ((14295827 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_372 : RB (Real.log ((14295863 : ℝ) / 3125000)) ((152053591 : ℝ) / 100000000) ((76026797 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((14295863 : ℝ) / 12500000)) (t := ((1795863 : ℝ) / 26795863))
    (lo := ((2684831 : ℝ) / 20000000)) (hi := ((3356039 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14295863 : ℝ) / 3125000) = Real.log ((14295863 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((14295863 : ℝ) / 3125000) = ((14295863 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_373 : RB (Real.log ((63986017 : ℝ) / 50000000)) ((6166039 : ℝ) / 25000000) ((24664157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63986017 : ℝ) / 50000000)) (t := ((13986017 : ℝ) / 113986017))
    (lo := ((6166039 : ℝ) / 25000000)) (hi := ((24664157 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_374 : RB (Real.log ((907793 : ℝ) / 12500000)) ((-262246759 : ℝ) / 100000000) ((-131123377 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((907793 : ℝ) / 781250)) (t := ((126543 : ℝ) / 1689043))
    (lo := ((15012117 : ℝ) / 100000000)) (hi := ((7506059 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((907793 : ℝ) / 12500000) = Real.log ((907793 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((907793 : ℝ) / 12500000) = ((907793 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_375 : RB (Real.log ((8491131 : ℝ) / 100000000)) ((-246614801 : ℝ) / 100000000) ((-246614797 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8491131 : ℝ) / 12500000)) (t := ((-4008869 : ℝ) / 20991131))
    (lo := ((-9667661 : ℝ) / 25000000)) (hi := ((-38670643 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8491131 : ℝ) / 100000000) = Real.log ((8491131 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8491131 : ℝ) / 100000000) = ((8491131 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_376 : RB (Real.log ((932503 : ℝ) / 50000000)) ((-199095299 : ℝ) / 50000000) ((-398190591 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((932503 : ℝ) / 781250)) (t := ((151253 : ℝ) / 1713753))
    (lo := ((4424429 : ℝ) / 25000000)) (hi := ((17697717 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((932503 : ℝ) / 50000000) = Real.log ((932503 : ℝ) / 781250) - 6 * Real.log 2 := by
    rw [show ((932503 : ℝ) / 50000000) = ((932503 : ℝ) / 781250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_377 : RB (Real.log ((474621 : ℝ) / 25000000)) ((-396411457 : ℝ) / 100000000) ((-7928229 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((474621 : ℝ) / 390625)) (t := ((41998 : ℝ) / 432623))
    (lo := ((19476857 : ℝ) / 100000000)) (hi := ((9738429 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((474621 : ℝ) / 25000000) = Real.log ((474621 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((474621 : ℝ) / 25000000) = ((474621 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_378 : RB (Real.log ((75441991 : ℝ) / 100000000)) ((-3522577 : ℝ) / 12500000) ((-5636123 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((75441991 : ℝ) / 100000000)) (t := ((-24558009 : ℝ) / 175441991))
    (lo := ((-3522577 : ℝ) / 12500000)) (hi := ((-5636123 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_379 : RB (Real.log ((9430321 : ℝ) / 12500000)) ((-28179851 : ℝ) / 100000000) ((-563597 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((9430321 : ℝ) / 12500000)) (t := ((-3069679 : ℝ) / 21930321))
    (lo := ((-28179851 : ℝ) / 100000000)) (hi := ((-563597 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_380 : RB (Real.log ((1343957 : ℝ) / 3125000)) ((-16876321 : ℝ) / 20000000) ((-84381603 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1343957 : ℝ) / 1562500)) (t := ((-218543 : ℝ) / 2906457))
    (lo := ((-7533443 : ℝ) / 50000000)) (hi := ((-3013377 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1343957 : ℝ) / 3125000) = Real.log ((1343957 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((1343957 : ℝ) / 3125000) = ((1343957 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_381 : RB (Real.log ((196120847 : ℝ) / 100000000)) ((16839021 : ℝ) / 25000000) ((33678043 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((196120847 : ℝ) / 200000000)) (t := ((-3879153 : ℝ) / 396120847))
    (lo := ((-979317 : ℝ) / 50000000)) (hi := ((-1958633 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196120847 : ℝ) / 100000000) = Real.log ((196120847 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196120847 : ℝ) / 100000000) = ((196120847 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_382 : RB (Real.log ((196185939 : ℝ) / 100000000)) ((67389269 : ℝ) / 100000000) ((67389271 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((196185939 : ℝ) / 200000000)) (t := ((-3814061 : ℝ) / 396185939))
    (lo := ((-1925449 : ℝ) / 100000000)) (hi := ((-240681 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196185939 : ℝ) / 100000000) = Real.log ((196185939 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196185939 : ℝ) / 100000000) = ((196185939 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_383 : RB (Real.log ((3843687 : ℝ) / 5000000)) ((-13150293 : ℝ) / 50000000) ((-5260117 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3843687 : ℝ) / 5000000)) (t := ((-1156313 : ℝ) / 8843687))
    (lo := ((-13150293 : ℝ) / 50000000)) (hi := ((-5260117 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_384 : RB (Real.log ((76874321 : ℝ) / 100000000)) ((-2629983 : ℝ) / 10000000) ((-26299829 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76874321 : ℝ) / 100000000)) (t := ((-23125679 : ℝ) / 176874321))
    (lo := ((-2629983 : ℝ) / 10000000)) (hi := ((-26299829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_385 : RB (Real.log ((43467971 : ℝ) / 100000000)) ((-83314583 : ℝ) / 100000000) ((-83314581 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43467971 : ℝ) / 50000000)) (t := ((-6532029 : ℝ) / 93467971))
    (lo := ((-1749983 : ℝ) / 12500000)) (hi := ((-13999863 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43467971 : ℝ) / 100000000) = Real.log ((43467971 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43467971 : ℝ) / 100000000) = ((43467971 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_386 : RB (Real.log ((91816487 : ℝ) / 20000000)) ((3810149 : ℝ) / 2500000) ((152405963 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((91816487 : ℝ) / 80000000)) (t := ((11816487 : ℝ) / 171816487))
    (lo := ((3444131 : ℝ) / 25000000)) (hi := ((551061 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91816487 : ℝ) / 20000000) = Real.log ((91816487 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((91816487 : ℝ) / 20000000) = ((91816487 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_387 : RB (Real.log ((229541807 : ℝ) / 50000000)) ((152406217 : ℝ) / 100000000) ((7620311 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((229541807 : ℝ) / 200000000)) (t := ((29541807 : ℝ) / 429541807))
    (lo := ((13776781 : ℝ) / 100000000)) (hi := ((6888391 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229541807 : ℝ) / 50000000) = Real.log ((229541807 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((229541807 : ℝ) / 50000000) = ((229541807 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_388 : RB (Real.log ((127846061 : ℝ) / 100000000)) ((2456567 : ℝ) / 10000000) ((24565671 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127846061 : ℝ) / 100000000)) (t := ((27846061 : ℝ) / 227846061))
    (lo := ((2456567 : ℝ) / 10000000)) (hi := ((24565671 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_389 : RB (Real.log ((5708321 : ℝ) / 1250000)) ((75939069 : ℝ) / 50000000) ((151878141 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5708321 : ℝ) / 5000000)) (t := ((708321 : ℝ) / 10708321))
    (lo := ((6624351 : ℝ) / 50000000)) (hi := ((13248703 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5708321 : ℝ) / 1250000) = Real.log ((5708321 : ℝ) / 5000000) + 2 * Real.log 2 := by
    rw [show ((5708321 : ℝ) / 1250000) = ((5708321 : ℝ) / 5000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_390 : RB (Real.log ((456666851 : ℝ) / 100000000)) ((75939197 : ℝ) / 50000000) ((151878397 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((456666851 : ℝ) / 400000000)) (t := ((56666851 : ℝ) / 856666851))
    (lo := ((6624479 : ℝ) / 50000000)) (hi := ((13248959 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((456666851 : ℝ) / 100000000) = Real.log ((456666851 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((456666851 : ℝ) / 100000000) = ((456666851 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_391 : RB (Real.log ((25606949 : ℝ) / 20000000)) ((6178287 : ℝ) / 25000000) ((24713149 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((25606949 : ℝ) / 20000000)) (t := ((5606949 : ℝ) / 45606949))
    (lo := ((6178287 : ℝ) / 25000000)) (hi := ((24713149 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_392 : RB (Real.log ((113931 : ℝ) / 1562500)) ((-130922471 : ℝ) / 50000000) ((-261844937 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((455724 : ℝ) / 390625)) (t := ((65099 : ℝ) / 846349))
    (lo := ((7706967 : ℝ) / 50000000)) (hi := ((3082787 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((113931 : ℝ) / 1562500) = Real.log ((455724 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((113931 : ℝ) / 1562500) = ((455724 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_393 : RB (Real.log ((1062967 : ℝ) / 12500000)) ((-123233231 : ℝ) / 50000000) ((-123233229 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1062967 : ℝ) / 1562500)) (t := ((-499533 : ℝ) / 2625467))
    (lo := ((-7704461 : ℝ) / 20000000)) (hi := ((-601911 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1062967 : ℝ) / 12500000) = Real.log ((1062967 : ℝ) / 1562500) - 3 * Real.log 2 := by
    rw [show ((1062967 : ℝ) / 12500000) = ((1062967 : ℝ) / 1562500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_394 : RB (Real.log ((94861 : ℝ) / 5000000)) ((-396478059 : ℝ) / 100000000) ((-99119513 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((94861 : ℝ) / 78125)) (t := ((8368 : ℝ) / 86493))
    (lo := ((3882051 : ℝ) / 20000000)) (hi := ((1213141 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94861 : ℝ) / 5000000) = Real.log ((94861 : ℝ) / 78125) - 6 * Real.log 2 := by
    rw [show ((94861 : ℝ) / 5000000) = ((94861 : ℝ) / 78125) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_395 : RB (Real.log ((1930721 : ℝ) / 100000000)) ((-197363837 : ℝ) / 50000000) ((-394727667 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1930721 : ℝ) / 1562500)) (t := ((368221 : ℝ) / 3493221))
    (lo := ((66127 : ℝ) / 312500)) (hi := ((21160641 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1930721 : ℝ) / 100000000) = Real.log ((1930721 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1930721 : ℝ) / 100000000) = ((1930721 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_396 : RB (Real.log ((18808883 : ℝ) / 25000000)) ((-28454657 : ℝ) / 100000000) ((-111151 : ℝ) / 390625) := by
  have hm := log_bounds_of_series (x := ((18808883 : ℝ) / 25000000)) (t := ((-6191117 : ℝ) / 43808883))
    (lo := ((-28454657 : ℝ) / 100000000)) (hi := ((-111151 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_397 : RB (Real.log ((75236117 : ℝ) / 100000000)) ((-711347 : ℝ) / 2500000) ((-28453879 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((75236117 : ℝ) / 100000000)) (t := ((-24763883 : ℝ) / 175236117))
    (lo := ((-711347 : ℝ) / 2500000)) (hi := ((-28453879 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_398 : RB (Real.log ((8587933 : ℝ) / 20000000)) ((-84537421 : ℝ) / 100000000) ((-84537419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8587933 : ℝ) / 10000000)) (t := ((-1412067 : ℝ) / 18587933))
    (lo := ((-7611351 : ℝ) / 50000000)) (hi := ((-15222701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8587933 : ℝ) / 20000000) = Real.log ((8587933 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8587933 : ℝ) / 20000000) = ((8587933 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_399 : RB (Real.log ((196055749 : ℝ) / 100000000)) ((33661443 : ℝ) / 50000000) ((8415361 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((196055749 : ℝ) / 200000000)) (t := ((-3944251 : ℝ) / 396055749))
    (lo := ((-248979 : ℝ) / 12500000)) (hi := ((-1991831 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196055749 : ℝ) / 100000000) = Real.log ((196055749 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196055749 : ℝ) / 100000000) = ((196055749 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
