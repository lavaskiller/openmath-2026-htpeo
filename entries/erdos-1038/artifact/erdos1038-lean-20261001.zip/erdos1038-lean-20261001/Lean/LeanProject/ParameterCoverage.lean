import LeanProject.DTargetComparison
import LeanProject.DeepMindInfimumBridge

/-!
# Coverage geometry and the remaining universal lower-bound obligation

The terminal family really represents every `k ≥ 21/5`. The partition of the
remaining normal-form ratios is exhaustive. The scalar certificates outside
the pilot are still explicit hypotheses of the final assembly theorem.
-/

open Real Set Filter Topology Polynomial
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12

noncomputable def terminalCut : ℝ := 21 / 500
noncomputable def terminalK (q : ℝ) : ℝ := -Real.log q / Real.log (D0q q) - 1
def terminalDomain : Set ℝ := Ioc 0 terminalCut
def r1Range : Set ℝ := Icc (36 / 25) (21 / 10)
def r2Range : Set ℝ := Icc (21 / 10) (21 / 5)
def r1RemainingLeft : Set ℝ := Ico (36 / 25) (9 / 5)
def r1RemainingRight : Set ℝ := Ioc (9001 / 5000) (21 / 10)

theorem terminal_D0_gt_one {q : ℝ} (hq : q ∈ terminalDomain) : 1 < D0q q := by
  have hq0 : 0 < q := hq.1
  have hq1 : q ≤ (21 : ℝ) / 500 := hq.2
  have hsq : q ^ 2 ≤ ((21 : ℝ) / 500) ^ 2 :=
    (sq_le_sq₀ hq0.le (by norm_num)).mpr hq1
  unfold D0q
  apply (lt_div_iff₀ (by positivity : (0 : ℝ) < (1 + q) ^ 2)).mpr
  nlinarith

theorem terminal_log_D0_pos {q : ℝ} (hq : q ∈ terminalDomain) :
    0 < Real.log (D0q q) := Real.log_pos (terminal_D0_gt_one hq)

theorem terminal_cut_fq_pos : 0 < fq terminalCut := by
  unfold fq terminalCut
  norm_num only [show (2 : ℝ) / (1 + 21 / 500) ^ 2 = 500000 / 271441 by norm_num]
  nlinarith [terminal_log_q.1, terminal_log_D0.1]

theorem terminal_admissible {q : ℝ} (hq : q ∈ terminalDomain) : q ∈ Qadm := by
  have hcut : terminalCut < (1 : ℝ) := by norm_num [terminalCut]
  have hq1 : q < 1 := lt_of_le_of_lt hq.2 hcut
  refine ⟨hq.1, hq1, ?_⟩
  rcases hq.2.lt_or_eq with hlt | heq
  · have hf := fq_strictAntiOn ⟨hq.1.le, hq1.le⟩
      ⟨by norm_num [terminalCut], hcut.le⟩ hlt
    exact lt_trans terminal_cut_fq_pos hf
  · rw [heq]
    exact terminal_cut_fq_pos

theorem terminal_width_ge_D {q : ℝ} (hq : q ∈ terminalDomain) :
    Dval ≤ Stage9.Lam q := Dval_le_Lam (terminal_admissible hq)

theorem terminalK_pos {q : ℝ} (hq : q ∈ terminalDomain) : 0 < terminalK q := by
  have hqa := terminal_admissible hq
  have hH : Real.log (D0q q * q) < 0 :=
    Real.log_neg (mul_pos (D0q_pos q hq.1.le) hq.1) (H_lt_one hq.1)
  rw [log_H_eq hq.1] at hH
  change Real.log (D0q q) + Real.log q < 0 at hH
  unfold terminalK
  apply sub_pos.mpr
  apply (lt_div_iff₀ (terminal_log_D0_pos hq)).mpr
  linarith

theorem terminal_mass_ratio {q : ℝ} (hq : q ∈ terminalDomain) :
    terminalK q / (terminalK q + 1) = Aq q := by
  have hn := (log_q_neg hq.1 (terminal_admissible hq).2.1).ne
  have hd := (terminal_log_D0_pos hq).ne'
  have hk1 : terminalK q + 1 ≠ 0 := by linarith [terminalK_pos hq]
  have he : terminalK q + 1 = -Real.log q / Real.log (D0q q) := by
    unfold terminalK
    ring
  calc
    terminalK q / (terminalK q + 1) = 1 - 1 / (terminalK q + 1) := by
      field_simp [hk1]
      <;> ring
    _ = Aq q := by
      rw [he]
      unfold Aq
      rw [log_H_eq hq.1]
      change 1 - 1 / (-Real.log q / Real.log (D0q q)) =
        (Real.log (D0q q) + Real.log q) / Real.log q
      field_simp [hn, hd]
      <;> ring

theorem terminal_density_strict {q : ℝ} (hq : q ∈ terminalDomain) :
    terminalK q / (terminalK q + 1) * (1 + q) < 1 - q := by
  rw [terminal_mass_ratio hq]
  exact (Aq_lt_s_iff hq.1 (terminal_admissible hq).2.1).mpr
    (terminal_admissible hq).2.2

/-- The exact rational overlap bounds from the paper's side certificate. -/
theorem terminal_cut_K_bounds :
    418951734 / 100000000 ≤ terminalK terminalCut ∧
      terminalK terminalCut ≤ 418951735 / 100000000 := by
  have hc : terminalCut ∈ terminalDomain := ⟨by norm_num [terminalCut], le_rfl⟩
  have hd := terminal_log_D0_pos hc
  unfold terminalK terminalCut D0q at *
  norm_num only [show (2 : ℝ) / (1 + 21 / 500) ^ 2 = 500000 / 271441 by norm_num] at *
  constructor
  · apply (le_sub_iff_add_le).mpr
    apply (le_div_iff₀ hd).mpr
    nlinarith [terminal_log_q.2, terminal_log_D0.2]
  · apply (sub_le_iff_le_add).mpr
    apply (div_le_iff₀ hd).mpr
    nlinarith [terminal_log_q.1, terminal_log_D0.1]

theorem terminal_cut_overlap : terminalK terminalCut < 21 / 5 := by
  linarith [terminal_cut_K_bounds.2]

theorem terminalK_continuousOn : ContinuousOn terminalK terminalDomain := by
  intro q hq
  have hq0 : q ≠ 0 := ne_of_gt hq.1
  have h1 : 1 + q ≠ 0 := by linarith [hq.1]
  have hd : D0q q ≠ 0 := ne_of_gt (D0q_pos q hq.1.le)
  have hc : ContinuousAt D0q q := by
    unfold D0q
    exact continuousAt_const.div ((continuous_const.add continuous_id).pow 2).continuousAt
      (pow_ne_zero 2 h1)
  exact ((((continuous_id.continuousAt.log hq0).neg).div (hc.log hd)
    (terminal_log_D0_pos hq).ne').sub continuousAt_const).continuousWithinAt

/-- IVT covers the unbounded ratio range; no monotonicity premise is needed. -/
theorem terminal_parameter_exists {k : ℝ} (hk : terminalK terminalCut ≤ k) :
    ∃ q ∈ terminalDomain, terminalK q = k := by
  have hk0 : 0 < k + 1 := by linarith [terminal_cut_K_bounds.1]
  have ht : Tendsto (fun q : ℝ => -Real.log q) (𝓝[>] 0) atTop :=
    tendsto_neg_atBot_atTop.comp Real.tendsto_log_nhdsGT_zero
  obtain ⟨ql, hlarge, hql⟩ :=
    ((ht.eventually (eventually_gt_atTop ((k + 1) * Real.log 2))).and
      (Ioo_mem_nhdsGT (by norm_num [terminalCut] : (0 : ℝ) < terminalCut))).exists
  have hqlD : ql ∈ terminalDomain := ⟨hql.1, hql.2.le⟩
  have hd : Real.log (D0q ql) ≤ Real.log 2 := by
    apply Real.log_le_log (D0q_pos ql hql.1.le)
    unfold D0q
    have h1 : 0 < 1 + ql := by linarith [hql.1]
    apply (div_le_iff₀ (pow_pos h1 2)).mpr
    nlinarith [sq_nonneg ql]
  have hkl : k < terminalK ql := by
    unfold terminalK
    apply (lt_sub_iff_add_lt).mpr
    apply (lt_div_iff₀ (terminal_log_D0_pos hqlD)).mpr
    have hm := mul_le_mul_of_nonneg_left hd hk0.le
    linarith
  have hsub : Icc ql terminalCut ⊆ terminalDomain := by
    intro q hq
    exact ⟨lt_of_lt_of_le hql.1 hq.1, hq.2⟩
  obtain ⟨q, hq, heq⟩ := intermediate_value_Icc' hql.2.le
    (terminalK_continuousOn.mono hsub) ⟨hk, hkl.le⟩
  exact ⟨q, hsub hq, heq⟩

theorem terminal_covers_large_ratios {k : ℝ} (hk : 21 / 5 ≤ k) :
    ∃ q ∈ terminalDomain, q ∈ Qadm ∧ terminalK q = k := by
  obtain ⟨q, hq, heq⟩ := terminal_parameter_exists (terminal_cut_overlap.le.trans hk)
  exact ⟨q, hq, terminal_admissible hq, heq⟩

theorem remaining_ratio_partition {k : ℝ} (hk : 29 / 20 < k) :
    k ∈ r1Range ∨ k ∈ r2Range ∨ 21 / 5 ≤ k := by
  rcases le_or_gt k (21 / 10) with h1 | h1
  · exact Or.inl ⟨by linarith, h1⟩
  · rcases le_or_gt k (21 / 5) with h2 | h2
    · exact Or.inr (Or.inl ⟨h1.le, h2⟩)
    · exact Or.inr (Or.inr h2.le)

theorem remaining_ratio_family_cover {k : ℝ} (hk : 29 / 20 < k) :
    k ∈ r1Range ∨ k ∈ r2Range ∨
      ∃ q ∈ terminalDomain, q ∈ Qadm ∧ terminalK q = k := by
  rcases remaining_ratio_partition hk with h1 | h2 | ht
  · exact Or.inl h1
  · exact Or.inr (Or.inl h2)
  · exact Or.inr (Or.inr (terminal_covers_large_ratios ht))

/-- This is the unfinished certificate obligation, stated for each actual ratio. -/
def RatioCertified (k : ℝ) : Prop :=
  ∃ R : SeparatedReference, R.angles.k = k ∧
    (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) ∧
    ScalarPositive R (calibratedCeff R Dval)

theorem pilot_ratio_certified {k : ℝ} (hk : k ∈ pilotSlab) : RatioCertified k :=
  ⟨pilotReference hk, pilotReference_k hk, pilotReference_platform hk,
    pilot_scalar_positive_at_D hk⟩

theorem r1_pilot_complement_partition {k : ℝ} (hk : k ∈ r1Range) :
    k ∈ pilotSlab ∨ k ∈ r1RemainingLeft ∨ k ∈ r1RemainingRight := by
  rcases lt_or_ge k (9 / 5) with hl | hl
  · exact Or.inr (Or.inl ⟨hk.1, hl⟩)
  · rcases le_or_gt k (9001 / 5000) with hr | hr
    · exact Or.inl ⟨hl, hr⟩
    · exact Or.inr (Or.inr ⟨hr, hk.2⟩)

/-- Geometric coverage plus all three actual certificates closes COV. -/
theorem all_ratios_certified
    (hR1 : ∀ k ∈ r1Range, RatioCertified k)
    (hR2 : ∀ k ∈ r2Range, RatioCertified k)
    (hTerminal : ∀ q ∈ terminalDomain, RatioCertified (terminalK q)) :
    ∀ k, 29 / 20 < k → RatioCertified k := by
  intro k hk
  rcases remaining_ratio_partition hk with h1 | h2 | ht
  · exact hR1 k h1
  · exact hR2 k h2
  · obtain ⟨q, hq, _, heq⟩ := terminal_covers_large_ratios ht
    rw [← heq]
    exact hTerminal q hq

/-- Only the pilot complement is left as an R1 premise. -/
theorem all_ratios_certified_of_remaining
    (hLeft : ∀ k ∈ r1RemainingLeft, RatioCertified k)
    (hRight : ∀ k ∈ r1RemainingRight, RatioCertified k)
    (hR2 : ∀ k ∈ r2Range, RatioCertified k)
    (hTerminal : ∀ q ∈ terminalDomain, RatioCertified (terminalK q)) :
    ∀ k, 29 / 20 < k → RatioCertified k := by
  apply all_ratios_certified ?_ hR2 hTerminal
  intro k hk
  rcases r1_pilot_complement_partition hk with hp | hl | hr
  · exact pilot_ratio_certified hp
  · exact hLeft k hl
  · exact hRight k hr

/-- Conditional final assembly; the certificate premise is not asserted here. -/
theorem universal_gt_D_of_ratio_certificates
    (hcover : ∀ k, 29 / 20 < k → RatioCertified k)
    {p : ℝ[X]} (hp : EP1038.Admissible p) :
    Dval < (EP1038.sublevelMeasure p).toReal := by
  rcases polynomial_certificate_reduction hp with hbig | ⟨n, a, hres, hk, _, _, hs⟩
  · exact Dval_lt_two.trans_le hbig
  · obtain ⟨R, hRk, hplatform, hscalar⟩ := hcover a.k hk
    exact hs R hRk hplatform Dval hscalar

theorem official_strict_lower_of_ratio_certificates
    (hcover : ∀ k, 29 / 20 < k → RatioCertified k) :
    ∀ p : ℝ[X], EP1038.DeepMind.InfAdmissible p →
      ENNReal.ofReal Dval < MeasureTheory.volume {x : ℝ | |p.eval x| < 1} := by
  intro p hp
  have ha := (EP1038.DeepMind.inf_admissible_iff p).mp hp
  have h := universal_gt_D_of_ratio_certificates hcover ha
  have hm : 0 < (EP1038.sublevelMeasure p).toReal := lt_of_le_of_lt Dval_nonneg h
  have he := (ENNReal.ofReal_lt_ofReal_iff hm).mpr h
  rw [ENNReal.ofReal_toReal (EP1038.admissible_measure_finite ha)] at he
  exact he

/-- The exact infimum/nonattainment implications are proved; four certificates remain inputs. -/
theorem exact_infimum_and_nonattainment_of_remaining
    (hLeft : ∀ k ∈ r1RemainingLeft, RatioCertified k)
    (hRight : ∀ k ∈ r1RemainingRight, RatioCertified k)
    (hR2 : ∀ k ∈ r2Range, RatioCertified k)
    (hTerminal : ∀ q ∈ terminalDomain, RatioCertified (terminalK q)) :
    EP1038.DeepMind.officialInf = ENNReal.ofReal Dval ∧
      ∀ p : ℝ[X], EP1038.DeepMind.InfAdmissible p →
        MeasureTheory.volume {x : ℝ | |p.eval x| < 1} ≠ EP1038.DeepMind.officialInf :=
  EP1038.DeepMind.strict_lower_implies_exact_inf_and_nonattainment
    (official_strict_lower_of_ratio_certificates
      (all_ratios_certified_of_remaining hLeft hRight hR2 hTerminal))

theorem officialInf_lt_pilotTarget :
    EP1038.DeepMind.officialInf < ENNReal.ofReal pilotTarget :=
  EP1038.DeepMind.officialInf_le_D.trans_lt
    ((ENNReal.ofReal_lt_ofReal_iff (by norm_num [pilotTarget])).mpr Dval_lt_pilotTarget)

theorem exists_polynomial_lt_pilotTarget :
    ∃ p : ℝ[X], EP1038.DeepMind.InfAdmissible p ∧
      MeasureTheory.volume {x : ℝ | |p.eval x| < 1} < ENNReal.ofReal pilotTarget :=
  (EP1038.DeepMind.officialInf_lt_iff _).mp officialInf_lt_pilotTarget

end EP1038.ReferenceCert
