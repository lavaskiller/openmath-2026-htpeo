import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog03
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_360 : RB (Real.log ((341523 : ℝ) / 320000)) ((520752247 : ℝ) / 8000000000) ((16273507719 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((341523 : ℝ) / 320000)) (t := ((21523 : ℝ) / 661523))
    (lo := ((520752247 : ℝ) / 8000000000)) (hi := ((16273507719 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_361 : RB (Real.log ((66108749999 : ℝ) / 1000000000000)) ((-169778385357 : ℝ) / 62500000000) ((-271645416571 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((66108749999 : ℝ) / 62500000000)) (t := ((3608749999 : ℝ) / 128608749999))
    (lo := ((3508409783 : ℝ) / 62500000000)) (hi := ((56134556529 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66108749999 : ℝ) / 1000000000000) = Real.log ((66108749999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((66108749999 : ℝ) / 1000000000000) = ((66108749999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_362 : RB (Real.log ((21523 : ℝ) / 320000)) ((-674799716253 : ℝ) / 250000000000) ((-269919886501 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((21523 : ℝ) / 20000)) (t := ((1523 : ℝ) / 41523))
    (lo := ((18347464307 : ℝ) / 250000000000)) (hi := ((73389857229 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21523 : ℝ) / 320000) = Real.log ((21523 : ℝ) / 20000) - 4 * Real.log 2 := by
    rw [show ((21523 : ℝ) / 320000) = ((21523 : ℝ) / 20000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_363 : RB (Real.log ((605650061017 : ℝ) / 1000000000000)) ((-250726458387 : ℝ) / 500000000000) ((-125363229193 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((605650061017 : ℝ) / 500000000000)) (t := ((105650061017 : ℝ) / 1105650061017))
    (lo := ((95847131893 : ℝ) / 500000000000)) (hi := ((191694263787 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((605650061017 : ℝ) / 1000000000000) = Real.log ((605650061017 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((605650061017 : ℝ) / 1000000000000) = ((605650061017 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_364 : RB (Real.log ((605897578503 : ℝ) / 1000000000000)) ((-501044319569 : ℝ) / 1000000000000) ((-501044319567 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((605897578503 : ℝ) / 500000000000)) (t := ((105897578503 : ℝ) / 1105897578503))
    (lo := ((192102860991 : ℝ) / 1000000000000)) (hi := ((3001607203 : ℝ) / 15625000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((605897578503 : ℝ) / 1000000000000) = Real.log ((605897578503 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((605897578503 : ℝ) / 1000000000000) = ((605897578503 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_365 : RB (Real.log ((47502091159 : ℝ) / 125000000000)) ((-967540002831 : ℝ) / 1000000000000) ((-967540002829 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((47502091159 : ℝ) / 62500000000)) (t := ((-14997908841 : ℝ) / 110002091159))
    (lo := ((-274392822271 : ℝ) / 1000000000000)) (hi := ((-27439282227 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47502091159 : ℝ) / 125000000000) = Real.log ((47502091159 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((47502091159 : ℝ) / 125000000000) = ((47502091159 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_366 : RB (Real.log ((3263372149203 : ℝ) / 1000000000000)) ((1182761062349 : ℝ) / 1000000000000) ((1182761062351 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3263372149203 : ℝ) / 4000000000000)) (t := ((-736627850797 : ℝ) / 7263372149203))
    (lo := ((-20353329877 : ℝ) / 100000000000)) (hi := ((-203533298769 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3263372149203 : ℝ) / 1000000000000) = Real.log ((3263372149203 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3263372149203 : ℝ) / 1000000000000) = ((3263372149203 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_367 : RB (Real.log ((3263721057223 : ℝ) / 1000000000000)) ((1182867973039 : ℝ) / 1000000000000) ((1182867973041 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3263721057223 : ℝ) / 4000000000000)) (t := ((-736278942777 : ℝ) / 7263721057223))
    (lo := ((-2542829851 : ℝ) / 12500000000)) (hi := ((-203426388079 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3263721057223 : ℝ) / 1000000000000) = Real.log ((3263721057223 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3263721057223 : ℝ) / 1000000000000) = ((3263721057223 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_368 : RB (Real.log ((719909964171 : ℝ) / 500000000000)) ((72903611201 : ℝ) / 200000000000) ((364518056007 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((719909964171 : ℝ) / 1000000000000)) (t := ((-280090035829 : ℝ) / 1719909964171))
    (lo := ((-164314562277 : ℝ) / 500000000000)) (hi := ((-328629124553 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((719909964171 : ℝ) / 500000000000) = Real.log ((719909964171 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((719909964171 : ℝ) / 500000000000) = ((719909964171 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_369 : RB (Real.log ((1067259374999 : ℝ) / 1000000000000)) ((520752247 : ℝ) / 8000000000) ((16273507719 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1067259374999 : ℝ) / 1000000000000)) (t := ((67259374999 : ℝ) / 2067259374999))
    (lo := ((520752247 : ℝ) / 8000000000)) (hi := ((16273507719 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_370 : RB (Real.log ((106841 : ℝ) / 100000)) ((33085781 : ℝ) / 500000000) ((66171562001 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((106841 : ℝ) / 100000)) (t := ((6841 : ℝ) / 206841))
    (lo := ((33085781 : ℝ) / 500000000)) (hi := ((66171562001 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_371 : RB (Real.log ((67259374999 : ℝ) / 1000000000000)) ((-2699198865027 : ℝ) / 1000000000000) ((-107967954601 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((67259374999 : ℝ) / 62500000000)) (t := ((4759374999 : ℝ) / 129759374999))
    (lo := ((73389857213 : ℝ) / 1000000000000)) (hi := ((36694928607 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((67259374999 : ℝ) / 1000000000000) = Real.log ((67259374999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((67259374999 : ℝ) / 1000000000000) = ((67259374999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_372 : RB (Real.log ((6841 : ℝ) / 100000)) ((-268223626621 : ℝ) / 100000000000) ((-83819883319 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((6841 : ℝ) / 6250)) (t := ((591 : ℝ) / 13091))
    (lo := ((9035245603 : ℝ) / 100000000000)) (hi := ((90352456031 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6841 : ℝ) / 100000) = Real.log ((6841 : ℝ) / 6250) - 4 * Real.log 2 := by
    rw [show ((6841 : ℝ) / 100000) = ((6841 : ℝ) / 6250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_373 : RB (Real.log ((299170745491 : ℝ) / 500000000000)) ((-128398408217 : ℝ) / 250000000000) ((-256796816433 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((299170745491 : ℝ) / 250000000000)) (t := ((49170745491 : ℝ) / 549170745491))
    (lo := ((44888386923 : ℝ) / 250000000000)) (hi := ((179553547693 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((299170745491 : ℝ) / 500000000000) = Real.log ((299170745491 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((299170745491 : ℝ) / 500000000000) = ((299170745491 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_374 : RB (Real.log ((299296086287 : ℝ) / 500000000000)) ((-513174759871 : ℝ) / 1000000000000) ((-513174759869 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((299296086287 : ℝ) / 250000000000)) (t := ((49296086287 : ℝ) / 549296086287))
    (lo := ((179972420689 : ℝ) / 1000000000000)) (hi := ((17997242069 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((299296086287 : ℝ) / 500000000000) = Real.log ((299296086287 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((299296086287 : ℝ) / 500000000000) = ((299296086287 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_375 : RB (Real.log ((94319865699 : ℝ) / 250000000000)) ((-974769085521 : ℝ) / 1000000000000) ((-974769085519 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((94319865699 : ℝ) / 125000000000)) (t := ((-30680134301 : ℝ) / 219319865699))
    (lo := ((-281621904961 : ℝ) / 1000000000000)) (hi := ((-880068453 : ℝ) / 3125000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94319865699 : ℝ) / 250000000000) = Real.log ((94319865699 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((94319865699 : ℝ) / 250000000000) = ((94319865699 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_376 : RB (Real.log ((814786676993 : ℝ) / 250000000000)) ((236293083019 : ℝ) / 200000000000) ((1181465415097 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((814786676993 : ℝ) / 1000000000000)) (t := ((-185213323007 : ℝ) / 1814786676993))
    (lo := ((-25603618253 : ℝ) / 125000000000)) (hi := ((-204828946023 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((814786676993 : ℝ) / 250000000000) = Real.log ((814786676993 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((814786676993 : ℝ) / 250000000000) = ((814786676993 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_377 : RB (Real.log ((3259501029309 : ℝ) / 1000000000000)) ((73848382823 : ℝ) / 62500000000) ((118157412517 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((3259501029309 : ℝ) / 4000000000000)) (t := ((-740498970691 : ℝ) / 7259501029309))
    (lo := ((-204720235951 : ℝ) / 1000000000000)) (hi := ((-4094404719 : ℝ) / 20000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3259501029309 : ℝ) / 1000000000000) = Real.log ((3259501029309 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3259501029309 : ℝ) / 1000000000000) = ((3259501029309 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_378 : RB (Real.log ((1440573455627 : ℝ) / 1000000000000)) ((365041267387 : ℝ) / 1000000000000) ((365041267389 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1440573455627 : ℝ) / 2000000000000)) (t := ((-559426544373 : ℝ) / 3440573455627))
    (lo := ((-82026478293 : ℝ) / 250000000000)) (hi := ((-328105913171 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1440573455627 : ℝ) / 1000000000000) = Real.log ((1440573455627 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1440573455627 : ℝ) / 1000000000000) = ((1440573455627 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_379 : RB (Real.log ((1068409999999 : ℝ) / 1000000000000)) ((66171561999 : ℝ) / 1000000000000) ((33085781 : ℝ) / 500000000) := by
  have hm := log_bounds_of_series (x := ((1068409999999 : ℝ) / 1000000000000)) (t := ((68409999999 : ℝ) / 2068409999999))
    (lo := ((66171561999 : ℝ) / 1000000000000)) (hi := ((33085781 : ℝ) / 500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_380 : RB (Real.log ((1711297 : ℝ) / 1600000)) ((672479333 : ℝ) / 10000000000) ((67247933301 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1711297 : ℝ) / 1600000)) (t := ((111297 : ℝ) / 3311297))
    (lo := ((672479333 : ℝ) / 10000000000)) (hi := ((67247933301 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_381 : RB (Real.log ((68409999999 : ℝ) / 1000000000000)) ((-107289450649 : ℝ) / 40000000000) ((-2682236266223 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((68409999999 : ℝ) / 62500000000)) (t := ((5909999999 : ℝ) / 130909999999))
    (lo := ((18070491203 : ℝ) / 200000000000)) (hi := ((5647028501 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68409999999 : ℝ) / 1000000000000) = Real.log ((68409999999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((68409999999 : ℝ) / 1000000000000) = ((68409999999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_382 : RB (Real.log ((111297 : ℝ) / 1600000)) ((-333194575561 : ℝ) / 125000000000) ((-1332778302243 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((111297 : ℝ) / 100000)) (t := ((11297 : ℝ) / 211297))
    (lo := ((13379014719 : ℝ) / 125000000000)) (hi := ((107032117753 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111297 : ℝ) / 1600000) = Real.log ((111297 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((111297 : ℝ) / 1600000) = ((111297 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_383 : RB (Real.log ((295518435071 : ℝ) / 500000000000)) ((-105175375499 : ℝ) / 200000000000) ((-525876877493 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((295518435071 : ℝ) / 250000000000)) (t := ((45518435071 : ℝ) / 545518435071))
    (lo := ((33454060613 : ℝ) / 200000000000)) (hi := ((83635151533 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((295518435071 : ℝ) / 500000000000) = Real.log ((295518435071 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((295518435071 : ℝ) / 500000000000) = ((295518435071 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_384 : RB (Real.log ((591290679249 : ℝ) / 1000000000000)) ((-525447539431 : ℝ) / 1000000000000) ((-525447539429 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((591290679249 : ℝ) / 500000000000)) (t := ((91290679249 : ℝ) / 1091290679249))
    (lo := ((167699641129 : ℝ) / 1000000000000)) (hi := ((16769964113 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((591290679249 : ℝ) / 1000000000000) = Real.log ((591290679249 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((591290679249 : ℝ) / 1000000000000) = ((591290679249 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_385 : RB (Real.log ((374520265291 : ℝ) / 1000000000000)) ((-982109364563 : ℝ) / 1000000000000) ((-982109364561 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((374520265291 : ℝ) / 500000000000)) (t := ((-125479734709 : ℝ) / 874520265291))
    (lo := ((-288962184003 : ℝ) / 1000000000000)) (hi := ((-144481092001 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((374520265291 : ℝ) / 1000000000000) = Real.log ((374520265291 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((374520265291 : ℝ) / 1000000000000) = ((374520265291 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_386 : RB (Real.log ((325488358337 : ℝ) / 100000000000)) ((590078254771 : ℝ) / 500000000000) ((147519563693 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((325488358337 : ℝ) / 400000000000)) (t := ((-74511641663 : ℝ) / 725488358337))
    (lo := ((-206137851577 : ℝ) / 1000000000000)) (hi := ((-25767231447 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((325488358337 : ℝ) / 100000000000) = Real.log ((325488358337 : ℝ) / 400000000000) + 2 * Real.log 2 := by
    rw [show ((325488358337 : ℝ) / 100000000000) = ((325488358337 : ℝ) / 400000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_387 : RB (Real.log ((651048658437 : ℝ) / 200000000000)) ((1180267017009 : ℝ) / 1000000000000) ((1180267017011 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((651048658437 : ℝ) / 800000000000)) (t := ((-148951341563 : ℝ) / 1451048658437))
    (lo := ((-20602734411 : ℝ) / 100000000000)) (hi := ((-206027344109 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((651048658437 : ℝ) / 200000000000) = Real.log ((651048658437 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((651048658437 : ℝ) / 200000000000) = ((651048658437 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_388 : RB (Real.log ((288267201623 : ℝ) / 200000000000)) ((584912747 : ℝ) / 1600000000) ((365570466877 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((288267201623 : ℝ) / 400000000000)) (t := ((-111732798377 : ℝ) / 688267201623))
    (lo := ((-81894178421 : ℝ) / 250000000000)) (hi := ((-327576713683 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((288267201623 : ℝ) / 200000000000) = Real.log ((288267201623 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((288267201623 : ℝ) / 200000000000) = ((288267201623 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_389 : RB (Real.log ((1069560624999 : ℝ) / 1000000000000)) ((67247933299 : ℝ) / 1000000000000) ((672479333 : ℝ) / 10000000000) := by
  have hm := log_bounds_of_series (x := ((1069560624999 : ℝ) / 1000000000000)) (t := ((69560624999 : ℝ) / 2069560624999))
    (lo := ((67247933299 : ℝ) / 1000000000000)) (hi := ((672479333 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_390 : RB (Real.log ((856569 : ℝ) / 800000)) ((68323147271 : ℝ) / 1000000000000) ((8540393409 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((856569 : ℝ) / 800000)) (t := ((56569 : ℝ) / 1656569))
    (lo := ((68323147271 : ℝ) / 1000000000000)) (hi := ((8540393409 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_391 : RB (Real.log ((69560624999 : ℝ) / 1000000000000)) ((-2665556604503 : ℝ) / 1000000000000) ((-2665556604501 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((69560624999 : ℝ) / 62500000000)) (t := ((7060624999 : ℝ) / 132060624999))
    (lo := ((107032117737 : ℝ) / 1000000000000)) (hi := ((53516058869 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((69560624999 : ℝ) / 1000000000000) = Real.log ((69560624999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((69560624999 : ℝ) / 1000000000000) = ((69560624999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_392 : RB (Real.log ((56569 : ℝ) / 800000)) ((-662287648921 : ℝ) / 250000000000) ((-1324575297841 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((56569 : ℝ) / 50000)) (t := ((6569 : ℝ) / 106569))
    (lo := ((30859531639 : ℝ) / 250000000000)) (hi := ((123438126557 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((56569 : ℝ) / 800000) = Real.log ((56569 : ℝ) / 50000) - 4 * Real.log 2 := by
    rw [show ((56569 : ℝ) / 800000) = ((56569 : ℝ) / 50000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_393 : RB (Real.log ((583736636571 : ℝ) / 1000000000000)) ((-107661072529 : ℝ) / 200000000000) ((-538305362643 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((583736636571 : ℝ) / 500000000000)) (t := ((83736636571 : ℝ) / 1083736636571))
    (lo := ((30968363583 : ℝ) / 200000000000)) (hi := ((38710454479 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((583736636571 : ℝ) / 1000000000000) = Real.log ((583736636571 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((583736636571 : ℝ) / 1000000000000) = ((583736636571 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_394 : RB (Real.log ((9124899011 : ℝ) / 15625000000)) ((-537865363503 : ℝ) / 1000000000000) ((-537865363501 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((9124899011 : ℝ) / 7812500000)) (t := ((1312399011 : ℝ) / 16937399011))
    (lo := ((155281817057 : ℝ) / 1000000000000)) (hi := ((77640908529 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9124899011 : ℝ) / 15625000000) = Real.log ((9124899011 : ℝ) / 7812500000) - 1 * Real.log 2 := by
    rw [show ((9124899011 : ℝ) / 15625000000) = ((9124899011 : ℝ) / 7812500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_395 : RB (Real.log ((371739027723 : ℝ) / 1000000000000)) ((-494781604641 : ℝ) / 500000000000) ((-3092385029 : ℝ) / 3125000000) := by
  have hm := log_bounds_of_series (x := ((371739027723 : ℝ) / 500000000000)) (t := ((-128260972277 : ℝ) / 871739027723))
    (lo := ((-148208014361 : ℝ) / 500000000000)) (hi := ((-296416028721 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((371739027723 : ℝ) / 1000000000000) = Real.log ((371739027723 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((371739027723 : ℝ) / 1000000000000) = ((371739027723 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_396 : RB (Real.log ((812646002199 : ℝ) / 250000000000)) ((1178834675211 : ℝ) / 1000000000000) ((1178834675213 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((812646002199 : ℝ) / 1000000000000)) (t := ((-187353997801 : ℝ) / 1812646002199))
    (lo := ((-51864921477 : ℝ) / 250000000000)) (hi := ((-207459685907 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((812646002199 : ℝ) / 250000000000) = Real.log ((812646002199 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((812646002199 : ℝ) / 250000000000) = ((812646002199 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_397 : RB (Real.log ((1625474539587 : ℝ) / 500000000000)) ((1178946978071 : ℝ) / 1000000000000) ((1178946978073 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1625474539587 : ℝ) / 2000000000000)) (t := ((-374525460413 : ℝ) / 3625474539587))
    (lo := ((-25918422881 : ℝ) / 125000000000)) (hi := ((-207347383047 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1625474539587 : ℝ) / 500000000000) = Real.log ((1625474539587 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1625474539587 : ℝ) / 500000000000) = ((1625474539587 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_398 : RB (Real.log ((360526858277 : ℝ) / 250000000000)) ((73221107787 : ℝ) / 200000000000) ((366105538937 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((360526858277 : ℝ) / 500000000000)) (t := ((-139473141723 : ℝ) / 860526858277))
    (lo := ((-40880205203 : ℝ) / 125000000000)) (hi := ((-327041641623 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((360526858277 : ℝ) / 250000000000) = Real.log ((360526858277 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((360526858277 : ℝ) / 250000000000) = ((360526858277 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_399 : RB (Real.log ((1070711249999 : ℝ) / 1000000000000)) ((6832314727 : ℝ) / 100000000000) ((68323147271 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1070711249999 : ℝ) / 1000000000000)) (t := ((70711249999 : ℝ) / 2070711249999))
    (lo := ((6832314727 : ℝ) / 100000000000)) (hi := ((68323147271 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_400 : RB (Real.log ((1714979 : ℝ) / 1600000)) ((69397206399 : ℝ) / 1000000000000) ((21686627 : ℝ) / 312500000) := by
  have hm := log_bounds_of_series (x := ((1714979 : ℝ) / 1600000)) (t := ((114979 : ℝ) / 3314979))
    (lo := ((69397206399 : ℝ) / 1000000000000)) (hi := ((21686627 : ℝ) / 312500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_401 : RB (Real.log ((70711249999 : ℝ) / 1000000000000)) ((-1324575297849 : ℝ) / 500000000000) ((-165571912231 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((70711249999 : ℝ) / 62500000000)) (t := ((8211249999 : ℝ) / 133211249999))
    (lo := ((61719063271 : ℝ) / 500000000000)) (hi := ((123438126543 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70711249999 : ℝ) / 1000000000000) = Real.log ((70711249999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((70711249999 : ℝ) / 1000000000000) = ((70711249999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_402 : RB (Real.log ((114979 : ℝ) / 1600000)) ((-658252351309 : ℝ) / 250000000000) ((-1316504702617 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((114979 : ℝ) / 100000)) (t := ((14979 : ℝ) / 214979))
    (lo := ((34894829251 : ℝ) / 250000000000)) (hi := ((27915863401 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114979 : ℝ) / 1600000) = Real.log ((114979 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((114979 : ℝ) / 1600000) = ((114979 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_403 : RB (Real.log ((576441242511 : ℝ) / 1000000000000)) ((-137720466381 : ℝ) / 250000000000) ((-275440932761 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((576441242511 : ℝ) / 500000000000)) (t := ((76441242511 : ℝ) / 1076441242511))
    (lo := ((35566328759 : ℝ) / 250000000000)) (hi := ((142265315037 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((576441242511 : ℝ) / 1000000000000) = Real.log ((576441242511 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((576441242511 : ℝ) / 1000000000000) = ((576441242511 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_404 : RB (Real.log ((115340239461 : ℝ) / 200000000000)) ((-68803875279 : ℝ) / 125000000000) ((-55043100223 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((115340239461 : ℝ) / 100000000000)) (t := ((15340239461 : ℝ) / 215340239461))
    (lo := ((17839522291 : ℝ) / 125000000000)) (hi := ((142716178329 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((115340239461 : ℝ) / 200000000000) = Real.log ((115340239461 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((115340239461 : ℝ) / 200000000000) = ((115340239461 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_405 : RB (Real.log ((368935648159 : ℝ) / 1000000000000)) ((-124641630673 : ℝ) / 125000000000) ((-498566522691 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((368935648159 : ℝ) / 500000000000)) (t := ((-131064351841 : ℝ) / 868935648159))
    (lo := ((-37998233103 : ℝ) / 125000000000)) (hi := ((-303985864823 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((368935648159 : ℝ) / 1000000000000) = Real.log ((368935648159 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((368935648159 : ℝ) / 1000000000000) = ((368935648159 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_406 : RB (Real.log ((3246249174111 : ℝ) / 1000000000000)) ((58875011479 : ℝ) / 50000000000) ((588750114791 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3246249174111 : ℝ) / 4000000000000)) (t := ((-753750825889 : ℝ) / 7246249174111))
    (lo := ((-208794131539 : ℝ) / 1000000000000)) (hi := ((-104397065769 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3246249174111 : ℝ) / 1000000000000) = Real.log ((3246249174111 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3246249174111 : ℝ) / 1000000000000) = ((3246249174111 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_407 : RB (Real.log ((3246619580077 : ℝ) / 1000000000000)) ((1177614325823 : ℝ) / 1000000000000) ((47104573033 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((3246619580077 : ℝ) / 4000000000000)) (t := ((-753380419923 : ℝ) / 7246619580077))
    (lo := ((-6521251103 : ℝ) / 31250000000)) (hi := ((-41736007059 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3246619580077 : ℝ) / 1000000000000) = Real.log ((3246619580077 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3246619580077 : ℝ) / 1000000000000) = ((3246619580077 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_408 : RB (Real.log ((721443792253 : ℝ) / 500000000000)) ((18332318637 : ℝ) / 50000000000) ((183323186371 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((721443792253 : ℝ) / 1000000000000)) (t := ((-278556207747 : ℝ) / 1721443792253))
    (lo := ((-326500807819 : ℝ) / 1000000000000)) (hi := ((-163250403909 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((721443792253 : ℝ) / 500000000000) = Real.log ((721443792253 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((721443792253 : ℝ) / 500000000000) = ((721443792253 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_409 : RB (Real.log ((1071861874999 : ℝ) / 1000000000000)) ((34698603199 : ℝ) / 500000000000) ((69397206399 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1071861874999 : ℝ) / 1000000000000)) (t := ((71861874999 : ℝ) / 2071861874999))
    (lo := ((34698603199 : ℝ) / 500000000000)) (hi := ((69397206399 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_410 : RB (Real.log ((85841 : ℝ) / 80000)) ((70470113161 : ℝ) / 1000000000000) ((35235056581 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((85841 : ℝ) / 80000)) (t := ((5841 : ℝ) / 165841))
    (lo := ((70470113161 : ℝ) / 1000000000000)) (hi := ((35235056581 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_411 : RB (Real.log ((71861874999 : ℝ) / 1000000000000)) ((-10532037621 : ℝ) / 4000000000) ((-41140771957 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((71861874999 : ℝ) / 62500000000)) (t := ((9361874999 : ℝ) / 134361874999))
    (lo := ((13957931699 : ℝ) / 100000000000)) (hi := ((139579316991 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71861874999 : ℝ) / 1000000000000) = Real.log ((71861874999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((71861874999 : ℝ) / 1000000000000) = ((71861874999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_412 : RB (Real.log ((5841 : ℝ) / 80000)) ((-81785144363 : ℝ) / 31250000000) ((-1308562309807 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((5841 : ℝ) / 5000)) (t := ((841 : ℝ) / 10841))
    (lo := ((4858253207 : ℝ) / 31250000000)) (hi := ((1243712821 : ℝ) / 8000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5841 : ℝ) / 80000) = Real.log ((5841 : ℝ) / 5000) - 4 * Real.log 2 := by
    rw [show ((5841 : ℝ) / 80000) = ((5841 : ℝ) / 5000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_413 : RB (Real.log ((35571947407 : ℝ) / 62500000000)) ((-563609223701 : ℝ) / 1000000000000) ((-563609223699 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((35571947407 : ℝ) / 31250000000)) (t := ((4321947407 : ℝ) / 66821947407))
    (lo := ((129537956859 : ℝ) / 1000000000000)) (hi := ((6476897843 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35571947407 : ℝ) / 62500000000) = Real.log ((35571947407 : ℝ) / 31250000000) - 1 * Real.log 2 := by
    rw [show ((35571947407 : ℝ) / 62500000000) = ((35571947407 : ℝ) / 31250000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_414 : RB (Real.log ((284707065861 : ℝ) / 500000000000)) ((-563147285827 : ℝ) / 1000000000000) ((-22525891433 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((284707065861 : ℝ) / 250000000000)) (t := ((34707065861 : ℝ) / 534707065861))
    (lo := ((129999894733 : ℝ) / 1000000000000)) (hi := ((64999947367 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284707065861 : ℝ) / 500000000000) = Real.log ((284707065861 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((284707065861 : ℝ) / 500000000000) = ((284707065861 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_415 : RB (Real.log ((366110033793 : ℝ) / 1000000000000)) ((-200964270397 : ℝ) / 200000000000) ((-1004821351983 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((366110033793 : ℝ) / 500000000000)) (t := ((-133889966207 : ℝ) / 866110033793))
    (lo := ((-12466966857 : ℝ) / 40000000000)) (hi := ((-9739817857 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((366110033793 : ℝ) / 1000000000000) = Real.log ((366110033793 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((366110033793 : ℝ) / 1000000000000) = ((366110033793 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_416 : RB (Real.log ((3241880227919 : ℝ) / 1000000000000)) ((1176153478743 : ℝ) / 1000000000000) ((235230695749 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3241880227919 : ℝ) / 4000000000000)) (t := ((-758119772081 : ℝ) / 7241880227919))
    (lo := ((-26267610297 : ℝ) / 125000000000)) (hi := ((-1681127059 : ℝ) / 8000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3241880227919 : ℝ) / 1000000000000) = Real.log ((3241880227919 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3241880227919 : ℝ) / 1000000000000) = ((3241880227919 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_417 : RB (Real.log ((1621127971719 : ℝ) / 500000000000)) ((73516835397 : ℝ) / 62500000000) ((588134683177 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1621127971719 : ℝ) / 2000000000000)) (t := ((-378872028281 : ℝ) / 3621127971719))
    (lo := ((-210024994767 : ℝ) / 1000000000000)) (hi := ((-105012497383 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1621127971719 : ℝ) / 500000000000) = Real.log ((1621127971719 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1621127971719 : ℝ) / 500000000000) = ((1621127971719 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_418 : RB (Real.log ((721838161213 : ℝ) / 500000000000)) ((183596430949 : ℝ) / 500000000000) ((367192861901 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((721838161213 : ℝ) / 1000000000000)) (t := ((-278161838787 : ℝ) / 1721838161213))
    (lo := ((-325954318661 : ℝ) / 1000000000000)) (hi := ((-325954318659 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((721838161213 : ℝ) / 500000000000) = Real.log ((721838161213 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((721838161213 : ℝ) / 500000000000) = ((721838161213 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_419 : RB (Real.log ((1073012499999 : ℝ) / 1000000000000)) ((1761752829 : ℝ) / 25000000000) ((70470113161 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1073012499999 : ℝ) / 1000000000000)) (t := ((73012499999 : ℝ) / 2073012499999))
    (lo := ((1761752829 : ℝ) / 25000000000)) (hi := ((70470113161 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
