import LeanProject.Stage10B1

/-!
# EP-1038, Stage 10, Lemma 10.4 (shape of `Ψ_S` on the real axis)

For measurable `S` with `a ≤ S ≤ 2` (`a > 0`) and `k > 0`:
1. `Ψ_S(0) = 0`, `Ψ_S'(0) = 1` (`PsiS_zero`, `PsiS_deriv_zero`).
2. On `(-∞, 0)`: `Ψ_S(y) < y` and `Ψ_S' > 0` (`PsiS_lt_of_neg`, `PsiS_deriv_pos_of_neg`).
3. On `(0, a)`: `0 < Ψ_S(y) < y` (so `P(S) ≤ a`), `G_S` strictly decreasing with `G_S(0+) = +∞`;
   `y_c = sup {y ∈ (0,a) : G_S(y) > 0}` has `G_S > 0` on `(0, y_c)`, `G_S < 0` on `(y_c, a)`
   (`GS_pos_of_lt_yc`, `GS_neg_of_yc_lt`).
4. `Ψ_S` is strictly increasing on `(-∞, y_c)` (`PsiS_strictMonoOn`) and strictly decreasing on
   `[y_c, a)` when `y_c < a` (`PsiS_strictAntiOn`).
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

/-- `y_c(S) = sup {y ∈ (0, a) : G_S(y) > 0}`. For an arbitrary lower bound `a ≤ S` this is
`min (y_c(S)) a`; it equals the paper's `y_c(S)` when `a = a_S = ess inf S` (later stages take
`a = a_S`) or when `y_c(S) < a` (Lean RED L-258). -/
noncomputable def yc (k a : ℝ) (S : ℝ → ℝ) : ℝ := sSup {y | y ∈ Ioo 0 a ∧ 0 < GS k S y}

section shape

variable {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
  (hS2 : ∀ u, S u ≤ 2)
include hSm ha hSa hS2

theorem JS_le {y : ℝ} (hy : y < a) : JS S y ≤ 1 / (a - y) := by
  have h : JS S y ≤ ∫ _ in (0 : ℝ)..1, 1 / (a - y) := by
    refine intervalIntegral.integral_mono_on zero_le_one (ii_inv hSm ha hSa hS2 hy)
      intervalIntegrable_const fun u _ => ?_
    exact one_div_le_one_div_of_le (by linarith) (by linarith [hSa u])
  simpa using h

theorem JS_pos {y : ℝ} (hy : y < a) : 0 < JS S y := by
  have h : ∫ _ in (0 : ℝ)..1, 1 / (2 - y) ≤ JS S y := by
    refine intervalIntegral.integral_mono_on zero_le_one intervalIntegrable_const
      (ii_inv hSm ha hSa hS2 hy) fun u _ => ?_
    exact one_div_le_one_div_of_le (by linarith [hSa u]) (by linarith [hS2 u])
  have h2 : (0 : ℝ) < 2 - y := by linarith [hSa 0, hS2 0]
  simp only [intervalIntegral.integral_const, sub_zero, one_smul] at h
  exact lt_of_lt_of_le (by positivity) h

theorem JS_mono {y1 y2 : ℝ} (h12 : y1 ≤ y2) (hy2 : y2 < a) : JS S y1 ≤ JS S y2 := by
  refine intervalIntegral.integral_mono_on zero_le_one (ii_inv hSm ha hSa hS2 (by linarith))
    (ii_inv hSm ha hSa hS2 hy2) fun u _ => ?_
  exact one_div_le_one_div_of_le (by linarith [hSa u]) (by linarith)

theorem LS_sub_ge {y : ℝ} (hy0 : y ≤ 0) : Real.log (1 - y / 2) ≤ LS S y - LS S 0 := by
  have hy : y < a := by linarith
  unfold LS
  rw [← intervalIntegral.integral_sub (ii_log hSm ha hSa hS2 hy) (ii_log hSm ha hSa hS2 ha)]
  have h : ∫ _ in (0 : ℝ)..1, Real.log (1 - y / 2) ≤
      ∫ u in (0 : ℝ)..1, (Real.log (S u - y) - Real.log (S u - 0)) := by
    refine intervalIntegral.integral_mono_on zero_le_one intervalIntegrable_const
      ((ii_log hSm ha hSa hS2 hy).sub (ii_log hSm ha hSa hS2 ha)) fun u _ => ?_
    have hS : 0 < S u := by linarith [hSa u]
    rw [sub_zero, ← Real.log_div (by linarith [hSa u]) hS.ne']
    refine Real.log_le_log (by linarith) ?_
    rw [le_div_iff₀ hS]
    nlinarith [mul_nonneg (neg_nonneg.mpr hy0) (sub_nonneg.mpr (hS2 u))]
  simpa using h

theorem LS_sub_le {y : ℝ} (hy0 : 0 ≤ y) (hy : y < a) : LS S y - LS S 0 ≤ Real.log (1 - y / 2) := by
  unfold LS
  rw [← intervalIntegral.integral_sub (ii_log hSm ha hSa hS2 hy) (ii_log hSm ha hSa hS2 ha)]
  have h : ∫ u in (0 : ℝ)..1, (Real.log (S u - y) - Real.log (S u - 0)) ≤
      ∫ _ in (0 : ℝ)..1, Real.log (1 - y / 2) := by
    refine intervalIntegral.integral_mono_on zero_le_one
      ((ii_log hSm ha hSa hS2 hy).sub (ii_log hSm ha hSa hS2 ha)) intervalIntegrable_const
      fun u _ => ?_
    have hS : 0 < S u := by linarith [hSa u]
    rw [sub_zero, ← Real.log_div (by linarith [hSa u]) hS.ne']
    refine Real.log_le_log (div_pos (by linarith [hSa u]) hS) ?_
    rw [div_le_iff₀ hS]
    nlinarith [mul_nonneg hy0 (sub_nonneg.mpr (hS2 u))]
  simpa using h

omit hSm ha hSa hS2 in
theorem PsiS_zero : PsiS k S 0 = 0 := by simp [PsiS]

theorem PsiS_deriv_zero : HasDerivAt (PsiS k S) 1 0 := by
  have := hasDerivAt_PsiS (k := k) hSm ha hSa hS2 ha
  simpa using this

theorem PsiS_lt_of_neg {y : ℝ} (hk : 0 < k) (hy : y < 0) : PsiS k S y < y := by
  have hL := LS_sub_ge hSm ha hSa hS2 hy.le
  have hpos : 0 < Real.log (1 - y / 2) := Real.log_pos (by linarith)
  have hexp : 1 < Real.exp ((1 / k) * (LS S y - LS S 0)) :=
    by rw [← Real.exp_zero]; exact Real.exp_lt_exp.mpr (mul_pos (by positivity) (by linarith))
  unfold PsiS
  nlinarith

theorem PsiS_deriv_pos_of_neg {y : ℝ} (hk : 0 < k) (hy : y < 0) :
    0 < Real.exp ((1 / k) * (LS S y - LS S 0)) * (1 - y * ((1 / k) * JS S y)) := by
  have hJ := JS_pos hSm ha hSa hS2 (show y < a by linarith)
  have : 0 < -y * ((1 / k) * JS S y) := mul_pos (by linarith) (mul_pos (by positivity) hJ)
  exact mul_pos (Real.exp_pos _) (by linarith)

theorem PsiS_pos {y : ℝ} (hy : 0 < y) : 0 < PsiS k S y := mul_pos hy (Real.exp_pos _)

theorem PsiS_lt_self {y : ℝ} (hk : 0 < k) (hy0 : 0 < y) (hy : y < a) : PsiS k S y < y := by
  have hL := LS_sub_le hSm ha hSa hS2 hy0.le hy
  have ha2 : a ≤ 2 := (hSa 0).trans (hS2 0)
  have hneg : Real.log (1 - y / 2) < 0 :=
    Real.log_neg (by linarith) (by linarith)
  have hexp : Real.exp ((1 / k) * (LS S y - LS S 0)) < 1 :=
    by rw [← Real.exp_zero]; exact Real.exp_lt_exp.mpr (mul_neg_of_pos_of_neg (by positivity) (by linarith))
  unfold PsiS
  nlinarith

theorem GS_strictAntiOn (hk : 0 < k) : StrictAntiOn (GS k S) (Ioo 0 a) := by
  intro y1 hy1 y2 hy2 h12
  have hJ := JS_mono hSm ha hSa hS2 h12.le hy2.2
  have h1 : 1 / y2 < 1 / y1 := one_div_lt_one_div_of_lt hy1.1 h12
  have h2 : (1 / k) * JS S y1 ≤ (1 / k) * JS S y2 := mul_le_mul_of_nonneg_left hJ (by positivity)
  unfold GS
  linarith

theorem hasDerivAt_JS {y : ℝ} (hy : y < a) :
    HasDerivAt (JS S) (∫ u in (0 : ℝ)..1, 1 / (S u - y) ^ 2) y := by
  set ε := (a - y) / 2 with hε
  have hε0 : 0 < ε := by linarith
  have hball : Metric.ball y ε ∈ 𝓝 y := Metric.ball_mem_nhds y hε0
  have hlt : ∀ x ∈ Metric.ball y ε, x < a - ε := fun x hx => by
    rw [Metric.mem_ball, Real.dist_eq, abs_lt] at hx; linarith [hx.2]
  have key := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (F := fun x u => 1 / (S u - x)) (F' := fun x u => 1 / (S u - x) ^ 2)
    (bound := fun _ => 1 / ε ^ 2) (a := 0) (b := 1) (μ := volume) hball
    (Eventually.of_forall fun x => (measurable_const.div (hSm.sub_const x)).aestronglyMeasurable)
    (ii_inv hSm ha hSa hS2 hy)
    ((measurable_const.div ((hSm.sub_const y).pow_const 2)).aestronglyMeasurable)
    (Eventually.of_forall fun u _ x hx => by
      have hpos : ε < S u - x := by linarith [hSa u, hlt x hx]
      rw [Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr (pow_pos (by linarith) 2))]
      exact one_div_le_one_div_of_le (by positivity) (pow_le_pow_left₀ hε0.le hpos.le 2))
    intervalIntegrable_const
    (Eventually.of_forall fun u _ x hx => by
      have hpos : 0 < S u - x := by linarith [hSa u, hlt x hx]
      exact ((hasDerivAt_const x (1 : ℝ)).div ((hasDerivAt_id' x).const_sub (S u))
        hpos.ne').congr_deriv (by field_simp; ring))
  exact key.2

theorem GS_continuousOn : ContinuousOn (GS k S) (Ioo 0 a) := by
  intro y hy
  have hJ := (hasDerivAt_JS hSm ha hSa hS2 hy.2).continuousAt
  have h1 : ContinuousAt (fun y : ℝ => 1 / y) y :=
    continuousAt_const.div continuousAt_id hy.1.ne'
  exact (h1.sub (continuousAt_const.mul hJ)).continuousWithinAt

theorem GS_tendsto_top (hk : 0 < k) : Tendsto (GS k S) (𝓝[>] 0) atTop := by
  have hinv : Tendsto (fun y : ℝ => 1 / y) (𝓝[>] 0) atTop := by
    simpa only [one_div] using tendsto_inv_nhdsGT_zero
  have hlow : ∀ᶠ y in 𝓝[>] (0 : ℝ), 1 / y - (1 / k) * (2 / a) ≤ GS k S y := by
    filter_upwards [Ioo_mem_nhdsGT (half_pos ha)] with y hy
    have hJ := JS_le hSm ha hSa hS2 (show y < a by linarith [hy.2])
    have hJ2 : JS S y ≤ 2 / a := hJ.trans (by
      rw [div_le_div_iff₀ (by linarith [hy.2]) ha]; linarith [hy.2])
    unfold GS
    have : (1 / k) * JS S y ≤ (1 / k) * (2 / a) := mul_le_mul_of_nonneg_left hJ2 (by positivity)
    linarith
  exact tendsto_atTop_mono' _ hlow (tendsto_atTop_add_const_right _ _ hinv)

theorem yc_set_nonempty (hk : 0 < k) : {y | y ∈ Ioo 0 a ∧ 0 < GS k S y}.Nonempty := by
  obtain ⟨y, hy1, hy2⟩ := ((GS_tendsto_top hSm ha hSa hS2 hk).eventually (eventually_gt_atTop 0)).and
    (Ioo_mem_nhdsGT ha) |>.exists
  exact ⟨y, hy2, hy1⟩

theorem yc_set_bdd : BddAbove {y | y ∈ Ioo 0 a ∧ 0 < GS k S y} := ⟨a, fun _ hy => hy.1.2.le⟩

theorem yc_pos (hk : 0 < k) : 0 < yc k a S := by
  obtain ⟨y, hy⟩ := yc_set_nonempty hSm ha hSa hS2 hk
  exact lt_of_lt_of_le hy.1.1 (le_csSup (yc_set_bdd hSm ha hSa hS2) hy)

theorem yc_le (hk : 0 < k) : yc k a S ≤ a :=
  csSup_le (yc_set_nonempty hSm ha hSa hS2 hk) fun _ hy => hy.1.2.le

theorem GS_pos_of_lt_yc (hk : 0 < k) {y : ℝ} (hy0 : 0 < y) (hy : y < yc k a S) : 0 < GS k S y := by
  obtain ⟨y', hy', hlt⟩ := exists_lt_of_lt_csSup (yc_set_nonempty hSm ha hSa hS2 hk) hy
  have := GS_strictAntiOn hSm ha hSa hS2 hk ⟨hy0, by linarith [hy'.1.2]⟩ hy'.1 hlt
  linarith [hy'.2]

theorem GS_neg_of_yc_lt (hk : 0 < k) {y : ℝ} (hy : yc k a S < y) (hya : y < a) : GS k S y < 0 := by
  have hpos := yc_pos hSm ha hSa hS2 hk
  set y' := (yc k a S + y) / 2 with hy'
  have h1 : yc k a S < y' := by linarith
  have h2 : y' < y := by linarith
  have hnot : ¬ (0 < GS k S y') := fun h =>
    absurd (le_csSup (yc_set_bdd hSm ha hSa hS2) ⟨⟨by linarith, by linarith⟩, h⟩) (not_le.mpr h1)
  have := GS_strictAntiOn hSm ha hSa hS2 hk ⟨by linarith, by linarith⟩ ⟨by linarith, hya⟩ h2
  linarith [not_lt.mp hnot]

/-- The derivative of `Ψ_S` is positive on `(-∞, y_c)`. -/
theorem PsiS_deriv_pos (hk : 0 < k) {y : ℝ} (hy : y < yc k a S) :
    0 < Real.exp ((1 / k) * (LS S y - LS S 0)) * (1 - y * ((1 / k) * JS S y)) := by
  rcases lt_trichotomy y 0 with h | h | h
  · exact PsiS_deriv_pos_of_neg hSm ha hSa hS2 hk h
  · subst h; simp
  · rw [PsiS_deriv_eq_G h.ne']
    exact mul_pos (GS_pos_of_lt_yc hSm ha hSa hS2 hk h hy) (PsiS_pos hSm ha hSa hS2 h)

theorem PsiS_continuousAt {y : ℝ} (hy : y < a) : ContinuousAt (PsiS k S) y :=
  (hasDerivAt_PsiS hSm ha hSa hS2 hy).continuousAt

/-- **Lemma 10.4(4)**: `Ψ_S` is strictly increasing on `(-∞, y_c)`. -/
theorem PsiS_strictMonoOn (hk : 0 < k) : StrictMonoOn (PsiS k S) (Iio (yc k a S)) := by
  have hyca := yc_le hSm ha hSa hS2 hk
  refine strictMonoOn_of_deriv_pos (convex_Iio _) ?_ ?_
  · intro y hy
    exact (PsiS_continuousAt hSm ha hSa hS2 (lt_of_lt_of_le hy hyca)).continuousWithinAt
  · intro y hy
    rw [interior_Iio] at hy
    rw [(hasDerivAt_PsiS hSm ha hSa hS2 (lt_of_lt_of_le hy hyca)).deriv]
    exact PsiS_deriv_pos hSm ha hSa hS2 hk hy

/-- **Lemma 10.4(3)**: `Ψ_S` is strictly decreasing on `[y_c, a)` (when `y_c < a`). -/
theorem PsiS_strictAntiOn (hk : 0 < k) : StrictAntiOn (PsiS k S) (Ico (yc k a S) a) := by
  have hpos := yc_pos hSm ha hSa hS2 hk
  refine strictAntiOn_of_deriv_neg (convex_Ico _ _) ?_ ?_
  · intro y hy
    exact (PsiS_continuousAt hSm ha hSa hS2 hy.2).continuousWithinAt
  · intro y hy
    rw [interior_Ico] at hy
    rw [(hasDerivAt_PsiS hSm ha hSa hS2 hy.2).deriv, PsiS_deriv_eq_G (by linarith [hy.1])]
    exact mul_neg_of_neg_of_pos (GS_neg_of_yc_lt hSm ha hSa hS2 hk hy.1 hy.2)
      (PsiS_pos hSm ha hSa hS2 (by linarith [hy.1]))

end shape

end EP1038.Stage10
