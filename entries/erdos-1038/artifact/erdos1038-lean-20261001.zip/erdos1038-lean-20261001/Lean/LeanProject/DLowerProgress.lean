import LeanProject.DLowerTS
import LeanProject.DWidthDerivatives
import LeanProject.DLowerInfimum

/-! Completed obligations 2/3 and the remaining numerical lower-bound interface. -/
open Real Set
namespace EP1038.DLowerCert
open EP1038.Stage9

theorem actual_TS_dLowerTarget {q : ℝ} (hq : q ∈ Qadm)
    (hTS : q ∈ TRegion ∪ SRegion) : dLowerTarget ≤ Lam q :=
  actual_TS_width_lower hq hTS

/-- Statement 2 is discharged: only statement 4 remains as a numerical input. -/
theorem numerical_family_lower_of_M_bound
    (hM : ∀ q ∈ Qadm, q ∈ MRegion → dLowerTarget ≤ Lam q) : NumericalFamilyLower :=
  family_lower_of_region_bounds (fun _ hq hTS => actual_TS_dLowerTarget hq hTS) hM

/-- Exact numerical enclosure follows as soon as the actual M Taylor bound is proved. -/
theorem numerical_enclosure_of_M_bound
    (hM : ∀ q ∈ Qadm, q ∈ MRegion → dLowerTarget ≤ Lam q) : NumericalDEnclosure :=
  numerical_enclosure_of_family_lower (numerical_family_lower_of_M_bound hM)

end EP1038.DLowerCert
