import LeanProject.ActualBlockReduction
import LeanProject.RefPotOff

/-!
# Certificate variables and the actual separated reference

The negative certificate value is an explicit input. The reference quantile,
its physical potential, and the separation witness are constructed from it.
-/

open Real Set MeasureTheory intervalIntegral

namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11

noncomputable def intervalQuantile (k a : ℝ) (hk : 0 < k) (ha : 0 < a)
    (ha2 : a < 2) (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) : ℝ → ℝ :=
  (AngleReference.ofInterval k a hk ha ha2 hH1).quantile ((a + 2) / 2) ((2 - a) / 2)

noncomputable def certPoint (a v : ℝ) : ℝ :=
  (a + 2) / 2 - D0a a * v - D0a a * (qa a) ^ 2 / v

noncomputable def certE (k a v : ℝ) : ℝ :=
  k / (k + 1) * Real.log ((v - (qa a) ^ 2) / |1 - v|) - Real.log v - Real.log (D0a a)

theorem intervalQuantile_measurable {k a : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) :
    Measurable (intervalQuantile k a hk ha ha2 hH1) :=
  (AngleReference.ofInterval k a hk ha ha2 hH1).quantile_measurable (by linarith)

theorem intervalQuantile_bounds {k a : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (u : ℝ) :
    intervalQuantile k a hk ha ha2 hH1 u ∈ Icc a 2 := by
  have h := (AngleReference.ofInterval k a hk ha ha2 hH1).quantile_bounds
    (c := (a + 2) / 2) (r := (2 - a) / 2) (by linarith) u
  unfold intervalQuantile
  convert h using 1 <;> ring

theorem interval_left_identity {a : ℝ} (ha : 0 < a) :
    D0a a * (1 - qa a) ^ 2 = a := by
  have h1 := D0a_mul_one_add ha
  have h2 := D0a_mul_qa ha
  linear_combination h1 - 2 * h2

theorem certPoint_factor {a v : ℝ} (ha : 0 < a) (hv : v ≠ 0) :
    certPoint a v = D0a a * (v - (qa a) ^ 2) * (1 - v) / v := by
  have hc := D0a_mul_one_add ha
  unfold certPoint
  rw [← hc]
  field_simp
  <;> ring

theorem certPoint_eq_xoff {a v : ℝ} (ha : 0 < a) (ha2 : a < 2) (hv : 0 < v) :
    certPoint a v = xoff (D0a a) (qa a) (qa a / v) := by
  have hc := D0a_mul_one_add ha
  have hq := (qa_pos ha ha2).ne'
  unfold certPoint xoff
  rw [← hc]
  field_simp
  <;> ring

theorem cert_parameter_bounds {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v < 1) :
    0 < v ∧ (qa a) ^ 2 < v ∧ 0 < qa a / v ∧ qa a / v < 1 := by
  have hq := qa_pos ha ha2
  have hq1 := qa_lt_one ha
  have hv := hq.trans hvq
  exact ⟨hv, by nlinarith, div_pos hq hv, (div_lt_one hv).mpr hvq⟩

theorem certPoint_bounds {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v < 1) : certPoint a v ∈ Ioo 0 a := by
  obtain ⟨hv, hvq2, hp, hp1⟩ := cert_parameter_bounds ha ha2 hvq hv1
  constructor
  · rw [certPoint_factor ha hv.ne']
    exact div_pos (mul_pos (mul_pos (D0a_pos ha) (sub_pos.mpr hvq2))
      (sub_pos.mpr hv1)) hv
  · rw [certPoint_eq_xoff ha ha2 hv]
    simpa only [interval_left_identity ha] using
      Stage9.xoff_lt (D0a_pos ha) (qa_pos ha ha2) hp hp1

theorem intervalQuantile_potential_off {k a p : ℝ} (hk : 0 < k) (ha : 0 < a)
    (ha2 : a < 2) (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hp : 0 < p) (hp1 : p < 1) :
    Stage10.WS k (intervalQuantile k a hk ha ha2 hH1) (xoff (D0a a) (qa a) p) =
      k * Real.log |xoff (D0a a) (qa a) p| + Real.log (D0a a * qa a) - Real.log p -
        2 * k * Real.log (1 - qa a * p) := by
  have hD := D0a_pos ha
  have hq := qa_pos ha ha2
  have hq1 := qa_lt_one ha
  let A := AngleReference.ofInterval k a hk ha ha2 hH1
  have hint : Continuous (fun θ =>
      Real.log |xoff (D0a a) (qa a) p - dth (D0a a) (qa a) θ| * alpha k (qa a) θ) := by
    simp_rw [log_dist_off hD hq hp hp1]
    exact (continuous_const.add ((Kl_continuous hp.le hp1).const_mul 2)).mul
      (alpha_cont k (qa a) hq.le hq1)
  have h := W0_off (k := k) hD hq hq1 hp hp1
  change k * Real.log |xoff (D0a a) (qa a) p| + 1 / (2 * π) *
    (∫ θ in (-π)..π, Real.log |xoff (D0a a) (qa a) p - dth (D0a a) (qa a) θ| *
      alpha k (qa a) θ) = _ at h
  rw [int_split (hint.intervalIntegrable _ _)] at h
  have he (θ : ℝ) : dth (D0a a) (qa a) (-θ) = dth (D0a a) (qa a) θ := by
    simp [dth, Real.cos_neg]
  simp_rw [he, alpha, EP1038.Arc.Pq_even] at h
  rw [Stage10.WS]
  change k * Real.log |xoff (D0a a) (qa a) p| +
    (∫ u in (0 : ℝ)..1, Real.log |xoff (D0a a) (qa a) p -
      A.quantile ((a + 2) / 2) ((2 - a) / 2) u|) = _
  rw [A.integral_quantile ((a + 2) / 2) ((2 - a) / 2)
    (fun x => Real.log |xoff (D0a a) (qa a) p - x|)]
  simp only [A, AngleReference.ofInterval]
  simp_rw [AngleReference.position, ← dth_a ha]
  dsimp [alpha]
  linear_combination h

theorem certPoint_log {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v < 1) :
    Real.log |certPoint a v| = Real.log (D0a a) + Real.log (v - (qa a) ^ 2) +
      Real.log (1 - v) - Real.log v := by
  obtain ⟨hv, hvq2, _, _⟩ := cert_parameter_bounds ha ha2 hvq hv1
  have hD := D0a_pos ha
  have hd := sub_pos.mpr hvq2
  have h1 := sub_pos.mpr hv1
  rw [certPoint_factor ha hv.ne', abs_of_pos (div_pos
    (mul_pos (mul_pos (D0a_pos ha) (sub_pos.mpr hvq2)) (sub_pos.mpr hv1)) hv),
    Real.log_div (by positivity) hv.ne', Real.log_mul (by positivity) (by positivity),
    Real.log_mul (D0a_pos ha).ne' (sub_pos.mpr hvq2).ne']

theorem certificate_potential_eq {k a v : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v < 1) :
    Stage10.WS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) =
      -(k + 1) * certE k a v := by
  obtain ⟨hv, hvq2, hp, hp1⟩ := cert_parameter_bounds ha ha2 hvq hv1
  have hq := qa_pos ha ha2
  have hD := D0a_pos ha
  have hmul : 1 - qa a * (qa a / v) = (v - (qa a) ^ 2) / v := by field_simp
  have hlogs : Real.log (qa a / v) = Real.log (qa a) - Real.log v :=
    Real.log_div hq.ne' hv.ne'
  have hlogm : Real.log (1 - qa a * (qa a / v)) = Real.log (v - (qa a) ^ 2) - Real.log v := by
    rw [hmul, Real.log_div (sub_pos.mpr hvq2).ne' hv.ne']
  have hlogD := Real.log_mul hD.ne' hq.ne'
  have hlograt : Real.log ((v - (qa a) ^ 2) / |1 - v|) =
      Real.log (v - (qa a) ^ 2) - Real.log (1 - v) := by
    rw [abs_of_pos (sub_pos.mpr hv1), Real.log_div (sub_pos.mpr hvq2).ne' (sub_pos.mpr hv1).ne']
  rw [certPoint_eq_xoff ha ha2 hv, intervalQuantile_potential_off hk ha ha2 hH1 hp hp1,
    ← certPoint_eq_xoff ha ha2 hv, certPoint_log ha ha2 hvq hv1, hlogs, hlogm, hlogD]
  unfold certE
  rw [hlograt]
  have hk1 : k + 1 ≠ 0 := by positivity
  field_simp
  <;> ring

theorem certificate_potential_pos {k a v : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v < 1)
    (hE : certE k a v < 0) :
    0 < Stage10.WS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) := by
  rw [certificate_potential_eq hk ha ha2 hH1 hvq hv1]
  exact mul_pos_of_neg_of_neg (by linarith) hE

theorem certificate_separation {k a v : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v < 1)
    (hE : certE k a v < 0) :
    Stage10.RS k (intervalQuantile k a hk ha ha2 hH1) <
      Stage10.PsiS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) := by
  have ht := certPoint_bounds ha ha2 hvq hv1
  have hm := intervalQuantile_measurable hk ha ha2 hH1
  have hlow := fun u => (intervalQuantile_bounds hk ha ha2 hH1 u).1
  have hhigh := fun u => (intervalQuantile_bounds hk ha ha2 hH1 u).2
  have h := (Stage10.WS_pos_iff hm ha hlow hhigh hk ht.2 ht.1.ne').mp
    (certificate_potential_pos hk ha ha2 hH1 hvq hv1 hE)
  rwa [abs_of_pos (Stage10.PsiS_pos hm ha hlow hhigh ht.1)] at h

theorem certificate_separation_of_upper_bound {k a v ehi : ℝ} (hk : 0 < k) (ha : 0 < a)
    (ha2 : a < 2) (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v < 1)
    (hbound : certE k a v ≤ ehi) (hneg : ehi < 0) :
    Stage10.RS k (intervalQuantile k a hk ha ha2 hH1) <
      Stage10.PsiS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) :=
  certificate_separation hk ha ha2 hH1 hvq hv1 (hbound.trans_lt hneg)

noncomputable def referenceOfCertificate {k a v : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v < 1)
    (hE : certE k a v < 0) : SeparatedReference :=
  intervalReference k a hk ha ha2 hH1 (certPoint a v)
    (certPoint_bounds ha ha2 hvq hv1).1 (certPoint_bounds ha ha2 hvq hv1).2
    (certificate_separation hk ha ha2 hH1 hvq hv1 hE)

theorem referenceOfCertificate_k {k a v : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v < 1)
    (hE : certE k a v < 0) : (referenceOfCertificate hk ha ha2 hH1 hvq hv1 hE).angles.k = k := rfl

theorem referenceOfCertificate_platform {k a v : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v < 1)
    (hE : certE k a v < 0) :
    let R := referenceOfCertificate hk ha ha2 hH1 hvq hv1 hE
    (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) :=
  interval_zero_exterior ha ha2

end EP1038.ReferenceCert
