import LeanProject.COVLogTwo
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_240 : RB (Real.log ((78695649 : ℝ) / 100000000)) ((-2994779 : ℝ) / 12500000) ((-23958231 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((78695649 : ℝ) / 100000000)) (t := ((-21304351 : ℝ) / 178695649))
    (lo := ((-2994779 : ℝ) / 12500000)) (hi := ((-23958231 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_241 : RB (Real.log ((22021409 : ℝ) / 50000000)) ((-8200079 : ℝ) / 10000000) ((-20500197 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((22021409 : ℝ) / 25000000)) (t := ((-2978591 : ℝ) / 47021409))
    (lo := ((-12686071 : ℝ) / 100000000)) (hi := ((-1268607 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22021409 : ℝ) / 50000000) = Real.log ((22021409 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22021409 : ℝ) / 50000000) = ((22021409 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_242 : RB (Real.log ((465809213 : ℝ) / 100000000)) ((76930297 : ℝ) / 50000000) ((153860597 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((465809213 : ℝ) / 400000000)) (t := ((65809213 : ℝ) / 865809213))
    (lo := ((7615579 : ℝ) / 50000000)) (hi := ((15231159 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((465809213 : ℝ) / 100000000) = Real.log ((465809213 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((465809213 : ℝ) / 100000000) = ((465809213 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_243 : RB (Real.log ((232905123 : ℝ) / 50000000)) ((9616301 : ℝ) / 6250000) ((153860819 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((232905123 : ℝ) / 200000000)) (t := ((32905123 : ℝ) / 432905123))
    (lo := ((761569 : ℝ) / 5000000)) (hi := ((15231381 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((232905123 : ℝ) / 50000000) = Real.log ((232905123 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((232905123 : ℝ) / 50000000) = ((232905123 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_244 : RB (Real.log ((127334677 : ℝ) / 100000000)) ((6041217 : ℝ) / 25000000) ((24164869 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127334677 : ℝ) / 100000000)) (t := ((27334677 : ℝ) / 227334677))
    (lo := ((6041217 : ℝ) / 25000000)) (hi := ((24164869 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_245 : RB (Real.log ((463241813 : ℝ) / 100000000)) ((1533079 : ℝ) / 1000000) ((153307903 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((463241813 : ℝ) / 400000000)) (t := ((63241813 : ℝ) / 863241813))
    (lo := ((229351 : ℝ) / 1562500)) (hi := ((2935693 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((463241813 : ℝ) / 100000000) = Real.log ((463241813 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((463241813 : ℝ) / 100000000) = ((463241813 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_246 : RB (Real.log ((463242839 : ℝ) / 100000000)) ((153308121 : ℝ) / 100000000) ((38327031 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((463242839 : ℝ) / 400000000)) (t := ((63242839 : ℝ) / 863242839))
    (lo := ((2935737 : ℝ) / 20000000)) (hi := ((7339343 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((463242839 : ℝ) / 100000000) = Real.log ((463242839 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((463242839 : ℝ) / 100000000) = ((463242839 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_247 : RB (Real.log ((127527879 : ℝ) / 100000000)) ((24316481 : ℝ) / 100000000) ((12158241 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((127527879 : ℝ) / 100000000)) (t := ((27527879 : ℝ) / 227527879))
    (lo := ((24316481 : ℝ) / 100000000)) (hi := ((12158241 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_248 : RB (Real.log ((905673 : ℝ) / 12500000)) ((-52496113 : ℝ) / 20000000) ((-3281007 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((905673 : ℝ) / 781250)) (t := ((124423 : ℝ) / 1686923))
    (lo := ((14778311 : ℝ) / 100000000)) (hi := ((1847289 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((905673 : ℝ) / 12500000) = Real.log ((905673 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((905673 : ℝ) / 12500000) = ((905673 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_249 : RB (Real.log ((416023 : ℝ) / 5000000)) ((-248645269 : ℝ) / 100000000) ((-15540329 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((416023 : ℝ) / 312500)) (t := ((103523 : ℝ) / 728523))
    (lo := ((28613607 : ℝ) / 100000000)) (hi := ((3576701 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((416023 : ℝ) / 5000000) = Real.log ((416023 : ℝ) / 312500) - 4 * Real.log 2 := by
    rw [show ((416023 : ℝ) / 5000000) = ((416023 : ℝ) / 312500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_250 : RB (Real.log ((204937 : ℝ) / 12500000)) ((-411078137 : ℝ) / 100000000) ((-41107813 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((409874 : ℝ) / 390625)) (t := ((19249 : ℝ) / 800499))
    (lo := ((4810177 : ℝ) / 100000000)) (hi := ((2405089 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((204937 : ℝ) / 12500000) = Real.log ((409874 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((204937 : ℝ) / 12500000) = ((409874 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_251 : RB (Real.log ((83641 : ℝ) / 5000000)) ((-204532971 : ℝ) / 50000000) ((-81813187 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((83641 : ℝ) / 78125)) (t := ((2758 : ℝ) / 80883))
    (lo := ((1705593 : ℝ) / 25000000)) (hi := ((6822373 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((83641 : ℝ) / 5000000) = Real.log ((83641 : ℝ) / 78125) - 6 * Real.log 2 := by
    rw [show ((83641 : ℝ) / 5000000) = ((83641 : ℝ) / 78125) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_252 : RB (Real.log ((15438361 : ℝ) / 20000000)) ((-25887689 : ℝ) / 100000000) ((-3235961 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((15438361 : ℝ) / 20000000)) (t := ((-4561639 : ℝ) / 35438361))
    (lo := ((-25887689 : ℝ) / 100000000)) (hi := ((-3235961 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_253 : RB (Real.log ((15438463 : ℝ) / 20000000)) ((-25887029 : ℝ) / 100000000) ((-6471757 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((15438463 : ℝ) / 20000000)) (t := ((-4561537 : ℝ) / 35438463))
    (lo := ((-25887029 : ℝ) / 100000000)) (hi := ((-6471757 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_254 : RB (Real.log ((1742729 : ℝ) / 4000000)) ((-8308421 : ℝ) / 10000000) ((-5192763 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((1742729 : ℝ) / 2000000)) (t := ((-257271 : ℝ) / 3742729))
    (lo := ((-13769491 : ℝ) / 100000000)) (hi := ((-1376949 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1742729 : ℝ) / 4000000) = Real.log ((1742729 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((1742729 : ℝ) / 4000000) = ((1742729 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_255 : RB (Real.log ((98288117 : ℝ) / 50000000)) ((16897003 : ℝ) / 25000000) ((33794007 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((98288117 : ℝ) / 100000000)) (t := ((-1711883 : ℝ) / 198288117))
    (lo := ((-863353 : ℝ) / 50000000)) (hi := ((-345341 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98288117 : ℝ) / 50000000) = Real.log ((98288117 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98288117 : ℝ) / 50000000) = ((98288117 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_256 : RB (Real.log ((196641251 : ℝ) / 100000000)) ((33810541 : ℝ) / 50000000) ((16905271 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((196641251 : ℝ) / 200000000)) (t := ((-3358749 : ℝ) / 396641251))
    (lo := ((-423409 : ℝ) / 25000000)) (hi := ((-338727 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196641251 : ℝ) / 100000000) = Real.log ((196641251 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196641251 : ℝ) / 100000000) = ((196641251 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_257 : RB (Real.log ((3921443 : ℝ) / 5000000)) ((-12148911 : ℝ) / 50000000) ((-24297821 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3921443 : ℝ) / 5000000)) (t := ((-1078557 : ℝ) / 8921443))
    (lo := ((-12148911 : ℝ) / 50000000)) (hi := ((-24297821 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_258 : RB (Real.log ((78429373 : ℝ) / 100000000)) ((-1518573 : ℝ) / 6250000) ((-24297167 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((78429373 : ℝ) / 100000000)) (t := ((-21570627 : ℝ) / 178429373))
    (lo := ((-1518573 : ℝ) / 6250000)) (hi := ((-24297167 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_259 : RB (Real.log ((43959469 : ℝ) / 100000000)) ((-16438043 : ℝ) / 20000000) ((-82190213 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43959469 : ℝ) / 50000000)) (t := ((-6040531 : ℝ) / 93959469))
    (lo := ((-1609437 : ℝ) / 12500000)) (hi := ((-2575099 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43959469 : ℝ) / 100000000) = Real.log ((43959469 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43959469 : ℝ) / 100000000) = ((43959469 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_260 : RB (Real.log ((92989157 : ℝ) / 20000000)) ((76837531 : ℝ) / 50000000) ((30735013 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((92989157 : ℝ) / 80000000)) (t := ((12989157 : ℝ) / 172989157))
    (lo := ((7522813 : ℝ) / 50000000)) (hi := ((15045627 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92989157 : ℝ) / 20000000) = Real.log ((92989157 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((92989157 : ℝ) / 20000000) = ((92989157 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_261 : RB (Real.log ((464946833 : ℝ) / 100000000)) ((153675287 : ℝ) / 100000000) ((15367529 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((464946833 : ℝ) / 400000000)) (t := ((64946833 : ℝ) / 864946833))
    (lo := ((15045851 : ℝ) / 100000000)) (hi := ((3761463 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((464946833 : ℝ) / 100000000) = Real.log ((464946833 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((464946833 : ℝ) / 100000000) = ((464946833 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_262 : RB (Real.log ((12739927 : ℝ) / 10000000)) ((12107791 : ℝ) / 50000000) ((24215583 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12739927 : ℝ) / 10000000)) (t := ((2739927 : ℝ) / 22739927))
    (lo := ((12107791 : ℝ) / 50000000)) (hi := ((24215583 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_263 : RB (Real.log ((28899877 : ℝ) / 6250000)) ((153125587 : ℝ) / 100000000) ((15312559 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((28899877 : ℝ) / 25000000)) (t := ((3899877 : ℝ) / 53899877))
    (lo := ((14496151 : ℝ) / 100000000)) (hi := ((1812019 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28899877 : ℝ) / 6250000) = Real.log ((28899877 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((28899877 : ℝ) / 6250000) = ((28899877 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_264 : RB (Real.log ((462399073 : ℝ) / 100000000)) ((38281453 : ℝ) / 25000000) ((30625163 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((462399073 : ℝ) / 400000000)) (t := ((62399073 : ℝ) / 862399073))
    (lo := ((1812047 : ℝ) / 12500000)) (hi := ((14496377 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((462399073 : ℝ) / 100000000) = Real.log ((462399073 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((462399073 : ℝ) / 100000000) = ((462399073 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_265 : RB (Real.log ((63795947 : ℝ) / 50000000)) ((4873333 : ℝ) / 20000000) ((12183333 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((63795947 : ℝ) / 50000000)) (t := ((13795947 : ℝ) / 113795947))
    (lo := ((4873333 : ℝ) / 20000000)) (hi := ((12183333 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_266 : RB (Real.log ((7259951 : ℝ) / 100000000)) ((-52455943 : ℝ) / 20000000) ((-26227971 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((7259951 : ℝ) / 6250000)) (t := ((1009951 : ℝ) / 13509951))
    (lo := ((14979161 : ℝ) / 100000000)) (hi := ((7489581 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7259951 : ℝ) / 100000000) = Real.log ((7259951 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7259951 : ℝ) / 100000000) = ((7259951 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_267 : RB (Real.log ((332813 : ℝ) / 4000000)) ((-248646891 : ℝ) / 100000000) ((-124323443 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((332813 : ℝ) / 250000)) (t := ((82813 : ℝ) / 582813))
    (lo := ((5722397 : ℝ) / 20000000)) (hi := ((14305993 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((332813 : ℝ) / 4000000) = Real.log ((332813 : ℝ) / 250000) - 4 * Real.log 2 := by
    rw [show ((332813 : ℝ) / 4000000) = ((332813 : ℝ) / 250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_268 : RB (Real.log ((1671711 : ℝ) / 100000000)) ((-409132259 : ℝ) / 100000000) ((-102283063 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1671711 : ℝ) / 1562500)) (t := ((109211 : ℝ) / 3234211))
    (lo := ((1351211 : ℝ) / 20000000)) (hi := ((844507 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1671711 : ℝ) / 100000000) = Real.log ((1671711 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1671711 : ℝ) / 100000000) = ((1671711 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_269 : RB (Real.log ((1705059 : ℝ) / 100000000)) ((-407157053 : ℝ) / 100000000) ((-203578523 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1705059 : ℝ) / 1562500)) (t := ((142559 : ℝ) / 3267559))
    (lo := ((8731261 : ℝ) / 100000000)) (hi := ((4365631 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1705059 : ℝ) / 100000000) = Real.log ((1705059 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1705059 : ℝ) / 100000000) = ((1705059 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_270 : RB (Real.log ((76953729 : ℝ) / 100000000)) ((-26196587 : ℝ) / 100000000) ((-13098293 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((76953729 : ℝ) / 100000000)) (t := ((-23046271 : ℝ) / 176953729))
    (lo := ((-26196587 : ℝ) / 100000000)) (hi := ((-13098293 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_271 : RB (Real.log ((76954249 : ℝ) / 100000000)) ((-26195911 : ℝ) / 100000000) ((-2619591 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((76954249 : ℝ) / 100000000)) (t := ((-23045751 : ℝ) / 176954249))
    (lo := ((-26195911 : ℝ) / 100000000)) (hi := ((-2619591 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_272 : RB (Real.log ((21746233 : ℝ) / 50000000)) ((-83258247 : ℝ) / 100000000) ((-16651649 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((21746233 : ℝ) / 25000000)) (t := ((-3253767 : ℝ) / 46746233))
    (lo := ((-1742941 : ℝ) / 12500000)) (hi := ((-13943527 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21746233 : ℝ) / 50000000) = Real.log ((21746233 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21746233 : ℝ) / 50000000) = ((21746233 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_273 : RB (Real.log ((49127803 : ℝ) / 25000000)) ((6755493 : ℝ) / 10000000) ((16888733 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((49127803 : ℝ) / 50000000)) (t := ((-872197 : ℝ) / 99127803))
    (lo := ((-439947 : ℝ) / 25000000)) (hi := ((-1759787 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((49127803 : ℝ) / 25000000) = Real.log ((49127803 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((49127803 : ℝ) / 25000000) = ((49127803 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_274 : RB (Real.log ((196576241 : ℝ) / 100000000)) ((4224251 : ℝ) / 6250000) ((33794009 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((196576241 : ℝ) / 200000000)) (t := ((-3423759 : ℝ) / 396576241))
    (lo := ((-863351 : ℝ) / 50000000)) (hi := ((-1726701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196576241 : ℝ) / 100000000) = Real.log ((196576241 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196576241 : ℝ) / 100000000) = ((196576241 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_275 : RB (Real.log ((78167601 : ℝ) / 100000000)) ((-12315747 : ℝ) / 50000000) ((-24631493 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((78167601 : ℝ) / 100000000)) (t := ((-21832399 : ℝ) / 178167601))
    (lo := ((-12315747 : ℝ) / 50000000)) (hi := ((-24631493 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_276 : RB (Real.log ((19542031 : ℝ) / 25000000)) ((-985233 : ℝ) / 4000000) ((-3078853 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((19542031 : ℝ) / 25000000)) (t := ((-5457969 : ℝ) / 44542031))
    (lo := ((-985233 : ℝ) / 4000000)) (hi := ((-3078853 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_277 : RB (Real.log ((43877457 : ℝ) / 100000000)) ((-10297119 : ℝ) / 12500000) ((-1647539 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((43877457 : ℝ) / 50000000)) (t := ((-6122543 : ℝ) / 93877457))
    (lo := ((-13062233 : ℝ) / 100000000)) (hi := ((-1632779 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43877457 : ℝ) / 100000000) = Real.log ((43877457 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43877457 : ℝ) / 100000000) = ((43877457 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_278 : RB (Real.log ((464088967 : ℝ) / 100000000)) ((9593163 : ℝ) / 6250000) ((153490611 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((464088967 : ℝ) / 400000000)) (t := ((64088967 : ℝ) / 864088967))
    (lo := ((3715293 : ℝ) / 25000000)) (hi := ((14861173 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((464088967 : ℝ) / 100000000) = Real.log ((464088967 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((464088967 : ℝ) / 100000000) = ((464088967 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_279 : RB (Real.log ((92818007 : ℝ) / 20000000)) ((76745419 : ℝ) / 50000000) ((153490841 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((92818007 : ℝ) / 80000000)) (t := ((12818007 : ℝ) / 172818007))
    (lo := ((7430701 : ℝ) / 50000000)) (hi := ((14861403 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92818007 : ℝ) / 20000000) = Real.log ((92818007 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((92818007 : ℝ) / 20000000) = ((92818007 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_280 : RB (Real.log ((127463669 : ℝ) / 100000000)) ((12133059 : ℝ) / 50000000) ((24266119 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127463669 : ℝ) / 100000000)) (t := ((27463669 : ℝ) / 227463669))
    (lo := ((12133059 : ℝ) / 50000000)) (hi := ((24266119 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_281 : RB (Real.log ((461560619 : ℝ) / 100000000)) ((152944321 : ℝ) / 100000000) ((38236081 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((461560619 : ℝ) / 400000000)) (t := ((61560619 : ℝ) / 861560619))
    (lo := ((2862977 : ℝ) / 20000000)) (hi := ((7157443 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((461560619 : ℝ) / 100000000) = Real.log ((461560619 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((461560619 : ℝ) / 100000000) = ((461560619 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_282 : RB (Real.log ((5769521 : ℝ) / 1250000)) ((3058891 : ℝ) / 2000000) ((152944553 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5769521 : ℝ) / 5000000)) (t := ((769521 : ℝ) / 10769521))
    (lo := ((7157557 : ℝ) / 50000000)) (hi := ((2863023 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5769521 : ℝ) / 1250000) = Real.log ((5769521 : ℝ) / 5000000) + 2 * Real.log 2 := by
    rw [show ((5769521 : ℝ) / 1250000) = ((5769521 : ℝ) / 5000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_283 : RB (Real.log ((127655719 : ℝ) / 100000000)) ((976667 : ℝ) / 4000000) ((6104169 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((127655719 : ℝ) / 100000000)) (t := ((27655719 : ℝ) / 227655719))
    (lo := ((976667 : ℝ) / 4000000)) (hi := ((6104169 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_284 : RB (Real.log ((3638239 : ℝ) / 50000000)) ((-262052327 : ℝ) / 100000000) ((-131026161 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3638239 : ℝ) / 3125000)) (t := ((513239 : ℝ) / 6763239))
    (lo := ((15206549 : ℝ) / 100000000)) (hi := ((304131 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3638239 : ℝ) / 50000000) = Real.log ((3638239 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((3638239 : ℝ) / 50000000) = ((3638239 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_285 : RB (Real.log ((2080607 : ℝ) / 25000000)) ((-248621619 : ℝ) / 100000000) ((-124310807 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2080607 : ℝ) / 1562500)) (t := ((518107 : ℝ) / 3643107))
    (lo := ((28637257 : ℝ) / 100000000)) (hi := ((14318629 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2080607 : ℝ) / 25000000) = Real.log ((2080607 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((2080607 : ℝ) / 25000000) = ((2080607 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_286 : RB (Real.log ((1703927 : ℝ) / 100000000)) ((-203611733 : ℝ) / 50000000) ((-407223459 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1703927 : ℝ) / 1562500)) (t := ((141427 : ℝ) / 3266427))
    (lo := ((541553 : ℝ) / 6250000)) (hi := ((8664849 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1703927 : ℝ) / 100000000) = Real.log ((1703927 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1703927 : ℝ) / 100000000) = ((1703927 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_287 : RB (Real.log ((108581 : ℝ) / 6250000)) ((-405284037 : ℝ) / 100000000) ((-40528403 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((434324 : ℝ) / 390625)) (t := ((43699 : ℝ) / 824949))
    (lo := ((10604277 : ℝ) / 100000000)) (hi := ((5302139 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((108581 : ℝ) / 6250000) = Real.log ((434324 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((108581 : ℝ) / 6250000) = ((434324 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_288 : RB (Real.log ((38265847 : ℝ) / 50000000)) ((-6686631 : ℝ) / 25000000) ((-26746523 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38265847 : ℝ) / 50000000)) (t := ((-11734153 : ℝ) / 88265847))
    (lo := ((-6686631 : ℝ) / 25000000)) (hi := ((-26746523 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_289 : RB (Real.log ((76532223 : ℝ) / 100000000)) ((-3343229 : ℝ) / 12500000) ((-26745831 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76532223 : ℝ) / 100000000)) (t := ((-23467777 : ℝ) / 176532223))
    (lo := ((-3343229 : ℝ) / 12500000)) (hi := ((-26745831 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_290 : RB (Real.log ((21678771 : ℝ) / 50000000)) ((-83568953 : ℝ) / 100000000) ((-83568951 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((21678771 : ℝ) / 25000000)) (t := ((-3321229 : ℝ) / 46678771))
    (lo := ((-7127117 : ℝ) / 50000000)) (hi := ((-14254233 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21678771 : ℝ) / 50000000) = Real.log ((21678771 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21678771 : ℝ) / 50000000) = ((21678771 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_291 : RB (Real.log ((98223089 : ℝ) / 50000000)) ((6752183 : ℝ) / 10000000) ((8440229 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((98223089 : ℝ) / 100000000)) (t := ((-1776911 : ℝ) / 198223089))
    (lo := ((-224111 : ℝ) / 12500000)) (hi := ((-1792887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98223089 : ℝ) / 50000000) = Real.log ((98223089 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98223089 : ℝ) / 50000000) = ((98223089 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_292 : RB (Real.log ((12281951 : ℝ) / 6250000)) ((16888733 : ℝ) / 25000000) ((33777467 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12281951 : ℝ) / 12500000)) (t := ((-218049 : ℝ) / 24781951))
    (lo := ((-879893 : ℝ) / 50000000)) (hi := ((-351957 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12281951 : ℝ) / 6250000) = Real.log ((12281951 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((12281951 : ℝ) / 6250000) = ((12281951 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_293 : RB (Real.log ((488141 : ℝ) / 625000)) ((-1544671 : ℝ) / 6250000) ((-4942947 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((488141 : ℝ) / 625000)) (t := ((-136859 : ℝ) / 1113141))
    (lo := ((-1544671 : ℝ) / 6250000)) (hi := ((-4942947 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_294 : RB (Real.log ((39051547 : ℝ) / 50000000)) ((-6178513 : ℝ) / 25000000) ((-24714051 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39051547 : ℝ) / 50000000)) (t := ((-10948453 : ℝ) / 89051547))
    (lo := ((-6178513 : ℝ) / 25000000)) (hi := ((-24714051 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_295 : RB (Real.log ((43857129 : ℝ) / 100000000)) ((-20605823 : ℝ) / 25000000) ((-8242329 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((43857129 : ℝ) / 50000000)) (t := ((-6142871 : ℝ) / 93857129))
    (lo := ((-13108573 : ℝ) / 100000000)) (hi := ((-3277143 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43857129 : ℝ) / 100000000) = Real.log ((43857129 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43857129 : ℝ) / 100000000) = ((43857129 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_296 : RB (Real.log ((115809671 : ℝ) / 25000000)) ((6132289 : ℝ) / 4000000) ((38326807 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((115809671 : ℝ) / 100000000)) (t := ((15809671 : ℝ) / 215809671))
    (lo := ((14677789 : ℝ) / 100000000)) (hi := ((1467779 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((115809671 : ℝ) / 25000000) = Real.log ((115809671 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((115809671 : ℝ) / 25000000) = ((115809671 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_297 : RB (Real.log ((463239771 : ℝ) / 100000000)) ((153307459 : ℝ) / 100000000) ((76653731 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((463239771 : ℝ) / 400000000)) (t := ((63239771 : ℝ) / 863239771))
    (lo := ((14678023 : ℝ) / 100000000)) (hi := ((1834753 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((463239771 : ℝ) / 100000000) = Real.log ((463239771 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((463239771 : ℝ) / 100000000) = ((463239771 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_298 : RB (Real.log ((1020223 : ℝ) / 800000)) ((12158239 : ℝ) / 50000000) ((24316479 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1020223 : ℝ) / 800000)) (t := ((220223 : ℝ) / 1820223))
    (lo := ((12158239 : ℝ) / 50000000)) (hi := ((24316479 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_299 : RB (Real.log ((230364757 : ℝ) / 50000000)) ((76382047 : ℝ) / 50000000) ((152764097 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((230364757 : ℝ) / 200000000)) (t := ((30364757 : ℝ) / 430364757))
    (lo := ((7067329 : ℝ) / 50000000)) (hi := ((14134659 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((230364757 : ℝ) / 50000000) = Real.log ((230364757 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((230364757 : ℝ) / 50000000) = ((230364757 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_300 : RB (Real.log ((460730593 : ℝ) / 100000000)) ((19095541 : ℝ) / 12500000) ((152764331 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((460730593 : ℝ) / 400000000)) (t := ((60730593 : ℝ) / 860730593))
    (lo := ((3533723 : ℝ) / 25000000)) (hi := ((14134893 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((460730593 : ℝ) / 100000000) = Real.log ((460730593 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((460730593 : ℝ) / 100000000) = ((460730593 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_301 : RB (Real.log ((63859677 : ℝ) / 50000000)) ((1529157 : ℝ) / 6250000) ((24466513 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63859677 : ℝ) / 50000000)) (t := ((13859677 : ℝ) / 113859677))
    (lo := ((1529157 : ℝ) / 6250000)) (hi := ((24466513 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_302 : RB (Real.log ((7162249 : ℝ) / 100000000)) ((-263634619 : ℝ) / 100000000) ((-131817307 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((7162249 : ℝ) / 6250000)) (t := ((912249 : ℝ) / 13412249))
    (lo := ((13624257 : ℝ) / 100000000)) (hi := ((6812129 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7162249 : ℝ) / 100000000) = Real.log ((7162249 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7162249 : ℝ) / 100000000) = ((7162249 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_303 : RB (Real.log ((2115309 : ℝ) / 25000000)) ((-30870937 : ℝ) / 12500000) ((-61741873 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2115309 : ℝ) / 3125000)) (t := ((-1009691 : ℝ) / 5240309))
    (lo := ((-39023339 : ℝ) / 100000000)) (hi := ((-19511669 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2115309 : ℝ) / 25000000) = Real.log ((2115309 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((2115309 : ℝ) / 25000000) = ((2115309 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_304 : RB (Real.log ((868071 : ℝ) / 50000000)) ((-101337621 : ℝ) / 25000000) ((-405350477 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((868071 : ℝ) / 781250)) (t := ((86821 : ℝ) / 1649321))
    (lo := ((1053783 : ℝ) / 10000000)) (hi := ((10537831 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((868071 : ℝ) / 50000000) = Real.log ((868071 : ℝ) / 781250) - 6 * Real.log 2 := by
    rw [show ((868071 : ℝ) / 50000000) = ((868071 : ℝ) / 781250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_305 : RB (Real.log ((1769533 : ℝ) / 100000000)) ((-201722729 : ℝ) / 50000000) ((-403445451 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1769533 : ℝ) / 1562500)) (t := ((207033 : ℝ) / 3332033))
    (lo := ((1555357 : ℝ) / 12500000)) (hi := ((12442857 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1769533 : ℝ) / 100000000) = Real.log ((1769533 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1769533 : ℝ) / 100000000) = ((1769533 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_306 : RB (Real.log ((19076441 : ℝ) / 25000000)) ((-27042171 : ℝ) / 100000000) ((-2704217 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((19076441 : ℝ) / 25000000)) (t := ((-5923559 : ℝ) / 44076441))
    (lo := ((-27042171 : ℝ) / 100000000)) (hi := ((-2704217 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_307 : RB (Real.log ((76306303 : ℝ) / 100000000)) ((-5408293 : ℝ) / 20000000) ((-3380183 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((76306303 : ℝ) / 100000000)) (t := ((-23693697 : ℝ) / 176306303))
    (lo := ((-5408293 : ℝ) / 20000000)) (hi := ((-3380183 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_308 : RB (Real.log ((43285129 : ℝ) / 100000000)) ((-83736107 : ℝ) / 100000000) ((-16747221 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((43285129 : ℝ) / 50000000)) (t := ((-6714871 : ℝ) / 93285129))
    (lo := ((-3605347 : ℝ) / 25000000)) (hi := ((-14421387 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43285129 : ℝ) / 100000000) = Real.log ((43285129 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43285129 : ℝ) / 100000000) = ((43285129 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_309 : RB (Real.log ((196381133 : ℝ) / 100000000)) ((33744357 : ℝ) / 50000000) ((16872179 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((196381133 : ℝ) / 200000000)) (t := ((-3618867 : ℝ) / 396381133))
    (lo := ((-456501 : ℝ) / 25000000)) (hi := ((-1826003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196381133 : ℝ) / 100000000) = Real.log ((196381133 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196381133 : ℝ) / 100000000) = ((196381133 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_310 : RB (Real.log ((39289237 : ℝ) / 20000000)) ((67521833 : ℝ) / 100000000) ((13504367 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((39289237 : ℝ) / 40000000)) (t := ((-710763 : ℝ) / 79289237))
    (lo := ((-358577 : ℝ) / 20000000)) (hi := ((-448221 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39289237 : ℝ) / 20000000) = Real.log ((39289237 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39289237 : ℝ) / 20000000) = ((39289237 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_311 : RB (Real.log ((15569489 : ℝ) / 20000000)) ((-25041911 : ℝ) / 100000000) ((-2504191 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((15569489 : ℝ) / 20000000)) (t := ((-4430511 : ℝ) / 35569489))
    (lo := ((-25041911 : ℝ) / 100000000)) (hi := ((-2504191 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_312 : RB (Real.log ((19461997 : ℝ) / 25000000)) ((-12520607 : ℝ) / 50000000) ((-25041213 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19461997 : ℝ) / 25000000)) (t := ((-5538003 : ℝ) / 44461997))
    (lo := ((-12520607 : ℝ) / 50000000)) (hi := ((-25041213 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_313 : RB (Real.log ((8755353 : ℝ) / 20000000)) ((-826067 : ℝ) / 1000000) ((-41303349 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8755353 : ℝ) / 10000000)) (t := ((-1244647 : ℝ) / 18755353))
    (lo := ((-13291981 : ℝ) / 100000000)) (hi := ((-664599 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8755353 : ℝ) / 20000000) = Real.log ((8755353 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8755353 : ℝ) / 20000000) = ((8755353 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_314 : RB (Real.log ((92478969 : ℝ) / 20000000)) ((76562449 : ℝ) / 50000000) ((153124901 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((92478969 : ℝ) / 80000000)) (t := ((12478969 : ℝ) / 172478969))
    (lo := ((7247731 : ℝ) / 50000000)) (hi := ((14495463 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92478969 : ℝ) / 20000000) = Real.log ((92478969 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((92478969 : ℝ) / 20000000) = ((92478969 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_315 : RB (Real.log ((462395951 : ℝ) / 100000000)) ((153125137 : ℝ) / 100000000) ((7656257 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((462395951 : ℝ) / 400000000)) (t := ((62395951 : ℝ) / 862395951))
    (lo := ((14495701 : ℝ) / 100000000)) (hi := ((7247851 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((462395951 : ℝ) / 100000000) = Real.log ((462395951 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((462395951 : ℝ) / 100000000) = ((462395951 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_316 : RB (Real.log ((12759189 : ℝ) / 10000000)) ((12183331 : ℝ) / 50000000) ((24366663 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12759189 : ℝ) / 10000000)) (t := ((2759189 : ℝ) / 22759189))
    (lo := ((12183331 : ℝ) / 50000000)) (hi := ((24366663 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_317 : RB (Real.log ((459904603 : ℝ) / 100000000)) ((152584889 : ℝ) / 100000000) ((38146223 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((459904603 : ℝ) / 400000000)) (t := ((59904603 : ℝ) / 859904603))
    (lo := ((13955453 : ℝ) / 100000000)) (hi := ((6977727 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459904603 : ℝ) / 100000000) = Real.log ((459904603 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((459904603 : ℝ) / 100000000) = ((459904603 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_318 : RB (Real.log ((229952851 : ℝ) / 50000000)) ((19073141 : ℝ) / 12500000) ((152585131 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((229952851 : ℝ) / 200000000)) (t := ((29952851 : ℝ) / 429952851))
    (lo := ((3488923 : ℝ) / 25000000)) (hi := ((13955693 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229952851 : ℝ) / 50000000) = Real.log ((229952851 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((229952851 : ℝ) / 50000000) = ((229952851 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_319 : RB (Real.log ((127782803 : ℝ) / 100000000)) ((12258089 : ℝ) / 50000000) ((24516179 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127782803 : ℝ) / 100000000)) (t := ((27782803 : ℝ) / 227782803))
    (lo := ((12258089 : ℝ) / 50000000)) (hi := ((24516179 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
