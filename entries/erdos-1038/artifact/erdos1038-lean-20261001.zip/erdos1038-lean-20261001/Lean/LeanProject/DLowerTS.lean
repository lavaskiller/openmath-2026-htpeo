import LeanProject.DLowerTSCertificates
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_T_all {r : ℝ}
    (hr0 : 0 < r) (hqa : tailQ r ∈ Qadm) (hr : r ≤ rho1) : lowerTarget ≤ Lam (tailQ r) := by
  have hlo : (0 : ℝ) ≤ r := hr0.le
  rcases le_or_gt r ((3912727356259487 : ℝ) / 72057594037927936) with hhi | hnext0
  · exact dlower_T_0 hr0 hqa ⟨by exact hlo, hhi⟩
  rcases le_or_gt r ((3912727356259487 : ℝ) / 36028797018963968) with hhi | hnext1
  · exact dlower_T_1 hr0 hqa ⟨by exact hnext0.le, hhi⟩
  rcases le_or_gt r ((19563636781297435 : ℝ) / 144115188075855872) with hhi | hnext2
  · exact dlower_T_2 hr0 hqa ⟨by exact hnext1.le, hhi⟩
  rcases le_or_gt r ((43040000918854357 : ℝ) / 288230376151711744) with hhi | hnext3
  · exact dlower_T_3 hr0 hqa ⟨by exact hnext2.le, hhi⟩
  rcases le_or_gt r ((11738182068778461 : ℝ) / 72057594037927936) with hhi | hnext4
  · exact dlower_T_4 hr0 hqa ⟨by exact hnext3.le, hhi⟩
  rcases le_or_gt r ((50865455631373331 : ℝ) / 288230376151711744) with hhi | hnext5
  · exact dlower_T_5 hr0 hqa ⟨by exact hnext4.le, hhi⟩
  rcases le_or_gt r ((105643638619006149 : ℝ) / 576460752303423488) with hhi | hnext6
  · exact dlower_T_6 hr0 hqa ⟨by exact hnext5.le, hhi⟩
  rcases le_or_gt r ((27389091493816409 : ℝ) / 144115188075855872) with hhi | hnext7
  · exact dlower_T_7 hr0 hqa ⟨by exact hnext6.le, hhi⟩
  rcases le_or_gt r ((113469093331525123 : ℝ) / 576460752303423488) with hhi | hnext8
  · exact dlower_T_8 hr0 hqa ⟨by exact hnext7.le, hhi⟩
  rcases le_or_gt r ((230850914019309733 : ℝ) / 1152921504606846976) with hhi | hnext9
  · exact dlower_T_9 hr0 hqa ⟨by exact hnext8.le, hhi⟩
  rcases le_or_gt r ((58690910343892305 : ℝ) / 288230376151711744) with hhi | hnext10
  · exact dlower_T_10 hr0 hqa ⟨by exact hnext9.le, hhi⟩
  rcases le_or_gt r ((238676368731828707 : ℝ) / 1152921504606846976) with hhi | hnext11
  · exact dlower_T_11 hr0 hqa ⟨by exact hnext10.le, hhi⟩
  rcases le_or_gt r ((121294548044044097 : ℝ) / 576460752303423488) with hhi | hnext12
  · exact dlower_T_12 hr0 hqa ⟨by exact hnext11.le, hhi⟩
  rcases le_or_gt r ((246501823444347681 : ℝ) / 1152921504606846976) with hhi | hnext13
  · exact dlower_T_13 hr0 hqa ⟨by exact hnext12.le, hhi⟩
  rcases le_or_gt r ((496916374244954849 : ℝ) / 2305843009213693952) with hhi | hnext14
  · exact dlower_T_14 hr0 hqa ⟨by exact hnext13.le, hhi⟩
  exact dlower_T_15 hr0 hqa ⟨hnext14.le, by norm_num [rho1, rho1Idx, dyad, gridDen] at hr ⊢; exact hr⟩
theorem dlower_S_all {q : ℝ}
    (hqa : q ∈ Qadm) (hq : q ∈ SRegion) : lowerTarget ≤ Lam q := by
  have hlo := hq.1
  rcases le_or_gt q ((262602036213167199442600599958323 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext0
  · exact dlower_S_0 hqa ⟨by norm_num [SRegion, qB, qbIdx, dyad, gridDen] at hlo ⊢; exact hlo, hhi⟩
  rcases le_or_gt q ((265589229499593017458676383455641 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext1
  · exact dlower_S_1 hqa ⟨by exact hnext0.le, hhi⟩
  rcases le_or_gt q ((268576422786018835474752166952959 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext2
  · exact dlower_S_2 hqa ⟨by exact hnext1.le, hhi⟩
  rcases le_or_gt q ((135781808036222326745413975225139 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext3
  · exact dlower_S_3 hqa ⟨by exact hnext2.le, hhi⟩
  rcases le_or_gt q ((68637702339717617876725933486899 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext4
  · exact dlower_S_4 hqa ⟨by exact hnext3.le, hhi⟩
  rcases le_or_gt q ((277538002645296289522979517444915 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext5
  · exact dlower_S_5 hqa ⟨by exact hnext4.le, hhi⟩
  rcases le_or_gt q ((280525195931722107539055300942233 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext6
  · exact dlower_S_6 hqa ⟨by exact hnext5.le, hhi⟩
  rcases le_or_gt q ((31476198227647681 : ℝ) / 576460752303423488) with hhi | hnext7
  · exact dlower_S_7 hqa ⟨by exact hnext6.le, hhi⟩
  rcases le_or_gt q ((143249791252286871785603433968435 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext8
  · exact dlower_S_8 hqa ⟨by exact hnext7.le, hhi⟩
  rcases le_or_gt q ((72371693947749890396820662858547 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext9
  · exact dlower_S_9 hqa ⟨by exact hnext8.le, hhi⟩
  rcases le_or_gt q ((146236984538712689801679217465753 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext10
  · exact dlower_S_10 hqa ⟨by exact hnext9.le, hhi⟩
  rcases le_or_gt q ((295461162363851197619434218428825 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext11
  · exact dlower_S_11 hqa ⟨by exact hnext10.le, hhi⟩
  rcases le_or_gt q ((150717774468351416825792892711731 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext12
  · exact dlower_S_12 hqa ⟨by exact hnext11.le, hhi⟩
  rcases le_or_gt q ((307409935509554469683737352418099 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext13
  · exact dlower_S_13 hqa ⟨by exact hnext12.le, hhi⟩
  rcases le_or_gt q ((313384322082406105715888919412735 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext14
  · exact dlower_S_14 hqa ⟨by exact hnext13.le, hhi⟩
  rcases le_or_gt q ((79839677163814435437010121601843 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext15
  · exact dlower_S_15 hqa ⟨by exact hnext14.le, hhi⟩
  rcases le_or_gt q ((325333095228109377780192053402009 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext16
  · exact dlower_S_16 hqa ⟨by exact hnext15.le, hhi⟩
  rcases le_or_gt q ((165653740900480506906171810198323 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext17
  · exact dlower_S_17 hqa ⟨by exact hnext16.le, hhi⟩
  rcases le_or_gt q ((168640934186906324922247593695641 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext18
  · exact dlower_S_18 hqa ⟨by exact hnext17.le, hhi⟩
  rcases le_or_gt q ((343256254946664285876646754385919 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext19
  · exact dlower_S_19 hqa ⟨by exact hnext18.le, hhi⟩
  rcases le_or_gt q ((87307660379878980477199580345139 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext20
  · exact dlower_S_20 hqa ⟨by exact hnext19.le, hhi⟩
  rcases le_or_gt q ((355205028092367557940949888375193 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext21
  · exact dlower_S_21 hqa ⟨by exact hnext20.le, hhi⟩
  rcases le_or_gt q ((361179414665219193973101455369829 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext22
  · exact dlower_S_22 hqa ⟨by exact hnext21.le, hhi⟩
  rcases le_or_gt q ((183576900619035415002626511182233 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext23
  · exact dlower_S_23 hqa ⟨by exact hnext22.le, hhi⟩
  rcases le_or_gt q ((373128187810922466037404589359103 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext24
  · exact dlower_S_24 hqa ⟨by exact hnext23.le, hhi⟩
  rcases le_or_gt q ((94775643595943525517389039088435 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext25
  · exact dlower_S_25 hqa ⟨by exact hnext24.le, hhi⟩
  rcases le_or_gt q ((48134620119578217262713465418547 : ℝ) / 649037107316853453566312041152512) with hhi | hnext26
  · exact dlower_S_26 hqa ⟨by exact hnext25.le, hhi⟩
  rcases le_or_gt q ((391051347529477374133859290343013 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext27
  · exact dlower_S_27 hqa ⟨by exact hnext26.le, hhi⟩
  rcases le_or_gt q ((198512867051164505083005428668825 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext28
  · exact dlower_S_28 hqa ⟨by exact hnext27.le, hhi⟩
  rcases le_or_gt q ((403000120675180646198162424332287 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext29
  · exact dlower_S_29 hqa ⟨by exact hnext28.le, hhi⟩
  rcases le_or_gt q ((408974507248032282230313991326923 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext30
  · exact dlower_S_30 hqa ⟨by exact hnext29.le, hhi⟩
  rcases le_or_gt q ((51868611727610489782808194790195 : ℝ) / 649037107316853453566312041152512) with hhi | hnext31
  · exact dlower_S_31 hqa ⟨by exact hnext30.le, hhi⟩
  rcases le_or_gt q ((213448833483293595163384346155417 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext32
  · exact dlower_S_32 hqa ⟨by exact hnext31.le, hhi⟩
  rcases le_or_gt q ((109711610028072615597767956575027 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext33
  · exact dlower_S_33 hqa ⟨by exact hnext32.le, hhi⟩
  rcases le_or_gt q ((225397606628996867227687480144691 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext34
  · exact dlower_S_34 hqa ⟨by exact hnext33.le, hhi⟩
  rcases le_or_gt q ((462743986403697006519678094278655 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext35
  · exact dlower_S_35 hqa ⟨by exact hnext34.le, hhi⟩
  rcases le_or_gt q ((474692759549400278583981228267929 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext36
  · exact dlower_S_36 hqa ⟨by exact hnext35.le, hhi⟩
  rcases le_or_gt q ((243320766347551775324142181128601 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext37
  · exact dlower_S_37 hqa ⟨by exact hnext36.le, hhi⟩
  rcases le_or_gt q ((124647576460201705678146874061619 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext38
  · exact dlower_S_38 hqa ⟨by exact hnext37.le, hhi⟩
  rcases le_or_gt q ((510539078986510094776890630235749 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext39
  · exact dlower_S_39 hqa ⟨by exact hnext38.le, hhi⟩
  rcases le_or_gt q ((522487852132213366841193764225023 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext40
  · exact dlower_S_40 hqa ⟨by exact hnext39.le, hhi⟩
  rcases le_or_gt q ((534436625277916638905496898214297 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext41
  · exact dlower_S_41 hqa ⟨by exact hnext40.le, hhi⟩
  rcases le_or_gt q ((546385398423619910969800032203571 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext42
  · exact dlower_S_42 hqa ⟨by exact hnext41.le, hhi⟩
  rcases le_or_gt q ((139583542892330795758525791548211 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext43
  · exact dlower_S_43 hqa ⟨by exact hnext42.le, hhi⟩
  rcases le_or_gt q ((285141472357513227549203150091059 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext44
  · exact dlower_S_44 hqa ⟨by exact hnext43.le, hhi⟩
  rcases le_or_gt q ((288128665643939045565278933588377 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext45
  · exact dlower_S_45 hqa ⟨by exact hnext44.le, hhi⟩
  rcases le_or_gt q ((582231717860729727162709434171391 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext46
  · exact dlower_S_46 hqa ⟨by exact hnext45.le, hhi⟩
  rcases le_or_gt q ((147051526108395340798715250291507 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext47
  · exact dlower_S_47 hqa ⟨by exact hnext46.le, hhi⟩
  rcases le_or_gt q ((594180491006432999227012568160665 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext48
  · exact dlower_S_48 hqa ⟨by exact hnext47.le, hhi⟩
  rcases le_or_gt q ((600154877579284635259164135155301 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext49
  · exact dlower_S_49 hqa ⟨by exact hnext48.le, hhi⟩
  rcases le_or_gt q ((303064632076068135645657851074969 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext50
  · exact dlower_S_50 hqa ⟨by exact hnext49.le, hhi⟩
  rcases le_or_gt q ((612103650724987907323467269144575 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext51
  · exact dlower_S_51 hqa ⟨by exact hnext50.le, hhi⟩
  rcases le_or_gt q ((154519509324459885838904709034803 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext52
  · exact dlower_S_52 hqa ⟨by exact hnext51.le, hhi⟩
  rcases le_or_gt q ((310532615292132680685847309818265 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext53
  · exact dlower_S_53 hqa ⟨by exact hnext52.le, hhi⟩
  rcases le_or_gt q ((624052423870691179387770403133849 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext54
  · exact dlower_S_54 hqa ⟨by exact hnext53.le, hhi⟩
  rcases le_or_gt q ((627039617157116997403846186631167 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext55
  · exact dlower_S_55 hqa ⟨by exact hnext54.le, hhi⟩
  rcases le_or_gt q ((315013405221771407709960985064243 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext56
  · exact dlower_S_56 hqa ⟨by exact hnext55.le, hhi⟩
  rcases le_or_gt q ((158253500932492158358999438406451 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext57
  · exact dlower_S_57 hqa ⟨by exact hnext56.le, hhi⟩
  rcases le_or_gt q ((634507600373181542444035645374463 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext58
  · exact dlower_S_58 hqa ⟨by exact hnext57.le, hhi⟩
  rcases le_or_gt q ((636001197016394451452073537123123 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext59
  · exact dlower_S_59 hqa ⟨by exact hnext58.le, hhi⟩
  rcases le_or_gt q ((318747396829803680230055714435891 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext60
  · exact dlower_S_60 hqa ⟨by exact hnext59.le, hhi⟩
  rcases le_or_gt q ((638241591981213814964130374746111 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext61
  · exact dlower_S_61 hqa ⟨by exact hnext60.le, hhi⟩
  rcases le_or_gt q ((638988390302820269468149320620441 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext62
  · exact dlower_S_62 hqa ⟨by exact hnext61.le, hhi⟩
  rcases le_or_gt q ((319867594312213361986084133247385 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext63
  · exact dlower_S_63 hqa ⟨by exact hnext62.le, hhi⟩
  rcases le_or_gt q ((640108587785229951224177739431935 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext64
  · exact dlower_S_64 hqa ⟨by exact hnext63.le, hhi⟩
  rcases le_or_gt q ((160120496736508294619046803092275 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext65
  · exact dlower_S_65 hqa ⟨by exact hnext64.le, hhi⟩
  rcases le_or_gt q ((640855386106836405728196685306265 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext66
  · exact dlower_S_66 hqa ⟨by exact hnext65.le, hhi⟩
  rcases le_or_gt q ((641042085687238019354201421774847 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext67
  · exact dlower_S_67 hqa ⟨by exact hnext66.le, hhi⟩
  rcases le_or_gt q ((320614392633819816490103079121715 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext68
  · exact dlower_S_68 hqa ⟨by exact hnext67.le, hhi⟩
  rcases le_or_gt q ((160353871212010311651552723678003 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext69
  · exact dlower_S_69 hqa ⟨by exact hnext68.le, hhi⟩
  rcases le_or_gt q ((641508834638242053419213262946303 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext70
  · exact dlower_S_70 hqa ⟨by exact hnext69.le, hhi⟩
  rcases le_or_gt q ((641602184428442860232215631180595 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext71
  · exact dlower_S_71 hqa ⟨by exact hnext70.le, hhi⟩
  rcases le_or_gt q ((320847767109321833522608999707443 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext72
  · exact dlower_S_72 hqa ⟨by exact hnext71.le, hhi⟩
  rcases le_or_gt q ((641742209113744070451719183532031 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext73
  · exact dlower_S_73 hqa ⟨by exact hnext72.le, hhi⟩
  rcases le_or_gt q ((641788884008844473858220367649177 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext74
  · exact dlower_S_74 hqa ⟨by exact hnext73.le, hhi⟩
  rcases le_or_gt q ((320917779451972438632360775883161 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext75
  · exact dlower_S_75 hqa ⟨by exact hnext74.le, hhi⟩
  rcases le_or_gt q ((160470558449761320167805683970867 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext76
  · exact dlower_S_76 hqa ⟨by exact hnext75.le, hhi⟩
  rcases le_or_gt q ((320964454347072842038861960000307 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext77
  · exact dlower_S_77 hqa ⟨by exact hnext76.le, hhi⟩
  have hlast := hq.2
  exact dlower_S_78 hqa ⟨hnext77.le, by norm_num [SRegion, qHi, qhiIdx, dyad, gridDen] at hlast ⊢; exact hlast⟩

/-- Numbered obligation 2, with no numerical or sign assumptions. -/
theorem actual_TS_width_lower {q : ℝ} (hq : q ∈ Qadm)
    (hTS : q ∈ TRegion ∪ SRegion) : lowerTarget ≤ Lam q := by
  rcases hTS with ht | hs
  · have hr := tail_rho_bounds ht
    have he := tailQ_rho hq.1 hq.2.1
    have hqa : tailQ (rho q) ∈ Qadm := by simpa only [he] using hq
    simpa only [he] using dlower_T_all hr.1 hqa hr.2
  · exact dlower_S_all hq hs
end EP1038.DLowerCert
