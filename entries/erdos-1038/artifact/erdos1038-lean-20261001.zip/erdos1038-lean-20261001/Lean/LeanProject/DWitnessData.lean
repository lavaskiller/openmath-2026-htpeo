import LeanProject.R1Pilot
import LeanProject.Stage9C

/-! Exact rational log data for the admissible D witness and the terminal overlap. -/
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9

set_option maxHeartbeats 4000000 in
theorem witness_log_two :
    ((17328679513998632735430803 : ℝ) / 25000000000000000000000000) ≤ Real.log (2 : ℝ) ∧ Real.log (2 : ℝ) ≤ ((69314718055994530941723213 : ℝ) / 100000000000000000000000000) := by
  have hm := log_bounds_of_series (x := (2 : ℝ)) (t := ((1 : ℝ) / 3))
    (lo := ((17328679513998632735430803 : ℝ) / 25000000000000000000000000)) (hi := ((69314718055994530941723213 : ℝ) / 100000000000000000000000000)) (by norm_num) (by norm_num) 30
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  constructor <;> linarith [hm.1, hm.2]

set_option maxHeartbeats 4000000 in
theorem witness_log_q :
    ((-3660661356039951794876769 : ℝ) / 1000000000000000000000000) ≤ Real.log ((51431 : ℝ) / 2000000) ∧ Real.log ((51431 : ℝ) / 2000000) ≤ ((-1830330678019975897438383 : ℝ) / 500000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((51431 : ℝ) / 62500)) (t := ((-11069 : ℝ) / 113931))
    (lo := ((-19492545324022524779060739 : ℝ) / 100000000000000000000000000)) (hi := ((-9746272662011262389530369 : ℝ) / 50000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51431 : ℝ) / 2000000) = Real.log ((51431 : ℝ) / 62500) - 5 * Real.log 2 := by
    rw [show ((51431 : ℝ) / 2000000) = ((51431 : ℝ) / 62500) / 2 ^ 5 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem witness_log_H :
    ((-603659002235253260538691 : ℝ) / 200000000000000000000000) ≤ Real.log ((205724000000 : ℝ) / 4208369147761) ∧ Real.log ((205724000000 : ℝ) / 4208369147761) ≤ ((-754573752794066575673363 : ℝ) / 250000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((3291584000000 : ℝ) / 4208369147761)) (t := ((-916785147761 : ℝ) / 7499953147761))
    (lo := ((-982825155745940260098101 : ℝ) / 4000000000000000000000000)) (hi := ((-6142657223412126625613131 : ℝ) / 25000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((205724000000 : ℝ) / 4208369147761) = Real.log ((3291584000000 : ℝ) / 4208369147761) - 4 * Real.log 2 := by
    rw [show ((205724000000 : ℝ) / 4208369147761) = ((3291584000000 : ℝ) / 4208369147761) / 2 ^ 4 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem witness_log_pm :
    ((-100376076296793394816637 : ℝ) / 25000000000000000000000) ≤ Real.log ((14095451394145233 : ℝ) / 781250000000000000) ∧ Real.log ((14095451394145233 : ℝ) / 781250000000000000) ≤ ((-4015043051871735792665477 : ℝ) / 1000000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((14095451394145233 : ℝ) / 12207031250000000)) (t := ((1888420144145233 : ℝ) / 26302482644145233))
    (lo := ((14384003148793606383791413 : ℝ) / 100000000000000000000000000)) (hi := ((7192001574396803191895707 : ℝ) / 50000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14095451394145233 : ℝ) / 781250000000000000) = Real.log ((14095451394145233 : ℝ) / 12207031250000000) - 6 * Real.log 2 := by
    rw [show ((14095451394145233 : ℝ) / 781250000000000000) = ((14095451394145233 : ℝ) / 12207031250000000) / 2 ^ 6 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem witness_log_pp :
    ((-2882671319613712042033899 : ℝ) / 1000000000000000000000000) ≤ Real.log ((279925045251633559 : ℝ) / 5000000000000000000) ∧ Real.log ((279925045251633559 : ℝ) / 5000000000000000000) ≤ ((-360333914951714005254237 : ℝ) / 125000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((279925045251633559 : ℝ) / 312500000000000000)) (t := ((-32574954748366441 : ℝ) / 592425045251633559))
    (lo := ((-11008259737393080436496943 : ℝ) / 100000000000000000000000000)) (hi := ((-5504129868696540218248471 : ℝ) / 50000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((279925045251633559 : ℝ) / 5000000000000000000) = Real.log ((279925045251633559 : ℝ) / 312500000000000000) - 4 * Real.log 2 := by
    rw [show ((279925045251633559 : ℝ) / 5000000000000000000) = ((279925045251633559 : ℝ) / 312500000000000000) / 2 ^ 4 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem witness_log_ratio_pm :
    ((4869541541963354082774031 : ℝ) / 1000000000000000000000000) ≤ Real.log ((1561775056839347716521577 : ℝ) / 11989565961709534000000) ∧ Real.log ((1561775056839347716521577 : ℝ) / 11989565961709534000000) ≤ ((2434770770981677041387017 : ℝ) / 500000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1561775056839347716521577 : ℝ) / 1534664443098820352000000)) (t := ((27110613740527364521577 : ℝ) / 3096439499938168068521577))
    (lo := ((1751127804373691685340733 : ℝ) / 100000000000000000000000000)) (hi := ((875563902186845842670367 : ℝ) / 50000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1561775056839347716521577 : ℝ) / 11989565961709534000000) = Real.log ((1561775056839347716521577 : ℝ) / 1534664443098820352000000) + 7 * Real.log 2 := by
    rw [show ((1561775056839347716521577 : ℝ) / 11989565961709534000000) = ((1561775056839347716521577 : ℝ) / 1534664443098820352000000) * 2 ^ 7 by norm_num,
      Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem witness_log_ratio_pp :
    ((3496173655259158101278583 : ℝ) / 1000000000000000000000000) ≤ Real.log ((9985603174997663234427071 : ℝ) / 302695090503267118000000) ∧ Real.log ((9985603174997663234427071 : ℝ) / 302695090503267118000000) ≤ ((1748086827629579050639293 : ℝ) / 500000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((9985603174997663234427071 : ℝ) / 9686242896104547776000000)) (t := ((299360278893115458427071 : ℝ) / 19671846071102211010427071))
    (lo := ((3043775245943155419242379 : ℝ) / 100000000000000000000000000)) (hi := ((152188762297157770962119 : ℝ) / 5000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9985603174997663234427071 : ℝ) / 302695090503267118000000) = Real.log ((9985603174997663234427071 : ℝ) / 9686242896104547776000000) + 5 * Real.log 2 := by
    rw [show ((9985603174997663234427071 : ℝ) / 302695090503267118000000) = ((9985603174997663234427071 : ℝ) / 9686242896104547776000000) * 2 ^ 5 by norm_num,
      Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem terminal_log_q :
    ((-1585042830349384373068073 : ℝ) / 500000000000000000000000) ≤ Real.log ((21 : ℝ) / 500) ∧ Real.log ((21 : ℝ) / 500) ≤ ((-3170085660698768746136143 : ℝ) / 1000000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((84 : ℝ) / 125)) (t := ((-41 : ℝ) / 209))
    (lo := ((-19874846922949375423360789 : ℝ) / 50000000000000000000000000)) (hi := ((-39749693845898750846721577 : ℝ) / 100000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21 : ℝ) / 500) = Real.log ((84 : ℝ) / 125) - 4 * Real.log 2 := by
    rw [show ((21 : ℝ) / 500) = ((84 : ℝ) / 125) / 2 ^ 4 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem terminal_log_D0 :
    ((152715823474398739628231 : ℝ) / 250000000000000000000000) ≤ Real.log ((500000 : ℝ) / 271441) ∧ Real.log ((500000 : ℝ) / 271441) ≤ ((610863293897594958512927 : ℝ) / 1000000000000000000000000) := by
  have hm := log_bounds_of_series (x := ((250000 : ℝ) / 271441)) (t := ((-21441 : ℝ) / 521441))
    (lo := ((-8228388666235035090430693 : ℝ) / 100000000000000000000000000)) (hi := ((-2057097166558758772607673 : ℝ) / 25000000000000000000000000)) (by norm_num) (by norm_num) 22
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((500000 : ℝ) / 271441) = Real.log ((250000 : ℝ) / 271441) + 1 * Real.log 2 := by
    rw [show ((500000 : ℝ) / 271441) = ((250000 : ℝ) / 271441) * 2 ^ 1 by norm_num,
      Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

noncomputable def dWitnessQ : ℝ := ((51431 : ℝ) / 2000000)
noncomputable def dWitnessPmLo : ℝ := ((14095451394145233 : ℝ) / 781250000000000000)
noncomputable def dWitnessPpHi : ℝ := ((279925045251633559 : ℝ) / 5000000000000000000)
noncomputable def dWitnessAHi : ℝ := ((4122608891691380449197 : ℝ) / 5000000000000000000000)

theorem d_witness_admissible : dWitnessQ ∈ Qadm := by
  refine ⟨by norm_num [dWitnessQ], by norm_num [dWitnessQ], ?_⟩
  unfold fq dWitnessQ
  have hd : Real.log (2 / (1 + ((51431 : ℝ) / 2000000)) ^ 2) = Real.log ((205724000000 : ℝ) / 4208369147761) - Real.log ((51431 : ℝ) / 2000000) := by
    rw [← Real.log_div (by norm_num) (by norm_num)]
    congr 1 <;> norm_num
  rw [hd]
  nlinarith [witness_log_q.1, witness_log_q.2, witness_log_H.1, witness_log_H.2]

theorem d_witness_A_upper : Aq dWitnessQ ≤ dWitnessAHi := by
  have hn : Real.log dWitnessQ < 0 := log_q_neg (by norm_num [dWitnessQ]) (by norm_num [dWitnessQ])
  unfold Aq
  apply (div_le_iff_of_neg hn).mpr
  norm_num [dWitnessQ, D0q, dWitnessAHi]
  nlinarith [witness_log_q.2, witness_log_H.1]

theorem d_witness_minus_sign : GA (Aq dWitnessQ) dWitnessQ dWitnessPmLo < 0 := by
  have ha := d_witness_A_upper
  have hr : 0 ≤ Real.log ((1561775056839347716521577 : ℝ) / 11989565961709534000000) := by linarith [witness_log_ratio_pm.1]
  have hm := mul_le_mul_of_nonneg_right ha hr
  unfold GA dWitnessPmLo dWitnessQ at *
  norm_num only [abs_of_neg (by norm_num : ((14095451394145233 : ℝ) / 781250000000000000) - ((51431 : ℝ) / 2000000) < 0)]
  unfold dWitnessAHi at hm
  nlinarith [witness_log_ratio_pm.2, witness_log_pm.2]

theorem d_witness_plus_sign : GA (Aq dWitnessQ) dWitnessQ dWitnessPpHi < 0 := by
  have ha := d_witness_A_upper
  have hr : 0 ≤ Real.log ((9985603174997663234427071 : ℝ) / 302695090503267118000000) := by linarith [witness_log_ratio_pp.1]
  have hm := mul_le_mul_of_nonneg_right ha hr
  unfold GA dWitnessPpHi dWitnessQ at *
  norm_num only [abs_of_pos (by norm_num : ((279925045251633559 : ℝ) / 5000000000000000000) - ((51431 : ℝ) / 2000000) > 0)]
  unfold dWitnessAHi at hm
  nlinarith [witness_log_ratio_pp.2, witness_log_pp.2]

end EP1038.ReferenceCert
