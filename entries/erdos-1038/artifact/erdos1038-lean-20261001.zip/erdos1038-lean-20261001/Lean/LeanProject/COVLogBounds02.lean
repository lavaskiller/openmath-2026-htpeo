import LeanProject.COVLogTwo
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_160 : RB (Real.log ((1478417 : ℝ) / 100000000)) ((-421419833 : ℝ) / 100000000) ((-210709913 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1478417 : ℝ) / 1562500)) (t := ((-84083 : ℝ) / 3040917))
    (lo := ((-5531519 : ℝ) / 100000000)) (hi := ((-2765759 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1478417 : ℝ) / 100000000) = Real.log ((1478417 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1478417 : ℝ) / 100000000) = ((1478417 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_161 : RB (Real.log ((1511633 : ℝ) / 100000000)) ((-104799493 : ℝ) / 25000000) ((-83839593 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1511633 : ℝ) / 1562500)) (t := ((-50867 : ℝ) / 3074133))
    (lo := ((-1654829 : ℝ) / 50000000)) (hi := ((-3309657 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1511633 : ℝ) / 100000000) = Real.log ((1511633 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1511633 : ℝ) / 100000000) = ((1511633 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_162 : RB (Real.log ((19612937 : ℝ) / 25000000)) ((-24268643 : ℝ) / 100000000) ((-12134321 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19612937 : ℝ) / 25000000)) (t := ((-5387063 : ℝ) / 44612937))
    (lo := ((-24268643 : ℝ) / 100000000)) (hi := ((-12134321 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_163 : RB (Real.log ((78452209 : ℝ) / 100000000)) ((-4853611 : ℝ) / 20000000) ((-12134027 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((78452209 : ℝ) / 100000000)) (t := ((-21547791 : ℝ) / 178452209))
    (lo := ((-4853611 : ℝ) / 20000000)) (hi := ((-12134027 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_164 : RB (Real.log ((21982943 : ℝ) / 50000000)) ((-82175619 : ℝ) / 100000000) ((-82175617 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((21982943 : ℝ) / 25000000)) (t := ((-3017057 : ℝ) / 46982943))
    (lo := ((-128609 : ℝ) / 1000000)) (hi := ((-12860899 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21982943 : ℝ) / 50000000) = Real.log ((21982943 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21982943 : ℝ) / 50000000) = ((21982943 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_165 : RB (Real.log ((196901183 : ℝ) / 100000000)) ((3387659 : ℝ) / 5000000) ((33876591 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((196901183 : ℝ) / 200000000)) (t := ((-3098817 : ℝ) / 396901183))
    (lo := ((-780769 : ℝ) / 50000000)) (hi := ((-1561537 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196901183 : ℝ) / 100000000) = Real.log ((196901183 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196901183 : ℝ) / 100000000) = ((196901183 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_166 : RB (Real.log ((769399 : ℝ) / 390625)) ((33893083 : ℝ) / 50000000) ((8473271 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((769399 : ℝ) / 781250)) (t := ((-11851 : ℝ) / 1550649))
    (lo := ((-191069 : ℝ) / 12500000)) (hi := ((-1528551 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((769399 : ℝ) / 390625) = Real.log ((769399 : ℝ) / 781250) + 1 * Real.log 2 := by
    rw [show ((769399 : ℝ) / 390625) = ((769399 : ℝ) / 781250) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_167 : RB (Real.log ((79812711 : ℝ) / 100000000)) ((-22548741 : ℝ) / 100000000) ((-1127437 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((79812711 : ℝ) / 100000000)) (t := ((-20187289 : ℝ) / 179812711))
    (lo := ((-22548741 : ℝ) / 100000000)) (hi := ((-1127437 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_168 : RB (Real.log ((9976647 : ℝ) / 12500000)) ((-22548159 : ℝ) / 100000000) ((-11274079 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9976647 : ℝ) / 12500000)) (t := ((-2523353 : ℝ) / 22476647))
    (lo := ((-22548159 : ℝ) / 100000000)) (hi := ((-11274079 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_169 : RB (Real.log ((11097499 : ℝ) / 25000000)) ((-81215607 : ℝ) / 100000000) ((-16243121 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((11097499 : ℝ) / 12500000)) (t := ((-1402501 : ℝ) / 23597499))
    (lo := ((-1487611 : ℝ) / 12500000)) (hi := ((-11900887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11097499 : ℝ) / 25000000) = Real.log ((11097499 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11097499 : ℝ) / 25000000) = ((11097499 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_170 : RB (Real.log ((93866153 : ℝ) / 20000000)) ((77306879 : ℝ) / 50000000) ((154613761 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((93866153 : ℝ) / 80000000)) (t := ((13866153 : ℝ) / 173866153))
    (lo := ((7992161 : ℝ) / 50000000)) (hi := ((15984323 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((93866153 : ℝ) / 20000000) = Real.log ((93866153 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((93866153 : ℝ) / 20000000) = ((93866153 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_171 : RB (Real.log ((469331719 : ℝ) / 100000000)) ((77306981 : ℝ) / 50000000) ((30922793 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((469331719 : ℝ) / 400000000)) (t := ((69331719 : ℝ) / 869331719))
    (lo := ((7992263 : ℝ) / 50000000)) (hi := ((15984527 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((469331719 : ℝ) / 100000000) = Real.log ((469331719 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((469331719 : ℝ) / 100000000) = ((469331719 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_172 : RB (Real.log ((127074337 : ℝ) / 100000000)) ((4792041 : ℝ) / 20000000) ((11980103 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((127074337 : ℝ) / 100000000)) (t := ((27074337 : ℝ) / 227074337))
    (lo := ((4792041 : ℝ) / 20000000)) (hi := ((11980103 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_173 : RB (Real.log ((233341129 : ℝ) / 50000000)) ((38511961 : ℝ) / 25000000) ((154047847 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((233341129 : ℝ) / 200000000)) (t := ((33341129 : ℝ) / 433341129))
    (lo := ((1927301 : ℝ) / 12500000)) (hi := ((15418409 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((233341129 : ℝ) / 50000000) = Real.log ((233341129 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((233341129 : ℝ) / 50000000) = ((233341129 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_174 : RB (Real.log ((233341603 : ℝ) / 50000000)) ((9628003 : ℝ) / 6250000) ((154048051 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((233341603 : ℝ) / 200000000)) (t := ((33341603 : ℝ) / 433341603))
    (lo := ((3854653 : ℝ) / 25000000)) (hi := ((15418613 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((233341603 : ℝ) / 50000000) = Real.log ((233341603 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((233341603 : ℝ) / 50000000) = ((233341603 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_175 : RB (Real.log ((31817473 : ℝ) / 25000000)) ((24113977 : ℝ) / 100000000) ((12056989 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((31817473 : ℝ) / 25000000)) (t := ((6817473 : ℝ) / 56817473))
    (lo := ((24113977 : ℝ) / 100000000)) (hi := ((12056989 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_176 : RB (Real.log ((7207649 : ℝ) / 100000000)) ((-263002741 : ℝ) / 100000000) ((-16437671 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((7207649 : ℝ) / 6250000)) (t := ((957649 : ℝ) / 13457649))
    (lo := ((2851227 : ℝ) / 20000000)) (hi := ((1782017 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7207649 : ℝ) / 100000000) = Real.log ((7207649 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7207649 : ℝ) / 100000000) = ((7207649 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_177 : RB (Real.log ((4172089 : ℝ) / 50000000)) ((-248360617 : ℝ) / 100000000) ((-248360613 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4172089 : ℝ) / 6250000)) (t := ((-2077911 : ℝ) / 10422089))
    (lo := ((-2020823 : ℝ) / 5000000)) (hi := ((-40416459 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4172089 : ℝ) / 50000000) = Real.log ((4172089 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4172089 : ℝ) / 50000000) = ((4172089 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_178 : RB (Real.log ((1510631 : ℝ) / 100000000)) ((-10481607 : ℝ) / 2500000) ((-419264273 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1510631 : ℝ) / 1562500)) (t := ((-51869 : ℝ) / 3073131))
    (lo := ((-1687983 : ℝ) / 50000000)) (hi := ((-675193 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1510631 : ℝ) / 100000000) = Real.log ((1510631 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1510631 : ℝ) / 100000000) = ((1510631 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_179 : RB (Real.log ((154387 : ℝ) / 10000000)) ((-2085439 : ℝ) / 500000) ((-417087793 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((154387 : ℝ) / 156250)) (t := ((-1863 : ℝ) / 310637))
    (lo := ((-599743 : ℝ) / 50000000)) (hi := ((-239897 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((154387 : ℝ) / 10000000) = Real.log ((154387 : ℝ) / 156250) - 6 * Real.log 2 := by
    rw [show ((154387 : ℝ) / 10000000) = ((154387 : ℝ) / 156250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_180 : RB (Real.log ((78190123 : ℝ) / 100000000)) ((-12301343 : ℝ) / 50000000) ((-4920537 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((78190123 : ℝ) / 100000000)) (t := ((-21809877 : ℝ) / 178190123))
    (lo := ((-12301343 : ℝ) / 50000000)) (hi := ((-4920537 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_181 : RB (Real.log ((19547649 : ℝ) / 25000000)) ((-24602081 : ℝ) / 100000000) ((-153763 : ℝ) / 625000) := by
  have hm := log_bounds_of_series (x := ((19547649 : ℝ) / 25000000)) (t := ((-5452351 : ℝ) / 44547649))
    (lo := ((-24602081 : ℝ) / 100000000)) (hi := ((-153763 : ℝ) / 625000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_182 : RB (Real.log ((43883763 : ℝ) / 100000000)) ((-82362581 : ℝ) / 100000000) ((-82362579 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43883763 : ℝ) / 50000000)) (t := ((-6116237 : ℝ) / 93883763))
    (lo := ((-6523931 : ℝ) / 50000000)) (hi := ((-13047861 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43883763 : ℝ) / 100000000) = Real.log ((43883763 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43883763 : ℝ) / 100000000) = ((43883763 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_183 : RB (Real.log ((98418107 : ℝ) / 50000000)) ((67720179 : ℝ) / 100000000) ((67720181 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((98418107 : ℝ) / 100000000)) (t := ((-1581893 : ℝ) / 198418107))
    (lo := ((-1594539 : ℝ) / 100000000)) (hi := ((-797269 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98418107 : ℝ) / 50000000) = Real.log ((98418107 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98418107 : ℝ) / 50000000) = ((98418107 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_184 : RB (Real.log ((98450593 : ℝ) / 50000000)) ((33876591 : ℝ) / 50000000) ((2117287 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((98450593 : ℝ) / 100000000)) (t := ((-1549407 : ℝ) / 198450593))
    (lo := ((-24399 : ℝ) / 1562500)) (hi := ((-312307 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98450593 : ℝ) / 50000000) = Real.log ((98450593 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98450593 : ℝ) / 50000000) = ((98450593 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_185 : RB (Real.log ((39762619 : ℝ) / 50000000)) ((-2863697 : ℝ) / 12500000) ((-916383 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((39762619 : ℝ) / 50000000)) (t := ((-10237381 : ℝ) / 89762619))
    (lo := ((-2863697 : ℝ) / 12500000)) (hi := ((-916383 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_186 : RB (Real.log ((15905143 : ℝ) / 20000000)) ((-1431811 : ℝ) / 6250000) ((-916359 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((15905143 : ℝ) / 20000000)) (t := ((-4094857 : ℝ) / 35905143))
    (lo := ((-1431811 : ℝ) / 6250000)) (hi := ((-916359 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_187 : RB (Real.log ((8860219 : ℝ) / 20000000)) ((-81416081 : ℝ) / 100000000) ((-81416079 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8860219 : ℝ) / 10000000)) (t := ((-1139781 : ℝ) / 18860219))
    (lo := ((-6050681 : ℝ) / 50000000)) (hi := ((-12101361 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8860219 : ℝ) / 20000000) = Real.log ((8860219 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8860219 : ℝ) / 20000000) = ((8860219 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_188 : RB (Real.log ((117110007 : ℝ) / 25000000)) ((154423789 : ℝ) / 100000000) ((9651487 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((117110007 : ℝ) / 100000000)) (t := ((17110007 : ℝ) / 217110007))
    (lo := ((15794353 : ℝ) / 100000000)) (hi := ((7897177 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((117110007 : ℝ) / 25000000) = Real.log ((117110007 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((117110007 : ℝ) / 25000000) = ((117110007 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_189 : RB (Real.log ((93688201 : ℝ) / 20000000)) ((77211999 : ℝ) / 50000000) ((154424001 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((93688201 : ℝ) / 80000000)) (t := ((13688201 : ℝ) / 173688201))
    (lo := ((7897281 : ℝ) / 50000000)) (hi := ((15794563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((93688201 : ℝ) / 20000000) = Real.log ((93688201 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((93688201 : ℝ) / 20000000) = ((93688201 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_190 : RB (Real.log ((3178493 : ℝ) / 2500000)) ((4802329 : ℝ) / 20000000) ((12005823 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3178493 : ℝ) / 2500000)) (t := ((678493 : ℝ) / 5678493))
    (lo := ((4802329 : ℝ) / 20000000)) (hi := ((12005823 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_191 : RB (Real.log ((232906089 : ℝ) / 50000000)) ((153861231 : ℝ) / 100000000) ((76930617 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((232906089 : ℝ) / 200000000)) (t := ((32906089 : ℝ) / 432906089))
    (lo := ((3046359 : ℝ) / 20000000)) (hi := ((3807949 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((232906089 : ℝ) / 50000000) = Real.log ((232906089 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((232906089 : ℝ) / 50000000) = ((232906089 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_192 : RB (Real.log ((116453287 : ℝ) / 25000000)) ((153861439 : ℝ) / 100000000) ((76930721 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((116453287 : ℝ) / 100000000)) (t := ((16453287 : ℝ) / 216453287))
    (lo := ((15232003 : ℝ) / 100000000)) (hi := ((3808001 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((116453287 : ℝ) / 25000000) = Real.log ((116453287 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((116453287 : ℝ) / 25000000) = ((116453287 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_193 : RB (Real.log ((127334681 : ℝ) / 100000000)) ((24164871 : ℝ) / 100000000) ((3020609 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((127334681 : ℝ) / 100000000)) (t := ((27334681 : ℝ) / 227334681))
    (lo := ((24164871 : ℝ) / 100000000)) (hi := ((3020609 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_194 : RB (Real.log ((7213917 : ℝ) / 100000000)) ((-52583163 : ℝ) / 20000000) ((-26291581 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((7213917 : ℝ) / 6250000)) (t := ((963917 : ℝ) / 13463917))
    (lo := ((14343061 : ℝ) / 100000000)) (hi := ((7171531 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7213917 : ℝ) / 100000000) = Real.log ((7213917 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7213917 : ℝ) / 100000000) = ((7213917 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_195 : RB (Real.log ((8334693 : ℝ) / 100000000)) ((-124237177 : ℝ) / 50000000) ((-4969487 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((8334693 : ℝ) / 12500000)) (t := ((-4165307 : ℝ) / 20834693))
    (lo := ((-40530197 : ℝ) / 100000000)) (hi := ((-10132549 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8334693 : ℝ) / 100000000) = Real.log ((8334693 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8334693 : ℝ) / 100000000) = ((8334693 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_196 : RB (Real.log ((1542849 : ℝ) / 100000000)) ((-208576977 : ℝ) / 50000000) ((-417153947 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1542849 : ℝ) / 1562500)) (t := ((-19651 : ℝ) / 3105349))
    (lo := ((-31641 : ℝ) / 2500000)) (hi := ((-1265639 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1542849 : ℝ) / 100000000) = Real.log ((1542849 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1542849 : ℝ) / 100000000) = ((1542849 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_197 : RB (Real.log ((394027 : ℝ) / 25000000)) ((-415021173 : ℝ) / 100000000) ((-207510583 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((394027 : ℝ) / 390625)) (t := ((1701 : ℝ) / 392326))
    (lo := ((867141 : ℝ) / 100000000)) (hi := ((433571 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((394027 : ℝ) / 25000000) = Real.log ((394027 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((394027 : ℝ) / 25000000) = ((394027 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_198 : RB (Real.log ((77933427 : ℝ) / 100000000)) ((-24931523 : ℝ) / 100000000) ((-12465761 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((77933427 : ℝ) / 100000000)) (t := ((-22066573 : ℝ) / 177933427))
    (lo := ((-24931523 : ℝ) / 100000000)) (hi := ((-12465761 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_199 : RB (Real.log ((19483477 : ℝ) / 25000000)) ((-12465453 : ℝ) / 50000000) ((-4986181 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((19483477 : ℝ) / 25000000)) (t := ((-5516523 : ℝ) / 44483477))
    (lo := ((-12465453 : ℝ) / 50000000)) (hi := ((-4986181 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_200 : RB (Real.log ((21901479 : ℝ) / 50000000)) ((-16509377 : ℝ) / 20000000) ((-82546883 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((21901479 : ℝ) / 25000000)) (t := ((-3098521 : ℝ) / 46901479))
    (lo := ((-6616083 : ℝ) / 50000000)) (hi := ((-2646433 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21901479 : ℝ) / 50000000) = Real.log ((21901479 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21901479 : ℝ) / 50000000) = ((21901479 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_201 : RB (Real.log ((39354247 : ℝ) / 20000000)) ((33843581 : ℝ) / 50000000) ((16921791 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((39354247 : ℝ) / 40000000)) (t := ((-645753 : ℝ) / 79354247))
    (lo := ((-406889 : ℝ) / 25000000)) (hi := ((-325511 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39354247 : ℝ) / 20000000) = Real.log ((39354247 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39354247 : ℝ) / 20000000) = ((39354247 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_202 : RB (Real.log ((9841811 : ℝ) / 5000000)) ((33860091 : ℝ) / 50000000) ((8465023 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((9841811 : ℝ) / 10000000)) (t := ((-158189 : ℝ) / 19841811))
    (lo := ((-199317 : ℝ) / 12500000)) (hi := ((-318907 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9841811 : ℝ) / 5000000) = Real.log ((9841811 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((9841811 : ℝ) / 5000000) = ((9841811 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_203 : RB (Real.log ((3169729 : ℝ) / 4000000)) ((-23264827 : ℝ) / 100000000) ((-11632413 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3169729 : ℝ) / 4000000)) (t := ((-830271 : ℝ) / 7169729))
    (lo := ((-23264827 : ℝ) / 100000000)) (hi := ((-11632413 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_204 : RB (Real.log ((7924371 : ℝ) / 10000000)) ((-4652843 : ℝ) / 20000000) ((-11632107 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((7924371 : ℝ) / 10000000)) (t := ((-2075629 : ℝ) / 17924371))
    (lo := ((-4652843 : ℝ) / 20000000)) (hi := ((-11632107 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_205 : RB (Real.log ((44213611 : ℝ) / 100000000)) ((-10201719 : ℝ) / 12500000) ((-65291 : ℝ) / 80000) := by
  have hm := log_bounds_of_series (x := ((44213611 : ℝ) / 50000000)) (t := ((-5786389 : ℝ) / 94213611))
    (lo := ((-12299033 : ℝ) / 100000000)) (hi := ((-1537379 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44213611 : ℝ) / 100000000) = Real.log ((44213611 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44213611 : ℝ) / 100000000) = ((44213611 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_206 : RB (Real.log ((14611133 : ℝ) / 3125000)) ((38558737 : ℝ) / 25000000) ((154234951 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((14611133 : ℝ) / 12500000)) (t := ((2111133 : ℝ) / 27111133))
    (lo := ((1950689 : ℝ) / 12500000)) (hi := ((15605513 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14611133 : ℝ) / 3125000) = Real.log ((14611133 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((14611133 : ℝ) / 3125000) = ((14611133 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_207 : RB (Real.log ((467557249 : ℝ) / 100000000)) ((154235161 : ℝ) / 100000000) ((38558791 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((467557249 : ℝ) / 400000000)) (t := ((67557249 : ℝ) / 867557249))
    (lo := ((624229 : ℝ) / 4000000)) (hi := ((7802863 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((467557249 : ℝ) / 100000000) = Real.log ((467557249 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((467557249 : ℝ) / 100000000) = ((467557249 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_208 : RB (Real.log ((127204903 : ℝ) / 100000000)) ((240629 : ℝ) / 1000000) ((24062901 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127204903 : ℝ) / 100000000)) (t := ((27204903 : ℝ) / 227204903))
    (lo := ((240629 : ℝ) / 1000000)) (hi := ((24062901 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_209 : RB (Real.log ((116237201 : ℝ) / 25000000)) ((153675711 : ℝ) / 100000000) ((76837857 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((116237201 : ℝ) / 100000000)) (t := ((16237201 : ℝ) / 216237201))
    (lo := ((601851 : ℝ) / 4000000)) (hi := ((3761569 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((116237201 : ℝ) / 25000000) = Real.log ((116237201 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((116237201 : ℝ) / 25000000) = ((116237201 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_210 : RB (Real.log ((464949791 : ℝ) / 100000000)) ((153675923 : ℝ) / 100000000) ((76837963 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((464949791 : ℝ) / 400000000)) (t := ((64949791 : ℝ) / 864949791))
    (lo := ((15046487 : ℝ) / 100000000)) (hi := ((1880811 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((464949791 : ℝ) / 100000000) = Real.log ((464949791 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((464949791 : ℝ) / 100000000) = ((464949791 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_211 : RB (Real.log ((63699637 : ℝ) / 50000000)) ((4843117 : ℝ) / 20000000) ((12107793 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((63699637 : ℝ) / 50000000)) (t := ((13699637 : ℝ) / 113699637))
    (lo := ((4843117 : ℝ) / 20000000)) (hi := ((12107793 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_212 : RB (Real.log ((3611163 : ℝ) / 50000000)) ((-262799317 : ℝ) / 100000000) ((-16424957 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((3611163 : ℝ) / 3125000)) (t := ((486163 : ℝ) / 6736163))
    (lo := ((14459559 : ℝ) / 100000000)) (hi := ((361489 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3611163 : ℝ) / 50000000) = Real.log ((3611163 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((3611163 : ℝ) / 50000000) = ((3611163 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_213 : RB (Real.log ((2081901 : ℝ) / 25000000)) ((-49711889 : ℝ) / 20000000) ((-3106993 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((2081901 : ℝ) / 1562500)) (t := ((519401 : ℝ) / 3644401))
    (lo := ((28699431 : ℝ) / 100000000)) (hi := ((3587429 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2081901 : ℝ) / 25000000) = Real.log ((2081901 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((2081901 : ℝ) / 25000000) = ((2081901 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_214 : RB (Real.log ((1575063 : ℝ) / 100000000)) ((-207543749 : ℝ) / 50000000) ((-415087491 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1575063 : ℝ) / 1562500)) (t := ((12563 : ℝ) / 3137563))
    (lo := ((50051 : ℝ) / 6250000)) (hi := ((800817 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1575063 : ℝ) / 100000000) = Real.log ((1575063 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1575063 : ℝ) / 100000000) = ((1575063 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_215 : RB (Real.log ((321669 : ℝ) / 20000000)) ((-82599291 : ℝ) / 20000000) ((-12906139 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((321669 : ℝ) / 312500)) (t := ((9169 : ℝ) / 634169))
    (lo := ((2891859 : ℝ) / 100000000)) (hi := ((144593 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((321669 : ℝ) / 20000000) = Real.log ((321669 : ℝ) / 312500) - 6 * Real.log 2 := by
    rw [show ((321669 : ℝ) / 20000000) = ((321669 : ℝ) / 312500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_216 : RB (Real.log ((38840773 : ℝ) / 50000000)) ((-25255247 : ℝ) / 100000000) ((-12627623 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((38840773 : ℝ) / 50000000)) (t := ((-11159227 : ℝ) / 88840773))
    (lo := ((-25255247 : ℝ) / 100000000)) (hi := ((-12627623 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_217 : RB (Real.log ((38841019 : ℝ) / 50000000)) ((-25254613 : ℝ) / 100000000) ((-6313653 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((38841019 : ℝ) / 50000000)) (t := ((-11158981 : ℝ) / 88841019))
    (lo := ((-25254613 : ℝ) / 100000000)) (hi := ((-6313653 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_218 : RB (Real.log ((5465431 : ℝ) / 12500000)) ((-82728567 : ℝ) / 100000000) ((-16545713 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((5465431 : ℝ) / 6250000)) (t := ((-784569 : ℝ) / 11715431))
    (lo := ((-1676731 : ℝ) / 12500000)) (hi := ((-13413847 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5465431 : ℝ) / 12500000) = Real.log ((5465431 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5465431 : ℝ) / 12500000) = ((5465431 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_219 : RB (Real.log ((98353123 : ℝ) / 50000000)) ((67654129 : ℝ) / 100000000) ((67654131 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((98353123 : ℝ) / 100000000)) (t := ((-1646877 : ℝ) / 198353123))
    (lo := ((-1660589 : ℝ) / 100000000)) (hi := ((-415147 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98353123 : ℝ) / 50000000) = Real.log ((98353123 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98353123 : ℝ) / 50000000) = ((98353123 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_220 : RB (Real.log ((196771239 : ℝ) / 100000000)) ((16921791 : ℝ) / 25000000) ((33843583 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((196771239 : ℝ) / 200000000)) (t := ((-3228761 : ℝ) / 396771239))
    (lo := ((-813777 : ℝ) / 50000000)) (hi := ((-1627553 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196771239 : ℝ) / 100000000) = Real.log ((196771239 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196771239 : ℝ) / 100000000) = ((196771239 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_221 : RB (Real.log ((39483281 : ℝ) / 50000000)) ((-23614569 : ℝ) / 100000000) ((-2951821 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((39483281 : ℝ) / 50000000)) (t := ((-10516719 : ℝ) / 89483281))
    (lo := ((-23614569 : ℝ) / 100000000)) (hi := ((-2951821 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_222 : RB (Real.log ((78967057 : ℝ) / 100000000)) ((-23613943 : ℝ) / 100000000) ((-11806971 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((78967057 : ℝ) / 100000000)) (t := ((-21032943 : ℝ) / 178967057))
    (lo := ((-23613943 : ℝ) / 100000000)) (hi := ((-11806971 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_223 : RB (Real.log ((1765101 : ℝ) / 4000000)) ((-40904323 : ℝ) / 50000000) ((-20452161 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1765101 : ℝ) / 2000000)) (t := ((-234899 : ℝ) / 3765101))
    (lo := ((-12493927 : ℝ) / 100000000)) (hi := ((-6246963 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1765101 : ℝ) / 4000000) = Real.log ((1765101 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((1765101 : ℝ) / 4000000) = ((1765101 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_224 : RB (Real.log ((466679349 : ℝ) / 100000000)) ((154047221 : ℝ) / 100000000) ((19255903 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((466679349 : ℝ) / 400000000)) (t := ((66679349 : ℝ) / 866679349))
    (lo := ((3083557 : ℝ) / 20000000)) (hi := ((7708893 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((466679349 : ℝ) / 100000000) = Real.log ((466679349 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((466679349 : ℝ) / 100000000) = ((466679349 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_225 : RB (Real.log ((233340181 : ℝ) / 50000000)) ((77023719 : ℝ) / 50000000) ((154047441 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((233340181 : ℝ) / 200000000)) (t := ((33340181 : ℝ) / 433340181))
    (lo := ((7709001 : ℝ) / 50000000)) (hi := ((15418003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((233340181 : ℝ) / 50000000) = Real.log ((233340181 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((233340181 : ℝ) / 50000000) = ((233340181 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_226 : RB (Real.log ((497148 : ℝ) / 390625)) ((12056987 : ℝ) / 50000000) ((964559 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((497148 : ℝ) / 390625)) (t := ((106523 : ℝ) / 887773))
    (lo := ((12056987 : ℝ) / 50000000)) (hi := ((964559 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_227 : RB (Real.log ((232046021 : ℝ) / 50000000)) ((153491271 : ℝ) / 100000000) ((76745637 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((232046021 : ℝ) / 200000000)) (t := ((32046021 : ℝ) / 432046021))
    (lo := ((2972367 : ℝ) / 20000000)) (hi := ((3715459 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((232046021 : ℝ) / 50000000) = Real.log ((232046021 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((232046021 : ℝ) / 50000000) = ((232046021 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_228 : RB (Real.log ((58011631 : ℝ) / 12500000)) ((153491487 : ℝ) / 100000000) ((15349149 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((58011631 : ℝ) / 50000000)) (t := ((8011631 : ℝ) / 108011631))
    (lo := ((14862051 : ℝ) / 100000000)) (hi := ((3715513 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((58011631 : ℝ) / 12500000) = Real.log ((58011631 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((58011631 : ℝ) / 12500000) = ((58011631 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_229 : RB (Real.log ((127463673 : ℝ) / 100000000)) ((12133061 : ℝ) / 50000000) ((24266123 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((127463673 : ℝ) / 100000000)) (t := ((27463673 : ℝ) / 227463673))
    (lo := ((12133061 : ℝ) / 50000000)) (hi := ((24266123 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_230 : RB (Real.log ((7232827 : ℝ) / 100000000)) ((-131327013 : ℝ) / 50000000) ((-262654021 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7232827 : ℝ) / 6250000)) (t := ((982827 : ℝ) / 13482827))
    (lo := ((292097 : ℝ) / 2000000)) (hi := ((14604851 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7232827 : ℝ) / 100000000) = Real.log ((7232827 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7232827 : ℝ) / 100000000) = ((7232827 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_231 : RB (Real.log ((8322869 : ℝ) / 100000000)) ((-388463 : ℝ) / 156250) ((-49723263 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((8322869 : ℝ) / 6250000)) (t := ((2072869 : ℝ) / 14572869))
    (lo := ((7160639 : ℝ) / 25000000)) (hi := ((28642557 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8322869 : ℝ) / 100000000) = Real.log ((8322869 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8322869 : ℝ) / 100000000) = ((8322869 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_232 : RB (Real.log ((20091 : ℝ) / 1250000)) ((-206531347 : ℝ) / 50000000) ((-413062687 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((80364 : ℝ) / 78125)) (t := ((2239 : ℝ) / 158489))
    (lo := ((141281 : ℝ) / 5000000)) (hi := ((2825621 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20091 : ℝ) / 1250000) = Real.log ((80364 : ℝ) / 78125) - 6 * Real.log 2 := by
    rw [show ((20091 : ℝ) / 1250000) = ((80364 : ℝ) / 78125) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_233 : RB (Real.log ((1640583 : ℝ) / 100000000)) ((-205505929 : ℝ) / 50000000) ((-411011851 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1640583 : ℝ) / 1562500)) (t := ((78083 : ℝ) / 3203083))
    (lo := ((609557 : ℝ) / 12500000)) (hi := ((4876457 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1640583 : ℝ) / 100000000) = Real.log ((1640583 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1640583 : ℝ) / 100000000) = ((1640583 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_234 : RB (Real.log ((77434373 : ℝ) / 100000000)) ((-25573941 : ℝ) / 100000000) ((-1278697 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((77434373 : ℝ) / 100000000)) (t := ((-22565627 : ℝ) / 177434373))
    (lo := ((-25573941 : ℝ) / 100000000)) (hi := ((-1278697 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_235 : RB (Real.log ((619479 : ℝ) / 800000)) ((-25573293 : ℝ) / 100000000) ((-6393323 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((619479 : ℝ) / 800000)) (t := ((-180521 : ℝ) / 1419479))
    (lo := ((-25573293 : ℝ) / 100000000)) (hi := ((-6393323 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_236 : RB (Real.log ((43645211 : ℝ) / 100000000)) ((-5181729 : ℝ) / 6250000) ((-41453831 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((43645211 : ℝ) / 50000000)) (t := ((-6354789 : ℝ) / 93645211))
    (lo := ((-2718589 : ℝ) / 20000000)) (hi := ((-849559 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43645211 : ℝ) / 100000000) = Real.log ((43645211 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43645211 : ℝ) / 100000000) = ((43645211 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_237 : RB (Real.log ((49160311 : ℝ) / 25000000)) ((33810539 : ℝ) / 50000000) ((1690527 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((49160311 : ℝ) / 50000000)) (t := ((-839689 : ℝ) / 99160311))
    (lo := ((-42341 : ℝ) / 2500000)) (hi := ((-1693639 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((49160311 : ℝ) / 25000000) = Real.log ((49160311 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((49160311 : ℝ) / 25000000) = ((49160311 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_238 : RB (Real.log ((49176563 : ℝ) / 25000000)) ((16913533 : ℝ) / 25000000) ((33827067 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((49176563 : ℝ) / 50000000)) (t := ((-823437 : ℝ) / 99176563))
    (lo := ((-830293 : ℝ) / 50000000)) (hi := ((-332117 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((49176563 : ℝ) / 25000000) = Real.log ((49176563 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((49176563 : ℝ) / 25000000) = ((49176563 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_239 : RB (Real.log ((9836893 : ℝ) / 12500000)) ((-11979437 : ℝ) / 50000000) ((-23958873 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9836893 : ℝ) / 12500000)) (t := ((-2663107 : ℝ) / 22336893))
    (lo := ((-11979437 : ℝ) / 50000000)) (hi := ((-23958873 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
