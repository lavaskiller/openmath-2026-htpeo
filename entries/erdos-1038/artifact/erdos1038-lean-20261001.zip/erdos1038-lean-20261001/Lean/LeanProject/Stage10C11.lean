import LeanProject.Stage10C10

/-!
# EP-1038, Stage 10 Part (c), N6(i)–(ii): separation along the segment, sign patterns, continuity

* `WS_eq_LS`: `W_S(x) = k log x + L_S(x)` (real axis, Mathlib's even `log`);
* generic consequences of strict separation at `r` (`xp_lt_r`, `W_right_pos`, `W_left_pos`,
  `W_mid_pos_neg`, `W_mid_neg_neg`, zeros at `x±`);
* `root_cont`: a root with a strict sign change depends continuously on the parameter;
* `seg_sep`: `T_s` stays strictly separated at `r` for `0 ≤ s ≤ s₁`;
* `W_seg_cont`: `s ↦ W_{T_s}(x)` is continuous at `0`.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

theorem WS_eq_LS (k : ℝ) (S : ℝ → ℝ) (x : ℝ) : WS k S x = k * Real.log x + LS S x := by
  unfold WS LS
  rw [Real.log_abs]
  congr 1
  refine intervalIntegral.integral_congr fun u _ => ?_
  rw [abs_sub_comm, Real.log_abs]

section generic

variable {k a r : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
  (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k) (hr0 : 0 < r) (hra : r < a) (hsep : RS k S < PsiS k S r)
include hSm ha hSa hS2 hk hr0 hra hsep

theorem xp_lt_r : xpS k S < r := by
  have hr_abs : |r| < a := by rwa [abs_of_pos hr0]
  have hpr := phiv_pos hSm ha hSa hS2 hk hr_abs
  have hfix : RS k S * phiv (phiS k S) r ≤ r := by
    have h := hsep
    rw [PsiS_eq_div hSm ha hSa hS2 hk hr_abs, lt_div_iff₀ hpr] at h
    exact h.le
  obtain ⟨-, hle, hpΨ, -⟩ := series_package hSm ha hSa hS2 hk hr0 hra hfix
  rcases hle.lt_or_eq with h | h
  · exact h
  · rw [h] at hpΨ; linarith

theorem W_right_pos {y : ℝ} (h1 : xpS k S < y) (h2 : y ≤ r) : 0 < WS k S y := by
  obtain ⟨hp0, hpyc, hpΨ, -, -⟩ := sep_series hSm ha hSa hS2 hk hr0 hra hsep
  have hy0 : 0 < y := by linarith
  rw [WS_pos_iff hSm ha hSa hS2 hk (by linarith) (ne_of_gt hy0), abs_of_pos (PsiS_pos hSm ha hSa hS2 hy0)]
  rcases lt_or_ge y (yc k a S) with h | h
  · have := PsiS_strictMonoOn hSm ha hSa hS2 hk hpyc h h1
    linarith
  · have := (PsiS_strictAntiOn hSm ha hSa hS2 hk).antitoneOn ⟨h, by linarith⟩ ⟨h.trans h2, hra⟩ h2
    linarith

theorem W_left_pos {y : ℝ} (h : y < xmS k S) : 0 < WS k S y := by
  obtain ⟨-, -, -, hm0, hmΨ⟩ := sep_series hSm ha hSa hS2 hk hr0 hra hsep
  have hycpos := yc_pos hSm ha hSa hS2 hk
  have hR := RS_pos hSm ha hSa hS2 hk
  have hy0 : y < 0 := by linarith
  rw [WS_pos_iff hSm ha hSa hS2 hk (by linarith) hy0.ne]
  have := PsiS_strictMonoOn hSm ha hSa hS2 hk (show y ∈ Iio (yc k a S) by
    simp only [mem_Iio]; linarith) (show xmS k S ∈ Iio (yc k a S) by simp only [mem_Iio]; linarith) h
  rw [abs_of_neg (by linarith)]
  linarith

theorem W_mid_neg {y : ℝ} (h1 : xmS k S < y) (h2 : y < xpS k S) (hy0 : y ≠ 0) : WS k S y < 0 := by
  obtain ⟨hp0, hpyc, hpΨ, hm0, hmΨ⟩ := sep_series hSm ha hSa hS2 hk hr0 hra hsep
  have hmono : StrictMonoOn (PsiS k S) (Iic (xpS k S)) :=
    (PsiS_strictMonoOn hSm ha hSa hS2 hk).mono fun x hx => lt_of_le_of_lt hx hpyc
  have hxr := xp_lt_r hSm ha hSa hS2 hk hr0 hra hsep
  exact (main_component_series hSm ha hSa hS2 hk hp0 hpyc.le (by linarith) hpΨ hm0 hmΨ
    hmono).2.2 y h1 h2 hy0

theorem W_xp_zero : WS k S (xpS k S) = 0 := by
  obtain ⟨hp0, hpyc, hpΨ, hm0, hmΨ⟩ := sep_series hSm ha hSa hS2 hk hr0 hra hsep
  have hR := RS_pos hSm ha hSa hS2 hk
  have hxr := xp_lt_r hSm ha hSa hS2 hk hr0 hra hsep
  exact WS_zero_of_abs hSm ha hSa hS2 hk (by linarith) (ne_of_gt hp0) (by rw [hpΨ, abs_of_pos hR])

theorem W_xm_zero : WS k S (xmS k S) = 0 := by
  obtain ⟨hp0, hpyc, hpΨ, hm0, hmΨ⟩ := sep_series hSm ha hSa hS2 hk hr0 hra hsep
  have hR := RS_pos hSm ha hSa hS2 hk
  exact WS_zero_of_abs hSm ha hSa hS2 hk (by linarith) hm0.ne (by rw [hmΨ, abs_neg, abs_of_pos hR])

end generic

/-- A root with a strict sign change (negative before, positive after) depends continuously on
the parameter. -/
theorem root_cont {Ω : ℝ → ℝ → ℝ} {X : ℝ → ℝ} {lo hi s1 : ℝ} (hs1 : 0 < s1)
    (hin : ∀ s ∈ Icc (0 : ℝ) s1, lo < X s ∧ X s < hi)
    (hneg : ∀ s ∈ Icc (0 : ℝ) s1, ∀ y, lo < y → y < X s → Ω y s < 0)
    (hpos : ∀ s ∈ Icc (0 : ℝ) s1, ∀ y, X s < y → y ≤ hi → 0 < Ω y s)
    (hzero : ∀ s ∈ Icc (0 : ℝ) s1, Ω (X s) s = 0)
    (hc : ∀ y, lo < y → y ≤ hi → Tendsto (fun s => Ω y s) (𝓝[Ici 0] 0) (𝓝 (Ω y 0))) :
    Tendsto X (𝓝[Ici 0] 0) (𝓝 (X 0)) := by
  have hs0 : (0 : ℝ) ∈ Icc (0 : ℝ) s1 := ⟨le_rfl, hs1.le⟩
  obtain ⟨hlo, hhi⟩ := hin 0 hs0
  set x0 := X 0
  rw [Metric.tendsto_nhds]
  intro ε hε
  set e := min (ε / 2) (min ((x0 - lo) / 2) ((hi - x0) / 2)) with he
  have he0 : 0 < e := lt_min (by linarith) (lt_min (by linarith) (by linarith))
  have he1 : e ≤ ε / 2 := min_le_left _ _
  have he2 : e ≤ (x0 - lo) / 2 := (min_le_right _ _).trans (min_le_left _ _)
  have he3 : e ≤ (hi - x0) / 2 := (min_le_right _ _).trans (min_le_right _ _)
  have hA : Ω (x0 - e) 0 < 0 := hneg 0 hs0 _ (by linarith) (by linarith)
  have hB : 0 < Ω (x0 + e) 0 := hpos 0 hs0 _ (by linarith) (by linarith)
  have hcA := (hc (x0 - e) (by linarith) (by linarith)).eventually (gt_mem_nhds hA)
  have hcB := (hc (x0 + e) (by linarith) (by linarith)).eventually (lt_mem_nhds hB)
  have hsmall : ∀ᶠ s in 𝓝[Ici 0] (0 : ℝ), s ∈ Icc (0 : ℝ) s1 := by
    filter_upwards [self_mem_nhdsWithin, nhdsWithin_le_nhds (Iio_mem_nhds hs1)] with s h1 h2
    exact ⟨h1, (Set.mem_Iio.mp h2).le⟩
  filter_upwards [hcA, hcB, hsmall] with s h1 h2 hs
  rw [Real.dist_eq, abs_lt]
  obtain ⟨hl, hh⟩ := hin s hs
  constructor
  · by_contra hc'
    push Not at hc'
    rcases (show X s ≤ x0 - e by linarith).lt_or_eq with h | h
    · have := hpos s hs (x0 - e) h (by linarith); linarith
    · have := hzero s hs; rw [h] at this; linarith
  · by_contra hc'
    push Not at hc'
    rcases (show x0 + e ≤ X s by linarith).lt_or_eq with h | h
    · have := hneg s hs (x0 + e) (by linarith) h; linarith
    · have := hzero s hs; rw [← h] at this; linarith

section seg

variable {T0 T : ℝ → ℝ} {a0 a1 k r : ℝ} (hm0 : Measurable T0) (hm1 : Measurable T)
  (ha0 : 0 < a0) (h0a : ∀ u, a0 ≤ T0 u) (h02 : ∀ u, T0 u ≤ 2) (ha1 : 0 < a1) (h1a : ∀ u, a1 ≤ T u)
  (h12 : ∀ u, T u ≤ 2) (hk : 0 < k) (hr0 : 0 < r) (hra : r < a0)
include hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hra

theorem h1nn : ∀ u, 0 ≤ T u := fun u => by linarith [h1a u]

/-- `s ↦ W_{T_s}(x)` is continuous at `0` (from the right), for `x < (r + a₀)/2`. -/
theorem W_seg_cont {x : ℝ} (hx : x < (r + a0) / 2) :
    Tendsto (fun s => WS k (Seg T0 T s) x) (𝓝[Ici 0] 0) (𝓝 (WS k T0 x)) := by
  have hT1 := h1nn hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hra
  have ha' : 0 < (r + a0) / 2 := by linarith
  have ha'0 : (r + a0) / 2 < a0 := by linarith
  rw [Metric.tendsto_nhds]
  intro ε hε
  have hax : 0 < (r + a0) / 2 - x := by linarith
  have hsmall : ∀ᶠ s in 𝓝[Ici 0] (0 : ℝ), 0 ≤ s ∧ s < min ((a0 - (r + a0) / 2) / 2)
      (ε * ((r + a0) / 2 - x) / 4) := by
    filter_upwards [self_mem_nhdsWithin, nhdsWithin_le_nhds (Iio_mem_nhds
      (show (0 : ℝ) < min ((a0 - (r + a0) / 2) / 2) (ε * ((r + a0) / 2 - x) / 4) from
        lt_min (by linarith) (by positivity)))] with s h1 h2
    exact ⟨h1, h2⟩
  filter_upwards [hsmall] with s ⟨hs0, hs⟩
  have hsδ : s ≤ (a0 - (r + a0) / 2) / 2 := (lt_of_lt_of_le hs (min_le_left _ _)).le
  have hsε : s < ε * ((r + a0) / 2 - x) / 4 := lt_of_lt_of_le hs (min_le_right _ _)
  have hcl := LS_seg_close hm0 hm1 h0a h02 hT1 h12 ha' ha'0 hs0 hsδ hx
  rw [Real.dist_eq, WS_eq_LS, WS_eq_LS]
  calc |k * Real.log x + LS (Seg T0 T s) x - (k * Real.log x + LS T0 x)|
      = |LS (Seg T0 T s) x - LS T0 x| := by ring_nf
    _ ≤ 2 * s / ((r + a0) / 2 - x) := hcl
    _ < ε := by
        rw [div_lt_iff₀ hax]; nlinarith

/-- `T_s` stays strictly separated at `r` for small `s`. -/
theorem seg_sep (hsep : RS k T0 < PsiS k T0 r) :
    ∃ s1, 0 < s1 ∧ s1 ≤ (a0 - (r + a0) / 2) / 2 ∧ s1 ≤ 1 ∧
      ∀ s ∈ Icc (0 : ℝ) s1, RS k (Seg T0 T s) < PsiS k (Seg T0 T s) r := by
  have hT1 := h1nn hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hra
  have ha' : 0 < (r + a0) / 2 := by linarith
  have ha'0 : (r + a0) / 2 < a0 := by linarith
  have hW0 : 0 < WS k T0 r := by
    rw [WS_pos_iff hm0 ha0 h0a h02 hk hra hr0.ne', abs_of_pos (PsiS_pos hm0 ha0 h0a h02 hr0)]
    exact hsep
  have hrx : 0 < (r + a0) / 2 - r := by linarith
  set s1 := min (min ((a0 - (r + a0) / 2) / 2) 1) (WS k T0 r * ((r + a0) / 2 - r) / 4) with hs1
  have hs1pos : 0 < s1 := lt_min (lt_min (by linarith) one_pos) (by positivity)
  refine ⟨s1, hs1pos, (min_le_left _ _).trans (min_le_left _ _),
    (min_le_left _ _).trans (min_le_right _ _), fun s hs => ?_⟩
  have hsδ : s ≤ (a0 - (r + a0) / 2) / 2 := hs.2.trans ((min_le_left _ _).trans (min_le_left _ _))
  have hs1' : s ≤ 1 := hs.2.trans ((min_le_left _ _).trans (min_le_right _ _))
  have hsW : s ≤ WS k T0 r * ((r + a0) / 2 - r) / 4 := hs.2.trans (min_le_right _ _)
  have hSm := Seg_measurable hm0 hm1 s
  have hSa := Seg_lower h0a h02 hT1 h12 ha' ha'0 hs.1 hsδ
  have hS2 := Seg_upper h0a h02 hT1 h12 ha' ha'0 hs.1 hs1'
  have hcl := LS_seg_close hm0 hm1 h0a h02 hT1 h12 ha' ha'0 hs.1 hsδ (show r < (r + a0) / 2 by linarith)
  have hWs : 0 < WS k (Seg T0 T s) r := by
    rw [WS_eq_LS] at hW0 ⊢
    have h2 : 2 * s / ((r + a0) / 2 - r) ≤ WS k T0 r / 2 := by
      rw [div_le_iff₀ hrx]; nlinarith
    rw [WS_eq_LS] at h2
    have := (abs_le.mp hcl).1
    linarith
  rw [WS_pos_iff hSm ha' hSa hS2 hk (by linarith) hr0.ne',
    abs_of_pos (PsiS_pos hSm ha' hSa hS2 hr0)] at hWs
  exact hWs

end seg

end EP1038.Stage10
