import LeanProject.COVLogTwo
import LeanProject.COVLogBounds28
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2560 : RB (Real.log ((17 : ℝ) / 500)) ((-338139481 : ℝ) / 100000000) ((-13525579 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((136 : ℝ) / 125)) (t := ((11 : ℝ) / 261))
    (lo := ((4217057 : ℝ) / 50000000)) (hi := ((1686823 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17 : ℝ) / 500) = Real.log ((136 : ℝ) / 125) - 5 * Real.log 2 := by
    rw [show ((17 : ℝ) / 500) = ((136 : ℝ) / 125) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2561 : RB (Real.log ((74556751 : ℝ) / 100000000)) ((-91753 : ℝ) / 312500) ((-29360959 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74556751 : ℝ) / 100000000)) (t := ((-25443249 : ℝ) / 174556751))
    (lo := ((-91753 : ℝ) / 312500)) (hi := ((-29360959 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2562 : RB (Real.log ((74607097 : ℝ) / 100000000)) ((-5858691 : ℝ) / 20000000) ((-14646727 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((74607097 : ℝ) / 100000000)) (t := ((-25392903 : ℝ) / 174607097))
    (lo := ((-5858691 : ℝ) / 20000000)) (hi := ((-14646727 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2563 : RB (Real.log ((8558953 : ℝ) / 20000000)) ((-42437721 : ℝ) / 50000000) ((-1060943 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((8558953 : ℝ) / 10000000)) (t := ((-1441047 : ℝ) / 18558953))
    (lo := ((-15560723 : ℝ) / 100000000)) (hi := ((-7780361 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8558953 : ℝ) / 20000000) = Real.log ((8558953 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8558953 : ℝ) / 20000000) = ((8558953 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2564 : RB (Real.log ((11601531 : ℝ) / 6250000)) ((1546389 : ℝ) / 2500000) ((30927781 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((11601531 : ℝ) / 12500000)) (t := ((-898469 : ℝ) / 24101531))
    (lo := ((-3729579 : ℝ) / 50000000)) (hi := ((-7459157 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11601531 : ℝ) / 6250000) = Real.log ((11601531 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((11601531 : ℝ) / 6250000) = ((11601531 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2565 : RB (Real.log ((187063441 : ℝ) / 100000000)) ((31313881 : ℝ) / 50000000) ((15656941 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((187063441 : ℝ) / 200000000)) (t := ((-12936559 : ℝ) / 387063441))
    (lo := ((-1671739 : ℝ) / 25000000)) (hi := ((-1337391 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((187063441 : ℝ) / 100000000) = Real.log ((187063441 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((187063441 : ℝ) / 100000000) = ((187063441 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2566 : RB (Real.log ((41054833 : ℝ) / 50000000)) ((-3942289 : ℝ) / 20000000) ((-4927861 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((41054833 : ℝ) / 50000000)) (t := ((-8945167 : ℝ) / 91054833))
    (lo := ((-3942289 : ℝ) / 20000000)) (hi := ((-4927861 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2567 : RB (Real.log ((82162191 : ℝ) / 100000000)) ((-2455937 : ℝ) / 12500000) ((-3929499 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((82162191 : ℝ) / 100000000)) (t := ((-17837809 : ℝ) / 182162191))
    (lo := ((-2455937 : ℝ) / 12500000)) (hi := ((-3929499 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2568 : RB (Real.log ((22583663 : ℝ) / 50000000)) ((-635837 : ℝ) / 800000) ((-79479623 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22583663 : ℝ) / 25000000)) (t := ((-2416337 : ℝ) / 47583663))
    (lo := ((-5082453 : ℝ) / 50000000)) (hi := ((-2032981 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22583663 : ℝ) / 50000000) = Real.log ((22583663 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22583663 : ℝ) / 50000000) = ((22583663 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2569 : RB (Real.log ((33665399 : ℝ) / 10000000)) ((121388547 : ℝ) / 100000000) ((2427771 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((33665399 : ℝ) / 40000000)) (t := ((-6334601 : ℝ) / 73665399))
    (lo := ((-17240889 : ℝ) / 100000000)) (hi := ((-2155111 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33665399 : ℝ) / 10000000) = Real.log ((33665399 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((33665399 : ℝ) / 10000000) = ((33665399 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2570 : RB (Real.log ((168361123 : ℝ) / 50000000)) ((6070441 : ℝ) / 5000000) ((121408823 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((168361123 : ℝ) / 200000000)) (t := ((-31638877 : ℝ) / 368361123))
    (lo := ((-2152577 : ℝ) / 12500000)) (hi := ((-3444123 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((168361123 : ℝ) / 50000000) = Real.log ((168361123 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((168361123 : ℝ) / 50000000) = ((168361123 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2571 : RB (Real.log ((142194767 : ℝ) / 100000000)) ((550043 : ℝ) / 1562500) ((17601377 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((142194767 : ℝ) / 200000000)) (t := ((-57805233 : ℝ) / 342194767))
    (lo := ((-17055983 : ℝ) / 50000000)) (hi := ((-6822393 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142194767 : ℝ) / 100000000) = Real.log ((142194767 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((142194767 : ℝ) / 100000000) = ((142194767 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2572 : RB (Real.log ((165042299 : ℝ) / 50000000)) ((119417879 : ℝ) / 100000000) ((59708941 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((165042299 : ℝ) / 200000000)) (t := ((-34957701 : ℝ) / 365042299))
    (lo := ((-19211557 : ℝ) / 100000000)) (hi := ((-4802889 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((165042299 : ℝ) / 50000000) = Real.log ((165042299 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((165042299 : ℝ) / 50000000) = ((165042299 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2573 : RB (Real.log ((4126887 : ℝ) / 1250000)) ((119437981 : ℝ) / 100000000) ((3732437 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((4126887 : ℝ) / 5000000)) (t := ((-873113 : ℝ) / 9126887))
    (lo := ((-3838291 : ℝ) / 20000000)) (hi := ((-9595727 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4126887 : ℝ) / 1250000) = Real.log ((4126887 : ℝ) / 5000000) + 2 * Real.log 2 := by
    rw [show ((4126887 : ℝ) / 1250000) = ((4126887 : ℝ) / 5000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2574 : RB (Real.log ((28679903 : ℝ) / 20000000)) ((7209287 : ℝ) / 20000000) ((36046437 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((28679903 : ℝ) / 40000000)) (t := ((-11320097 : ℝ) / 68679903))
    (lo := ((-33268283 : ℝ) / 100000000)) (hi := ((-16634141 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28679903 : ℝ) / 20000000) = Real.log ((28679903 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((28679903 : ℝ) / 20000000) = ((28679903 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2575 : RB (Real.log ((71221879 : ℝ) / 100000000)) ((-33937013 : ℝ) / 100000000) ((-8484253 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((71221879 : ℝ) / 100000000)) (t := ((-28778121 : ℝ) / 171221879))
    (lo := ((-33937013 : ℝ) / 100000000)) (hi := ((-8484253 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2576 : RB (Real.log ((90450657 : ℝ) / 100000000)) ((-2509143 : ℝ) / 25000000) ((-10036571 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((90450657 : ℝ) / 100000000)) (t := ((-9549343 : ℝ) / 190450657))
    (lo := ((-2509143 : ℝ) / 25000000)) (hi := ((-10036571 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2577 : RB (Real.log ((19 : ℝ) / 500)) ((-327016917 : ℝ) / 100000000) ((-327016911 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((152 : ℝ) / 125)) (t := ((27 : ℝ) / 277))
    (lo := ((9778339 : ℝ) / 50000000)) (hi := ((19556679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19 : ℝ) / 500) = Real.log ((152 : ℝ) / 125) - 5 * Real.log 2 := by
    rw [show ((19 : ℝ) / 500) = ((152 : ℝ) / 125) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2578 : RB (Real.log ((74469907 : ℝ) / 100000000)) ((-7369377 : ℝ) / 25000000) ((-29477507 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74469907 : ℝ) / 100000000)) (t := ((-25530093 : ℝ) / 174469907))
    (lo := ((-7369377 : ℝ) / 25000000)) (hi := ((-29477507 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2579 : RB (Real.log ((74497169 : ℝ) / 100000000)) ((-29440907 : ℝ) / 100000000) ((-14720453 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((74497169 : ℝ) / 100000000)) (t := ((-25502831 : ℝ) / 174497169))
    (lo := ((-29440907 : ℝ) / 100000000)) (hi := ((-14720453 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2580 : RB (Real.log ((668363 : ℝ) / 1562500)) ((-10615137 : ℝ) / 12500000) ((-42460547 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((668363 : ℝ) / 781250)) (t := ((-112887 : ℝ) / 1449613))
    (lo := ((-15606377 : ℝ) / 100000000)) (hi := ((-1950797 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((668363 : ℝ) / 1562500) = Real.log ((668363 : ℝ) / 781250) - 1 * Real.log 2 := by
    rw [show ((668363 : ℝ) / 1562500) = ((668363 : ℝ) / 781250) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2581 : RB (Real.log ((92455621 : ℝ) / 50000000)) ((2458823 : ℝ) / 4000000) ((61470577 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((92455621 : ℝ) / 100000000)) (t := ((-7544379 : ℝ) / 192455621))
    (lo := ((-7844143 : ℝ) / 100000000)) (hi := ((-3922071 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92455621 : ℝ) / 50000000) = Real.log ((92455621 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((92455621 : ℝ) / 50000000) = ((92455621 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2582 : RB (Real.log ((185624497 : ℝ) / 100000000)) ((61855561 : ℝ) / 100000000) ((61855563 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((185624497 : ℝ) / 200000000)) (t := ((-14375503 : ℝ) / 385624497))
    (lo := ((-7459157 : ℝ) / 100000000)) (hi := ((-1864789 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((185624497 : ℝ) / 100000000) = Real.log ((185624497 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((185624497 : ℝ) / 100000000) = ((185624497 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2583 : RB (Real.log ((7825647 : ℝ) / 10000000)) ((-6129467 : ℝ) / 25000000) ((-24517867 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7825647 : ℝ) / 10000000)) (t := ((-2174353 : ℝ) / 17825647))
    (lo := ((-6129467 : ℝ) / 25000000)) (hi := ((-24517867 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2584 : RB (Real.log ((19571081 : ℝ) / 25000000)) ((-24482281 : ℝ) / 100000000) ((-612057 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((19571081 : ℝ) / 25000000)) (t := ((-5428919 : ℝ) / 44571081))
    (lo := ((-24482281 : ℝ) / 100000000)) (hi := ((-612057 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2585 : RB (Real.log ((43990813 : ℝ) / 100000000)) ((-41059469 : ℝ) / 50000000) ((-10264867 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((43990813 : ℝ) / 50000000)) (t := ((-6009187 : ℝ) / 93990813))
    (lo := ((-12804219 : ℝ) / 100000000)) (hi := ((-6402109 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43990813 : ℝ) / 100000000) = Real.log ((43990813 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43990813 : ℝ) / 100000000) = ((43990813 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2586 : RB (Real.log ((334077863 : ℝ) / 100000000)) ((12062039 : ℝ) / 10000000) ((120620393 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((334077863 : ℝ) / 400000000)) (t := ((-65922137 : ℝ) / 734077863))
    (lo := ((-9004523 : ℝ) / 50000000)) (hi := ((-3601809 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((334077863 : ℝ) / 100000000) = Real.log ((334077863 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((334077863 : ℝ) / 100000000) = ((334077863 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2587 : RB (Real.log ((334114439 : ℝ) / 100000000)) ((120631337 : ℝ) / 100000000) ((6031567 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((334114439 : ℝ) / 400000000)) (t := ((-65885561 : ℝ) / 734114439))
    (lo := ((-17998099 : ℝ) / 100000000)) (hi := ((-8999049 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((334114439 : ℝ) / 100000000) = Real.log ((334114439 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((334114439 : ℝ) / 100000000) = ((334114439 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2588 : RB (Real.log ((71326237 : ℝ) / 50000000)) ((35524123 : ℝ) / 100000000) ((284193 : ℝ) / 800000) := by
  have hm := log_bounds_of_series (x := ((71326237 : ℝ) / 100000000)) (t := ((-28673763 : ℝ) / 171326237))
    (lo := ((-6758119 : ℝ) / 20000000)) (hi := ((-16895297 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71326237 : ℝ) / 50000000) = Real.log ((71326237 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((71326237 : ℝ) / 50000000) = ((71326237 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2589 : RB (Real.log ((165666523 : ℝ) / 50000000)) ((59897693 : ℝ) / 50000000) ((119795389 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((165666523 : ℝ) / 200000000)) (t := ((-34333477 : ℝ) / 365666523))
    (lo := ((-376681 : ℝ) / 2000000)) (hi := ((-18834049 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((165666523 : ℝ) / 50000000) = Real.log ((165666523 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((165666523 : ℝ) / 50000000) = ((165666523 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2590 : RB (Real.log ((331369193 : ℝ) / 100000000)) ((23961259 : ℝ) / 20000000) ((59903149 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((331369193 : ℝ) / 400000000)) (t := ((-68630807 : ℝ) / 731369193))
    (lo := ((-18823141 : ℝ) / 100000000)) (hi := ((-941157 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((331369193 : ℝ) / 100000000) = Real.log ((331369193 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((331369193 : ℝ) / 100000000) = ((331369193 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2591 : RB (Real.log ((28631711 : ℝ) / 20000000)) ((1793913 : ℝ) / 5000000) ((17939131 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((28631711 : ℝ) / 40000000)) (t := ((-11368289 : ℝ) / 68631711))
    (lo := ((-16718229 : ℝ) / 50000000)) (hi := ((-33436457 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28631711 : ℝ) / 20000000) = Real.log ((28631711 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((28631711 : ℝ) / 20000000) = ((28631711 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2592 : RB (Real.log ((35319251 : ℝ) / 50000000)) ((-8689871 : ℝ) / 25000000) ((-34759483 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35319251 : ℝ) / 50000000)) (t := ((-14680749 : ℝ) / 85319251))
    (lo := ((-8689871 : ℝ) / 25000000)) (hi := ((-34759483 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2593 : RB (Real.log ((3190377 : ℝ) / 4000000)) ((-22615527 : ℝ) / 100000000) ((-11307763 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3190377 : ℝ) / 4000000)) (t := ((-809623 : ℝ) / 7190377))
    (lo := ((-22615527 : ℝ) / 100000000)) (hi := ((-11307763 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2594 : RB (Real.log ((1 : ℝ) / 25)) ((-80471897 : ℝ) / 25000000) ((-160943791 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((32 : ℝ) / 25)) (t := ((7 : ℝ) / 57))
    (lo := ((24686007 : ℝ) / 100000000)) (hi := ((3085751 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 25) = Real.log ((32 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((1 : ℝ) / 25) = ((32 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2595 : RB (Real.log ((73175109 : ℝ) / 100000000)) ((-31231487 : ℝ) / 100000000) ((-15615743 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((73175109 : ℝ) / 100000000)) (t := ((-26824891 : ℝ) / 173175109))
    (lo := ((-31231487 : ℝ) / 100000000)) (hi := ((-15615743 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2596 : RB (Real.log ((1830089 : ℝ) / 2500000)) ((-15596307 : ℝ) / 50000000) ((-31192613 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1830089 : ℝ) / 2500000)) (t := ((-669911 : ℝ) / 4330089))
    (lo := ((-15596307 : ℝ) / 50000000)) (hi := ((-31192613 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2597 : RB (Real.log ((42356843 : ℝ) / 100000000)) ((-85904021 : ℝ) / 100000000) ((-85904019 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42356843 : ℝ) / 50000000)) (t := ((-7643157 : ℝ) / 92356843))
    (lo := ((-8294651 : ℝ) / 50000000)) (hi := ((-16589301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42356843 : ℝ) / 100000000) = Real.log ((42356843 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42356843 : ℝ) / 100000000) = ((42356843 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2598 : RB (Real.log ((184202091 : ℝ) / 100000000)) ((7635791 : ℝ) / 12500000) ((6108633 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((184202091 : ℝ) / 200000000)) (t := ((-15797909 : ℝ) / 384202091))
    (lo := ((-822839 : ℝ) / 10000000)) (hi := ((-8228389 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((184202091 : ℝ) / 100000000) = Real.log ((184202091 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((184202091 : ℝ) / 100000000) = ((184202091 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2599 : RB (Real.log ((184911243 : ℝ) / 100000000)) ((2458823 : ℝ) / 4000000) ((61470577 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((184911243 : ℝ) / 200000000)) (t := ((-15088757 : ℝ) / 384911243))
    (lo := ((-7844143 : ℝ) / 100000000)) (hi := ((-3922071 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((184911243 : ℝ) / 100000000) = Real.log ((184911243 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((184911243 : ℝ) / 100000000) = ((184911243 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2600 : RB (Real.log ((76967777 : ℝ) / 100000000)) ((-13089167 : ℝ) / 50000000) ((-26178333 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76967777 : ℝ) / 100000000)) (t := ((-23032223 : ℝ) / 176967777))
    (lo := ((-13089167 : ℝ) / 50000000)) (hi := ((-26178333 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2601 : RB (Real.log ((19249213 : ℝ) / 25000000)) ((-5228113 : ℝ) / 20000000) ((-6535141 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((19249213 : ℝ) / 25000000)) (t := ((-5750787 : ℝ) / 44249213))
    (lo := ((-5228113 : ℝ) / 20000000)) (hi := ((-6535141 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2602 : RB (Real.log ((43592217 : ℝ) / 100000000)) ((-41514579 : ℝ) / 50000000) ((-20757289 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((43592217 : ℝ) / 50000000)) (t := ((-6407783 : ℝ) / 93592217))
    (lo := ((-13714439 : ℝ) / 100000000)) (hi := ((-6857219 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43592217 : ℝ) / 100000000) = Real.log ((43592217 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43592217 : ℝ) / 100000000) = ((43592217 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2603 : RB (Real.log ((3336907 : ℝ) / 1000000)) ((7531527 : ℝ) / 6250000) ((24100887 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3336907 : ℝ) / 4000000)) (t := ((-663093 : ℝ) / 7336907))
    (lo := ((-4531251 : ℝ) / 25000000)) (hi := ((-18125003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3336907 : ℝ) / 1000000) = Real.log ((3336907 : ℝ) / 4000000) + 2 * Real.log 2 := by
    rw [show ((3336907 : ℝ) / 1000000) = ((3336907 : ℝ) / 4000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2604 : RB (Real.log ((166864547 : ℝ) / 50000000)) ((60257969 : ℝ) / 50000000) ((120515941 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((166864547 : ℝ) / 200000000)) (t := ((-33135453 : ℝ) / 366864547))
    (lo := ((-9056749 : ℝ) / 50000000)) (hi := ((-18113497 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((166864547 : ℝ) / 50000000) = Real.log ((166864547 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((166864547 : ℝ) / 50000000) = ((166864547 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2605 : RB (Real.log ((3567903 : ℝ) / 2500000)) ((35568729 : ℝ) / 100000000) ((35568731 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3567903 : ℝ) / 5000000)) (t := ((-1432097 : ℝ) / 8567903))
    (lo := ((-33745989 : ℝ) / 100000000)) (hi := ((-8436497 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3567903 : ℝ) / 2500000) = Real.log ((3567903 : ℝ) / 5000000) + 1 * Real.log 2 := by
    rw [show ((3567903 : ℝ) / 2500000) = ((3567903 : ℝ) / 5000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2606 : RB (Real.log ((330773217 : ℝ) / 100000000)) ((2990657 : ℝ) / 2500000) ((119626283 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((330773217 : ℝ) / 400000000)) (t := ((-69226783 : ℝ) / 730773217))
    (lo := ((-4750789 : ℝ) / 25000000)) (hi := ((-3800631 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((330773217 : ℝ) / 100000000) = Real.log ((330773217 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((330773217 : ℝ) / 100000000) = ((330773217 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2607 : RB (Real.log ((82702783 : ℝ) / 25000000)) ((59818871 : ℝ) / 50000000) ((23927549 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((82702783 : ℝ) / 100000000)) (t := ((-17297217 : ℝ) / 182702783))
    (lo := ((-9495847 : ℝ) / 50000000)) (hi := ((-18991693 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((82702783 : ℝ) / 25000000) = Real.log ((82702783 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((82702783 : ℝ) / 25000000) = ((82702783 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2608 : RB (Real.log ((71628073 : ℝ) / 50000000)) ((35946407 : ℝ) / 100000000) ((35946409 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((71628073 : ℝ) / 100000000)) (t := ((-28371927 : ℝ) / 171628073))
    (lo := ((-33368311 : ℝ) / 100000000)) (hi := ((-3336831 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71628073 : ℝ) / 50000000) = Real.log ((71628073 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((71628073 : ℝ) / 50000000) = ((71628073 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2609 : RB (Real.log ((67452133 : ℝ) / 100000000)) ((-39375199 : ℝ) / 100000000) ((-19687599 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((67452133 : ℝ) / 100000000)) (t := ((-32547867 : ℝ) / 167452133))
    (lo := ((-39375199 : ℝ) / 100000000)) (hi := ((-19687599 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2610 : RB (Real.log ((15259787 : ℝ) / 20000000)) ((-27051121 : ℝ) / 100000000) ((-338139 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((15259787 : ℝ) / 20000000)) (t := ((-4740213 : ℝ) / 35259787))
    (lo := ((-27051121 : ℝ) / 100000000)) (hi := ((-338139 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2611 : RB (Real.log ((21 : ℝ) / 500)) ((-31700857 : ℝ) / 10000000) ((-63401713 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((84 : ℝ) / 125)) (t := ((-41 : ℝ) / 209))
    (lo := ((-19874847 : ℝ) / 50000000)) (hi := ((-39749693 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21 : ℝ) / 500) = Real.log ((84 : ℝ) / 125) - 4 * Real.log 2 := by
    rw [show ((21 : ℝ) / 500) = ((84 : ℝ) / 125) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2612 : RB (Real.log ((50833333 : ℝ) / 50000000)) ((1652929 : ℝ) / 100000000) ((165293 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((50833333 : ℝ) / 50000000)) (t := ((833333 : ℝ) / 100833333))
    (lo := ((1652929 : ℝ) / 100000000)) (hi := ((165293 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2613 : RB (Real.log ((6283 : ℝ) / 3200)) ((16867419 : ℝ) / 25000000) ((33734839 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6283 : ℝ) / 6400)) (t := ((-117 : ℝ) / 12683))
    (lo := ((-922521 : ℝ) / 50000000)) (hi := ((-1845041 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6283 : ℝ) / 3200) = Real.log ((6283 : ℝ) / 6400) + 1 * Real.log 2 := by
    rw [show ((6283 : ℝ) / 3200) = ((6283 : ℝ) / 6400) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2614 : RB (Real.log ((101996753 : ℝ) / 100000000)) ((1977079 : ℝ) / 100000000) ((49427 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((101996753 : ℝ) / 100000000)) (t := ((1996753 : ℝ) / 201996753))
    (lo := ((1977079 : ℝ) / 100000000)) (hi := ((49427 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2615 : RB (Real.log ((10232899 : ℝ) / 10000000)) ((1151141 : ℝ) / 50000000) ((2302283 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10232899 : ℝ) / 10000000)) (t := ((232899 : ℝ) / 20232899))
    (lo := ((1151141 : ℝ) / 50000000)) (hi := ((2302283 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2616 : RB (Real.log ((195124223 : ℝ) / 100000000)) ((66846621 : ℝ) / 100000000) ((66846623 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((195124223 : ℝ) / 200000000)) (t := ((-4875777 : ℝ) / 395124223))
    (lo := ((-2468097 : ℝ) / 100000000)) (hi := ((-9641 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195124223 : ℝ) / 100000000) = Real.log ((195124223 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195124223 : ℝ) / 100000000) = ((195124223 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2617 : RB (Real.log ((51331699 : ℝ) / 50000000)) ((2628547 : ℝ) / 100000000) ((657137 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((51331699 : ℝ) / 50000000)) (t := ((1331699 : ℝ) / 101331699))
    (lo := ((2628547 : ℝ) / 100000000)) (hi := ((657137 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2618 : RB (Real.log ((103 : ℝ) / 100)) ((73897 : ℝ) / 2500000) ((2955881 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((103 : ℝ) / 100)) (t := ((3 : ℝ) / 203))
    (lo := ((73897 : ℝ) / 2500000)) (hi := ((2955881 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2619 : RB (Real.log ((193919753 : ℝ) / 100000000)) ((2069607 : ℝ) / 3125000) ((33113713 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((193919753 : ℝ) / 200000000)) (t := ((-6080247 : ℝ) / 393919753))
    (lo := ((-1543647 : ℝ) / 50000000)) (hi := ((-3087293 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((193919753 : ℝ) / 100000000) = Real.log ((193919753 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((193919753 : ℝ) / 100000000) = ((193919753 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2620 : RB (Real.log ((20667763 : ℝ) / 20000000)) ((1642143 : ℝ) / 50000000) ((3284287 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20667763 : ℝ) / 20000000)) (t := ((667763 : ℝ) / 40667763))
    (lo := ((1642143 : ℝ) / 50000000)) (hi := ((3284287 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2621 : RB (Real.log ((103679867 : ℝ) / 100000000)) ((225861 : ℝ) / 6250000) ((3613777 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((103679867 : ℝ) / 100000000)) (t := ((3679867 : ℝ) / 203679867))
    (lo := ((225861 : ℝ) / 6250000)) (hi := ((3613777 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2622 : RB (Real.log ((52011589 : ℝ) / 50000000)) ((788871 : ℝ) / 20000000) ((986089 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((52011589 : ℝ) / 50000000)) (t := ((2011589 : ℝ) / 102011589))
    (lo := ((788871 : ℝ) / 20000000)) (hi := ((986089 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2623 : RB (Real.log ((192730061 : ℝ) / 100000000)) ((65612037 : ℝ) / 100000000) ((65612039 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((192730061 : ℝ) / 200000000)) (t := ((-7269939 : ℝ) / 392730061))
    (lo := ((-3702681 : ℝ) / 100000000)) (hi := ((-92567 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192730061 : ℝ) / 100000000) = Real.log ((192730061 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((192730061 : ℝ) / 100000000) = ((192730061 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2624 : RB (Real.log ((10436877 : ℝ) / 10000000)) ((427603 : ℝ) / 10000000) ((4276031 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10436877 : ℝ) / 10000000)) (t := ((436877 : ℝ) / 20436877))
    (lo := ((427603 : ℝ) / 10000000)) (hi := ((4276031 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2625 : RB (Real.log ((52358333 : ℝ) / 50000000)) ((4608809 : ℝ) / 100000000) ((460881 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((52358333 : ℝ) / 50000000)) (t := ((2358333 : ℝ) / 102358333))
    (lo := ((4608809 : ℝ) / 100000000)) (hi := ((460881 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2626 : RB (Real.log ((105066889 : ℝ) / 100000000)) ((4942699 : ℝ) / 100000000) ((49427 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((105066889 : ℝ) / 100000000)) (t := ((5066889 : ℝ) / 205066889))
    (lo := ((4942699 : ℝ) / 100000000)) (hi := ((49427 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2627 : RB (Real.log ((95777439 : ℝ) / 50000000)) ((13000083 : ℝ) / 20000000) ((65000417 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((95777439 : ℝ) / 100000000)) (t := ((-4222561 : ℝ) / 195777439))
    (lo := ((-4314303 : ℝ) / 100000000)) (hi := ((-2157151 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95777439 : ℝ) / 50000000) = Real.log ((95777439 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95777439 : ℝ) / 50000000) = ((95777439 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2628 : RB (Real.log ((105419463 : ℝ) / 100000000)) ((5277709 : ℝ) / 100000000) ((527771 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((105419463 : ℝ) / 100000000)) (t := ((5419463 : ℝ) / 205419463))
    (lo := ((5277709 : ℝ) / 100000000)) (hi := ((527771 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2629 : RB (Real.log ((10577441 : ℝ) / 10000000)) ((5613843 : ℝ) / 100000000) ((1403461 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((10577441 : ℝ) / 10000000)) (t := ((577441 : ℝ) / 20577441))
    (lo := ((5613843 : ℝ) / 100000000)) (hi := ((1403461 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2630 : RB (Real.log ((26532939 : ℝ) / 25000000)) ((5951111 : ℝ) / 100000000) ((743889 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((26532939 : ℝ) / 25000000)) (t := ((1532939 : ℝ) / 51532939))
    (lo := ((5951111 : ℝ) / 100000000)) (hi := ((743889 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2631 : RB (Real.log ((190393939 : ℝ) / 100000000)) ((6439251 : ℝ) / 10000000) ((1006133 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((190393939 : ℝ) / 200000000)) (t := ((-9606061 : ℝ) / 390393939))
    (lo := ((-153819 : ℝ) / 3125000)) (hi := ((-4922207 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((190393939 : ℝ) / 100000000) = Real.log ((190393939 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((190393939 : ℝ) / 100000000) = ((190393939 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2632 : RB (Real.log ((4259661 : ℝ) / 4000000)) ((6289521 : ℝ) / 100000000) ((3144761 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4259661 : ℝ) / 4000000)) (t := ((259661 : ℝ) / 8259661))
    (lo := ((6289521 : ℝ) / 100000000)) (hi := ((3144761 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2633 : RB (Real.log ((106853741 : ℝ) / 100000000)) ((165727 : ℝ) / 2500000) ((6629081 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((106853741 : ℝ) / 100000000)) (t := ((6853741 : ℝ) / 206853741))
    (lo := ((165727 : ℝ) / 2500000)) (hi := ((6629081 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2634 : RB (Real.log ((10721843 : ℝ) / 10000000)) ((1742449 : ℝ) / 25000000) ((6969797 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10721843 : ℝ) / 10000000)) (t := ((721843 : ℝ) / 20721843))
    (lo := ((1742449 : ℝ) / 25000000)) (hi := ((6969797 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2635 : RB (Real.log ((189246987 : ℝ) / 100000000)) ((31894139 : ℝ) / 50000000) ((1594707 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((189246987 : ℝ) / 200000000)) (t := ((-10753013 : ℝ) / 389246987))
    (lo := ((-138161 : ℝ) / 2500000)) (hi := ((-5526439 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189246987 : ℝ) / 100000000) = Real.log ((189246987 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189246987 : ℝ) / 100000000) = ((189246987 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2636 : RB (Real.log ((6724101 : ℝ) / 6250000)) ((7311677 : ℝ) / 100000000) ((3655839 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6724101 : ℝ) / 6250000)) (t := ((474101 : ℝ) / 12974101))
    (lo := ((7311677 : ℝ) / 100000000)) (hi := ((3655839 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2637 : RB (Real.log ((53977663 : ℝ) / 50000000)) ((765473 : ℝ) / 10000000) ((7654731 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((53977663 : ℝ) / 50000000)) (t := ((3977663 : ℝ) / 103977663))
    (lo := ((765473 : ℝ) / 10000000)) (hi := ((7654731 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2638 : RB (Real.log ((47028443 : ℝ) / 25000000)) ((15796919 : ℝ) / 25000000) ((31593839 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((47028443 : ℝ) / 50000000)) (t := ((-2971557 : ℝ) / 97028443))
    (lo := ((-3063521 : ℝ) / 50000000)) (hi := ((-6127041 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47028443 : ℝ) / 25000000) = Real.log ((47028443 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((47028443 : ℝ) / 25000000) = ((47028443 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2639 : RB (Real.log ((54163793 : ℝ) / 50000000)) ((1599793 : ℝ) / 20000000) ((3999483 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((54163793 : ℝ) / 50000000)) (t := ((4163793 : ℝ) / 104163793))
    (lo := ((1599793 : ℝ) / 20000000)) (hi := ((3999483 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
