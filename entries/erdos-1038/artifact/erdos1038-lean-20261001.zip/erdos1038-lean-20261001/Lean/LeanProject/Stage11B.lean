import LeanProject.Stage11A

/-!
# EP-1038, Stage 11: the difference-quotient transform on cosine polynomials

This extends the basis computation `HT_cos` to finite cosine combinations.
The extension to the Lipschitz and one-jump functions used in the paper's
adjoint identity still requires a separate approximation theorem.
-/

open Real Set MeasureTheory intervalIntegral Finset

namespace EP1038.Stage11

/-- A finite cosine polynomial on `[0, π]`. -/
noncomputable def cosPoly (s : Finset ℕ) (c : ℕ → ℝ) (θ : ℝ) : ℝ :=
  ∑ n ∈ s, c n * Real.cos ((n : ℝ) * θ)

/-- The difference quotient of a cosine polynomial is almost everywhere a
finite combination of the continuous functions `rr θ n`. -/
theorem HT_cosPoly {θ : ℝ} (hθ : θ ∈ Icc 0 π) (s : Finset ℕ) (c : ℕ → ℝ) :
    HT (cosPoly s c) θ = -(∑ n ∈ s, c n * Vn θ n) := by
  have hπ : π ≠ 0 := Real.pi_ne_zero
  have heq : ∀ᵐ φ ∂volume, φ ∈ Set.uIoc (0 : ℝ) π →
      (cosPoly s c φ - cosPoly s c θ) / (Real.cos θ - Real.cos φ) =
        ∑ n ∈ s, c n * rr θ n φ := by
    filter_upwards [EP1038.Stage9.ae_ne_real θ] with φ hφ hmem
    rw [uIoc_of_le Real.pi_pos.le] at hmem
    have hne : Real.cos θ - Real.cos φ ≠ 0 := by
      intro h
      exact hφ (Real.injOn_cos ⟨hmem.1.le, hmem.2⟩ hθ (by linarith)).symm.symm
    rw [div_eq_iff hne]
    unfold cosPoly
    rw [← Finset.sum_sub_distrib, Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro n hn
    rw [← mul_sub, cos_diff_eq θ n φ]
    ring
  have hint : ∀ n ∈ s, IntervalIntegrable (fun φ => c n * rr θ n φ) volume 0 π := by
    intro n hn
    exact (continuous_const.mul (rr_cont θ n)).intervalIntegrable _ _
  unfold HT
  rw [intervalIntegral.integral_congr_ae heq, intervalIntegral.integral_finsetSum hint]
  simp_rw [intervalIntegral.integral_const_mul, int_rr]
  have hs : (∑ n ∈ s, c n * -(π * Vn θ n)) =
      -π * (∑ n ∈ s, c n * Vn θ n) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro n hn
    ring
  rw [hs]
  field_simp

/-- On finite cosine polynomials, `HT` acts term by term. -/
theorem HT_cosPoly_sum {θ : ℝ} (hθ : θ ∈ Icc 0 π) (s : Finset ℕ) (c : ℕ → ℝ) :
    HT (cosPoly s c) θ =
      ∑ n ∈ s, c n * HT (fun φ => Real.cos ((n : ℝ) * φ)) θ := by
  rw [HT_cosPoly hθ]
  simp_rw [HT_cos hθ, mul_neg]
  rw [← Finset.sum_neg_distrib]

end EP1038.Stage11
