import LeanProject.RefMeasure

/-!
# EP-1038, Stage 10, Lemma 10.2(iii) and Proposition 10.3(6): potentials off `I`

With `d(θ) = D₀(1 - 2q cos θ + q²)` (so `c = D₀(1+q²)`, `ϱ = 2D₀q`, `H = D₀q`), a point `x < a`
is written `x = c - ϱ cosh τ_x = D₀(1+q²) - D₀q(p + 1/p)` with `p = e^{-τ_x} ∈ (0, 1)`.

* `log_dist_off`: `log|x - d(θ)| = log(H/p) + 2 log|1 - p e^{iθ}|` for every `θ`.
* `U_e_off` (**Lemma 10.2(iii)**, equilibrium): `(1/2π) ∫ log|x - d(θ)| dθ = log H + τ_x`.
* `U_omega_off` (**Lemma 10.2(iii)**, balayage):
  `(1/2π) ∫ log|x - d(θ)| P_q(θ) dθ = log H + τ_x + 2 log(1 - q e^{-τ_x})`.
* `W0_off` (**Proposition 10.3(6)**):
  `k log|x| + (1/2π) ∫ log|x - d(θ)| ((k+1) - k P_q(θ)) dθ = k log|x| + log H + τ_x - 2k log(1 - q e^{-τ_x})`.
  Here `τ_x = -log p`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- `x = D₀(1+q²) - D₀q(p + 1/p)`, i.e. `x = c - ϱ cosh τ` with `p = e^{-τ}`. -/
noncomputable def xoff (D0 q p : ℝ) : ℝ := D0 * (1 + q ^ 2) - D0 * q * (p + 1 / p)

theorem log_dist_off {D0 q p : ℝ} (hD : 0 < D0) (hq : 0 < q) (hp0 : 0 < p) (hp1 : p < 1)
    (θ : ℝ) :
    Real.log |xoff D0 q p - dth D0 q θ| = Real.log (D0 * q / p) + 2 * Kl p θ := by
  have hden := Pq_den_pos hp0.le hp1 θ
  have e : xoff D0 q p - dth D0 q θ = -(D0 * q / p * (1 - 2 * p * Real.cos θ + p ^ 2)) := by
    unfold xoff dth
    field_simp
    ring
  have hpos : 0 < D0 * q / p := by positivity
  rw [e, abs_neg, abs_of_pos (mul_pos hpos hden), Real.log_mul hpos.ne' hden.ne',
    Kl_eq_half_log]
  ring

/-- `K_r(0) = log|1 - r| = log(1 - r)` (with Mathlib's `log |x| = log x`). -/
theorem Kl_at_zero (r : ℝ) : Kl r 0 = Real.log (1 - r) := by
  rw [Kl_eq_half_log, Real.cos_zero, show 1 - 2 * r * 1 + r ^ 2 = (1 - r) ^ 2 by ring,
    Real.log_pow]
  push_cast
  ring

/-- **Lemma 10.2(iii)**, equilibrium part: `U_e(x) = log H + τ_x` (`τ_x = -log p`). -/
theorem U_e_off {D0 q p : ℝ} (hD : 0 < D0) (hq : 0 < q) (hp0 : 0 < p) (hp1 : p < 1) :
    1 / (2 * π) * ∫ θ in (-π)..π, Real.log |xoff D0 q p - dth D0 q θ| =
      Real.log (D0 * q) - Real.log p := by
  have hc := Kl_continuous hp0.le hp1
  rw [intervalIntegral.integral_congr (fun θ _ => log_dist_off hD hq hp0 hp1 θ),
    intervalIntegral.integral_add intervalIntegrable_const
      ((hc.intervalIntegrable _ _).const_mul 2),
    intervalIntegral.integral_const_mul, poisson_log_ii hp0.le hp1,
    intervalIntegral.integral_const, smul_eq_mul, Real.log_div (by positivity) hp0.ne']
  have hπ := Real.pi_pos.ne'
  field_simp
  ring

/-- **Lemma 10.2(iii)**, balayage part: `U_ω(x) = log H + τ_x + 2 log(1 - q e^{-τ_x})`. -/
theorem U_omega_off {D0 q p : ℝ} (hD : 0 < D0) (hq : 0 < q) (hq1 : q < 1) (hp0 : 0 < p)
    (hp1 : p < 1) :
    1 / (2 * π) * ∫ θ in (-π)..π, Real.log |xoff D0 q p - dth D0 q θ| * Pq q θ =
      Real.log (D0 * q) - Real.log p + 2 * Real.log (1 - q * p) := by
  have hc := Kl_continuous hp0.le hp1
  have hPc := Pq_cont hq.le hq1
  have e : ∀ θ, Real.log |xoff D0 q p - dth D0 q θ| * Pq q θ =
      Real.log (D0 * q / p) * Pq q θ + 2 * (Kl p (θ + 0) * Pq q θ) := by
    intro θ
    rw [log_dist_off hD hq hp0 hp1 θ, add_zero]
    ring
  have hA : IntervalIntegrable (fun θ => Real.log (D0 * q / p) * Pq q θ) volume (-π) π :=
    (continuous_const.mul hPc).intervalIntegrable _ _
  have hB : IntervalIntegrable (fun θ => 2 * (Kl p (θ + 0) * Pq q θ)) volume (-π) π :=
    (((hc.comp (continuous_id.add continuous_const)).mul hPc).intervalIntegrable _ _).const_mul 2
  rw [intervalIntegral.integral_congr (fun θ _ => e θ), intervalIntegral.integral_add hA hB,
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul, int_Pq hq.le hq1,
    int_Kl_Pq hp0.le hp1 hq.le hq1 0, Kl_at_zero,
    Real.log_div (by positivity) hp0.ne', mul_comm p q]
  have hπ := Real.pi_pos.ne'
  field_simp

/-- **Proposition 10.3(6)**: the reference potential off `I`. -/
theorem W0_off {D0 q p k : ℝ} (hD : 0 < D0) (hq : 0 < q) (hq1 : q < 1) (hp0 : 0 < p)
    (hp1 : p < 1) :
    k * Real.log |xoff D0 q p| + 1 / (2 * π) *
        ∫ θ in (-π)..π, Real.log |xoff D0 q p - dth D0 q θ| * ((k + 1) - k * Pq q θ) =
      k * Real.log |xoff D0 q p| + Real.log (D0 * q) - Real.log p -
        2 * k * Real.log (1 - q * p) := by
  have hc := Kl_continuous hp0.le hp1
  have hPc := Pq_cont hq.le hq1
  have hL : IntervalIntegrable (fun θ => Real.log |xoff D0 q p - dth D0 q θ|) volume (-π) π := by
    have hs : IntervalIntegrable (fun θ => Real.log (D0 * q / p) + 2 * Kl p θ) volume (-π) π :=
      intervalIntegrable_const.add ((hc.intervalIntegrable _ _).const_mul 2)
    refine (intervalIntegrable_congr ?_).mp hs
    intro θ _
    exact (log_dist_off hD hq hp0 hp1 θ).symm
  have hLP : IntervalIntegrable (fun θ => Real.log |xoff D0 q p - dth D0 q θ| * Pq q θ)
      volume (-π) π := hL.mul_continuousOn hPc.continuousOn
  have e : ∫ θ in (-π)..π, Real.log |xoff D0 q p - dth D0 q θ| * ((k + 1) - k * Pq q θ) =
      (k + 1) * (∫ θ in (-π)..π, Real.log |xoff D0 q p - dth D0 q θ|) -
        k * ∫ θ in (-π)..π, Real.log |xoff D0 q p - dth D0 q θ| * Pq q θ := by
    rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_const_mul,
      ← intervalIntegral.integral_sub (hL.const_mul _) (hLP.const_mul _)]
    refine intervalIntegral.integral_congr (fun θ _ => ?_)
    ring
  have hU := U_omega_off hD hq hq1 hp0 hp1
  have hE := U_e_off hD hq hp0 hp1
  rw [e, mul_sub, ← mul_assoc, mul_comm (1 / (2 * π)) (k + 1), mul_assoc, ← mul_assoc _ k,
    mul_comm (1 / (2 * π)) k, mul_assoc, hU, hE]
  ring

end EP1038.Arc
