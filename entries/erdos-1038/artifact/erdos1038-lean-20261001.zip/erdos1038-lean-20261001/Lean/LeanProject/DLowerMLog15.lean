import LeanProject.DLowerMTools
import LeanProject.DLowerMLog12
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_600 : RB (Real.log ((858274353667819 : ℝ) / 1953125000000000)) ((-822262125029381217 : ℝ) / 1000000000000000000) ((-164452425005876243 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((858274353667819 : ℝ) / 976562500000000)) (t := ((-118288146332181 : ℝ) / 1834836853667819))
    (lo := ((-129114944469435907 : ℝ) / 1000000000000000000)) (hi := ((-64557472234717953 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((858274353667819 : ℝ) / 1953125000000000) = Real.log ((858274353667819 : ℝ) / 976562500000000) - 1 * Real.log 2 := by
    rw [show ((858274353667819 : ℝ) / 1953125000000000) = ((858274353667819 : ℝ) / 976562500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_601 : RB (Real.log ((112941601906477783 : ℝ) / 250000000000000000)) ((-794590030023457921 : ℝ) / 1000000000000000000) ((-794590030023457919 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((112941601906477783 : ℝ) / 125000000000000000)) (t := ((-12058398093522217 : ℝ) / 237941601906477783))
    (lo := ((-101442849463512611 : ℝ) / 1000000000000000000)) (hi := ((-10144284946351261 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112941601906477783 : ℝ) / 250000000000000000) = Real.log ((112941601906477783 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((112941601906477783 : ℝ) / 250000000000000000) = ((112941601906477783 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_602 : RB (Real.log ((547333592374088869 : ℝ) / 1000000000000000000)) ((-602696804360112733 : ℝ) / 1000000000000000000) ((-602696804360112731 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((547333592374088869 : ℝ) / 500000000000000000)) (t := ((47333592374088869 : ℝ) / 1047333592374088869))
    (lo := ((90450376199832577 : ℝ) / 1000000000000000000)) (hi := ((45225188099916289 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((547333592374088869 : ℝ) / 1000000000000000000) = Real.log ((547333592374088869 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((547333592374088869 : ℝ) / 1000000000000000000) = ((547333592374088869 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_603 : RB (Real.log ((1092458068207181 : ℝ) / 1953125000000000)) ((-581000388195334351 : ℝ) / 1000000000000000000) ((-581000388195334349 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1092458068207181 : ℝ) / 976562500000000)) (t := ((115895568207181 : ℝ) / 2069020568207181))
    (lo := ((112146792364610959 : ℝ) / 1000000000000000000)) (hi := ((1401834904557637 : ℝ) / 12500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1092458068207181 : ℝ) / 1953125000000000) = Real.log ((1092458068207181 : ℝ) / 976562500000000) - 1 * Real.log 2 := by
    rw [show ((1092458068207181 : ℝ) / 1953125000000000) = ((1092458068207181 : ℝ) / 976562500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_604 : RB (Real.log ((860666931792819 : ℝ) / 1953125000000000)) ((-819478342138908461 : ℝ) / 1000000000000000000) ((-819478342138908459 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((860666931792819 : ℝ) / 976562500000000)) (t := ((-115895568207181 : ℝ) / 1837229431792819))
    (lo := ((-126331161578963151 : ℝ) / 1000000000000000000)) (hi := ((-2526623231579263 : ℝ) / 20000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((860666931792819 : ℝ) / 1953125000000000) = Real.log ((860666931792819 : ℝ) / 976562500000000) - 1 * Real.log 2 := by
    rw [show ((860666931792819 : ℝ) / 1953125000000000) = ((860666931792819 : ℝ) / 976562500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_605 : RB (Real.log ((452666407625911131 : ℝ) / 1000000000000000000)) ((-39629991589337591 : ℝ) / 50000000000000000) ((-396299915893375909 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((452666407625911131 : ℝ) / 500000000000000000)) (t := ((-47333592374088869 : ℝ) / 952666407625911131))
    (lo := ((-9945265122680651 : ℝ) / 100000000000000000)) (hi := ((-99452651226806509 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((452666407625911131 : ℝ) / 1000000000000000000) = Real.log ((452666407625911131 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((452666407625911131 : ℝ) / 1000000000000000000) = ((452666407625911131 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_606 : RB (Real.log ((858603943511569 : ℝ) / 1953125000000000)) ((-41093909209469041 : ℝ) / 50000000000000000) ((-410939092094690409 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((858603943511569 : ℝ) / 976562500000000)) (t := ((-117958556488431 : ℝ) / 1835166443511569))
    (lo := ((-12873100362943551 : ℝ) / 100000000000000000)) (hi := ((-128731003629435509 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((858603943511569 : ℝ) / 1953125000000000) = Real.log ((858603943511569 : ℝ) / 976562500000000) - 1 * Real.log 2 := by
    rw [show ((858603943511569 : ℝ) / 1953125000000000) = ((858603943511569 : ℝ) / 976562500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_607 : RB (Real.log ((439605219077923329 : ℝ) / 1000000000000000000)) ((-410939092094690409 : ℝ) / 500000000000000000) ((-51367386511836301 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((439605219077923329 : ℝ) / 500000000000000000)) (t := ((-60394780922076671 : ℝ) / 939605219077923329))
    (lo := ((-32182750907358877 : ℝ) / 250000000000000000)) (hi := ((-128731003629435507 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((439605219077923329 : ℝ) / 1000000000000000000) = Real.log ((439605219077923329 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((439605219077923329 : ℝ) / 1000000000000000000) = ((439605219077923329 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_608 : RB (Real.log ((439761469077923329 : ℝ) / 1000000000000000000)) ((-821522814799685047 : ℝ) / 1000000000000000000) ((-164304562959937009 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((439761469077923329 : ℝ) / 500000000000000000)) (t := ((-60238530922076671 : ℝ) / 939761469077923329))
    (lo := ((-128375634239739737 : ℝ) / 1000000000000000000)) (hi := ((-16046954279967467 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((439761469077923329 : ℝ) / 1000000000000000000) = Real.log ((439761469077923329 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((439761469077923329 : ℝ) / 1000000000000000000) = ((439761469077923329 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_609 : RB (Real.log ((451610157625911131 : ℝ) / 1000000000000000000)) ((-794935954430993479 : ℝ) / 1000000000000000000) ((-794935954430993477 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((451610157625911131 : ℝ) / 500000000000000000)) (t := ((-48389842374088869 : ℝ) / 951610157625911131))
    (lo := ((-101788773871048169 : ℝ) / 1000000000000000000)) (hi := ((-12723596733881021 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((451610157625911131 : ℝ) / 1000000000000000000) = Real.log ((451610157625911131 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((451610157625911131 : ℝ) / 1000000000000000000) = ((451610157625911131 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_610 : RB (Real.log ((112902539406477783 : ℝ) / 250000000000000000)) ((-794935954430993477 : ℝ) / 1000000000000000000) ((-31797438177239739 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((112902539406477783 : ℝ) / 125000000000000000)) (t := ((-12097460593522217 : ℝ) / 237902539406477783))
    (lo := ((-101788773871048167 : ℝ) / 1000000000000000000)) (hi := ((-50894386935524083 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112902539406477783 : ℝ) / 250000000000000000) = Real.log ((112902539406477783 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((112902539406477783 : ℝ) / 250000000000000000) = ((112902539406477783 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_611 : RB (Real.log ((451441407625911131 : ℝ) / 1000000000000000000)) ((-159061937449277689 : ℝ) / 200000000000000000) ((-795309687246388443 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((451441407625911131 : ℝ) / 500000000000000000)) (t := ((-48558592374088869 : ℝ) / 951441407625911131))
    (lo := ((-20432501337288627 : ℝ) / 200000000000000000)) (hi := ((-51081253343221567 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((451441407625911131 : ℝ) / 1000000000000000000) = Real.log ((451441407625911131 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((451441407625911131 : ℝ) / 1000000000000000000) = ((451441407625911131 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_612 : RB (Real.log ((1423781932332283969 : ℝ) / 1000000000000000000)) ((2826533310847601 : ℝ) / 8000000000000000) ((353316663855950127 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1423781932332283969 : ℝ) / 2000000000000000000)) (t := ((-576218067667716031 : ℝ) / 3423781932332283969))
    (lo := ((-21239407293999699 : ℝ) / 62500000000000000)) (hi := ((-339830516703995183 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1423781932332283969 : ℝ) / 1000000000000000000) = Real.log ((1423781932332283969 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1423781932332283969 : ℝ) / 1000000000000000000) = ((1423781932332283969 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_613 : RB (Real.log ((1427738492858960549 : ℝ) / 1000000000000000000)) ((356091718897339629 : ℝ) / 1000000000000000000) ((356091718897339631 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1427738492858960549 : ℝ) / 2000000000000000000)) (t := ((-572261507141039451 : ℝ) / 3427738492858960549))
    (lo := ((-4213193270782571 : ℝ) / 12500000000000000)) (hi := ((-337055461662605679 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1427738492858960549 : ℝ) / 1000000000000000000) = Real.log ((1427738492858960549 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1427738492858960549 : ℝ) / 1000000000000000000) = ((1427738492858960549 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_614 : RB (Real.log ((425006932332283969 : ℝ) / 1000000000000000000)) ((-855649798820669247 : ℝ) / 1000000000000000000) ((-171129959764133849 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((425006932332283969 : ℝ) / 500000000000000000)) (t := ((-74993067667716031 : ℝ) / 925006932332283969))
    (lo := ((-162502618260723937 : ℝ) / 1000000000000000000)) (hi := ((-5078206820647623 : ℝ) / 31250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425006932332283969 : ℝ) / 1000000000000000000) = Real.log ((425006932332283969 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425006932332283969 : ℝ) / 1000000000000000000) = ((425006932332283969 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_615 : RB (Real.log ((107159623214740137 : ℝ) / 250000000000000000)) ((-847141389291869351 : ℝ) / 1000000000000000000) ((-847141389291869349 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((107159623214740137 : ℝ) / 125000000000000000)) (t := ((-17840376785259863 : ℝ) / 232159623214740137))
    (lo := ((-153994208731924041 : ℝ) / 1000000000000000000)) (hi := ((-3849855218298101 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((107159623214740137 : ℝ) / 250000000000000000) = Real.log ((107159623214740137 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((107159623214740137 : ℝ) / 250000000000000000) = ((107159623214740137 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_616 : RB (Real.log ((1425006932332283969 : ℝ) / 1000000000000000000)) ((177088339251683007 : ℝ) / 500000000000000000) ((2767005300807547 : ℝ) / 7812500000000000) := by
  have hm := log_bounds_of_series (x := ((1425006932332283969 : ℝ) / 2000000000000000000)) (t := ((-574993067667716031 : ℝ) / 3425006932332283969))
    (lo := ((-67794100411315859 : ℝ) / 200000000000000000)) (hi := ((-169485251028289647 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425006932332283969 : ℝ) / 1000000000000000000) = Real.log ((1425006932332283969 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425006932332283969 : ℝ) / 1000000000000000000) = ((1425006932332283969 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_617 : RB (Real.log ((357159623214740137 : ℝ) / 250000000000000000)) ((178360943919061337 : ℝ) / 500000000000000000) ((89180471959530669 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((357159623214740137 : ℝ) / 500000000000000000)) (t := ((-142840376785259863 : ℝ) / 857159623214740137))
    (lo := ((-67285058544364527 : ℝ) / 200000000000000000)) (hi := ((-168212646360911317 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((357159623214740137 : ℝ) / 250000000000000000) = Real.log ((357159623214740137 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((357159623214740137 : ℝ) / 250000000000000000) = ((357159623214740137 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_618 : RB (Real.log ((1423950682332283969 : ℝ) / 1000000000000000000)) ((353435179196420317 : ℝ) / 1000000000000000000) ((353435179196420319 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1423950682332283969 : ℝ) / 2000000000000000000)) (t := ((-576049317667716031 : ℝ) / 3423950682332283969))
    (lo := ((-2654000010652539 : ℝ) / 7812500000000000)) (hi := ((-339712001363524991 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1423950682332283969 : ℝ) / 1000000000000000000) = Real.log ((1423950682332283969 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1423950682332283969 : ℝ) / 1000000000000000000) = ((1423950682332283969 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_619 : RB (Real.log ((142395068233228397 : ℝ) / 100000000000000000)) ((176717589598210159 : ℝ) / 500000000000000000) ((2208969869977627 : ℝ) / 6250000000000000) := by
  have hm := log_bounds_of_series (x := ((142395068233228397 : ℝ) / 200000000000000000)) (t := ((-57604931766771603 : ℝ) / 342395068233228397))
    (lo := ((-339712001363524991 : ℝ) / 1000000000000000000)) (hi := ((-33971200136352499 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142395068233228397 : ℝ) / 100000000000000000) = Real.log ((142395068233228397 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142395068233228397 : ℝ) / 100000000000000000) = ((142395068233228397 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_620 : RB (Real.log ((142410693233228397 : ℝ) / 100000000000000000)) ((70708980620085159 : ℝ) / 200000000000000000) ((353544903100425797 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((142410693233228397 : ℝ) / 200000000000000000)) (t := ((-57589306766771603 : ℝ) / 342410693233228397))
    (lo := ((-169801138729759757 : ℝ) / 500000000000000000)) (hi := ((-339602277459519513 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142410693233228397 : ℝ) / 100000000000000000) = Real.log ((142410693233228397 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142410693233228397 : ℝ) / 100000000000000000) = ((142410693233228397 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_621 : RB (Real.log ((356895560714740137 : ℝ) / 250000000000000000)) ((355982274099631689 : ℝ) / 1000000000000000000) ((355982274099631691 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((356895560714740137 : ℝ) / 500000000000000000)) (t := ((-143104439285259863 : ℝ) / 856895560714740137))
    (lo := ((-16858245323015681 : ℝ) / 50000000000000000)) (hi := ((-337164906460313619 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356895560714740137 : ℝ) / 250000000000000000) = Real.log ((356895560714740137 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356895560714740137 : ℝ) / 250000000000000000) = ((356895560714740137 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_622 : RB (Real.log ((1427582242858960549 : ℝ) / 1000000000000000000)) ((35598227409963169 : ℝ) / 100000000000000000) ((88995568524907923 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1427582242858960549 : ℝ) / 2000000000000000000)) (t := ((-572417757141039451 : ℝ) / 3427582242858960549))
    (lo := ((-337164906460313619 : ℝ) / 1000000000000000000)) (hi := ((-168582453230156809 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1427582242858960549 : ℝ) / 1000000000000000000) = Real.log ((1427582242858960549 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1427582242858960549 : ℝ) / 1000000000000000000) = ((1427582242858960549 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_623 : RB (Real.log ((356853373214740137 : ℝ) / 250000000000000000)) ((177932030131341207 : ℝ) / 500000000000000000) ((22241503766417651 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((356853373214740137 : ℝ) / 500000000000000000)) (t := ((-143146626785259863 : ℝ) / 856853373214740137))
    (lo := ((-67456624059452579 : ℝ) / 200000000000000000)) (hi := ((-168641560148631447 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356853373214740137 : ℝ) / 250000000000000000) = Real.log ((356853373214740137 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356853373214740137 : ℝ) / 250000000000000000) = ((356853373214740137 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_624 : RB (Real.log ((37499999999999999 : ℝ) / 1000000000000000000)) ((-3283414346005771949 : ℝ) / 1000000000000000000) ((-3283414346005771947 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((37499999999999999 : ℝ) / 31250000000000000)) (t := ((6249999999999999 : ℝ) / 68749999999999999))
    (lo := ((182321556793954599 : ℝ) / 1000000000000000000)) (hi := ((911607783969773 : ℝ) / 5000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37499999999999999 : ℝ) / 1000000000000000000) = Real.log ((37499999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((37499999999999999 : ℝ) / 1000000000000000000) = ((37499999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_625 : RB (Real.log ((3 : ℝ) / 80)) ((-1641707173002885961 : ℝ) / 500000000000000000) ((-41042679325072149 : ℝ) / 12500000000000000) := by
  have hm := log_bounds_of_series (x := ((6 : ℝ) / 5)) (t := ((1 : ℝ) / 11))
    (lo := ((91160778396977313 : ℝ) / 500000000000000000)) (hi := ((182321556793954627 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3 : ℝ) / 80) = Real.log ((6 : ℝ) / 5) - 5 * Real.log 2 := by
    rw [show ((3 : ℝ) / 80) = ((6 : ℝ) / 5) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_626 : RB (Real.log ((1037499999999999999 : ℝ) / 1000000000000000000)) ((3681397312271631 : ℝ) / 100000000000000000) ((36813973122716311 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1037499999999999999 : ℝ) / 1000000000000000000)) (t := ((37499999999999999 : ℝ) / 2037499999999999999))
    (lo := ((3681397312271631 : ℝ) / 100000000000000000)) (hi := ((36813973122716311 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_627 : RB (Real.log ((83 : ℝ) / 80)) ((36813973122716311 : ℝ) / 1000000000000000000) ((4601746640339539 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((83 : ℝ) / 80)) (t := ((3 : ℝ) / 163))
    (lo := ((36813973122716311 : ℝ) / 1000000000000000000)) (hi := ((4601746640339539 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_628 : RB (Real.log ((34999999999999999 : ℝ) / 1000000000000000000)) ((-1676203608746361701 : ℝ) / 500000000000000000) ((-16762036087463617 : ℝ) / 5000000000000000) := by
  have hm := log_bounds_of_series (x := ((34999999999999999 : ℝ) / 31250000000000000)) (t := ((3749999999999999 : ℝ) / 66249999999999999))
    (lo := ((56664342653501573 : ℝ) / 500000000000000000)) (hi := ((113328685307003147 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34999999999999999 : ℝ) / 1000000000000000000) = Real.log ((34999999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((34999999999999999 : ℝ) / 1000000000000000000) = ((34999999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_629 : RB (Real.log ((1 : ℝ) / 25)) ((-3218875824868200751 : ℝ) / 1000000000000000000) ((-3218875824868200749 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((32 : ℝ) / 25)) (t := ((7 : ℝ) / 57))
    (lo := ((246860077931525797 : ℝ) / 1000000000000000000)) (hi := ((123430038965762899 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 25) = Real.log ((32 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((1 : ℝ) / 25) = ((32 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_630 : RB (Real.log ((1034999999999999999 : ℝ) / 1000000000000000000)) ((6880285343466479 : ℝ) / 200000000000000000) ((8600356679333099 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1034999999999999999 : ℝ) / 1000000000000000000)) (t := ((34999999999999999 : ℝ) / 2034999999999999999))
    (lo := ((6880285343466479 : ℝ) / 200000000000000000)) (hi := ((8600356679333099 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_631 : RB (Real.log ((26 : ℝ) / 25)) ((2451294572080081 : ℝ) / 62500000000000000) ((39220713153281297 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((26 : ℝ) / 25)) (t := ((1 : ℝ) / 51))
    (lo := ((2451294572080081 : ℝ) / 62500000000000000)) (hi := ((39220713153281297 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_632 : RB (Real.log ((435452697545871 : ℝ) / 1000000000000000)) ((-83136910501616239 : ℝ) / 100000000000000000) ((-207842276254040597 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((435452697545871 : ℝ) / 500000000000000)) (t := ((-64547302454129 : ℝ) / 935452697545871))
    (lo := ((-3455548111405427 : ℝ) / 25000000000000000)) (hi := ((-138221924456217079 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((435452697545871 : ℝ) / 1000000000000000) = Real.log ((435452697545871 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((435452697545871 : ℝ) / 1000000000000000) = ((435452697545871 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_633 : RB (Real.log ((435452697545874001 : ℝ) / 1000000000000000000)) ((-831369105016155499 : ℝ) / 1000000000000000000) ((-831369105016155497 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((435452697545874001 : ℝ) / 500000000000000000)) (t := ((-64547302454125999 : ℝ) / 935452697545874001))
    (lo := ((-138221924456210189 : ℝ) / 1000000000000000000)) (hi := ((-34555481114052547 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((435452697545874001 : ℝ) / 1000000000000000000) = Real.log ((435452697545874001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((435452697545874001 : ℝ) / 1000000000000000000) = ((435452697545874001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_634 : RB (Real.log ((281570526227063 : ℝ) / 500000000000000)) ((-28711257250147919 : ℝ) / 50000000000000000) ((-287112572501479189 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((281570526227063 : ℝ) / 250000000000000)) (t := ((31570526227063 : ℝ) / 531570526227063))
    (lo := ((11892203555698693 : ℝ) / 100000000000000000)) (hi := ((118922035556986931 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((281570526227063 : ℝ) / 500000000000000) = Real.log ((281570526227063 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((281570526227063 : ℝ) / 500000000000000) = ((281570526227063 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_635 : RB (Real.log ((563141052454129 : ℝ) / 1000000000000000)) ((-574225145002953053 : ℝ) / 1000000000000000000) ((-574225145002953051 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((563141052454129 : ℝ) / 500000000000000)) (t := ((63141052454129 : ℝ) / 1063141052454129))
    (lo := ((118922035556992257 : ℝ) / 1000000000000000000)) (hi := ((59461017778496129 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((563141052454129 : ℝ) / 1000000000000000) = Real.log ((563141052454129 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((563141052454129 : ℝ) / 1000000000000000) = ((563141052454129 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_636 : RB (Real.log ((436858947545871 : ℝ) / 1000000000000000)) ((-414072455242010203 : ℝ) / 500000000000000000) ((-207036227621005101 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((436858947545871 : ℝ) / 500000000000000)) (t := ((-63141052454129 : ℝ) / 936858947545871))
    (lo := ((-16874716240509387 : ℝ) / 125000000000000000)) (hi := ((-26999545984815019 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((436858947545871 : ℝ) / 1000000000000000) = Real.log ((436858947545871 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((436858947545871 : ℝ) / 1000000000000000) = ((436858947545871 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_637 : RB (Real.log ((218429473772937 : ℝ) / 500000000000000)) ((-828144910484013539 : ℝ) / 1000000000000000000) ((-828144910484013537 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((218429473772937 : ℝ) / 250000000000000)) (t := ((-31570526227063 : ℝ) / 468429473772937))
    (lo := ((-134997729924068229 : ℝ) / 1000000000000000000)) (hi := ((-33749432481017057 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((218429473772937 : ℝ) / 500000000000000) = Real.log ((218429473772937 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((218429473772937 : ℝ) / 500000000000000) = ((218429473772937 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_638 : RB (Real.log ((435452697545871001 : ℝ) / 1000000000000000000)) ((-207842276254040597 : ℝ) / 250000000000000000) ((-415684552508081193 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((435452697545871001 : ℝ) / 500000000000000000)) (t := ((-64547302454128999 : ℝ) / 935452697545871001))
    (lo := ((-69110962228108539 : ℝ) / 500000000000000000)) (hi := ((-138221924456217077 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((435452697545871001 : ℝ) / 1000000000000000000) = Real.log ((435452697545871001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((435452697545871001 : ℝ) / 1000000000000000000) = ((435452697545871001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_639 : RB (Real.log ((217726348772937 : ℝ) / 500000000000000)) ((-831369105016155501 : ℝ) / 1000000000000000000) ((-831369105016155499 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((217726348772937 : ℝ) / 250000000000000)) (t := ((-32273651227063 : ℝ) / 467726348772937))
    (lo := ((-138221924456210191 : ℝ) / 1000000000000000000)) (hi := ((-13822192445621019 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((217726348772937 : ℝ) / 500000000000000) = Real.log ((217726348772937 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((217726348772937 : ℝ) / 500000000000000) = ((217726348772937 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
