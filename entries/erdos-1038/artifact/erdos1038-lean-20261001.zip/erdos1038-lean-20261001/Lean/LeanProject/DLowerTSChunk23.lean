import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk20
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_76 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((320917779451972438632360775883161 : ℝ) / 2596148429267413814265248164610048) ((160470558449761320167805683970867 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((61806516113 : ℝ) / 500000000000) ((24724404297 : ℝ) / 200000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((561806516113 : ℝ) / 500000000000) ((224724404297 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((23309882963 : ℝ) / 200000000000) ((1165574151 : ℝ) / 10000000000) := rb_log h1 (by norm_num) dlower_log_919.1 dlower_log_920.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((23309882963 : ℝ) / 100000000000) ((1165574151 : ℝ) / 5000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460032350359 : ℝ) / 1000000000000) ((46004835093 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-522649825199 : ℝ) / 250000000000) ((-2090526582473 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_921.1 dlower_log_922.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2090526582473 : ℝ) / 1000000000000) ((522649825199 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((220048074341 : ℝ) / 1000000000000) ((220063382493 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779936617507 : ℝ) / 1000000000000) ((779951925659 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1910022717 : ℝ) / 125000000000) ((15282404197 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((221399756207 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((20611735201 : ℝ) / 100000000000) ((206119574471 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((221399756207 : ℝ) / 1000000000000) ((221399756207 : ℝ) / 1000000000000) ((221399756207 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((778600243793 : ℝ) / 1000000000000))
  have h11 : RB z11 ((264728085629 : ℝ) / 1000000000000) ((264730940061 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((778600243793 : ℝ) / 1000000000000) ((778600243793 : ℝ) / 1000000000000) ((778600243793 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-265810414351 : ℝ) / 200000000000) ((-664520644653 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_923.1 dlower_log_924.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-1036596722667 : ℝ) / 1000000000000) ((-259141991927 : ℝ) / 250000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((221399756207 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-376946339963 : ℝ) / 250000000000) ((-30155707197 : ℝ) / 20000000000) := rb_log (show RB ((221399756207 : ℝ) / 1000000000000) ((221399756207 : ℝ) / 1000000000000) ((221399756207 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_925.1 dlower_log_925.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((471188637183 : ℝ) / 1000000000000) ((29451087009 : ℝ) / 62500000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((11140286253 : ℝ) / 1000000000000) ((2237008357 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1910022717 : ℝ) / 125000000000) ((15282404197 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1490277490883 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((737497543343 : ℝ) / 500000000000) ((1474997309147 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1490277490883 : ℝ) / 1000000000000) ((1490277490883 : ℝ) / 1000000000000) ((1490277490883 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((490277490883 : ℝ) / 1000000000000))
  have h19 : RB z19 ((60169806451 : ℝ) / 20000000000) ((3008494855619 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((490277490883 : ℝ) / 1000000000000) ((490277490883 : ℝ) / 1000000000000) ((490277490883 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1101438398969 : ℝ) / 1000000000000) ((1101439905729 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_926.1 dlower_log_927.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((214763034821 : ℝ) / 250000000000) ((53691885967 : ℝ) / 62500000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1490277490883 : ℝ) / 1000000000000))
  have h22 : RB z22 ((99740584527 : ℝ) / 250000000000) ((39896233811 : ℝ) / 100000000000) := rb_log (show RB ((1490277490883 : ℝ) / 1000000000000) ((1490277490883 : ℝ) / 1000000000000) ((1490277490883 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_928.1 dlower_log_928.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((230044900587 : ℝ) / 500000000000) ((115026959341 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((10362561 : ℝ) / 250000000000) ((15097401 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((561806516113 : ℝ) / 500000000000) ((224724404297 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((315626561547 : ℝ) / 250000000000) ((1262526447167 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((396031307797 : ℝ) / 250000000000) ((198018822287 : ℝ) / 125000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((317219433669 : ℝ) / 250000000000))
  have h28 : RB z28 ((251257654349 : ℝ) / 125000000000) ((1005046698587 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((317219433669 : ℝ) / 250000000000) ((317219433669 : ℝ) / 250000000000) ((317219433669 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1910022717 : ℝ) / 125000000000) ((15282404197 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((329947073162275865160781 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((46311008579 : ℝ) / 1000000000000) ((46317744391 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((329947073162275865160781 : ℝ) / 1000000000000000000000000) ((329947073162275865160781 : ℝ) / 1000000000000000000000000) ((329947073162275865160781 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((953682255609 : ℝ) / 1000000000000) ((953688991421 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((479239933077 : ℝ) / 250000000000) ((1917003944613 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((221399756207 : ℝ) / 1000000000000)) ((11140286253 : ℝ) / 1000000000000) ((2237008357 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1490277490883 : ℝ) / 1000000000000)) ((10362561 : ℝ) / 250000000000) ((15097401 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((221399756207 : ℝ) / 1000000000000)) (wl := ((1490277490883 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((479239933077 : ℝ) / 250000000000) ≤ D0q (q) * (((1490277490883 : ℝ) / 1000000000000) - ((221399756207 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1490277490883 : ℝ) / 1000000000000) * ((221399756207 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_77 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((160470558449761320167805683970867 : ℝ) / 1298074214633706907132624082305024) ((320964454347072842038861960000307 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((30905505371 : ℝ) / 250000000000) ((123631010743 : ℝ) / 1000000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((280905505371 : ℝ) / 250000000000) ((1123631010743 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((58278707549 : ℝ) / 500000000000) ((58282707659 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_929.1 dlower_log_930.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((58278707549 : ℝ) / 250000000000) ((58282707659 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460016349923 : ℝ) / 1000000000000) ((115008087591 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2090526582483 : ℝ) / 1000000000000) ((-2090453869447 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_931.1 dlower_log_932.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2090453869447 : ℝ) / 1000000000000) ((2090526582483 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((220048074861 : ℝ) / 1000000000000) ((13753961433 : ℝ) / 62500000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((48746038567 : ℝ) / 62500000000) ((779951925139 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3056480839 : ℝ) / 200000000000) ((7642313409 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((110431439639 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((10278912623 : ℝ) / 50000000000) ((205580475083 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((110431439639 : ℝ) / 500000000000) ((110431439639 : ℝ) / 500000000000) ((110431439639 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((389568560361 : ℝ) / 500000000000))
  have h11 : RB z11 ((65963437947 : ℝ) / 250000000000) ((263856604461 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((389568560361 : ℝ) / 500000000000) ((389568560361 : ℝ) / 500000000000) ((389568560361 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-266472059967 : ℝ) / 200000000000) ((-666174744161 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_933.1 dlower_log_934.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-259794245209 : ℝ) / 250000000000) ((-1039148152679 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((110431439639 : ℝ) / 500000000000))
  have h14 : RB z14 ((-1510213225783 : ℝ) / 1000000000000) ((-1510213225781 : ℝ) / 1000000000000) := rb_log (show RB ((110431439639 : ℝ) / 500000000000) ((110431439639 : ℝ) / 500000000000) ((110431439639 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_935.1 dlower_log_935.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((94207248989 : ℝ) / 200000000000) ((29441567069 : ℝ) / 62500000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((11003894581 : ℝ) / 1000000000000) ((11048723181 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3056480839 : ℝ) / 200000000000) ((7642313409 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1490286045239 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1475001418421 : ℝ) / 1000000000000) ((368750910261 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((1490286045239 : ℝ) / 1000000000000) ((1490286045239 : ℝ) / 1000000000000) ((1490286045239 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((490286045239 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3008450745731 : ℝ) / 1000000000000) ((3008455279051 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((490286045239 : ℝ) / 1000000000000) ((490286045239 : ℝ) / 1000000000000) ((490286045239 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((3441953887 : ℝ) / 3125000000) ((1101426750703 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_936.1 dlower_log_937.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((429520939319 : ℝ) / 500000000000) ((859059914611 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1490286045239 : ℝ) / 1000000000000))
  have h22 : RB z22 ((398968078201 : ℝ) / 1000000000000) ((398968078203 : ℝ) / 1000000000000) := rb_log (show RB ((1490286045239 : ℝ) / 1000000000000) ((1490286045239 : ℝ) / 1000000000000) ((1490286045239 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_938.1 dlower_log_938.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((92014760087 : ℝ) / 200000000000) ((46009183641 : ℝ) / 100000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41450071 : ℝ) / 1000000000000) ((75486487 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((280905505371 : ℝ) / 250000000000) ((1123631010743 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1262526447163 : ℝ) / 1000000000000) ((78909165519 : ℝ) / 62500000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((792049942347 : ℝ) / 500000000000) ((792062615597 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1269423165961 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1005446545413 : ℝ) / 500000000000) ((2010925266261 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1269423165961 : ℝ) / 1000000000000) ((1269423165961 : ℝ) / 1000000000000) ((1269423165961 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3056480839 : ℝ) / 200000000000) ((7642313409 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((164574433449654651828721 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((9286013553 : ℝ) / 200000000000) ((46436820403 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((164574433449654651828721 : ℝ) / 500000000000000000000000) ((164574433449654651828721 : ℝ) / 500000000000000000000000) ((164574433449654651828721 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((953563179597 : ℝ) / 1000000000000) ((190713986447 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1917513609517 : ℝ) / 1000000000000) ((1917557869879 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((110431439639 : ℝ) / 500000000000)) ((11003894581 : ℝ) / 1000000000000) ((11048723181 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1490286045239 : ℝ) / 1000000000000)) ((41450071 : ℝ) / 1000000000000) ((75486487 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((110431439639 : ℝ) / 500000000000)) (wl := ((1490286045239 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1917513609517 : ℝ) / 1000000000000) ≤ D0q (q) * (((1490286045239 : ℝ) / 1000000000000) - ((110431439639 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((1490286045239 : ℝ) / 1000000000000) * ((110431439639 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_78 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((320964454347072842038861960000307 : ℝ) / 2596148429267413814265248164610048) ((4454600463424705 : ℝ) / 36028797018963968)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((61815505371 : ℝ) / 500000000000) ((3091 : ℝ) / 25000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((561815505371 : ℝ) / 500000000000) ((28091 : ℝ) / 25000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((116565415317 : ℝ) / 1000000000000) ((7285838467 : ℝ) / 62500000000) := rb_log h1 (by norm_num) dlower_log_939.1 dlower_log_940.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((116565415317 : ℝ) / 500000000000) ((7285838467 : ℝ) / 31250000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((92000069923 : ℝ) / 200000000000) ((230008174963 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2090453869457 : ℝ) / 1000000000000) ((-2090381161717 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_941.1 dlower_log_942.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2090381161717 : ℝ) / 1000000000000) ((2090453869457 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((220048074887 : ℝ) / 1000000000000) ((110031691433 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((389968308567 : ℝ) / 500000000000) ((779951925113 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15284626817 : ℝ) / 1000000000000) ((9554281 : ℝ) / 625000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((109819596087 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((102176171287 : ℝ) / 500000000000) ((204354565357 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((109819596087 : ℝ) / 500000000000) ((109819596087 : ℝ) / 500000000000) ((109819596087 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((390180403913 : ℝ) / 500000000000))
  have h11 : RB z11 ((130934524469 : ℝ) / 500000000000) ((261871897343 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((390180403913 : ℝ) / 500000000000) ((390180403913 : ℝ) / 500000000000) ((390180403913 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-167488839173 : ℝ) / 125000000000) ((-1339899836229 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_943.1 dlower_log_944.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-32658310637 : ℝ) / 31250000000) ((-522518472783 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((109819596087 : ℝ) / 500000000000))
  have h14 : RB z14 ((-757884557267 : ℝ) / 500000000000) ((-378942278633 : ℝ) / 250000000000) := rb_log (show RB ((109819596087 : ℝ) / 500000000000) ((109819596087 : ℝ) / 500000000000) ((109819596087 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_945.1 dlower_log_945.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((117675793537 : ℝ) / 250000000000) ((58841521121 : ℝ) / 125000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((5343412111 : ℝ) / 500000000000) ((10731819353 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15284626817 : ℝ) / 1000000000000) ((9554281 : ℝ) / 625000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((298058919987 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((295001550067 : ℝ) / 200000000000) ((737504986559 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((298058919987 : ℝ) / 200000000000) ((298058919987 : ℝ) / 200000000000) ((298058919987 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((98058919987 : ℝ) / 200000000000))
  have h19 : RB z19 ((752102792143 : ℝ) / 250000000000) ((3008415702139 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((98058919987 : ℝ) / 200000000000) ((98058919987 : ℝ) / 200000000000) ((98058919987 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((137676511053 : ℝ) / 125000000000) ((1101413595389 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_946.1 dlower_log_947.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((171806323663 : ℝ) / 200000000000) ((85904965407 : ℝ) / 100000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((298058919987 : ℝ) / 200000000000))
  have h22 : RB z22 ((398973818489 : ℝ) / 1000000000000) ((398973818491 : ℝ) / 1000000000000) := rb_log (show RB ((298058919987 : ℝ) / 200000000000) ((298058919987 : ℝ) / 200000000000) ((298058919987 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_948.1 dlower_log_948.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((28753612489 : ℝ) / 62500000000) ((460075835581 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((20724949 : ℝ) / 500000000000) ((37742983 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((561815505371 : ℝ) / 500000000000) ((28091 : ℝ) / 25000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1262546648301 : ℝ) / 1000000000000) ((789104281 : ℝ) / 625000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((396018634703 : ℝ) / 250000000000) ((1584099884699 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1270655407761 : ℝ) / 1000000000000))
  have h28 : RB z28 ((2012812879037 : ℝ) / 1000000000000) ((2012845084927 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1270655407761 : ℝ) / 1000000000000) ((1270655407761 : ℝ) / 1000000000000) ((1270655407761 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15284626817 : ℝ) / 1000000000000) ((9554281 : ℝ) / 625000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((32732710203099791290869 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((9339053639 : ℝ) / 200000000000) ((9340411781 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((32732710203099791290869 : ℝ) / 100000000000000000000000) ((32732710203099791290869 : ℝ) / 100000000000000000000000) ((32732710203099791290869 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((190659588219 : ℝ) / 200000000000) ((190660946361 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((383762074679 : ℝ) / 200000000000) ((479713685963 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((109819596087 : ℝ) / 500000000000)) ((5343412111 : ℝ) / 500000000000) ((10731819353 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((298058919987 : ℝ) / 200000000000)) ((20724949 : ℝ) / 500000000000) ((37742983 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((109819596087 : ℝ) / 500000000000)) (wl := ((298058919987 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((383762074679 : ℝ) / 200000000000) ≤ D0q (q) * (((298058919987 : ℝ) / 200000000000) - ((109819596087 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((298058919987 : ℝ) / 200000000000) * ((109819596087 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
