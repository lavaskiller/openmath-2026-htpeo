import LeanProject.Radius

/-!
# EP-1038: the expansive quantile map, property (v) (Stage 15, sixth batch)

proof.md Lemma 6.2: `H(y) = |K ∩ [0,y]|` is nondecreasing and 1-Lipschitz, and
`φ(s) = min {y ≥ 0 : H y ≥ s}` satisfies `H (φ s) = s`. Property (v) says that for every `q ≥ 0`,
`|q - φ(s)| ≥ |min (H q) B - s|` for `s ≤ B`. This file proves (v) for an arbitrary monotone
1-Lipschitz `H` and any point `φs` with `H φs = s` that is minimal among points where `H ≥ s`
(the measure-theoretic construction of `H` and `φ` is not formalised here).

Extension to ℝ (Lean RED L-13): Lemma 6.2`s `H` lives on `[0, ∞)`. To apply this theorem, extend it by
`H y = y` for `y < 0`; this keeps `H` monotone and 1-Lipschitz, and keeps `φ(0) = 0` minimal. The zero
extension would make `hmin` fail at `s = 0`.
-/

namespace EP1038

theorem quantile_expansive {H : ℝ → ℝ} (hmono : Monotone H)
    (hlip : ∀ x y, x ≤ y → H y - H x ≤ y - x) {φs s q B : ℝ} (hφ : H φs = s)
    (hmin : ∀ y, s ≤ H y → φs ≤ y) (hsB : s ≤ B) :
    |min (H q) B - s| ≤ |q - φs| := by
  rcases le_or_gt s (min (H q) B) with h | h
  · -- case s ≤ x(q): then φs ≤ q and q - φs ≥ H q - s ≥ x(q) - s ≥ 0
    have hsq : s ≤ H q := le_trans h (min_le_left _ _)
    have hle : φs ≤ q := hmin q hsq
    have h1 : H q - H φs ≤ q - φs := hlip φs q hle
    rw [abs_of_nonneg (by linarith), abs_of_nonneg (by linarith)]
    have : min (H q) B ≤ H q := min_le_left _ _
    linarith
  · -- case s > x(q): then x(q) = H q < s, hence q < φs and φs - q ≥ s - H q
    have hmin_eq : min (H q) B = H q := by
      rcases le_total (H q) B with hb | hb
      · exact min_eq_left hb
      · exfalso
        rw [min_eq_right hb] at h
        linarith
    rw [hmin_eq] at h ⊢
    have hlt : q < φs := by
      by_contra hc
      push_neg at hc
      have := hmono hc
      rw [hφ] at this
      linarith
    have h1 : H φs - H q ≤ φs - q := hlip q φs hlt.le
    rw [abs_of_neg (by linarith), abs_of_neg (by linarith)]
    linarith

end EP1038
