import LeanProject.DLowerMLeaf00
import LeanProject.DLowerMLeaf01
import LeanProject.DLowerMLeaf02
import LeanProject.DLowerMLeaf03
import LeanProject.DLowerMLeaf04
import LeanProject.DLowerMLeaf05
import LeanProject.DLowerMLeaf06
import LeanProject.DLowerMLeaf07
import LeanProject.DLowerMLeaf08
import LeanProject.DLowerMLeaf09
import LeanProject.DLowerMLeaf10
import LeanProject.DLowerMLeaf11
import LeanProject.DLowerMLeaf12
import LeanProject.DLowerMLeaf13
import LeanProject.DLowerMLeaf14
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
/-- Numbered obligation 4: true Lambda lower bound on the complete central region. -/
theorem actual_M_Taylor_lower {q : ℝ} (hq : q ∈ MRegion) : lowerTarget ≤ Lam q := by
  have hlo := hq.1
  rcases le_or_gt q ((19471113219505603606989361234575 : ℝ) / 1298074214633706907132624082305024) with hhi | hnext0
  · exact dlower_M_0 ⟨by norm_num [MRegion, qA, qaIdx, dyad, gridDen] at hlo ⊢; exact hlo, hhi⟩
  rcases le_or_gt q ((103845937170696552570609926584401 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext1
  · exact dlower_M_1 ⟨by exact hnext0.le, hhi⟩
  rcases le_or_gt q ((116826679317033621641936167407451 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext2
  · exact dlower_M_2 ⟨by exact hnext1.le, hhi⟩
  rcases le_or_gt q ((129807421463370690713262408230501 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext3
  · exact dlower_M_3 ⟨by exact hnext2.le, hhi⟩
  rcases le_or_gt q ((133052606999954957981093968436263 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext4
  · exact dlower_M_4 ⟨by exact hnext3.le, hhi⟩
  rcases le_or_gt q ((133458255192027991389572913461983 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext5
  · exact dlower_M_5 ⟨by exact hnext4.le, hhi⟩
  rcases le_or_gt q ((133661079288064508093812385974843 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext6
  · exact dlower_M_6 ⟨by exact hnext5.le, hhi⟩
  rcases le_or_gt q ((133863903384101024798051858487703 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext7
  · exact dlower_M_7 ⟨by exact hnext6.le, hhi⟩
  rcases le_or_gt q ((16834399971030886451876218567393 : ℝ) / 649037107316853453566312041152512) with hhi | hnext8
  · exact dlower_M_8 ⟨by exact hnext7.le, hhi⟩
  rcases le_or_gt q ((68148896268269612624462764321013 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext9
  · exact dlower_M_9 ⟨by exact hnext8.le, hhi⟩
  rcases le_or_gt q ((142788163609707759784588649053551 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext10
  · exact dlower_M_10 ⟨by exact hnext9.le, hhi⟩
  rcases le_or_gt q ((77884452878022414427957444938301 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext11
  · exact dlower_M_11 ⟨by exact hnext10.le, hhi⟩
  rcases le_or_gt q ((90865195024359483499283685761351 : ℝ) / 2596148429267413814265248164610048) with hhi | hnext12
  · exact dlower_M_12 ⟨by exact hnext11.le, hhi⟩
  rcases le_or_gt q ((207691874341393105141219853168803 : ℝ) / 5192296858534827628530496329220096) with hhi | hnext13
  · exact dlower_M_13 ⟨by exact hnext12.le, hhi⟩
  have hlast := hq.2
  exact dlower_M_14 ⟨hnext13.le, by norm_num [MRegion, qB, qbIdx, dyad, gridDen] at hlast ⊢; exact hlast⟩

/-- Numbered obligation 5, now without a missing M certificate. -/
theorem actual_numerical_family_lower : NumericalFamilyLower := by
  apply numerical_family_lower_of_M_bound
  intro q hq hM
  simpa only [dLowerTarget, lowerTarget] using actual_M_Taylor_lower hM

/-- Numbered obligation 6: the requested numerical enclosure of the true infimum D. -/
theorem actual_numerical_D_enclosure : NumericalDEnclosure := by
  apply numerical_enclosure_of_M_bound
  intro q hq hM
  simpa only [dLowerTarget, lowerTarget] using actual_M_Taylor_lower hM

end EP1038.DLowerCert
