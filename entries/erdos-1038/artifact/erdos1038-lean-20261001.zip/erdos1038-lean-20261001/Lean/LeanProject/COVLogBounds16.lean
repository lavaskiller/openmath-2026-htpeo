import LeanProject.COVLogTwo
import LeanProject.COVLogBounds12
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1280 : RB (Real.log ((9871683 : ℝ) / 25000000)) ((-23230137 : ℝ) / 25000000) ((-46460273 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9871683 : ℝ) / 12500000)) (t := ((-2628317 : ℝ) / 22371683))
    (lo := ((-23605829 : ℝ) / 100000000)) (hi := ((-5901457 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9871683 : ℝ) / 25000000) = Real.log ((9871683 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9871683 : ℝ) / 25000000) = ((9871683 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1281 : RB (Real.log ((95636487 : ℝ) / 50000000)) ((3242657 : ℝ) / 5000000) ((32426571 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((95636487 : ℝ) / 100000000)) (t := ((-4363513 : ℝ) / 195636487))
    (lo := ((-2230789 : ℝ) / 50000000)) (hi := ((-4461577 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95636487 : ℝ) / 50000000) = Real.log ((95636487 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95636487 : ℝ) / 50000000) = ((95636487 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1282 : RB (Real.log ((95702419 : ℝ) / 50000000)) ((8115257 : ℝ) / 12500000) ((32461029 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((95702419 : ℝ) / 100000000)) (t := ((-4297581 : ℝ) / 195702419))
    (lo := ((-2196331 : ℝ) / 50000000)) (hi := ((-4392661 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95702419 : ℝ) / 50000000) = Real.log ((95702419 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95702419 : ℝ) / 50000000) = ((95702419 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1283 : RB (Real.log ((13362603 : ℝ) / 20000000)) ((-40327229 : ℝ) / 100000000) ((-10081807 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((13362603 : ℝ) / 20000000)) (t := ((-6637397 : ℝ) / 33362603))
    (lo := ((-40327229 : ℝ) / 100000000)) (hi := ((-10081807 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1284 : RB (Real.log ((1336313 : ℝ) / 2000000)) ((-20161643 : ℝ) / 50000000) ((-8064657 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1336313 : ℝ) / 2000000)) (t := ((-663687 : ℝ) / 3336313))
    (lo := ((-20161643 : ℝ) / 50000000)) (hi := ((-8064657 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1285 : RB (Real.log ((20041573 : ℝ) / 50000000)) ((-3656857 : ℝ) / 4000000) ((-91421423 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20041573 : ℝ) / 25000000)) (t := ((-4958427 : ℝ) / 45041573))
    (lo := ((-11053353 : ℝ) / 50000000)) (hi := ((-4421341 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20041573 : ℝ) / 50000000) = Real.log ((20041573 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20041573 : ℝ) / 50000000) = ((20041573 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1286 : RB (Real.log ((206255093 : ℝ) / 50000000)) ((141709071 : ℝ) / 100000000) ((70854537 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((206255093 : ℝ) / 200000000)) (t := ((6255093 : ℝ) / 406255093))
    (lo := ((615927 : ℝ) / 20000000)) (hi := ((769909 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((206255093 : ℝ) / 50000000) = Real.log ((206255093 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((206255093 : ℝ) / 50000000) = ((206255093 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1287 : RB (Real.log ((412515121 : ℝ) / 100000000)) ((141710267 : ℝ) / 100000000) ((14171027 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((412515121 : ℝ) / 400000000)) (t := ((12515121 : ℝ) / 812515121))
    (lo := ((3080831 : ℝ) / 100000000)) (hi := ((24069 : ℝ) / 781250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((412515121 : ℝ) / 100000000) = Real.log ((412515121 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((412515121 : ℝ) / 100000000) = ((412515121 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1288 : RB (Real.log ((131982673 : ℝ) / 100000000)) ((13875023 : ℝ) / 50000000) ((27750047 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((131982673 : ℝ) / 100000000)) (t := ((31982673 : ℝ) / 231982673))
    (lo := ((13875023 : ℝ) / 50000000)) (hi := ((27750047 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1289 : RB (Real.log ((409479121 : ℝ) / 100000000)) ((35242893 : ℝ) / 25000000) ((5638863 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((409479121 : ℝ) / 400000000)) (t := ((9479121 : ℝ) / 809479121))
    (lo := ((292767 : ℝ) / 12500000)) (hi := ((2342137 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((409479121 : ℝ) / 100000000) = Real.log ((409479121 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((409479121 : ℝ) / 100000000) = ((409479121 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1290 : RB (Real.log ((51185501 : ℝ) / 12500000)) ((70486383 : ℝ) / 50000000) ((140972769 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((51185501 : ℝ) / 50000000)) (t := ((1185501 : ℝ) / 101185501))
    (lo := ((234333 : ℝ) / 10000000)) (hi := ((2343331 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51185501 : ℝ) / 12500000) = Real.log ((51185501 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((51185501 : ℝ) / 12500000) = ((51185501 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1291 : RB (Real.log ((66147957 : ℝ) / 50000000)) ((279871 : ℝ) / 1000000) ((27987101 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66147957 : ℝ) / 50000000)) (t := ((16147957 : ℝ) / 116147957))
    (lo := ((279871 : ℝ) / 1000000)) (hi := ((27987101 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1292 : RB (Real.log ((5488913 : ℝ) / 50000000)) ((-172601 : ℝ) / 78125) ((-55232319 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5488913 : ℝ) / 6250000)) (t := ((-761087 : ℝ) / 11738913))
    (lo := ((-12985123 : ℝ) / 100000000)) (hi := ((-6492561 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5488913 : ℝ) / 50000000) = Real.log ((5488913 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5488913 : ℝ) / 50000000) = ((5488913 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1293 : RB (Real.log ((12676083 : ℝ) / 100000000)) ((-206545323 : ℝ) / 100000000) ((-206545319 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12676083 : ℝ) / 12500000)) (t := ((176083 : ℝ) / 25176083))
    (lo := ((699417 : ℝ) / 50000000)) (hi := ((279767 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12676083 : ℝ) / 100000000) = Real.log ((12676083 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12676083 : ℝ) / 100000000) = ((12676083 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1294 : RB (Real.log ((4247461 : ℝ) / 100000000)) ((-78971221 : ℝ) / 25000000) ((-315884879 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4247461 : ℝ) / 6250000)) (t := ((-2002539 : ℝ) / 10497461))
    (lo := ((-4828251 : ℝ) / 12500000)) (hi := ((-38626007 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4247461 : ℝ) / 100000000) = Real.log ((4247461 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4247461 : ℝ) / 100000000) = ((4247461 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1295 : RB (Real.log ((215891 : ℝ) / 5000000)) ((-157120979 : ℝ) / 50000000) ((-314241953 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((215891 : ℝ) / 312500)) (t := ((-96609 : ℝ) / 528391))
    (lo := ((-18491541 : ℝ) / 50000000)) (hi := ((-36983081 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((215891 : ℝ) / 5000000) = Real.log ((215891 : ℝ) / 312500) - 4 * Real.log 2 := by
    rw [show ((215891 : ℝ) / 5000000) = ((215891 : ℝ) / 312500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1296 : RB (Real.log ((32493563 : ℝ) / 50000000)) ((-43098101 : ℝ) / 100000000) ((-43098099 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32493563 : ℝ) / 25000000)) (t := ((7493563 : ℝ) / 57493563))
    (lo := ((13108309 : ℝ) / 50000000)) (hi := ((26216619 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32493563 : ℝ) / 50000000) = Real.log ((32493563 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32493563 : ℝ) / 50000000) = ((32493563 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1297 : RB (Real.log ((64989777 : ℝ) / 100000000)) ((-21547011 : ℝ) / 50000000) ((-2154701 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((64989777 : ℝ) / 50000000)) (t := ((14989777 : ℝ) / 114989777))
    (lo := ((26220697 : ℝ) / 100000000)) (hi := ((13110349 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64989777 : ℝ) / 100000000) = Real.log ((64989777 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64989777 : ℝ) / 100000000) = ((64989777 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1298 : RB (Real.log ((39421027 : ℝ) / 100000000)) ((-18617417 : ℝ) / 20000000) ((-93087083 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39421027 : ℝ) / 50000000)) (t := ((-10578973 : ℝ) / 89421027))
    (lo := ((-11886183 : ℝ) / 50000000)) (hi := ((-4754473 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39421027 : ℝ) / 100000000) = Real.log ((39421027 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39421027 : ℝ) / 100000000) = ((39421027 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1299 : RB (Real.log ((47785267 : ℝ) / 25000000)) ((32392077 : ℝ) / 50000000) ((16196039 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((47785267 : ℝ) / 50000000)) (t := ((-2214733 : ℝ) / 97785267))
    (lo := ((-1132641 : ℝ) / 25000000)) (hi := ((-4530563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47785267 : ℝ) / 25000000) = Real.log ((47785267 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((47785267 : ℝ) / 25000000) = ((47785267 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1300 : RB (Real.log ((95636489 : ℝ) / 50000000)) ((32426571 : ℝ) / 50000000) ((8106643 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((95636489 : ℝ) / 100000000)) (t := ((-4363511 : ℝ) / 195636489))
    (lo := ((-557697 : ℝ) / 12500000)) (hi := ((-178463 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95636489 : ℝ) / 50000000) = Real.log ((95636489 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95636489 : ℝ) / 50000000) = ((95636489 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1301 : RB (Real.log ((16653191 : ℝ) / 25000000)) ((-40627399 : ℝ) / 100000000) ((-40627397 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16653191 : ℝ) / 12500000)) (t := ((4153191 : ℝ) / 29153191))
    (lo := ((717183 : ℝ) / 2500000)) (hi := ((28687321 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16653191 : ℝ) / 25000000) = Real.log ((16653191 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((16653191 : ℝ) / 25000000) = ((16653191 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1302 : RB (Real.log ((66615441 : ℝ) / 100000000)) ((-2031169 : ℝ) / 5000000) ((-20311689 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((66615441 : ℝ) / 50000000)) (t := ((16615441 : ℝ) / 116615441))
    (lo := ((28691339 : ℝ) / 100000000)) (hi := ((1434567 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66615441 : ℝ) / 100000000) = Real.log ((66615441 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66615441 : ℝ) / 100000000) = ((66615441 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1303 : RB (Real.log ((8002419 : ℝ) / 20000000)) ((-45799421 : ℝ) / 50000000) ((-2289971 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((8002419 : ℝ) / 10000000)) (t := ((-1997581 : ℝ) / 18002419))
    (lo := ((-22284123 : ℝ) / 100000000)) (hi := ((-11142061 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8002419 : ℝ) / 20000000) = Real.log ((8002419 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8002419 : ℝ) / 20000000) = ((8002419 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1304 : RB (Real.log ((205741933 : ℝ) / 50000000)) ((70729981 : ℝ) / 50000000) ((28291993 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((205741933 : ℝ) / 200000000)) (t := ((5741933 : ℝ) / 405741933))
    (lo := ((1415263 : ℝ) / 50000000)) (hi := ((2830527 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((205741933 : ℝ) / 50000000) = Real.log ((205741933 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((205741933 : ℝ) / 50000000) = ((205741933 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1305 : RB (Real.log ((102872217 : ℝ) / 25000000)) ((70730589 : ℝ) / 50000000) ((141461181 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((102872217 : ℝ) / 100000000)) (t := ((2872217 : ℝ) / 202872217))
    (lo := ((1415871 : ℝ) / 50000000)) (hi := ((2831743 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((102872217 : ℝ) / 25000000) = Real.log ((102872217 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((102872217 : ℝ) / 25000000) = ((102872217 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1306 : RB (Real.log ((132087539 : ℝ) / 100000000)) ((27829469 : ℝ) / 100000000) ((2782947 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((132087539 : ℝ) / 100000000)) (t := ((32087539 : ℝ) / 232087539))
    (lo := ((27829469 : ℝ) / 100000000)) (hi := ((2782947 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1307 : RB (Real.log ((408485463 : ℝ) / 100000000)) ((70364307 : ℝ) / 50000000) ((140728617 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((408485463 : ℝ) / 400000000)) (t := ((8485463 : ℝ) / 808485463))
    (lo := ((1049589 : ℝ) / 50000000)) (hi := ((2099179 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((408485463 : ℝ) / 100000000) = Real.log ((408485463 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((408485463 : ℝ) / 100000000) = ((408485463 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1308 : RB (Real.log ((408490417 : ℝ) / 100000000)) ((70364913 : ℝ) / 50000000) ((140729829 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((408490417 : ℝ) / 400000000)) (t := ((8490417 : ℝ) / 808490417))
    (lo := ((210039 : ℝ) / 10000000)) (hi := ((2100391 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((408490417 : ℝ) / 100000000) = Real.log ((408490417 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((408490417 : ℝ) / 100000000) = ((408490417 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1309 : RB (Real.log ((66199711 : ℝ) / 50000000)) ((28065309 : ℝ) / 100000000) ((2806531 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((66199711 : ℝ) / 50000000)) (t := ((16199711 : ℝ) / 116199711))
    (lo := ((28065309 : ℝ) / 100000000)) (hi := ((2806531 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1310 : RB (Real.log ((2221701 : ℝ) / 20000000)) ((-219745919 : ℝ) / 100000000) ((-43949183 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((2221701 : ℝ) / 2500000)) (t := ((-278299 : ℝ) / 4721701))
    (lo := ((-5900881 : ℝ) / 50000000)) (hi := ((-11801761 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2221701 : ℝ) / 20000000) = Real.log ((2221701 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((2221701 : ℝ) / 20000000) = ((2221701 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1311 : RB (Real.log ((12794973 : ℝ) / 100000000)) ((-102805893 : ℝ) / 50000000) ((-102805891 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12794973 : ℝ) / 12500000)) (t := ((294973 : ℝ) / 25294973))
    (lo := ((2332371 : ℝ) / 100000000)) (hi := ((583093 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12794973 : ℝ) / 100000000) = Real.log ((12794973 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12794973 : ℝ) / 100000000) = ((12794973 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1312 : RB (Real.log ((4311867 : ℝ) / 100000000)) ((-78594981 : ℝ) / 25000000) ((-314379919 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4311867 : ℝ) / 6250000)) (t := ((-1938133 : ℝ) / 10561867))
    (lo := ((-4640131 : ℝ) / 12500000)) (hi := ((-37121047 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4311867 : ℝ) / 100000000) = Real.log ((4311867 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4311867 : ℝ) / 100000000) = ((4311867 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1313 : RB (Real.log ((4382321 : ℝ) / 100000000)) ((-156379587 : ℝ) / 50000000) ((-312759169 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4382321 : ℝ) / 6250000)) (t := ((-1867679 : ℝ) / 10632321))
    (lo := ((-17750149 : ℝ) / 50000000)) (hi := ((-35500297 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4382321 : ℝ) / 100000000) = Real.log ((4382321 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4382321 : ℝ) / 100000000) = ((4382321 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1314 : RB (Real.log ((16201739 : ℝ) / 25000000)) ((-21687863 : ℝ) / 50000000) ((-10843931 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((16201739 : ℝ) / 12500000)) (t := ((3701739 : ℝ) / 28701739))
    (lo := ((25938993 : ℝ) / 100000000)) (hi := ((12969497 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16201739 : ℝ) / 25000000) = Real.log ((16201739 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((16201739 : ℝ) / 25000000) = ((16201739 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1315 : RB (Real.log ((1296193 : ℝ) / 2000000)) ((-43371569 : ℝ) / 100000000) ((-43371567 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1296193 : ℝ) / 1000000)) (t := ((296193 : ℝ) / 2296193))
    (lo := ((518863 : ℝ) / 2000000)) (hi := ((25943151 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1296193 : ℝ) / 2000000) = Real.log ((1296193 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((1296193 : ℝ) / 2000000) = ((1296193 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1316 : RB (Real.log ((39355791 : ℝ) / 100000000)) ((-93252707 : ℝ) / 100000000) ((-18650541 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((39355791 : ℝ) / 50000000)) (t := ((-10644209 : ℝ) / 89355791))
    (lo := ((-5984497 : ℝ) / 25000000)) (hi := ((-23937987 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39355791 : ℝ) / 100000000) = Real.log ((39355791 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39355791 : ℝ) / 100000000) = ((39355791 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1317 : RB (Real.log ((191009117 : ℝ) / 100000000)) ((64715097 : ℝ) / 100000000) ((64715099 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((191009117 : ℝ) / 200000000)) (t := ((-8990883 : ℝ) / 391009117))
    (lo := ((-4599621 : ℝ) / 100000000)) (hi := ((-229981 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((191009117 : ℝ) / 100000000) = Real.log ((191009117 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((191009117 : ℝ) / 100000000) = ((191009117 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1318 : RB (Real.log ((7645643 : ℝ) / 4000000)) ((32392079 : ℝ) / 50000000) ((404901 : ℝ) / 625000) := by
  have hm := log_bounds_of_series (x := ((7645643 : ℝ) / 8000000)) (t := ((-354357 : ℝ) / 15645643))
    (lo := ((-7079 : ℝ) / 156250)) (hi := ((-4530559 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7645643 : ℝ) / 4000000) = Real.log ((7645643 : ℝ) / 8000000) + 1 * Real.log 2 := by
    rw [show ((7645643 : ℝ) / 4000000) = ((7645643 : ℝ) / 8000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1319 : RB (Real.log ((66414969 : ℝ) / 100000000)) ((-40924773 : ℝ) / 100000000) ((-40924771 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66414969 : ℝ) / 50000000)) (t := ((16414969 : ℝ) / 116414969))
    (lo := ((14194973 : ℝ) / 50000000)) (hi := ((28389947 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66414969 : ℝ) / 100000000) = Real.log ((66414969 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66414969 : ℝ) / 100000000) = ((66414969 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1320 : RB (Real.log ((66417689 : ℝ) / 100000000)) ((-20460339 : ℝ) / 50000000) ((-10230169 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((66417689 : ℝ) / 50000000)) (t := ((16417689 : ℝ) / 116417689))
    (lo := ((28394041 : ℝ) / 100000000)) (hi := ((14197021 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66417689 : ℝ) / 100000000) = Real.log ((66417689 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66417689 : ℝ) / 100000000) = ((66417689 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1321 : RB (Real.log ((2496361 : ℝ) / 6250000)) ((-91774741 : ℝ) / 100000000) ((-91774739 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2496361 : ℝ) / 3125000)) (t := ((-628639 : ℝ) / 5621361))
    (lo := ((-11230011 : ℝ) / 50000000)) (hi := ((-22460021 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2496361 : ℝ) / 6250000) = Real.log ((2496361 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((2496361 : ℝ) / 6250000) = ((2496361 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1322 : RB (Real.log ((205234281 : ℝ) / 50000000)) ((28242583 : ℝ) / 20000000) ((70606459 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((205234281 : ℝ) / 200000000)) (t := ((5234281 : ℝ) / 405234281))
    (lo := ((2583479 : ℝ) / 100000000)) (hi := ((64587 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((205234281 : ℝ) / 50000000) = Real.log ((205234281 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((205234281 : ℝ) / 50000000) = ((205234281 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1323 : RB (Real.log ((82094727 : ℝ) / 20000000)) ((141214151 : ℝ) / 100000000) ((70607077 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((82094727 : ℝ) / 80000000)) (t := ((2094727 : ℝ) / 162094727))
    (lo := ((516943 : ℝ) / 20000000)) (hi := ((646179 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((82094727 : ℝ) / 20000000) = Real.log ((82094727 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((82094727 : ℝ) / 20000000) = ((82094727 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1324 : RB (Real.log ((132191947 : ℝ) / 100000000)) ((13954241 : ℝ) / 50000000) ((27908483 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((132191947 : ℝ) / 100000000)) (t := ((32191947 : ℝ) / 232191947))
    (lo := ((13954241 : ℝ) / 50000000)) (hi := ((27908483 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1325 : RB (Real.log ((101875557 : ℝ) / 25000000)) ((140487621 : ℝ) / 100000000) ((17560953 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((101875557 : ℝ) / 100000000)) (t := ((1875557 : ℝ) / 201875557))
    (lo := ((371637 : ℝ) / 20000000)) (hi := ((929093 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((101875557 : ℝ) / 25000000) = Real.log ((101875557 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((101875557 : ℝ) / 25000000) = ((101875557 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1326 : RB (Real.log ((407507253 : ℝ) / 100000000)) ((70244427 : ℝ) / 50000000) ((140488857 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((407507253 : ℝ) / 400000000)) (t := ((7507253 : ℝ) / 807507253))
    (lo := ((929709 : ℝ) / 50000000)) (hi := ((1859419 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((407507253 : ℝ) / 100000000) = Real.log ((407507253 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((407507253 : ℝ) / 100000000) = ((407507253 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1327 : RB (Real.log ((16562811 : ℝ) / 12500000)) ((28143123 : ℝ) / 100000000) ((7035781 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((16562811 : ℝ) / 12500000)) (t := ((4062811 : ℝ) / 29062811))
    (lo := ((28143123 : ℝ) / 100000000)) (hi := ((7035781 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1328 : RB (Real.log ((11238429 : ℝ) / 100000000)) ((-43716623 : ℝ) / 20000000) ((-218583111 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11238429 : ℝ) / 12500000)) (t := ((-1261571 : ℝ) / 23738429))
    (lo := ((-5319479 : ℝ) / 50000000)) (hi := ((-10638957 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11238429 : ℝ) / 100000000) = Real.log ((11238429 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((11238429 : ℝ) / 100000000) = ((11238429 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1329 : RB (Real.log ((1291369 : ℝ) / 10000000)) ((-204688223 : ℝ) / 100000000) ((-204688219 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1291369 : ℝ) / 1250000)) (t := ((41369 : ℝ) / 2541369))
    (lo := ((1627967 : ℝ) / 50000000)) (hi := ((651187 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1291369 : ℝ) / 10000000) = Real.log ((1291369 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((1291369 : ℝ) / 10000000) = ((1291369 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1330 : RB (Real.log ((4376271 : ℝ) / 100000000)) ((-78224331 : ℝ) / 25000000) ((-312897319 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4376271 : ℝ) / 6250000)) (t := ((-1873729 : ℝ) / 10626271))
    (lo := ((-2227403 : ℝ) / 6250000)) (hi := ((-35638447 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4376271 : ℝ) / 100000000) = Real.log ((4376271 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4376271 : ℝ) / 100000000) = ((4376271 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1331 : RB (Real.log ((4446821 : ℝ) / 100000000)) ((-311298077 : ℝ) / 100000000) ((-38912259 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4446821 : ℝ) / 6250000)) (t := ((-1803179 : ℝ) / 10696821))
    (lo := ((-34039201 : ℝ) / 100000000)) (hi := ((-42549 : ℝ) / 125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4446821 : ℝ) / 100000000) = Real.log ((4446821 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4446821 : ℝ) / 100000000) = ((4446821 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1332 : RB (Real.log ((64628347 : ℝ) / 100000000)) ((-10912927 : ℝ) / 25000000) ((-21825853 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((64628347 : ℝ) / 50000000)) (t := ((14628347 : ℝ) / 114628347))
    (lo := ((25663011 : ℝ) / 100000000)) (hi := ((6415753 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64628347 : ℝ) / 100000000) = Real.log ((64628347 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64628347 : ℝ) / 100000000) = ((64628347 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1333 : RB (Real.log ((64631081 : ℝ) / 100000000)) ((-21823739 : ℝ) / 50000000) ((-10911869 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((64631081 : ℝ) / 50000000)) (t := ((14631081 : ℝ) / 114631081))
    (lo := ((25667241 : ℝ) / 100000000)) (hi := ((12833621 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64631081 : ℝ) / 100000000) = Real.log ((64631081 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64631081 : ℝ) / 100000000) = ((64631081 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1334 : RB (Real.log ((9822751 : ℝ) / 25000000)) ((-93417461 : ℝ) / 100000000) ((-93417459 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9822751 : ℝ) / 12500000)) (t := ((-2677249 : ℝ) / 22322751))
    (lo := ((-12051371 : ℝ) / 50000000)) (hi := ((-24102741 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9822751 : ℝ) / 25000000) = Real.log ((9822751 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9822751 : ℝ) / 25000000) = ((9822751 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1335 : RB (Real.log ((95438557 : ℝ) / 50000000)) ((12929193 : ℝ) / 20000000) ((64645967 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((95438557 : ℝ) / 100000000)) (t := ((-4561443 : ℝ) / 195438557))
    (lo := ((-4668753 : ℝ) / 100000000)) (hi := ((-291797 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95438557 : ℝ) / 50000000) = Real.log ((95438557 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95438557 : ℝ) / 50000000) = ((95438557 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1336 : RB (Real.log ((1193807 : ℝ) / 625000)) ((32357549 : ℝ) / 50000000) ((647151 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((1193807 : ℝ) / 1250000)) (t := ((-56193 : ℝ) / 2443807))
    (lo := ((-229981 : ℝ) / 5000000)) (hi := ((-4599619 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1193807 : ℝ) / 625000) = Real.log ((1193807 : ℝ) / 1250000) + 1 * Real.log 2 := by
    rw [show ((1193807 : ℝ) / 625000) = ((1193807 : ℝ) / 1250000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1337 : RB (Real.log ((66219511 : ℝ) / 100000000)) ((-8243901 : ℝ) / 20000000) ((-41219503 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66219511 : ℝ) / 50000000)) (t := ((16219511 : ℝ) / 116219511))
    (lo := ((14047607 : ℝ) / 50000000)) (hi := ((5619043 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66219511 : ℝ) / 100000000) = Real.log ((66219511 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66219511 : ℝ) / 100000000) = ((66219511 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1338 : RB (Real.log ((66222271 : ℝ) / 100000000)) ((-41215337 : ℝ) / 100000000) ((-8243067 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((66222271 : ℝ) / 50000000)) (t := ((16222271 : ℝ) / 116222271))
    (lo := ((14049691 : ℝ) / 50000000)) (hi := ((28099383 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66222271 : ℝ) / 100000000) = Real.log ((66222271 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66222271 : ℝ) / 100000000) = ((66222271 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1339 : RB (Real.log ((39872151 : ℝ) / 100000000)) ((-91949209 : ℝ) / 100000000) ((-91949207 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39872151 : ℝ) / 50000000)) (t := ((-10127849 : ℝ) / 89872151))
    (lo := ((-2263449 : ℝ) / 10000000)) (hi := ((-22634489 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39872151 : ℝ) / 100000000) = Real.log ((39872151 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39872151 : ℝ) / 100000000) = ((39872151 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1340 : RB (Real.log ((409464083 : ℝ) / 100000000)) ((1409679 : ℝ) / 1000000) ((140967903 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((409464083 : ℝ) / 400000000)) (t := ((9464083 : ℝ) / 809464083))
    (lo := ((73077 : ℝ) / 3125000)) (hi := ((467693 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((409464083 : ℝ) / 100000000) = Real.log ((409464083 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((409464083 : ℝ) / 100000000) = ((409464083 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1341 : RB (Real.log ((20473461 : ℝ) / 5000000)) ((70484577 : ℝ) / 50000000) ((140969157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20473461 : ℝ) / 20000000)) (t := ((473461 : ℝ) / 40473461))
    (lo := ((1169859 : ℝ) / 50000000)) (hi := ((2339719 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20473461 : ℝ) / 5000000) = Real.log ((20473461 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((20473461 : ℝ) / 5000000) = ((20473461 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1342 : RB (Real.log ((66147951 : ℝ) / 50000000)) ((2798709 : ℝ) / 10000000) ((27987091 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66147951 : ℝ) / 50000000)) (t := ((16147951 : ℝ) / 116147951))
    (lo := ((2798709 : ℝ) / 10000000)) (hi := ((27987091 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1343 : RB (Real.log ((20326461 : ℝ) / 5000000)) ((70124281 : ℝ) / 50000000) ((28049713 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((20326461 : ℝ) / 20000000)) (t := ((326461 : ℝ) / 40326461))
    (lo := ((809563 : ℝ) / 50000000)) (hi := ((1619127 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20326461 : ℝ) / 5000000) = Real.log ((20326461 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((20326461 : ℝ) / 5000000) = ((20326461 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1344 : RB (Real.log ((406534309 : ℝ) / 100000000)) ((140249813 : ℝ) / 100000000) ((17531227 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((406534309 : ℝ) / 400000000)) (t := ((6534309 : ℝ) / 806534309))
    (lo := ((1620377 : ℝ) / 100000000)) (hi := ((810189 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((406534309 : ℝ) / 100000000) = Real.log ((406534309 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((406534309 : ℝ) / 100000000) = ((406534309 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1345 : RB (Real.log ((132605119 : ℝ) / 100000000)) ((28220549 : ℝ) / 100000000) ((564411 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((132605119 : ℝ) / 100000000)) (t := ((32605119 : ℝ) / 232605119))
    (lo := ((28220549 : ℝ) / 100000000)) (hi := ((564411 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1346 : RB (Real.log ((2841891 : ℝ) / 25000000)) ((-108720309 : ℝ) / 50000000) ((-108720307 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2841891 : ℝ) / 3125000)) (t := ((-283109 : ℝ) / 5966891))
    (lo := ((-9496461 : ℝ) / 100000000)) (hi := ((-474823 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2841891 : ℝ) / 25000000) = Real.log ((2841891 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((2841891 : ℝ) / 25000000) = ((2841891 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1347 : RB (Real.log ((260643 : ℝ) / 2000000)) ((-50943771 : ℝ) / 25000000) ((-5094377 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((260643 : ℝ) / 250000)) (t := ((10643 : ℝ) / 510643))
    (lo := ((4169073 : ℝ) / 100000000)) (hi := ((2084537 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((260643 : ℝ) / 2000000) = Real.log ((260643 : ℝ) / 250000) - 3 * Real.log 2 := by
    rw [show ((260643 : ℝ) / 2000000) = ((260643 : ℝ) / 250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1348 : RB (Real.log ((4440677 : ℝ) / 100000000)) ((-311436339 : ℝ) / 100000000) ((-155718167 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4440677 : ℝ) / 6250000)) (t := ((-1809323 : ℝ) / 10690677))
    (lo := ((-34177463 : ℝ) / 100000000)) (hi := ((-17088731 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4440677 : ℝ) / 100000000) = Real.log ((4440677 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4440677 : ℝ) / 100000000) = ((4440677 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1349 : RB (Real.log ((4511323 : ℝ) / 100000000)) ((-309857977 : ℝ) / 100000000) ((-77464493 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4511323 : ℝ) / 6250000)) (t := ((-1738677 : ℝ) / 10761323))
    (lo := ((-32599101 : ℝ) / 100000000)) (hi := ((-325991 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4511323 : ℝ) / 100000000) = Real.log ((4511323 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4511323 : ℝ) / 100000000) = ((4511323 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1350 : RB (Real.log ((64451229 : ℝ) / 100000000)) ((-2196307 : ℝ) / 5000000) ((-21963069 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((64451229 : ℝ) / 50000000)) (t := ((14451229 : ℝ) / 114451229))
    (lo := ((25388579 : ℝ) / 100000000)) (hi := ((1269429 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64451229 : ℝ) / 100000000) = Real.log ((64451229 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64451229 : ℝ) / 100000000) = ((64451229 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1351 : RB (Real.log ((32227003 : ℝ) / 50000000)) ((-5490229 : ℝ) / 12500000) ((-4392183 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((32227003 : ℝ) / 25000000)) (t := ((7227003 : ℝ) / 57227003))
    (lo := ((25392887 : ℝ) / 100000000)) (hi := ((3174111 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32227003 : ℝ) / 50000000) = Real.log ((32227003 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32227003 : ℝ) / 50000000) = ((32227003 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1352 : RB (Real.log ((9806661 : ℝ) / 25000000)) ((-93581399 : ℝ) / 100000000) ((-93581397 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9806661 : ℝ) / 12500000)) (t := ((-2693339 : ℝ) / 22306661))
    (lo := ((-606667 : ℝ) / 2500000)) (hi := ((-24266679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9806661 : ℝ) / 25000000) = Real.log ((9806661 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9806661 : ℝ) / 25000000) = ((9806661 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1353 : RB (Real.log ((95372533 : ℝ) / 50000000)) ((64576761 : ℝ) / 100000000) ((64576763 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((95372533 : ℝ) / 100000000)) (t := ((-4627467 : ℝ) / 195372533))
    (lo := ((-4737957 : ℝ) / 100000000)) (hi := ((-1184489 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95372533 : ℝ) / 50000000) = Real.log ((95372533 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95372533 : ℝ) / 50000000) = ((95372533 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1354 : RB (Real.log ((596491 : ℝ) / 312500)) ((4040373 : ℝ) / 6250000) ((6464597 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((596491 : ℝ) / 625000)) (t := ((-28509 : ℝ) / 1221491))
    (lo := ((-747 : ℝ) / 16000)) (hi := ((-4668749 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((596491 : ℝ) / 312500) = Real.log ((596491 : ℝ) / 625000) + 1 * Real.log 2 := by
    rw [show ((596491 : ℝ) / 312500) = ((596491 : ℝ) / 625000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1355 : RB (Real.log ((1650657 : ℝ) / 2500000)) ((-5188967 : ℝ) / 12500000) ((-20755867 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1650657 : ℝ) / 1250000)) (t := ((400657 : ℝ) / 2900657))
    (lo := ((27802983 : ℝ) / 100000000)) (hi := ((3475373 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1650657 : ℝ) / 2500000) = Real.log ((1650657 : ℝ) / 1250000) - 1 * Real.log 2 := by
    rw [show ((1650657 : ℝ) / 2500000) = ((1650657 : ℝ) / 1250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1356 : RB (Real.log ((66029083 : ℝ) / 100000000)) ((-4150749 : ℝ) / 10000000) ((-1297109 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((66029083 : ℝ) / 50000000)) (t := ((16029083 : ℝ) / 116029083))
    (lo := ((27807229 : ℝ) / 100000000)) (hi := ((2780723 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66029083 : ℝ) / 100000000) = Real.log ((66029083 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66029083 : ℝ) / 100000000) = ((66029083 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1357 : RB (Real.log ((19901593 : ℝ) / 50000000)) ((-23030581 : ℝ) / 25000000) ((-46061161 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19901593 : ℝ) / 25000000)) (t := ((-5098407 : ℝ) / 44901593))
    (lo := ((-4561521 : ℝ) / 20000000)) (hi := ((-5701901 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19901593 : ℝ) / 50000000) = Real.log ((19901593 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19901593 : ℝ) / 50000000) = ((19901593 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1358 : RB (Real.log ((408470219 : ℝ) / 100000000)) ((70362441 : ℝ) / 50000000) ((28144977 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((408470219 : ℝ) / 400000000)) (t := ((8470219 : ℝ) / 808470219))
    (lo := ((1047723 : ℝ) / 50000000)) (hi := ((2095447 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((408470219 : ℝ) / 100000000) = Real.log ((408470219 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((408470219 : ℝ) / 100000000) = ((408470219 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1359 : RB (Real.log ((204237713 : ℝ) / 50000000)) ((35181539 : ℝ) / 25000000) ((140726159 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((204237713 : ℝ) / 200000000)) (t := ((4237713 : ℝ) / 404237713))
    (lo := ((26209 : ℝ) / 1250000)) (hi := ((2096721 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((204237713 : ℝ) / 50000000) = Real.log ((204237713 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((204237713 : ℝ) / 50000000) = ((204237713 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
