import LeanProject.Stage10B4

/-!
# EP-1038, Stage 10 Part (c), N5: log-convex functions on `[0, 1]`

`LCOn f`: `f ≥ 0` on `[0, 1]` and `f((1-λ)t₀ + λt₁) ≤ f(t₀)^(1-λ) f(t₁)^λ`.
Closure under nonnegative constants, products, sums, finite sums, powers; `exp ∘ convex` is LC;
LC implies convex. The sum and integral closures use the normalised weighted AM–GM inequality
(no Hölder inequality needed).
-/

open Real Set Filter Topology MeasureTheory

namespace EP1038.Stage10

/-- `f` is log-convex on `[0, 1]` (with `f ≥ 0`; zero values allowed). -/
def LCOn (f : ℝ → ℝ) : Prop :=
  (∀ t ∈ Icc (0 : ℝ) 1, 0 ≤ f t) ∧
    ∀ t0 ∈ Icc (0 : ℝ) 1, ∀ t1 ∈ Icc (0 : ℝ) 1, ∀ l ∈ Icc (0 : ℝ) 1,
      f ((1 - l) * t0 + l * t1) ≤ f t0 ^ (1 - l) * f t1 ^ l

theorem mid_mem {t0 t1 l : ℝ} (h0 : t0 ∈ Icc (0 : ℝ) 1) (h1 : t1 ∈ Icc (0 : ℝ) 1)
    (hl : l ∈ Icc (0 : ℝ) 1) : (1 - l) * t0 + l * t1 ∈ Icc (0 : ℝ) 1 := by
  obtain ⟨a0, b0⟩ := h0; obtain ⟨a1, b1⟩ := h1; obtain ⟨c0, c1⟩ := hl
  constructor <;> nlinarith

/-- Normalised two-point AM–GM: `a^(1-l) b^l + c^(1-l) d^l ≤ (a+c)^(1-l) (b+d)^l`. -/
theorem rpow_add_le {a b c d l : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (hl : l ∈ Icc (0 : ℝ) 1) :
    a ^ (1 - l) * b ^ l + c ^ (1 - l) * d ^ l ≤ (a + c) ^ (1 - l) * (b + d) ^ l := by
  obtain ⟨hl0, hl1⟩ := hl
  rcases (add_nonneg ha hc).lt_or_eq with hA | hA
  · rcases (add_nonneg hb hd).lt_or_eq with hB | hB
    · set A := a + c
      set B := b + d
      have key : ∀ x y : ℝ, 0 ≤ x → 0 ≤ y →
          x ^ (1 - l) * y ^ l ≤ A ^ (1 - l) * B ^ l * ((1 - l) * (x / A) + l * (y / B)) := by
        intro x y hx hy
        have h := Real.geom_mean_le_arith_mean2_weighted (sub_nonneg.mpr hl1) hl0
          (div_nonneg hx hA.le) (div_nonneg hy hB.le) (by ring)
        rw [Real.div_rpow hx hA.le, Real.div_rpow hy hB.le] at h
        have hApos : 0 < A ^ (1 - l) := Real.rpow_pos_of_pos hA _
        have hBpos : 0 < B ^ l := Real.rpow_pos_of_pos hB _
        have e : x ^ (1 - l) / A ^ (1 - l) * (y ^ l / B ^ l) * (A ^ (1 - l) * B ^ l) =
            x ^ (1 - l) * y ^ l := by field_simp
        calc x ^ (1 - l) * y ^ l = x ^ (1 - l) / A ^ (1 - l) * (y ^ l / B ^ l) *
              (A ^ (1 - l) * B ^ l) := e.symm
          _ ≤ ((1 - l) * (x / A) + l * (y / B)) * (A ^ (1 - l) * B ^ l) :=
              mul_le_mul_of_nonneg_right h (by positivity)
          _ = A ^ (1 - l) * B ^ l * ((1 - l) * (x / A) + l * (y / B)) := by ring
      have h1 := key a b ha hb
      have h2 := key c d hc hd
      have hsum : (1 - l) * (a / A) + l * (b / B) + ((1 - l) * (c / A) + l * (d / B)) = 1 := by
        field_simp
        ring
      calc a ^ (1 - l) * b ^ l + c ^ (1 - l) * d ^ l
          ≤ A ^ (1 - l) * B ^ l * ((1 - l) * (a / A) + l * (b / B)) +
            A ^ (1 - l) * B ^ l * ((1 - l) * (c / A) + l * (d / B)) := add_le_add h1 h2
        _ = A ^ (1 - l) * B ^ l := by rw [← mul_add, hsum, mul_one]
    · -- b = d = 0
      have hb0 : b = 0 := by linarith
      have hd0 : d = 0 := by linarith
      subst hb0; subst hd0
      rcases hl0.lt_or_eq with h | h
      · simp [Real.zero_rpow h.ne']
      · subst h; simp
  · have ha0 : a = 0 := by linarith
    have hc0 : c = 0 := by linarith
    subst ha0; subst hc0
    rcases hl1.lt_or_eq with h | h
    · simp [Real.zero_rpow (show (1 - l) ≠ 0 by linarith)]
    · subst h; simp

theorem LCOn.nonneg {f : ℝ → ℝ} (hf : LCOn f) {t : ℝ} (ht : t ∈ Icc (0 : ℝ) 1) : 0 ≤ f t := hf.1 t ht

theorem LCOn_const {c : ℝ} (hc : 0 ≤ c) : LCOn fun _ => c := by
  refine ⟨fun _ _ => hc, fun t0 _ t1 _ l hl => ?_⟩
  rcases hc.lt_or_eq with h | h
  · rw [← Real.rpow_add h, show 1 - l + l = 1 by ring, Real.rpow_one]
  · rw [← h]; positivity

theorem LCOn_zero : LCOn fun _ => (0 : ℝ) := LCOn_const le_rfl

theorem LCOn.mul {f g : ℝ → ℝ} (hf : LCOn f) (hg : LCOn g) : LCOn fun t => f t * g t := by
  refine ⟨fun t ht => mul_nonneg (hf.1 t ht) (hg.1 t ht), fun t0 h0 t1 h1 l hl => ?_⟩
  have e1 := hf.2 t0 h0 t1 h1 l hl
  have e2 := hg.2 t0 h0 t1 h1 l hl
  rw [Real.mul_rpow (hf.1 t0 h0) (hg.1 t0 h0), Real.mul_rpow (hf.1 t1 h1) (hg.1 t1 h1)]
  calc f ((1 - l) * t0 + l * t1) * g ((1 - l) * t0 + l * t1)
      ≤ (f t0 ^ (1 - l) * f t1 ^ l) * (g t0 ^ (1 - l) * g t1 ^ l) :=
        mul_le_mul e1 e2 (hg.1 _ (mid_mem h0 h1 hl)) (by
          have := hf.1 t0 h0; have := hf.1 t1 h1; positivity)
    _ = f t0 ^ (1 - l) * g t0 ^ (1 - l) * (f t1 ^ l * g t1 ^ l) := by ring

theorem LCOn.add {f g : ℝ → ℝ} (hf : LCOn f) (hg : LCOn g) : LCOn fun t => f t + g t := by
  refine ⟨fun t ht => add_nonneg (hf.1 t ht) (hg.1 t ht), fun t0 h0 t1 h1 l hl => ?_⟩
  calc f ((1 - l) * t0 + l * t1) + g ((1 - l) * t0 + l * t1)
      ≤ f t0 ^ (1 - l) * f t1 ^ l + g t0 ^ (1 - l) * g t1 ^ l :=
        add_le_add (hf.2 t0 h0 t1 h1 l hl) (hg.2 t0 h0 t1 h1 l hl)
    _ ≤ (f t0 + g t0) ^ (1 - l) * (f t1 + g t1) ^ l :=
        rpow_add_le (hf.1 t0 h0) (hf.1 t1 h1) (hg.1 t0 h0) (hg.1 t1 h1) hl

theorem LCOn.smul {f : ℝ → ℝ} (hf : LCOn f) {c : ℝ} (hc : 0 ≤ c) : LCOn fun t => c * f t :=
  (LCOn_const hc).mul hf

theorem LCOn_sum {ι : Type*} (s : Finset ι) {f : ι → ℝ → ℝ} (hf : ∀ i ∈ s, LCOn (f i)) :
    LCOn fun t => ∑ i ∈ s, f i t := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using LCOn_zero
  | insert i s hi ih =>
    simp only [Finset.sum_insert hi]
    exact (hf i (Finset.mem_insert_self i s)).add
      (ih fun j hj => hf j (Finset.mem_insert_of_mem hj))

theorem LCOn.pow {f : ℝ → ℝ} (hf : LCOn f) (n : ℕ) : LCOn fun t => f t ^ n := by
  induction n with
  | zero => simpa using LCOn_const zero_le_one
  | succ n ih => simpa [pow_succ] using ih.mul hf

/-- LC implies convex (weighted AM–GM). -/
theorem LCOn.convex_ineq {f : ℝ → ℝ} (hf : LCOn f) {t0 t1 l : ℝ} (h0 : t0 ∈ Icc (0 : ℝ) 1)
    (h1 : t1 ∈ Icc (0 : ℝ) 1) (hl : l ∈ Icc (0 : ℝ) 1) :
    f ((1 - l) * t0 + l * t1) ≤ (1 - l) * f t0 + l * f t1 :=
  (hf.2 t0 h0 t1 h1 l hl).trans (Real.geom_mean_le_arith_mean2_weighted (sub_nonneg.mpr hl.2) hl.1
    (hf.1 t0 h0) (hf.1 t1 h1) (by ring))

/-- `exp ∘ g` is LC when `g` is convex on `[0,1]`. -/
theorem LCOn_exp {g : ℝ → ℝ}
    (hg : ∀ t0 ∈ Icc (0 : ℝ) 1, ∀ t1 ∈ Icc (0 : ℝ) 1, ∀ l ∈ Icc (0 : ℝ) 1,
      g ((1 - l) * t0 + l * t1) ≤ (1 - l) * g t0 + l * g t1) :
    LCOn fun t => Real.exp (g t) := by
  refine ⟨fun t _ => (Real.exp_pos _).le, fun t0 h0 t1 h1 l hl => ?_⟩
  rw [← Real.exp_mul, ← Real.exp_mul, ← Real.exp_add]
  refine Real.exp_le_exp.mpr ?_
  have := hg t0 h0 t1 h1 l hl
  linarith [mul_comm (g t0) (1 - l), mul_comm (g t1) l]

end EP1038.Stage10
