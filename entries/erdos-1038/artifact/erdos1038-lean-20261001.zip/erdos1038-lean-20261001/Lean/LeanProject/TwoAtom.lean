import LeanProject.AllDegree

/-!
# EP-1038: the witness contradiction (proof.md Lemma 6.3) for the two-atom witness `δ₀ + C δ_B`

Setting of Lemma 6.3 after the shift `g(x) = f(x - M)`: `n ≥ 1` roots `q_j ∈ [a, a + 2]`,
`a > 0`, `|g(0)| = 1` (i.e. `∏ q_j = 1`), and `K = {x : |g(x)| ≤ 1}`. The quantile point `φ(B)`
of Lemma 6.2 is replaced by any `y` with `|g(y)| ≤ 1` and `|K ∩ [0, y]| ≥ B`; both `φ(B)`
(Lemma 6.2(i),(ii)) and `max K` are such points (Math RED M-165). If `C > 0`, `a + 2 < B`
(here `B` is arbitrary; Lemma 6.3 uses `B = 2√2`) and the two-atom potential
`W(t) = log t + C log(B - t)` is positive on `[a, a + 2]`, this is contradictory. Only the
1-Lipschitz property of `H(z) = |K ∩ [0, z]|` and `[0, a] ⊆ K` are used.

Scope (Lean RED L-60): this is the two-atom core of Lemma 6.3 only. The reduction `f ↦ g`, the
witness inequality `hW` (Lemma 6.4, certified numerically) and the Lemma 6.6 branch are not
formalised, so the bound of Theorem 6.7 is not formal end to end.
-/

open Real MeasureTheory

namespace EP1038

theorem two_atom_contradiction {n : ℕ} (hn : 0 < n) (q : Fin n → ℝ) {a C B y : ℝ}
    (ha : 0 < a) (hq : ∀ j, q j ∈ Set.Icc a (a + 2)) (hB : a + 2 < B) (hC : 0 < C)
    (h0 : ∏ j, q j = 1)
    (hy : |∏ j, (y - q j)| ≤ 1)
    (hvol : ENNReal.ofReal B ≤ volume (Set.Icc 0 y ∩ {x | |∏ j, (x - q j)| ≤ 1}))
    (hW : ∀ t ∈ Set.Icc a (a + 2), 0 < Real.log t + C * Real.log (B - t)) : False := by
  set K : Set ℝ := {x | |∏ j, (x - q j)| ≤ 1} with hK
  have hqpos : ∀ j, 0 < q j := fun j => lt_of_lt_of_le ha (hq j).1
  -- [0, a] ⊆ K
  have hsubK : Set.Icc 0 a ⊆ K := by
    intro x hx
    obtain ⟨hx0, hxa⟩ := hx
    change |∏ j, (x - q j)| ≤ 1
    rw [Finset.abs_prod, ← h0]
    gcongr with j
    rw [abs_of_nonpos (by linarith [(hq j).1])]; linarith
  -- finiteness of the relevant volumes
  have hfin : ∀ z : ℝ, volume (Set.Icc 0 z ∩ K) ≠ ⊤ := fun z =>
    ne_top_of_le_ne_top (by simp [Real.volume_Icc]) (measure_mono Set.inter_subset_left)
  -- the quantities t_j = |K ∩ [0, q_j]|
  set t : Fin n → ℝ := fun j => (volume (Set.Icc 0 (q j) ∩ K)).toReal with ht
  have ht_eq : ∀ j, volume (Set.Icc 0 (q j) ∩ K) = ENNReal.ofReal (t j) := fun j =>
    (ENNReal.ofReal_toReal (hfin (q j))).symm
  have ht_le : ∀ j, t j ≤ q j := by
    intro j
    apply ENNReal.toReal_le_of_le_ofReal (hqpos j).le
    calc volume (Set.Icc 0 (q j) ∩ K) ≤ volume (Set.Icc 0 (q j)) :=
          measure_mono Set.inter_subset_left
      _ = ENNReal.ofReal (q j) := by rw [Real.volume_Icc, sub_zero]
  have ht_ge : ∀ j, a ≤ t j := by
    intro j
    have h1 : Set.Icc 0 a ⊆ Set.Icc 0 (q j) ∩ K := fun x hx =>
      ⟨⟨hx.1, hx.2.trans (hq j).1⟩, hsubK hx⟩
    have h2 : ENNReal.ofReal a ≤ ENNReal.ofReal (t j) := by
      rw [← ht_eq j]
      calc ENNReal.ofReal a = volume (Set.Icc 0 a) := by rw [Real.volume_Icc, sub_zero]
        _ ≤ _ := measure_mono h1
    have htn : 0 ≤ t j := ENNReal.toReal_nonneg
    exact (ENNReal.ofReal_le_ofReal_iff htn).mp h2
  -- y is far to the right: y - q_j ≥ B - t_j
  have hgap : ∀ j, B - t j ≤ y - q j := by
    intro j
    have hsub : Set.Icc 0 y ∩ K ⊆ (Set.Icc 0 (q j) ∩ K) ∪ Set.Icc (q j) y := by
      rintro x ⟨⟨hx0, hxy⟩, hxK⟩
      rcases le_total x (q j) with h | h
      · exact Or.inl ⟨⟨hx0, h⟩, hxK⟩
      · exact Or.inr ⟨h, hxy⟩
    have h1 : ENNReal.ofReal B ≤ ENNReal.ofReal (t j) + ENNReal.ofReal (y - q j) := by
      calc ENNReal.ofReal B ≤ volume (Set.Icc 0 y ∩ K) := hvol
        _ ≤ volume ((Set.Icc 0 (q j) ∩ K) ∪ Set.Icc (q j) y) := measure_mono hsub
        _ ≤ volume (Set.Icc 0 (q j) ∩ K) + volume (Set.Icc (q j) y) := measure_union_le _ _
        _ = ENNReal.ofReal (t j) + ENNReal.ofReal (y - q j) := by rw [ht_eq j, Real.volume_Icc]
    have htn : 0 ≤ t j := ENNReal.toReal_nonneg
    by_cases hyq : q j ≤ y
    · rw [← ENNReal.ofReal_add htn (by linarith)] at h1
      have := (ENNReal.ofReal_le_ofReal_iff (by linarith)).mp h1
      linarith
    · push Not at hyq
      rw [ENNReal.ofReal_of_nonpos (by linarith : y - q j ≤ 0), add_zero] at h1
      have := (ENNReal.ofReal_le_ofReal_iff htn).mp h1
      linarith [ht_le j, (hq j).2]
  have hyq : ∀ j, q j < y := by
    intro j
    have := hgap j
    linarith [ht_le j, (hq j).2]
  -- the two-sided estimate
  have hterm : ∀ j, 0 < Real.log (q j) + C * Real.log (y - q j) := by
    intro j
    have hta : a ≤ t j := ht_ge j
    have htq : t j ≤ q j := ht_le j
    have hW' := hW (t j) ⟨hta, htq.trans (hq j).2⟩
    have hBt : 0 < B - t j := by linarith [(hq j).2]
    have l1 : Real.log (t j) ≤ Real.log (q j) := Real.log_le_log (by linarith) htq
    have l2 : Real.log (B - t j) ≤ Real.log (y - q j) := Real.log_le_log hBt (hgap j)
    nlinarith
  have hsum_pos : 0 < ∑ j, (Real.log (q j) + C * Real.log (y - q j)) := by
    have : Nonempty (Fin n) := ⟨⟨0, hn⟩⟩
    exact Finset.sum_pos (fun j _ => hterm j) Finset.univ_nonempty
  have hlogq : ∑ j, Real.log (q j) = 0 := by
    rw [← Real.log_prod (fun j _ => (hqpos j).ne'), h0, Real.log_one]
  have hlogy : ∑ j, Real.log (y - q j) ≤ 0 := by
    rw [← Real.log_prod (fun j _ => (sub_pos.mpr (hyq j)).ne')]
    have hp : 0 < ∏ j, (y - q j) := Finset.prod_pos (fun j _ => sub_pos.mpr (hyq j))
    rw [abs_of_pos hp] at hy
    exact Real.log_nonpos hp.le hy
  rw [Finset.sum_add_distrib, ← Finset.mul_sum, hlogq, zero_add] at hsum_pos
  nlinarith

end EP1038
