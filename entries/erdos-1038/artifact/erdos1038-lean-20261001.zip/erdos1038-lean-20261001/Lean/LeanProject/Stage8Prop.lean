import LeanProject.Stage8

/-!
# EP-1038: Proposition 8.1 (small mass ratio), modulo two certified numeric facts

Setting (proof.md Stage 7 normal form): residual atoms `d i ∈ [1,2]`, pairwise distinct, with masses
`q i > 0`, `∑ q = 1`; mass ratio `1 ≤ k ≤ K`; a separating point `b ∈ (0, min d)` with
`k log b + ∑ q_i log (d_i - b) ≥ 0`. Radii `R_i = exp(-(k log d_i + ∑_{j≠i} q_j log|d_i - d_j|)/q_i)`.
Conclusion: `∑ R_i > 1/3`.
The numeric hypotheses `0 < ε` and `0 < log 3 - K log 2 - 6 ε / e` with
`ε = 2 - (K+1) K^(-K/(K+1))` are proved in Lean for `K = 29/20` in NumericK.lean
(`eps_pos`, `num_pos`), giving `prop81_full`.
-/

open Real Finset

namespace EP1038

variable {N : ℕ}

/-- `∑_{j ≠ i} f j = ∑ f - f i`. -/
theorem sum_ne (f : Fin N → ℝ) (i : Fin N) :
    ∑ j, (if i = j then 0 else f j) = ∑ j, f j - f i := by
  have : ∑ j, (if i = j then f j else 0) = f i := by simp
  have h2 : ∑ j, ((if i = j then 0 else f j) + (if i = j then f j else 0)) = ∑ j, f j := by
    apply sum_congr rfl; intro j _; split_ifs <;> ring
  rw [sum_add_distrib, this] at h2
  linarith

theorem prop81 (q d : Fin N → ℝ) (k K b ε : ℝ)
    (hq : ∀ i, 0 < q i) (hq1 : ∑ i, q i = 1)
    (hd1 : ∀ i, 1 ≤ d i) (hd2 : ∀ i, d i ≤ 2) (hdist : ∀ i j, i ≠ j → d i ≠ d j)
    (hk1 : 1 ≤ k) (hkK : k ≤ K) (hb0 : 0 < b) (hbd : ∀ i, b < d i)
    (hsep : 0 ≤ k * Real.log b + ∑ i, q i * Real.log (d i - b))
    (hε : ε = 2 - (K + 1) * K ^ (-K / (K + 1))) (hε0 : 0 < ε)
    (hnum : 0 < Real.log 3 - K * Real.log 2 - 6 * ε / Real.exp 1) :
    1 / 3 < ∑ i, Real.exp (-(k * Real.log (d i) +
      ∑ j, (if i = j then 0 else q j * Real.log |d i - d j|)) / q i) := by
  have hK : 0 < K := by linarith
  have hN : 0 < N := by
    rcases Nat.eq_zero_or_pos N with h | h
    · subst h; simp at hq1
    · exact h
  haveI : NeZero N := ⟨hN.ne'⟩
  -- Step 1: Jensen for the separating point
  set m := ∑ i, q i * d i with hm
  have hsumeq : ∑ i, q i * (d i - b) = m - b := by
    simp only [mul_sub, sum_sub_distrib, ← sum_mul, hq1, one_mul, hm]
  have hmb : 0 < m - b := by
    rw [← hsumeq]
    exact sum_pos (fun i _ => mul_pos (hq i) (by linarith [hbd i])) univ_nonempty
  have hjen : ∑ i, q i * Real.log (d i - b) ≤ Real.log (m - b) := by
    have hc := (strictConcaveOn_log_Ioi).concaveOn.le_map_sum (t := univ) (w := q)
      (p := fun i => d i - b) (fun i _ => (hq i).le) hq1 (fun i _ => by
        simp only [Set.mem_Ioi]; linarith [hbd i])
    simp only [smul_eq_mul] at hc
    rw [hsumeq] at hc; exact hc
  have hsep' : 0 ≤ k * Real.log b + Real.log (m - b) := by linarith
  -- Step 2: b ≥ 1
  have hb1 : 1 ≤ b := by
    by_contra hlt
    push_neg at hlt
    have hlogb : Real.log b < 0 := Real.log_neg hb0 hlt
    have h1 : k * Real.log b ≤ Real.log b := by nlinarith
    have h2 : 0 ≤ Real.log b + Real.log (m - b) := by linarith
    rw [← Real.log_mul hb0.ne' hmb.ne'] at h2
    have h3 : 1 ≤ b * (m - b) := by
      by_contra h; push_neg at h
      have := Real.log_neg (by positivity) h; linarith
    have hm2 : m ≤ 2 := by
      calc m = ∑ i, q i * d i := rfl
        _ ≤ ∑ i, q i * 2 := sum_le_sum fun i _ => mul_le_mul_of_nonneg_left (hd2 i) (hq i).le
        _ = 2 := by rw [← sum_mul, hq1, one_mul]
    nlinarith [sq_nonneg (1 - b)]
  -- Step 3: ȳ = 2 - m ≤ ε
  have hmlow : b + b ^ (-k) ≤ m := by
    have h1 : -(k * Real.log b) ≤ Real.log (m - b) := by linarith
    have h2 : b ^ (-k) ≤ m - b := by
      rw [Real.rpow_def_of_pos hb0]
      calc Real.exp (Real.log b * -k) = Real.exp (-(k * Real.log b)) := by ring_nf
        _ ≤ Real.exp (Real.log (m - b)) := Real.exp_le_exp.mpr h1
        _ = m - b := Real.exp_log hmb
    linarith
  have hbk : b ^ (-K) ≤ b ^ (-k) := Real.rpow_le_rpow_of_exponent_le hb1 (by linarith)
  have hye : 2 - m ≤ ε := by
    have := amgm_eps hb0 hK
    rw [hε]; linarith
  -- Step 4: notation
  set Q := ∑ i, q i ^ 2 with hQ
  set t := ∑ i, ∑ j, (if i = j then 0 else q i * q j) with ht
  set P2 := ∑ i, ∑ j, (if i = j then 0 else q i * q j * Real.log |d i - d j|) with hP2
  have hQpos : 0 < Q := sum_pos (fun i _ => by have := hq i; positivity) univ_nonempty
  have ht_eq : t = 1 - Q := by
    have : ∀ i, ∑ j, (if i = j then 0 else q i * q j) = q i * (1 - q i) := by
      intro i
      have h := sum_ne q i
      rw [hq1] at h
      rw [← h, mul_sum]
      apply sum_congr rfl; intro j _; split_ifs <;> simp
    rw [ht, sum_congr rfl (fun i _ => this i)]
    simp only [mul_sub, mul_one, sum_sub_distrib, hq1, hQ, sq]
  have ht0 : 0 ≤ t := sum_nonneg fun i _ => sum_nonneg fun j _ => by
    split_ifs
    · exact le_refl _
    · exact (mul_pos (hq i) (hq j)).le
  -- Step 5: exact identity for ∑ q_i^2 log R_i
  set lR : Fin N → ℝ := fun i => -(k * Real.log (d i) +
      ∑ j, (if i = j then 0 else q j * Real.log |d i - d j|)) / q i with hlR
  have hident : ∑ i, q i ^ 2 * lR i = -k * ∑ i, q i * Real.log (d i) - P2 := by
    have : ∀ i, q i ^ 2 * lR i = -(k * (q i * Real.log (d i))) -
        ∑ j, (if i = j then 0 else q i * q j * Real.log |d i - d j|) := by
      intro i
      have hqi := (hq i).ne'
      have hsum : ∑ j, (if i = j then 0 else q i * q j * Real.log |d i - d j|) =
          q i * ∑ j, (if i = j then 0 else q j * Real.log |d i - d j|) := by
        rw [mul_sum]; apply sum_congr rfl; intro j _
        split_ifs
        · ring
        · ring
      rw [hsum]; simp only [hlR]; field_simp; ring
    rw [sum_congr rfl (fun i _ => this i), sum_sub_distrib, sum_neg_distrib, ← mul_sum, hP2]
    ring
  have hlogd : ∑ i, q i * Real.log (d i) ≤ Real.log 2 := by
    calc ∑ i, q i * Real.log (d i) ≤ ∑ i, q i * Real.log 2 :=
          sum_le_sum fun i _ => mul_le_mul_of_nonneg_left
            (Real.log_le_log (by linarith [hd1 i]) (hd2 i)) (hq i).le
      _ = Real.log 2 := by rw [← sum_mul, hq1, one_mul]
  -- Step 6: the pair term, P2 ≤ t log(2ε/t)  (read as 0 when t = 0)
  have hpair : P2 ≤ t * Real.log (2 * ε / t) := by
    rcases eq_or_lt_of_le ht0 with h0 | htpos
    · -- t = 0: every off-diagonal pair is absent
      have hoff : ∀ i j : Fin N, i ≠ j → False := by
        intro i j hij
        have hnn : ∀ i ∈ (univ : Finset (Fin N)), 0 ≤ ∑ j, (if i = j then 0 else q i * q j) :=
          fun i _ => sum_nonneg fun j _ => by
            split_ifs
            · exact le_refl _
            · exact (mul_pos (hq i) (hq j)).le
        have hzero := (sum_eq_zero_iff_of_nonneg hnn).mp (by rw [← ht, ← h0]) i (mem_univ i)
        have hnn2 : ∀ j ∈ (univ : Finset (Fin N)), 0 ≤ (if i = j then 0 else q i * q j) :=
          fun j _ => by
            split_ifs
            · exact le_refl _
            · exact (mul_pos (hq i) (hq j)).le
        have := (sum_eq_zero_iff_of_nonneg hnn2).mp hzero j (mem_univ j)
        rw [if_neg hij] at this
        exact absurd this (mul_pos (hq i) (hq j)).ne'
      have hP0 : P2 = 0 := by
        rw [hP2]; apply sum_eq_zero; intro i _; apply sum_eq_zero; intro j _
        split_ifs with hij
        · rfl
        · exact (hoff i j hij).elim
      rw [hP0, ← h0, zero_mul]
    · -- t > 0: Jensen with weights q_i q_j / t on off-diagonal pairs
      set w : Fin N × Fin N → ℝ := fun p => if p.1 = p.2 then 0 else q p.1 * q p.2 / t with hw
      set pt : Fin N × Fin N → ℝ := fun p => if p.1 = p.2 then 1 else |d p.1 - d p.2| with hpt
      have hw0 : ∀ p ∈ (univ : Finset (Fin N × Fin N)), 0 ≤ w p := by
        intro p _; simp only [hw]; split_ifs
        · exact le_refl _
        · exact div_nonneg (mul_pos (hq _) (hq _)).le htpos.le
      have hw1 : ∑ p, w p = 1 := by
        rw [Fintype.sum_prod_type]
        have : ∑ i, ∑ j, w (i, j) = t / t := by
          rw [ht, sum_div]; apply sum_congr rfl; intro i _; rw [sum_div]
          apply sum_congr rfl; intro j _; simp only [hw]; split_ifs <;> first | rfl | simp
        rw [this, div_self htpos.ne']
      have hpt0 : ∀ p ∈ (univ : Finset (Fin N × Fin N)), pt p ∈ Set.Ioi (0 : ℝ) := by
        intro p _; simp only [hpt, Set.mem_Ioi]; split_ifs with h
        · exact one_pos
        · exact abs_pos.mpr (sub_ne_zero.mpr (hdist _ _ h))
      have hc := (strictConcaveOn_log_Ioi).concaveOn.le_map_sum (t := univ) hw0 hw1 hpt0
      simp only [smul_eq_mul] at hc
      have hL : ∑ p, w p * Real.log (pt p) = P2 / t := by
        rw [Fintype.sum_prod_type, hP2, sum_div]; apply sum_congr rfl; intro i _; rw [sum_div]
        apply sum_congr rfl; intro j _; simp only [hw, hpt]
        split_ifs
        · simp
        · ring
      set S2 := ∑ i, ∑ j, (if i = j then 0 else q i * q j * |d i - d j|) with hS2
      have hR : ∑ p, w p * pt p = S2 / t := by
        rw [Fintype.sum_prod_type, hS2, sum_div]; apply sum_congr rfl; intro i _; rw [sum_div]
        apply sum_congr rfl; intro j _; simp only [hw, hpt]
        split_ifs
        · simp
        · ring
      rw [hL, hR] at hc
      have hSpos : 0 < S2 / t := by
        rw [← hR]
        have hpos : ∀ p ∈ (univ : Finset (Fin N × Fin N)), 0 ≤ w p * pt p := fun p hp =>
          mul_nonneg (hw0 p hp) (le_of_lt (hpt0 p hp))
        by_contra hle; push_neg at hle
        have hz : ∑ p, w p * pt p = 0 := le_antisymm hle (sum_nonneg hpos)
        have := (sum_eq_zero_iff_of_nonneg hpos).mp hz
        have hsum0 : ∑ p, w p = 0 := by
          apply sum_eq_zero; intro p hp
          have h1 := this p hp
          rcases mul_eq_zero.mp h1 with h | h
          · exact h
          · exact absurd h (ne_of_gt (hpt0 p hp))
        rw [hw1] at hsum0; exact one_ne_zero hsum0
      -- S2 ≤ 2 ε via |d_i - d_j| ≤ y_i + y_j, y = 2 - d
      have hS2le : S2 ≤ 2 * ε := by
        have h1 : S2 ≤ ∑ i, ∑ j, q i * q j * ((2 - d i) + (2 - d j)) := by
          apply sum_le_sum; intro i _; apply sum_le_sum; intro j _
          have hqq := (mul_pos (hq i) (hq j)).le
          split_ifs
          · have := hd2 i; have := hd2 j; positivity
          · apply mul_le_mul_of_nonneg_left _ hqq
            rw [abs_le]; constructor <;> linarith [hd1 i, hd1 j, hd2 i, hd2 j]
        have h2 : ∑ i, ∑ j, q i * q j * ((2 - d i) + (2 - d j)) = 2 * (2 - m) := by
          have e1 : ∀ i, ∑ j, q i * q j * ((2 - d i) + (2 - d j)) =
              q i * (2 - d i) + q i * (2 - m) := by
            intro i
            have : ∑ j, q i * q j * ((2 - d i) + (2 - d j)) =
                q i * (2 - d i) * ∑ j, q j + q i * ∑ j, q j * (2 - d j) := by
              rw [mul_sum, mul_sum, ← sum_add_distrib]; apply sum_congr rfl; intro j _; ring
            rw [this, hq1]
            have : ∑ j, q j * (2 - d j) = 2 - m := by
              simp only [mul_sub, sum_sub_distrib, ← sum_mul, hq1, hm]; ring
            rw [this]; ring
          rw [sum_congr rfl (fun i _ => e1 i), sum_add_distrib, ← sum_mul, hq1]
          have : ∑ i, q i * (2 - d i) = 2 - m := by
            simp only [mul_sub, sum_sub_distrib, ← sum_mul, hq1, hm]; ring
          rw [this]; ring
        linarith
      have hlogmono : Real.log (S2 / t) ≤ Real.log (2 * ε / t) :=
        Real.log_le_log hSpos (div_le_div_of_nonneg_right hS2le htpos.le)
      have : P2 = t * (P2 / t) := by field_simp
      rw [this]
      exact mul_le_mul_of_nonneg_left (le_trans hc hlogmono) htpos.le
  -- Step 7: AM–GM with weights q_i^2 / Q
  have hRpos : ∀ i, 0 < Real.exp (lR i) := fun i => Real.exp_pos _
  set SR := ∑ i, Real.exp (lR i) with hSR
  have hSRpos : 0 < SR := sum_pos (fun i _ => hRpos i) univ_nonempty
  have hamgm : (∑ i, q i ^ 2 * lR i) / Q ≤ Real.log SR := by
    have hv0 : ∀ i ∈ (univ : Finset (Fin N)), 0 ≤ q i ^ 2 / Q := fun i _ => by positivity
    have hv1 : ∑ i, q i ^ 2 / Q = 1 := by rw [← sum_div, div_self hQpos.ne']
    have hc := (strictConcaveOn_log_Ioi).concaveOn.le_map_sum (t := univ) hv0 hv1
      (p := fun i => Real.exp (lR i)) (fun i _ => hRpos i)
    simp only [smul_eq_mul, Real.log_exp] at hc
    have hlhs : ∑ i, q i ^ 2 / Q * lR i = (∑ i, q i ^ 2 * lR i) / Q := by
      rw [sum_div]; apply sum_congr rfl; intro i _; ring
    rw [hlhs] at hc
    have hle : ∑ i, q i ^ 2 / Q * Real.exp (lR i) ≤ SR := by
      apply sum_le_sum; intro i _
      have : q i ^ 2 / Q ≤ 1 := by
        rw [div_le_one hQpos]
        exact single_le_sum (f := fun j => q j ^ 2) (fun j _ => by have := hq j; positivity) (mem_univ i)
      nlinarith [hRpos i]
    have hpos : 0 < ∑ i, q i ^ 2 / Q * Real.exp (lR i) :=
      sum_pos (fun i _ => by have := hq i; positivity) univ_nonempty
    exact le_trans hc (Real.log_le_log hpos hle)
  -- Step 8: conclude
  have hmain : 0 < Q * Real.log (3 * SR) := by
    rw [Real.log_mul (by norm_num) hSRpos.ne', mul_add]
    have h1 : Q * Real.log SR ≥ ∑ i, q i ^ 2 * lR i := by
      have := mul_le_mul_of_nonneg_left hamgm hQpos.le
      rwa [mul_div_cancel₀ _ hQpos.ne'] at this
    have h2 : ∑ i, q i ^ 2 * lR i ≥ -K * Real.log 2 - t * Real.log (2 * ε / t) := by
      rw [hident]
      have hl2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
      nlinarith [hlogd, hpair]
    have h3 : t * Real.log 3 + t * Real.log (2 * ε / t) ≤ 6 * ε / Real.exp 1 := by
      rcases eq_or_lt_of_le ht0 with h0 | htpos
      · rw [← h0]; simp; positivity
      · rw [← mul_add, ← Real.log_mul (by norm_num) (by positivity)]
        have : 3 * (2 * ε / t) = 6 * ε / t := by ring
        rw [this]; exact tlog_le htpos (by linarith)
    have hQt : Q = 1 - t := by linarith
    rw [hQt] at h1 ⊢
    nlinarith [hnum]
  have hlog3 : 0 < Real.log (3 * SR) := by
    by_contra h; push_neg at h
    have := mul_nonpos_of_nonneg_of_nonpos hQpos.le h
    linarith
  have : 1 < 3 * SR := by
    by_contra h; push_neg at h
    have := Real.log_nonpos (by positivity) h
    linarith
  simp only [hSR, hlR] at this
  linarith

end EP1038