import LeanProject.Stage10C13

/-!
# The negative main component of the logarithmic potential

`Real.log 0 = 0` in Lean, while the potential of a positive atom at zero is
`-∞` in the paper.  For questions about the negative sublevel set we must
insert zero explicitly.  The following theorem identifies the resulting set
on the whole interval to the left of a strict separation witness `r`.

The theorem is local to `(-∞, r)`: the potential can have other negative
components to the right of `r`.
-/

open Real Set MeasureTheory

namespace EP1038.Stage10

/-- The negative sublevel set with the atom at zero given its correct sign.
This is used only when `k > 0`, so that the logarithmic atom has potential
`-∞` at zero. -/
def correctedNegSet (k : ℝ) (S : ℝ → ℝ) : Set ℝ :=
  {x | x = 0 ∨ WS k S x < 0}

/-- In the strictly separated case, the corrected negative sublevel set
to the left of the separation witness is exactly the interval bounded by
the two zeroes of the potential. -/
theorem correctedNegSet_sep {k a r : ℝ} {S : ℝ → ℝ}
    (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
    (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
    (hr0 : 0 < r) (hra : r < a)
    (hsep : RS k S < PsiS k S r) :
    correctedNegSet k S ∩ Iio r = Ioo (xmS k S) (xpS k S) := by
  obtain ⟨hxp0, -, -, hxm0, -⟩ :=
    sep_series hSm ha hSa hS2 hk hr0 hra hsep
  have hxr := xp_lt_r hSm ha hSa hS2 hk hr0 hra hsep
  ext x
  simp only [correctedNegSet, Set.mem_inter_iff, Set.mem_ofPred_eq,
    Set.mem_Iio, Set.mem_Ioo]
  constructor
  · rintro ⟨hx, hxr'⟩
    rcases hx with rfl | hneg
    · exact ⟨hxm0, hxp0⟩
    · constructor
      · by_contra h
        have hle : x ≤ xmS k S := le_of_not_gt h
        rcases hle.lt_or_eq with hlt | heq
        · exact (not_lt_of_ge (W_left_pos hSm ha hSa hS2 hk hr0 hra hsep hlt).le) hneg
        · rw [heq, W_xm_zero hSm ha hSa hS2 hk hr0 hra hsep] at hneg
          exact (lt_irrefl 0) hneg
      · by_contra h
        have hle : xpS k S ≤ x := le_of_not_gt h
        rcases hle.lt_or_eq with hlt | heq
        · exact (not_lt_of_ge (W_right_pos hSm ha hSa hS2 hk hr0 hra hsep hlt hxr'.le).le) hneg
        · rw [← heq, W_xp_zero hSm ha hSa hS2 hk hr0 hra hsep] at hneg
          exact (lt_irrefl 0) hneg
  · rintro ⟨hxm, hxp⟩
    refine ⟨?_, hxp.trans hxr⟩
    by_cases hx0 : x = 0
    · exact Or.inl hx0
    · exact Or.inr (W_mid_neg hSm ha hSa hS2 hk hr0 hra hsep hxm hxp hx0)

/-- The interval in `correctedNegSet_sep` has the expected Lebesgue length. -/
theorem volume_correctedNegSet_sep {k a r : ℝ} {S : ℝ → ℝ}
    (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
    (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
    (hr0 : 0 < r) (hra : r < a)
    (hsep : RS k S < PsiS k S r) :
    (volume (correctedNegSet k S ∩ Iio r)).toReal = xpS k S - xmS k S := by
  rw [correctedNegSet_sep hSm ha hSa hS2 hk hr0 hra hsep, Real.volume_Ioo,
    ENNReal.toReal_ofReal]
  obtain ⟨hxp0, -, -, hxm0, -⟩ :=
    sep_series hSm ha hSa hS2 hk hr0 hra hsep
  linarith

/-- The convex supporting inequality stated for the length of the actual
negative component, with the atom at zero included. -/
theorem convex_supporting_sep_component
    {T0 T : ℝ → ℝ} {a0 a1 k r0 r1 : ℝ}
    (hm0 : Measurable T0) (hm1 : Measurable T)
    (ha0 : 0 < a0) (h0a : ∀ u, a0 ≤ T0 u) (h02 : ∀ u, T0 u ≤ 2)
    (ha1 : 0 < a1) (h1a : ∀ u, a1 ≤ T u) (h12 : ∀ u, T u ≤ 2)
    (hk : 0 < k) (hr0 : 0 < r0) (hr0a : r0 < a0)
    (hsep0 : RS k T0 < PsiS k T0 r0)
    (hr1 : 0 < r1) (hr1a : r1 < a1)
    (hsep1 : RS k T < PsiS k T r1) :
    (volume (correctedNegSet k T0 ∩ Iio r0)).toReal + Mdot k T0 T ≤
      (volume (correctedNegSet k T ∩ Iio r1)).toReal := by
  rw [volume_correctedNegSet_sep hm0 ha0 h0a h02 hk hr0 hr0a hsep0,
    volume_correctedNegSet_sep hm1 ha1 h1a h12 hk hr1 hr1a hsep1]
  exact convex_supporting_sep hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hr0a hsep0
    hr1 hr1a hsep1

/-- In the contact case, the potential is positive to the left of the
negative crossing.  This complements `main_component_series`, which only
states the sign between the crossings. -/
theorem W_left_pos_contact {k a : ℝ} {S : ℝ → ℝ}
    (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
    (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
    (hyc : yc k a S < a) (hcon : RS k S = PsiS k S (yc k a S))
    {x : ℝ} (hx : x < xmS k S) : 0 < WS k S x := by
  obtain ⟨-, hxm0, hpsim⟩ := contact_series hSm ha hSa hS2 hk hyc hcon
  have hR := RS_pos hSm ha hSa hS2 hk
  have hycpos := yc_pos hSm ha hSa hS2 hk
  have hmono := PsiS_strictMonoOn_Iic hSm ha hSa hS2 hk hyc
  have hψ : PsiS k S x < -RS k S :=
    lt_of_lt_of_eq (hmono (by simp; linarith) (by simp; linarith) hx) hpsim
  rw [WS_pos_iff hSm ha hSa hS2 hk (by linarith [hxm0]) (by linarith [hxm0]),
    abs_of_neg (by linarith)]
  linarith

/-- If the target has an atom at its smallest residual distance and the
reference level is tangent, the negative sublevel set below `a` consists
of two open intervals separated by the contact point.  The first is the
main component containing the logarithmic atom at zero. -/
theorem correctedNegSet_contact {k a : ℝ} {S : ℝ → ℝ}
    (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
    (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
    (hatom : 0 < volume ({u | S u = a} ∩ Ioc (0 : ℝ) 1))
    (hcon : RS k S = PsiS k S (yc k a S)) :
    correctedNegSet k S ∩ Iio a =
      Ioo (xmS k S) (yc k a S) ∪ Ioo (yc k a S) a := by
  have hyc := yc_lt hSm ha hSa hS2 hk hatom
  have hycpos := yc_pos hSm ha hSa hS2 hk
  obtain ⟨hxp, hxm0, hpsim⟩ := contact_series hSm ha hSa hS2 hk hyc hcon
  have hmono := PsiS_strictMonoOn_Iic hSm ha hSa hS2 hk hyc
  have hcomp := main_component_series hSm ha hSa hS2 hk
    (by rw [hxp]; exact hycpos)
    (by rw [hxp]) (by rw [hxp]; exact hyc)
    (by rw [hxp, ← hcon]) hxm0 hpsim (by rw [hxp]; exact hmono)
  have hright := contact_right hSm ha hSa hS2 hk hatom hcon
  ext x
  simp only [correctedNegSet, Set.mem_inter_iff, Set.mem_ofPred_eq,
    Set.mem_Iio, Set.mem_union, Set.mem_Ioo]
  constructor
  · rintro ⟨hx, hxa⟩
    rcases hx with rfl | hneg
    · exact Or.inl ⟨hxm0, hycpos⟩
    · by_cases hleft : x < yc k a S
      · left
        refine ⟨?_, hleft⟩
        by_contra hn
        have hle : x ≤ xmS k S := le_of_not_gt hn
        rcases hle.lt_or_eq with hlt | heq
        · exact (not_lt_of_ge (W_left_pos_contact hSm ha hSa hS2 hk hyc hcon hlt).le) hneg
        · rw [heq, hcomp.1] at hneg
          exact (lt_irrefl 0) hneg
      · right
        have hge : yc k a S ≤ x := le_of_not_gt hleft
        refine ⟨?_, hxa⟩
        rcases hge.lt_or_eq with hlt | heq
        · exact hlt
        · rw [← heq, hright.1] at hneg
          exact False.elim ((lt_irrefl 0) hneg)
  · rintro (⟨hxm, hxyc⟩ | ⟨hxyc, hxa⟩)
    · refine ⟨?_, hxyc.trans hyc⟩
      by_cases hx0 : x = 0
      · exact Or.inl hx0
      · exact Or.inr (by rw [← hxp] at hxyc; exact hcomp.2.2 x hxm hxyc hx0)
    · exact ⟨Or.inr (hright.2 x hxyc hxa), hxa⟩

/-- In the contact case the part before the contact point is precisely
the main negative component. -/
theorem correctedNegSet_contact_main {k a : ℝ} {S : ℝ → ℝ}
    (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
    (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
    (hatom : 0 < volume ({u | S u = a} ∩ Ioc (0 : ℝ) 1))
    (hcon : RS k S = PsiS k S (yc k a S)) :
    correctedNegSet k S ∩ Iio (yc k a S) = Ioo (xmS k S) (yc k a S) := by
  have hyc := yc_lt hSm ha hSa hS2 hk hatom
  have hfull := correctedNegSet_contact hSm ha hSa hS2 hk hatom hcon
  ext x
  have hx : x ∈ correctedNegSet k S ∩ Iio (yc k a S) ↔
      x ∈ (correctedNegSet k S ∩ Iio a) ∩ Iio (yc k a S) := by
    simp only [Set.mem_inter_iff, Set.mem_Iio]
    constructor
    · rintro ⟨hneg, hxyc⟩
      exact ⟨⟨hneg, hxyc.trans hyc⟩, hxyc⟩
    · rintro ⟨⟨hneg, -⟩, hxyc⟩
      exact ⟨hneg, hxyc⟩
  rw [hx, hfull]
  simp only [Set.mem_inter_iff, Set.mem_union, Set.mem_Ioo, Set.mem_Iio]
  constructor
  · rintro ⟨h, hxyc⟩
    rcases h with h | h
    · exact h
    · linarith [h.1]
  · intro h
    exact ⟨Or.inl h, h.2⟩

/-- Lebesgue length of the main component in the contact case. -/
theorem volume_correctedNegSet_contact_main {k a : ℝ} {S : ℝ → ℝ}
    (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
    (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
    (hatom : 0 < volume ({u | S u = a} ∩ Ioc (0 : ℝ) 1))
    (hcon : RS k S = PsiS k S (yc k a S)) :
    (volume (correctedNegSet k S ∩ Iio (yc k a S))).toReal = xpS k S - xmS k S := by
  obtain ⟨hxp, hxm0, -⟩ := contact_series hSm ha hSa hS2 hk
    (yc_lt hSm ha hSa hS2 hk hatom) hcon
  have hycpos := yc_pos hSm ha hSa hS2 hk
  have hnonneg : 0 ≤ yc k a S - xmS k S := by linarith
  rw [correctedNegSet_contact_main hSm ha hSa hS2 hk hatom hcon,
    Real.volume_Ioo, ENNReal.toReal_ofReal hnonneg, hxp]

/-- The supporting inequality for a separated reference and a contact
target, both stated as lengths of corrected negative components. -/
theorem convex_supporting_contact_component
    {T0 T : ℝ → ℝ} {a0 a1 k r0 : ℝ}
    (hm0 : Measurable T0) (hm1 : Measurable T)
    (ha0 : 0 < a0) (h0a : ∀ u, a0 ≤ T0 u) (h02 : ∀ u, T0 u ≤ 2)
    (ha1 : 0 < a1) (h1a : ∀ u, a1 ≤ T u) (h12 : ∀ u, T u ≤ 2)
    (hk : 0 < k) (hr0 : 0 < r0) (hr0a : r0 < a0)
    (hsep0 : RS k T0 < PsiS k T0 r0)
    (hatom : 0 < volume ({u | T u = a1} ∩ Ioc (0 : ℝ) 1))
    (hcon : RS k T = PsiS k T (yc k a1 T)) :
    (volume (correctedNegSet k T0 ∩ Iio r0)).toReal + Mdot k T0 T ≤
      (volume (correctedNegSet k T ∩ Iio (yc k a1 T))).toReal := by
  rw [volume_correctedNegSet_sep hm0 ha0 h0a h02 hk hr0 hr0a hsep0,
    volume_correctedNegSet_contact_main hm1 ha1 h1a h12 hk hatom hcon]
  exact convex_supporting_contact hm0 hm1 ha0 h0a h02 ha1 h1a h12 hk hr0 hr0a hsep0
    (yc_lt hm1 ha1 h1a h12 hk hatom) hcon

end EP1038.Stage10
