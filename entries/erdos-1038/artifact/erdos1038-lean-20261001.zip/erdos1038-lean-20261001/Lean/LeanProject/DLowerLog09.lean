import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog06
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_540 : RB (Real.log ((43841 : ℝ) / 40000)) ((22922499621 : ℝ) / 250000000000) ((18337999697 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((43841 : ℝ) / 40000)) (t := ((3841 : ℝ) / 83841))
    (lo := ((22922499621 : ℝ) / 250000000000)) (hi := ((18337999697 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_541 : RB (Real.log ((93723749999 : ℝ) / 1000000000000)) ((-47348073067 : ℝ) / 20000000000) ((-591850913337 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((93723749999 : ℝ) / 125000000000)) (t := ((-31276250001 : ℝ) / 218723749999))
    (lo := ((-28796211167 : ℝ) / 100000000000)) (hi := ((-287962111669 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((93723749999 : ℝ) / 1000000000000) = Real.log ((93723749999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((93723749999 : ℝ) / 1000000000000) = ((93723749999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_542 : RB (Real.log ((3841 : ℝ) / 40000)) ((-2343146704751 : ℝ) / 1000000000000) ((-2343146704749 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3841 : ℝ) / 5000)) (t := ((-1159 : ℝ) / 8841))
    (lo := ((-263705163071 : ℝ) / 1000000000000)) (hi := ((-26370516307 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3841 : ℝ) / 40000) = Real.log ((3841 : ℝ) / 5000) - 3 * Real.log 2 := by
    rw [show ((3841 : ℝ) / 40000) = ((3841 : ℝ) / 5000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_543 : RB (Real.log ((233831591743 : ℝ) / 500000000000)) ((-30400277423 : ℝ) / 40000000000) ((-760006935573 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((233831591743 : ℝ) / 250000000000)) (t := ((-16168408257 : ℝ) / 483831591743))
    (lo := ((-13371951003 : ℝ) / 200000000000)) (hi := ((-33429877507 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((233831591743 : ℝ) / 500000000000) = Real.log ((233831591743 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((233831591743 : ℝ) / 500000000000) = ((233831591743 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_544 : RB (Real.log ((468310016603 : ℝ) / 1000000000000)) ((-151724954747 : ℝ) / 200000000000) ((-758624773733 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((468310016603 : ℝ) / 500000000000)) (t := ((-31689983397 : ℝ) / 968310016603))
    (lo := ((-2619103727 : ℝ) / 40000000000)) (hi := ((-32738796587 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((468310016603 : ℝ) / 1000000000000) = Real.log ((468310016603 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((468310016603 : ℝ) / 1000000000000) = ((468310016603 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_545 : RB (Real.log ((81231850311 : ℝ) / 250000000000)) ((-562076751197 : ℝ) / 500000000000) ((-140519187799 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((81231850311 : ℝ) / 62500000000)) (t := ((18731850311 : ℝ) / 143731850311))
    (lo := ((131070429363 : ℝ) / 500000000000)) (hi := ((262140858727 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((81231850311 : ℝ) / 250000000000) = Real.log ((81231850311 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((81231850311 : ℝ) / 250000000000) = ((81231850311 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_546 : RB (Real.log ((634149162717 : ℝ) / 200000000000)) ((225384147 : ℝ) / 195312500) ((576983416321 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((634149162717 : ℝ) / 800000000000)) (t := ((-165850837283 : ℝ) / 1434149162717))
    (lo := ((-232327528479 : ℝ) / 1000000000000)) (hi := ((-116163764239 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((634149162717 : ℝ) / 200000000000) = Real.log ((634149162717 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((634149162717 : ℝ) / 200000000000) = ((634149162717 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_547 : RB (Real.log ((79292562787 : ℝ) / 25000000000)) ((230853702717 : ℝ) / 200000000000) ((1154268513587 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((79292562787 : ℝ) / 100000000000)) (t := ((-20707437213 : ℝ) / 179292562787))
    (lo := ((-116012923767 : ℝ) / 500000000000)) (hi := ((-232025847533 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((79292562787 : ℝ) / 25000000000) = Real.log ((79292562787 : ℝ) / 100000000000) + 2 * Real.log 2 := by
    rw [show ((79292562787 : ℝ) / 25000000000) = ((79292562787 : ℝ) / 100000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_548 : RB (Real.log ((1456423406727 : ℝ) / 1000000000000)) ((187991854411 : ℝ) / 500000000000) ((46997963603 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((1456423406727 : ℝ) / 2000000000000)) (t := ((-543576593273 : ℝ) / 3456423406727))
    (lo := ((-317163471737 : ℝ) / 1000000000000)) (hi := ((-39645433967 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1456423406727 : ℝ) / 1000000000000) = Real.log ((1456423406727 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1456423406727 : ℝ) / 1000000000000) = ((1456423406727 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_549 : RB (Real.log ((1096024999999 : ℝ) / 1000000000000)) ((91689998483 : ℝ) / 1000000000000) ((22922499621 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1096024999999 : ℝ) / 1000000000000)) (t := ((96024999999 : ℝ) / 2096024999999))
    (lo := ((91689998483 : ℝ) / 1000000000000)) (hi := ((22922499621 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_550 : RB (Real.log ((878661 : ℝ) / 800000)) ((937874301 : ℝ) / 10000000000) ((93787430101 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((878661 : ℝ) / 800000)) (t := ((78661 : ℝ) / 1678661))
    (lo := ((937874301 : ℝ) / 10000000000)) (hi := ((93787430101 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_551 : RB (Real.log ((96024999999 : ℝ) / 1000000000000)) ((-2343146704761 : ℝ) / 1000000000000) ((-2343146704759 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((96024999999 : ℝ) / 125000000000)) (t := ((-28975000001 : ℝ) / 221024999999))
    (lo := ((-263705163081 : ℝ) / 1000000000000)) (hi := ((-6592629077 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((96024999999 : ℝ) / 1000000000000) = Real.log ((96024999999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((96024999999 : ℝ) / 1000000000000) = ((96024999999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_552 : RB (Real.log ((78661 : ℝ) / 800000)) ((-579866061951 : ℝ) / 250000000000) ((-1159732123901 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((78661 : ℝ) / 100000)) (t := ((-21339 : ℝ) / 178661))
    (lo := ((-60005676531 : ℝ) / 250000000000)) (hi := ((-240022706123 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((78661 : ℝ) / 800000) = Real.log ((78661 : ℝ) / 100000) - 3 * Real.log 2 := by
    rw [show ((78661 : ℝ) / 800000) = ((78661 : ℝ) / 100000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_553 : RB (Real.log ((456433448909 : ℝ) / 1000000000000)) ((-392156187549 : ℝ) / 500000000000) ((-98039046887 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((456433448909 : ℝ) / 500000000000)) (t := ((-43566551091 : ℝ) / 956433448909))
    (lo := ((-45582597269 : ℝ) / 500000000000)) (hi := ((-91165194537 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((456433448909 : ℝ) / 1000000000000) = Real.log ((456433448909 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((456433448909 : ℝ) / 1000000000000) = ((456433448909 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_554 : RB (Real.log ((457091199121 : ℝ) / 1000000000000)) ((-391436173779 : ℝ) / 500000000000) ((-195718086889 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((457091199121 : ℝ) / 500000000000)) (t := ((-42908800879 : ℝ) / 957091199121))
    (lo := ((-44862583499 : ℝ) / 500000000000)) (hi := ((-89725166997 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457091199121 : ℝ) / 1000000000000) = Real.log ((457091199121 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((457091199121 : ℝ) / 1000000000000) = ((457091199121 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_555 : RB (Real.log ((320029384589 : ℝ) / 1000000000000)) ((-284835615141 : ℝ) / 250000000000) ((-569671230281 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((320029384589 : ℝ) / 250000000000)) (t := ((70029384589 : ℝ) / 570029384589))
    (lo := ((61737975139 : ℝ) / 250000000000)) (hi := ((246951900557 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((320029384589 : ℝ) / 1000000000000) = Real.log ((320029384589 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((320029384589 : ℝ) / 1000000000000) = ((320029384589 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_556 : RB (Real.log ((3160870388691 : ℝ) / 1000000000000)) ((115084742913 : ℝ) / 100000000000) ((287711857283 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3160870388691 : ℝ) / 4000000000000)) (t := ((-839129611309 : ℝ) / 7160870388691))
    (lo := ((-235446931989 : ℝ) / 1000000000000)) (hi := ((-58861732997 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3160870388691 : ℝ) / 1000000000000) = Real.log ((3160870388691 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3160870388691 : ℝ) / 1000000000000) = ((3160870388691 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_557 : RB (Real.log ((3161846274653 : ℝ) / 1000000000000)) ((143894515139 : ℝ) / 125000000000) ((575578060557 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3161846274653 : ℝ) / 4000000000000)) (t := ((-838153725347 : ℝ) / 7161846274653))
    (lo := ((-235138240007 : ℝ) / 1000000000000)) (hi := ((-117569120003 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3161846274653 : ℝ) / 1000000000000) = Real.log ((3161846274653 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3161846274653 : ℝ) / 1000000000000) = ((3161846274653 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_558 : RB (Real.log ((729151168377 : ℝ) / 500000000000)) ((377272976117 : ℝ) / 1000000000000) ((377272976119 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((729151168377 : ℝ) / 1000000000000)) (t := ((-270848831623 : ℝ) / 1729151168377))
    (lo := ((-157937102221 : ℝ) / 500000000000)) (hi := ((-315874204441 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((729151168377 : ℝ) / 500000000000) = Real.log ((729151168377 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((729151168377 : ℝ) / 500000000000) = ((729151168377 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_559 : RB (Real.log ((1098326249999 : ℝ) / 1000000000000)) ((93787430099 : ℝ) / 1000000000000) ((937874301 : ℝ) / 10000000000) := by
  have hm := log_bounds_of_series (x := ((1098326249999 : ℝ) / 1000000000000)) (t := ((98326249999 : ℝ) / 2098326249999))
    (lo := ((93787430099 : ℝ) / 1000000000000)) (hi := ((937874301 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_560 : RB (Real.log ((440251 : ℝ) / 400000)) ((47940235851 : ℝ) / 500000000000) ((95880471703 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((440251 : ℝ) / 400000)) (t := ((40251 : ℝ) / 840251))
    (lo := ((47940235851 : ℝ) / 500000000000)) (hi := ((95880471703 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_561 : RB (Real.log ((98326249999 : ℝ) / 1000000000000)) ((-1159732123907 : ℝ) / 500000000000) ((-579866061953 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((98326249999 : ℝ) / 125000000000)) (t := ((-26673750001 : ℝ) / 223326249999))
    (lo := ((-120011353067 : ℝ) / 500000000000)) (hi := ((-240022706133 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98326249999 : ℝ) / 1000000000000) = Real.log ((98326249999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((98326249999 : ℝ) / 1000000000000) = ((98326249999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_562 : RB (Real.log ((40251 : ℝ) / 400000)) ((-143520606177 : ℝ) / 62500000000) ((-229632969883 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((40251 : ℝ) / 50000)) (t := ((-9749 : ℝ) / 90251))
    (lo := ((-6777754911 : ℝ) / 31250000000)) (hi := ((-216888157151 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40251 : ℝ) / 400000) = Real.log ((40251 : ℝ) / 50000) - 3 * Real.log 2 := by
    rw [show ((40251 : ℝ) / 400000) = ((40251 : ℝ) / 50000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_563 : RB (Real.log ((696811917 : ℝ) / 1562500000)) ((-807526853751 : ℝ) / 1000000000000) ((-807526853749 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((696811917 : ℝ) / 781250000)) (t := ((-84438083 : ℝ) / 1478061917))
    (lo := ((-114379673191 : ℝ) / 1000000000000)) (hi := ((-11437967319 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((696811917 : ℝ) / 1562500000) = Real.log ((696811917 : ℝ) / 781250000) - 1 * Real.log 2 := by
    rw [show ((696811917 : ℝ) / 1562500000) = ((696811917 : ℝ) / 781250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_564 : RB (Real.log ((446628420523 : ℝ) / 1000000000000)) ((-806028304067 : ℝ) / 1000000000000) ((-161205660813 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((446628420523 : ℝ) / 500000000000)) (t := ((-53371579477 : ℝ) / 946628420523))
    (lo := ((-112881123507 : ℝ) / 1000000000000)) (hi := ((-56440561753 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((446628420523 : ℝ) / 1000000000000) = Real.log ((446628420523 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((446628420523 : ℝ) / 1000000000000) = ((446628420523 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_565 : RB (Real.log ((315420646717 : ℝ) / 1000000000000)) ((-1153848144589 : ℝ) / 1000000000000) ((-1153848144587 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((315420646717 : ℝ) / 250000000000)) (t := ((65420646717 : ℝ) / 565420646717))
    (lo := ((232446216531 : ℝ) / 1000000000000)) (hi := ((58111554133 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((315420646717 : ℝ) / 1000000000000) = Real.log ((315420646717 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((315420646717 : ℝ) / 1000000000000) = ((315420646717 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_566 : RB (Real.log ((157546563241 : ℝ) / 50000000000)) ((1147698048769 : ℝ) / 1000000000000) ((1147698048771 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((157546563241 : ℝ) / 200000000000)) (t := ((-42453436759 : ℝ) / 357546563241))
    (lo := ((-4771926247 : ℝ) / 20000000000)) (hi := ((-238596312349 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((157546563241 : ℝ) / 50000000000) = Real.log ((157546563241 : ℝ) / 200000000000) + 2 * Real.log 2 := by
    rw [show ((157546563241 : ℝ) / 50000000000) = ((157546563241 : ℝ) / 200000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_567 : RB (Real.log ((1575963063019 : ℝ) / 500000000000)) ((1148013734549 : ℝ) / 1000000000000) ((1148013734551 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1575963063019 : ℝ) / 2000000000000)) (t := ((-424036936981 : ℝ) / 3575963063019))
    (lo := ((-23828062657 : ℝ) / 100000000000)) (hi := ((-238280626569 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1575963063019 : ℝ) / 500000000000) = Real.log ((1575963063019 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1575963063019 : ℝ) / 500000000000) = ((1575963063019 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_568 : RB (Real.log ((182525902991 : ℝ) / 125000000000)) ((94644589961 : ℝ) / 250000000000) ((189289179923 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((182525902991 : ℝ) / 250000000000)) (t := ((-67474097009 : ℝ) / 432525902991))
    (lo := ((-62913764143 : ℝ) / 200000000000)) (hi := ((-157284410357 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((182525902991 : ℝ) / 125000000000) = Real.log ((182525902991 : ℝ) / 250000000000) + 1 * Real.log 2 := by
    rw [show ((182525902991 : ℝ) / 125000000000) = ((182525902991 : ℝ) / 250000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_569 : RB (Real.log ((1100627499999 : ℝ) / 1000000000000)) ((95880471701 : ℝ) / 1000000000000) ((47940235851 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1100627499999 : ℝ) / 1000000000000)) (t := ((100627499999 : ℝ) / 2100627499999))
    (lo := ((95880471701 : ℝ) / 1000000000000)) (hi := ((47940235851 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_570 : RB (Real.log ((882343 : ℝ) / 800000)) ((9796914163 : ℝ) / 100000000000) ((97969141631 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((882343 : ℝ) / 800000)) (t := ((82343 : ℝ) / 1682343))
    (lo := ((9796914163 : ℝ) / 100000000000)) (hi := ((97969141631 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_571 : RB (Real.log ((100627499999 : ℝ) / 1000000000000)) ((-1148164849421 : ℝ) / 500000000000) ((-57408242471 : ℝ) / 25000000000) := by
  have hm := log_bounds_of_series (x := ((100627499999 : ℝ) / 125000000000)) (t := ((-24372500001 : ℝ) / 225627499999))
    (lo := ((-108444078581 : ℝ) / 500000000000)) (hi := ((-216888157161 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((100627499999 : ℝ) / 1000000000000) = Real.log ((100627499999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((100627499999 : ℝ) / 1000000000000) = ((100627499999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_572 : RB (Real.log ((82343 : ℝ) / 800000)) ((-1136859138847 : ℝ) / 500000000000) ((-568429569423 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((82343 : ℝ) / 100000)) (t := ((-17657 : ℝ) / 182343))
    (lo := ((-97138368007 : ℝ) / 500000000000)) (hi := ((-194276736013 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((82343 : ℝ) / 800000) = Real.log ((82343 : ℝ) / 100000) - 3 * Real.log 2 := by
    rw [show ((82343 : ℝ) / 800000) = ((82343 : ℝ) / 100000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_573 : RB (Real.log ((218258275863 : ℝ) / 500000000000)) ((-828928985233 : ℝ) / 1000000000000) ((-828928985231 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((218258275863 : ℝ) / 250000000000)) (t := ((-31741724137 : ℝ) / 468258275863))
    (lo := ((-135781804673 : ℝ) / 1000000000000)) (hi := ((-1060795349 : ℝ) / 7812500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((218258275863 : ℝ) / 500000000000) = Real.log ((218258275863 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((218258275863 : ℝ) / 500000000000) = ((218258275863 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_574 : RB (Real.log ((437196670061 : ℝ) / 1000000000000)) ((-827372139221 : ℝ) / 1000000000000) ((-827372139219 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((437196670061 : ℝ) / 500000000000)) (t := ((-62803329939 : ℝ) / 937196670061))
    (lo := ((-134224958661 : ℝ) / 1000000000000)) (hi := ((-6711247933 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((437196670061 : ℝ) / 1000000000000) = Real.log ((437196670061 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((437196670061 : ℝ) / 1000000000000) = ((437196670061 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_575 : RB (Real.log ((155623295383 : ℝ) / 500000000000)) ((-583584892313 : ℝ) / 500000000000) ((-72948111539 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((155623295383 : ℝ) / 125000000000)) (t := ((30623295383 : ℝ) / 280623295383))
    (lo := ((109562288247 : ℝ) / 500000000000)) (hi := ((43824915299 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((155623295383 : ℝ) / 500000000000) = Real.log ((155623295383 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((155623295383 : ℝ) / 500000000000) = ((155623295383 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_576 : RB (Real.log ((3140932991997 : ℝ) / 1000000000000)) ((1144519886993 : ℝ) / 1000000000000) ((228903977399 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3140932991997 : ℝ) / 4000000000000)) (t := ((-859067008003 : ℝ) / 7140932991997))
    (lo := ((-120887237063 : ℝ) / 500000000000)) (hi := ((-1934195793 : ℝ) / 8000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3140932991997 : ℝ) / 1000000000000) = Real.log ((3140932991997 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3140932991997 : ℝ) / 1000000000000) = ((3140932991997 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_577 : RB (Real.log ((1570973308043 : ℝ) / 500000000000)) ((1144842549263 : ℝ) / 1000000000000) ((228968509853 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1570973308043 : ℝ) / 2000000000000)) (t := ((-429026691957 : ℝ) / 3570973308043))
    (lo := ((-15090738241 : ℝ) / 62500000000)) (hi := ((-48290362371 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1570973308043 : ℝ) / 500000000000) = Real.log ((1570973308043 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1570973308043 : ℝ) / 500000000000) = ((1570973308043 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_578 : RB (Real.log ((365534404407 : ℝ) / 250000000000)) ((379899486601 : ℝ) / 1000000000000) ((379899486603 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((365534404407 : ℝ) / 500000000000)) (t := ((-134465595593 : ℝ) / 865534404407))
    (lo := ((-156623846979 : ℝ) / 500000000000)) (hi := ((-313247693957 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((365534404407 : ℝ) / 250000000000) = Real.log ((365534404407 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((365534404407 : ℝ) / 250000000000) = ((365534404407 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_579 : RB (Real.log ((1102928749999 : ℝ) / 1000000000000)) ((97969141629 : ℝ) / 1000000000000) ((9796914163 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((1102928749999 : ℝ) / 1000000000000)) (t := ((102928749999 : ℝ) / 2102928749999))
    (lo := ((97969141629 : ℝ) / 1000000000000)) (hi := ((9796914163 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_580 : RB (Real.log ((110523 : ℝ) / 100000)) ((50026729053 : ℝ) / 500000000000) ((100053458107 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((110523 : ℝ) / 100000)) (t := ((10523 : ℝ) / 210523))
    (lo := ((50026729053 : ℝ) / 500000000000)) (hi := ((100053458107 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_581 : RB (Real.log ((102928749999 : ℝ) / 1000000000000)) ((-2273718277703 : ℝ) / 1000000000000) ((-2273718277701 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((102928749999 : ℝ) / 125000000000)) (t := ((-22071250001 : ℝ) / 227928749999))
    (lo := ((-194276736023 : ℝ) / 1000000000000)) (hi := ((-97138368011 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((102928749999 : ℝ) / 1000000000000) = Real.log ((102928749999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((102928749999 : ℝ) / 1000000000000) = ((102928749999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_582 : RB (Real.log ((10523 : ℝ) / 100000)) ((-225160684823 : ℝ) / 100000000000) ((-562901712057 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((10523 : ℝ) / 12500)) (t := ((-1977 : ℝ) / 23023))
    (lo := ((-3443306131 : ℝ) / 20000000000)) (hi := ((-172165306549 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10523 : ℝ) / 100000) = Real.log ((10523 : ℝ) / 12500) - 3 * Real.log 2 := by
    rw [show ((10523 : ℝ) / 100000) = ((10523 : ℝ) / 12500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_583 : RB (Real.log ((107132081311 : ℝ) / 250000000000)) ((-211849609969 : ℝ) / 250000000000) ((-423699219937 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((107132081311 : ℝ) / 125000000000)) (t := ((-17867918689 : ℝ) / 232132081311))
    (lo := ((-38562814829 : ℝ) / 250000000000)) (hi := ((-30850251863 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((107132081311 : ℝ) / 250000000000) = Real.log ((107132081311 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((107132081311 : ℝ) / 250000000000) = ((107132081311 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_584 : RB (Real.log ((214610144423 : ℝ) / 500000000000)) ((-422892499017 : ℝ) / 500000000000) ((-52861562377 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((214610144423 : ℝ) / 250000000000)) (t := ((-35389855577 : ℝ) / 464610144423))
    (lo := ((-76318908737 : ℝ) / 500000000000)) (hi := ((-152637817473 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((214610144423 : ℝ) / 500000000000) = Real.log ((214610144423 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((214610144423 : ℝ) / 500000000000) = ((214610144423 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_585 : RB (Real.log ((153865229823 : ℝ) / 500000000000)) ((-1178531010179 : ℝ) / 1000000000000) ((-1178531010177 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((153865229823 : ℝ) / 125000000000)) (t := ((28865229823 : ℝ) / 278865229823))
    (lo := ((207763350941 : ℝ) / 1000000000000)) (hi := ((103881675471 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((153865229823 : ℝ) / 500000000000) = Real.log ((153865229823 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((153865229823 : ℝ) / 500000000000) = ((153865229823 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_586 : RB (Real.log ((782719975371 : ℝ) / 250000000000)) ((1141314083729 : ℝ) / 1000000000000) ((1141314083731 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((782719975371 : ℝ) / 1000000000000)) (t := ((-217280024629 : ℝ) / 1782719975371))
    (lo := ((-24498027739 : ℝ) / 100000000000)) (hi := ((-244980277389 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((782719975371 : ℝ) / 250000000000) = Real.log ((782719975371 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((782719975371 : ℝ) / 250000000000) = ((782719975371 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_587 : RB (Real.log ((3131912076559 : ℝ) / 1000000000000)) ((228328741023 : ℝ) / 200000000000) ((1141643705117 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3131912076559 : ℝ) / 4000000000000)) (t := ((-868087923441 : ℝ) / 7131912076559))
    (lo := ((-61162664001 : ℝ) / 250000000000)) (hi := ((-244650656003 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3131912076559 : ℝ) / 1000000000000) = Real.log ((3131912076559 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3131912076559 : ℝ) / 1000000000000) = ((3131912076559 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_588 : RB (Real.log ((732046547159 : ℝ) / 500000000000)) ((381236002531 : ℝ) / 1000000000000) ((381236002533 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((732046547159 : ℝ) / 1000000000000)) (t := ((-267953452841 : ℝ) / 1732046547159))
    (lo := ((-77977794507 : ℝ) / 250000000000)) (hi := ((-311911178027 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((732046547159 : ℝ) / 500000000000) = Real.log ((732046547159 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((732046547159 : ℝ) / 500000000000) = ((732046547159 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_589 : RB (Real.log ((1105229999999 : ℝ) / 1000000000000)) ((50026729053 : ℝ) / 500000000000) ((100053458107 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1105229999999 : ℝ) / 1000000000000)) (t := ((105229999999 : ℝ) / 2105229999999))
    (lo := ((50026729053 : ℝ) / 500000000000)) (hi := ((100053458107 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_590 : RB (Real.log ((35441 : ℝ) / 32000)) ((102133439243 : ℝ) / 1000000000000) ((25533359811 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((35441 : ℝ) / 32000)) (t := ((3441 : ℝ) / 67441))
    (lo := ((102133439243 : ℝ) / 1000000000000)) (hi := ((25533359811 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_591 : RB (Real.log ((105229999999 : ℝ) / 1000000000000)) ((-28145085603 : ℝ) / 12500000000) ((-1125803424119 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((105229999999 : ℝ) / 125000000000)) (t := ((-19770000001 : ℝ) / 230229999999))
    (lo := ((-538016583 : ℝ) / 3125000000)) (hi := ((-172165306559 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((105229999999 : ℝ) / 1000000000000) = Real.log ((105229999999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((105229999999 : ℝ) / 1000000000000) = ((105229999999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_592 : RB (Real.log ((3441 : ℝ) / 32000)) ((-445994755197 : ℝ) / 200000000000) ((-2229973775983 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3441 : ℝ) / 4000)) (t := ((-559 : ℝ) / 7441))
    (lo := ((-30106446861 : ℝ) / 200000000000)) (hi := ((-2352066161 : ℝ) / 15625000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3441 : ℝ) / 32000) = Real.log ((3441 : ℝ) / 4000) - 3 * Real.log 2 := by
    rw [show ((3441 : ℝ) / 32000) = ((3441 : ℝ) / 4000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_593 : RB (Real.log ((84536562903 : ℝ) / 200000000000)) ((-172226645739 : ℝ) / 200000000000) ((-861133228693 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((84536562903 : ℝ) / 100000000000)) (t := ((-15463437097 : ℝ) / 184536562903))
    (lo := ((-33597209627 : ℝ) / 200000000000)) (hi := ((-83993024067 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((84536562903 : ℝ) / 200000000000) = Real.log ((84536562903 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((84536562903 : ℝ) / 200000000000) = ((84536562903 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_594 : RB (Real.log ((105846883149 : ℝ) / 250000000000)) ((-859467366639 : ℝ) / 1000000000000) ((-859467366637 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((105846883149 : ℝ) / 125000000000)) (t := ((-19153116851 : ℝ) / 230846883149))
    (lo := ((-166320186079 : ℝ) / 1000000000000)) (hi := ((-83160093039 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((105846883149 : ℝ) / 250000000000) = Real.log ((105846883149 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((105846883149 : ℝ) / 250000000000) = ((105846883149 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_595 : RB (Real.log ((38153777129 : ℝ) / 125000000000)) ((-29667224429 : ℝ) / 25000000000) ((-593344488579 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((38153777129 : ℝ) / 31250000000)) (t := ((6903777129 : ℝ) / 69403777129))
    (lo := ((4990134599 : ℝ) / 25000000000)) (hi := ((199605383961 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38153777129 : ℝ) / 125000000000) = Real.log ((38153777129 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((38153777129 : ℝ) / 125000000000) = ((38153777129 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_596 : RB (Real.log ((3120776120093 : ℝ) / 1000000000000)) ((45523269093 : ℝ) / 40000000000) ((1138081727327 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3120776120093 : ℝ) / 4000000000000)) (t := ((-879223879907 : ℝ) / 7120776120093))
    (lo := ((-124106316897 : ℝ) / 500000000000)) (hi := ((-248212633793 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3120776120093 : ℝ) / 1000000000000) = Real.log ((3120776120093 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3120776120093 : ℝ) / 1000000000000) = ((3120776120093 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_597 : RB (Real.log ((3121826634841 : ℝ) / 1000000000000)) ((113841829039 : ℝ) / 100000000000) ((142302286299 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((3121826634841 : ℝ) / 4000000000000)) (t := ((-878173365159 : ℝ) / 7121826634841))
    (lo := ((-247876070729 : ℝ) / 1000000000000)) (hi := ((-30984508841 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3121826634841 : ℝ) / 1000000000000) = Real.log ((3121826634841 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3121826634841 : ℝ) / 1000000000000) = ((3121826634841 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_598 : RB (Real.log ((1466073255403 : ℝ) / 1000000000000)) ((191293785897 : ℝ) / 500000000000) ((95646892949 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1466073255403 : ℝ) / 2000000000000)) (t := ((-533926744597 : ℝ) / 3466073255403))
    (lo := ((-62111921753 : ℝ) / 200000000000)) (hi := ((-77639902191 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1466073255403 : ℝ) / 1000000000000) = Real.log ((1466073255403 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1466073255403 : ℝ) / 1000000000000) = ((1466073255403 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_599 : RB (Real.log ((1107531249999 : ℝ) / 1000000000000)) ((51066719621 : ℝ) / 500000000000) ((102133439243 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1107531249999 : ℝ) / 1000000000000)) (t := ((107531249999 : ℝ) / 2107531249999))
    (lo := ((51066719621 : ℝ) / 500000000000)) (hi := ((102133439243 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
