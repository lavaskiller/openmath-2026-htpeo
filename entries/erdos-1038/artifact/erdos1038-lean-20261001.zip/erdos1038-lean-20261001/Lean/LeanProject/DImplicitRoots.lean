import LeanProject.DActualRoots
import Mathlib.Analysis.Calculus.ImplicitContDiff
import Mathlib.Analysis.Calculus.ContDiff.Deriv

/-! Nondegeneracy and smoothness of the actual roots, not hypothetical root boxes. -/
open Real Set Filter Topology
open scoped ContDiff
namespace EP1038.DLowerCert
open EP1038.Stage9

noncomputable def Ev (q v : ℝ) : ℝ :=
  aval q * (1 / (v - q ^ 2) + 1 / (1 - v)) - 1 / v
noncomputable def delta1 (q : ℝ) : ℝ := -2 / (1 + q)
noncomputable def delta2 (q : ℝ) : ℝ := 2 / (1 + q) ^ 2
noncomputable def aval1 (q : ℝ) : ℝ :=
  delta1 q / Real.log q - delta q / (q * (Real.log q) ^ 2)
noncomputable def aval2 (q : ℝ) : ℝ :=
  delta2 q / Real.log q - 2 * delta1 q / (q * (Real.log q) ^ 2) +
    delta q * (Real.log q + 2) / (q ^ 2 * (Real.log q) ^ 3)
noncomputable def Eq (q v : ℝ) : ℝ :=
  aval1 q * (Real.log (v - q ^ 2) - Real.log (1 - v)) +
    aval q * (-2 * q / (v - q ^ 2)) - delta1 q
noncomputable def Evv (q v : ℝ) : ℝ :=
  aval q * (1 / (1 - v) ^ 2 - 1 / (v - q ^ 2) ^ 2) + 1 / v ^ 2
noncomputable def Evq (q v : ℝ) : ℝ :=
  aval1 q * (1 / (v - q ^ 2) + 1 / (1 - v)) +
    aval q * (2 * q / (v - q ^ 2) ^ 2)
noncomputable def Eqq (q v : ℝ) : ℝ :=
  aval2 q * (Real.log (v - q ^ 2) - Real.log (1 - v)) +
    2 * aval1 q * (-2 * q / (v - q ^ 2)) +
    aval q * (-2 / (v - q ^ 2) - 4 * q ^ 2 / (v - q ^ 2) ^ 2) - delta2 q

theorem hasDerivAt_delta {q : ℝ} (hq : 0 < q) : HasDerivAt delta (delta1 q) q := by
  have h1 : 1 + q ≠ 0 := by linarith
  have h := (((hasDerivAt_id q).const_add 1).log h1).const_mul 2 |>.const_sub (Real.log 2)
  convert h using 1
  · rfl
  · simp only [delta1, id_eq, neg_div, one_mul]
    ring

theorem hasDerivAt_delta1 {q : ℝ} (hq : 0 < q) : HasDerivAt delta1 (delta2 q) q := by
  have h1 : 1 + q ≠ 0 := by linarith
  convert (hasDerivAt_const q (-2 : ℝ)).div ((hasDerivAt_id q).const_add 1) h1 using 1
  · rfl
  · simp only [delta2, id_eq]
    ring

theorem hasDerivAt_aval {q : ℝ} (hq : 0 < q) (hq1 : q < 1) :
    HasDerivAt aval (aval1 q) q := by
  have h := ((hasDerivAt_delta hq).div (Real.hasDerivAt_log hq.ne')
    (log_q_neg hq hq1).ne).const_add 1
  convert h using 1
  · rfl
  · unfold aval1
    field_simp [hq.ne', (log_q_neg hq hq1).ne]
    <;> ring

theorem hasDerivAt_aval1 {q : ℝ} (hq : 0 < q) (hq1 : q < 1) :
    HasDerivAt aval1 (aval2 q) q := by
  have hl := Real.hasDerivAt_log hq.ne'
  have hn := (log_q_neg hq hq1).ne
  have h := ((hasDerivAt_delta1 hq).div hl hn).sub
    ((hasDerivAt_delta hq).div ((hasDerivAt_id q).mul (hl.pow 2))
      (mul_ne_zero hq.ne' (pow_ne_zero _ hn)))
  convert h using 1
  · rfl
  · unfold aval2
    simp only [id_eq, Pi.mul_apply, Pi.pow_apply]
    field_simp [hq.ne', hn]
    <;> ring

theorem hasDerivAt_E_v {q v : ℝ} (hv : v ≠ 0) (hx : v - q ^ 2 ≠ 0)
    (hy : 1 - v ≠ 0) : HasDerivAt (E q) (Ev q v) v := by
  have hx' := ((hasDerivAt_id v).sub_const (q ^ 2)).log hx
  have hy' := ((hasDerivAt_id v).const_sub 1).log hy
  convert (((hx'.sub hy').const_mul (aval q)).sub (Real.hasDerivAt_log hv)).sub_const
    (delta q) using 1
  · rfl
  · unfold Ev
    simp only [one_div, id_eq]
    ring

theorem pPlus_lt_critical {q : ℝ} (hq : q ∈ Qadm) : pPlus q < r1 (Aq q) q := by
  have hp := pPlus_spec hq
  by_contra h
  have hh := Gr_neg hq.1 hq.2.1 (Aq_pos hq.1 hq.2.1)
    ((Aq_lt_s_iff hq.1 hq.2.1).mpr hq.2.2) (le_of_not_gt h) hp.2.1
  rw [← GA_eq_Gr hq.1 hq.2.1 hp.1 hp.2.1, hp.2.2.1] at hh
  exact lt_irrefl _ hh

theorem Ev_vPlus_pos {q : ℝ} (hq : q ∈ Qadm) : 0 < Ev q (vPlus q) := by
  have hv := vPlus_mem hq
  have hv0 := hq.1.trans hv.1
  have hx : 0 < vPlus q - q ^ 2 := by
    nlinarith [mul_pos hq.1 (sub_pos.mpr hq.2.1)]
  have hy : 0 < 1 - vPlus q := sub_pos.mpr hv.2
  have hp := pPlus_spec hq
  have hQ := (Qf_pos_iff hq.1 hq.2.1 (Aq_pos hq.1 hq.2.1)
    ((Aq_lt_s_iff hq.1 hq.2.1).mpr hq.2.2) hp.2.1).mpr (pPlus_lt_critical hq)
  have he : Ev q (vPlus q) * (vPlus q * (vPlus q - q ^ 2) * (1 - vPlus q)) =
      (vPlus q) ^ 2 / q * Qf (Aq q) q (pPlus q) := by
    rw [Ev, aval_eq_Aq hq.1 hq.2.1]
    have hpp : pPlus q = q / vPlus q := by
      rw [vPlus, div_div_cancel₀ hq.1.ne']
    rw [hpp]
    unfold Qf BA
    field_simp [hq.1.ne', hv0.ne', hx.ne', hy.ne']
    <;> ring
  have hd : 0 < vPlus q * (vPlus q - q ^ 2) * (1 - vPlus q) := by positivity
  have hn : 0 < (vPlus q) ^ 2 / q * Qf (Aq q) q (pPlus q) :=
    mul_pos (div_pos (sq_pos_of_pos hv0) hq.1) hQ
  exact (mul_pos_iff_of_pos_right hd).mp (he.symm ▸ hn)

theorem Ev_vMinus_neg {q : ℝ} (hq : q ∈ Qadm) : Ev q (vMinus q) < 0 := by
  have hv := vMinus_mem hq
  have hv0 := zero_lt_one.trans hv
  have hx : 0 < vMinus q - q ^ 2 := by nlinarith [hq.1, hq.2.1]
  have hy : 0 < vMinus q - 1 := sub_pos.mpr hv
  have he : 1 / (vMinus q - q ^ 2) + 1 / (1 - vMinus q) =
      -(1 - q ^ 2) / ((vMinus q - q ^ 2) * (vMinus q - 1)) := by
    field_simp [hx.ne', hy.ne', (show 1 - vMinus q ≠ 0 by linarith)]
    <;> ring
  have hsum : 1 / (vMinus q - q ^ 2) + 1 / (1 - vMinus q) < 0 := by
    rw [he]
    exact div_neg_of_neg_of_pos (by nlinarith [hq.1, hq.2.1]) (mul_pos hx hy)
  have ha : 0 < aval q := by rw [aval_eq_Aq hq.1 hq.2.1]; exact Aq_pos hq.1 hq.2.1
  unfold Ev
  have hm := mul_neg_of_pos_of_neg ha hsum
  have hd := one_div_pos.mpr hv0
  linarith

theorem vPlus_unique {q v : ℝ} (hq : q ∈ Qadm) (hvq : q < v) (hv1 : v < 1)
    (he : E q v = 0) : v = vPlus q := by
  have hv0 := hq.1.trans hvq
  have hpq : q < q / v := (lt_div_iff₀ hv0).mpr
    (by nlinarith [mul_pos hq.1 (sub_pos.mpr hv1)])
  have hp1 := (div_lt_one hv0).mpr hvq
  have hp := pPlus_unique hq hpq hp1 ((E_eq_GA hq.1 hq.2.1 hvq hv1.ne).symm.trans he)
  rw [vPlus, ← hp, div_div_cancel₀ hq.1.ne']

theorem vMinus_unique {q v : ℝ} (hq : q ∈ Qadm) (hv1 : 1 < v)
    (he : E q v = 0) : v = vMinus q := by
  have hv0 := zero_lt_one.trans hv1
  have hpq : q / v < q := (div_lt_iff₀ hv0).mpr
    (by nlinarith [mul_pos hq.1 (sub_pos.mpr hv1)])
  have hp := pMinus_unique hq (div_pos hq.1 hv0) hpq
    ((E_eq_GA hq.1 hq.2.1 (hq.2.1.trans hv1) hv1.ne').symm.trans he)
  rw [vMinus, ← hp, div_div_cancel₀ hq.1.ne']

theorem Qadm_mem_nhds {q : ℝ} (hq : q ∈ Qadm) : Qadm ∈ 𝓝 q := by
  have hf := (hasDerivAt_fq hq.1).continuousAt
  filter_upwards [Ioi_mem_nhds hq.1, Iio_mem_nhds hq.2.1,
    hf.eventually (Ioi_mem_nhds hq.2.2)] with x hx0 hx1 hxf
  exact ⟨hx0, hx1, hxf⟩

theorem contDiffAt_E {q v : ℝ} {n : ℕ∞ω} (hq : 0 < q) (hq1 : q < 1)
    (hx : v - q ^ 2 ≠ 0) (hy : 1 - v ≠ 0) (hv : v ≠ 0) :
    ContDiffAt ℝ n (fun p : ℝ × ℝ => E p.1 p.2) (q, v) := by
  have h1 : 1 + q ≠ 0 := by linarith
  have hl : Real.log q ≠ 0 := (log_q_neg hq hq1).ne
  unfold E aval delta
  fun_prop (disch := first | assumption | exact hq.ne')

/-- Local IFT, identified with the chosen actual plus/minus root by branch uniqueness. -/
theorem actual_root_contDiffAt {q : ℝ} (hq : q ∈ Qadm)
    (r : ℝ → ℝ) (isPlus : Bool)
    (hdom : if isPlus then q < r q ∧ r q < 1 else 1 < r q)
    (hzero : E q (r q) = 0) (hn : Ev q (r q) ≠ 0)
    (hu : ∀ x ∈ Qadm, ∀ v,
      (if isPlus then x < v ∧ v < 1 else 1 < v) → E x v = 0 → v = r x) :
    ContDiffAt ℝ ∞ r q := by
  have hv0 : 0 < r q := by cases isPlus <;> simp_all <;> linarith [hq.1]
  have hx : 0 < r q - q ^ 2 := by
    cases isPlus <;> simp_all <;> nlinarith [hq.1, hq.2.1, mul_pos hq.1 (sub_pos.mpr hq.2.1)]
  have hy : 1 - r q ≠ 0 := by cases isPlus <;> simp_all <;> linarith
  let F : ℝ × ℝ → ℝ := fun p => E p.1 p.2
  have hc : ContDiffAt ℝ ∞ F (q, r q) := contDiffAt_E hq.1 hq.2.1 hx.ne' hy hv0.ne'
  have hf := hc.differentiableAt (by simp)
  have hv := hasDerivAt_E_v hv0.ne' hx.ne' hy
  have hi : HasFDerivAt (fun v : ℝ => (q, v)) (ContinuousLinearMap.inr ℝ ℝ ℝ) (r q) := by
    convert (hasFDerivAt_const q (r q)).prodMk (hasFDerivAt_id (r q)) using 1 <;>
      first | rfl | (ext x <;> simp)
  have hd : fderiv ℝ F (q, r q) ∘L ContinuousLinearMap.inr ℝ ℝ ℝ =
      Ev q (r q) • ContinuousLinearMap.id ℝ ℝ := by
    have he := (hf.hasFDerivAt.comp (r q) hi).unique hv.hasFDerivAt
    convert he using 1
    ext x
    simp
  have hinv : (fderiv ℝ F (q, r q) ∘L ContinuousLinearMap.inr ℝ ℝ ℝ).IsInvertible := by
    rw [hd]
    apply ContinuousLinearMap.IsInvertible.of_inverse
      (g := (Ev q (r q))⁻¹ • ContinuousLinearMap.id ℝ ℝ)
    · ext x; simp [hn]
    · ext x; simp [hn]
  let b := hc.implicitFunction (by simp) hinv
  have hb : b q = r q := hc.implicitFunction_apply_self (by simp) hinv
  have hbc : ContDiffAt ℝ ∞ b q := hc.contDiffAt_implicitFunction (by simp) hinv
  have he : ∀ᶠ x in 𝓝 q, E x (b x) = 0 := by
    have hh := hc.eventually_apply_implicitFunction (by simp) hinv
    simpa only [F, hzero] using hh
  have hbd : ∀ᶠ x in 𝓝 q, if isPlus then x < b x ∧ b x < 1 else 1 < b x := by
    have hcont := hbc.continuousAt
    cases isPlus with
    | false =>
      simp only [Bool.false_eq_true, ↓reduceIte] at hdom ⊢
      exact continuousAt_const.eventually_lt hcont (by simpa only [hb] using hdom)
    | true =>
      simp only [↓reduceIte] at hdom ⊢
      exact (continuousAt_id.eventually_lt hcont (by simpa only [hb, id_eq] using hdom.1)).and
        (hcont.eventually_lt continuousAt_const (by simpa only [hb] using hdom.2))
  apply hbc.congr_of_eventuallyEq
  filter_upwards [Qadm_mem_nhds hq, he, hbd] with x hxa hxe hxd
  exact (hu x hxa (b x) hxd hxe).symm

theorem vPlus_contDiffAt {q : ℝ} (hq : q ∈ Qadm) : ContDiffAt ℝ ∞ vPlus q :=
  actual_root_contDiffAt hq vPlus true (vPlus_mem hq) (E_vPlus hq)
    (Ev_vPlus_pos hq).ne' (fun x hx v hv he => vPlus_unique hx hv.1 hv.2 he)

theorem vMinus_contDiffAt {q : ℝ} (hq : q ∈ Qadm) : ContDiffAt ℝ ∞ vMinus q :=
  actual_root_contDiffAt hq vMinus false (vMinus_mem hq) (E_vMinus hq)
    (Ev_vMinus_neg hq).ne (fun x hx v hv he => vMinus_unique hx hv he)

end EP1038.DLowerCert
