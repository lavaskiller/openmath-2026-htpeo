import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk19
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_72 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((641602184428442860232215631180595 : ℝ) / 5192296858534827628530496329220096) ((320847767109321833522608999707443 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((123568085937 : ℝ) / 1000000000000) ((61793032227 : ℝ) / 500000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1123568085937 : ℝ) / 1000000000000) ((561793032227 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((58254706221 : ℝ) / 500000000000) ((23305082717 : ℝ) / 200000000000) := rb_log h1 (by norm_num) dlower_log_879.1 dlower_log_880.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((58254706221 : ℝ) / 250000000000) ((23305082717 : ℝ) / 100000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460096353389 : ℝ) / 1000000000000) ((115032088919 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2090962971693 : ℝ) / 1000000000000) ((-41816349749 : ℝ) / 20000000000) := rb_log hqr (by norm_num) dlower_log_881.1 dlower_log_882.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((41816349749 : ℝ) / 20000000000) ((2090962971693 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((110020205909 : ℝ) / 500000000000) ((220071028887 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779928971113 : ℝ) / 1000000000000) ((389979794091 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7634535931 : ℝ) / 500000000000) ((238648677 : ℝ) / 15625000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((65569410303 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((61751031471 : ℝ) / 250000000000) ((4940171387 : ℝ) / 20000000000) := rb_widen (rb_sub (show RB ((65569410303 : ℝ) / 250000000000) ((65569410303 : ℝ) / 250000000000) ((65569410303 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((184430589697 : ℝ) / 250000000000))
  have h11 : RB z11 ((41852487413 : ℝ) / 125000000000) ((10463310079 : ℝ) / 31250000000) := rb_div_signed h10 (show RB ((184430589697 : ℝ) / 250000000000) ((184430589697 : ℝ) / 250000000000) ((184430589697 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-68385156609 : ℝ) / 62500000000) ((-218828903291 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_883.1 dlower_log_884.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-170680507477 : ℝ) / 200000000000) ((-853355006967 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((65569410303 : ℝ) / 250000000000))
  have h14 : RB z14 ((-41823488657 : ℝ) / 31250000000) ((-669175818511 : ℝ) / 500000000000) := rb_log (show RB ((65569410303 : ℝ) / 250000000000) ((65569410303 : ℝ) / 250000000000) ((65569410303 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_885.1 dlower_log_885.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((484949099637 : ℝ) / 1000000000000) ((484996630057 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((24820743961 : ℝ) / 1000000000000) ((6225069167 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7634535931 : ℝ) / 500000000000) ((238648677 : ℝ) / 15625000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((59608210529 : ℝ) / 40000000000)) - (z17)
  have h18 : RB z18 ((1474931747897 : ℝ) / 1000000000000) ((1474936191363 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((59608210529 : ℝ) / 40000000000) ((59608210529 : ℝ) / 40000000000) ((59608210529 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((19608210529 : ℝ) / 40000000000))
  have h19 : RB z19 ((601760877961 : ℝ) / 200000000000) ((3008813454307 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((19608210529 : ℝ) / 40000000000) ((19608210529 : ℝ) / 40000000000) ((19608210529 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((27538569679 : ℝ) / 25000000000) ((1101545799817 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_886.1 dlower_log_887.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((429562566313 : ℝ) / 500000000000) ((859161208389 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((59608210529 : ℝ) / 40000000000))
  have h22 : RB z22 ((398913871021 : ℝ) / 1000000000000) ((24932116939 : ℝ) / 62500000000) := rb_log (show RB ((59608210529 : ℝ) / 40000000000) ((59608210529 : ℝ) / 40000000000) ((59608210529 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_888.1 dlower_log_888.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((230105630801 : ℝ) / 500000000000) ((57530917171 : ℝ) / 125000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41452963 : ℝ) / 500000000000) ((150983979 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1123568085937 : ℝ) / 1000000000000) ((561793032227 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((157800655467 : ℝ) / 125000000000) ((315611411059 : ℝ) / 250000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((792113311623 : ℝ) / 500000000000) ((1584277322931 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1227927622013 : ℝ) / 1000000000000))
  have h28 : RB z28 ((486328907553 : ℝ) / 250000000000) ((486344471439 : ℝ) / 250000000000) := rb_widen (rb_mul h27 (show RB ((1227927622013 : ℝ) / 1000000000000) ((1227927622013 : ℝ) / 1000000000000) ((1227927622013 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7634535931 : ℝ) / 500000000000) ((238648677 : ℝ) / 15625000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3908475213603605680287 : ℝ) / 10000000000000000000000))
  have h30 : RB z30 ((4883321189 : ℝ) / 125000000000) ((3907793831 : ℝ) / 100000000000) := rb_div_signed h29 (show RB ((3908475213603605680287 : ℝ) / 10000000000000000000000) ((3908475213603605680287 : ℝ) / 10000000000000000000000) ((3908475213603605680287 : ℝ) / 10000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((96092206169 : ℝ) / 100000000000) ((120116678811 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1869296706021 : ℝ) / 1000000000000) ((467344661339 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((65569410303 : ℝ) / 250000000000)) ((24820743961 : ℝ) / 1000000000000) ((6225069167 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((59608210529 : ℝ) / 40000000000)) ((41452963 : ℝ) / 500000000000) ((150983979 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((65569410303 : ℝ) / 250000000000)) (wl := ((59608210529 : ℝ) / 40000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1869296706021 : ℝ) / 1000000000000) ≤ D0q (q) * (((59608210529 : ℝ) / 40000000000) - ((65569410303 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((59608210529 : ℝ) / 40000000000) * ((65569410303 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_73 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((320847767109321833522608999707443 : ℝ) / 2596148429267413814265248164610048) ((641742209113744070451719183532031 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((123586064453 : ℝ) / 1000000000000) ((123595053711 : ℝ) / 1000000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1123586064453 : ℝ) / 1000000000000) ((1123595053711 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((116525413583 : ℝ) / 1000000000000) ((116533414059 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_889.1 dlower_log_890.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((116525413583 : ℝ) / 500000000000) ((116533414059 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460080352441 : ℝ) / 1000000000000) ((230048176697 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-104540874373 : ℝ) / 50000000000) ((-2090744753277 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_891.1 dlower_log_892.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2090744753277 : ℝ) / 1000000000000) ((104540874373 : ℝ) / 50000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((22004806981 : ℝ) / 100000000000) ((220063378217 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779936621783 : ℝ) / 1000000000000) ((77995193019 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7636757663 : ℝ) / 500000000000) ((7637868651 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((211776470619 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((196500733317 : ℝ) / 1000000000000) ((196502955293 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((211776470619 : ℝ) / 1000000000000) ((211776470619 : ℝ) / 1000000000000) ((211776470619 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((788223529381 : ℝ) / 1000000000000))
  have h11 : RB z11 ((31161961993 : ℝ) / 125000000000) ((7790578591 : ℝ) / 31250000000) := rb_div_signed h10 (show RB ((788223529381 : ℝ) / 1000000000000) ((788223529381 : ℝ) / 1000000000000) ((788223529381 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1389115553167 : ℝ) / 1000000000000) ((-1389104245501 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_893.1 dlower_log_894.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-21668867139 : ℝ) / 20000000000) ((-54170663627 : ℝ) / 50000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((211776470619 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1552223944437 : ℝ) / 1000000000000) ((-310444788887 : ℝ) / 200000000000) := rb_log (show RB ((211776470619 : ℝ) / 1000000000000) ((211776470619 : ℝ) / 1000000000000) ((211776470619 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_895.1 dlower_log_895.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((93756117497 : ℝ) / 200000000000) ((468810671897 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((8684234091 : ℝ) / 1000000000000) ((272822483 : ℝ) / 31250000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7636757663 : ℝ) / 500000000000) ((7637868651 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((29805036597 : ℝ) / 20000000000)) - (z17)
  have h18 : RB z18 ((368744023137 : ℝ) / 250000000000) ((368744578631 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((29805036597 : ℝ) / 20000000000) ((29805036597 : ℝ) / 20000000000) ((29805036597 : ℝ) / 20000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((9805036597 : ℝ) / 20000000000))
  have h19 : RB z19 ((3008609050983 : ℝ) / 1000000000000) ((30086135833 : ℝ) / 10000000000) := rb_div_signed h18 (show RB ((9805036597 : ℝ) / 20000000000) ((9805036597 : ℝ) / 20000000000) ((9805036597 : ℝ) / 20000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((550738931323 : ℝ) / 500000000000) ((137684921137 : ℝ) / 125000000000) := rb_log h19 (by norm_num) dlower_log_896.1 dlower_log_897.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((21477073079 : ℝ) / 25000000000) ((859100959991 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((29805036597 : ℝ) / 20000000000))
  have h22 : RB z22 ((398945118997 : ℝ) / 1000000000000) ((398945118999 : ℝ) / 1000000000000) := rb_log (show RB ((29805036597 : ℝ) / 20000000000) ((29805036597 : ℝ) / 20000000000) ((29805036597 : ℝ) / 20000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_898.1 dlower_log_898.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((460137804161 : ℝ) / 1000000000000) ((230077920497 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41450767 : ℝ) / 1000000000000) ((75488553 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1123586064453 : ℝ) / 1000000000000) ((1123595053711 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((157805705529 : ℝ) / 125000000000) ((315616461181 : ℝ) / 250000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((792100637161 : ℝ) / 500000000000) ((396056655813 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1278475359231 : ℝ) / 1000000000000))
  have h28 : RB z28 ((2025362293283 : ℝ) / 1000000000000) ((1012697350633 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((1278475359231 : ℝ) / 1000000000000) ((1278475359231 : ℝ) / 1000000000000) ((1278475359231 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7636757663 : ℝ) / 500000000000) ((7637868651 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((6312005457182790243543 : ℝ) / 20000000000000000000000))
  have h30 : RB z30 ((387161017 : ℝ) / 8000000000) ((24201083801 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((6312005457182790243543 : ℝ) / 20000000000000000000000) ((6312005457182790243543 : ℝ) / 20000000000000000000000) ((6312005457182790243543 : ℝ) / 20000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((475798916199 : ℝ) / 500000000000) ((7612838983 : ℝ) / 8000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((481832592027 : ℝ) / 250000000000) ((96368773361 : ℝ) / 50000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((211776470619 : ℝ) / 1000000000000)) ((8684234091 : ℝ) / 1000000000000) ((272822483 : ℝ) / 31250000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((29805036597 : ℝ) / 20000000000)) ((41450767 : ℝ) / 1000000000000) ((75488553 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((211776470619 : ℝ) / 1000000000000)) (wl := ((29805036597 : ℝ) / 20000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((481832592027 : ℝ) / 250000000000) ≤ D0q (q) * (((29805036597 : ℝ) / 20000000000) - ((211776470619 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((29805036597 : ℝ) / 20000000000) * ((211776470619 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_74 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((641742209113744070451719183532031 : ℝ) / 5192296858534827628530496329220096) ((641788884008844473858220367649177 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((12359505371 : ℝ) / 100000000000) ((123604042969 : ℝ) / 1000000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((112359505371 : ℝ) / 100000000000) ((1123604042969 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((116533414057 : ℝ) / 1000000000000) ((11654141447 : ℝ) / 100000000000) := rb_log h1 (by norm_num) dlower_log_899.1 dlower_log_900.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((116533414057 : ℝ) / 500000000000) ((11654141447 : ℝ) / 50000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460064351619 : ℝ) / 1000000000000) ((230040176223 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2090744753287 : ℝ) / 1000000000000) ((-2090672024387 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_901.1 dlower_log_902.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2090672024387 : ℝ) / 1000000000000) ((2090744753287 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((44009614363 : ℝ) / 200000000000) ((110031690069 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((389968309931 : ℝ) / 500000000000) ((155990385637 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15275737301 : ℝ) / 1000000000000) ((15277959439 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((8886629473 : ℝ) / 40000000000)) - (z9)
  have h10 : RB z10 ((103443888693 : ℝ) / 500000000000) ((51722499881 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((8886629473 : ℝ) / 40000000000) ((8886629473 : ℝ) / 40000000000) ((8886629473 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((31113370527 : ℝ) / 40000000000))
  have h11 : RB z11 ((10639170177 : ℝ) / 40000000000) ((265982111253 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((31113370527 : ℝ) / 40000000000) ((31113370527 : ℝ) / 40000000000) ((31113370527 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-662168482063 : ℝ) / 500000000000) ((-1324326223389 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_903.1 dlower_log_904.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-1032919168737 : ℝ) / 1000000000000) ((-129111314783 : ℝ) / 125000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((8886629473 : ℝ) / 40000000000))
  have h14 : RB z14 ((-12034652907 : ℝ) / 8000000000) ((-1504331613373 : ℝ) / 1000000000000) := rb_log (show RB ((8886629473 : ℝ) / 40000000000) ((8886629473 : ℝ) / 40000000000) ((8886629473 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_905.1 dlower_log_905.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((117853111159 : ℝ) / 250000000000) ((471441095111 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1133209219 : ℝ) / 100000000000) ((2844185873 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15275737301 : ℝ) / 1000000000000) ((15277959439 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((372565095797 : ℝ) / 250000000000)) - (z17)
  have h18 : RB z18 ((1474982423749 : ℝ) / 1000000000000) ((1474984645887 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((372565095797 : ℝ) / 250000000000) ((372565095797 : ℝ) / 250000000000) ((372565095797 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((122565095797 : ℝ) / 250000000000))
  have h19 : RB z19 ((3008569475179 : ℝ) / 1000000000000) ((1504287003873 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((122565095797 : ℝ) / 250000000000) ((122565095797 : ℝ) / 250000000000) ((122565095797 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1101464708373 : ℝ) / 1000000000000) ((550733107463 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_906.1 dlower_log_907.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((171814532309 : ℝ) / 200000000000) ((859090698163 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((372565095797 : ℝ) / 250000000000))
  have h22 : RB z22 ((199475429253 : ℝ) / 500000000000) ((99737714627 : ℝ) / 250000000000) := rb_log (show RB ((372565095797 : ℝ) / 250000000000) ((372565095797 : ℝ) / 250000000000) ((372565095797 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_908.1 dlower_log_908.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((460121803037 : ℝ) / 1000000000000) ((460139839657 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41450591 : ℝ) / 1000000000000) ((37744019 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((112359505371 : ℝ) / 100000000000) ((1123604042969 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1262465844721 : ℝ) / 1000000000000) ((1262486045377 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((792087963001 : ℝ) / 500000000000) ((792100637163 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1268094646363 : ℝ) / 1000000000000))
  have h28 : RB z28 ((100444250533 : ℝ) / 50000000000) ((401783430947 : ℝ) / 200000000000) := rb_widen (rb_mul h27 (show RB ((1268094646363 : ℝ) / 1000000000000) ((1268094646363 : ℝ) / 1000000000000) ((1268094646363 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15275737301 : ℝ) / 1000000000000) ((15277959439 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3310847960920688624981 : ℝ) / 10000000000000000000000))
  have h30 : RB z30 ((46138443931 : ℝ) / 1000000000000) ((2307257781 : ℝ) / 50000000000) := rb_div_signed h29 (show RB ((3310847960920688624981 : ℝ) / 10000000000000000000000) ((3310847960920688624981 : ℝ) / 10000000000000000000000) ((3310847960920688624981 : ℝ) / 10000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((47692742219 : ℝ) / 50000000000) ((953861556069 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((95809234961 : ℝ) / 50000000000) ((191622884323 : ℝ) / 100000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((8886629473 : ℝ) / 40000000000)) ((1133209219 : ℝ) / 100000000000) ((2844185873 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((372565095797 : ℝ) / 250000000000)) ((41450591 : ℝ) / 1000000000000) ((37744019 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((8886629473 : ℝ) / 40000000000)) (wl := ((372565095797 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((95809234961 : ℝ) / 50000000000) ≤ D0q (q) * (((372565095797 : ℝ) / 250000000000) - ((8886629473 : ℝ) / 40000000000)) * (1 - (q) ^ 2 / (((372565095797 : ℝ) / 250000000000) * ((8886629473 : ℝ) / 40000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_75 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((641788884008844473858220367649177 : ℝ) / 5192296858534827628530496329220096) ((320917779451972438632360775883161 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((15450505371 : ℝ) / 125000000000) ((123613032227 : ℝ) / 1000000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((140450505371 : ℝ) / 125000000000) ((1123613032227 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((29135353617 : ℝ) / 250000000000) ((116549414817 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_909.1 dlower_log_910.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((29135353617 : ℝ) / 125000000000) ((116549414817 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((18401934037 : ℝ) / 40000000000) ((57508043953 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2090672024397 : ℝ) / 1000000000000) ((-1045299650393 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_911.1 dlower_log_912.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1045299650393 : ℝ) / 500000000000) ((2090672024397 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((8801922933 : ℝ) / 40000000000) ((220063381563 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779936618437 : ℝ) / 1000000000000) ((31198077067 : ℝ) / 40000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7638979719 : ℝ) / 500000000000) ((15280181737 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((27726761583 : ℝ) / 125000000000)) - (z9)
  have h10 : RB z10 ((206533910927 : ℝ) / 1000000000000) ((103268066613 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((27726761583 : ℝ) / 125000000000) ((27726761583 : ℝ) / 125000000000) ((27726761583 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((97273238417 : ℝ) / 125000000000))
  have h11 : RB z11 ((265404332023 : ℝ) / 1000000000000) ((33175898471 : ℝ) / 125000000000) := rb_div_signed h10 (show RB ((97273238417 : ℝ) / 125000000000) ((97273238417 : ℝ) / 125000000000) ((97273238417 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1326500834599 : ℝ) / 1000000000000) ((-331622518669 : ℝ) / 250000000000) := rb_log h11 (by norm_num) dlower_log_913.1 dlower_log_914.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-517303440841 : ℝ) / 500000000000) ((-1034578183233 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((27726761583 : ℝ) / 125000000000))
  have h14 : RB z14 ((-12047325347 : ℝ) / 8000000000) ((-1505915668373 : ℝ) / 1000000000000) := rb_log (show RB ((27726761583 : ℝ) / 125000000000) ((27726761583 : ℝ) / 125000000000) ((27726761583 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_915.1 dlower_log_915.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((471308786691 : ℝ) / 1000000000000) ((235668742571 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((11244435067 : ℝ) / 1000000000000) ((11289134217 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7638979719 : ℝ) / 500000000000) ((15280181737 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((745134468433 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1474988755129 : ℝ) / 1000000000000) ((368747744357 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((745134468433 : ℝ) / 500000000000) ((745134468433 : ℝ) / 500000000000) ((745134468433 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((245134468433 : ℝ) / 500000000000))
  have h19 : RB z19 ((1504264949517 : ℝ) / 500000000000) ((3008534431851 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((245134468433 : ℝ) / 500000000000) ((245134468433 : ℝ) / 500000000000) ((245134468433 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((550725776907 : ℝ) / 500000000000) ((110145306047 : ℝ) / 100000000000) := rb_log h19 (by norm_num) dlower_log_916.1 dlower_log_917.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((859062400253 : ℝ) / 1000000000000) ((53692527291 : ℝ) / 62500000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((745134468433 : ℝ) / 500000000000))
  have h22 : RB z22 ((39895659821 : ℝ) / 100000000000) ((99739149553 : ℝ) / 250000000000) := rb_log (show RB ((745134468433 : ℝ) / 500000000000) ((745134468433 : ℝ) / 500000000000) ((745134468433 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_918.1 dlower_log_918.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((460105802041 : ℝ) / 1000000000000) ((230061919223 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41450417 : ℝ) / 1000000000000) ((75487521 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((140450505371 : ℝ) / 125000000000) ((1123613032227 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((631243022687 : ℝ) / 500000000000) ((1262506246191 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1584150578291 : ℝ) / 1000000000000) ((792087963003 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((634227422101 : ℝ) / 500000000000))
  have h28 : RB z28 ((1004711737489 : ℝ) / 500000000000) ((2009455627411 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((634227422101 : ℝ) / 500000000000) ((634227422101 : ℝ) / 500000000000) ((634227422101 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7638979719 : ℝ) / 500000000000) ((15280181737 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((20660165753517230609439 : ℝ) / 62500000000000000000000))
  have h30 : RB z30 ((46218044727 : ℝ) / 1000000000000) ((9244953501 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((20660165753517230609439 : ℝ) / 62500000000000000000000) ((20660165753517230609439 : ℝ) / 62500000000000000000000) ((20660165753517230609439 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((190755046499 : ℝ) / 200000000000) ((953781955273 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((479134585507 : ℝ) / 250000000000) ((1916582517347 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((27726761583 : ℝ) / 125000000000)) ((11244435067 : ℝ) / 1000000000000) ((11289134217 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((745134468433 : ℝ) / 500000000000)) ((41450417 : ℝ) / 1000000000000) ((75487521 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((27726761583 : ℝ) / 125000000000)) (wl := ((745134468433 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((479134585507 : ℝ) / 250000000000) ≤ D0q (q) * (((745134468433 : ℝ) / 500000000000) - ((27726761583 : ℝ) / 125000000000)) * (1 - (q) ^ 2 / (((745134468433 : ℝ) / 500000000000) * ((27726761583 : ℝ) / 125000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
