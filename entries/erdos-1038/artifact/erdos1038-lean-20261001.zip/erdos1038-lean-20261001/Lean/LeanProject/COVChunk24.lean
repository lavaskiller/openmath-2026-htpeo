import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk20
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_120 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((63 : ℝ) / 83) ((1029 : ℝ) / 1349))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((44441987 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((44735313 : ℝ) / 100000000) ∧ 0 < certE k a ((138485561 : ℝ) / 100000000) ∧ certE k a ((69578937 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((44441987 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((22186319 : ℝ) / 50000000) ((44372639 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((44441987 : ℝ) / 100000000) ((44441987 : ℝ) / 100000000) ((44441987 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((55558013 : ℝ) / 100000000))
  have h3 : RB z3 ((15973443 : ℝ) / 20000000) ((39933609 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((55558013 : ℝ) / 100000000) ((55558013 : ℝ) / 100000000) ((55558013 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-899219 : ℝ) / 4000000) ((-2248047 : ℝ) / 10000000) := rb_log h3 (by norm_num) cov_log_2092.1 cov_log_2093.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-857391 : ℝ) / 5000000) ((-17063489 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((44441987 : ℝ) / 100000000))
  have h6 : RB z6 ((-10137319 : ℝ) / 12500000) ((-1621971 : ℝ) / 2000000) := rb_log (show RB ((44441987 : ℝ) / 100000000) ((44441987 : ℝ) / 100000000) ((44441987 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2094.1 cov_log_2094.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((6395073 : ℝ) / 10000000) ((64035063 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-165337 : ℝ) / 100000000) ((-81 : ℝ) / 100000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((44735313 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((11166491 : ℝ) / 25000000) ((8933193 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((44735313 : ℝ) / 100000000) ((44735313 : ℝ) / 100000000) ((44735313 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((55264687 : ℝ) / 100000000))
  have h12 : RB z12 ((80821889 : ℝ) / 100000000) ((80821891 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((55264687 : ℝ) / 100000000) ((55264687 : ℝ) / 100000000) ((55264687 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-5323059 : ℝ) / 25000000) ((-2661529 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_2095.1 cov_log_2096.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-16241447 : ℝ) / 100000000) ((-16161573 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((44735313 : ℝ) / 100000000))
  have h15 : RB z15 ((-80440701 : ℝ) / 100000000) ((-80440699 : ℝ) / 100000000) := rb_log (show RB ((44735313 : ℝ) / 100000000) ((44735313 : ℝ) / 100000000) ((44735313 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2097.1 cov_log_2097.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16049813 : ℝ) / 25000000) ((8034891 : ℝ) / 12500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((16637 : ℝ) / 20000000) ((32613 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((138485561 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((34604053 : ℝ) / 25000000) ((138416213 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((138485561 : ℝ) / 100000000) ((138485561 : ℝ) / 100000000) ((138485561 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((38485561 : ℝ) / 100000000))
  have h21 : RB z21 ((179828757 : ℝ) / 50000000) ((359657517 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((38485561 : ℝ) / 100000000) ((38485561 : ℝ) / 100000000) ((38485561 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((31999551 : ℝ) / 25000000) ((127998207 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2098.1 cov_log_2099.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((97155263 : ℝ) / 100000000) ((97635401 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((138485561 : ℝ) / 100000000))
  have h24 : RB z24 ((8139897 : ℝ) / 25000000) ((3255959 : ℝ) / 10000000) := rb_log (show RB ((138485561 : ℝ) / 100000000) ((138485561 : ℝ) / 100000000) ((138485561 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2100.1 cov_log_2100.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64595673 : ℝ) / 100000000) ((65075813 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((239803 : ℝ) / 50000000) ((3839 : ℝ) / 400000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((69578937 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((5563541 : ℝ) / 4000000) ((69544263 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((69578937 : ℝ) / 50000000) ((69578937 : ℝ) / 50000000) ((69578937 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((19578937 : ℝ) / 50000000))
  have h30 : RB z30 ((177599689 : ℝ) / 50000000) ((355199381 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((19578937 : ℝ) / 50000000) ((19578937 : ℝ) / 50000000) ((19578937 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((126750907 : ℝ) / 100000000) ((126750911 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_2101.1 cov_log_2102.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((96208519 : ℝ) / 100000000) ((96683979 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((69578937 : ℝ) / 50000000))
  have h33 : RB z33 ((2065243 : ℝ) / 6250000) ((3304389 : ℝ) / 10000000) := rb_log (show RB ((69578937 : ℝ) / 50000000) ((69578937 : ℝ) / 50000000) ((69578937 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2103.1 cov_log_2103.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63164629 : ℝ) / 100000000) ((63640091 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-475719 : ℝ) / 50000000) ((-118993 : ℝ) / 25000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((44441987 : ℝ) / 100000000)) ((-165337 : ℝ) / 100000000) ((-81 : ℝ) / 100000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((44735313 : ℝ) / 100000000)) ((16637 : ℝ) / 20000000) ((32613 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((138485561 : ℝ) / 100000000)) ((239803 : ℝ) / 50000000) ((3839 : ℝ) / 400000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((69578937 : ℝ) / 50000000)) ((-475719 : ℝ) / 50000000) ((-118993 : ℝ) / 25000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_120 {k A q d vp vm : ℝ}
    (hk : RB k ((63 : ℝ) / 20) ((1029 : ℝ) / 320))
    (hA : RB A ((63 : ℝ) / 83) ((1029 : ℝ) / 1349))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((44441987 : ℝ) / 100000000) ((44735313 : ℝ) / 100000000))
    (hm : RB vm ((138485561 : ℝ) / 100000000) ((69578937 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((2370343 : ℝ) / 3125000) ((19056457 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((77509 : ℝ) / 50000000) ((39011 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24960989 : ℝ) / 25000000) ((49922491 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((55264687 : ℝ) / 100000000) ((55558013 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((55178449 : ℝ) / 100000000) ((55471889 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((136737683 : ℝ) / 100000000) ((69072101 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((36737683 : ℝ) / 100000000) ((19072101 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((2370343 : ℝ) / 3125000) ((19056457 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((24917 : ℝ) / 50000000) ((50077 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99949923 : ℝ) / 100000000) ((49975083 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((38485561 : ℝ) / 100000000) ((19578937 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((2404143 : ℝ) / 6250000) ((39138361 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((96901063 : ℝ) / 50000000) ((198162683 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((146901063 : ℝ) / 50000000) ((298162683 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((262163041 : ℝ) / 100000000) ((136100037 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33538737 : ℝ) / 100000000) ((17018257 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((63 : ℝ) / 10) ((1029 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((8295219 : ℝ) / 50000000) ((211701 : ℝ) / 1250000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((8082377 : ℝ) / 50000000) ((16501529 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((58082377 : ℝ) / 50000000) ((116501529 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((11718781 : ℝ) / 12500000) ((94715887 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((44500507 : ℝ) / 25000000) ((7193419 : ℝ) / 4000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((12309147 : ℝ) / 20000000) ((62252711 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((111397 : ℝ) / 100000000) ((112679 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99887321 : ℝ) / 100000000) ((99888603 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((177801457 : ℝ) / 100000000) ((22454393 : ℝ) / 12500000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((83 : ℝ) / 20) ((1349 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1186063 : ℝ) / 50000000) ((2409639 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5886631 : ℝ) / 100000000) ((5925487 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105886631 : ℝ) / 100000000) ((105925487 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((277595611 : ℝ) / 100000000) ((144164627 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((378477 : ℝ) / 20000000) ((1901573 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20378477 : ℝ) / 20000000) ((101901573 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((34173419 : ℝ) / 100000000) ((1083867 : ℝ) / 3125000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((31176903 : ℝ) / 10000000) ((161506499 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((3697777 : ℝ) / 50000000) ((972931 : ℝ) / 12500000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((83 : ℝ) / 20) ((1349 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((58082377 : ℝ) / 25000000) ((116501529 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((147850889 : ℝ) / 50000000) ((76559147 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((137400497 : ℝ) / 20000000) ((142708123 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((58160669 : ℝ) / 100000000) ((15340647 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-27098043 : ℝ) / 50000000) ((-9767397 : ℝ) / 20000000) := rb_log h47 (by norm_num) cov_log_2104.1 cov_log_2105.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((100982799 : ℝ) / 50000000) ((51543307 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-48803837 : ℝ) / 50000000) ((-93399979 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3807903 : ℝ) / 100000000) ((5641591 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((24461543 : ℝ) / 50000000) ((76283549 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-12171147 : ℝ) / 25000000) ((-1711643 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((58082377 : ℝ) / 50000000) ((116501529 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-27098043 : ℝ) / 50000000) ((-9767397 : ℝ) / 20000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-12171147 : ℝ) / 25000000) ((-1711643 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((271 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5886631 : ℝ) / 100000000) ((5925487 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((105925487 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((271 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-112523 : ℝ) / 625000) ≤ formC0 k A q vp vm + hfun ((271 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_49, cov_h_25]
  have hP : ((23077493 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((1711643 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((1711643 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((1862041 : ℝ) / 3125000) ≤ EP1038.Arc.sinc ((167 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((397 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1279 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1279 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1299 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1299 : ℝ) / 500)) (lo := ((1279 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1319 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1319 : ℝ) / 500)) (lo := ((1299 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1339 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1339 : ℝ) / 500)) (lo := ((1319 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((271 : ℝ) / 100)) (lo := ((1339 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_120 {k : ℝ} (hk : RB k ((63 : ℝ) / 20) ((1029 : ℝ) / 320)) :
    RB (k / (k + 1)) ((63 : ℝ) / 83) ((1029 : ℝ) / 1349) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((63 : ℝ) / 83) ((1029 : ℝ) / 1349) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_120 {k : ℝ} (hk : RB k ((63 : ℝ) / 20) ((1029 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_120 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_120 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((44441987 : ℝ) / 100000000)) (ph := ((44735313 : ℝ) / 100000000)) (ml := ((138485561 : ℝ) / 100000000)) (mh := ((69578937 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_120 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_121 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1029 : ℝ) / 1349) ((105 : ℝ) / 137))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((8909283 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((22409891 : ℝ) / 50000000) ∧ 0 < certE k a ((4334899 : ℝ) / 3125000) ∧ certE k a ((139367771 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8909283 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((22238533 : ℝ) / 50000000) ((44477067 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((8909283 : ℝ) / 20000000) ((8909283 : ℝ) / 20000000) ((8909283 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11090717 : ℝ) / 20000000))
  have h3 : RB z3 ((40102967 : ℝ) / 50000000) ((80205937 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((11090717 : ℝ) / 20000000) ((11090717 : ℝ) / 20000000) ((11090717 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22057269 : ℝ) / 100000000) ((-1378579 : ℝ) / 6250000) := rb_log h3 (by norm_num) cov_log_2106.1 cov_log_2107.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-16905207 : ℝ) / 100000000) ((-16824999 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8909283 : ℝ) / 20000000))
  have h6 : RB z6 ((-20215963 : ℝ) / 25000000) ((-1617277 : ℝ) / 2000000) := rb_log (show RB ((8909283 : ℝ) / 20000000) ((8909283 : ℝ) / 20000000) ((8909283 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2108.1 cov_log_2108.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63958643 : ℝ) / 100000000) ((64038853 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-9839 : ℝ) / 6250000) ((-7721 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22409891 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((44750433 : ℝ) / 100000000) ((22375217 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22409891 : ℝ) / 50000000) ((22409891 : ℝ) / 50000000) ((22409891 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27590109 : ℝ) / 50000000))
  have h12 : RB z12 ((1267167 : ℝ) / 1562500) ((81098691 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((27590109 : ℝ) / 50000000) ((27590109 : ℝ) / 50000000) ((27590109 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-20950341 : ℝ) / 100000000) ((-327349 : ℝ) / 1562500) := rb_log h12 (by norm_num) cov_log_2109.1 cov_log_2110.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-16056831 : ℝ) / 100000000) ((-15980649 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22409891 : ℝ) / 50000000))
  have h15 : RB z15 ((-4012603 : ℝ) / 5000000) ((-40126029 : ℝ) / 50000000) := rb_log (show RB ((22409891 : ℝ) / 50000000) ((22409891 : ℝ) / 50000000) ((22409891 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2111.1 cov_log_2111.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64195227 : ℝ) / 100000000) ((64271411 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1979 : ℝ) / 2500000) ((38837 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((4334899 : ℝ) / 3125000)) - (z19)
  have h20 : RB z20 ((138647419 : ℝ) / 100000000) ((6932371 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((4334899 : ℝ) / 3125000) ((4334899 : ℝ) / 3125000) ((4334899 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1209899 : ℝ) / 3125000))
  have h21 : RB z21 ((358106903 : ℝ) / 100000000) ((358106907 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((1209899 : ℝ) / 3125000) ((1209899 : ℝ) / 3125000) ((1209899 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((15945767 : ℝ) / 12500000) ((6378307 : ℝ) / 5000000) := rb_log h21 (by norm_num) cov_log_2112.1 cov_log_2113.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((48652911 : ℝ) / 50000000) ((9776967 : ℝ) / 10000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((4334899 : ℝ) / 3125000))
  have h24 : RB z24 ((16363201 : ℝ) / 50000000) ((8181601 : ℝ) / 25000000) := rb_log (show RB ((4334899 : ℝ) / 3125000) ((4334899 : ℝ) / 3125000) ((4334899 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2114.1 cov_log_2114.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((32289709 : ℝ) / 50000000) ((16260817 : ℝ) / 25000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((463351 : ℝ) / 100000000) ((185441 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((139367771 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((69649211 : ℝ) / 50000000) ((139298423 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((139367771 : ℝ) / 100000000) ((139367771 : ℝ) / 100000000) ((139367771 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((39367771 : ℝ) / 100000000))
  have h30 : RB z30 ((88459683 : ℝ) / 25000000) ((22114921 : ℝ) / 6250000) := rb_div_signed h29 (show RB ((39367771 : ℝ) / 100000000) ((39367771 : ℝ) / 100000000) ((39367771 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((63183553 : ℝ) / 50000000) ((12636711 : ℝ) / 10000000) := rb_log h30 (by norm_num) cov_log_2115.1 cov_log_2116.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((96391217 : ℝ) / 100000000) ((19370141 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((139367771 : ℝ) / 100000000))
  have h33 : RB z33 ((2074663 : ℝ) / 6250000) ((3319461 : ℝ) / 10000000) := rb_log (show RB ((139367771 : ℝ) / 100000000) ((139367771 : ℝ) / 100000000) ((139367771 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2117.1 cov_log_2117.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63196607 : ℝ) / 100000000) ((63656097 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-45973 : ℝ) / 5000000) ((-229983 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8909283 : ℝ) / 20000000)) ((-9839 : ℝ) / 6250000) ((-7721 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22409891 : ℝ) / 50000000)) ((1979 : ℝ) / 2500000) ((38837 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((4334899 : ℝ) / 3125000)) ((463351 : ℝ) / 100000000) ((185441 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((139367771 : ℝ) / 100000000)) ((-45973 : ℝ) / 5000000) ((-229983 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_121 {k A q d vp vm : ℝ}
    (hk : RB k ((1029 : ℝ) / 320) ((105 : ℝ) / 32))
    (hA : RB A ((1029 : ℝ) / 1349) ((105 : ℝ) / 137))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((8909283 : ℝ) / 20000000) ((22409891 : ℝ) / 50000000))
    (hm : RB vm ((4334899 : ℝ) / 3125000) ((139367771 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((38112913 : ℝ) / 50000000) ((38294593 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((77363 : ℝ) / 50000000) ((155679 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99844321 : ℝ) / 100000000) ((49922637 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27590109 : ℝ) / 50000000) ((11090717 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((55094313 : ℝ) / 100000000) ((6920973 : ℝ) / 12500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((68835901 : ℝ) / 50000000) ((69507343 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((18835901 : ℝ) / 50000000) ((19507343 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((38112913 : ℝ) / 50000000) ((38294593 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((24879 : ℝ) / 50000000) ((24997 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49975003 : ℝ) / 50000000) ((49975121 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1209899 : ℝ) / 3125000) ((39367771 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((38697411 : ℝ) / 100000000) ((39348183 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((24215167 : ℝ) / 12500000) ((98959057 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((36715167 : ℝ) / 12500000) ((148959057 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((256313737 : ℝ) / 100000000) ((33181317 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((3356627 : ℝ) / 10000000) ((8511469 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1029 : ℝ) / 160) ((105 : ℝ) / 16) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((16936073 : ℝ) / 100000000) ((8640857 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((16501521 : ℝ) / 100000000) ((8419147 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((116501521 : ℝ) / 100000000) ((58419147 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((46948493 : ℝ) / 50000000) ((23705339 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((178280637 : ℝ) / 100000000) ((11252233 : ℝ) / 6250000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((61793347 : ℝ) / 100000000) ((15616083 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((5551 : ℝ) / 5000000) ((28057 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24971943 : ℝ) / 25000000) ((4994449 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((44520139 : ℝ) / 25000000) ((179835853 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1349 : ℝ) / 320) ((137 : ℝ) / 32) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((467153 : ℝ) / 20000000) ((74129 : ℝ) / 3125000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5875537 : ℝ) / 100000000) ((1477899 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105875537 : ℝ) / 100000000) ((26477899 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((54274709 : ℝ) / 20000000) ((2811429 : ℝ) / 1000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((377907 : ℝ) / 20000000) ((474601 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20377907 : ℝ) / 20000000) ((25474601 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((8550129 : ℝ) / 25000000) ((6938441 : ℝ) / 20000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((305574061 : ℝ) / 100000000) ((63167021 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((7137491 : ℝ) / 100000000) ((7492013 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1349 : ℝ) / 320) ((137 : ℝ) / 32) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((116501521 : ℝ) / 50000000) ((58419147 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((289880007 : ℝ) / 100000000) ((74874103 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((337714617 : ℝ) / 50000000) ((699852997 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7529483 : ℝ) / 12500000) ((63385619 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-12672557 : ℝ) / 25000000) ((-45593317 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2118.1 cov_log_2119.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((41234643 : ℝ) / 20000000) ((42076169 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-93400057 : ℝ) / 100000000) ((-44596181 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1803597 : ℝ) / 50000000) ((1340623 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((48147193 : ℝ) / 100000000) ((18782833 : ℝ) / 25000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-176769 : ℝ) / 390625) ((-1406103 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((116501521 : ℝ) / 100000000) ((58419147 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-12672557 : ℝ) / 25000000) ((-45593317 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-176769 : ℝ) / 390625) ((-1406103 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((27 : ℝ) / 10) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5875537 : ℝ) / 100000000) ((1477899 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((26477899 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((27 : ℝ) / 10) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-446767 : ℝ) / 3125000) ≤ formC0 k A q vp vm + hfun ((27 : ℝ) / 10) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_50, cov_h_25]
  have hP : ((37806719 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((1406103 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((1406103 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((1862041 : ℝ) / 3125000) ≤ EP1038.Arc.sinc ((167 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((397 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2639 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2639 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2679 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2679 : ℝ) / 1000)) (lo := ((2639 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((27 : ℝ) / 10)) (lo := ((2679 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_121 {k : ℝ} (hk : RB k ((1029 : ℝ) / 320) ((105 : ℝ) / 32)) :
    RB (k / (k + 1)) ((1029 : ℝ) / 1349) ((105 : ℝ) / 137) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1029 : ℝ) / 1349) ((105 : ℝ) / 137) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_121 {k : ℝ} (hk : RB k ((1029 : ℝ) / 320) ((105 : ℝ) / 32)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_121 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_121 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((8909283 : ℝ) / 20000000)) (ph := ((22409891 : ℝ) / 50000000)) (ml := ((4334899 : ℝ) / 3125000)) (mh := ((139367771 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_121 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_122 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((105 : ℝ) / 137) ((1071 : ℝ) / 1391))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((22321757 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((897979 : ℝ) / 2000000) ∧ 0 < certE k a ((138940539 : ℝ) / 100000000) ∧ certE k a ((13957123 : ℝ) / 10000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((22321757 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((8914833 : ℝ) / 20000000) ((22287083 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22321757 : ℝ) / 50000000) ((22321757 : ℝ) / 50000000) ((22321757 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((27678243 : ℝ) / 50000000))
  have h3 : RB z3 ((80522027 : ℝ) / 100000000) ((8052203 : ℝ) / 10000000) := rb_div_signed h2 (show RB ((27678243 : ℝ) / 50000000) ((27678243 : ℝ) / 50000000) ((27678243 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-10831971 : ℝ) / 50000000) ((-21663937 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2120.1 cov_log_2121.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-8340073 : ℝ) / 50000000) ((-16603747 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((22321757 : ℝ) / 50000000))
  have h6 : RB z6 ((-80646117 : ℝ) / 100000000) ((-16129223 : ℝ) / 20000000) := rb_log (show RB ((22321757 : ℝ) / 50000000) ((22321757 : ℝ) / 50000000) ((22321757 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2122.1 cov_log_2122.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63965969 : ℝ) / 100000000) ((6404237 : ℝ) / 10000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-75049 : ℝ) / 50000000) ((-73693 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((897979 : ℝ) / 2000000)) - (z10)
  have h11 : RB z11 ((44829601 : ℝ) / 100000000) ((22414801 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((897979 : ℝ) / 2000000) ((897979 : ℝ) / 2000000) ((897979 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((1102021 : ℝ) / 2000000))
  have h12 : RB z12 ((40679443 : ℝ) / 50000000) ((81358889 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((1102021 : ℝ) / 2000000) ((1102021 : ℝ) / 2000000) ((1102021 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-20630013 : ℝ) / 100000000) ((-2578751 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_2123.1 cov_log_2124.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-1985509 : ℝ) / 12500000) ((-395283 : ℝ) / 2500000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((897979 : ℝ) / 2000000))
  have h15 : RB z15 ((-80075579 : ℝ) / 100000000) ((-80075577 : ℝ) / 100000000) := rb_log (show RB ((897979 : ℝ) / 2000000) ((897979 : ℝ) / 2000000) ((897979 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2125.1 cov_log_2125.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((12838301 : ℝ) / 20000000) ((64264259 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((37719 : ℝ) / 50000000) ((37049 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((138940539 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((13887119 : ℝ) / 10000000) ((138871191 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((138940539 : ℝ) / 100000000) ((138940539 : ℝ) / 100000000) ((138940539 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((38940539 : ℝ) / 100000000))
  have h21 : RB z21 ((356623697 : ℝ) / 100000000) ((356623701 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((38940539 : ℝ) / 100000000) ((38940539 : ℝ) / 100000000) ((38940539 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((15893887 : ℝ) / 12500000) ((1271511 : ℝ) / 1000000) := rb_log h21 (by norm_num) cov_log_2126.1 cov_log_2127.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((97451569 : ℝ) / 100000000) ((97899949 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((138940539 : ℝ) / 100000000))
  have h24 : RB z24 ((32887587 : ℝ) / 100000000) ((32887589 : ℝ) / 100000000) := rb_log (show RB ((138940539 : ℝ) / 100000000) ((138940539 : ℝ) / 100000000) ((138940539 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2128.1 cov_log_2128.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((3228199 : ℝ) / 5000000) ((32506181 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((447913 : ℝ) / 100000000) ((896299 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((13957123 : ℝ) / 10000000)) - (z28)
  have h29 : RB z29 ((139501881 : ℝ) / 100000000) ((69750941 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((13957123 : ℝ) / 10000000) ((13957123 : ℝ) / 10000000) ((13957123 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3957123 : ℝ) / 10000000))
  have h30 : RB z30 ((176266799 : ℝ) / 50000000) ((352533601 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((3957123 : ℝ) / 10000000) ((3957123 : ℝ) / 10000000) ((3957123 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((62998787 : ℝ) / 50000000) ((62998789 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_2129.1 cov_log_2130.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((96567483 : ℝ) / 100000000) ((19402359 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((13957123 : ℝ) / 10000000))
  have h33 : RB z33 ((33340489 : ℝ) / 100000000) ((33340491 : ℝ) / 100000000) := rb_log (show RB ((13957123 : ℝ) / 10000000) ((13957123 : ℝ) / 10000000) ((13957123 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2131.1 cov_log_2131.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((3951687 : ℝ) / 6250000) ((31835653 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-35563 : ℝ) / 4000000) ((-444757 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((22321757 : ℝ) / 50000000)) ((-75049 : ℝ) / 50000000) ((-73693 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((897979 : ℝ) / 2000000)) ((37719 : ℝ) / 50000000) ((37049 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((138940539 : ℝ) / 100000000)) ((447913 : ℝ) / 100000000) ((896299 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((13957123 : ℝ) / 10000000)) ((-35563 : ℝ) / 4000000) ((-444757 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_122 {k A q d vp vm : ℝ}
    (hk : RB k ((105 : ℝ) / 32) ((1071 : ℝ) / 320))
    (hA : RB A ((105 : ℝ) / 137) ((1071 : ℝ) / 1391))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((22321757 : ℝ) / 50000000) ((897979 : ℝ) / 2000000))
    (hm : RB vm ((138940539 : ℝ) / 100000000) ((13957123 : ℝ) / 10000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((15317837 : ℝ) / 20000000) ((38470787 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((154453 : ℝ) / 100000000) ((7767 : ℝ) / 5000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((4992233 : ℝ) / 5000000) ((99845547 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((1102021 : ℝ) / 2000000) ((27678243 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((1719233 : ℝ) / 3125000) ((55270987 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((69285161 : ℝ) / 50000000) ((13985447 : ℝ) / 10000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((19285161 : ℝ) / 50000000) ((3985447 : ℝ) / 10000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((15317837 : ℝ) / 20000000) ((38470787 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((24843 : ℝ) / 50000000) ((49913 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99950087 : ℝ) / 100000000) ((49975157 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((38940539 : ℝ) / 100000000) ((3957123 : ℝ) / 10000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((19460551 : ℝ) / 50000000) ((39551569 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((9682193 : ℝ) / 5000000) ((49421503 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((14682193 : ℝ) / 5000000) ((74421503 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((250912883 : ℝ) / 100000000) ((129633349 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33592441 : ℝ) / 100000000) ((34054859 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((105 : ℝ) / 16) ((1071 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((17281707 : ℝ) / 100000000) ((17627349 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((8419143 : ℝ) / 50000000) ((17175061 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((58419143 : ℝ) / 50000000) ((117175061 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((94041589 : ℝ) / 100000000) ((23731929 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((22319399 : ℝ) / 12500000) ((180237671 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((31013969 : ℝ) / 50000000) ((62666017 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((55331 : ℝ) / 50000000) ((111803 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99888197 : ℝ) / 100000000) ((49944669 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178355561 : ℝ) / 100000000) ((180038217 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((137 : ℝ) / 32) ((1391 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1150251 : ℝ) / 50000000) ((2335767 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5865177 : ℝ) / 100000000) ((5898739 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105865177 : ℝ) / 100000000) ((105898739 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((265629367 : ℝ) / 100000000) ((68640041 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((94339 : ℝ) / 5000000) ((1895347 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((5094339 : ℝ) / 5000000) ((101895347 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((2139141 : ℝ) / 6250000) ((34700317 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((299855623 : ℝ) / 100000000) ((309260481 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((862273 : ℝ) / 12500000) ((1444721 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((137 : ℝ) / 32) ((1391 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((58419143 : ℝ) / 25000000) ((117175061 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((71126331 : ℝ) / 25000000) ((293321557 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((41551393 : ℝ) / 6250000) ((687399427 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((31140919 : ℝ) / 50000000) ((13076803 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-23675017 : ℝ) / 50000000) ((-42489237 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2132.1 cov_log_2133.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((210380831 : ℝ) / 100000000) ((107294231 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-89192441 : ℝ) / 100000000) ((-16996949 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((340483 : ℝ) / 10000000) ((5087487 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1885391 : ℝ) / 4000000) ((73751107 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-21028833 : ℝ) / 50000000) ((-5616819 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((58419143 : ℝ) / 50000000) ((117175061 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-23675017 : ℝ) / 50000000) ((-42489237 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-21028833 : ℝ) / 50000000) ((-5616819 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((269 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5865177 : ℝ) / 100000000) ((5898739 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((105898739 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((269 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-10756249 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((269 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_51, cov_h_25]
  have hP : ((15058867 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((5616819 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((5616819 : ℝ) / 50000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((269 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_122 {k : ℝ} (hk : RB k ((105 : ℝ) / 32) ((1071 : ℝ) / 320)) :
    RB (k / (k + 1)) ((105 : ℝ) / 137) ((1071 : ℝ) / 1391) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((105 : ℝ) / 137) ((1071 : ℝ) / 1391) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_122 {k : ℝ} (hk : RB k ((105 : ℝ) / 32) ((1071 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_122 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_122 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((22321757 : ℝ) / 50000000)) (ph := ((897979 : ℝ) / 2000000)) (ml := ((138940539 : ℝ) / 100000000)) (mh := ((13957123 : ℝ) / 10000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_122 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_123 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1071 : ℝ) / 1391) ((273 : ℝ) / 353))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((894681 : ℝ) / 2000000) < 0 ∧ 0 < certE k a ((175677 : ℝ) / 390625) ∧ 0 < certE k a ((34789307 : ℝ) / 25000000) ∧ certE k a ((4367767 : ℝ) / 3125000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((894681 : ℝ) / 2000000)) - (z1)
  have h2 : RB z2 ((44664701 : ℝ) / 100000000) ((22332351 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((894681 : ℝ) / 2000000) ((894681 : ℝ) / 2000000) ((894681 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((1105319 : ℝ) / 2000000))
  have h3 : RB z3 ((20204439 : ℝ) / 25000000) ((80817759 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((1105319 : ℝ) / 2000000) ((1105319 : ℝ) / 2000000) ((1105319 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-425947 : ℝ) / 2000000) ((-4259469 : ℝ) / 20000000) := rb_log h3 (by norm_num) cov_log_2134.1 cov_log_2135.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-4117689 : ℝ) / 25000000) ((-16397883 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((894681 : ℝ) / 2000000))
  have h6 : RB z6 ((-20110881 : ℝ) / 25000000) ((-40221761 : ℝ) / 50000000) := rb_log (show RB ((894681 : ℝ) / 2000000) ((894681 : ℝ) / 2000000) ((894681 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2136.1 cov_log_2136.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((31986383 : ℝ) / 50000000) ((64045641 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-143301 : ℝ) / 100000000) ((-35211 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((175677 : ℝ) / 390625)) - (z10)
  have h11 : RB z11 ((44903963 : ℝ) / 100000000) ((11225991 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((175677 : ℝ) / 390625) ((175677 : ℝ) / 390625) ((175677 : ℝ) / 390625) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((214948 : ℝ) / 390625))
  have h12 : RB z12 ((81603971 : ℝ) / 100000000) ((40801987 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((214948 : ℝ) / 390625) ((214948 : ℝ) / 390625) ((214948 : ℝ) / 390625) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-20329227 : ℝ) / 100000000) ((-10164611 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_2137.1 cov_log_2138.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15722037 : ℝ) / 100000000) ((-15652477 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((175677 : ℝ) / 390625))
  have h15 : RB z15 ((-15982019 : ℝ) / 20000000) ((-79910093 : ℝ) / 100000000) := rb_log (show RB ((175677 : ℝ) / 390625) ((175677 : ℝ) / 390625) ((175677 : ℝ) / 390625) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2139.1 cov_log_2139.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((8023507 : ℝ) / 12500000) ((32128809 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((71989 : ℝ) / 100000000) ((28311 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((34789307 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((139087879 : ℝ) / 100000000) ((3477197 : ℝ) / 2500000) := rb_widen (rb_sub (show RB ((34789307 : ℝ) / 25000000) ((34789307 : ℝ) / 25000000) ((34789307 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((9789307 : ℝ) / 25000000))
  have h21 : RB z21 ((88800897 : ℝ) / 25000000) ((44400449 : ℝ) / 12500000) := rb_div_signed h20 (show RB ((9789307 : ℝ) / 25000000) ((9789307 : ℝ) / 25000000) ((9789307 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((31688023 : ℝ) / 25000000) ((3961003 : ℝ) / 3125000) := rb_log h21 (by norm_num) cov_log_2140.1 cov_log_2141.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((24398183 : ℝ) / 25000000) ((98026409 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((34789307 : ℝ) / 25000000))
  have h24 : RB z24 ((1032607 : ℝ) / 3125000) ((16521713 : ℝ) / 50000000) := rb_log (show RB ((34789307 : ℝ) / 25000000) ((34789307 : ℝ) / 25000000) ((34789307 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2142.1 cov_log_2142.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((32274653 : ℝ) / 50000000) ((12996597 : ℝ) / 20000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((433239 : ℝ) / 100000000) ((433461 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((4367767 : ℝ) / 3125000)) - (z28)
  have h29 : RB z29 ((27939839 : ℝ) / 20000000) ((34924799 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4367767 : ℝ) / 3125000) ((4367767 : ℝ) / 3125000) ((4367767 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((1242767 : ℝ) / 3125000))
  have h30 : RB z30 ((351280637 : ℝ) / 100000000) ((351280641 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((1242767 : ℝ) / 3125000) ((1242767 : ℝ) / 3125000) ((1242767 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((5025661 : ℝ) / 4000000) ((125641529 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_2143.1 cov_log_2144.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((96737651 : ℝ) / 100000000) ((97167529 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((4367767 : ℝ) / 3125000))
  have h33 : RB z33 ((33481761 : ℝ) / 100000000) ((33481763 : ℝ) / 100000000) := rb_log (show RB ((4367767 : ℝ) / 3125000) ((4367767 : ℝ) / 3125000) ((4367767 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2145.1 cov_log_2145.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((3953493 : ℝ) / 6250000) ((7960721 : ℝ) / 12500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-860179 : ℝ) / 100000000) ((-86059 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((894681 : ℝ) / 2000000)) ((-143301 : ℝ) / 100000000) ((-35211 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((175677 : ℝ) / 390625)) ((71989 : ℝ) / 100000000) ((28311 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((34789307 : ℝ) / 25000000)) ((433239 : ℝ) / 100000000) ((433461 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((4367767 : ℝ) / 3125000)) ((-860179 : ℝ) / 100000000) ((-86059 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_123 {k A q d vp vm : ℝ}
    (hk : RB k ((1071 : ℝ) / 320) ((273 : ℝ) / 80))
    (hA : RB A ((1071 : ℝ) / 1391) ((273 : ℝ) / 353))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((894681 : ℝ) / 2000000) ((175677 : ℝ) / 390625))
    (hm : RB vm ((34789307 : ℝ) / 25000000) ((4367767 : ℝ) / 3125000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((19235393 : ℝ) / 25000000) ((77283479 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((77099 : ℝ) / 50000000) ((77513 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49922487 : ℝ) / 50000000) ((49922901 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((214948 : ℝ) / 390625) ((1105319 : ℝ) / 2000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27470691 : ℝ) / 50000000) ((13795183 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((17429447 : ℝ) / 12500000) ((28133067 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((4929447 : ℝ) / 12500000) ((8133067 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((19235393 : ℝ) / 25000000) ((77283479 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3101 : ℝ) / 6250000) ((9967 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19990033 : ℝ) / 20000000) ((6246899 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((9789307 : ℝ) / 25000000) ((1242767 : ℝ) / 3125000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((39137713 : ℝ) / 100000000) ((39748813 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((193569483 : ℝ) / 100000000) ((24683187 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((293569483 : ℝ) / 100000000) ((37183187 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((245909691 : ℝ) / 100000000) ((12678907 : ℝ) / 5000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((525271 : ℝ) / 1562500) ((34063487 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1071 : ℝ) / 160) ((273 : ℝ) / 40) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((17627341 : ℝ) / 100000000) ((17972983 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4293763 : ℝ) / 25000000) ((17511827 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((29293763 : ℝ) / 25000000) ((117511827 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((23545979 : ℝ) / 25000000) ((47517247 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((89412713 : ℝ) / 50000000) ((180440409 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((62250663 : ℝ) / 100000000) ((3928659 : ℝ) / 6250000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((110323 : ℝ) / 100000000) ((111403 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99888597 : ℝ) / 100000000) ((99889677 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178626209 : ℝ) / 100000000) ((90120671 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1391 : ℝ) / 320) ((353 : ℝ) / 80) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((141643 : ℝ) / 6250000) ((287563 : ℝ) / 12500000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5855479 : ℝ) / 100000000) ((14717 : ℝ) / 250000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105855479 : ℝ) / 100000000) ((264717 : ℝ) / 250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((260308881 : ℝ) / 100000000) ((134252889 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1884117 : ℝ) / 100000000) ((378479 : ℝ) / 20000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101884117 : ℝ) / 100000000) ((20378479 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((17125367 : ℝ) / 50000000) ((34708103 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((58911923 : ℝ) / 20000000) ((303213881 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((6675569 : ℝ) / 100000000) ((871931 : ℝ) / 12500000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1391 : ℝ) / 320) ((353 : ℝ) / 80) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((29293763 : ℝ) / 12500000) ((117511827 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((55905407 : ℝ) / 20000000) ((287641627 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((655071897 : ℝ) / 100000000) ((676025863 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8037553 : ℝ) / 12500000) ((67359019 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-22080199 : ℝ) / 50000000) ((-39513337 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2146.1 cov_log_2147.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((6705889 : ℝ) / 3125000) ((218796079 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-10623103 : ℝ) / 12500000) ((-10097141 : ℝ) / 12500000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((640341 : ℝ) / 20000000) ((4816839 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2868727 : ℝ) / 6250000) ((9019529 : ℝ) / 12500000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-4885649 : ℝ) / 12500000) ((-269403 : ℝ) / 3125000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((29293763 : ℝ) / 25000000) ((117511827 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-22080199 : ℝ) / 50000000) ((-39513337 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-4885649 : ℝ) / 12500000) ((-269403 : ℝ) / 3125000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((269 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5855479 : ℝ) / 100000000) ((14717 : ℝ) / 250000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((264717 : ℝ) / 500000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((269 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-7566613 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((269 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_51, cov_h_25]
  have hP : ((11523327 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((269403 : ℝ) / 3125000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((269403 : ℝ) / 3125000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((269 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_123 {k : ℝ} (hk : RB k ((1071 : ℝ) / 320) ((273 : ℝ) / 80)) :
    RB (k / (k + 1)) ((1071 : ℝ) / 1391) ((273 : ℝ) / 353) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1071 : ℝ) / 1391) ((273 : ℝ) / 353) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_123 {k : ℝ} (hk : RB k ((1071 : ℝ) / 320) ((273 : ℝ) / 80)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_123 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_123 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((894681 : ℝ) / 2000000)) (ph := ((175677 : ℝ) / 390625)) (ml := ((34789307 : ℝ) / 25000000)) (mh := ((4367767 : ℝ) / 3125000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_123 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_124 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((273 : ℝ) / 353) ((1113 : ℝ) / 1433))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((22409343 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((45043303 : ℝ) / 100000000) ∧ 0 < certE k a ((34841791 : ℝ) / 25000000) ∧ certE k a ((69979993 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((22409343 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((44749337 : ℝ) / 100000000) ((22374669 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22409343 : ℝ) / 50000000) ((22409343 : ℝ) / 50000000) ((22409343 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((27590657 : ℝ) / 50000000))
  have h3 : RB z3 ((81095091 : ℝ) / 100000000) ((40547547 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((27590657 : ℝ) / 50000000) ((27590657 : ℝ) / 50000000) ((27590657 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2619347 : ℝ) / 12500000) ((-20954771 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2148.1 cov_log_2149.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-16275413 : ℝ) / 100000000) ((-8102907 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((22409343 : ℝ) / 50000000))
  have h6 : RB z6 ((-16050901 : ℝ) / 20000000) ((-80254503 : ℝ) / 100000000) := rb_log (show RB ((22409343 : ℝ) / 50000000) ((22409343 : ℝ) / 50000000) ((22409343 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2150.1 cov_log_2150.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((6397909 : ℝ) / 10000000) ((64048691 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-136977 : ℝ) / 100000000) ((-16843 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((45043303 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((22486977 : ℝ) / 50000000) ((8994791 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((45043303 : ℝ) / 100000000) ((45043303 : ℝ) / 100000000) ((45043303 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((54956697 : ℝ) / 100000000))
  have h12 : RB z12 ((10229407 : ℝ) / 12500000) ((81835259 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((54956697 : ℝ) / 100000000) ((54956697 : ℝ) / 100000000) ((54956697 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-5011551 : ℝ) / 25000000) ((-20046199 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2151.1 cov_log_2152.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3892433 : ℝ) / 25000000) ((-15503151 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((45043303 : ℝ) / 100000000))
  have h15 : RB z15 ((-19938647 : ℝ) / 25000000) ((-39877293 : ℝ) / 50000000) := rb_log (show RB ((45043303 : ℝ) / 100000000) ((45043303 : ℝ) / 100000000) ((45043303 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2153.1 cov_log_2153.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((32092427 : ℝ) / 50000000) ((64251437 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((68787 : ℝ) / 100000000) ((67687 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((34841791 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((27859563 : ℝ) / 20000000) ((17412227 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((34841791 : ℝ) / 25000000) ((34841791 : ℝ) / 25000000) ((34841791 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((9841791 : ℝ) / 25000000))
  have h21 : RB z21 ((176921323 : ℝ) / 50000000) ((7076853 : ℝ) / 2000000) := rb_div_signed h20 (show RB ((9841791 : ℝ) / 25000000) ((9841791 : ℝ) / 25000000) ((9841791 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((31592053 : ℝ) / 25000000) ((15796027 : ℝ) / 12500000) := rb_log h21 (by norm_num) cov_log_2154.1 cov_log_2155.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((97729523 : ℝ) / 100000000) ((19629843 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((34841791 : ℝ) / 25000000))
  have h24 : RB z24 ((33194173 : ℝ) / 100000000) ((1327767 : ℝ) / 4000000) := rb_log (show RB ((34841791 : ℝ) / 25000000) ((34841791 : ℝ) / 25000000) ((34841791 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2156.1 cov_log_2156.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16133837 : ℝ) / 25000000) ((32477521 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((419281 : ℝ) / 100000000) ((838979 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((69979993 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((139890637 : ℝ) / 100000000) ((69945319 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((69979993 : ℝ) / 50000000) ((69979993 : ℝ) / 50000000) ((69979993 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((19979993 : ℝ) / 50000000))
  have h30 : RB z30 ((350076791 : ℝ) / 100000000) ((70015359 : ℝ) / 20000000) := rb_div_signed h29 (show RB ((19979993 : ℝ) / 50000000) ((19979993 : ℝ) / 50000000) ((19979993 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((62649117 : ℝ) / 50000000) ((62649119 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_2157.1 cov_log_2158.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((96902033 : ℝ) / 100000000) ((97318171 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((69979993 : ℝ) / 50000000))
  have h33 : RB z33 ((16809319 : ℝ) / 50000000) ((420233 : ℝ) / 1250000) := rb_log (show RB ((69979993 : ℝ) / 50000000) ((69979993 : ℝ) / 50000000) ((69979993 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2159.1 cov_log_2159.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63283393 : ℝ) / 100000000) ((63699533 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-416337 : ℝ) / 50000000) ((-41653 : ℝ) / 10000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((22409343 : ℝ) / 50000000)) ((-136977 : ℝ) / 100000000) ((-16843 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((45043303 : ℝ) / 100000000)) ((68787 : ℝ) / 100000000) ((67687 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((34841791 : ℝ) / 25000000)) ((419281 : ℝ) / 100000000) ((838979 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((69979993 : ℝ) / 50000000)) ((-416337 : ℝ) / 50000000) ((-41653 : ℝ) / 10000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_124 {k A q d vp vm : ℝ}
    (hk : RB k ((273 : ℝ) / 80) ((1113 : ℝ) / 320))
    (hA : RB A ((273 : ℝ) / 353) ((1113 : ℝ) / 1433))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((22409343 : ℝ) / 50000000) ((45043303 : ℝ) / 100000000))
    (hm : RB vm ((34841791 : ℝ) / 25000000) ((69979993 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((77283477 : ℝ) / 100000000) ((19403841 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((76979 : ℝ) / 50000000) ((154733 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99845267 : ℝ) / 100000000) ((49923021 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((54956697 : ℝ) / 100000000) ((27590657 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((2743583 : ℝ) / 5000000) ((27548179 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((28053933 : ℝ) / 20000000) ((141448909 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((8053933 : ℝ) / 20000000) ((41448909 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((77283477 : ℝ) / 100000000) ((19403841 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((12387 : ℝ) / 25000000) ((311 : ℝ) / 625000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((624689 : ℝ) / 625000) ((24987613 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((9841791 : ℝ) / 25000000) ((19979993 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((19673787 : ℝ) / 50000000) ((39940187 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((96749017 : ℝ) / 50000000) ((9862789 : ℝ) / 5000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((146749017 : ℝ) / 50000000) ((14862789 : ℝ) / 5000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((241260873 : ℝ) / 100000000) ((248325881 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33641061 : ℝ) / 100000000) ((34071779 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((273 : ℝ) / 40) ((1113 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((718919 : ℝ) / 4000000) ((18318617 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((8755909 : ℝ) / 50000000) ((1115537 : ℝ) / 6250000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((58755909 : ℝ) / 50000000) ((7365537 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((94323861 : ℝ) / 100000000) ((951413 : ℝ) / 1000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((179091137 : ℝ) / 100000000) ((56451 : ℝ) / 31250) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((62462531 : ℝ) / 100000000) ((63042601 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((110001 : ℝ) / 100000000) ((4441 : ℝ) / 4000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((3995559 : ℝ) / 4000000) ((99889999 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178892301 : ℝ) / 100000000) ((180444491 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((353 : ℝ) / 80) ((1433 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((558269 : ℝ) / 25000000) ((226629 : ℝ) / 10000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((292319 : ℝ) / 5000000) ((1468921 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((5292319 : ℝ) / 5000000) ((26468921 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((2553659 : ℝ) / 1000000) ((131458363 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1881539 : ℝ) / 100000000) ((377909 : ℝ) / 20000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101881539 : ℝ) / 100000000) ((20377909 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3427403 : ℝ) / 10000000) ((34715581 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((28963993 : ℝ) / 10000000) ((297632307 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((6467879 : ℝ) / 100000000) ((1686303 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((353 : ℝ) / 80) ((1433 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((58755909 : ℝ) / 25000000) ((7365537 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((137450967 : ℝ) / 50000000) ((14119883 : ℝ) / 5000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((16152113 : ℝ) / 2500000) ((665603333 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((66293237 : ℝ) / 100000000) ((8663969 : ℝ) / 12500000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-41108231 : ℝ) / 100000000) ((-36655571 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2160.1 cov_log_2161.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((6837377 : ℝ) / 3125000) ((13937731 : ℝ) / 6250000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-10097151 : ℝ) / 12500000) ((-76569511 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((749639 : ℝ) / 25000000) ((4550747 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((5556823 : ℝ) / 12500000) ((35179593 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-567541 : ℝ) / 1562500) ((-248413 : ℝ) / 4000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((58755909 : ℝ) / 50000000) ((7365537 : ℝ) / 6250000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-41108231 : ℝ) / 100000000) ((-36655571 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-567541 : ℝ) / 1562500) ((-248413 : ℝ) / 4000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((67 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((292319 : ℝ) / 5000000) ((1468921 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((26468921 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((67 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-215779 : ℝ) / 5000000) ≤ formC0 k A q vp vm + hfun ((67 : ℝ) / 25) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_52, cov_h_25]
  have hP : ((4138729 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((248413 : ℝ) / 4000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((248413 : ℝ) / 4000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((67 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_124 {k : ℝ} (hk : RB k ((273 : ℝ) / 80) ((1113 : ℝ) / 320)) :
    RB (k / (k + 1)) ((273 : ℝ) / 353) ((1113 : ℝ) / 1433) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((273 : ℝ) / 353) ((1113 : ℝ) / 1433) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_124 {k : ℝ} (hk : RB k ((273 : ℝ) / 80) ((1113 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_124 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_124 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((22409343 : ℝ) / 50000000)) (ph := ((45043303 : ℝ) / 100000000)) (ml := ((34841791 : ℝ) / 25000000)) (mh := ((69979993 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_124 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
