import LeanProject.JumpAdjointEquality
import LeanProject.MaterialDictionary

/-! Exact jump adjoint identity for the actual sorted residual-root target. -/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset

namespace EP1038.Stage11
open EP1038.Arc EP1038.AtomicQuantile

theorem atomicVelocity_adjoint_eq {ι : Type*} (s : Finset ι)
    {k ρ c r d0 ρ1 ρ2 σ1 σ2 : ℝ} (δ z : ι → ℝ)
    (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1) (ha0 : 0 ≤ alpha k ρ 0) (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (hz : ∀ i ∈ s, z i ∈ Ioo (-1 : ℝ) 1) :
    AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (atomicVelocity s k ρ c r d0 δ z) ∧
      Lfun r ρ1 ρ2 σ1 σ2 (atomicVelocity s k ρ c r d0 δ z) = 0 := by
  have hz' : ∀ i ∈ s, z i ∈ Icc (-1 : ℝ) 1 := fun i hi => ⟨(hz i hi).1.le, (hz i hi).2.le⟩
  obtain ⟨M, hM, hfc⟩ := velocityRemainder_XLip s (c := c) (d0 := d0) δ z hk h0 h1 hr.le ha0
  have hdec := atomicVelocity_decomposition s (c := c) (r := r) (d0 := d0) δ z hk h0 h1 hz'
  have h := finite_jump_adjoint_eq hr h10 h11 h20 h21 hs1 hs2 hM hfc s
    (fun i => jumpDensity k ρ (z i) * δ i) z hz
  rw [← hdec] at h
  exact h

namespace AngleReference

theorem step_adjoint_eq (A : AngleReference) {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ)
    {c r ρ1 ρ2 σ1 σ2 : ℝ} (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) :
    AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (A.angularVelocity c r (step hn d)) ∧
      Lfun r ρ1 ρ2 σ1 σ2 (A.angularVelocity c r (step hn d)) = 0 := by
  rw [A.angularVelocity_step hn d c r]
  exact atomicVelocity_adjoint_eq (range (n - 1))
    (fun i => entry hn d (i + 1) - entry hn d i) (A.threshold n)
    A.k_pos.le A.rho_pos.le A.rho_lt_one A.density_zero_nonneg
    hr h10 h11 h20 h21 hs1 hs2 (fun i hi => A.threshold_interior hn hi)

theorem step_velocity_pi (A : AngleReference) {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ)
    (c r : ℝ) : A.angularVelocity c r (step hn d) π =
      alpha A.k A.ρ π * (entry hn d (n - 1) - (c + r)) := by
  rw [A.angularVelocity_step hn d c r,
    atomicVelocity_pi (range (n - 1)) A.k A.ρ c r (entry hn d 0)
      (fun i => entry hn d (i + 1) - entry hn d i) (A.threshold n)
      (fun i hi => (A.threshold_interior hn hi).1), sum_jumps hn d]
  rw [entry_eq hn d (by omega : n - 1 < n)]

end AngleReference

namespace SeparatedReference

/-- The exact identity is applied to the actual normal-form polynomial target. -/
theorem residual_exact_jump_adjoint {n : ℕ} (R : SeparatedReference)
    (a : EP1038.NormalForm.NormalData n) (hres : 0 < a.residualCount) :
    Stage10.Mdot R.angles.k R.quantile (a.residualQuantile hres) -
      adjointIntegral R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
        (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) =
      -Gam R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus *
        alpha R.angles.k R.angles.ρ π *
          (entry (EP1038.NormalForm.sorted_length_pos a hres) a.orderedAtoms
            (a.sortedLocations.length - 1) - 2) := by
  have h := R.angles.step_adjoint_eq (c := R.c) (EP1038.NormalForm.sorted_length_pos a hres)
    a.orderedAtoms R.radius_pos R.rhoPlus_spec.1 R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1 R.rhoMinus_spec.2.1 R.sigmaPlus_pos.le R.sigmaMinus_pos.le
  have heq := endpoint_corrected_equality h.2
  rw [R.Mdot_eq]
  change widthVariation R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
      (R.angles.angularVelocity R.c R.r (step (EP1038.NormalForm.sorted_length_pos a hres) a.orderedAtoms)) -
    adjointIntegral R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
      (R.angles.angularVelocity R.c R.r (step (EP1038.NormalForm.sorted_length_pos a hres) a.orderedAtoms)) = _
  rw [heq, R.angles.step_velocity_pi (EP1038.NormalForm.sorted_length_pos a hres) a.orderedAtoms,
    R.end_eq_two]
  ring

/-- The spatial material integral is the actual integral from the existing dictionary. -/
theorem residual_exact_material_adjoint {n : ℕ} (R : SeparatedReference)
    (a : EP1038.NormalForm.NormalData n) (hres : 0 < a.residualCount)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    Stage10.Mdot R.angles.k R.quantile (a.residualQuantile hres) -
      (∫ d, R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d
        ∂spatialAdjointMeasure R.c R.r (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)) =
      -Gam R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus *
        alpha R.angles.k R.angles.ρ π *
          (entry (EP1038.NormalForm.sorted_length_pos a hres) a.orderedAtoms
            (a.sortedLocations.length - 1) - 2) := by
  rw [(R.residual_material_dictionary a hres hzero).2]
  exact R.residual_exact_jump_adjoint a hres

end SeparatedReference
end EP1038.Stage11
