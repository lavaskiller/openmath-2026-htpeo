import LeanProject.NormalFormBridge

/-!
# Equivalence with the polynomial classes in DeepMind's Erdős 1038 statements

The official infimum excludes the monic constant `1`; the local contract instead
requires positive degree. The official supremum includes `1`, whose strict
sublevel set has measure zero. The filtered-root condition is proved equivalent
to the local split and root-location conditions, retaining root multiplicities.
-/

open Polynomial Set MeasureTheory
open scoped ENNReal

namespace EP1038.DeepMind

/-- The nonconstant polynomial class used by the official infimum statements. -/
def InfAdmissible (p : Polynomial ℝ) : Prop :=
  p.Monic ∧ p ≠ 1 ∧
    (p.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1).card = p.natDegree

/-- The polynomial class used by the official supremum statement. -/
def SupAdmissible (p : Polynomial ℝ) : Prop :=
  p.Monic ∧ (p.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1).card = p.natDegree

noncomputable def officialInf : ℝ≥0∞ :=
  ⨅ p : {p : Polynomial ℝ // InfAdmissible p}, volume {x : ℝ | |p.1.eval x| < 1}

noncomputable def officialSup : ℝ≥0∞ :=
  ⨆ p : {p : Polynomial ℝ // SupAdmissible p}, volume {x : ℝ | |p.1.eval x| < 1}

noncomputable def localInf : ℝ≥0∞ :=
  ⨅ p : {p : Polynomial ℝ // EP1038.Admissible p}, EP1038.sublevelMeasure p

noncomputable def localSup : ℝ≥0∞ :=
  ⨆ p : {p : Polynomial ℝ // EP1038.Admissible p}, EP1038.sublevelMeasure p

/-- Filtering out roots outside the interval keeps the full degree exactly when
all roots are real, with their full multiplicities, and lie in the interval. -/
theorem filtered_roots_iff (p : Polynomial ℝ) :
    (p.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1).card = p.natDegree ↔
      p.roots.card = p.natDegree ∧ ∀ x ∈ p.roots, x ∈ Set.Icc (-1 : ℝ) 1 := by
  constructor
  · intro h
    have hf : (p.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1) ≤ p.roots :=
      Multiset.filter_le _ _
    have hc : p.roots.card = p.natDegree :=
      le_antisymm (Polynomial.card_roots' p)
        (h ▸ Multiset.card_le_card hf)
    have heq : (p.roots.filter fun x => x ∈ Set.Icc (-1 : ℝ) 1) = p.roots :=
      Multiset.eq_of_le_of_card_le hf (by omega)
    exact ⟨hc, Multiset.filter_eq_self.mp heq⟩
  · rintro ⟨hc, hroots⟩
    rw [Multiset.filter_eq_self.mpr hroots, hc]

/-- Monicity converts the official `p ≠ 1` premise to positive degree. -/
theorem inf_admissible_iff (p : Polynomial ℝ) : InfAdmissible p ↔ EP1038.Admissible p := by
  constructor
  · rintro ⟨hm, hne, hf⟩
    obtain ⟨hc, hroots⟩ := (filtered_roots_iff p).mp hf
    have hn : p.natDegree ≠ 0 := fun hz => hne (hm.natDegree_eq_zero.mp hz)
    exact ⟨hm, by omega, hc, hroots⟩
  · rintro ⟨hm, hn, hc, hroots⟩
    refine ⟨hm, ?_, (filtered_roots_iff p).mpr ⟨hc, hroots⟩⟩
    intro heq
    subst p
    simp at hn

/-- The sole extra polynomial in the official supremum domain is `1`. -/
theorem sup_admissible_iff (p : Polynomial ℝ) :
    SupAdmissible p ↔ (EP1038.Admissible p ∨ p = 1) := by
  constructor
  · rintro ⟨hm, hf⟩
    by_cases h : p = 1
    · exact Or.inr h
    · exact Or.inl ((inf_admissible_iff p).mp ⟨hm, h, hf⟩)
  · rintro (hp | rfl)
    · exact ⟨hp.1, (filtered_roots_iff p).mpr ⟨hp.2.2.1, hp.2.2.2⟩⟩
    · simp [SupAdmissible]

theorem sublevelMeasure_one : EP1038.sublevelMeasure (1 : Polynomial ℝ) = 0 := by
  simp [EP1038.sublevelMeasure]

/-- The official and local infima have exactly the same admissible polynomials. -/
theorem officialInf_eq_localInf : officialInf = localInf := by
  apply le_antisymm
  · apply le_iInf
    intro p
    exact iInf_le_of_le ⟨p.1, (inf_admissible_iff p.1).mpr p.2⟩ le_rfl
  · apply le_iInf
    intro p
    exact iInf_le_of_le ⟨p.1, (inf_admissible_iff p.1).mp p.2⟩ le_rfl

/-- Adding the constant `1`, which contributes zero, does not change the supremum. -/
theorem officialSup_eq_localSup : officialSup = localSup := by
  apply le_antisymm
  · apply iSup_le
    intro p
    obtain hp | hp := (sup_admissible_iff p.1).mp p.2
    · exact le_iSup_of_le ⟨p.1, hp⟩ le_rfl
    · change EP1038.sublevelMeasure p.1 ≤ localSup
      rw [hp, sublevelMeasure_one]
      exact bot_le
  · apply iSup_le
    intro p
    exact le_iSup_of_le ⟨p.1, (sup_admissible_iff p.1).mpr (Or.inl p.2)⟩ le_rfl

end EP1038.DeepMind
