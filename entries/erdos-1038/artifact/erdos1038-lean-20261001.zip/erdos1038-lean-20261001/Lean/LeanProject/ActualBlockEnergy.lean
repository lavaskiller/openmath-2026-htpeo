import LeanProject.ActualBlocks
import LeanProject.BlockLogKernel

/-! The angular energy inequality applied to the actual residual blocks. -/

open Real Set MeasureTheory Finset Filter Topology intervalIntegral
open scoped ENNReal

namespace EP1038.Stage12
open EP1038.Arc EP1038.Stage11 EP1038.NormalForm NormalData AngleReference

noncomputable def api (A : AngleReference) : ℝ := alpha A.k A.ρ π
noncomputable def bpi (R : SeparatedReference) : ℝ := refB R π
noncomputable def refD0 (R : SeparatedReference) : ℝ := R.r / (2 * R.angles.ρ)

theorem api_pos (A : AngleReference) : 0 < api A :=
  lt_of_lt_of_le one_pos (one_le_api A.k_pos.le A.rho_pos.le)

theorem bpi_pos (R : SeparatedReference) : 0 < bpi R := refB_pos R ⟨Real.pi_pos, le_rfl⟩

theorem refD0_pos (R : SeparatedReference) : 0 < refD0 R :=
  div_pos R.radius_pos (mul_pos (by norm_num) R.angles.rho_pos)

theorem refPosition_eq_dth (R : SeparatedReference)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    position R.c R.r = dth (refD0 R) R.angles.ρ := by
  funext θ
  have hρ := R.angles.rho_pos.ne'
  have heq : R.c = R.r / (2 * R.angles.ρ) * (1 + R.angles.ρ ^ 2) := by
    field_simp at hzero ⊢
    nlinarith
  dsimp [position, dth, refD0]
  rw [heq]
  field_simp
  ring

theorem refH_eq (R : SeparatedReference) : refD0 R * R.angles.ρ = R.r / 2 := by
  dsimp [refD0]
  field_simp [R.angles.rho_pos.ne']

noncomputable def blockF {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ → ℝ :=
  (blockSet A a hres v).indicator (fun θ => alpha A.k A.ρ θ / api A)

noncomputable def blockG {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ → ℝ :=
  (blockSet R.angles a hres v).indicator (fun θ => refB R θ / bpi R)

theorem blockF_measurable {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : Measurable (blockF A a hres v) :=
  ((alpha_cont A.k A.ρ A.rho_pos.le A.rho_lt_one).div_const _).measurable.indicator
    (blockSet_measurable A a hres v)

theorem blockG_measurable {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : Measurable (blockG R a hres v) :=
  ((refB_continuous R).div_const _).measurable.indicator (blockSet_measurable R.angles a hres v)

theorem blockF_bounds {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v θ : ℝ) : 0 ≤ blockF A a hres v θ ∧ blockF A a hres v θ ≤ 1 := by
  by_cases hθ : θ ∈ blockSet A a hres v
  · rw [blockF, indicator_of_mem hθ]
    exact ⟨div_nonneg (alpha_bounds A.k_pos.le A.rho_pos.le A.rho_lt_one
      A.density_zero_nonneg θ).1 (api_pos A).le,
      (div_le_one (api_pos A)).mpr (alpha_le_api A.k_pos.le A.rho_pos.le A.rho_lt_one
        hθ.1.1 hθ.1.2)⟩
  · simp [blockF, indicator_of_notMem hθ]

theorem blockG_bounds {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v θ : ℝ) : 0 ≤ blockG R a hres v θ ∧ blockG R a hres v θ ≤ 1 := by
  by_cases hθ : θ ∈ blockSet R.angles a hres v
  · rw [blockG, indicator_of_mem hθ]
    refine ⟨div_nonneg (refB_nonneg R θ) (bpi_pos R).le, (div_le_one (bpi_pos R)).mpr ?_⟩
    change refB R θ ≤ refB R π
    rw [refB_eq]
    exact Bf_le_bpi R.sigmaPlus_pos.le R.sigmaMinus_pos.le R.rhoPlus_spec.1.le
      R.rhoPlus_spec.2.1 R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1 hθ.1.1 hθ.1.2
  · simp [blockG, indicator_of_notMem hθ]

noncomputable def blockQ {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ := ∫ θ in (0 : ℝ)..π, blockF A a hres v θ

noncomputable def blockR {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ := ∫ θ in (0 : ℝ)..π, blockG R a hres v θ

theorem indicator_div_const (s : Set ℝ) (f : ℝ → ℝ) (c : ℝ) :
    s.indicator (fun θ => f θ / c) = fun θ => s.indicator f θ / c := by
  funext θ
  by_cases hθ : θ ∈ s <;> simp [hθ]

theorem blockMass_eq_Q {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : blockMass A a hres v = api A * blockQ A a hres v / π := by
  unfold blockMass blockQ blockF
  simp_rw [indicator_div_const, intervalIntegral.integral_div]
  field_simp [(api_pos A).ne']

theorem blockXi_eq_R {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : blockXi R a hres v = bpi R * blockR R a hres v / π := by
  unfold blockXi blockR blockG
  simp_rw [indicator_div_const, intervalIntegral.integral_div]
  field_simp [(bpi_pos R).ne']

theorem blockQ_pos {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) : 0 < blockQ A a hres v := by
  have hq := blockMass_pos A a hres hv
  rw [blockMass_eq_Q] at hq
  exact pos_of_mul_pos_right ((div_pos_iff_of_pos_right Real.pi_pos).mp hq) (api_pos A).le

theorem blockR_pos {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) : 0 < blockR R a hres v := by
  have hr := blockXi_pos R a hres hv
  rw [blockXi_eq_R] at hr
  exact pos_of_mul_pos_right ((div_pos_iff_of_pos_right Real.pi_pos).mp hr) (bpi_pos R).le

theorem blockF_integrable {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : IntervalIntegrable (blockF A a hres v) volume 0 π :=
  interval_integrable_indicator
    (((alpha_cont A.k A.ρ A.rho_pos.le A.rho_lt_one).div_const _).intervalIntegrable _ _)
      (blockSet_measurable A a hres v)

theorem blockG_integrable {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : IntervalIntegrable (blockG R a hres v) volume 0 π :=
  interval_integrable_indicator (((refB_continuous R).div_const _).intervalIntegrable _ _)
    (blockSet_measurable R.angles a hres v)

noncomputable def centeredBlockEnergy {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ :=
  ∫ θ in (0 : ℝ)..π, blockF R.angles a hres v θ * ∫ φ in (0 : ℝ)..π,
    (Real.log |position R.c R.r θ - position R.c R.r φ| - Real.log (R.r / 2)) *
      blockG R a hres v φ

noncomputable def blockEnergy {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ :=
  api R.angles * bpi R / π ^ 2 *
    (Real.log (R.r / 2) * blockQ R.angles a hres v * blockR R a hres v +
      centeredBlockEnergy R a hres v)

theorem blockEnergy_normalized {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) :
    blockEnergy R a hres v / (blockMass R.angles a hres v * blockXi R a hres v) =
      Real.log (R.r / 2) + centeredBlockEnergy R a hres v /
        (blockQ R.angles a hres v * blockR R a hres v) := by
  rw [blockEnergy, blockMass_eq_Q, blockXi_eq_R]
  have ha := (api_pos R.angles).ne'
  have hb := (bpi_pos R).ne'
  have hQ := (blockQ_pos R.angles a hres hv).ne'
  have hR := (blockR_pos R a hres hv).ne'
  field_simp

theorem actual_block_ineq {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) (Ceff : ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    rhs (Real.log (2 * (R.r / 2) / (api R.angles * bpi R))) Ceff (api R.angles)
      (blockQ R.angles a hres v) (blockR R a hres v) ≤
        blockEnergy R a hres v / (blockMass R.angles a hres v * blockXi R a hres v) -
          Real.log (blockMass R.angles a hres v * blockXi R a hres v / 2) -
            Ceff / blockMass R.angles a hres v := by
  have h := block_ineq_angle (blockF_measurable R.angles a hres v) (blockG_measurable R a hres v)
    (fun θ => (blockF_bounds R.angles a hres v θ).1)
    (fun θ => (blockF_bounds R.angles a hres v θ).2)
    (fun θ => (blockG_bounds R a hres v θ).1) (fun θ => (blockG_bounds R a hres v θ).2)
    (refD0_pos R) R.angles.rho_pos (api_pos R.angles) (bpi_pos R)
    (blockQ_pos R.angles a hres hv) (blockR_pos R a hres hv) (Ceff := Ceff)
  rw [refH_eq] at h
  simp_rw [← refPosition_eq_dth R hzero] at h
  rw [blockEnergy_normalized R a hres hv, blockMass_eq_Q, blockXi_eq_R]
  exact h

theorem blockEnergy_strict_of_rhs_pos {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) {Ceff : ℝ}
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ))
    (hs : 0 < rhs (Real.log (2 * (R.r / 2) / (api R.angles * bpi R))) Ceff (api R.angles)
      (blockQ R.angles a hres v) (blockR R a hres v)) :
    blockMass R.angles a hres v * blockXi R a hres v *
      Real.log (blockMass R.angles a hres v * blockXi R a hres v / 2) +
        Ceff * blockXi R a hres v < blockEnergy R a hres v := by
  have h := hs.trans_le (actual_block_ineq R a hres hv Ceff hzero)
  have hq := blockMass_pos R.angles a hres hv
  have hr := blockXi_pos R a hres hv
  have hm := mul_pos hq hr
  have hx := mul_pos hm h
  have e1 : (blockMass R.angles a hres v * blockXi R a hres v) *
      (blockEnergy R a hres v / (blockMass R.angles a hres v * blockXi R a hres v)) =
        blockEnergy R a hres v := by field_simp
  have e2 : (blockMass R.angles a hres v * blockXi R a hres v) *
      (Ceff / blockMass R.angles a hres v) = Ceff * blockXi R a hres v := by field_simp
  nlinarith

theorem log_distance_half_integrable {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) (θ : ℝ) :
    IntervalIntegrable (fun φ => Real.log |dth D0 q θ - dth D0 q φ|) volume 0 π :=
  (log_dist_ii hD hq θ).mono_set (by
    rw [Set.uIcc_of_le Real.pi_pos.le, Set.uIcc_of_le (by linarith [Real.pi_pos])]
    exact Set.Icc_subset_Icc (by linarith [Real.pi_pos]) le_rfl)

theorem energy_centering {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q)
    {F G : ℝ → ℝ} (hFm : Measurable F) (hGm : Measurable G)
    (hF : ∀ θ, |F θ| ≤ 1) (hG : ∀ θ, |G θ| ≤ 1)
    (hFi : IntervalIntegrable F volume 0 π) (hGi : IntervalIntegrable G volume 0 π) :
    (∫ θ in (0 : ℝ)..π, F θ * ∫ φ in (0 : ℝ)..π,
      (Real.log |dth D0 q θ - dth D0 q φ| - Real.log (D0 * q)) * G φ) =
        (∫ θ in (0 : ℝ)..π, F θ * ∫ φ in (0 : ℝ)..π,
          Real.log |dth D0 q θ - dth D0 q φ| * G φ) -
            Real.log (D0 * q) * (∫ θ in (0 : ℝ)..π, F θ) * (∫ φ in (0 : ℝ)..π, G φ) := by
  have hj := weighted_log_distance_integrable hD hq hFm hGm hF hG
  have ho : IntervalIntegrable (fun θ => F θ * ∫ φ in (0 : ℝ)..π,
      Real.log |dth D0 q θ - dth D0 q φ| * G φ) volume 0 π := by
    rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le]
    have hi := hj.integral_prod_left
    have he (θ : ℝ) : (∫ φ, F θ * (Real.log |dth D0 q θ - dth D0 q φ| * G φ)
        ∂angleMeasure) = F θ * ∫ φ in (0 : ℝ)..π,
          Real.log |dth D0 q θ - dth D0 q φ| * G φ := by
      rw [MeasureTheory.integral_const_mul, intervalIntegral.integral_of_le Real.pi_pos.le]
      rfl
    simp_rw [he] at hi
    exact hi
  have hc := (hFi.mul_const (Real.log (D0 * q))).mul_const (∫ φ in (0 : ℝ)..π, G φ)
  have heq : (fun θ => F θ * ∫ φ in (0 : ℝ)..π,
      (Real.log |dth D0 q θ - dth D0 q φ| - Real.log (D0 * q)) * G φ) =
        (fun θ => F θ * ∫ φ in (0 : ℝ)..π, Real.log |dth D0 q θ - dth D0 q φ| * G φ) -
          (fun θ => F θ * Real.log (D0 * q) * ∫ φ in (0 : ℝ)..π, G φ) := by
    funext θ
    simp only [Pi.sub_apply, sub_mul]
    rw [intervalIntegral.integral_sub (ii_mul_bdd (log_distance_half_integrable hD hq θ) hGm hG)
      (hGi.const_mul _), intervalIntegral.integral_const_mul]
    ring
  rw [heq]
  change (∫ θ in (0 : ℝ)..π, (F θ * ∫ φ in (0 : ℝ)..π,
    Real.log |dth D0 q θ - dth D0 q φ| * G φ) -
      F θ * Real.log (D0 * q) * ∫ φ in (0 : ℝ)..π, G φ) = _
  rw [intervalIntegral.integral_sub ho hc, intervalIntegral.integral_mul_const,
    intervalIntegral.integral_mul_const]
  ring

theorem block_alpha_eq {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) :
    (blockSet A a hres v).indicator (alpha A.k A.ρ) = fun θ => api A * blockF A a hres v θ := by
  funext θ
  by_cases hθ : θ ∈ blockSet A a hres v
  · rw [indicator_of_mem hθ, blockF, indicator_of_mem hθ]
    field_simp [(api_pos A).ne']
  · simp [blockF, indicator_of_notMem hθ]

theorem block_B_eq {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) :
    (blockSet R.angles a hres v).indicator (refB R) = fun θ => bpi R * blockG R a hres v θ := by
  funext θ
  by_cases hθ : θ ∈ blockSet R.angles a hres v
  · rw [indicator_of_mem hθ, blockG, indicator_of_mem hθ]
    field_simp [(bpi_pos R).ne']
  · simp [blockG, indicator_of_notMem hθ]

theorem blockEnergy_raw {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    blockEnergy R a hres v = 1 / π ^ 2 * ∫ θ in (0 : ℝ)..π,
      (blockSet R.angles a hres v).indicator (alpha R.angles.k R.angles.ρ) θ *
        ∫ φ in (0 : ℝ)..π, Real.log |position R.c R.r θ - position R.c R.r φ| *
          (blockSet R.angles a hres v).indicator (refB R) φ := by
  have hF : ∀ θ, |blockF R.angles a hres v θ| ≤ 1 := fun θ => abs_le.mpr
    ⟨by linarith [(blockF_bounds R.angles a hres v θ).1], (blockF_bounds R.angles a hres v θ).2⟩
  have hG : ∀ θ, |blockG R a hres v θ| ≤ 1 := fun θ => abs_le.mpr
    ⟨by linarith [(blockG_bounds R a hres v θ).1], (blockG_bounds R a hres v θ).2⟩
  have hc := energy_centering (refD0_pos R) R.angles.rho_pos
    (blockF_measurable R.angles a hres v) (blockG_measurable R a hres v) hF hG
    (blockF_integrable R.angles a hres v) (blockG_integrable R a hres v)
  rw [refH_eq] at hc
  simp_rw [← refPosition_eq_dth R hzero] at hc
  unfold blockEnergy centeredBlockEnergy blockQ blockR
  rw [hc]
  simp only [add_sub_cancel_left, block_alpha_eq, block_B_eq]
  simp_rw [show ∀ θ φ, Real.log |position R.c R.r θ - position R.c R.r φ| *
      (bpi R * blockG R a hres v φ) = bpi R *
        (Real.log |position R.c R.r θ - position R.c R.r φ| * blockG R a hres v φ) by
          intros; ring, intervalIntegral.integral_const_mul]
  simp_rw [show ∀ θ, api R.angles * blockF R.angles a hres v θ *
      (bpi R * ∫ φ in (0 : ℝ)..π,
        Real.log |position R.c R.r θ - position R.c R.r φ| * blockG R a hres v φ) =
        api R.angles * bpi R * (blockF R.angles a hres v θ * ∫ φ in (0 : ℝ)..π,
          Real.log |position R.c R.r θ - position R.c R.r φ| * blockG R a hres v φ) by
            intros; ring, intervalIntegral.integral_const_mul]
  ring

theorem block_log_joint_integrable {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    Integrable (fun p : ℝ × ℝ => (blockSet R.angles a hres v).indicator
      (alpha R.angles.k R.angles.ρ) p.1 *
        (Real.log |position R.c R.r p.1 - position R.c R.r p.2| *
          (blockSet R.angles a hres v).indicator (refB R) p.2)) (angleMeasure.prod angleMeasure) := by
  have hF : ∀ θ, |blockF R.angles a hres v θ| ≤ 1 := fun θ => abs_le.mpr
    ⟨by linarith [(blockF_bounds R.angles a hres v θ).1], (blockF_bounds R.angles a hres v θ).2⟩
  have hG : ∀ θ, |blockG R a hres v θ| ≤ 1 := fun θ => abs_le.mpr
    ⟨by linarith [(blockG_bounds R a hres v θ).1], (blockG_bounds R a hres v θ).2⟩
  have h := (weighted_log_distance_integrable (refD0_pos R) R.angles.rho_pos
    (blockF_measurable R.angles a hres v) (blockG_measurable R a hres v) hF hG).const_mul
      (api R.angles * bpi R)
  simp_rw [← refPosition_eq_dth R hzero] at h
  apply h.congr
  refine Eventually.of_forall fun p => ?_
  rw [block_alpha_eq, block_B_eq]
  ring

theorem blockEnergy_raw_swap {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    blockEnergy R a hres v = 1 / π ^ 2 * ∫ θ in (0 : ℝ)..π,
      (blockSet R.angles a hres v).indicator (refB R) θ *
        ∫ φ in (0 : ℝ)..π, Real.log |position R.c R.r θ - position R.c R.r φ| *
          (blockSet R.angles a hres v).indicator (alpha R.angles.k R.angles.ρ) φ := by
  rw [blockEnergy_raw R a hres v hzero]
  congr 1
  simp_rw [intervalIntegral.integral_of_le Real.pi_pos.le, ← MeasureTheory.integral_const_mul]
  rw [MeasureTheory.integral_integral_swap (block_log_joint_integrable R a hres v hzero)]
  apply MeasureTheory.integral_congr_ae
  refine Eventually.of_forall fun θ => ?_
  apply MeasureTheory.integral_congr_ae
  refine Eventually.of_forall fun φ => ?_
  dsimp only
  rw [abs_sub_comm (position R.c R.r φ) (position R.c R.r θ)]
  ring

theorem blockMass_le_one {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : blockMass A a hres v ≤ 1 := by
  have hi : IntervalIntegrable (alpha A.k A.ρ) volume 0 π :=
    (alpha_cont A.k A.ρ A.rho_pos.le A.rho_lt_one).intervalIntegrable 0 π
  have hs := interval_integrable_indicator hi (blockSet_measurable A a hres v)
  have h := intervalIntegral.integral_mono Real.pi_pos.le hs hi (fun θ => by
    by_cases hθ : θ ∈ blockSet A a hres v
    · rw [indicator_of_mem hθ]
    · rw [indicator_of_notMem hθ]
      exact (alpha_bounds A.k_pos.le A.rho_pos.le A.rho_lt_one A.density_zero_nonneg θ).1)
  have hm := mul_le_mul_of_nonneg_left h (one_div_pos.mpr Real.pi_pos).le
  exact hm.trans_eq A.cdf_pi

theorem blockXi_le_total {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : blockXi R a hres v ≤ totalXi R := by
  have hi : IntervalIntegrable (refB R) volume 0 π :=
    (refB_continuous R).intervalIntegrable 0 π
  have hs := interval_integrable_indicator hi (blockSet_measurable R.angles a hres v)
  have h := intervalIntegral.integral_mono Real.pi_pos.le hs hi (fun θ => by
    by_cases hθ : θ ∈ blockSet R.angles a hres v
    · rw [indicator_of_mem hθ]
    · rw [indicator_of_notMem hθ]
      exact refB_nonneg R θ)
  exact mul_le_mul_of_nonneg_left h (one_div_pos.mpr Real.pi_pos).le

theorem totalXi_le_bpi (R : SeparatedReference) : totalXi R ≤ bpi R := by
  rw [totalXi_formula]
  change _ ≤ refB R π
  rw [refB_eq, bpi_eq R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1]
  exact Rxi_le_bpi R.sigmaPlus_pos.le R.sigmaMinus_pos.le R.rhoPlus_spec.1.le
    R.rhoPlus_spec.2.1 R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1

theorem actual_block_rectangle {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) :
    blockQ R.angles a hres v ∈ Ioc (0 : ℝ) (π / api R.angles) ∧
      blockR R a hres v ∈ Ioc (0 : ℝ) (π * totalXi R / bpi R) := by
  have hq := blockMass_le_one R.angles a hres v
  have hr := blockXi_le_total R a hres v
  rw [blockMass_eq_Q, div_le_iff₀ Real.pi_pos, mul_comm (api R.angles),
    ← le_div_iff₀ (api_pos R.angles), one_mul] at hq
  rw [blockXi_eq_R, div_le_iff₀ Real.pi_pos, mul_comm (bpi R),
    ← le_div_iff₀ (bpi_pos R)] at hr
  exact ⟨⟨blockQ_pos R.angles a hres hv, hq⟩,
    ⟨blockR_pos R a hres hv, by simpa only [mul_comm] using hr⟩⟩

theorem rectangle_upper_bounds (R : SeparatedReference) :
    π / api R.angles ≤ π ∧ π * totalXi R / bpi R ≤ π := by
  constructor
  · rw [div_le_iff₀ (api_pos R.angles)]
    have ha := one_le_api R.angles.k_pos.le R.angles.rho_pos.le
    dsimp [api]
    nlinarith [Real.pi_pos]
  · rw [div_le_iff₀ (bpi_pos R)]
    exact mul_le_mul_of_nonneg_left (totalXi_le_bpi R) Real.pi_pos.le

end EP1038.Stage12
