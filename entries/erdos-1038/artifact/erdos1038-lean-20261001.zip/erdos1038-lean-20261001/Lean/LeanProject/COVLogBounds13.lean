import LeanProject.COVLogTwo
import LeanProject.COVLogBounds09
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1040 : RB (Real.log ((454781 : ℝ) / 5000000)) ((-59934431 : ℝ) / 25000000) ((-5993443 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((454781 : ℝ) / 625000)) (t := ((-170219 : ℝ) / 1079781))
    (lo := ((-31793567 : ℝ) / 100000000)) (hi := ((-15896783 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((454781 : ℝ) / 5000000) = Real.log ((454781 : ℝ) / 625000) - 3 * Real.log 2 := by
    rw [show ((454781 : ℝ) / 5000000) = ((454781 : ℝ) / 625000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1041 : RB (Real.log ((1104387 : ℝ) / 10000000)) ((-22032947 : ℝ) / 10000000) ((-110164733 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1104387 : ℝ) / 1250000)) (t := ((-145613 : ℝ) / 2354387))
    (lo := ((-12385313 : ℝ) / 100000000)) (hi := ((-387041 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1104387 : ℝ) / 10000000) = Real.log ((1104387 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((1104387 : ℝ) / 10000000) = ((1104387 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1042 : RB (Real.log ((3345771 : ℝ) / 100000000)) ((-84936827 : ℝ) / 25000000) ((-169873651 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3345771 : ℝ) / 3125000)) (t := ((220771 : ℝ) / 6470771))
    (lo := ((6826287 : ℝ) / 100000000)) (hi := ((426643 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3345771 : ℝ) / 100000000) = Real.log ((3345771 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3345771 : ℝ) / 100000000) = ((3345771 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1043 : RB (Real.log ((170741 : ℝ) / 5000000)) ((-168852273 : ℝ) / 50000000) ((-16885227 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((170741 : ℝ) / 156250)) (t := ((14491 : ℝ) / 326991))
    (lo := ((8869049 : ℝ) / 100000000)) (hi := ((177381 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170741 : ℝ) / 5000000) = Real.log ((170741 : ℝ) / 156250) - 5 * Real.log 2 := by
    rw [show ((170741 : ℝ) / 5000000) = ((170741 : ℝ) / 156250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1044 : RB (Real.log ((33860211 : ℝ) / 50000000)) ((-121807 : ℝ) / 312500) ((-38978239 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33860211 : ℝ) / 50000000)) (t := ((-16139789 : ℝ) / 83860211))
    (lo := ((-121807 : ℝ) / 312500)) (hi := ((-38978239 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1045 : RB (Real.log ((67722497 : ℝ) / 100000000)) ((-4871897 : ℝ) / 12500000) ((-1559007 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((67722497 : ℝ) / 100000000)) (t := ((-32277503 : ℝ) / 167722497))
    (lo := ((-4871897 : ℝ) / 12500000)) (hi := ((-1559007 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1046 : RB (Real.log ((40396323 : ℝ) / 100000000)) ((-90643143 : ℝ) / 100000000) ((-90643141 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40396323 : ℝ) / 50000000)) (t := ((-9603677 : ℝ) / 90396323))
    (lo := ((-2666053 : ℝ) / 12500000)) (hi := ((-21328423 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40396323 : ℝ) / 100000000) = Real.log ((40396323 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40396323 : ℝ) / 100000000) = ((40396323 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1047 : RB (Real.log ((192983449 : ℝ) / 100000000)) ((1027241 : ℝ) / 1562500) ((32871713 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((192983449 : ℝ) / 200000000)) (t := ((-7016551 : ℝ) / 392983449))
    (lo := ((-1785647 : ℝ) / 50000000)) (hi := ((-3571293 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192983449 : ℝ) / 100000000) = Real.log ((192983449 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((192983449 : ℝ) / 100000000) = ((192983449 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1048 : RB (Real.log ((1931147 : ℝ) / 1000000)) ((16452853 : ℝ) / 25000000) ((32905707 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1931147 : ℝ) / 2000000)) (t := ((-68853 : ℝ) / 3931147))
    (lo := ((-1751653 : ℝ) / 50000000)) (hi := ((-700661 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1931147 : ℝ) / 1000000) = Real.log ((1931147 : ℝ) / 2000000) + 1 * Real.log 2 := by
    rw [show ((1931147 : ℝ) / 1000000) = ((1931147 : ℝ) / 2000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1049 : RB (Real.log ((69709243 : ℝ) / 100000000)) ((-36083727 : ℝ) / 100000000) ((-18041863 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((69709243 : ℝ) / 100000000)) (t := ((-30290757 : ℝ) / 169709243))
    (lo := ((-36083727 : ℝ) / 100000000)) (hi := ((-18041863 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1050 : RB (Real.log ((69711343 : ℝ) / 100000000)) ((-7216143 : ℝ) / 20000000) ((-18040357 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((69711343 : ℝ) / 100000000)) (t := ((-30288657 : ℝ) / 169711343))
    (lo := ((-7216143 : ℝ) / 20000000)) (hi := ((-18040357 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1051 : RB (Real.log ((20547409 : ℝ) / 50000000)) ((-88928817 : ℝ) / 100000000) ((-17785763 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((20547409 : ℝ) / 25000000)) (t := ((-4452591 : ℝ) / 45547409))
    (lo := ((-9807049 : ℝ) / 50000000)) (hi := ((-19614097 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20547409 : ℝ) / 50000000) = Real.log ((20547409 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20547409 : ℝ) / 50000000) = ((20547409 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1052 : RB (Real.log ((426958897 : ℝ) / 100000000)) ((36287939 : ℝ) / 25000000) ((145151759 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((426958897 : ℝ) / 400000000)) (t := ((26958897 : ℝ) / 826958897))
    (lo := ((81529 : ℝ) / 1250000)) (hi := ((6522321 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((426958897 : ℝ) / 100000000) = Real.log ((426958897 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((426958897 : ℝ) / 100000000) = ((426958897 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1053 : RB (Real.log ((21348147 : ℝ) / 5000000)) ((145152703 : ℝ) / 100000000) ((72576353 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((21348147 : ℝ) / 20000000)) (t := ((1348147 : ℝ) / 41348147))
    (lo := ((6523267 : ℝ) / 100000000)) (hi := ((1630817 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21348147 : ℝ) / 5000000) = Real.log ((21348147 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((21348147 : ℝ) / 5000000) = ((21348147 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1054 : RB (Real.log ((32643739 : ℝ) / 25000000)) ((1067109 : ℝ) / 4000000) ((13338863 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((32643739 : ℝ) / 25000000)) (t := ((7643739 : ℝ) / 57643739))
    (lo := ((1067109 : ℝ) / 4000000)) (hi := ((13338863 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1055 : RB (Real.log ((423441007 : ℝ) / 100000000)) ((144324401 : ℝ) / 100000000) ((36081101 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((423441007 : ℝ) / 400000000)) (t := ((23441007 : ℝ) / 823441007))
    (lo := ((1138993 : ℝ) / 20000000)) (hi := ((2847483 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((423441007 : ℝ) / 100000000) = Real.log ((423441007 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((423441007 : ℝ) / 100000000) = ((423441007 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1056 : RB (Real.log ((423445007 : ℝ) / 100000000)) ((72162673 : ℝ) / 50000000) ((144325349 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((423445007 : ℝ) / 400000000)) (t := ((23445007 : ℝ) / 823445007))
    (lo := ((569591 : ℝ) / 10000000)) (hi := ((5695911 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((423445007 : ℝ) / 100000000) = Real.log ((423445007 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((423445007 : ℝ) / 100000000) = ((423445007 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1057 : RB (Real.log ((130907503 : ℝ) / 100000000)) ((336651 : ℝ) / 1250000) ((26932081 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((130907503 : ℝ) / 100000000)) (t := ((30907503 : ℝ) / 230907503))
    (lo := ((336651 : ℝ) / 1250000)) (hi := ((26932081 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1058 : RB (Real.log ((4615729 : ℝ) / 50000000)) ((-119127661 : ℝ) / 50000000) ((-119127659 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4615729 : ℝ) / 6250000)) (t := ((-1634271 : ℝ) / 10865729))
    (lo := ((-6062233 : ℝ) / 20000000)) (hi := ((-7577791 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4615729 : ℝ) / 50000000) = Real.log ((4615729 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4615729 : ℝ) / 50000000) = ((4615729 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1059 : RB (Real.log ((11154887 : ℝ) / 100000000)) ((-54832313 : ℝ) / 25000000) ((-6854039 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((11154887 : ℝ) / 12500000)) (t := ((-1345113 : ℝ) / 23654887))
    (lo := ((-2277019 : ℝ) / 20000000)) (hi := ((-5692547 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11154887 : ℝ) / 100000000) = Real.log ((11154887 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((11154887 : ℝ) / 100000000) = ((11154887 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1060 : RB (Real.log ((3410179 : ℝ) / 100000000)) ((-168920273 : ℝ) / 50000000) ((-16892027 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((3410179 : ℝ) / 3125000)) (t := ((285179 : ℝ) / 6535179))
    (lo := ((8733049 : ℝ) / 100000000)) (hi := ((174661 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3410179 : ℝ) / 100000000) = Real.log ((3410179 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3410179 : ℝ) / 100000000) = ((3410179 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1061 : RB (Real.log ((3479321 : ℝ) / 100000000)) ((-83958327 : ℝ) / 25000000) ((-167916651 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3479321 : ℝ) / 3125000)) (t := ((354321 : ℝ) / 6604321))
    (lo := ((10740287 : ℝ) / 100000000)) (hi := ((167817 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3479321 : ℝ) / 100000000) = Real.log ((3479321 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3479321 : ℝ) / 100000000) = ((3479321 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1062 : RB (Real.log ((33754451 : ℝ) / 50000000)) ((-613923 : ℝ) / 1562500) ((-39291071 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33754451 : ℝ) / 50000000)) (t := ((-16245549 : ℝ) / 83754451))
    (lo := ((-613923 : ℝ) / 1562500)) (hi := ((-39291071 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1063 : RB (Real.log ((33755509 : ℝ) / 50000000)) ((-19643969 : ℝ) / 50000000) ((-39287937 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33755509 : ℝ) / 50000000)) (t := ((-16244491 : ℝ) / 83755509))
    (lo := ((-19643969 : ℝ) / 50000000)) (hi := ((-39287937 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1064 : RB (Real.log ((10080453 : ℝ) / 25000000)) ((-22706941 : ℝ) / 25000000) ((-45413881 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((10080453 : ℝ) / 12500000)) (t := ((-2419547 : ℝ) / 22580453))
    (lo := ((-4302609 : ℝ) / 20000000)) (hi := ((-5378261 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10080453 : ℝ) / 25000000) = Real.log ((10080453 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10080453 : ℝ) / 25000000) = ((10080453 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1065 : RB (Real.log ((96426077 : ℝ) / 50000000)) ((32837683 : ℝ) / 50000000) ((8209421 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((96426077 : ℝ) / 100000000)) (t := ((-3573923 : ℝ) / 196426077))
    (lo := ((-454919 : ℝ) / 12500000)) (hi := ((-3639351 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((96426077 : ℝ) / 50000000) = Real.log ((96426077 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((96426077 : ℝ) / 50000000) = ((96426077 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1066 : RB (Real.log ((48245863 : ℝ) / 25000000)) ((2629737 : ℝ) / 4000000) ((65743427 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((48245863 : ℝ) / 50000000)) (t := ((-1754137 : ℝ) / 98245863))
    (lo := ((-3571293 : ℝ) / 100000000)) (hi := ((-892823 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48245863 : ℝ) / 25000000) = Real.log ((48245863 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48245863 : ℝ) / 25000000) = ((48245863 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1067 : RB (Real.log ((542673 : ℝ) / 781250)) ((-9109707 : ℝ) / 25000000) ((-36438827 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((542673 : ℝ) / 781250)) (t := ((-238577 : ℝ) / 1323923))
    (lo := ((-9109707 : ℝ) / 25000000)) (hi := ((-36438827 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1068 : RB (Real.log ((17366071 : ℝ) / 25000000)) ((-36435747 : ℝ) / 100000000) ((-18217873 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((17366071 : ℝ) / 25000000)) (t := ((-7633929 : ℝ) / 42366071))
    (lo := ((-36435747 : ℝ) / 100000000)) (hi := ((-18217873 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1069 : RB (Real.log ((4100967 : ℝ) / 10000000)) ((-89136231 : ℝ) / 100000000) ((-89136229 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4100967 : ℝ) / 5000000)) (t := ((-899033 : ℝ) / 9100967))
    (lo := ((-2477689 : ℝ) / 12500000)) (hi := ((-19821511 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4100967 : ℝ) / 10000000) = Real.log ((4100967 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((4100967 : ℝ) / 10000000) = ((4100967 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1070 : RB (Real.log ((26610501 : ℝ) / 6250000)) ((36218111 : ℝ) / 25000000) ((144872447 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((26610501 : ℝ) / 25000000)) (t := ((1610501 : ℝ) / 51610501))
    (lo := ((97547 : ℝ) / 1562500)) (hi := ((6243009 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((26610501 : ℝ) / 6250000) = Real.log ((26610501 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((26610501 : ℝ) / 6250000) = ((26610501 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1071 : RB (Real.log ((42577213 : ℝ) / 10000000)) ((14487341 : ℝ) / 10000000) ((144873413 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42577213 : ℝ) / 40000000)) (t := ((2577213 : ℝ) / 82577213))
    (lo := ((3121987 : ℝ) / 50000000)) (hi := ((249759 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42577213 : ℝ) / 10000000) = Real.log ((42577213 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((42577213 : ℝ) / 10000000) = ((42577213 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1072 : RB (Real.log ((130686339 : ℝ) / 100000000)) ((2676299 : ℝ) / 10000000) ((26762991 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((130686339 : ℝ) / 100000000)) (t := ((30686339 : ℝ) / 230686339))
    (lo := ((2676299 : ℝ) / 10000000)) (hi := ((26762991 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1073 : RB (Real.log ((1319663 : ℝ) / 312500)) ((1800659 : ℝ) / 1250000) ((144052723 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1319663 : ℝ) / 1250000)) (t := ((69663 : ℝ) / 2569663))
    (lo := ((1355821 : ℝ) / 25000000)) (hi := ((1084657 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1319663 : ℝ) / 312500) = Real.log ((1319663 : ℝ) / 1250000) + 2 * Real.log 2 := by
    rw [show ((1319663 : ℝ) / 312500) = ((1319663 : ℝ) / 1250000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1074 : RB (Real.log ((42229623 : ℝ) / 10000000)) ((36013421 : ℝ) / 25000000) ((144053687 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42229623 : ℝ) / 40000000)) (t := ((2229623 : ℝ) / 82229623))
    (lo := ((678031 : ℝ) / 12500000)) (hi := ((5424249 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42229623 : ℝ) / 10000000) = Real.log ((42229623 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((42229623 : ℝ) / 10000000) = ((42229623 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1075 : RB (Real.log ((26203457 : ℝ) / 20000000)) ((27015907 : ℝ) / 100000000) ((6753977 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((26203457 : ℝ) / 20000000)) (t := ((6203457 : ℝ) / 46203457))
    (lo := ((27015907 : ℝ) / 100000000)) (hi := ((6753977 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1076 : RB (Real.log ((936739 : ℝ) / 10000000)) ((-236793571 : ℝ) / 100000000) ((-236793567 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((936739 : ℝ) / 1250000)) (t := ((-313261 : ℝ) / 2186739))
    (lo := ((-14424707 : ℝ) / 50000000)) (hi := ((-28849413 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((936739 : ℝ) / 10000000) = Real.log ((936739 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((936739 : ℝ) / 10000000) = ((936739 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1077 : RB (Real.log ((563367 : ℝ) / 5000000)) ((-109163097 : ℝ) / 50000000) ((-21832619 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((563367 : ℝ) / 625000)) (t := ((-61633 : ℝ) / 1188367))
    (lo := ((-10382037 : ℝ) / 100000000)) (hi := ((-2595509 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((563367 : ℝ) / 5000000) = Real.log ((563367 : ℝ) / 625000) - 3 * Real.log 2 := by
    rw [show ((563367 : ℝ) / 5000000) = ((563367 : ℝ) / 625000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1078 : RB (Real.log ((1737293 : ℝ) / 50000000)) ((-33596949 : ℝ) / 10000000) ((-83992371 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1737293 : ℝ) / 1562500)) (t := ((174793 : ℝ) / 3299793))
    (lo := ((2120821 : ℝ) / 20000000)) (hi := ((5302053 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1737293 : ℝ) / 50000000) = Real.log ((1737293 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1737293 : ℝ) / 50000000) = ((1737293 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1079 : RB (Real.log ((3543819 : ℝ) / 100000000)) ((-20874783 : ℝ) / 6250000) ((-166998261 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3543819 : ℝ) / 3125000)) (t := ((418819 : ℝ) / 6668819))
    (lo := ((12577067 : ℝ) / 100000000)) (hi := ((3144267 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3543819 : ℝ) / 100000000) = Real.log ((3543819 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3543819 : ℝ) / 100000000) = ((3543819 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1080 : RB (Real.log ((13460081 : ℝ) / 20000000)) ((-19800197 : ℝ) / 50000000) ((-39600393 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13460081 : ℝ) / 20000000)) (t := ((-6539919 : ℝ) / 33460081))
    (lo := ((-19800197 : ℝ) / 50000000)) (hi := ((-39600393 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1081 : RB (Real.log ((420641 : ℝ) / 625000)) ((-4949649 : ℝ) / 12500000) ((-39597191 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((420641 : ℝ) / 625000)) (t := ((-204359 : ℝ) / 1045641))
    (lo := ((-4949649 : ℝ) / 12500000)) (hi := ((-39597191 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1082 : RB (Real.log ((40248207 : ℝ) / 100000000)) ((-45505237 : ℝ) / 50000000) ((-11376309 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((40248207 : ℝ) / 50000000)) (t := ((-9751793 : ℝ) / 90248207))
    (lo := ((-4339151 : ℝ) / 20000000)) (hi := ((-10847877 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40248207 : ℝ) / 100000000) = Real.log ((40248207 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40248207 : ℝ) / 100000000) = ((40248207 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1083 : RB (Real.log ((192720813 : ℝ) / 100000000)) ((65607239 : ℝ) / 100000000) ((65607241 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((192720813 : ℝ) / 200000000)) (t := ((-7279187 : ℝ) / 392720813))
    (lo := ((-3707479 : ℝ) / 100000000)) (hi := ((-1853739 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192720813 : ℝ) / 100000000) = Real.log ((192720813 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((192720813 : ℝ) / 100000000) = ((192720813 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1084 : RB (Real.log ((96426079 : ℝ) / 50000000)) ((8209421 : ℝ) / 12500000) ((6567537 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((96426079 : ℝ) / 100000000)) (t := ((-3573921 : ℝ) / 196426079))
    (lo := ((-72787 : ℝ) / 2000000)) (hi := ((-3639349 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((96426079 : ℝ) / 50000000) = Real.log ((96426079 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((96426079 : ℝ) / 50000000) = ((96426079 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1085 : RB (Real.log ((1384399 : ℝ) / 2000000)) ((-9197027 : ℝ) / 25000000) ((-36788107 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1384399 : ℝ) / 2000000)) (t := ((-615601 : ℝ) / 3384399))
    (lo := ((-9197027 : ℝ) / 25000000)) (hi := ((-36788107 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1086 : RB (Real.log ((6922213 : ℝ) / 10000000)) ((-18392479 : ℝ) / 50000000) ((-36784957 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6922213 : ℝ) / 10000000)) (t := ((-3077787 : ℝ) / 16922213))
    (lo := ((-18392479 : ℝ) / 50000000)) (hi := ((-36784957 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1087 : RB (Real.log ((40926001 : ℝ) / 100000000)) ((-44670231 : ℝ) / 50000000) ((-4467023 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((40926001 : ℝ) / 50000000)) (t := ((-9073999 : ℝ) / 90926001))
    (lo := ((-20025743 : ℝ) / 100000000)) (hi := ((-10012871 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40926001 : ℝ) / 100000000) = Real.log ((40926001 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40926001 : ℝ) / 100000000) = ((40926001 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1088 : RB (Real.log ((424591381 : ℝ) / 100000000)) ((72297853 : ℝ) / 50000000) ((144595709 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((424591381 : ℝ) / 400000000)) (t := ((24591381 : ℝ) / 824591381))
    (lo := ((596627 : ℝ) / 10000000)) (hi := ((5966271 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((424591381 : ℝ) / 100000000) = Real.log ((424591381 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((424591381 : ℝ) / 100000000) = ((424591381 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1089 : RB (Real.log ((424595561 : ℝ) / 100000000)) ((14459669 : ℝ) / 10000000) ((144596693 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((424595561 : ℝ) / 400000000)) (t := ((24595561 : ℝ) / 824595561))
    (lo := ((2983627 : ℝ) / 50000000)) (hi := ((1193451 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((424595561 : ℝ) / 100000000) = Real.log ((424595561 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((424595561 : ℝ) / 100000000) = ((424595561 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1090 : RB (Real.log ((6539859 : ℝ) / 5000000)) ((26847769 : ℝ) / 100000000) ((2684777 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((6539859 : ℝ) / 5000000)) (t := ((1539859 : ℝ) / 11539859))
    (lo := ((26847769 : ℝ) / 100000000)) (hi := ((2684777 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1091 : RB (Real.log ((52644589 : ℝ) / 12500000)) ((143783481 : ℝ) / 100000000) ((35945871 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((52644589 : ℝ) / 50000000)) (t := ((2644589 : ℝ) / 102644589))
    (lo := ((1030809 : ℝ) / 20000000)) (hi := ((2577023 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52644589 : ℝ) / 12500000) = Real.log ((52644589 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((52644589 : ℝ) / 12500000) = ((52644589 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1092 : RB (Real.log ((26322553 : ℝ) / 6250000)) ((143784463 : ℝ) / 100000000) ((71892233 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((26322553 : ℝ) / 25000000)) (t := ((1322553 : ℝ) / 51322553))
    (lo := ((5155027 : ℝ) / 100000000)) (hi := ((1288757 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((26322553 : ℝ) / 6250000) = Real.log ((26322553 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((26322553 : ℝ) / 6250000) = ((26322553 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1093 : RB (Real.log ((65563273 : ℝ) / 50000000)) ((27099267 : ℝ) / 100000000) ((6774817 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((65563273 : ℝ) / 50000000)) (t := ((15563273 : ℝ) / 115563273))
    (lo := ((27099267 : ℝ) / 100000000)) (hi := ((6774817 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1094 : RB (Real.log ((4751661 : ℝ) / 50000000)) ((-2941911 : ℝ) / 1250000) ((-58838219 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4751661 : ℝ) / 6250000)) (t := ((-1498339 : ℝ) / 11001661))
    (lo := ((-27408723 : ℝ) / 100000000)) (hi := ((-13704361 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4751661 : ℝ) / 50000000) = Real.log ((4751661 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4751661 : ℝ) / 50000000) = ((4751661 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1095 : RB (Real.log ((177829 : ℝ) / 1562500)) ((-108661 : ℝ) / 50000) ((-54330499 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((355658 : ℝ) / 390625)) (t := ((-34967 : ℝ) / 746283))
    (lo := ((-9377843 : ℝ) / 100000000)) (hi := ((-4688921 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((177829 : ℝ) / 1562500) = Real.log ((355658 : ℝ) / 390625) - 3 * Real.log 2 := by
    rw [show ((177829 : ℝ) / 1562500) = ((355658 : ℝ) / 390625) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1096 : RB (Real.log ((3538993 : ℝ) / 100000000)) ((-334132801 : ℝ) / 100000000) ((-66826559 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3538993 : ℝ) / 3125000)) (t := ((413993 : ℝ) / 6663993))
    (lo := ((6220397 : ℝ) / 50000000)) (hi := ((2488159 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3538993 : ℝ) / 100000000) = Real.log ((3538993 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3538993 : ℝ) / 100000000) = ((3538993 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1097 : RB (Real.log ((1804159 : ℝ) / 50000000)) ((-6643857 : ℝ) / 2000000) ((-83048211 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1804159 : ℝ) / 1562500)) (t := ((241659 : ℝ) / 3366659))
    (lo := ((2876149 : ℝ) / 20000000)) (hi := ((7190373 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1804159 : ℝ) / 50000000) = Real.log ((1804159 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1804159 : ℝ) / 50000000) = ((1804159 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1098 : RB (Real.log ((8386847 : ℝ) / 12500000)) ((-49883 : ℝ) / 125000) ((-39906399 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8386847 : ℝ) / 12500000)) (t := ((-4113153 : ℝ) / 20886847))
    (lo := ((-49883 : ℝ) / 125000)) (hi := ((-39906399 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1099 : RB (Real.log ((16774243 : ℝ) / 25000000)) ((-39903127 : ℝ) / 100000000) ((-19951563 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16774243 : ℝ) / 25000000)) (t := ((-8225757 : ℝ) / 41774243))
    (lo := ((-39903127 : ℝ) / 100000000)) (hi := ((-19951563 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1100 : RB (Real.log ((40175461 : ℝ) / 100000000)) ((-91191381 : ℝ) / 100000000) ((-91191379 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40175461 : ℝ) / 50000000)) (t := ((-9824539 : ℝ) / 90175461))
    (lo := ((-10938331 : ℝ) / 50000000)) (hi := ((-21876661 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40175461 : ℝ) / 100000000) = Real.log ((40175461 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40175461 : ℝ) / 100000000) = ((40175461 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1101 : RB (Real.log ((12036839 : ℝ) / 6250000)) ((65539039 : ℝ) / 100000000) ((65539041 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12036839 : ℝ) / 12500000)) (t := ((-463161 : ℝ) / 24536839))
    (lo := ((-3775679 : ℝ) / 100000000)) (hi := ((-1887839 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12036839 : ℝ) / 6250000) = Real.log ((12036839 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((12036839 : ℝ) / 6250000) = ((12036839 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1102 : RB (Real.log ((12045051 : ℝ) / 6250000)) ((1640181 : ℝ) / 2500000) ((32803621 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12045051 : ℝ) / 12500000)) (t := ((-454949 : ℝ) / 24545051))
    (lo := ((-1853739 : ℝ) / 50000000)) (hi := ((-3707477 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12045051 : ℝ) / 6250000) = Real.log ((12045051 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((12045051 : ℝ) / 6250000) = ((12045051 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1103 : RB (Real.log ((68982383 : ℝ) / 100000000)) ((-290093 : ℝ) / 781250) ((-37131903 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68982383 : ℝ) / 100000000)) (t := ((-31017617 : ℝ) / 168982383))
    (lo := ((-290093 : ℝ) / 781250)) (hi := ((-37131903 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1104 : RB (Real.log ((68984603 : ℝ) / 100000000)) ((-18564343 : ℝ) / 50000000) ((-7425737 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((68984603 : ℝ) / 100000000)) (t := ((-31015397 : ℝ) / 168984603))
    (lo := ((-18564343 : ℝ) / 50000000)) (hi := ((-7425737 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1105 : RB (Real.log ((40843727 : ℝ) / 100000000)) ((-17908339 : ℝ) / 20000000) ((-89541693 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40843727 : ℝ) / 50000000)) (t := ((-9156273 : ℝ) / 90843727))
    (lo := ((-632093 : ℝ) / 3125000)) (hi := ((-809079 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40843727 : ℝ) / 100000000) = Real.log ((40843727 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40843727 : ℝ) / 100000000) = ((40843727 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1106 : RB (Real.log ((105857167 : ℝ) / 25000000)) ((144321487 : ℝ) / 100000000) ((14432149 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((105857167 : ℝ) / 100000000)) (t := ((5857167 : ℝ) / 205857167))
    (lo := ((5692051 : ℝ) / 100000000)) (hi := ((1423013 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((105857167 : ℝ) / 25000000) = Real.log ((105857167 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((105857167 : ℝ) / 25000000) = ((105857167 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1107 : RB (Real.log ((423432917 : ℝ) / 100000000)) ((144322491 : ℝ) / 100000000) ((72161247 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((423432917 : ℝ) / 400000000)) (t := ((23432917 : ℝ) / 823432917))
    (lo := ((1138611 : ℝ) / 20000000)) (hi := ((44477 : ℝ) / 781250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((423432917 : ℝ) / 100000000) = Real.log ((423432917 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((423432917 : ℝ) / 100000000) = ((423432917 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1108 : RB (Real.log ((130907489 : ℝ) / 100000000)) ((26932069 : ℝ) / 100000000) ((2693207 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((130907489 : ℝ) / 100000000)) (t := ((30907489 : ℝ) / 230907489))
    (lo := ((26932069 : ℝ) / 100000000)) (hi := ((2693207 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1109 : RB (Real.log ((420034381 : ℝ) / 100000000)) ((71758319 : ℝ) / 50000000) ((143516641 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((420034381 : ℝ) / 400000000)) (t := ((20034381 : ℝ) / 820034381))
    (lo := ((2443601 : ℝ) / 50000000)) (hi := ((4887203 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((420034381 : ℝ) / 100000000) = Real.log ((420034381 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((420034381 : ℝ) / 100000000) = ((420034381 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1110 : RB (Real.log ((210019293 : ℝ) / 50000000)) ((143517639 : ℝ) / 100000000) ((71758821 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((210019293 : ℝ) / 200000000)) (t := ((10019293 : ℝ) / 410019293))
    (lo := ((4888203 : ℝ) / 100000000)) (hi := ((1222051 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((210019293 : ℝ) / 50000000) = Real.log ((210019293 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((210019293 : ℝ) / 50000000) = ((210019293 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1111 : RB (Real.log ((65617647 : ℝ) / 50000000)) ((13591083 : ℝ) / 50000000) ((27182167 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65617647 : ℝ) / 50000000)) (t := ((15617647 : ℝ) / 115617647))
    (lo := ((13591083 : ℝ) / 50000000)) (hi := ((27182167 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1112 : RB (Real.log ((1927833 : ℝ) / 20000000)) ((-233933573 : ℝ) / 100000000) ((-233933569 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1927833 : ℝ) / 2500000)) (t := ((-572167 : ℝ) / 4427833))
    (lo := ((-3248677 : ℝ) / 12500000)) (hi := ((-5197883 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1927833 : ℝ) / 20000000) = Real.log ((1927833 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((1927833 : ℝ) / 20000000) = ((1927833 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1113 : RB (Real.log ((179623 : ℝ) / 1562500)) ((-10815911 : ℝ) / 5000000) ((-27039777 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((359246 : ℝ) / 390625)) (t := ((-31379 : ℝ) / 749871))
    (lo := ((-8374063 : ℝ) / 100000000)) (hi := ((-4187031 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((179623 : ℝ) / 1562500) = Real.log ((359246 : ℝ) / 390625) - 3 * Real.log 2 := by
    rw [show ((179623 : ℝ) / 1562500) = ((359246 : ℝ) / 390625) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1114 : RB (Real.log ((18017 : ℝ) / 500000)) ((-332329239 : ℝ) / 100000000) ((-332329233 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((18017 : ℝ) / 15625)) (t := ((1196 : ℝ) / 16821))
    (lo := ((3561089 : ℝ) / 25000000)) (hi := ((14244357 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((18017 : ℝ) / 500000) = Real.log ((18017 : ℝ) / 15625) - 5 * Real.log 2 := by
    rw [show ((18017 : ℝ) / 500000) = ((18017 : ℝ) / 15625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1115 : RB (Real.log ((1836409 : ℝ) / 50000000)) ((-165210551 : ℝ) / 50000000) ((-41302637 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((1836409 : ℝ) / 1562500)) (t := ((273909 : ℝ) / 3398909))
    (lo := ((16152493 : ℝ) / 100000000)) (hi := ((8076247 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1836409 : ℝ) / 50000000) = Real.log ((1836409 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1836409 : ℝ) / 50000000) = ((1836409 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1116 : RB (Real.log ((33445939 : ℝ) / 50000000)) ((-2513079 : ℝ) / 6250000) ((-40209263 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33445939 : ℝ) / 50000000)) (t := ((-16554061 : ℝ) / 83445939))
    (lo := ((-2513079 : ℝ) / 6250000)) (hi := ((-40209263 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1117 : RB (Real.log ((33447057 : ℝ) / 50000000)) ((-40205921 : ℝ) / 100000000) ((-251287 : ℝ) / 625000) := by
  have hm := log_bounds_of_series (x := ((33447057 : ℝ) / 50000000)) (t := ((-16552943 : ℝ) / 83447057))
    (lo := ((-40205921 : ℝ) / 100000000)) (hi := ((-251287 : ℝ) / 625000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1118 : RB (Real.log ((40103531 : ℝ) / 100000000)) ((-45685291 : ℝ) / 50000000) ((-4568529 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((40103531 : ℝ) / 50000000)) (t := ((-9896469 : ℝ) / 90103531))
    (lo := ((-22055863 : ℝ) / 100000000)) (hi := ((-11027931 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40103531 : ℝ) / 100000000) = Real.log ((40103531 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40103531 : ℝ) / 100000000) = ((40103531 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1119 : RB (Real.log ((24057249 : ℝ) / 12500000)) ((65470771 : ℝ) / 100000000) ((65470773 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((24057249 : ℝ) / 25000000)) (t := ((-942751 : ℝ) / 49057249))
    (lo := ((-3843947 : ℝ) / 100000000)) (hi := ((-1921973 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24057249 : ℝ) / 12500000) = Real.log ((24057249 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((24057249 : ℝ) / 12500000) = ((24057249 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
