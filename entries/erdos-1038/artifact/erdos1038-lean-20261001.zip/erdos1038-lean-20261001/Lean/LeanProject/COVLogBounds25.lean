import LeanProject.COVLogTwo
import LeanProject.COVLogBounds21
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2000 : RB (Real.log ((37285837 : ℝ) / 10000000)) ((26320569 : ℝ) / 20000000) ((4112589 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((37285837 : ℝ) / 40000000)) (t := ((-2714163 : ℝ) / 77285837))
    (lo := ((-7026591 : ℝ) / 100000000)) (hi := ((-702659 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37285837 : ℝ) / 10000000) = Real.log ((37285837 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((37285837 : ℝ) / 10000000) = ((37285837 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2001 : RB (Real.log ((186429187 : ℝ) / 50000000)) ((65801423 : ℝ) / 50000000) ((131602849 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((186429187 : ℝ) / 200000000)) (t := ((-13570813 : ℝ) / 386429187))
    (lo := ((-702659 : ℝ) / 10000000)) (hi := ((-7026589 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((186429187 : ℝ) / 50000000) = Real.log ((186429187 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((186429187 : ℝ) / 50000000) = ((186429187 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2002 : RB (Real.log ((68311817 : ℝ) / 50000000)) ((3900747 : ℝ) / 12500000) ((15602989 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((68311817 : ℝ) / 100000000)) (t := ((-31688183 : ℝ) / 168311817))
    (lo := ((-19054371 : ℝ) / 50000000)) (hi := ((-38108741 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68311817 : ℝ) / 50000000) = Real.log ((68311817 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((68311817 : ℝ) / 50000000) = ((68311817 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2003 : RB (Real.log ((183313899 : ℝ) / 50000000)) ((129917697 : ℝ) / 100000000) ((1299177 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((183313899 : ℝ) / 200000000)) (t := ((-16686101 : ℝ) / 383313899))
    (lo := ((-8711739 : ℝ) / 100000000)) (hi := ((-4355869 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((183313899 : ℝ) / 50000000) = Real.log ((183313899 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((183313899 : ℝ) / 50000000) = ((183313899 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2004 : RB (Real.log ((366627801 : ℝ) / 100000000)) ((64958849 : ℝ) / 50000000) ((129917701 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((366627801 : ℝ) / 400000000)) (t := ((-33372199 : ℝ) / 766627801))
    (lo := ((-4355869 : ℝ) / 50000000)) (hi := ((-8711737 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((366627801 : ℝ) / 100000000) = Real.log ((366627801 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((366627801 : ℝ) / 100000000) = ((366627801 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2005 : RB (Real.log ((137479457 : ℝ) / 100000000)) ((31830431 : ℝ) / 100000000) ((31830433 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((137479457 : ℝ) / 200000000)) (t := ((-62520543 : ℝ) / 337479457))
    (lo := ((-37484287 : ℝ) / 100000000)) (hi := ((-18742143 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((137479457 : ℝ) / 100000000) = Real.log ((137479457 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((137479457 : ℝ) / 100000000) = ((137479457 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2006 : RB (Real.log ((5323287 : ℝ) / 12500000)) ((-85363769 : ℝ) / 100000000) ((-85363767 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5323287 : ℝ) / 6250000)) (t := ((-926713 : ℝ) / 11573287))
    (lo := ((-320981 : ℝ) / 2000000)) (hi := ((-16049049 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5323287 : ℝ) / 12500000) = Real.log ((5323287 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5323287 : ℝ) / 12500000) = ((5323287 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2007 : RB (Real.log ((23184013 : ℝ) / 50000000)) ((-76856007 : ℝ) / 100000000) ((-15371201 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((23184013 : ℝ) / 25000000)) (t := ((-1815987 : ℝ) / 48184013))
    (lo := ((-942661 : ℝ) / 12500000)) (hi := ((-7541287 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23184013 : ℝ) / 50000000) = Real.log ((23184013 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((23184013 : ℝ) / 50000000) = ((23184013 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2008 : RB (Real.log ((77174447 : ℝ) / 100000000)) ((-25910179 : ℝ) / 100000000) ((-12955089 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((77174447 : ℝ) / 100000000)) (t := ((-22825553 : ℝ) / 177174447))
    (lo := ((-25910179 : ℝ) / 100000000)) (hi := ((-12955089 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2009 : RB (Real.log ((77174449 : ℝ) / 100000000)) ((-809693 : ℝ) / 3125000) ((-1036407 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((77174449 : ℝ) / 100000000)) (t := ((-22825551 : ℝ) / 177174449))
    (lo := ((-809693 : ℝ) / 3125000)) (hi := ((-1036407 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2010 : RB (Real.log ((21798797 : ℝ) / 50000000)) ((-10377103 : ℝ) / 12500000) ((-41508411 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((21798797 : ℝ) / 25000000)) (t := ((-3201203 : ℝ) / 46798797))
    (lo := ((-2740421 : ℝ) / 20000000)) (hi := ((-1712763 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21798797 : ℝ) / 50000000) = Real.log ((21798797 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21798797 : ℝ) / 50000000) = ((21798797 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2011 : RB (Real.log ((9837207 : ℝ) / 12500000)) ((-11977841 : ℝ) / 50000000) ((-23955681 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9837207 : ℝ) / 12500000)) (t := ((-2662793 : ℝ) / 22337207))
    (lo := ((-11977841 : ℝ) / 50000000)) (hi := ((-23955681 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2012 : RB (Real.log ((39348829 : ℝ) / 50000000)) ((-23955679 : ℝ) / 100000000) ((-11977839 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39348829 : ℝ) / 50000000)) (t := ((-10651171 : ℝ) / 89348829))
    (lo := ((-23955679 : ℝ) / 100000000)) (hi := ((-11977839 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2013 : RB (Real.log ((8815673 : ℝ) / 20000000)) ((-81920113 : ℝ) / 100000000) ((-81920111 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8815673 : ℝ) / 10000000)) (t := ((-1184327 : ℝ) / 18815673))
    (lo := ((-6302697 : ℝ) / 50000000)) (hi := ((-12605393 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8815673 : ℝ) / 20000000) = Real.log ((8815673 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8815673 : ℝ) / 20000000) = ((8815673 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2014 : RB (Real.log ((370674791 : ℝ) / 100000000)) ((131015491 : ℝ) / 100000000) ((65507747 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((370674791 : ℝ) / 400000000)) (t := ((-29325209 : ℝ) / 770674791))
    (lo := ((-1522789 : ℝ) / 20000000)) (hi := ((-951743 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((370674791 : ℝ) / 100000000) = Real.log ((370674791 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((370674791 : ℝ) / 100000000) = ((370674791 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2015 : RB (Real.log ((74134959 : ℝ) / 20000000)) ((32753873 : ℝ) / 25000000) ((26203099 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((74134959 : ℝ) / 80000000)) (t := ((-5865041 : ℝ) / 154134959))
    (lo := ((-951743 : ℝ) / 12500000)) (hi := ((-7613943 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((74134959 : ℝ) / 20000000) = Real.log ((74134959 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((74134959 : ℝ) / 20000000) = ((74134959 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2016 : RB (Real.log ((136919083 : ℝ) / 100000000)) ((3927749 : ℝ) / 12500000) ((15710997 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((136919083 : ℝ) / 200000000)) (t := ((-63080917 : ℝ) / 336919083))
    (lo := ((-18946363 : ℝ) / 50000000)) (hi := ((-1515709 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((136919083 : ℝ) / 100000000) = Real.log ((136919083 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((136919083 : ℝ) / 100000000) = ((136919083 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2017 : RB (Real.log ((364756357 : ℝ) / 100000000)) ((64702971 : ℝ) / 50000000) ((25881189 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((364756357 : ℝ) / 400000000)) (t := ((-35243643 : ℝ) / 764756357))
    (lo := ((-4611747 : ℝ) / 50000000)) (hi := ((-9223493 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((364756357 : ℝ) / 100000000) = Real.log ((364756357 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((364756357 : ℝ) / 100000000) = ((364756357 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2018 : RB (Real.log ((364756361 : ℝ) / 100000000)) ((129405943 : ℝ) / 100000000) ((64702973 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((364756361 : ℝ) / 400000000)) (t := ((-35243639 : ℝ) / 764756361))
    (lo := ((-9223493 : ℝ) / 100000000)) (hi := ((-2305873 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((364756361 : ℝ) / 100000000) = Real.log ((364756361 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((364756361 : ℝ) / 100000000) = ((364756361 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2019 : RB (Real.log ((68872191 : ℝ) / 50000000)) ((32022947 : ℝ) / 100000000) ((32022949 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68872191 : ℝ) / 100000000)) (t := ((-31127809 : ℝ) / 168872191))
    (lo := ((-37291771 : ℝ) / 100000000)) (hi := ((-3729177 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68872191 : ℝ) / 50000000) = Real.log ((68872191 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((68872191 : ℝ) / 50000000) = ((68872191 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2020 : RB (Real.log ((22475123 : ℝ) / 50000000)) ((-79961397 : ℝ) / 100000000) ((-15992279 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((22475123 : ℝ) / 25000000)) (t := ((-2524877 : ℝ) / 47475123))
    (lo := ((-5323339 : ℝ) / 50000000)) (hi := ((-10646677 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22475123 : ℝ) / 50000000) = Real.log ((22475123 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22475123 : ℝ) / 50000000) = ((22475123 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2021 : RB (Real.log ((24307509 : ℝ) / 50000000)) ((-7212377 : ℝ) / 10000000) ((-9015471 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((24307509 : ℝ) / 25000000)) (t := ((-692491 : ℝ) / 49307509))
    (lo := ((-2809051 : ℝ) / 100000000)) (hi := ((-56181 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24307509 : ℝ) / 50000000) = Real.log ((24307509 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((24307509 : ℝ) / 50000000) = ((24307509 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2022 : RB (Real.log ((77724123 : ℝ) / 100000000)) ((-6300113 : ℝ) / 25000000) ((-25200451 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((77724123 : ℝ) / 100000000)) (t := ((-22275877 : ℝ) / 177724123))
    (lo := ((-6300113 : ℝ) / 25000000)) (hi := ((-25200451 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2023 : RB (Real.log ((38862063 : ℝ) / 50000000)) ((-393757 : ℝ) / 1562500) ((-25200447 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38862063 : ℝ) / 50000000)) (t := ((-11137937 : ℝ) / 88862063))
    (lo := ((-393757 : ℝ) / 1562500)) (hi := ((-25200447 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2024 : RB (Real.log ((43772039 : ℝ) / 100000000)) ((-82617497 : ℝ) / 100000000) ((-16523499 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((43772039 : ℝ) / 50000000)) (t := ((-6227961 : ℝ) / 93772039))
    (lo := ((-6651389 : ℝ) / 50000000)) (hi := ((-13302777 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43772039 : ℝ) / 100000000) = Real.log ((43772039 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43772039 : ℝ) / 100000000) = ((43772039 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2025 : RB (Real.log ((79120071 : ℝ) / 100000000)) ((-23420361 : ℝ) / 100000000) ((-585509 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((79120071 : ℝ) / 100000000)) (t := ((-20879929 : ℝ) / 179120071))
    (lo := ((-23420361 : ℝ) / 100000000)) (hi := ((-585509 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2026 : RB (Real.log ((39560037 : ℝ) / 50000000)) ((-23420357 : ℝ) / 100000000) ((-5855089 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((39560037 : ℝ) / 50000000)) (t := ((-10439963 : ℝ) / 89560037))
    (lo := ((-23420357 : ℝ) / 100000000)) (hi := ((-5855089 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2027 : RB (Real.log ((11052561 : ℝ) / 25000000)) ((-81621367 : ℝ) / 100000000) ((-16324273 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((11052561 : ℝ) / 12500000)) (t := ((-1447439 : ℝ) / 23552561))
    (lo := ((-1538331 : ℝ) / 12500000)) (hi := ((-12306647 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11052561 : ℝ) / 25000000) = Real.log ((11052561 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11052561 : ℝ) / 25000000) = ((11052561 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2028 : RB (Real.log ((73720637 : ℝ) / 20000000)) ((130455049 : ℝ) / 100000000) ((32613763 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((73720637 : ℝ) / 80000000)) (t := ((-6279363 : ℝ) / 153720637))
    (lo := ((-8174387 : ℝ) / 100000000)) (hi := ((-4087193 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((73720637 : ℝ) / 20000000) = Real.log ((73720637 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((73720637 : ℝ) / 20000000) = ((73720637 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2029 : RB (Real.log ((368603189 : ℝ) / 100000000)) ((2609101 : ℝ) / 2000000) ((130455053 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((368603189 : ℝ) / 400000000)) (t := ((-31396811 : ℝ) / 768603189))
    (lo := ((-4087193 : ℝ) / 50000000)) (hi := ((-1634877 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((368603189 : ℝ) / 100000000) = Real.log ((368603189 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((368603189 : ℝ) / 100000000) = ((368603189 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2030 : RB (Real.log ((68601911 : ℝ) / 50000000)) ((15814869 : ℝ) / 50000000) ((1581487 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((68601911 : ℝ) / 100000000)) (t := ((-31398089 : ℝ) / 168601911))
    (lo := ((-1884249 : ℝ) / 5000000)) (hi := ((-37684979 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68601911 : ℝ) / 50000000) = Real.log ((68601911 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((68601911 : ℝ) / 50000000) = ((68601911 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2031 : RB (Real.log ((362973999 : ℝ) / 100000000)) ((128916101 : ℝ) / 100000000) ((16114513 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((362973999 : ℝ) / 400000000)) (t := ((-37026001 : ℝ) / 762973999))
    (lo := ((-1942667 : ℝ) / 20000000)) (hi := ((-4856667 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((362973999 : ℝ) / 100000000) = Real.log ((362973999 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((362973999 : ℝ) / 100000000) = ((362973999 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2032 : RB (Real.log ((362974003 : ℝ) / 100000000)) ((64458051 : ℝ) / 50000000) ((25783221 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((362974003 : ℝ) / 400000000)) (t := ((-37025997 : ℝ) / 762974003))
    (lo := ((-4856667 : ℝ) / 50000000)) (hi := ((-9713333 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((362974003 : ℝ) / 100000000) = Real.log ((362974003 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((362974003 : ℝ) / 100000000) = ((362974003 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2033 : RB (Real.log ((69000101 : ℝ) / 50000000)) ((2013031 : ℝ) / 6250000) ((16104249 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((69000101 : ℝ) / 100000000)) (t := ((-30999899 : ℝ) / 169000101))
    (lo := ((-18553111 : ℝ) / 50000000)) (hi := ((-37106221 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((69000101 : ℝ) / 50000000) = Real.log ((69000101 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((69000101 : ℝ) / 50000000) = ((69000101 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2034 : RB (Real.log ((23629809 : ℝ) / 50000000)) ((-74951401 : ℝ) / 100000000) ((-74951399 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((23629809 : ℝ) / 25000000)) (t := ((-1370191 : ℝ) / 48629809))
    (lo := ((-2818341 : ℝ) / 50000000)) (hi := ((-5636681 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23629809 : ℝ) / 50000000) = Real.log ((23629809 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((23629809 : ℝ) / 50000000) = ((23629809 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2035 : RB (Real.log ((50822481 : ℝ) / 100000000)) ((-3384157 : ℝ) / 5000000) ((-33841569 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((50822481 : ℝ) / 50000000)) (t := ((822481 : ℝ) / 100822481))
    (lo := ((1631579 : ℝ) / 100000000)) (hi := ((81579 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((50822481 : ℝ) / 100000000) = Real.log ((50822481 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((50822481 : ℝ) / 100000000) = ((50822481 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2036 : RB (Real.log ((782261 : ℝ) / 1000000)) ((-6139171 : ℝ) / 25000000) ((-24556683 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((782261 : ℝ) / 1000000)) (t := ((-217739 : ℝ) / 1782261))
    (lo := ((-6139171 : ℝ) / 25000000)) (hi := ((-24556683 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2037 : RB (Real.log ((78226103 : ℝ) / 100000000)) ((-613917 : ℝ) / 2500000) ((-24556679 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((78226103 : ℝ) / 100000000)) (t := ((-21773897 : ℝ) / 178226103))
    (lo := ((-613917 : ℝ) / 2500000)) (hi := ((-24556679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2038 : RB (Real.log ((21965203 : ℝ) / 50000000)) ((-1645127 : ℝ) / 2000000) ((-20564087 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((21965203 : ℝ) / 25000000)) (t := ((-3034797 : ℝ) / 46965203))
    (lo := ((-12941631 : ℝ) / 100000000)) (hi := ((-1294163 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21965203 : ℝ) / 50000000) = Real.log ((21965203 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21965203 : ℝ) / 50000000) = ((21965203 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2039 : RB (Real.log ((79510917 : ℝ) / 100000000)) ((-11463793 : ℝ) / 50000000) ((-4585517 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((79510917 : ℝ) / 100000000)) (t := ((-20489083 : ℝ) / 179510917))
    (lo := ((-11463793 : ℝ) / 50000000)) (hi := ((-4585517 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2040 : RB (Real.log ((1987773 : ℝ) / 2500000)) ((-11463791 : ℝ) / 50000000) ((-22927581 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1987773 : ℝ) / 2500000)) (t := ((-512227 : ℝ) / 4487773))
    (lo := ((-11463791 : ℝ) / 50000000)) (hi := ((-22927581 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2041 : RB (Real.log ((22165857 : ℝ) / 50000000)) ((-81346989 : ℝ) / 100000000) ((-81346987 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22165857 : ℝ) / 25000000)) (t := ((-2834143 : ℝ) / 47165857))
    (lo := ((-1203227 : ℝ) / 10000000)) (hi := ((-12032269 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22165857 : ℝ) / 50000000) = Real.log ((22165857 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22165857 : ℝ) / 50000000) = ((22165857 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2042 : RB (Real.log ((366635161 : ℝ) / 100000000)) ((25983941 : ℝ) / 20000000) ((32479927 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((366635161 : ℝ) / 400000000)) (t := ((-33364839 : ℝ) / 766635161))
    (lo := ((-8709731 : ℝ) / 100000000)) (hi := ((-870973 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((366635161 : ℝ) / 100000000) = Real.log ((366635161 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((366635161 : ℝ) / 100000000) = ((366635161 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2043 : RB (Real.log ((73327033 : ℝ) / 20000000)) ((64959853 : ℝ) / 50000000) ((129919709 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((73327033 : ℝ) / 80000000)) (t := ((-6672967 : ℝ) / 153327033))
    (lo := ((-870973 : ℝ) / 10000000)) (hi := ((-8709729 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((73327033 : ℝ) / 20000000) = Real.log ((73327033 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((73327033 : ℝ) / 20000000) = ((73327033 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2044 : RB (Real.log ((68739211 : ℝ) / 50000000)) ((15914839 : ℝ) / 50000000) ((397871 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((68739211 : ℝ) / 100000000)) (t := ((-31260789 : ℝ) / 168739211))
    (lo := ((-468563 : ℝ) / 1250000)) (hi := ((-37485039 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68739211 : ℝ) / 50000000) = Real.log ((68739211 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((68739211 : ℝ) / 50000000) = ((68739211 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2045 : RB (Real.log ((722549 : ℝ) / 200000)) ((128446787 : ℝ) / 100000000) ((12844679 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((722549 : ℝ) / 800000)) (t := ((-77451 : ℝ) / 1522549))
    (lo := ((-10182649 : ℝ) / 100000000)) (hi := ((-1272831 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((722549 : ℝ) / 200000) = Real.log ((722549 : ℝ) / 800000) + 2 * Real.log 2 := by
    rw [show ((722549 : ℝ) / 200000) = ((722549 : ℝ) / 800000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2046 : RB (Real.log ((361274503 : ℝ) / 100000000)) ((128446787 : ℝ) / 100000000) ((12844679 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((361274503 : ℝ) / 400000000)) (t := ((-38725497 : ℝ) / 761274503))
    (lo := ((-10182649 : ℝ) / 100000000)) (hi := ((-1272831 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((361274503 : ℝ) / 100000000) = Real.log ((361274503 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((361274503 : ℝ) / 100000000) = ((361274503 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2047 : RB (Real.log ((6912369 : ℝ) / 5000000)) ((647749 : ℝ) / 2000000) ((8096863 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((6912369 : ℝ) / 10000000)) (t := ((-3087631 : ℝ) / 16912369))
    (lo := ((-9231817 : ℝ) / 25000000)) (hi := ((-36927267 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6912369 : ℝ) / 5000000) = Real.log ((6912369 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((6912369 : ℝ) / 5000000) = ((6912369 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2048 : RB (Real.log ((12380073 : ℝ) / 25000000)) ((-4392423 : ℝ) / 6250000) ((-35139383 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12380073 : ℝ) / 12500000)) (t := ((-119927 : ℝ) / 24880073))
    (lo := ((-964049 : ℝ) / 100000000)) (hi := ((-60253 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12380073 : ℝ) / 25000000) = Real.log ((12380073 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((12380073 : ℝ) / 25000000) = ((12380073 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2049 : RB (Real.log ((52993551 : ℝ) / 100000000)) ((-63499997 : ℝ) / 100000000) ((-12699999 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((52993551 : ℝ) / 50000000)) (t := ((2993551 : ℝ) / 102993551))
    (lo := ((2907361 : ℝ) / 50000000)) (hi := ((5814723 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52993551 : ℝ) / 100000000) = Real.log ((52993551 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((52993551 : ℝ) / 100000000) = ((52993551 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2050 : RB (Real.log ((78686641 : ℝ) / 100000000)) ((-299621 : ℝ) / 1250000) ((-23969679 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((78686641 : ℝ) / 100000000)) (t := ((-21313359 : ℝ) / 178686641))
    (lo := ((-299621 : ℝ) / 1250000)) (hi := ((-23969679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2051 : RB (Real.log ((19671661 : ℝ) / 25000000)) ((-5992419 : ℝ) / 25000000) ((-958787 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((19671661 : ℝ) / 25000000)) (t := ((-5328339 : ℝ) / 44671661))
    (lo := ((-5992419 : ℝ) / 25000000)) (hi := ((-958787 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2052 : RB (Real.log ((22037459 : ℝ) / 50000000)) ((-81927933 : ℝ) / 100000000) ((-81927931 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22037459 : ℝ) / 25000000)) (t := ((-2962541 : ℝ) / 47037459))
    (lo := ((-6306607 : ℝ) / 50000000)) (hi := ((-12613213 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22037459 : ℝ) / 50000000) = Real.log ((22037459 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22037459 : ℝ) / 50000000) = ((22037459 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2053 : RB (Real.log ((79873723 : ℝ) / 100000000)) ((-22472327 : ℝ) / 100000000) ((-11236163 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((79873723 : ℝ) / 100000000)) (t := ((-20126277 : ℝ) / 179873723))
    (lo := ((-22472327 : ℝ) / 100000000)) (hi := ((-11236163 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2054 : RB (Real.log ((3194949 : ℝ) / 4000000)) ((-5618081 : ℝ) / 25000000) ((-22472323 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3194949 : ℝ) / 4000000)) (t := ((-805051 : ℝ) / 7194949))
    (lo := ((-5618081 : ℝ) / 25000000)) (hi := ((-22472323 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2055 : RB (Real.log ((44443997 : ℝ) / 100000000)) ((-8109403 : ℝ) / 10000000) ((-20273507 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((44443997 : ℝ) / 50000000)) (t := ((-5556003 : ℝ) / 94443997))
    (lo := ((-11779311 : ℝ) / 100000000)) (hi := ((-1177931 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44443997 : ℝ) / 100000000) = Real.log ((44443997 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44443997 : ℝ) / 100000000) = ((44443997 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2056 : RB (Real.log ((364763119 : ℝ) / 100000000)) ((32351949 : ℝ) / 25000000) ((129407799 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((364763119 : ℝ) / 400000000)) (t := ((-35236881 : ℝ) / 764763119))
    (lo := ((-230541 : ℝ) / 2500000)) (hi := ((-9221639 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((364763119 : ℝ) / 100000000) = Real.log ((364763119 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((364763119 : ℝ) / 100000000) = ((364763119 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2057 : RB (Real.log ((364763123 : ℝ) / 100000000)) ((129407797 : ℝ) / 100000000) ((647039 : ℝ) / 500000) := by
  have hm := log_bounds_of_series (x := ((364763123 : ℝ) / 400000000)) (t := ((-35236877 : ℝ) / 764763123))
    (lo := ((-9221639 : ℝ) / 100000000)) (hi := ((-4610819 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((364763123 : ℝ) / 100000000) = Real.log ((364763123 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((364763123 : ℝ) / 100000000) = ((364763123 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2058 : RB (Real.log ((68871709 : ℝ) / 50000000)) ((32022247 : ℝ) / 100000000) ((32022249 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68871709 : ℝ) / 100000000)) (t := ((-31128291 : ℝ) / 168871709))
    (lo := ((-37292471 : ℝ) / 100000000)) (hi := ((-3729247 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68871709 : ℝ) / 50000000) = Real.log ((68871709 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((68871709 : ℝ) / 50000000) = ((68871709 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2059 : RB (Real.log ((359652217 : ℝ) / 100000000)) ((127996731 : ℝ) / 100000000) ((63998367 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((359652217 : ℝ) / 400000000)) (t := ((-40347783 : ℝ) / 759652217))
    (lo := ((-2126541 : ℝ) / 20000000)) (hi := ((-41534 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((359652217 : ℝ) / 100000000) = Real.log ((359652217 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((359652217 : ℝ) / 100000000) = ((359652217 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2060 : RB (Real.log ((359652221 : ℝ) / 100000000)) ((31999183 : ℝ) / 25000000) ((25599347 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((359652221 : ℝ) / 400000000)) (t := ((-40347779 : ℝ) / 759652221))
    (lo := ((-41534 : ℝ) / 390625)) (hi := ((-10632703 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((359652221 : ℝ) / 100000000) = Real.log ((359652221 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((359652221 : ℝ) / 100000000) = ((359652221 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2061 : RB (Real.log ((69243173 : ℝ) / 50000000)) ((16280077 : ℝ) / 50000000) ((8140039 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((69243173 : ℝ) / 100000000)) (t := ((-30756827 : ℝ) / 169243173))
    (lo := ((-9188641 : ℝ) / 25000000)) (hi := ((-36754563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((69243173 : ℝ) / 50000000) = Real.log ((69243173 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((69243173 : ℝ) / 50000000) = ((69243173 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2062 : RB (Real.log ((51737059 : ℝ) / 100000000)) ((-65899587 : ℝ) / 100000000) ((-13179917 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((51737059 : ℝ) / 50000000)) (t := ((1737059 : ℝ) / 101737059))
    (lo := ((853783 : ℝ) / 25000000)) (hi := ((3415133 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51737059 : ℝ) / 100000000) = Real.log ((51737059 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((51737059 : ℝ) / 100000000) = ((51737059 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2063 : RB (Real.log ((1378273 : ℝ) / 2500000)) ((-14886487 : ℝ) / 25000000) ((-29772973 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1378273 : ℝ) / 1250000)) (t := ((128273 : ℝ) / 2628273))
    (lo := ((9768771 : ℝ) / 100000000)) (hi := ((2442193 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1378273 : ℝ) / 2500000) = Real.log ((1378273 : ℝ) / 1250000) - 1 * Real.log 2 := by
    rw [show ((1378273 : ℝ) / 2500000) = ((1378273 : ℝ) / 1250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2064 : RB (Real.log ((39555459 : ℝ) / 50000000)) ((-2343193 : ℝ) / 10000000) ((-23431929 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39555459 : ℝ) / 50000000)) (t := ((-10444541 : ℝ) / 89555459))
    (lo := ((-2343193 : ℝ) / 10000000)) (hi := ((-23431929 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2065 : RB (Real.log ((79110921 : ℝ) / 100000000)) ((-11715963 : ℝ) / 50000000) ((-937277 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((79110921 : ℝ) / 100000000)) (t := ((-20889079 : ℝ) / 179110921))
    (lo := ((-11715963 : ℝ) / 50000000)) (hi := ((-937277 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2066 : RB (Real.log ((44207393 : ℝ) / 100000000)) ((-10203477 : ℝ) / 12500000) ((-40813907 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((44207393 : ℝ) / 50000000)) (t := ((-5792607 : ℝ) / 94207393))
    (lo := ((-12313097 : ℝ) / 100000000)) (hi := ((-1539137 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44207393 : ℝ) / 100000000) = Real.log ((44207393 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44207393 : ℝ) / 100000000) = ((44207393 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2067 : RB (Real.log ((80211491 : ℝ) / 100000000)) ((-22050341 : ℝ) / 100000000) ((-1102517 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((80211491 : ℝ) / 100000000)) (t := ((-19788509 : ℝ) / 180211491))
    (lo := ((-22050341 : ℝ) / 100000000)) (hi := ((-1102517 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2068 : RB (Real.log ((40105747 : ℝ) / 50000000)) ((-22050337 : ℝ) / 100000000) ((-689073 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((40105747 : ℝ) / 50000000)) (t := ((-9894253 : ℝ) / 90105747))
    (lo := ((-22050337 : ℝ) / 100000000)) (hi := ((-689073 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2069 : RB (Real.log ((71277 : ℝ) / 160000)) ((-80860013 : ℝ) / 100000000) ((-80860011 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((71277 : ℝ) / 80000)) (t := ((-8723 : ℝ) / 151277))
    (lo := ((-5772647 : ℝ) / 50000000)) (hi := ((-11545293 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71277 : ℝ) / 160000) = Real.log ((71277 : ℝ) / 80000) - 1 * Real.log 2 := by
    rw [show ((71277 : ℝ) / 160000) = ((71277 : ℝ) / 80000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2070 : RB (Real.log ((18149011 : ℝ) / 5000000)) ((25783563 : ℝ) / 20000000) ((64458909 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18149011 : ℝ) / 20000000)) (t := ((-1850989 : ℝ) / 38149011))
    (lo := ((-9711621 : ℝ) / 100000000)) (hi := ((-485581 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((18149011 : ℝ) / 5000000) = Real.log ((18149011 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((18149011 : ℝ) / 5000000) = ((18149011 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2071 : RB (Real.log ((2835783 : ℝ) / 781250)) ((16114727 : ℝ) / 12500000) ((128917819 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2835783 : ℝ) / 3125000)) (t := ((-289217 : ℝ) / 5960783))
    (lo := ((-485581 : ℝ) / 5000000)) (hi := ((-9711619 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2835783 : ℝ) / 781250) = Real.log ((2835783 : ℝ) / 3125000) + 2 * Real.log 2 := by
    rw [show ((2835783 : ℝ) / 781250) = ((2835783 : ℝ) / 3125000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2072 : RB (Real.log ((137999303 : ℝ) / 100000000)) ((8051961 : ℝ) / 25000000) ((16103923 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((137999303 : ℝ) / 200000000)) (t := ((-62000697 : ℝ) / 337999303))
    (lo := ((-18553437 : ℝ) / 50000000)) (hi := ((-37106873 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((137999303 : ℝ) / 100000000) = Real.log ((137999303 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((137999303 : ℝ) / 100000000) = ((137999303 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2073 : RB (Real.log ((358102003 : ℝ) / 100000000)) ((3986399 : ℝ) / 3125000) ((127564771 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((358102003 : ℝ) / 400000000)) (t := ((-41897997 : ℝ) / 758102003))
    (lo := ((-2766167 : ℝ) / 25000000)) (hi := ((-11064667 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((358102003 : ℝ) / 100000000) = Real.log ((358102003 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((358102003 : ℝ) / 100000000) = ((358102003 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2074 : RB (Real.log ((358102007 : ℝ) / 100000000)) ((127564769 : ℝ) / 100000000) ((31891193 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((358102007 : ℝ) / 400000000)) (t := ((-41897993 : ℝ) / 758102007))
    (lo := ((-11064667 : ℝ) / 100000000)) (hi := ((-5532333 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((358102007 : ℝ) / 100000000) = Real.log ((358102007 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((358102007 : ℝ) / 100000000) = ((358102007 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2075 : RB (Real.log ((138717503 : ℝ) / 100000000)) ((8181733 : ℝ) / 25000000) ((16363467 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((138717503 : ℝ) / 200000000)) (t := ((-61282497 : ℝ) / 338717503))
    (lo := ((-18293893 : ℝ) / 50000000)) (hi := ((-7317557 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((138717503 : ℝ) / 100000000) = Real.log ((138717503 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((138717503 : ℝ) / 100000000) = ((138717503 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2076 : RB (Real.log ((53913899 : ℝ) / 100000000)) ((-61778189 : ℝ) / 100000000) ((-61778187 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((53913899 : ℝ) / 50000000)) (t := ((3913899 : ℝ) / 103913899))
    (lo := ((753653 : ℝ) / 10000000)) (hi := ((7536531 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53913899 : ℝ) / 100000000) = Real.log ((53913899 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((53913899 : ℝ) / 100000000) = ((53913899 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2077 : RB (Real.log ((14309227 : ℝ) / 25000000)) ((-55797127 : ℝ) / 100000000) ((-446377 : ℝ) / 800000) := by
  have hm := log_bounds_of_series (x := ((14309227 : ℝ) / 12500000)) (t := ((1809227 : ℝ) / 26809227))
    (lo := ((1689699 : ℝ) / 12500000)) (hi := ((13517593 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14309227 : ℝ) / 25000000) = Real.log ((14309227 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((14309227 : ℝ) / 25000000) = ((14309227 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2078 : RB (Real.log ((19875809 : ℝ) / 25000000)) ((-22937247 : ℝ) / 100000000) ((-11468623 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19875809 : ℝ) / 25000000)) (t := ((-5124191 : ℝ) / 44875809))
    (lo := ((-22937247 : ℝ) / 100000000)) (hi := ((-11468623 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2079 : RB (Real.log ((79503239 : ℝ) / 100000000)) ((-22937243 : ℝ) / 100000000) ((-11468621 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((79503239 : ℝ) / 100000000)) (t := ((-20496761 : ℝ) / 179503239))
    (lo := ((-22937243 : ℝ) / 100000000)) (hi := ((-11468621 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
