import Mathlib.Analysis.MeanInequalities
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-!
# EP-1038: elementary lemmas (Stage 15, first batch)

Formalisations of Math-RED-reviewed elementary steps of proof.md:

* `orientation_abs_le` — Lemma 7.3, pointwise inequality only: `|x - t| ≤ 1 - x t`.
* `amgm_radius` — Lemma 7.5(b), final AM–GM step only: `w^(1-w) (1-w)^w ≤ 1/2` for `w ∈ [0,1]`.
* `rect_factor_le` — Lemma 1.4, the vertex bound for one factor only.
* `one_le_prod`, `prod_eq_one_of_one_le`, `sq_eq_one_of_two_sub_sq` — the algebraic core of the
  equality case of Theorem 6.7 (all roots are `±1`).
* `pow_balance` — `(√2+1)^a (√2-1)^b = 1 → a = b` (Theorem 6.7, last step).
-/

open Real

namespace EP1038

/-- Lemma 7.3 (pointwise part): for `-1 < x < 0` and `t ∈ [-1,1]`, `|x - t| ≤ 1 - x t`. -/
theorem orientation_abs_le {x t : ℝ} (hx1 : -1 < x) (hx0 : x < 0) (ht1 : -1 ≤ t) (ht2 : t ≤ 1) :
    |x - t| ≤ 1 - x * t := by
  rw [abs_le]
  constructor
  · nlinarith [mul_nonneg (by linarith : (0:ℝ) ≤ 1 + x) (by linarith : (0:ℝ) ≤ 1 - t)]
  · nlinarith [mul_nonneg (by linarith : (0:ℝ) ≤ 1 - x) (by linarith : (0:ℝ) ≤ 1 + t)]

/-- Lemma 7.5(b), final AM–GM step only (not the lemma itself): `w^(1-w) * (1-w)^w ≤ 1/2`
for `0 ≤ w ≤ 1` (real powers). -/
theorem amgm_radius {w : ℝ} (h0 : 0 ≤ w) (h1 : w ≤ 1) :
    w ^ (1 - w) * (1 - w) ^ w ≤ 1 / 2 := by
  have key := Real.geom_mean_le_arith_mean2_weighted (w₁ := 1 - w) (w₂ := w) (p₁ := w)
    (p₂ := 1 - w) (by linarith) h0 h0 (by linarith) (by ring)
  have : (1 - w) * w + w * (1 - w) ≤ 1 / 2 := by nlinarith [sq_nonneg (2 * w - 1)]
  linarith

/-- Lemma 1.4, one factor: if `r ∈ [l, u]` and `x ∈ [a, b]` then `|x - r|` is at most the largest
of the four vertex distances. -/
theorem rect_factor_le {a b l u x r : ℝ} (hx : x ∈ Set.Icc a b) (hr : r ∈ Set.Icc l u) :
    |x - r| ≤ max (max |a - l| |a - u|) (max |b - l| |b - u|) := by
  obtain ⟨hxa, hxb⟩ := hx
  obtain ⟨hrl, hru⟩ := hr
  rcases le_total r x with h | h
  · have : |x - r| ≤ |b - l| := by
      rw [abs_of_nonneg (by linarith), abs_of_nonneg (by linarith)]; linarith
    exact le_trans this (le_trans (le_max_left _ _) (le_max_right _ _))
  · have : |x - r| ≤ |a - u| := by
      rw [abs_of_nonpos (by linarith), abs_of_nonpos (by linarith)]; linarith
    exact le_trans this (le_trans (le_max_right _ _) (le_max_left _ _))

/-- A finite product of reals `≥ 1` is `≥ 1`. -/
theorem one_le_prod (s : Multiset ℝ) (h1 : ∀ y ∈ s, 1 ≤ y) : 1 ≤ s.prod := by
  induction s using Multiset.induction_on with
  | empty => simp
  | cons a s ih =>
    rw [Multiset.prod_cons]
    have ha : 1 ≤ a := h1 a (Multiset.mem_cons_self a s)
    have hs : 1 ≤ s.prod := ih (fun z hz => h1 z (Multiset.mem_cons_of_mem hz))
    nlinarith

/-- A finite product of reals `≥ 1` equals `1` only if every factor equals `1`. -/
theorem prod_eq_one_of_one_le (s : Multiset ℝ) (h1 : ∀ y ∈ s, 1 ≤ y) (hp : s.prod = 1) :
    ∀ y ∈ s, y = 1 := by
  induction s using Multiset.induction_on with
  | empty => intro y hy; simp at hy
  | cons a s ih =>
    intro y hy
    have ha : 1 ≤ a := h1 a (Multiset.mem_cons_self a s)
    have hs1 : ∀ z ∈ s, 1 ≤ z := fun z hz => h1 z (Multiset.mem_cons_of_mem hz)
    have hsp : 1 ≤ s.prod := one_le_prod s hs1
    rw [Multiset.prod_cons] at hp
    have ha1 : a = 1 := by nlinarith
    have hs : s.prod = 1 := by rw [ha1, one_mul] at hp; exact hp
    rcases Multiset.mem_cons.mp hy with rfl | hy'
    · exact ha1
    · exact ih hs1 hs y hy'

/-- Theorem 6.7, equality case: if all roots lie in `[-1,1]` and `∏ (2 - r^2) = 1`, then every
root satisfies `r^2 = 1`, i.e. `r = ±1`. -/
theorem sq_eq_one_of_two_sub_sq (s : Multiset ℝ) (hs : ∀ r ∈ s, r ∈ Set.Icc (-1 : ℝ) 1)
    (hp : (s.map fun r => 2 - r ^ 2).prod = 1) : ∀ r ∈ s, r ^ 2 = 1 := by
  have hge : ∀ y ∈ s.map (fun r => 2 - r ^ 2), 1 ≤ y := by
    intro y hy
    obtain ⟨r, hr, rfl⟩ := Multiset.mem_map.mp hy
    obtain ⟨h1, h2⟩ := hs r hr
    nlinarith
  have hall := prod_eq_one_of_one_le _ hge hp
  intro r hr
  have := hall (2 - r ^ 2) (Multiset.mem_map_of_mem _ hr)
  linarith

/-- Theorem 6.7, last step: `(√2+1)^a (√2-1)^b = 1` forces `a = b`. -/
theorem pow_balance (a b : ℕ) (h : (√2 + 1) ^ a * (√2 - 1) ^ b = 1) : a = b := by
  have hs : √2 * √2 = 2 := Real.mul_self_sqrt (by norm_num)
  have hs1 : (1 : ℝ) < √2 := by
    rw [show (1 : ℝ) = √1 by simp]; exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
  have hprod : (√2 - 1) * (√2 + 1) = 1 := by nlinarith
  have hgt : (1 : ℝ) < √2 + 1 := by linarith
  have hinv : √2 - 1 = (√2 + 1)⁻¹ := eq_inv_of_mul_eq_one_left hprod
  rw [hinv, inv_pow, ← div_eq_mul_inv, div_eq_one_iff_eq (by positivity)] at h
  rcases lt_trichotomy a b with hab | hab | hab
  · exact absurd h (ne_of_lt (pow_lt_pow_right₀ hgt hab))
  · exact hab
  · exact absurd h (ne_of_gt (pow_lt_pow_right₀ hgt hab))

end EP1038
