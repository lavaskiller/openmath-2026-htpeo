import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk13
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_48 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((147051526108395340798715250291507 : ℝ) / 1298074214633706907132624082305024) ((594180491006432999227012568160665 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((113284374999 : ℝ) / 1000000000000) ((22887 : ℝ) / 200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1113284374999 : ℝ) / 1000000000000) ((222887 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((107314542801 : ℝ) / 1000000000000) ((54173775013 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_639.1 dlower_log_640.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((107314542801 : ℝ) / 500000000000) ((54173775013 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((476452080507 : ℝ) / 1000000000000) ((239259047479 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-544463507169 : ℝ) / 250000000000) ((-216774830277 : ℝ) / 100000000000) := rb_log hqr (by norm_num) dlower_log_641.1 dlower_log_642.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((216774830277 : ℝ) / 100000000000) ((544463507169 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((218771356681 : ℝ) / 1000000000000) ((22074430613 : ℝ) / 100000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((77925569387 : ℝ) / 100000000000) ((781228643319 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((6416674809 : ℝ) / 500000000000) ((523814769 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((13090699077 : ℝ) / 50000000000)) - (z9)
  have h10 : RB z10 ((49743722463 : ℝ) / 200000000000) ((124490315961 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((13090699077 : ℝ) / 50000000000) ((13090699077 : ℝ) / 50000000000) ((13090699077 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((36909300923 : ℝ) / 50000000000))
  have h11 : RB z11 ((336932163567 : ℝ) / 1000000000000) ((168643557109 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((36909300923 : ℝ) / 50000000000) ((36909300923 : ℝ) / 50000000000) ((36909300923 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-271968415987 : ℝ) / 250000000000) ((-8694565923 : ℝ) / 8000000000) := rb_log h11 (by norm_num) dlower_log_643.1 dlower_log_644.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-849878066589 : ℝ) / 1000000000000) ((-846911250153 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((13090699077 : ℝ) / 50000000000))
  have h14 : RB z14 ((-1340121021509 : ℝ) / 1000000000000) ((-1340121021507 : ℝ) / 1000000000000) := rb_log (show RB ((13090699077 : ℝ) / 50000000000) ((13090699077 : ℝ) / 50000000000) ((13090699077 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_645.1 dlower_log_645.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((245121477459 : ℝ) / 500000000000) ((123302442839 : ℝ) / 250000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((293121499 : ℝ) / 25000000000) ((16757690849 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((6416674809 : ℝ) / 500000000000) ((523814769 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((295391266239 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((146386096197 : ℝ) / 100000000000) ((1464122981577 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((295391266239 : ℝ) / 200000000000) ((295391266239 : ℝ) / 200000000000) ((295391266239 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((95391266239 : ℝ) / 200000000000))
  have h19 : RB z19 ((383646485597 : ℝ) / 125000000000) ((3069721242423 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((95391266239 : ℝ) / 200000000000) ((95391266239 : ℝ) / 200000000000) ((95391266239 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((560703890419 : ℝ) / 500000000000) ((1121586756963 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_646.1 dlower_log_647.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((27308231199 : ℝ) / 31250000000) ((876215700507 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((295391266239 : ℝ) / 200000000000))
  have h22 : RB z22 ((389983437231 : ℝ) / 1000000000000) ((389983437233 : ℝ) / 1000000000000) := rb_log (show RB ((295391266239 : ℝ) / 200000000000) ((295391266239 : ℝ) / 200000000000) ((295391266239 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_648.1 dlower_log_648.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((96775992227 : ℝ) / 200000000000) ((121558065819 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5361866177 : ℝ) / 1000000000000) ((9780182769 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1113284374999 : ℝ) / 1000000000000) ((222887 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((38731315613 : ℝ) / 31250000000) ((49678614769 : ℝ) / 40000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((80517542983 : ℝ) / 50000000000) ((322736261399 : ℝ) / 200000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((243028469931 : ℝ) / 200000000000))
  have h28 : RB z28 ((122300345461 : ℝ) / 62500000000) ((1960852494977 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((243028469931 : ℝ) / 200000000000) ((243028469931 : ℝ) / 200000000000) ((243028469931 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((6416674809 : ℝ) / 500000000000) ((523814769 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3866878176308738561403 : ℝ) / 10000000000000000000000))
  have h30 : RB z30 ((6637576377 : ℝ) / 200000000000) ((6773096347 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((3866878176308738561403 : ℝ) / 10000000000000000000000) ((3866878176308738561403 : ℝ) / 10000000000000000000000) ((3866878176308738561403 : ℝ) / 10000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((193226903653 : ℝ) / 200000000000) ((193362423623 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1890537365529 : ℝ) / 1000000000000) ((94788797699 : ℝ) / 50000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((13090699077 : ℝ) / 50000000000)) ((293121499 : ℝ) / 25000000000) ((16757690849 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((295391266239 : ℝ) / 200000000000)) ((5361866177 : ℝ) / 1000000000000) ((9780182769 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((13090699077 : ℝ) / 50000000000)) (wl := ((295391266239 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1890537365529 : ℝ) / 1000000000000) ≤ D0q (q) * (((295391266239 : ℝ) / 200000000000) - ((13090699077 : ℝ) / 50000000000)) * (1 - (q) ^ 2 / (((295391266239 : ℝ) / 200000000000) * ((13090699077 : ℝ) / 50000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_49 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((594180491006432999227012568160665 : ℝ) / 5192296858534827628530496329220096) ((600154877579284635259164135155301 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((114434999999 : ℝ) / 1000000000000) ((184937 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1114434999999 : ℝ) / 1000000000000) ((1784937 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((13543443753 : ℝ) / 125000000000) ((54689745623 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_649.1 dlower_log_650.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((13543443753 : ℝ) / 62500000000) ((54689745623 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((474388198067 : ℝ) / 1000000000000) ((3722281879 : ℝ) / 7812500000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2167748302781 : ℝ) / 1000000000000) ((-1078871840843 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_651.1 dlower_log_652.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1078871840843 : ℝ) / 500000000000) ((2167748302781 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((54709787739 : ℝ) / 250000000000) ((5520258089 : ℝ) / 25000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((19479741911 : ℝ) / 25000000000) ((195290212261 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1636921153 : ℝ) / 125000000000) ((13360036707 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((32779717429 : ℝ) / 125000000000)) - (z9)
  have h10 : RB z10 ((9955108109 : ℝ) / 40000000000) ((7785699069 : ℝ) / 31250000000) := rb_widen (rb_sub (show RB ((32779717429 : ℝ) / 125000000000) ((32779717429 : ℝ) / 125000000000) ((32779717429 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((92220282571 : ℝ) / 125000000000))
  have h11 : RB z11 ((168670665353 : ℝ) / 500000000000) ((168850037149 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((92220282571 : ℝ) / 125000000000) ((92220282571 : ℝ) / 125000000000) ((92220282571 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1086660010459 : ℝ) / 1000000000000) ((-135699641447 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_653.1 dlower_log_654.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-848856256393 : ℝ) / 1000000000000) ((-3304242491 : ℝ) / 3906250000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((32779717429 : ℝ) / 125000000000))
  have h14 : RB z14 ((-5354015137 : ℝ) / 4000000000) ((-167312973031 : ℝ) / 125000000000) := rb_log (show RB ((32779717429 : ℝ) / 125000000000) ((32779717429 : ℝ) / 125000000000) ((32779717429 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_655.1 dlower_log_655.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((97929505571 : ℝ) / 200000000000) ((246308853277 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((13195447343 : ℝ) / 1000000000000) ((18229508487 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1636921153 : ℝ) / 125000000000) ((13360036707 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((738999973603 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1464639910499 : ℝ) / 1000000000000) ((732452288991 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((738999973603 : ℝ) / 500000000000) ((738999973603 : ℝ) / 500000000000) ((738999973603 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((238999973603 : ℝ) / 500000000000))
  have h19 : RB z19 ((383012571199 : ℝ) / 125000000000) ((3064654267317 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((238999973603 : ℝ) / 500000000000) ((238999973603 : ℝ) / 500000000000) ((238999973603 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((139969259289 : ℝ) / 125000000000) ((279983690701 : ℝ) / 250000000000) := rb_log h19 (by norm_num) dlower_log_656.1 dlower_log_657.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((174500162971 : ℝ) / 200000000000) ((437424595093 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((738999973603 : ℝ) / 500000000000))
  have h22 : RB z22 ((78137957361 : ℝ) / 200000000000) ((390689786807 : ℝ) / 1000000000000) := rb_log (show RB ((738999973603 : ℝ) / 500000000000) ((738999973603 : ℝ) / 500000000000) ((738999973603 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_658.1 dlower_log_658.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((30113189253 : ℝ) / 62500000000) ((484159403381 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((334934221 : ℝ) / 62500000000) ((4885602657 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1114434999999 : ℝ) / 1000000000000) ((1784937 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((620982684611 : ℝ) / 500000000000) ((1244531286707 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((803515356087 : ℝ) / 500000000000) ((322070171933 : ℝ) / 200000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((607881103887 : ℝ) / 500000000000))
  have h28 : RB z28 ((1953767206593 : ℝ) / 1000000000000) ((978901858219 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((607881103887 : ℝ) / 500000000000) ((607881103887 : ℝ) / 500000000000) ((607881103887 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1636921153 : ℝ) / 125000000000) ((13360036707 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((24224210314744799026687 : ℝ) / 62500000000000000000000))
  have h30 : RB z30 ((16893441847 : ℝ) / 500000000000) ((17234871299 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((24224210314744799026687 : ℝ) / 62500000000000000000000) ((24224210314744799026687 : ℝ) / 62500000000000000000000) ((24224210314744799026687 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((482765128701 : ℝ) / 500000000000) ((483106558153 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((377284270777 : ℝ) / 200000000000) ((236456953747 : ℝ) / 125000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((32779717429 : ℝ) / 125000000000)) ((13195447343 : ℝ) / 1000000000000) ((18229508487 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((738999973603 : ℝ) / 500000000000)) ((334934221 : ℝ) / 62500000000) ((4885602657 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((32779717429 : ℝ) / 125000000000)) (wl := ((738999973603 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((377284270777 : ℝ) / 200000000000) ≤ D0q (q) * (((738999973603 : ℝ) / 500000000000) - ((32779717429 : ℝ) / 125000000000)) * (1 - (q) ^ 2 / (((738999973603 : ℝ) / 500000000000) * ((32779717429 : ℝ) / 125000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_50 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((600154877579284635259164135155301 : ℝ) / 5192296858534827628530496329220096) ((303064632076068135645657851074969 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((115585624999 : ℝ) / 1000000000000) ((93389 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1115585624999 : ℝ) / 1000000000000) ((893389 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((27344872811 : ℝ) / 250000000000) ((110410368661 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_659.1 dlower_log_660.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((27344872811 : ℝ) / 125000000000) ((110410368661 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((472326443237 : ℝ) / 1000000000000) ((59298524759 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2157743681697 : ℝ) / 1000000000000) ((-2147838162387 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_661.1 dlower_log_662.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2147838162387 : ℝ) / 1000000000000) ((2157743681697 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((109449154513 : ℝ) / 500000000000) ((55216939337 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((194783060663 : ℝ) / 250000000000) ((390550845487 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((6680018353 : ℝ) / 500000000000) ((2725470413 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((132197243409 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((250767134753 : ℝ) / 1000000000000) ((3922413283 : ℝ) / 15625000000) := rb_widen (rb_sub (show RB ((132197243409 : ℝ) / 500000000000) ((132197243409 : ℝ) / 500000000000) ((132197243409 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((367802756591 : ℝ) / 500000000000))
  have h11 : RB z11 ((42612366659 : ℝ) / 125000000000) ((42657791033 : ℝ) / 125000000000) := rb_div_signed h10 (show RB ((367802756591 : ℝ) / 500000000000) ((367802756591 : ℝ) / 500000000000) ((367802756591 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1076169228997 : ℝ) / 1000000000000) ((-67193987897 : ℝ) / 62500000000) := rb_log h11 (by norm_num) dlower_log_663.1 dlower_log_664.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-13134337571 : ℝ) / 15625000000) ((-418824019863 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((132197243409 : ℝ) / 500000000000))
  have h14 : RB z14 ((-665156511447 : ℝ) / 500000000000) ((-332578255723 : ℝ) / 250000000000) := rb_log (show RB ((132197243409 : ℝ) / 500000000000) ((132197243409 : ℝ) / 500000000000) ((132197243409 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_665.1 dlower_log_665.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((122428854587 : ℝ) / 250000000000) ((3848945181 : ℝ) / 7812500000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((3831805069 : ℝ) / 250000000000) ((20338539931 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((6680018353 : ℝ) / 500000000000) ((2725470413 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1479049358823 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((732711003379 : ℝ) / 500000000000) ((1465689322117 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1479049358823 : ℝ) / 1000000000000) ((1479049358823 : ℝ) / 1000000000000) ((1479049358823 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((479049358823 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3059020912497 : ℝ) / 1000000000000) ((19122368279 : ℝ) / 6250000000) := rb_div_signed h18 (show RB ((479049358823 : ℝ) / 1000000000000) ((479049358823 : ℝ) / 1000000000000) ((479049358823 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1118094901527 : ℝ) / 1000000000000) ((1118277300169 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_666.1 dlower_log_667.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((217785947031 : ℝ) / 250000000000) ((43674414507 : ℝ) / 50000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1479049358823 : ℝ) / 1000000000000))
  have h22 : RB z22 ((97849889069 : ℝ) / 250000000000) ((195699778139 : ℝ) / 500000000000) := rb_log (show RB ((1479049358823 : ℝ) / 1000000000000) ((1479049358823 : ℝ) / 1000000000000) ((1479049358823 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_668.1 dlower_log_668.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((239872115923 : ℝ) / 500000000000) ((60261091733 : ℝ) / 125000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2678016887 : ℝ) / 500000000000) ((9762290627 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1115585624999 : ℝ) / 1000000000000) ((893389 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((77783205419 : ℝ) / 62500000000) ((249419970413 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((200465102763 : ℝ) / 125000000000) ((1607030712179 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((242930974401 : ℝ) / 200000000000))
  have h28 : RB z28 ((121747956869 : ℝ) / 62500000000) ((195198768401 : ℝ) / 100000000000) := rb_widen (rb_mul h27 (show RB ((242930974401 : ℝ) / 200000000000) ((242930974401 : ℝ) / 200000000000) ((242930974401 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((6680018353 : ℝ) / 500000000000) ((2725470413 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((195526248102249512747607 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((8541076221 : ℝ) / 250000000000) ((34847884101 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((195526248102249512747607 : ℝ) / 500000000000000000000000) ((195526248102249512747607 : ℝ) / 500000000000000000000000) ((195526248102249512747607 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((965152115899 : ℝ) / 1000000000000) ((241458923779 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((376016954171 : ℝ) / 200000000000) ((471324845411 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((132197243409 : ℝ) / 500000000000)) ((3831805069 : ℝ) / 250000000000) ((20338539931 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1479049358823 : ℝ) / 1000000000000)) ((2678016887 : ℝ) / 500000000000) ((9762290627 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((132197243409 : ℝ) / 500000000000)) (wl := ((1479049358823 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((376016954171 : ℝ) / 200000000000) ≤ D0q (q) * (((1479049358823 : ℝ) / 1000000000000) - ((132197243409 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((1479049358823 : ℝ) / 1000000000000) * ((132197243409 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_51 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((303064632076068135645657851074969 : ℝ) / 2596148429267413814265248164610048) ((612103650724987907323467269144575 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((116736249999 : ℝ) / 1000000000000) ((188619 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1116736249999 : ℝ) / 1000000000000) ((1788619 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((110410368659 : ℝ) / 1000000000000) ((55720092231 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_669.1 dlower_log_670.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((110410368659 : ℝ) / 500000000000) ((55720092231 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((94053362327 : ℝ) / 200000000000) ((236163221621 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2147838162397 : ℝ) / 1000000000000) ((-213802980079 : ℝ) / 100000000000) := rb_log hqr (by norm_num) dlower_log_671.1 dlower_log_672.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((213802980079 : ℝ) / 100000000000) ((2147838162397 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((54737226001 : ℝ) / 250000000000) ((220916679023 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779083320977 : ℝ) / 1000000000000) ((195262773999 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((13627352063 : ℝ) / 1000000000000) ((6948657649 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((3367622899 : ℝ) / 12500000000)) - (z9)
  have h10 : RB z10 ((127756258311 : ℝ) / 500000000000) ((255782479857 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((3367622899 : ℝ) / 12500000000) ((3367622899 : ℝ) / 12500000000) ((3367622899 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((9132377101 : ℝ) / 12500000000))
  have h11 : RB z11 ((8743360087 : ℝ) / 25000000000) ((175051958699 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((9132377101 : ℝ) / 12500000000) ((9132377101 : ℝ) / 12500000000) ((9132377101 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-105058125977 : ℝ) / 100000000000) ((-524762630857 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_673.1 dlower_log_674.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-820557644377 : ℝ) / 1000000000000) ((-163533525269 : ℝ) / 200000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((3367622899 : ℝ) / 12500000000))
  have h14 : RB z14 ((-1311521520053 : ℝ) / 1000000000000) ((-1311521520051 : ℝ) / 1000000000000) := rb_log (show RB ((3367622899 : ℝ) / 12500000000) ((3367622899 : ℝ) / 12500000000) ((3367622899 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_675.1 dlower_log_675.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((245481937837 : ℝ) / 500000000000) ((123463473427 : ℝ) / 250000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1164839527 : ℝ) / 62500000000) ((23587082073 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((13627352063 : ℝ) / 1000000000000) ((6948657649 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1480104528747 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1466207213449 : ℝ) / 1000000000000) ((366619294171 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((1480104528747 : ℝ) / 1000000000000) ((1480104528747 : ℝ) / 1000000000000) ((1480104528747 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((480104528747 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3053933311721 : ℝ) / 1000000000000) ((3054495612677 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((480104528747 : ℝ) / 1000000000000) ((480104528747 : ℝ) / 1000000000000) ((480104528747 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((223286074037 : ℝ) / 200000000000) ((27915361919 : ℝ) / 25000000000) := rb_log h19 (by norm_num) dlower_log_676.1 dlower_log_677.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((869792280443 : ℝ) / 1000000000000) ((872132960879 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1480104528747 : ℝ) / 1000000000000))
  have h22 : RB z22 ((98028178203 : ℝ) / 250000000000) ((196056356407 : ℝ) / 500000000000) := rb_log (show RB ((1480104528747 : ℝ) / 1000000000000) ((1480104528747 : ℝ) / 1000000000000) ((1480104528747 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_678.1 dlower_log_678.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((477679567629 : ℝ) / 1000000000000) ((480020248067 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5353124387 : ℝ) / 1000000000000) ((609589777 : ℝ) / 62500000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1116736249999 : ℝ) / 1000000000000) ((1788619 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1247099852061 : ℝ) / 1000000000000) ((624835532649 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((800210573621 : ℝ) / 500000000000) ((160372082211 : ℝ) / 100000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1210694696827 : ℝ) / 1000000000000))
  have h28 : RB z28 ((387524279131 : ℝ) / 200000000000) ((48540407363 : ℝ) / 25000000000) := rb_widen (rb_mul h27 (show RB ((1210694696827 : ℝ) / 1000000000000) ((1210694696827 : ℝ) / 1000000000000) ((1210694696827 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((13627352063 : ℝ) / 1000000000000) ((6948657649 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((4984433903922000977553 : ℝ) / 12500000000000000000000))
  have h30 : RB z30 ((34174773719 : ℝ) / 1000000000000) ((17425894753 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((4984433903922000977553 : ℝ) / 12500000000000000000000) ((4984433903922000977553 : ℝ) / 12500000000000000000000) ((4984433903922000977553 : ℝ) / 12500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((482574105247 : ℝ) / 500000000000) ((965825226281 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1870091822631 : ℝ) / 1000000000000) ((937630998503 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((3367622899 : ℝ) / 12500000000)) ((1164839527 : ℝ) / 62500000000) ((23587082073 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1480104528747 : ℝ) / 1000000000000)) ((5353124387 : ℝ) / 1000000000000) ((609589777 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((3367622899 : ℝ) / 12500000000)) (wl := ((1480104528747 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1870091822631 : ℝ) / 1000000000000) ≤ D0q (q) * (((1480104528747 : ℝ) / 1000000000000) - ((3367622899 : ℝ) / 12500000000)) * (1 - (q) ^ 2 / (((1480104528747 : ℝ) / 1000000000000) * ((3367622899 : ℝ) / 12500000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
