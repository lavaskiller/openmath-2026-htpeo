import LeanProject.Stage9D1

/-!
# EP-1038, Stage 9, Lemmas A′ and B′ (the Lean route of Theorem 9.4)

* **Lemma A′** (`lemmaA_tendsto`): for a monotone `Q : ℝ → [a₀, b₀]` with `[a₀, b₀] ⊆ [α, β]`, the
  quantile discretizations `V_N(y) = (1/N) Σ_j log|y - Q((j + 1/2)/N)|` converge to
  `V(y) = ∫_0^1 log|y - Q u| du` in `L¹(α, β)` (as a lintegral of `‖V_N - V‖ₑ`).
  The proof is Fubini–Tonelli on each cell `[j/N, (j+1)/N]`, the modulus `om` of `Stage9D1`, and
  oscillation counting (`lemmaA_bound`).
* **Lemma B′** (`lemmaB`): `L¹` convergence plus a null zero set gives the one-sided bound
  `|{v_N < 0} ∩ K| ≤ |{v < 0} ∩ K| + ε` eventually.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral
open scoped ENNReal

namespace EP1038.Stage9

/-- `V(y) = ∫_0^1 log|y - Q(u)| du`. -/
noncomputable def VQ (Q : ℝ → ℝ) (y : ℝ) : ℝ := ∫ u in (0 : ℝ)..1, Real.log (y - Q u)

/-- The quantile points `u_j = (j + 1/2)/N`. -/
noncomputable def usamp (N j : ℕ) : ℝ := (j + 1 / 2) / N

/-- `V_N(y) = (1/N) Σ_{j < N} log|y - Q(u_j)|`. -/
noncomputable def VN (Q : ℝ → ℝ) (N : ℕ) (y : ℝ) : ℝ :=
  (∑ j ∈ Finset.range N, Real.log (y - Q (usamp N j))) / N

/-- The cell endpoints `j/N`. -/
noncomputable def cpt (N j : ℕ) : ℝ := j / N

section lemmaA

variable {Q : ℝ → ℝ} {α β a0 b0 : ℝ}

theorem measurable_F (hQ : Monotone Q) :
    Measurable fun p : ℝ × ℝ => Real.log (p.1 - Q p.2) :=
  Real.measurable_log.comp (measurable_fst.sub (hQ.measurable.comp measurable_snd))

theorem lintegral_log_le (hαβ : α ≤ β) {t : ℝ} (ht : t ∈ Icc a0 b0) (hα : α ≤ a0) (hβ : b0 ≤ β) :
    ∫⁻ y in Ioc α β, ‖Real.log (y - t)‖ₑ ≤
      ENNReal.ofReal (∫ z in (α - b0)..(β - a0), |Real.log z|) := by
  have hint : IntegrableOn (fun y => |Real.log (y - t)|) (Ioc α β) :=
    ((intervalIntegrable_iff_integrableOn_Ioc_of_le hαβ).mp (ii_log_sub α β t)).abs
  have e1 : ∫⁻ y in Ioc α β, ‖Real.log (y - t)‖ₑ =
      ENNReal.ofReal (∫ y in Ioc α β, |Real.log (y - t)|) := by
    rw [ofReal_integral_eq_lintegral_ofReal hint (Eventually.of_forall fun _ => abs_nonneg _)]
    simp only [Real.enorm_eq_ofReal_abs]
  rw [e1]
  refine ENNReal.ofReal_le_ofReal ?_
  rw [← intervalIntegral.integral_of_le hαβ,
    intervalIntegral.integral_comp_sub_right (fun z => |Real.log z|) t]
  refine intervalIntegral.integral_mono_interval (by linarith [ht.2]) (by linarith)
    (by linarith [ht.1]) (Eventually.of_forall fun _ => abs_nonneg _) intervalIntegrable_log'.abs

/-- Almost every `y ∈ (α, β]` has `u ↦ log|y - Q u|` integrable on `(0, 1]`. -/
theorem ae_integrableOn (hQ : Monotone Q) (hQr : ∀ u, Q u ∈ Icc a0 b0) (hαβ : α ≤ β)
    (hα : α ≤ a0) (hβ : b0 ≤ β) :
    ∀ᵐ y ∂(volume.restrict (Ioc α β)), IntegrableOn (fun u => Real.log (y - Q u)) (Ioc 0 1) := by
  have hF := measurable_F hQ
  have hFe : Measurable fun p : ℝ × ℝ => ‖Real.log (p.1 - Q p.2)‖ₑ := hF.enorm
  set Cst := ∫ z in (α - b0)..(β - a0), |Real.log z|
  have hfin : ∫⁻ y in Ioc α β, ∫⁻ u in Ioc (0 : ℝ) 1, ‖Real.log (y - Q u)‖ₑ ≠ ∞ := by
    rw [lintegral_lintegral_swap hFe.aemeasurable]
    refine ne_top_of_le_ne_top (b := ∫⁻ _ in Ioc (0 : ℝ) 1, ENNReal.ofReal Cst) ?_ ?_
    · rw [setLIntegral_const, Real.volume_Ioc]
      exact ENNReal.mul_ne_top ENNReal.ofReal_ne_top ENNReal.ofReal_ne_top
    · exact lintegral_mono fun u => lintegral_log_le hαβ (hQr u) hα hβ
  have hmeas : Measurable fun y => ∫⁻ u in Ioc (0 : ℝ) 1, ‖Real.log (y - Q u)‖ₑ :=
    hFe.lintegral_prod_right'
  filter_upwards [ae_lt_top hmeas hfin] with y hy
  exact ⟨(hF.comp (measurable_const.prodMk measurable_id)).aestronglyMeasurable, hy⟩

theorem cpt_zero (N : ℕ) : cpt N 0 = 0 := by simp [cpt]

theorem cpt_N {N : ℕ} (hN : 0 < N) : cpt N N = 1 := by
  unfold cpt
  exact div_self (by exact_mod_cast hN.ne')

theorem cpt_succ (N j : ℕ) (hN : 0 < N) : cpt N (j + 1) - cpt N j = 1 / N := by
  unfold cpt
  push_cast
  ring

theorem cpt_mono {N : ℕ} (hN : 0 < N) {i j : ℕ} (h : i ≤ j) : cpt N i ≤ cpt N j := by
  unfold cpt
  exact div_le_div_of_nonneg_right (by exact_mod_cast h) (by positivity)

theorem usamp_mem {N : ℕ} (hN : 0 < N) (j : ℕ) : usamp N j ∈ Icc (cpt N j) (cpt N (j + 1)) := by
  unfold usamp cpt
  have : (0 : ℝ) < N := by exact_mod_cast hN
  push_cast
  constructor <;> exact div_le_div_of_nonneg_right (by linarith) this.le

theorem cell_sub {N : ℕ} (hN : 0 < N) {j : ℕ} (hj : j < N) :
    Ioc (cpt N j) (cpt N (j + 1)) ⊆ Ioc 0 1 := by
  intro u hu
  refine ⟨lt_of_le_of_lt ?_ hu.1, hu.2.trans ?_⟩
  · rw [← cpt_zero N]; exact cpt_mono hN (Nat.zero_le j)
  · rw [← cpt_N hN]; exact cpt_mono hN hj

/-- Pointwise cell decomposition: `‖V_N - V‖ₑ ≤ Σ_j ∫_{cell j} ‖log|y - Q u_j| - log|y - Q u|‖ₑ`. -/
theorem pointwise_bound {N : ℕ} (hN : 0 < N) {y : ℝ}
    (hy : IntegrableOn (fun u => Real.log (y - Q u)) (Ioc 0 1)) :
    ‖VN Q N y - VQ Q y‖ₑ ≤ ∑ j ∈ Finset.range N,
      ∫⁻ u in Ioc (cpt N j) (cpt N (j + 1)), ‖Real.log (y - Q (usamp N j)) - Real.log (y - Q u)‖ₑ := by
  have hcell : ∀ j < N, IntervalIntegrable (fun u => Real.log (y - Q u)) volume (cpt N j)
      (cpt N (j + 1)) := fun j hj =>
    (intervalIntegrable_iff_integrableOn_Ioc_of_le (cpt_mono hN (Nat.le_succ j))).mpr
      (hy.mono_set (cell_sub hN hj))
  have hVQ : VQ Q y = ∑ j ∈ Finset.range N, ∫ u in (cpt N j)..(cpt N (j + 1)), Real.log (y - Q u) := by
    unfold VQ
    rw [intervalIntegral.sum_integral_adjacent_intervals hcell, cpt_zero, cpt_N hN]
  have hVN : VN Q N y = ∑ j ∈ Finset.range N,
      ∫ _ in (cpt N j)..(cpt N (j + 1)), Real.log (y - Q (usamp N j)) := by
    unfold VN
    rw [Finset.sum_div]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [intervalIntegral.integral_const, cpt_succ N j hN, smul_eq_mul]
    ring
  rw [hVN, hVQ, ← Finset.sum_sub_distrib]
  refine (enorm_sum_le _ _).trans (Finset.sum_le_sum fun j hj => ?_)
  have hj := Finset.mem_range.mp hj
  rw [← intervalIntegral.integral_sub intervalIntegrable_const (hcell j hj),
    intervalIntegral.integral_of_le (cpt_mono hN (Nat.le_succ j))]
  exact enorm_integral_le_lintegral_enorm _

theorem lintegral_om {a b : ℝ} (hαβ : α ≤ β) :
    ∫⁻ y in Ioc α β, ‖Real.log (y - a) - Real.log (y - b)‖ₑ = ENNReal.ofReal (om α β a b) := by
  have hint : IntegrableOn (fun y => |Real.log (y - a) - Real.log (y - b)|) (Ioc α β) :=
    ((intervalIntegrable_iff_integrableOn_Ioc_of_le hαβ).mp
      ((ii_log_sub α β a).sub (ii_log_sub α β b))).abs
  unfold om
  rw [intervalIntegral.integral_of_le hαβ,
    ofReal_integral_eq_lintegral_ofReal hint (Eventually.of_forall fun _ => abs_nonneg _)]
  simp only [Real.enorm_eq_ofReal_abs]

/-- **Lemma A′, quantitative form.** -/
theorem lemmaA_bound (hQ : Monotone Q) (hQr : ∀ u, Q u ∈ Icc a0 b0) (hαβ : α ≤ β)
    (hα : α ≤ a0) (hβ : b0 ≤ β) {η δ M : ℝ} (hη : 0 ≤ η) (hδ : 0 < δ) (hM : 0 ≤ M)
    (hsmall : ∀ a b, a ∈ Icc a0 b0 → b ∈ Icc a0 b0 → |a - b| ≤ δ → om α β a b ≤ η)
    (hbdd : ∀ a b, a ∈ Icc a0 b0 → b ∈ Icc a0 b0 → om α β a b ≤ M) {N : ℕ} (hN : 0 < N) :
    ∫⁻ y in Ioc α β, ‖VN Q N y - VQ Q y‖ₑ ≤ ENNReal.ofReal (η + M * (b0 - a0) / (δ * N)) := by
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hF := measurable_F hQ
  -- oscillations and the bound `b j`
  set osc : ℕ → ℝ := fun j => Q (cpt N (j + 1)) - Q (cpt N j) with hosc
  set bj : ℕ → ℝ := fun j => if osc j ≤ δ then η else M with hbj
  have hbj0 : ∀ j, 0 ≤ bj j := fun j => by simp only [hbj]; split_ifs <;> assumption
  -- step 1: integrate the pointwise bound and swap
  have step1 : ∫⁻ y in Ioc α β, ‖VN Q N y - VQ Q y‖ₑ ≤ ∑ j ∈ Finset.range N,
      ∫⁻ u in Ioc (cpt N j) (cpt N (j + 1)), ENNReal.ofReal (om α β (Q (usamp N j)) (Q u)) := by
    calc ∫⁻ y in Ioc α β, ‖VN Q N y - VQ Q y‖ₑ
        ≤ ∫⁻ y in Ioc α β, ∑ j ∈ Finset.range N, ∫⁻ u in Ioc (cpt N j) (cpt N (j + 1)),
            ‖Real.log (y - Q (usamp N j)) - Real.log (y - Q u)‖ₑ := by
          refine lintegral_mono_ae ?_
          filter_upwards [ae_integrableOn hQ hQr hαβ hα hβ] with y hy
          exact pointwise_bound hN hy
      _ = ∑ j ∈ Finset.range N, ∫⁻ y in Ioc α β, ∫⁻ u in Ioc (cpt N j) (cpt N (j + 1)),
            ‖Real.log (y - Q (usamp N j)) - Real.log (y - Q u)‖ₑ := by
          refine lintegral_finset_sum _ fun j _ => ?_
          have hm : Measurable fun p : ℝ × ℝ =>
              ‖Real.log (p.1 - Q (usamp N j)) - Real.log (p.1 - Q p.2)‖ₑ :=
            ((Real.measurable_log.comp (measurable_fst.sub measurable_const)).sub hF).enorm
          exact hm.lintegral_prod_right'
      _ = ∑ j ∈ Finset.range N, ∫⁻ u in Ioc (cpt N j) (cpt N (j + 1)),
            ENNReal.ofReal (om α β (Q (usamp N j)) (Q u)) := by
          refine Finset.sum_congr rfl fun j _ => ?_
          have hm : Measurable fun p : ℝ × ℝ =>
              ‖Real.log (p.1 - Q (usamp N j)) - Real.log (p.1 - Q p.2)‖ₑ :=
            ((Real.measurable_log.comp (measurable_fst.sub measurable_const)).sub hF).enorm
          rw [lintegral_lintegral_swap hm.aemeasurable]
          refine lintegral_congr fun u => ?_
          exact lintegral_om hαβ
  -- step 2: each cell contributes at most `b j / N`
  have step2 : ∀ j ∈ Finset.range N, ∫⁻ u in Ioc (cpt N j) (cpt N (j + 1)),
      ENNReal.ofReal (om α β (Q (usamp N j)) (Q u)) ≤ ENNReal.ofReal (bj j / N) := by
    intro j _
    have hle : ∀ u ∈ Ioc (cpt N j) (cpt N (j + 1)),
        ENNReal.ofReal (om α β (Q (usamp N j)) (Q u)) ≤ ENNReal.ofReal (bj j) := by
      intro u hu
      refine ENNReal.ofReal_le_ofReal ?_
      have hs := usamp_mem hN j
      have h1 := hQ hs.1; have h2 := hQ hs.2
      have h3 := hQ hu.1.le; have h4 := hQ hu.2
      simp only [hbj]
      split_ifs with hc
      · refine hsmall _ _ (hQr _) (hQr _) ?_
        rw [abs_le]; constructor <;> linarith
      · exact hbdd _ _ (hQr _) (hQr _)
    calc ∫⁻ u in Ioc (cpt N j) (cpt N (j + 1)), ENNReal.ofReal (om α β (Q (usamp N j)) (Q u))
        ≤ ∫⁻ _ in Ioc (cpt N j) (cpt N (j + 1)), ENNReal.ofReal (bj j) :=
          setLIntegral_mono measurable_const hle
      _ = ENNReal.ofReal (bj j / N) := by
          rw [setLIntegral_const, Real.volume_Ioc, cpt_succ N j hN,
            ← ENNReal.ofReal_mul (hbj0 j)]
          congr 1
          ring
  -- step 3: oscillation counting
  have hosc0 : ∀ j, 0 ≤ osc j := fun j => sub_nonneg.mpr (hQ (cpt_mono hN (Nat.le_succ j)))
  have htel : ∑ j ∈ Finset.range N, osc j ≤ b0 - a0 := by
    rw [Finset.sum_range_sub (fun j => Q (cpt N j)), cpt_N hN, cpt_zero]
    linarith [(hQr 1).2, (hQr 0).1]
  set bad := (Finset.range N).filter fun j => ¬ osc j ≤ δ with hbad
  have hcard : (bad.card : ℝ) * δ ≤ b0 - a0 := by
    calc (bad.card : ℝ) * δ = ∑ _j ∈ bad, δ := by rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ ∑ j ∈ bad, osc j := Finset.sum_le_sum fun j hj => by
          have := (Finset.mem_filter.mp hj).2; push Not at this; exact this.le
      _ ≤ ∑ j ∈ Finset.range N, osc j :=
          Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
            fun j _ _ => hosc0 j
      _ ≤ b0 - a0 := htel
  have hsum : ∑ j ∈ Finset.range N, bj j ≤ N * η + bad.card * M := by
    have : ∑ j ∈ Finset.range N, bj j = ∑ j ∈ Finset.range N, (if osc j ≤ δ then η else 0)
        + ∑ j ∈ bad, M := by
      rw [hbad, Finset.sum_filter, ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun j _ => ?_
      simp only [hbj]
      split_ifs <;> simp
    rw [this]
    have h1 : ∑ j ∈ Finset.range N, (if osc j ≤ δ then η else 0) ≤ ∑ _j ∈ Finset.range N, η :=
      Finset.sum_le_sum fun j _ => by split_ifs <;> linarith
    rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at h1
    rw [Finset.sum_const, nsmul_eq_mul]
    linarith
  calc ∫⁻ y in Ioc α β, ‖VN Q N y - VQ Q y‖ₑ
      ≤ ∑ j ∈ Finset.range N, ENNReal.ofReal (bj j / N) := step1.trans (Finset.sum_le_sum step2)
    _ = ENNReal.ofReal (∑ j ∈ Finset.range N, bj j / N) :=
        (ENNReal.ofReal_sum_of_nonneg fun j _ => div_nonneg (hbj0 j) hNr.le).symm
    _ ≤ ENNReal.ofReal (η + M * (b0 - a0) / (δ * N)) := by
        refine ENNReal.ofReal_le_ofReal ?_
        rw [← Finset.sum_div, div_le_iff₀ hNr]
        have hc : (bad.card : ℝ) * M ≤ M * (b0 - a0) / δ := by
          rw [le_div_iff₀ hδ]
          nlinarith
        have : (η + M * (b0 - a0) / (δ * N)) * N = N * η + M * (b0 - a0) / δ := by
          field_simp
        rw [this]
        linarith

/-- **Lemma A′**: `∫_α^β |V_N - V| → 0`. -/
theorem lemmaA_tendsto (hQ : Monotone Q) (hQr : ∀ u, Q u ∈ Icc a0 b0) (hαβ : α ≤ β)
    (hα : α ≤ a0) (hβ : b0 ≤ β) :
    Tendsto (fun N => ∫⁻ y in Ioc α β, ‖VN Q N y - VQ Q y‖ₑ) atTop (𝓝 0) := by
  rw [ENNReal.tendsto_nhds_zero]
  intro ε hε
  obtain ⟨e, he, hle⟩ : ∃ e : ℝ, 0 < e ∧ ENNReal.ofReal e ≤ ε := by
    by_cases htop : ε = ∞
    · exact ⟨1, one_pos, htop ▸ le_top⟩
    · exact ⟨ε.toReal, ENNReal.toReal_pos hε.ne' htop, ENNReal.ofReal_toReal_le⟩
  obtain ⟨δ, hδ, hsmall⟩ := om_small hα hβ (half_pos he)
  obtain ⟨M0, hbdd⟩ := om_bdd hα hβ (a0 := a0) (b0 := b0)
  set M := max M0 0
  have hbdd' : ∀ a b, a ∈ Icc a0 b0 → b ∈ Icc a0 b0 → om α β a b ≤ M :=
    fun a b ha hb => (hbdd a b ha hb).trans (le_max_left _ _)
  have hab : 0 ≤ b0 - a0 := by linarith [(hQr 0).1, (hQr 0).2]
  obtain ⟨N0, hN0⟩ := exists_nat_gt (2 * M * (b0 - a0) / (δ * e))
  filter_upwards [eventually_ge_atTop (N0 + 1)] with N hN
  have hNpos : 0 < N := by omega
  have hNr : (0 : ℝ) < N := by exact_mod_cast hNpos
  refine (lemmaA_bound hQ hQr hαβ hα hβ (half_pos he).le hδ (le_max_right _ _) hsmall hbdd'
    hNpos).trans (le_trans (ENNReal.ofReal_le_ofReal ?_) hle)
  have hN0' : (N0 : ℝ) + 1 ≤ N := by exact_mod_cast hN
  have h2 : M * (b0 - a0) / (δ * N) ≤ e / 2 := by
    rw [div_le_iff₀ (by positivity)]
    have h3 : 2 * M * (b0 - a0) / (δ * e) < N := by linarith
    rw [div_lt_iff₀ (by positivity)] at h3
    nlinarith [mul_nonneg (le_max_right M0 0) hab]
  linarith

end lemmaA

/-- **Lemma B′** (one-sided sign-set bound). -/
theorem lemmaB {v : ℝ → ℝ} {vN : ℕ → ℝ → ℝ} {K : Set ℝ} (hK : MeasurableSet K)
    (hKf : volume K ≠ ∞) (hv : Measurable v) (hvN : ∀ N, Measurable (vN N))
    (hconv : Tendsto (fun N => ∫⁻ y in K, ‖vN N y - v y‖ₑ) atTop (𝓝 0))
    (hz : volume ({y | v y = 0} ∩ K) = 0) {ε : ℝ≥0∞} (hε : 0 < ε) :
    ∀ᶠ N in atTop, volume ({y | vN N y < 0} ∩ K) ≤ volume ({y | v y < 0} ∩ K) + ε := by
  set T : ℝ → Set ℝ := fun δ => {y | 0 ≤ v y ∧ v y < δ} ∩ K with hT
  have hTm : ∀ δ, MeasurableSet (T δ) := fun δ =>
    ((measurableSet_le measurable_const hv).inter (measurableSet_lt hv measurable_const)).inter hK
  have hinter : (⋂ δ > (0 : ℝ), T δ) = {y | v y = 0} ∩ K := by
    ext y
    simp only [hT, mem_iInter, mem_inter_iff, mem_setOf_eq]
    constructor
    · intro h
      obtain ⟨h0, -⟩ := (h 1 one_pos).1
      have hK' := (h 1 one_pos).2
      refine ⟨le_antisymm ?_ h0, hK'⟩
      by_contra hc
      push Not at hc
      exact absurd (h (v y) hc).1.2 (lt_irrefl _)
    · rintro ⟨h0, hK'⟩ δ hδ
      exact ⟨⟨h0.symm.le, by rw [h0]; exact hδ⟩, hK'⟩
  have htend : Tendsto (fun δ => volume (T δ)) (𝓝[>] 0) (𝓝 0) := by
    have := tendsto_measure_biInter_gt (μ := volume) (s := T) (a := (0 : ℝ))
      (fun r _ => (hTm r).nullMeasurableSet)
      (fun i j _ hij y hy => ⟨⟨hy.1.1, lt_of_lt_of_le hy.1.2 hij⟩, hy.2⟩)
      ⟨1, one_pos, ne_top_of_le_ne_top hKf (measure_mono inter_subset_right)⟩
    rwa [hinter, hz] at this
  have hε2 : 0 < ε / 2 := ENNReal.half_pos hε.ne'
  obtain ⟨δ, hδT, hδpos⟩ := ((htend.eventually (gt_mem_nhds hε2)).and
    self_mem_nhdsWithin).exists
  have hδ0 : (0 : ℝ) < δ := mem_Ioi.mp hδpos
  have hδne : ENNReal.ofReal δ ≠ 0 := by simpa using hδ0
  have hconv' := (ENNReal.tendsto_nhds_zero.mp hconv) (ENNReal.ofReal δ * (ε / 2))
    (ENNReal.mul_pos hδne hε2.ne')
  filter_upwards [hconv'] with N hN
  set D := {y | ENNReal.ofReal δ ≤ ‖vN N y - v y‖ₑ} ∩ K
  have hDm : MeasurableSet {y | ENNReal.ofReal δ ≤ ‖vN N y - v y‖ₑ} :=
    measurableSet_le measurable_const ((hvN N).sub hv).enorm
  have hD : volume D ≤ ε / 2 := by
    have hmk : volume.restrict K {y | ENNReal.ofReal δ ≤ ‖vN N y - v y‖ₑ} ≤
        (∫⁻ y in K, ‖vN N y - v y‖ₑ) / ENNReal.ofReal δ :=
      meas_ge_le_lintegral_div (((hvN N).sub hv).enorm.aemeasurable) hδne ENNReal.ofReal_ne_top
    rw [Measure.restrict_apply hDm] at hmk
    refine hmk.trans ?_
    rw [ENNReal.div_le_iff hδne ENNReal.ofReal_ne_top, mul_comm]
    exact hN
  have hsub : {y | vN N y < 0} ∩ K ⊆ ({y | v y < 0} ∩ K) ∪ T δ ∪ D := by
    rintro y ⟨hy, hyK⟩
    simp only [mem_setOf_eq] at hy
    by_cases h1 : v y < 0
    · exact Or.inl (Or.inl ⟨h1, hyK⟩)
    by_cases h2 : v y < δ
    · exact Or.inl (Or.inr ⟨⟨not_lt.mp h1, h2⟩, hyK⟩)
    · refine Or.inr ⟨?_, hyK⟩
      simp only [mem_setOf_eq, Real.enorm_eq_ofReal_abs]
      refine ENNReal.ofReal_le_ofReal ?_
      rw [abs_sub_comm, abs_of_nonneg (by linarith)]
      linarith [not_lt.mp h2]
  calc volume ({y | vN N y < 0} ∩ K) ≤ volume (({y | v y < 0} ∩ K) ∪ T δ ∪ D) := measure_mono hsub
    _ ≤ volume ({y | v y < 0} ∩ K) + volume (T δ) + volume D :=
        (measure_union_le _ _).trans (by gcongr; exact measure_union_le _ _)
    _ ≤ volume ({y | v y < 0} ∩ K) + ε / 2 + ε / 2 := by
        gcongr
    _ = volume ({y | v y < 0} ∩ K) + ε := by rw [add_assoc, ENNReal.add_halves]

end EP1038.Stage9
