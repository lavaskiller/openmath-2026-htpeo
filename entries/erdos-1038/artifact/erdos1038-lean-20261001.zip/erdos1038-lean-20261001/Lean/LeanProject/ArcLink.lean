import LeanProject.ArcEnergyB

/-!
# EP-1038, Stage 12, Theorem 12.8 step 3 in arc-energy form

Links the log-kernel rearrangement inequality (`Circ.circle_rearrangement_log`) with the arc energy
`AE = 𝒜` of Lemma 12.7.

* `int_Kl_one`: `∫_a^b K(c - t) dt = (b - a) log 2 - ∫_a^b 𝓛(c - t) dt` (`K = log|1 - e^{i·}|`,
  `𝓛 = -log|sin(·/2)|`; `K = log 2 - 𝓛` off the null set `c - t ∈ 2πℤ`).
* `double_Kl_symm`: the double integral of `K(θ - φ)` over `[-Q, Q] × [-R, R]` does not depend on
  the order of the radii (both equal the symmetric sine series of Lemma 12.7(a)).
* `VK_Lsin_AE`: `V_𝓛(Q, R) = 4QR (log 2 - 𝒜(Q, R))` for `Q, R > 0`.
* `circle_block_log` (**Theorem 12.8, step 3**): `I_𝓛(f, g) ≤ 4QR (log 2 - 𝒜(Q, R))`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

theorem Lsin_neg (u : ℝ) : Circ.Lsin (-u) = Circ.Lsin u := by
  unfold Circ.Lsin
  rw [neg_div, Real.sin_neg, abs_neg]

theorem Lsin_ii' (a b : ℝ) : IntervalIntegrable Circ.Lsin volume a b := by
  have h := Circ.Lsin_ii 0 a b
  have e : (fun u => Circ.Lsin (0 - u)) = Circ.Lsin := by
    funext u
    rw [zero_sub, Lsin_neg]
  rwa [e] at h

/-- `∫_a^b K(c - t) dt = (b - a) log 2 - ∫_a^b 𝓛(c - t) dt`. -/
theorem int_Kl_one (c a b : ℝ) :
    ∫ t in a..b, Kl 1 (c - t) = (b - a) * Real.log 2 - ∫ t in a..b, Circ.Lsin (c - t) := by
  have h : ∫ t in a..b, Kl 1 (c - t) = ∫ t in a..b, (Real.log 2 - Circ.Lsin (c - t)) := by
    refine intervalIntegral.integral_congr_ae ?_
    filter_upwards [Circ.ae_sin_ne c] with t ht _
    exact Kl_one_eq ht
  rw [h, intervalIntegral.integral_sub intervalIntegrable_const (Circ.Lsin_ii c a b),
    intervalIntegral.integral_const, smul_eq_mul]

theorem win_Lsin_cont (Q : ℝ) : Continuous (Circ.win Circ.Lsin Q) := by
  show Continuous (fun θ => ∫ t in (-Q)..Q, Circ.Lsin (θ - t))
  exact cont_window Lsin_ii' Q

theorem VK_Lsin (Q R : ℝ) :
    Circ.VK Circ.Lsin Q R = 4 * Q * R * Real.log 2 -
      ∫ φ in (-R)..R, ∫ t in (-Q)..Q, Kl 1 (φ - t) := by
  have e : ∀ φ, ∫ t in (-Q)..Q, Kl 1 (φ - t) = 2 * Q * Real.log 2 - Circ.win Circ.Lsin Q φ := by
    intro φ
    rw [int_Kl_one, Circ.win_def]
    ring
  simp_rw [e]
  unfold Circ.VK
  rw [intervalIntegral.integral_sub intervalIntegrable_const
    ((win_Lsin_cont Q).intervalIntegrable _ _), intervalIntegral.integral_const, smul_eq_mul]
  ring

/-- The double integral of `K(θ - φ)` is symmetric in the two radii. -/
theorem double_Kl_symm {Q R : ℝ} (hQ : 0 ≤ Q) (hR : 0 ≤ R) :
    ∫ φ in (-R)..R, ∫ t in (-Q)..Q, Kl 1 (φ - t) =
      ∫ θ in (-Q)..Q, ∫ φ in (-R)..R, Kl 1 (θ - φ) := by
  rw [arc_series (Q := R) hQ, arc_series (Q := Q) hR]
  congr 1
  refine tsum_congr (fun n => ?_)
  ring

/-- `V_𝓛(Q, R) = 4QR (log 2 - 𝒜(Q, R))`. -/
theorem VK_Lsin_AE {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R) :
    Circ.VK Circ.Lsin Q R = 4 * Q * R * (Real.log 2 - AE Q R) := by
  have h4 : 4 * Q * R ≠ 0 := mul_ne_zero (mul_ne_zero four_ne_zero hQ.ne') hR.ne'
  have key : 4 * Q * R * AE Q R = ∫ θ in (-Q)..Q, ∫ φ in (-R)..R, Kl 1 (θ - φ) := by
    unfold AE
    rw [← mul_assoc, mul_one_div_cancel h4, one_mul]
  rw [VK_Lsin, double_Kl_symm hQ.le hR.le, mul_sub, key]

/-- **Theorem 12.8, step 3** (arc-energy form): for measurable `2π`-periodic `f, g` with values in
`[0, 1]` and masses `2Q, 2R > 0`, `I_𝓛(f, g) ≤ 4QR (log 2 - 𝒜(Q, R))`. -/
theorem circle_block_log {f g : ℝ → ℝ} (hfm : Measurable f) (hgm : Measurable g)
    (hfp : Function.Periodic f (2 * π)) (hgp : Function.Periodic g (2 * π))
    (hf0 : ∀ x, 0 ≤ f x) (hf1 : ∀ x, f x ≤ 1) (hg0 : ∀ x, 0 ≤ g x) (hg1 : ∀ x, g x ≤ 1)
    {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R)
    (hfmass : ∫ θ in (-π)..π, f θ = 2 * Q) (hgmass : ∫ θ in (-π)..π, g θ = 2 * R) :
    Circ.IK Circ.Lsin f g ≤ 4 * Q * R * (Real.log 2 - AE Q R) := by
  rw [← VK_Lsin_AE hQ hR]
  exact Circ.circle_rearrangement_log hfm hgm hfp hgp hf0 hf1 hg0 hg1 hfmass hgmass

end EP1038.Arc
