import LeanProject.DLowerMTools
import LeanProject.DLowerMLog11
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_560 : RB (Real.log ((90018125251055523 : ℝ) / 200000000000000000)) ((-99788290601994833 : ℝ) / 125000000000000000) ((-399153162407979331 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((90018125251055523 : ℝ) / 100000000000000000)) (t := ((-9981874748944477 : ℝ) / 190018125251055523))
    (lo := ((-52579572128006677 : ℝ) / 500000000000000000)) (hi := ((-105159144256013353 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((90018125251055523 : ℝ) / 200000000000000000) = Real.log ((90018125251055523 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((90018125251055523 : ℝ) / 200000000000000000) = ((90018125251055523 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_561 : RB (Real.log ((455835788566401301 : ℝ) / 1000000000000000000)) ((-392811323558456619 : ℝ) / 500000000000000000) ((-196405661779228309 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((455835788566401301 : ℝ) / 500000000000000000)) (t := ((-44164211433598699 : ℝ) / 955835788566401301))
    (lo := ((-11559433319620991 : ℝ) / 125000000000000000)) (hi := ((-92475466556967927 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((455835788566401301 : ℝ) / 1000000000000000000) = Real.log ((455835788566401301 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((455835788566401301 : ℝ) / 1000000000000000000) = ((455835788566401301 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_562 : RB (Real.log ((227917894283200651 : ℝ) / 500000000000000000)) ((-196405661779228309 : ℝ) / 250000000000000000) ((-392811323558456617 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((227917894283200651 : ℝ) / 250000000000000000)) (t := ((-22082105716799349 : ℝ) / 477917894283200651))
    (lo := ((-46237733278483963 : ℝ) / 500000000000000000)) (hi := ((-3699018662278717 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((227917894283200651 : ℝ) / 500000000000000000) = Real.log ((227917894283200651 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((227917894283200651 : ℝ) / 500000000000000000) = ((227917894283200651 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_563 : RB (Real.log ((455762351066401301 : ℝ) / 1000000000000000000)) ((-392891882630449071 : ℝ) / 500000000000000000) ((-39289188263044907 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((455762351066401301 : ℝ) / 500000000000000000)) (t := ((-44237648933598699 : ℝ) / 955762351066401301))
    (lo := ((-361861658988097 : ℝ) / 3906250000000000)) (hi := ((-92636584700952831 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((455762351066401301 : ℝ) / 1000000000000000000) = Real.log ((455762351066401301 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((455762351066401301 : ℝ) / 1000000000000000000) = ((455762351066401301 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_564 : RB (Real.log ((1424278146902568219 : ℝ) / 1000000000000000000)) ((353665121796794229 : ℝ) / 1000000000000000000) ((353665121796794231 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424278146902568219 : ℝ) / 2000000000000000000)) (t := ((-575721853097431781 : ℝ) / 3424278146902568219))
    (lo := ((-8487051469078777 : ℝ) / 25000000000000000)) (hi := ((-339482058763151079 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424278146902568219 : ℝ) / 1000000000000000000) = Real.log ((1424278146902568219 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424278146902568219 : ℝ) / 1000000000000000000) = ((1424278146902568219 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_565 : RB (Real.log ((1425791745099080171 : ℝ) / 1000000000000000000)) ((354727270022041571 : ℝ) / 1000000000000000000) ((354727270022041573 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425791745099080171 : ℝ) / 2000000000000000000)) (t := ((-574208254900919829 : ℝ) / 3425791745099080171))
    (lo := ((-169209955268951869 : ℝ) / 500000000000000000)) (hi := ((-338419910537903737 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425791745099080171 : ℝ) / 1000000000000000000) = Real.log ((1425791745099080171 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425791745099080171 : ℝ) / 1000000000000000000) = ((1425791745099080171 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_566 : RB (Real.log ((425178146902568219 : ℝ) / 1000000000000000000)) ((-855247028702066533 : ℝ) / 1000000000000000000) ((-855247028702066531 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((425178146902568219 : ℝ) / 500000000000000000)) (t := ((-74821853097431781 : ℝ) / 925178146902568219))
    (lo := ((-162099848142121223 : ℝ) / 1000000000000000000)) (hi := ((-81049924071060611 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425178146902568219 : ℝ) / 1000000000000000000) = Real.log ((425178146902568219 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425178146902568219 : ℝ) / 1000000000000000000) = ((425178146902568219 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_567 : RB (Real.log ((42654799509908017 : ℝ) / 100000000000000000)) ((-852030385910241017 : ℝ) / 1000000000000000000) ((-170406077182048203 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((42654799509908017 : ℝ) / 50000000000000000)) (t := ((-7345200490091983 : ℝ) / 92654799509908017))
    (lo := ((-158883205350295707 : ℝ) / 1000000000000000000)) (hi := ((-79441602675147853 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42654799509908017 : ℝ) / 100000000000000000) = Real.log ((42654799509908017 : ℝ) / 50000000000000000) - 1 * Real.log 2 := by
    rw [show ((42654799509908017 : ℝ) / 100000000000000000) = ((42654799509908017 : ℝ) / 50000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_568 : RB (Real.log ((1425178146902568219 : ℝ) / 1000000000000000000)) ((44287102659633373 : ℝ) / 125000000000000000) ((177148410638533493 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425178146902568219 : ℝ) / 2000000000000000000)) (t := ((-574821853097431781 : ℝ) / 3425178146902568219))
    (lo := ((-13554014371315133 : ℝ) / 40000000000000000)) (hi := ((-84712589820719581 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425178146902568219 : ℝ) / 1000000000000000000) = Real.log ((1425178146902568219 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425178146902568219 : ℝ) / 1000000000000000000) = ((1425178146902568219 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_569 : RB (Real.log ((142654799509908017 : ℝ) / 100000000000000000)) ((177628768230273207 : ℝ) / 500000000000000000) ((22203596028784151 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((142654799509908017 : ℝ) / 200000000000000000)) (t := ((-57345200490091983 : ℝ) / 342654799509908017))
    (lo := ((-67577928819879779 : ℝ) / 200000000000000000)) (hi := ((-168944822049699447 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142654799509908017 : ℝ) / 100000000000000000) = Real.log ((142654799509908017 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142654799509908017 : ℝ) / 100000000000000000) = ((142654799509908017 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_570 : RB (Real.log ((1424351584402568219 : ℝ) / 1000000000000000000)) ((35371668167430953 : ℝ) / 100000000000000000) ((88429170418577383 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424351584402568219 : ℝ) / 2000000000000000000)) (t := ((-575648415597431781 : ℝ) / 3424351584402568219))
    (lo := ((-339430498885635779 : ℝ) / 1000000000000000000)) (hi := ((-169715249442817889 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424351584402568219 : ℝ) / 1000000000000000000) = Real.log ((1424351584402568219 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424351584402568219 : ℝ) / 1000000000000000000) = ((1424351584402568219 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_571 : RB (Real.log ((71217579220128411 : ℝ) / 50000000000000000)) ((353716681674309531 : ℝ) / 1000000000000000000) ((353716681674309533 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((71217579220128411 : ℝ) / 100000000000000000)) (t := ((-28782420779871589 : ℝ) / 171217579220128411))
    (lo := ((-169715249442817889 : ℝ) / 500000000000000000)) (hi := ((-339430498885635777 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71217579220128411 : ℝ) / 50000000000000000) = Real.log ((71217579220128411 : ℝ) / 100000000000000000) + 1 * Real.log 2 := by
    rw [show ((71217579220128411 : ℝ) / 50000000000000000) = ((71217579220128411 : ℝ) / 100000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_572 : RB (Real.log ((71221094845128411 : ℝ) / 50000000000000000)) ((353766045023467123 : ℝ) / 1000000000000000000) ((2830128360187737 : ℝ) / 8000000000000000) := by
  have hm := log_bounds_of_series (x := ((71221094845128411 : ℝ) / 100000000000000000)) (t := ((-28778905154871589 : ℝ) / 171221094845128411))
    (lo := ((-169690567768239093 : ℝ) / 500000000000000000)) (hi := ((-67876227107295637 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71221094845128411 : ℝ) / 50000000000000000) = Real.log ((71221094845128411 : ℝ) / 100000000000000000) + 1 * Real.log 2 := by
    rw [show ((71221094845128411 : ℝ) / 50000000000000000) = ((71221094845128411 : ℝ) / 100000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_573 : RB (Real.log ((142572143259908017 : ℝ) / 100000000000000000)) ((177338977050270623 : ℝ) / 500000000000000000) ((5541843032820957 : ℝ) / 15625000000000000) := by
  have hm := log_bounds_of_series (x := ((142572143259908017 : ℝ) / 200000000000000000)) (t := ((-57427856740091983 : ℝ) / 342572143259908017))
    (lo := ((-338469226459404063 : ℝ) / 1000000000000000000)) (hi := ((-169234613229702031 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142572143259908017 : ℝ) / 100000000000000000) = Real.log ((142572143259908017 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142572143259908017 : ℝ) / 100000000000000000) = ((142572143259908017 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_574 : RB (Real.log ((1425721432599080171 : ℝ) / 1000000000000000000)) ((354677954100541247 : ℝ) / 1000000000000000000) ((354677954100541249 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425721432599080171 : ℝ) / 2000000000000000000)) (t := ((-574278567400919829 : ℝ) / 3425721432599080171))
    (lo := ((-169234613229702031 : ℝ) / 500000000000000000)) (hi := ((-338469226459404061 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425721432599080171 : ℝ) / 1000000000000000000) = Real.log ((1425721432599080171 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425721432599080171 : ℝ) / 1000000000000000000) = ((1425721432599080171 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_575 : RB (Real.log ((142564799509908017 : ℝ) / 100000000000000000)) ((354626443763576231 : ℝ) / 1000000000000000000) ((354626443763576233 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((142564799509908017 : ℝ) / 200000000000000000)) (t := ((-57435200490091983 : ℝ) / 342564799509908017))
    (lo := ((-169260368398184539 : ℝ) / 500000000000000000)) (hi := ((-338520736796369077 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142564799509908017 : ℝ) / 100000000000000000) = Real.log ((142564799509908017 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142564799509908017 : ℝ) / 100000000000000000) = ((142564799509908017 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_576 : RB (Real.log ((32499999999999999 : ℝ) / 1000000000000000000)) ((-3426515189646445283 : ℝ) / 1000000000000000000) ((-3426515189646445281 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((32499999999999999 : ℝ) / 31250000000000000)) (t := ((1249999999999999 : ℝ) / 63749999999999999))
    (lo := ((7844142630656253 : ℝ) / 200000000000000000)) (hi := ((19610356576640633 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32499999999999999 : ℝ) / 1000000000000000000) = Real.log ((32499999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((32499999999999999 : ℝ) / 1000000000000000000) = ((32499999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_577 : RB (Real.log ((13 : ℝ) / 400)) ((-856628797411611313 : ℝ) / 250000000000000000) ((-13706060758585781 : ℝ) / 4000000000000000) := by
  have hm := log_bounds_of_series (x := ((26 : ℝ) / 25)) (t := ((1 : ℝ) / 51))
    (lo := ((2451294572080081 : ℝ) / 62500000000000000)) (hi := ((39220713153281297 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13 : ℝ) / 400) = Real.log ((26 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((13 : ℝ) / 400) = ((26 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_578 : RB (Real.log ((1032499999999999999 : ℝ) / 1000000000000000000)) ((31983045853050767 : ℝ) / 1000000000000000000) ((1998940365815673 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((1032499999999999999 : ℝ) / 1000000000000000000)) (t := ((32499999999999999 : ℝ) / 2032499999999999999))
    (lo := ((31983045853050767 : ℝ) / 1000000000000000000)) (hi := ((1998940365815673 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_579 : RB (Real.log ((413 : ℝ) / 400)) ((1998940365815673 : ℝ) / 62500000000000000) ((31983045853050769 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((413 : ℝ) / 400)) (t := ((13 : ℝ) / 813))
    (lo := ((1998940365815673 : ℝ) / 62500000000000000)) (hi := ((31983045853050769 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_580 : RB (Real.log ((29999999999999999 : ℝ) / 1000000000000000000)) ((-3506557897319981711 : ℝ) / 1000000000000000000) ((-3506557897319981709 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((29999999999999999 : ℝ) / 31250000000000000)) (t := ((-1250000000000001 : ℝ) / 61249999999999999))
    (lo := ((-40821994520255163 : ℝ) / 1000000000000000000)) (hi := ((-20410997260127581 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((29999999999999999 : ℝ) / 1000000000000000000) = Real.log ((29999999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((29999999999999999 : ℝ) / 1000000000000000000) = ((29999999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_581 : RB (Real.log ((7 : ℝ) / 200)) ((-1676203608746361687 : ℝ) / 500000000000000000) ((-838101804373180843 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((28 : ℝ) / 25)) (t := ((3 : ℝ) / 53))
    (lo := ((56664342653501587 : ℝ) / 500000000000000000)) (hi := ((4533147412280127 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7 : ℝ) / 200) = Real.log ((28 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((7 : ℝ) / 200) = ((28 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_582 : RB (Real.log ((1029999999999999999 : ℝ) / 1000000000000000000)) ((29558802241544401 : ℝ) / 1000000000000000000) ((14779401120772201 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1029999999999999999 : ℝ) / 1000000000000000000)) (t := ((29999999999999999 : ℝ) / 2029999999999999999))
    (lo := ((29558802241544401 : ℝ) / 1000000000000000000)) (hi := ((14779401120772201 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_583 : RB (Real.log ((207 : ℝ) / 200)) ((8600356679333099 : ℝ) / 250000000000000000) ((34401426717332397 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((207 : ℝ) / 200)) (t := ((7 : ℝ) / 407))
    (lo := ((8600356679333099 : ℝ) / 250000000000000000)) (hi := ((34401426717332397 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_584 : RB (Real.log ((111401922087979 : ℝ) / 250000000000000)) ((-202079084146580321 : ℝ) / 250000000000000000) ((-404158168293160641 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((111401922087979 : ℝ) / 125000000000000)) (t := ((-13598077912021 : ℝ) / 236401922087979))
    (lo := ((-57584578013187987 : ℝ) / 500000000000000000)) (hi := ((-115169156026375973 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111401922087979 : ℝ) / 250000000000000) = Real.log ((111401922087979 : ℝ) / 125000000000000) - 1 * Real.log 2 := by
    rw [show ((111401922087979 : ℝ) / 250000000000000) = ((111401922087979 : ℝ) / 125000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_585 : RB (Real.log ((445607688351919001 : ℝ) / 1000000000000000000)) ((-808316336586314549 : ℝ) / 1000000000000000000) ((-808316336586314547 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((445607688351919001 : ℝ) / 500000000000000000)) (t := ((-54392311648080999 : ℝ) / 945607688351919001))
    (lo := ((-115169156026369239 : ℝ) / 1000000000000000000)) (hi := ((-57584578013184619 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((445607688351919001 : ℝ) / 1000000000000000000) = Real.log ((445607688351919001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((445607688351919001 : ℝ) / 1000000000000000000) = ((445607688351919001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_586 : RB (Real.log ((553336061648081 : ℝ) / 1000000000000000)) ((-18493429863203457 : ℝ) / 31250000000000000) ((-295894877811255311 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((553336061648081 : ℝ) / 500000000000000)) (t := ((53336061648081 : ℝ) / 1053336061648081))
    (lo := ((50678712468717343 : ℝ) / 500000000000000000)) (hi := ((101357424937434687 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((553336061648081 : ℝ) / 1000000000000000) = Real.log ((553336061648081 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((553336061648081 : ℝ) / 1000000000000000) = ((553336061648081 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_587 : RB (Real.log ((138334015412021 : ℝ) / 250000000000000)) ((-295894877811252601 : ℝ) / 500000000000000000) ((-1479474389056263 : ℝ) / 2500000000000000) := by
  have hm := log_bounds_of_series (x := ((138334015412021 : ℝ) / 125000000000000)) (t := ((13334015412021 : ℝ) / 263334015412021))
    (lo := ((25339356234360027 : ℝ) / 250000000000000000)) (hi := ((101357424937440109 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((138334015412021 : ℝ) / 250000000000000) = Real.log ((138334015412021 : ℝ) / 125000000000000) - 1 * Real.log 2 := by
    rw [show ((138334015412021 : ℝ) / 250000000000000) = ((138334015412021 : ℝ) / 125000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_588 : RB (Real.log ((111665984587979 : ℝ) / 250000000000000)) ((-40297439144564843 : ℝ) / 50000000000000000) ((-402974391445648429 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((111665984587979 : ℝ) / 125000000000000)) (t := ((-13334015412021 : ℝ) / 236665984587979))
    (lo := ((-2256032046627031 : ℝ) / 20000000000000000)) (hi := ((-112801602331351549 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111665984587979 : ℝ) / 250000000000000) = Real.log ((111665984587979 : ℝ) / 125000000000000) - 1 * Real.log 2 := by
    rw [show ((111665984587979 : ℝ) / 250000000000000) = ((111665984587979 : ℝ) / 125000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_589 : RB (Real.log ((446663938351919 : ℝ) / 1000000000000000)) ((-25185899465352817 : ℝ) / 31250000000000000) ((-402974391445645071 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((446663938351919 : ℝ) / 500000000000000)) (t := ((-53336061648081 : ℝ) / 946663938351919))
    (lo := ((-56400801165672417 : ℝ) / 500000000000000000)) (hi := ((-112801602331344833 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((446663938351919 : ℝ) / 1000000000000000) = Real.log ((446663938351919 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((446663938351919 : ℝ) / 1000000000000000) = ((446663938351919 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_590 : RB (Real.log ((445607688351916001 : ℝ) / 1000000000000000000)) ((-808316336586321281 : ℝ) / 1000000000000000000) ((-808316336586321279 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((445607688351916001 : ℝ) / 500000000000000000)) (t := ((-54392311648083999 : ℝ) / 945607688351916001))
    (lo := ((-115169156026375971 : ℝ) / 1000000000000000000)) (hi := ((-11516915602637597 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((445607688351916001 : ℝ) / 1000000000000000000) = Real.log ((445607688351916001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((445607688351916001 : ℝ) / 1000000000000000000) = ((445607688351916001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_591 : RB (Real.log ((445607688351919 : ℝ) / 1000000000000000)) ((-808316336586314551 : ℝ) / 1000000000000000000) ((-808316336586314549 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((445607688351919 : ℝ) / 500000000000000)) (t := ((-54392311648081 : ℝ) / 945607688351919))
    (lo := ((-115169156026369241 : ℝ) / 1000000000000000000)) (hi := ((-2879228900659231 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((445607688351919 : ℝ) / 1000000000000000) = Real.log ((445607688351919 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((445607688351919 : ℝ) / 1000000000000000) = ((445607688351919 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_592 : RB (Real.log ((1425766462595621 : ℝ) / 1000000000000000)) ((354709537609361647 : ℝ) / 1000000000000000000) ((354709537609361649 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425766462595621 : ℝ) / 2000000000000000)) (t := ((-574233537404379 : ℝ) / 3425766462595621))
    (lo := ((-169218821475291831 : ℝ) / 500000000000000000)) (hi := ((-338437642950583661 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425766462595621 : ℝ) / 1000000000000000) = Real.log ((1425766462595621 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425766462595621 : ℝ) / 1000000000000000) = ((1425766462595621 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_593 : RB (Real.log ((1425766462595624001 : ℝ) / 1000000000000000000)) ((354709537609363751 : ℝ) / 1000000000000000000) ((354709537609363753 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425766462595624001 : ℝ) / 2000000000000000000)) (t := ((-574233537404375999 : ℝ) / 3425766462595624001))
    (lo := ((-169218821475290779 : ℝ) / 500000000000000000)) (hi := ((-338437642950581557 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425766462595624001 : ℝ) / 1000000000000000000) = Real.log ((1425766462595624001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425766462595624001 : ℝ) / 1000000000000000000) = ((1425766462595624001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_594 : RB (Real.log ((426822712595621 : ℝ) / 1000000000000000)) ((-851386544954478973 : ℝ) / 1000000000000000000) ((-851386544954478971 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((426822712595621 : ℝ) / 500000000000000)) (t := ((-73177287404379 : ℝ) / 926822712595621))
    (lo := ((-158239364394533663 : ℝ) / 1000000000000000000)) (hi := ((-79119682197266831 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((426822712595621 : ℝ) / 1000000000000000) = Real.log ((426822712595621 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((426822712595621 : ℝ) / 1000000000000000) = ((426822712595621 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_595 : RB (Real.log ((53352839074453 : ℝ) / 125000000000000)) ((-170277308990894389 : ℝ) / 200000000000000000) ((-851386544954471943 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((53352839074453 : ℝ) / 62500000000000)) (t := ((-9147160925547 : ℝ) / 115852839074453))
    (lo := ((-31647872878905327 : ℝ) / 200000000000000000)) (hi := ((-79119682197263317 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53352839074453 : ℝ) / 125000000000000) = Real.log ((53352839074453 : ℝ) / 62500000000000) - 1 * Real.log 2 := by
    rw [show ((53352839074453 : ℝ) / 125000000000000) = ((53352839074453 : ℝ) / 62500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_596 : RB (Real.log ((1426822712595621 : ℝ) / 1000000000000000)) ((694238462757509 : ℝ) / 1953125000000000) ((35545009293184461 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426822712595621 : ℝ) / 2000000000000000)) (t := ((-573177287404379 : ℝ) / 3426822712595621))
    (lo := ((-337697087628100701 : ℝ) / 1000000000000000000)) (hi := ((-3376970876281007 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426822712595621 : ℝ) / 1000000000000000) = Real.log ((1426822712595621 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426822712595621 : ℝ) / 1000000000000000) = ((1426822712595621 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_597 : RB (Real.log ((178352839074453 : ℝ) / 125000000000000)) ((35545009293184671 : ℝ) / 100000000000000000) ((44431261616480839 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((178352839074453 : ℝ) / 250000000000000)) (t := ((-71647160925547 : ℝ) / 428352839074453))
    (lo := ((-337697087628098599 : ℝ) / 1000000000000000000)) (hi := ((-168848543814049299 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178352839074453 : ℝ) / 125000000000000) = Real.log ((178352839074453 : ℝ) / 250000000000000) + 1 * Real.log 2 := by
    rw [show ((178352839074453 : ℝ) / 125000000000000) = ((178352839074453 : ℝ) / 250000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_598 : RB (Real.log ((1425766462595621001 : ℝ) / 1000000000000000000)) ((354709537609361647 : ℝ) / 1000000000000000000) ((354709537609361649 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425766462595621001 : ℝ) / 2000000000000000000)) (t := ((-574233537404378999 : ℝ) / 3425766462595621001))
    (lo := ((-169218821475291831 : ℝ) / 500000000000000000)) (hi := ((-338437642950583661 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425766462595621001 : ℝ) / 1000000000000000000) = Real.log ((1425766462595621001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425766462595621001 : ℝ) / 1000000000000000000) = ((1425766462595621001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_599 : RB (Real.log ((178220807824453 : ℝ) / 125000000000000)) ((354709537609363751 : ℝ) / 1000000000000000000) ((354709537609363753 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((178220807824453 : ℝ) / 250000000000000)) (t := ((-71779192175547 : ℝ) / 428220807824453))
    (lo := ((-169218821475290779 : ℝ) / 500000000000000000)) (hi := ((-338437642950581557 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178220807824453 : ℝ) / 125000000000000) = Real.log ((178220807824453 : ℝ) / 250000000000000) + 1 * Real.log 2 := by
    rw [show ((178220807824453 : ℝ) / 125000000000000) = ((178220807824453 : ℝ) / 250000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
