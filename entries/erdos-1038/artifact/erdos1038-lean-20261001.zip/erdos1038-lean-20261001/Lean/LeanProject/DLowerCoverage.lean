import LeanProject.DLowerBoundaryData

/-!
# Exhaustive actual T/M/S coverage for the numerical lower bound of D

All constants are the exact 112-bit endpoints of the independent certificate.
The tail uses positive rho only; rho=0 is an auxiliary leaf endpoint, not an
admissible q. This module proves coverage, not numerical width lower bounds.
-/
open Real Set
namespace EP1038.DLowerCert
open EP1038.Stage9

noncomputable def rho (q : ℝ) : ℝ := 1 / (-Real.log q)
noncomputable def tailQ (r : ℝ) : ℝ := if r = 0 then 0 else Real.exp (-1 / r)
noncomputable def TRegion : Set ℝ := Ioc 0 (tailQ rho1)
noncomputable def MRegion : Set ℝ := Icc qA qB
noncomputable def SRegion : Set ℝ := Icc qB qHi

theorem rho_eq_replay (q : ℝ) : rho q = 1 / Real.log (1 / q) := by
  simp only [rho, one_div, Real.log_inv]

theorem rho_pos {q : ℝ} (hq : 0 < q) (hq1 : q < 1) : 0 < rho q :=
  div_pos zero_lt_one (neg_pos.mpr (Real.log_neg hq hq1))

theorem tailQ_pos {r : ℝ} (hr : 0 < r) : 0 < tailQ r := by
  rw [tailQ, if_neg hr.ne']
  exact Real.exp_pos _

theorem tailQ_lt_one {r : ℝ} (hr : 0 < r) : tailQ r < 1 := by
  rw [tailQ, if_neg hr.ne', Real.exp_lt_one_iff]
  exact div_neg_of_neg_of_pos (by norm_num) hr

theorem tailQ_rho {q : ℝ} (hq : 0 < q) (hq1 : q < 1) : tailQ (rho q) = q := by
  have hlog : Real.log q ≠ 0 := (Real.log_neg hq hq1).ne
  rw [tailQ, if_neg (rho_pos hq hq1).ne']
  have he : -1 / rho q = Real.log q := by
    dsimp [rho]
    field_simp
  rw [he, Real.exp_log hq]

theorem tail_M_overlap : qA < tailQ rho1 := by
  have he := Real.exp_lt_exp.mpr tail_overlap_log
  rw [Real.exp_log qA_bounds.1] at he
  simpa only [tailQ, if_neg rho1_bounds.1.ne'] using he

theorem qHi_pos : 0 < qHi := qProbe_bounds.1.trans qHi_bounds.1

theorem admissible_lt_qHi {q : ℝ} (hq : q ∈ Qadm) : q < qHi := by
  by_contra h
  have hm := fq_strictAntiOn.antitoneOn
    (show qHi ∈ Icc (0 : ℝ) 1 from ⟨qHi_pos.le, qHi_bounds.2.le⟩)
    (show q ∈ Icc (0 : ℝ) 1 from ⟨hq.1.le, hq.2.1.le⟩) (le_of_not_gt h)
  linarith [hq.2.2, fq_qHi_neg]

theorem exists_qs_lt_qHi : ∃ qs, 0 < qs ∧ qs < qHi ∧ fq qs = 0 ∧
    ∀ q, 0 < q → q < 1 → (0 < fq q ↔ q < qs) := by
  obtain ⟨qs, hs0, hs1, hs, hiff⟩ := exists_qs
  have hshi : qs < qHi := by
    by_contra h
    have hm := fq_strictAntiOn.antitoneOn
      (show qHi ∈ Icc (0 : ℝ) 1 from ⟨qHi_pos.le, qHi_bounds.2.le⟩)
      (show qs ∈ Icc (0 : ℝ) 1 from ⟨hs0.le, hs1.le⟩) (le_of_not_gt h)
    rw [hs] at hm
    linarith [fq_qHi_neg]
  exact ⟨qs, hs0, hshi, hs, hiff⟩

theorem MRegion_admissible {q : ℝ} (hq : q ∈ MRegion) : q ∈ Qadm := by
  have h0 : 0 < q := qA_bounds.1.trans_le hq.1
  have h10 : q < (1 : ℝ) / 10 := hq.2.trans_lt qB_bounds.2
  have h1 : q < 1 := by linarith
  have hm := fq_strictAntiOn
    (show q ∈ Icc (0 : ℝ) 1 from ⟨h0.le, h1.le⟩)
    (show (1 : ℝ) / 10 ∈ Icc (0 : ℝ) 1 by norm_num) h10
  exact ⟨h0, h1, fq_tenth_pos.trans hm⟩

theorem tail_rho_bounds {q : ℝ} (hq : q ∈ TRegion) : rho q ∈ Ioc 0 rho1 := by
  have hq1 : q < 1 := hq.2.trans_lt (tailQ_lt_one rho1_bounds.1)
  have hn : 0 < -Real.log q := neg_pos.mpr (Real.log_neg hq.1 hq1)
  have hm := Real.log_le_log hq.1 hq.2
  rw [tailQ, if_neg rho1_bounds.1.ne', Real.log_exp] at hm
  have hp := (le_div_iff₀ rho1_bounds.1).mp hm
  refine ⟨rho_pos hq.1 hq1, ?_⟩
  rw [rho, div_le_iff₀ hn]
  nlinarith

theorem admissible_region_cover {q : ℝ} (hq : q ∈ Qadm) :
    q ∈ TRegion ∨ q ∈ MRegion ∨ q ∈ SRegion := by
  rcases le_or_gt q qA with hA | hA
  · exact Or.inl ⟨hq.1, (hA.trans_lt tail_M_overlap).le⟩
  · rcases le_or_gt q qB with hB | hB
    · exact Or.inr (Or.inl ⟨hA.le, hB⟩)
    · exact Or.inr (Or.inr ⟨hB.le, (admissible_lt_qHi hq).le⟩)

theorem Qadm_subset_three_regions : Qadm ⊆ TRegion ∪ MRegion ∪ SRegion := by
  intro q hq
  rcases admissible_region_cover hq with ht | hm | hs
  · exact Or.inl (Or.inl ht)
  · exact Or.inl (Or.inr hm)
  · exact Or.inr hs

/-- Every admissible parameter belongs to one actual certificate leaf. -/
theorem admissible_exact_leaf_cover {q : ℝ} (hq : q ∈ Qadm) :
    (∃ r ∈ Ioc 0 rho1, tailQ r = q ∧
      ∃ s ∈ tLeaves, r ∈ Icc (dyad s.1) (dyad s.2)) ∨
    (∃ s ∈ mLeaves, q ∈ Icc (dyad s.1) (dyad s.2)) ∨
    (∃ s ∈ sLeaves, q ∈ Icc (dyad s.1) (dyad s.2)) := by
  rcases admissible_region_cover hq with ht | hm | hs
  · have hr := tail_rho_bounds ht
    have hc : rho q ∈ Icc (dyad 0) (dyad rho1Idx) := by
      exact ⟨by simpa only [dyad_zero] using hr.1.le, hr.2⟩
    obtain ⟨s, hmem, hslab⟩ := t_leaves_cover hc
    exact Or.inl ⟨rho q, hr, tailQ_rho hq.1 hq.2.1, s, hmem, hslab⟩
  · exact Or.inr (Or.inl (m_leaves_cover hm))
  · exact Or.inr (Or.inr (s_leaves_cover hs))

/-- The later numerical certificates plug into this already proved assembler.
It does not assert that their width/sign hypotheses have been discharged. -/
theorem family_lower_of_actual_leaf_bounds {L : ℝ}
    (hT : ∀ r, 0 < r → r ≤ rho1 → tailQ r ∈ Qadm →
      ∀ s ∈ tLeaves, r ∈ Icc (dyad s.1) (dyad s.2) → L ≤ Lam (tailQ r))
    (hM : ∀ q, q ∈ Qadm → ∀ s ∈ mLeaves,
      q ∈ Icc (dyad s.1) (dyad s.2) → L ≤ Lam q)
    (hS : ∀ q, q ∈ Qadm → ∀ s ∈ sLeaves,
      q ∈ Icc (dyad s.1) (dyad s.2) → L ≤ Lam q) :
    ∀ q ∈ Qadm, L ≤ Lam q := by
  intro q hq
  rcases admissible_exact_leaf_cover hq with ⟨r, hr, he, s, hm, hs⟩ | hm | hs
  · have hqa : tailQ r ∈ Qadm := by simpa only [he] using hq
    simpa only [he] using hT r hr.1 hr.2 hqa s hm hs
  · obtain ⟨s, hmem, hslab⟩ := hm
    exact hM q hq s hmem hslab
  · obtain ⟨s, hmem, hslab⟩ := hs
    exact hS q hq s hmem hslab

/-- The proved implication (1 ∧ 2 ∧ 4) ⇒ 5 in the dependency diagram.
The remaining numerical statements 2 and 4 are still explicit hypotheses. -/
theorem family_lower_of_region_bounds {L : ℝ}
    (hTS : ∀ q, q ∈ Qadm → q ∈ TRegion ∪ SRegion → L ≤ Lam q)
    (hM : ∀ q, q ∈ Qadm → q ∈ MRegion → L ≤ Lam q) :
    ∀ q ∈ Qadm, L ≤ Lam q := by
  intro q hq
  rcases admissible_region_cover hq with ht | hm | hs
  · exact hTS q hq (Or.inl ht)
  · exact hM q hq hm
  · exact hTS q hq (Or.inr hs)

end EP1038.DLowerCert
