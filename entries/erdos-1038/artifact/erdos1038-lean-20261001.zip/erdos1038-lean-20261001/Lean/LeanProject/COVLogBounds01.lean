import LeanProject.COVLogTwo
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_80 : RB (Real.log ((471591607 : ℝ) / 100000000)) ((77547159 : ℝ) / 50000000) ((155094321 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((471591607 : ℝ) / 400000000)) (t := ((71591607 : ℝ) / 871591607))
    (lo := ((8232441 : ℝ) / 50000000)) (hi := ((16464883 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((471591607 : ℝ) / 100000000) = Real.log ((471591607 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((471591607 : ℝ) / 100000000) = ((471591607 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_81 : RB (Real.log ((471592057 : ℝ) / 100000000)) ((155094413 : ℝ) / 100000000) ((9693401 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((471592057 : ℝ) / 400000000)) (t := ((71592057 : ℝ) / 871592057))
    (lo := ((16464977 : ℝ) / 100000000)) (hi := ((8232489 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((471592057 : ℝ) / 100000000) = Real.log ((471592057 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((471592057 : ℝ) / 100000000) = ((471592057 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_82 : RB (Real.log ((126909847 : ℝ) / 100000000)) ((11915339 : ℝ) / 50000000) ((23830679 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((126909847 : ℝ) / 100000000)) (t := ((26909847 : ℝ) / 226909847))
    (lo := ((11915339 : ℝ) / 50000000)) (hi := ((23830679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_83 : RB (Real.log ((117558217 : ℝ) / 25000000)) ((19350723 : ℝ) / 12500000) ((154805787 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((117558217 : ℝ) / 100000000)) (t := ((17558217 : ℝ) / 217558217))
    (lo := ((4044087 : ℝ) / 25000000)) (hi := ((16176349 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((117558217 : ℝ) / 25000000) = Real.log ((117558217 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((117558217 : ℝ) / 25000000) = ((117558217 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_84 : RB (Real.log ((470233317 : ℝ) / 100000000)) ((3870147 : ℝ) / 2500000) ((154805883 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((470233317 : ℝ) / 400000000)) (t := ((70233317 : ℝ) / 870233317))
    (lo := ((4044111 : ℝ) / 25000000)) (hi := ((3235289 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((470233317 : ℝ) / 100000000) = Real.log ((470233317 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((470233317 : ℝ) / 100000000) = ((470233317 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_85 : RB (Real.log ((25401721 : ℝ) / 20000000)) ((4781693 : ℝ) / 20000000) ((11954233 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((25401721 : ℝ) / 20000000)) (t := ((5401721 : ℝ) / 45401721))
    (lo := ((4781693 : ℝ) / 20000000)) (hi := ((11954233 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_86 : RB (Real.log ((7497983 : ℝ) / 100000000)) ((-129526809 : ℝ) / 50000000) ((-259053613 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7497983 : ℝ) / 6250000)) (t := ((1247983 : ℝ) / 13747983))
    (lo := ((9102629 : ℝ) / 50000000)) (hi := ((18205259 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7497983 : ℝ) / 100000000) = Real.log ((7497983 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7497983 : ℝ) / 100000000) = ((7497983 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_87 : RB (Real.log ((2023179 : ℝ) / 25000000)) ((-251420583 : ℝ) / 100000000) ((-125710289 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2023179 : ℝ) / 1562500)) (t := ((460679 : ℝ) / 3585679))
    (lo := ((25838293 : ℝ) / 100000000)) (hi := ((12919147 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2023179 : ℝ) / 25000000) = Real.log ((2023179 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((2023179 : ℝ) / 25000000) = ((2023179 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_88 : RB (Real.log ((1414219 : ℝ) / 100000000)) ((-425859281 : ℝ) / 100000000) ((-212929637 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1414219 : ℝ) / 1562500)) (t := ((-148281 : ℝ) / 2976719))
    (lo := ((-9970967 : ℝ) / 100000000)) (hi := ((-4985483 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1414219 : ℝ) / 100000000) = Real.log ((1414219 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1414219 : ℝ) / 100000000) = ((1414219 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_89 : RB (Real.log ((1430803 : ℝ) / 100000000)) ((-212346721 : ℝ) / 50000000) ((-84938687 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1430803 : ℝ) / 1562500)) (t := ((-131697 : ℝ) / 2993303))
    (lo := ((-1100641 : ℝ) / 12500000)) (hi := ((-8805127 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1430803 : ℝ) / 100000000) = Real.log ((1430803 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1430803 : ℝ) / 100000000) = ((1430803 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_90 : RB (Real.log ((15910747 : ℝ) / 20000000)) ((-22873749 : ℝ) / 100000000) ((-5718437 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((15910747 : ℝ) / 20000000)) (t := ((-4089253 : ℝ) / 35910747))
    (lo := ((-22873749 : ℝ) / 100000000)) (hi := ((-5718437 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_91 : RB (Real.log ((15910791 : ℝ) / 20000000)) ((-178699 : ℝ) / 781250) ((-22873471 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((15910791 : ℝ) / 20000000)) (t := ((-4089209 : ℝ) / 35910791))
    (lo := ((-178699 : ℝ) / 781250)) (hi := ((-22873471 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_92 : RB (Real.log ((44309367 : ℝ) / 100000000)) ((-8139741 : ℝ) / 10000000) ((-2543669 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((44309367 : ℝ) / 50000000)) (t := ((-5690633 : ℝ) / 94309367))
    (lo := ((-12082691 : ℝ) / 100000000)) (hi := ((-1208269 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44309367 : ℝ) / 100000000) = Real.log ((44309367 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44309367 : ℝ) / 100000000) = ((44309367 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_93 : RB (Real.log ((197096019 : ℝ) / 100000000)) ((33926041 : ℝ) / 50000000) ((16963021 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((197096019 : ℝ) / 200000000)) (t := ((-2903981 : ℝ) / 397096019))
    (lo := ((-365659 : ℝ) / 25000000)) (hi := ((-292527 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197096019 : ℝ) / 100000000) = Real.log ((197096019 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((197096019 : ℝ) / 100000000) = ((197096019 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_94 : RB (Real.log ((197128489 : ℝ) / 100000000)) ((13573711 : ℝ) / 20000000) ((67868557 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((197128489 : ℝ) / 200000000)) (t := ((-2871511 : ℝ) / 397128489))
    (lo := ((-1446163 : ℝ) / 100000000)) (hi := ((-723081 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197128489 : ℝ) / 100000000) = Real.log ((197128489 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((197128489 : ℝ) / 100000000) = ((197128489 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_95 : RB (Real.log ((40135559 : ℝ) / 50000000)) ((-21976031 : ℝ) / 100000000) ((-2197603 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((40135559 : ℝ) / 50000000)) (t := ((-9864441 : ℝ) / 90135559))
    (lo := ((-21976031 : ℝ) / 100000000)) (hi := ((-2197603 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_96 : RB (Real.log ((80271339 : ℝ) / 100000000)) ((-5493939 : ℝ) / 25000000) ((-4395151 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((80271339 : ℝ) / 100000000)) (t := ((-19728661 : ℝ) / 180271339))
    (lo := ((-5493939 : ℝ) / 25000000)) (hi := ((-4395151 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_97 : RB (Real.log ((22265493 : ℝ) / 50000000)) ((-40449247 : ℝ) / 50000000) ((-20224623 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((22265493 : ℝ) / 25000000)) (t := ((-2734507 : ℝ) / 47265493))
    (lo := ((-463351 : ℝ) / 4000000)) (hi := ((-5791887 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22265493 : ℝ) / 50000000) = Real.log ((22265493 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22265493 : ℝ) / 50000000) = ((22265493 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_98 : RB (Real.log ((11778411 : ℝ) / 2500000)) ((77498877 : ℝ) / 50000000) ((154997757 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11778411 : ℝ) / 10000000)) (t := ((1778411 : ℝ) / 21778411))
    (lo := ((8184159 : ℝ) / 50000000)) (hi := ((16368319 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11778411 : ℝ) / 2500000) = Real.log ((11778411 : ℝ) / 10000000) + 2 * Real.log 2 := by
    rw [show ((11778411 : ℝ) / 2500000) = ((11778411 : ℝ) / 10000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_99 : RB (Real.log ((235568447 : ℝ) / 50000000)) ((154997851 : ℝ) / 100000000) ((77498927 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((235568447 : ℝ) / 200000000)) (t := ((35568447 : ℝ) / 435568447))
    (lo := ((3273683 : ℝ) / 20000000)) (hi := ((511513 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((235568447 : ℝ) / 50000000) = Real.log ((235568447 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((235568447 : ℝ) / 50000000) = ((235568447 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_100 : RB (Real.log ((126942817 : ℝ) / 100000000)) ((23856653 : ℝ) / 100000000) ((11928327 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((126942817 : ℝ) / 100000000)) (t := ((26942817 : ℝ) / 226942817))
    (lo := ((23856653 : ℝ) / 100000000)) (hi := ((11928327 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_101 : RB (Real.log ((58722889 : ℝ) / 12500000)) ((154710093 : ℝ) / 100000000) ((9669381 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((58722889 : ℝ) / 50000000)) (t := ((8722889 : ℝ) / 108722889))
    (lo := ((16080657 : ℝ) / 100000000)) (hi := ((8040329 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((58722889 : ℝ) / 12500000) = Real.log ((58722889 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((58722889 : ℝ) / 12500000) = ((58722889 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_102 : RB (Real.log ((117445891 : ℝ) / 25000000)) ((154710189 : ℝ) / 100000000) ((9669387 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((117445891 : ℝ) / 100000000)) (t := ((17445891 : ℝ) / 217445891))
    (lo := ((16080753 : ℝ) / 100000000)) (hi := ((8040377 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((117445891 : ℝ) / 25000000) = Real.log ((117445891 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((117445891 : ℝ) / 25000000) = ((117445891 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_103 : RB (Real.log ((63520711 : ℝ) / 50000000)) ((239343 : ℝ) / 1000000) ((23934301 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63520711 : ℝ) / 50000000)) (t := ((13520711 : ℝ) / 113520711))
    (lo := ((239343 : ℝ) / 1000000)) (hi := ((23934301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_104 : RB (Real.log ((1873789 : ℝ) / 25000000)) ((-2024151 : ℝ) / 781250) ((-259091323 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1873789 : ℝ) / 1562500)) (t := ((311289 : ℝ) / 3436289))
    (lo := ((4541887 : ℝ) / 25000000)) (hi := ((18167549 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1873789 : ℝ) / 25000000) = Real.log ((1873789 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1873789 : ℝ) / 25000000) = ((1873789 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_105 : RB (Real.log ((8085733 : ℝ) / 100000000)) ((-62876727 : ℝ) / 25000000) ((-251506903 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8085733 : ℝ) / 6250000)) (t := ((1835733 : ℝ) / 14335733))
    (lo := ((804749 : ℝ) / 3125000)) (hi := ((25751969 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8085733 : ℝ) / 100000000) = Real.log ((8085733 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8085733 : ℝ) / 100000000) = ((8085733 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_106 : RB (Real.log ((1430329 : ℝ) / 100000000)) ((-26545411 : ℝ) / 6250000) ((-424726569 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1430329 : ℝ) / 1562500)) (t := ((-132171 : ℝ) / 2992829))
    (lo := ((-4419131 : ℝ) / 50000000)) (hi := ((-8838261 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1430329 : ℝ) / 100000000) = Real.log ((1430329 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1430329 : ℝ) / 100000000) = ((1430329 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_107 : RB (Real.log ((36173 : ℝ) / 2500000)) ((-423573309 : ℝ) / 100000000) ((-211786651 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((72346 : ℝ) / 78125)) (t := ((-5779 : ℝ) / 150471))
    (lo := ((-1536999 : ℝ) / 20000000)) (hi := ((-3842497 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((36173 : ℝ) / 2500000) = Real.log ((72346 : ℝ) / 78125) - 6 * Real.log 2 := by
    rw [show ((36173 : ℝ) / 2500000) = ((72346 : ℝ) / 78125) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_108 : RB (Real.log ((79411823 : ℝ) / 100000000)) ((-23052293 : ℝ) / 100000000) ((-5763073 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((79411823 : ℝ) / 100000000)) (t := ((-20588177 : ℝ) / 179411823))
    (lo := ((-23052293 : ℝ) / 100000000)) (hi := ((-5763073 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_109 : RB (Real.log ((39706023 : ℝ) / 50000000)) ((-5763003 : ℝ) / 25000000) ((-23052011 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39706023 : ℝ) / 50000000)) (t := ((-10293977 : ℝ) / 89706023))
    (lo := ((-5763003 : ℝ) / 25000000)) (hi := ((-23052011 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_110 : RB (Real.log ((8853077 : ℝ) / 20000000)) ((-81496721 : ℝ) / 100000000) ((-81496719 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8853077 : ℝ) / 10000000)) (t := ((-1146923 : ℝ) / 18853077))
    (lo := ((-6091001 : ℝ) / 50000000)) (hi := ((-12182001 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8853077 : ℝ) / 20000000) = Real.log ((8853077 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8853077 : ℝ) / 20000000) = ((8853077 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_111 : RB (Real.log ((98531777 : ℝ) / 50000000)) ((67835609 : ℝ) / 100000000) ((67835611 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((98531777 : ℝ) / 100000000)) (t := ((-1468223 : ℝ) / 198531777))
    (lo := ((-1479109 : ℝ) / 100000000)) (hi := ((-369777 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98531777 : ℝ) / 50000000) = Real.log ((98531777 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98531777 : ℝ) / 50000000) = ((98531777 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_112 : RB (Real.log ((98548013 : ℝ) / 50000000)) ((33926043 : ℝ) / 50000000) ((8481511 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((98548013 : ℝ) / 100000000)) (t := ((-1451987 : ℝ) / 198548013))
    (lo := ((-182829 : ℝ) / 12500000)) (hi := ((-1462631 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98548013 : ℝ) / 50000000) = Real.log ((98548013 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98548013 : ℝ) / 50000000) = ((98548013 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_113 : RB (Real.log ((10015293 : ℝ) / 12500000)) ((-11080771 : ℝ) / 50000000) ((-22161541 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10015293 : ℝ) / 12500000)) (t := ((-2484707 : ℝ) / 22515293))
    (lo := ((-11080771 : ℝ) / 50000000)) (hi := ((-22161541 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_114 : RB (Real.log ((10015321 : ℝ) / 12500000)) ((-22161263 : ℝ) / 100000000) ((-11080631 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((10015321 : ℝ) / 12500000)) (t := ((-2484679 : ℝ) / 22515321))
    (lo := ((-22161263 : ℝ) / 100000000)) (hi := ((-11080631 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_115 : RB (Real.log ((44485239 : ℝ) / 100000000)) ((-81001277 : ℝ) / 100000000) ((-3240051 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((44485239 : ℝ) / 50000000)) (t := ((-5514761 : ℝ) / 94485239))
    (lo := ((-5843279 : ℝ) / 50000000)) (hi := ((-11686557 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44485239 : ℝ) / 100000000) = Real.log ((44485239 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44485239 : ℝ) / 100000000) = ((44485239 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_116 : RB (Real.log ((470683093 : ℝ) / 100000000)) ((38725371 : ℝ) / 25000000) ((154901487 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((470683093 : ℝ) / 400000000)) (t := ((70683093 : ℝ) / 870683093))
    (lo := ((1017003 : ℝ) / 6250000)) (hi := ((16272049 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((470683093 : ℝ) / 100000000) = Real.log ((470683093 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((470683093 : ℝ) / 100000000) = ((470683093 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_117 : RB (Real.log ((235341777 : ℝ) / 50000000)) ((77450791 : ℝ) / 50000000) ((30980317 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((235341777 : ℝ) / 200000000)) (t := ((35341777 : ℝ) / 435341777))
    (lo := ((8136073 : ℝ) / 50000000)) (hi := ((16272147 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((235341777 : ℝ) / 50000000) = Real.log ((235341777 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((235341777 : ℝ) / 50000000) = ((235341777 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_118 : RB (Real.log ((25395147 : ℝ) / 20000000)) ((23882581 : ℝ) / 100000000) ((11941291 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((25395147 : ℝ) / 20000000)) (t := ((5395147 : ℝ) / 45395147))
    (lo := ((23882581 : ℝ) / 100000000)) (hi := ((11941291 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_119 : RB (Real.log ((234667561 : ℝ) / 50000000)) ((154614687 : ℝ) / 100000000) ((15461469 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((234667561 : ℝ) / 200000000)) (t := ((34667561 : ℝ) / 434667561))
    (lo := ((15985251 : ℝ) / 100000000)) (hi := ((3996313 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((234667561 : ℝ) / 50000000) = Real.log ((234667561 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((234667561 : ℝ) / 50000000) = ((234667561 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_120 : RB (Real.log ((469335581 : ℝ) / 100000000)) ((603964 : ℝ) / 390625) ((154614787 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((469335581 : ℝ) / 400000000)) (t := ((69335581 : ℝ) / 869335581))
    (lo := ((3996337 : ℝ) / 25000000)) (hi := ((15985349 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((469335581 : ℝ) / 100000000) = Real.log ((469335581 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((469335581 : ℝ) / 100000000) = ((469335581 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_121 : RB (Real.log ((127074189 : ℝ) / 100000000)) ((23960089 : ℝ) / 100000000) ((2396009 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((127074189 : ℝ) / 100000000)) (t := ((27074189 : ℝ) / 227074189))
    (lo := ((23960089 : ℝ) / 100000000)) (hi := ((2396009 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_122 : RB (Real.log ((1498583 : ℝ) / 20000000)) ((-16195077 : ℝ) / 6250000) ((-259121227 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1498583 : ℝ) / 1250000)) (t := ((248583 : ℝ) / 2748583))
    (lo := ((4534411 : ℝ) / 25000000)) (hi := ((3627529 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1498583 : ℝ) / 20000000) = Real.log ((1498583 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1498583 : ℝ) / 20000000) = ((1498583 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_123 : RB (Real.log ((8079367 : ℝ) / 100000000)) ((-25158567 : ℝ) / 10000000) ((-50317133 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((8079367 : ℝ) / 6250000)) (t := ((1829367 : ℝ) / 14329367))
    (lo := ((12836603 : ℝ) / 50000000)) (hi := ((25673207 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8079367 : ℝ) / 100000000) = Real.log ((8079367 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8079367 : ℝ) / 100000000) = ((8079367 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_124 : RB (Real.log ((36161 : ℝ) / 2500000)) ((-52950811 : ℝ) / 12500000) ((-423606481 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((72322 : ℝ) / 78125)) (t := ((-5803 : ℝ) / 150447))
    (lo := ((-3859087 : ℝ) / 50000000)) (hi := ((-7718173 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((36161 : ℝ) / 2500000) = Real.log ((72322 : ℝ) / 78125) - 6 * Real.log 2 := by
    rw [show ((36161 : ℝ) / 2500000) = ((72322 : ℝ) / 78125) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_125 : RB (Real.log ((365759 : ℝ) / 25000000)) ((-105616413 : ℝ) / 25000000) ((-84493129 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((365759 : ℝ) / 390625)) (t := ((-12433 : ℝ) / 378192))
    (lo := ((-3288669 : ℝ) / 50000000)) (hi := ((-6577337 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((365759 : ℝ) / 25000000) = Real.log ((365759 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((365759 : ℝ) / 25000000) = ((365759 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_126 : RB (Real.log ((39635631 : ℝ) / 50000000)) ((-5807363 : ℝ) / 25000000) ((-23229451 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39635631 : ℝ) / 50000000)) (t := ((-10364369 : ℝ) / 89635631))
    (lo := ((-5807363 : ℝ) / 25000000)) (hi := ((-23229451 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_127 : RB (Real.log ((39635743 : ℝ) / 50000000)) ((-2322917 : ℝ) / 10000000) ((-23229169 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39635743 : ℝ) / 50000000)) (t := ((-10364257 : ℝ) / 89635743))
    (lo := ((-2322917 : ℝ) / 10000000)) (hi := ((-23229169 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_128 : RB (Real.log ((22110877 : ℝ) / 50000000)) ((-10199417 : ℝ) / 12500000) ((-40797667 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((22110877 : ℝ) / 25000000)) (t := ((-2889123 : ℝ) / 47110877))
    (lo := ((-12280617 : ℝ) / 100000000)) (hi := ((-1535077 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22110877 : ℝ) / 50000000) = Real.log ((22110877 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22110877 : ℝ) / 50000000) = ((22110877 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_129 : RB (Real.log ((98515543 : ℝ) / 50000000)) ((16954783 : ℝ) / 25000000) ((33909567 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((98515543 : ℝ) / 100000000)) (t := ((-1484457 : ℝ) / 198515543))
    (lo := ((-747793 : ℝ) / 50000000)) (hi := ((-299117 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98515543 : ℝ) / 50000000) = Real.log ((98515543 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98515543 : ℝ) / 50000000) = ((98515543 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_130 : RB (Real.log ((197063561 : ℝ) / 100000000)) ((67835613 : ℝ) / 100000000) ((13567123 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((197063561 : ℝ) / 200000000)) (t := ((-2936439 : ℝ) / 397063561))
    (lo := ((-295821 : ℝ) / 20000000)) (hi := ((-23111 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197063561 : ℝ) / 100000000) = Real.log ((197063561 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((197063561 : ℝ) / 100000000) = ((197063561 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_131 : RB (Real.log ((79974991 : ℝ) / 100000000)) ((-11172811 : ℝ) / 50000000) ((-22345621 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((79974991 : ℝ) / 100000000)) (t := ((-20025009 : ℝ) / 179974991))
    (lo := ((-11172811 : ℝ) / 50000000)) (hi := ((-22345621 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_132 : RB (Real.log ((15995043 : ℝ) / 20000000)) ((-11172671 : ℝ) / 50000000) ((-22345341 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((15995043 : ℝ) / 20000000)) (t := ((-4004957 : ℝ) / 35995043))
    (lo := ((-11172671 : ℝ) / 50000000)) (hi := ((-22345341 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_133 : RB (Real.log ((8887971 : ℝ) / 20000000)) ((-1622067 : ℝ) / 2000000) ((-20275837 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((8887971 : ℝ) / 10000000)) (t := ((-1112029 : ℝ) / 18887971))
    (lo := ((-11788631 : ℝ) / 100000000)) (hi := ((-1178863 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8887971 : ℝ) / 20000000) = Real.log ((8887971 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8887971 : ℝ) / 20000000) = ((8887971 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_134 : RB (Real.log ((29389471 : ℝ) / 6250000)) ((154805501 : ℝ) / 100000000) ((604709 : ℝ) / 390625) := by
  have hm := log_bounds_of_series (x := ((29389471 : ℝ) / 25000000)) (t := ((4389471 : ℝ) / 54389471))
    (lo := ((3235213 : ℝ) / 20000000)) (hi := ((8088033 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((29389471 : ℝ) / 6250000) = Real.log ((29389471 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((29389471 : ℝ) / 6250000) = ((29389471 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_135 : RB (Real.log ((470231997 : ℝ) / 100000000)) ((154805599 : ℝ) / 100000000) ((77402801 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((470231997 : ℝ) / 400000000)) (t := ((70231997 : ℝ) / 870231997))
    (lo := ((16176163 : ℝ) / 100000000)) (hi := ((4044041 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((470231997 : ℝ) / 100000000) = Real.log ((470231997 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((470231997 : ℝ) / 100000000) = ((470231997 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_136 : RB (Real.log ((127008603 : ℝ) / 100000000)) ((23908463 : ℝ) / 100000000) ((1494279 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((127008603 : ℝ) / 100000000)) (t := ((27008603 : ℝ) / 227008603))
    (lo := ((23908463 : ℝ) / 100000000)) (hi := ((1494279 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_137 : RB (Real.log ((234444447 : ℝ) / 50000000)) ((30903913 : ℝ) / 20000000) ((9657473 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((234444447 : ℝ) / 200000000)) (t := ((34444447 : ℝ) / 434444447))
    (lo := ((15890129 : ℝ) / 100000000)) (hi := ((1589013 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((234444447 : ℝ) / 50000000) = Real.log ((234444447 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((234444447 : ℝ) / 50000000) = ((234444447 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_138 : RB (Real.log ((468889353 : ℝ) / 100000000)) ((154519663 : ℝ) / 100000000) ((77259833 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((468889353 : ℝ) / 400000000)) (t := ((68889353 : ℝ) / 868889353))
    (lo := ((15890227 : ℝ) / 100000000)) (hi := ((3972557 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((468889353 : ℝ) / 100000000) = Real.log ((468889353 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((468889353 : ℝ) / 100000000) = ((468889353 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_139 : RB (Real.log ((63553453 : ℝ) / 50000000)) ((2998229 : ℝ) / 12500000) ((23985833 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63553453 : ℝ) / 50000000)) (t := ((13553453 : ℝ) / 113553453))
    (lo := ((2998229 : ℝ) / 12500000)) (hi := ((23985833 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_140 : RB (Real.log ((3745631 : ℝ) / 50000000)) ((-51828659 : ℝ) / 20000000) ((-25914329 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((3745631 : ℝ) / 3125000)) (t := ((620631 : ℝ) / 6870631))
    (lo := ((18115581 : ℝ) / 100000000)) (hi := ((9057791 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3745631 : ℝ) / 50000000) = Real.log ((3745631 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((3745631 : ℝ) / 50000000) = ((3745631 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_141 : RB (Real.log ((2018403 : ℝ) / 25000000)) ((-125828463 : ℝ) / 50000000) ((-251656921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2018403 : ℝ) / 1562500)) (t := ((455903 : ℝ) / 3580903))
    (lo := ((512039 : ℝ) / 2000000)) (hi := ((25601951 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2018403 : ℝ) / 25000000) = Real.log ((2018403 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((2018403 : ℝ) / 25000000) = ((2018403 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_142 : RB (Real.log ((1462549 : ℝ) / 100000000)) ((-3300773 : ℝ) / 781250) ((-422498937 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1462549 : ℝ) / 1562500)) (t := ((-99951 : ℝ) / 3025049))
    (lo := ((-661063 : ℝ) / 10000000)) (hi := ((-6610629 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1462549 : ℝ) / 100000000) = Real.log ((1462549 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1462549 : ℝ) / 100000000) = ((1462549 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_143 : RB (Real.log ((92447 : ℝ) / 6250000)) ((-42137013 : ℝ) / 10000000) ((-421370123 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((369788 : ℝ) / 390625)) (t := ((-20837 : ℝ) / 760413))
    (lo := ((-685227 : ℝ) / 12500000)) (hi := ((-1096363 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92447 : ℝ) / 6250000) = Real.log ((369788 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((92447 : ℝ) / 6250000) = ((369788 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_144 : RB (Real.log ((15743681 : ℝ) / 20000000)) ((-598233 : ℝ) / 2500000) ((-23929319 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((15743681 : ℝ) / 20000000)) (t := ((-4256319 : ℝ) / 35743681))
    (lo := ((-598233 : ℝ) / 2500000)) (hi := ((-23929319 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_145 : RB (Real.log ((3935943 : ℝ) / 5000000)) ((-11964371 : ℝ) / 50000000) ((-23928741 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3935943 : ℝ) / 5000000)) (t := ((-1064057 : ℝ) / 8935943))
    (lo := ((-11964371 : ℝ) / 50000000)) (hi := ((-23928741 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_146 : RB (Real.log ((11012337 : ℝ) / 25000000)) ((-16397193 : ℝ) / 20000000) ((-81985963 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11012337 : ℝ) / 12500000)) (t := ((-1487663 : ℝ) / 23512337))
    (lo := ((-6335623 : ℝ) / 50000000)) (hi := ((-2534249 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11012337 : ℝ) / 25000000) = Real.log ((11012337 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11012337 : ℝ) / 25000000) = ((11012337 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_147 : RB (Real.log ((196966137 : ℝ) / 100000000)) ((67786163 : ℝ) / 100000000) ((13557233 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((196966137 : ℝ) / 200000000)) (t := ((-3033863 : ℝ) / 396966137))
    (lo := ((-305711 : ℝ) / 20000000)) (hi := ((-764277 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196966137 : ℝ) / 100000000) = Real.log ((196966137 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196966137 : ℝ) / 100000000) = ((196966137 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_148 : RB (Real.log ((197031089 : ℝ) / 100000000)) ((33909567 : ℝ) / 50000000) ((529837 : ℝ) / 781250) := by
  have hm := log_bounds_of_series (x := ((197031089 : ℝ) / 200000000)) (t := ((-2968911 : ℝ) / 397031089))
    (lo := ((-46737 : ℝ) / 3125000)) (hi := ((-1495583 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197031089 : ℝ) / 100000000) = Real.log ((197031089 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((197031089 : ℝ) / 100000000) = ((197031089 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_149 : RB (Real.log ((320423 : ℝ) / 400000)) ((-4436451 : ℝ) / 20000000) ((-11091127 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((320423 : ℝ) / 400000)) (t := ((-79577 : ℝ) / 720423))
    (lo := ((-4436451 : ℝ) / 20000000)) (hi := ((-11091127 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_150 : RB (Real.log ((80106209 : ℝ) / 100000000)) ((-11090841 : ℝ) / 50000000) ((-22181681 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((80106209 : ℝ) / 100000000)) (t := ((-19893791 : ℝ) / 180106209))
    (lo := ((-11090841 : ℝ) / 50000000)) (hi := ((-22181681 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_151 : RB (Real.log ((44480333 : ℝ) / 100000000)) ((-40506153 : ℝ) / 50000000) ((-5063269 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((44480333 : ℝ) / 50000000)) (t := ((-5519667 : ℝ) / 94480333))
    (lo := ((-11697587 : ℝ) / 100000000)) (hi := ((-5848793 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44480333 : ℝ) / 100000000) = Real.log ((44480333 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44480333 : ℝ) / 100000000) = ((44480333 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_152 : RB (Real.log ((47022853 : ℝ) / 10000000)) ((77402431 : ℝ) / 50000000) ((30960973 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((47022853 : ℝ) / 40000000)) (t := ((7022853 : ℝ) / 87022853))
    (lo := ((8087713 : ℝ) / 50000000)) (hi := ((16175427 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47022853 : ℝ) / 10000000) = Real.log ((47022853 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((47022853 : ℝ) / 10000000) = ((47022853 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_153 : RB (Real.log ((470229471 : ℝ) / 100000000)) ((77402531 : ℝ) / 50000000) ((30961013 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((470229471 : ℝ) / 400000000)) (t := ((70229471 : ℝ) / 870229471))
    (lo := ((8087813 : ℝ) / 50000000)) (hi := ((16175627 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((470229471 : ℝ) / 100000000) = Real.log ((470229471 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((470229471 : ℝ) / 100000000) = ((470229471 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_154 : RB (Real.log ((63504377 : ℝ) / 50000000)) ((11954291 : ℝ) / 50000000) ((23908583 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63504377 : ℝ) / 50000000)) (t := ((13504377 : ℝ) / 113504377))
    (lo := ((11954291 : ℝ) / 50000000)) (hi := ((23908583 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_155 : RB (Real.log ((233779553 : ℝ) / 50000000)) ((77117779 : ℝ) / 50000000) ((154235561 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((233779553 : ℝ) / 200000000)) (t := ((33779553 : ℝ) / 433779553))
    (lo := ((7803061 : ℝ) / 50000000)) (hi := ((15606123 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((233779553 : ℝ) / 50000000) = Real.log ((233779553 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((233779553 : ℝ) / 50000000) = ((233779553 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_156 : RB (Real.log ((11689001 : ℝ) / 2500000)) ((77117879 : ℝ) / 50000000) ((154235761 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11689001 : ℝ) / 10000000)) (t := ((1689001 : ℝ) / 21689001))
    (lo := ((7803161 : ℝ) / 50000000)) (hi := ((15606323 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11689001 : ℝ) / 2500000) = Real.log ((11689001 : ℝ) / 10000000) + 2 * Real.log 2 := by
    rw [show ((11689001 : ℝ) / 2500000) = ((11689001 : ℝ) / 10000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_157 : RB (Real.log ((127204907 : ℝ) / 100000000)) ((3007863 : ℝ) / 12500000) ((4812581 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((127204907 : ℝ) / 100000000)) (t := ((27204907 : ℝ) / 227204907))
    (lo := ((3007863 : ℝ) / 12500000)) (hi := ((4812581 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_158 : RB (Real.log ((3601781 : ℝ) / 50000000)) ((-13152973 : ℝ) / 5000000) ((-52611891 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3601781 : ℝ) / 3125000)) (t := ((476781 : ℝ) / 6726781))
    (lo := ((1774927 : ℝ) / 12500000)) (hi := ((14199417 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3601781 : ℝ) / 50000000) = Real.log ((3601781 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((3601781 : ℝ) / 50000000) = ((3601781 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_159 : RB (Real.log ((8356109 : ℝ) / 100000000)) ((-248217733 : ℝ) / 100000000) ((-248217729 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8356109 : ℝ) / 12500000)) (t := ((-4143891 : ℝ) / 20856109))
    (lo := ((-5034197 : ℝ) / 12500000)) (hi := ((-1610943 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8356109 : ℝ) / 100000000) = Real.log ((8356109 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8356109 : ℝ) / 100000000) = ((8356109 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
