import LeanProject.DLowerLogs
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_T_4 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((43040000918854357 : ℝ) / 288230376151711744) ((11738182068778461 : ℝ) / 72057594037927936)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((215765041431 : ℝ) / 100000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((11738182068778461 : ℝ) / 72057594037927936) ≤ ((-1534683855123 : ℝ) / 250000000000) by norm_num).trans dlower_log_39.1)
  have hql : ((60295621 : ℝ) / 48828125000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_40.2.trans (show ((-104637535577 : ℝ) / 15625000000) ≤ -1 / ((43040000918854357 : ℝ) / 288230376151711744) by norm_num))
  have hqr : RB (tailQ r) ((60295621 : ℝ) / 48828125000) ((215765041431 : ℝ) / 100000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((500617427159 : ℝ) / 500000000000) ((200431530083 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((38565391 : ℝ) / 31250000000) ((2155326031 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_41.1 dlower_log_42.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((38565391 : ℝ) / 15625000000) ((2155326031 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((688836528497 : ℝ) / 1000000000000) ((43167437221 : ℝ) / 62500000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((102860514617 : ℝ) / 1000000000000) ((112511608373 : ℝ) / 1000000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((887488391627 : ℝ) / 1000000000000) ((897139485383 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((304973 : ℝ) / 200000000000) ((145483 : ℝ) / 31250000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((62537802239 : ℝ) / 125000000000)) - (z7)
  have h8 : RB z8 ((62537220307 : ℝ) / 125000000000) ((500300893047 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((62537802239 : ℝ) / 125000000000) ((62537802239 : ℝ) / 125000000000) ((62537802239 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((62462197761 : ℝ) / 125000000000))
  have h9 : RB z9 ((250300271799 : ℝ) / 250000000000) ((125150919021 : ℝ) / 125000000000) := rb_div_signed h8 (show RB ((62462197761 : ℝ) / 125000000000) ((62462197761 : ℝ) / 125000000000) ((62462197761 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((1200366467 : ℝ) / 1000000000000) ((241324781 : ℝ) / 200000000000) := rb_log h9 (by norm_num) dlower_log_43.1 dlower_log_44.2
  let z11 : ℝ := (z6) * (z10)
  have h11 : RB z11 ((213062261 : ℝ) / 200000000000) ((21650199 : ℝ) / 20000000000) := rb_widen (rb_mul h6 h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((62537802239 : ℝ) / 125000000000))
  have h12 : RB z12 ((-86567815947 : ℝ) / 125000000000) ((-346271263787 : ℝ) / 500000000000) := rb_log (show RB ((62537802239 : ℝ) / 125000000000) ((62537802239 : ℝ) / 125000000000) ((62537802239 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_45.1 dlower_log_45.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((693607838879 : ℝ) / 1000000000000) ((346812518763 : ℝ) / 500000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((2928843343 : ℝ) / 1000000000000) ((4788509029 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((304973 : ℝ) / 200000000000) ((145483 : ℝ) / 31250000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((1430040390301 : ℝ) / 1000000000000)) - (z15)
  have h16 : RB z16 ((286007146969 : ℝ) / 200000000000) ((357509716359 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((1430040390301 : ℝ) / 1000000000000) ((1430040390301 : ℝ) / 1000000000000) ((1430040390301 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((430040390301 : ℝ) / 1000000000000))
  have h17 : RB z17 ((3325352146211 : ℝ) / 1000000000000) ((831339856493 : ℝ) / 250000000000) := rb_div_signed h16 (show RB ((430040390301 : ℝ) / 1000000000000) ((430040390301 : ℝ) / 1000000000000) ((430040390301 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((1201575577133 : ℝ) / 1000000000000) ((1201577766303 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_46.1 dlower_log_47.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((66649023523 : ℝ) / 62500000000) ((1077982858909 : ℝ) / 1000000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((1430040390301 : ℝ) / 1000000000000))
  have h20 : RB z20 ((357702688837 : ℝ) / 1000000000000) ((357702688839 : ℝ) / 1000000000000) := rb_log (show RB ((1430040390301 : ℝ) / 1000000000000) ((1430040390301 : ℝ) / 1000000000000) ((1430040390301 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_48.1 dlower_log_48.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((708681687529 : ℝ) / 1000000000000) ((90035021259 : ℝ) / 125000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((18002691993 : ℝ) / 1000000000000) ((1257745663 : ℝ) / 40000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((500617427159 : ℝ) / 500000000000) ((200431530083 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1002471233501 : ℝ) / 1000000000000) ((502159978143 : ℝ) / 500000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((1991397250927 : ℝ) / 1000000000000) ((1995069716879 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((929737972389 : ℝ) / 1000000000000))
  have h26 : RB z26 ((1851477642297 : ℝ) / 1000000000000) ((927446036673 : ℝ) / 500000000000) := rb_widen (rb_mul h25 (show RB ((929737972389 : ℝ) / 1000000000000) ((929737972389 : ℝ) / 1000000000000) ((929737972389 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((304973 : ℝ) / 200000000000) ((145483 : ℝ) / 31250000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((89431583122426311683939 : ℝ) / 125000000000000000000000))
  have h28 : RB z28 ((16651 : ℝ) / 7812500000) ((12709 : ℝ) / 1953125000) := rb_div_signed h27 (show RB ((89431583122426311683939 : ℝ) / 125000000000000000000000) ((89431583122426311683939 : ℝ) / 125000000000000000000000) ((89431583122426311683939 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((1953112291 : ℝ) / 1953125000) ((7812483349 : ℝ) / 7812500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1851465594717 : ℝ) / 1000000000000) ((1854888119963 : ℝ) / 1000000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((62537802239 : ℝ) / 125000000000)) ((2928843343 : ℝ) / 1000000000000) ((4788509029 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((1430040390301 : ℝ) / 1000000000000)) ((18002691993 : ℝ) / 1000000000000) ((1257745663 : ℝ) / 40000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((62537802239 : ℝ) / 125000000000)) (wl := ((1430040390301 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1851465594717 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((1430040390301 : ℝ) / 1000000000000) - ((62537802239 : ℝ) / 125000000000)) * (1 - (tailQ r) ^ 2 / (((1430040390301 : ℝ) / 1000000000000) * ((62537802239 : ℝ) / 125000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_5 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((11738182068778461 : ℝ) / 72057594037927936) ((50865455631373331 : ℝ) / 288230376151711744)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((345986743741 : ℝ) / 100000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((50865455631373331 : ℝ) / 288230376151711744) ≤ ((-1133305000707 : ℝ) / 200000000000) by norm_num).trans dlower_log_49.1)
  have hql : ((107882520713 : ℝ) / 50000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_50.2.trans (show ((-6138735420513 : ℝ) / 1000000000000) ≤ -1 / ((11738182068778461 : ℝ) / 72057594037927936) by norm_num))
  have hqr : RB (tailQ r) ((107882520713 : ℝ) / 50000000000000) ((345986743741 : ℝ) / 100000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((501078825207 : ℝ) / 500000000000) ((501729933719 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((2155326029 : ℝ) / 1000000000000) ((3453895867 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_51.1 dlower_log_52.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((2155326029 : ℝ) / 500000000000) ((3453895867 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((27449575553 : ℝ) / 40000000000) ((344418264251 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((111788396439 : ℝ) / 1000000000000) ((118713307 : ℝ) / 976562500) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((857849193 : ℝ) / 976562500) ((888211603561 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((931091 : ℝ) / 200000000000) ((11970683 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((499940128819 : ℝ) / 1000000000000)) - (z7)
  have h8 : RB z8 ((62491019767 : ℝ) / 125000000000) ((124983868341 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((499940128819 : ℝ) / 1000000000000) ((499940128819 : ℝ) / 1000000000000) ((499940128819 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((500059871181 : ℝ) / 1000000000000))
  have h9 : RB z9 ((999736605449 : ℝ) / 1000000000000) ((499875617077 : ℝ) / 500000000000) := rb_div_signed h8 (show RB ((500059871181 : ℝ) / 1000000000000) ((500059871181 : ℝ) / 1000000000000) ((500059871181 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-131714623 : ℝ) / 500000000000) ((-248796793 : ℝ) / 1000000000000) := rb_log h9 (by norm_num) dlower_log_53.1 dlower_log_54.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-116990457 : ℝ) / 500000000000) ((-218552451 : ℝ) / 1000000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((499940128819 : ℝ) / 1000000000000))
  have h12 : RB z12 ((-173316732523 : ℝ) / 250000000000) ((-69326693009 : ℝ) / 100000000000) := rb_log (show RB ((499940128819 : ℝ) / 1000000000000) ((499940128819 : ℝ) / 1000000000000) ((499940128819 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_55.1 dlower_log_55.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((86629118647 : ℝ) / 125000000000) ((693048377641 : ℝ) / 1000000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((2098210337 : ℝ) / 500000000000) ((425561801 : ℝ) / 62500000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((931091 : ℝ) / 200000000000) ((11970683 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((1425574185371 : ℝ) / 1000000000000)) - (z15)
  have h16 : RB z16 ((44548819209 : ℝ) / 31250000000) ((356392382479 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((1425574185371 : ℝ) / 1000000000000) ((1425574185371 : ℝ) / 1000000000000) ((1425574185371 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((425574185371 : ℝ) / 1000000000000))
  have h17 : RB z17 ((837434614041 : ℝ) / 250000000000) ((3349755645243 : ℝ) / 1000000000000) := rb_div_signed h16 (show RB ((425574185371 : ℝ) / 1000000000000) ((425574185371 : ℝ) / 1000000000000) ((425574185371 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((1208882270001 : ℝ) / 1000000000000) ((1208887401459 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_56.1 dlower_log_57.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((530963804033 : ℝ) / 500000000000) ((8589982539 : ℝ) / 8000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((1425574185371 : ℝ) / 1000000000000))
  have h20 : RB z20 ((11080458427 : ℝ) / 31250000000) ((177287334833 : ℝ) / 500000000000) := rb_log (show RB ((1425574185371 : ℝ) / 1000000000000) ((1425574185371 : ℝ) / 1000000000000) ((1425574185371 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_58.1 dlower_log_58.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((884191173 : ℝ) / 1250000000) ((719173147711 : ℝ) / 1000000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((9258204949 : ℝ) / 500000000000) ((16466879443 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((501078825207 : ℝ) / 500000000000) ((501729933719 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1004319956283 : ℝ) / 1000000000000) ((1006931705559 : ℝ) / 1000000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((993116012217 : ℝ) / 500000000000) ((995698625467 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((115704257069 : ℝ) / 125000000000))
  have h26 : RB z26 ((183852400603 : ℝ) / 100000000000) ((1843305115589 : ℝ) / 1000000000000) := rb_widen (rb_mul h25 (show RB ((115704257069 : ℝ) / 125000000000) ((115704257069 : ℝ) / 125000000000) ((115704257069 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((931091 : ℝ) / 200000000000) ((11970683 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((712701741875418725306849 : ℝ) / 1000000000000000000000000))
  have h28 : RB z28 ((3266061 : ℝ) / 500000000000) ((16796203 : ℝ) / 1000000000000) := rb_div_signed h27 (show RB ((712701741875418725306849 : ℝ) / 1000000000000000000000000) ((712701741875418725306849 : ℝ) / 1000000000000000000000000) ((712701741875418725306849 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((999983203797 : ℝ) / 1000000000000) ((499996733939 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1838493125807 : ℝ) / 1000000000000) ((115205817181 : ℝ) / 62500000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((499940128819 : ℝ) / 1000000000000)) ((2098210337 : ℝ) / 500000000000) ((425561801 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((1425574185371 : ℝ) / 1000000000000)) ((9258204949 : ℝ) / 500000000000) ((16466879443 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((499940128819 : ℝ) / 1000000000000)) (wl := ((1425574185371 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1838493125807 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((1425574185371 : ℝ) / 1000000000000) - ((499940128819 : ℝ) / 1000000000000)) * (1 - (tailQ r) ^ 2 / (((1425574185371 : ℝ) / 1000000000000) * ((499940128819 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_6 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((50865455631373331 : ℝ) / 288230376151711744) ((105643638619006149 : ℝ) / 576460752303423488)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((106695330743 : ℝ) / 25000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((105643638619006149 : ℝ) / 576460752303423488) ≤ ((-545665370711 : ℝ) / 100000000000) by norm_num).trans dlower_log_59.1)
  have hql : ((43248342967 : ℝ) / 12500000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_60.2.trans (show ((-5666525003547 : ℝ) / 1000000000000) ≤ -1 / ((50865455631373331 : ℝ) / 288230376151711744) by norm_num))
  have hqr : RB (tailQ r) ((43248342967 : ℝ) / 12500000000000) ((106695330743 : ℝ) / 25000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((1003459867437 : ℝ) / 1000000000000) ((100426781323 : ℝ) / 100000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((690779173 : ℝ) / 200000000000) ((851746389 : ℝ) / 200000000000) := rb_log h1 (by norm_num) dlower_log_61.1 dlower_log_62.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((690779173 : ℝ) / 100000000000) ((851746389 : ℝ) / 100000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((684629716669 : ℝ) / 1000000000000) ((68623938883 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((120820029249 : ℝ) / 1000000000000) ((31440486499 : ℝ) / 250000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((218559513501 : ℝ) / 250000000000) ((879179970751 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((5985341 : ℝ) / 500000000000) ((1821423 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((124292074937 : ℝ) / 250000000000)) - (z7)
  have h8 : RB z8 ((248575042759 : ℝ) / 500000000000) ((248578164533 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((124292074937 : ℝ) / 250000000000) ((124292074937 : ℝ) / 250000000000) ((124292074937 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((125707925063 : ℝ) / 250000000000))
  have h9 : RB z9 ((494350381319 : ℝ) / 500000000000) ((494356589707 : ℝ) / 500000000000) := rb_div_signed h8 (show RB ((125707925063 : ℝ) / 250000000000) ((125707925063 : ℝ) / 250000000000) ((125707925063 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-5681779363 : ℝ) / 500000000000) ((-2837750031 : ℝ) / 250000000000) := rb_log h9 (by norm_num) dlower_log_63.1 dlower_log_64.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-9990613229 : ℝ) / 1000000000000) ((-9923476259 : ℝ) / 1000000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((124292074937 : ℝ) / 250000000000))
  have h12 : RB z12 ((-27953067157 : ℝ) / 40000000000) ((-698826678923 : ℝ) / 1000000000000) := rb_log (show RB ((124292074937 : ℝ) / 250000000000) ((124292074937 : ℝ) / 250000000000) ((124292074937 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_65.1 dlower_log_65.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((344418032847 : ℝ) / 500000000000) ((344451601333 : ℝ) / 500000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((10143269 : ℝ) / 3906250000) ((4273485997 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((5985341 : ℝ) / 500000000000) ((1821423 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((357171640021 : ℝ) / 250000000000)) - (z15)
  have h16 : RB z16 ((714334172927 : ℝ) / 500000000000) ((714337294701 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((357171640021 : ℝ) / 250000000000) ((357171640021 : ℝ) / 250000000000) ((357171640021 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((107171640021 : ℝ) / 250000000000))
  have h17 : RB z17 ((3332664186099 : ℝ) / 1000000000000) ((1666339375233 : ℝ) / 500000000000) := rb_div_signed h16 (show RB ((107171640021 : ℝ) / 250000000000) ((107171640021 : ℝ) / 250000000000) ((107171640021 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((601886020001 : ℝ) / 500000000000) ((601888205091 : ℝ) / 500000000000) := rb_log h17 (by norm_num) dlower_log_66.1 dlower_log_67.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((210476665143 : ℝ) / 200000000000) ((211667221819 : ℝ) / 200000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((357171640021 : ℝ) / 250000000000))
  have h20 : RB z20 ((356755532749 : ℝ) / 1000000000000) ((356755532751 : ℝ) / 1000000000000) := rb_log (show RB ((357171640021 : ℝ) / 250000000000) ((357171640021 : ℝ) / 250000000000) ((357171640021 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_68.1 dlower_log_68.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((173906948241 : ℝ) / 250000000000) ((350790288173 : ℝ) / 500000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((4694202067 : ℝ) / 500000000000) ((16950859677 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((1003459867437 : ℝ) / 1000000000000) ((100426781323 : ℝ) / 100000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((251732926389 : ℝ) / 250000000000) ((100855384069 : ℝ) / 100000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((1983037413879 : ℝ) / 1000000000000) ((1986232024441 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((58219891271 : ℝ) / 62500000000))
  have h26 : RB z26 ((1847235561957 : ℝ) / 1000000000000) ((1850211400031 : ℝ) / 1000000000000) := rb_widen (rb_mul h25 (show RB ((58219891271 : ℝ) / 62500000000) ((58219891271 : ℝ) / 62500000000) ((58219891271 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((5985341 : ℝ) / 500000000000) ((1821423 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((44393604246861320253677 : ℝ) / 62500000000000000000000))
  have h28 : RB z28 ((16853049 : ℝ) / 1000000000000) ((5128619 : ℝ) / 200000000000) := rb_div_signed h27 (show RB ((44393604246861320253677 : ℝ) / 62500000000000000000000) ((44393604246861320253677 : ℝ) / 62500000000000000000000) ((44393604246861320253677 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((199994871381 : ℝ) / 200000000000) ((999983146951 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1847188193119 : ℝ) / 1000000000000) ((231272527291 : ℝ) / 125000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((124292074937 : ℝ) / 250000000000)) ((10143269 : ℝ) / 3906250000) ((4273485997 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((357171640021 : ℝ) / 250000000000)) ((4694202067 : ℝ) / 500000000000) ((16950859677 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((124292074937 : ℝ) / 250000000000)) (wl := ((357171640021 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1847188193119 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((357171640021 : ℝ) / 250000000000) - ((124292074937 : ℝ) / 250000000000)) * (1 - (tailQ r) ^ 2 / (((357171640021 : ℝ) / 250000000000) * ((124292074937 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_7 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((105643638619006149 : ℝ) / 576460752303423488) ((27389091493816409 : ℝ) / 144115188075855872)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((518610047607 : ℝ) / 100000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((27389091493816409 : ℝ) / 144115188075855872) ≤ ((-5261773217571 : ℝ) / 1000000000000) by norm_num).trans dlower_log_69.1)
  have hql : ((426781322967 : ℝ) / 100000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_70.2.trans (show ((-68208171339 : ℝ) / 12500000000) ≤ -1 / ((105643638619006149 : ℝ) / 576460752303423488) by norm_num))
  have hqr : RB (tailQ r) ((426781322967 : ℝ) / 100000000000000) ((518610047607 : ℝ) / 100000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((1004267813229 : ℝ) / 1000000000000) ((1005186100477 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((4258731943 : ℝ) / 1000000000000) ((5172698973 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_71.1 dlower_log_72.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((4258731943 : ℝ) / 500000000000) ((5172698973 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((682801782613 : ℝ) / 1000000000000) ((342314858337 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((62565980843 : ℝ) / 500000000000) ((65056938827 : ℝ) / 500000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((434943061173 : ℝ) / 500000000000) ((437434019157 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((18214229 : ℝ) / 1000000000000) ((26895639 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((99262616499 : ℝ) / 200000000000)) - (z7)
  have h8 : RB z8 ((62035773357 : ℝ) / 125000000000) ((248147434133 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((99262616499 : ℝ) / 200000000000) ((99262616499 : ℝ) / 200000000000) ((99262616499 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((100737383501 : ℝ) / 200000000000))
  have h9 : RB z9 ((24632672083 : ℝ) / 25000000000) ((985324119047 : ℝ) / 1000000000000) := rb_div_signed h8 (show RB ((100737383501 : ℝ) / 200000000000) ((100737383501 : ℝ) / 200000000000) ((100737383501 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-57820819 : ℝ) / 3906250000) ((-7392318533 : ℝ) / 500000000000) := rb_log h9 (by norm_num) dlower_log_73.1 dlower_log_74.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-12949910143 : ℝ) / 1000000000000) ((-12860950607 : ℝ) / 1000000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((99262616499 : ℝ) / 200000000000))
  have h12 : RB z12 ((-350274168341 : ℝ) / 500000000000) ((-17513708417 : ℝ) / 25000000000) := rb_log (show RB ((99262616499 : ℝ) / 200000000000) ((99262616499 : ℝ) / 200000000000) ((99262616499 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_75.1 dlower_log_75.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((687598426537 : ℝ) / 1000000000000) ((27507495443 : ℝ) / 40000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((2968709863 : ℝ) / 1000000000000) ((2442801731 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((18214229 : ℝ) / 1000000000000) ((26895639 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((1426909785291 : ℝ) / 1000000000000)) - (z15)
  have h16 : RB z16 ((356720722413 : ℝ) / 250000000000) ((713445785531 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((1426909785291 : ℝ) / 1000000000000) ((1426909785291 : ℝ) / 1000000000000) ((1426909785291 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((426909785291 : ℝ) / 1000000000000))
  have h17 : RB z17 ((668470453859 : ℝ) / 200000000000) ((835593151191 : ℝ) / 250000000000) := rb_div_signed h16 (show RB ((426909785291 : ℝ) / 1000000000000) ((426909785291 : ℝ) / 1000000000000) ((426909785291 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((301668707837 : ℝ) / 250000000000) ((120668091551 : ℝ) / 100000000000) := rb_log h17 (by norm_num) dlower_log_76.1 dlower_log_77.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1049669689973 : ℝ) / 1000000000000) ((65980410339 : ℝ) / 62500000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((1426909785291 : ℝ) / 1000000000000))
  have h20 : RB z20 ((355511116657 : ℝ) / 1000000000000) ((355511116659 : ℝ) / 1000000000000) := rb_log (show RB ((1426909785291 : ℝ) / 1000000000000) ((1426909785291 : ℝ) / 1000000000000) ((1426909785291 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_78.1 dlower_log_78.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((347079286657 : ℝ) / 500000000000) ((700175448767 : ℝ) / 1000000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((29777677 : ℝ) / 3125000000) ((8686833077 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((1004267813229 : ℝ) / 1000000000000) ((1005186100477 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1008553840687 : ℝ) / 1000000000000) ((1010399096593 : ℝ) / 1000000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((49485396581 : ℝ) / 25000000000) ((991518706943 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((232649175699 : ℝ) / 250000000000))
  have h26 : RB z26 ((1842037875793 : ℝ) / 1000000000000) ((461352019721 : ℝ) / 250000000000) := rb_widen (rb_mul h25 (show RB ((232649175699 : ℝ) / 250000000000) ((232649175699 : ℝ) / 250000000000) ((232649175699 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((18214229 : ℝ) / 1000000000000) ((26895639 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((141638798796010964116209 : ℝ) / 200000000000000000000000))
  have h28 : RB z28 ((803727 : ℝ) / 31250000000) ((7595557 : ℝ) / 200000000000) := rb_div_signed h27 (show RB ((141638798796010964116209 : ℝ) / 200000000000000000000000) ((141638798796010964116209 : ℝ) / 200000000000000000000000) ((141638798796010964116209 : ℝ) / 200000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((199992404443 : ℝ) / 200000000000) ((31249196273 : ℝ) / 31250000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((920983959637 : ℝ) / 500000000000) ((1845360616347 : ℝ) / 1000000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((99262616499 : ℝ) / 200000000000)) ((2968709863 : ℝ) / 1000000000000) ((2442801731 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((1426909785291 : ℝ) / 1000000000000)) ((29777677 : ℝ) / 3125000000) ((8686833077 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((99262616499 : ℝ) / 200000000000)) (wl := ((1426909785291 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((920983959637 : ℝ) / 500000000000) ≤ D0q (tailQ r) * (((1426909785291 : ℝ) / 1000000000000) - ((99262616499 : ℝ) / 200000000000)) * (1 - (tailQ r) ^ 2 / (((1426909785291 : ℝ) / 1000000000000) * ((99262616499 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
