import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk04
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_12 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((295461162363851197619434218428825 : ℝ) / 5192296858534827628530496329220096) ((150717774468351416825792892711731 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((56903749999 : ℝ) / 1000000000000) ((92887 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1056903749999 : ℝ) / 1000000000000) ((1692887 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((27671821569 : ℝ) / 500000000000) ((3526982891 : ℝ) / 62500000000) := rb_log h1 (by norm_num) dlower_log_279.1 dlower_log_280.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((27671821569 : ℝ) / 250000000000) ((3526982891 : ℝ) / 31250000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((580283728047 : ℝ) / 1000000000000) ((145614973571 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2866394034943 : ℝ) / 1000000000000) ((-2846375207613 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_281.1 dlower_log_282.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2846375207613 : ℝ) / 1000000000000) ((2866394034943 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((202443809529 : ℝ) / 1000000000000) ((204632155567 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((795367844433 : ℝ) / 1000000000000) ((797556190471 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3238036763 : ℝ) / 1000000000000) ((3370310457 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((80227920859 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((198884646919 : ℝ) / 500000000000) ((99475391883 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((80227920859 : ℝ) / 200000000000) ((80227920859 : ℝ) / 200000000000) ((80227920859 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((119772079141 : ℝ) / 200000000000))
  have h11 : RB z11 ((332105192371 : ℝ) / 500000000000) ((664431260417 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((119772079141 : ℝ) / 200000000000) ((119772079141 : ℝ) / 200000000000) ((119772079141 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-511445419 : ℝ) / 1250000000) ((-408823851751 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_283.1 dlower_log_284.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-32632516801 : ℝ) / 100000000000) ((-325165345719 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((80227920859 : ℝ) / 200000000000))
  have h14 : RB z14 ((-228361442969 : ℝ) / 250000000000) ((-456722885937 : ℝ) / 500000000000) := rb_log (show RB ((80227920859 : ℝ) / 200000000000) ((80227920859 : ℝ) / 200000000000) ((80227920859 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_285.1 dlower_log_285.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((73390075483 : ℝ) / 125000000000) ((588280426157 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((233035479 : ℝ) / 50000000000) ((799669811 : ℝ) / 100000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3238036763 : ℝ) / 1000000000000) ((3370310457 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1434137478923 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((715383584233 : ℝ) / 500000000000) ((17886243027 : ℝ) / 12500000000) := rb_widen (rb_sub (show RB ((1434137478923 : ℝ) / 1000000000000) ((1434137478923 : ℝ) / 1000000000000) ((1434137478923 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((434137478923 : ℝ) / 1000000000000))
  have h19 : RB z19 ((329565457471 : ℝ) / 100000000000) ((1647979628147 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((434137478923 : ℝ) / 1000000000000) ((434137478923 : ℝ) / 1000000000000) ((434137478923 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((149075600649 : ℝ) / 125000000000) ((119269725041 : ℝ) / 100000000000) := rb_log h19 (by norm_num) dlower_log_286.1 dlower_log_287.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((189711902633 : ℝ) / 200000000000) ((951243075423 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1434137478923 : ℝ) / 1000000000000))
  have h22 : RB z22 ((360563608517 : ℝ) / 1000000000000) ((360563608519 : ℝ) / 1000000000000) := rb_log (show RB ((1434137478923 : ℝ) / 1000000000000) ((1434137478923 : ℝ) / 1000000000000) ((1434137478923 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_288.1 dlower_log_288.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((293997952323 : ℝ) / 500000000000) ((295339733453 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2768005181 : ℝ) / 500000000000) ((10395738859 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1056903749999 : ℝ) / 1000000000000) ((1692887 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1117045536761 : ℝ) / 1000000000000) ((1119479060457 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((357309050369 : ℝ) / 200000000000) ((895218652321 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((258249468657 : ℝ) / 250000000000))
  have h28 : RB z28 ((922748724041 : ℝ) / 500000000000) ((36990358607 : ℝ) / 20000000000) := rb_widen (rb_mul h27 (show RB ((258249468657 : ℝ) / 250000000000) ((258249468657 : ℝ) / 250000000000) ((258249468657 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3238036763 : ℝ) / 1000000000000) ((3370310457 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((115057868159960224554857 : ℝ) / 200000000000000000000000))
  have h30 : RB z30 ((1407133999 : ℝ) / 250000000000) ((1171692301 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((115057868159960224554857 : ℝ) / 200000000000000000000000) ((115057868159960224554857 : ℝ) / 200000000000000000000000) ((115057868159960224554857 : ℝ) / 200000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((198828307699 : ℝ) / 200000000000) ((248592866001 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((458671418081 : ℝ) / 250000000000) ((229888481513 : ℝ) / 125000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((80227920859 : ℝ) / 200000000000)) ((233035479 : ℝ) / 50000000000) ((799669811 : ℝ) / 100000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1434137478923 : ℝ) / 1000000000000)) ((2768005181 : ℝ) / 500000000000) ((10395738859 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((80227920859 : ℝ) / 200000000000)) (wl := ((1434137478923 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((458671418081 : ℝ) / 250000000000) ≤ D0q (q) * (((1434137478923 : ℝ) / 1000000000000) - ((80227920859 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((1434137478923 : ℝ) / 1000000000000) * ((80227920859 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_13 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((150717774468351416825792892711731 : ℝ) / 2596148429267413814265248164610048) ((307409935509554469683737352418099 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((58054374999 : ℝ) / 1000000000000) ((11841 : ℝ) / 200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1058054374999 : ℝ) / 1000000000000) ((211841 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((28215863127 : ℝ) / 500000000000) ((28759313367 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_289.1 dlower_log_290.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((28215863127 : ℝ) / 250000000000) ((28759313367 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((578109927091 : ℝ) / 1000000000000) ((145070932013 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-177898450477 : ℝ) / 62500000000) ((-1413374640599 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_291.1 dlower_log_292.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1413374640599 : ℝ) / 500000000000) ((177898450477 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((203103907573 : ℝ) / 1000000000000) ((205283054961 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((794716945039 : ℝ) / 1000000000000) ((796896092427 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((421288807 : ℝ) / 125000000000) ((140209281 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((398573480269 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((98767062061 : ℝ) / 250000000000) ((395203169813 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((398573480269 : ℝ) / 1000000000000) ((398573480269 : ℝ) / 1000000000000) ((398573480269 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((601426519731 : ℝ) / 1000000000000))
  have h11 : RB z11 ((656885313971 : ℝ) / 1000000000000) ((657109649887 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((601426519731 : ℝ) / 1000000000000) ((601426519731 : ℝ) / 1000000000000) ((601426519731 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-420245835901 : ℝ) / 1000000000000) ((-13122011863 : ℝ) / 31250000000) := rb_log h11 (by norm_num) dlower_log_293.1 dlower_log_294.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-334892264489 : ℝ) / 1000000000000) ((-20856570361 : ℝ) / 62500000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((398573480269 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-114982925701 : ℝ) / 125000000000) ((-459931702803 : ℝ) / 500000000000) := rb_log (show RB ((398573480269 : ℝ) / 1000000000000) ((398573480269 : ℝ) / 1000000000000) ((398573480269 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_295.1 dlower_log_295.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((584971141117 : ℝ) / 1000000000000) ((73269784979 : ℝ) / 125000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((937482613 : ℝ) / 200000000000) ((8048352741 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((421288807 : ℝ) / 125000000000) ((140209281 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((717406181243 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1431307130461 : ℝ) / 1000000000000) ((143144205203 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((717406181243 : ℝ) / 500000000000) ((717406181243 : ℝ) / 500000000000) ((717406181243 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((217406181243 : ℝ) / 500000000000))
  have h19 : RB z19 ((3291781131239 : ℝ) / 1000000000000) ((1646045714807 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((217406181243 : ℝ) / 500000000000) ((217406181243 : ℝ) / 500000000000) ((217406181243 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((29785719889 : ℝ) / 25000000000) ((1191523055703 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_296.1 dlower_log_297.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((473424326319 : ℝ) / 500000000000) ((949520067127 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((717406181243 : ℝ) / 500000000000))
  have h22 : RB z22 ((361034082811 : ℝ) / 1000000000000) ((361034082813 : ℝ) / 1000000000000) := rb_log (show RB ((717406181243 : ℝ) / 500000000000) ((717406181243 : ℝ) / 500000000000) ((717406181243 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_298.1 dlower_log_298.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((23432582793 : ℝ) / 40000000000) ((147121496079 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5530841773 : ℝ) / 1000000000000) ((415042289 : ℝ) / 40000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1058054374999 : ℝ) / 1000000000000) ((211841 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((559739530227 : ℝ) / 500000000000) ((44876609281 : ℝ) / 40000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1782665876093 : ℝ) / 1000000000000) ((1786545251851 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1036238882217 : ℝ) / 1000000000000))
  have h28 : RB z28 ((230908461851 : ℝ) / 125000000000) ((1851287654809 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1036238882217 : ℝ) / 1000000000000) ((1036238882217 : ℝ) / 1000000000000) ((1036238882217 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((421288807 : ℝ) / 125000000000) ((140209281 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((285939078424515498394367 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((1473351629 : ℝ) / 250000000000) ((6129333641 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((285939078424515498394367 : ℝ) / 500000000000000000000000) ((285939078424515498394367 : ℝ) / 500000000000000000000000) ((285939078424515498394367 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((993870666359 : ℝ) / 1000000000000) ((248526648371 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((917972587391 : ℝ) / 500000000000) ((920188632041 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((398573480269 : ℝ) / 1000000000000)) ((937482613 : ℝ) / 200000000000) ((8048352741 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((717406181243 : ℝ) / 500000000000)) ((5530841773 : ℝ) / 1000000000000) ((415042289 : ℝ) / 40000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((398573480269 : ℝ) / 1000000000000)) (wl := ((717406181243 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((917972587391 : ℝ) / 500000000000) ≤ D0q (q) * (((717406181243 : ℝ) / 500000000000) - ((398573480269 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((717406181243 : ℝ) / 500000000000) * ((398573480269 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_14 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((307409935509554469683737352418099 : ℝ) / 5192296858534827628530496329220096) ((313384322082406105715888919412735 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((59204999999 : ℝ) / 1000000000000) ((96569 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1059204999999 : ℝ) / 1000000000000) ((1696569 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((14379656683 : ℝ) / 250000000000) ((29302173571 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_299.1 dlower_log_300.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((14379656683 : ℝ) / 125000000000) ((29302173571 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((23037539451 : ℝ) / 40000000000) ((72263740887 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2826749281217 : ℝ) / 1000000000000) ((-701875282371 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_301.1 dlower_log_302.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((701875282371 : ℝ) / 250000000000) ((2826749281217 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((325993389 : ℝ) / 1600000000) ((51479046707 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((198520953293 : ℝ) / 250000000000) ((1274006611 : ℝ) / 1600000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((438154003 : ℝ) / 125000000000) ((364280147 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((197993194669 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((98085896967 : ℝ) / 250000000000) ((196240578657 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((197993194669 : ℝ) / 500000000000) ((197993194669 : ℝ) / 500000000000) ((197993194669 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((302006805331 : ℝ) / 500000000000))
  have h11 : RB z11 ((649560839263 : ℝ) / 1000000000000) ((129957719623 : ℝ) / 200000000000) := rb_div_signed h10 (show RB ((302006805331 : ℝ) / 500000000000) ((302006805331 : ℝ) / 500000000000) ((302006805331 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-215729388169 : ℝ) / 500000000000) ((-21555410133 : ℝ) / 50000000000) := rb_log h11 (by norm_num) dlower_log_303.1 dlower_log_304.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-343550833393 : ℝ) / 1000000000000) ((-342336045457 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((197993194669 : ℝ) / 500000000000))
  have h14 : RB z14 ((-926375438677 : ℝ) / 1000000000000) ((-37055017547 : ℝ) / 40000000000) := rb_log (show RB ((197993194669 : ℝ) / 500000000000) ((197993194669 : ℝ) / 500000000000) ((197993194669 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_305.1 dlower_log_305.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((291412302641 : ℝ) / 500000000000) ((29201969661 : ℝ) / 50000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2357339093 : ℝ) / 500000000000) ((1620181389 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((438154003 : ℝ) / 125000000000) ((364280147 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1435497787779 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1431854986309 : ℝ) / 1000000000000) ((286398511151 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((1435497787779 : ℝ) / 1000000000000) ((1435497787779 : ℝ) / 1000000000000) ((1435497787779 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((435497787779 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3287858231407 : ℝ) / 1000000000000) ((3288174121523 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((435497787779 : ℝ) / 1000000000000) ((435497787779 : ℝ) / 1000000000000) ((435497787779 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((595118179647 : ℝ) / 500000000000) ((59516621623 : ℝ) / 50000000000) := rb_log h19 (by norm_num) dlower_log_306.1 dlower_log_307.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((236286856691 : ℝ) / 250000000000) ((236951779413 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1435497787779 : ℝ) / 1000000000000))
  have h22 : RB z22 ((45188959937 : ℝ) / 125000000000) ((180755839749 : ℝ) / 500000000000) := rb_log (show RB ((1435497787779 : ℝ) / 1000000000000) ((1435497787779 : ℝ) / 1000000000000) ((1435497787779 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_308.1 dlower_log_308.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((291817873633 : ℝ) / 500000000000) ((146573859539 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((552582017 : ℝ) / 100000000000) ((10356951881 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1059204999999 : ℝ) / 1000000000000) ((1696569 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((560957616011 : ℝ) / 500000000000) ((112435405147 : ℝ) / 100000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((88939956119 : ℝ) / 50000000000) ((891332938049 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1039511398441 : ℝ) / 1000000000000))
  have h28 : RB z28 ((7396327853 : ℝ) / 4000000000) ((231637687227 : ℝ) / 125000000000) := rb_widen (rb_mul h27 (show RB ((1039511398441 : ℝ) / 1000000000000) ((1039511398441 : ℝ) / 1000000000000) ((1039511398441 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((438154003 : ℝ) / 125000000000) ((364280147 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((284218792942646396150151 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((1233286507 : ℝ) / 200000000000) ((3204222909 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((284218792942646396150151 : ℝ) / 500000000000000000000000) ((284218792942646396150151 : ℝ) / 500000000000000000000000) ((284218792942646396150151 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((496795777091 : ℝ) / 500000000000) ((198766713493 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((73489288867 : ℝ) / 40000000000) ((36833489449 : ℝ) / 20000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((197993194669 : ℝ) / 500000000000)) ((2357339093 : ℝ) / 500000000000) ((1620181389 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1435497787779 : ℝ) / 1000000000000)) ((552582017 : ℝ) / 100000000000) ((10356951881 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((197993194669 : ℝ) / 500000000000)) (wl := ((1435497787779 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((73489288867 : ℝ) / 40000000000) ≤ D0q (q) * (((1435497787779 : ℝ) / 1000000000000) - ((197993194669 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((1435497787779 : ℝ) / 1000000000000) * ((197993194669 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_15 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((313384322082406105715888919412735 : ℝ) / 5192296858534827628530496329220096) ((79839677163814435437010121601843 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((60355624999 : ℝ) / 1000000000000) ((9841 : ℝ) / 160000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1060355624999 : ℝ) / 1000000000000) ((169841 : ℝ) / 160000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((2930217357 : ℝ) / 50000000000) ((59688890039 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_309.1 dlower_log_310.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((2930217357 : ℝ) / 25000000000) ((59688890039 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((573769400481 : ℝ) / 1000000000000) ((14398462157 : ℝ) / 25000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2807501129503 : ℝ) / 1000000000000) ((-697154120829 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_311.1 dlower_log_312.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((697154120829 : ℝ) / 250000000000) ((2807501129503 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((204370140567 : ℝ) / 1000000000000) ((25816497613 : ℝ) / 125000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((99183502387 : ℝ) / 125000000000) ((795629859433 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3642801469 : ℝ) / 1000000000000) ((378301879 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((78675642237 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((77919038479 : ℝ) / 200000000000) ((97433852429 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((78675642237 : ℝ) / 200000000000) ((78675642237 : ℝ) / 200000000000) ((78675642237 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((121324357763 : ℝ) / 200000000000))
  have h11 : RB z11 ((642237386751 : ℝ) / 1000000000000) ((642468531303 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((121324357763 : ℝ) / 200000000000) ((121324357763 : ℝ) / 200000000000) ((121324357763 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-442797282343 : ℝ) / 1000000000000) ((-55304680241 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_313.1 dlower_log_314.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-88075684877 : ℝ) / 250000000000) ((-17552998031 : ℝ) / 50000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((78675642237 : ℝ) / 200000000000))
  have h14 : RB z14 ((-932983760467 : ℝ) / 1000000000000) ((-186596752093 : ℝ) / 200000000000) := rb_log (show RB ((78675642237 : ℝ) / 200000000000) ((78675642237 : ℝ) / 200000000000) ((78675642237 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_315.1 dlower_log_315.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((580681020957 : ℝ) / 1000000000000) ((581923799847 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((4742534677 : ℝ) / 1000000000000) ((4077199683 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3642801469 : ℝ) / 1000000000000) ((378301879 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((718096765603 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((44762828513 : ℝ) / 31250000000) ((1432550729737 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((718096765603 : ℝ) / 500000000000) ((718096765603 : ℝ) / 500000000000) ((718096765603 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((218096765603 : ℝ) / 500000000000))
  have h19 : RB z19 ((3283887563521 : ℝ) / 1000000000000) ((1642104510097 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((218096765603 : ℝ) / 500000000000) ((218096765603 : ℝ) / 500000000000) ((218096765603 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((594513976671 : ℝ) / 500000000000) ((237825167523 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_316.1 dlower_log_317.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((235863913697 : ℝ) / 250000000000) ((94610402303 : ℝ) / 100000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((718096765603 : ℝ) / 500000000000))
  have h22 : RB z22 ((361996232579 : ℝ) / 1000000000000) ((361996232581 : ℝ) / 1000000000000) := rb_log (show RB ((718096765603 : ℝ) / 500000000000) ((718096765603 : ℝ) / 500000000000) ((718096765603 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_318.1 dlower_log_318.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((581459422207 : ℝ) / 1000000000000) ((584107790451 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5520935927 : ℝ) / 1000000000000) ((1033838997 : ℝ) / 100000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1060355624999 : ℝ) / 1000000000000) ((169841 : ℝ) / 160000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1124354051467 : ℝ) / 1000000000000) ((112679551879 : ℝ) / 100000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((887472468007 : ℝ) / 500000000000) ((889399561193 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1042815320021 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1850939771469 : ℝ) / 1000000000000) ((370991795213 : ℝ) / 200000000000) := rb_widen (rb_mul h27 (show RB ((1042815320021 : ℝ) / 1000000000000) ((1042815320021 : ℝ) / 1000000000000) ((1042815320021 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3642801469 : ℝ) / 1000000000000) ((378301879 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((56496724222128475573911 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((6447810061 : ℝ) / 1000000000000) ((6695996701 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((56496724222128475573911 : ℝ) / 100000000000000000000000) ((56496724222128475573911 : ℝ) / 100000000000000000000000) ((56496724222128475573911 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((993304003299 : ℝ) / 1000000000000) ((993552189939 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((367709176973 : ℝ) / 200000000000) ((1842998552917 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((78675642237 : ℝ) / 200000000000)) ((4742534677 : ℝ) / 1000000000000) ((4077199683 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((718096765603 : ℝ) / 500000000000)) ((5520935927 : ℝ) / 1000000000000) ((1033838997 : ℝ) / 100000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((78675642237 : ℝ) / 200000000000)) (wl := ((718096765603 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((367709176973 : ℝ) / 200000000000) ≤ D0q (q) * (((718096765603 : ℝ) / 500000000000) - ((78675642237 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((718096765603 : ℝ) / 500000000000) * ((78675642237 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
