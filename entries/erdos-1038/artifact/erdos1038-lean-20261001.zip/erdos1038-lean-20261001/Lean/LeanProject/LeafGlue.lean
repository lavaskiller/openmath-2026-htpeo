import LeanProject.Stage8

/-!
# EP-1038: glue between `leaf_sound` and the acceptance conditions of `cert/check.py` (Lean RED L-20)

From the Lean RED Review 4 scratch file: check.py's ordering `a_k < b_k ≤ a_{k+1}` implies the
pairwise disjointness assumed by `leaf_sound` (`disjoint_of_order`), and the full acceptance test
(ordering, `P(B,J) < 1`, `∑ |J| ≥ T`) implies `|S(r)| ≥ T` on the box (`leaf_check_sound`).
`scaled_check_iff` shows that check.py's integer-scaled product test is equivalent to the real one.
-/

open Real MeasureTheory

namespace EP1038

theorem chain_le {m : ℕ} (a b : Fin m → ℝ) (hab : ∀ j, a j < b j)
    (hord : ∀ (j : ℕ) (h : j + 1 < m), b ⟨j, by omega⟩ ≤ a ⟨j + 1, h⟩) :
    ∀ j k : Fin m, j < k → b j ≤ a k := by
  intro j k hjk
  obtain ⟨j, hj⟩ := j
  obtain ⟨k, hk⟩ := k
  simp only [Fin.mk_lt_mk] at hjk
  induction k with
  | zero => omega
  | succ k ih =>
    rcases Nat.lt_succ_iff_lt_or_eq.mp hjk with h | h
    · have h1 := ih (by omega) h
      have h2 := hab ⟨k, by omega⟩
      have h3 := hord k hk
      linarith
    · subst h
      exact hord j hk

theorem disjoint_of_order {m : ℕ} (a b : Fin m → ℝ) (hab : ∀ j, a j < b j)
    (hord : ∀ (j : ℕ) (h : j + 1 < m), b ⟨j, by omega⟩ ≤ a ⟨j + 1, h⟩) :
    Pairwise (Function.onFun Disjoint fun j => Set.Ioo (a j) (b j)) := by
  intro j k hjk
  simp only [Function.onFun]
  rw [Set.disjoint_left]
  rcases lt_or_gt_of_ne hjk with h | h
  · have := chain_le a b hab hord j k h
    rintro x ⟨_, hx1⟩ ⟨hx2, _⟩
    linarith
  · have := chain_le a b hab hord k j h
    rintro x ⟨hx1, _⟩ ⟨_, hx2⟩
    linarith

/-- `leaf_sound` restated with exactly the acceptance conditions of `check_P` (real form):
`a_k < b_k`, `b_k ≤ a_{k+1}`, `P(B,J_k) < 1`, `∑ |J_k| ≥ T`  ⇒  `L(r) ≥ T` on the box. -/
theorem leaf_check_sound {n m : ℕ} (l u r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (l i) (u i))
    (a b : Fin m → ℝ) (hab : ∀ j, a j < b j)
    (hord : ∀ (j : ℕ) (h : j + 1 < m), b ⟨j, by omega⟩ ≤ a ⟨j + 1, h⟩)
    (hP : ∀ j, ∏ i, max (max |a j - l i| |a j - u i|) (max |b j - l i| |b j - u i|) < 1)
    (T : ℝ) (hT : T ≤ ∑ j, (b j - a j)) :
    ENNReal.ofReal T ≤ volume (sublevel r) := by
  have h := leaf_sound l u r hr a b (disjoint_of_order a b hab hord) hP
  calc ENNReal.ofReal T ≤ ENNReal.ofReal (∑ j, (b j - a j)) := ENNReal.ofReal_le_ofReal hT
    _ = ∑ j, ENNReal.ofReal (b j - a j) :=
        ENNReal.ofReal_sum_of_nonneg (fun j _ => by linarith [hab j])
    _ ≤ _ := h

/-- check.py's integer product test: after scaling every coordinate by `s = 2^K > 0`, the test
`p < scale^n` is equivalent to the real test `P(B,J) < 1`. -/
theorem scaled_check_iff {n : ℕ} (s : ℝ) (hs : 0 < s) (A B : ℝ) (L U : Fin n → ℝ) :
    (∏ i, max (max |s * A - s * L i| |s * A - s * U i|) (max |s * B - s * L i| |s * B - s * U i|)
        < s ^ n) ↔
    (∏ i, max (max |A - L i| |A - U i|) (max |B - L i| |B - U i|) < 1) := by
  have key : ∀ x y : ℝ, |s * x - s * y| = s * |x - y| := by
    intro x y; rw [← mul_sub, abs_mul, abs_of_pos hs]
  simp only [key, ← mul_max_of_nonneg _ _ hs.le]
  rw [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
  exact mul_lt_iff_lt_one_right (pow_pos hs n)


end EP1038