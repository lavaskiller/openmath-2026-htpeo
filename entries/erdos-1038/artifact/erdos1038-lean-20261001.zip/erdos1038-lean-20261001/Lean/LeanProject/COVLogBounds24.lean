import LeanProject.COVLogTwo
import LeanProject.COVLogBounds20
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1920 : RB (Real.log ((11880219 : ℝ) / 3125000)) ((66772023 : ℝ) / 50000000) ((133544049 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11880219 : ℝ) / 12500000)) (t := ((-619781 : ℝ) / 24380219))
    (lo := ((-508539 : ℝ) / 10000000)) (hi := ((-5085389 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11880219 : ℝ) / 3125000) = Real.log ((11880219 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((11880219 : ℝ) / 3125000) = ((11880219 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1921 : RB (Real.log ((33917061 : ℝ) / 25000000)) ((30504233 : ℝ) / 100000000) ((6100847 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((33917061 : ℝ) / 50000000)) (t := ((-16082939 : ℝ) / 83917061))
    (lo := ((-7762097 : ℝ) / 20000000)) (hi := ((-9702621 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33917061 : ℝ) / 25000000) = Real.log ((33917061 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33917061 : ℝ) / 25000000) = ((33917061 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1922 : RB (Real.log ((6662837 : ℝ) / 25000000)) ((-16529131 : ℝ) / 12500000) ((-26446609 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((6662837 : ℝ) / 6250000)) (t := ((412837 : ℝ) / 12912837))
    (lo := ((639639 : ℝ) / 10000000)) (hi := ((6396391 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6662837 : ℝ) / 25000000) = Real.log ((6662837 : ℝ) / 6250000) - 2 * Real.log 2 := by
    rw [show ((6662837 : ℝ) / 25000000) = ((6662837 : ℝ) / 6250000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1923 : RB (Real.log ((3178937 : ℝ) / 10000000)) ((-4584153 : ℝ) / 4000000) ((-57301911 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3178937 : ℝ) / 2500000)) (t := ((678937 : ℝ) / 5678937))
    (lo := ((24025613 : ℝ) / 100000000)) (hi := ((12012807 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3178937 : ℝ) / 10000000) = Real.log ((3178937 : ℝ) / 2500000) - 2 * Real.log 2 := by
    rw [show ((3178937 : ℝ) / 10000000) = ((3178937 : ℝ) / 2500000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1924 : RB (Real.log ((72261163 : ℝ) / 100000000)) ((-32488337 : ℝ) / 100000000) ((-2030521 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((72261163 : ℝ) / 100000000)) (t := ((-27738837 : ℝ) / 172261163))
    (lo := ((-32488337 : ℝ) / 100000000)) (hi := ((-2030521 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1925 : RB (Real.log ((36130583 : ℝ) / 50000000)) ((-32488333 : ℝ) / 100000000) ((-8122083 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((36130583 : ℝ) / 50000000)) (t := ((-13869417 : ℝ) / 86130583))
    (lo := ((-32488333 : ℝ) / 100000000)) (hi := ((-8122083 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1926 : RB (Real.log ((10497217 : ℝ) / 25000000)) ((-43388283 : ℝ) / 50000000) ((-21694141 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((10497217 : ℝ) / 12500000)) (t := ((-2002783 : ℝ) / 22997217))
    (lo := ((-17461847 : ℝ) / 100000000)) (hi := ((-8730923 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10497217 : ℝ) / 25000000) = Real.log ((10497217 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10497217 : ℝ) / 25000000) = ((10497217 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1927 : RB (Real.log ((75197959 : ℝ) / 100000000)) ((-2850461 : ℝ) / 10000000) ((-28504609 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((75197959 : ℝ) / 100000000)) (t := ((-24802041 : ℝ) / 175197959))
    (lo := ((-2850461 : ℝ) / 10000000)) (hi := ((-28504609 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1928 : RB (Real.log ((37598981 : ℝ) / 50000000)) ((-14252303 : ℝ) / 50000000) ((-5700921 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((37598981 : ℝ) / 50000000)) (t := ((-12401019 : ℝ) / 87598981))
    (lo := ((-14252303 : ℝ) / 50000000)) (hi := ((-5700921 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1929 : RB (Real.log ((42961293 : ℝ) / 100000000)) ((-16897413 : ℝ) / 20000000) ((-84487063 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42961293 : ℝ) / 50000000)) (t := ((-7038707 : ℝ) / 92961293))
    (lo := ((-7586173 : ℝ) / 50000000)) (hi := ((-3034469 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42961293 : ℝ) / 100000000) = Real.log ((42961293 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42961293 : ℝ) / 100000000) = ((42961293 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1930 : RB (Real.log ((38582343 : ℝ) / 10000000)) ((33755241 : ℝ) / 25000000) ((135020967 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38582343 : ℝ) / 40000000)) (t := ((-1417657 : ℝ) / 78582343))
    (lo := ((-451059 : ℝ) / 12500000)) (hi := ((-3608471 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38582343 : ℝ) / 10000000) = Real.log ((38582343 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((38582343 : ℝ) / 10000000) = ((38582343 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1931 : RB (Real.log ((192911717 : ℝ) / 50000000)) ((27004193 : ℝ) / 20000000) ((16877621 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((192911717 : ℝ) / 200000000)) (t := ((-7088283 : ℝ) / 392911717))
    (lo := ((-3608471 : ℝ) / 100000000)) (hi := ((-360847 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192911717 : ℝ) / 50000000) = Real.log ((192911717 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((192911717 : ℝ) / 50000000) = ((192911717 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1932 : RB (Real.log ((33740593 : ℝ) / 25000000)) ((14991291 : ℝ) / 50000000) ((3747823 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((33740593 : ℝ) / 50000000)) (t := ((-16259407 : ℝ) / 83740593))
    (lo := ((-4916517 : ℝ) / 12500000)) (hi := ((-7866427 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33740593 : ℝ) / 25000000) = Real.log ((33740593 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33740593 : ℝ) / 25000000) = ((33740593 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1933 : RB (Real.log ((11799633 : ℝ) / 3125000)) ((66431707 : ℝ) / 50000000) ((132863417 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11799633 : ℝ) / 12500000)) (t := ((-700367 : ℝ) / 24299633))
    (lo := ((-2883011 : ℝ) / 50000000)) (hi := ((-5766021 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11799633 : ℝ) / 3125000) = Real.log ((11799633 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((11799633 : ℝ) / 3125000) = ((11799633 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1934 : RB (Real.log ((18879413 : ℝ) / 5000000)) ((26572683 : ℝ) / 20000000) ((66431709 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18879413 : ℝ) / 20000000)) (t := ((-1120587 : ℝ) / 38879413))
    (lo := ((-5766021 : ℝ) / 100000000)) (hi := ((-288301 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((18879413 : ℝ) / 5000000) = Real.log ((18879413 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((18879413 : ℝ) / 5000000) = ((18879413 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1935 : RB (Real.log ((33999899 : ℝ) / 25000000)) ((7687043 : ℝ) / 25000000) ((15374087 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((33999899 : ℝ) / 50000000)) (t := ((-16000101 : ℝ) / 83999899))
    (lo := ((-19283273 : ℝ) / 50000000)) (hi := ((-7713309 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33999899 : ℝ) / 25000000) = Real.log ((33999899 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33999899 : ℝ) / 25000000) = ((33999899 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1936 : RB (Real.log ((29604189 : ℝ) / 100000000)) ((-60862717 : ℝ) / 50000000) ((-121725431 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((29604189 : ℝ) / 25000000)) (t := ((4604189 : ℝ) / 54604189))
    (lo := ((4226001 : ℝ) / 25000000)) (hi := ((3380801 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((29604189 : ℝ) / 100000000) = Real.log ((29604189 : ℝ) / 25000000) - 2 * Real.log 2 := by
    rw [show ((29604189 : ℝ) / 100000000) = ((29604189 : ℝ) / 25000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1937 : RB (Real.log ((34382579 : ℝ) / 100000000)) ((-106762019 : ℝ) / 100000000) ((-106762017 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((34382579 : ℝ) / 50000000)) (t := ((-15617421 : ℝ) / 84382579))
    (lo := ((-374473 : ℝ) / 1000000)) (hi := ((-37447299 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34382579 : ℝ) / 100000000) = Real.log ((34382579 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((34382579 : ℝ) / 100000000) = ((34382579 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1938 : RB (Real.log ((36678883 : ℝ) / 50000000)) ((-15491091 : ℝ) / 50000000) ((-30982181 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36678883 : ℝ) / 50000000)) (t := ((-13321117 : ℝ) / 86678883))
    (lo := ((-15491091 : ℝ) / 50000000)) (hi := ((-30982181 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1939 : RB (Real.log ((73357769 : ℝ) / 100000000)) ((-15491089 : ℝ) / 50000000) ((-30982177 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((73357769 : ℝ) / 100000000)) (t := ((-26642231 : ℝ) / 173357769))
    (lo := ((-15491089 : ℝ) / 50000000)) (hi := ((-30982177 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1940 : RB (Real.log ((42355827 : ℝ) / 100000000)) ((-4295321 : ℝ) / 5000000) ((-42953209 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42355827 : ℝ) / 50000000)) (t := ((-7644173 : ℝ) / 92355827))
    (lo := ((-16591701 : ℝ) / 100000000)) (hi := ((-165917 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42355827 : ℝ) / 100000000) = Real.log ((42355827 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42355827 : ℝ) / 100000000) = ((42355827 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1941 : RB (Real.log ((607469 : ℝ) / 800000)) ((-27531059 : ℝ) / 100000000) ((-13765529 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((607469 : ℝ) / 800000)) (t := ((-192531 : ℝ) / 1407469))
    (lo := ((-27531059 : ℝ) / 100000000)) (hi := ((-13765529 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1942 : RB (Real.log ((75933627 : ℝ) / 100000000)) ((-1720691 : ℝ) / 6250000) ((-5506211 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((75933627 : ℝ) / 100000000)) (t := ((-24066373 : ℝ) / 175933627))
    (lo := ((-1720691 : ℝ) / 6250000)) (hi := ((-5506211 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1943 : RB (Real.log ((215999 : ℝ) / 500000)) ((-83933433 : ℝ) / 100000000) ((-83933431 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((215999 : ℝ) / 250000)) (t := ((-34001 : ℝ) / 465999))
    (lo := ((-7309357 : ℝ) / 50000000)) (hi := ((-14618713 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((215999 : ℝ) / 500000) = Real.log ((215999 : ℝ) / 250000) - 1 * Real.log 2 := by
    rw [show ((215999 : ℝ) / 500000) = ((215999 : ℝ) / 250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1944 : RB (Real.log ((191458049 : ℝ) / 50000000)) ((134264571 : ℝ) / 100000000) ((67132287 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((191458049 : ℝ) / 200000000)) (t := ((-8541951 : ℝ) / 391458049))
    (lo := ((-872973 : ℝ) / 20000000)) (hi := ((-68201 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((191458049 : ℝ) / 50000000) = Real.log ((191458049 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((191458049 : ℝ) / 50000000) = ((191458049 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1945 : RB (Real.log ((191458051 : ℝ) / 50000000)) ((33566143 : ℝ) / 25000000) ((5370583 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((191458051 : ℝ) / 200000000)) (t := ((-8541949 : ℝ) / 391458051))
    (lo := ((-68201 : ℝ) / 1562500)) (hi := ((-4364863 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((191458051 : ℝ) / 50000000) = Real.log ((191458051 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((191458051 : ℝ) / 50000000) = ((191458051 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1946 : RB (Real.log ((16915207 : ℝ) / 12500000)) ((30248439 : ℝ) / 100000000) ((30248441 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16915207 : ℝ) / 25000000)) (t := ((-8084793 : ℝ) / 41915207))
    (lo := ((-39066279 : ℝ) / 100000000)) (hi := ((-19533139 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16915207 : ℝ) / 12500000) = Real.log ((16915207 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((16915207 : ℝ) / 12500000) = ((16915207 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1947 : RB (Real.log ((75030543 : ℝ) / 20000000)) ((132216299 : ℝ) / 100000000) ((66108151 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((75030543 : ℝ) / 80000000)) (t := ((-4969457 : ℝ) / 155030543))
    (lo := ((-6413137 : ℝ) / 100000000)) (hi := ((-400821 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((75030543 : ℝ) / 20000000) = Real.log ((75030543 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((75030543 : ℝ) / 20000000) = ((75030543 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1948 : RB (Real.log ((187576359 : ℝ) / 50000000)) ((1322163 : ℝ) / 1000000) ((132216303 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((187576359 : ℝ) / 200000000)) (t := ((-12423641 : ℝ) / 387576359))
    (lo := ((-400821 : ℝ) / 6250000)) (hi := ((-1282627 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((187576359 : ℝ) / 50000000) = Real.log ((187576359 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((187576359 : ℝ) / 50000000) = ((187576359 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1949 : RB (Real.log ((545273 : ℝ) / 400000)) ((30982203 : ℝ) / 100000000) ((6196441 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((545273 : ℝ) / 800000)) (t := ((-254727 : ℝ) / 1345273))
    (lo := ((-7666503 : ℝ) / 20000000)) (hi := ((-19166257 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((545273 : ℝ) / 400000) = Real.log ((545273 : ℝ) / 800000) + 1 * Real.log 2 := by
    rw [show ((545273 : ℝ) / 400000) = ((545273 : ℝ) / 800000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1950 : RB (Real.log ((8101093 : ℝ) / 25000000)) ((-56343843 : ℝ) / 50000000) ((-112687683 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8101093 : ℝ) / 6250000)) (t := ((1851093 : ℝ) / 14351093))
    (lo := ((3242719 : ℝ) / 12500000)) (hi := ((25941753 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8101093 : ℝ) / 25000000) = Real.log ((8101093 : ℝ) / 6250000) - 2 * Real.log 2 := by
    rw [show ((8101093 : ℝ) / 25000000) = ((8101093 : ℝ) / 6250000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1951 : RB (Real.log ((18449713 : ℝ) / 50000000)) ((-99697421 : ℝ) / 100000000) ((-99697419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((18449713 : ℝ) / 25000000)) (t := ((-6550287 : ℝ) / 43449713))
    (lo := ((-15191351 : ℝ) / 50000000)) (hi := ((-30382701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((18449713 : ℝ) / 50000000) = Real.log ((18449713 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((18449713 : ℝ) / 50000000) = ((18449713 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1952 : RB (Real.log ((37155917 : ℝ) / 50000000)) ((-14844999 : ℝ) / 50000000) ((-29689997 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37155917 : ℝ) / 50000000)) (t := ((-12844083 : ℝ) / 87155917))
    (lo := ((-14844999 : ℝ) / 50000000)) (hi := ((-29689997 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1953 : RB (Real.log ((18577959 : ℝ) / 25000000)) ((-5937999 : ℝ) / 20000000) ((-14844997 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18577959 : ℝ) / 25000000)) (t := ((-6422041 : ℝ) / 43577959))
    (lo := ((-5937999 : ℝ) / 20000000)) (hi := ((-14844997 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1954 : RB (Real.log ((42671333 : ℝ) / 100000000)) ((-42582143 : ℝ) / 50000000) ((-21291071 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((42671333 : ℝ) / 50000000)) (t := ((-7328667 : ℝ) / 92671333))
    (lo := ((-15849567 : ℝ) / 100000000)) (hi := ((-7924783 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42671333 : ℝ) / 100000000) = Real.log ((42671333 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42671333 : ℝ) / 100000000) = ((42671333 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1955 : RB (Real.log ((76595729 : ℝ) / 100000000)) ((-26662887 : ℝ) / 100000000) ((-13331443 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((76595729 : ℝ) / 100000000)) (t := ((-23404271 : ℝ) / 176595729))
    (lo := ((-26662887 : ℝ) / 100000000)) (hi := ((-13331443 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1956 : RB (Real.log ((19148933 : ℝ) / 25000000)) ((-26662883 : ℝ) / 100000000) ((-13331441 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19148933 : ℝ) / 25000000)) (t := ((-5851067 : ℝ) / 44148933))
    (lo := ((-26662883 : ℝ) / 100000000)) (hi := ((-13331441 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1957 : RB (Real.log ((43412759 : ℝ) / 100000000)) ((-41720841 : ℝ) / 50000000) ((-1043021 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((43412759 : ℝ) / 50000000)) (t := ((-6587241 : ℝ) / 93412759))
    (lo := ((-14126963 : ℝ) / 100000000)) (hi := ((-7063481 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43412759 : ℝ) / 100000000) = Real.log ((43412759 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43412759 : ℝ) / 100000000) = ((43412759 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1958 : RB (Real.log ((380179793 : ℝ) / 100000000)) ((133547409 : ℝ) / 100000000) ((33386853 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((380179793 : ℝ) / 400000000)) (t := ((-19820207 : ℝ) / 780179793))
    (lo := ((-5082027 : ℝ) / 100000000)) (hi := ((-2541013 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((380179793 : ℝ) / 100000000) = Real.log ((380179793 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((380179793 : ℝ) / 100000000) = ((380179793 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1959 : RB (Real.log ((380179797 : ℝ) / 100000000)) ((13354741 : ℝ) / 10000000) ((133547413 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((380179797 : ℝ) / 400000000)) (t := ((-19820203 : ℝ) / 780179797))
    (lo := ((-2541013 : ℝ) / 50000000)) (hi := ((-203281 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((380179797 : ℝ) / 100000000) = Real.log ((380179797 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((380179797 : ℝ) / 100000000) = ((380179797 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1960 : RB (Real.log ((16958327 : ℝ) / 12500000)) ((30503033 : ℝ) / 100000000) ((6100607 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((16958327 : ℝ) / 25000000)) (t := ((-8041673 : ℝ) / 41958327))
    (lo := ((-7762337 : ℝ) / 20000000)) (hi := ((-9702921 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16958327 : ℝ) / 12500000) = Real.log ((16958327 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((16958327 : ℝ) / 12500000) = ((16958327 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1961 : RB (Real.log ((372848767 : ℝ) / 100000000)) ((131600269 : ℝ) / 100000000) ((8225017 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((372848767 : ℝ) / 400000000)) (t := ((-27151233 : ℝ) / 772848767))
    (lo := ((-7029167 : ℝ) / 100000000)) (hi := ((-3514583 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((372848767 : ℝ) / 100000000) = Real.log ((372848767 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((372848767 : ℝ) / 100000000) = ((372848767 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1962 : RB (Real.log ((372848771 : ℝ) / 100000000)) ((131600271 : ℝ) / 100000000) ((65800137 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((372848771 : ℝ) / 400000000)) (t := ((-27151229 : ℝ) / 772848771))
    (lo := ((-1405833 : ℝ) / 20000000)) (hi := ((-1757291 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((372848771 : ℝ) / 100000000) = Real.log ((372848771 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((372848771 : ℝ) / 100000000) = ((372848771 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1963 : RB (Real.log ((136624923 : ℝ) / 100000000)) ((31206919 : ℝ) / 100000000) ((31206921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((136624923 : ℝ) / 200000000)) (t := ((-63375077 : ℝ) / 336624923))
    (lo := ((-38107799 : ℝ) / 100000000)) (hi := ((-19053899 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((136624923 : ℝ) / 100000000) = Real.log ((136624923 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((136624923 : ℝ) / 100000000) = ((136624923 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1964 : RB (Real.log ((35083489 : ℝ) / 100000000)) ((-52371979 : ℝ) / 50000000) ((-26185989 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((35083489 : ℝ) / 50000000)) (t := ((-14916511 : ℝ) / 85083489))
    (lo := ((-35429239 : ℝ) / 100000000)) (hi := ((-17714619 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35083489 : ℝ) / 100000000) = Real.log ((35083489 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((35083489 : ℝ) / 100000000) = ((35083489 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1965 : RB (Real.log ((39349323 : ℝ) / 100000000)) ((-93269143 : ℝ) / 100000000) ((-93269141 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39349323 : ℝ) / 50000000)) (t := ((-10650677 : ℝ) / 89349323))
    (lo := ((-2994303 : ℝ) / 12500000)) (hi := ((-23954423 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39349323 : ℝ) / 100000000) = Real.log ((39349323 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39349323 : ℝ) / 100000000) = ((39349323 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1966 : RB (Real.log ((75152033 : ℝ) / 100000000)) ((-14282851 : ℝ) / 50000000) ((-28565701 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((75152033 : ℝ) / 100000000)) (t := ((-24847967 : ℝ) / 175152033))
    (lo := ((-14282851 : ℝ) / 50000000)) (hi := ((-28565701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1967 : RB (Real.log ((18788009 : ℝ) / 25000000)) ((-14282849 : ℝ) / 50000000) ((-28565697 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((18788009 : ℝ) / 25000000)) (t := ((-6211991 : ℝ) / 43788009))
    (lo := ((-14282849 : ℝ) / 50000000)) (hi := ((-28565697 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1968 : RB (Real.log ((42946337 : ℝ) / 100000000)) ((-21130471 : ℝ) / 25000000) ((-42260941 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42946337 : ℝ) / 50000000)) (t := ((-7053663 : ℝ) / 92946337))
    (lo := ((-3041433 : ℝ) / 20000000)) (hi := ((-3801791 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42946337 : ℝ) / 100000000) = Real.log ((42946337 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42946337 : ℝ) / 100000000) = ((42946337 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1969 : RB (Real.log ((9649391 : ℝ) / 12500000)) ((-3235423 : ℝ) / 12500000) ((-25883383 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9649391 : ℝ) / 12500000)) (t := ((-2850609 : ℝ) / 22149391))
    (lo := ((-3235423 : ℝ) / 12500000)) (hi := ((-25883383 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1970 : RB (Real.log ((77195131 : ℝ) / 100000000)) ((-25883381 : ℝ) / 100000000) ((-1294169 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((77195131 : ℝ) / 100000000)) (t := ((-22804869 : ℝ) / 177195131))
    (lo := ((-25883381 : ℝ) / 100000000)) (hi := ((-1294169 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1971 : RB (Real.log ((43604177 : ℝ) / 100000000)) ((-3320069 : ℝ) / 4000000) ((-83001723 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43604177 : ℝ) / 50000000)) (t := ((-6395823 : ℝ) / 93604177))
    (lo := ((-6843503 : ℝ) / 50000000)) (hi := ((-2737401 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43604177 : ℝ) / 100000000) = Real.log ((43604177 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43604177 : ℝ) / 100000000) = ((43604177 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1972 : RB (Real.log ((188799931 : ℝ) / 50000000)) ((16608311 : ℝ) / 12500000) ((132866491 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((188799931 : ℝ) / 200000000)) (t := ((-11200069 : ℝ) / 388799931))
    (lo := ((-1440737 : ℝ) / 25000000)) (hi := ((-5762947 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((188799931 : ℝ) / 50000000) = Real.log ((188799931 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((188799931 : ℝ) / 50000000) = ((188799931 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1973 : RB (Real.log ((75519973 : ℝ) / 20000000)) ((16608311 : ℝ) / 12500000) ((132866491 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((75519973 : ℝ) / 80000000)) (t := ((-4480027 : ℝ) / 155519973))
    (lo := ((-1440737 : ℝ) / 25000000)) (hi := ((-5762947 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((75519973 : ℝ) / 20000000) = Real.log ((75519973 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((75519973 : ℝ) / 20000000) = ((75519973 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1974 : RB (Real.log ((135998091 : ℝ) / 100000000)) ((15373533 : ℝ) / 50000000) ((7686767 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((135998091 : ℝ) / 200000000)) (t := ((-64001909 : ℝ) / 335998091))
    (lo := ((-9641913 : ℝ) / 25000000)) (hi := ((-38567651 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((135998091 : ℝ) / 100000000) = Real.log ((135998091 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((135998091 : ℝ) / 100000000) = ((135998091 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1975 : RB (Real.log ((11583313 : ℝ) / 3125000)) ((32753281 : ℝ) / 25000000) ((131013127 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11583313 : ℝ) / 12500000)) (t := ((-916687 : ℝ) / 24083313))
    (lo := ((-952039 : ℝ) / 12500000)) (hi := ((-7616311 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11583313 : ℝ) / 3125000) = Real.log ((11583313 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((11583313 : ℝ) / 3125000) = ((11583313 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1976 : RB (Real.log ((370666019 : ℝ) / 100000000)) ((209621 : ℝ) / 160000) ((16376641 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((370666019 : ℝ) / 400000000)) (t := ((-29333981 : ℝ) / 770666019))
    (lo := ((-7616311 : ℝ) / 100000000)) (hi := ((-761631 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((370666019 : ℝ) / 100000000) = Real.log ((370666019 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((370666019 : ℝ) / 100000000) = ((370666019 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1977 : RB (Real.log ((3423007 : ℝ) / 2500000)) ((31422867 : ℝ) / 100000000) ((31422869 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3423007 : ℝ) / 5000000)) (t := ((-1576993 : ℝ) / 8423007))
    (lo := ((-37891851 : ℝ) / 100000000)) (hi := ((-757837 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3423007 : ℝ) / 2500000) = Real.log ((3423007 : ℝ) / 5000000) + 1 * Real.log 2 := by
    rw [show ((3423007 : ℝ) / 2500000) = ((3423007 : ℝ) / 5000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1978 : RB (Real.log ((37663537 : ℝ) / 100000000)) ((-3051493 : ℝ) / 3125000) ((-48823887 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((37663537 : ℝ) / 50000000)) (t := ((-12336463 : ℝ) / 87663537))
    (lo := ((-28333057 : ℝ) / 100000000)) (hi := ((-110676 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37663537 : ℝ) / 100000000) = Real.log ((37663537 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((37663537 : ℝ) / 100000000) = ((37663537 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1979 : RB (Real.log ((41739999 : ℝ) / 100000000)) ((-10921379 : ℝ) / 12500000) ((-8737103 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((41739999 : ℝ) / 50000000)) (t := ((-8260001 : ℝ) / 91739999))
    (lo := ((-18056313 : ℝ) / 100000000)) (hi := ((-2257039 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41739999 : ℝ) / 100000000) = Real.log ((41739999 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41739999 : ℝ) / 100000000) = ((41739999 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1980 : RB (Real.log ((7589929 : ℝ) / 10000000)) ((-13788143 : ℝ) / 50000000) ((-5515257 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((7589929 : ℝ) / 10000000)) (t := ((-2410071 : ℝ) / 17589929))
    (lo := ((-13788143 : ℝ) / 50000000)) (hi := ((-5515257 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1981 : RB (Real.log ((75899293 : ℝ) / 100000000)) ((-13788141 : ℝ) / 50000000) ((-27576281 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((75899293 : ℝ) / 100000000)) (t := ((-24100707 : ℝ) / 175899293))
    (lo := ((-13788141 : ℝ) / 50000000)) (hi := ((-27576281 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1982 : RB (Real.log ((43188713 : ℝ) / 100000000)) ((-83959101 : ℝ) / 100000000) ((-83959099 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43188713 : ℝ) / 50000000)) (t := ((-6811287 : ℝ) / 93188713))
    (lo := ((-7322191 : ℝ) / 50000000)) (hi := ((-14644381 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43188713 : ℝ) / 100000000) = Real.log ((43188713 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43188713 : ℝ) / 100000000) = ((43188713 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1983 : RB (Real.log ((38870323 : ℝ) / 50000000)) ((-6294799 : ℝ) / 25000000) ((-5035839 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((38870323 : ℝ) / 50000000)) (t := ((-11129677 : ℝ) / 88870323))
    (lo := ((-6294799 : ℝ) / 25000000)) (hi := ((-5035839 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1984 : RB (Real.log ((77740649 : ℝ) / 100000000)) ((-3147399 : ℝ) / 12500000) ((-25179191 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((77740649 : ℝ) / 100000000)) (t := ((-22259351 : ℝ) / 177740649))
    (lo := ((-3147399 : ℝ) / 12500000)) (hi := ((-25179191 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1985 : RB (Real.log ((21888633 : ℝ) / 50000000)) ((-20651389 : ℝ) / 25000000) ((-41302777 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((21888633 : ℝ) / 25000000)) (t := ((-3111367 : ℝ) / 46888633))
    (lo := ((-13290837 : ℝ) / 100000000)) (hi := ((-3322709 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21888633 : ℝ) / 50000000) = Real.log ((21888633 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21888633 : ℝ) / 50000000) = ((21888633 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1986 : RB (Real.log ((375163261 : ℝ) / 100000000)) ((13221911 : ℝ) / 10000000) ((132219113 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((375163261 : ℝ) / 400000000)) (t := ((-24836739 : ℝ) / 775163261))
    (lo := ((-3205163 : ℝ) / 50000000)) (hi := ((-256413 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((375163261 : ℝ) / 100000000) = Real.log ((375163261 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((375163261 : ℝ) / 100000000) = ((375163261 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1987 : RB (Real.log ((75032653 : ℝ) / 20000000)) ((132219111 : ℝ) / 100000000) ((66109557 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((75032653 : ℝ) / 80000000)) (t := ((-4967347 : ℝ) / 155032653))
    (lo := ((-256413 : ℝ) / 4000000)) (hi := ((-1602581 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((75032653 : ℝ) / 20000000) = Real.log ((75032653 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((75032653 : ℝ) / 20000000) = ((75032653 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1988 : RB (Real.log ((68158429 : ℝ) / 50000000)) ((15490591 : ℝ) / 50000000) ((484081 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((68158429 : ℝ) / 100000000)) (t := ((-31841571 : ℝ) / 168158429))
    (lo := ((-1197923 : ℝ) / 3125000)) (hi := ((-7666707 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68158429 : ℝ) / 50000000) = Real.log ((68158429 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((68158429 : ℝ) / 50000000) = ((68158429 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1989 : RB (Real.log ((368595157 : ℝ) / 100000000)) ((130452871 : ℝ) / 100000000) ((65226437 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((368595157 : ℝ) / 400000000)) (t := ((-31404843 : ℝ) / 768595157))
    (lo := ((-1635313 : ℝ) / 20000000)) (hi := ((-2044141 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((368595157 : ℝ) / 100000000) = Real.log ((368595157 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((368595157 : ℝ) / 100000000) = ((368595157 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1990 : RB (Real.log ((9214879 : ℝ) / 2500000)) ((16306609 : ℝ) / 12500000) ((1043623 : ℝ) / 800000) := by
  have hm := log_bounds_of_series (x := ((9214879 : ℝ) / 10000000)) (t := ((-785121 : ℝ) / 19214879))
    (lo := ((-2044141 : ℝ) / 25000000)) (hi := ((-8176563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9214879 : ℝ) / 2500000) = Real.log ((9214879 : ℝ) / 10000000) + 2 * Real.log 2 := by
    rw [show ((9214879 : ℝ) / 2500000) = ((9214879 : ℝ) / 10000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1991 : RB (Real.log ((68602467 : ℝ) / 50000000)) ((31630549 : ℝ) / 100000000) ((31630551 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68602467 : ℝ) / 100000000)) (t := ((-31397533 : ℝ) / 168602467))
    (lo := ((-37684169 : ℝ) / 100000000)) (hi := ((-4710521 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68602467 : ℝ) / 50000000) = Real.log ((68602467 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((68602467 : ℝ) / 50000000) = ((68602467 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1992 : RB (Real.log ((10040119 : ℝ) / 25000000)) ((-91228687 : ℝ) / 100000000) ((-18245737 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((10040119 : ℝ) / 12500000)) (t := ((-2459881 : ℝ) / 22540119))
    (lo := ((-1369623 : ℝ) / 6250000)) (hi := ((-21913967 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10040119 : ℝ) / 25000000) = Real.log ((10040119 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10040119 : ℝ) / 25000000) = ((10040119 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1993 : RB (Real.log ((5509727 : ℝ) / 12500000)) ((-40960679 : ℝ) / 50000000) ((-20480339 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5509727 : ℝ) / 6250000)) (t := ((-740273 : ℝ) / 11759727))
    (lo := ((-12606639 : ℝ) / 100000000)) (hi := ((-6303319 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5509727 : ℝ) / 12500000) = Real.log ((5509727 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5509727 : ℝ) / 12500000) = ((5509727 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1994 : RB (Real.log ((76569369 : ℝ) / 100000000)) ((-6674327 : ℝ) / 25000000) ((-26697307 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76569369 : ℝ) / 100000000)) (t := ((-23430631 : ℝ) / 176569369))
    (lo := ((-6674327 : ℝ) / 25000000)) (hi := ((-26697307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1995 : RB (Real.log ((76569371 : ℝ) / 100000000)) ((-5339461 : ℝ) / 20000000) ((-3337163 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((76569371 : ℝ) / 100000000)) (t := ((-23430629 : ℝ) / 176569371))
    (lo := ((-5339461 : ℝ) / 20000000)) (hi := ((-3337163 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1996 : RB (Real.log ((43404311 : ℝ) / 100000000)) ((-83461143 : ℝ) / 100000000) ((-83461141 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43404311 : ℝ) / 50000000)) (t := ((-6595689 : ℝ) / 93404311))
    (lo := ((-1768303 : ℝ) / 12500000)) (hi := ((-14146423 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43404311 : ℝ) / 100000000) = Real.log ((43404311 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43404311 : ℝ) / 100000000) = ((43404311 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1997 : RB (Real.log ((78239499 : ℝ) / 100000000)) ((-24539557 : ℝ) / 100000000) ((-6134889 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((78239499 : ℝ) / 100000000)) (t := ((-21760501 : ℝ) / 178239499))
    (lo := ((-24539557 : ℝ) / 100000000)) (hi := ((-6134889 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1998 : RB (Real.log ((39119751 : ℝ) / 50000000)) ((-24539553 : ℝ) / 100000000) ((-766861 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((39119751 : ℝ) / 50000000)) (t := ((-10880249 : ℝ) / 89119751))
    (lo := ((-24539553 : ℝ) / 100000000)) (hi := ((-766861 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1999 : RB (Real.log ((43934621 : ℝ) / 100000000)) ((-20561689 : ℝ) / 25000000) ((-41123377 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((43934621 : ℝ) / 50000000)) (t := ((-6065379 : ℝ) / 93934621))
    (lo := ((-12932037 : ℝ) / 100000000)) (hi := ((-3233009 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43934621 : ℝ) / 100000000) = Real.log ((43934621 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43934621 : ℝ) / 100000000) = ((43934621 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
