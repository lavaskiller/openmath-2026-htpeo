import LeanProject.Stage8Full

/-!
# EP-1038, Stage 9, Lemmas 9.1–9.2: the one-cut family `μ_A` and its potential

We work in the variable `y = x + 1`, so the interval `[a, 1]` of Stage 9 becomes `[a', 2]`,
`a' = D₀(1 - q)²`, and the atom `-1` becomes `0`. With `D₀ = 2/(1+q)²` and `H = D₀q = 2q/(1+q)²`,
the interval is parametrised by `d(φ) = D₀(1 - 2q cos φ + q²)` (`φ = π - θ` in Stage 9's notation).
The arcsine measure `ω` has angle density `1`, and the balayage `ω₋₁` has angle density
`Π = P_q(φ)` (both against `dφ/(2π)` on `[-π, π]`).

* `yR`, `log_dist_right`, `U_e_right`, `U_omega_right`: potentials to the right of the interval
  (`y = c + ϱ cosh τ`, `p = e^{-τ}`): `log H + τ` and `log H + τ + 2 log(1 + q e^{-τ})`.
* `VA A q y = (1/2π) ∫ log|y - d(φ)| (1 - A P_q(φ)) dφ + A log|y|`, the potential of
  `μ_A = ω + A(δ₋₁ - ω₋₁)` (Lemma 9.2).
* `VA_platform` (**Lemma 9.2(ii)**): `V_{μ_A} = C(A) = log H - A log q` on the interval.
* `VA_left` (**Lemma 9.2(iii)**): `V_{μ_A}(y(p)) = C(A) - G_A(p)` with `G_A(p) = F_A(1/p)`.
* `VA_right` (**Lemma 9.2(ii)**, second part): `V_{μ_A} > C(A)` to the right, for `0 ≤ A ≤ 1`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Stage9

open Arc

/-- `D₀(q) = 2/(1+q)²`. -/
noncomputable def D0q (q : ℝ) : ℝ := 2 / (1 + q) ^ 2

theorem D0q_pos (q : ℝ) (hq : 0 ≤ q) : 0 < D0q q := by unfold D0q; positivity

/-- A point to the right of the interval: `y = D₀(1+q²) + D₀q(p + 1/p)`. -/
noncomputable def yR (D0 q p : ℝ) : ℝ := D0 * (1 + q ^ 2) + D0 * q * (p + 1 / p)

theorem log_dist_right {D0 q p : ℝ} (hD : 0 < D0) (hq : 0 < q) (hp0 : 0 < p) (hp1 : p < 1)
    (θ : ℝ) :
    Real.log |yR D0 q p - dth D0 q θ| = Real.log (D0 * q / p) + 2 * Kl p (θ + π) := by
  have hden := Pq_den_pos hp0.le hp1 (θ + π)
  rw [Real.cos_add_pi] at hden
  have e : yR D0 q p - dth D0 q θ = D0 * q / p * (1 - 2 * p * Real.cos (θ + π) + p ^ 2) := by
    rw [Real.cos_add_pi]
    unfold yR dth
    field_simp
    ring
  have hpos : 0 < D0 * q / p := by positivity
  have hden' : 0 < 1 - 2 * p * Real.cos (θ + π) + p ^ 2 := by rw [Real.cos_add_pi]; linarith
  rw [e, abs_of_pos (mul_pos hpos hden'), Real.log_mul hpos.ne' hden'.ne', Kl_eq_half_log]
  ring

theorem Kl_at_pi (r : ℝ) : Kl r π = Real.log (1 + r) := by
  rw [Kl_eq_half_log, Real.cos_pi, show 1 - 2 * r * -1 + r ^ 2 = (1 + r) ^ 2 by ring,
    Real.log_pow]
  push_cast
  ring

/-- Equilibrium potential to the right: `U_e(y) = log H + τ`. -/
theorem U_e_right {D0 q p : ℝ} (hD : 0 < D0) (hq : 0 < q) (hp0 : 0 < p) (hp1 : p < 1) :
    1 / (2 * π) * ∫ θ in (-π)..π, Real.log |yR D0 q p - dth D0 q θ| =
      Real.log (D0 * q) - Real.log p := by
  have hc : Continuous (fun θ => Kl p (θ + π)) :=
    (Kl_continuous hp0.le hp1).comp (continuous_id.add continuous_const)
  have hB : IntervalIntegrable (fun θ => 2 * Kl p (θ + π)) volume (-π) π :=
    (hc.intervalIntegrable _ _).const_mul 2
  rw [intervalIntegral.integral_congr (fun θ _ => log_dist_right hD hq hp0 hp1 θ),
    intervalIntegral.integral_add intervalIntegrable_const hB,
    intervalIntegral.integral_const_mul, int_Kl_shift hp0.le hp1,
    intervalIntegral.integral_const, smul_eq_mul, Real.log_div (by positivity) hp0.ne']
  have hπ := Real.pi_pos.ne'
  field_simp
  ring

/-- Balayage potential to the right: `U_ω(y) = log H + τ + 2 log(1 + qp)`. -/
theorem U_omega_right {D0 q p : ℝ} (hD : 0 < D0) (hq : 0 < q) (hq1 : q < 1) (hp0 : 0 < p)
    (hp1 : p < 1) :
    1 / (2 * π) * ∫ θ in (-π)..π, Real.log |yR D0 q p - dth D0 q θ| * Pq q θ =
      Real.log (D0 * q) - Real.log p + 2 * Real.log (1 + q * p) := by
  have hc : Continuous (fun θ => Kl p (θ + π)) :=
    (Kl_continuous hp0.le hp1).comp (continuous_id.add continuous_const)
  have hPc := Pq_cont hq.le hq1
  have e : ∀ θ, Real.log |yR D0 q p - dth D0 q θ| * Pq q θ =
      Real.log (D0 * q / p) * Pq q θ + 2 * (Kl p (θ + π) * Pq q θ) := by
    intro θ
    rw [log_dist_right hD hq hp0 hp1 θ]
    ring
  have hA : IntervalIntegrable (fun θ => Real.log (D0 * q / p) * Pq q θ) volume (-π) π :=
    (continuous_const.mul hPc).intervalIntegrable _ _
  have hB : IntervalIntegrable (fun θ => 2 * (Kl p (θ + π) * Pq q θ)) volume (-π) π :=
    ((hc.mul hPc).intervalIntegrable _ _).const_mul 2
  rw [intervalIntegral.integral_congr (fun θ _ => e θ), intervalIntegral.integral_add hA hB,
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul, int_Pq hq.le hq1,
    int_Kl_Pq hp0.le hp1 hq.le hq1 π, Kl_at_pi _,
    Real.log_div (by positivity) hp0.ne', mul_comm p q]
  have hπ := Real.pi_pos.ne'
  field_simp

/-! ### The potential of `μ_A` -/

/-- `V_{μ_A}(y) = (1/2π) ∫ log|y - d(φ)| (1 - A P_q(φ)) dφ + A log|y|` (shifted variable). -/
noncomputable def VA (A q y : ℝ) : ℝ :=
  1 / (2 * π) * (∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ| * (1 - A * Pq q θ)) +
    A * Real.log |y|

/-- `C(A) = log H - A log q`. -/
noncomputable def CA (A q : ℝ) : ℝ := Real.log (D0q q * q) - A * Real.log q

/-- The two potentials combine: `V_{μ_A} = U_e - A U_ω + A log|y|`. -/
theorem VA_eq {A q y : ℝ} (hq : 0 < q) (hq1 : q < 1)
    (hL : IntervalIntegrable (fun θ => Real.log |y - dth (D0q q) q θ|) volume (-π) π) :
    VA A q y = 1 / (2 * π) * (∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ|) -
      A * (1 / (2 * π) * ∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ| * Pq q θ) +
      A * Real.log |y| := by
  have hLP : IntervalIntegrable (fun θ => Real.log |y - dth (D0q q) q θ| * Pq q θ) volume (-π) π :=
    hL.mul_continuousOn (Pq_cont hq.le hq1).continuousOn
  unfold VA
  have e : ∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ| * (1 - A * Pq q θ) =
      (∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ|) -
        A * ∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ| * Pq q θ := by
    rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_sub hL (hLP.const_mul _)]
    refine intervalIntegral.integral_congr (fun θ _ => ?_)
    ring
  rw [e]
  ring

/-- **Lemma 9.2(ii)**: `V_{μ_A} ≡ C(A)` on the interval. -/
theorem VA_platform {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (φ : ℝ) :
    VA A q (dth (D0q q) q φ) = CA A q := by
  have hD := D0q_pos q hq.le
  rw [VA_eq hq hq1 (log_dist_ii hD hq φ), U_e hD hq φ, U_omega hD hq hq1 φ,
    abs_of_pos (dth_pos hD hq.le hq1 φ)]
  unfold CA
  rw [Real.log_mul hD.ne' hq.ne']
  ring

/-- `G_A(p) = F_A(1/p) = A log((1 - qp)/|p - q|) + log p`. -/
noncomputable def GA (A q p : ℝ) : ℝ := A * Real.log ((1 - q * p) / |p - q|) + Real.log p

/-- The left-side point in terms of `p` factors: `y = D₀(1 - qp)(p - q)/p`. -/
theorem xoff_eq {D0 q p : ℝ} (hp : p ≠ 0) :
    xoff D0 q p = D0 * (1 - q * p) * (p - q) / p := by
  unfold xoff
  field_simp
  ring

/-- **Lemma 9.2(iii)**: left of the interval, `V_{μ_A}(y(p)) = C(A) - G_A(p)` (`p ≠ q`). -/
theorem VA_left {A q p : ℝ} (hq : 0 < q) (hq1 : q < 1) (hp0 : 0 < p) (hp1 : p < 1)
    (hpq : p ≠ q) : VA A q (xoff (D0q q) q p) = CA A q - GA A q p := by
  have hD := D0q_pos q hq.le
  have hL : IntervalIntegrable (fun θ => Real.log |xoff (D0q q) q p - dth (D0q q) q θ|)
      volume (-π) π := by
    have hc := Kl_continuous hp0.le hp1
    refine (intervalIntegrable_congr ?_).mp
      (intervalIntegrable_const.add ((hc.intervalIntegrable _ _).const_mul 2) :
        IntervalIntegrable (fun θ => Real.log (D0q q * q / p) + 2 * Kl p θ) volume (-π) π)
    intro θ _
    exact (log_dist_off hD hq hp0 hp1 θ).symm
  rw [VA_eq hq hq1 hL, U_e_off hD hq hp0 hp1, U_omega_off hD hq hq1 hp0 hp1, xoff_eq hp0.ne']
  have h1 : 0 < 1 - q * p := by nlinarith
  have hpq' : 0 < |p - q| := abs_pos.mpr (sub_ne_zero.mpr hpq)
  rw [abs_div, abs_mul, abs_mul, abs_of_pos hD, abs_of_pos h1, abs_of_pos hp0,
    Real.log_div (by positivity) hp0.ne', Real.log_mul (by positivity) hpq'.ne',
    Real.log_mul hD.ne' h1.ne']
  unfold CA GA
  rw [Real.log_div h1.ne' hpq'.ne', Real.log_mul hD.ne' hq.ne']
  ring

/-- The right-side point factors: `y = D₀(1 + qp)(p + q)/p`. -/
theorem yR_eq {D0 q p : ℝ} (hp : p ≠ 0) : yR D0 q p = D0 * (1 + q * p) * (p + q) / p := by
  unfold yR
  field_simp
  ring

/-- **Lemma 9.2(ii)**, right side: `V_{μ_A} > C(A)` to the right of the interval (`0 ≤ A ≤ 1`). -/
theorem VA_right {A q p : ℝ} (hA0 : 0 ≤ A) (hA1 : A ≤ 1) (hq : 0 < q) (hq1 : q < 1)
    (hp0 : 0 < p) (hp1 : p < 1) : CA A q < VA A q (yR (D0q q) q p) := by
  have hD := D0q_pos q hq.le
  have hL : IntervalIntegrable (fun θ => Real.log |yR (D0q q) q p - dth (D0q q) q θ|)
      volume (-π) π := by
    have hc : Continuous (fun θ => Kl p (θ + π)) :=
    (Kl_continuous hp0.le hp1).comp (continuous_id.add continuous_const)
    refine (intervalIntegrable_congr ?_).mp
      (intervalIntegrable_const.add ((hc.intervalIntegrable _ _).const_mul 2) :
        IntervalIntegrable (fun θ => Real.log (D0q q * q / p) + 2 * Kl p (θ + π)) volume (-π) π)
    intro θ _
    exact (log_dist_right hD hq hp0 hp1 θ).symm
  rw [VA_eq hq hq1 hL, U_e_right hD hq hp0 hp1, U_omega_right hD hq hq1 hp0 hp1, yR_eq hp0.ne']
  have h1 : 0 < 1 + q * p := by positivity
  have h2 : 0 < p + q := by positivity
  rw [abs_of_pos (by positivity), Real.log_div (by positivity) hp0.ne',
    Real.log_mul (by positivity) h2.ne', Real.log_mul hD.ne' h1.ne']
  unfold CA
  rw [Real.log_mul hD.ne' hq.ne']
  -- the key: `-log p + A log((p+q)/(1+qp)) > 0`
  have hlt1 : (p + q) / (1 + q * p) < 1 := by
    rw [div_lt_one h1]; nlinarith
  have hgt : p < (p + q) / (1 + q * p) := by
    rw [lt_div_iff₀ h1]; nlinarith [mul_pos hq (show 0 < 1 - p ^ 2 by nlinarith)]
  have hL1 : Real.log ((p + q) / (1 + q * p)) < 0 := Real.log_neg (by positivity) hlt1
  have hL2 : Real.log p < Real.log ((p + q) / (1 + q * p)) := Real.log_lt_log hp0 hgt
  have hdiv : Real.log ((p + q) / (1 + q * p)) = Real.log (p + q) - Real.log (1 + q * p) :=
    Real.log_div h2.ne' h1.ne'
  nlinarith [mul_le_mul_of_nonneg_left hA1 (neg_nonneg.mpr hL1.le)]

end EP1038.Stage9
