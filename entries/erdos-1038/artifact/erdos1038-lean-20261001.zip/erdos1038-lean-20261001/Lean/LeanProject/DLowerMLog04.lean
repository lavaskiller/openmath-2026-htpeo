import LeanProject.DLowerMTools
import LeanProject.DLowerMLog01
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_160 : RB (Real.log ((712244159191543 : ℝ) / 500000000000000)) ((353812674418927489 : ℝ) / 1000000000000000000) ((353812674418927491 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712244159191543 : ℝ) / 1000000000000000)) (t := ((-287755840808457 : ℝ) / 1712244159191543))
    (lo := ((-16966725307050891 : ℝ) / 50000000000000000)) (hi := ((-339334506141017819 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712244159191543 : ℝ) / 500000000000000) = Real.log ((712244159191543 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712244159191543 : ℝ) / 500000000000000) = ((712244159191543 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_161 : RB (Real.log ((1424488318383089001 : ℝ) / 1000000000000000000)) ((88453168604732399 : ℝ) / 250000000000000000) ((176906337209464799 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424488318383089001 : ℝ) / 2000000000000000000)) (t := ((-575511681616910999 : ℝ) / 3424488318383089001))
    (lo := ((-339334506141015713 : ℝ) / 1000000000000000000)) (hi := ((-10604203316906741 : ℝ) / 31250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424488318383089001 : ℝ) / 1000000000000000000) = Real.log ((1424488318383089001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424488318383089001 : ℝ) / 1000000000000000000) = ((1424488318383089001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_162 : RB (Real.log ((212526190441543 : ℝ) / 500000000000000)) ((-21388571712889953 : ℝ) / 25000000000000000) ((-427771434257799059 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((212526190441543 : ℝ) / 250000000000000)) (t := ((-37473809558457 : ℝ) / 462526190441543))
    (lo := ((-16239568795565281 : ℝ) / 100000000000000000)) (hi := ((-162395687955652809 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212526190441543 : ℝ) / 500000000000000) = Real.log ((212526190441543 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212526190441543 : ℝ) / 500000000000000) = ((212526190441543 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_163 : RB (Real.log ((425052380883089 : ℝ) / 1000000000000000)) ((-427771434257795531 : ℝ) / 500000000000000000) ((-42777143425779553 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((425052380883089 : ℝ) / 500000000000000)) (t := ((-74947619116911 : ℝ) / 925052380883089))
    (lo := ((-20299460994455719 : ℝ) / 125000000000000000)) (hi := ((-162395687955645751 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425052380883089 : ℝ) / 1000000000000000) = Real.log ((425052380883089 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425052380883089 : ℝ) / 1000000000000000) = ((425052380883089 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_164 : RB (Real.log ((712526190441543 : ℝ) / 500000000000000)) ((354208571559482527 : ℝ) / 1000000000000000000) ((354208571559482529 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712526190441543 : ℝ) / 1000000000000000)) (t := ((-287473809558457 : ℝ) / 1712526190441543))
    (lo := ((-169469304500231391 : ℝ) / 500000000000000000)) (hi := ((-338938609000462781 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712526190441543 : ℝ) / 500000000000000) = Real.log ((712526190441543 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712526190441543 : ℝ) / 500000000000000) = ((712526190441543 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_165 : RB (Real.log ((1425052380883089 : ℝ) / 1000000000000000)) ((44276071444935579 : ℝ) / 125000000000000000) ((177104285779742317 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425052380883089 : ℝ) / 2000000000000000)) (t := ((-574947619116911 : ℝ) / 3425052380883089))
    (lo := ((-338938609000460677 : ℝ) / 1000000000000000000)) (hi := ((-84734652250115169 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425052380883089 : ℝ) / 1000000000000000) = Real.log ((1425052380883089 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425052380883089 : ℝ) / 1000000000000000) = ((1425052380883089 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_166 : RB (Real.log ((1424488318383086001 : ℝ) / 1000000000000000000)) ((35381267441892749 : ℝ) / 100000000000000000) ((88453168604731873 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424488318383086001 : ℝ) / 2000000000000000000)) (t := ((-575511681616913999 : ℝ) / 3424488318383086001))
    (lo := ((-339334506141017819 : ℝ) / 1000000000000000000)) (hi := ((-169667253070508909 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424488318383086001 : ℝ) / 1000000000000000000) = Real.log ((1424488318383086001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424488318383086001 : ℝ) / 1000000000000000000) = ((1424488318383086001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_167 : RB (Real.log ((1424488318383089 : ℝ) / 1000000000000000)) ((70762534883785919 : ℝ) / 200000000000000000) ((353812674418929597 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424488318383089 : ℝ) / 2000000000000000)) (t := ((-575511681616911 : ℝ) / 3424488318383089))
    (lo := ((-169667253070507857 : ℝ) / 500000000000000000)) (hi := ((-339334506141015713 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424488318383089 : ℝ) / 1000000000000000) = Real.log ((1424488318383089 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424488318383089 : ℝ) / 1000000000000000) = ((1424488318383089 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_168 : RB (Real.log ((229726024870408897 : ℝ) / 500000000000000000)) ((-777720695752741071 : ℝ) / 1000000000000000000) ((-777720695752741069 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229726024870408897 : ℝ) / 250000000000000000)) (t := ((-20273975129591103 : ℝ) / 479726024870408897))
    (lo := ((-84573515192795761 : ℝ) / 1000000000000000000)) (hi := ((-1057168939909947 : ℝ) / 12500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229726024870408897 : ℝ) / 500000000000000000) = Real.log ((229726024870408897 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229726024870408897 : ℝ) / 500000000000000000) = ((229726024870408897 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_169 : RB (Real.log ((116284211270265347 : ℝ) / 250000000000000000)) ((-191355906548207207 : ℝ) / 250000000000000000) ((-382711813096414413 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((116284211270265347 : ℝ) / 125000000000000000)) (t := ((-8715788729734653 : ℝ) / 241284211270265347))
    (lo := ((-36138222816441759 : ℝ) / 500000000000000000)) (hi := ((-72276445632883517 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((116284211270265347 : ℝ) / 250000000000000000) = Real.log ((116284211270265347 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((116284211270265347 : ℝ) / 250000000000000000) = ((116284211270265347 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_170 : RB (Real.log ((534356904918938613 : ℝ) / 1000000000000000000)) ((-78336412750555689 : ℝ) / 125000000000000000) ((-62669130200444551 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((534356904918938613 : ℝ) / 500000000000000000)) (t := ((34356904918938613 : ℝ) / 1034356904918938613))
    (lo := ((33227939277749899 : ℝ) / 500000000000000000)) (hi := ((66455878555499799 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((534356904918938613 : ℝ) / 1000000000000000000) = Real.log ((534356904918938613 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((534356904918938613 : ℝ) / 1000000000000000000) = ((534356904918938613 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_171 : RB (Real.log ((269961475129591103 : ℝ) / 500000000000000000)) ((-3852055214434163 : ℝ) / 6250000000000000) ((-308164417154733039 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((269961475129591103 : ℝ) / 250000000000000000)) (t := ((19961475129591103 : ℝ) / 519961475129591103))
    (lo := ((7681834625047923 : ℝ) / 100000000000000000)) (hi := ((76818346250479231 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((269961475129591103 : ℝ) / 500000000000000000) = Real.log ((269961475129591103 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((269961475129591103 : ℝ) / 500000000000000000) = ((269961475129591103 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_172 : RB (Real.log ((230038524870408897 : ℝ) / 500000000000000000)) ((-77636130408890031 : ℝ) / 100000000000000000) ((-194090326022225077 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((230038524870408897 : ℝ) / 250000000000000000)) (t := ((-19961475129591103 : ℝ) / 480038524870408897))
    (lo := ((-16642824705791 : ℝ) / 200000000000000)) (hi := ((-83214123528954999 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((230038524870408897 : ℝ) / 500000000000000000) = Real.log ((230038524870408897 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((230038524870408897 : ℝ) / 500000000000000000) = ((230038524870408897 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_173 : RB (Real.log ((465643095081061387 : ℝ) / 1000000000000000000)) ((-191083957171089973 : ℝ) / 250000000000000000) ((-76433582868435989 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((465643095081061387 : ℝ) / 500000000000000000)) (t := ((-34356904918938613 : ℝ) / 965643095081061387))
    (lo := ((-35594324062207291 : ℝ) / 500000000000000000)) (hi := ((-71188648124414581 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((465643095081061387 : ℝ) / 1000000000000000000) = Real.log ((465643095081061387 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((465643095081061387 : ℝ) / 1000000000000000000) = ((465643095081061387 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_174 : RB (Real.log ((229756493620408897 : ℝ) / 500000000000000000)) ((-777588073732017697 : ℝ) / 1000000000000000000) ((-155517614746403539 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((229756493620408897 : ℝ) / 250000000000000000)) (t := ((-20243506379591103 : ℝ) / 479756493620408897))
    (lo := ((-84440893172072387 : ℝ) / 1000000000000000000)) (hi := ((-42220446586036193 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229756493620408897 : ℝ) / 500000000000000000) = Real.log ((229756493620408897 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229756493620408897 : ℝ) / 500000000000000000) = ((229756493620408897 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_175 : RB (Real.log ((91902597448163559 : ℝ) / 200000000000000000)) ((-155517614746403539 : ℝ) / 200000000000000000) ((-777588073732017693 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((91902597448163559 : ℝ) / 100000000000000000)) (t := ((-8097402551836441 : ℝ) / 191902597448163559))
    (lo := ((-16888178634414477 : ℝ) / 200000000000000000)) (hi := ((-1319388955813631 : ℝ) / 15625000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91902597448163559 : ℝ) / 200000000000000000) = Real.log ((91902597448163559 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((91902597448163559 : ℝ) / 200000000000000000) = ((91902597448163559 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_176 : RB (Real.log ((91914159948163559 : ℝ) / 200000000000000000)) ((-31098490763889549 : ℝ) / 40000000000000000) ((-777462269097238723 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((91914159948163559 : ℝ) / 100000000000000000)) (t := ((-8085840051836441 : ℝ) / 191914159948163559))
    (lo := ((-16863017707458683 : ℝ) / 200000000000000000)) (hi := ((-42157544268646707 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91914159948163559 : ℝ) / 200000000000000000) = Real.log ((91914159948163559 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((91914159948163559 : ℝ) / 200000000000000000) = ((91914159948163559 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_177 : RB (Real.log ((465079032581061387 : ℝ) / 1000000000000000000)) ((-191386981324214973 : ℝ) / 250000000000000000) ((-76554792529685989 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((465079032581061387 : ℝ) / 500000000000000000)) (t := ((-34920967418938613 : ℝ) / 965079032581061387))
    (lo := ((-36200372368457291 : ℝ) / 500000000000000000)) (hi := ((-72400744736914581 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((465079032581061387 : ℝ) / 1000000000000000000) = Real.log ((465079032581061387 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((465079032581061387 : ℝ) / 1000000000000000000) = ((465079032581061387 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_178 : RB (Real.log ((116269758145265347 : ℝ) / 250000000000000000)) ((-76554792529685989 : ℝ) / 100000000000000000) ((-47846745331053743 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((116269758145265347 : ℝ) / 125000000000000000)) (t := ((-8730241854734653 : ℝ) / 241269758145265347))
    (lo := ((-3620037236845729 : ℝ) / 50000000000000000)) (hi := ((-72400744736914579 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((116269758145265347 : ℝ) / 250000000000000000) = Real.log ((116269758145265347 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((116269758145265347 : ℝ) / 250000000000000000) = ((116269758145265347 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_179 : RB (Real.log ((465018095081061387 : ℝ) / 1000000000000000000)) ((-765678959999096557 : ℝ) / 1000000000000000000) ((-153135791999819311 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((465018095081061387 : ℝ) / 500000000000000000)) (t := ((-34981904918938613 : ℝ) / 965018095081061387))
    (lo := ((-72531779439151247 : ℝ) / 1000000000000000000)) (hi := ((-36265889719575623 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((465018095081061387 : ℝ) / 1000000000000000000) = Real.log ((465018095081061387 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((465018095081061387 : ℝ) / 1000000000000000000) = ((465018095081061387 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_180 : RB (Real.log ((356029183793037749 : ℝ) / 250000000000000000)) ((176775893288296499 : ℝ) / 500000000000000000) ((353551786576593 : ℝ) / 1000000000000000) := by
  have hm := log_bounds_of_series (x := ((356029183793037749 : ℝ) / 500000000000000000)) (t := ((-143970816206962251 : ℝ) / 856029183793037749))
    (lo := ((-339595393983352311 : ℝ) / 1000000000000000000)) (hi := ((-33959539398335231 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356029183793037749 : ℝ) / 250000000000000000) = Real.log ((356029183793037749 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356029183793037749 : ℝ) / 250000000000000000) = ((356029183793037749 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_181 : RB (Real.log ((89053548537126473 : ℝ) / 62500000000000000)) ((88517825254016101 : ℝ) / 250000000000000000) ((177035650508032203 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((89053548537126473 : ℝ) / 125000000000000000)) (t := ((-35946451462873527 : ℝ) / 214053548537126473))
    (lo := ((-67815175908776181 : ℝ) / 200000000000000000)) (hi := ((-42384484942985113 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89053548537126473 : ℝ) / 62500000000000000) = Real.log ((89053548537126473 : ℝ) / 125000000000000000) + 1 * Real.log 2 := by
    rw [show ((89053548537126473 : ℝ) / 62500000000000000) = ((89053548537126473 : ℝ) / 125000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_182 : RB (Real.log ((106185433793037749 : ℝ) / 250000000000000000)) ((-85627397671911029 : ℝ) / 100000000000000000) ((-53517123544944393 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((106185433793037749 : ℝ) / 125000000000000000)) (t := ((-18814566206962251 : ℝ) / 231185433793037749))
    (lo := ((-8156339807958249 : ℝ) / 50000000000000000)) (hi := ((-163126796159164979 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((106185433793037749 : ℝ) / 250000000000000000) = Real.log ((106185433793037749 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((106185433793037749 : ℝ) / 250000000000000000) = ((106185433793037749 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_183 : RB (Real.log ((425363026594023567 : ℝ) / 1000000000000000000)) ((-854812294440803049 : ℝ) / 1000000000000000000) ((-854812294440803047 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((425363026594023567 : ℝ) / 500000000000000000)) (t := ((-74636973405976433 : ℝ) / 925363026594023567))
    (lo := ((-161665113880857739 : ℝ) / 1000000000000000000)) (hi := ((-80832556940428869 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425363026594023567 : ℝ) / 1000000000000000000) = Real.log ((425363026594023567 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425363026594023567 : ℝ) / 1000000000000000000) = ((425363026594023567 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_184 : RB (Real.log ((356185433793037749 : ℝ) / 250000000000000000)) ((353990558819253129 : ℝ) / 1000000000000000000) ((353990558819253131 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((356185433793037749 : ℝ) / 500000000000000000)) (t := ((-143814566206962251 : ℝ) / 856185433793037749))
    (lo := ((-16957831087034609 : ℝ) / 50000000000000000)) (hi := ((-339156621740692179 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356185433793037749 : ℝ) / 250000000000000000) = Real.log ((356185433793037749 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356185433793037749 : ℝ) / 250000000000000000) = ((356185433793037749 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_185 : RB (Real.log ((1425363026594023567 : ℝ) / 1000000000000000000)) ((177213268390259211 : ℝ) / 500000000000000000) ((44303317097564803 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425363026594023567 : ℝ) / 2000000000000000000)) (t := ((-574636973405976433 : ℝ) / 3425363026594023567))
    (lo := ((-338720643779426887 : ℝ) / 1000000000000000000)) (hi := ((-169360321889713443 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425363026594023567 : ℝ) / 1000000000000000000) = Real.log ((1425363026594023567 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425363026594023567 : ℝ) / 1000000000000000000) = ((1425363026594023567 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_186 : RB (Real.log ((356044418168037749 : ℝ) / 250000000000000000)) ((35359457534157563 : ℝ) / 100000000000000000) ((22099660958848477 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((356044418168037749 : ℝ) / 500000000000000000)) (t := ((-143955581831962251 : ℝ) / 856044418168037749))
    (lo := ((-339552605218369679 : ℝ) / 1000000000000000000)) (hi := ((-169776302609184839 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356044418168037749 : ℝ) / 250000000000000000) = Real.log ((356044418168037749 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356044418168037749 : ℝ) / 250000000000000000) = ((356044418168037749 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_187 : RB (Real.log ((1424177672672150997 : ℝ) / 1000000000000000000)) ((353594575341575631 : ℝ) / 1000000000000000000) ((353594575341575633 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424177672672150997 : ℝ) / 2000000000000000000)) (t := ((-575822327327849003 : ℝ) / 3424177672672150997))
    (lo := ((-169776302609184839 : ℝ) / 500000000000000000)) (hi := ((-339552605218369677 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424177672672150997 : ℝ) / 1000000000000000000) = Real.log ((1424177672672150997 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424177672672150997 : ℝ) / 1000000000000000000) = ((1424177672672150997 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_188 : RB (Real.log ((1424235485172150997 : ℝ) / 1000000000000000000)) ((22102198007408687 : ℝ) / 62500000000000000) ((176817584059269497 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424235485172150997 : ℝ) / 2000000000000000000)) (t := ((-575764514827849003 : ℝ) / 3424235485172150997))
    (lo := ((-339512012441406317 : ℝ) / 1000000000000000000)) (hi := ((-84878003110351579 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424235485172150997 : ℝ) / 1000000000000000000) = Real.log ((1424235485172150997 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424235485172150997 : ℝ) / 1000000000000000000) = ((1424235485172150997 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_189 : RB (Real.log ((1424798964094023567 : ℝ) / 1000000000000000000)) ((354030725939445519 : ℝ) / 1000000000000000000) ((354030725939445521 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424798964094023567 : ℝ) / 2000000000000000000)) (t := ((-575201035905976433 : ℝ) / 3424798964094023567))
    (lo := ((-33911645462049979 : ℝ) / 100000000000000000)) (hi := ((-339116454620499789 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424798964094023567 : ℝ) / 1000000000000000000) = Real.log ((1424798964094023567 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424798964094023567 : ℝ) / 1000000000000000000) = ((1424798964094023567 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_190 : RB (Real.log ((89049935255876473 : ℝ) / 62500000000000000)) ((354030725939445519 : ℝ) / 1000000000000000000) ((354030725939445521 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((89049935255876473 : ℝ) / 125000000000000000)) (t := ((-35950064744123527 : ℝ) / 214049935255876473))
    (lo := ((-33911645462049979 : ℝ) / 100000000000000000)) (hi := ((-339116454620499789 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89049935255876473 : ℝ) / 62500000000000000) = Real.log ((89049935255876473 : ℝ) / 125000000000000000) + 1 * Real.log 2 := by
    rw [show ((89049935255876473 : ℝ) / 62500000000000000) = ((89049935255876473 : ℝ) / 125000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_191 : RB (Real.log ((1424738026594023567 : ℝ) / 1000000000000000000)) ((566380729333021 : ℝ) / 1600000000000000) ((353987955833138127 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424738026594023567 : ℝ) / 2000000000000000000)) (t := ((-575261973405976433 : ℝ) / 3424738026594023567))
    (lo := ((-21197451545425449 : ℝ) / 62500000000000000)) (hi := ((-339159224726807183 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424738026594023567 : ℝ) / 1000000000000000000) = Real.log ((1424738026594023567 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424738026594023567 : ℝ) / 1000000000000000000) = ((1424738026594023567 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_192 : RB (Real.log ((25312499999999999 : ℝ) / 1000000000000000000)) ((-367645693411537919 : ℝ) / 100000000000000000) ((-919114233528844797 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((25312499999999999 : ℝ) / 31250000000000000)) (t := ((-5937500000000001 : ℝ) / 56562499999999999))
    (lo := ((-105360515657826321 : ℝ) / 500000000000000000)) (hi := ((-210721031315652641 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25312499999999999 : ℝ) / 1000000000000000000) = Real.log ((25312499999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25312499999999999 : ℝ) / 1000000000000000000) = ((25312499999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_193 : RB (Real.log ((81 : ℝ) / 3200)) ((-3676456934115379151 : ℝ) / 1000000000000000000) ((-3676456934115379149 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((81 : ℝ) / 100)) (t := ((-19 : ℝ) / 181))
    (lo := ((-210721031315652603 : ℝ) / 1000000000000000000)) (hi := ((-105360515657826301 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((81 : ℝ) / 3200) = Real.log ((81 : ℝ) / 100) - 5 * Real.log 2 := by
    rw [show ((81 : ℝ) / 3200) = ((81 : ℝ) / 100) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_194 : RB (Real.log ((1025312499999999999 : ℝ) / 1000000000000000000)) ((6249361043320929 : ℝ) / 250000000000000000) ((24997444173283717 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025312499999999999 : ℝ) / 1000000000000000000)) (t := ((25312499999999999 : ℝ) / 2025312499999999999))
    (lo := ((6249361043320929 : ℝ) / 250000000000000000)) (hi := ((24997444173283717 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_195 : RB (Real.log ((3281 : ℝ) / 3200)) ((6249361043320929 : ℝ) / 250000000000000000) ((24997444173283717 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((3281 : ℝ) / 3200)) (t := ((81 : ℝ) / 6481))
    (lo := ((6249361043320929 : ℝ) / 250000000000000000)) (hi := ((24997444173283717 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_196 : RB (Real.log ((24999999999999999 : ℝ) / 1000000000000000000)) ((-461109931764242043 : ℝ) / 125000000000000000) ((-1844439727056968171 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((24999999999999999 : ℝ) / 31250000000000000)) (t := ((-6250000000000001 : ℝ) / 56249999999999999))
    (lo := ((-55785887828552449 : ℝ) / 250000000000000000)) (hi := ((-44628710262841959 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24999999999999999 : ℝ) / 1000000000000000000) = Real.log ((24999999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((24999999999999999 : ℝ) / 1000000000000000000) = ((24999999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_197 : RB (Real.log ((41 : ℝ) / 1600)) ((-3664186841523564803 : ℝ) / 1000000000000000000) ((-3664186841523564801 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((41 : ℝ) / 50)) (t := ((-9 : ℝ) / 91))
    (lo := ((-39690187744767651 : ℝ) / 200000000000000000)) (hi := ((-99225469361919127 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41 : ℝ) / 1600) = Real.log ((41 : ℝ) / 50) - 5 * Real.log 2 := by
    rw [show ((41 : ℝ) / 1600) = ((41 : ℝ) / 50) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_198 : RB (Real.log ((1024999999999999999 : ℝ) / 1000000000000000000)) ((49385225180743 : ℝ) / 2000000000000000) ((24692612590371501 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1024999999999999999 : ℝ) / 1000000000000000000)) (t := ((24999999999999999 : ℝ) / 2024999999999999999))
    (lo := ((49385225180743 : ℝ) / 2000000000000000)) (hi := ((24692612590371501 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_199 : RB (Real.log ((1641 : ℝ) / 1600)) ((25302182862218291 : ℝ) / 1000000000000000000) ((6325545715554573 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1641 : ℝ) / 1600)) (t := ((41 : ℝ) / 3241))
    (lo := ((25302182862218291 : ℝ) / 1000000000000000000)) (hi := ((6325545715554573 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
