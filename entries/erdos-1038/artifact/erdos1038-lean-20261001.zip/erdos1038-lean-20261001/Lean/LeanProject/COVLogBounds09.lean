import LeanProject.COVLogTwo
import LeanProject.COVLogBounds05
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_720 : RB (Real.log ((8984141 : ℝ) / 12500000)) ((-16513387 : ℝ) / 50000000) ((-33026773 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8984141 : ℝ) / 12500000)) (t := ((-3515859 : ℝ) / 21484141))
    (lo := ((-16513387 : ℝ) / 50000000)) (hi := ((-33026773 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_721 : RB (Real.log ((71873887 : ℝ) / 100000000)) ((-16512859 : ℝ) / 50000000) ((-33025717 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((71873887 : ℝ) / 100000000)) (t := ((-28126113 : ℝ) / 171873887))
    (lo := ((-16512859 : ℝ) / 50000000)) (hi := ((-33025717 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_722 : RB (Real.log ((41827451 : ℝ) / 100000000)) ((-17432347 : ℝ) / 20000000) ((-87161733 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41827451 : ℝ) / 50000000)) (t := ((-8172549 : ℝ) / 91827451))
    (lo := ((-2230877 : ℝ) / 12500000)) (hi := ((-3569403 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41827451 : ℝ) / 100000000) = Real.log ((41827451 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41827451 : ℝ) / 100000000) = ((41827451 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_723 : RB (Real.log ((97441033 : ℝ) / 50000000)) ((66722439 : ℝ) / 100000000) ((66722441 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((97441033 : ℝ) / 100000000)) (t := ((-2558967 : ℝ) / 197441033))
    (lo := ((-2592279 : ℝ) / 100000000)) (hi := ((-1296139 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97441033 : ℝ) / 50000000) = Real.log ((97441033 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97441033 : ℝ) / 50000000) = ((97441033 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_724 : RB (Real.log ((194947369 : ℝ) / 100000000)) ((66755943 : ℝ) / 100000000) ((13351189 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((194947369 : ℝ) / 200000000)) (t := ((-5052631 : ℝ) / 394947369))
    (lo := ((-102351 : ℝ) / 4000000)) (hi := ((-1279387 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194947369 : ℝ) / 100000000) = Real.log ((194947369 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194947369 : ℝ) / 100000000) = ((194947369 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_725 : RB (Real.log ((36634463 : ℝ) / 50000000)) ((-48599 : ℝ) / 156250) ((-31103359 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36634463 : ℝ) / 50000000)) (t := ((-13365537 : ℝ) / 86634463))
    (lo := ((-48599 : ℝ) / 156250)) (hi := ((-31103359 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_726 : RB (Real.log ((73269691 : ℝ) / 100000000)) ((-7775579 : ℝ) / 25000000) ((-6220463 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((73269691 : ℝ) / 100000000)) (t := ((-26730309 : ℝ) / 173269691))
    (lo := ((-7775579 : ℝ) / 25000000)) (hi := ((-6220463 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_727 : RB (Real.log ((4229607 : ℝ) / 10000000)) ((-86047603 : ℝ) / 100000000) ((-86047601 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4229607 : ℝ) / 5000000)) (t := ((-770393 : ℝ) / 9229607))
    (lo := ((-4183221 : ℝ) / 25000000)) (hi := ((-16732883 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4229607 : ℝ) / 10000000) = Real.log ((4229607 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((4229607 : ℝ) / 10000000) = ((4229607 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_728 : RB (Real.log ((222299843 : ℝ) / 50000000)) ((14920041 : ℝ) / 10000000) ((149200413 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((222299843 : ℝ) / 200000000)) (t := ((22299843 : ℝ) / 422299843))
    (lo := ((5285487 : ℝ) / 50000000)) (hi := ((422839 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((222299843 : ℝ) / 50000000) = Real.log ((222299843 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((222299843 : ℝ) / 50000000) = ((222299843 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_729 : RB (Real.log ((444601207 : ℝ) / 100000000)) ((9325047 : ℝ) / 6250000) ((29840151 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((444601207 : ℝ) / 400000000)) (t := ((44601207 : ℝ) / 844601207))
    (lo := ((2642829 : ℝ) / 25000000)) (hi := ((10571317 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((444601207 : ℝ) / 100000000) = Real.log ((444601207 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((444601207 : ℝ) / 100000000) = ((444601207 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_730 : RB (Real.log ((806339 : ℝ) / 625000)) ((25475259 : ℝ) / 100000000) ((1273763 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((806339 : ℝ) / 625000)) (t := ((181339 : ℝ) / 1431339))
    (lo := ((25475259 : ℝ) / 100000000)) (hi := ((1273763 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_731 : RB (Real.log ((442488231 : ℝ) / 100000000)) ((9295273 : ℝ) / 6250000) ((148724371 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((442488231 : ℝ) / 400000000)) (t := ((42488231 : ℝ) / 842488231))
    (lo := ((2523733 : ℝ) / 25000000)) (hi := ((10094933 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((442488231 : ℝ) / 100000000) = Real.log ((442488231 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((442488231 : ℝ) / 100000000) = ((442488231 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_732 : RB (Real.log ((442489743 : ℝ) / 100000000)) ((148724709 : ℝ) / 100000000) ((18590589 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((442489743 : ℝ) / 400000000)) (t := ((42489743 : ℝ) / 842489743))
    (lo := ((10095273 : ℝ) / 100000000)) (hi := ((5047637 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((442489743 : ℝ) / 100000000) = Real.log ((442489743 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((442489743 : ℝ) / 100000000) = ((442489743 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_733 : RB (Real.log ((64596557 : ℝ) / 50000000)) ((2561381 : ℝ) / 10000000) ((25613811 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64596557 : ℝ) / 50000000)) (t := ((14596557 : ℝ) / 114596557))
    (lo := ((2561381 : ℝ) / 10000000)) (hi := ((25613811 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_734 : RB (Real.log ((248991 : ℝ) / 3125000)) ((-50595457 : ℝ) / 20000000) ((-395277 : ℝ) / 156250) := by
  have hm := log_bounds_of_series (x := ((497982 : ℝ) / 390625)) (t := ((107357 : ℝ) / 888607))
    (lo := ((24281591 : ℝ) / 100000000)) (hi := ((3035199 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((248991 : ℝ) / 3125000) = Real.log ((497982 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((248991 : ℝ) / 3125000) = ((497982 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_735 : RB (Real.log ((4596793 : ℝ) / 50000000)) ((-47733283 : ℝ) / 20000000) ((-238666411 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4596793 : ℝ) / 6250000)) (t := ((-1653207 : ℝ) / 10846793))
    (lo := ((-15361129 : ℝ) / 50000000)) (hi := ((-30722257 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4596793 : ℝ) / 50000000) = Real.log ((4596793 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4596793 : ℝ) / 50000000) = ((4596793 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_736 : RB (Real.log ((501863 : ℝ) / 20000000)) ((-368516043 : ℝ) / 100000000) ((-368516037 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((501863 : ℝ) / 625000)) (t := ((-123137 : ℝ) / 1126863))
    (lo := ((-1371403 : ℝ) / 6250000)) (hi := ((-21942447 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((501863 : ℝ) / 20000000) = Real.log ((501863 : ℝ) / 625000) - 5 * Real.log 2 := by
    rw [show ((501863 : ℝ) / 20000000) = ((501863 : ℝ) / 625000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_737 : RB (Real.log ((2543237 : ℝ) / 100000000)) ((-45896657 : ℝ) / 12500000) ((-1468693 : ℝ) / 400000) := by
  have hm := log_bounds_of_series (x := ((2543237 : ℝ) / 3125000)) (t := ((-581763 : ℝ) / 5668237))
    (lo := ((-20599661 : ℝ) / 100000000)) (hi := ((-1029983 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2543237 : ℝ) / 100000000) = Real.log ((2543237 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2543237 : ℝ) / 100000000) = ((2543237 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_738 : RB (Real.log ((17930729 : ℝ) / 25000000)) ((-8308997 : ℝ) / 25000000) ((-33235987 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17930729 : ℝ) / 25000000)) (t := ((-7069271 : ℝ) / 42930729))
    (lo := ((-8308997 : ℝ) / 25000000)) (hi := ((-33235987 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_739 : RB (Real.log ((17930921 : ℝ) / 25000000)) ((-16617459 : ℝ) / 50000000) ((-33234917 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17930921 : ℝ) / 25000000)) (t := ((-7069079 : ℝ) / 42930921))
    (lo := ((-16617459 : ℝ) / 50000000)) (hi := ((-33234917 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_740 : RB (Real.log ((1671073 : ℝ) / 4000000)) ((-21820711 : ℝ) / 25000000) ((-43641421 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1671073 : ℝ) / 2000000)) (t := ((-328927 : ℝ) / 3671073))
    (lo := ((-28749 : ℝ) / 160000)) (hi := ((-4492031 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1671073 : ℝ) / 4000000) = Real.log ((1671073 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((1671073 : ℝ) / 4000000) = ((1671073 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_741 : RB (Real.log ((38963351 : ℝ) / 20000000)) ((66688921 : ℝ) / 100000000) ((66688923 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38963351 : ℝ) / 40000000)) (t := ((-1036649 : ℝ) / 78963351))
    (lo := ((-2625797 : ℝ) / 100000000)) (hi := ((-656449 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38963351 : ℝ) / 20000000) = Real.log ((38963351 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38963351 : ℝ) / 20000000) = ((38963351 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_742 : RB (Real.log ((19488207 : ℝ) / 10000000)) ((66722441 : ℝ) / 100000000) ((66722443 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19488207 : ℝ) / 20000000)) (t := ((-511793 : ℝ) / 39488207))
    (lo := ((-2592277 : ℝ) / 100000000)) (hi := ((-648069 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19488207 : ℝ) / 10000000) = Real.log ((19488207 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((19488207 : ℝ) / 10000000) = ((19488207 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_743 : RB (Real.log ((36549153 : ℝ) / 50000000)) ((-62673 : ℝ) / 200000) ((-31336499 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36549153 : ℝ) / 50000000)) (t := ((-13450847 : ℝ) / 86549153))
    (lo := ((-62673 : ℝ) / 200000)) (hi := ((-31336499 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_744 : RB (Real.log ((73099081 : ℝ) / 100000000)) ((-391693 : ℝ) / 1250000) ((-31335439 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((73099081 : ℝ) / 100000000)) (t := ((-26900919 : ℝ) / 173099081))
    (lo := ((-391693 : ℝ) / 1250000)) (hi := ((-31335439 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_745 : RB (Real.log ((844789 : ℝ) / 2000000)) ((-43090779 : ℝ) / 50000000) ((-21545389 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((844789 : ℝ) / 1000000)) (t := ((-155211 : ℝ) / 1844789))
    (lo := ((-16866839 : ℝ) / 100000000)) (hi := ((-8433419 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((844789 : ℝ) / 2000000) = Real.log ((844789 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((844789 : ℝ) / 2000000) = ((844789 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_746 : RB (Real.log ((443889539 : ℝ) / 100000000)) ((29808111 : ℝ) / 20000000) ((74520279 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((443889539 : ℝ) / 400000000)) (t := ((43889539 : ℝ) / 843889539))
    (lo := ((10411119 : ℝ) / 100000000)) (hi := ((130139 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((443889539 : ℝ) / 100000000) = Real.log ((443889539 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((443889539 : ℝ) / 100000000) = ((443889539 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_747 : RB (Real.log ((443891077 : ℝ) / 100000000)) ((74520451 : ℝ) / 50000000) ((29808181 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((443891077 : ℝ) / 400000000)) (t := ((43891077 : ℝ) / 843891077))
    (lo := ((5205733 : ℝ) / 50000000)) (hi := ((10411467 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((443891077 : ℝ) / 100000000) = Real.log ((443891077 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((443891077 : ℝ) / 100000000) = ((443891077 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_748 : RB (Real.log ((64537013 : ℝ) / 50000000)) ((25521589 : ℝ) / 100000000) ((2552159 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((64537013 : ℝ) / 50000000)) (t := ((14537013 : ℝ) / 114537013))
    (lo := ((25521589 : ℝ) / 100000000)) (hi := ((2552159 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_749 : RB (Real.log ((88358477 : ℝ) / 20000000)) ((74283493 : ℝ) / 50000000) ((148566989 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((88358477 : ℝ) / 80000000)) (t := ((8358477 : ℝ) / 168358477))
    (lo := ((198751 : ℝ) / 2000000)) (hi := ((9937551 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((88358477 : ℝ) / 20000000) = Real.log ((88358477 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((88358477 : ℝ) / 20000000) = ((88358477 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_750 : RB (Real.log ((220896957 : ℝ) / 50000000)) ((37141833 : ℝ) / 25000000) ((29713467 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((220896957 : ℝ) / 200000000)) (t := ((20896957 : ℝ) / 420896957))
    (lo := ((1242237 : ℝ) / 12500000)) (hi := ((9937897 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((220896957 : ℝ) / 50000000) = Real.log ((220896957 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((220896957 : ℝ) / 50000000) = ((220896957 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_751 : RB (Real.log ((129252417 : ℝ) / 100000000)) ((12829851 : ℝ) / 50000000) ((25659703 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129252417 : ℝ) / 100000000)) (t := ((29252417 : ℝ) / 229252417))
    (lo := ((12829851 : ℝ) / 50000000)) (hi := ((25659703 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_752 : RB (Real.log ((1002767 : ℝ) / 12500000)) ((-252296551 : ℝ) / 100000000) ((-126148273 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1002767 : ℝ) / 781250)) (t := ((221517 : ℝ) / 1784017))
    (lo := ((998493 : ℝ) / 4000000)) (hi := ((12481163 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1002767 : ℝ) / 12500000) = Real.log ((1002767 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((1002767 : ℝ) / 12500000) = ((1002767 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_753 : RB (Real.log ((9234709 : ℝ) / 100000000)) ((-14888757 : ℝ) / 6250000) ((-59555027 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((9234709 : ℝ) / 12500000)) (t := ((-3265291 : ℝ) / 21734709))
    (lo := ((-6055191 : ℝ) / 20000000)) (hi := ((-15137977 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9234709 : ℝ) / 100000000) = Real.log ((9234709 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9234709 : ℝ) / 100000000) = ((9234709 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_754 : RB (Real.log ((317691 : ℝ) / 12500000)) ((-91810119 : ℝ) / 25000000) ((-36724047 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((317691 : ℝ) / 390625)) (t := ((-36467 : ℝ) / 354158))
    (lo := ((-20666881 : ℝ) / 100000000)) (hi := ((-16146 : ℝ) / 78125)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((317691 : ℝ) / 12500000) = Real.log ((317691 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((317691 : ℝ) / 12500000) = ((317691 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_755 : RB (Real.log ((1287737 : ℝ) / 50000000)) ((-5717401 : ℝ) / 1562500) ((-182956829 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1287737 : ℝ) / 1562500)) (t := ((-274763 : ℝ) / 2850237))
    (lo := ((-19340069 : ℝ) / 100000000)) (hi := ((-4835017 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1287737 : ℝ) / 50000000) = Real.log ((1287737 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1287737 : ℝ) / 50000000) = ((1287737 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_756 : RB (Real.log ((71574723 : ℝ) / 100000000)) ((-33442821 : ℝ) / 100000000) ((-1672141 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((71574723 : ℝ) / 100000000)) (t := ((-28425277 : ℝ) / 171574723))
    (lo := ((-33442821 : ℝ) / 100000000)) (hi := ((-1672141 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_757 : RB (Real.log ((35787751 : ℝ) / 50000000)) ((-33441733 : ℝ) / 100000000) ((-8360433 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((35787751 : ℝ) / 50000000)) (t := ((-14212249 : ℝ) / 85787751))
    (lo := ((-33441733 : ℝ) / 100000000)) (hi := ((-8360433 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_758 : RB (Real.log ((104317 : ℝ) / 250000)) ((-87402659 : ℝ) / 100000000) ((-87402657 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((104317 : ℝ) / 125000)) (t := ((-20683 : ℝ) / 229317))
    (lo := ((-904397 : ℝ) / 5000000)) (hi := ((-18087939 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((104317 : ℝ) / 250000) = Real.log ((104317 : ℝ) / 125000) - 1 * Real.log 2 := by
    rw [show ((104317 : ℝ) / 250000) = ((104317 : ℝ) / 125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_759 : RB (Real.log ((194751433 : ℝ) / 100000000)) ((13331077 : ℝ) / 20000000) ((66655387 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((194751433 : ℝ) / 200000000)) (t := ((-5248567 : ℝ) / 394751433))
    (lo := ((-2659333 : ℝ) / 100000000)) (hi := ((-664833 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194751433 : ℝ) / 100000000) = Real.log ((194751433 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194751433 : ℝ) / 100000000) = ((194751433 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_760 : RB (Real.log ((194816759 : ℝ) / 100000000)) ((66688923 : ℝ) / 100000000) ((2667557 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((194816759 : ℝ) / 200000000)) (t := ((-5183241 : ℝ) / 394816759))
    (lo := ((-525159 : ℝ) / 20000000)) (hi := ((-1312897 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194816759 : ℝ) / 100000000) = Real.log ((194816759 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194816759 : ℝ) / 100000000) = ((194816759 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_761 : RB (Real.log ((72930289 : ℝ) / 100000000)) ((-6313323 : ℝ) / 20000000) ((-15783307 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((72930289 : ℝ) / 100000000)) (t := ((-27069711 : ℝ) / 172930289))
    (lo := ((-6313323 : ℝ) / 20000000)) (hi := ((-15783307 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_762 : RB (Real.log ((36465537 : ℝ) / 50000000)) ((-31565539 : ℝ) / 100000000) ((-15782769 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((36465537 : ℝ) / 50000000)) (t := ((-13534463 : ℝ) / 86465537))
    (lo := ((-31565539 : ℝ) / 100000000)) (hi := ((-15782769 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_763 : RB (Real.log ((5272949 : ℝ) / 12500000)) ((-86313887 : ℝ) / 100000000) ((-17262777 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((5272949 : ℝ) / 6250000)) (t := ((-977051 : ℝ) / 11522949))
    (lo := ((-66403 : ℝ) / 390625)) (hi := ((-16999167 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5272949 : ℝ) / 12500000) = Real.log ((5272949 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5272949 : ℝ) / 12500000) = ((5272949 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_764 : RB (Real.log ((221592103 : ℝ) / 50000000)) ((148881531 : ℝ) / 100000000) ((74440767 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((221592103 : ℝ) / 200000000)) (t := ((21592103 : ℝ) / 421592103))
    (lo := ((2050419 : ℝ) / 20000000)) (hi := ((160189 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((221592103 : ℝ) / 50000000) = Real.log ((221592103 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((221592103 : ℝ) / 50000000) = ((221592103 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_765 : RB (Real.log ((443185761 : ℝ) / 100000000)) ((74440941 : ℝ) / 50000000) ((29776377 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((443185761 : ℝ) / 400000000)) (t := ((43185761 : ℝ) / 843185761))
    (lo := ((5126223 : ℝ) / 50000000)) (hi := ((10252447 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((443185761 : ℝ) / 100000000) = Real.log ((443185761 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((443185761 : ℝ) / 100000000) = ((443185761 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_766 : RB (Real.log ((129133649 : ℝ) / 100000000)) ((6391943 : ℝ) / 25000000) ((25567773 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129133649 : ℝ) / 100000000)) (t := ((29133649 : ℝ) / 229133649))
    (lo := ((6391943 : ℝ) / 25000000)) (hi := ((25567773 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_767 : RB (Real.log ((88220237 : ℝ) / 20000000)) ((14841041 : ℝ) / 10000000) ((148410413 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((88220237 : ℝ) / 80000000)) (t := ((8220237 : ℝ) / 168220237))
    (lo := ((4890487 : ℝ) / 50000000)) (hi := ((391239 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((88220237 : ℝ) / 20000000) = Real.log ((88220237 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((88220237 : ℝ) / 20000000) = ((88220237 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_768 : RB (Real.log ((441102731 : ℝ) / 100000000)) ((148410761 : ℝ) / 100000000) ((37102691 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((441102731 : ℝ) / 400000000)) (t := ((41102731 : ℝ) / 841102731))
    (lo := ((391253 : ℝ) / 4000000)) (hi := ((4890663 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((441102731 : ℝ) / 100000000) = Real.log ((441102731 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((441102731 : ℝ) / 100000000) = ((441102731 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_769 : RB (Real.log ((129311561 : ℝ) / 100000000)) ((514109 : ℝ) / 2000000) ((25705451 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129311561 : ℝ) / 100000000)) (t := ((29311561 : ℝ) / 229311561))
    (lo := ((514109 : ℝ) / 2000000)) (hi := ((25705451 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_770 : RB (Real.log ((8077287 : ℝ) / 100000000)) ((-125805709 : ℝ) / 50000000) ((-251611413 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8077287 : ℝ) / 6250000)) (t := ((1827287 : ℝ) / 14327287))
    (lo := ((12823729 : ℝ) / 50000000)) (hi := ((25647459 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8077287 : ℝ) / 100000000) = Real.log ((8077287 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8077287 : ℝ) / 100000000) = ((8077287 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_771 : RB (Real.log ((9276919 : ℝ) / 100000000)) ((-237764073 : ℝ) / 100000000) ((-237764069 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9276919 : ℝ) / 12500000)) (t := ((-3223081 : ℝ) / 21776919))
    (lo := ((-7454979 : ℝ) / 25000000)) (hi := ((-5963983 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9276919 : ℝ) / 100000000) = Real.log ((9276919 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9276919 : ℝ) / 100000000) = ((9276919 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_772 : RB (Real.log ((514749 : ℝ) / 20000000)) ((-18299041 : ℝ) / 5000000) ((-182990407 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((514749 : ℝ) / 625000)) (t := ((-110251 : ℝ) / 1139749))
    (lo := ((-776289 : ℝ) / 4000000)) (hi := ((-2425903 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((514749 : ℝ) / 20000000) = Real.log ((514749 : ℝ) / 625000) - 5 * Real.log 2 := by
    rw [show ((514749 : ℝ) / 20000000) = ((514749 : ℝ) / 625000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_773 : RB (Real.log ((81491 : ℝ) / 3125000)) ((-364669703 : ℝ) / 100000000) ((-364669697 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((325964 : ℝ) / 390625)) (t := ((-64661 : ℝ) / 716589))
    (lo := ((-4524027 : ℝ) / 25000000)) (hi := ((-18096107 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((81491 : ℝ) / 3125000) = Real.log ((325964 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((81491 : ℝ) / 3125000) = ((325964 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_774 : RB (Real.log ((35714243 : ℝ) / 50000000)) ((-2102959 : ℝ) / 6250000) ((-33647343 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35714243 : ℝ) / 50000000)) (t := ((-14285757 : ℝ) / 85714243))
    (lo := ((-2102959 : ℝ) / 6250000)) (hi := ((-33647343 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_775 : RB (Real.log ((35714637 : ℝ) / 50000000)) ((-33646241 : ℝ) / 100000000) ((-210289 : ℝ) / 625000) := by
  have hm := log_bounds_of_series (x := ((35714637 : ℝ) / 50000000)) (t := ((-14285363 : ℝ) / 85714637))
    (lo := ((-33646241 : ℝ) / 100000000)) (hi := ((-210289 : ℝ) / 625000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_776 : RB (Real.log ((41677357 : ℝ) / 100000000)) ((-43760611 : ℝ) / 50000000) ((-4376061 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((41677357 : ℝ) / 50000000)) (t := ((-8322643 : ℝ) / 91677357))
    (lo := ((-18206503 : ℝ) / 100000000)) (hi := ((-9103251 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41677357 : ℝ) / 100000000) = Real.log ((41677357 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41677357 : ℝ) / 100000000) = ((41677357 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_777 : RB (Real.log ((1946861 : ℝ) / 1000000)) ((66621833 : ℝ) / 100000000) ((13324367 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1946861 : ℝ) / 2000000)) (t := ((-53139 : ℝ) / 3946861))
    (lo := ((-538577 : ℝ) / 20000000)) (hi := ((-673221 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1946861 : ℝ) / 1000000) = Real.log ((1946861 : ℝ) / 2000000) + 1 * Real.log 2 := by
    rw [show ((1946861 : ℝ) / 1000000) = ((1946861 : ℝ) / 2000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_778 : RB (Real.log ((194751437 : ℝ) / 100000000)) ((66655387 : ℝ) / 100000000) ((66655389 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((194751437 : ℝ) / 200000000)) (t := ((-5248563 : ℝ) / 394751437))
    (lo := ((-2659331 : ℝ) / 100000000)) (hi := ((-265933 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194751437 : ℝ) / 100000000) = Real.log ((194751437 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194751437 : ℝ) / 100000000) = ((194751437 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_779 : RB (Real.log ((72764799 : ℝ) / 100000000)) ((-7948447 : ℝ) / 25000000) ((-31793787 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((72764799 : ℝ) / 100000000)) (t := ((-27235201 : ℝ) / 172764799))
    (lo := ((-7948447 : ℝ) / 25000000)) (hi := ((-31793787 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_780 : RB (Real.log ((72765593 : ℝ) / 100000000)) ((-31792697 : ℝ) / 100000000) ((-3974087 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((72765593 : ℝ) / 100000000)) (t := ((-27234407 : ℝ) / 172765593))
    (lo := ((-31792697 : ℝ) / 100000000)) (hi := ((-3974087 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_781 : RB (Real.log ((1685139 : ℝ) / 4000000)) ((-10805579 : ℝ) / 12500000) ((-8644463 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((1685139 : ℝ) / 2000000)) (t := ((-314861 : ℝ) / 3685139))
    (lo := ((-17129913 : ℝ) / 100000000)) (hi := ((-2141239 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1685139 : ℝ) / 4000000) = Real.log ((1685139 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((1685139 : ℝ) / 4000000) = ((1685139 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_782 : RB (Real.log ((221241811 : ℝ) / 50000000)) ((74361663 : ℝ) / 50000000) ((148723329 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((221241811 : ℝ) / 200000000)) (t := ((21241811 : ℝ) / 421241811))
    (lo := ((1009389 : ℝ) / 10000000)) (hi := ((10093891 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((221241811 : ℝ) / 50000000) = Real.log ((221241811 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((221241811 : ℝ) / 50000000) = ((221241811 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_783 : RB (Real.log ((88497039 : ℝ) / 20000000)) ((148723681 : ℝ) / 100000000) ((37180921 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((88497039 : ℝ) / 80000000)) (t := ((8497039 : ℝ) / 168497039))
    (lo := ((2018849 : ℝ) / 20000000)) (hi := ((5047123 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((88497039 : ℝ) / 20000000) = Real.log ((88497039 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((88497039 : ℝ) / 20000000) = ((88497039 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_784 : RB (Real.log ((129193111 : ℝ) / 100000000)) ((1600863 : ℝ) / 6250000) ((25613809 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129193111 : ℝ) / 100000000)) (t := ((29193111 : ℝ) / 229193111))
    (lo := ((1600863 : ℝ) / 6250000)) (hi := ((25613809 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_785 : RB (Real.log ((440414579 : ℝ) / 100000000)) ((18531829 : ℝ) / 12500000) ((29650927 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((440414579 : ℝ) / 400000000)) (t := ((40414579 : ℝ) / 840414579))
    (lo := ((2406299 : ℝ) / 25000000)) (hi := ((9625197 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((440414579 : ℝ) / 100000000) = Real.log ((440414579 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((440414579 : ℝ) / 100000000) = ((440414579 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_786 : RB (Real.log ((440416143 : ℝ) / 100000000)) ((148254987 : ℝ) / 100000000) ((14825499 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((440416143 : ℝ) / 400000000)) (t := ((40416143 : ℝ) / 840416143))
    (lo := ((9625551 : ℝ) / 100000000)) (hi := ((601597 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((440416143 : ℝ) / 100000000) = Real.log ((440416143 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((440416143 : ℝ) / 100000000) = ((440416143 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_787 : RB (Real.log ((129370547 : ℝ) / 100000000)) ((5150211 : ℝ) / 20000000) ((1609441 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((129370547 : ℝ) / 100000000)) (t := ((29370547 : ℝ) / 229370547))
    (lo := ((5150211 : ℝ) / 20000000)) (hi := ((1609441 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_788 : RB (Real.log ((8133123 : ℝ) / 100000000)) ((-10036901 : ℝ) / 4000000) ((-6273063 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((8133123 : ℝ) / 6250000)) (t := ((1883123 : ℝ) / 14383123))
    (lo := ((26336351 : ℝ) / 100000000)) (hi := ((823011 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8133123 : ℝ) / 100000000) = Real.log ((8133123 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8133123 : ℝ) / 100000000) = ((8133123 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_789 : RB (Real.log ((9320173 : ℝ) / 100000000)) ((-237298903 : ℝ) / 100000000) ((-237298899 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9320173 : ℝ) / 12500000)) (t := ((-3179827 : ℝ) / 21820173))
    (lo := ((-14677373 : ℝ) / 50000000)) (hi := ((-5870949 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9320173 : ℝ) / 100000000) = Real.log ((9320173 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9320173 : ℝ) / 100000000) = ((9320173 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_790 : RB (Real.log ((2605959 : ℝ) / 100000000)) ((-364736949 : ℝ) / 100000000) ((-364736943 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2605959 : ℝ) / 3125000)) (t := ((-519041 : ℝ) / 5730959))
    (lo := ((-9081677 : ℝ) / 50000000)) (hi := ((-18163353 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2605959 : ℝ) / 100000000) = Real.log ((2605959 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2605959 : ℝ) / 100000000) = ((2605959 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_791 : RB (Real.log ((52799 : ℝ) / 2000000)) ((-181720513 : ℝ) / 50000000) ((-18172051 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((52799 : ℝ) / 62500)) (t := ((-9701 : ℝ) / 115299))
    (lo := ((-16867431 : ℝ) / 100000000)) (hi := ((-1686743 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52799 : ℝ) / 2000000) = Real.log ((52799 : ℝ) / 62500) - 5 * Real.log 2 := by
    rw [show ((52799 : ℝ) / 2000000) = ((52799 : ℝ) / 62500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_792 : RB (Real.log ((8910519 : ℝ) / 12500000)) ((-2115601 : ℝ) / 6250000) ((-6769923 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((8910519 : ℝ) / 12500000)) (t := ((-3589481 : ℝ) / 21410519))
    (lo := ((-2115601 : ℝ) / 6250000)) (hi := ((-6769923 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_793 : RB (Real.log ((1425699 : ℝ) / 2000000)) ((-33848497 : ℝ) / 100000000) ((-2115531 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((1425699 : ℝ) / 2000000)) (t := ((-574301 : ℝ) / 3425699))
    (lo := ((-33848497 : ℝ) / 100000000)) (hi := ((-2115531 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_794 : RB (Real.log ((20814241 : ℝ) / 50000000)) ((-547741 : ℝ) / 625000) ((-43819279 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((20814241 : ℝ) / 25000000)) (t := ((-4185759 : ℝ) / 45814241))
    (lo := ((-18323841 : ℝ) / 100000000)) (hi := ((-28631 : ℝ) / 156250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20814241 : ℝ) / 50000000) = Real.log ((20814241 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20814241 : ℝ) / 50000000) = ((20814241 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_795 : RB (Real.log ((38924151 : ℝ) / 20000000)) ((66588263 : ℝ) / 100000000) ((13317653 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((38924151 : ℝ) / 40000000)) (t := ((-1075849 : ℝ) / 78924151))
    (lo := ((-545291 : ℝ) / 20000000)) (hi := ((-1363227 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38924151 : ℝ) / 20000000) = Real.log ((38924151 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38924151 : ℝ) / 20000000) = ((38924151 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_796 : RB (Real.log ((194686103 : ℝ) / 100000000)) ((33310917 : ℝ) / 50000000) ((16655459 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((194686103 : ℝ) / 200000000)) (t := ((-5313897 : ℝ) / 394686103))
    (lo := ((-673221 : ℝ) / 25000000)) (hi := ((-2692883 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194686103 : ℝ) / 100000000) = Real.log ((194686103 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194686103 : ℝ) / 100000000) = ((194686103 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_797 : RB (Real.log ((18150441 : ℝ) / 25000000)) ((-32018097 : ℝ) / 100000000) ((-2001131 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((18150441 : ℝ) / 25000000)) (t := ((-6849559 : ℝ) / 43150441))
    (lo := ((-32018097 : ℝ) / 100000000)) (hi := ((-2001131 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_798 : RB (Real.log ((9075321 : ℝ) / 12500000)) ((-3201699 : ℝ) / 10000000) ((-32016989 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9075321 : ℝ) / 12500000)) (t := ((-3424679 : ℝ) / 21575321))
    (lo := ((-3201699 : ℝ) / 10000000)) (hi := ((-32016989 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_799 : RB (Real.log ((262963 : ℝ) / 625000)) ((-86573833 : ℝ) / 100000000) ((-86573831 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((262963 : ℝ) / 312500)) (t := ((-49537 : ℝ) / 575463))
    (lo := ((-8629557 : ℝ) / 50000000)) (hi := ((-17259113 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((262963 : ℝ) / 625000) = Real.log ((262963 : ℝ) / 312500) - 1 * Real.log 2 := by
    rw [show ((262963 : ℝ) / 625000) = ((262963 : ℝ) / 312500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
