import LeanProject.DeepMindModelBridge
import LeanProject.Residual
import Mathlib.Analysis.SpecialFunctions.Pow.NNReal

/-!
# Bounds in the exact constants used by DeepMind's Erdős 1038 statements

The constants in the official file are expressions in `ENNReal`. These bridges
retain that interpretation and prove their agreement with the real-valued constants
used by the project. The lower-bound comparison is a rational cubic calculation.
-/

open Real Polynomial MeasureTheory
open scoped ENNReal

namespace EP1038.DeepMind

/-- The official `ENNReal` upper-bound expression agrees with the project's `ofReal` one. -/
theorem official_upper_constant_eq :
    (2 * 2 ^ (1 / 2 : ℝ) : ℝ≥0∞) = ENNReal.ofReal (2 * Real.sqrt 2) := by
  rw [Real.sqrt_eq_rpow, ENNReal.ofReal_mul (by norm_num),
    ← ENNReal.ofReal_rpow_of_pos (by norm_num : (0 : ℝ) < 2)]
  norm_num

/-- An exact comparison with the classical lower-bound constant, checked by cubing. -/
theorem classical_lower_real_le_1525 :
    (2 : ℝ) ^ (4 / 3 : ℝ) - 1 ≤ 61 / 40 := by
  have hcubed : ((2 : ℝ) ^ (4 / 3 : ℝ)) ^ (3 : ℕ) = 16 := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)]
    norm_num
  have hroot : (2 : ℝ) ^ (4 / 3 : ℝ) ≤ 101 / 40 := by
    apply le_of_pow_le_pow_left₀ (n := 3) (by norm_num) (by norm_num)
    rw [hcubed]
    norm_num
  linarith

/-- The classical constant is below `61/40`, with subtraction interpreted in `ENNReal`. -/
theorem classical_lower_constant_le_1525 :
    (2 ^ (4 / 3 : ℝ) - 1 : ℝ≥0∞) ≤ ENNReal.ofReal (61 / 40) := by
  have hconstant : (2 ^ (4 / 3 : ℝ) - 1 : ℝ≥0∞) =
      ENNReal.ofReal ((2 : ℝ) ^ (4 / 3 : ℝ) - 1) := by
    rw [ENNReal.ofReal_sub _ (by norm_num),
      ← ENNReal.ofReal_rpow_of_pos (by norm_num : (0 : ℝ) < 2)]
    norm_num
  rw [hconstant]
  exact ENNReal.ofReal_le_ofReal classical_lower_real_le_1525

/-- An admissible polynomial attaining the upper bound. -/
theorem sq_sub_one_admissible : EP1038.Admissible (X ^ 2 - 1 : ℝ[X]) := by
  let s : Multiset ℝ := (([-1, 1] : List ℝ) : Multiset ℝ)
  have hp : (X ^ 2 - 1 : ℝ[X]) = EP1038.polyOf s := by
    simp [EP1038.polyOf, s]
    ring
  rw [hp]
  refine ⟨EP1038.polyOf_monic s, ?_, ?_, ?_⟩
  · rw [EP1038.polyOf_natDegree]
    norm_num [s]
  · rw [EP1038.polyOf_roots, EP1038.polyOf_natDegree]
  · intro x hx
    rw [EP1038.polyOf_roots] at hx
    simp only [s, Multiset.mem_coe, List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl <;> norm_num

/-- The exact supremum in the official polynomial class, including the constant `1`. -/
theorem officialSup_eq : officialSup = (2 * 2 ^ (1 / 2 : ℝ) : ℝ≥0∞) := by
  rw [officialSup_eq_localSup, official_upper_constant_eq]
  apply le_antisymm
  · apply iSup_le
    intro p
    exact (EP1038.sup_theorem p.1 p.2.1 p.2.2.1 p.2.2.2.1 p.2.2.2.2).1
  · have hmeasure : EP1038.sublevelMeasure (X ^ 2 - 1 : ℝ[X]) =
        ENNReal.ofReal (2 * Real.sqrt 2) := by
      simpa [EP1038.sublevelMeasure] using EP1038.volume_sublevel_sq_sub_one 1 (by norm_num)
    calc ENNReal.ofReal (2 * Real.sqrt 2) =
        EP1038.sublevelMeasure (X ^ 2 - 1 : ℝ[X]) := hmeasure.symm
      _ ≤ localSup := le_iSup_of_le ⟨_, sq_sub_one_admissible⟩ le_rfl

/-- Every official nonconstant polynomial obeys the project's stronger lower bound. -/
theorem officialInf_ge_1525 : ENNReal.ofReal (61 / 40) ≤ officialInf := by
  rw [officialInf_eq_localInf]
  apply le_iInf
  intro p
  exact (EP1038.volume_bounds_1525 p.1 p.2.1 p.2.2.1 p.2.2.2.1 p.2.2.2.2).1

/-- DeepMind's lower-bound variant follows from the stronger certified rational bound. -/
theorem officialInf_lowerBound : (2 ^ (4 / 3 : ℝ) - 1 : ℝ≥0∞) ≤ officialInf :=
  classical_lower_constant_le_1525.trans officialInf_ge_1525

/-- In the official nonconstant class, all upper-bound equality cases are classified. -/
theorem official_equality_iff (p : ℝ[X]) (hp : InfAdmissible p) :
    volume {x : ℝ | |p.eval x| < 1} = (2 * 2 ^ (1 / 2 : ℝ) : ℝ≥0∞) ↔
      ∃ m : ℕ, 1 ≤ m ∧ p = (X ^ 2 - 1) ^ m := by
  rw [official_upper_constant_eq]
  have hlocal := (inf_admissible_iff p).mp hp
  exact (EP1038.sup_theorem p hlocal.1 hlocal.2.1 hlocal.2.2.1 hlocal.2.2.2).2

end EP1038.DeepMind
