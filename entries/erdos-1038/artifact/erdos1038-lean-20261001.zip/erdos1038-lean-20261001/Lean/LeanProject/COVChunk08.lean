import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk04
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_40 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2601 : ℝ) / 4201) ((10437 : ℝ) / 16837))
    (hq : RB (qa a) ((1287607 : ℝ) / 100000000) ((5096 : ℝ) / 390625))
    (hd : RB (D0a a) ((97441033 : ℝ) / 50000000) ((194947369 : ℝ) / 100000000))
    : certE k a ((41827451 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((4229607 : ℝ) / 10000000) ∧ 0 < certE k a ((806339 : ℝ) / 625000) ∧ certE k a ((64596557 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((16579 : ℝ) / 100000000) ((851 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((41827451 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((41810431 : ℝ) / 100000000) ((5226359 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((41827451 : ℝ) / 100000000) ((41827451 : ℝ) / 100000000) ((41827451 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((58172549 : ℝ) / 100000000))
  have h3 : RB z3 ((8984141 : ℝ) / 12500000) ((71873887 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((58172549 : ℝ) / 100000000) ((58172549 : ℝ) / 100000000) ((58172549 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-16513387 : ℝ) / 50000000) ((-33025717 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_720.1 cov_log_721.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-4094559 : ℝ) / 20000000) ((-10223743 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((41827451 : ℝ) / 100000000))
  have h6 : RB z6 ((-17432347 : ℝ) / 20000000) ((-87161733 : ℝ) / 100000000) := rb_log (show RB ((41827451 : ℝ) / 100000000) ((41827451 : ℝ) / 100000000) ((41827451 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_722.1 cov_log_722.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33344469 : ℝ) / 50000000) ((66714249 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66722439 : ℝ) / 100000000) ((13351189 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_723.1 cov_log_724.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-67007 : ℝ) / 100000000) ((-819 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((16579 : ℝ) / 100000000) ((851 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((4229607 : ℝ) / 10000000)) - (z10)
  have h11 : RB z11 ((845581 : ℝ) / 2000000) ((42279491 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4229607 : ℝ) / 10000000) ((4229607 : ℝ) / 10000000) ((4229607 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((5770393 : ℝ) / 10000000))
  have h12 : RB z12 ((36634463 : ℝ) / 50000000) ((73269691 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((5770393 : ℝ) / 10000000) ((5770393 : ℝ) / 10000000) ((5770393 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-48599 : ℝ) / 156250) ((-6220463 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_725.1 cov_log_726.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-38561 : ℝ) / 200000) ((-9628317 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((4229607 : ℝ) / 10000000))
  have h15 : RB z15 ((-86047603 : ℝ) / 100000000) ((-86047601 : ℝ) / 100000000) := rb_log (show RB ((4229607 : ℝ) / 10000000) ((4229607 : ℝ) / 10000000) ((4229607 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_727.1 cov_log_727.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66767101 : ℝ) / 100000000) ((66790969 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66722439 : ℝ) / 100000000) ((13351189 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_723.1 cov_log_724.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2789 : ℝ) / 25000000) ((6853 : ℝ) / 10000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((16579 : ℝ) / 100000000) ((851 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((806339 : ℝ) / 625000)) - (z19)
  have h20 : RB z20 ((6449861 : ℝ) / 5000000) ((128997661 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((806339 : ℝ) / 625000) ((806339 : ℝ) / 625000) ((806339 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((181339 : ℝ) / 625000))
  have h21 : RB z21 ((222299843 : ℝ) / 50000000) ((444601207 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((181339 : ℝ) / 625000) ((181339 : ℝ) / 625000) ((181339 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((14920041 : ℝ) / 10000000) ((29840151 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_728.1 cov_log_729.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((11546961 : ℝ) / 12500000) ((92487277 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((806339 : ℝ) / 625000))
  have h24 : RB z24 ((25475259 : ℝ) / 100000000) ((1273763 : ℝ) / 5000000) := rb_log (show RB ((806339 : ℝ) / 625000) ((806339 : ℝ) / 625000) ((806339 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_730.1 cov_log_730.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16725107 : ℝ) / 25000000) ((33506009 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66722439 : ℝ) / 100000000) ((13351189 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_723.1 cov_log_724.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((144483 : ℝ) / 100000000) ((289579 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((16579 : ℝ) / 100000000) ((851 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((64596557 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((64588047 : ℝ) / 50000000) ((25835307 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((64596557 : ℝ) / 50000000) ((64596557 : ℝ) / 50000000) ((64596557 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((14596557 : ℝ) / 50000000))
  have h30 : RB z30 ((442488231 : ℝ) / 100000000) ((442489743 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((14596557 : ℝ) / 50000000) ((14596557 : ℝ) / 50000000) ((14596557 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((9295273 : ℝ) / 6250000) ((18590589 : ℝ) / 12500000) := rb_log h30 (by norm_num) cov_log_731.1 cov_log_732.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((11510119 : ℝ) / 12500000) ((46096093 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((64596557 : ℝ) / 50000000))
  have h33 : RB z33 ((2561381 : ℝ) / 10000000) ((25613811 : ℝ) / 100000000) := rb_log (show RB ((64596557 : ℝ) / 50000000) ((64596557 : ℝ) / 50000000) ((64596557 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_733.1 cov_log_733.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((66467141 : ℝ) / 100000000) ((8322297 : ℝ) / 12500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66722439 : ℝ) / 100000000) ((13351189 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_723.1 cov_log_724.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-72201 : ℝ) / 25000000) ((-144063 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((41827451 : ℝ) / 100000000)) ((-67007 : ℝ) / 100000000) ((-819 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((4229607 : ℝ) / 10000000)) ((2789 : ℝ) / 25000000) ((6853 : ℝ) / 10000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((806339 : ℝ) / 625000)) ((144483 : ℝ) / 100000000) ((289579 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((64596557 : ℝ) / 50000000)) ((-72201 : ℝ) / 25000000) ((-144063 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_40 {k A q d vp vm : ℝ}
    (hk : RB k ((2601 : ℝ) / 1600) ((10437 : ℝ) / 6400))
    (hA : RB A ((2601 : ℝ) / 4201) ((10437 : ℝ) / 16837))
    (hq : RB q ((1287607 : ℝ) / 100000000) ((5096 : ℝ) / 390625))
    (hd : RB d ((97441033 : ℝ) / 50000000) ((194947369 : ℝ) / 100000000))
    (hp : RB vp ((41827451 : ℝ) / 100000000) ((4229607 : ℝ) / 10000000))
    (hm : RB vm ((806339 : ℝ) / 625000) ((64596557 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((16579 : ℝ) / 100000000) ((851 : ℝ) / 5000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((4999149 : ℝ) / 5000000) ((99983421 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((15475823 : ℝ) / 25000000) ((61978201 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((39197 : ℝ) / 100000000) ((40691 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99959309 : ℝ) / 100000000) ((99960803 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((5770393 : ℝ) / 10000000) ((58172549 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57680449 : ℝ) / 100000000) ((14537437 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106454961 : ℝ) / 100000000) ((107450969 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6454961 : ℝ) / 100000000) ((7450969 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((4999149 : ℝ) / 5000000) ((99983421 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((15475823 : ℝ) / 25000000) ((61978201 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((401 : ℝ) / 3125000) ((13193 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99986807 : ℝ) / 100000000) ((3124599 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((181339 : ℝ) / 625000) ((14596557 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((7252603 : ℝ) / 25000000) ((3648671 : ℝ) / 12500000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((212074793 : ℝ) / 100000000) ((21364123 : ℝ) / 10000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((312074793 : ℝ) / 100000000) ((31364123 : ℝ) / 10000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((268421463 : ℝ) / 20000000) ((1549196037 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31883563 : ℝ) / 100000000) ((32043601 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2601 : ℝ) / 800) ((10437 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1046583 : ℝ) / 25000000) ((4254957 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101287607 : ℝ) / 100000000) ((395721 : ℝ) / 390625) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4132421 : ℝ) / 100000000) ((4200867 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((104132421 : ℝ) / 100000000) ((104200867 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((8671817 : ℝ) / 10000000) ((87365663 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((168998161 : ℝ) / 100000000) ((85158531 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((6745421 : ℝ) / 12500000) ((5464361 : ℝ) / 10000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1517 : ℝ) / 5000000) ((1577 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4998423 : ℝ) / 5000000) ((4998483 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((84472429 : ℝ) / 50000000) ((42566347 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((97441033 : ℝ) / 25000000) ((194947369 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((501863 : ℝ) / 10000000) ((2543237 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4201 : ℝ) / 1600) ((16837 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1907657 : ℝ) / 100000000) ((484311 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3044271 : ℝ) / 100000000) ((3118947 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((103044271 : ℝ) / 100000000) ((103118947 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((691482349 : ℝ) / 50000000) ((1597514641 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((249163 : ℝ) / 25000000) ((252797 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25249163 : ℝ) / 25000000) ((25252797 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32201331 : ℝ) / 100000000) ((32367623 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1415166029 : ℝ) / 100000000) ((203735283 : ℝ) / 12500000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((26996513 : ℝ) / 100000000) ((31574797 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4201 : ℝ) / 1600) ((16837 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((104132421 : ℝ) / 50000000) ((104200867 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((686995439 : ℝ) / 50000000) ((790619819 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2861539931 : ℝ) / 100000000) ((131813233 : ℝ) / 4000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((248991 : ℝ) / 3125000) ((4596793 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-50595457 : ℝ) / 20000000) ((-238666411 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_734.1 cov_log_735.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((501863 : ℝ) / 20000000) ((2543237 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-368516043 : ℝ) / 100000000) ((-1468693 : ℝ) / 400000) := rb_log h49 (by norm_num) cov_log_736.1 cov_log_737.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66722439 : ℝ) / 100000000) ((13351189 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_723.1 cov_log_724.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((423694 : ℝ) / 390625) ((13608043 : ℝ) / 12500000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-260050379 : ℝ) / 100000000) ((-129154453 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((13177659 : ℝ) / 100000000) ((1449819 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((20867369 : ℝ) / 50000000) ((209781 : ℝ) / 390625) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-218315641 : ℝ) / 100000000) ((-20460497 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((104132421 : ℝ) / 100000000) ((104200867 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-50595457 : ℝ) / 20000000) ((-238666411 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-218315641 : ℝ) / 100000000) ((-20460497 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((151 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3044271 : ℝ) / 100000000) ((3118947 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((103118947 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((151 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-13961083 : ℝ) / 6250000) ≤ formC0 k A q vp vm + hfun ((151 : ℝ) / 50) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_11, cov_h_6]
  have hP : ((24674133 : ℝ) / 4000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((20460497 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((20460497 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((551 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((551 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((559 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((559 : ℝ) / 200)) (lo := ((551 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((567 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((567 : ℝ) / 200)) (lo := ((559 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((23 : ℝ) / 8) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((23 : ℝ) / 8)) (lo := ((567 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((583 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((583 : ℝ) / 200)) (lo := ((23 : ℝ) / 8)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((591 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((591 : ℝ) / 200)) (lo := ((583 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((599 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((599 : ℝ) / 200)) (lo := ((591 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((151 : ℝ) / 50)) (lo := ((599 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_40 {k : ℝ} (hk : RB k ((2601 : ℝ) / 1600) ((10437 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((2601 : ℝ) / 4201) ((10437 : ℝ) / 16837) ∧
    RB (qa (r1A k)) ((1287607 : ℝ) / 100000000) ((5096 : ℝ) / 390625) ∧ RB (D0a (r1A k)) ((97441033 : ℝ) / 50000000) ((194947369 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2601 : ℝ) / 6400) ((10192383 : ℝ) / 25000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((47457617 : ℝ) / 25000000) ((60787 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((68889489 : ℝ) / 50000000) ((137825751 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139600167 : ℝ) / 50000000) ((69811777 : ℝ) / 25000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139600167 : ℝ) / 100000000) ((69811777 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((97441033 : ℝ) / 50000000) ((194947369 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3213 : ℝ) / 32000) ((2542383 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((627539 : ℝ) / 25000000) ((2542383 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1287607 : ℝ) / 100000000) ((5096 : ℝ) / 390625) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((97441033 : ℝ) / 50000000) ((194947369 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1287607 : ℝ) / 100000000) ((5096 : ℝ) / 390625) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2601 : ℝ) / 4201) ((10437 : ℝ) / 16837) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_40 {k : ℝ} (hk : RB k ((2601 : ℝ) / 1600) ((10437 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_40 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_40 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((41827451 : ℝ) / 100000000)) (ph := ((4229607 : ℝ) / 10000000)) (ml := ((806339 : ℝ) / 625000)) (mh := ((64596557 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_40 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_41 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10437 : ℝ) / 16837) ((1047 : ℝ) / 1687))
    (hq : RB (qa a) ((652287 : ℝ) / 50000000) ((264311 : ℝ) / 20000000))
    (hd : RB (D0a a) ((38963351 : ℝ) / 20000000) ((19488207 : ℝ) / 10000000))
    : certE k a ((1671073 : ℝ) / 4000000) < 0 ∧ 0 < certE k a ((844789 : ℝ) / 2000000) ∧ 0 < certE k a ((64537013 : ℝ) / 50000000) ∧ certE k a ((129252417 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17019 : ℝ) / 100000000) ((8733 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1671073 : ℝ) / 4000000)) - (z1)
  have h2 : RB z2 ((41759359 : ℝ) / 100000000) ((20879903 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1671073 : ℝ) / 4000000) ((1671073 : ℝ) / 4000000) ((1671073 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((2328927 : ℝ) / 4000000))
  have h3 : RB z3 ((17930729 : ℝ) / 25000000) ((17930921 : ℝ) / 25000000) := rb_div_signed h2 (show RB ((2328927 : ℝ) / 4000000) ((2328927 : ℝ) / 4000000) ((2328927 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-8308997 : ℝ) / 25000000) ((-33234917 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_738.1 cov_log_739.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-5156799 : ℝ) / 25000000) ((-20601819 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((1671073 : ℝ) / 4000000))
  have h6 : RB z6 ((-21820711 : ℝ) / 25000000) ((-43641421 : ℝ) / 50000000) := rb_log (show RB ((1671073 : ℝ) / 4000000) ((1671073 : ℝ) / 4000000) ((1671073 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_740.1 cov_log_740.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33327823 : ℝ) / 50000000) ((2667241 : ℝ) / 4000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66688921 : ℝ) / 100000000) ((66722443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_741.1 cov_log_742.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-66797 : ℝ) / 100000000) ((-987 : ℝ) / 12500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17019 : ℝ) / 100000000) ((8733 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((844789 : ℝ) / 2000000)) - (z10)
  have h11 : RB z11 ((1319437 : ℝ) / 3125000) ((42222431 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((844789 : ℝ) / 2000000) ((844789 : ℝ) / 2000000) ((844789 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((1155211 : ℝ) / 2000000))
  have h12 : RB z12 ((36549153 : ℝ) / 50000000) ((73099081 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((1155211 : ℝ) / 2000000) ((1155211 : ℝ) / 2000000) ((1155211 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-62673 : ℝ) / 200000) ((-31335439 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_743.1 cov_log_744.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15194 : ℝ) / 78125) ((-19424361 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((844789 : ℝ) / 2000000))
  have h15 : RB z15 ((-43090779 : ℝ) / 50000000) ((-21545389 : ℝ) / 25000000) := rb_log (show RB ((844789 : ℝ) / 2000000) ((844789 : ℝ) / 2000000) ((844789 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_745.1 cov_log_745.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16683309 : ℝ) / 25000000) ((66757197 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66688921 : ℝ) / 100000000) ((66722443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_741.1 cov_log_742.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((10793 : ℝ) / 100000000) ((17069 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17019 : ℝ) / 100000000) ((8733 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((64537013 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((1613207 : ℝ) / 1250000) ((129057007 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((64537013 : ℝ) / 50000000) ((64537013 : ℝ) / 50000000) ((64537013 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((14537013 : ℝ) / 50000000))
  have h21 : RB z21 ((443889539 : ℝ) / 100000000) ((443891077 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((14537013 : ℝ) / 50000000) ((14537013 : ℝ) / 50000000) ((14537013 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((29808111 : ℝ) / 20000000) ((29808181 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_746.1 cov_log_747.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92387971 : ℝ) / 100000000) ((92499009 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((64537013 : ℝ) / 50000000))
  have h24 : RB z24 ((25521589 : ℝ) / 100000000) ((2552159 : ℝ) / 10000000) := rb_log (show RB ((64537013 : ℝ) / 50000000) ((64537013 : ℝ) / 50000000) ((64537013 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_748.1 cov_log_748.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((66866381 : ℝ) / 100000000) ((3348871 : ℝ) / 5000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66688921 : ℝ) / 100000000) ((66722443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_741.1 cov_log_742.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((71969 : ℝ) / 50000000) ((288499 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17019 : ℝ) / 100000000) ((8733 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129252417 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((129234951 : ℝ) / 100000000) ((64617699 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((129252417 : ℝ) / 100000000) ((129252417 : ℝ) / 100000000) ((129252417 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29252417 : ℝ) / 100000000))
  have h30 : RB z30 ((88358477 : ℝ) / 20000000) ((220896957 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((29252417 : ℝ) / 100000000) ((29252417 : ℝ) / 100000000) ((29252417 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((74283493 : ℝ) / 50000000) ((29713467 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_749.1 cov_log_750.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92094413 : ℝ) / 100000000) ((46102549 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129252417 : ℝ) / 100000000))
  have h33 : RB z33 ((12829851 : ℝ) / 50000000) ((25659703 : ℝ) / 100000000) := rb_log (show RB ((129252417 : ℝ) / 100000000) ((129252417 : ℝ) / 100000000) ((129252417 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_751.1 cov_log_751.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6643471 : ℝ) / 10000000) ((16636349 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66688921 : ℝ) / 100000000) ((66722443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_741.1 cov_log_742.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-287733 : ℝ) / 100000000) ((-5741 : ℝ) / 4000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((1671073 : ℝ) / 4000000)) ((-66797 : ℝ) / 100000000) ((-987 : ℝ) / 12500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((844789 : ℝ) / 2000000)) ((10793 : ℝ) / 100000000) ((17069 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((64537013 : ℝ) / 50000000)) ((71969 : ℝ) / 50000000) ((288499 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129252417 : ℝ) / 100000000)) ((-287733 : ℝ) / 100000000) ((-5741 : ℝ) / 4000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_41 {k A q d vp vm : ℝ}
    (hk : RB k ((10437 : ℝ) / 6400) ((1047 : ℝ) / 640))
    (hA : RB A ((10437 : ℝ) / 16837) ((1047 : ℝ) / 1687))
    (hq : RB q ((652287 : ℝ) / 50000000) ((264311 : ℝ) / 20000000))
    (hd : RB d ((38963351 : ℝ) / 20000000) ((19488207 : ℝ) / 10000000))
    (hp : RB vp ((1671073 : ℝ) / 4000000) ((844789 : ℝ) / 2000000))
    (hm : RB vm ((64537013 : ℝ) / 50000000) ((129252417 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17019 : ℝ) / 100000000) ((8733 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49991267 : ℝ) / 50000000) ((99982981 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((1239553 : ℝ) / 2000000) ((62052271 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((40291 : ℝ) / 100000000) ((2613 : ℝ) / 6250000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((6247387 : ℝ) / 6250000) ((99959709 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((1155211 : ℝ) / 2000000) ((2328927 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57736401 : ℝ) / 100000000) ((58199717 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((4259653 : ℝ) / 4000000) ((107475129 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((259653 : ℝ) / 4000000) ((7475129 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49991267 : ℝ) / 50000000) ((99982981 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((1239553 : ℝ) / 2000000) ((62052271 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((13167 : ℝ) / 100000000) ((3383 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24996617 : ℝ) / 25000000) ((99986833 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((14537013 : ℝ) / 50000000) ((29252417 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((29070091 : ℝ) / 100000000) ((14624283 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((21189979 : ℝ) / 10000000) ((213457437 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((31189979 : ℝ) / 10000000) ((313457437 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((267553911 : ℝ) / 20000000) ((1540517537 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31902257 : ℝ) / 100000000) ((1603079 : ℝ) / 5000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10437 : ℝ) / 3200) ((1047 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4254949 : ℝ) / 100000000) ((4323963 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50652287 : ℝ) / 50000000) ((20264311 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((83989 : ℝ) / 2000000) ((4268281 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((2083989 : ℝ) / 2000000) ((104268281 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((5427161 : ℝ) / 6250000) ((10934449 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((169168303 : ℝ) / 100000000) ((34094849 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53923029 : ℝ) / 100000000) ((54595511 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((7793 : ℝ) / 25000000) ((32391 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99967609 : ℝ) / 100000000) ((24992207 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((169113507 : ℝ) / 100000000) ((34084221 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((38963351 : ℝ) / 10000000) ((19488207 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5083057 : ℝ) / 100000000) ((1287737 : ℝ) / 25000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16837 : ℝ) / 6400) ((1687 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1928367 : ℝ) / 100000000) ((978977 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((77213 : ℝ) / 2500000) ((3163369 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((2577213 : ℝ) / 2500000) ((103163369 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((275817367 : ℝ) / 20000000) ((6208007 : ℝ) / 390625) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((504661 : ℝ) / 50000000) ((511937 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50504661 : ℝ) / 50000000) ((50511937 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32224253 : ℝ) / 100000000) ((32389851 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((88206943 : ℝ) / 6250000) ((1621639643 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((27215257 : ℝ) / 100000000) ((31750959 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16837 : ℝ) / 6400) ((1687 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((2083989 : ℝ) / 1000000) ((104268281 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((342417953 : ℝ) / 25000000) ((1572579117 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2854380989 : ℝ) / 100000000) ((1639701213 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1002767 : ℝ) / 12500000) ((9234709 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-252296551 : ℝ) / 100000000) ((-59555027 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_752.1 cov_log_753.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((317691 : ℝ) / 12500000) ((1287737 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-91810119 : ℝ) / 25000000) ((-182956829 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_754.1 cov_log_755.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66688921 : ℝ) / 100000000) ((66722443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_741.1 cov_log_742.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((108755041 : ℝ) / 100000000) ((109153747 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-51697087 : ℝ) / 20000000) ((-256759911 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((6510971 : ℝ) / 50000000) ((14329541 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((41012751 : ℝ) / 100000000) ((52652603 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-54368171 : ℝ) / 25000000) ((-51026827 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((2083989 : ℝ) / 2000000) ((104268281 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-252296551 : ℝ) / 100000000) ((-59555027 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-54368171 : ℝ) / 25000000) ((-51026827 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((151 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((77213 : ℝ) / 2500000) ((3163369 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((103163369 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((151 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-222794789 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((151 : ℝ) / 50) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_11, cov_h_10]
  have hP : ((76869387 : ℝ) / 12500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((51026827 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((51026827 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1377 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1377 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1397 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1397 : ℝ) / 500)) (lo := ((1377 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1417 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1417 : ℝ) / 500)) (lo := ((1397 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1437 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1437 : ℝ) / 500)) (lo := ((1417 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1457 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1457 : ℝ) / 500)) (lo := ((1437 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1477 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1477 : ℝ) / 500)) (lo := ((1457 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1497 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1497 : ℝ) / 500)) (lo := ((1477 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((151 : ℝ) / 50)) (lo := ((1497 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_41 {k : ℝ} (hk : RB k ((10437 : ℝ) / 6400) ((1047 : ℝ) / 640)) :
    RB (k / (k + 1)) ((10437 : ℝ) / 16837) ((1047 : ℝ) / 1687) ∧
    RB (qa (r1A k)) ((652287 : ℝ) / 50000000) ((264311 : ℝ) / 20000000) ∧ RB (D0a (r1A k)) ((38963351 : ℝ) / 20000000) ((19488207 : ℝ) / 10000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((40769531 : ℝ) / 100000000) ((20449219 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((94850781 : ℝ) / 50000000) ((189830469 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((13773219 : ℝ) / 10000000) ((137778979 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139576773 : ℝ) / 50000000) ((17450021 : ℝ) / 6250000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139576773 : ℝ) / 100000000) ((17450021 : ℝ) / 12500000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((38963351 : ℝ) / 20000000) ((19488207 : ℝ) / 10000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((10169531 : ℝ) / 100000000) ((5149219 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1271191 : ℝ) / 50000000) ((257461 : ℝ) / 10000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((652287 : ℝ) / 50000000) ((264311 : ℝ) / 20000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((38963351 : ℝ) / 20000000) ((19488207 : ℝ) / 10000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((652287 : ℝ) / 50000000) ((264311 : ℝ) / 20000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10437 : ℝ) / 16837) ((1047 : ℝ) / 1687) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_41 {k : ℝ} (hk : RB k ((10437 : ℝ) / 6400) ((1047 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_41 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_41 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((1671073 : ℝ) / 4000000)) (ph := ((844789 : ℝ) / 2000000)) (ml := ((64537013 : ℝ) / 50000000)) (mh := ((129252417 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_41 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_42 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1047 : ℝ) / 1687) ((10503 : ℝ) / 16903))
    (hq : RB (qa a) ((660777 : ℝ) / 50000000) ((669273 : ℝ) / 50000000))
    (hd : RB (D0a a) ((194751433 : ℝ) / 100000000) ((194816759 : ℝ) / 100000000))
    : certE k a ((104317 : ℝ) / 250000) < 0 ∧ 0 < certE k a ((5272949 : ℝ) / 12500000) ∧ 0 < certE k a ((129133649 : ℝ) / 100000000) ∧ certE k a ((129311561 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((3493 : ℝ) / 20000000) ((8959 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((104317 : ℝ) / 250000)) - (z1)
  have h2 : RB z2 ((20854441 : ℝ) / 50000000) ((8341867 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((104317 : ℝ) / 250000) ((104317 : ℝ) / 250000) ((104317 : ℝ) / 250000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((145683 : ℝ) / 250000))
  have h3 : RB z3 ((71574723 : ℝ) / 100000000) ((35787751 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((145683 : ℝ) / 250000) ((145683 : ℝ) / 250000) ((145683 : ℝ) / 250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-33442821 : ℝ) / 100000000) ((-8360433 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_756.1 cov_log_757.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-5195083 : ℝ) / 25000000) ((-10377443 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((104317 : ℝ) / 250000))
  have h6 : RB z6 ((-87402659 : ℝ) / 100000000) ((-87402657 : ℝ) / 100000000) := rb_log (show RB ((104317 : ℝ) / 250000) ((104317 : ℝ) / 250000) ((104317 : ℝ) / 250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_758.1 cov_log_758.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((2664893 : ℝ) / 4000000) ((66647773 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((13331077 : ℝ) / 20000000) ((2667557 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_759.1 cov_log_760.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-333 : ℝ) / 500000) ((-1903 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((3493 : ℝ) / 20000000) ((8959 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((5272949 : ℝ) / 12500000)) - (z10)
  have h11 : RB z11 ((21082837 : ℝ) / 50000000) ((42166127 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((5272949 : ℝ) / 12500000) ((5272949 : ℝ) / 12500000) ((5272949 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((7227051 : ℝ) / 12500000))
  have h12 : RB z12 ((72930289 : ℝ) / 100000000) ((36465537 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((7227051 : ℝ) / 12500000) ((7227051 : ℝ) / 12500000) ((7227051 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-6313323 : ℝ) / 20000000) ((-15782769 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_761.1 cov_log_762.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4903629 : ℝ) / 25000000) ((-19590467 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((5272949 : ℝ) / 12500000))
  have h15 : RB z15 ((-86313887 : ℝ) / 100000000) ((-17262777 : ℝ) / 20000000) := rb_log (show RB ((5272949 : ℝ) / 12500000) ((5272949 : ℝ) / 12500000) ((5272949 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_763.1 cov_log_763.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66699369 : ℝ) / 100000000) ((3336171 : ℝ) / 5000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((13331077 : ℝ) / 20000000) ((2667557 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_759.1 cov_log_760.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2611 : ℝ) / 25000000) ((13607 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((3493 : ℝ) / 20000000) ((8959 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((129133649 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((129115731 : ℝ) / 100000000) ((16139523 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((129133649 : ℝ) / 100000000) ((129133649 : ℝ) / 100000000) ((129133649 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((29133649 : ℝ) / 100000000))
  have h21 : RB z21 ((221592103 : ℝ) / 50000000) ((443185761 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((29133649 : ℝ) / 100000000) ((29133649 : ℝ) / 100000000) ((29133649 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((148881531 : ℝ) / 100000000) ((29776377 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_764.1 cov_log_765.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((2887503 : ℝ) / 3125000) ((92510587 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((129133649 : ℝ) / 100000000))
  have h24 : RB z24 ((6391943 : ℝ) / 25000000) ((25567773 : ℝ) / 100000000) := rb_log (show RB ((129133649 : ℝ) / 100000000) ((129133649 : ℝ) / 100000000) ((129133649 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_766.1 cov_log_766.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((66832323 : ℝ) / 100000000) ((13388563 : ℝ) / 20000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((13331077 : ℝ) / 20000000) ((2667557 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_759.1 cov_log_760.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((71699 : ℝ) / 50000000) ((28743 : ℝ) / 10000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((3493 : ℝ) / 20000000) ((8959 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129311561 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((129293643 : ℝ) / 100000000) ((8080881 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((129311561 : ℝ) / 100000000) ((129311561 : ℝ) / 100000000) ((129311561 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29311561 : ℝ) / 100000000))
  have h30 : RB z30 ((88220237 : ℝ) / 20000000) ((441102731 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((29311561 : ℝ) / 100000000) ((29311561 : ℝ) / 100000000) ((29311561 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((14841041 : ℝ) / 10000000) ((37102691 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_767.1 cov_log_768.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18421541 : ℝ) / 20000000) ((92217847 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129311561 : ℝ) / 100000000))
  have h33 : RB z33 ((514109 : ℝ) / 2000000) ((25705451 : ℝ) / 100000000) := rb_log (show RB ((129311561 : ℝ) / 100000000) ((129311561 : ℝ) / 100000000) ((129311561 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_769.1 cov_log_769.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33201127 : ℝ) / 50000000) ((66512397 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((13331077 : ℝ) / 20000000) ((2667557 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_759.1 cov_log_760.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-286671 : ℝ) / 100000000) ((-35747 : ℝ) / 25000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((104317 : ℝ) / 250000)) ((-333 : ℝ) / 500000) ((-1903 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((5272949 : ℝ) / 12500000)) ((2611 : ℝ) / 25000000) ((13607 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((129133649 : ℝ) / 100000000)) ((71699 : ℝ) / 50000000) ((28743 : ℝ) / 10000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129311561 : ℝ) / 100000000)) ((-286671 : ℝ) / 100000000) ((-35747 : ℝ) / 25000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_42 {k A q d vp vm : ℝ}
    (hk : RB k ((1047 : ℝ) / 640) ((10503 : ℝ) / 6400))
    (hA : RB A ((1047 : ℝ) / 1687) ((10503 : ℝ) / 16903))
    (hq : RB q ((660777 : ℝ) / 50000000) ((669273 : ℝ) / 50000000))
    (hd : RB d ((194751433 : ℝ) / 100000000) ((194816759 : ℝ) / 100000000))
    (hp : RB vp ((104317 : ℝ) / 250000) ((5272949 : ℝ) / 12500000))
    (hm : RB vm ((129133649 : ℝ) / 100000000) ((129311561 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((3493 : ℝ) / 20000000) ((8959 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49991041 : ℝ) / 50000000) ((19996507 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((62051713 : ℝ) / 100000000) ((62126047 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((20701 : ℝ) / 50000000) ((21471 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49978529 : ℝ) / 50000000) ((49979299 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((7227051 : ℝ) / 12500000) ((145683 : ℝ) / 250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((2889579 : ℝ) / 5000000) ((29124537 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106528239 : ℝ) / 100000000) ((107500171 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6528239 : ℝ) / 100000000) ((7500171 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49991041 : ℝ) / 50000000) ((19996507 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((62051713 : ℝ) / 100000000) ((62126047 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((6753 : ℝ) / 50000000) ((3469 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24996531 : ℝ) / 25000000) ((49993247 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((29133649 : ℝ) / 100000000) ((29311561 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((14564803 : ℝ) / 50000000) ((29307603 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((4234513 : ℝ) / 2000000) ((53318647 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((6234513 : ℝ) / 2000000) ((78318647 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((666651467 : ℝ) / 50000000) ((191475833 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15960439 : ℝ) / 50000000) ((32079491 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1047 : ℝ) / 320) ((10503 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4323959 : ℝ) / 100000000) ((4393359 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50660777 : ℝ) / 50000000) ((50669273 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((853369 : ℝ) / 20000000) ((542007 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((20853369 : ℝ) / 20000000) ((13042007 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((86950057 : ℝ) / 100000000) ((87584761 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((84668241 : ℝ) / 50000000) ((170629793 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53883339 : ℝ) / 100000000) ((27274131 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((32017 : ℝ) / 100000000) ((16627 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49983373 : ℝ) / 50000000) ((99967983 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((16928017 : ℝ) / 10000000) ((170575163 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((194751433 : ℝ) / 50000000) ((194816759 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((514749 : ℝ) / 10000000) ((81491 : ℝ) / 1562500) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1687 : ℝ) / 640) ((16903 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1948999 : ℝ) / 100000000) ((395717 : ℝ) / 20000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1566431 : ℝ) / 50000000) ((3207881 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51566431 : ℝ) / 50000000) ((103207881 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((687536737 : ℝ) / 50000000) ((1580945199 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((127749 : ℝ) / 12500000) ((1036559 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((12627749 : ℝ) / 12500000) ((101036559 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16123553 : ℝ) / 50000000) ((16206007 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((70366029 : ℝ) / 5000000) ((1613357213 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((3428583 : ℝ) / 12500000) ((7980411 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1687 : ℝ) / 640) ((16903 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((20853369 : ℝ) / 10000000) ((13042007 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((341305953 : ℝ) / 25000000) ((312777231 : ℝ) / 20000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2846951591 : ℝ) / 100000000) ((3263394269 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8077287 : ℝ) / 100000000) ((9276919 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-125805709 : ℝ) / 50000000) ((-237764069 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_770.1 cov_log_771.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((514749 : ℝ) / 20000000) ((81491 : ℝ) / 3125000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-18299041 : ℝ) / 5000000) ((-364669697 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_772.1 cov_log_773.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((13331077 : ℝ) / 20000000) ((2667557 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_759.1 cov_log_760.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((109044043 : ℝ) / 100000000) ((109442779 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-256936777 : ℝ) / 100000000) ((-127613459 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3216971 : ℝ) / 25000000) ((7081439 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((40310843 : ℝ) / 100000000) ((51635319 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-108312967 : ℝ) / 50000000) ((-203591599 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((20853369 : ℝ) / 20000000) ((13042007 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-125805709 : ℝ) / 50000000) ((-237764069 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-108312967 : ℝ) / 50000000) ((-203591599 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((151 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1566431 : ℝ) / 50000000) ((3207881 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((103207881 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((151 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-27763707 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((151 : ℝ) / 50) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_11, cov_h_10]
  have hP : ((30650143 : ℝ) / 5000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((203591599 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((203591599 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1377 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1377 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1397 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1397 : ℝ) / 500)) (lo := ((1377 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1417 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1417 : ℝ) / 500)) (lo := ((1397 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1437 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1437 : ℝ) / 500)) (lo := ((1417 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1457 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1457 : ℝ) / 500)) (lo := ((1437 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1477 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1477 : ℝ) / 500)) (lo := ((1457 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1497 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1497 : ℝ) / 500)) (lo := ((1477 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((151 : ℝ) / 50)) (lo := ((1497 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_42 {k : ℝ} (hk : RB k ((1047 : ℝ) / 640) ((10503 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((1047 : ℝ) / 1687) ((10503 : ℝ) / 16903) ∧
    RB (qa (r1A k)) ((660777 : ℝ) / 50000000) ((669273 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((194751433 : ℝ) / 100000000) ((194816759 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((40898437 : ℝ) / 100000000) ((2564209 : ℝ) / 6250000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((11848291 : ℝ) / 6250000) ((189701563 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((68842693 : ℝ) / 50000000) ((137732191 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139553371 : ℝ) / 50000000) ((69788387 : ℝ) / 25000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139553371 : ℝ) / 100000000) ((69788387 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((194751433 : ℝ) / 100000000) ((194816759 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((10298437 : ℝ) / 100000000) ((651709 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2574609 : ℝ) / 100000000) ((651709 : ℝ) / 25000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((660777 : ℝ) / 50000000) ((669273 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((194751433 : ℝ) / 100000000) ((194816759 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((660777 : ℝ) / 50000000) ((669273 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1047 : ℝ) / 1687) ((10503 : ℝ) / 16903) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_42 {k : ℝ} (hk : RB k ((1047 : ℝ) / 640) ((10503 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_42 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_42 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((104317 : ℝ) / 250000)) (ph := ((5272949 : ℝ) / 12500000)) (ml := ((129133649 : ℝ) / 100000000)) (mh := ((129311561 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_42 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_43 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10503 : ℝ) / 16903) ((1317 : ℝ) / 2117))
    (hq : RB (qa a) ((83659 : ℝ) / 6250000) ((338887 : ℝ) / 25000000))
    (hd : RB (D0a a) ((1946861 : ℝ) / 1000000) ((194751437 : ℝ) / 100000000))
    : certE k a ((41677357 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((1685139 : ℝ) / 4000000) ∧ 0 < certE k a ((129193111 : ℝ) / 100000000) ∧ certE k a ((129370547 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17917 : ℝ) / 100000000) ((2297 : ℝ) / 12500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((41677357 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((41658981 : ℝ) / 100000000) ((520743 : ℝ) / 1250000) := rb_widen (rb_sub (show RB ((41677357 : ℝ) / 100000000) ((41677357 : ℝ) / 100000000) ((41677357 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((58322643 : ℝ) / 100000000))
  have h3 : RB z3 ((35714243 : ℝ) / 50000000) ((35714637 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((58322643 : ℝ) / 100000000) ((58322643 : ℝ) / 100000000) ((58322643 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2102959 : ℝ) / 6250000) ((-210289 : ℝ) / 625000) := rb_log h3 (by norm_num) cov_log_774.1 cov_log_775.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-261653 : ℝ) / 1250000) ((-2090673 : ℝ) / 10000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((41677357 : ℝ) / 100000000))
  have h6 : RB z6 ((-43760611 : ℝ) / 50000000) ((-4376061 : ℝ) / 5000000) := rb_log (show RB ((41677357 : ℝ) / 100000000) ((41677357 : ℝ) / 100000000) ((41677357 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_776.1 cov_log_776.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((3329449 : ℝ) / 5000000) ((16653623 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66621833 : ℝ) / 100000000) ((66655389 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_777.1 cov_log_778.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-66409 : ℝ) / 100000000) ((-7341 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17917 : ℝ) / 100000000) ((2297 : ℝ) / 12500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((1685139 : ℝ) / 4000000)) - (z10)
  have h11 : RB z11 ((42110099 : ℝ) / 100000000) ((21055279 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1685139 : ℝ) / 4000000) ((1685139 : ℝ) / 4000000) ((1685139 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((2314861 : ℝ) / 4000000))
  have h12 : RB z12 ((72764799 : ℝ) / 100000000) ((72765593 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((2314861 : ℝ) / 4000000) ((2314861 : ℝ) / 4000000) ((2314861 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-7948447 : ℝ) / 25000000) ((-3974087 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_779.1 cov_log_780.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-19779131 : ℝ) / 100000000) ((-3950999 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((1685139 : ℝ) / 4000000))
  have h15 : RB z15 ((-10805579 : ℝ) / 12500000) ((-8644463 : ℝ) / 10000000) := rb_log (show RB ((1685139 : ℝ) / 4000000) ((1685139 : ℝ) / 4000000) ((1685139 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_781.1 cov_log_781.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66665499 : ℝ) / 100000000) ((66689637 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66621833 : ℝ) / 100000000) ((66655389 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_777.1 cov_log_778.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1011 : ℝ) / 10000000) ((16951 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17917 : ℝ) / 100000000) ((2297 : ℝ) / 12500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((129193111 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((25834947 : ℝ) / 20000000) ((64587597 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((129193111 : ℝ) / 100000000) ((129193111 : ℝ) / 100000000) ((129193111 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((29193111 : ℝ) / 100000000))
  have h21 : RB z21 ((221241811 : ℝ) / 50000000) ((88497039 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((29193111 : ℝ) / 100000000) ((29193111 : ℝ) / 100000000) ((29193111 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((74361663 : ℝ) / 50000000) ((37180921 : ℝ) / 25000000) := rb_log h21 (by norm_num) cov_log_782.1 cov_log_783.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46206031 : ℝ) / 50000000) ((92522009 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((129193111 : ℝ) / 100000000))
  have h24 : RB z24 ((1600863 : ℝ) / 6250000) ((25613809 : ℝ) / 100000000) := rb_log (show RB ((129193111 : ℝ) / 100000000) ((129193111 : ℝ) / 100000000) ((129193111 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_784.1 cov_log_784.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((66798253 : ℝ) / 100000000) ((66908201 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66621833 : ℝ) / 100000000) ((66655389 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_777.1 cov_log_778.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((8929 : ℝ) / 6250000) ((8949 : ℝ) / 3125000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17917 : ℝ) / 100000000) ((2297 : ℝ) / 12500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129370547 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((129352171 : ℝ) / 100000000) ((12935263 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((129370547 : ℝ) / 100000000) ((129370547 : ℝ) / 100000000) ((129370547 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29370547 : ℝ) / 100000000))
  have h30 : RB z30 ((440414579 : ℝ) / 100000000) ((440416143 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((29370547 : ℝ) / 100000000) ((29370547 : ℝ) / 100000000) ((29370547 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((18531829 : ℝ) / 12500000) ((14825499 : ℝ) / 10000000) := rb_log h30 (by norm_num) cov_log_785.1 cov_log_786.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((9212083 : ℝ) / 10000000) ((92230431 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129370547 : ℝ) / 100000000))
  have h33 : RB z33 ((5150211 : ℝ) / 20000000) ((1609441 : ℝ) / 6250000) := rb_log (show RB ((129370547 : ℝ) / 100000000) ((129370547 : ℝ) / 100000000) ((129370547 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_787.1 cov_log_787.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33184887 : ℝ) / 50000000) ((4154961 : ℝ) / 6250000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66621833 : ℝ) / 100000000) ((66655389 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_777.1 cov_log_778.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-57123 : ℝ) / 20000000) ((-142457 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((41677357 : ℝ) / 100000000)) ((-66409 : ℝ) / 100000000) ((-7341 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((1685139 : ℝ) / 4000000)) ((1011 : ℝ) / 10000000) ((16951 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((129193111 : ℝ) / 100000000)) ((8929 : ℝ) / 6250000) ((8949 : ℝ) / 3125000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129370547 : ℝ) / 100000000)) ((-57123 : ℝ) / 20000000) ((-142457 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_43 {k A q d vp vm : ℝ}
    (hk : RB k ((10503 : ℝ) / 6400) ((1317 : ℝ) / 800))
    (hA : RB A ((10503 : ℝ) / 16903) ((1317 : ℝ) / 2117))
    (hq : RB q ((83659 : ℝ) / 6250000) ((338887 : ℝ) / 25000000))
    (hd : RB d ((1946861 : ℝ) / 1000000) ((194751437 : ℝ) / 100000000))
    (hp : RB vp ((41677357 : ℝ) / 100000000) ((1685139 : ℝ) / 4000000))
    (hm : RB vm ((129193111 : ℝ) / 100000000) ((129370547 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17917 : ℝ) / 100000000) ((2297 : ℝ) / 12500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((12497703 : ℝ) / 12500000) ((99982083 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((1553137 : ℝ) / 2500000) ((6219953 : ℝ) / 10000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((42529 : ℝ) / 100000000) ((11023 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24988977 : ℝ) / 25000000) ((99957471 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((2314861 : ℝ) / 4000000) ((58322643 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7230751 : ℝ) / 12500000) ((58297839 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((21313133 : ℝ) / 20000000) ((21505211 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1313133 : ℝ) / 20000000) ((1505211 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((12497703 : ℝ) / 12500000) ((99982083 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((1553137 : ℝ) / 2500000) ((6219953 : ℝ) / 10000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((13849 : ℝ) / 100000000) ((889 : ℝ) / 6250000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((6249111 : ℝ) / 6250000) ((99986151 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((29193111 : ℝ) / 100000000) ((29370547 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((14594479 : ℝ) / 50000000) ((367081 : ℝ) / 1250000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((105776177 : ℝ) / 50000000) ((213092671 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((155776177 : ℝ) / 50000000) ((313092671 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1328717369 : ℝ) / 100000000) ((1523074967 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((1277577 : ℝ) / 4000000) ((6419467 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10503 : ℝ) / 3200) ((1317 : ℝ) / 400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((549169 : ℝ) / 12500000) ((2231571 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((6333659 : ℝ) / 6250000) ((25338887 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2167297 : ℝ) / 50000000) ((440419 : ℝ) / 10000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((52167297 : ℝ) / 50000000) ((10440419 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((21766159 : ℝ) / 25000000) ((8769319 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((21187843 : ℝ) / 12500000) ((42695937 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((26922137 : ℝ) / 50000000) ((54501839 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((16437 : ℝ) / 50000000) ((34129 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99965871 : ℝ) / 100000000) ((49983563 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((84722447 : ℝ) / 50000000) ((34145521 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((1946861 : ℝ) / 500000) ((194751437 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2605959 : ℝ) / 50000000) ((5279899 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16903 : ℝ) / 6400) ((2117 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((492387 : ℝ) / 25000000) ((999567 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((317729 : ℝ) / 10000000) ((3252481 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((10317729 : ℝ) / 10000000) ((103252481 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1370934573 : ℝ) / 100000000) ((1572612691 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((517329 : ℝ) / 50000000) ((524621 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50517329 : ℝ) / 50000000) ((50524621 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((504217 : ℝ) / 1562500) ((16217057 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1403204461 : ℝ) / 100000000) ((321009361 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5527357 : ℝ) / 20000000) ((32087037 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16903 : ℝ) / 6400) ((2117 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((52167297 : ℝ) / 25000000) ((10440419 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((680328397 : ℝ) / 50000000) ((777586151 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2839271483 : ℝ) / 100000000) ((3247330091 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8133123 : ℝ) / 100000000) ((9320173 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-10036901 : ℝ) / 4000000) ((-237298899 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_788.1 cov_log_789.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2605959 : ℝ) / 100000000) ((52799 : ℝ) / 2000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-364736949 : ℝ) / 100000000) ((-18172051 : ℝ) / 5000000) := rb_log h49 (by norm_num) cov_log_790.1 cov_log_791.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66621833 : ℝ) / 100000000) ((66655389 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_777.1 cov_log_778.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((109332673 : ℝ) / 100000000) ((21946287 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-63851069 : ℝ) / 25000000) ((-50741917 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((6357721 : ℝ) / 50000000) ((6999077 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((39627971 : ℝ) / 100000000) ((50650443 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-43155261 : ℝ) / 20000000) ((-101529571 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((52167297 : ℝ) / 50000000) ((10440419 : ℝ) / 10000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-10036901 : ℝ) / 4000000) ((-237298899 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-43155261 : ℝ) / 20000000) ((-101529571 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((151 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((317729 : ℝ) / 10000000) ((3252481 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((103252481 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((151 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-221420763 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((151 : ℝ) / 50) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_11, cov_h_10]
  have hP : ((76375083 : ℝ) / 12500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((101529571 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((101529571 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2753 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2753 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2793 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2793 : ℝ) / 1000)) (lo := ((2753 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2833 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2833 : ℝ) / 1000)) (lo := ((2793 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2873 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2873 : ℝ) / 1000)) (lo := ((2833 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2913 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2913 : ℝ) / 1000)) (lo := ((2873 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2953 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2953 : ℝ) / 1000)) (lo := ((2913 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2993 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2993 : ℝ) / 1000)) (lo := ((2953 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((151 : ℝ) / 50)) (lo := ((2993 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_43 {k : ℝ} (hk : RB k ((10503 : ℝ) / 6400) ((1317 : ℝ) / 800)) :
    RB (k / (k + 1)) ((10503 : ℝ) / 16903) ((1317 : ℝ) / 2117) ∧
    RB (qa (r1A k)) ((83659 : ℝ) / 6250000) ((338887 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((1946861 : ℝ) / 1000000) ((194751437 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((41027343 : ℝ) / 100000000) ((1317 : ℝ) / 3200) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((30311 : ℝ) / 16000) ((189572657 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((68819283 : ℝ) / 50000000) ((137685387 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139529961 : ℝ) / 50000000) ((34888343 : ℝ) / 12500000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139529961 : ℝ) / 100000000) ((34888343 : ℝ) / 25000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((1946861 : ℝ) / 1000000) ((194751437 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((10427343 : ℝ) / 100000000) ((1689 : ℝ) / 16000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((521367 : ℝ) / 20000000) ((2639063 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((83659 : ℝ) / 6250000) ((338887 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((1946861 : ℝ) / 1000000) ((194751437 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((83659 : ℝ) / 6250000) ((338887 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10503 : ℝ) / 16903) ((1317 : ℝ) / 2117) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_43 {k : ℝ} (hk : RB k ((10503 : ℝ) / 6400) ((1317 : ℝ) / 800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_43 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_43 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((41677357 : ℝ) / 100000000)) (ph := ((1685139 : ℝ) / 4000000)) (ml := ((129193111 : ℝ) / 100000000)) (mh := ((129370547 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_43 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_44 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1317 : ℝ) / 2117) ((10569 : ℝ) / 16969))
    (hq : RB (qa a) ((1355547 : ℝ) / 100000000) ((686281 : ℝ) / 50000000))
    (hd : RB (D0a a) ((38924151 : ℝ) / 20000000) ((194686103 : ℝ) / 100000000))
    : certE k a ((20814241 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((262963 : ℝ) / 625000) ∧ 0 < certE k a ((64626207 : ℝ) / 50000000) ∧ certE k a ((1011167 : ℝ) / 781250) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((147 : ℝ) / 800000) ((471 : ℝ) / 2500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((20814241 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((20804821 : ℝ) / 50000000) ((41610107 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((20814241 : ℝ) / 50000000) ((20814241 : ℝ) / 50000000) ((20814241 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((29185759 : ℝ) / 50000000))
  have h3 : RB z3 ((8910519 : ℝ) / 12500000) ((1425699 : ℝ) / 2000000) := rb_div_signed h2 (show RB ((29185759 : ℝ) / 50000000) ((29185759 : ℝ) / 50000000) ((29185759 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2115601 : ℝ) / 6250000) ((-2115531 : ℝ) / 6250000) := rb_log h3 (by norm_num) cov_log_792.1 cov_log_793.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-21082951 : ℝ) / 100000000) ((-10528689 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((20814241 : ℝ) / 50000000))
  have h6 : RB z6 ((-547741 : ℝ) / 625000) ((-43819279 : ℝ) / 50000000) := rb_log (show RB ((20814241 : ℝ) / 50000000) ((20814241 : ℝ) / 50000000) ((20814241 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_794.1 cov_log_794.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66555607 : ℝ) / 100000000) ((33290591 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66588263 : ℝ) / 100000000) ((16655459 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_795.1 cov_log_796.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-66229 : ℝ) / 100000000) ((-7081 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((147 : ℝ) / 800000) ((471 : ℝ) / 2500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((262963 : ℝ) / 625000)) - (z10)
  have h11 : RB z11 ((1051381 : ℝ) / 2500000) ((8411141 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((262963 : ℝ) / 625000) ((262963 : ℝ) / 625000) ((262963 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((362037 : ℝ) / 625000))
  have h12 : RB z12 ((18150441 : ℝ) / 25000000) ((9075321 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((362037 : ℝ) / 625000) ((362037 : ℝ) / 625000) ((362037 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-32018097 : ℝ) / 100000000) ((-32016989 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_797.1 cov_log_798.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3988441 : ℝ) / 20000000) ((-3983597 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((262963 : ℝ) / 625000))
  have h15 : RB z15 ((-86573833 : ℝ) / 100000000) ((-86573831 : ℝ) / 100000000) := rb_log (show RB ((262963 : ℝ) / 625000) ((262963 : ℝ) / 625000) ((262963 : ℝ) / 625000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_799.1 cov_log_799.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33315813 : ℝ) / 50000000) ((8331981 : ℝ) / 12500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66588263 : ℝ) / 100000000) ((16655459 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_795.1 cov_log_796.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((979 : ℝ) / 10000000) ((13517 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((147 : ℝ) / 800000) ((471 : ℝ) / 2500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((64626207 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((64616787 : ℝ) / 50000000) ((129234039 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((64626207 : ℝ) / 50000000) ((64626207 : ℝ) / 50000000) ((64626207 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((14626207 : ℝ) / 50000000))
  have h21 : RB z21 ((441787723 : ℝ) / 100000000) ((220894657 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((14626207 : ℝ) / 50000000) ((14626207 : ℝ) / 50000000) ((14626207 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((148565931 : ℝ) / 100000000) ((74283147 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_800.1 cov_log_801.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92423869 : ℝ) / 100000000) ((92533277 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((64626207 : ℝ) / 50000000))
  have h24 : RB z24 ((256597 : ℝ) / 1000000) ((25659701 : ℝ) / 100000000) := rb_log (show RB ((64626207 : ℝ) / 50000000) ((64626207 : ℝ) / 50000000) ((64626207 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_802.1 cov_log_802.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((8345521 : ℝ) / 12500000) ((66873577 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66588263 : ℝ) / 100000000) ((16655459 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_795.1 cov_log_796.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((35583 : ℝ) / 25000000) ((142657 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((147 : ℝ) / 800000) ((471 : ℝ) / 2500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((1011167 : ℝ) / 781250)) - (z28)
  have h29 : RB z29 ((16176317 : ℝ) / 12500000) ((129411001 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1011167 : ℝ) / 781250) ((1011167 : ℝ) / 781250) ((1011167 : ℝ) / 781250) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((229917 : ℝ) / 781250))
  have h30 : RB z30 ((439732517 : ℝ) / 100000000) ((219867049 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((229917 : ℝ) / 781250) ((229917 : ℝ) / 781250) ((229917 : ℝ) / 781250) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((148099643 : ℝ) / 100000000) ((74050003 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_803.1 cov_log_804.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((23033447 : ℝ) / 25000000) ((92242853 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((1011167 : ℝ) / 781250))
  have h33 : RB z33 ((12898259 : ℝ) / 50000000) ((25796519 : ℝ) / 100000000) := rb_log (show RB ((1011167 : ℝ) / 781250) ((1011167 : ℝ) / 781250) ((1011167 : ℝ) / 781250) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_805.1 cov_log_805.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((66337269 : ℝ) / 100000000) ((13289267 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66588263 : ℝ) / 100000000) ((16655459 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_795.1 cov_log_796.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-284567 : ℝ) / 100000000) ((-17741 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((20814241 : ℝ) / 50000000)) ((-66229 : ℝ) / 100000000) ((-7081 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((262963 : ℝ) / 625000)) ((979 : ℝ) / 10000000) ((13517 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((64626207 : ℝ) / 50000000)) ((35583 : ℝ) / 25000000) ((142657 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((1011167 : ℝ) / 781250)) ((-284567 : ℝ) / 100000000) ((-17741 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_44 {k A q d vp vm : ℝ}
    (hk : RB k ((1317 : ℝ) / 800) ((10569 : ℝ) / 6400))
    (hA : RB A ((1317 : ℝ) / 2117) ((10569 : ℝ) / 16969))
    (hq : RB q ((1355547 : ℝ) / 100000000) ((686281 : ℝ) / 50000000))
    (hd : RB d ((38924151 : ℝ) / 20000000) ((194686103 : ℝ) / 100000000))
    (hp : RB vp ((20814241 : ℝ) / 50000000) ((262963 : ℝ) / 625000))
    (hm : RB vm ((64626207 : ℝ) / 50000000) ((1011167 : ℝ) / 781250))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((147 : ℝ) / 800000) ((471 : ℝ) / 2500000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((2499529 : ℝ) / 2500000) ((799853 : ℝ) / 800000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((31099477 : ℝ) / 50000000) ((62272721 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((5459 : ℝ) / 12500000) ((22629 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49977371 : ℝ) / 50000000) ((12494541 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((362037 : ℝ) / 625000) ((29185759 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57899703 : ℝ) / 100000000) ((29173013 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53301791 : ℝ) / 50000000) ((107552747 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3301791 : ℝ) / 50000000) ((7552747 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((2499529 : ℝ) / 2500000) ((799853 : ℝ) / 800000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((31099477 : ℝ) / 50000000) ((62272721 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3549 : ℝ) / 25000000) ((14577 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99985423 : ℝ) / 100000000) ((24996451 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((14626207 : ℝ) / 50000000) ((229917 : ℝ) / 781250) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((29248149 : ℝ) / 100000000) ((29425199 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((52844973 : ℝ) / 25000000) ((42582333 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((77844973 : ℝ) / 25000000) ((62582333 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1324021577 : ℝ) / 100000000) ((94645603 : ℝ) / 6250000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((319579 : ℝ) / 1000000) ((4014389 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1317 : ℝ) / 400) ((10569 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2231569 : ℝ) / 50000000) ((906663 : ℝ) / 20000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101355547 : ℝ) / 100000000) ((50686281 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1100677 : ℝ) / 25000000) ((2236343 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((26100677 : ℝ) / 25000000) ((52236343 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((43589167 : ℝ) / 50000000) ((43900447 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((169667131 : ℝ) / 100000000) ((170936139 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53805817 : ℝ) / 100000000) ((2722811 : ℝ) / 5000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((16871 : ℝ) / 50000000) ((7003 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19992997 : ℝ) / 20000000) ((49983129 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((84803861 : ℝ) / 50000000) ((85439231 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((38924151 : ℝ) / 10000000) ((194686103 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5276351 : ℝ) / 100000000) ((8551 : ℝ) / 160000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((2117 : ℝ) / 800) ((16969 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1990019 : ℝ) / 100000000) ((504901 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((322181 : ℝ) / 10000000) ((3297171 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((10322181 : ℝ) / 10000000) ((103297171 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((341669759 : ℝ) / 25000000) ((782129843 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((41893 : ℝ) / 4000000) ((265481 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((4041893 : ℝ) / 4000000) ((25265481 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32292603 : ℝ) / 100000000) ((32456151 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1398971639 : ℝ) / 100000000) ((1596715837 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((27839801 : ℝ) / 100000000) ((32247337 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((2117 : ℝ) / 800) ((16969 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((26100677 : ℝ) / 12500000) ((52236343 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1355979477 : ℝ) / 100000000) ((38661119 : ℝ) / 2500000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2831358587 : ℝ) / 100000000) ((3231224757 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8189619 : ℝ) / 100000000) ((585277 : ℝ) / 6250000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-50046057 : ℝ) / 20000000) ((-4736503 : ℝ) / 2000000) := rb_log h47 (by norm_num) cov_log_806.1 cov_log_807.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((105527 : ℝ) / 4000000) ((668047 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-72701657 : ℝ) / 20000000) ((-362227257 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_808.1 cov_log_809.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66588263 : ℝ) / 100000000) ((16655459 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_795.1 cov_log_796.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((109620927 : ℝ) / 100000000) ((110019717 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-126943679 : ℝ) / 50000000) ((-12610377 : ℝ) / 5000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2512917 : ℝ) / 20000000) ((6917663 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((3896317 : ℝ) / 10000000) ((49696211 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-53731047 : ℝ) / 25000000) ((-202511329 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((26100677 : ℝ) / 25000000) ((52236343 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-50046057 : ℝ) / 20000000) ((-4736503 : ℝ) / 2000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-53731047 : ℝ) / 25000000) ((-202511329 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((301 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((322181 : ℝ) / 10000000) ((3297171 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((103297171 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((301 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-220468723 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((301 : ℝ) / 100) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_12, cov_h_10]
  have hP : ((608952793 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((202511329 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((202511329 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((689 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((689 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((699 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((699 : ℝ) / 250)) (lo := ((689 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((709 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((709 : ℝ) / 250)) (lo := ((699 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((719 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((719 : ℝ) / 250)) (lo := ((709 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((729 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((729 : ℝ) / 250)) (lo := ((719 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((739 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((739 : ℝ) / 250)) (lo := ((729 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((749 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((749 : ℝ) / 250)) (lo := ((739 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((301 : ℝ) / 100)) (lo := ((749 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_44 {k : ℝ} (hk : RB k ((1317 : ℝ) / 800) ((10569 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((1317 : ℝ) / 2117) ((10569 : ℝ) / 16969) ∧
    RB (qa (r1A k)) ((1355547 : ℝ) / 100000000) ((686281 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((38924151 : ℝ) / 20000000) ((194686103 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((1317 : ℝ) / 3200) ((41285157 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((189314843 : ℝ) / 100000000) ((30311 : ℝ) / 16000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((13759173 : ℝ) / 10000000) ((137638567 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139506543 : ℝ) / 50000000) ((69764981 : ℝ) / 25000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139506543 : ℝ) / 100000000) ((69764981 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((38924151 : ℝ) / 20000000) ((194686103 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1689 : ℝ) / 16000) ((10685157 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1319531 : ℝ) / 50000000) ((267129 : ℝ) / 10000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1355547 : ℝ) / 100000000) ((686281 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((38924151 : ℝ) / 20000000) ((194686103 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1355547 : ℝ) / 100000000) ((686281 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1317 : ℝ) / 2117) ((10569 : ℝ) / 16969) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_44 {k : ℝ} (hk : RB k ((1317 : ℝ) / 800) ((10569 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_44 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_44 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((20814241 : ℝ) / 50000000)) (ph := ((262963 : ℝ) / 625000)) (ml := ((64626207 : ℝ) / 50000000)) (mh := ((1011167 : ℝ) / 781250)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_44 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
