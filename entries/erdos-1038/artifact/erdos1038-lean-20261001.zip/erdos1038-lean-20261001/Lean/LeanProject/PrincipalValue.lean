import LeanProject.JumpAdjointEquality
import LeanProject.MaterialDictionary
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

/-! Raw symmetric principal values and the absolutely integrable transform `HT`.

Principal values below are limits of the original, unsubtracted singular kernel.
Both angular and spatial excisions are treated at the filter `𝓝[>] 0`.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral
open scoped ENNReal

namespace EP1038.Stage11
open EP1038.Arc AngleReference

noncomputable def pvPrimitive (θ φ : ℝ) : ℝ :=
  (log |sin ((φ - θ) / 2)| - log |sin ((φ + θ) / 2)|) / sin θ

theorem cos_gap_factor (θ φ : ℝ) :
    cos θ - cos φ = 2 * sin ((φ + θ) / 2) * sin ((φ - θ) / 2) := by
  rw [cos_sub_cos, show (θ - φ) / 2 = -((φ - θ) / 2) by ring, sin_neg]
  ring

theorem pv_sines_nonzero {θ φ : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hφ : φ ∈ Icc (0 : ℝ) π) (hne : φ ≠ θ) :
    sin ((φ - θ) / 2) ≠ 0 ∧ 0 < sin ((φ + θ) / 2) := by
  have hsum : 0 < sin ((φ + θ) / 2) :=
    sin_pos_of_pos_of_lt_pi (by linarith [hφ.1, hθ.1]) (by linarith [hφ.2, hθ.2])
  refine ⟨?_, hsum⟩
  intro hdiff
  have hc : cos θ = cos φ := by
    have := cos_gap_factor θ φ
    rw [hdiff, mul_zero] at this
    linarith
  exact hne (Real.injOn_cos hφ ⟨hθ.1.le, hθ.2.le⟩ hc.symm)

theorem hasDerivAt_pvPrimitive {θ φ : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hφ : φ ∈ Icc (0 : ℝ) π) (hne : φ ≠ θ) :
    HasDerivAt (pvPrimitive θ) (1 / (cos θ - cos φ)) φ := by
  obtain ⟨hd, hs⟩ := pv_sines_nonzero hθ hφ hne
  have ht := sin_pos_of_pos_of_lt_pi hθ.1 hθ.2
  have hc : cos θ - cos φ ≠ 0 := by
    rw [cos_gap_factor]
    exact mul_ne_zero (mul_ne_zero (by norm_num) hs.ne') hd
  have hdiff := (Real.hasDerivAt_sin ((φ - θ) / 2)).comp φ
    (((hasDerivAt_id φ).sub_const θ).div_const 2)
  have hsum := (Real.hasDerivAt_sin ((φ + θ) / 2)).comp φ
    (((hasDerivAt_id φ).add_const θ).div_const 2)
  have h := ((hdiff.log hd).sub (hsum.log hs.ne')).div_const (sin θ)
  have he : cos ((φ - θ) / 2) * sin ((φ + θ) / 2) -
      cos ((φ + θ) / 2) * sin ((φ - θ) / 2) = sin θ := by
    have h := Real.sin_sub ((φ + θ) / 2) ((φ - θ) / 2)
    rw [show (φ + θ) / 2 - (φ - θ) / 2 = θ by ring] at h
    linarith
  convert h using 1
  · funext x
    simp only [pvPrimitive, log_abs, Function.comp_apply, id_eq, Pi.sub_apply]
  · simp only [Function.comp_apply, id_eq]
    rw [cos_gap_factor]
    field_simp [hd, hs.ne', ht.ne']
    nlinarith

theorem pvPrimitive_zero (θ : ℝ) : pvPrimitive θ 0 = 0 := by
  simp only [pvPrimitive, zero_sub, zero_add, neg_div, sin_neg, abs_neg, sub_self, zero_div]

theorem pvPrimitive_pi (θ : ℝ) : pvPrimitive θ π = 0 := by
  have he : sin ((π - θ) / 2) = sin ((π + θ) / 2) := by
    rw [show (π + θ) / 2 = π - (π - θ) / 2 by ring, sin_pi_sub]
  simp only [pvPrimitive, he, sub_self, zero_div]

theorem integral_cos_kernel {θ a b : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (ha : a ∈ Icc (0 : ℝ) π) (hb : b ∈ Icc (0 : ℝ) π) (hab : a ≤ b)
    (hside : b < θ ∨ θ < a) :
    (∫ φ in a..b, 1 / (cos θ - cos φ)) = pvPrimitive θ b - pvPrimitive θ a := by
  have hmem : ∀ φ ∈ Icc a b, φ ∈ Icc (0 : ℝ) π := fun φ hφ =>
    ⟨ha.1.trans hφ.1, hφ.2.trans hb.2⟩
  have hne : ∀ φ ∈ Icc a b, φ ≠ θ := by
    intro φ hφ
    rcases hside with hl | hr
    · exact (hφ.2.trans_lt hl).ne
    · exact (hr.trans_le hφ.1).ne'
  have hc : ∀ φ ∈ Icc a b, cos θ - cos φ ≠ 0 := by
    intro φ hφ hh
    exact hne φ hφ (Real.injOn_cos (hmem φ hφ) ⟨hθ.1.le, hθ.2.le⟩ (by linarith))
  have hcont : ContinuousOn (fun φ => 1 / (cos θ - cos φ)) (Icc a b) :=
    continuousOn_const.div (continuousOn_const.sub Real.continuous_cos.continuousOn) hc
  apply intervalIntegral.integral_eq_sub_of_hasDerivAt
  · intro φ hφ
    rw [uIcc_of_le hab] at hφ
    exact hasDerivAt_pvPrimitive hθ (hmem φ hφ) (hne φ hφ)
  · exact hcont.intervalIntegrable_of_Icc hab

/-- The original raw transform on the two intervals remaining after excision. -/
noncomputable def rawCutTransform (f : ℝ → ℝ) (θ a b : ℝ) : ℝ :=
  1 / π * ((∫ φ in (0 : ℝ)..a, f φ / (cos θ - cos φ)) +
    ∫ φ in b..π, f φ / (cos θ - cos φ))

noncomputable def angularPVTrunc (f : ℝ → ℝ) (θ ε : ℝ) : ℝ :=
  rawCutTransform f θ (θ - ε) (θ + ε)

theorem angularPVTrunc_one_eq {θ ε : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hε : 0 < ε) (hεl : ε < θ) (hεr : ε < π - θ) :
    angularPVTrunc (fun _ => 1) θ ε = 1 / (π * sin θ) *
      (log |sin (θ + ε / 2)| - log |sin (θ - ε / 2)|) := by
  unfold angularPVTrunc rawCutTransform
  rw [integral_cos_kernel hθ ⟨le_rfl, Real.pi_pos.le⟩
      ⟨by linarith, by linarith [hθ.2]⟩ (by linarith) (Or.inl (by linarith)),
    integral_cos_kernel hθ ⟨by linarith [hθ.1], by linarith⟩
      ⟨Real.pi_pos.le, le_rfl⟩ (by linarith) (Or.inr (by linarith)),
    pvPrimitive_zero, pvPrimitive_pi]
  simp only [pvPrimitive, show (θ - ε - θ) / 2 = -(ε / 2) by ring,
    show (θ + ε - θ) / 2 = ε / 2 by ring,
    show (θ - ε + θ) / 2 = θ - ε / 2 by ring,
    show (θ + ε + θ) / 2 = θ + ε / 2 by ring, sin_neg, abs_neg]
  ring

/-- The constant part of the raw angular PV converges to zero. -/
theorem tendsto_angularPVTrunc_one {θ : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π) :
    Tendsto (angularPVTrunc (fun _ => 1) θ) (𝓝[>] (0 : ℝ)) (𝓝 0) := by
  have hs := sin_pos_of_pos_of_lt_pi hθ.1 hθ.2
  have hp : ContinuousAt (fun ε : ℝ => log |sin (θ + ε / 2)|) 0 := by
    simp only [log_abs]
    fun_prop (disch := simpa using hs.ne')
  have hm : ContinuousAt (fun ε : ℝ => log |sin (θ - ε / 2)|) 0 := by
    simp only [log_abs]
    fun_prop (disch := simpa using hs.ne')
  have hh : Tendsto (fun ε : ℝ => 1 / (π * sin θ) *
      (log |sin (θ + ε / 2)| - log |sin (θ - ε / 2)|)) (𝓝[>] 0) (𝓝 0) := by
    simpa only [Pi.sub_apply, zero_div, add_zero, sub_zero, sub_self, mul_zero] using
      ((hp.sub hm).const_mul (1 / (π * sin θ))).tendsto.mono_left
        (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
  apply hh.congr'
  have hl : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < θ :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < θ from Iio_mem_nhds hθ.1).filter_mono nhdsWithin_le_nhds
  have hr : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < π - θ :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < π - θ from
      Iio_mem_nhds (by linarith [hθ.2] : 0 < π - θ)).filter_mono nhdsWithin_le_nhds
  filter_upwards [self_mem_nhdsWithin, hl, hr] with ε hε hεl hεr
  exact (angularPVTrunc_one_eq hθ hε hεl hεr).symm

theorem intervalIntegrable_cos_kernel {θ a b : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (ha : a ∈ Icc (0 : ℝ) π) (hb : b ∈ Icc (0 : ℝ) π) (hab : a ≤ b)
    (hside : b < θ ∨ θ < a) :
    IntervalIntegrable (fun φ => 1 / (cos θ - cos φ)) volume a b := by
  apply ContinuousOn.intervalIntegrable_of_Icc hab
  apply continuousOn_const.div (continuousOn_const.sub Real.continuous_cos.continuousOn)
  intro φ hφ hh
  change cos θ - cos φ = 0 at hh
  have hp : φ ∈ Icc (0 : ℝ) π := ⟨ha.1.trans hφ.1, hφ.2.trans hb.2⟩
  have he : φ = θ := Real.injOn_cos hp ⟨hθ.1.le, hθ.2.le⟩ (by linarith)
  rcases hside with hl | hr
  · linarith [hφ.2]
  · linarith [hφ.1]

/-- Exact separation of the integrable difference quotient and the raw constant part. -/
theorem rawCutTransform_decomposition {f : ℝ → ℝ} {θ a b : ℝ}
    (hθ : θ ∈ Ioo (0 : ℝ) π) (ha : a ∈ Icc (0 : ℝ) θ) (hb : b ∈ Icc θ π)
    (hal : a < θ) (hbr : θ < b)
    (hi : IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π) :
    rawCutTransform f θ a b = 1 / π *
      ((∫ φ in (0 : ℝ)..a, (f φ - f θ) / (cos θ - cos φ)) +
        ∫ φ in b..π, (f φ - f θ) / (cos θ - cos φ)) +
      f θ * rawCutTransform (fun _ => 1) θ a b := by
  have hil := hi.mono_set (by
    rw [uIcc_of_le ha.1, uIcc_of_le Real.pi_pos.le]
    exact Icc_subset_Icc le_rfl (ha.2.trans hθ.2.le))
  have hir := hi.mono_set (by
    rw [uIcc_of_le hb.2, uIcc_of_le Real.pi_pos.le]
    exact Icc_subset_Icc (hθ.1.le.trans hb.1) le_rfl)
  have hkl := intervalIntegrable_cos_kernel hθ ⟨le_rfl, Real.pi_pos.le⟩
    ⟨ha.1, ha.2.trans hθ.2.le⟩ ha.1 (Or.inl hal)
  have hkr := intervalIntegrable_cos_kernel hθ ⟨hθ.1.le.trans hb.1, hb.2⟩
    ⟨Real.pi_pos.le, le_rfl⟩ hb.2 (Or.inr hbr)
  have he : (fun φ => f φ / (cos θ - cos φ)) =
      (fun φ => (f φ - f θ) / (cos θ - cos φ) + f θ * (1 / (cos θ - cos φ))) := by
    funext φ
    simp only [sub_div, one_div, div_eq_mul_inv]
    ring
  unfold rawCutTransform
  rw [he, intervalIntegral.integral_add hil (hkl.const_mul _),
    intervalIntegral.integral_add hir (hkr.const_mul _),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul]
  ring

/-- Any pair of cuts approaching an interior point preserves an integrable fiber integral. -/
theorem tendsto_cut_fiber_integrals {ι : Type*} {l : Filter ι} {a b : ι → ℝ}
    {g : ℝ → ℝ} {θ : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hi : IntervalIntegrable g volume 0 π)
    (ha : Tendsto a l (𝓝 θ)) (hb : Tendsto b l (𝓝 θ)) :
    Tendsto (fun t => (∫ φ in (0 : ℝ)..a t, g φ) + ∫ φ in b t..π, g φ)
      l (𝓝 (∫ φ in (0 : ℝ)..π, g φ)) := by
  have hc := continuousOn_primitive_interval' hi (a := 0) left_mem_uIcc
  rw [uIcc_of_le Real.pi_pos.le] at hc
  have hn := Icc_mem_nhds hθ.1 hθ.2
  have ht := (hc.continuousAt hn).tendsto
  have hr : ContinuousAt (fun b : ℝ => ∫ φ in b..π, g φ) θ := by
    have hh := continuousOn_primitive_interval' hi (a := π) right_mem_uIcc
    rw [uIcc_of_le Real.pi_pos.le] at hh
    convert (hh.continuousAt hn).neg using 1
    funext b
    simp only [Pi.neg_apply]
    exact intervalIntegral.integral_symm (f := g) π b
  have hl := (ht.comp ha).add (hr.tendsto.comp hb)
  have he := intervalIntegral.integral_add_adjacent_intervals
    (hi.mono_set (by
      rw [uIcc_of_le hθ.1.le, uIcc_of_le Real.pi_pos.le]
      exact Icc_subset_Icc le_rfl hθ.2.le))
    (hi.mono_set (by
      rw [uIcc_of_le hθ.2.le, uIcc_of_le Real.pi_pos.le]
      exact Icc_subset_Icc hθ.1.le le_rfl))
  rw [he] at hl
  exact hl

/-- The raw angular PV is the existing ordinary, absolutely integrable `HT` expression. -/
theorem tendsto_angularPVTrunc {f : ℝ → ℝ} {θ : ℝ}
    (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hi : IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π) :
    Tendsto (angularPVTrunc f θ) (𝓝[>] (0 : ℝ)) (𝓝 (HT f θ)) := by
  have ha : Tendsto (fun ε : ℝ => θ - ε) (𝓝[>] 0) (𝓝 θ) := by
    simpa only [sub_zero, id_eq] using tendsto_const_nhds.sub
      (tendsto_id.mono_left (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0))
  have hb : Tendsto (fun ε : ℝ => θ + ε) (𝓝[>] 0) (𝓝 θ) := by
    simpa only [add_zero, id_eq] using tendsto_const_nhds.add
      (tendsto_id.mono_left (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0))
  have hh := ((tendsto_cut_fiber_integrals hθ hi ha hb).const_mul (1 / π)).add
    ((tendsto_angularPVTrunc_one hθ).const_mul (f θ))
  simp only [mul_zero, add_zero] at hh
  change Tendsto _ _ (𝓝 (HT f θ)) at hh
  apply hh.congr'
  have hl : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < θ :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < θ from Iio_mem_nhds hθ.1).filter_mono nhdsWithin_le_nhds
  have hr : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < π - θ :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < π - θ from
      Iio_mem_nhds (by linarith [hθ.2] : 0 < π - θ)).filter_mono nhdsWithin_le_nhds
  filter_upwards [self_mem_nhdsWithin, hl, hr] with ε hε hεl hεr
  change 0 < ε at hε
  exact (rawCutTransform_decomposition hθ
    ⟨by linarith, by linarith⟩ ⟨by linarith, by linarith⟩
    (by linarith) (by linarith) hi).symm

noncomputable def cosinePVTrunc (f : ℝ → ℝ) (θ ε : ℝ) : ℝ :=
  rawCutTransform f θ (arccos (cos θ + ε)) (arccos (cos θ - ε))

theorem cos_interior {θ : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π) : cos θ ∈ Ioo (-1 : ℝ) 1 := by
  constructor
  · simpa only [cos_pi] using cos_lt_cos_of_nonneg_of_le_pi hθ.1.le le_rfl hθ.2
  · simpa only [cos_zero] using cos_lt_cos_of_nonneg_of_le_pi (le_refl (0 : ℝ)) hθ.2.le hθ.1

theorem cosine_cuts_bounds {θ ε : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hε : 0 < ε) (hl : ε < 1 - cos θ) (hr : ε < cos θ + 1) :
    arccos (cos θ + ε) ∈ Ioo (0 : ℝ) θ ∧
      arccos (cos θ - ε) ∈ Ioo θ π := by
  have hc := cos_interior hθ
  constructor
  · constructor
    · exact arccos_pos.mpr (by linarith)
    · have hh := arccos_lt_arccos hc.1.le (by linarith : cos θ < cos θ + ε)
        (by linarith : cos θ + ε ≤ 1)
      simpa only [arccos_cos hθ.1.le hθ.2.le] using hh
  · constructor
    · have hh := arccos_lt_arccos (by linarith : -1 ≤ cos θ - ε)
        (by linarith : cos θ - ε < cos θ) hc.2.le
      simpa only [arccos_cos hθ.1.le hθ.2.le] using hh
    · exact arccos_lt_pi.mpr (by linarith)

/-- The singular logarithm cancels explicitly at a spatial cutoff. -/
theorem pvPrimitive_spatial_cut {θ φ ε : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hφ : φ ∈ Icc (0 : ℝ) π) (hε : 0 < ε)
    (hgap : |cos θ - cos φ| = ε) :
    pvPrimitive θ φ = (log ε - log 2 - 2 * log |sin ((φ + θ) / 2)|) / sin θ := by
  have hne : φ ≠ θ := by
    intro hh
    rw [hh, sub_self, abs_zero] at hgap
    linarith
  obtain ⟨hd, hs⟩ := pv_sines_nonzero hθ hφ hne
  have he : ε = (2 * sin ((φ + θ) / 2)) * |sin ((φ - θ) / 2)| := by
    rw [← hgap, cos_gap_factor, abs_mul, abs_of_pos (mul_pos (by norm_num) hs)]
  have hlog := congrArg log he
  rw [log_mul (mul_pos (by norm_num : (0 : ℝ) < 2) hs).ne' (abs_ne_zero.mpr hd),
    log_mul (by norm_num : (2 : ℝ) ≠ 0) hs.ne'] at hlog
  unfold pvPrimitive
  rw [abs_of_pos hs]
  congr 1
  linarith

theorem cosinePVTrunc_one_eq {θ ε : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hε : 0 < ε) (hl : ε < 1 - cos θ) (hr : ε < cos θ + 1) :
    cosinePVTrunc (fun _ => 1) θ ε = 2 / (π * sin θ) *
      (log |sin ((arccos (cos θ - ε) + θ) / 2)| -
        log |sin ((arccos (cos θ + ε) + θ) / 2)|) := by
  obtain ⟨ha, hb⟩ := cosine_cuts_bounds hθ hε hl hr
  have hca : cos (arccos (cos θ + ε)) = cos θ + ε :=
    cos_arccos (by linarith [(cos_interior hθ).1]) (by linarith)
  have hcb : cos (arccos (cos θ - ε)) = cos θ - ε :=
    cos_arccos (by linarith) (by linarith [(cos_interior hθ).2])
  unfold cosinePVTrunc rawCutTransform
  rw [integral_cos_kernel hθ ⟨le_rfl, Real.pi_pos.le⟩ ⟨ha.1.le, ha.2.le.trans hθ.2.le⟩
      ha.1.le (Or.inl ha.2),
    integral_cos_kernel hθ ⟨hθ.1.le.trans hb.1.le, hb.2.le⟩ ⟨Real.pi_pos.le, le_rfl⟩
      hb.2.le (Or.inr hb.1), pvPrimitive_zero, pvPrimitive_pi,
    pvPrimitive_spatial_cut hθ ⟨ha.1.le, ha.2.le.trans hθ.2.le⟩ hε
      (by rw [hca]; simp only [sub_add_cancel_left, abs_neg, abs_of_pos hε]),
    pvPrimitive_spatial_cut hθ ⟨hθ.1.le.trans hb.1.le, hb.2.le⟩ hε
      (by rw [hcb]; simp only [sub_sub_cancel, abs_of_pos hε])]
  ring

/-- Symmetric cosine cutoffs have the same vanishing constant PV as angular cutoffs. -/
theorem tendsto_cosinePVTrunc_one {θ : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π) :
    Tendsto (cosinePVTrunc (fun _ => 1) θ) (𝓝[>] (0 : ℝ)) (𝓝 0) := by
  have hs := sin_pos_of_pos_of_lt_pi hθ.1 hθ.2
  have hp : ContinuousAt (fun ε : ℝ => log |sin ((arccos (cos θ - ε) + θ) / 2)|) 0 := by
    simp only [log_abs]
    fun_prop (disch := simpa only [sub_zero, arccos_cos hθ.1.le hθ.2.le,
      add_self_div_two] using hs.ne')
  have hm : ContinuousAt (fun ε : ℝ => log |sin ((arccos (cos θ + ε) + θ) / 2)|) 0 := by
    simp only [log_abs]
    fun_prop (disch := simpa only [add_zero, arccos_cos hθ.1.le hθ.2.le,
      add_self_div_two] using hs.ne')
  have hh : Tendsto (fun ε : ℝ => 2 / (π * sin θ) *
      (log |sin ((arccos (cos θ - ε) + θ) / 2)| -
        log |sin ((arccos (cos θ + ε) + θ) / 2)|)) (𝓝[>] 0) (𝓝 0) := by
    simpa only [Pi.sub_apply, add_zero, sub_zero, sub_self, mul_zero] using
      ((hp.sub hm).const_mul (2 / (π * sin θ))).tendsto.mono_left
        (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
  apply hh.congr'
  have hl : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < 1 - cos θ :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < 1 - cos θ from
      Iio_mem_nhds (by linarith [(cos_interior hθ).2] : 0 < 1 - cos θ)).filter_mono nhdsWithin_le_nhds
  have hr : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < cos θ + 1 :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < cos θ + 1 from
      Iio_mem_nhds (by linarith [(cos_interior hθ).1] : 0 < cos θ + 1)).filter_mono nhdsWithin_le_nhds
  filter_upwards [self_mem_nhdsWithin, hl, hr] with ε hε hεl hεr
  exact (cosinePVTrunc_one_eq hθ hε hεl hεr).symm

theorem tendsto_cosinePVTrunc {f : ℝ → ℝ} {θ : ℝ}
    (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hi : IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π) :
    Tendsto (cosinePVTrunc f θ) (𝓝[>] (0 : ℝ)) (𝓝 (HT f θ)) := by
  have ha : Tendsto (fun ε : ℝ => arccos (cos θ + ε)) (𝓝[>] 0) (𝓝 θ) := by
    have hc : ContinuousAt (fun ε : ℝ => arccos (cos θ + ε)) 0 := by fun_prop
    simpa only [add_zero, arccos_cos hθ.1.le hθ.2.le] using hc.tendsto.mono_left
        (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
  have hb : Tendsto (fun ε : ℝ => arccos (cos θ - ε)) (𝓝[>] 0) (𝓝 θ) := by
    have hc : ContinuousAt (fun ε : ℝ => arccos (cos θ - ε)) 0 := by fun_prop
    simpa only [sub_zero, arccos_cos hθ.1.le hθ.2.le] using hc.tendsto.mono_left
        (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
  have hh := ((tendsto_cut_fiber_integrals hθ hi ha hb).const_mul (1 / π)).add
    ((tendsto_cosinePVTrunc_one hθ).const_mul (f θ))
  simp only [mul_zero, add_zero] at hh
  change Tendsto _ _ (𝓝 (HT f θ)) at hh
  apply hh.congr'
  have hl : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < 1 - cos θ :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < 1 - cos θ from
      Iio_mem_nhds (by linarith [(cos_interior hθ).2] : 0 < 1 - cos θ)).filter_mono nhdsWithin_le_nhds
  have hr : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε < cos θ + 1 :=
    (show ∀ᶠ ε : ℝ in 𝓝 0, ε < cos θ + 1 from
      Iio_mem_nhds (by linarith [(cos_interior hθ).1] : 0 < cos θ + 1)).filter_mono nhdsWithin_le_nhds
  filter_upwards [self_mem_nhdsWithin, hl, hr] with ε hε hεl hεr
  obtain ⟨hca, hcb⟩ := cosine_cuts_bounds hθ hε hεl hεr
  exact (rawCutTransform_decomposition hθ ⟨hca.1.le, hca.2.le⟩ ⟨hcb.1.le, hcb.2.le⟩
    hca.2 hcb.1 hi).symm

/-- Converts an actual excision indicator into the two remaining interval integrals. -/
theorem integral_excision_eq_intervals {p : ℝ → Prop} [DecidablePred p] {g : ℝ → ℝ}
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) (hb : b ≤ π)
    (hl : IntervalIntegrable g volume 0 a) (hr : IntervalIntegrable g volume b π)
    (hp : ∀ φ ∈ Ioc (0 : ℝ) π, p φ ↔ φ < a ∨ b < φ) :
    (∫ φ, (if p φ then g φ else 0) ∂angleMeasure) =
      (∫ φ in (0 : ℝ)..a, g φ) + ∫ φ in b..π, g φ := by
  have hil : Integrable ((Ioo (0 : ℝ) a).indicator g) angleMeasure :=
    (hl.1.mono_set Ioo_subset_Ioc_self).integrable_indicator measurableSet_Ioo |>.mono_measure
      Measure.restrict_le_self
  have hir : Integrable ((Ioc b π).indicator g) angleMeasure :=
    hr.1.integrable_indicator measurableSet_Ioc |>.mono_measure Measure.restrict_le_self
  have he : (fun φ => if p φ then g φ else 0) =ᵐ[angleMeasure]
      (fun φ => (Ioo (0 : ℝ) a).indicator g φ + (Ioc b π).indicator g φ) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with φ hφ
    have hmL : φ ∈ Ioo (0 : ℝ) a ↔ φ < a := by simp only [mem_Ioo, hφ.1, true_and]
    have hmR : φ ∈ Ioc b π ↔ b < φ := by simp only [mem_Ioc, hφ.2, and_true]
    by_cases hL : φ < a
    · have hR : ¬b < φ := by linarith
      rw [if_pos ((hp φ hφ).mpr (Or.inl hL)), indicator_of_mem (hmL.mpr hL),
        indicator_of_notMem (mt hmR.mp hR), add_zero]
    · by_cases hR : b < φ
      · rw [if_pos ((hp φ hφ).mpr (Or.inr hR)), indicator_of_notMem (mt hmL.mp hL),
          indicator_of_mem (hmR.mpr hR), zero_add]
      · rw [if_neg (fun hh => (hp φ hφ).mp hh |>.elim hL hR),
          indicator_of_notMem (mt hmL.mp hL), indicator_of_notMem (mt hmR.mp hR), add_zero]
  rw [MeasureTheory.integral_congr_ae he, MeasureTheory.integral_add hil hir]
  have hleft : (∫ φ, (Ioo (0 : ℝ) a).indicator g φ ∂angleMeasure) = ∫ φ in (0 : ℝ)..a, g φ := by
    rw [angleMeasure, setIntegral_indicator measurableSet_Ioo,
      inter_eq_right.mpr (show Ioo (0 : ℝ) a ⊆ Ioc (0 : ℝ) π from
        fun φ hφ => ⟨hφ.1, hφ.2.le.trans (hab.trans hb)⟩),
      MeasureTheory.setIntegral_congr_set (Ioo_ae_eq_Ioc : Ioo (0 : ℝ) a =ᵐ[volume] Ioc 0 a),
      intervalIntegral.integral_of_le ha]
  have hright : (∫ φ, (Ioc b π).indicator g φ ∂angleMeasure) = ∫ φ in b..π, g φ := by
    rw [angleMeasure, setIntegral_indicator measurableSet_Ioc,
      inter_eq_right.mpr (show Ioc b π ⊆ Ioc (0 : ℝ) π from
        fun φ hφ => ⟨(ha.trans hab).trans_lt hφ.1, hφ.2⟩), intervalIntegral.integral_of_le hb]
  rw [hleft, hright]

theorem raw_kernel_cut_integrable {f : ℝ → ℝ} {θ a b : ℝ}
    (hθ : θ ∈ Ioo (0 : ℝ) π) (ha : a ∈ Icc (0 : ℝ) θ) (hb : b ∈ Icc θ π)
    (hal : a < θ) (hbr : θ < b)
    (hi : IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π) :
    IntervalIntegrable (fun φ => f φ / (cos θ - cos φ)) volume 0 a ∧
      IntervalIntegrable (fun φ => f φ / (cos θ - cos φ)) volume b π := by
  have hil := hi.mono_set (by
    rw [uIcc_of_le ha.1, uIcc_of_le Real.pi_pos.le]
    exact Icc_subset_Icc le_rfl (ha.2.trans hθ.2.le))
  have hir := hi.mono_set (by
    rw [uIcc_of_le hb.2, uIcc_of_le Real.pi_pos.le]
    exact Icc_subset_Icc (hθ.1.le.trans hb.1) le_rfl)
  have hkl := intervalIntegrable_cos_kernel hθ ⟨le_rfl, Real.pi_pos.le⟩
    ⟨ha.1, ha.2.trans hθ.2.le⟩ ha.1 (Or.inl hal)
  have hkr := intervalIntegrable_cos_kernel hθ ⟨hθ.1.le.trans hb.1, hb.2⟩
    ⟨Real.pi_pos.le, le_rfl⟩ hb.2 (Or.inr hbr)
  have he : (fun φ => f φ / (cos θ - cos φ)) =
      (fun φ => (f φ - f θ) / (cos θ - cos φ) + f θ * (1 / (cos θ - cos φ))) := by
    funext φ
    simp only [div_eq_mul_inv]
    ring
  rw [he]
  exact ⟨hil.add (hkl.const_mul _), hir.add (hkr.const_mul _)⟩

theorem cosine_excision_iff {θ ε φ : ℝ} (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hε : 0 < ε) (hl : ε < 1 - cos θ) (hr : ε < cos θ + 1)
    (hφ : φ ∈ Icc (0 : ℝ) π) :
    ε < |cos θ - cos φ| ↔ φ < arccos (cos θ + ε) ∨ arccos (cos θ - ε) < φ := by
  obtain ⟨ha, hb⟩ := cosine_cuts_bounds hθ hε hl hr
  have haC : cos (arccos (cos θ + ε)) = cos θ + ε :=
    cos_arccos (by linarith [(cos_interior hθ).1]) (by linarith)
  have hbC : cos (arccos (cos θ - ε)) = cos θ - ε :=
    cos_arccos (by linarith) (by linarith [(cos_interior hθ).2])
  have hla := Real.strictAntiOn_cos.lt_iff_gt
    ⟨ha.1.le, ha.2.le.trans hθ.2.le⟩ hφ
  have hrb := Real.strictAntiOn_cos.lt_iff_gt
    hφ ⟨hθ.1.le.trans hb.1.le, hb.2.le⟩
  rw [haC] at hla
  rw [hbC] at hrb
  rw [lt_abs]
  constructor
  · rintro (h | h)
    · exact Or.inr (hrb.mp (by linarith))
    · exact Or.inl (hla.mp (by linarith))
  · rintro (h | h)
    · exact Or.inr (by linarith [hla.mpr h])
    · exact Or.inl (by linarith [hrb.mpr h])

theorem cosinePVTrunc_eq_indicator {f : ℝ → ℝ} {θ ε : ℝ}
    (hθ : θ ∈ Ioo (0 : ℝ) π) (hε : 0 < ε)
    (hl : ε < 1 - cos θ) (hr : ε < cos θ + 1)
    (hi : IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π) :
    cosinePVTrunc f θ ε = 1 / π *
      ∫ φ, (if ε < |cos θ - cos φ| then f φ / (cos θ - cos φ) else 0) ∂angleMeasure := by
  obtain ⟨ha, hb⟩ := cosine_cuts_bounds hθ hε hl hr
  obtain ⟨hfl, hfr⟩ := raw_kernel_cut_integrable hθ ⟨ha.1.le, ha.2.le⟩ ⟨hb.1.le, hb.2.le⟩
    ha.2 hb.1 hi
  rw [cosinePVTrunc, rawCutTransform,
    integral_excision_eq_intervals ha.1.le (ha.2.le.trans hb.1.le) hb.2.le hfl hfr
      (fun φ hφ => cosine_excision_iff hθ hε hl hr ⟨hφ.1.le, hφ.2⟩)]

/-- The spatial equilibrium measure is the push-forward of `dφ/π`. -/
theorem integral_equilibriumMeasure {c r : ℝ} {H : ℝ → ℝ} (hm : Measurable H) :
    (∫ e, H e ∂spatialAdjointMeasure c r (fun _ => 1)) =
      1 / π * ∫ φ, H (position c r φ) ∂angleMeasure := by
  rw [spatialAdjointMeasure, MeasureTheory.integral_map_of_stronglyMeasurable
    (by unfold position; fun_prop) hm.stronglyMeasurable, angularAdjointMeasure,
    integral_withDensity_eq_integral_toReal_smul (by fun_prop)
      (Eventually.of_forall (fun _ => ENNReal.ofReal_lt_top))]
  simp only [ENNReal.toReal_ofReal (one_div_nonneg.mpr Real.pi_pos.le), smul_eq_mul]
  exact MeasureTheory.integral_const_mul _ _

/-- The raw spatial PV uses symmetric excision in the actual spatial variable `e`. -/
noncomputable def spatialPVTrunc (c r : ℝ) (f : ℝ → ℝ) (d ε : ℝ) : ℝ :=
  ∫ e, {e : ℝ | ε < |e - d|}.indicator
    (fun e => f (physicalAngle c r e) / (e - d)) e
      ∂spatialAdjointMeasure c r (fun _ => 1)

theorem spatialPVTrunc_eq_cosine {f : ℝ → ℝ} {c r θ ε : ℝ}
    (hr : 0 < r) (hm : Measurable f) (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hε : 0 < ε) (hl : ε / r < 1 - cos θ) (hb : ε / r < cos θ + 1)
    (hi : IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π) :
    spatialPVTrunc c r f (position c r θ) ε = cosinePVTrunc f θ (ε / r) / r := by
  let H := fun e => {e : ℝ | ε < |e - position c r θ|}.indicator
    (fun e => f (physicalAngle c r e) / (e - position c r θ)) e
  have hset : MeasurableSet {e : ℝ | ε < |e - position c r θ|} :=
    (isOpen_lt continuous_const (continuous_id.sub continuous_const).abs).measurableSet
  have hH : Measurable H :=
    ((hm.comp (by unfold physicalAngle; fun_prop)).div
      (measurable_id.sub measurable_const)).indicator hset
  have he : (fun φ => H (position c r φ)) =ᵐ[angleMeasure]
      (fun φ => 1 / r * (if ε / r < |cos θ - cos φ| then f φ / (cos θ - cos φ) else 0)) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with φ hφ
    have hpos : position c r φ - position c r θ = r * (cos θ - cos φ) := by
      dsimp [position]
      ring
    have hex : ε < |position c r φ - position c r θ| ↔ ε / r < |cos θ - cos φ| := by
      rw [hpos, abs_mul, abs_of_pos hr]
      rw [div_lt_iff₀ hr, mul_comm r |cos θ - cos φ|]
    by_cases hcut : ε / r < |cos θ - cos φ|
    · dsimp [H]
      have hmem : position c r φ ∈ {e : ℝ | ε < |e - position c r θ|} := hex.mpr hcut
      rw [indicator_of_mem hmem, physicalAngle_position hr ⟨hφ.1.le, hφ.2⟩,
        hpos, if_pos hcut]
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring
    · dsimp [H]
      have hnot : position c r φ ∉ {e : ℝ | ε < |e - position c r θ|} := mt hex.mp hcut
      rw [indicator_of_notMem hnot, if_neg hcut, mul_zero]
  change (∫ e, H e ∂spatialAdjointMeasure c r (fun _ => 1)) = _
  rw [integral_equilibriumMeasure hH, MeasureTheory.integral_congr_ae he,
    MeasureTheory.integral_const_mul, cosinePVTrunc_eq_indicator hθ (div_pos hε hr) hl hb hi]
  ring

/-- Actual spatial PV and raw angular PV have the same value, with the radius normalization. -/
theorem tendsto_spatialPVTrunc {f : ℝ → ℝ} {c r θ : ℝ}
    (hr : 0 < r) (hm : Measurable f) (hθ : θ ∈ Ioo (0 : ℝ) π)
    (hi : IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π) :
    Tendsto (spatialPVTrunc c r f (position c r θ)) (𝓝[>] (0 : ℝ)) (𝓝 (HT f θ / r)) := by
  have hscale : Tendsto (fun ε : ℝ => ε / r) (𝓝[>] 0) (𝓝[>] 0) := by
    apply tendsto_nhdsWithin_iff.mpr
    refine ⟨?_, ?_⟩
    · simpa only [zero_div, id_eq] using
        (tendsto_id.div_const r).mono_left (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
    · filter_upwards [self_mem_nhdsWithin] with ε hε
      exact div_pos hε hr
  have hh := ((tendsto_cosinePVTrunc hθ hi).comp hscale).div_const r
  apply hh.congr'
  have hl : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε / r < 1 - cos θ :=
    hscale.eventually ((show ∀ᶠ t : ℝ in 𝓝 0, t < 1 - cos θ from
      Iio_mem_nhds (by linarith [(cos_interior hθ).2] : 0 < 1 - cos θ)).filter_mono nhdsWithin_le_nhds)
  have hb : ∀ᶠ ε : ℝ in 𝓝[>] 0, ε / r < cos θ + 1 :=
    hscale.eventually ((show ∀ᶠ t : ℝ in 𝓝 0, t < cos θ + 1 from
      Iio_mem_nhds (by linarith [(cos_interior hθ).1] : 0 < cos θ + 1)).filter_mono nhdsWithin_le_nhds)
  filter_upwards [self_mem_nhdsWithin, hl, hb] with ε hε hεl hεb
  exact (spatialPVTrunc_eq_cosine hr hm hθ hε hεl hεb hi).symm

end EP1038.Stage11
