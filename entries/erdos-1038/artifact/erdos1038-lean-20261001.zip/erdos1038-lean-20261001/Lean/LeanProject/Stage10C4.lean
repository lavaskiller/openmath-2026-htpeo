import LeanProject.Stage10C3

/-!
# EP-1038, Stage 10 Part (c), N2: the inverse coefficients by recursion

For a coefficient sequence `φ : ℕ → ℝ` define power series `P 0 = 0`,
`P (N+1) = P N + c_{N+1} X^{N+1}` with `c_{N+1} = Σ_{j ≤ N} φ_j [X^N] (P N)^j`, and
`Φ = Σ c_n Xⁿ` (`PhiS`). Then:
* `coeff_P_le`, `coeff_P_gt`: `P N` is the truncation of `Φ` to degree `N`;
* `coeff_Phi_zero`: `c_0 = 0`; `coeff_Phi_succ` (**formal identity**): `c_{N+1} = Σ_{j≤N} φ_j [X^N]Φ^j`;
* `NN_Phi`: `c_n ≥ 0` when `φ ≥ 0`;
* `coeff_pow_lt`: `[Xⁿ]Φ^j = 0` for `n < j`.
-/

open Real Set Filter Topology PowerSeries Finset

namespace EP1038.Stage10

/-- `c_{N+1}` computed from `P N`. -/
noncomputable def newc (φ : ℕ → ℝ) (Q : PowerSeries ℝ) (N : ℕ) : ℝ :=
  ∑ j ∈ range (N + 1), φ j * coeff N (Q ^ j)

/-- The partial inverse series `P N`. -/
noncomputable def Pinv (φ : ℕ → ℝ) : ℕ → PowerSeries ℝ
  | 0 => 0
  | N + 1 => Pinv φ N + monomial (N + 1) (newc φ (Pinv φ N) N)

/-- The inverse series `Φ = Σ c_n Xⁿ`, `c_n = [Xⁿ] P n`. -/
noncomputable def PhiS (φ : ℕ → ℝ) : PowerSeries ℝ := PowerSeries.mk fun n => coeff n (Pinv φ n)

theorem coeff_P_gt (φ : ℕ → ℝ) : ∀ N m, N < m → coeff m (Pinv φ N) = 0
  | 0, m, _ => by simp [Pinv]
  | N + 1, m, h => by
    simp only [Pinv, map_add, coeff_monomial]
    rw [coeff_P_gt φ N m (by omega), if_neg (by omega), add_zero]

theorem coeff_P_le (φ : ℕ → ℝ) : ∀ N m, m ≤ N → coeff m (Pinv φ N) = coeff m (PhiS φ)
  | 0, m, h => by
    have : m = 0 := by omega
    subst this
    simp [PhiS]
  | N + 1, m, h => by
    rcases Nat.lt_or_ge m (N + 1) with h' | h'
    · simp only [Pinv, map_add, coeff_monomial]
      rw [if_neg (by omega), add_zero]
      exact coeff_P_le φ N m (by omega)
    · have : m = N + 1 := by omega
      subst this
      simp [PhiS]

/-- If two series agree up to degree `N`, so do their powers. -/
theorem coeff_pow_agree {A B : PowerSeries ℝ} {N : ℕ} (h : ∀ i ≤ N, coeff i A = coeff i B) :
    ∀ j m, m ≤ N → coeff m (A ^ j) = coeff m (B ^ j)
  | 0, m, _ => by simp
  | j + 1, m, hm => by
    rw [pow_succ, pow_succ, coeff_mul, coeff_mul]
    refine Finset.sum_congr rfl fun kl hkl => ?_
    rw [Finset.mem_antidiagonal] at hkl
    rw [coeff_pow_agree h j kl.1 (by omega), h kl.2 (by omega)]

theorem coeff_Phi_zero (φ : ℕ → ℝ) : coeff 0 (PhiS φ) = 0 := by
  simp [PhiS, Pinv]

/-- **Formal identity**: `c_{N+1} = Σ_{j ≤ N} φ_j [X^N] Φ^j`. -/
theorem coeff_Phi_succ (φ : ℕ → ℝ) (N : ℕ) :
    coeff (N + 1) (PhiS φ) = ∑ j ∈ range (N + 1), φ j * coeff N (PhiS φ ^ j) := by
  have h1 : coeff (N + 1) (PhiS φ) = newc φ (Pinv φ N) N := by
    rw [← coeff_P_le φ (N + 1) (N + 1) le_rfl]
    simp only [Pinv, map_add, coeff_monomial, if_true]
    rw [coeff_P_gt φ N (N + 1) (by omega), zero_add]
  rw [h1, newc]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [coeff_pow_agree (fun i hi => coeff_P_le φ N i hi) j N le_rfl]

theorem NN_Pinv {φ : ℕ → ℝ} (hφ : ∀ j, 0 ≤ φ j) : ∀ N, NN (Pinv φ N)
  | 0 => fun n => by simp [Pinv]
  | N + 1 => fun n => by
    simp only [Pinv, map_add, coeff_monomial]
    refine add_nonneg (NN_Pinv hφ N n) ?_
    split_ifs
    · exact Finset.sum_nonneg fun j _ => mul_nonneg (hφ j) (NN_pow (NN_Pinv hφ N) j N)
    · exact le_rfl

theorem NN_Phi {φ : ℕ → ℝ} (hφ : ∀ j, 0 ≤ φ j) : NN (PhiS φ) := fun n => by
  rw [← coeff_P_le φ n n le_rfl]
  exact NN_Pinv hφ n n

/-- `[Xⁿ] A^j = 0` for `n < j` when `A` has zero constant term. -/
theorem coeff_pow_lt {A : PowerSeries ℝ} (h0 : coeff 0 A = 0) : ∀ j n, n < j → coeff n (A ^ j) = 0
  | 0, n, h => absurd h (Nat.not_lt_zero n)
  | j + 1, n, h => by
    rw [pow_succ, coeff_mul]
    refine Finset.sum_eq_zero fun kl hkl => ?_
    rw [Finset.mem_antidiagonal] at hkl
    rcases Nat.eq_zero_or_pos kl.2 with h2 | h2
    · rw [h2, h0, mul_zero]
    · rw [coeff_pow_lt h0 j kl.1 (by omega), zero_mul]

/-- The formal identity with a `tsum` over `j`. -/
theorem coeff_Phi_succ_tsum (φ : ℕ → ℝ) (N : ℕ) :
    coeff (N + 1) (PhiS φ) = ∑' j, φ j * coeff N (PhiS φ ^ j) := by
  rw [coeff_Phi_succ, tsum_eq_sum (s := range (N + 1))]
  intro j hj
  rw [Finset.mem_range, not_lt] at hj
  rw [coeff_pow_lt (coeff_Phi_zero φ) j N (by omega), mul_zero]

end EP1038.Stage10
