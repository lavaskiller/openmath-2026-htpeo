import LeanProject.CertificateArithmetic

/-! Simplified certificate formulas, identified with actual reference data. -/
open Real Set
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

noncomputable def formDp (A q v : ℝ) : ℝ :=
  A * (1 - q ^ 2) / ((1 - q ^ 2 / v) * (1 - v)) - 1
noncomputable def formDm (A q v : ℝ) : ℝ :=
  A * (1 - q ^ 2) / ((1 - q ^ 2 / v) * (v - 1)) + 1
noncomputable def formWp (A q v : ℝ) : ℝ := 1 / formDp A q v
noncomputable def formWm (A q v : ℝ) : ℝ := 1 / formDm A q v
noncomputable def formApi (k q : ℝ) : ℝ := 1 + 2 * k * q / (1 + q)
noncomputable def formWidth (d q vp vm : ℝ) : ℝ :=
  d * (vm - vp) * (1 - q ^ 2 / (vp * vm))
noncomputable def formXi (k A q d vp vm : ℝ) : ℝ :=
  2 * d * q / (k + 1) *
    ((1 + q / vp) * formWp A q vp + (1 + q / vm) * formWm A q vm)
noncomputable def formC0 (k A q vp vm : ℝ) : ℝ :=
  Real.log ((k + 1) / (2 * formApi k q * (formWp A q vp + formWm A q vm)))
noncomputable def formCeff (k A q d vp vm L : ℝ) : ℝ :=
  Real.log (d * q) + k * Real.log d + (L - formWidth d q vp vm) / formXi k A q d vp vm
def FormulaPositive (k A q d vp vm L : ℝ) : Prop :=
  ∀ Q V, Q ∈ Ioc 0 (π / formApi k q) → V ∈ Ioc 0 (π * ((1 + q / vp) / 2)) →
    0 < rhs (formC0 k A q vp vm) (formCeff k A q d vp vm L) (formApi k q) Q V
def FormulaPositiveZero (k A q vp vm : ℝ) : Prop :=
  ∀ Q V, Q ∈ Ioc 0 (π / formApi k q) → V ∈ Ioc 0 (π * ((1 + q / vp) / 2)) →
    0 < rhs (formC0 k A q vp vm) 0 (formApi k q) Q V

theorem formDp_eq {k a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v ≠ 1) :
    formDp (k / (k + 1)) (qa a) v = v * certEprime k a v := by
  obtain ⟨hv, hq2, _, _⟩ := exterior_parameter_bounds ha ha2 hvq
  have hn : 1 - (qa a) ^ 2 / v ≠ 0 := by
    have h : (qa a) ^ 2 / v < 1 := (div_lt_one hv).mpr hq2
    linarith
  unfold formDp certEprime
  field_simp [hv.ne', (sub_pos.mpr hq2).ne', sub_ne_zero.mpr (Ne.symm hv1), hn]
  <;> ring

theorem formDm_eq {k a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v ≠ 1) :
    formDm (k / (k + 1)) (qa a) v = -(v * certEprime k a v) := by
  obtain ⟨hv, hq2, _, _⟩ := exterior_parameter_bounds ha ha2 hvq
  have hn : 1 - (qa a) ^ 2 / v ≠ 0 := by
    have h : (qa a) ^ 2 / v < 1 := (div_lt_one hv).mpr hq2
    linarith
  unfold formDm certEprime
  field_simp [hv.ne', (sub_pos.mpr hq2).ne', sub_ne_zero.mpr hv1, hn]
  <;> ring

theorem certificate_plus_from_separator {k a lo hi : ℝ} (hk : 0 < k)
    (ha : 0 < a) (ha2 : a < 2) (hH : 2 * (k / (k + 1)) ^ 2 ≤ a)
    (hql : qa a < lo) (hlh : lo < hi) (hh1 : hi < 1)
    (hEl : certE k a lo < 0) (hEh : 0 < certE k a hi) :
    ∃ v ∈ Ioo lo hi, certE k a v = 0 := by
  have hc : ContinuousOn (certE k a) (Icc lo hi) := by
    intro v hv
    exact (hasDerivAt_certE ha ha2 (hql.trans_le hv.1)
      (hv.2.trans_lt hh1).ne).continuousAt.continuousWithinAt
  obtain ⟨v, hv, he⟩ := intermediate_value_Icc hlh.le hc ⟨hEl.le, hEh.le⟩
  have hlv : lo < v := by
    rcases hv.1.lt_or_eq with h | h
    · exact h
    · rw [← h] at he; linarith
  have hvh : v < hi := by
    rcases hv.2.lt_or_eq with h | h
    · exact h
    · rw [h] at he; linarith
  exact ⟨v, ⟨hlv, hvh⟩, he⟩

theorem coefficient_b_cancel {d q v w k : ℝ} (hv : v ≠ 0) (hk : k + 1 ≠ 0)
    (hr : 1 - (q / v) ^ 2 ≠ 0) :
    (d * (1 - q ^ 2 / v ^ 2) * v * w / (k + 1)) *
      (4 * (q / v) / (1 - (q / v) ^ 2)) = 4 * d * q * w / (k + 1) := by
  have hn : v ^ 2 - q ^ 2 ≠ 0 := by
    intro he
    apply hr
    apply (sub_eq_zero.mpr)
    rw [div_pow]
    exact ((div_eq_one_iff_eq (pow_ne_zero 2 hv)).mpr (sub_eq_zero.mp he).symm).symm
  field_simp [hv, hk, hr, hn, neg_add_eq_sub]
  <;> ring

theorem coefficient_xi_cancel {d q v w k : ℝ} (hv : v ≠ 0) (hk : k + 1 ≠ 0)
    (hr : 1 - q / v ≠ 0) :
    (d * (1 - q ^ 2 / v ^ 2) * v * w / (k + 1)) *
      (2 * (q / v) / (1 - q / v)) = 2 * d * q * (1 + q / v) * w / (k + 1) := by
  have hn : v - q ≠ 0 := by
    intro he
    apply hr
    rw [← sub_eq_zero.mp he, div_self hv, sub_self]
  field_simp [hv, hk, hr, hn, neg_add_eq_sub]
  <;> ring

theorem certificate_formula_dictionary {k a v0 vp vm : ℝ}
    (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2) (hH : 2 * (k / (k + 1)) ^ 2 ≤ a)
    (hvq : qa a < v0) (hv1 : v0 < 1) (hE0 : certE k a v0 < 0)
    (hp0 : v0 < vp) (hp1 : vp < 1) (hEp : certE k a vp = 0)
    (hm1 : 1 < vm) (hEm : certE k a vm = 0) :
    let R := referenceOfCertificate hk ha ha2 hH hvq hv1 hE0
    let A := k / (k + 1)
    let q := qa a
    let d := D0a a
    R.rhoPlus = q / vp ∧ R.rhoMinus = q / vm ∧
      api R.angles = formApi k q ∧ referenceWidth R = formWidth d q vp vm ∧
      totalXi R = formXi k A q d vp vm ∧ scalarC0 R = formC0 k A q vp vm ∧
      (∀ L, calibratedCeff R L = formCeff k A q d vp vm L) := by
  let R := referenceOfCertificate hk ha ha2 hH hvq hv1 hE0
  let A := k / (k + 1)
  let q := qa a
  let d := D0a a
  have hq := qa_pos ha ha2
  have hd := D0a_pos ha
  have hvp : 0 < vp := hq.trans (hvq.trans hp0)
  have hvm : 0 < vm := zero_lt_one.trans hm1
  have hk1 : k + 1 ≠ 0 := by linarith
  have hrp : R.rhoPlus = q / vp := certificate_rho_plus hk ha ha2 hH hvq hv1 hE0 hp0 hp1 hEp
  have hrm : R.rhoMinus = q / vm := certificate_rho_minus hk ha ha2 hH hvq hv1 hE0 hm1 hEm
  have hepp := certificate_Eprime_plus_pos hk ha ha2 hH hvq hv1 hE0 hp0 hp1 hEp
  have hepm := certificate_Eprime_minus_neg hk ha ha2 hH hvq hv1 hE0 hm1 hEm
  have hdp : formDp A q vp = vp * certEprime k a vp := formDp_eq ha ha2 (hvq.trans hp0) hp1.ne
  have hdm : formDm A q vm = -(vm * certEprime k a vm) :=
    formDm_eq ha ha2 ((qa_lt_one ha).trans hm1) hm1.ne'
  have hwp : 0 < formWp A q vp := by
    unfold formWp
    rw [hdp]
    positivity
  have hwm : 0 < formWm A q vm := by
    unfold formWm
    rw [hdm]
    exact one_div_pos.mpr (neg_pos.mpr (mul_neg_of_pos_of_neg hvm hepm))
  have hsp : R.sigmaPlus = d * (1 - q ^ 2 / vp ^ 2) * vp * formWp A q vp / (k + 1) := by
    have hh := certificate_sigma_plus hk ha ha2 hH hvq hv1 hE0 hp0 hp1 hEp
    change R.sigmaPlus = _ at hh
    rw [hh]
    unfold formWp
    rw [hdp]
    field_simp [hk1, hvp.ne', hepp.ne']
    <;> ring
  have hsm : R.sigmaMinus = d * (1 - q ^ 2 / vm ^ 2) * vm * formWm A q vm / (k + 1) := by
    have hh := certificate_sigma_minus hk ha ha2 hH hvq hv1 hE0 hm1 hEm
    change R.sigmaMinus = _ at hh
    rw [hh]
    unfold formWm
    rw [hdm]
    field_simp [hk1, hvm.ne', hepm.ne]
    <;> ring
  have hpr : 1 - (q / vp) ^ 2 ≠ 0 := by
    have hs := R.rhoPlus_spec
    rw [hrp] at hs
    nlinarith [hs.1, hs.2.1]
  have hmr : 1 - (q / vm) ^ 2 ≠ 0 := by
    have hs := R.rhoMinus_spec
    rw [hrm] at hs
    nlinarith [hs.1, hs.2.1]
  have hp1r : 1 - q / vp ≠ 0 := by
    have hs := R.rhoPlus_spec.2.1
    rw [hrp] at hs
    linarith
  have hm1r : 1 - q / vm ≠ 0 := by
    have hs := R.rhoMinus_spec.2.1
    rw [hrm] at hs
    linarith
  have hb : bpi R = 4 * d * q / (k + 1) * (formWp A q vp + formWm A q vm) := by
    rw [bpi, refB_eq, bpi_eq R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
      R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1, hrp, hrm, hsp, hsm,
      coefficient_b_cancel hvp.ne' hk1 hpr, coefficient_b_cancel hvm.ne' hk1 hmr]
    ring
  have hxi : totalXi R = formXi k A q d vp vm := by
    rw [totalXi_formula, hrp, hrm, hsp, hsm,
      coefficient_xi_cancel hvp.ne' hk1 hp1r, coefficient_xi_cancel hvm.ne' hk1 hm1r]
    unfold formXi
    ring
  have hapi : api R.angles = formApi k q := by
    rw [api, api_eq R.angles.rho_pos.le]
    rfl
  have hw : referenceWidth R = formWidth d q vp vm := by
    rw [certificate_width hk ha ha2 hH hvq hv1 hE0 hp0 hp1 hEp hm1 hEm]
    unfold certPoint formWidth
    dsimp [d, q]
    field_simp [hvp.ne', hvm.ne']
    <;> ring
  have hrefD : refD0 R = d := by
    change ((2 - a) / 2) / (2 * qa a) = D0a a
    apply (div_eq_iff (mul_pos (by norm_num) hq).ne').mpr
    linear_combination -2 * D0a_mul_qa ha
  have hHq : R.r / 2 = d * q := by
    change ((2 - a) / 2) / 2 = D0a a * qa a
    linear_combination -D0a_mul_qa ha
  have hc : refConstant R = Real.log (d * q) + k * Real.log d := by
    unfold refConstant
    rw [hHq, hrefD]
    rfl
  have hc0 : scalarC0 R = formC0 k A q vp vm := by
    unfold scalarC0 formC0
    rw [hHq, hapi, hb]
    congr 1
    have hs : formWp A q vp + formWm A q vm ≠ 0 := by linarith
    have hap : formApi k q ≠ 0 := by rw [← hapi]; exact (api_pos _).ne'
    have hdn : d ≠ 0 := hd.ne'
    have hqn : q ≠ 0 := hq.ne'
    field_simp [hdn, hqn, hk1, hs, hap]
    <;> ring
  have hce : ∀ L, calibratedCeff R L = formCeff k A q d vp vm L := by
    intro L
    unfold calibratedCeff formCeff
    rw [hc, hw, hxi]
  exact ⟨hrp, hrm, hapi, hw, hxi, hc0, hce⟩

theorem scalarPositive_mono (R : SeparatedReference) {C1 C2 : ℝ}
    (hC : C1 ≤ C2) (hpos : ScalarPositive R C2) : ScalarPositive R C1 := by
  intro Q V hQ hV
  have hp := hpos Q V hQ hV
  have hd := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hC Real.pi_pos.le)
    (mul_pos (api_pos R.angles) hQ.1).le
  unfold rhs at *
  linarith

theorem scalarPositive_of_formula {k a v0 vp vm L : ℝ}
    (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2) (hH : 2 * (k / (k + 1)) ^ 2 ≤ a)
    (hvq : qa a < v0) (hv1 : v0 < 1) (hE0 : certE k a v0 < 0)
    (hp0 : v0 < vp) (hp1 : vp < 1) (hEp : certE k a vp = 0)
    (hm1 : 1 < vm) (hEm : certE k a vm = 0)
    (hf : FormulaPositive k (k / (k + 1)) (qa a) (D0a a) vp vm L) :
    let R := referenceOfCertificate hk ha ha2 hH hvq hv1 hE0
    ScalarPositive R (calibratedCeff R L) := by
  let R := referenceOfCertificate hk ha ha2 hH hvq hv1 hE0
  obtain ⟨hrp, hrm, hap, hw, hx, hc, he⟩ :=
    certificate_formula_dictionary hk ha ha2 hH hvq hv1 hE0 hp0 hp1 hEp hm1 hEm
  have hq := qa_pos ha ha2
  have hvp : 0 < vp := hq.trans (hvq.trans hp0)
  have hvm : 0 < vm := zero_lt_one.trans hm1
  have hm : R.rhoMinus ≤ qa a / vp := by
    rw [hrm]
    exact div_le_div_of_nonneg_left hq.le hvp (hp1.trans hm1).le
  have hr := Rmax_le_rho_bound R (by rw [hrp]) hm
  dsimp only
  intro Q V hQ hV
  have hQ' : Q ∈ Ioc 0 (π / formApi k (qa a)) := by rwa [← hap]
  have hV' : V ∈ Ioc 0 (π * ((1 + qa a / vp) / 2)) := ⟨hV.1, hV.2.trans hr⟩
  have hh := hf Q V hQ' hV'
  rwa [← hc, ← he L, ← hap] at hh

theorem ratio_certified_of_box {k a pl ph ml mh L : ℝ}
    (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2) (hH : 2 * (k / (k + 1)) ^ 2 ≤ a)
    (hql : qa a < pl) (hph : ph < 1) (hplph : pl < ph) (hml : 1 < ml) (hmlmh : ml < mh)
    (hpl : certE k a pl < 0) (hphE : 0 < certE k a ph)
    (hmlE : 0 < certE k a ml) (hmhE : certE k a mh < 0)
    (hL : Stage9.Dval ≤ L)
    (hf : ∀ vp ∈ Ioo pl ph, ∀ vm ∈ Ioo ml mh,
      FormulaPositive k (k / (k + 1)) (qa a) (D0a a) vp vm L) : RatioCertified k := by
  have hpl1 : pl < 1 := hplph.trans hph
  let R := referenceOfCertificate hk ha ha2 hH hql hpl1 hpl
  obtain ⟨vp, hp, he⟩ := certificate_plus_from_separator hk ha ha2 hH hql hplph hph hpl hphE
  obtain ⟨vm, hm, hem, _⟩ := certificate_minus_bracket hk ha ha2 hH hql hpl1 hpl
    hml hmlmh hmlE hmhE
  have hs := scalarPositive_of_formula hk ha ha2 hH hql hpl1 hpl hp.1 (hp.2.trans hph) he
    (hml.trans hm.1) hem (hf vp hp vm hm)
  have hc : calibratedCeff R Stage9.Dval ≤ calibratedCeff R L := by
    unfold calibratedCeff
    exact add_le_add (le_refl _) (div_le_div_of_nonneg_right (sub_le_sub_right hL _) (totalXi_pos R).le)
  exact ⟨R, rfl, referenceOfCertificate_platform hk ha ha2 hH hql hpl1 hpl,
    scalarPositive_mono R hc hs⟩

end EP1038.ReferenceCert
