import LeanProject.Stage10C8

/-!
# EP-1038, Stage 10 Part (c), N6(ii): an implicit-root derivative lemma

`implicit_root_deriv`: let `X(s)` be roots of `Ω(·, s)` (`Ω(X s, s) = 0` for small `s ≥ 0`), with
`X(0) = x₀`, `X(s) → x₀`, and suppose
* `Ω(·, s)` is uniformly approximately linear with slope `L ≠ 0` near `x₀` for small `s`
  (`|Ω(x,s) - Ω(y,s) - L(x-y)| ≤ η|x-y|`), and
* `s ↦ Ω(x₀, s)` has right derivative `D` at `0`.
Then `X` has right derivative `-D/L` at `0`. (Proof: `|L e + D s| ≤ η(|e| + s)` with `e = X(s) - x₀`.)
-/

open Real Set Filter Topology Asymptotics

namespace EP1038.Stage10

theorem implicit_root_deriv {Ω : ℝ → ℝ → ℝ} {X : ℝ → ℝ} {x0 L D : ℝ} (hL : L ≠ 0)
    (hX0 : X 0 = x0) (hΩ0 : Ω x0 0 = 0)
    (hroot : ∀ᶠ s in 𝓝[Ici 0] (0 : ℝ), Ω (X s) s = 0)
    (hcont : Tendsto X (𝓝[Ici 0] 0) (𝓝 x0))
    (hlin : ∀ η > 0, ∃ ε > 0, ∀ᶠ s in 𝓝[Ici 0] (0 : ℝ), ∀ x ∈ Icc (x0 - ε) (x0 + ε),
      |Ω x s - Ω x0 s - L * (x - x0)| ≤ η * |x - x0|)
    (hD : HasDerivWithinAt (fun s => Ω x0 s) D (Ici 0) 0) :
    HasDerivWithinAt X (-D / L) (Ici 0) 0 := by
  rw [hasDerivWithinAt_iff_isLittleO]
  rw [hasDerivWithinAt_iff_isLittleO] at hD
  have hLpos : 0 < |L| := abs_pos.mpr hL
  set K := 2 * |D / L| + 1 with hK
  have hKpos : 0 < K := by positivity
  refine IsLittleO.of_bound fun c hc => ?_
  set η := min (|L| / 2) (c * |L| / (2 * (K + 1))) with hη
  have hηpos : 0 < η := lt_min (by positivity) (by positivity)
  obtain ⟨ε, hε, hlinε⟩ := hlin η hηpos
  have hXε : ∀ᶠ s in 𝓝[Ici 0] (0 : ℝ), X s ∈ Icc (x0 - ε) (x0 + ε) :=
    hcont (Icc_mem_nhds (by linarith) (by linarith))
  have hDη := hD.bound hηpos
  filter_upwards [hroot, hXε, hlinε, hDη, self_mem_nhdsWithin] with s hs1 hs2 hs3 hs4 hs5
  have hs0 : 0 ≤ s := hs5
  simp only [sub_zero, smul_eq_mul, hΩ0, Real.norm_eq_abs, abs_of_nonneg hs0] at hs4 ⊢
  rw [hX0]
  set e := X s - x0 with he
  have h1 := hs3 (X s) hs2
  rw [hs1, ← he] at h1
  -- `|L e + D s| ≤ η(|e| + s)`
  have key : |L * e + D * s| ≤ η * |e| + η * s := by
    have : L * e + D * s = -(0 - Ω x0 s - L * e) - (Ω x0 s - s * D) := by ring
    rw [this]
    calc |-(0 - Ω x0 s - L * e) - (Ω x0 s - s * D)|
        ≤ |-(0 - Ω x0 s - L * e)| + |Ω x0 s - s * D| := abs_sub _ _
      _ = |0 - Ω x0 s - L * e| + |Ω x0 s - s * D| := by rw [abs_neg]
      _ ≤ η * |e| + η * s := add_le_add h1 hs4
  have hη1 : η ≤ |L| / 2 := min_le_left _ _
  have hη2 : η ≤ c * |L| / (2 * (K + 1)) := min_le_right _ _
  -- divide by `L`
  have key2 : |e + D / L * s| ≤ η / |L| * (|e| + s) := by
    have e1 : e + D / L * s = (L * e + D * s) / L := by field_simp
    rw [e1, abs_div, div_le_iff₀ hLpos]
    calc |L * e + D * s| ≤ η * |e| + η * s := key
      _ = η / |L| * (|e| + s) * |L| := by field_simp
  have hηL : η / |L| ≤ 1 / 2 := by rw [div_le_iff₀ hLpos]; linarith
  have hebound : |e| ≤ K * s := by
    have t1 : |e| ≤ |e + D / L * s| + |D / L| * s := by
      calc |e| = |(e + D / L * s) - D / L * s| := by ring_nf
        _ ≤ |e + D / L * s| + |D / L * s| := abs_sub _ _
        _ = |e + D / L * s| + |D / L| * s := by rw [abs_mul, abs_of_nonneg hs0]
    have t2 : |e + D / L * s| ≤ 1 / 2 * (|e| + s) :=
      key2.trans (mul_le_mul_of_nonneg_right hηL (by positivity))
    rw [hK]; nlinarith [abs_nonneg e]
  have hfinal : |e + D / L * s| ≤ c * s := by
    calc |e + D / L * s| ≤ η / |L| * (|e| + s) := key2
      _ ≤ η / |L| * (K * s + s) := mul_le_mul_of_nonneg_left (by linarith) (by positivity)
      _ = η / |L| * (K + 1) * s := by ring
      _ ≤ c / (2 * (K + 1)) * (K + 1) * s := by
          refine mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right ?_ (by positivity)) hs0
          rw [div_le_iff₀ hLpos]
          calc η ≤ c * |L| / (2 * (K + 1)) := hη2
            _ = c / (2 * (K + 1)) * |L| := by ring
      _ ≤ c * s := by
          have : c / (2 * (K + 1)) * (K + 1) = c / 2 := by field_simp
          rw [this]; nlinarith
  have e2 : X s - x0 - s * (-D / L) = e + D / L * s := by rw [he]; ring
  rw [e2]
  exact hfinal

end EP1038.Stage10
