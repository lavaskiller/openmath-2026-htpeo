import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk08
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_60 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((573 : ℝ) / 893) ((5763 : ℝ) / 8963))
    (hq : RB (qa a) ((459083 : ℝ) / 25000000) ((467757 : ℝ) / 25000000))
    (hd : RB (D0a a) ((192720813 : ℝ) / 100000000) ((96426079 : ℝ) / 50000000))
    : certE k a ((40248207 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((40926001 : ℝ) / 100000000) ∧ 0 < certE k a ((6539859 : ℝ) / 5000000) ∧ certE k a ((65563273 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((33721 : ℝ) / 100000000) ((547 : ℝ) / 1562500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40248207 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((40213199 : ℝ) / 100000000) ((20107243 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((40248207 : ℝ) / 100000000) ((40248207 : ℝ) / 100000000) ((40248207 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59751793 : ℝ) / 100000000))
  have h3 : RB z3 ((13460081 : ℝ) / 20000000) ((420641 : ℝ) / 625000) := rb_div_signed h2 (show RB ((59751793 : ℝ) / 100000000) ((59751793 : ℝ) / 100000000) ((59751793 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-19800197 : ℝ) / 50000000) ((-39597191 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1080.1 cov_log_1081.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-2546213 : ℝ) / 10000000) ((-6351957 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40248207 : ℝ) / 100000000))
  have h6 : RB z6 ((-45505237 : ℝ) / 50000000) ((-11376309 : ℝ) / 12500000) := rb_log (show RB ((40248207 : ℝ) / 100000000) ((40248207 : ℝ) / 100000000) ((40248207 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1082.1 cov_log_1082.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((32774171 : ℝ) / 50000000) ((32801323 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((65607239 : ℝ) / 100000000) ((6567537 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1083.1 cov_log_1084.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-31757 : ℝ) / 25000000) ((-4593 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((33721 : ℝ) / 100000000) ((547 : ℝ) / 1562500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((40926001 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((40890993 : ℝ) / 100000000) ((1022307 : ℝ) / 2500000) := rb_widen (rb_sub (show RB ((40926001 : ℝ) / 100000000) ((40926001 : ℝ) / 100000000) ((40926001 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((59073999 : ℝ) / 100000000))
  have h12 : RB z12 ((1384399 : ℝ) / 2000000) ((6922213 : ℝ) / 10000000) := rb_div_signed h11 (show RB ((59073999 : ℝ) / 100000000) ((59073999 : ℝ) / 100000000) ((59073999 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-9197027 : ℝ) / 25000000) ((-36784957 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_1085.1 cov_log_1086.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-2956737 : ℝ) / 12500000) ((-23603337 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((40926001 : ℝ) / 100000000))
  have h15 : RB z15 ((-44670231 : ℝ) / 50000000) ((-4467023 : ℝ) / 5000000) := rb_log (show RB ((40926001 : ℝ) / 100000000) ((40926001 : ℝ) / 100000000) ((40926001 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1087.1 cov_log_1087.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16421641 : ℝ) / 25000000) ((525897 : ℝ) / 800000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((65607239 : ℝ) / 100000000) ((6567537 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1083.1 cov_log_1084.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((5597 : ℝ) / 50000000) ((64943 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((33721 : ℝ) / 100000000) ((547 : ℝ) / 1562500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((6539859 : ℝ) / 5000000)) - (z19)
  have h20 : RB z20 ((32690543 : ℝ) / 25000000) ((130763459 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((6539859 : ℝ) / 5000000) ((6539859 : ℝ) / 5000000) ((6539859 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1539859 : ℝ) / 5000000))
  have h21 : RB z21 ((424591381 : ℝ) / 100000000) ((424595561 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((1539859 : ℝ) / 5000000) ((1539859 : ℝ) / 5000000) ((1539859 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((72297853 : ℝ) / 50000000) ((144596693 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1088.1 cov_log_1089.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((18556179 : ℝ) / 20000000) ((46486151 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((6539859 : ℝ) / 5000000))
  have h24 : RB z24 ((26847769 : ℝ) / 100000000) ((2684777 : ℝ) / 10000000) := rb_log (show RB ((6539859 : ℝ) / 5000000) ((6539859 : ℝ) / 5000000) ((6539859 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1090.1 cov_log_1090.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((105493 : ℝ) / 160000) ((66124533 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((65607239 : ℝ) / 100000000) ((6567537 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1083.1 cov_log_1084.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((51551 : ℝ) / 20000000) ((258647 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((33721 : ℝ) / 100000000) ((547 : ℝ) / 1562500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((65563273 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((65545769 : ℝ) / 50000000) ((5243713 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((65563273 : ℝ) / 50000000) ((65563273 : ℝ) / 50000000) ((65563273 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((15563273 : ℝ) / 50000000))
  have h30 : RB z30 ((52644589 : ℝ) / 12500000) ((26322553 : ℝ) / 6250000) := rb_div_signed h29 (show RB ((15563273 : ℝ) / 50000000) ((15563273 : ℝ) / 50000000) ((15563273 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((143783481 : ℝ) / 100000000) ((71892233 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_1091.1 cov_log_1092.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((3690389 : ℝ) / 4000000) ((92450059 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((65563273 : ℝ) / 50000000))
  have h33 : RB z33 ((27099267 : ℝ) / 100000000) ((6774817 : ℝ) / 25000000) := rb_log (show RB ((65563273 : ℝ) / 50000000) ((65563273 : ℝ) / 50000000) ((65563273 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1093.1 cov_log_1093.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((65160457 : ℝ) / 100000000) ((8168849 : ℝ) / 12500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((65607239 : ℝ) / 100000000) ((6567537 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1083.1 cov_log_1084.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-514913 : ℝ) / 100000000) ((-256447 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40248207 : ℝ) / 100000000)) ((-31757 : ℝ) / 25000000) ((-4593 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((40926001 : ℝ) / 100000000)) ((5597 : ℝ) / 50000000) ((64943 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((6539859 : ℝ) / 5000000)) ((51551 : ℝ) / 20000000) ((258647 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((65563273 : ℝ) / 50000000)) ((-514913 : ℝ) / 100000000) ((-256447 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_60 {k A q d vp vm : ℝ}
    (hk : RB k ((573 : ℝ) / 320) ((5763 : ℝ) / 3200))
    (hA : RB A ((573 : ℝ) / 893) ((5763 : ℝ) / 8963))
    (hq : RB q ((459083 : ℝ) / 25000000) ((467757 : ℝ) / 25000000))
    (hd : RB d ((192720813 : ℝ) / 100000000) ((96426079 : ℝ) / 50000000))
    (hp : RB vp ((40248207 : ℝ) / 100000000) ((40926001 : ℝ) / 100000000))
    (hm : RB vm ((6539859 : ℝ) / 5000000) ((65563273 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((33721 : ℝ) / 100000000) ((547 : ℝ) / 1562500) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((1561953 : ℝ) / 1562500) ((99966279 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((6414327 : ℝ) / 10000000) ((64275987 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((16479 : ℝ) / 20000000) ((86981 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99913019 : ℝ) / 100000000) ((19983521 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((59073999 : ℝ) / 100000000) ((59751793 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11804523 : ℝ) / 20000000) ((59702561 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53719027 : ℝ) / 50000000) ((108900609 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3719027 : ℝ) / 50000000) ((8900609 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((1561953 : ℝ) / 1562500) ((99966279 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((6414327 : ℝ) / 10000000) ((64275987 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((6429 : ℝ) / 25000000) ((13383 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49986617 : ℝ) / 50000000) ((24993571 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1539859 : ℝ) / 5000000) ((15563273 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((3848617 : ℝ) / 12500000) ((15559271 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((206125563 : ℝ) / 100000000) ((104381631 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((306125563 : ℝ) / 100000000) ((154381631 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((561759313 : ℝ) / 50000000) ((168054709 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((4048409 : ℝ) / 12500000) ((6533267 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((573 : ℝ) / 160) ((5763 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((6576363 : ℝ) / 100000000) ((6739209 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((25459083 : ℝ) / 25000000) ((25467757 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((6455577 : ℝ) / 100000000) ((6617687 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((106455577 : ℝ) / 100000000) ((106617687 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((89871179 : ℝ) / 100000000) ((90878339 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((86600233 : ℝ) / 50000000) ((87630419 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52643519 : ℝ) / 100000000) ((13416213 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((15709 : ℝ) / 25000000) ((66501 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99933499 : ℝ) / 100000000) ((24984291 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((34617057 : ℝ) / 20000000) ((21893839 : ℝ) / 12500000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((192720813 : ℝ) / 50000000) ((96426079 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((7077987 : ℝ) / 100000000) ((1804159 : ℝ) / 25000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((893 : ℝ) / 320) ((8963 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1263503 : ℝ) / 50000000) ((2586029 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1121739 : ℝ) / 25000000) ((1162181 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((26121739 : ℝ) / 25000000) ((26162181 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((293482603 : ℝ) / 25000000) ((1406936869 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1400427 : ℝ) / 100000000) ((1430481 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101400427 : ℝ) / 100000000) ((101430481 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((256569 : ℝ) / 781250) ((33133621 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((301692811 : ℝ) / 25000000) ((144007049 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((30495181 : ℝ) / 100000000) ((37240641 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((893 : ℝ) / 320) ((8963 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((106455577 : ℝ) / 50000000) ((106617687 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((577952949 : ℝ) / 50000000) ((1377104007 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1230526293 : ℝ) / 50000000) ((36705911 : ℝ) / 1250000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((4751661 : ℝ) / 50000000) ((177829 : ℝ) / 1562500) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-2941911 : ℝ) / 1250000) ((-54330499 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_1094.1 cov_log_1095.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((3538993 : ℝ) / 100000000) ((1804159 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-334132801 : ℝ) / 100000000) ((-83048211 : ℝ) / 25000000) := rb_log h49 (by norm_num) cov_log_1096.1 cov_log_1097.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((65607239 : ℝ) / 100000000) ((6567537 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_1083.1 cov_log_1084.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((58738981 : ℝ) / 50000000) ((118277237 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-216654839 : ℝ) / 100000000) ((-213915607 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1658467 : ℝ) / 20000000) ((10357763 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1391681 : ℝ) / 6250000) ((16982623 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-194387943 : ℝ) / 100000000) ((-179950361 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((106455577 : ℝ) / 100000000) ((106617687 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-2941911 : ℝ) / 1250000) ((-54330499 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-194387943 : ℝ) / 100000000) ((-179950361 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((74 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1121739 : ℝ) / 25000000) ((1162181 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((33 : ℝ) / 20) := by
    have hu : (1 + q / vp) / 2 ≤ ((26162181 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((74 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((33 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-204528663 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((74 : ℝ) / 25) + hfun ((33 : ℝ) / 20) := by
    linarith [hc0.1, cov_h_19, cov_h_17]
  have hP : ((530225401 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((179950361 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((179950361 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((3020787 : ℝ) / 5000000) ≤ EP1038.Arc.sinc ((33 : ℝ) / 20) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((317 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2587 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2587 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2627 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2627 : ℝ) / 1000)) (lo := ((2587 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2667 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2667 : ℝ) / 1000)) (lo := ((2627 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2707 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2707 : ℝ) / 1000)) (lo := ((2667 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2747 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2747 : ℝ) / 1000)) (lo := ((2707 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2787 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2787 : ℝ) / 1000)) (lo := ((2747 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2827 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2827 : ℝ) / 1000)) (lo := ((2787 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2867 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2867 : ℝ) / 1000)) (lo := ((2827 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2907 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2907 : ℝ) / 1000)) (lo := ((2867 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2947 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2947 : ℝ) / 1000)) (lo := ((2907 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((74 : ℝ) / 25)) (lo := ((2947 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_60 {k : ℝ} (hk : RB k ((573 : ℝ) / 320) ((5763 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((573 : ℝ) / 893) ((5763 : ℝ) / 8963) ∧
    RB (qa (r1A k)) ((459083 : ℝ) / 25000000) ((467757 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((192720813 : ℝ) / 100000000) ((96426079 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((573 : ℝ) / 1280) ((22511719 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((92788281 : ℝ) / 50000000) ((59467 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((17028311 : ℝ) / 12500000) ((136321083 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69411961 : ℝ) / 25000000) ((6943561 : ℝ) / 2500000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69411961 : ℝ) / 50000000) ((6943561 : ℝ) / 5000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((192720813 : ℝ) / 100000000) ((96426079 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4533 : ℝ) / 32000) ((7211719 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1770703 : ℝ) / 50000000) ((180293 : ℝ) / 5000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((459083 : ℝ) / 25000000) ((467757 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((192720813 : ℝ) / 100000000) ((96426079 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((459083 : ℝ) / 25000000) ((467757 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((573 : ℝ) / 893) ((5763 : ℝ) / 8963) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_60 {k : ℝ} (hk : RB k ((573 : ℝ) / 320) ((5763 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_60 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_60 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40248207 : ℝ) / 100000000)) (ph := ((40926001 : ℝ) / 100000000)) (ml := ((6539859 : ℝ) / 5000000)) (mh := ((65563273 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_60 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_61 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5763 : ℝ) / 8963) ((1449 : ℝ) / 2249))
    (hq : RB (qa a) ((1871027 : ℝ) / 100000000) ((1905771 : ℝ) / 100000000))
    (hd : RB (D0a a) ((12036839 : ℝ) / 6250000) ((12045051 : ℝ) / 6250000))
    : certE k a ((40175461 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((40843727 : ℝ) / 100000000) ∧ 0 < certE k a ((130907489 : ℝ) / 100000000) ∧ certE k a ((65617647 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((35007 : ℝ) / 100000000) ((227 : ℝ) / 625000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40175461 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((40139141 : ℝ) / 100000000) ((20070227 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((40175461 : ℝ) / 100000000) ((40175461 : ℝ) / 100000000) ((40175461 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59824539 : ℝ) / 100000000))
  have h3 : RB z3 ((8386847 : ℝ) / 12500000) ((16774243 : ℝ) / 25000000) := rb_div_signed h2 (show RB ((59824539 : ℝ) / 100000000) ((59824539 : ℝ) / 100000000) ((59824539 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-49883 : ℝ) / 125000) ((-19951563 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_1098.1 cov_log_1099.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-25711149 : ℝ) / 100000000) ((-25656779 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40175461 : ℝ) / 100000000))
  have h6 : RB z6 ((-91191381 : ℝ) / 100000000) ((-91191379 : ℝ) / 100000000) := rb_log (show RB ((40175461 : ℝ) / 100000000) ((40175461 : ℝ) / 100000000) ((40175461 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1100.1 cov_log_1100.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((6548023 : ℝ) / 10000000) ((32767301 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((65539039 : ℝ) / 100000000) ((32803621 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1101.1 cov_log_1102.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-31753 : ℝ) / 25000000) ((-4437 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((35007 : ℝ) / 100000000) ((227 : ℝ) / 625000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((40843727 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((40807407 : ℝ) / 100000000) ((510109 : ℝ) / 1250000) := rb_widen (rb_sub (show RB ((40843727 : ℝ) / 100000000) ((40843727 : ℝ) / 100000000) ((40843727 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((59156273 : ℝ) / 100000000))
  have h12 : RB z12 ((68982383 : ℝ) / 100000000) ((68984603 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((59156273 : ℝ) / 100000000) ((59156273 : ℝ) / 100000000) ((59156273 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-290093 : ℝ) / 781250) ((-7425737 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_1103.1 cov_log_1104.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-23923579 : ℝ) / 100000000) ((-11936439 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((40843727 : ℝ) / 100000000))
  have h15 : RB z15 ((-17908339 : ℝ) / 20000000) ((-89541693 : ℝ) / 100000000) := rb_log (show RB ((40843727 : ℝ) / 100000000) ((40843727 : ℝ) / 100000000) ((40843727 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1105.1 cov_log_1105.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((32809057 : ℝ) / 50000000) ((65668817 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((65539039 : ℝ) / 100000000) ((32803621 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1101.1 cov_log_1102.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1359 : ℝ) / 12500000) ((64889 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((35007 : ℝ) / 100000000) ((227 : ℝ) / 625000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((130907489 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((130871169 : ℝ) / 100000000) ((65436241 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((130907489 : ℝ) / 100000000) ((130907489 : ℝ) / 100000000) ((130907489 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((30907489 : ℝ) / 100000000))
  have h21 : RB z21 ((105857167 : ℝ) / 25000000) ((423432917 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((30907489 : ℝ) / 100000000) ((30907489 : ℝ) / 100000000) ((30907489 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((144321487 : ℝ) / 100000000) ((72161247 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_1106.1 cov_log_1107.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((1855907 : ℝ) / 2000000) ((92985013 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((130907489 : ℝ) / 100000000))
  have h24 : RB z24 ((26932069 : ℝ) / 100000000) ((2693207 : ℝ) / 10000000) := rb_log (show RB ((130907489 : ℝ) / 100000000) ((130907489 : ℝ) / 100000000) ((130907489 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1108.1 cov_log_1108.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((823291 : ℝ) / 1250000) ((4128309 : ℝ) / 6250000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((65539039 : ℝ) / 100000000) ((32803621 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1101.1 cov_log_1102.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((128019 : ℝ) / 50000000) ((102781 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((35007 : ℝ) / 100000000) ((227 : ℝ) / 625000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((65617647 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((65599487 : ℝ) / 50000000) ((131200287 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((65617647 : ℝ) / 50000000) ((65617647 : ℝ) / 50000000) ((65617647 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((15617647 : ℝ) / 50000000))
  have h30 : RB z30 ((420034381 : ℝ) / 100000000) ((210019293 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((15617647 : ℝ) / 50000000) ((15617647 : ℝ) / 50000000) ((15617647 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((71758319 : ℝ) / 50000000) ((71758821 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_1109.1 cov_log_1110.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92277851 : ℝ) / 100000000) ((46233229 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((65617647 : ℝ) / 50000000))
  have h33 : RB z33 ((13591083 : ℝ) / 50000000) ((27182167 : ℝ) / 100000000) := rb_log (show RB ((65617647 : ℝ) / 50000000) ((65617647 : ℝ) / 50000000) ((65617647 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1111.1 cov_log_1111.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((16273921 : ℝ) / 25000000) ((16321073 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((65539039 : ℝ) / 100000000) ((32803621 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1101.1 cov_log_1102.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-255779 : ℝ) / 50000000) ((-254747 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40175461 : ℝ) / 100000000)) ((-31753 : ℝ) / 25000000) ((-4437 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((40843727 : ℝ) / 100000000)) ((1359 : ℝ) / 12500000) ((64889 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((130907489 : ℝ) / 100000000)) ((128019 : ℝ) / 50000000) ((102781 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((65617647 : ℝ) / 50000000)) ((-255779 : ℝ) / 50000000) ((-254747 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_61 {k A q d vp vm : ℝ}
    (hk : RB k ((5763 : ℝ) / 3200) ((1449 : ℝ) / 800))
    (hA : RB A ((5763 : ℝ) / 8963) ((1449 : ℝ) / 2249))
    (hq : RB q ((1871027 : ℝ) / 100000000) ((1905771 : ℝ) / 100000000))
    (hd : RB d ((12036839 : ℝ) / 6250000) ((12045051 : ℝ) / 6250000))
    (hp : RB vp ((40175461 : ℝ) / 100000000) ((40843727 : ℝ) / 100000000))
    (hm : RB vm ((130907489 : ℝ) / 100000000) ((65617647 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((35007 : ℝ) / 100000000) ((227 : ℝ) / 625000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((624773 : ℝ) / 625000) ((99964993 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((12854863 : ℝ) / 20000000) ((64406081 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((85709 : ℝ) / 100000000) ((22601 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24977399 : ℝ) / 25000000) ((99914291 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((59156273 : ℝ) / 100000000) ((59824539 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((59102793 : ℝ) / 100000000) ((3735829 : ℝ) / 6250000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((107530207 : ℝ) / 100000000) ((108972991 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((7530207 : ℝ) / 100000000) ((8972991 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((624773 : ℝ) / 625000) ((99964993 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((12854863 : ℝ) / 20000000) ((64406081 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((13337 : ℝ) / 50000000) ((5549 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19994451 : ℝ) / 20000000) ((49986663 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((30907489 : ℝ) / 100000000) ((15617647 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((30898913 : ℝ) / 100000000) ((31226963 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((102914771 : ℝ) / 50000000) ((52110313 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((152914771 : ℝ) / 50000000) ((77110313 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((139306949 : ℝ) / 12500000) ((663992371 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((8105271 : ℝ) / 25000000) ((16348977 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5763 : ℝ) / 1600) ((1449 : ℝ) / 400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1347841 : ℝ) / 20000000) ((862957 : ℝ) / 12500000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101871027 : ℝ) / 100000000) ((101905771 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((6613173 : ℝ) / 100000000) ((338843 : ℝ) / 5000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((106613173 : ℝ) / 100000000) ((5338843 : ℝ) / 5000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((45031881 : ℝ) / 50000000) ((91059833 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((1084083 : ℝ) / 625000) ((87745627 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52592687 : ℝ) / 100000000) ((26800693 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((65309 : ℝ) / 100000000) ((3453 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4996547 : ℝ) / 5000000) ((99934691 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((173333493 : ℝ) / 100000000) ((175376643 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((12036839 : ℝ) / 3125000) ((12045051 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((18017 : ℝ) / 250000) ((1469127 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8963 : ℝ) / 3200) ((2249 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2563557 : ℝ) / 100000000) ((2622563 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((229047 : ℝ) / 5000000) ((237181 : ℝ) / 5000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((5229047 : ℝ) / 5000000) ((5237181 : ℝ) / 5000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1165508133 : ℝ) / 100000000) ((347744823 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((178213 : ℝ) / 12500000) ((181977 : ℝ) / 12500000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((12678213 : ℝ) / 12500000) ((12681977 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((2055207 : ℝ) / 6250000) ((33173977 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((239678289 : ℝ) / 20000000) ((1424153269 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((30721447 : ℝ) / 100000000) ((37349317 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8963 : ℝ) / 3200) ((2249 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((106613173 : ℝ) / 50000000) ((5338843 : ℝ) / 2500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((286719169 : ℝ) / 25000000) ((170085337 : ℝ) / 12500000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2445443229 : ℝ) / 100000000) ((581157703 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1927833 : ℝ) / 20000000) ((179623 : ℝ) / 1562500) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-233933573 : ℝ) / 100000000) ((-27039777 : ℝ) / 12500000) := rb_log h47 (by norm_num) cov_log_1112.1 cov_log_1113.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((18017 : ℝ) / 500000) ((1836409 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-332329239 : ℝ) / 100000000) ((-41302637 : ℝ) / 12500000) := rb_log h49 (by norm_num) cov_log_1114.1 cov_log_1115.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((65539039 : ℝ) / 100000000) ((32803621 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1101.1 cov_log_1102.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((118031713 : ℝ) / 100000000) ((59415559 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-107148763 : ℝ) / 50000000) ((-105794989 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2016601 : ℝ) / 25000000) ((2021911 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2699649 : ℝ) / 12500000) ((16453579 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-96350167 : ℝ) / 50000000) ((-8934141 : ℝ) / 5000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((106613173 : ℝ) / 100000000) ((5338843 : ℝ) / 5000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-233933573 : ℝ) / 100000000) ((-27039777 : ℝ) / 12500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-96350167 : ℝ) / 50000000) ((-8934141 : ℝ) / 5000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((59 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((229047 : ℝ) / 5000000) ((237181 : ℝ) / 5000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((33 : ℝ) / 20) := by
    have hu : (1 + q / vp) / 2 ≤ ((5237181 : ℝ) / 10000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((59 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((33 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-6339483 : ℝ) / 3125000) ≤ formC0 k A q vp vm + hfun ((59 : ℝ) / 20) + hfun ((33 : ℝ) / 20) := by
    linarith [hc0.1, cov_h_20, cov_h_17]
  have hP : ((525705737 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((8934141 : ℝ) / 5000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((8934141 : ℝ) / 5000000))
    linarith [hap.2]
  have hS : ((3020787 : ℝ) / 5000000) ≤ EP1038.Arc.sinc ((33 : ℝ) / 20) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((317 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1293 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1293 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1313 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1313 : ℝ) / 500)) (lo := ((1293 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1333 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1333 : ℝ) / 500)) (lo := ((1313 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1353 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1353 : ℝ) / 500)) (lo := ((1333 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1373 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1373 : ℝ) / 500)) (lo := ((1353 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1393 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1393 : ℝ) / 500)) (lo := ((1373 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1413 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1413 : ℝ) / 500)) (lo := ((1393 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1433 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1433 : ℝ) / 500)) (lo := ((1413 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1453 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1453 : ℝ) / 500)) (lo := ((1433 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1473 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1473 : ℝ) / 500)) (lo := ((1453 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((1473 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_61 {k : ℝ} (hk : RB k ((5763 : ℝ) / 3200) ((1449 : ℝ) / 800)) :
    RB (k / (k + 1)) ((5763 : ℝ) / 8963) ((1449 : ℝ) / 2249) ∧
    RB (qa (r1A k)) ((1871027 : ℝ) / 100000000) ((1905771 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((12036839 : ℝ) / 6250000) ((12045051 : ℝ) / 6250000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((45023437 : ℝ) / 100000000) ((1449 : ℝ) / 3200) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((29651 : ℝ) / 16000) ((185576563 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((136131829 : ℝ) / 100000000) ((136226489 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((55510637 : ℝ) / 20000000) ((138823923 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((8673537 : ℝ) / 6250000) ((138823923 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((12036839 : ℝ) / 6250000) ((12045051 : ℝ) / 6250000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((14423437 : ℝ) / 100000000) ((2349 : ℝ) / 16000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((3605859 : ℝ) / 100000000) ((3670313 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1871027 : ℝ) / 100000000) ((1905771 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((12036839 : ℝ) / 6250000) ((12045051 : ℝ) / 6250000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1871027 : ℝ) / 100000000) ((1905771 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5763 : ℝ) / 8963) ((1449 : ℝ) / 2249) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_61 {k : ℝ} (hk : RB k ((5763 : ℝ) / 3200) ((1449 : ℝ) / 800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_61 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_61 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40175461 : ℝ) / 100000000)) (ph := ((40843727 : ℝ) / 100000000)) (ml := ((130907489 : ℝ) / 100000000)) (mh := ((65617647 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_61 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_62 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1449 : ℝ) / 2249) ((5829 : ℝ) / 9029))
    (hq : RB (qa a) ((190577 : ℝ) / 10000000) ((970281 : ℝ) / 50000000))
    (hd : RB (D0a a) ((24057249 : ℝ) / 12500000) ((192589431 : ℝ) / 100000000))
    : certE k a ((40103531 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((1630511 : ℝ) / 4000000) ∧ 0 < certE k a ((13101727 : ℝ) / 10000000) ∧ certE k a ((26268707 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((36319 : ℝ) / 100000000) ((18829 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40103531 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((40065873 : ℝ) / 100000000) ((10016803 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((40103531 : ℝ) / 100000000) ((40103531 : ℝ) / 100000000) ((40103531 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59896469 : ℝ) / 100000000))
  have h3 : RB z3 ((33445939 : ℝ) / 50000000) ((33447057 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((59896469 : ℝ) / 100000000) ((59896469 : ℝ) / 100000000) ((59896469 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2513079 : ℝ) / 6250000) ((-251287 : ℝ) / 625000) := rb_log h3 (by norm_num) cov_log_1116.1 cov_log_1117.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-6489639 : ℝ) / 25000000) ((-207233 : ℝ) / 800000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40103531 : ℝ) / 100000000))
  have h6 : RB z6 ((-45685291 : ℝ) / 50000000) ((-4568529 : ℝ) / 5000000) := rb_log (show RB ((40103531 : ℝ) / 100000000) ((40103531 : ℝ) / 100000000) ((40103531 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1118.1 cov_log_1118.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((8176503 : ℝ) / 12500000) ((65466457 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((65470771 : ℝ) / 100000000) ((13107809 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1119.1 cov_log_1120.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-127021 : ℝ) / 100000000) ((-2157 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((36319 : ℝ) / 100000000) ((18829 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((1630511 : ℝ) / 4000000)) - (z10)
  have h11 : RB z11 ((40725117 : ℝ) / 100000000) ((5090807 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((1630511 : ℝ) / 4000000) ((1630511 : ℝ) / 4000000) ((1630511 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((2369489 : ℝ) / 4000000))
  have h12 : RB z12 ((68749197 : ℝ) / 100000000) ((68751459 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((2369489 : ℝ) / 4000000) ((2369489 : ℝ) / 4000000) ((2369489 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-37470513 : ℝ) / 100000000) ((-18733611 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_1121.1 cov_log_1122.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3023807 : ℝ) / 12500000) ((-24139619 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((1630511 : ℝ) / 4000000))
  have h15 : RB z15 ((-89740091 : ℝ) / 100000000) ((-89740089 : ℝ) / 100000000) := rb_log (show RB ((1630511 : ℝ) / 4000000) ((1630511 : ℝ) / 4000000) ((1630511 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1123.1 cov_log_1123.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((65549633 : ℝ) / 100000000) ((8200059 : ℝ) / 12500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((65470771 : ℝ) / 100000000) ((13107809 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1119.1 cov_log_1120.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2647 : ℝ) / 25000000) ((129701 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((36319 : ℝ) / 100000000) ((18829 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((13101727 : ℝ) / 10000000)) - (z19)
  have h20 : RB z20 ((32744903 : ℝ) / 25000000) ((130980951 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((13101727 : ℝ) / 10000000) ((13101727 : ℝ) / 10000000) ((13101727 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((3101727 : ℝ) / 10000000))
  have h21 : RB z21 ((211139813 : ℝ) / 50000000) ((52785493 : ℝ) / 12500000) := rb_div_signed h20 (show RB ((3101727 : ℝ) / 10000000) ((3101727 : ℝ) / 10000000) ((3101727 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((18006219 : ℝ) / 12500000) ((72025389 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_1124.1 cov_log_1125.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((11601161 : ℝ) / 12500000) ((9299723 : ℝ) / 10000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((13101727 : ℝ) / 10000000))
  have h24 : RB z24 ((3376987 : ℝ) / 12500000) ((27015897 : ℝ) / 100000000) := rb_log (show RB ((13101727 : ℝ) / 10000000) ((13101727 : ℝ) / 10000000) ((13101727 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1126.1 cov_log_1126.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((65793391 : ℝ) / 100000000) ((32990667 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((65470771 : ℝ) / 100000000) ((13107809 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1119.1 cov_log_1120.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((127173 : ℝ) / 50000000) ((510563 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((36319 : ℝ) / 100000000) ((18829 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((26268707 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((131305877 : ℝ) / 100000000) ((8206701 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((26268707 : ℝ) / 20000000) ((26268707 : ℝ) / 20000000) ((26268707 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((6268707 : ℝ) / 20000000))
  have h30 : RB z30 ((418924913 : ℝ) / 100000000) ((209464593 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((6268707 : ℝ) / 20000000) ((6268707 : ℝ) / 20000000) ((6268707 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((143252151 : ℝ) / 100000000) ((71626587 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_1127.1 cov_log_1128.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18459081 : ℝ) / 20000000) ((23120577 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((26268707 : ℝ) / 20000000))
  have h33 : RB z33 ((2726461 : ℝ) / 10000000) ((27264611 : ℝ) / 100000000) := rb_log (show RB ((26268707 : ℝ) / 20000000) ((26268707 : ℝ) / 20000000) ((26268707 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1129.1 cov_log_1129.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((32515397 : ℝ) / 50000000) ((32608849 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((65470771 : ℝ) / 100000000) ((13107809 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1119.1 cov_log_1120.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-508251 : ℝ) / 100000000) ((-253073 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40103531 : ℝ) / 100000000)) ((-127021 : ℝ) / 100000000) ((-2157 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((1630511 : ℝ) / 4000000)) ((2647 : ℝ) / 25000000) ((129701 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((13101727 : ℝ) / 10000000)) ((127173 : ℝ) / 50000000) ((510563 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((26268707 : ℝ) / 20000000)) ((-508251 : ℝ) / 100000000) ((-253073 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_62 {k A q d vp vm : ℝ}
    (hk : RB k ((1449 : ℝ) / 800) ((5829 : ℝ) / 3200))
    (hA : RB A ((1449 : ℝ) / 2249) ((5829 : ℝ) / 9029))
    (hq : RB q ((190577 : ℝ) / 10000000) ((970281 : ℝ) / 50000000))
    (hd : RB d ((24057249 : ℝ) / 12500000) ((192589431 : ℝ) / 100000000))
    (hp : RB vp ((40103531 : ℝ) / 100000000) ((1630511 : ℝ) / 4000000))
    (hm : RB vm ((13101727 : ℝ) / 10000000) ((26268707 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((36319 : ℝ) / 100000000) ((18829 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49981171 : ℝ) / 50000000) ((99963681 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((16101093 : ℝ) / 25000000) ((32267599 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((44549 : ℝ) / 50000000) ((46951 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49953049 : ℝ) / 50000000) ((49955451 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((2369489 : ℝ) / 4000000) ((59896469 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((73977 : ℝ) / 125000) ((59843103 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53811023 : ℝ) / 50000000) ((27261513 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3811023 : ℝ) / 50000000) ((2261513 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49981171 : ℝ) / 50000000) ((99963681 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((16101093 : ℝ) / 25000000) ((32267599 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((27651 : ℝ) / 100000000) ((28743 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99971257 : ℝ) / 100000000) ((99972349 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((3101727 : ℝ) / 10000000) ((6268707 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((15504177 : ℝ) / 50000000) ((31334869 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((102767897 : ℝ) / 50000000) ((208121973 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((152767897 : ℝ) / 50000000) ((308121973 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((552727311 : ℝ) / 50000000) ((655991843 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((32454679 : ℝ) / 100000000) ((3272939 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1449 : ℝ) / 400) ((5829 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((6903651 : ℝ) / 100000000) ((706971 : ℝ) / 10000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((10190577 : ℝ) / 10000000) ((50970281 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((6772231 : ℝ) / 100000000) ((3468749 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((106772231 : ℝ) / 100000000) ((53468749 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((18050899 : ℝ) / 20000000) ((22810001 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((43425497 : ℝ) / 25000000) ((35143721 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52542551 : ℝ) / 100000000) ((5353927 : ℝ) / 10000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((16959 : ℝ) / 25000000) ((8959 : ℝ) / 12500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((12491041 : ℝ) / 12500000) ((24983041 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((43394373 : ℝ) / 25000000) ((35119881 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((24057249 : ℝ) / 6250000) ((192589431 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((7335613 : ℝ) / 100000000) ((1494927 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((2249 : ℝ) / 800) ((9029 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((16249 : ℝ) / 625000) ((265883 : ℝ) / 10000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((467527 : ℝ) / 10000000) ((4838881 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((10467527 : ℝ) / 10000000) ((104838881 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((115713761 : ℝ) / 10000000) ((171933627 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1450981 : ℝ) / 100000000) ((29623 : ℝ) / 2000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101450981 : ℝ) / 100000000) ((2029623 : ℝ) / 2000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3292559 : ℝ) / 10000000) ((16607081 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1487579 : ℝ) / 125000) ((704341589 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((30939739 : ℝ) / 100000000) ((37454491 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((2249 : ℝ) / 800) ((9029 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((106772231 : ℝ) / 50000000) ((53468749 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1137909301 : ℝ) / 100000000) ((336178269 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1214971147 : ℝ) / 50000000) ((1438002519 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((9774843 : ℝ) / 100000000) ((2322329 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-232535817 : ℝ) / 100000000) ((-215316171 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1130.1 cov_log_1131.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1833903 : ℝ) / 50000000) ((1868659 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-165278829 : ℝ) / 50000000) ((-164340097 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_1132.1 cov_log_1133.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((65470771 : ℝ) / 100000000) ((13107809 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1119.1 cov_log_1120.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((118583933 : ℝ) / 100000000) ((119383467 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-8478949 : ℝ) / 4000000) ((-209296727 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3921821 : ℝ) / 50000000) ((2466389 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((20941793 : ℝ) / 100000000) ((31886359 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-47757983 : ℝ) / 25000000) ((-2772037 : ℝ) / 1562500) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((106772231 : ℝ) / 100000000) ((53468749 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-232535817 : ℝ) / 100000000) ((-215316171 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-47757983 : ℝ) / 25000000) ((-2772037 : ℝ) / 1562500) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((59 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((467527 : ℝ) / 10000000) ((4838881 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((33 : ℝ) / 20) := by
    have hu : (1 + q / vp) / 2 ≤ ((104838881 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((59 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((33 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-2014657 : ℝ) / 1000000) ≤ formC0 k A q vp vm + hfun ((59 : ℝ) / 20) + hfun ((33 : ℝ) / 20) := by
    linarith [hc0.1, cov_h_20, cov_h_17]
  have hP : ((13029449 : ℝ) / 2500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((2772037 : ℝ) / 1562500) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((2772037 : ℝ) / 1562500))
    linarith [hap.2]
  have hS : ((3020787 : ℝ) / 5000000) ≤ EP1038.Arc.sinc ((33 : ℝ) / 20) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((317 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2581 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2581 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2621 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2621 : ℝ) / 1000)) (lo := ((2581 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2661 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2661 : ℝ) / 1000)) (lo := ((2621 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2701 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2701 : ℝ) / 1000)) (lo := ((2661 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2741 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2741 : ℝ) / 1000)) (lo := ((2701 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2781 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2781 : ℝ) / 1000)) (lo := ((2741 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2821 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2821 : ℝ) / 1000)) (lo := ((2781 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2861 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2861 : ℝ) / 1000)) (lo := ((2821 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2901 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2901 : ℝ) / 1000)) (lo := ((2861 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2941 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2941 : ℝ) / 1000)) (lo := ((2901 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((2941 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_62 {k : ℝ} (hk : RB k ((1449 : ℝ) / 800) ((5829 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((1449 : ℝ) / 2249) ((5829 : ℝ) / 9029) ∧
    RB (qa (r1A k)) ((190577 : ℝ) / 10000000) ((970281 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((24057249 : ℝ) / 12500000) ((192589431 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((1449 : ℝ) / 3200) ((45539063 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((185060937 : ℝ) / 100000000) ((29651 : ℝ) / 16000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((8502319 : ℝ) / 6250000) ((13613183 : ℝ) / 10000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((13872923 : ℝ) / 5000000) ((277553187 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((13872923 : ℝ) / 10000000) ((69388297 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((24057249 : ℝ) / 12500000) ((192589431 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2349 : ℝ) / 16000) ((14939063 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((458789 : ℝ) / 12500000) ((1867383 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((190577 : ℝ) / 10000000) ((970281 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((24057249 : ℝ) / 12500000) ((192589431 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((190577 : ℝ) / 10000000) ((970281 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1449 : ℝ) / 2249) ((5829 : ℝ) / 9029) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_62 {k : ℝ} (hk : RB k ((1449 : ℝ) / 800) ((5829 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_62 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_62 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40103531 : ℝ) / 100000000)) (ph := ((1630511 : ℝ) / 4000000)) (ml := ((13101727 : ℝ) / 10000000)) (mh := ((26268707 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_62 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_63 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5829 : ℝ) / 9029) ((2931 : ℝ) / 4531))
    (hq : RB (qa a) ((1940561 : ℝ) / 100000000) ((1975401 : ℝ) / 100000000))
    (hd : RB (D0a a) ((19232651 : ℝ) / 10000000) ((48114499 : ℝ) / 25000000))
    : certE k a ((20016187 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((40683073 : ℝ) / 100000000) ∧ 0 < certE k a ((32781633 : ℝ) / 25000000) ∧ certE k a ((5258051 : ℝ) / 4000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((37657 : ℝ) / 100000000) ((39023 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((20016187 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((39993351 : ℝ) / 100000000) ((39994717 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((20016187 : ℝ) / 50000000) ((20016187 : ℝ) / 50000000) ((20016187 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((29983813 : ℝ) / 50000000))
  have h3 : RB z3 ((66691569 : ℝ) / 100000000) ((8336731 : ℝ) / 12500000) := rb_div_signed h2 (show RB ((29983813 : ℝ) / 50000000) ((29983813 : ℝ) / 50000000) ((29983813 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-8101833 : ℝ) / 20000000) ((-40505747 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1134.1 cov_log_1135.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-524089 : ℝ) / 2000000) ((-26149961 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((20016187 : ℝ) / 50000000))
  have h6 : RB z6 ((-22887043 : ℝ) / 25000000) ((-9154817 : ℝ) / 10000000) := rb_log (show RB ((20016187 : ℝ) / 50000000) ((20016187 : ℝ) / 50000000) ((20016187 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1136.1 cov_log_1136.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((1633593 : ℝ) / 2500000) ((65398211 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((65402431 : ℝ) / 100000000) ((8183847 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_1137.1 cov_log_1138.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-7941 : ℝ) / 6250000) ((-211 : ℝ) / 5000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((37657 : ℝ) / 100000000) ((39023 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((40683073 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((812881 : ℝ) / 2000000) ((5080677 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((40683073 : ℝ) / 100000000) ((40683073 : ℝ) / 100000000) ((40683073 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((59316927 : ℝ) / 100000000))
  have h12 : RB z12 ((34260077 : ℝ) / 50000000) ((34261229 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((59316927 : ℝ) / 100000000) ((59316927 : ℝ) / 100000000) ((59316927 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-37804227 : ℝ) / 100000000) ((-1181277 : ℝ) / 3125000) := rb_log h12 (by norm_num) cov_log_1139.1 cov_log_1140.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-764209 : ℝ) / 3125000) ((-976149 : ℝ) / 4000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((40683073 : ℝ) / 100000000))
  have h15 : RB z15 ((-89935809 : ℝ) / 100000000) ((-89935807 : ℝ) / 100000000) := rb_log (show RB ((40683073 : ℝ) / 100000000) ((40683073 : ℝ) / 100000000) ((40683073 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1141.1 cov_log_1141.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((65481119 : ℝ) / 100000000) ((16383021 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((65402431 : ℝ) / 100000000) ((8183847 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_1137.1 cov_log_1138.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((10343 : ℝ) / 100000000) ((129653 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((37657 : ℝ) / 100000000) ((39023 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((32781633 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((131087509 : ℝ) / 100000000) ((1048711 : ℝ) / 800000) := rb_widen (rb_sub (show RB ((32781633 : ℝ) / 25000000) ((32781633 : ℝ) / 25000000) ((32781633 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((7781633 : ℝ) / 25000000))
  have h21 : RB z21 ((210571979 : ℝ) / 50000000) ((105287087 : ℝ) / 25000000) := rb_div_signed h20 (show RB ((7781633 : ℝ) / 25000000) ((7781633 : ℝ) / 25000000) ((7781633 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((143780453 : ℝ) / 100000000) ((71890749 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_1142.1 cov_log_1143.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92822711 : ℝ) / 100000000) ((18601791 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((32781633 : ℝ) / 25000000))
  have h24 : RB z24 ((3387407 : ℝ) / 12500000) ((27099257 : ℝ) / 100000000) := rb_log (show RB ((32781633 : ℝ) / 25000000) ((32781633 : ℝ) / 25000000) ((32781633 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1144.1 cov_log_1144.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((32861727 : ℝ) / 50000000) ((65909699 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((65402431 : ℝ) / 100000000) ((8183847 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_1137.1 cov_log_1138.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((126339 : ℝ) / 50000000) ((126817 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((37657 : ℝ) / 100000000) ((39023 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((5258051 : ℝ) / 4000000)) - (z28)
  have h29 : RB z29 ((32853063 : ℝ) / 25000000) ((65706809 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((5258051 : ℝ) / 4000000) ((5258051 : ℝ) / 4000000) ((5258051 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((1258051 : ℝ) / 4000000))
  have h30 : RB z30 ((417828059 : ℝ) / 100000000) ((417832403 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((1258051 : ℝ) / 4000000) ((1258051 : ℝ) / 4000000) ((1258051 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((142989981 : ℝ) / 100000000) ((8936939 : ℝ) / 6250000) := rb_log h30 (by norm_num) cov_log_1145.1 cov_log_1146.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92312393 : ℝ) / 100000000) ((18499523 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((5258051 : ℝ) / 4000000))
  have h33 : RB z33 ((13673303 : ℝ) / 50000000) ((27346607 : ℝ) / 100000000) := rb_log (show RB ((5258051 : ℝ) / 4000000) ((5258051 : ℝ) / 4000000) ((5258051 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1147.1 cov_log_1147.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((32482893 : ℝ) / 50000000) ((65151009 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((65402431 : ℝ) / 100000000) ((8183847 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_1137.1 cov_log_1138.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-50499 : ℝ) / 10000000) ((-125711 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((20016187 : ℝ) / 50000000)) ((-7941 : ℝ) / 6250000) ((-211 : ℝ) / 5000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((40683073 : ℝ) / 100000000)) ((10343 : ℝ) / 100000000) ((129653 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((32781633 : ℝ) / 25000000)) ((126339 : ℝ) / 50000000) ((126817 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((5258051 : ℝ) / 4000000)) ((-50499 : ℝ) / 10000000) ((-125711 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_63 {k A q d vp vm : ℝ}
    (hk : RB k ((5829 : ℝ) / 3200) ((2931 : ℝ) / 1600))
    (hA : RB A ((5829 : ℝ) / 9029) ((2931 : ℝ) / 4531))
    (hq : RB q ((1940561 : ℝ) / 100000000) ((1975401 : ℝ) / 100000000))
    (hd : RB d ((19232651 : ℝ) / 10000000) ((48114499 : ℝ) / 25000000))
    (hp : RB vp ((20016187 : ℝ) / 50000000) ((40683073 : ℝ) / 100000000))
    (hm : RB vm ((32781633 : ℝ) / 25000000) ((5258051 : ℝ) / 4000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((37657 : ℝ) / 100000000) ((39023 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99960977 : ℝ) / 100000000) ((99962343 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((64533451 : ℝ) / 100000000) ((16165837 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((92561 : ℝ) / 100000000) ((97479 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99902521 : ℝ) / 100000000) ((99907439 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((59316927 : ℝ) / 100000000) ((29983813 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11851821 : ℝ) / 20000000) ((1497803 : ℝ) / 2500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((26928379 : ℝ) / 25000000) ((27279921 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1928379 : ℝ) / 25000000) ((2279921 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99960977 : ℝ) / 100000000) ((99962343 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((64533451 : ℝ) / 100000000) ((16165837 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((28647 : ℝ) / 100000000) ((93 : ℝ) / 312500) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((312407 : ℝ) / 312500) ((99971353 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((7781633 : ℝ) / 25000000) ((1258051 : ℝ) / 4000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((7779317 : ℝ) / 25000000) ((15721133 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((8209771 : ℝ) / 4000000) ((25975669 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((12209771 : ℝ) / 4000000) ((38475669 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1096529221 : ℝ) / 100000000) ((1296425651 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((253813 : ℝ) / 781250) ((4095081 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5829 : ℝ) / 1600) ((2931 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((3534853 : ℝ) / 50000000) ((28271 : ℝ) / 390625) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101940561 : ℝ) / 100000000) ((101975401 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1733189 : ℝ) / 25000000) ((1774901 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((26733189 : ℝ) / 25000000) ((26774901 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((90443459 : ℝ) / 100000000) ((91418901 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((43486687 : ℝ) / 25000000) ((35188597 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52493063 : ℝ) / 100000000) ((53478419 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((14083 : ℝ) / 20000000) ((3717 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4996283 : ℝ) / 5000000) ((19985917 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((34763487 : ℝ) / 20000000) ((35163819 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((19232651 : ℝ) / 5000000) ((48114499 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((3732213 : ℝ) / 50000000) ((1520727 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((9029 : ℝ) / 3200) ((4531 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2635859 : ℝ) / 100000000) ((168427 : ℝ) / 6250000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2384973 : ℝ) / 50000000) ((4934509 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((52384973 : ℝ) / 50000000) ((104934509 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((71802067 : ℝ) / 6250000) ((340099473 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((738129 : ℝ) / 50000000) ((301297 : ℝ) / 20000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50738129 : ℝ) / 50000000) ((20301297 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32967671 : ℝ) / 100000000) ((33254183 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1181800743 : ℝ) / 100000000) ((55746083 : ℝ) / 4000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((31150601 : ℝ) / 100000000) ((37556583 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((9029 : ℝ) / 3200) ((4531 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((26733189 : ℝ) / 12500000) ((26774901 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((225803457 : ℝ) / 20000000) ((1329186299 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2414578597 : ℝ) / 100000000) ((1423553263 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((247757 : ℝ) / 2500000) ((11728237 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-115579881 : ℝ) / 50000000) ((-214317083 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1148.1 cov_log_1149.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((3732213 : ℝ) / 100000000) ((1900909 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-41102111 : ℝ) / 12500000) ((-8174227 : ℝ) / 2500000) := rb_log h49 (by norm_num) cov_log_1150.1 cov_log_1151.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((65402431 : ℝ) / 100000000) ((8183847 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_1137.1 cov_log_1138.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((23826923 : ℝ) / 20000000) ((59967139 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-209682273 : ℝ) / 100000000) ((-103517401 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((476497 : ℝ) / 6250000) ((9625613 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((5074977 : ℝ) / 25000000) ((30900249 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-37876473 : ℝ) / 20000000) ((-176134553 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((26733189 : ℝ) / 25000000) ((26774901 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-115579881 : ℝ) / 50000000) ((-214317083 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-37876473 : ℝ) / 20000000) ((-176134553 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((147 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2384973 : ℝ) / 50000000) ((4934509 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((33 : ℝ) / 20) := by
    have hu : (1 + q / vp) / 2 ≤ ((104934509 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((147 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((33 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-199846433 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((147 : ℝ) / 50) + hfun ((33 : ℝ) / 20) := by
    linarith [hc0.1, cov_h_22, cov_h_17]
  have hP : ((516646819 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((176134553 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((176134553 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((3020787 : ℝ) / 5000000) ≤ EP1038.Arc.sinc ((33 : ℝ) / 20) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((317 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((129 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((129 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((131 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((131 : ℝ) / 50)) (lo := ((129 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((133 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((133 : ℝ) / 50)) (lo := ((131 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((27 : ℝ) / 10) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((27 : ℝ) / 10)) (lo := ((133 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((137 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((137 : ℝ) / 50)) (lo := ((27 : ℝ) / 10)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((139 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((139 : ℝ) / 50)) (lo := ((137 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((141 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((141 : ℝ) / 50)) (lo := ((139 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((143 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((143 : ℝ) / 50)) (lo := ((141 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((29 : ℝ) / 10) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((29 : ℝ) / 10)) (lo := ((143 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((147 : ℝ) / 50)) (lo := ((29 : ℝ) / 10)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_63 {k : ℝ} (hk : RB k ((5829 : ℝ) / 3200) ((2931 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((5829 : ℝ) / 9029) ((2931 : ℝ) / 4531) ∧
    RB (qa (r1A k)) ((1940561 : ℝ) / 100000000) ((1975401 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((19232651 : ℝ) / 10000000) ((48114499 : ℝ) / 25000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((22769531 : ℝ) / 50000000) ((2931 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((59137 : ℝ) / 32000) ((92530469 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((135942313 : ℝ) / 100000000) ((27207421 : ℝ) / 20000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((277363669 : ℝ) / 100000000) ((138729231 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69340917 : ℝ) / 50000000) ((138729231 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((19232651 : ℝ) / 10000000) ((48114499 : ℝ) / 25000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((7469531 : ℝ) / 50000000) ((4863 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((746953 : ℝ) / 20000000) ((3799219 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1940561 : ℝ) / 100000000) ((1975401 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((19232651 : ℝ) / 10000000) ((48114499 : ℝ) / 25000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1940561 : ℝ) / 100000000) ((1975401 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5829 : ℝ) / 9029) ((2931 : ℝ) / 4531) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_63 {k : ℝ} (hk : RB k ((5829 : ℝ) / 3200) ((2931 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_63 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_63 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((20016187 : ℝ) / 50000000)) (ph := ((40683073 : ℝ) / 100000000)) (ml := ((32781633 : ℝ) / 25000000)) (mh := ((5258051 : ℝ) / 4000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_63 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_64 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2931 : ℝ) / 4531) ((1179 : ℝ) / 1819))
    (hq : RB (qa a) ((1975399 : ℝ) / 100000000) ((125643 : ℝ) / 6250000))
    (hd : RB (D0a a) ((96097491 : ℝ) / 50000000) ((192326517 : ℝ) / 100000000))
    : certE k a ((1248811 : ℝ) / 3125000) < 0 ∧ 0 < certE k a ((5075569 : ℝ) / 12500000) ∧ 0 < certE k a ((1640441 : ℝ) / 1250000) ∧ certE k a ((65779261 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((19511 : ℝ) / 50000000) ((40413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1248811 : ℝ) / 3125000)) - (z1)
  have h2 : RB z2 ((39921539 : ℝ) / 100000000) ((3992293 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((1248811 : ℝ) / 3125000) ((1248811 : ℝ) / 3125000) ((1248811 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((1876189 : ℝ) / 3125000))
  have h3 : RB z3 ((16623433 : ℝ) / 25000000) ((1329921 : ℝ) / 2000000) := rb_div_signed h2 (show RB ((1876189 : ℝ) / 3125000) ((1876189 : ℝ) / 3125000) ((1876189 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-40806251 : ℝ) / 100000000) ((-40802763 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1152.1 cov_log_1153.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1653057 : ℝ) / 6250000) ((-26394371 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((1248811 : ℝ) / 3125000))
  have h6 : RB z6 ((-1146553 : ℝ) / 1250000) ((-45862119 : ℝ) / 50000000) := rb_log (show RB ((1248811 : ℝ) / 3125000) ((1248811 : ℝ) / 3125000) ((1248811 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1154.1 cov_log_1154.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((32637663 : ℝ) / 50000000) ((65329869 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((3266701 : ℝ) / 5000000) ((65402437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1155.1 cov_log_1156.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-127111 : ℝ) / 100000000) ((-4151 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((19511 : ℝ) / 50000000) ((40413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((5075569 : ℝ) / 12500000)) - (z10)
  have h11 : RB z11 ((40564139 : ℝ) / 100000000) ((4056553 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((5075569 : ℝ) / 12500000) ((5075569 : ℝ) / 12500000) ((5075569 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((7424431 : ℝ) / 12500000))
  have h12 : RB z12 ((68295029 : ℝ) / 100000000) ((17074343 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((7424431 : ℝ) / 12500000) ((7424431 : ℝ) / 12500000) ((7424431 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-38133321 : ℝ) / 100000000) ((-38129889 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_1157.1 cov_log_1158.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-2471643 : ℝ) / 10000000) ((-493307 : ℝ) / 2000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((5075569 : ℝ) / 12500000))
  have h15 : RB z15 ((-45064501 : ℝ) / 50000000) ((-90129 : ℝ) / 100000) := rb_log (show RB ((5075569 : ℝ) / 12500000) ((5075569 : ℝ) / 12500000) ((5075569 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1159.1 cov_log_1159.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((6541257 : ℝ) / 10000000) ((16365913 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((3266701 : ℝ) / 5000000) ((65402437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1155.1 cov_log_1156.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((10133 : ℝ) / 100000000) ((4051 : ℝ) / 3125000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((19511 : ℝ) / 50000000) ((40413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((1640441 : ℝ) / 1250000)) - (z19)
  have h20 : RB z20 ((131194867 : ℝ) / 100000000) ((65598129 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1640441 : ℝ) / 1250000) ((1640441 : ℝ) / 1250000) ((1640441 : ℝ) / 1250000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((390441 : ℝ) / 1250000))
  have h21 : RB z21 ((420021421 : ℝ) / 100000000) ((3360207 : ℝ) / 800000) := rb_div_signed h20 (show RB ((390441 : ℝ) / 1250000) ((390441 : ℝ) / 1250000) ((390441 : ℝ) / 1250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((8969597 : ℝ) / 6250000) ((28702923 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_1160.1 cov_log_1161.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((148537 : ℝ) / 160000) ((46510097 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((1640441 : ℝ) / 1250000))
  have h24 : RB z24 ((5436431 : ℝ) / 20000000) ((6795539 : ℝ) / 25000000) := rb_log (show RB ((1640441 : ℝ) / 1250000) ((1640441 : ℝ) / 1250000) ((1640441 : ℝ) / 1250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1162.1 cov_log_1162.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((65653469 : ℝ) / 100000000) ((65838039 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((3266701 : ℝ) / 5000000) ((65402437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1155.1 cov_log_1156.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((31379 : ℝ) / 12500000) ((504019 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((19511 : ℝ) / 50000000) ((40413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((65779261 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((131518109 : ℝ) / 100000000) ((263039 : ℝ) / 200000) := rb_widen (rb_sub (show RB ((65779261 : ℝ) / 50000000) ((65779261 : ℝ) / 50000000) ((65779261 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((15779261 : ℝ) / 50000000))
  have h30 : RB z30 ((208371781 : ℝ) / 50000000) ((416747971 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((15779261 : ℝ) / 50000000) ((15779261 : ℝ) / 50000000) ((15779261 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((17841261 : ℝ) / 12500000) ((142731149 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1163.1 cov_log_1164.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((4616441 : ℝ) / 5000000) ((92512383 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((65779261 : ℝ) / 50000000))
  have h33 : RB z33 ((85713 : ℝ) / 312500) ((27428161 : ℝ) / 100000000) := rb_log (show RB ((65779261 : ℝ) / 50000000) ((65779261 : ℝ) / 50000000) ((65779261 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1165.1 cov_log_1165.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((64900659 : ℝ) / 100000000) ((65084223 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((3266701 : ℝ) / 5000000) ((65402437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1155.1 cov_log_1156.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-250889 : ℝ) / 50000000) ((-249797 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((1248811 : ℝ) / 3125000)) ((-127111 : ℝ) / 100000000) ((-4151 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((5075569 : ℝ) / 12500000)) ((10133 : ℝ) / 100000000) ((4051 : ℝ) / 3125000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((1640441 : ℝ) / 1250000)) ((31379 : ℝ) / 12500000) ((504019 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((65779261 : ℝ) / 50000000)) ((-250889 : ℝ) / 50000000) ((-249797 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_64 {k A q d vp vm : ℝ}
    (hk : RB k ((2931 : ℝ) / 1600) ((1179 : ℝ) / 640))
    (hA : RB A ((2931 : ℝ) / 4531) ((1179 : ℝ) / 1819))
    (hq : RB q ((1975399 : ℝ) / 100000000) ((125643 : ℝ) / 6250000))
    (hd : RB d ((96097491 : ℝ) / 50000000) ((192326517 : ℝ) / 100000000))
    (hp : RB vp ((1248811 : ℝ) / 3125000) ((5075569 : ℝ) / 12500000))
    (hm : RB vm ((1640441 : ℝ) / 1250000) ((65779261 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((19511 : ℝ) / 50000000) ((40413 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99959587 : ℝ) / 100000000) ((49980489 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((16165391 : ℝ) / 25000000) ((64790541 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((48051 : ℝ) / 50000000) ((101129 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99898871 : ℝ) / 100000000) ((49951949 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((7424431 : ℝ) / 12500000) ((1876189 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((59335381 : ℝ) / 100000000) ((59980351 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((107804577 : ℝ) / 100000000) ((109193773 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((7804577 : ℝ) / 100000000) ((9193773 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99959587 : ℝ) / 100000000) ((49980489 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((16165391 : ℝ) / 25000000) ((64790541 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((29661 : ℝ) / 100000000) ((6159 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19993841 : ℝ) / 20000000) ((99970339 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((390441 : ℝ) / 1250000) ((15779261 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((31225661 : ℝ) / 100000000) ((15774581 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((204954933 : ℝ) / 100000000) ((25936417 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((304954933 : ℝ) / 100000000) ((38436417 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((271923181 : ℝ) / 25000000) ((1281299423 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((32521241 : ℝ) / 100000000) ((32791731 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2931 : ℝ) / 800) ((1179 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((904671 : ℝ) / 12500000) ((1481331 : ℝ) / 20000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101975399 : ℝ) / 100000000) ((6375643 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((7094743 : ℝ) / 100000000) ((7263179 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((107094743 : ℝ) / 100000000) ((107263179 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((11328841 : ℝ) / 12500000) ((9159657 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((174187711 : ℝ) / 100000000) ((176164493 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52444179 : ℝ) / 100000000) ((53418749 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((73049 : ℝ) / 100000000) ((3853 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4996147 : ℝ) / 5000000) ((99926951 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((174053481 : ℝ) / 100000000) ((176035807 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((96097491 : ℝ) / 25000000) ((192326517 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1518647 : ℝ) / 20000000) ((3866317 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4531 : ℝ) / 1600) ((1819 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((10436 : ℝ) / 390625) ((2730571 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((4864969 : ℝ) / 100000000) ((2515253 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((104864969 : ℝ) / 100000000) ((52515253 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1140608637 : ℝ) / 100000000) ((336438817 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((46923 : ℝ) / 3125000) ((76591 : ℝ) / 5000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((3171923 : ℝ) / 3125000) ((5076591 : ℝ) / 5000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33009559 : ℝ) / 100000000) ((16647021 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((293404549 : ℝ) / 25000000) ((137904931 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((31354571 : ℝ) / 100000000) ((37655921 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4531 : ℝ) / 1600) ((1819 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((107094743 : ℝ) / 50000000) ((107263179 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((224042793 : ℝ) / 20000000) ((657045577 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2399380533 : ℝ) / 100000000) ((1409535947 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1255677 : ℝ) / 12500000) ((5922753 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-229805381 : ℝ) / 100000000) ((-106661081 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1166.1 cov_log_1167.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((3796617 : ℝ) / 100000000) ((3866317 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-327105983 : ℝ) / 100000000) ((-16264339 : ℝ) / 5000000) := rb_log h49 (by norm_num) cov_log_1168.1 cov_log_1169.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((3266701 : ℝ) / 5000000) ((65402437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1155.1 cov_log_1156.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((119683757 : ℝ) / 100000000) ((3765111 : ℝ) / 3125000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-103711113 : ℝ) / 50000000) ((-51200807 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((185181 : ℝ) / 2500000) ((9389567 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((393417 : ℝ) / 2000000) ((14973203 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-11734461 : ℝ) / 6250000) ((-87428411 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((107094743 : ℝ) / 100000000) ((107263179 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-229805381 : ℝ) / 100000000) ((-106661081 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-11734461 : ℝ) / 6250000) ((-87428411 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((147 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((4864969 : ℝ) / 100000000) ((2515253 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((33 : ℝ) / 20) := by
    have hu : (1 + q / vp) / 2 ≤ ((52515253 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((147 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((33 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-49623013 : ℝ) / 25000000) ≤ formC0 k A q vp vm + hfun ((147 : ℝ) / 50) + hfun ((33 : ℝ) / 20) := by
    linarith [hc0.1, cov_h_22, cov_h_17]
  have hP : ((2048467 : ℝ) / 400000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((87428411 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((87428411 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((3020787 : ℝ) / 5000000) ≤ EP1038.Arc.sinc ((33 : ℝ) / 20) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((317 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1287 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1287 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1307 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1307 : ℝ) / 500)) (lo := ((1287 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1327 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1327 : ℝ) / 500)) (lo := ((1307 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1347 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1347 : ℝ) / 500)) (lo := ((1327 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1367 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1367 : ℝ) / 500)) (lo := ((1347 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1387 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1387 : ℝ) / 500)) (lo := ((1367 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1407 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1407 : ℝ) / 500)) (lo := ((1387 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1427 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1427 : ℝ) / 500)) (lo := ((1407 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1447 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1447 : ℝ) / 500)) (lo := ((1427 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1467 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1467 : ℝ) / 500)) (lo := ((1447 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((147 : ℝ) / 50)) (lo := ((1467 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_64 {k : ℝ} (hk : RB k ((2931 : ℝ) / 1600) ((1179 : ℝ) / 640)) :
    RB (k / (k + 1)) ((2931 : ℝ) / 4531) ((1179 : ℝ) / 1819) ∧
    RB (qa (r1A k)) ((1975399 : ℝ) / 100000000) ((125643 : ℝ) / 6250000) ∧ RB (D0a (r1A k)) ((96097491 : ℝ) / 50000000) ((192326517 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2931 : ℝ) / 6400) ((1439209 : ℝ) / 3125000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((5767041 : ℝ) / 3125000) ((59137 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((27169491 : ℝ) / 20000000) ((67971157 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((277268811 : ℝ) / 100000000) ((277363671 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((27726881 : ℝ) / 20000000) ((34670459 : ℝ) / 25000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((96097491 : ℝ) / 50000000) ((192326517 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4863 : ℝ) / 32000) ((482959 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1899609 : ℝ) / 50000000) ((482959 : ℝ) / 12500000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1975399 : ℝ) / 100000000) ((125643 : ℝ) / 6250000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((96097491 : ℝ) / 50000000) ((192326517 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1975399 : ℝ) / 100000000) ((125643 : ℝ) / 6250000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2931 : ℝ) / 4531) ((1179 : ℝ) / 1819) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_64 {k : ℝ} (hk : RB k ((2931 : ℝ) / 1600) ((1179 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_64 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_64 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((1248811 : ℝ) / 3125000)) (ph := ((5075569 : ℝ) / 12500000)) (ml := ((1640441 : ℝ) / 1250000)) (mh := ((65779261 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_64 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
