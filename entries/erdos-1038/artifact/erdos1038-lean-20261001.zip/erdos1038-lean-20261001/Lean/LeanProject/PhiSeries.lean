import LeanProject.PhiEndpoint

/-!
# EP-1038: `φ > 0` on `(0, U]` (proof.md Lemma 6.4 via Remark 6.4′) and the two-atom branch

`φ(u) = log(P+u)log(P-u) - log(m+u)log(m-u)`, `P = √2 + 1`, `m = √2 - 1 = 1/P`, `U = 7/4 - √2`.

* `A_hasSum`: `log(1+t)·log(1-t) = ∑_k T(2k)/(k+1) · t^(2k+2)` for `|t| < 1` (Cauchy product of
  the two logarithm series; coefficient identity `(n+2)·c n = (1 + (-1)^n)·T n` by reflection).
* `phi_hasSum`: `φ(u) = ∑_k E k · u^(2k+2)` for `0 ≤ u < m`.
* `E_neg`: `E k < 0` for `k ≥ 1`, since `-T(2k) = s_{k+1} ≤ 5/6 < log(1+√2)` (`T_bound`, `L_gt`).
* `phi_pos`: hence `φ(u)·U² ≥ φ(U)·u² > 0` for `0 < u ≤ U`, using `phi_three_quarters` (φ(U) > 0).
* `hphi_of_mem`, `two_atom_branch`: the scalar inequality of Lemma 6.4 for every
  `a ∈ (√2 - 1, 3/4]`, and with `two_atom_of_phi` the whole two-atom branch of Lemmas 6.3–6.4.

Not formalised here: the reduction `f ↦ g` of Lemma 6.3 and the arcsine branch (Lemma 6.6).
-/
open Real Finset

namespace EP1038.PhiSeries

/-- `T n = ∑_{i ≤ n} (-1)^(i+1)/(i+1)` (so `-T (2k) = 1 - 1/2 + ⋯ + 1/(2k+1) = s_{k+1}`). -/
noncomputable def T (n : ℕ) : ℝ := ∑ i ∈ range (n + 1), (-1 : ℝ) ^ (i + 1) / ((i : ℝ) + 1)

/-- The Cauchy coefficient of `log(1+t)·log(1-t)` at `t^(n+2)`. -/
noncomputable def c (n : ℕ) : ℝ :=
  ∑ k ∈ range (n + 1), (-1 : ℝ) ^ (k + 1) / (((k : ℝ) + 1) * (((n - k : ℕ) : ℝ) + 1))

theorem neg_one_pow_sub {n j : ℕ} (h : j ≤ n) :
    (-1 : ℝ) ^ (n - j + 1) = (-1) ^ n * (-1) ^ (j + 1) := by
  obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_le h
  rw [Nat.add_sub_cancel_left]
  have hsq : ((-1 : ℝ) ^ j) ^ 2 = 1 := by
    rw [← pow_mul, mul_comm, pow_mul, neg_one_sq, one_pow]
  calc (-1 : ℝ) ^ (d + 1) = (-1) ^ (d + 1) * ((-1 : ℝ) ^ j) ^ 2 := by rw [hsq, mul_one]
    _ = (-1) ^ (j + d) * (-1) ^ (j + 1) := by ring

/-- Coefficient identity: `(n+2)·c n = (1 + (-1)^n)·T n`. -/
theorem c_mul (n : ℕ) : ((n : ℝ) + 2) * c n = (1 + (-1) ^ n) * T n := by
  have split : ∀ k ∈ range (n + 1),
      ((n : ℝ) + 2) * ((-1 : ℝ) ^ (k + 1) / (((k : ℝ) + 1) * (((n - k : ℕ) : ℝ) + 1))) =
        (-1 : ℝ) ^ (k + 1) / ((k : ℝ) + 1) + (-1 : ℝ) ^ (k + 1) / (((n - k : ℕ) : ℝ) + 1) := by
    intro k hk
    have hkn : k ≤ n := Nat.lt_succ_iff.mp (mem_range.mp hk)
    have hcast : (((n - k : ℕ) : ℝ)) = (n : ℝ) - k := by rw [Nat.cast_sub hkn]
    rw [hcast]
    have h1 : (0 : ℝ) < (k : ℝ) + 1 := by positivity
    have h2 : (0 : ℝ) < (n : ℝ) - k + 1 := by
      have : (k : ℝ) ≤ n := by exact_mod_cast hkn
      linarith
    field_simp
    ring
  -- the reflected sum
  have hrefl : ∑ k ∈ range (n + 1), (-1 : ℝ) ^ (k + 1) / (((n - k : ℕ) : ℝ) + 1) =
      (-1) ^ n * T n := by
    set f : ℕ → ℝ := fun j => (-1 : ℝ) ^ (n - j + 1) / ((j : ℝ) + 1) with hf
    have h := sum_range_reflect f (n + 1)
    simp only [Nat.add_sub_cancel] at h
    have step1 : (-1 : ℝ) ^ n * T n = ∑ i ∈ range (n + 1), f i := by
      rw [T, mul_sum]
      apply sum_congr rfl
      intro i hi
      have hin : i ≤ n := Nat.lt_succ_iff.mp (mem_range.mp hi)
      change _ = (-1 : ℝ) ^ (n - i + 1) / ((i : ℝ) + 1)
      rw [neg_one_pow_sub hin, mul_div_assoc]
    rw [step1, ← h]
    apply sum_congr rfl
    intro k hk
    have hkn : k ≤ n := Nat.lt_succ_iff.mp (mem_range.mp hk)
    change _ = (-1 : ℝ) ^ (n - (n - k) + 1) / (((n - k : ℕ) : ℝ) + 1)
    rw [Nat.sub_sub_self hkn]
  rw [c, mul_sum, sum_congr rfl split, sum_add_distrib, hrefl, T]
  ring

/-- `c n = 0` for odd `n`. -/
theorem c_odd {n : ℕ} (hn : Odd n) : c n = 0 := by
  have h := c_mul n
  rw [hn.neg_one_pow, add_neg_cancel, zero_mul] at h
  have : ((n : ℝ) + 2) ≠ 0 := by positivity
  exact (mul_eq_zero.mp h).resolve_left this

/-- `c (2k) = T (2k) / (k+1)`. -/
theorem c_even (k : ℕ) : c (2 * k) = T (2 * k) / ((k : ℝ) + 1) := by
  have h := c_mul (2 * k)
  rw [(even_two_mul k).neg_one_pow] at h
  have hk : (0 : ℝ) < (k : ℝ) + 1 := by positivity
  rw [eq_div_iff hk.ne']
  push_cast at h
  linarith

/-- Cauchy product: `log(1+t)·log(1-t) = ∑ c n t^(n+2)` for `|t| < 1`. -/
theorem A_hasSum_n {t : ℝ} (ht : |t| < 1) :
    HasSum (fun n => c n * t ^ (n + 2)) (Real.log (1 + t) * Real.log (1 - t)) := by
  set F : ℕ → ℝ := fun k => (-t) ^ (k + 1) / ((k : ℝ) + 1) with hF
  set G : ℕ → ℝ := fun k => t ^ (k + 1) / ((k : ℝ) + 1) with hG
  have hsF : HasSum F (-Real.log (1 - -t)) :=
    Real.hasSum_pow_div_log_of_abs_lt_one (by rwa [abs_neg])
  have hsG : HasSum G (-Real.log (1 - t)) := Real.hasSum_pow_div_log_of_abs_lt_one ht
  have hN : HasSum (fun k : ℕ => |t| ^ (k + 1) / ((k : ℝ) + 1)) (-Real.log (1 - |t|)) :=
    Real.hasSum_pow_div_log_of_abs_lt_one (by rwa [abs_abs])
  have hnF : Summable fun k => ‖F k‖ := hN.summable.congr fun k => by
    rw [hF, Real.norm_eq_abs, abs_div, abs_pow, abs_neg,
      abs_of_pos (by positivity : (0 : ℝ) < (k : ℝ) + 1)]
  have hnG : Summable fun k => ‖G k‖ := hN.summable.congr fun k => by
    rw [hG, Real.norm_eq_abs, abs_div, abs_pow,
      abs_of_pos (by positivity : (0 : ℝ) < (k : ℝ) + 1)]
  have h := hasSum_sum_range_mul_of_summable_norm hnF hnG
  rw [hsF.tsum_eq, hsG.tsum_eq, sub_neg_eq_add] at h
  have key : (fun n => c n * t ^ (n + 2)) = fun n => ∑ k ∈ range (n + 1), F k * G (n - k) := by
    funext n
    rw [c, sum_mul]
    apply sum_congr rfl
    intro k hk
    have hkn : k ≤ n := Nat.lt_succ_iff.mp (mem_range.mp hk)
    have hp : t ^ (k + 1) * t ^ (n - k + 1) = t ^ (n + 2) := by
      rw [← pow_add]; congr 1; omega
    rw [← hp, hF, hG]
    simp only
    rw [neg_pow t (k + 1)]
    simp only [div_eq_mul_inv, mul_inv]
    ring
  rw [key]
  convert h using 1
  ring

/-- Even form: `log(1+t)·log(1-t) = ∑_k T(2k)/(k+1) · t^(2k+2)` for `|t| < 1`. -/
theorem A_hasSum {t : ℝ} (ht : |t| < 1) :
    HasSum (fun k : ℕ => T (2 * k) / ((k : ℝ) + 1) * t ^ (2 * k + 2))
      (Real.log (1 + t) * Real.log (1 - t)) := by
  have h := A_hasSum_n ht
  have hinj : Function.Injective (fun k : ℕ => 2 * k) := fun a b hab => by
    simp only at hab; omega
  rw [← hinj.hasSum_iff] at h
  · convert h using 1
    funext k
    simp only [Function.comp]
    rw [c_even]
  · intro x hx
    have hodd : Odd x := by
      rcases Nat.even_or_odd x with he | ho
      · exfalso; obtain ⟨r, hr⟩ := he; exact hx ⟨r, by simp only; omega⟩
      · exact ho
    rw [c_odd hodd, zero_mul]

theorem T_step (k : ℕ) :
    T (2 * (k + 1)) = T (2 * k) + 1 / (2 * (k : ℝ) + 2) - 1 / (2 * (k : ℝ) + 3) := by
  have e : 2 * (k + 1) + 1 = 2 * k + 1 + 1 + 1 := by ring
  rw [T, T, e, sum_range_succ, sum_range_succ]
  have p1 : (-1 : ℝ) ^ (2 * k + 1 + 1) = 1 := by
    rw [show 2 * k + 1 + 1 = 2 * (k + 1) by ring, pow_mul]; norm_num
  have p2 : (-1 : ℝ) ^ (2 * k + 1 + 1 + 1) = -1 := by
    rw [show 2 * k + 1 + 1 + 1 = 2 * (k + 1) + 1 by ring, pow_succ, pow_mul]; norm_num
  rw [p1, p2]
  push_cast
  ring

/-- `s_{k+1} = -T (2k) ≤ 5/6` for `k ≥ 1`. -/
theorem T_bound (k : ℕ) (hk : 1 ≤ k) : -T (2 * k) ≤ 5 / 6 := by
  induction k, hk using Nat.le_induction with
  | base => norm_num [T, sum_range_succ]
  | succ k hk ih =>
    rw [T_step]
    have : 1 / (2 * (k : ℝ) + 3) ≤ 1 / (2 * (k : ℝ) + 2) :=
      one_div_le_one_div_of_le (by positivity) (by linarith)
    linarith

/-- `L = log(1 + √2) > 5/6`. -/
theorem L_gt : 5 / 6 < Real.log (√2 + 1) := by
  have hs : (1.41 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have h1 : Real.log 2.41 ≤ Real.log (√2 + 1) := Real.log_le_log (by norm_num) (by linarith)
  have h2 : Real.log 2.41 = Real.log 2 + Real.log 1.205 := by
    rw [← Real.log_mul (by norm_num) (by norm_num)]; norm_num
  have h3 : Real.log (1.205 : ℝ)⁻¹ ≤ (1.205 : ℝ)⁻¹ - 1 := Real.log_le_sub_one_of_pos (by norm_num)
  rw [Real.log_inv] at h3
  have l2 := Real.log_two_gt_d9
  norm_num at h3
  linarith

/-- The series coefficient of `φ(u)` at `u^(2k+2)`. -/
noncomputable def E (k : ℕ) : ℝ :=
  (-Real.log (√2 + 1) * ((1 / (√2 + 1)) ^ (2 * k + 2) + (√2 + 1) ^ (2 * k + 2)) +
    T (2 * k) * ((1 / (√2 + 1)) ^ (2 * k + 2) - (√2 + 1) ^ (2 * k + 2))) / ((k : ℝ) + 1)

/-- `E k < 0` for `k ≥ 1` (proof.md Remark 6.4′). -/
theorem E_neg (k : ℕ) (hk : 1 ≤ k) : E k < 0 := by
  have hs1 : (1 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  set P := √2 + 1 with hP
  have hP1 : 1 ≤ P := by linarith
  have hq : 0 < (1 / P) ^ (2 * k + 2) := by positivity
  have hqQ : (1 / P) ^ (2 * k + 2) ≤ P ^ (2 * k + 2) := by
    apply pow_le_pow_left₀ (by positivity)
    calc 1 / P ≤ 1 := by rw [div_le_one (by linarith)]; exact hP1
      _ ≤ P := hP1
  have hT := T_bound k hk
  have hL := L_gt
  have hk1 : (0 : ℝ) < (k : ℝ) + 1 := by positivity
  rw [E, div_neg_iff]
  right
  refine ⟨?_, hk1⟩
  nlinarith

/-- Decomposition of `φ(u) = log(P+u)log(P-u) - log(m+u)log(m-u)`, `P = √2+1`, `m = √2-1`. -/
theorem phi_decomp {u : ℝ} (hu0 : 0 ≤ u) (hum : u < √2 - 1) :
    Real.log (√2 + 1 + u) * Real.log (√2 + 1 - u) - Real.log (√2 - 1 + u) * Real.log (√2 - 1 - u) =
      Real.log (√2 + 1) * (Real.log (1 - (u / (√2 + 1)) ^ 2) + Real.log (1 - (u * (√2 + 1)) ^ 2)) +
        Real.log (1 + u / (√2 + 1)) * Real.log (1 - u / (√2 + 1)) -
        Real.log (1 + u * (√2 + 1)) * Real.log (1 - u * (√2 + 1)) := by
  have hs1 : (1 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have hss : √2 * √2 = 2 := Real.mul_self_sqrt (by norm_num)
  set P := √2 + 1 with hP
  set m := √2 - 1 with hm
  have hPpos : 0 < P := by linarith
  have hmpos : 0 < m := by linarith
  have hPm : P * m = 1 := by rw [hP, hm]; nlinarith
  have huP : u * P < 1 := by nlinarith
  have hup : u / P < 1 := by rw [div_lt_one hPpos]; linarith
  have a1 : 0 < 1 + u / P := by positivity
  have a2 : 0 < 1 - u / P := by linarith
  have a3 : 0 < 1 + u * P := by positivity
  have a4 : 0 < 1 - u * P := by linarith
  have e1 : Real.log (P + u) = Real.log P + Real.log (1 + u / P) := by
    rw [← Real.log_mul hPpos.ne' a1.ne']; congr 1; field_simp
  have e2 : Real.log (P - u) = Real.log P + Real.log (1 - u / P) := by
    rw [← Real.log_mul hPpos.ne' a2.ne']; congr 1; field_simp
  have hlogm : Real.log m = -Real.log P := by
    rw [show m = P⁻¹ by field_simp; linarith [hPm], Real.log_inv]
  have e3 : Real.log (m + u) = -Real.log P + Real.log (1 + u * P) := by
    rw [← hlogm, ← Real.log_mul hmpos.ne' a3.ne']; congr 1; linear_combination (-u) * hPm
  have e4 : Real.log (m - u) = -Real.log P + Real.log (1 - u * P) := by
    rw [← hlogm, ← Real.log_mul hmpos.ne' a4.ne']; congr 1; linear_combination u * hPm
  have e5 : Real.log (1 - (u / P) ^ 2) = Real.log (1 + u / P) + Real.log (1 - u / P) := by
    rw [← Real.log_mul a1.ne' a2.ne']; congr 1; ring
  have e6 : Real.log (1 - (u * P) ^ 2) = Real.log (1 + u * P) + Real.log (1 - u * P) := by
    rw [← Real.log_mul a3.ne' a4.ne']; congr 1; ring
  rw [e1, e2, e3, e4, e5, e6]
  ring

/-- `φ(u) = ∑_k E k · u^(2k+2)` for `0 ≤ u < √2 - 1`. -/
theorem phi_hasSum {u : ℝ} (hu0 : 0 ≤ u) (hum : u < √2 - 1) :
    HasSum (fun k : ℕ => E k * u ^ (2 * k + 2))
      (Real.log (√2 + 1 + u) * Real.log (√2 + 1 - u) -
        Real.log (√2 - 1 + u) * Real.log (√2 - 1 - u)) := by
  have hs1 : (1 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have hss : √2 * √2 = 2 := Real.mul_self_sqrt (by norm_num)
  rw [phi_decomp hu0 hum]
  set P := √2 + 1 with hP
  have hPpos : 0 < P := by linarith
  have hPm : P * (√2 - 1) = 1 := by rw [hP]; nlinarith
  have huP : u * P < 1 := by nlinarith
  have hup : u / P < 1 := by rw [div_lt_one hPpos]; linarith
  have t1 : |u / P| < 1 := by rw [abs_of_nonneg (by positivity)]; exact hup
  have t2 : |u * P| < 1 := by rw [abs_of_nonneg (by positivity)]; exact huP
  have y1 : |(u / P) ^ 2| < 1 := by
    rw [abs_pow]; exact pow_lt_one₀ (abs_nonneg _) t1 (by norm_num)
  have y2 : |(u * P) ^ 2| < 1 := by
    rw [abs_pow]; exact pow_lt_one₀ (abs_nonneg _) t2 (by norm_num)
  have S1 := (Real.hasSum_pow_div_log_of_abs_lt_one y1).mul_left (-Real.log P)
  have S2 := (Real.hasSum_pow_div_log_of_abs_lt_one y2).mul_left (-Real.log P)
  have S3 := A_hasSum t1
  have S4 := A_hasSum t2
  have S := ((S1.add S2).add S3).sub S4
  convert S using 1
  · funext k
    simp only [E]
    rw [← hP, ← pow_mul, ← pow_mul, show 2 * (k + 1) = 2 * k + 2 by ring]
    have hk1 : (k : ℝ) + 1 ≠ 0 := by positivity
    have hPn : P ^ (2 * k + 2) ≠ 0 := by positivity
    rw [div_pow, div_pow, mul_pow, one_pow]
    field_simp
    ring
  · ring

/-- **`φ > 0` on `(0, U]`**, `U = 7/4 - √2`: `log(m+u)log(m-u) < log(P+u)log(P-u)`. -/
theorem phi_pos {u : ℝ} (hu0 : 0 < u) (huU : u ≤ 7 / 4 - √2) :
    Real.log (√2 - 1 + u) * Real.log (√2 - 1 - u) <
      Real.log (√2 + 1 + u) * Real.log (√2 + 1 - u) := by
  have hs1 : (1.375 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  set U := 7 / 4 - √2 with hU
  have hUm : U < √2 - 1 := by rw [hU]; linarith
  have hU0 : 0 < U := by linarith
  have hum : u < √2 - 1 := by linarith
  -- φ(U) > 0 from phi_three_quarters
  have hphiU : 0 < Real.log (√2 + 1 + U) * Real.log (√2 + 1 - U) -
      Real.log (√2 - 1 + U) * Real.log (√2 - 1 - U) := by
    have h := phi_three_quarters
    have r1 : √2 + 1 + U = 3 / 4 + 2 := by rw [hU]; ring
    have r2 : √2 + 1 - U = 2 * √2 - 3 / 4 := by rw [hU]; ring
    have r3 : √2 - 1 + U = 3 / 4 := by rw [hU]; ring
    have r4 : √2 - 1 - U = 2 * √2 - 3 / 4 - 2 := by rw [hU]; ring
    rw [r1, r2, r3, r4]
    linarith
  have hu := phi_hasSum hu0.le hum
  have hUs := phi_hasSum hU0.le hUm
  have hD := (hu.mul_right (U ^ 2)).sub (hUs.mul_right (u ^ 2))
  have hnn : 0 ≤ (Real.log (√2 + 1 + u) * Real.log (√2 + 1 - u) -
      Real.log (√2 - 1 + u) * Real.log (√2 - 1 - u)) * U ^ 2 -
      (Real.log (√2 + 1 + U) * Real.log (√2 + 1 - U) -
        Real.log (√2 - 1 + U) * Real.log (√2 - 1 - U)) * u ^ 2 := by
    apply hD.nonneg
    intro k
    rcases Nat.eq_zero_or_pos k with rfl | hk
    · simp only [mul_zero, zero_add]; ring_nf; exact le_refl _
    · have hE := E_neg k hk
      have hpow : u ^ (2 * k) ≤ U ^ (2 * k) := pow_le_pow_left₀ hu0.le huU _
      have hfac : u ^ (2 * k + 2) * U ^ 2 - U ^ (2 * k + 2) * u ^ 2 =
          u ^ 2 * U ^ 2 * (u ^ (2 * k) - U ^ (2 * k)) := by ring
      have hneg : u ^ (2 * k + 2) * U ^ 2 - U ^ (2 * k + 2) * u ^ 2 ≤ 0 := by
        rw [hfac]
        exact mul_nonpos_of_nonneg_of_nonpos (by positivity) (by linarith)
      calc (0 : ℝ) ≤ E k * (u ^ (2 * k + 2) * U ^ 2 - U ^ (2 * k + 2) * u ^ 2) :=
            mul_nonneg_of_nonpos_of_nonpos hE.le hneg
        _ = E k * u ^ (2 * k + 2) * U ^ 2 - E k * U ^ (2 * k + 2) * u ^ 2 := by ring
  have hu2 : 0 < u ^ 2 := by positivity
  have hU2 : 0 < U ^ 2 := by positivity
  have : 0 < (Real.log (√2 + 1 + u) * Real.log (√2 + 1 - u) -
      Real.log (√2 - 1 + u) * Real.log (√2 - 1 - u)) * U ^ 2 := by nlinarith
  have hφ := (pos_iff_pos_of_mul_pos this).mpr hU2
  linarith

end EP1038.PhiSeries

namespace EP1038

open MeasureTheory

/-- **Lemma 6.4's scalar inequality on its whole range**: for `a ∈ (√2 - 1, 3/4]`,
`log a · log(2√2 - a - 2) < log(a+2) · log(2√2 - a)`. -/
theorem hphi_of_mem {a : ℝ} (ha1 : √2 - 1 < a) (ha2 : a ≤ 3 / 4) :
    Real.log a * Real.log (2 * √2 - a - 2) < Real.log (a + 2) * Real.log (2 * √2 - a) := by
  have h := PhiSeries.phi_pos (u := a - (√2 - 1)) (by linarith) (by linarith)
  have r1 : √2 - 1 + (a - (√2 - 1)) = a := by ring
  have r2 : √2 - 1 - (a - (√2 - 1)) = 2 * √2 - a - 2 := by ring
  have r3 : √2 + 1 + (a - (√2 - 1)) = a + 2 := by ring
  have r4 : √2 + 1 - (a - (√2 - 1)) = 2 * √2 - a := by ring
  rwa [r1, r2, r3, r4] at h

/-- **The two-atom branch of the supremum argument (Lemmas 6.3–6.4), for every
`a ∈ (√2 - 1, 3/4]`**: the configuration of Lemma 6.3 (after the shift `g(x) = f(x - M)`,
`a = M - 1`, `B = 2√2`) is impossible. -/
theorem two_atom_branch {n : ℕ} (hn : 0 < n) (q : Fin n → ℝ) {a y : ℝ}
    (ha1 : √2 - 1 < a) (ha2 : a ≤ 3 / 4)
    (hq : ∀ j, q j ∈ Set.Icc a (a + 2)) (h0 : ∏ j, q j = 1)
    (hy : |∏ j, (y - q j)| ≤ 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤ volume (Set.Icc 0 y ∩ {x | |∏ j, (x - q j)| ≤ 1})) :
    False := by
  have hs1 : (1.41421 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have hs2 : √2 < 1.41422 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  exact two_atom_of_phi hn q (by linarith) (by linarith) (by linarith) (by linarith)
    (by linarith) (hphi_of_mem ha1 ha2) hq h0 hy hvol

end EP1038
