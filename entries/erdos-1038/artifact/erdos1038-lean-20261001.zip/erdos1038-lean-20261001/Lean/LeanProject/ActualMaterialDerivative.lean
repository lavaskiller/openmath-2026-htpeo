import LeanProject.MaterialDerivative
import LeanProject.JumpAdjointEquality

/-! Actual material derivatives at the interior points of the residual-root blocks. -/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset

namespace EP1038.Stage11
open EP1038.Arc AngleReference

/-- A locally constant bounded target has a bounded material fiber quotient.
The constant and punctured-distance lower bound are constructed explicitly. -/
theorem locally_constant_target_fiber_bound {T : ℝ → ℝ} {c r θ B ε : ℝ}
    (hr : 0 < r) (hθ : θ ∈ Ioo (0 : ℝ) π) (hB : 0 ≤ B)
    (hT : ∀ φ, |T φ| ≤ B) (hε : 0 < ε)
    (hlocal : ∀ φ, |φ - θ| < ε → T φ = T θ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ φ ∈ Ioc (0 : ℝ) π,
      |((T φ - position c r φ) - (T θ - position c r θ)) /
        (position c r φ - position c r θ)| ≤ C := by
  obtain ⟨b, hb, hchord⟩ := exists_cos_chord_lower hθ
  let d0 : ℝ := r * b * ε
  have hd0 : 0 < d0 := by dsimp [d0]; positivity
  refine ⟨2 * B / d0 + 1, by positivity, ?_⟩
  intro φ hφ
  by_cases hne : φ = θ
  · subst φ
    simp
    positivity
  have hD : position c r φ - position c r θ ≠ 0 :=
    sub_ne_zero.mpr (fun hh => hne ((EP1038.Stage12.position_strictMonoOn hr).injOn
      ⟨hφ.1.le, hφ.2⟩ ⟨hθ.1.le, hθ.2.le⟩ hh))
  have he : ((T φ - position c r φ) - (T θ - position c r θ)) /
      (position c r φ - position c r θ) =
        (T φ - T θ) / (position c r φ - position c r θ) - 1 := by
    field_simp [hD]
    ring
  rw [he]
  by_cases hnear : |φ - θ| < ε
  · rw [hlocal φ hnear]
    simp only [sub_self, zero_div, zero_sub, abs_neg, abs_one]
    have : 0 ≤ 2 * B / d0 := by positivity
    linarith
  have hd : d0 ≤ |position c r φ - position c r θ| := by
    have hgap := hchord φ ⟨hφ.1.le, hφ.2⟩
    have hab : ε ≤ |φ - θ| := le_of_not_gt hnear
    have hp : |position c r φ - position c r θ| = r * |cos φ - cos θ| := by
      dsimp [position]
      rw [show (c - r * cos φ) - (c - r * cos θ) = -(r * (cos φ - cos θ)) by ring,
        abs_neg, abs_mul, abs_of_pos hr]
    rw [hp]
    dsimp [d0]
    simpa only [mul_assoc] using mul_le_mul_of_nonneg_left
      ((mul_le_mul_of_nonneg_left hab hb.le).trans hgap) hr.le
  have habs : |T φ - T θ| ≤ |T φ| + |T θ| := by
    simpa only [sub_zero, zero_sub, abs_neg] using abs_sub_le (T φ) (0 : ℝ) (T θ)
  have hnum : |T φ - T θ| ≤ 2 * B := habs.trans (by linarith [hT φ, hT θ])
  have hquot : |(T φ - T θ) / (position c r φ - position c r θ)| ≤ 2 * B / d0 := by
    rw [abs_div]
    exact (div_le_div_of_nonneg_right hnum (abs_nonneg _)).trans
      (div_le_div_of_nonneg_left (by positivity) hd0 hd)
  calc
    _ ≤ |(T φ - T θ) / (position c r φ - position c r θ)| + |(1 : ℝ)| := by
      simpa only [sub_zero, zero_sub, abs_neg] using
        abs_sub_le ((T φ - T θ) / (position c r φ - position c r θ)) (0 : ℝ) 1
    _ ≤ _ := by rw [abs_one]; linarith

end EP1038.Stage11

namespace EP1038.Stage12
open EP1038.Arc EP1038.Stage11 EP1038.NormalForm NormalData AngleReference

theorem residual_target_bounded {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ φ, |A.angularTarget (a.residualQuantile hres) φ| ≤ B := by
  classical
  refine ⟨∑ v ∈ a.residualValues, |v - a.roots a.main|,
    Finset.sum_nonneg (fun (v : ℝ) _ => abs_nonneg (v - a.roots a.main)), ?_⟩
  intro φ
  obtain ⟨v, hv, he⟩ := residualQuantile_original a hres (A.cdf (foldedAngle φ))
  unfold angularTarget
  rw [he]
  exact Finset.single_le_sum (f := fun v => |v - a.roots a.main|)
    (fun _ _ => abs_nonneg _) hv

/-- No regularity or fiber-integrability hypothesis is supplied by the caller. -/
theorem residual_block_fiber_bound {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v θ : ℝ}
    (hθ : θ ∈ interior (blockSet R.angles a hres v)) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ φ ∈ Ioc (0 : ℝ) π,
      |(R.angles.angularDrift R.c R.r (a.residualQuantile hres) φ -
        R.angles.angularDrift R.c R.r (a.residualQuantile hres) θ) /
          (position R.c R.r φ - position R.c R.r θ)| ≤ C := by
  have hi : θ ∈ Ioo (0 : ℝ) π := by
    have hh := (interior_mono (inter_subset_left : blockSet R.angles a hres v ⊆ Icc 0 π)) hθ
    simpa only [interior_Icc] using hh
  obtain ⟨B, hB, hbounded⟩ := residual_target_bounded R.angles a hres
  obtain ⟨ε, hε, hball⟩ := Metric.mem_nhds_iff.mp (mem_interior_iff_mem_nhds.mp hθ)
  apply locally_constant_target_fiber_bound R.radius_pos hi hB hbounded hε
  intro φ hφ
  have hm : φ ∈ blockSet R.angles a hres v := hball (by
    simpa only [Metric.mem_ball, Real.dist_eq] using hφ)
  exact hm.2.trans (interior_subset hθ).2.symm

/-- The actual potential has the stated material derivative at every block-interior point. -/
theorem residual_block_material_derivative {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) {v θ : ℝ}
    (hθ : θ ∈ interior (blockSet R.angles a hres v))
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    HasDerivAt (fun s => movingLogPotential R.angles.k R.angles.ρ R.c R.r
      (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) s θ)
      (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ) 0 := by
  obtain ⟨C, hC, hq⟩ := residual_block_fiber_bound R a hres hθ
  have hi := (interior_subset hθ).1
  apply hasDerivAt_movingLogPotential R.angles.k_pos.le R.angles.rho_pos.le
    R.angles.rho_lt_one R.angles.density_zero_nonneg R.radius_pos hi
    (lt_of_lt_of_le R.left_pos (position_bounds R.radius_pos.le).1).ne'
    (R.angles.angularDrift_measurable R.c R.r (measurable_residualQuantile a hres)) hC hq
  rw [refPosition_eq_dth R hzero]
  exact (log_distance_half_integrable (refD0_pos R) R.angles.rho_pos θ).mul_continuousOn
    (alpha_cont R.angles.k R.angles.ρ R.angles.rho_pos.le R.angles.rho_lt_one).continuousOn

theorem residual_block_material_integrable {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) {v θ : ℝ}
    (hθ : θ ∈ interior (blockSet R.angles a hres v)) :
    IntervalIntegrable (fun φ => materialKernel R.angles.k R.angles.ρ R.c R.r
      (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) (θ, φ)) volume 0 π := by
  obtain ⟨C, hC, hq⟩ := residual_block_fiber_bound R a hres hθ
  have hvm := R.angles.angularDrift_measurable R.c R.r (measurable_residualQuantile a hres)
  have hpm : Measurable (position R.c R.r) := by unfold position; fun_prop
  have hm : Measurable (fun φ => materialKernel R.angles.k R.angles.ρ R.c R.r
      (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) (θ, φ)) := by
    convert
      ((hvm.sub (measurable_const : Measurable (fun _ : ℝ =>
        R.angles.angularDrift R.c R.r (a.residualQuantile hres) θ))).div
          (hpm.sub (measurable_const : Measurable (fun _ : ℝ => position R.c R.r θ)))).mul
        (alpha_cont R.angles.k R.angles.ρ R.angles.rho_pos.le R.angles.rho_lt_one).measurable using 1
    funext φ
    rfl
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le]
  apply (integrable_const (C * (R.angles.k + 1))).mono' hm.aestronglyMeasurable
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with φ hφ
  rw [Real.norm_eq_abs, materialKernel, abs_mul]
  exact mul_le_mul (hq φ hφ)
    (alpha_bounds R.angles.k_pos.le R.angles.rho_pos.le R.angles.rho_lt_one
      R.angles.density_zero_nonneg φ).2 (abs_nonneg _) hC

/-- Fiber integrability holds at every actual interior block point, not just almost everywhere. -/
theorem residual_block_velocity_dq_integrable {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) {v θ : ℝ}
    (hθ : θ ∈ interior (blockSet R.angles a hres v)) :
    IntervalIntegrable (fun φ =>
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres) φ -
        R.angles.angularVelocity R.c R.r (a.residualQuantile hres) θ) /
          (cos θ - cos φ)) volume 0 π := by
  let drift := R.angles.angularDrift R.c R.r (a.residualQuantile hres)
  have hi := residual_block_material_integrable R a hres hθ
  have hα := (alpha_XLip R.angles.k_pos.le R.angles.rho_pos.le R.angles.rho_lt_one).dq_integrable
    (mul_nonneg R.angles.k_pos.le (poissonLip_nonneg R.angles.rho_pos.le R.angles.rho_lt_one)) θ
  have he : (fun φ =>
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres) φ -
        R.angles.angularVelocity R.c R.r (a.residualQuantile hres) θ) / (cos θ - cos φ)) =
      (fun φ => R.r * materialKernel R.angles.k R.angles.ρ R.c R.r drift (θ, φ) +
        drift θ * ((alpha R.angles.k R.angles.ρ φ - alpha R.angles.k R.angles.ρ θ) /
          (cos θ - cos φ))) := by
    funext φ
    change (alpha R.angles.k R.angles.ρ φ * drift φ - alpha R.angles.k R.angles.ρ θ * drift θ) /
      (cos θ - cos φ) = _
    dsimp [materialKernel, position]
    rw [show (R.c - R.r * cos φ) - (R.c - R.r * cos θ) = R.r * (cos θ - cos φ) by ring]
    by_cases hc : cos θ - cos φ = 0
    · simp [hc]
    · field_simp [hc, R.radius_pos.ne']
      ring
  rw [he]
  exact (hi.const_mul _).add (hα.const_mul _)

theorem residual_block_material_eq_HT {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) {v θ : ℝ}
    (hθ : θ ∈ interior (blockSet R.angles a hres v))
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    materialAngular R.angles.k R.angles.ρ R.c R.r
      (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ =
      HT (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) θ / R.r := by
  exact materialAngular_eq_HT R.radius_pos R.angles.k_pos.le R.angles.rho_pos
    R.angles.rho_lt_one hzero (interior_subset hθ).1
      (residual_block_velocity_dq_integrable R a hres hθ)

/-- The original mass-coordinate potential `WS(T_s, T_s(u))` has the actual material derivative. -/
theorem residual_block_WS_derivative {n : ℕ} (R : SeparatedReference)
    (a : NormalData n) (hres : 0 < a.residualCount) {v θ : ℝ}
    (hθ : θ ∈ interior (blockSet R.angles a hres v))
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    HasDerivAt (fun s => Stage10.WS R.angles.k
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s)
      (R.angles.deformedQuantile R.c R.r (a.residualQuantile hres) s (R.angles.cdf θ)))
      (materialAngular R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ) 0 := by
  apply (residual_block_material_derivative R a hres hθ hzero).congr_of_eventuallyEq
  have hp : 0 < position R.c R.r θ :=
    lt_of_lt_of_le R.left_pos (position_bounds R.radius_pos.le).1
  have hc : ContinuousAt (fun s : ℝ => position R.c R.r θ + s *
      R.angles.angularDrift R.c R.r (a.residualQuantile hres) θ) 0 := by fun_prop
  have he : ∀ᶠ s : ℝ in 𝓝 0, 0 < position R.c R.r θ + s *
      R.angles.angularDrift R.c R.r (a.residualQuantile hres) θ := by
    exact hc.eventually (Ioi_mem_nhds (by simpa only [zero_mul, add_zero] using hp))
  filter_upwards [he] with s hs
  exact (R.angles.movingLogPotential_eq_WS R.c R.r (a.residualQuantile hres) s
    (interior_subset hθ).1 hs).symm

end EP1038.Stage12
