import LeanProject.ParameterCoverage

/-! Sound arithmetic and finite scalar certificates for the complete parameter cover. -/
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

theorem rb_mul_signed {x y l u a b lo hi : ℝ} (hx : RB x l u) (hy : RB y a b)
    (ha : 0 ≤ a) (hl1 : lo ≤ l * a) (hl2 : lo ≤ l * b)
    (hu1 : u * a ≤ hi) (hu2 : u * b ≤ hi) : RB (x * y) lo hi := by
  have hy0 : 0 ≤ y := ha.trans hy.1
  constructor
  · have hxy := mul_le_mul_of_nonneg_right hx.1 hy0
    rcases le_or_gt 0 l with hl | hl
    · exact hl1.trans ((mul_le_mul_of_nonneg_left hy.1 hl).trans hxy)
    · exact hl2.trans ((mul_le_mul_of_nonpos_left hy.2 hl.le).trans hxy)
  · have hxy := mul_le_mul_of_nonneg_right hx.2 hy0
    rcases le_or_gt 0 u with hu | hu
    · exact (hxy.trans (mul_le_mul_of_nonneg_left hy.2 hu)).trans hu2
    · exact (hxy.trans (mul_le_mul_of_nonpos_left hy.1 hu.le)).trans hu1

theorem rb_div_signed {x y l u a b lo hi : ℝ} (hx : RB x l u) (hy : RB y a b)
    (ha : 0 < a) (hl1 : lo ≤ l / b) (hl2 : lo ≤ l / a)
    (hu1 : u / b ≤ hi) (hu2 : u / a ≤ hi) : RB (x / y) lo hi := by
  have hb : 0 < b := ha.trans_le (hy.1.trans hy.2)
  have hr := rb_div (show RB (1 : ℝ) 1 1 from ⟨le_rfl, le_rfl⟩) hy zero_le_one ha
  have h1 : lo ≤ l * (1 / b) := by simpa only [div_eq_mul_inv, one_div, one_mul] using hl1
  have h2 : lo ≤ l * (1 / a) := by simpa only [div_eq_mul_inv, one_div, one_mul] using hl2
  have h3 : u * (1 / b) ≤ hi := by simpa only [div_eq_mul_inv, one_div, one_mul] using hu1
  have h4 : u * (1 / a) ≤ hi := by simpa only [div_eq_mul_inv, one_div, one_mul] using hu2
  simpa only [div_eq_mul_inv, one_mul, one_div] using
    rb_mul_signed hx hr (one_div_nonneg.mpr hb.le) h1 h2 h3 h4

theorem rb_sqrt {x l u lo hi : ℝ} (hx : RB x l u) (hx0 : 0 ≤ x)
    (hlo : 0 ≤ lo) (hhi : 0 ≤ hi) (hl : lo ^ 2 ≤ l) (hu : u ≤ hi ^ 2) :
    RB (Real.sqrt x) lo hi := by
  have hs := Real.sqrt_nonneg x
  have he := Real.sq_sqrt hx0
  constructor <;> nlinarith [hx.1, hx.2]

theorem rb_log {x l u lo hi : ℝ} (hx : RB x l u) (hl : 0 < l)
    (hlo : lo ≤ Real.log l) (hhi : Real.log u ≤ hi) : RB (Real.log x) lo hi :=
  ⟨hlo.trans (Real.log_le_log hl hx.1), (Real.log_le_log (hl.trans_le hx.1) hx.2).trans hhi⟩

theorem rb_qa_from_D0 {a dl du ql qu : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hd : RB (D0a a) dl du) (hdl : 0 < dl)
    (hl : ql * du ≤ (2 - a) / 4) (hu : (2 - a) / 4 ≤ qu * dl)
    (hql : 0 ≤ ql) (hqu : 0 ≤ qu) : RB (qa a) ql qu := by
  have hm := D0a_mul_qa ha
  have hq := (qa_pos ha ha2).le
  have hdlp := mul_le_mul_of_nonneg_right hd.1 hq
  have hdup := mul_le_mul_of_nonneg_right hd.2 hq
  constructor
  · by_contra h
    have hh : qa a < ql := lt_of_not_ge h
    have hp := mul_lt_mul_of_pos_right hh (hdl.trans_le (hd.1.trans hd.2))
    nlinarith
  · by_contra h
    have hh : qu < qa a := lt_of_not_ge h
    have hp := mul_lt_mul_of_pos_right hh hdl
    nlinarith

theorem sinc_upper_from_lower {Q l : ℝ} (hl : 0 < l) (hQl : l ≤ Q) (hQπ : Q ≤ π) :
    EP1038.Arc.sinc Q ≤ (22 / 7 - l) / l := by
  have hQ := hl.trans_le hQl
  have hs := scalar_sinc_upper hQ hQπ
  have hdiv := div_le_div_of_nonneg_left (by norm_num : (0 : ℝ) ≤ 22 / 7) hl hQl
  have he1 : (22 / 7 - Q) / Q = (22 / 7) / Q - 1 := by field_simp
  have he2 : (22 / 7 - l) / l = (22 / 7) / l - 1 := by field_simp
  rw [he1] at hs
  rw [he2]
  linarith

theorem scalar_cell_simple {c0 Ceff ap Qm Rm b p hi Q V : ℝ}
    (hap : 0 < ap) (hQπ : Qm ≤ π) (hRπ : Rm ≤ π)
    (hB : b ≤ c0 + hfun Qm + hfun Rm) (hP : p ≤ -(π * Ceff / ap)) (hp : 0 ≤ p)
    (hQ : 0 < Q) (hQQ : Q ≤ Qm) (hV : 0 < V) (hVV : V ≤ Rm)
    (hhi : Q ≤ hi) (hmargin : 0 < b + p / hi) : 0 < rhs c0 Ceff ap Q V := by
  have hh : 0 < hi := hQ.trans_le hhi
  have hP0 : 0 ≤ -(π * Ceff / ap) := hp.trans hP
  have hc := Lam_case1 (B := c0 + hfun Qm + hfun Rm)
    (P := -(π * Ceff / ap)) (R := V) hP0 hQ hhi
  have hd := div_le_div_of_nonneg_right hP hh.le
  have hl := rhs_ge_Lam (c0 := c0) (Ceff := Ceff) hap hQπ hRπ hQ hQQ hV hVV
  linarith

theorem scalar_cell_square {c0 Ceff ap Qm Rm b p s lo hi Q V : ℝ}
    (hap : 0 < ap) (hQπ : Qm ≤ π) (hRπ : Rm ≤ π)
    (hB : b ≤ c0 + hfun Qm + hfun Rm) (hP : p ≤ -(π * Ceff / ap)) (hp : 0 ≤ p)
    (hS : s ≤ EP1038.Arc.sinc Rm) (hlo : 0 < lo)
    (hdiff : 0 ≤ s - (22 / 7 - lo) / lo)
    (hQ : 0 < Q) (hQQ : Q ≤ Qm) (hV : 0 < V) (hVV : V ≤ Rm)
    (hQl : lo ≤ Q) (hQu : Q ≤ hi)
    (hmargin : 0 < b + p / hi + (s - (22 / 7 - lo) / lo) ^ 2) :
    0 < rhs c0 Ceff ap Q V := by
  have hh : 0 < hi := hQ.trans_le hQu
  have hP0 : 0 ≤ -(π * Ceff / ap) := hp.trans hP
  have hsq := sinc_upper_from_lower hlo hQl (hQQ.trans hQπ)
  have hsv := sinc_anti hV hVV hRπ
  have hdiff' : 0 ≤ EP1038.Arc.sinc V - EP1038.Arc.sinc Q := by linarith
  have hds : (s - (22 / 7 - lo) / lo) ^ 2 ≤
      (EP1038.Arc.sinc Q - EP1038.Arc.sinc V) ^ 2 := by
    have hh' := pow_le_pow_left₀ hdiff
      (show s - (22 / 7 - lo) / lo ≤ EP1038.Arc.sinc V - EP1038.Arc.sinc Q by linarith) 2
    nlinarith
  have hpq := div_le_div_of_nonneg_left hP0 hQ hQu
  have hd := div_le_div_of_nonneg_right hP hh.le
  have hl := rhs_ge_Lam (c0 := c0) (Ceff := Ceff) hap hQπ hRπ hQ hQQ hV hVV
  unfold EP1038.Arc.Lam at hl
  linarith

theorem Rmax_le_rho_bound (R : SeparatedReference) {u : ℝ}
    (hp : R.rhoPlus ≤ u) (hm : R.rhoMinus ≤ u) :
    π * totalXi R / bpi R ≤ π * ((1 + u) / 2) := by
  let tp := R.sigmaPlus * (4 * R.rhoPlus / (1 - R.rhoPlus ^ 2))
  let tm := R.sigmaMinus * (4 * R.rhoMinus / (1 - R.rhoMinus ^ 2))
  have hdp : 0 < 1 - R.rhoPlus ^ 2 := by nlinarith [R.rhoPlus_spec.1, R.rhoPlus_spec.2.1]
  have hdm : 0 < 1 - R.rhoMinus ^ 2 := by nlinarith [R.rhoMinus_spec.1, R.rhoMinus_spec.2.1]
  have htp : 0 ≤ tp := by
    dsimp [tp]
    exact mul_nonneg R.sigmaPlus_pos.le
      (div_nonneg (by linarith [R.rhoPlus_spec.1]) hdp.le)
  have htm : 0 ≤ tm := by
    dsimp [tm]
    exact mul_nonneg R.sigmaMinus_pos.le
      (div_nonneg (by linarith [R.rhoMinus_spec.1]) hdm.le)
  have hbp : bpi R = tp + tm := by
    rw [bpi, refB_eq, bpi_eq R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
      R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1]
  have hxi : totalXi R = tp * ((1 + R.rhoPlus) / 2) + tm * ((1 + R.rhoMinus) / 2) := by
    rw [totalXi_formula]
    dsimp [tp, tm]
    have hpn : 1 - R.rhoPlus ≠ 0 := by linarith [R.rhoPlus_spec.2.1]
    have hmn : 1 - R.rhoMinus ≠ 0 := by linarith [R.rhoMinus_spec.2.1]
    field_simp [hpn, hmn, hdp.ne', hdm.ne']
    <;> ring
  have hx : 2 * totalXi R ≤ (1 + u) * bpi R := by
    rw [hxi, hbp]
    nlinarith [mul_nonneg htp (sub_nonneg.mpr hp), mul_nonneg htm (sub_nonneg.mpr hm)]
  apply (div_le_iff₀ (bpi_pos R)).mpr
  nlinarith [mul_le_mul_of_nonneg_left hx Real.pi_pos.le]

end EP1038.ReferenceCert
