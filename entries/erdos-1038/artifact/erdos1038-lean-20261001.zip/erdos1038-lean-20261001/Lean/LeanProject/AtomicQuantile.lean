import LeanProject.NormalFormBridge
import Mathlib.Order.Interval.Set.Union
import Mathlib.Data.Multiset.Sort

/-! A finite empirical distribution as a measurable monotone step quantile.
Each listed atom receives a cell of length `1 / n`; repeated entries retain multiplicity.
The extension outside `(0,1]` uses the first and last listed atoms. -/

open Real Set MeasureTheory Finset intervalIntegral Filter
open scoped ENNReal

namespace EP1038.AtomicQuantile

noncomputable def cut (n j : ℕ) : ℝ := (j : ℝ) / n

def cell (n : ℕ) (j : Fin n) : Set ℝ := Ioc (cut n j) (cut n (j + 1))

noncomputable def step {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) (u : ℝ) : ℝ :=
  if u ≤ 0 then d ⟨0, hn⟩ else if 1 < u then d ⟨n - 1, by omega⟩ else
    ∑ j : Fin n, (cell n j).indicator (fun _ => d j) u

theorem cut_zero (n : ℕ) : cut n 0 = 0 := by simp [cut]

theorem cut_end {n : ℕ} (hn : 0 < n) : cut n n = 1 := by
  simp [cut, Nat.ne_of_gt hn]

theorem cut_mono {n : ℕ} (hn : 0 < n) : Monotone (cut n) := by
  intro i j hij
  exact div_le_div_of_nonneg_right (by exact_mod_cast hij) (by positivity)

theorem cell_subset {n : ℕ} (hn : 0 < n) (j : Fin n) : cell n j ⊆ Ioc 0 1 := by
  apply Set.Ioc_subset_Ioc
  · simpa only [cut_zero] using cut_mono hn (Nat.zero_le j)
  · simpa only [cut_end hn] using cut_mono hn (Nat.succ_le_of_lt j.isLt)

theorem cell_cover {n : ℕ} (hn : 0 < n) {u : ℝ} (hu : u ∈ Ioc (0 : ℝ) 1) :
    ∃ j : Fin n, u ∈ cell n j := by
  have h := Ioc_subset_biUnion_Ioc n (cut n)
    (by simpa only [cut_zero, cut_end hn] using hu)
  simp only [Set.mem_iUnion] at h
  obtain ⟨j, hj, huj⟩ := h
  exact ⟨⟨j, Finset.mem_range.mp hj⟩, huj⟩

theorem cell_order {n : ℕ} (hn : 0 < n) {i j : Fin n} {u v : ℝ}
    (hi : u ∈ cell n i) (hj : v ∈ cell n j) (huv : u ≤ v) : i ≤ j := by
  by_contra h
  have hji : j.1 + 1 ≤ i.1 := by omega
  have hcut := cut_mono hn hji
  have hi0 := hi.1
  have hj1 := hj.2
  linarith

theorem step_on_cell {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) {j : Fin n} {u : ℝ}
    (hu : u ∈ cell n j) : step hn d u = d j := by
  classical
  have hu01 := cell_subset hn j hu
  simp only [step, not_le.mpr hu01.1, not_lt.mpr hu01.2, ite_false]
  rw [Finset.sum_eq_single j]
  · exact Set.indicator_of_mem hu _
  · intro i _ hij
    apply Set.indicator_of_notMem
    intro hui
    exact hij (le_antisymm (cell_order hn hui hu le_rfl) (cell_order hn hu hui le_rfl))
  · simp

theorem measurable_step {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) : Measurable (step hn d) := by
  classical
  apply Measurable.ite measurableSet_Iic measurable_const
  apply Measurable.ite measurableSet_Ioi measurable_const
  exact Finset.measurable_sum _ fun j _ => measurable_const.indicator measurableSet_Ioc

theorem step_bounds {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) {a b : ℝ}
    (hd : ∀ j, d j ∈ Icc a b) (u : ℝ) : step hn d u ∈ Icc a b := by
  by_cases hu0 : u ≤ 0
  · simpa [step, hu0] using hd ⟨0, hn⟩
  by_cases hu1 : 1 < u
  · simpa [step, hu0, hu1] using hd ⟨n - 1, by omega⟩
  obtain ⟨j, hj⟩ := cell_cover hn ⟨lt_of_not_ge hu0, le_of_not_gt hu1⟩
  rw [step_on_cell hn d hj]
  exact hd j

theorem monotone_step {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) (hd : Monotone d) :
    Monotone (step hn d) := by
  intro u v huv
  have hb : ∀ w, step hn d w ∈ Icc (d ⟨0, hn⟩) (d ⟨n - 1, by omega⟩) :=
    step_bounds hn d (fun j => ⟨hd (by change (0 : ℕ) ≤ j.1; omega),
      hd (by change j.1 ≤ n - 1; omega)⟩)
  by_cases hu0 : u ≤ 0
  · simpa [step, hu0] using (hb v).1
  by_cases hv1 : 1 < v
  · simpa [step, hv1, show ¬ v ≤ 0 by linarith] using (hb u).2
  obtain ⟨i, hi⟩ := cell_cover hn (u := u) ⟨by linarith, by linarith⟩
  obtain ⟨j, hj⟩ := cell_cover hn (u := v) ⟨by linarith, by linarith⟩
  rw [step_on_cell hn d hi, step_on_cell hn d hj]
  exact hd (cell_order hn hi hj huv)

/-- Exact integration of any real-valued function against the finite empirical law.
No regularity assumption on `g` is needed because the composition has finite range. -/
theorem integral_step {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) (g : ℝ → ℝ) :
    (∫ u in (0 : ℝ)..1, g (step hn d u)) = (∑ j : Fin n, g (d j)) / n := by
  have hcell : ∀ j < n, IntervalIntegrable (fun u => g (step hn d u)) volume
      (cut n j) (cut n (j + 1)) := by
    intro j hj
    apply (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => g (d ⟨j, hj⟩))
      volume (cut n j) (cut n (j + 1))).congr
    intro u hu
    rw [uIoc_of_le (cut_mono hn (Nat.le_succ j))] at hu
    exact (congrArg g (step_on_cell hn d (j := ⟨j, hj⟩) hu)).symm
  have heq : ∀ j (hj : j < n),
      (∫ u in cut n j..cut n (j + 1), g (step hn d u)) = g (d ⟨j, hj⟩) / n := by
    intro j hj
    calc
      _ = ∫ _ in cut n j..cut n (j + 1), g (d ⟨j, hj⟩) := by
        apply intervalIntegral.integral_congr_ae
        apply Eventually.of_forall
        intro u hu
        rw [uIoc_of_le (cut_mono hn (Nat.le_succ j))] at hu
        exact congrArg g (step_on_cell hn d (j := ⟨j, hj⟩) hu)
      _ = _ := by
        rw [intervalIntegral.integral_const]
        simp only [smul_eq_mul, cut, Nat.cast_add, Nat.cast_one]
        ring
  rw [← cut_zero n, ← cut_end hn, ← sum_integral_adjacent_intervals hcell,
    ← Fin.sum_univ_eq_sum_range]
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro j _
  exact heq j j.isLt

theorem first_atom_positive {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) :
    0 < volume ({u | step hn d u = d ⟨0, hn⟩} ∩ Ioc (0 : ℝ) 1) := by
  have hsub : cell n ⟨0, hn⟩ ⊆ {u | step hn d u = d ⟨0, hn⟩} ∩ Ioc (0 : ℝ) 1 :=
    fun _ hu => ⟨step_on_cell hn d hu, cell_subset hn _ hu⟩
  apply lt_of_lt_of_le _ (measure_mono hsub)
  rw [cell, Real.volume_Ioc, ENNReal.ofReal_pos]
  simp only [cut, Nat.cast_zero, zero_div, Nat.cast_one, zero_add, sub_zero]
  positivity

end EP1038.AtomicQuantile
