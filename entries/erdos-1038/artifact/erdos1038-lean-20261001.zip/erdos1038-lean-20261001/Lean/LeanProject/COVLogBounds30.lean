import LeanProject.COVLogTwo
import LeanProject.COVLogBounds26
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2400 : RB (Real.log ((16644209 : ℝ) / 20000000)) ((-18366993 : ℝ) / 100000000) ((-1147937 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((16644209 : ℝ) / 20000000)) (t := ((-3355791 : ℝ) / 36644209))
    (lo := ((-18366993 : ℝ) / 100000000)) (hi := ((-1147937 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2401 : RB (Real.log ((10402631 : ℝ) / 12500000)) ((-18366989 : ℝ) / 100000000) ((-4591747 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((10402631 : ℝ) / 12500000)) (t := ((-2097369 : ℝ) / 22902631))
    (lo := ((-18366989 : ℝ) / 100000000)) (hi := ((-4591747 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2402 : RB (Real.log ((45458967 : ℝ) / 100000000)) ((-78836011 : ℝ) / 100000000) ((-78836009 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45458967 : ℝ) / 50000000)) (t := ((-4541033 : ℝ) / 95458967))
    (lo := ((-2380323 : ℝ) / 25000000)) (hi := ((-9521291 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45458967 : ℝ) / 100000000) = Real.log ((45458967 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45458967 : ℝ) / 100000000) = ((45458967 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2403 : RB (Real.log ((41667371 : ℝ) / 50000000)) ((-9115233 : ℝ) / 50000000) ((-3646093 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((41667371 : ℝ) / 50000000)) (t := ((-8332629 : ℝ) / 91667371))
    (lo := ((-9115233 : ℝ) / 50000000)) (hi := ((-3646093 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2404 : RB (Real.log ((10416843 : ℝ) / 12500000)) ((-18230463 : ℝ) / 100000000) ((-9115231 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((10416843 : ℝ) / 12500000)) (t := ((-2083157 : ℝ) / 22916843))
    (lo := ((-18230463 : ℝ) / 100000000)) (hi := ((-9115231 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2405 : RB (Real.log ((45492791 : ℝ) / 100000000)) ((-78761633 : ℝ) / 100000000) ((-78761631 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45492791 : ℝ) / 50000000)) (t := ((-4507209 : ℝ) / 95492791))
    (lo := ((-4723457 : ℝ) / 50000000)) (hi := ((-9446913 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45492791 : ℝ) / 100000000) = Real.log ((45492791 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45492791 : ℝ) / 100000000) = ((45492791 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2406 : RB (Real.log ((68476557 : ℝ) / 20000000)) ((123075917 : ℝ) / 100000000) ((1538449 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((68476557 : ℝ) / 80000000)) (t := ((-11523443 : ℝ) / 148476557))
    (lo := ((-15553519 : ℝ) / 100000000)) (hi := ((-7776759 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68476557 : ℝ) / 20000000) = Real.log ((68476557 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((68476557 : ℝ) / 20000000) = ((68476557 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2407 : RB (Real.log ((85595697 : ℝ) / 25000000)) ((61537959 : ℝ) / 50000000) ((123075921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((85595697 : ℝ) / 100000000)) (t := ((-14404303 : ℝ) / 185595697))
    (lo := ((-7776759 : ℝ) / 50000000)) (hi := ((-15553517 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85595697 : ℝ) / 25000000) = Real.log ((85595697 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((85595697 : ℝ) / 25000000) = ((85595697 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2408 : RB (Real.log ((35307111 : ℝ) / 25000000)) ((4315107 : ℝ) / 12500000) ((17260429 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((35307111 : ℝ) / 50000000)) (t := ((-14692889 : ℝ) / 85307111))
    (lo := ((-17396931 : ℝ) / 50000000)) (hi := ((-34793861 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35307111 : ℝ) / 25000000) = Real.log ((35307111 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((35307111 : ℝ) / 25000000) = ((35307111 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2409 : RB (Real.log ((68343513 : ℝ) / 20000000)) ((122881437 : ℝ) / 100000000) ((768009 : ℝ) / 625000) := by
  have hm := log_bounds_of_series (x := ((68343513 : ℝ) / 80000000)) (t := ((-11656487 : ℝ) / 148343513))
    (lo := ((-15747999 : ℝ) / 100000000)) (hi := ((-7873999 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68343513 : ℝ) / 20000000) = Real.log ((68343513 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((68343513 : ℝ) / 20000000) = ((68343513 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2410 : RB (Real.log ((5339337 : ℝ) / 1562500)) ((61440719 : ℝ) / 50000000) ((122881441 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5339337 : ℝ) / 6250000)) (t := ((-910663 : ℝ) / 11589337))
    (lo := ((-7873999 : ℝ) / 50000000)) (hi := ((-15747997 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5339337 : ℝ) / 1562500) = Real.log ((5339337 : ℝ) / 6250000) + 2 * Real.log 2 := by
    rw [show ((5339337 : ℝ) / 1562500) = ((5339337 : ℝ) / 6250000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2411 : RB (Real.log ((141341907 : ℝ) / 100000000)) ((8650291 : ℝ) / 25000000) ((17300583 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((141341907 : ℝ) / 200000000)) (t := ((-58658093 : ℝ) / 341341907))
    (lo := ((-17356777 : ℝ) / 50000000)) (hi := ((-34713553 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141341907 : ℝ) / 100000000) = Real.log ((141341907 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141341907 : ℝ) / 100000000) = ((141341907 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2412 : RB (Real.log ((265511 : ℝ) / 312500)) ((-814741 : ℝ) / 5000000) ((-16294819 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((265511 : ℝ) / 312500)) (t := ((-46989 : ℝ) / 578011))
    (lo := ((-814741 : ℝ) / 5000000)) (hi := ((-16294819 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2413 : RB (Real.log ((85652273 : ℝ) / 100000000)) ((-15487443 : ℝ) / 100000000) ((-7743721 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((85652273 : ℝ) / 100000000)) (t := ((-14347727 : ℝ) / 185652273))
    (lo := ((-15487443 : ℝ) / 100000000)) (hi := ((-7743721 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2414 : RB (Real.log ((83259373 : ℝ) / 100000000)) ((-4580237 : ℝ) / 25000000) ((-18320947 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83259373 : ℝ) / 100000000)) (t := ((-16740627 : ℝ) / 183259373))
    (lo := ((-4580237 : ℝ) / 25000000)) (hi := ((-18320947 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2415 : RB (Real.log ((5203711 : ℝ) / 6250000)) ((-1145059 : ℝ) / 6250000) ((-18320943 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5203711 : ℝ) / 6250000)) (t := ((-1046289 : ℝ) / 11453711))
    (lo := ((-1145059 : ℝ) / 6250000)) (hi := ((-18320943 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2416 : RB (Real.log ((22735187 : ℝ) / 50000000)) ((-78810921 : ℝ) / 100000000) ((-78810919 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22735187 : ℝ) / 25000000)) (t := ((-2264813 : ℝ) / 47735187))
    (lo := ((-4748101 : ℝ) / 50000000)) (hi := ((-9496201 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22735187 : ℝ) / 50000000) = Real.log ((22735187 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22735187 : ℝ) / 50000000) = ((22735187 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2417 : RB (Real.log ((83371781 : ℝ) / 100000000)) ((-1818603 : ℝ) / 10000000) ((-18186029 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83371781 : ℝ) / 100000000)) (t := ((-16628219 : ℝ) / 183371781))
    (lo := ((-1818603 : ℝ) / 10000000)) (hi := ((-18186029 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2418 : RB (Real.log ((10421473 : ℝ) / 12500000)) ((-9093013 : ℝ) / 50000000) ((-727441 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((10421473 : ℝ) / 12500000)) (t := ((-2078527 : ℝ) / 22921473))
    (lo := ((-9093013 : ℝ) / 50000000)) (hi := ((-727441 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2419 : RB (Real.log ((45503801 : ℝ) / 100000000)) ((-39368717 : ℝ) / 50000000) ((-9842179 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((45503801 : ℝ) / 50000000)) (t := ((-4496199 : ℝ) / 95503801))
    (lo := ((-1884543 : ℝ) / 20000000)) (hi := ((-4711357 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45503801 : ℝ) / 100000000) = Real.log ((45503801 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45503801 : ℝ) / 100000000) = ((45503801 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2420 : RB (Real.log ((171079583 : ℝ) / 50000000)) ((123010583 : ℝ) / 100000000) ((61505293 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((171079583 : ℝ) / 200000000)) (t := ((-28920417 : ℝ) / 371079583))
    (lo := ((-15618853 : ℝ) / 100000000)) (hi := ((-3904713 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((171079583 : ℝ) / 50000000) = Real.log ((171079583 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((171079583 : ℝ) / 50000000) = ((171079583 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2421 : RB (Real.log ((342159169 : ℝ) / 100000000)) ((15376323 : ℝ) / 12500000) ((123010587 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((342159169 : ℝ) / 400000000)) (t := ((-57840831 : ℝ) / 742159169))
    (lo := ((-3904713 : ℝ) / 25000000)) (hi := ((-15618851 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342159169 : ℝ) / 100000000) = Real.log ((342159169 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((342159169 : ℝ) / 100000000) = ((342159169 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2422 : RB (Real.log ((35316629 : ℝ) / 25000000)) ((3454781 : ℝ) / 10000000) ((8636953 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((35316629 : ℝ) / 50000000)) (t := ((-14683371 : ℝ) / 85316629))
    (lo := ((-8691727 : ℝ) / 25000000)) (hi := ((-34766907 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35316629 : ℝ) / 25000000) = Real.log ((35316629 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((35316629 : ℝ) / 25000000) = ((35316629 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2423 : RB (Real.log ((341499559 : ℝ) / 100000000)) ((6140881 : ℝ) / 5000000) ((122817623 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((341499559 : ℝ) / 400000000)) (t := ((-58500441 : ℝ) / 741499559))
    (lo := ((-1976477 : ℝ) / 12500000)) (hi := ((-3162363 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((341499559 : ℝ) / 100000000) = Real.log ((341499559 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((341499559 : ℝ) / 100000000) = ((341499559 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2424 : RB (Real.log ((341499563 : ℝ) / 100000000)) ((122817621 : ℝ) / 100000000) ((15352203 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((341499563 : ℝ) / 400000000)) (t := ((-58500437 : ℝ) / 741499563))
    (lo := ((-3162363 : ℝ) / 20000000)) (hi := ((-7905907 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((341499563 : ℝ) / 100000000) = Real.log ((341499563 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((341499563 : ℝ) / 100000000) = ((341499563 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2425 : RB (Real.log ((141379227 : ℝ) / 100000000)) ((8656891 : ℝ) / 25000000) ((17313783 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((141379227 : ℝ) / 200000000)) (t := ((-58620773 : ℝ) / 341379227))
    (lo := ((-17343577 : ℝ) / 50000000)) (hi := ((-34687153 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141379227 : ℝ) / 100000000) = Real.log ((141379227 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141379227 : ℝ) / 100000000) = ((141379227 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2426 : RB (Real.log ((133453 : ℝ) / 156250)) ((-7885397 : ℝ) / 50000000) ((-15770793 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133453 : ℝ) / 156250)) (t := ((-22797 : ℝ) / 289703))
    (lo := ((-7885397 : ℝ) / 50000000)) (hi := ((-15770793 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2427 : RB (Real.log ((21524347 : ℝ) / 25000000)) ((-1871139 : ℝ) / 12500000) ((-14969111 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((21524347 : ℝ) / 25000000)) (t := ((-3475653 : ℝ) / 46524347))
    (lo := ((-1871139 : ℝ) / 12500000)) (hi := ((-14969111 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2428 : RB (Real.log ((83297263 : ℝ) / 100000000)) ((-365509 : ℝ) / 2000000) ((-18275449 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83297263 : ℝ) / 100000000)) (t := ((-16702737 : ℝ) / 183297263))
    (lo := ((-365509 : ℝ) / 2000000)) (hi := ((-18275449 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2429 : RB (Real.log ((41648633 : ℝ) / 50000000)) ((-9137723 : ℝ) / 50000000) ((-3655089 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((41648633 : ℝ) / 50000000)) (t := ((-8351367 : ℝ) / 91648633))
    (lo := ((-9137723 : ℝ) / 50000000)) (hi := ((-3655089 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2430 : RB (Real.log ((22740823 : ℝ) / 50000000)) ((-39393067 : ℝ) / 50000000) ((-19696533 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((22740823 : ℝ) / 25000000)) (t := ((-2259177 : ℝ) / 47740823))
    (lo := ((-1894283 : ℝ) / 20000000)) (hi := ((-4735707 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22740823 : ℝ) / 50000000) = Real.log ((22740823 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22740823 : ℝ) / 50000000) = ((22740823 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2431 : RB (Real.log ((16681681 : ℝ) / 20000000)) ((-18142111 : ℝ) / 100000000) ((-1814211 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((16681681 : ℝ) / 20000000)) (t := ((-3318319 : ℝ) / 36681681))
    (lo := ((-18142111 : ℝ) / 100000000)) (hi := ((-1814211 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2432 : RB (Real.log ((10426051 : ℝ) / 12500000)) ((-18142107 : ℝ) / 100000000) ((-9071053 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((10426051 : ℝ) / 12500000)) (t := ((-2073949 : ℝ) / 22926051))
    (lo := ((-18142107 : ℝ) / 100000000)) (hi := ((-9071053 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2433 : RB (Real.log ((45514683 : ℝ) / 100000000)) ((-39356761 : ℝ) / 50000000) ((-983919 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((45514683 : ℝ) / 50000000)) (t := ((-4485317 : ℝ) / 95514683))
    (lo := ((-9398803 : ℝ) / 100000000)) (hi := ((-4699401 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45514683 : ℝ) / 100000000) = Real.log ((45514683 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45514683 : ℝ) / 100000000) = ((45514683 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2434 : RB (Real.log ((170968723 : ℝ) / 50000000)) ((61472881 : ℝ) / 50000000) ((24589153 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((170968723 : ℝ) / 200000000)) (t := ((-29031277 : ℝ) / 370968723))
    (lo := ((-7841837 : ℝ) / 50000000)) (hi := ((-15683673 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170968723 : ℝ) / 50000000) = Real.log ((170968723 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((170968723 : ℝ) / 50000000) = ((170968723 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2435 : RB (Real.log ((341937449 : ℝ) / 100000000)) ((122945763 : ℝ) / 100000000) ((61472883 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((341937449 : ℝ) / 400000000)) (t := ((-58062551 : ℝ) / 741937449))
    (lo := ((-15683673 : ℝ) / 100000000)) (hi := ((-1960459 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((341937449 : ℝ) / 100000000) = Real.log ((341937449 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((341937449 : ℝ) / 100000000) = ((341937449 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2436 : RB (Real.log ((70652167 : ℝ) / 50000000)) ((34574577 : ℝ) / 100000000) ((34574579 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70652167 : ℝ) / 100000000)) (t := ((-29347833 : ℝ) / 170652167))
    (lo := ((-34740141 : ℝ) / 100000000)) (hi := ((-1737007 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70652167 : ℝ) / 50000000) = Real.log ((70652167 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70652167 : ℝ) / 50000000) = ((70652167 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2437 : RB (Real.log ((170641693 : ℝ) / 50000000)) ((61377149 : ℝ) / 50000000) ((122754301 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((170641693 : ℝ) / 200000000)) (t := ((-29358307 : ℝ) / 370641693))
    (lo := ((-7937569 : ℝ) / 50000000)) (hi := ((-15875137 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170641693 : ℝ) / 50000000) = Real.log ((170641693 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((170641693 : ℝ) / 50000000) = ((170641693 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2438 : RB (Real.log ((341283389 : ℝ) / 100000000)) ((122754299 : ℝ) / 100000000) ((61377151 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((341283389 : ℝ) / 400000000)) (t := ((-58716611 : ℝ) / 741283389))
    (lo := ((-15875137 : ℝ) / 100000000)) (hi := ((-248049 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((341283389 : ℝ) / 100000000) = Real.log ((341283389 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((341283389 : ℝ) / 100000000) = ((341283389 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2439 : RB (Real.log ((1414163 : ℝ) / 1000000)) ((34653783 : ℝ) / 100000000) ((6930757 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1414163 : ℝ) / 2000000)) (t := ((-585837 : ℝ) / 3414163))
    (lo := ((-6932187 : ℝ) / 20000000)) (hi := ((-17330467 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1414163 : ℝ) / 1000000) = Real.log ((1414163 : ℝ) / 2000000) + 1 * Real.log 2 := by
    rw [show ((1414163 : ℝ) / 1000000) = ((1414163 : ℝ) / 2000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2440 : RB (Real.log ((2682979 : ℝ) / 3125000)) ((-7625327 : ℝ) / 50000000) ((-15250653 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2682979 : ℝ) / 3125000)) (t := ((-442021 : ℝ) / 5807979))
    (lo := ((-7625327 : ℝ) / 50000000)) (hi := ((-15250653 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2441 : RB (Real.log ((86541531 : ℝ) / 100000000)) ((-14454577 : ℝ) / 100000000) ((-903411 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((86541531 : ℝ) / 100000000)) (t := ((-13458469 : ℝ) / 186541531))
    (lo := ((-14454577 : ℝ) / 100000000)) (hi := ((-903411 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2442 : RB (Real.log ((3333389 : ℝ) / 4000000)) ((-9115243 : ℝ) / 50000000) ((-3646097 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3333389 : ℝ) / 4000000)) (t := ((-666611 : ℝ) / 7333389))
    (lo := ((-9115243 : ℝ) / 50000000)) (hi := ((-3646097 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2443 : RB (Real.log ((10416841 : ℝ) / 12500000)) ((-18230483 : ℝ) / 100000000) ((-9115241 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((10416841 : ℝ) / 12500000)) (t := ((-2083159 : ℝ) / 22916841))
    (lo := ((-18230483 : ℝ) / 100000000)) (hi := ((-9115241 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2444 : RB (Real.log ((22746393 : ℝ) / 50000000)) ((-19690411 : ℝ) / 25000000) ((-39380821 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((22746393 : ℝ) / 25000000)) (t := ((-2253607 : ℝ) / 47746393))
    (lo := ((-377877 : ℝ) / 4000000)) (hi := ((-2361731 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22746393 : ℝ) / 50000000) = Real.log ((22746393 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22746393 : ℝ) / 50000000) = ((22746393 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2445 : RB (Real.log ((83444619 : ℝ) / 100000000)) ((-9049351 : ℝ) / 50000000) ((-18098701 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83444619 : ℝ) / 100000000)) (t := ((-16555381 : ℝ) / 183444619))
    (lo := ((-9049351 : ℝ) / 50000000)) (hi := ((-18098701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2446 : RB (Real.log ((41722311 : ℝ) / 50000000)) ((-18098699 : ℝ) / 100000000) ((-9049349 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((41722311 : ℝ) / 50000000)) (t := ((-8277689 : ℝ) / 91722311))
    (lo := ((-18098699 : ℝ) / 100000000)) (hi := ((-9049349 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2447 : RB (Real.log ((45525439 : ℝ) / 100000000)) ((-78689893 : ℝ) / 100000000) ((-78689891 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45525439 : ℝ) / 50000000)) (t := ((-4474561 : ℝ) / 95525439))
    (lo := ((-4687587 : ℝ) / 50000000)) (hi := ((-9375173 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45525439 : ℝ) / 100000000) = Real.log ((45525439 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45525439 : ℝ) / 100000000) = ((45525439 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2448 : RB (Real.log ((427147 : ℝ) / 125000)) ((122881447 : ℝ) / 100000000) ((2457629 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((427147 : ℝ) / 500000)) (t := ((-72853 : ℝ) / 927147))
    (lo := ((-15747989 : ℝ) / 100000000)) (hi := ((-3936997 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((427147 : ℝ) / 125000) = Real.log ((427147 : ℝ) / 500000) + 2 * Real.log 2 := by
    rw [show ((427147 : ℝ) / 125000) = ((427147 : ℝ) / 500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2449 : RB (Real.log ((341717603 : ℝ) / 100000000)) ((15360181 : ℝ) / 12500000) ((122881451 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((341717603 : ℝ) / 400000000)) (t := ((-58282397 : ℝ) / 741717603))
    (lo := ((-3936997 : ℝ) / 25000000)) (hi := ((-15747987 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((341717603 : ℝ) / 100000000) = Real.log ((341717603 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((341717603 : ℝ) / 100000000) = ((341717603 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2450 : RB (Real.log ((141341901 : ℝ) / 100000000)) ((34601159 : ℝ) / 100000000) ((34601161 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((141341901 : ℝ) / 200000000)) (t := ((-58658099 : ℝ) / 341341901))
    (lo := ((-34713559 : ℝ) / 100000000)) (hi := ((-17356779 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141341901 : ℝ) / 100000000) = Real.log ((141341901 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141341901 : ℝ) / 100000000) = ((141341901 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2451 : RB (Real.log ((85267253 : ℝ) / 25000000)) ((24538293 : ℝ) / 20000000) ((30672867 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((85267253 : ℝ) / 100000000)) (t := ((-14732747 : ℝ) / 185267253))
    (lo := ((-15937971 : ℝ) / 100000000)) (hi := ((-1593797 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85267253 : ℝ) / 25000000) = Real.log ((85267253 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((85267253 : ℝ) / 25000000) = ((85267253 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2452 : RB (Real.log ((68213803 : ℝ) / 20000000)) ((24538293 : ℝ) / 20000000) ((30672867 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((68213803 : ℝ) / 80000000)) (t := ((-11786197 : ℝ) / 148213803))
    (lo := ((-15937971 : ℝ) / 100000000)) (hi := ((-1593797 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68213803 : ℝ) / 20000000) = Real.log ((68213803 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((68213803 : ℝ) / 20000000) = ((68213803 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2453 : RB (Real.log ((14145313 : ℝ) / 10000000)) ((34679823 : ℝ) / 100000000) ((1387193 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((14145313 : ℝ) / 20000000)) (t := ((-5854687 : ℝ) / 34145313))
    (lo := ((-6926979 : ℝ) / 20000000)) (hi := ((-17317447 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14145313 : ℝ) / 10000000) = Real.log ((14145313 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((14145313 : ℝ) / 10000000) = ((14145313 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2454 : RB (Real.log ((43149879 : ℝ) / 50000000)) ((-736717 : ℝ) / 5000000) ((-14734339 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43149879 : ℝ) / 50000000)) (t := ((-6850121 : ℝ) / 93149879))
    (lo := ((-736717 : ℝ) / 5000000)) (hi := ((-14734339 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2455 : RB (Real.log ((17396943 : ℝ) / 20000000)) ((-6971889 : ℝ) / 50000000) ((-13943777 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17396943 : ℝ) / 20000000)) (t := ((-2603057 : ℝ) / 37396943))
    (lo := ((-6971889 : ℝ) / 50000000)) (hi := ((-13943777 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2456 : RB (Real.log ((83371761 : ℝ) / 100000000)) ((-9093027 : ℝ) / 50000000) ((-18186053 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83371761 : ℝ) / 100000000)) (t := ((-16628239 : ℝ) / 183371761))
    (lo := ((-9093027 : ℝ) / 50000000)) (hi := ((-18186053 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2457 : RB (Real.log ((20842941 : ℝ) / 25000000)) ((-363721 : ℝ) / 2000000) ((-18186049 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20842941 : ℝ) / 25000000)) (t := ((-4157059 : ℝ) / 45842941))
    (lo := ((-363721 : ℝ) / 2000000)) (hi := ((-18186049 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2458 : RB (Real.log ((9100759 : ℝ) / 20000000)) ((-78737447 : ℝ) / 100000000) ((-15747489 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((9100759 : ℝ) / 10000000)) (t := ((-899241 : ℝ) / 19100759))
    (lo := ((-1177841 : ℝ) / 12500000)) (hi := ((-9422727 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9100759 : ℝ) / 20000000) = Real.log ((9100759 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((9100759 : ℝ) / 20000000) = ((9100759 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2459 : RB (Real.log ((83480433 : ℝ) / 100000000)) ((-1128487 : ℝ) / 6250000) ((-18055791 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83480433 : ℝ) / 100000000)) (t := ((-16519567 : ℝ) / 183480433))
    (lo := ((-1128487 : ℝ) / 6250000)) (hi := ((-18055791 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2460 : RB (Real.log ((16696087 : ℝ) / 20000000)) ((-1805579 : ℝ) / 10000000) ((-18055789 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16696087 : ℝ) / 20000000)) (t := ((-3303913 : ℝ) / 36696087))
    (lo := ((-1805579 : ℝ) / 10000000)) (hi := ((-18055789 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2461 : RB (Real.log ((5692009 : ℝ) / 12500000)) ((-3933327 : ℝ) / 5000000) ((-39333269 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5692009 : ℝ) / 6250000)) (t := ((-557991 : ℝ) / 11942009))
    (lo := ((-9351821 : ℝ) / 100000000)) (hi := ((-467591 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5692009 : ℝ) / 12500000) = Real.log ((5692009 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5692009 : ℝ) / 12500000) = ((5692009 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2462 : RB (Real.log ((170749797 : ℝ) / 50000000)) ((12281763 : ℝ) / 10000000) ((122817633 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((170749797 : ℝ) / 200000000)) (t := ((-29250203 : ℝ) / 370749797))
    (lo := ((-7905903 : ℝ) / 50000000)) (hi := ((-3162361 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170749797 : ℝ) / 50000000) = Real.log ((170749797 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((170749797 : ℝ) / 50000000) = ((170749797 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2463 : RB (Real.log ((170749799 : ℝ) / 50000000)) ((122817631 : ℝ) / 100000000) ((61408817 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((170749799 : ℝ) / 200000000)) (t := ((-29250201 : ℝ) / 370749799))
    (lo := ((-3162361 : ℝ) / 20000000)) (hi := ((-3952951 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170749799 : ℝ) / 50000000) = Real.log ((170749799 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((170749799 : ℝ) / 50000000) = ((170749799 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2464 : RB (Real.log ((141379221 : ℝ) / 100000000)) ((865689 : ℝ) / 2500000) ((17313781 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((141379221 : ℝ) / 200000000)) (t := ((-58620779 : ℝ) / 341379221))
    (lo := ((-17343579 : ℝ) / 50000000)) (hi := ((-34687157 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141379221 : ℝ) / 100000000) = Real.log ((141379221 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141379221 : ℝ) / 100000000) = ((141379221 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2465 : RB (Real.log ((340856423 : ℝ) / 100000000)) ((24525823 : ℝ) / 20000000) ((61314559 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((340856423 : ℝ) / 400000000)) (t := ((-59143577 : ℝ) / 740856423))
    (lo := ((-16000321 : ℝ) / 100000000)) (hi := ((-50001 : ℝ) / 312500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340856423 : ℝ) / 100000000) = Real.log ((340856423 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((340856423 : ℝ) / 100000000) = ((340856423 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2466 : RB (Real.log ((340856427 : ℝ) / 100000000)) ((30657279 : ℝ) / 25000000) ((122629119 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((340856427 : ℝ) / 400000000)) (t := ((-59143573 : ℝ) / 740856427))
    (lo := ((-50001 : ℝ) / 312500)) (hi := ((-16000319 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340856427 : ℝ) / 100000000) = Real.log ((340856427 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((340856427 : ℝ) / 100000000) = ((340856427 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2467 : RB (Real.log ((70744859 : ℝ) / 50000000)) ((17352843 : ℝ) / 50000000) ((4338211 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((70744859 : ℝ) / 100000000)) (t := ((-29255141 : ℝ) / 170744859))
    (lo := ((-4326129 : ℝ) / 12500000)) (hi := ((-34609031 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70744859 : ℝ) / 50000000) = Real.log ((70744859 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70744859 : ℝ) / 50000000) = ((70744859 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2468 : RB (Real.log ((86743209 : ℝ) / 100000000)) ((-7110903 : ℝ) / 50000000) ((-2844361 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((86743209 : ℝ) / 100000000)) (t := ((-13256791 : ℝ) / 186743209))
    (lo := ((-7110903 : ℝ) / 50000000)) (hi := ((-2844361 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2469 : RB (Real.log ((17485387 : ℝ) / 20000000)) ((-6718339 : ℝ) / 50000000) ((-13436677 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17485387 : ℝ) / 20000000)) (t := ((-2514613 : ℝ) / 37485387))
    (lo := ((-6718339 : ℝ) / 50000000)) (hi := ((-13436677 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2470 : RB (Real.log ((16681677 : ℝ) / 20000000)) ((-3628427 : ℝ) / 20000000) ((-9071067 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16681677 : ℝ) / 20000000)) (t := ((-3318323 : ℝ) / 36681677))
    (lo := ((-3628427 : ℝ) / 20000000)) (hi := ((-9071067 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2471 : RB (Real.log ((83408387 : ℝ) / 100000000)) ((-4535533 : ℝ) / 25000000) ((-18142131 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83408387 : ℝ) / 100000000)) (t := ((-16591613 : ℝ) / 183408387))
    (lo := ((-4535533 : ℝ) / 25000000)) (hi := ((-18142131 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2472 : RB (Real.log ((45514677 : ℝ) / 100000000)) ((-1229899 : ℝ) / 1562500) ((-39356767 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((45514677 : ℝ) / 50000000)) (t := ((-4485323 : ℝ) / 95514677))
    (lo := ((-9398817 : ℝ) / 100000000)) (hi := ((-293713 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45514677 : ℝ) / 100000000) = Real.log ((45514677 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45514677 : ℝ) / 100000000) = ((45514677 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2473 : RB (Real.log ((83515853 : ℝ) / 100000000)) ((-4503343 : ℝ) / 25000000) ((-18013371 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83515853 : ℝ) / 100000000)) (t := ((-16484147 : ℝ) / 183515853))
    (lo := ((-4503343 : ℝ) / 25000000)) (hi := ((-18013371 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2474 : RB (Real.log ((5219741 : ℝ) / 6250000)) ((-2251671 : ℝ) / 12500000) ((-18013367 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5219741 : ℝ) / 6250000)) (t := ((-1030259 : ℝ) / 11469741))
    (lo := ((-2251671 : ℝ) / 12500000)) (hi := ((-18013367 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2475 : RB (Real.log ((5693323 : ℝ) / 12500000)) ((-78643457 : ℝ) / 100000000) ((-15728691 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((5693323 : ℝ) / 6250000)) (t := ((-556677 : ℝ) / 11943323))
    (lo := ((-4664369 : ℝ) / 50000000)) (hi := ((-9328737 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5693323 : ℝ) / 12500000) = Real.log ((5693323 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5693323 : ℝ) / 12500000) = ((5693323 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2476 : RB (Real.log ((17064171 : ℝ) / 5000000)) ((30688577 : ℝ) / 25000000) ((122754311 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17064171 : ℝ) / 20000000)) (t := ((-2935829 : ℝ) / 37064171))
    (lo := ((-1984391 : ℝ) / 12500000)) (hi := ((-15875127 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17064171 : ℝ) / 5000000) = Real.log ((17064171 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((17064171 : ℝ) / 5000000) = ((17064171 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2477 : RB (Real.log ((10665107 : ℝ) / 3125000)) ((12275431 : ℝ) / 10000000) ((122754313 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10665107 : ℝ) / 12500000)) (t := ((-1834893 : ℝ) / 23165107))
    (lo := ((-7937563 : ℝ) / 50000000)) (hi := ((-127001 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10665107 : ℝ) / 3125000) = Real.log ((10665107 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((10665107 : ℝ) / 3125000) = ((10665107 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2478 : RB (Real.log ((70708147 : ℝ) / 50000000)) ((34653779 : ℝ) / 100000000) ((34653781 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70708147 : ℝ) / 100000000)) (t := ((-29291853 : ℝ) / 170708147))
    (lo := ((-34660939 : ℝ) / 100000000)) (hi := ((-17330469 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70708147 : ℝ) / 50000000) = Real.log ((70708147 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70708147 : ℝ) / 50000000) = ((70708147 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2479 : RB (Real.log ((340645589 : ℝ) / 100000000)) ((61283621 : ℝ) / 50000000) ((24513449 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((340645589 : ℝ) / 400000000)) (t := ((-59354411 : ℝ) / 740645589))
    (lo := ((-8031097 : ℝ) / 50000000)) (hi := ((-16062193 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340645589 : ℝ) / 100000000) = Real.log ((340645589 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((340645589 : ℝ) / 100000000) = ((340645589 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
