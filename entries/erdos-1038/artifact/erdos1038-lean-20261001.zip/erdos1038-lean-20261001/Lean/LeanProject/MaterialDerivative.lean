import LeanProject.ActualBlockMaterial
import Mathlib.Analysis.Calculus.ParametricIntegral

/-!
# Actual derivatives of the moving logarithmic potential

The potential is an integral of the moved positions. A bounded material fiber
quotient supplies a common neighborhood and a genuine dominated derivative.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral
open scoped ENNReal

namespace EP1038.Stage11
open EP1038.Arc AngleReference

set_option maxHeartbeats 2000000

theorem abs_log_le_one_of_half_bounds {u : ℝ} (hl : (1 : ℝ) / 2 ≤ u) (hu : u ≤ 3 / 2) :
    |log u| ≤ 1 := by
  have hp : 0 < u := by linarith
  have hupper := log_le_sub_one_of_pos hp
  have hrecip : 1 / u ≤ 2 := (div_le_iff₀ hp).mpr (by linarith)
  have hlower := log_le_sub_one_of_pos (one_div_pos.mpr hp)
  rw [log_div (by norm_num : (1 : ℝ) ≠ 0) hp.ne', log_one, zero_sub] at hlower
  exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem perturbation_half_bounds {s q C : ℝ} (hC : 0 ≤ C) (hq : |q| ≤ C)
    (hs : |s| < 1 / (4 * (C + 1))) : (1 : ℝ) / 2 ≤ 1 + s * q ∧ 1 + s * q ≤ 3 / 2 := by
  have hp : 0 < 4 * (C + 1) := by positivity
  have hmul := (lt_div_iff₀ hp).mp hs
  have hsq : |s * q| ≤ |s| * C := by
    rw [abs_mul]
    exact mul_le_mul_of_nonneg_left hq (abs_nonneg _)
  have hh : |s| * C ≤ (1 : ℝ) / 2 := by nlinarith [abs_nonneg s]
  have hab := abs_le.mp (hsq.trans hh)
  constructor <;> linarith [hab.1, hab.2]

theorem integrable_log_perturbation {q α : ℝ → ℝ} {C B s : ℝ}
    (hqm : Measurable q) (hαm : Measurable α) (hC : 0 ≤ C) (_hB : 0 ≤ B)
    (hq : ∀ θ ∈ Ioc (0 : ℝ) π, |q θ| ≤ C)
    (hα : ∀ θ ∈ Ioc (0 : ℝ) π, |α θ| ≤ B)
    (hs : |s| < 1 / (4 * (C + 1))) :
    Integrable (fun θ => log (1 + s * q θ) * α θ) angleMeasure := by
  have hm : Measurable (fun θ => log (1 + s * q θ) * α θ) :=
    (Real.measurable_log.comp (measurable_const.add (hqm.const_mul s))).mul hαm
  apply (integrable_const B).mono' hm.aestronglyMeasurable
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with θ hθ
  rw [Real.norm_eq_abs, abs_mul]
  have hb := perturbation_half_bounds hC (hq θ hθ) hs
  have hh := mul_le_mul (abs_log_le_one_of_half_bounds hb.1 hb.2) (hα θ hθ)
    (abs_nonneg _) zero_le_one
  simpa only [one_mul] using hh

/-- A derivative of the integral itself, with its majorant and neighborhood constructed. -/
theorem hasDerivAt_log_perturbation_integral {q α : ℝ → ℝ} {C B : ℝ}
    (hqm : Measurable q) (hαm : Measurable α) (hC : 0 ≤ C) (_hB : 0 ≤ B)
    (hq : ∀ θ ∈ Ioc (0 : ℝ) π, |q θ| ≤ C)
    (hα : ∀ θ ∈ Ioc (0 : ℝ) π, |α θ| ≤ B) :
    HasDerivAt (fun s => ∫ θ, log (1 + s * q θ) * α θ ∂angleMeasure)
      (∫ θ, q θ * α θ ∂angleMeasure) 0 := by
  let δ : ℝ := 1 / (4 * (C + 1))
  have hδ : 0 < δ := by dsimp [δ]; positivity
  let F := fun (s θ : ℝ) => log (1 + s * q θ) * α θ
  let F' := fun (s θ : ℝ) => (q θ / (1 + s * q θ)) * α θ
  have hfm : ∀ s : ℝ, AEStronglyMeasurable (F s) angleMeasure := by
    intro s
    exact ((Real.measurable_log.comp (measurable_const.add (hqm.const_mul s))).mul hαm).aestronglyMeasurable
  have hfi : Integrable (F 0) angleMeasure := by
    simp only [F, zero_mul, add_zero, log_one]
    exact integrable_const 0
  have hdfm : AEStronglyMeasurable (F' 0) angleMeasure := by
    have heq : F' 0 = q * α := by
      funext θ
      simp only [F', zero_mul, add_zero, div_one, Pi.mul_apply]
    rw [heq]
    exact (hqm.mul hαm).aestronglyMeasurable
  have hb : ∀ᵐ θ ∂angleMeasure, ∀ s ∈ Metric.ball (0 : ℝ) δ, ‖F' s θ‖ ≤ 2 * C * B := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with θ hθ s hs
    have hs' : |s| < 1 / (4 * (C + 1)) := by
      simpa only [Metric.mem_ball, Real.dist_eq, sub_zero, δ] using hs
    have hd := (perturbation_half_bounds hC (hq θ hθ) hs').1
    have hp : 0 < 1 + s * q θ := by linarith
    have hr : |q θ| / (1 + s * q θ) ≤ 2 * C :=
      (div_le_iff₀ hp).mpr (by nlinarith [hq θ hθ, mul_nonneg hC (by linarith : 0 ≤ 1 + s * q θ - 1 / 2)])
    dsimp only [F']
    rw [Real.norm_eq_abs, abs_mul, abs_div, abs_of_pos hp]
    exact mul_le_mul hr (hα θ hθ) (abs_nonneg _) (by positivity)
  have hd : ∀ᵐ θ ∂angleMeasure, ∀ s ∈ Metric.ball (0 : ℝ) δ, HasDerivAt (F · θ) (F' s θ) s := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with θ hθ s hs
    have hs' : |s| < 1 / (4 * (C + 1)) := by
      simpa only [Metric.mem_ball, Real.dist_eq, sub_zero, δ] using hs
    have hp : 0 < 1 + s * q θ := by
      have := (perturbation_half_bounds hC (hq θ hθ) hs').1
      linarith
    have hh := ((hasDerivAt_const s (1 : ℝ)).add
      ((hasDerivAt_id s).mul_const (q θ))).log hp.ne'
    simpa only [F, F', Pi.add_apply, id_eq, zero_add, one_mul] using hh.mul_const (α θ)
  have hder := hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (F := F) (F' := F') (bound := fun _ => 2 * C * B)
    (Metric.ball_mem_nhds (0 : ℝ) hδ) (Eventually.of_forall hfm) hfi hdfm hb
    (integrable_const _) hd
  simpa only [F, F', zero_mul, add_zero, div_one] using hder.2

/-- The potential of positions actually displaced by `s * v`. -/
noncomputable def movingLogPotential (k ρ c r : ℝ) (v : ℝ → ℝ) (s θ : ℝ) : ℝ :=
  k * log (position c r θ + s * v θ) + 1 / π *
    ∫ φ in (0 : ℝ)..π, log |(position c r θ + s * v θ) -
      (position c r φ + s * v φ)| * alpha k ρ φ

/-- Differentiation of the actual moving integral, not a formal definition of its derivative.
The fiber bound is later constructed for every interior point of an actual root block. -/
theorem hasDerivAt_movingLogPotential {k ρ c r θ C : ℝ} {v : ℝ → ℝ}
    (hk : 0 ≤ k) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (ha0 : 0 ≤ alpha k ρ 0)
    (hr : 0 < r) (hθ : θ ∈ Icc (0 : ℝ) π) (hp : position c r θ ≠ 0)
    (hvm : Measurable v) (hC : 0 ≤ C)
    (hq : ∀ φ ∈ Ioc (0 : ℝ) π,
      |(v φ - v θ) / (position c r φ - position c r θ)| ≤ C)
    (hbase : IntervalIntegrable (fun φ => log |position c r θ - position c r φ| *
      alpha k ρ φ) volume 0 π) :
    HasDerivAt (fun s => movingLogPotential k ρ c r v s θ)
      (materialAngular k ρ c r v θ) 0 := by
  let q := fun φ => (v φ - v θ) / (position c r φ - position c r θ)
  have hpm : Measurable (position c r) := by unfold position; fun_prop
  have hqm : Measurable q := (hvm.sub measurable_const).div (hpm.sub measurable_const)
  have hαm := (alpha_cont k ρ hρ0 hρ1).measurable
  have hα : ∀ φ ∈ Ioc (0 : ℝ) π, |alpha k ρ φ| ≤ k + 1 := by
    intro φ _
    exact (alpha_bounds hk hρ0 hρ1 ha0 φ).2
  have hbi : Integrable (fun φ => log |position c r θ - position c r φ| *
      alpha k ρ φ) angleMeasure :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le).mp hbase
  have hpert := hasDerivAt_log_perturbation_integral hqm hαm hC (by linarith : 0 ≤ k + 1) hq hα
  have hmass := (((hasDerivAt_const (0 : ℝ) (position c r θ)).add
    ((hasDerivAt_id (0 : ℝ)).mul_const (v θ))).log (by simpa using hp)).const_mul k
  have hd := hmass.add (((hasDerivAt_const (0 : ℝ)
    (∫ φ, log |position c r θ - position c r φ| * alpha k ρ φ ∂angleMeasure)).add
      hpert).const_mul (1 / π))
  have hd' : HasDerivAt (fun s => k * log (position c r θ + s * v θ) +
      1 / π * ((∫ φ, log |position c r θ - position c r φ| * alpha k ρ φ ∂angleMeasure) +
        ∫ φ, log (1 + s * q φ) * alpha k ρ φ ∂angleMeasure))
      (materialAngular k ρ c r v θ) 0 := by
    convert hd using 1
    · funext s
      simp
    · dsimp [materialAngular, materialKernel, q]
      rw [intervalIntegral.integral_of_le Real.pi_pos.le]
      simp only [Pi.add_apply, id_eq, zero_mul, add_zero, zero_add, one_mul, angleMeasure]
      ring
  apply hd'.congr_of_eventuallyEq
  have hδ : 0 < 1 / (4 * (C + 1)) := by positivity
  filter_upwards [Metric.ball_mem_nhds (0 : ℝ) hδ] with s hs
  have hs' : |s| < 1 / (4 * (C + 1)) := by
    simpa only [Metric.mem_ball, Real.dist_eq, sub_zero] using hs
  have hpi := integrable_log_perturbation hqm hαm hC (by linarith : 0 ≤ k + 1) hq hα hs'
  have he : (fun φ => log |(position c r θ + s * v θ) -
      (position c r φ + s * v φ)| * alpha k ρ φ) =ᵐ[angleMeasure]
      (fun φ => log |position c r θ - position c r φ| * alpha k ρ φ +
        log (1 + s * q φ) * alpha k ρ φ) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc,
      ae_restrict_of_ae (EP1038.Stage9.ae_ne_real θ)] with φ hφ hne
    have hdif : position c r φ - position c r θ ≠ 0 :=
      sub_ne_zero.mpr (fun hh => hne ((EP1038.Stage12.position_strictMonoOn hr).injOn
        ⟨hφ.1.le, hφ.2⟩ hθ hh))
    have hD : position c r θ - position c r φ ≠ 0 := by
      intro hh
      exact hdif (by linarith)
    have hh : 0 < 1 + s * q φ := by
      have := (perturbation_half_bounds hC (hq φ hφ) hs').1
      linarith
    have hfac : (position c r θ + s * v θ) - (position c r φ + s * v φ) =
        (position c r θ - position c r φ) * (1 + s * q φ) := by
      dsimp [q]
      field_simp [hdif]
      ring
    rw [hfac, abs_mul, abs_of_pos hh,
      log_mul (abs_ne_zero.mpr hD) hh.ne']
    ring
  unfold movingLogPotential
  rw [intervalIntegral.integral_of_le Real.pi_pos.le]
  change k * log (position c r θ + s * v θ) + 1 / π *
    (∫ φ, log |(position c r θ + s * v θ) - (position c r φ + s * v φ)| *
      alpha k ρ φ ∂angleMeasure) = _
  rw [MeasureTheory.integral_congr_ae he, MeasureTheory.integral_add hbi hpi]

namespace AngleReference

/-- The original quantile deformation, with Lebesgue mass coordinate `u`. -/
noncomputable def deformedQuantile (A : AngleReference) (c r : ℝ) (T : ℝ → ℝ)
    (s u : ℝ) : ℝ := A.quantile c r u + s * (T u - A.quantile c r u)

/-- Exact equality with the existing logarithmic potential `WS` in mass coordinates. -/
theorem movingLogPotential_eq_WS (A : AngleReference) (c r : ℝ) (T : ℝ → ℝ)
    (s : ℝ) {θ : ℝ} (hθ : θ ∈ Icc (0 : ℝ) π)
    (hp : 0 < position c r θ + s * A.angularDrift c r T θ) :
    movingLogPotential A.k A.ρ c r (A.angularDrift c r T) s θ =
      Stage10.WS A.k (A.deformedQuantile c r T s)
        (A.deformedQuantile c r T s (A.cdf θ)) := by
  have hx : A.deformedQuantile c r T s (A.cdf θ) =
      position c r θ + s * A.angularDrift c r T θ := by
    simp only [deformedQuantile, angularDrift, angularTarget, foldedAngle_eq hθ,
      A.quantile_cdf c r hθ]
  rw [Stage10.WS, hx, abs_of_pos hp, A.integral_cdf]
  unfold movingLogPotential
  congr 2
  apply intervalIntegral.integral_congr
  intro φ hφ
  rw [uIcc_of_le Real.pi_pos.le] at hφ
  simp only [deformedQuantile, A.quantile_cdf c r hφ, angularDrift, angularTarget,
    foldedAngle_eq hθ, foldedAngle_eq hφ]

end AngleReference
end EP1038.Stage11
