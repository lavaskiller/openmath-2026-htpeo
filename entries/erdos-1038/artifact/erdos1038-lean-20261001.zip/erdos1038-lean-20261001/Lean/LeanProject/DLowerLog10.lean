import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog07
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_600 : RB (Real.log ((443933 : ℝ) / 400000)) ((26052275759 : ℝ) / 250000000000) ((104209103037 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((443933 : ℝ) / 400000)) (t := ((43933 : ℝ) / 843933))
    (lo := ((26052275759 : ℝ) / 250000000000)) (hi := ((104209103037 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_601 : RB (Real.log ((107531249999 : ℝ) / 1000000000000)) ((-1114986887997 : ℝ) / 500000000000) ((-278746721999 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((107531249999 : ℝ) / 125000000000)) (t := ((-17468750001 : ℝ) / 232531249999))
    (lo := ((-75266117157 : ℝ) / 500000000000)) (hi := ((-150532234313 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((107531249999 : ℝ) / 1000000000000) = Real.log ((107531249999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((107531249999 : ℝ) / 1000000000000) = ((107531249999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_602 : RB (Real.log ((43933 : ℝ) / 400000)) ((-2208798800991 : ℝ) / 1000000000000) ((-2208798800989 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((43933 : ℝ) / 50000)) (t := ((-6067 : ℝ) / 93933))
    (lo := ((-129357259311 : ℝ) / 1000000000000)) (hi := ((-12935725931 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43933 : ℝ) / 400000) = Real.log ((43933 : ℝ) / 50000) - 3 * Real.log 2 := by
    rw [show ((43933 : ℝ) / 400000) = ((43933 : ℝ) / 50000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_603 : RB (Real.log ((420169059019 : ℝ) / 1000000000000)) ((-433549063611 : ℝ) / 500000000000) ((-43354906361 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((420169059019 : ℝ) / 500000000000)) (t := ((-79830940981 : ℝ) / 920169059019))
    (lo := ((-86975473331 : ℝ) / 500000000000)) (hi := ((-173950946661 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((420169059019 : ℝ) / 1000000000000) = Real.log ((420169059019 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((420169059019 : ℝ) / 1000000000000) = ((420169059019 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_604 : RB (Real.log ((420888113497 : ℝ) / 1000000000000)) ((-865388244287 : ℝ) / 1000000000000) ((-173077648857 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((420888113497 : ℝ) / 500000000000)) (t := ((-79111886503 : ℝ) / 920888113497))
    (lo := ((-172241063727 : ℝ) / 1000000000000)) (hi := ((-86120531863 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((420888113497 : ℝ) / 1000000000000) = Real.log ((420888113497 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((420888113497 : ℝ) / 1000000000000) = ((420888113497 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_605 : RB (Real.log ((152176332223 : ℝ) / 500000000000)) ((-237913633907 : ℝ) / 200000000000) ((-1189568169533 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((152176332223 : ℝ) / 125000000000)) (t := ((27176332223 : ℝ) / 277176332223))
    (lo := ((39345238317 : ℝ) / 200000000000)) (hi := ((98363095793 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((152176332223 : ℝ) / 500000000000) = Real.log ((152176332223 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((152176332223 : ℝ) / 500000000000) = ((152176332223 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_606 : RB (Real.log ((3110625583201 : ℝ) / 1000000000000)) ((283705964529 : ℝ) / 250000000000) ((567411929059 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3110625583201 : ℝ) / 4000000000000)) (t := ((-889374416799 : ℝ) / 7110625583201))
    (lo := ((-251470503003 : ℝ) / 1000000000000)) (hi := ((-125735251501 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3110625583201 : ℝ) / 1000000000000) = Real.log ((3110625583201 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3110625583201 : ℝ) / 1000000000000) = ((3110625583201 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_607 : RB (Real.log ((1555847113471 : ℝ) / 500000000000)) ((1135167345363 : ℝ) / 1000000000000) ((227033469073 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1555847113471 : ℝ) / 2000000000000)) (t := ((-444152886529 : ℝ) / 3555847113471))
    (lo := ((-62781753939 : ℝ) / 250000000000)) (hi := ((-50225403151 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1555847113471 : ℝ) / 500000000000) = Real.log ((1555847113471 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1555847113471 : ℝ) / 500000000000) = ((1555847113471 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_608 : RB (Real.log ((1468077725299 : ℝ) / 1000000000000)) ((191976937589 : ℝ) / 500000000000) ((19197693759 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((1468077725299 : ℝ) / 2000000000000)) (t := ((-531922274701 : ℝ) / 3468077725299))
    (lo := ((-309193305381 : ℝ) / 1000000000000)) (hi := ((-15459665269 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1468077725299 : ℝ) / 1000000000000) = Real.log ((1468077725299 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1468077725299 : ℝ) / 1000000000000) = ((1468077725299 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_609 : RB (Real.log ((1109832499999 : ℝ) / 1000000000000)) ((20841820607 : ℝ) / 200000000000) ((26052275759 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1109832499999 : ℝ) / 1000000000000)) (t := ((109832499999 : ℝ) / 2109832499999))
    (lo := ((20841820607 : ℝ) / 200000000000)) (hi := ((26052275759 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_610 : RB (Real.log ((1777573 : ℝ) / 1600000)) ((105245321523 : ℝ) / 1000000000000) ((26311330381 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1777573 : ℝ) / 1600000)) (t := ((177573 : ℝ) / 3377573))
    (lo := ((105245321523 : ℝ) / 1000000000000)) (hi := ((26311330381 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_611 : RB (Real.log ((109832499999 : ℝ) / 1000000000000)) ((-2208798801 : ℝ) / 1000000000) ((-1104399400499 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((109832499999 : ℝ) / 125000000000)) (t := ((-15167500001 : ℝ) / 234832499999))
    (lo := ((-3233931483 : ℝ) / 25000000000)) (hi := ((-129357259319 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((109832499999 : ℝ) / 1000000000000) = Real.log ((109832499999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((109832499999 : ℝ) / 1000000000000) = ((109832499999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_612 : RB (Real.log ((177573 : ℝ) / 1600000)) ((-439675423251 : ℝ) / 200000000000) ((-2198377116253 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((177573 : ℝ) / 200000)) (t := ((-22427 : ℝ) / 377573))
    (lo := ((-4757422983 : ℝ) / 40000000000)) (hi := ((-59467787287 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((177573 : ℝ) / 1600000) = Real.log ((177573 : ℝ) / 200000) - 3 * Real.log 2 := by
    rw [show ((177573 : ℝ) / 1600000) = ((177573 : ℝ) / 200000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_613 : RB (Real.log ((172712717643 : ℝ) / 500000000000)) ((-212595695179 : ℝ) / 200000000000) ((-265744618973 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((172712717643 : ℝ) / 250000000000)) (t := ((-77287282357 : ℝ) / 422712717643))
    (lo := ((-73966259067 : ℝ) / 200000000000)) (hi := ((-369831295333 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((172712717643 : ℝ) / 500000000000) = Real.log ((172712717643 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((172712717643 : ℝ) / 500000000000) = ((172712717643 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_614 : RB (Real.log ((69154307723 : ℝ) / 200000000000)) ((-212395403007 : ℝ) / 200000000000) ((-132747126879 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((69154307723 : ℝ) / 100000000000)) (t := ((-30845692277 : ℝ) / 169154307723))
    (lo := ((-14753193379 : ℝ) / 40000000000)) (hi := ((-368829834473 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((69154307723 : ℝ) / 200000000000) = Real.log ((69154307723 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((69154307723 : ℝ) / 200000000000) = ((69154307723 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_615 : RB (Real.log ((132947794779 : ℝ) / 500000000000)) ((-331162891929 : ℝ) / 250000000000) ((-662325783857 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((132947794779 : ℝ) / 125000000000)) (t := ((7947794779 : ℝ) / 257947794779))
    (lo := ((15410698351 : ℝ) / 250000000000)) (hi := ((12328558681 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((132947794779 : ℝ) / 500000000000) = Real.log ((132947794779 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((132947794779 : ℝ) / 500000000000) = ((132947794779 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_616 : RB (Real.log ((1542165830139 : ℝ) / 500000000000)) ((1126334992161 : ℝ) / 1000000000000) ((1126334992163 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1542165830139 : ℝ) / 2000000000000)) (t := ((-457834169861 : ℝ) / 3542165830139))
    (lo := ((-129979684479 : ℝ) / 500000000000)) (hi := ((-259959368957 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1542165830139 : ℝ) / 500000000000) = Real.log ((1542165830139 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1542165830139 : ℝ) / 500000000000) = ((1542165830139 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_617 : RB (Real.log ((3084867843187 : ℝ) / 1000000000000)) ((45060352717 : ℝ) / 40000000000) ((1126508817927 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3084867843187 : ℝ) / 4000000000000)) (t := ((-915132156813 : ℝ) / 7084867843187))
    (lo := ((-129892771597 : ℝ) / 500000000000)) (hi := ((-259785543193 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3084867843187 : ℝ) / 1000000000000) = Real.log ((3084867843187 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3084867843187 : ℝ) / 1000000000000) = ((3084867843187 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_618 : RB (Real.log ((294772129099 : ℝ) / 200000000000)) ((38788524757 : ℝ) / 100000000000) ((96971311893 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((294772129099 : ℝ) / 400000000000)) (t := ((-105227870901 : ℝ) / 694772129099))
    (lo := ((-305261932989 : ℝ) / 1000000000000)) (hi := ((-76315483247 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((294772129099 : ℝ) / 200000000000) = Real.log ((294772129099 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((294772129099 : ℝ) / 200000000000) = ((294772129099 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_619 : RB (Real.log ((1110983124999 : ℝ) / 1000000000000)) ((52622660761 : ℝ) / 500000000000) ((105245321523 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1110983124999 : ℝ) / 1000000000000)) (t := ((110983124999 : ℝ) / 2110983124999))
    (lo := ((52622660761 : ℝ) / 500000000000)) (hi := ((105245321523 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_620 : RB (Real.log ((889707 : ℝ) / 800000)) ((26570116843 : ℝ) / 250000000000) ((106280467373 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((889707 : ℝ) / 800000)) (t := ((89707 : ℝ) / 1689707))
    (lo := ((26570116843 : ℝ) / 250000000000)) (hi := ((106280467373 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_621 : RB (Real.log ((110983124999 : ℝ) / 1000000000000)) ((-274797139533 : ℝ) / 125000000000) ((-1099188558131 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((110983124999 : ℝ) / 125000000000)) (t := ((-14016875001 : ℝ) / 235983124999))
    (lo := ((-14866946823 : ℝ) / 125000000000)) (hi := ((-118935574583 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((110983124999 : ℝ) / 1000000000000) = Real.log ((110983124999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((110983124999 : ℝ) / 1000000000000) = ((110983124999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_622 : RB (Real.log ((89707 : ℝ) / 800000)) ((-437612584749 : ℝ) / 200000000000) ((-2188062923743 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((89707 : ℝ) / 100000)) (t := ((-10293 : ℝ) / 189707))
    (lo := ((-21724276413 : ℝ) / 200000000000)) (hi := ((-6788836379 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89707 : ℝ) / 800000) = Real.log ((89707 : ℝ) / 100000) - 3 * Real.log 2 := by
    rw [show ((89707 : ℝ) / 800000) = ((89707 : ℝ) / 100000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_623 : RB (Real.log ((42688072049 : ℝ) / 125000000000)) ((-134299274901 : ℝ) / 125000000000) ((-268598549801 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((42688072049 : ℝ) / 62500000000)) (t := ((-19811927951 : ℝ) / 105188072049))
    (lo := ((-47655877331 : ℝ) / 125000000000)) (hi := ((-76249403729 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42688072049 : ℝ) / 125000000000) = Real.log ((42688072049 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((42688072049 : ℝ) / 125000000000) = ((42688072049 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_624 : RB (Real.log ((85463339549 : ℝ) / 250000000000)) ((-1073373411077 : ℝ) / 1000000000000) ((-1073373411073 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((85463339549 : ℝ) / 125000000000)) (t := ((-39536660451 : ℝ) / 210463339549))
    (lo := ((-380226230517 : ℝ) / 1000000000000)) (hi := ((-190113115257 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85463339549 : ℝ) / 250000000000) = Real.log ((85463339549 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((85463339549 : ℝ) / 250000000000) = ((85463339549 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_625 : RB (Real.log ((263941368903 : ℝ) / 1000000000000)) ((-133202828799 : ℝ) / 100000000000) ((-333007071997 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((263941368903 : ℝ) / 250000000000)) (t := ((13941368903 : ℝ) / 513941368903))
    (lo := ((5426607313 : ℝ) / 100000000000)) (hi := ((54266073131 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((263941368903 : ℝ) / 1000000000000) = Real.log ((263941368903 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((263941368903 : ℝ) / 1000000000000) = ((263941368903 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_626 : RB (Real.log ((769821962837 : ℝ) / 250000000000)) ((562349176577 : ℝ) / 500000000000) ((281174588289 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((769821962837 : ℝ) / 1000000000000)) (t := ((-230178037163 : ℝ) / 1769821962837))
    (lo := ((-52319201593 : ℝ) / 200000000000)) (hi := ((-65399001991 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((769821962837 : ℝ) / 250000000000) = Real.log ((769821962837 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((769821962837 : ℝ) / 250000000000) = ((769821962837 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_627 : RB (Real.log ((76995711291 : ℝ) / 25000000000)) ((1124873897913 : ℝ) / 1000000000000) ((224974779583 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((76995711291 : ℝ) / 100000000000)) (t := ((-23004288709 : ℝ) / 176995711291))
    (lo := ((-130710231603 : ℝ) / 500000000000)) (hi := ((-52284092641 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((76995711291 : ℝ) / 25000000000) = Real.log ((76995711291 : ℝ) / 100000000000) + 2 * Real.log 2 := by
    rw [show ((76995711291 : ℝ) / 25000000000) = ((76995711291 : ℝ) / 100000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_628 : RB (Real.log ((73744332019 : ℝ) / 50000000000)) ((388581132857 : ℝ) / 1000000000000) ((388581132859 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((73744332019 : ℝ) / 100000000000)) (t := ((-26255667981 : ℝ) / 173744332019))
    (lo := ((-152283023851 : ℝ) / 500000000000)) (hi := ((-304566047701 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((73744332019 : ℝ) / 50000000000) = Real.log ((73744332019 : ℝ) / 100000000000) + 1 * Real.log 2 := by
    rw [show ((73744332019 : ℝ) / 50000000000) = ((73744332019 : ℝ) / 100000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_629 : RB (Real.log ((1112133749999 : ℝ) / 1000000000000)) ((106280467371 : ℝ) / 1000000000000) ((26570116843 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1112133749999 : ℝ) / 1000000000000)) (t := ((112133749999 : ℝ) / 2112133749999))
    (lo := ((106280467371 : ℝ) / 1000000000000)) (hi := ((26570116843 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_630 : RB (Real.log ((356251 : ℝ) / 320000)) ((53657271401 : ℝ) / 500000000000) ((107314542803 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((356251 : ℝ) / 320000)) (t := ((36251 : ℝ) / 676251))
    (lo := ((53657271401 : ℝ) / 500000000000)) (hi := ((107314542803 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_631 : RB (Real.log ((112133749999 : ℝ) / 1000000000000)) ((-2188062923753 : ℝ) / 1000000000000) ((-2188062923751 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((112133749999 : ℝ) / 125000000000)) (t := ((-12866250001 : ℝ) / 237133749999))
    (lo := ((-108621382073 : ℝ) / 1000000000000)) (hi := ((-13577672759 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112133749999 : ℝ) / 1000000000000) = Real.log ((112133749999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((112133749999 : ℝ) / 1000000000000) = ((112133749999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_632 : RB (Real.log ((36251 : ℝ) / 320000)) ((-2177854028667 : ℝ) / 1000000000000) ((-435570805733 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((36251 : ℝ) / 40000)) (t := ((-3749 : ℝ) / 76251))
    (lo := ((-98412486987 : ℝ) / 1000000000000)) (hi := ((-49206243493 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((36251 : ℝ) / 320000) = Real.log ((36251 : ℝ) / 40000) - 3 * Real.log 2 := by
    rw [show ((36251 : ℝ) / 320000) = ((36251 : ℝ) / 40000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_633 : RB (Real.log ((338538571201 : ℝ) / 1000000000000)) ((-216623449141 : ℝ) / 200000000000) ((-10831172457 : ℝ) / 10000000000) := by
  have hm := log_bounds_of_series (x := ((338538571201 : ℝ) / 500000000000)) (t := ((-161461428799 : ℝ) / 838538571201))
    (lo := ((-77994013029 : ℝ) / 200000000000)) (hi := ((-389970065141 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((338538571201 : ℝ) / 1000000000000) = Real.log ((338538571201 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((338538571201 : ℝ) / 1000000000000) = ((338538571201 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_634 : RB (Real.log ((169445131831 : ℝ) / 500000000000)) ((-1082078930019 : ℝ) / 1000000000000) ((-216415786003 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((169445131831 : ℝ) / 250000000000)) (t := ((-80554868169 : ℝ) / 419445131831))
    (lo := ((-388931749459 : ℝ) / 1000000000000)) (hi := ((-24308234341 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((169445131831 : ℝ) / 500000000000) = Real.log ((169445131831 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((169445131831 : ℝ) / 500000000000) = ((169445131831 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_635 : RB (Real.log ((65626035809 : ℝ) / 250000000000)) ((-1337488413319 : ℝ) / 1000000000000) ((-1337488413317 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((65626035809 : ℝ) / 62500000000)) (t := ((3126035809 : ℝ) / 128126035809))
    (lo := ((48805947801 : ℝ) / 1000000000000)) (hi := ((24402973901 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65626035809 : ℝ) / 250000000000) = Real.log ((65626035809 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((65626035809 : ℝ) / 250000000000) = ((65626035809 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_636 : RB (Real.log ((3074234450851 : ℝ) / 1000000000000)) ((1123055911189 : ℝ) / 1000000000000) ((1123055911191 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3074234450851 : ℝ) / 4000000000000)) (t := ((-925765549149 : ℝ) / 7074234450851))
    (lo := ((-26323844993 : ℝ) / 100000000000)) (hi := ((-263238449929 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3074234450851 : ℝ) / 1000000000000) = Real.log ((3074234450851 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3074234450851 : ℝ) / 1000000000000) = ((3074234450851 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_637 : RB (Real.log ((614955888541 : ℝ) / 200000000000)) ((224646634547 : ℝ) / 200000000000) ((1123233172737 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((614955888541 : ℝ) / 800000000000)) (t := ((-185044111459 : ℝ) / 1414955888541))
    (lo := ((-8220662137 : ℝ) / 31250000000)) (hi := ((-263061188383 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((614955888541 : ℝ) / 200000000000) = Real.log ((614955888541 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((614955888541 : ℝ) / 200000000000) = ((614955888541 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_638 : RB (Real.log ((737959274559 : ℝ) / 500000000000)) ((38928054113 : ℝ) / 100000000000) ((97320135283 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((737959274559 : ℝ) / 1000000000000)) (t := ((-262040725441 : ℝ) / 1737959274559))
    (lo := ((-303866639429 : ℝ) / 1000000000000)) (hi := ((-75966659857 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((737959274559 : ℝ) / 500000000000) = Real.log ((737959274559 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((737959274559 : ℝ) / 500000000000) = ((737959274559 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_639 : RB (Real.log ((1113284374999 : ℝ) / 1000000000000)) ((107314542801 : ℝ) / 1000000000000) ((53657271401 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1113284374999 : ℝ) / 1000000000000)) (t := ((113284374999 : ℝ) / 2113284374999))
    (lo := ((107314542801 : ℝ) / 1000000000000)) (hi := ((53657271401 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_640 : RB (Real.log ((222887 : ℝ) / 200000)) ((4333902001 : ℝ) / 40000000000) ((54173775013 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((222887 : ℝ) / 200000)) (t := ((22887 : ℝ) / 422887))
    (lo := ((4333902001 : ℝ) / 40000000000)) (hi := ((54173775013 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_641 : RB (Real.log ((113284374999 : ℝ) / 1000000000000)) ((-544463507169 : ℝ) / 250000000000) ((-1088927014337 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((113284374999 : ℝ) / 125000000000)) (t := ((-11715625001 : ℝ) / 238284374999))
    (lo := ((-24603121749 : ℝ) / 250000000000)) (hi := ((-19682497399 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((113284374999 : ℝ) / 1000000000000) = Real.log ((113284374999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((113284374999 : ℝ) / 1000000000000) = ((113284374999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_642 : RB (Real.log ((22887 : ℝ) / 200000)) ((-541937075693 : ℝ) / 250000000000) ((-216774830277 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((22887 : ℝ) / 25000)) (t := ((-2113 : ℝ) / 47887))
    (lo := ((-22076690273 : ℝ) / 250000000000)) (hi := ((-88306761091 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22887 : ℝ) / 200000) = Real.log ((22887 : ℝ) / 25000) - 3 * Real.log 2 := by
    rw [show ((22887 : ℝ) / 200000) = ((22887 : ℝ) / 25000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_643 : RB (Real.log ((336932163567 : ℝ) / 1000000000000)) ((-271968415987 : ℝ) / 250000000000) ((-543936831971 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((336932163567 : ℝ) / 500000000000)) (t := ((-163067836433 : ℝ) / 836932163567))
    (lo := ((-98681620847 : ℝ) / 250000000000)) (hi := ((-394726483383 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((336932163567 : ℝ) / 1000000000000) = Real.log ((336932163567 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((336932163567 : ℝ) / 1000000000000) = ((336932163567 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_644 : RB (Real.log ((168643557109 : ℝ) / 500000000000)) ((-54341037019 : ℝ) / 50000000000) ((-8694565923 : ℝ) / 8000000000) := by
  have hm := log_bounds_of_series (x := ((168643557109 : ℝ) / 250000000000)) (t := ((-81356442891 : ℝ) / 418643557109))
    (lo := ((-19683677991 : ℝ) / 50000000000)) (hi := ((-49209194977 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((168643557109 : ℝ) / 500000000000) = Real.log ((168643557109 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((168643557109 : ℝ) / 500000000000) = ((168643557109 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_645 : RB (Real.log ((13090699077 : ℝ) / 50000000000)) ((-1340121021509 : ℝ) / 1000000000000) ((-1340121021507 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((13090699077 : ℝ) / 12500000000)) (t := ((590699077 : ℝ) / 25590699077))
    (lo := ((46173339611 : ℝ) / 1000000000000)) (hi := ((11543334903 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13090699077 : ℝ) / 50000000000) = Real.log ((13090699077 : ℝ) / 12500000000) - 2 * Real.log 2 := by
    rw [show ((13090699077 : ℝ) / 50000000000) = ((13090699077 : ℝ) / 12500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_646 : RB (Real.log ((383646485597 : ℝ) / 125000000000)) ((560703890419 : ℝ) / 500000000000) ((28035194521 : ℝ) / 25000000000) := by
  have hm := log_bounds_of_series (x := ((383646485597 : ℝ) / 500000000000)) (t := ((-116353514403 : ℝ) / 883646485597))
    (lo := ((-264886580281 : ℝ) / 1000000000000)) (hi := ((-6622164507 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((383646485597 : ℝ) / 125000000000) = Real.log ((383646485597 : ℝ) / 500000000000) + 2 * Real.log 2 := by
    rw [show ((383646485597 : ℝ) / 125000000000) = ((383646485597 : ℝ) / 500000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_647 : RB (Real.log ((3069721242423 : ℝ) / 1000000000000)) ((1121586756961 : ℝ) / 1000000000000) ((1121586756963 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3069721242423 : ℝ) / 4000000000000)) (t := ((-930278757577 : ℝ) / 7069721242423))
    (lo := ((-132353802079 : ℝ) / 500000000000)) (hi := ((-264707604157 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3069721242423 : ℝ) / 1000000000000) = Real.log ((3069721242423 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3069721242423 : ℝ) / 1000000000000) = ((3069721242423 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_648 : RB (Real.log ((295391266239 : ℝ) / 200000000000)) ((389983437231 : ℝ) / 1000000000000) ((389983437233 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((295391266239 : ℝ) / 400000000000)) (t := ((-104608733761 : ℝ) / 695391266239))
    (lo := ((-9473866979 : ℝ) / 31250000000)) (hi := ((-303163743327 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((295391266239 : ℝ) / 200000000000) = Real.log ((295391266239 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((295391266239 : ℝ) / 200000000000) = ((295391266239 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_649 : RB (Real.log ((1114434999999 : ℝ) / 1000000000000)) ((13543443753 : ℝ) / 125000000000) ((4333902001 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((1114434999999 : ℝ) / 1000000000000)) (t := ((114434999999 : ℝ) / 2114434999999))
    (lo := ((13543443753 : ℝ) / 125000000000)) (hi := ((4333902001 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_650 : RB (Real.log ((1784937 : ℝ) / 1600000)) ((21875898249 : ℝ) / 200000000000) ((54689745623 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1784937 : ℝ) / 1600000)) (t := ((184937 : ℝ) / 3384937))
    (lo := ((21875898249 : ℝ) / 200000000000)) (hi := ((54689745623 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_651 : RB (Real.log ((114434999999 : ℝ) / 1000000000000)) ((-2167748302781 : ℝ) / 1000000000000) ((-2167748302779 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((114434999999 : ℝ) / 125000000000)) (t := ((-10565000001 : ℝ) / 239434999999))
    (lo := ((-88306761101 : ℝ) / 1000000000000)) (hi := ((-883067611 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114434999999 : ℝ) / 1000000000000) = Real.log ((114434999999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((114434999999 : ℝ) / 1000000000000) = ((114434999999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_652 : RB (Real.log ((184937 : ℝ) / 1600000)) ((-269717960211 : ℝ) / 125000000000) ((-1078871840843 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((184937 : ℝ) / 200000)) (t := ((-15063 : ℝ) / 384937))
    (lo := ((-9787767501 : ℝ) / 125000000000)) (hi := ((-78302140007 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((184937 : ℝ) / 1600000) = Real.log ((184937 : ℝ) / 200000) - 3 * Real.log 2 := by
    rw [show ((184937 : ℝ) / 1600000) = ((184937 : ℝ) / 200000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_653 : RB (Real.log ((168670665353 : ℝ) / 500000000000)) ((-1086660010459 : ℝ) / 1000000000000) ((-543330005227 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((168670665353 : ℝ) / 250000000000)) (t := ((-81329334647 : ℝ) / 418670665353))
    (lo := ((-393512829899 : ℝ) / 1000000000000)) (hi := ((-78702565979 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((168670665353 : ℝ) / 500000000000) = Real.log ((168670665353 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((168670665353 : ℝ) / 500000000000) = ((168670665353 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_654 : RB (Real.log ((168850037149 : ℝ) / 500000000000)) ((-1085597131581 : ℝ) / 1000000000000) ((-135699641447 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((168850037149 : ℝ) / 250000000000)) (t := ((-81149962851 : ℝ) / 418850037149))
    (lo := ((-392449951021 : ℝ) / 1000000000000)) (hi := ((-392449951017 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((168850037149 : ℝ) / 500000000000) = Real.log ((168850037149 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((168850037149 : ℝ) / 500000000000) = ((168850037149 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_655 : RB (Real.log ((32779717429 : ℝ) / 125000000000)) ((-5354015137 : ℝ) / 4000000000) ((-167312973031 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((32779717429 : ℝ) / 31250000000)) (t := ((1529717429 : ℝ) / 64029717429))
    (lo := ((4779057687 : ℝ) / 100000000000)) (hi := ((47790576871 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32779717429 : ℝ) / 125000000000) = Real.log ((32779717429 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((32779717429 : ℝ) / 125000000000) = ((32779717429 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_656 : RB (Real.log ((383012571199 : ℝ) / 125000000000)) ((139969259289 : ℝ) / 125000000000) ((559877037157 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((383012571199 : ℝ) / 500000000000)) (t := ((-116987428801 : ℝ) / 883012571199))
    (lo := ((-266540286807 : ℝ) / 1000000000000)) (hi := ((-133270143403 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((383012571199 : ℝ) / 125000000000) = Real.log ((383012571199 : ℝ) / 500000000000) + 2 * Real.log 2 := by
    rw [show ((383012571199 : ℝ) / 125000000000) = ((383012571199 : ℝ) / 500000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_657 : RB (Real.log ((3064654267317 : ℝ) / 1000000000000)) ((559967381401 : ℝ) / 500000000000) ((279983690701 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3064654267317 : ℝ) / 4000000000000)) (t := ((-935345732683 : ℝ) / 7064654267317))
    (lo := ((-266359598317 : ℝ) / 1000000000000)) (hi := ((-66589899579 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3064654267317 : ℝ) / 1000000000000) = Real.log ((3064654267317 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3064654267317 : ℝ) / 1000000000000) = ((3064654267317 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_658 : RB (Real.log ((738999973603 : ℝ) / 500000000000)) ((78137957361 : ℝ) / 200000000000) ((390689786807 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((738999973603 : ℝ) / 1000000000000)) (t := ((-261000026397 : ℝ) / 1738999973603))
    (lo := ((-151228696877 : ℝ) / 500000000000)) (hi := ((-302457393753 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((738999973603 : ℝ) / 500000000000) = Real.log ((738999973603 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((738999973603 : ℝ) / 500000000000) = ((738999973603 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_659 : RB (Real.log ((1115585624999 : ℝ) / 1000000000000)) ((27344872811 : ℝ) / 250000000000) ((21875898249 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1115585624999 : ℝ) / 1000000000000)) (t := ((115585624999 : ℝ) / 2115585624999))
    (lo := ((27344872811 : ℝ) / 250000000000)) (hi := ((21875898249 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
