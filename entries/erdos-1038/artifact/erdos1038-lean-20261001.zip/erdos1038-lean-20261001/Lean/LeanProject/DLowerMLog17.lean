import LeanProject.DLowerMTools
import LeanProject.DLowerMLog14
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_680 : RB (Real.log ((209679509673283 : ℝ) / 500000000000000)) ((-173805575572451953 : ℝ) / 200000000000000000) ((-869027877862259763 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((209679509673283 : ℝ) / 250000000000000)) (t := ((-40320490326717 : ℝ) / 459679509673283))
    (lo := ((-35176139460462891 : ℝ) / 200000000000000000)) (hi := ((-87940348651157227 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((209679509673283 : ℝ) / 500000000000000) = Real.log ((209679509673283 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((209679509673283 : ℝ) / 500000000000000) = ((209679509673283 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_681 : RB (Real.log ((419359019346569001 : ℝ) / 1000000000000000000)) ((-869027877862252609 : ℝ) / 1000000000000000000) ((-869027877862252607 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((419359019346569001 : ℝ) / 500000000000000000)) (t := ((-80640980653430999 : ℝ) / 919359019346569001))
    (lo := ((-175880697302307299 : ℝ) / 1000000000000000000)) (hi := ((-87940348651153649 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((419359019346569001 : ℝ) / 1000000000000000000) = Real.log ((419359019346569001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((419359019346569001 : ℝ) / 1000000000000000000) = ((419359019346569001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_682 : RB (Real.log ((578615980653431 : ℝ) / 1000000000000000)) ((-547116267302967721 : ℝ) / 1000000000000000000) ((-547116267302967719 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((578615980653431 : ℝ) / 500000000000000)) (t := ((78615980653431 : ℝ) / 1078615980653431))
    (lo := ((146030913256977589 : ℝ) / 1000000000000000000)) (hi := ((14603091325697759 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((578615980653431 : ℝ) / 1000000000000000) = Real.log ((578615980653431 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((578615980653431 : ℝ) / 1000000000000000) = ((578615980653431 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_683 : RB (Real.log ((289307990326717 : ℝ) / 500000000000000)) ((-68389533412870317 : ℝ) / 125000000000000000) ((-273558133651481267 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((289307990326717 : ℝ) / 250000000000000)) (t := ((39307990326717 : ℝ) / 539307990326717))
    (lo := ((73015456628491387 : ℝ) / 500000000000000000)) (hi := ((5841236530279311 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((289307990326717 : ℝ) / 500000000000000) = Real.log ((289307990326717 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((289307990326717 : ℝ) / 500000000000000) = ((289307990326717 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_684 : RB (Real.log ((210692009673283 : ℝ) / 500000000000000)) ((-21605267527418969 : ℝ) / 25000000000000000) ((-432105350548379379 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((210692009673283 : ℝ) / 250000000000000)) (t := ((-39307990326717 : ℝ) / 460692009673283))
    (lo := ((-3421270410736269 : ℝ) / 20000000000000000)) (hi := ((-171063520536813449 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((210692009673283 : ℝ) / 500000000000000) = Real.log ((210692009673283 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((210692009673283 : ℝ) / 500000000000000) = ((210692009673283 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_685 : RB (Real.log ((421384019346569 : ℝ) / 1000000000000000)) ((-864210701096751641 : ℝ) / 1000000000000000000) ((-864210701096751639 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((421384019346569 : ℝ) / 500000000000000)) (t := ((-78615980653431 : ℝ) / 921384019346569))
    (lo := ((-171063520536806331 : ℝ) / 1000000000000000000)) (hi := ((-17106352053680633 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((421384019346569 : ℝ) / 1000000000000000) = Real.log ((421384019346569 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((421384019346569 : ℝ) / 1000000000000000) = ((421384019346569 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_686 : RB (Real.log ((419359019346566001 : ℝ) / 1000000000000000000)) ((-869027877862259763 : ℝ) / 1000000000000000000) ((-869027877862259761 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((419359019346566001 : ℝ) / 500000000000000000)) (t := ((-80640980653433999 : ℝ) / 919359019346566001))
    (lo := ((-175880697302314453 : ℝ) / 1000000000000000000)) (hi := ((-43970174325578613 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((419359019346566001 : ℝ) / 1000000000000000000) = Real.log ((419359019346566001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((419359019346566001 : ℝ) / 1000000000000000000) = ((419359019346566001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_687 : RB (Real.log ((419359019346569 : ℝ) / 1000000000000000)) ((-869027877862252611 : ℝ) / 1000000000000000000) ((-869027877862252609 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((419359019346569 : ℝ) / 500000000000000)) (t := ((-80640980653431 : ℝ) / 919359019346569))
    (lo := ((-175880697302307301 : ℝ) / 1000000000000000000)) (hi := ((-1758806973023073 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((419359019346569 : ℝ) / 1000000000000000) = Real.log ((419359019346569 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((419359019346569 : ℝ) / 1000000000000000) = ((419359019346569 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_688 : RB (Real.log ((1429592022295211 : ℝ) / 1000000000000000)) ((178694552236014463 : ℝ) / 500000000000000000) ((1396051189343863 : ℝ) / 3906250000000000) := by
  have hm := log_bounds_of_series (x := ((1429592022295211 : ℝ) / 2000000000000000)) (t := ((-570407977704789 : ℝ) / 3429592022295211))
    (lo := ((-335758076087916383 : ℝ) / 1000000000000000000)) (hi := ((-167879038043958191 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1429592022295211 : ℝ) / 1000000000000000) = Real.log ((1429592022295211 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1429592022295211 : ℝ) / 1000000000000000) = ((1429592022295211 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_689 : RB (Real.log ((1429592022295214001 : ℝ) / 1000000000000000000)) ((14295564178881241 : ℝ) / 40000000000000000) ((357389104472031027 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1429592022295214001 : ℝ) / 2000000000000000000)) (t := ((-570407977704785999 : ℝ) / 3429592022295214001))
    (lo := ((-83939519021978571 : ℝ) / 250000000000000000)) (hi := ((-335758076087914283 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1429592022295214001 : ℝ) / 1000000000000000000) = Real.log ((1429592022295214001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1429592022295214001 : ℝ) / 1000000000000000000) = ((1429592022295214001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_690 : RB (Real.log ((431617022295211 : ℝ) / 1000000000000000)) ((-840216606396256769 : ℝ) / 1000000000000000000) ((-840216606396256767 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((431617022295211 : ℝ) / 500000000000000)) (t := ((-68382977704789 : ℝ) / 931617022295211))
    (lo := ((-147069425836311459 : ℝ) / 1000000000000000000)) (hi := ((-73534712918155729 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((431617022295211 : ℝ) / 1000000000000000) = Real.log ((431617022295211 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((431617022295211 : ℝ) / 1000000000000000) = ((431617022295211 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_691 : RB (Real.log ((215808511147607 : ℝ) / 500000000000000)) ((-840216606396249819 : ℝ) / 1000000000000000000) ((-840216606396249817 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((215808511147607 : ℝ) / 250000000000000)) (t := ((-34191488852393 : ℝ) / 465808511147607))
    (lo := ((-147069425836304509 : ℝ) / 1000000000000000000)) (hi := ((-36767356459076127 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((215808511147607 : ℝ) / 500000000000000) = Real.log ((215808511147607 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((215808511147607 : ℝ) / 500000000000000) = ((215808511147607 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_692 : RB (Real.log ((1431617022295211 : ℝ) / 1000000000000000)) ((358804590238045269 : ℝ) / 1000000000000000000) ((358804590238045271 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1431617022295211 : ℝ) / 2000000000000000)) (t := ((-568382977704789 : ℝ) / 3431617022295211))
    (lo := ((-8358564758047501 : ℝ) / 25000000000000000)) (hi := ((-334342590321900039 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1431617022295211 : ℝ) / 1000000000000000) = Real.log ((1431617022295211 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1431617022295211 : ℝ) / 1000000000000000) = ((1431617022295211 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_693 : RB (Real.log ((715808511147607 : ℝ) / 500000000000000)) ((89701147559511841 : ℝ) / 250000000000000000) ((179402295119023683 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((715808511147607 : ℝ) / 1000000000000000)) (t := ((-284191488852393 : ℝ) / 1715808511147607))
    (lo := ((-66868518064379589 : ℝ) / 200000000000000000)) (hi := ((-41792823790237243 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((715808511147607 : ℝ) / 500000000000000) = Real.log ((715808511147607 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((715808511147607 : ℝ) / 500000000000000) = ((715808511147607 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_694 : RB (Real.log ((1429592022295211001 : ℝ) / 1000000000000000000)) ((357389104472028927 : ℝ) / 1000000000000000000) ((357389104472028929 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1429592022295211001 : ℝ) / 2000000000000000000)) (t := ((-570407977704788999 : ℝ) / 3429592022295211001))
    (lo := ((-167879038043958191 : ℝ) / 500000000000000000)) (hi := ((-335758076087916381 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1429592022295211001 : ℝ) / 1000000000000000000) = Real.log ((1429592022295211001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1429592022295211001 : ℝ) / 1000000000000000000) = ((1429592022295211001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_695 : RB (Real.log ((714796011147607 : ℝ) / 500000000000000)) ((22336819029501939 : ℝ) / 62500000000000000) ((178694552236015513 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((714796011147607 : ℝ) / 1000000000000000)) (t := ((-285203988852393 : ℝ) / 1714796011147607))
    (lo := ((-67151615217582857 : ℝ) / 200000000000000000)) (hi := ((-83939519021978571 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((714796011147607 : ℝ) / 500000000000000) = Real.log ((714796011147607 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((714796011147607 : ℝ) / 500000000000000) = ((714796011147607 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_696 : RB (Real.log ((12674862434388401 : ℝ) / 31250000000000000)) ((-451199340033375709 : ℝ) / 500000000000000000) ((-112799835008343927 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((12674862434388401 : ℝ) / 15625000000000000)) (t := ((-2950137565611599 : ℝ) / 28299862434388401))
    (lo := ((-52312874876701527 : ℝ) / 250000000000000000)) (hi := ((-209251499506806107 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12674862434388401 : ℝ) / 31250000000000000) = Real.log ((12674862434388401 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((12674862434388401 : ℝ) / 31250000000000000) = ((12674862434388401 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_697 : RB (Real.log ((86614488158541177 : ℝ) / 200000000000000000)) ((-418425132610241249 : ℝ) / 500000000000000000) ((-13075785394070039 : ℝ) / 15625000000000000) := by
  have hm := log_bounds_of_series (x := ((86614488158541177 : ℝ) / 100000000000000000)) (t := ((-13385511841458823 : ℝ) / 186614488158541177))
    (lo := ((-35925771165134297 : ℝ) / 250000000000000000)) (hi := ((-143703084660537187 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86614488158541177 : ℝ) / 200000000000000000) = Real.log ((86614488158541177 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((86614488158541177 : ℝ) / 200000000000000000) = ((86614488158541177 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_698 : RB (Real.log ((141331889801823529 : ℝ) / 250000000000000000)) ((-142587491254225291 : ℝ) / 250000000000000000) ((-285174982508450581 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((141331889801823529 : ℝ) / 125000000000000000)) (t := ((16331889801823529 : ℝ) / 266331889801823529))
    (lo := ((61398607771522073 : ℝ) / 500000000000000000)) (hi := ((122797215543044147 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141331889801823529 : ℝ) / 250000000000000000) = Real.log ((141331889801823529 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((141331889801823529 : ℝ) / 250000000000000000) = ((141331889801823529 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_699 : RB (Real.log ((591904402099571167 : ℝ) / 1000000000000000000)) ((-524410140077818701 : ℝ) / 1000000000000000000) ((-524410140077818699 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((591904402099571167 : ℝ) / 500000000000000000)) (t := ((91904402099571167 : ℝ) / 1091904402099571167))
    (lo := ((168737040482126609 : ℝ) / 1000000000000000000)) (hi := ((16873704048212661 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((591904402099571167 : ℝ) / 1000000000000000000) = Real.log ((591904402099571167 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((591904402099571167 : ℝ) / 1000000000000000000) = ((591904402099571167 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_700 : RB (Real.log ((408095597900428833 : ℝ) / 1000000000000000000)) ((-179250764688892199 : ℝ) / 200000000000000000) ((-896253823444460993 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((408095597900428833 : ℝ) / 500000000000000000)) (t := ((-91904402099571167 : ℝ) / 908095597900428833))
    (lo := ((-40621328576903137 : ℝ) / 200000000000000000)) (hi := ((-50776660721128921 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((408095597900428833 : ℝ) / 1000000000000000000) = Real.log ((408095597900428833 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((408095597900428833 : ℝ) / 1000000000000000000) = ((408095597900428833 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_701 : RB (Real.log ((108668110198176471 : ℝ) / 250000000000000000)) ((-166632508243916329 : ℝ) / 200000000000000000) ((-833162541219581643 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((108668110198176471 : ℝ) / 125000000000000000)) (t := ((-16331889801823529 : ℝ) / 233668110198176471))
    (lo := ((-28003072131927267 : ℝ) / 200000000000000000)) (hi := ((-70007680329818167 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((108668110198176471 : ℝ) / 250000000000000000) = Real.log ((108668110198176471 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((108668110198176471 : ℝ) / 250000000000000000) = ((108668110198176471 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_702 : RB (Real.log ((406070597900428833 : ℝ) / 1000000000000000000)) ((-180245649608528669 : ℝ) / 200000000000000000) ((-901228248042643343 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((406070597900428833 : ℝ) / 500000000000000000)) (t := ((-93929402099571167 : ℝ) / 906070597900428833))
    (lo := ((-41616213496539607 : ℝ) / 200000000000000000)) (hi := ((-104040533741349017 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((406070597900428833 : ℝ) / 1000000000000000000) = Real.log ((406070597900428833 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((406070597900428833 : ℝ) / 1000000000000000000) = ((406070597900428833 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_703 : RB (Real.log ((203035298950214417 : ℝ) / 500000000000000000)) ((-901228248042643343 : ℝ) / 1000000000000000000) ((-901228248042643341 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((203035298950214417 : ℝ) / 250000000000000000)) (t := ((-46964701049785583 : ℝ) / 453035298950214417))
    (lo := ((-208081067482698033 : ℝ) / 1000000000000000000)) (hi := ((-13005066717668627 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((203035298950214417 : ℝ) / 500000000000000000) = Real.log ((203035298950214417 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((203035298950214417 : ℝ) / 500000000000000000) = ((203035298950214417 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_704 : RB (Real.log ((203247798950214417 : ℝ) / 500000000000000000)) ((-36007287173045863 : ℝ) / 40000000000000000) ((-900182179326146573 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((203247798950214417 : ℝ) / 250000000000000000)) (t := ((-46752201049785583 : ℝ) / 453247798950214417))
    (lo := ((-41406999753240253 : ℝ) / 200000000000000000)) (hi := ((-12939687422887579 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((203247798950214417 : ℝ) / 500000000000000000) = Real.log ((203247798950214417 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((203247798950214417 : ℝ) / 500000000000000000) = ((203247798950214417 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_705 : RB (Real.log ((108161860198176471 : ℝ) / 250000000000000000)) ((-52364506696104457 : ℝ) / 62500000000000000) ((-83783210713767131 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((108161860198176471 : ℝ) / 125000000000000000)) (t := ((-16838139801823529 : ℝ) / 233161860198176471))
    (lo := ((-72342463288863001 : ℝ) / 500000000000000000)) (hi := ((-144684926577726001 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((108161860198176471 : ℝ) / 250000000000000000) = Real.log ((108161860198176471 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((108161860198176471 : ℝ) / 250000000000000000) = ((108161860198176471 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_706 : RB (Real.log ((86529488158541177 : ℝ) / 200000000000000000)) ((-83783210713767131 : ℝ) / 100000000000000000) ((-209458026784417827 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((86529488158541177 : ℝ) / 100000000000000000)) (t := ((-13470511841458823 : ℝ) / 186529488158541177))
    (lo := ((-72342463288863 : ℝ) / 500000000000000)) (hi := ((-144684926577725999 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86529488158541177 : ℝ) / 200000000000000000) = Real.log ((86529488158541177 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((86529488158541177 : ℝ) / 200000000000000000) = ((86529488158541177 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_707 : RB (Real.log ((432172440792705883 : ℝ) / 1000000000000000000)) ((-209732650470736219 : ℝ) / 250000000000000000) ((-419465300941472437 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((432172440792705883 : ℝ) / 500000000000000000)) (t := ((-67827559207294117 : ℝ) / 932172440792705883))
    (lo := ((-72891710661499783 : ℝ) / 500000000000000000)) (hi := ((-29156684264599913 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((432172440792705883 : ℝ) / 1000000000000000000) = Real.log ((432172440792705883 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((432172440792705883 : ℝ) / 1000000000000000000) = ((432172440792705883 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_708 : RB (Real.log ((284663905357471531 : ℝ) / 200000000000000000)) ((88247959593994827 : ℝ) / 250000000000000000) ((35299183837597931 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((284663905357471531 : ℝ) / 400000000000000000)) (t := ((-115336094642528469 : ℝ) / 684663905357471531))
    (lo := ((-340155342183966001 : ℝ) / 1000000000000000000)) (hi := ((-170077671091983 : ℝ) / 500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284663905357471531 : ℝ) / 200000000000000000) = Real.log ((284663905357471531 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284663905357471531 : ℝ) / 200000000000000000) = ((284663905357471531 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_709 : RB (Real.log ((1435814517803068277 : ℝ) / 1000000000000000000)) ((361732296408101729 : ℝ) / 1000000000000000000) ((361732296408101731 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1435814517803068277 : ℝ) / 2000000000000000000)) (t := ((-564185482196931723 : ℝ) / 3435814517803068277))
    (lo := ((-16570744207592179 : ℝ) / 50000000000000000)) (hi := ((-331414884151843579 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1435814517803068277 : ℝ) / 1000000000000000000) = Real.log ((1435814517803068277 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1435814517803068277 : ℝ) / 1000000000000000000) = ((1435814517803068277 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_710 : RB (Real.log ((53227440848419707 : ℝ) / 125000000000000000)) ((-853739668515169191 : ℝ) / 1000000000000000000) ((-853739668515169189 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((53227440848419707 : ℝ) / 62500000000000000)) (t := ((-9272559151580293 : ℝ) / 115727440848419707))
    (lo := ((-160592487955223881 : ℝ) / 1000000000000000000)) (hi := ((-4014812198880597 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53227440848419707 : ℝ) / 125000000000000000) = Real.log ((53227440848419707 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((53227440848419707 : ℝ) / 125000000000000000) = ((53227440848419707 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_711 : RB (Real.log ((109353629450767069 : ℝ) / 250000000000000000)) ((-826873980153867357 : ℝ) / 1000000000000000000) ((-165374796030773471 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((109353629450767069 : ℝ) / 125000000000000000)) (t := ((-15646370549232931 : ℝ) / 234353629450767069))
    (lo := ((-133726799593922047 : ℝ) / 1000000000000000000)) (hi := ((-66863399796961023 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((109353629450767069 : ℝ) / 250000000000000000) = Real.log ((109353629450767069 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((109353629450767069 : ℝ) / 250000000000000000) = ((109353629450767069 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_712 : RB (Real.log ((178227440848419707 : ℝ) / 125000000000000000)) ((354746754927682293 : ℝ) / 1000000000000000000) ((70949350985536459 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((178227440848419707 : ℝ) / 250000000000000000)) (t := ((-71772559151580293 : ℝ) / 428227440848419707))
    (lo := ((-42300053204032877 : ℝ) / 125000000000000000)) (hi := ((-67680085126452603 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178227440848419707 : ℝ) / 125000000000000000) = Real.log ((178227440848419707 : ℝ) / 250000000000000000) + 1 * Real.log 2 := by
    rw [show ((178227440848419707 : ℝ) / 125000000000000000) = ((178227440848419707 : ℝ) / 250000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_713 : RB (Real.log ((359353629450767069 : ℝ) / 250000000000000000)) ((181423013022538363 : ℝ) / 500000000000000000) ((45355753255634591 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((359353629450767069 : ℝ) / 500000000000000000)) (t := ((-140646370549232931 : ℝ) / 859353629450767069))
    (lo := ((-330301154514868583 : ℝ) / 1000000000000000000)) (hi := ((-165150577257434291 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((359353629450767069 : ℝ) / 250000000000000000) = Real.log ((359353629450767069 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((359353629450767069 : ℝ) / 250000000000000000) = ((359353629450767069 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_714 : RB (Real.log ((177974315848419707 : ℝ) / 125000000000000000)) ((70665101918428679 : ℝ) / 200000000000000000) ((353325509592143397 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((177974315848419707 : ℝ) / 250000000000000000)) (t := ((-72025684151580293 : ℝ) / 427974315848419707))
    (lo := ((-169910835483900957 : ℝ) / 500000000000000000)) (hi := ((-339821670967801913 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((177974315848419707 : ℝ) / 125000000000000000) = Real.log ((177974315848419707 : ℝ) / 250000000000000000) + 1 * Real.log 2 := by
    rw [show ((177974315848419707 : ℝ) / 125000000000000000) = ((177974315848419707 : ℝ) / 250000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_715 : RB (Real.log ((1423794526787357657 : ℝ) / 1000000000000000000)) ((88331377398035849 : ℝ) / 250000000000000000) ((176662754796071699 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1423794526787357657 : ℝ) / 2000000000000000000)) (t := ((-576205473212642343 : ℝ) / 3423794526787357657))
    (lo := ((-339821670967801913 : ℝ) / 1000000000000000000)) (hi := ((-42477708870975239 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1423794526787357657 : ℝ) / 1000000000000000000) = Real.log ((1423794526787357657 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1423794526787357657 : ℝ) / 1000000000000000000) = ((1423794526787357657 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_716 : RB (Real.log ((1424219526787357657 : ℝ) / 1000000000000000000)) ((88405990794451727 : ℝ) / 250000000000000000) ((35362396317780691 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424219526787357657 : ℝ) / 2000000000000000000)) (t := ((-575780473212642343 : ℝ) / 3424219526787357657))
    (lo := ((-339523217382138401 : ℝ) / 1000000000000000000)) (hi := ((-424404021727673 : ℝ) / 1250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424219526787357657 : ℝ) / 1000000000000000000) = Real.log ((1424219526787357657 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424219526787357657 : ℝ) / 1000000000000000000) = ((1424219526787357657 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_717 : RB (Real.log ((358847379450767069 : ℝ) / 250000000000000000)) ((36143625335589541 : ℝ) / 100000000000000000) ((90359063338973853 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((358847379450767069 : ℝ) / 500000000000000000)) (t := ((-141152620549232931 : ℝ) / 858847379450767069))
    (lo := ((-331710927204049899 : ℝ) / 1000000000000000000)) (hi := ((-165855463602024949 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((358847379450767069 : ℝ) / 250000000000000000) = Real.log ((358847379450767069 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((358847379450767069 : ℝ) / 250000000000000000) = ((358847379450767069 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_718 : RB (Real.log ((1435389517803068277 : ℝ) / 1000000000000000000)) ((36143625335589541 : ℝ) / 100000000000000000) ((90359063338973853 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1435389517803068277 : ℝ) / 2000000000000000000)) (t := ((-564610482196931723 : ℝ) / 3435389517803068277))
    (lo := ((-331710927204049899 : ℝ) / 1000000000000000000)) (hi := ((-165855463602024949 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1435389517803068277 : ℝ) / 1000000000000000000) = Real.log ((1435389517803068277 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1435389517803068277 : ℝ) / 1000000000000000000) = ((1435389517803068277 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_719 : RB (Real.log ((57396580712122731 : ℝ) / 40000000000000000)) ((45138159745254879 : ℝ) / 125000000000000000) ((180552638981019517 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((57396580712122731 : ℝ) / 80000000000000000)) (t := ((-22603419287877269 : ℝ) / 137396580712122731))
    (lo := ((-332041902597906277 : ℝ) / 1000000000000000000)) (hi := ((-83010475649476569 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57396580712122731 : ℝ) / 40000000000000000) = Real.log ((57396580712122731 : ℝ) / 80000000000000000) + 1 * Real.log 2 := by
    rw [show ((57396580712122731 : ℝ) / 40000000000000000) = ((57396580712122731 : ℝ) / 80000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
