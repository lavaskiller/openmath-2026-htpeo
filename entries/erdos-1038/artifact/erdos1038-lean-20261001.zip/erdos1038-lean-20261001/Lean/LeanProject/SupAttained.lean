import LeanProject.Bridge
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic

/-!
# EP-1038: the supremum is attained (Stage 15, eighth batch)

proof.md Theorem 6.7, converse: for `m ≥ 1`, `|{x : |(x^2 - 1)^m| < 1}| = 2√2`
(Lebesgue measure). Together with the (not yet formalised) upper bound `|S_f| ≤ 2√2`, this shows
the supremum is attained by `(x^2 - 1)^m`.
-/

open Real Polynomial MeasureTheory

namespace EP1038

theorem sublevel_sq_sub_one (m : ℕ) (hm : 1 ≤ m) :
    {x : ℝ | |((X ^ 2 - 1 : ℝ[X]) ^ m).eval x| < 1} = Set.Ioo (-√2) 0 ∪ Set.Ioo 0 √2 := by
  have hs2 : √2 * √2 = 2 := Real.mul_self_sqrt (by norm_num)
  have hs0 : 0 < √2 := by positivity
  ext x
  simp only [Set.mem_setOf_eq, eval_pow, eval_sub, eval_X, eval_one, abs_pow, Set.mem_union,
    Set.mem_Ioo]
  rw [pow_lt_one_iff_of_nonneg (abs_nonneg _) (by omega), abs_lt]
  constructor
  · rintro ⟨h1, h2⟩
    have hx0 : x ≠ 0 := by rintro rfl; norm_num at h1
    have hx2 : x ^ 2 < 2 := by linarith
    have hlt : |x| < √2 := by
      rw [← Real.sqrt_sq_eq_abs]; exact Real.sqrt_lt_sqrt (sq_nonneg _) hx2
    rw [abs_lt] at hlt
    rcases lt_or_gt_of_ne hx0 with h | h
    · left; exact ⟨hlt.1, h⟩
    · right; exact ⟨h, hlt.2⟩
  · rintro (⟨h1, h2⟩ | ⟨h1, h2⟩)
    · constructor
      · nlinarith
      · nlinarith
    · constructor
      · nlinarith
      · nlinarith

theorem volume_sublevel_sq_sub_one (m : ℕ) (hm : 1 ≤ m) :
    volume {x : ℝ | |((X ^ 2 - 1 : ℝ[X]) ^ m).eval x| < 1} = ENNReal.ofReal (2 * √2) := by
  rw [sublevel_sq_sub_one m hm]
  have hdisj : Disjoint (Set.Ioo (-√2) 0) (Set.Ioo 0 √2) := by
    rw [Set.disjoint_left]
    rintro x ⟨_, hx⟩ ⟨hx', _⟩
    linarith
  rw [measure_union hdisj measurableSet_Ioo, Real.volume_Ioo, Real.volume_Ioo,
    ← ENNReal.ofReal_add (by simp [Real.sqrt_nonneg]) (by simp [Real.sqrt_nonneg])]
  congr 1
  ring

end EP1038
