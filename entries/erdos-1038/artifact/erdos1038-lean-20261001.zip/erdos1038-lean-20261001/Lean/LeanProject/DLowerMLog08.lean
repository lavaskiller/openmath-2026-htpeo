import LeanProject.DLowerMTools
import LeanProject.DLowerMLog05
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_320 : RB (Real.log ((114652609884216903 : ℝ) / 250000000000000000)) ((-779554144890546271 : ℝ) / 1000000000000000000) ((-779554144890546269 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((114652609884216903 : ℝ) / 125000000000000000)) (t := ((-10347390115783097 : ℝ) / 239652609884216903))
    (lo := ((-86406964330600961 : ℝ) / 1000000000000000000)) (hi := ((-33752720441641 : ℝ) / 390625000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114652609884216903 : ℝ) / 250000000000000000) = Real.log ((114652609884216903 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((114652609884216903 : ℝ) / 250000000000000000) = ((114652609884216903 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_321 : RB (Real.log ((458697945887579687 : ℝ) / 1000000000000000000)) ((-389681677753184907 : ℝ) / 500000000000000000) ((-194840838876592453 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((458697945887579687 : ℝ) / 500000000000000000)) (t := ((-41302054112420313 : ℝ) / 958697945887579687))
    (lo := ((-10777021868303063 : ℝ) / 125000000000000000)) (hi := ((-86216174946424503 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458697945887579687 : ℝ) / 1000000000000000000) = Real.log ((458697945887579687 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458697945887579687 : ℝ) / 1000000000000000000) = ((458697945887579687 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_322 : RB (Real.log ((57337243235947461 : ℝ) / 125000000000000000)) ((-779363355506369811 : ℝ) / 1000000000000000000) ((-779363355506369809 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((57337243235947461 : ℝ) / 62500000000000000)) (t := ((-5162756764052539 : ℝ) / 119837243235947461))
    (lo := ((-86216174946424501 : ℝ) / 1000000000000000000)) (hi := ((-172432349892849 : ℝ) / 2000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57337243235947461 : ℝ) / 125000000000000000) = Real.log ((57337243235947461 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57337243235947461 : ℝ) / 125000000000000000) = ((57337243235947461 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_323 : RB (Real.log ((91739388142970039 : ℝ) / 200000000000000000)) ((-97420693358705031 : ℝ) / 125000000000000000) ((-389682773434820123 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((91739388142970039 : ℝ) / 100000000000000000)) (t := ((-8260611857029961 : ℝ) / 191739388142970039))
    (lo := ((-43109183154847469 : ℝ) / 500000000000000000)) (hi := ((-86218366309694937 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91739388142970039 : ℝ) / 200000000000000000) = Real.log ((91739388142970039 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((91739388142970039 : ℝ) / 200000000000000000) = ((91739388142970039 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_324 : RB (Real.log ((1424633849935284971 : ℝ) / 1000000000000000000)) ((176957416645068093 : ℝ) / 500000000000000000) ((88478708322534047 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424633849935284971 : ℝ) / 2000000000000000000)) (t := ((-575366150064715029 : ℝ) / 3424633849935284971))
    (lo := ((-339232347269809123 : ℝ) / 1000000000000000000)) (hi := ((-169616173634904561 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424633849935284971 : ℝ) / 1000000000000000000) = Real.log ((1424633849935284971 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424633849935284971 : ℝ) / 1000000000000000000) = ((1424633849935284971 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_325 : RB (Real.log ((178080402898467853 : ℝ) / 125000000000000000)) ((353921412680077799 : ℝ) / 1000000000000000000) ((353921412680077801 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((178080402898467853 : ℝ) / 250000000000000000)) (t := ((-71919597101532147 : ℝ) / 428080402898467853))
    (lo := ((-33922576787986751 : ℝ) / 100000000000000000)) (hi := ((-339225767879867509 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178080402898467853 : ℝ) / 125000000000000000) = Real.log ((178080402898467853 : ℝ) / 250000000000000000) + 1 * Real.log 2 := by
    rw [show ((178080402898467853 : ℝ) / 125000000000000000) = ((178080402898467853 : ℝ) / 250000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_326 : RB (Real.log ((26581031884535633 : ℝ) / 62500000000000000)) ((-170993736473947 : ℝ) / 200000000000000) ((-427484341184867499 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((26581031884535633 : ℝ) / 31250000000000000)) (t := ((-4668968115464367 : ℝ) / 57831031884535633))
    (lo := ((-16182150180978969 : ℝ) / 100000000000000000)) (hi := ((-161821501809789689 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((26581031884535633 : ℝ) / 62500000000000000) = Real.log ((26581031884535633 : ℝ) / 31250000000000000) - 1 * Real.log 2 := by
    rw [show ((26581031884535633 : ℝ) / 62500000000000000) = ((26581031884535633 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_327 : RB (Real.log ((13290746056953389 : ℝ) / 31250000000000000)) ((-427475684158516193 : ℝ) / 500000000000000000) ((-13358615129953631 : ℝ) / 15625000000000000) := by
  have hm := log_bounds_of_series (x := ((13290746056953389 : ℝ) / 15625000000000000)) (t := ((-2334253943046611 : ℝ) / 28915746056953389))
    (lo := ((-40451046939271769 : ℝ) / 250000000000000000)) (hi := ((-6472167510283483 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13290746056953389 : ℝ) / 31250000000000000) = Real.log ((13290746056953389 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((13290746056953389 : ℝ) / 31250000000000000) = ((13290746056953389 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_328 : RB (Real.log ((89081031884535633 : ℝ) / 62500000000000000)) ((354379869375584177 : ℝ) / 1000000000000000000) ((354379869375584179 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((89081031884535633 : ℝ) / 125000000000000000)) (t := ((-35918968115464367 : ℝ) / 214081031884535633))
    (lo := ((-84691827796090283 : ℝ) / 250000000000000000)) (hi := ((-338767311184361131 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89081031884535633 : ℝ) / 62500000000000000) = Real.log ((89081031884535633 : ℝ) / 125000000000000000) + 1 * Real.log 2 := by
    rw [show ((89081031884535633 : ℝ) / 62500000000000000) = ((89081031884535633 : ℝ) / 125000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_329 : RB (Real.log ((44540746056953389 : ℝ) / 31250000000000000)) ((354385035774901129 : ℝ) / 1000000000000000000) ((354385035774901131 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((44540746056953389 : ℝ) / 62500000000000000)) (t := ((-17959253943046611 : ℝ) / 107040746056953389))
    (lo := ((-16938107239252209 : ℝ) / 50000000000000000)) (hi := ((-338762144785044179 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44540746056953389 : ℝ) / 31250000000000000) = Real.log ((44540746056953389 : ℝ) / 62500000000000000) + 1 * Real.log 2 := by
    rw [show ((44540746056953389 : ℝ) / 31250000000000000) = ((44540746056953389 : ℝ) / 62500000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_330 : RB (Real.log ((1424634855108014463 : ℝ) / 1000000000000000000)) ((353915538855552121 : ℝ) / 1000000000000000000) ((353915538855552123 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424634855108014463 : ℝ) / 2000000000000000000)) (t := ((-575365144891985537 : ℝ) / 3424634855108014463))
    (lo := ((-84807910426098297 : ℝ) / 250000000000000000)) (hi := ((-339231641704393187 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424634855108014463 : ℝ) / 1000000000000000000) = Real.log ((1424634855108014463 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424634855108014463 : ℝ) / 1000000000000000000) = ((1424634855108014463 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_331 : RB (Real.log ((11129959805531363 : ℝ) / 7812500000000000)) ((176957769427776061 : ℝ) / 500000000000000000) ((88478884713888031 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((11129959805531363 : ℝ) / 15625000000000000)) (t := ((-4495040194468637 : ℝ) / 26754959805531363))
    (lo := ((-339231641704393187 : ℝ) / 1000000000000000000)) (hi := ((-169615820852196593 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11129959805531363 : ℝ) / 7812500000000000) = Real.log ((11129959805531363 : ℝ) / 15625000000000000) + 1 * Real.log 2 := by
    rw [show ((11129959805531363 : ℝ) / 7812500000000000) = ((11129959805531363 : ℝ) / 15625000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_332 : RB (Real.log ((178079482439725563 : ℝ) / 125000000000000000)) ((353916243884937279 : ℝ) / 1000000000000000000) ((353916243884937281 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((178079482439725563 : ℝ) / 250000000000000000)) (t := ((-71920517560274437 : ℝ) / 428079482439725563))
    (lo := ((-33923093667500803 : ℝ) / 100000000000000000)) (hi := ((-339230936675008029 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178079482439725563 : ℝ) / 125000000000000000) = Real.log ((178079482439725563 : ℝ) / 250000000000000000) + 1 * Real.log 2 := by
    rw [show ((178079482439725563 : ℝ) / 125000000000000000) = ((178079482439725563 : ℝ) / 250000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_333 : RB (Real.log ((1424642218777952783 : ℝ) / 1000000000000000000)) ((70784141530867357 : ℝ) / 200000000000000000) ((353920707654336787 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424642218777952783 : ℝ) / 2000000000000000000)) (t := ((-575357781222047217 : ℝ) / 3424642218777952783))
    (lo := ((-84806618226402131 : ℝ) / 250000000000000000)) (hi := ((-339226472905608523 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424642218777952783 : ℝ) / 1000000000000000000) = Real.log ((1424642218777952783 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424642218777952783 : ℝ) / 1000000000000000000) = ((1424642218777952783 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_334 : RB (Real.log ((89040138673622049 : ℝ) / 62500000000000000)) ((176960353827168393 : ℝ) / 500000000000000000) ((88480176913584197 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((89040138673622049 : ℝ) / 125000000000000000)) (t := ((-35959861326377951 : ℝ) / 214040138673622049))
    (lo := ((-339226472905608523 : ℝ) / 1000000000000000000)) (hi := ((-169613236452804261 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89040138673622049 : ℝ) / 62500000000000000) = Real.log ((89040138673622049 : ℝ) / 125000000000000000) + 1 * Real.log 2 := by
    rw [show ((89040138673622049 : ℝ) / 62500000000000000) = ((89040138673622049 : ℝ) / 125000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_335 : RB (Real.log ((1424641213605223291 : ℝ) / 1000000000000000000)) ((44240000261570971 : ℝ) / 125000000000000000) ((35392000209256777 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424641213605223291 : ℝ) / 2000000000000000000)) (t := ((-575358786394776709 : ℝ) / 3424641213605223291))
    (lo := ((-339227178467377541 : ℝ) / 1000000000000000000)) (hi := ((-16961358923368877 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424641213605223291 : ℝ) / 1000000000000000000) = Real.log ((1424641213605223291 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424641213605223291 : ℝ) / 1000000000000000000) = ((1424641213605223291 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_336 : RB (Real.log ((25761718749999999 : ℝ) / 1000000000000000000)) ((-1829432829155142297 : ℝ) / 500000000000000000) ((-228679103644392787 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((25761718749999999 : ℝ) / 31250000000000000)) (t := ((-5488281250000001 : ℝ) / 57011718749999999))
    (lo := ((-96564877755279023 : ℝ) / 500000000000000000)) (hi := ((-38625951102111609 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25761718749999999 : ℝ) / 1000000000000000000) = Real.log ((25761718749999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25761718749999999 : ℝ) / 1000000000000000000) = ((25761718749999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_337 : RB (Real.log ((1319 : ℝ) / 51200)) ((-914716414577571139 : ℝ) / 250000000000000000) ((-1829432829155142277 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1319 : ℝ) / 1600)) (t := ((-281 : ℝ) / 2919))
    (lo := ((-24141219438819751 : ℝ) / 125000000000000000)) (hi := ((-193129755510558007 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1319 : ℝ) / 51200) = Real.log ((1319 : ℝ) / 1600) - 5 * Real.log 2 := by
    rw [show ((1319 : ℝ) / 51200) = ((1319 : ℝ) / 1600) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_338 : RB (Real.log ((1025761718749999999 : ℝ) / 1000000000000000000)) ((5087095368457651 : ℝ) / 200000000000000000) ((198714662830377 : ℝ) / 7812500000000000) := by
  have hm := log_bounds_of_series (x := ((1025761718749999999 : ℝ) / 1000000000000000000)) (t := ((25761718749999999 : ℝ) / 2025761718749999999))
    (lo := ((5087095368457651 : ℝ) / 200000000000000000)) (hi := ((198714662830377 : ℝ) / 7812500000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_339 : RB (Real.log ((52519 : ℝ) / 51200)) ((198714662830377 : ℝ) / 7812500000000000) ((25435476842288257 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((52519 : ℝ) / 51200)) (t := ((1319 : ℝ) / 103719))
    (lo := ((198714662830377 : ℝ) / 7812500000000000)) (hi := ((25435476842288257 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_340 : RB (Real.log ((25742187499999999 : ℝ) / 1000000000000000000)) ((-457453011995643333 : ℝ) / 125000000000000000) ((-1829812047982573331 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((25742187499999999 : ℝ) / 31250000000000000)) (t := ((-5507812500000001 : ℝ) / 56992187499999999))
    (lo := ((-48472048291355029 : ℝ) / 250000000000000000)) (hi := ((-38777638633084023 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25742187499999999 : ℝ) / 1000000000000000000) = Real.log ((25742187499999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25742187499999999 : ℝ) / 1000000000000000000) = ((25742187499999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_341 : RB (Real.log ((33 : ℝ) / 1280)) ((-457263474430897827 : ℝ) / 125000000000000000) ((-1829053897723591307 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((33 : ℝ) / 40)) (t := ((-7 : ℝ) / 73))
    (lo := ((-48092973161864017 : ℝ) / 250000000000000000)) (hi := ((-192371892647456067 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33 : ℝ) / 1280) = Real.log ((33 : ℝ) / 40) - 5 * Real.log 2 := by
    rw [show ((33 : ℝ) / 1280) = ((33 : ℝ) / 40) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_342 : RB (Real.log ((1025742187499999999 : ℝ) / 1000000000000000000)) ((25416435932893847 : ℝ) / 1000000000000000000) ((3177054491611731 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025742187499999999 : ℝ) / 1000000000000000000)) (t := ((25742187499999999 : ℝ) / 2025742187499999999))
    (lo := ((25416435932893847 : ℝ) / 1000000000000000000)) (hi := ((3177054491611731 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_343 : RB (Real.log ((1313 : ℝ) / 1280)) ((3181814673641667 : ℝ) / 125000000000000000) ((25454517389133337 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1313 : ℝ) / 1280)) (t := ((33 : ℝ) / 2593))
    (lo := ((3181814673641667 : ℝ) / 125000000000000000)) (hi := ((25454517389133337 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_344 : RB (Real.log ((229290429305209449 : ℝ) / 500000000000000000)) ((-155923729635373981 : ℝ) / 200000000000000000) ((-779618648176869903 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229290429305209449 : ℝ) / 250000000000000000)) (t := ((-20709570694790551 : ℝ) / 479290429305209449))
    (lo := ((-17294293523384919 : ℝ) / 200000000000000000)) (hi := ((-43235733808462297 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229290429305209449 : ℝ) / 500000000000000000) = Real.log ((229290429305209449 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229290429305209449 : ℝ) / 500000000000000000) = ((229290429305209449 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_345 : RB (Real.log ((458580858610421899 : ℝ) / 1000000000000000000)) ((-779618648176863361 : ℝ) / 1000000000000000000) ((-779618648176863359 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458580858610421899 : ℝ) / 500000000000000000)) (t := ((-41419141389578101 : ℝ) / 958580858610421899))
    (lo := ((-86471467616918051 : ℝ) / 1000000000000000000)) (hi := ((-1729429352338361 : ℝ) / 20000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458580858610421899 : ℝ) / 1000000000000000000) = Real.log ((458580858610421899 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458580858610421899 : ℝ) / 1000000000000000000) = ((458580858610421899 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_346 : RB (Real.log ((33797217202289 : ℝ) / 62500000000000)) ((-61478808893601453 : ℝ) / 100000000000000000) ((-9606063889625227 : ℝ) / 15625000000000000) := by
  have hm := log_bounds_of_series (x := ((33797217202289 : ℝ) / 31250000000000)) (t := ((2547217202289 : ℝ) / 65047217202289))
    (lo := ((3917954581196539 : ℝ) / 50000000000000000)) (hi := ((78359091623930781 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33797217202289 : ℝ) / 62500000000000) = Real.log ((33797217202289 : ℝ) / 31250000000000) - 1 * Real.log 2 := by
    rw [show ((33797217202289 : ℝ) / 62500000000000) = ((33797217202289 : ℝ) / 31250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_347 : RB (Real.log ((540755475236627 : ℝ) / 1000000000000000)) ((-307394044468004491 : ℝ) / 500000000000000000) ((-30739404446800449 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((540755475236627 : ℝ) / 500000000000000)) (t := ((40755475236627 : ℝ) / 1040755475236627))
    (lo := ((9794886452992041 : ℝ) / 125000000000000000)) (hi := ((78359091623936329 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540755475236627 : ℝ) / 1000000000000000) = Real.log ((540755475236627 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((540755475236627 : ℝ) / 1000000000000000) = ((540755475236627 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_348 : RB (Real.log ((459244524763373 : ℝ) / 1000000000000000)) ((-778172477084540543 : ℝ) / 1000000000000000000) ((-778172477084540541 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((459244524763373 : ℝ) / 500000000000000)) (t := ((-40755475236627 : ℝ) / 959244524763373))
    (lo := ((-85025296524595233 : ℝ) / 1000000000000000000)) (hi := ((-2657040516393601 : ℝ) / 31250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459244524763373 : ℝ) / 1000000000000000) = Real.log ((459244524763373 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((459244524763373 : ℝ) / 1000000000000000) = ((459244524763373 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_349 : RB (Real.log ((28702782797711 : ℝ) / 62500000000000)) ((-778172477084534011 : ℝ) / 1000000000000000000) ((-778172477084534009 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28702782797711 : ℝ) / 31250000000000)) (t := ((-2547217202289 : ℝ) / 59952782797711))
    (lo := ((-85025296524588701 : ℝ) / 1000000000000000000)) (hi := ((-850252965245887 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28702782797711 : ℝ) / 62500000000000) = Real.log ((28702782797711 : ℝ) / 31250000000000) - 1 * Real.log 2 := by
    rw [show ((28702782797711 : ℝ) / 62500000000000) = ((28702782797711 : ℝ) / 31250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_350 : RB (Real.log ((458580858610418899 : ℝ) / 1000000000000000000)) ((-779618648176869903 : ℝ) / 1000000000000000000) ((-779618648176869901 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458580858610418899 : ℝ) / 500000000000000000)) (t := ((-41419141389581101 : ℝ) / 958580858610418899))
    (lo := ((-86471467616924593 : ℝ) / 1000000000000000000)) (hi := ((-5404466726057787 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458580858610418899 : ℝ) / 1000000000000000000) = Real.log ((458580858610418899 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458580858610418899 : ℝ) / 1000000000000000000) = ((458580858610418899 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_351 : RB (Real.log ((229290429305210949 : ℝ) / 500000000000000000)) ((-194904662044215841 : ℝ) / 250000000000000000) ((-389809324088431681 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((229290429305210949 : ℝ) / 250000000000000000)) (t := ((-20709570694789051 : ℝ) / 479290429305210949))
    (lo := ((-43235733808459027 : ℝ) / 500000000000000000)) (hi := ((-86471467616918053 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229290429305210949 : ℝ) / 500000000000000000) = Real.log ((229290429305210949 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229290429305210949 : ℝ) / 500000000000000000) = ((229290429305210949 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_352 : RB (Real.log ((712321217740397949 : ℝ) / 500000000000000000)) ((353920859764686863 : ℝ) / 1000000000000000000) ((70784171952937373 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((712321217740397949 : ℝ) / 1000000000000000000)) (t := ((-287678782259602051 : ℝ) / 1712321217740397949))
    (lo := ((-169613160397629223 : ℝ) / 500000000000000000)) (hi := ((-67845264159051689 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712321217740397949 : ℝ) / 500000000000000000) = Real.log ((712321217740397949 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712321217740397949 : ℝ) / 500000000000000000) = ((712321217740397949 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_353 : RB (Real.log ((1424642435480798899 : ℝ) / 1000000000000000000)) ((353920859764688969 : ℝ) / 1000000000000000000) ((353920859764688971 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424642435480798899 : ℝ) / 2000000000000000000)) (t := ((-575357564519201101 : ℝ) / 3424642435480798899))
    (lo := ((-16961316039762817 : ℝ) / 50000000000000000)) (hi := ((-339226320795256339 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424642435480798899 : ℝ) / 1000000000000000000) = Real.log ((1424642435480798899 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424642435480798899 : ℝ) / 1000000000000000000) = ((1424642435480798899 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_354 : RB (Real.log ((340244881307 : ℝ) / 800000000000)) ((-854946130167220277 : ℝ) / 1000000000000000000) ((-34197845206688811 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((340244881307 : ℝ) / 400000000000)) (t := ((-59755118693 : ℝ) / 740244881307))
    (lo := ((-161798949607274967 : ℝ) / 1000000000000000000)) (hi := ((-80899474803637483 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340244881307 : ℝ) / 800000000000) = Real.log ((340244881307 : ℝ) / 400000000000) - 1 * Real.log 2 := by
    rw [show ((340244881307 : ℝ) / 800000000000) = ((340244881307 : ℝ) / 400000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_355 : RB (Real.log ((425306101633753 : ℝ) / 1000000000000000)) ((-106868266270901653 : ℝ) / 125000000000000000) ((-427473065083606611 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((425306101633753 : ℝ) / 500000000000000)) (t := ((-74693898366247 : ℝ) / 925306101633753))
    (lo := ((-80899474803633957 : ℝ) / 500000000000000000)) (hi := ((-161798949607267913 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425306101633753 : ℝ) / 1000000000000000) = Real.log ((425306101633753 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425306101633753 : ℝ) / 1000000000000000) = ((425306101633753 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_356 : RB (Real.log ((1140244881307 : ℝ) / 800000000000)) ((354386598816678667 : ℝ) / 1000000000000000000) ((354386598816678669 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1140244881307 : ℝ) / 1600000000000)) (t := ((-459755118693 : ℝ) / 2740244881307))
    (lo := ((-169380290871633321 : ℝ) / 500000000000000000)) (hi := ((-338760581743266641 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1140244881307 : ℝ) / 800000000000) = Real.log ((1140244881307 : ℝ) / 1600000000000) + 1 * Real.log 2 := by
    rw [show ((1140244881307 : ℝ) / 800000000000) = ((1140244881307 : ℝ) / 1600000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_357 : RB (Real.log ((1425306101633753 : ℝ) / 1000000000000000)) ((88596649704170193 : ℝ) / 250000000000000000) ((177193299408340387 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425306101633753 : ℝ) / 2000000000000000)) (t := ((-574693898366247 : ℝ) / 3425306101633753))
    (lo := ((-338760581743264537 : ℝ) / 1000000000000000000)) (hi := ((-42345072717908067 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425306101633753 : ℝ) / 1000000000000000) = Real.log ((1425306101633753 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425306101633753 : ℝ) / 1000000000000000) = ((1425306101633753 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_358 : RB (Real.log ((1424642435480795899 : ℝ) / 1000000000000000000)) ((353920859764686863 : ℝ) / 1000000000000000000) ((70784171952937373 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424642435480795899 : ℝ) / 2000000000000000000)) (t := ((-575357564519204101 : ℝ) / 3424642435480795899))
    (lo := ((-169613160397629223 : ℝ) / 500000000000000000)) (hi := ((-67845264159051689 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424642435480795899 : ℝ) / 1000000000000000000) = Real.log ((1424642435480795899 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424642435480795899 : ℝ) / 1000000000000000000) = ((1424642435480795899 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_359 : RB (Real.log ((712321217740399449 : ℝ) / 500000000000000000)) ((44240107470586121 : ℝ) / 125000000000000000) ((35392085976468897 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((712321217740399449 : ℝ) / 1000000000000000000)) (t := ((-287678782259600551 : ℝ) / 1712321217740399449))
    (lo := ((-339226320795256341 : ℝ) / 1000000000000000000)) (hi := ((-16961316039762817 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712321217740399449 : ℝ) / 500000000000000000) = Real.log ((712321217740399449 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712321217740399449 : ℝ) / 500000000000000000) = ((712321217740399449 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
