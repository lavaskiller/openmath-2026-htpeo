import LeanProject.DistFn
import LeanProject.BlockIneq

/-!
# EP-1038, Stage 12, Theorem 12.8 step 2 in the angle variable: the energy identity (12.6)

For functions `F, G` on `[0, π]` (values in `[0, 1]`), the even `2π`-periodic extensions are
`fold F θ = F(arccos(cos θ))` (so `fold F θ = F |θ|` on `[-π, π]`).

* `int_split`: `∫_{-π}^{π} h = ∫_0^π h(t) dt + ∫_0^π h(-t) dt`.
* `conv_even`: the convolution of an even kernel with an even function is even.
* `conv_fold`: `(K * fold G)(t) = ∫_0^π (K(t - s) + K(t + s)) G(s) ds`.
* `IK_fold`: `I_K(fold F, fold G) = 2 ∫_0^π F(t) ∫_0^π (K(t - s) + K(t + s)) G(s) ds dt`.
* `IK_energy` (**(12.6)**): with `d(θ) = D₀(1 - 2q cos θ + q²)` and `H = D₀q`,
  `I_K(fold F, fold G) = 2 ∫_0^π F(t) ∫_0^π (log|d(t) - d(s)| - log H) G(s) ds dt`.
* `block_energy` (**Theorem 12.8, steps 2–4**, angle form): with `Q = ∫_0^π F > 0`, `R = ∫_0^π G > 0`
  and `𝓔_H = ∫_0^π F(t) ∫_0^π (log|d(t) - d(s)| - log H) G(s) ds dt`: `2QR 𝒜(Q, R) ≤ 𝓔_H`.
* `block_ineq_angle` (**Theorem 12.8**, angle form): (12.5) with `𝓔/(qr) = log H + 𝓔_H/(QR)`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- The even `2π`-periodic extension `fold F θ = F(arccos(cos θ))`. -/
noncomputable def fold (F : ℝ → ℝ) (θ : ℝ) : ℝ := F (Real.arccos (Real.cos θ))

theorem fold_of_mem {F : ℝ → ℝ} {θ : ℝ} (hθ : θ ∈ Icc 0 π) : fold F θ = F θ := by
  unfold fold
  rw [Real.arccos_cos hθ.1 hθ.2]

theorem fold_neg (F : ℝ → ℝ) (θ : ℝ) : fold F (-θ) = fold F θ := by
  unfold fold
  rw [Real.cos_neg]

theorem fold_periodic (F : ℝ → ℝ) : Function.Periodic (fold F) (2 * π) := fun θ => by
  unfold fold
  rw [Real.cos_add_two_pi]

theorem fold_measurable {F : ℝ → ℝ} (hF : Measurable F) : Measurable (fold F) :=
  hF.comp (Real.continuous_arccos.comp Real.continuous_cos).measurable

theorem fold_abs_le {F : ℝ → ℝ} (hF0 : ∀ x, 0 ≤ F x) (hF1 : ∀ x, F x ≤ 1) (x : ℝ) :
    |fold F x| ≤ 1 := by
  unfold fold
  exact abs_le.mpr ⟨by linarith [hF0 (Real.arccos (Real.cos x))], hF1 _⟩

theorem int_split {h : ℝ → ℝ} (hi : IntervalIntegrable h volume (-π) π) :
    ∫ θ in (-π)..π, h θ = (∫ t in (0 : ℝ)..π, h t) + ∫ t in (0 : ℝ)..π, h (-t) := by
  have hπ := Real.pi_pos
  have h1 : IntervalIntegrable h volume (-π) 0 := hi.mono_set (by
    rw [uIcc_of_le (by linarith), uIcc_of_le (by linarith)]
    exact Icc_subset_Icc le_rfl hπ.le)
  have h2 : IntervalIntegrable h volume 0 π := hi.mono_set (by
    rw [uIcc_of_le hπ.le, uIcc_of_le (by linarith)]
    exact Icc_subset_Icc (by linarith) le_rfl)
  rw [← intervalIntegral.integral_add_adjacent_intervals h1 h2]
  have h3 := intervalIntegral.integral_comp_neg (a := 0) (b := π) (f := h)
  rw [neg_zero] at h3
  rw [h3]
  ring

theorem conv_even {K g : ℝ → ℝ} (hK : ∀ x, K (-x) = K x) (hg : ∀ x, g (-x) = g x) (t : ℝ) :
    Circ.conv K g (-t) = Circ.conv K g t := by
  unfold Circ.conv
  have h := intervalIntegral.integral_comp_neg (a := -π) (b := π) (f := fun u => K (t - u) * g u)
  simp only [neg_neg] at h
  rw [← h]
  refine intervalIntegral.integral_congr (fun u _ => ?_)
  show K (-t - u) * g u = K (t - -u) * g (-u)
  rw [hg u, show -t - u = -(t - -u) by ring, hK]

theorem Kl1_sub_ii (t a b : ℝ) : IntervalIntegrable (fun u => Kl 1 (t - u)) volume a b := by
  have := (Kl1_ii (t - a) (t - b)).comp_sub_left t
  simpa using this

theorem Kl1_add_ii (t a b : ℝ) : IntervalIntegrable (fun u => Kl 1 (t + u)) volume a b := by
  have := (Kl1_ii (t + a) (t + b)).comp_add_left t
  simpa using this

section fold

variable {F G : ℝ → ℝ} (hFm : Measurable F) (hGm : Measurable G)
  (hF0 : ∀ x, 0 ≤ F x) (hF1 : ∀ x, F x ≤ 1) (hG0 : ∀ x, 0 ≤ G x) (hG1 : ∀ x, G x ≤ 1)

include hGm hG0 hG1 in
theorem conv_fold (t : ℝ) :
    Circ.conv (Kl 1) (fold G) t = ∫ s in (0 : ℝ)..π, (Kl 1 (t - s) + Kl 1 (t + s)) * G s := by
  have hπ := Real.pi_pos
  have hgm := fold_measurable hGm
  have hb : ∀ x, |fold G x| ≤ 1 := fold_abs_le hG0 hG1
  have hbG : ∀ x, |G x| ≤ 1 := fun x => abs_le.mpr ⟨by linarith [hG0 x], hG1 x⟩
  unfold Circ.conv
  rw [int_split (ii_mul_bdd (Kl1_sub_ii t _ _) hgm hb)]
  have e1 : ∫ s in (0 : ℝ)..π, Kl 1 (t - s) * fold G s = ∫ s in (0 : ℝ)..π, Kl 1 (t - s) * G s := by
    refine intervalIntegral.integral_congr (fun s hs => ?_)
    rw [uIcc_of_le hπ.le] at hs
    show Kl 1 (t - s) * fold G s = Kl 1 (t - s) * G s
    rw [fold_of_mem hs]
  have e2 : ∫ s in (0 : ℝ)..π, Kl 1 (t - -s) * fold G (-s) =
      ∫ s in (0 : ℝ)..π, Kl 1 (t + s) * G s := by
    refine intervalIntegral.integral_congr (fun s hs => ?_)
    rw [uIcc_of_le hπ.le] at hs
    show Kl 1 (t - -s) * fold G (-s) = Kl 1 (t + s) * G s
    rw [fold_neg, fold_of_mem hs, sub_neg_eq_add]
  rw [e1, e2, ← intervalIntegral.integral_add (ii_mul_bdd (Kl1_sub_ii t _ _) hGm hbG)
    (ii_mul_bdd (Kl1_add_ii t _ _) hGm hbG)]
  refine intervalIntegral.integral_congr (fun s _ => ?_)
  show Kl 1 (t - s) * G s + Kl 1 (t + s) * G s = (Kl 1 (t - s) + Kl 1 (t + s)) * G s
  ring

include hFm hGm hF0 hF1 hG0 hG1 in
theorem IK_fold :
    Circ.IK (Kl 1) (fold F) (fold G) =
      2 * ∫ t in (0 : ℝ)..π, F t * ∫ s in (0 : ℝ)..π, (Kl 1 (t - s) + Kl 1 (t + s)) * G s := by
  have hπ := Real.pi_pos
  have hgm := fold_measurable hGm
  have hg0 : ∀ x, 0 ≤ fold G x := fun x => hG0 _
  have hg1 : ∀ x, fold G x ≤ 1 := fun x => hG1 _
  -- boundedness of the convolution
  set C0 := ∫ s in (-π)..π, Circ.Lsin s with hC0
  set m := ∫ u in (-π)..π, fold G u with hm
  have hconv_b : ∀ θ, |Circ.conv (Kl 1) (fold G) θ| ≤ |Real.log 2 * m| + C0 := by
    intro θ
    rw [conv_Kl_one hgm hg0 hg1 θ]
    obtain ⟨b0, b1⟩ := conv_Lsin_bounds hgm hg0 hg1 θ
    calc |Real.log 2 * m - Circ.conv Circ.Lsin (fold G) θ|
        ≤ |Real.log 2 * m| + |Circ.conv Circ.Lsin (fold G) θ| := abs_sub _ _
      _ ≤ |Real.log 2 * m| + C0 := by rw [abs_of_nonneg b0]; linarith
  have hbd : Circ.Bdd (fun θ => fold F θ * Circ.conv (Kl 1) (fold G) θ) := by
    refine ⟨(fold_measurable hFm).mul (Circ.conv_measurable Kl1_measurable hgm),
      |Real.log 2 * m| + C0, fun θ => ?_⟩
    rw [abs_mul]
    have h1 : |fold F θ| ≤ 1 := fold_abs_le hF0 hF1 θ
    calc |fold F θ| * |Circ.conv (Kl 1) (fold G) θ| ≤ 1 * (|Real.log 2 * m| + C0) :=
          mul_le_mul h1 (hconv_b θ) (abs_nonneg _) zero_le_one
      _ = |Real.log 2 * m| + C0 := one_mul _
  unfold Circ.IK
  rw [int_split (hbd.ii _ _)]
  have hKe : ∀ x, Kl 1 (-x) = Kl 1 x := Kl1_even
  have hge : ∀ x, fold G (-x) = fold G x := fold_neg G
  have e : ∀ t ∈ uIcc (0 : ℝ) π, fold F (-t) * Circ.conv (Kl 1) (fold G) (-t) =
      F t * ∫ s in (0 : ℝ)..π, (Kl 1 (t - s) + Kl 1 (t + s)) * G s := by
    intro t ht
    rw [uIcc_of_le hπ.le] at ht
    rw [fold_neg, conv_even hKe hge, fold_of_mem ht, conv_fold hGm hG0 hG1]
  have e' : ∀ t ∈ uIcc (0 : ℝ) π, fold F t * Circ.conv (Kl 1) (fold G) t =
      F t * ∫ s in (0 : ℝ)..π, (Kl 1 (t - s) + Kl 1 (t + s)) * G s := by
    intro t ht
    rw [uIcc_of_le hπ.le] at ht
    rw [fold_of_mem ht, conv_fold hGm hG0 hG1]
  rw [intervalIntegral.integral_congr e', intervalIntegral.integral_congr e]
  ring

include hFm hGm hF0 hF1 hG0 hG1 in
/-- **(12.6)**, angle form: `I_K(fold F, fold G) = 2 ∫_0^π F(t) ∫_0^π (log|d(t) - d(s)| - log H) G(s)`. -/
theorem IK_energy {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) :
    Circ.IK (Kl 1) (fold F) (fold G) =
      2 * ∫ t in (0 : ℝ)..π, F t * ∫ s in (0 : ℝ)..π,
        (Real.log |dth D0 q t - dth D0 q s| - Real.log (D0 * q)) * G s := by
  rw [IK_fold hFm hGm hF0 hF1 hG0 hG1]
  congr 1
  refine intervalIntegral.integral_congr (fun t _ => ?_)
  show F t * ∫ s in (0 : ℝ)..π, (Kl 1 (t - s) + Kl 1 (t + s)) * G s =
    F t * ∫ s in (0 : ℝ)..π, (Real.log |dth D0 q t - dth D0 q s| - Real.log (D0 * q)) * G s
  congr 1
  refine intervalIntegral.integral_congr_ae ?_
  filter_upwards [log_dist_eq hD hq t] with s hs _
  rw [hs, show s + -t = -(t - s) by ring, Kl1_even, add_comm s t]
  ring

include hFm hF0 hF1 in
theorem int_fold : ∫ θ in (-π)..π, fold F θ = 2 * ∫ t in (0 : ℝ)..π, F t := by
  have hπ := Real.pi_pos
  have hb : Circ.Bdd (fold F) := ⟨fold_measurable hFm, 1, fold_abs_le hF0 hF1⟩
  rw [int_split (hb.ii _ _)]
  have e : ∀ t ∈ uIcc (0 : ℝ) π, fold F (-t) = F t := by
    intro t ht; rw [uIcc_of_le hπ.le] at ht; rw [fold_neg, fold_of_mem ht]
  have e' : ∀ t ∈ uIcc (0 : ℝ) π, fold F t = F t := by
    intro t ht; rw [uIcc_of_le hπ.le] at ht; rw [fold_of_mem ht]
  rw [intervalIntegral.integral_congr e', intervalIntegral.integral_congr e]
  ring

end fold

/-- **Theorem 12.8, steps 2–4** (angle form): `2QR 𝒜(Q, R) ≤ 𝓔_H`. -/
theorem block_energy {F G : ℝ → ℝ} (hFm : Measurable F) (hGm : Measurable G)
    (hF0 : ∀ x, 0 ≤ F x) (hF1 : ∀ x, F x ≤ 1) (hG0 : ∀ x, 0 ≤ G x) (hG1 : ∀ x, G x ≤ 1)
    {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q)
    (hQ : 0 < ∫ t in (0 : ℝ)..π, F t) (hR : 0 < ∫ t in (0 : ℝ)..π, G t) :
    2 * (∫ t in (0 : ℝ)..π, F t) * (∫ t in (0 : ℝ)..π, G t) *
        AE (∫ t in (0 : ℝ)..π, F t) (∫ t in (0 : ℝ)..π, G t) ≤
      ∫ t in (0 : ℝ)..π, F t * ∫ s in (0 : ℝ)..π,
        (Real.log |dth D0 q t - dth D0 q s| - Real.log (D0 * q)) * G s := by
  have h := circle_block_K (fold_measurable hFm) (fold_measurable hGm) (fold_periodic F)
    (fold_periodic G) (fun x => hF0 _) (fun x => hF1 _) (fun x => hG0 _) (fun x => hG1 _) hQ hR
    (int_fold hFm hF0 hF1) (int_fold hGm hG0 hG1)
  rw [IK_energy hFm hGm hF0 hF1 hG0 hG1 hD hq] at h
  linarith

/-- **Theorem 12.8** (angle form): (12.5) with `𝓔/(qr) = log H + 𝓔_H/(QR)`, `q = a_π Q/π`,
`r = b_π R/π`, `Q = ∫_0^π F`, `R = ∫_0^π G`. -/
theorem block_ineq_angle {F G : ℝ → ℝ} (hFm : Measurable F) (hGm : Measurable G)
    (hF0 : ∀ x, 0 ≤ F x) (hF1 : ∀ x, F x ≤ 1) (hG0 : ∀ x, 0 ≤ G x) (hG1 : ∀ x, G x ≤ 1)
    {D0 q0 api bpi Ceff : ℝ} (hD : 0 < D0) (hq0 : 0 < q0) (ha : 0 < api) (hb : 0 < bpi)
    (hQ : 0 < ∫ t in (0 : ℝ)..π, F t) (hR : 0 < ∫ t in (0 : ℝ)..π, G t) :
    rhs (Real.log (2 * (D0 * q0) / (api * bpi))) Ceff api
        (∫ t in (0 : ℝ)..π, F t) (∫ t in (0 : ℝ)..π, G t) ≤
      (Real.log (D0 * q0) + (∫ t in (0 : ℝ)..π, F t * ∫ s in (0 : ℝ)..π,
          (Real.log |dth D0 q0 t - dth D0 q0 s| - Real.log (D0 * q0)) * G s) /
          ((∫ t in (0 : ℝ)..π, F t) * (∫ t in (0 : ℝ)..π, G t))) -
        Real.log (api * (∫ t in (0 : ℝ)..π, F t) / π * (bpi * (∫ t in (0 : ℝ)..π, G t) / π) / 2) -
        Ceff / (api * (∫ t in (0 : ℝ)..π, F t) / π) := by
  set Q := ∫ t in (0 : ℝ)..π, F t with hQdef
  set R := ∫ t in (0 : ℝ)..π, G t with hRdef
  set EH := ∫ t in (0 : ℝ)..π, F t * ∫ s in (0 : ℝ)..π,
    (Real.log |dth D0 q0 t - dth D0 q0 s| - Real.log (D0 * q0)) * G s with hEH
  have hπ := Real.pi_pos
  set qq := api * Q / π with hqq
  set rr := bpi * R / π with hrr
  have hqq0 : 0 < qq := by rw [hqq]; positivity
  have hrr0 : 0 < rr := by rw [hrr]; positivity
  set E := (Real.log (D0 * q0) + EH / (Q * R)) * (qq * rr) with hE
  have hIK := IK_energy hFm hGm hF0 hF1 hG0 hG1 hD hq0
  have hEid : E / (qq * rr) = Real.log (D0 * q0) + 1 / (2 * Q * R) *
      Circ.IK (Kl 1) (fold F) (fold G) := by
    rw [hIK, hE, mul_div_assoc, div_self (mul_pos hqq0 hrr0).ne', mul_one]
    have := hQ.ne'
    have := hR.ne'
    field_simp
    ring
  have h := block_ineq (Ceff := Ceff) (fold_measurable hFm) (fold_measurable hGm) (fold_periodic F)
    (fold_periodic G) (fun x => hF0 _) (fun x => hF1 _) (fun x => hG0 _) (fun x => hG1 _) hQ hR
    (int_fold hFm hF0 hF1) (int_fold hGm hG0 hG1) (mul_pos hD hq0) ha hb hqq hrr hEid
  have e2 : E / (qq * rr) = Real.log (D0 * q0) + EH / (Q * R) := by
    rw [hE, mul_div_cancel_right₀ _ (mul_pos hqq0 hrr0).ne']
  rw [e2] at h
  exact h

end EP1038.Arc
