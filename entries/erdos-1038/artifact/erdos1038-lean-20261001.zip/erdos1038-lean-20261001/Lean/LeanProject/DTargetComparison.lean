import LeanProject.DWitnessData
import LeanProject.R1PilotScalar

/-!
# Comparing the certified rational target with the actual infimum `D`

An admissible terminal-family witness suffices for an upper bound on `D`.
The two strict signs below bound the actual roots, using the proved branch
sign characterizations, rather than treating proposed numerical roots as exact.
-/

open Real Set Polynomial
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage12

theorem reciprocal_sum_strictAnti {x y : ℝ} (hx : 0 < x) (hxy : x < y)
    (hy : y < 1) : y + 1 / y < x + 1 / x := by
  have hy0 : 0 < y := lt_trans hx hxy
  have hx1 : x < 1 := lt_trans hxy hy
  have hp : 0 < 1 - x * y := by
    nlinarith [mul_lt_mul_of_pos_right hx1 hy0]
  have he : x + 1 / x - (y + 1 / y) = (y - x) * (1 - x * y) / (x * y) := by
    field_simp
    <;> ring
  apply sub_pos.mp
  rw [he]
  exact div_pos (mul_pos (sub_pos.mpr hxy) hp) (mul_pos hx hy0)

/-- Two strict negative signs bound the width from above. -/
theorem Lam_lt_of_outer_signs {q ml pu : ℝ} (hq : q ∈ Qadm)
    (hml : ml ∈ Ioo 0 q) (hpu : pu ∈ Ioo q 1)
    (hgm : GA (Aq q) q ml < 0) (hgp : GA (Aq q) q pu < 0) :
    Stage9.Lam q < D0q q * q * (ml + 1 / ml - pu - 1 / pu) := by
  obtain ⟨pm, pp, hpm0, hpmq, hqpp, hpp1, hGm, hGp, hLam⟩ := Lam_eq hq
  have hA := Aq_pos hq.1 hq.2.1
  have hAs := (Aq_lt_s_iff hq.1 hq.2.1).mpr hq.2.2
  obtain ⟨m, hm0, hmq, hGm', hmpos, hmneg⟩ :=
    exists_pminus hq.1 hq.2.1 hA hAs 0
  have hem : m = pm := by
    apply le_antisymm
    · apply le_of_not_gt
      intro h
      have hh := (hmneg pm hpm0 hpmq).mpr h
      rw [hGm] at hh
      exact (lt_irrefl 0) hh
    · apply le_of_not_gt
      intro h
      have hh := (hmpos pm hpm0 hpmq).mpr h
      rw [hGm] at hh
      exact (lt_irrefl 0) hh
  have hmlpm : ml < pm := hem ▸ (hmneg ml hml.1 hml.2).mp hgm
  obtain ⟨p, hqp, hp1, hGp', hppos, hpneg⟩ :=
    exists_pplus hq.1 hq.2.1 hA hAs (C := 0) le_rfl
  have hep : p = pp := by
    apply le_antisymm
    · apply le_of_not_gt
      intro h
      have hh := (hppos pp hqpp hpp1).mpr h
      rw [hGp] at hh
      exact (lt_irrefl 0) hh
    · apply le_of_not_gt
      intro h
      have hh := (hpneg pp hqpp hpp1).mpr h
      rw [hGp] at hh
      exact (lt_irrefl 0) hh
  have hpppu : pp < pu := hep ▸ (hpneg pu hpu.1 hpu.2).mp hgp
  have hm := reciprocal_sum_strictAnti hml.1 hmlpm (lt_trans hpmq hq.2.1)
  have hp := reciprocal_sum_strictAnti (lt_trans hq.1 hqpp) hpppu hpu.2
  rw [hLam]
  exact mul_lt_mul_of_pos_left (by linarith) (mul_pos (D0q_pos q hq.1.le) hq.1)

theorem d_witness_width_lt_target : Stage9.Lam dWitnessQ < pilotTarget := by
  have h := Lam_lt_of_outer_signs d_witness_admissible
    (ml := dWitnessPmLo) (pu := dWitnessPpHi)
    (by constructor <;> norm_num [dWitnessPmLo, dWitnessQ])
    (by constructor <;> norm_num [dWitnessPpHi, dWitnessQ])
    d_witness_minus_sign d_witness_plus_sign
  have hb : D0q dWitnessQ * dWitnessQ *
      (dWitnessPmLo + 1 / dWitnessPmLo - dWitnessPpHi - 1 / dWitnessPpHi) < pilotTarget := by
    norm_num [D0q, dWitnessQ, dWitnessPmLo, dWitnessPpHi, pilotTarget]
  exact h.trans hb

/-- The paper's rational target dominates the actual infimum, without a minimizer premise. -/
theorem Dval_lt_pilotTarget : Dval < pilotTarget :=
  (Dval_le_Lam d_witness_admissible).trans_lt d_witness_width_lt_target

theorem Dval_lt_two : Dval < 2 :=
  Dval_lt_pilotTarget.trans (by norm_num [pilotTarget])

theorem pilot_scalar_positive_at_D {k : ℝ} (hk : k ∈ pilotSlab) :
    ScalarPositive (pilotReference hk) (calibratedCeff (pilotReference hk) Dval) :=
  pilot_scalar_positive hk Dval_lt_pilotTarget.le

theorem pilot_normal_form_gt_D {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (hk : a.k ∈ pilotSlab) : Dval < a.J :=
  Dval_lt_pilotTarget.trans (pilot_normal_form_lower a hres hk)

theorem pilot_polynomial_gt_D {p : ℝ[X]} {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (hk : a.k ∈ pilotSlab)
    (hJ : a.J ≤ (EP1038.sublevelMeasure p).toReal) :
    Dval < (EP1038.sublevelMeasure p).toReal :=
  (pilot_normal_form_gt_D a hres hk).trans_le hJ

end EP1038.ReferenceCert
