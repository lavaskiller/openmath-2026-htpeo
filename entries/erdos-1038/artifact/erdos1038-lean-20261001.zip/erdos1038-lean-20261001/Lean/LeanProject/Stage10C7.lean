import LeanProject.Stage10C6

/-!
# EP-1038, Stage 10 Part (c), N4: Proposition 10.10 on the real axis

`cS k S = Φ_S` (inverse coefficients of `φ_S`), `xpS = Φ_S(R)`, `xmS = Φ_S(-R)`.
* `sep_series` (strictly separated): `x₊ = Φ(R) ∈ (0, y_c)`, `Ψ(x₊) = R`; `x₋ = Φ(-R) < 0`, `Ψ(x₋) = -R`;
* `contact_series`: `Φ(R) = y_c`, `Φ(-R) < 0` with `Ψ = -R`;
* `main_component_series`: `W < 0` on `(x₋, x₊) \ {0}` and `W(x±) = 0` in both cases, so the
  main component is `(Φ(-R), Φ(R))` and `M_k(S) = Φ(R) - Φ(-R) = Σ c_n (Rⁿ - (-R)ⁿ)`
  (`width_series`).
-/

open Real Set Filter Topology PowerSeries Finset MeasureTheory

namespace EP1038.Stage10

/-- `Φ_S`. -/
noncomputable def cS (k : ℝ) (S : ℝ → ℝ) : PowerSeries ℝ := PhiS (phiS k S)

/-- `x₊ = Φ_S(R)`. -/
noncomputable def xpS (k : ℝ) (S : ℝ → ℝ) : ℝ := ev (cS k S) (RS k S)

/-- `x₋ = Φ_S(-R)`. -/
noncomputable def xmS (k : ℝ) (S : ℝ → ℝ) : ℝ := ev (cS k S) (-RS k S)

section prop

variable {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
  (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
include hSm ha hSa hS2 hk

theorem hconvS : ∀ w, 0 ≤ w → w < a → Summable fun j => phiS k S j * w ^ j := fun w hw hwa =>
  (phiv_phiS hSm ha hSa hS2 hk (by rw [abs_of_nonneg hw]; exact hwa)).1

theorem phiv_pos {y : ℝ} (hy : |y| < a) : 0 < phiv (phiS k S) y := by
  rw [(phiv_phiS hSm ha hSa hS2 hk hy).2]; exact Real.exp_pos _

/-- The general N3 package for `Z = R` and a given `r`. -/
theorem series_package {r : ℝ} (hr : 0 < r) (hra : r < a)
    (hfix : RS k S * phiv (phiS k S) r ≤ r) :
    0 < xpS k S ∧ xpS k S ≤ r ∧ PsiS k S (xpS k S) = RS k S ∧
      xmS k S < 0 ∧ |xmS k S| < a ∧ PsiS k S (xmS k S) = -RS k S := by
  have hφ := phiS_nonneg hSm ha hSa hS2 hk
  have hconv := hconvS hSm ha hSa hS2 hk
  have hR := RS_pos hSm ha hSa hS2 hk
  have hNN := NN_Phi hφ
  have hRabs : |RS k S| ≤ RS k S := le_of_eq (abs_of_pos hR)
  have hmRabs : |-RS k S| ≤ RS k S := le_of_eq (by rw [abs_neg, abs_of_pos hR])
  have hle := ev_Phi_le hφ hconv hR hr hra hfix
  have hfp := Phi_functional hφ hconv hR hr hra hfix hRabs
  have hfm := Phi_functional hφ hconv hR hr hra hfix hmRabs
  have hxp0 : 0 ≤ xpS k S := ev_nonneg hNN hR.le
  have hxpa : |xpS k S| < a := by rw [abs_of_nonneg hxp0]; unfold xpS cS; linarith
  have hxmabs : |xmS k S| ≤ r := by
    have h1 := ev_abs_le hNN (AC_Phi hφ hconv hR hr hra hfix hmRabs)
    rw [abs_neg, abs_of_pos hR] at h1
    unfold xmS cS; linarith
  have hxma : |xmS k S| < a := lt_of_le_of_lt hxmabs hra
  have hpp := phiv_pos hSm ha hSa hS2 hk hxpa
  have hpm := phiv_pos hSm ha hSa hS2 hk hxma
  refine ⟨?_, hle, ?_, ?_, hxma, ?_⟩
  · unfold xpS cS; rw [hfp]; exact mul_pos hR hpp
  · rw [PsiS_eq_div hSm ha hSa hS2 hk hxpa]
    unfold xpS cS at *
    rw [div_eq_iff hpp.ne']; exact hfp
  · unfold xmS cS; rw [hfm]; exact mul_neg_of_neg_of_pos (by linarith) hpm
  · rw [PsiS_eq_div hSm ha hSa hS2 hk hxma]
    unfold xmS cS at *
    rw [div_eq_iff hpm.ne']; exact hfm

/-- **Proposition 10.10**, strictly separated case. -/
theorem sep_series {r : ℝ} (hr0 : 0 < r) (hra : r < a) (hsep : RS k S < PsiS k S r) :
    0 < xpS k S ∧ xpS k S < yc k a S ∧ PsiS k S (xpS k S) = RS k S ∧
      xmS k S < 0 ∧ PsiS k S (xmS k S) = -RS k S := by
  have hr_abs : |r| < a := by rwa [abs_of_pos hr0]
  have hpr := phiv_pos hSm ha hSa hS2 hk hr_abs
  have hfix : RS k S * phiv (phiS k S) r ≤ r := by
    rw [PsiS_eq_div hSm ha hSa hS2 hk hr_abs, lt_div_iff₀ hpr] at hsep
    exact hsep.le
  obtain ⟨hp0, hple, hpΨ, hm0, -, hmΨ⟩ := series_package hSm ha hSa hS2 hk hr0 hra hfix
  refine ⟨hp0, ?_, hpΨ, hm0, hmΨ⟩
  by_contra hc
  push Not at hc
  rcases lt_or_ge r (yc k a S) with h | h
  · linarith
  · have hanti := (PsiS_strictAntiOn hSm ha hSa hS2 hk).antitoneOn ⟨hc, lt_of_le_of_lt hple hra⟩
      ⟨h, hra⟩ hple
    linarith

/-- **Proposition 10.10**, contact case. -/
theorem contact_series (hyc : yc k a S < a) (hcon : RS k S = PsiS k S (yc k a S)) :
    xpS k S = yc k a S ∧ xmS k S < 0 ∧ PsiS k S (xmS k S) = -RS k S := by
  have hycpos := yc_pos hSm ha hSa hS2 hk
  have hyc_abs : |yc k a S| < a := by rwa [abs_of_pos hycpos]
  have hpy := phiv_pos hSm ha hSa hS2 hk hyc_abs
  have hfix : RS k S * phiv (phiS k S) (yc k a S) ≤ yc k a S := by
    rw [hcon, PsiS_eq_div hSm ha hSa hS2 hk hyc_abs, div_mul_cancel₀ _ hpy.ne']
  obtain ⟨hp0, hple, hpΨ, hm0, -, hmΨ⟩ := series_package hSm ha hSa hS2 hk hycpos hyc hfix
  refine ⟨?_, hm0, hmΨ⟩
  have hmono := PsiS_strictMonoOn_Iic hSm ha hSa hS2 hk hyc
  exact hmono.injOn hple (Set.mem_Iic.mpr le_rfl) (by rw [hpΨ, hcon])

/-- The main component is `(Φ(-R), Φ(R))` (either case), given `Φ(R) ≤ y_c < a` data. -/
theorem main_component_series (hxp : 0 < xpS k S) (hxpyc : xpS k S ≤ yc k a S)
    (hyca : xpS k S < a) (hpΨ : PsiS k S (xpS k S) = RS k S) (hm0 : xmS k S < 0)
    (hmΨ : PsiS k S (xmS k S) = -RS k S)
    (hmono : StrictMonoOn (PsiS k S) (Iic (xpS k S))) :
    WS k S (xmS k S) = 0 ∧ WS k S (xpS k S) = 0 ∧
      ∀ y, xmS k S < y → y < xpS k S → y ≠ 0 → WS k S y < 0 := by
  have hR := RS_pos hSm ha hSa hS2 hk
  refine ⟨WS_zero_of_abs hSm ha hSa hS2 hk (by linarith) hm0.ne (by rw [hmΨ, abs_neg, abs_of_pos hR]),
    WS_zero_of_abs hSm ha hSa hS2 hk hyca hxp.ne' (by rw [hpΨ, abs_of_pos hR]), fun y h1 h2 hy0 => ?_⟩
  rw [WS_neg_iff hSm ha hSa hS2 hk (by linarith) hy0, abs_lt]
  have a1 := hmono (Set.mem_Iic.mpr (by linarith)) (Set.mem_Iic.mpr h2.le) h1
  have a2 := hmono (Set.mem_Iic.mpr h2.le) (Set.mem_Iic.mpr le_rfl) h2
  constructor <;> linarith

/-- `x₊ - x₋ = Σ c_n (Rⁿ - (-R)ⁿ)` whenever both series converge absolutely. -/
theorem width_series {r : ℝ} (hr : 0 < r) (hra : r < a) (hfix : RS k S * phiv (phiS k S) r ≤ r) :
    xpS k S - xmS k S = ∑' n, coeff n (cS k S) * (RS k S ^ n - (-RS k S) ^ n) := by
  have hφ := phiS_nonneg hSm ha hSa hS2 hk
  have hconv := hconvS hSm ha hSa hS2 hk
  have hR := RS_pos hSm ha hSa hS2 hk
  have h1 := (AC_Phi hφ hconv hR hr hra hfix (le_of_eq (abs_of_pos hR))).of_norm
  have h2 := (AC_Phi hφ hconv hR hr hra hfix (le_of_eq (by rw [abs_neg, abs_of_pos hR]))).of_norm
  unfold xpS xmS ev cS at *
  rw [← h1.tsum_sub h2]
  exact tsum_congr fun n => by ring

end prop

end EP1038.Stage10
