import LeanProject.Stage9D2

/-!
# EP-1038, Stage 9, Lemma Q: the quantile form of `μ_A`

For `0 < A < s` (i.e. `A(1+q) < 1 - q`) let `w(θ) = (1 - A P_q(θ))/π > 0`,
`G(θ) = A + ∫_0^θ w` (strictly increasing, `G(0) = A`, `G(π) = 1`), and
`Q(u) = 0` for `u ≤ A`, `Q(u) = dth(G⁻¹(u))` for `A < u < 1`, `Q(u) = 2` for `u ≥ 1`.
Then `Q` is monotone with values in `[0, 2]` (`Qu_mono`, `Qu_mem`) and
`∫_0^1 log|y - Q u| du = V_{μ_A}(y)` for **every** `y` (`VQ_eq_VA`).

Also: measurability of `V_A` and `V_N`; `V ≥ 0` outside `(-1, 3]`; the zero set of `V_A` off the platform
for `C(A) ≥ 0` (Lean RED L-242); continuity of `A ↦ V_A(y)`.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral
open scoped ENNReal

namespace EP1038.Stage9

open Arc

theorem dth_mem {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) (θ : ℝ) :
    dth D0 q θ ∈ Icc (D0 * (1 - q) ^ 2) (D0 * (1 + q) ^ 2) := by
  unfold dth
  have h1 := Real.neg_one_le_cos θ
  have h2 := Real.cos_le_one θ
  have hDq := mul_pos hD hq
  constructor
  · nlinarith [mul_nonneg hDq.le (sub_nonneg.mpr h2)]
  · nlinarith [mul_nonneg hDq.le (show 0 ≤ Real.cos θ + 1 by linarith)]

theorem D0q_top (q : ℝ) (hq : 0 ≤ q) : D0q q * (1 + q) ^ 2 = 2 := by
  unfold D0q
  have : (1 + q) ^ 2 ≠ 0 := by positivity
  field_simp

theorem dth_mem02 {q : ℝ} (hq : 0 < q) (θ : ℝ) : dth (D0q q) q θ ∈ Icc 0 2 := by
  have h := dth_mem (D0q_pos q hq.le) hq θ
  rw [D0q_top q hq.le] at h
  exact ⟨le_trans (mul_nonneg (D0q_pos q hq.le).le (sq_nonneg _)) h.1, h.2⟩

theorem ii_log_dth {q : ℝ} (hq : 0 < q) (y : ℝ) :
    IntervalIntegrable (fun θ => Real.log |y - dth (D0q q) q θ|) volume (-π) π := by
  have hD := D0q_pos q hq.le
  by_cases hy : y ∈ Icc (D0q q * (1 - q) ^ 2) (D0q q * (1 + q) ^ 2)
  · obtain ⟨φ, rfl⟩ := exists_dth hD hq hy.1 hy.2
    exact log_dist_ii hD hq φ
  · have hne : ∀ θ, y - dth (D0q q) q θ ≠ 0 := fun θ h =>
      hy (by rw [sub_eq_zero.mp h]; exact dth_mem hD hq θ)
    have hc0 : Continuous fun θ => y - dth (D0q q) q θ := by unfold dth; fun_prop
    exact (hc0.abs.log fun θ => abs_ne_zero.mpr (hne θ)).intervalIntegrable _ _

/-- The weight `w(θ) = (1 - A P_q(θ))/π`. -/
noncomputable def wA (A q θ : ℝ) : ℝ := (1 - A * Pq q θ) / π

/-- `G(θ) = A + ∫_0^θ w`. -/
noncomputable def Gq (A q θ : ℝ) : ℝ := A + ∫ t in (0 : ℝ)..θ, wA A q t

/-- `G⁻¹` on `(A, 1)`. -/
noncomputable def Ginv (A q u : ℝ) : ℝ := Function.invFunOn (Gq A q) (Ioo 0 π) u

/-- The quantile function of `μ_A` (in the variable `y = x + 1`). -/
noncomputable def Qu (A q u : ℝ) : ℝ :=
  if u ≤ A then 0 else if u < 1 then dth (D0q q) q (Ginv A q u) else 2

theorem wA_cont {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) : Continuous (wA A q) :=
  (continuous_const.sub (continuous_const.mul (Pq_cont hq.le hq1))).div_const π

theorem dth_mono {D0 q' a b : ℝ} (hD : 0 < D0) (hq : 0 < q') (ha : 0 ≤ a) (hb : b ≤ π) (hab : a ≤ b) :
    dth D0 q' a ≤ dth D0 q' b := by
  have := Real.cos_le_cos_of_nonneg_of_le_pi ha hb hab
  unfold dth
  nlinarith [mul_pos hD hq]

section Q

variable {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A) (hAs : A * (1 + q) < 1 - q)
include hq hq1 hA0 hAs

theorem wA_pos (θ : ℝ) : 0 < wA A q θ := by
  unfold wA
  have hP := Pq_le hq.le hq1 θ
  have : A * Pq q θ < 1 := by
    calc A * Pq q θ ≤ A * ((1 + q) / (1 - q)) := mul_le_mul_of_nonneg_left hP hA0.le
      _ < 1 := by rw [mul_div_assoc', div_lt_one (by linarith)]; linarith
  exact div_pos (by linarith) Real.pi_pos

omit hA0 hAs in
theorem hasDerivAt_Gq (θ : ℝ) : HasDerivAt (Gq A q) (wA A q θ) θ :=
  (((wA_cont hq hq1).integral_hasStrictDerivAt 0 θ).hasDerivAt).const_add A

theorem Gq_strictMono : StrictMono (Gq A q) :=
  strictMono_of_deriv_pos fun θ => by
    rw [(hasDerivAt_Gq hq hq1 θ).deriv]
    exact wA_pos hq hq1 hA0 hAs θ

omit hq hq1 hA0 hAs in
theorem Gq_zero : Gq A q 0 = A := by simp [Gq]

omit hA0 hAs in
theorem Gq_pi : Gq A q π = 1 := by
  have hπ := Real.pi_pos.ne'
  unfold Gq wA
  rw [intervalIntegral.integral_div, intervalIntegral.integral_sub intervalIntegrable_const
    (((Pq_cont hq.le hq1).intervalIntegrable _ _).const_mul A), intervalIntegral.integral_const_mul,
    int_Pq_partial hq.le hq1, intervalIntegral.integral_const]
  simp only [Real.sin_pi, mul_zero, zero_div, Real.arctan_zero, add_zero, sub_zero, smul_eq_mul,
    mul_one]
  field_simp
  ring

omit hA0 hAs in
theorem Gq_cont : Continuous (Gq A q) :=
  continuous_iff_continuousAt.mpr fun θ => (hasDerivAt_Gq hq hq1 θ).continuousAt

theorem Gq_image : Gq A q '' Ioo 0 π = Ioo A 1 := by
  have hmono := Gq_strictMono hq hq1 hA0 hAs
  ext u
  constructor
  · rintro ⟨θ, hθ, rfl⟩
    have h1 := hmono hθ.1
    have h2 := hmono hθ.2
    rw [Gq_zero] at h1
    rw [Gq_pi hq hq1] at h2
    exact ⟨h1, h2⟩
  · intro hu
    have := intermediate_value_Ioo Real.pi_pos.le (Gq_cont (A := A) hq hq1).continuousOn
    rw [Gq_zero, Gq_pi hq hq1] at this
    exact this hu

theorem Gq_Ginv {u : ℝ} (hu : u ∈ Ioo A 1) : Gq A q (Ginv A q u) = u := by
  rw [← Gq_image hq hq1 hA0 hAs] at hu
  exact Function.invFunOn_eq hu

theorem Ginv_mem {u : ℝ} (hu : u ∈ Ioo A 1) : Ginv A q u ∈ Ioo 0 π := by
  rw [← Gq_image hq hq1 hA0 hAs] at hu
  exact Function.invFunOn_mem hu

theorem Ginv_Gq {θ : ℝ} (hθ : θ ∈ Ioo 0 π) : Ginv A q (Gq A q θ) = θ :=
  (Gq_strictMono hq hq1 hA0 hAs).injective.injOn.leftInvOn_invFunOn hθ

theorem Qu_Gq {θ : ℝ} (hθ : θ ∈ Ioo 0 π) : Qu A q (Gq A q θ) = dth (D0q q) q θ := by
  have h : Gq A q θ ∈ Ioo A 1 := by rw [← Gq_image hq hq1 hA0 hAs]; exact ⟨θ, hθ, rfl⟩
  simp only [Qu, if_neg (not_le.mpr h.1), if_pos h.2, Ginv_Gq hq hq1 hA0 hAs hθ]

omit hA0 hAs in
theorem Qu_mem (u : ℝ) : Qu A q u ∈ Icc 0 2 := by
  unfold Qu
  split_ifs
  · exact ⟨le_rfl, zero_le_two⟩
  · exact dth_mem02 hq _
  · exact ⟨zero_le_two, le_rfl⟩

theorem Qu_mono : Monotone (Qu A q) := by
  have hmono := Gq_strictMono hq hq1 hA0 hAs
  have hD := D0q_pos q hq.le
  intro u v huv
  unfold Qu
  by_cases hu : u ≤ A
  · rw [if_pos hu]
    split_ifs
    · exact le_rfl
    · exact (dth_mem02 hq _).1
    · exact zero_le_two
  · have hv : ¬ v ≤ A := fun h => hu (huv.trans h)
    rw [if_neg hu, if_neg hv]
    by_cases hu1 : u < 1
    · rw [if_pos hu1]
      by_cases hv1 : v < 1
      · rw [if_pos hv1]
        have mu : u ∈ Ioo A 1 := ⟨not_le.mp hu, hu1⟩
        have mv : v ∈ Ioo A 1 := ⟨not_le.mp hv, hv1⟩
        have hle : Ginv A q u ≤ Ginv A q v := by
          by_contra hc
          push Not at hc
          have := hmono hc
          rw [Gq_Ginv hq hq1 hA0 hAs mu, Gq_Ginv hq hq1 hA0 hAs mv] at this
          linarith
        exact dth_mono hD hq (Ginv_mem hq hq1 hA0 hAs mu).1.le (Ginv_mem hq hq1 hA0 hAs mv).2.le hle
      · rw [if_neg hv1]; exact (dth_mem02 hq _).2
    · have hv1 : ¬ v < 1 := fun h => hu1 (lt_of_le_of_lt huv h)
      rw [if_neg hu1, if_neg hv1]

/-- **Lemma Q**: `∫_0^1 log|y - Q(u)| du = V_{μ_A}(y)` for every `y`. -/
theorem VQ_eq_VA (y : ℝ) : VQ (Qu A q) y = VA A q y := by
  have hπ := Real.pi_pos
  have hA1 : A < 1 := A_lt_one hq hq1 hA0 hAs
  have hmono := Gq_strictMono hq hq1 hA0 hAs
  set g : ℝ → ℝ := fun u => Real.log (y - Qu A q u) with hg
  set h : ℝ → ℝ := fun θ => wA A q θ * Real.log (y - dth (D0q q) q θ) with hh
  have hL := ii_log_dth hq y
  have hL' : IntervalIntegrable (fun θ => Real.log (y - dth (D0q q) q θ)) volume (-π) π := by
    simpa only [Real.log_abs] using hL
  have hhi : IntervalIntegrable h volume 0 π := by
    have : IntervalIntegrable (fun θ => Real.log (y - dth (D0q q) q θ)) volume 0 π :=
      hL'.mono_set (by
        rw [uIcc_of_le hπ.le, uIcc_of_le (by linarith)]
        exact Icc_subset_Icc (by linarith) le_rfl)
    exact this.continuousOn_mul (wA_cont hq hq1).continuousOn
  have himg := Gq_image hq hq1 hA0 hAs
  have hderiv : ∀ θ ∈ Ioo 0 π, HasDerivWithinAt (Gq A q) (wA A q θ) (Ioo 0 π) θ :=
    fun θ _ => (hasDerivAt_Gq hq hq1 θ).hasDerivWithinAt
  have hcv := integral_image_eq_integral_abs_deriv_smul measurableSet_Ioo hderiv
    hmono.injective.injOn g
  rw [himg] at hcv
  have hcongr : EqOn (fun θ => |wA A q θ| • g (Gq A q θ)) h (Ioo 0 π) := by
    intro θ hθ
    simp only [hg, hh, smul_eq_mul, abs_of_pos (wA_pos hq hq1 hA0 hAs θ),
      Qu_Gq hq hq1 hA0 hAs hθ]
  have hR : ∫ θ in Ioo 0 π, |wA A q θ| • g (Gq A q θ) = ∫ θ in Ioo 0 π, h θ :=
    setIntegral_congr_fun measurableSet_Ioo hcongr
  have hgi : IntegrableOn g (Ioo A 1) := by
    rw [← himg, integrableOn_image_iff_integrableOn_abs_deriv_smul measurableSet_Ioo hderiv
      hmono.injective.injOn]
    exact (integrableOn_congr_fun hcongr measurableSet_Ioo).mpr
      ((intervalIntegrable_iff_integrableOn_Ioo_of_le hπ.le).mp hhi)
  have hg0 : IntervalIntegrable g volume 0 A := by
    have : IntervalIntegrable (fun _ : ℝ => Real.log y) volume 0 A := intervalIntegrable_const
    refine this.congr fun u hu => ?_
    rw [uIoc_of_le hA0.le] at hu
    simp only [hg, Qu, if_pos hu.2, sub_zero]
  have hg1 : IntervalIntegrable g volume A 1 :=
    (intervalIntegrable_iff_integrableOn_Ioo_of_le hA1.le).mpr hgi
  unfold VQ
  rw [← intervalIntegral.integral_add_adjacent_intervals hg0 hg1]
  have e0 : ∫ u in (0 : ℝ)..A, g u = A * Real.log y := by
    rw [intervalIntegral.integral_congr (g := fun _ => Real.log y) (fun u hu => by
      rw [uIcc_of_le hA0.le] at hu
      simp only [hg, Qu, if_pos hu.2, sub_zero])]
    simp
  have e1 : ∫ u in A..1, g u = ∫ θ in (0 : ℝ)..π, h θ := by
    rw [intervalIntegral.integral_of_le hA1.le, integral_Ioc_eq_integral_Ioo, hcv, hR,
      intervalIntegral.integral_of_le hπ.le, integral_Ioc_eq_integral_Ioo]
  rw [e0, e1]
  unfold VA
  have hfull : IntervalIntegrable
      (fun θ => Real.log |y - dth (D0q q) q θ| * (1 - A * Pq q θ)) volume (-π) π :=
    hL.mul_continuousOn (continuous_const.sub (continuous_const.mul (Pq_cont hq.le hq1))).continuousOn
  rw [int_split hfull]
  have heven : ∀ t, Real.log |y - dth (D0q q) q (-t)| * (1 - A * Pq q (-t)) =
      Real.log |y - dth (D0q q) q t| * (1 - A * Pq q t) := by
    intro t
    simp only [dth, Pq, Real.cos_neg]
  simp only [heven]
  have hint : ∫ θ in (0 : ℝ)..π, h θ =
      1 / π * ∫ t in (0 : ℝ)..π, Real.log |y - dth (D0q q) q t| * (1 - A * Pq q t) := by
    rw [← intervalIntegral.integral_const_mul]
    refine intervalIntegral.integral_congr fun θ _ => ?_
    simp only [hh, wA, Real.log_abs]
    ring
  rw [hint, Real.log_abs]
  ring

end Q

/-! ### Measurability, positivity outside `(-1, 3]` -/

theorem VQ_measurable {Q : ℝ → ℝ} (hQ : Monotone Q) : Measurable (VQ Q) := by
  have hF := measurable_F hQ
  have e : VQ Q = fun y => ∫ u in Ioc (0 : ℝ) 1, Real.log (y - Q u) := by
    funext y
    unfold VQ
    exact intervalIntegral.integral_of_le zero_le_one
  rw [e]
  exact (hF.stronglyMeasurable.integral_prod_right' (ν := volume.restrict (Ioc (0 : ℝ) 1))).measurable

theorem VN_measurable (Q : ℝ → ℝ) (N : ℕ) : Measurable (VN Q N) :=
  (Finset.measurable_sum _ fun j _ =>
    Real.measurable_log.comp (measurable_id.sub_const _)).div_const _

theorem log_nonneg_far {y t : ℝ} (ht : t ∈ Icc (0 : ℝ) 2) (hy : y ∉ Ioc (-1 : ℝ) 3) :
    0 ≤ Real.log (y - t) := by
  rw [← Real.log_abs]
  refine Real.log_nonneg ?_
  simp only [mem_Ioc, not_and_or, not_lt, not_le] at hy
  rcases hy with h | h
  · rw [abs_of_neg (by linarith [ht.1])]; linarith [ht.1, ht.2]
  · rw [abs_of_pos (by linarith [ht.2])]; linarith [ht.1, ht.2]

theorem VQ_nonneg_out {Q : ℝ → ℝ} (hQr : ∀ u, Q u ∈ Icc (0 : ℝ) 2) {y : ℝ} (hy : y ∉ Ioc (-1 : ℝ) 3) :
    0 ≤ VQ Q y :=
  intervalIntegral.integral_nonneg zero_le_one fun u _ => log_nonneg_far (hQr u) hy

theorem VN_nonneg_out {Q : ℝ → ℝ} (hQr : ∀ u, Q u ∈ Icc (0 : ℝ) 2) (N : ℕ) {y : ℝ}
    (hy : y ∉ Ioc (-1 : ℝ) 3) : 0 ≤ VN Q N y :=
  div_nonneg (Finset.sum_nonneg fun j _ => log_nonneg_far (hQr _) hy) (Nat.cast_nonneg N)

/-! ### Zeros off the platform for `C(A) ≥ 0` (Lean RED L-242), continuity in `A` -/

theorem zero_off_platform {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A)
    (hAs : A * (1 + q) < 1 - q) (hC : 0 ≤ CA A q) :
    ∃ a b : ℝ, ∀ y, VA A q y = 0 → y ∉ Icc (D0q q * (1 - q) ^ 2) (D0q q * (1 + q) ^ 2) →
      y = 0 ∨ y = a ∨ y = b := by
  obtain ⟨pp, hqpp, hpp1, hGpp, hpp, hpp'⟩ := exists_pplus hq hq1 hA0 hAs hC
  obtain ⟨pm, hpm0, hpmq, hGpm, hpm, hpm'⟩ := exists_pminus hq hq1 hA0 hAs (CA A q)
  have hD := D0q_pos q hq.le
  refine ⟨xoff (D0q q) q pm, xoff (D0q q) q pp, fun y hV hy => ?_⟩
  by_cases hy0 : y = 0
  · exact Or.inl hy0
  right
  simp only [mem_Icc, not_and_or, not_le] at hy
  rcases hy with hyl | hyr
  · obtain ⟨p, hp0, hp1, rfl⟩ := exists_xoff hD hq hyl
    have hpq : p ≠ q := by
      rintro rfl
      exact hy0 (xoff_self hq)
    rw [VA_left hq hq1 hp0 hp1 hpq, sub_eq_zero] at hV
    rcases lt_or_gt_of_ne hpq with h | h
    · rcases lt_trichotomy p pm with h' | h' | h'
      · have := (hpm' p hp0 h).mpr h'; linarith
      · exact Or.inl (by rw [h'])
      · have := (hpm p hp0 h).mpr h'; linarith
    · rcases lt_trichotomy p pp with h' | h' | h'
      · have := (hpp p h hp1).mpr h'; linarith
      · exact Or.inr (by rw [h'])
      · have := (hpp' p h hp1).mpr h'; linarith
  · obtain ⟨p, hp0, hp1, rfl⟩ := exists_yR hD hq hyr
    have := VA_right hA0.le (A_lt_one hq hq1 hA0 hAs).le hq hq1 hp0 hp1
    linarith

theorem VA_continuous_A {q : ℝ} (hq : 0 < q) (hq1 : q < 1) (y : ℝ) :
    Continuous fun A => VA A q y := by
  have e : (fun A => VA A q y) = fun A =>
      1 / (2 * π) * (∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ|) -
        A * (1 / (2 * π) * ∫ θ in (-π)..π, Real.log |y - dth (D0q q) q θ| * Pq q θ) +
        A * Real.log |y| :=
    funext fun A => VA_eq hq hq1 (ii_log_dth hq y)
  rw [e]
  fun_prop

theorem VA_on_platform {A q y : ℝ} (hq : 0 < q) (hq1 : q < 1)
    (hy : y ∈ Icc (D0q q * (1 - q) ^ 2) (D0q q * (1 + q) ^ 2)) : VA A q y = CA A q := by
  obtain ⟨θ, rfl⟩ := exists_dth (D0q_pos q hq.le) hq hy.1 hy.2
  exact VA_platform hq hq1 θ

end EP1038.Stage9
