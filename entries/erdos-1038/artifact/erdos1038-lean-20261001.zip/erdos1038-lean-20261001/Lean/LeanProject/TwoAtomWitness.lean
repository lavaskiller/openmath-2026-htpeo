import LeanProject.TwoAtom

/-!
# EP-1038: the two-atom witness of proof.md Lemma 6.4, reduced to the scalar inequality `φ > 0`

`witness_of_phi`: if `0 < a < 1`, `B - a > 1`, `0 < B - a - 2 < 1` and
`log a · log(B - a - 2) < log(a + 2) · log(B - a)` (with `B = 2√2`, `a = √2 - 1 + u` this is
`φ(u) > 0` of Lemma 6.4), then some `C > 0` makes `W(t) = log t + C log(B - t)` positive on all of
`[a, a + 2]` (the endpoints suffice because `W` is concave).

`two_atom_of_phi`: combined with `two_atom_contradiction`, the configuration of Lemma 6.3 is
impossible under the same scalar inequality. What remains unformalised for this branch is the
scalar inequality itself (proof.md Lemma 6.4 (A1)/(A2), or Remark 6.4′) and the reduction `f ↦ g`.
-/

open Real MeasureTheory

namespace EP1038

/-- Concavity of `W(t) = log t + C log(B - t)`: on `[a, b] ⊂ (0, B)`, `W ≥ min(W(a), W(b))`
in the form needed here. -/
theorem W_pos_of_endpoints {a b B C : ℝ} (ha : 0 < a) (hab : a < b) (hbB : b < B) (hC : 0 ≤ C)
    (hWa : 0 < Real.log a + C * Real.log (B - a))
    (hWb : 0 < Real.log b + C * Real.log (B - b)) :
    ∀ t ∈ Set.Icc a b, 0 < Real.log t + C * Real.log (B - t) := by
  intro t ⟨hta, htb⟩
  set l : ℝ := (t - a) / (b - a) with hl
  have hba : 0 < b - a := by linarith
  have hl0 : 0 ≤ l := div_nonneg (by linarith) hba.le
  have hl1 : l ≤ 1 := (div_le_one hba).mpr (by linarith)
  have ht : t = (1 - l) * a + l * b := by
    rw [hl]; field_simp; ring
  have hBt : B - t = (1 - l) * (B - a) + l * (B - b) := by rw [ht]; ring
  have hcc := strictConcaveOn_log_Ioi.concaveOn
  have c1 : (1 - l) * Real.log a + l * Real.log b ≤ Real.log t := by
    have := hcc.2 (Set.mem_Ioi.mpr ha) (Set.mem_Ioi.mpr (by linarith : (0 : ℝ) < b))
      (by linarith : (0 : ℝ) ≤ 1 - l) hl0 (by ring)
    simpa [smul_eq_mul, ← ht] using this
  have c2 : (1 - l) * Real.log (B - a) + l * Real.log (B - b) ≤ Real.log (B - t) := by
    have := hcc.2 (Set.mem_Ioi.mpr (by linarith : (0 : ℝ) < B - a))
      (Set.mem_Ioi.mpr (by linarith : (0 : ℝ) < B - b))
      (by linarith : (0 : ℝ) ≤ 1 - l) hl0 (by ring)
    simpa [smul_eq_mul, ← hBt] using this
  have key : (1 - l) * (Real.log a + C * Real.log (B - a)) + l * (Real.log b + C * Real.log (B - b))
      ≤ Real.log t + C * Real.log (B - t) := by nlinarith
  have pos : 0 < (1 - l) * (Real.log a + C * Real.log (B - a)) +
      l * (Real.log b + C * Real.log (B - b)) := by
    rcases eq_or_lt_of_le hl0 with h | h
    · rw [← h]; simpa using hWa
    · have : 0 ≤ (1 - l) * (Real.log a + C * Real.log (B - a)) :=
        mul_nonneg (by linarith) hWa.le
      nlinarith
  linarith

/-- **Lemma 6.4, given the scalar inequality**: a suitable `C > 0` exists. -/
theorem witness_of_phi {a B : ℝ} (ha : 0 < a) (ha1 : a < 1) (hB1 : 1 < B - a)
    (hB2 : 0 < B - a - 2) (hB3 : B - a - 2 < 1)
    (hphi : Real.log a * Real.log (B - a - 2) < Real.log (a + 2) * Real.log (B - a)) :
    ∃ C > 0, ∀ t ∈ Set.Icc a (a + 2), 0 < Real.log t + C * Real.log (B - t) := by
  have la : Real.log a < 0 := Real.log_neg ha ha1
  have lB : 0 < Real.log (B - a) := Real.log_pos hB1
  have la2 : 0 < Real.log (a + 2) := Real.log_pos (by linarith)
  have lB2 : Real.log (B - a - 2) < 0 := Real.log_neg hB2 hB3
  set Cm := -Real.log a / Real.log (B - a) with hCm
  set Cp := Real.log (a + 2) / (-Real.log (B - a - 2)) with hCp
  have hCm0 : 0 < Cm := div_pos (by linarith) lB
  have hlt : Cm < Cp := by
    rw [hCm, hCp, div_lt_div_iff₀ lB (by linarith)]
    nlinarith
  refine ⟨(Cm + Cp) / 2, by linarith, ?_⟩
  apply W_pos_of_endpoints ha (by linarith) (by linarith) (by linarith)
  · -- W(a) > 0
    have : Cm * Real.log (B - a) = -Real.log a := by
      rw [hCm]; field_simp
    nlinarith
  · -- W(a + 2) > 0
    have e : B - (a + 2) = B - a - 2 := by ring
    rw [e]
    have : Cp * Real.log (B - a - 2) = -Real.log (a + 2) := by
      rw [hCp, div_mul_eq_mul_div, div_eq_iff (by linarith : -Real.log (B - a - 2) ≠ 0)]; ring
    nlinarith

/-- The two-atom branch of the supremum argument, reduced to the scalar inequality. -/
theorem two_atom_of_phi {n : ℕ} (hn : 0 < n) (q : Fin n → ℝ) {a B y : ℝ}
    (ha : 0 < a) (ha1 : a < 1) (hB1 : 1 < B - a) (hB2 : 0 < B - a - 2) (hB3 : B - a - 2 < 1)
    (hphi : Real.log a * Real.log (B - a - 2) < Real.log (a + 2) * Real.log (B - a))
    (hq : ∀ j, q j ∈ Set.Icc a (a + 2)) (h0 : ∏ j, q j = 1)
    (hy : |∏ j, (y - q j)| ≤ 1)
    (hvol : ENNReal.ofReal B ≤ volume (Set.Icc 0 y ∩ {x | |∏ j, (x - q j)| ≤ 1})) : False := by
  obtain ⟨C, hC, hW⟩ := witness_of_phi ha ha1 hB1 hB2 hB3 hphi
  exact two_atom_contradiction hn q ha hq (by linarith) hC h0 hy hvol hW

end EP1038
