import LeanProject.RefDensities

/-!
# EP-1038, Stage 12, Lemma 12.1(4) (positivity of the block masses), angle form

* `Pq_strict_anti`: for `0 < ρ < 1`, `P_ρ` is strictly decreasing on `[0, π]`.
* `alpha_pos`, `Bf_pos`: `α > 0` and `B > 0` on `(0, π]` (with `α(0) ≥ 0`, i.e. (H1), and
  `σ₊ > 0`, `ρ₊ > 0`).
* `indicator_int_pos`: `∫_0^π 1_J h > 0` for continuous `h` with `h ≥ 0` on `J = [θ₁, θ₂] ⊆ [0, π]`,
  `θ₁ < θ₂`, and `h > 0` on `(θ₁, θ₂)`.
* `block_ineq_ref'` (**Theorem 12.8** for the reference, angle form): `block_ineq_ref` without the
  positivity hypotheses `Q, R > 0`, which now follow (Lemma 12.1(4)).
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

theorem Pq_strict_anti {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1) {x y : ℝ} (hx : 0 ≤ x) (hxy : x < y)
    (hy : y ≤ π) : Pq q y < Pq q x := by
  have hc : Real.cos y < Real.cos x := Real.cos_lt_cos_of_nonneg_of_le_pi hx hy hxy
  unfold Pq
  apply div_lt_div_of_pos_left (by nlinarith) (Pq_den_pos hq0.le hq1 x)
  nlinarith

theorem alpha_pos {k ρ0 θ : ℝ} (hk : 0 < k) (h0 : 0 < ρ0) (h1 : ρ0 < 1)
    (hH1 : 0 ≤ alpha k ρ0 0) (hθ0 : 0 < θ) (hθ : θ ≤ π) : 0 < alpha k ρ0 θ := by
  have := Pq_strict_anti h0 h1 le_rfl hθ0 hθ
  unfold alpha at hH1 ⊢
  nlinarith

theorem Bf_pos {sp sm rp rm θ : ℝ} (hsp : 0 < sp) (hsm : 0 ≤ sm) (hrp0 : 0 < rp) (hrp1 : rp < 1)
    (hrm0 : 0 ≤ rm) (hrm1 : rm < 1) (hθ0 : 0 < θ) (hθ : θ ≤ π) : 0 < Bf sp sm rp rm θ := by
  unfold Bf
  have h1 := Pq_strict_anti hrp0 hrp1 le_rfl hθ0 hθ
  have h2 := Pq_anti hrm0 hrm1 le_rfl hθ0.le hθ
  have := mul_pos hsp (sub_pos.mpr h1)
  have := mul_nonneg hsm (sub_nonneg.mpr h2)
  linarith

theorem indicator_int_pos {h : ℝ → ℝ} (hc : Continuous h) {θ1 θ2 : ℝ} (hθ1 : 0 ≤ θ1)
    (h12 : θ1 < θ2) (hθ2 : θ2 ≤ π) (hpos : ∀ x ∈ Ioo θ1 θ2, 0 < h x)
    (hnn : ∀ x ∈ Icc θ1 θ2, 0 ≤ h x) :
    0 < ∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator h t := by
  have hπ := Real.pi_pos
  have hint : IntervalIntegrable ((Icc θ1 θ2).indicator h) volume 0 π := by
    refine (hc.intervalIntegrable 0 π).mono_fun
      (hc.measurable.indicator measurableSet_Icc).aestronglyMeasurable ?_
    exact Eventually.of_forall fun x => norm_indicator_le_norm_self h x
  have hnn' : 0 ≤ᵐ[volume] (Icc θ1 θ2).indicator h := by
    refine Eventually.of_forall fun x => ?_
    by_cases hx : x ∈ Icc θ1 θ2
    · rw [indicator_of_mem hx]; exact hnn x hx
    · rw [indicator_of_notMem hx]; rfl
  rw [intervalIntegral.integral_pos_iff_support_of_nonneg_ae hnn' hint]
  refine ⟨hπ, ?_⟩
  have hsub : Ioo θ1 θ2 ⊆ Function.support ((Icc θ1 θ2).indicator h) ∩ Ioc 0 π := by
    intro x hx
    refine ⟨?_, ⟨by linarith [hx.1], by linarith [hx.2]⟩⟩
    rw [Function.mem_support, indicator_of_mem (Ioo_subset_Icc_self hx)]
    exact (hpos x hx).ne'
  refine lt_of_lt_of_le ?_ (measure_mono hsub)
  rw [Real.volume_Ioo]
  exact ENNReal.ofReal_pos.mpr (sub_pos.mpr h12)

/-- **Theorem 12.8** for the reference (angle form), with Lemma 12.1(4) proved: for
`J = [θ₁, θ₂] ⊆ [0, π]` with `θ₁ < θ₂`, (12.5) holds for `F = 1_J α/a_π`, `G = 1_J B/b_π`. -/
theorem block_ineq_ref' {k ρ0 sp sm rp rm θ1 θ2 D0 Ceff : ℝ} (hk : 0 < k) (hρ0 : 0 < ρ0)
    (hρ1 : ρ0 < 1) (hH1 : ∀ θ, 0 ≤ alpha k ρ0 θ) (hsp : 0 < sp) (hsm : 0 ≤ sm) (hrp0 : 0 < rp)
    (hrp1 : rp < 1) (hrm0 : 0 ≤ rm) (hrm1 : rm < 1) (hθ1 : 0 ≤ θ1) (h12 : θ1 < θ2)
    (hθ2 : θ2 ≤ π) (hD : 0 < D0) :
    rhs (Real.log (2 * (D0 * ρ0) / (alpha k ρ0 π * Bf sp sm rp rm π))) Ceff (alpha k ρ0 π)
        (∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t)
        (∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) t) ≤
      (Real.log (D0 * ρ0) + (∫ t in (0 : ℝ)..π,
          (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t *
          ∫ s in (0 : ℝ)..π, (Real.log |dth D0 ρ0 t - dth D0 ρ0 s| - Real.log (D0 * ρ0)) *
            (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) s) /
          ((∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t) *
            (∫ t in (0 : ℝ)..π,
              (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) t))) -
        Real.log (alpha k ρ0 π * (∫ t in (0 : ℝ)..π,
            (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t) / π *
          (Bf sp sm rp rm π * (∫ t in (0 : ℝ)..π,
            (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) t) / π) / 2) -
        Ceff / (alpha k ρ0 π * (∫ t in (0 : ℝ)..π,
          (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t) / π) := by
  have ha : 0 < alpha k ρ0 π := lt_of_lt_of_le one_pos (one_le_api hk.le hρ0.le)
  have hbpi : 0 < Bf sp sm rp rm π :=
    Bf_pos hsp hsm hrp0 hrp1 hrm0 hrm1 Real.pi_pos le_rfl
  have hQ := indicator_int_pos ((alpha_cont k ρ0 hρ0.le hρ1).div_const (alpha k ρ0 π)) hθ1 h12 hθ2
    (fun x hx => div_pos (alpha_pos hk hρ0 hρ1 (hH1 0) (by linarith [hx.1]) (by linarith [hx.2]))
      ha)
    (fun x _ => div_nonneg (hH1 x) ha.le)
  have hR := indicator_int_pos ((Bf_cont hrp0.le hrp1 hrm0 hrm1).div_const (Bf sp sm rp rm π))
    hθ1 h12 hθ2
    (fun x hx => div_pos (Bf_pos hsp hsm hrp0 hrp1 hrm0 hrm1 (by linarith [hx.1])
      (by linarith [hx.2])) hbpi)
    (fun x hx => div_nonneg (Bf_nonneg hsp.le hsm hrp0.le hrp1 hrm0 hrm1 (hθ1.trans hx.1)
      (hx.2.trans hθ2)) hbpi.le)
  exact block_ineq_ref hk.le hρ0 hρ1 hH1 hsp hsm hrp0 hrp1 hrm0 hrm1 hθ1 hθ2 hD hQ hR

end EP1038.Arc
