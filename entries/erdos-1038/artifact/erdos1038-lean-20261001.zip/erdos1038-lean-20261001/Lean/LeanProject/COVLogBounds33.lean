import LeanProject.COVLogTwo
import LeanProject.COVLogBounds29
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2640 : RB (Real.log ((54351211 : ℝ) / 50000000)) ((2086097 : ℝ) / 25000000) ((8344389 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((54351211 : ℝ) / 50000000)) (t := ((4351211 : ℝ) / 104351211))
    (lo := ((2086097 : ℝ) / 25000000)) (hi := ((8344389 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2641 : RB (Real.log ((109079861 : ℝ) / 100000000)) ((8691009 : ℝ) / 100000000) ((869101 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((109079861 : ℝ) / 100000000)) (t := ((9079861 : ℝ) / 209079861))
    (lo := ((8691009 : ℝ) / 100000000)) (hi := ((869101 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2642 : RB (Real.log ((10945993 : ℝ) / 10000000)) ((2259709 : ℝ) / 25000000) ((9038837 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10945993 : ℝ) / 10000000)) (t := ((945993 : ℝ) / 20945993))
    (lo := ((2259709 : ℝ) / 25000000)) (hi := ((9038837 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2643 : RB (Real.log ((186994047 : ℝ) / 100000000)) ((62590659 : ℝ) / 100000000) ((62590661 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((186994047 : ℝ) / 200000000)) (t := ((-13005953 : ℝ) / 386994047))
    (lo := ((-6724059 : ℝ) / 100000000)) (hi := ((-3362029 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((186994047 : ℝ) / 100000000) = Real.log ((186994047 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((186994047 : ℝ) / 100000000) = ((186994047 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2644 : RB (Real.log ((109842657 : ℝ) / 100000000)) ((2346969 : ℝ) / 25000000) ((9387877 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((109842657 : ℝ) / 100000000)) (t := ((9842657 : ℝ) / 209842657))
    (lo := ((2346969 : ℝ) / 25000000)) (hi := ((9387877 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2645 : RB (Real.log ((11022807 : ℝ) / 10000000)) ((9738139 : ℝ) / 100000000) ((486907 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((11022807 : ℝ) / 10000000)) (t := ((1022807 : ℝ) / 21022807))
    (lo := ((9738139 : ℝ) / 100000000)) (hi := ((486907 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2646 : RB (Real.log ((110616197 : ℝ) / 100000000)) ((10089633 : ℝ) / 100000000) ((5044817 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((110616197 : ℝ) / 100000000)) (t := ((10616197 : ℝ) / 210616197))
    (lo := ((10089633 : ℝ) / 100000000)) (hi := ((5044817 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2647 : RB (Real.log ((185887573 : ℝ) / 100000000)) ((12399437 : ℝ) / 20000000) ((61997187 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((185887573 : ℝ) / 200000000)) (t := ((-14112427 : ℝ) / 385887573))
    (lo := ((-7317533 : ℝ) / 100000000)) (hi := ((-1829383 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((185887573 : ℝ) / 100000000) = Real.log ((185887573 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((185887573 : ℝ) / 100000000) = ((185887573 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2648 : RB (Real.log ((111007067 : ℝ) / 100000000)) ((10442367 : ℝ) / 100000000) ((81581 : ℝ) / 781250) := by
  have hm := log_bounds_of_series (x := ((111007067 : ℝ) / 100000000)) (t := ((11007067 : ℝ) / 211007067))
    (lo := ((10442367 : ℝ) / 100000000)) (hi := ((81581 : ℝ) / 781250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2649 : RB (Real.log ((111400709 : ℝ) / 100000000)) ((215927 : ℝ) / 2000000) ((10796351 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((111400709 : ℝ) / 100000000)) (t := ((11400709 : ℝ) / 211400709))
    (lo := ((215927 : ℝ) / 2000000)) (hi := ((10796351 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2650 : RB (Real.log ((111797153 : ℝ) / 100000000)) ((1115159 : ℝ) / 10000000) ((11151591 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((111797153 : ℝ) / 100000000)) (t := ((11797153 : ℝ) / 211797153))
    (lo := ((1115159 : ℝ) / 10000000)) (hi := ((11151591 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2651 : RB (Real.log ((28049107 : ℝ) / 25000000)) ((11508097 : ℝ) / 100000000) ((5754049 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((28049107 : ℝ) / 25000000)) (t := ((3049107 : ℝ) / 53049107))
    (lo := ((11508097 : ℝ) / 100000000)) (hi := ((5754049 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2652 : RB (Real.log ((56299283 : ℝ) / 50000000)) ((11865879 : ℝ) / 100000000) ((296647 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((56299283 : ℝ) / 50000000)) (t := ((6299283 : ℝ) / 106299283))
    (lo := ((11865879 : ℝ) / 100000000)) (hi := ((296647 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2653 : RB (Real.log ((113003597 : ℝ) / 100000000)) ((6112473 : ℝ) / 50000000) ((12224947 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((113003597 : ℝ) / 100000000)) (t := ((13003597 : ℝ) / 213003597))
    (lo := ((6112473 : ℝ) / 50000000)) (hi := ((12224947 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2654 : RB (Real.log ((3544111 : ℝ) / 3125000)) ((6292653 : ℝ) / 50000000) ((12585307 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3544111 : ℝ) / 3125000)) (t := ((419111 : ℝ) / 6669111))
    (lo := ((6292653 : ℝ) / 50000000)) (hi := ((12585307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2655 : RB (Real.log ((113822463 : ℝ) / 100000000)) ((1294697 : ℝ) / 10000000) ((12946971 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((113822463 : ℝ) / 100000000)) (t := ((13822463 : ℝ) / 213822463))
    (lo := ((1294697 : ℝ) / 10000000)) (hi := ((12946971 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2656 : RB (Real.log ((114236363 : ℝ) / 100000000)) ((13309947 : ℝ) / 100000000) ((3327487 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((114236363 : ℝ) / 100000000)) (t := ((14236363 : ℝ) / 214236363))
    (lo := ((13309947 : ℝ) / 100000000)) (hi := ((3327487 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2657 : RB (Real.log ((28663321 : ℝ) / 25000000)) ((6837123 : ℝ) / 50000000) ((13674247 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((28663321 : ℝ) / 25000000)) (t := ((3663321 : ℝ) / 53663321))
    (lo := ((6837123 : ℝ) / 50000000)) (hi := ((13674247 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2658 : RB (Real.log ((5753663 : ℝ) / 5000000)) ((7019939 : ℝ) / 50000000) ((14039879 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5753663 : ℝ) / 5000000)) (t := ((753663 : ℝ) / 10753663))
    (lo := ((7019939 : ℝ) / 50000000)) (hi := ((14039879 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2659 : RB (Real.log ((115496323 : ℝ) / 100000000)) ((288137 : ℝ) / 2000000) ((14406851 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((115496323 : ℝ) / 100000000)) (t := ((15496323 : ℝ) / 215496323))
    (lo := ((288137 : ℝ) / 2000000)) (hi := ((14406851 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2660 : RB (Real.log ((115922509 : ℝ) / 100000000)) ((591007 : ℝ) / 4000000) ((1846897 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((115922509 : ℝ) / 100000000)) (t := ((15922509 : ℝ) / 215922509))
    (lo := ((591007 : ℝ) / 4000000)) (hi := ((1846897 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2661 : RB (Real.log ((116351851 : ℝ) / 100000000)) ((15144861 : ℝ) / 100000000) ((7572431 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((116351851 : ℝ) / 100000000)) (t := ((16351851 : ℝ) / 216351851))
    (lo := ((15144861 : ℝ) / 100000000)) (hi := ((7572431 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2662 : RB (Real.log ((58392193 : ℝ) / 50000000)) ((15515919 : ℝ) / 100000000) ((193949 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((58392193 : ℝ) / 50000000)) (t := ((8392193 : ℝ) / 108392193))
    (lo := ((15515919 : ℝ) / 100000000)) (hi := ((193949 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2663 : RB (Real.log ((117220149 : ℝ) / 100000000)) ((15888359 : ℝ) / 100000000) ((397209 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((117220149 : ℝ) / 100000000)) (t := ((17220149 : ℝ) / 217220149))
    (lo := ((15888359 : ℝ) / 100000000)) (hi := ((397209 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2664 : RB (Real.log ((14707397 : ℝ) / 12500000)) ((1016387 : ℝ) / 6250000) ((16262193 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((14707397 : ℝ) / 12500000)) (t := ((2207397 : ℝ) / 27207397))
    (lo := ((1016387 : ℝ) / 6250000)) (hi := ((16262193 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2665 : RB (Real.log ((118101503 : ℝ) / 100000000)) ((8318713 : ℝ) / 50000000) ((16637427 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((118101503 : ℝ) / 100000000)) (t := ((18101503 : ℝ) / 218101503))
    (lo := ((8318713 : ℝ) / 50000000)) (hi := ((16637427 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2666 : RB (Real.log ((118547169 : ℝ) / 100000000)) ((8507037 : ℝ) / 50000000) ((680563 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((118547169 : ℝ) / 100000000)) (t := ((18547169 : ℝ) / 218547169))
    (lo := ((8507037 : ℝ) / 50000000)) (hi := ((680563 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2667 : RB (Real.log ((29749053 : ℝ) / 25000000)) ((17392147 : ℝ) / 100000000) ((4348037 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((29749053 : ℝ) / 25000000)) (t := ((4749053 : ℝ) / 54749053))
    (lo := ((17392147 : ℝ) / 100000000)) (hi := ((4348037 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2668 : RB (Real.log ((119448669 : ℝ) / 100000000)) ((8885827 : ℝ) / 50000000) ((3554331 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((119448669 : ℝ) / 100000000)) (t := ((19448669 : ℝ) / 219448669))
    (lo := ((8885827 : ℝ) / 50000000)) (hi := ((3554331 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2669 : RB (Real.log ((5995229 : ℝ) / 5000000)) ((18152607 : ℝ) / 100000000) ((567269 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((5995229 : ℝ) / 5000000)) (t := ((995229 : ℝ) / 10995229))
    (lo := ((18152607 : ℝ) / 100000000)) (hi := ((567269 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2670 : RB (Real.log ((7522749 : ℝ) / 6250000)) ((2316877 : ℝ) / 12500000) ((18535017 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7522749 : ℝ) / 6250000)) (t := ((1272749 : ℝ) / 13772749))
    (lo := ((2316877 : ℝ) / 12500000)) (hi := ((18535017 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2671 : RB (Real.log ((120826923 : ℝ) / 100000000)) ((9459447 : ℝ) / 50000000) ((3783779 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((120826923 : ℝ) / 100000000)) (t := ((20826923 : ℝ) / 220826923))
    (lo := ((9459447 : ℝ) / 50000000)) (hi := ((3783779 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2672 : RB (Real.log ((30323359 : ℝ) / 25000000)) ((19304251 : ℝ) / 100000000) ((4826063 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((30323359 : ℝ) / 25000000)) (t := ((5323359 : ℝ) / 55323359))
    (lo := ((19304251 : ℝ) / 100000000)) (hi := ((4826063 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2673 : RB (Real.log ((184794117 : ℝ) / 100000000)) ((61407213 : ℝ) / 100000000) ((12281443 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((184794117 : ℝ) / 200000000)) (t := ((-15205883 : ℝ) / 384794117))
    (lo := ((-1581501 : ℝ) / 20000000)) (hi := ((-494219 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((184794117 : ℝ) / 100000000) = Real.log ((184794117 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((184794117 : ℝ) / 100000000) = ((184794117 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2674 : RB (Real.log ((63593117 : ℝ) / 50000000)) ((24048223 : ℝ) / 100000000) ((751507 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((63593117 : ℝ) / 50000000)) (t := ((13593117 : ℝ) / 113593117))
    (lo := ((24048223 : ℝ) / 100000000)) (hi := ((751507 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2675 : RB (Real.log ((45661337 : ℝ) / 25000000)) ((60237609 : ℝ) / 100000000) ((60237611 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45661337 : ℝ) / 50000000)) (t := ((-4338663 : ℝ) / 95661337))
    (lo := ((-9077109 : ℝ) / 100000000)) (hi := ((-2269277 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45661337 : ℝ) / 25000000) = Real.log ((45661337 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((45661337 : ℝ) / 25000000) = ((45661337 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2676 : RB (Real.log ((130352697 : ℝ) / 100000000)) ((6626841 : ℝ) / 25000000) ((5301473 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((130352697 : ℝ) / 100000000)) (t := ((30352697 : ℝ) / 230352697))
    (lo := ((6626841 : ℝ) / 25000000)) (hi := ((5301473 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2677 : RB (Real.log ((65721757 : ℝ) / 50000000)) ((13670351 : ℝ) / 50000000) ((27340703 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65721757 : ℝ) / 50000000)) (t := ((15721757 : ℝ) / 115721757))
    (lo := ((13670351 : ℝ) / 50000000)) (hi := ((27340703 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2678 : RB (Real.log ((36317919 : ℝ) / 20000000)) ((29828949 : ℝ) / 50000000) ((596579 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((36317919 : ℝ) / 40000000)) (t := ((-3682081 : ℝ) / 76317919))
    (lo := ((-482841 : ℝ) / 5000000)) (hi := ((-9656819 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((36317919 : ℝ) / 20000000) = Real.log ((36317919 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((36317919 : ℝ) / 20000000) = ((36317919 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
