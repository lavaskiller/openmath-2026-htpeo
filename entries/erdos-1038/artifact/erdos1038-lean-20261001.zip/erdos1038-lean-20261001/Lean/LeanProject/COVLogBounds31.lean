import LeanProject.COVLogTwo
import LeanProject.COVLogBounds27
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2480 : RB (Real.log ((42580699 : ℝ) / 12500000)) ((122567243 : ℝ) / 100000000) ((61283623 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42580699 : ℝ) / 50000000)) (t := ((-7419301 : ℝ) / 92580699))
    (lo := ((-16062193 : ℝ) / 100000000)) (hi := ((-1003887 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42580699 : ℝ) / 12500000) = Real.log ((42580699 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((42580699 : ℝ) / 12500000) = ((42580699 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2481 : RB (Real.log ((35381517 : ℝ) / 25000000)) ((34731373 : ℝ) / 100000000) ((277851 : ℝ) / 800000) := by
  have hm := log_bounds_of_series (x := ((35381517 : ℝ) / 50000000)) (t := ((-14618483 : ℝ) / 85381517))
    (lo := ((-6916669 : ℝ) / 20000000)) (hi := ((-2161459 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35381517 : ℝ) / 25000000) = Real.log ((35381517 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((35381517 : ℝ) / 25000000) = ((35381517 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2482 : RB (Real.log ((43592849 : ℝ) / 50000000)) ((-13712989 : ℝ) / 100000000) ((-3428247 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((43592849 : ℝ) / 50000000)) (t := ((-6407151 : ℝ) / 93592849))
    (lo := ((-13712989 : ℝ) / 100000000)) (hi := ((-3428247 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2483 : RB (Real.log ((43934107 : ℝ) / 50000000)) ((-12933207 : ℝ) / 100000000) ((-6466603 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((43934107 : ℝ) / 50000000)) (t := ((-6065893 : ℝ) / 93934107))
    (lo := ((-12933207 : ℝ) / 100000000)) (hi := ((-6466603 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2484 : RB (Real.log ((41722301 : ℝ) / 50000000)) ((-18098723 : ℝ) / 100000000) ((-9049361 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((41722301 : ℝ) / 50000000)) (t := ((-8277699 : ℝ) / 91722301))
    (lo := ((-18098723 : ℝ) / 100000000)) (hi := ((-9049361 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2485 : RB (Real.log ((16688921 : ℝ) / 20000000)) ((-18098719 : ℝ) / 100000000) ((-9049359 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16688921 : ℝ) / 20000000)) (t := ((-3311079 : ℝ) / 36688921))
    (lo := ((-18098719 : ℝ) / 100000000)) (hi := ((-9049359 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2486 : RB (Real.log ((22762717 : ℝ) / 50000000)) ((-4918119 : ℝ) / 6250000) ((-39344951 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((22762717 : ℝ) / 25000000)) (t := ((-2237283 : ℝ) / 47762717))
    (lo := ((-1875037 : ℝ) / 20000000)) (hi := ((-585949 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22762717 : ℝ) / 50000000) = Real.log ((22762717 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22762717 : ℝ) / 50000000) = ((22762717 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2487 : RB (Real.log ((41775441 : ℝ) / 50000000)) ((-8985719 : ℝ) / 50000000) ((-17971437 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41775441 : ℝ) / 50000000)) (t := ((-8224559 : ℝ) / 91775441))
    (lo := ((-8985719 : ℝ) / 50000000)) (hi := ((-17971437 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2488 : RB (Real.log ((16710177 : ℝ) / 20000000)) ((-8985717 : ℝ) / 50000000) ((-17971433 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16710177 : ℝ) / 20000000)) (t := ((-3289823 : ℝ) / 36710177))
    (lo := ((-8985717 : ℝ) / 50000000)) (hi := ((-17971433 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2489 : RB (Real.log ((2847311 : ℝ) / 6250000)) ((-19655161 : ℝ) / 25000000) ((-39310321 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2847311 : ℝ) / 3125000)) (t := ((-277689 : ℝ) / 5972311))
    (lo := ((-372237 : ℝ) / 4000000)) (hi := ((-2326481 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2847311 : ℝ) / 6250000) = Real.log ((2847311 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((2847311 : ℝ) / 6250000) = ((2847311 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2490 : RB (Real.log ((341069047 : ℝ) / 100000000)) ((4907659 : ℝ) / 4000000) ((61345739 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((341069047 : ℝ) / 400000000)) (t := ((-58930953 : ℝ) / 741069047))
    (lo := ((-15937961 : ℝ) / 100000000)) (hi := ((-398449 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((341069047 : ℝ) / 100000000) = Real.log ((341069047 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((341069047 : ℝ) / 100000000) = ((341069047 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2491 : RB (Real.log ((6821381 : ℝ) / 2000000)) ((30672869 : ℝ) / 25000000) ((122691479 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6821381 : ℝ) / 8000000)) (t := ((-1178619 : ℝ) / 14821381))
    (lo := ((-398449 : ℝ) / 2500000)) (hi := ((-15937959 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6821381 : ℝ) / 2000000) = Real.log ((6821381 : ℝ) / 8000000) + 2 * Real.log 2 := by
    rw [show ((6821381 : ℝ) / 2000000) = ((6821381 : ℝ) / 8000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2492 : RB (Real.log ((35363281 : ℝ) / 25000000)) ((34679819 : ℝ) / 100000000) ((34679821 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35363281 : ℝ) / 50000000)) (t := ((-14636719 : ℝ) / 85363281))
    (lo := ((-34634899 : ℝ) / 100000000)) (hi := ((-17317449 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35363281 : ℝ) / 25000000) = Real.log ((35363281 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((35363281 : ℝ) / 25000000) = ((35363281 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2493 : RB (Real.log ((42554561 : ℝ) / 12500000)) ((122505839 : ℝ) / 100000000) ((61252921 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42554561 : ℝ) / 50000000)) (t := ((-7445439 : ℝ) / 92554561))
    (lo := ((-16123597 : ℝ) / 100000000)) (hi := ((-4030899 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42554561 : ℝ) / 12500000) = Real.log ((42554561 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((42554561 : ℝ) / 12500000) = ((42554561 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2494 : RB (Real.log ((85109123 : ℝ) / 25000000)) ((1531323 : ℝ) / 1250000) ((122505843 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((85109123 : ℝ) / 100000000)) (t := ((-14890877 : ℝ) / 185109123))
    (lo := ((-4030899 : ℝ) / 25000000)) (hi := ((-3224719 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85109123 : ℝ) / 25000000) = Real.log ((85109123 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((85109123 : ℝ) / 25000000) = ((85109123 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2495 : RB (Real.log ((70781091 : ℝ) / 50000000)) ((4344611 : ℝ) / 12500000) ((3475689 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((70781091 : ℝ) / 100000000)) (t := ((-29218909 : ℝ) / 170781091))
    (lo := ((-3455783 : ℝ) / 10000000)) (hi := ((-34557829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70781091 : ℝ) / 50000000) = Real.log ((70781091 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70781091 : ℝ) / 50000000) = ((70781091 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2496 : RB (Real.log ((43813617 : ℝ) / 50000000)) ((-2641567 : ℝ) / 20000000) ((-6603917 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((43813617 : ℝ) / 50000000)) (t := ((-6186383 : ℝ) / 93813617))
    (lo := ((-2641567 : ℝ) / 20000000)) (hi := ((-6603917 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2497 : RB (Real.log ((4415427 : ℝ) / 5000000)) ((-12433337 : ℝ) / 100000000) ((-1554167 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4415427 : ℝ) / 5000000)) (t := ((-584573 : ℝ) / 9415427))
    (lo := ((-12433337 : ℝ) / 100000000)) (hi := ((-1554167 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2498 : RB (Real.log ((2608763 : ℝ) / 3125000)) ((-18055813 : ℝ) / 100000000) ((-4513953 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2608763 : ℝ) / 3125000)) (t := ((-516237 : ℝ) / 5733763))
    (lo := ((-18055813 : ℝ) / 100000000)) (hi := ((-4513953 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2499 : RB (Real.log ((83480419 : ℝ) / 100000000)) ((-18055809 : ℝ) / 100000000) ((-141061 : ℝ) / 781250) := by
  have hm := log_bounds_of_series (x := ((83480419 : ℝ) / 100000000)) (t := ((-16519581 : ℝ) / 183480419))
    (lo := ((-18055809 : ℝ) / 100000000)) (hi := ((-141061 : ℝ) / 781250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2500 : RB (Real.log ((45536067 : ℝ) / 100000000)) ((-78666551 : ℝ) / 100000000) ((-78666549 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45536067 : ℝ) / 50000000)) (t := ((-4463933 : ℝ) / 95536067))
    (lo := ((-1168979 : ℝ) / 12500000)) (hi := ((-9351831 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45536067 : ℝ) / 100000000) = Real.log ((45536067 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45536067 : ℝ) / 100000000) = ((45536067 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2501 : RB (Real.log ((83585533 : ℝ) / 100000000)) ((-8964987 : ℝ) / 50000000) ((-17929973 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83585533 : ℝ) / 100000000)) (t := ((-16414467 : ℝ) / 183585533))
    (lo := ((-8964987 : ℝ) / 50000000)) (hi := ((-17929973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2502 : RB (Real.log ((326506 : ℝ) / 390625)) ((-1792997 : ℝ) / 10000000) ((-17929969 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((326506 : ℝ) / 390625)) (t := ((-64119 : ℝ) / 717131))
    (lo := ((-1792997 : ℝ) / 10000000)) (hi := ((-17929969 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2503 : RB (Real.log ((11391813 : ℝ) / 25000000)) ((-7859809 : ℝ) / 10000000) ((-9824761 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((11391813 : ℝ) / 12500000)) (t := ((-1108187 : ℝ) / 23891813))
    (lo := ((-9283371 : ℝ) / 100000000)) (hi := ((-928337 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11391813 : ℝ) / 25000000) = Real.log ((11391813 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11391813 : ℝ) / 25000000) = ((11391813 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2504 : RB (Real.log ((85214113 : ℝ) / 25000000)) ((122629123 : ℝ) / 100000000) ((61314563 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((85214113 : ℝ) / 100000000)) (t := ((-14785887 : ℝ) / 185214113))
    (lo := ((-16000313 : ℝ) / 100000000)) (hi := ((-2000039 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85214113 : ℝ) / 25000000) = Real.log ((85214113 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((85214113 : ℝ) / 25000000) = ((85214113 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2505 : RB (Real.log ((42607057 : ℝ) / 12500000)) ((981033 : ℝ) / 800000) ((15328641 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((42607057 : ℝ) / 50000000)) (t := ((-7392943 : ℝ) / 92607057))
    (lo := ((-16000311 : ℝ) / 100000000)) (hi := ((-1600031 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42607057 : ℝ) / 12500000) = Real.log ((42607057 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((42607057 : ℝ) / 12500000) = ((42607057 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2506 : RB (Real.log ((141489713 : ℝ) / 100000000)) ((17352841 : ℝ) / 50000000) ((8676421 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((141489713 : ℝ) / 200000000)) (t := ((-58510287 : ℝ) / 341489713))
    (lo := ((-8652259 : ℝ) / 25000000)) (hi := ((-6921807 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141489713 : ℝ) / 100000000) = Real.log ((141489713 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141489713 : ℝ) / 100000000) = ((141489713 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2507 : RB (Real.log ((170114551 : ℝ) / 50000000)) ((122444903 : ℝ) / 100000000) ((61222453 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((170114551 : ℝ) / 200000000)) (t := ((-29885449 : ℝ) / 370114551))
    (lo := ((-16184533 : ℝ) / 100000000)) (hi := ((-4046133 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170114551 : ℝ) / 50000000) = Real.log ((170114551 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((170114551 : ℝ) / 50000000) = ((170114551 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2508 : RB (Real.log ((68045821 : ℝ) / 20000000)) ((15305613 : ℝ) / 12500000) ((122444907 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68045821 : ℝ) / 80000000)) (t := ((-11954179 : ℝ) / 148045821))
    (lo := ((-4046133 : ℝ) / 25000000)) (hi := ((-16184531 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68045821 : ℝ) / 20000000) = Real.log ((68045821 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((68045821 : ℝ) / 20000000) = ((68045821 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2509 : RB (Real.log ((70799031 : ℝ) / 50000000)) ((3478223 : ℝ) / 10000000) ((4347779 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((70799031 : ℝ) / 100000000)) (t := ((-29200969 : ℝ) / 170799031))
    (lo := ((-4316561 : ℝ) / 12500000)) (hi := ((-34532487 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70799031 : ℝ) / 50000000) = Real.log ((70799031 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70799031 : ℝ) / 50000000) = ((70799031 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2510 : RB (Real.log ((22016953 : ℝ) / 25000000)) ((-3176577 : ℝ) / 25000000) ((-12706307 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22016953 : ℝ) / 25000000)) (t := ((-2983047 : ℝ) / 47016953))
    (lo := ((-3176577 : ℝ) / 25000000)) (hi := ((-12706307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2511 : RB (Real.log ((44373969 : ℝ) / 50000000)) ((-11937 : ℝ) / 100000) ((-11936999 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((44373969 : ℝ) / 50000000)) (t := ((-5626031 : ℝ) / 94373969))
    (lo := ((-11937 : ℝ) / 100000)) (hi := ((-11936999 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2512 : RB (Real.log ((20878959 : ℝ) / 25000000)) ((-1125837 : ℝ) / 6250000) ((-18013391 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20878959 : ℝ) / 25000000)) (t := ((-4121041 : ℝ) / 45878959))
    (lo := ((-1125837 : ℝ) / 6250000)) (hi := ((-18013391 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2513 : RB (Real.log ((83515839 : ℝ) / 100000000)) ((-18013389 : ℝ) / 100000000) ((-4503347 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((83515839 : ℝ) / 100000000)) (t := ((-16484161 : ℝ) / 183515839))
    (lo := ((-18013389 : ℝ) / 100000000)) (hi := ((-4503347 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2514 : RB (Real.log ((45546579 : ℝ) / 100000000)) ((-19660867 : ℝ) / 25000000) ((-39321733 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((45546579 : ℝ) / 50000000)) (t := ((-4453421 : ℝ) / 95546579))
    (lo := ((-9328749 : ℝ) / 100000000)) (hi := ((-2332187 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45546579 : ℝ) / 100000000) = Real.log ((45546579 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45546579 : ℝ) / 100000000) = ((45546579 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2515 : RB (Real.log ((8361981 : ℝ) / 10000000)) ((-8944487 : ℝ) / 50000000) ((-17888973 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8361981 : ℝ) / 10000000)) (t := ((-1638019 : ℝ) / 18361981))
    (lo := ((-8944487 : ℝ) / 50000000)) (hi := ((-17888973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2516 : RB (Real.log ((83619813 : ℝ) / 100000000)) ((-1788897 : ℝ) / 10000000) ((-17888969 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83619813 : ℝ) / 100000000)) (t := ((-16380187 : ℝ) / 183619813))
    (lo := ((-1788897 : ℝ) / 10000000)) (hi := ((-17888969 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2517 : RB (Real.log ((45577413 : ℝ) / 100000000)) ((-39287897 : ℝ) / 50000000) ((-4910987 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((45577413 : ℝ) / 50000000)) (t := ((-4422587 : ℝ) / 95577413))
    (lo := ((-370443 : ℝ) / 4000000)) (hi := ((-4630537 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45577413 : ℝ) / 100000000) = Real.log ((45577413 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45577413 : ℝ) / 100000000) = ((45577413 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2518 : RB (Real.log ((170322809 : ℝ) / 50000000)) ((490269 : ℝ) / 400000) ((122567253 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((170322809 : ℝ) / 200000000)) (t := ((-29677191 : ℝ) / 370322809))
    (lo := ((-8031093 : ℝ) / 50000000)) (hi := ((-3212437 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170322809 : ℝ) / 50000000) = Real.log ((170322809 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((170322809 : ℝ) / 50000000) = ((170322809 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2519 : RB (Real.log ((340645621 : ℝ) / 100000000)) ((122567251 : ℝ) / 100000000) ((61283627 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((340645621 : ℝ) / 400000000)) (t := ((-59354379 : ℝ) / 740645621))
    (lo := ((-3212437 : ℝ) / 20000000)) (hi := ((-2007773 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340645621 : ℝ) / 100000000) = Real.log ((340645621 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((340645621 : ℝ) / 100000000) = ((340645621 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2520 : RB (Real.log ((141526063 : ℝ) / 100000000)) ((3473137 : ℝ) / 10000000) ((8682843 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((141526063 : ℝ) / 200000000)) (t := ((-58473937 : ℝ) / 341526063))
    (lo := ((-8645837 : ℝ) / 25000000)) (hi := ((-34583347 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141526063 : ℝ) / 100000000) = Real.log ((141526063 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141526063 : ℝ) / 100000000) = ((141526063 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2521 : RB (Real.log ((340023417 : ℝ) / 100000000)) ((12238443 : ℝ) / 10000000) ((122384433 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((340023417 : ℝ) / 400000000)) (t := ((-59976583 : ℝ) / 740023417))
    (lo := ((-8122503 : ℝ) / 50000000)) (hi := ((-3249001 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340023417 : ℝ) / 100000000) = Real.log ((340023417 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((340023417 : ℝ) / 100000000) = ((340023417 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2522 : RB (Real.log ((17001171 : ℝ) / 5000000)) ((122384431 : ℝ) / 100000000) ((61192217 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((17001171 : ℝ) / 20000000)) (t := ((-2998829 : ℝ) / 37001171))
    (lo := ((-3249001 : ℝ) / 20000000)) (hi := ((-4061251 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17001171 : ℝ) / 5000000) = Real.log ((17001171 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((17001171 : ℝ) / 5000000) = ((17001171 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2523 : RB (Real.log ((141633709 : ℝ) / 100000000)) ((17403701 : ℝ) / 50000000) ((8701851 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((141633709 : ℝ) / 200000000)) (t := ((-58366291 : ℝ) / 341633709))
    (lo := ((-8626829 : ℝ) / 25000000)) (hi := ((-6901463 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141633709 : ℝ) / 100000000) = Real.log ((141633709 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141633709 : ℝ) / 100000000) = ((141633709 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2524 : RB (Real.log ((1770149 : ℝ) / 2000000)) ((-6104173 : ℝ) / 50000000) ((-2441669 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1770149 : ℝ) / 2000000)) (t := ((-229851 : ℝ) / 3770149))
    (lo := ((-6104173 : ℝ) / 50000000)) (hi := ((-2441669 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2525 : RB (Real.log ((89186401 : ℝ) / 100000000)) ((-5722081 : ℝ) / 50000000) ((-11444161 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((89186401 : ℝ) / 100000000)) (t := ((-10813599 : ℝ) / 189186401))
    (lo := ((-5722081 : ℝ) / 50000000)) (hi := ((-11444161 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2526 : RB (Real.log ((75888901 : ℝ) / 100000000)) ((-1103599 : ℝ) / 4000000) ((-13794987 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((75888901 : ℝ) / 100000000)) (t := ((-24111099 : ℝ) / 175888901))
    (lo := ((-1103599 : ℝ) / 4000000)) (hi := ((-13794987 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2527 : RB (Real.log ((75990283 : ℝ) / 100000000)) ((-27456471 : ℝ) / 100000000) ((-2745647 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((75990283 : ℝ) / 100000000)) (t := ((-24009717 : ℝ) / 175990283))
    (lo := ((-27456471 : ℝ) / 100000000)) (hi := ((-2745647 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2528 : RB (Real.log ((43184363 : ℝ) / 100000000)) ((-41984587 : ℝ) / 50000000) ((-20992293 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((43184363 : ℝ) / 50000000)) (t := ((-6815637 : ℝ) / 93184363))
    (lo := ((-2930891 : ℝ) / 20000000)) (hi := ((-7327227 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43184363 : ℝ) / 100000000) = Real.log ((43184363 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43184363 : ℝ) / 100000000) = ((43184363 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2529 : RB (Real.log ((94995991 : ℝ) / 50000000)) ((4011323 : ℝ) / 6250000) ((6418117 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((94995991 : ℝ) / 100000000)) (t := ((-5004009 : ℝ) / 194995991))
    (lo := ((-102671 : ℝ) / 2000000)) (hi := ((-5133549 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94995991 : ℝ) / 50000000) = Real.log ((94995991 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94995991 : ℝ) / 50000000) = ((94995991 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2530 : RB (Real.log ((19605921 : ℝ) / 10000000)) ((67324651 : ℝ) / 100000000) ((67324653 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19605921 : ℝ) / 20000000)) (t := ((-394079 : ℝ) / 39605921))
    (lo := ((-1990067 : ℝ) / 100000000)) (hi := ((-995033 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19605921 : ℝ) / 10000000) = Real.log ((19605921 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((19605921 : ℝ) / 10000000) = ((19605921 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2531 : RB (Real.log ((26273543 : ℝ) / 25000000)) ((4968663 : ℝ) / 100000000) ((621083 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((26273543 : ℝ) / 25000000)) (t := ((1273543 : ℝ) / 51273543))
    (lo := ((4968663 : ℝ) / 100000000)) (hi := ((621083 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2532 : RB (Real.log ((105212387 : ℝ) / 100000000)) ((1016217 : ℝ) / 20000000) ((2540543 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((105212387 : ℝ) / 100000000)) (t := ((5212387 : ℝ) / 205212387))
    (lo := ((1016217 : ℝ) / 20000000)) (hi := ((2540543 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2533 : RB (Real.log ((51274871 : ℝ) / 100000000)) ((-66796941 : ℝ) / 100000000) ((-66796939 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((51274871 : ℝ) / 50000000)) (t := ((1274871 : ℝ) / 101274871))
    (lo := ((1258889 : ℝ) / 50000000)) (hi := ((2517779 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51274871 : ℝ) / 100000000) = Real.log ((51274871 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((51274871 : ℝ) / 100000000) = ((51274871 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2534 : RB (Real.log ((174456963 : ℝ) / 50000000)) ((124965507 : ℝ) / 100000000) ((12496551 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((174456963 : ℝ) / 200000000)) (t := ((-25543037 : ℝ) / 374456963))
    (lo := ((-13663929 : ℝ) / 100000000)) (hi := ((-1707991 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((174456963 : ℝ) / 50000000) = Real.log ((174456963 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((174456963 : ℝ) / 50000000) = ((174456963 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2535 : RB (Real.log ((174528699 : ℝ) / 50000000)) ((62503309 : ℝ) / 50000000) ((125006621 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((174528699 : ℝ) / 200000000)) (t := ((-25471301 : ℝ) / 374528699))
    (lo := ((-6811409 : ℝ) / 50000000)) (hi := ((-13622817 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((174528699 : ℝ) / 50000000) = Real.log ((174528699 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((174528699 : ℝ) / 50000000) = ((174528699 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2536 : RB (Real.log ((35036843 : ℝ) / 25000000)) ((33752433 : ℝ) / 100000000) ((6750487 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((35036843 : ℝ) / 50000000)) (t := ((-14963157 : ℝ) / 85036843))
    (lo := ((-7112457 : ℝ) / 20000000)) (hi := ((-8890571 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35036843 : ℝ) / 25000000) = Real.log ((35036843 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((35036843 : ℝ) / 25000000) = ((35036843 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2537 : RB (Real.log ((12853829 : ℝ) / 4000000)) ((58367369 : ℝ) / 50000000) ((116734741 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12853829 : ℝ) / 16000000)) (t := ((-3146171 : ℝ) / 28853829))
    (lo := ((-10947349 : ℝ) / 50000000)) (hi := ((-21894697 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12853829 : ℝ) / 4000000) = Real.log ((12853829 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((12853829 : ℝ) / 4000000) = ((12853829 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2538 : RB (Real.log ((321473307 : ℝ) / 100000000)) ((3649201 : ℝ) / 3125000) ((23354887 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((321473307 : ℝ) / 400000000)) (t := ((-78526693 : ℝ) / 721473307))
    (lo := ((-5463751 : ℝ) / 25000000)) (hi := ((-21855003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((321473307 : ℝ) / 100000000) = Real.log ((321473307 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((321473307 : ℝ) / 100000000) = ((321473307 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2539 : RB (Real.log ((145147653 : ℝ) / 100000000)) ((37258133 : ℝ) / 100000000) ((7451627 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((145147653 : ℝ) / 200000000)) (t := ((-54852347 : ℝ) / 345147653))
    (lo := ((-6411317 : ℝ) / 20000000)) (hi := ((-4007073 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((145147653 : ℝ) / 100000000) = Real.log ((145147653 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((145147653 : ℝ) / 100000000) = ((145147653 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2540 : RB (Real.log ((3870399 : ℝ) / 5000000)) ((-25608031 : ℝ) / 100000000) ((-2560803 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((3870399 : ℝ) / 5000000)) (t := ((-1129601 : ℝ) / 8870399))
    (lo := ((-25608031 : ℝ) / 100000000)) (hi := ((-2560803 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2541 : RB (Real.log ((204066123 : ℝ) / 100000000)) ((17831847 : ℝ) / 25000000) ((7132739 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((204066123 : ℝ) / 200000000)) (t := ((4066123 : ℝ) / 404066123))
    (lo := ((201267 : ℝ) / 10000000)) (hi := ((2012671 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((204066123 : ℝ) / 100000000) = Real.log ((204066123 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((204066123 : ℝ) / 100000000) = ((204066123 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2542 : RB (Real.log ((1 : ℝ) / 100)) ((-230258513 : ℝ) / 50000000) ((-230258509 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((32 : ℝ) / 25)) (t := ((7 : ℝ) / 57))
    (lo := ((24686007 : ℝ) / 100000000)) (hi := ((3085751 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 100) = Real.log ((32 : ℝ) / 25) - 7 * Real.log 2 := by
    rw [show ((1 : ℝ) / 100) = ((32 : ℝ) / 25) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2543 : RB (Real.log ((13 : ℝ) / 500)) ((-364965879 : ℝ) / 100000000) ((-364965873 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((104 : ℝ) / 125)) (t := ((-21 : ℝ) / 229))
    (lo := ((-4598071 : ℝ) / 25000000)) (hi := ((-18392283 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13 : ℝ) / 500) = Real.log ((104 : ℝ) / 125) - 5 * Real.log 2 := by
    rw [show ((13 : ℝ) / 500) = ((104 : ℝ) / 125) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2544 : RB (Real.log ((37421189 : ℝ) / 50000000)) ((-905581 : ℝ) / 3125000) ((-28978591 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37421189 : ℝ) / 50000000)) (t := ((-12578811 : ℝ) / 87421189))
    (lo := ((-905581 : ℝ) / 3125000)) (hi := ((-28978591 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2545 : RB (Real.log ((74926401 : ℝ) / 100000000)) ((-7216597 : ℝ) / 25000000) ((-28866387 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74926401 : ℝ) / 100000000)) (t := ((-25073599 : ℝ) / 174926401))
    (lo := ((-7216597 : ℝ) / 25000000)) (hi := ((-28866387 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2546 : RB (Real.log ((8574349 : ℝ) / 20000000)) ((-42347861 : ℝ) / 50000000) ((-2117393 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((8574349 : ℝ) / 10000000)) (t := ((-1425651 : ℝ) / 18574349))
    (lo := ((-15381003 : ℝ) / 100000000)) (hi := ((-7690501 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8574349 : ℝ) / 20000000) = Real.log ((8574349 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8574349 : ℝ) / 20000000) = ((8574349 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2547 : RB (Real.log ((2338293 : ℝ) / 1250000)) ((31313881 : ℝ) / 50000000) ((15656941 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2338293 : ℝ) / 2500000)) (t := ((-161707 : ℝ) / 4838293))
    (lo := ((-1671739 : ℝ) / 25000000)) (hi := ((-1337391 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2338293 : ℝ) / 1250000) = Real.log ((2338293 : ℝ) / 2500000) + 1 * Real.log 2 := by
    rw [show ((2338293 : ℝ) / 1250000) = ((2338293 : ℝ) / 2500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2548 : RB (Real.log ((189991983 : ℝ) / 100000000)) ((4011323 : ℝ) / 6250000) ((6418117 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((189991983 : ℝ) / 200000000)) (t := ((-10008017 : ℝ) / 389991983))
    (lo := ((-102671 : ℝ) / 2000000)) (hi := ((-5133549 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189991983 : ℝ) / 100000000) = Real.log ((189991983 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189991983 : ℝ) / 100000000) = ((189991983 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2549 : RB (Real.log ((179687 : ℝ) / 200000)) ((-2677523 : ℝ) / 25000000) ((-10710091 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((179687 : ℝ) / 200000)) (t := ((-20313 : ℝ) / 379687))
    (lo := ((-2677523 : ℝ) / 25000000)) (hi := ((-10710091 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2550 : RB (Real.log ((22483683 : ℝ) / 25000000)) ((-5304299 : ℝ) / 50000000) ((-10608597 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22483683 : ℝ) / 25000000)) (t := ((-2516317 : ℝ) / 47483683))
    (lo := ((-5304299 : ℝ) / 50000000)) (hi := ((-10608597 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2551 : RB (Real.log ((23692963 : ℝ) / 50000000)) ((-37342247 : ℝ) / 50000000) ((-18671123 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((23692963 : ℝ) / 25000000)) (t := ((-1307037 : ℝ) / 48692963))
    (lo := ((-214791 : ℝ) / 4000000)) (hi := ((-2684887 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23692963 : ℝ) / 50000000) = Real.log ((23692963 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((23692963 : ℝ) / 50000000) = ((23692963 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2552 : RB (Real.log ((8518039 : ℝ) / 2500000)) ((122589541 : ℝ) / 100000000) ((15323693 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((8518039 : ℝ) / 10000000)) (t := ((-1481961 : ℝ) / 18518039))
    (lo := ((-3207979 : ℝ) / 20000000)) (hi := ((-8019947 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8518039 : ℝ) / 2500000) = Real.log ((8518039 : ℝ) / 10000000) + 2 * Real.log 2 := by
    rw [show ((8518039 : ℝ) / 2500000) = ((8518039 : ℝ) / 10000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2553 : RB (Real.log ((340837241 : ℝ) / 100000000)) ((122623487 : ℝ) / 100000000) ((12262349 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((340837241 : ℝ) / 400000000)) (t := ((-59162759 : ℝ) / 740837241))
    (lo := ((-16005949 : ℝ) / 100000000)) (hi := ((-4001487 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340837241 : ℝ) / 100000000) = Real.log ((340837241 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((340837241 : ℝ) / 100000000) = ((340837241 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2554 : RB (Real.log ((141493749 : ℝ) / 100000000)) ((6941707 : ℝ) / 20000000) ((34708537 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((141493749 : ℝ) / 200000000)) (t := ((-58506251 : ℝ) / 341493749))
    (lo := ((-34606183 : ℝ) / 100000000)) (hi := ((-17303091 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141493749 : ℝ) / 100000000) = Real.log ((141493749 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141493749 : ℝ) / 100000000) = ((141493749 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2555 : RB (Real.log ((20513229 : ℝ) / 6250000)) ((118848853 : ℝ) / 100000000) ((14856107 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((20513229 : ℝ) / 25000000)) (t := ((-4486771 : ℝ) / 45513229))
    (lo := ((-19780583 : ℝ) / 100000000)) (hi := ((-9890291 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20513229 : ℝ) / 6250000) = Real.log ((20513229 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((20513229 : ℝ) / 6250000) = ((20513229 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2556 : RB (Real.log ((328321333 : ℝ) / 100000000)) ((118882261 : ℝ) / 100000000) ((14860283 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((328321333 : ℝ) / 400000000)) (t := ((-71678667 : ℝ) / 728321333))
    (lo := ((-789887 : ℝ) / 4000000)) (hi := ((-9873587 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((328321333 : ℝ) / 100000000) = Real.log ((328321333 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((328321333 : ℝ) / 100000000) = ((328321333 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2557 : RB (Real.log ((28753663 : ℝ) / 20000000)) ((36303289 : ℝ) / 100000000) ((36303291 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((28753663 : ℝ) / 40000000)) (t := ((-11246337 : ℝ) / 68753663))
    (lo := ((-33011429 : ℝ) / 100000000)) (hi := ((-8252857 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28753663 : ℝ) / 20000000) = Real.log ((28753663 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((28753663 : ℝ) / 20000000) = ((28753663 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2558 : RB (Real.log ((36419549 : ℝ) / 50000000)) ((-7922933 : ℝ) / 25000000) ((-31691731 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36419549 : ℝ) / 50000000)) (t := ((-13580451 : ℝ) / 86419549))
    (lo := ((-7922933 : ℝ) / 25000000)) (hi := ((-31691731 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2559 : RB (Real.log ((58089393 : ℝ) / 50000000)) ((14996007 : ℝ) / 100000000) ((1874501 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((58089393 : ℝ) / 50000000)) (t := ((8089393 : ℝ) / 108089393))
    (lo := ((14996007 : ℝ) / 100000000)) (hi := ((1874501 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
