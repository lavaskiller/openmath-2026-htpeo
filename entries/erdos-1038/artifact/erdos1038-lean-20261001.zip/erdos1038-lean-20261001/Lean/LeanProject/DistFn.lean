import LeanProject.RefPotOff

/-!
# EP-1038, Stage 10, Proposition 10.3(5): the distribution function of `η_{k,a}`

* `hasDerivAt_prim`: `θ ↦ θ + 2 arctan(q sin θ/(1 - q cos θ))` has derivative `P_q(θ)`.
* `int_Pq_partial`: `∫_0^θ P_q = θ + 2 arctan(q sin θ/(1 - q cos θ))` (`0 ≤ q < 1`).
* `eta_dist` (**Proposition 10.3(5)**, angle form):
  `η_{k,a}([a, c - ϱ cos θ]) = (1/π) ∫_0^θ ((k+1) - k P_q) = (1/π)(θ - 2k arctan(q sin θ/(1 - q cos θ)))`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

theorem hasDerivAt_prim {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (t : ℝ) :
    HasDerivAt (fun x => x + 2 * Real.arctan (q * Real.sin x / (1 - q * Real.cos x))) (Pq q t) t := by
  have hE : 0 < 1 - q * Real.cos t := by nlinarith [Real.cos_le_one t]
  have hD := Pq_den_pos hq0 hq1 t
  have hg : HasDerivAt (fun x => q * Real.sin x / (1 - q * Real.cos x))
      ((q * Real.cos t * (1 - q * Real.cos t) - q * Real.sin t * (q * Real.sin t)) /
        (1 - q * Real.cos t) ^ 2) t := by
    have h1 : HasDerivAt (fun x => q * Real.sin x) (q * Real.cos t) t :=
      (Real.hasDerivAt_sin t).const_mul q
    have h2 : HasDerivAt (fun x => 1 - q * Real.cos x) (q * Real.sin t) t := by
      have := ((Real.hasDerivAt_cos t).const_mul q).const_sub 1
      convert this using 1
      ring
    exact h1.div h2 hE.ne'
  have h := (hasDerivAt_id t).add ((hg.arctan).const_mul 2)
  refine h.congr_deriv ?_
  have hs := Real.sin_sq_add_cos_sq t
  have hE2 : (1 - q * Real.cos t) ^ 2 ≠ 0 := pow_ne_zero 2 hE.ne'
  have hA : 1 + (q * Real.sin t / (1 - q * Real.cos t)) ^ 2 =
      (1 - 2 * q * Real.cos t + q ^ 2) / (1 - q * Real.cos t) ^ 2 := by
    rw [div_pow, eq_div_iff hE2, add_mul, div_mul_cancel₀ _ hE2]
    linear_combination q ^ 2 * hs
  have hN : q * Real.cos t * (1 - q * Real.cos t) - q * Real.sin t * (q * Real.sin t) =
      q * Real.cos t - q ^ 2 := by
    linear_combination (-q ^ 2) * hs
  rw [hA, hN]
  have hD' := hD.ne'
  have hE' := hE.ne'
  unfold Pq
  field_simp
  ring

/-- `∫_0^θ P_q = θ + 2 arctan(q sin θ/(1 - q cos θ))`. -/
theorem int_Pq_partial {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (θ : ℝ) :
    ∫ t in (0 : ℝ)..θ, Pq q t = θ + 2 * Real.arctan (q * Real.sin θ / (1 - q * Real.cos θ)) := by
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hasDerivAt_prim hq0 hq1 t)
    ((Pq_cont hq0 hq1).intervalIntegrable _ _)]
  simp

/-- **Proposition 10.3(5)** (angle form): the `η_{k,a}`-mass of `[a, c - ϱ cos θ]` is
`(1/π) ∫_0^θ ((k+1) - k P_q) = (1/π)(θ - 2k arctan(q sin θ/(1 - q cos θ)))`. -/
theorem eta_dist {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (k θ : ℝ) :
    1 / π * ∫ t in (0 : ℝ)..θ, ((k + 1) - k * Pq q t) =
      1 / π * (θ - 2 * k * Real.arctan (q * Real.sin θ / (1 - q * Real.cos θ))) := by
  rw [intervalIntegral.integral_sub intervalIntegrable_const
    (((Pq_cont hq0 hq1).intervalIntegrable _ _).const_mul k), intervalIntegral.integral_const_mul,
    int_Pq_partial hq0 hq1, intervalIntegral.integral_const, smul_eq_mul]
  ring

end EP1038.Arc
