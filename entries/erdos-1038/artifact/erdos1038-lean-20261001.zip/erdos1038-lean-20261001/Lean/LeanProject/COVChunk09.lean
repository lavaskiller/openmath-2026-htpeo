import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk05
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_45 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10569 : ℝ) / 16969) ((5301 : ℝ) / 8501))
    (hq : RB (qa a) ((1372561 : ℝ) / 100000000) ((1389587 : ℝ) / 100000000))
    (hd : RB (D0a a) ((194555399 : ℝ) / 100000000) ((194620759 : ℝ) / 100000000))
    : certE k a ((41580157 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((10505097 : ℝ) / 25000000) ∧ 0 < certE k a ((64655779 : ℝ) / 50000000) ∧ certE k a ((129488049 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((18839 : ℝ) / 100000000) ((1931 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((41580157 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((41560847 : ℝ) / 100000000) ((20780659 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((41580157 : ℝ) / 100000000) ((41580157 : ℝ) / 100000000) ((41580157 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((58419843 : ℝ) / 100000000))
  have h3 : RB z3 ((71141661 : ℝ) / 100000000) ((17785617 : ℝ) / 25000000) := rb_div_signed h2 (show RB ((58419843 : ℝ) / 100000000) ((58419843 : ℝ) / 100000000) ((58419843 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-8512427 : ℝ) / 25000000) ((-8512143 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_810.1 cov_log_811.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-21232503 : ℝ) / 100000000) ((-5301717 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((41580157 : ℝ) / 100000000))
  have h6 : RB z6 ((-43877357 : ℝ) / 50000000) ((-10969339 : ℝ) / 12500000) := rb_log (show RB ((41580157 : ℝ) / 100000000) ((41580157 : ℝ) / 100000000) ((41580157 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_812.1 cov_log_812.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66522209 : ℝ) / 100000000) ((33273923 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16638669 : ℝ) / 25000000) ((66588267 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_813.1 cov_log_814.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-33029 : ℝ) / 50000000) ((-683 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((18839 : ℝ) / 100000000) ((1931 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((10505097 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((21000539 : ℝ) / 50000000) ((42001549 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((10505097 : ℝ) / 25000000) ((10505097 : ℝ) / 25000000) ((10505097 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((14494903 : ℝ) / 25000000))
  have h12 : RB z12 ((18110279 : ℝ) / 25000000) ((72441929 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((14494903 : ℝ) / 25000000) ((14494903 : ℝ) / 25000000) ((14494903 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-6447923 : ℝ) / 20000000) ((-8059623 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_815.1 cov_log_816.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-628243 : ℝ) / 3125000) ((-803179 : ℝ) / 4000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((10505097 : ℝ) / 25000000))
  have h15 : RB z15 ((-86701527 : ℝ) / 100000000) ((-3468061 : ℝ) / 4000000) := rb_log (show RB ((10505097 : ℝ) / 25000000) ((10505097 : ℝ) / 25000000) ((10505097 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_817.1 cov_log_817.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66597749 : ℝ) / 100000000) ((16655513 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16638669 : ℝ) / 25000000) ((66588267 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_813.1 cov_log_814.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4741 : ℝ) / 50000000) ((4211 : ℝ) / 6250000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((18839 : ℝ) / 100000000) ((1931 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((64655779 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((16161531 : ℝ) / 12500000) ((129292719 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((64655779 : ℝ) / 50000000) ((64655779 : ℝ) / 50000000) ((64655779 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((14655779 : ℝ) / 50000000))
  have h21 : RB z21 ((441096471 : ℝ) / 100000000) ((441098079 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((14655779 : ℝ) / 50000000) ((14655779 : ℝ) / 50000000) ((14655779 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((148409341 : ℝ) / 100000000) ((148409709 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_818.1 cov_log_819.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92435519 : ℝ) / 100000000) ((92544391 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((64655779 : ℝ) / 50000000))
  have h24 : RB z24 ((3213181 : ℝ) / 12500000) ((25705449 : ℝ) / 100000000) := rb_log (show RB ((64655779 : ℝ) / 50000000) ((64655779 : ℝ) / 50000000) ((64655779 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_820.1 cov_log_820.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((6673007 : ℝ) / 10000000) ((66838943 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16638669 : ℝ) / 25000000) ((66588267 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_813.1 cov_log_814.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((141803 : ℝ) / 100000000) ((284267 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((18839 : ℝ) / 100000000) ((1931 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129488049 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((129468739 : ℝ) / 100000000) ((12946921 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((129488049 : ℝ) / 100000000) ((129488049 : ℝ) / 100000000) ((129488049 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29488049 : ℝ) / 100000000))
  have h30 : RB z30 ((8781099 : ℝ) / 2000000) ((109764137 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((29488049 : ℝ) / 100000000) ((29488049 : ℝ) / 100000000) ((29488049 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((73972719 : ℝ) / 50000000) ((29589161 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_821.1 cov_log_822.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92146581 : ℝ) / 100000000) ((92255113 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129488049 : ℝ) / 100000000))
  have h33 : RB z33 ((323023 : ℝ) / 1250000) ((25841841 : ℝ) / 100000000) := rb_log (show RB ((129488049 : ℝ) / 100000000) ((129488049 : ℝ) / 100000000) ((129488049 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_823.1 cov_log_823.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((3315237 : ℝ) / 5000000) ((66413273 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16638669 : ℝ) / 25000000) ((66588267 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_813.1 cov_log_814.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-283527 : ℝ) / 100000000) ((-141403 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((41580157 : ℝ) / 100000000)) ((-33029 : ℝ) / 50000000) ((-683 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((10505097 : ℝ) / 25000000)) ((4741 : ℝ) / 50000000) ((4211 : ℝ) / 6250000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((64655779 : ℝ) / 50000000)) ((141803 : ℝ) / 100000000) ((284267 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129488049 : ℝ) / 100000000)) ((-283527 : ℝ) / 100000000) ((-141403 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_45 {k A q d vp vm : ℝ}
    (hk : RB k ((10569 : ℝ) / 6400) ((5301 : ℝ) / 3200))
    (hA : RB A ((10569 : ℝ) / 16969) ((5301 : ℝ) / 8501))
    (hq : RB q ((1372561 : ℝ) / 100000000) ((1389587 : ℝ) / 100000000))
    (hd : RB d ((194555399 : ℝ) / 100000000) ((194620759 : ℝ) / 100000000))
    (hp : RB vp ((41580157 : ℝ) / 100000000) ((10505097 : ℝ) / 25000000))
    (hm : RB vm ((64655779 : ℝ) / 50000000) ((129488049 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((18839 : ℝ) / 100000000) ((1931 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((9998069 : ℝ) / 10000000) ((99981161 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((31136069 : ℝ) / 50000000) ((62345623 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((1401 : ℝ) / 3125000) ((46441 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99953559 : ℝ) / 100000000) ((3123599 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((14494903 : ℝ) / 25000000) ((58419843 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11590537 : ℝ) / 20000000) ((58393653 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106641963 : ℝ) / 100000000) ((21516043 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6641963 : ℝ) / 100000000) ((1516043 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((9998069 : ℝ) / 10000000) ((99981161 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((31136069 : ℝ) / 50000000) ((62345623 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3637 : ℝ) / 25000000) ((14933 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99985067 : ℝ) / 100000000) ((24996363 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((14655779 : ℝ) / 50000000) ((29488049 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1465359 : ℝ) / 5000000) ((368547 : ℝ) / 1250000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((42241653 : ℝ) / 20000000) ((212731567 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((62241653 : ℝ) / 20000000) ((312731567 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((263844759 : ℝ) / 20000000) ((1505578999 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6395261 : ℝ) / 20000000) ((32132823 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10569 : ℝ) / 3200) ((5301 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4533311 : ℝ) / 100000000) ((1150969 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101372561 : ℝ) / 100000000) ((101389587 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((223559 : ℝ) / 5000000) ((4541541 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((5223559 : ℝ) / 5000000) ((104541541 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((8729117 : ℝ) / 10000000) ((21976973 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((42457421 : ℝ) / 25000000) ((171087007 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13441987 : ℝ) / 25000000) ((54411381 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((34623 : ℝ) / 100000000) ((17957 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49982043 : ℝ) / 50000000) ((99965377 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((169768691 : ℝ) / 100000000) ((42756943 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((194555399 : ℝ) / 50000000) ((194620759 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5340783 : ℝ) / 100000000) ((108177 : ℝ) / 2000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16969 : ℝ) / 6400) ((8501 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2010411 : ℝ) / 100000000) ((2039993 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((204151 : ℝ) / 6250000) ((835487 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((6454151 : ℝ) / 6250000) ((25835487 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((340578783 : ℝ) / 25000000) ((1555894667 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((105999 : ℝ) / 10000000) ((268651 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((10105999 : ℝ) / 10000000) ((25268651 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((129261 : ℝ) / 400000) ((8119531 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((697315191 : ℝ) / 50000000) ((1588372791 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((14018901 : ℝ) / 50000000) ((16201347 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16969 : ℝ) / 6400) ((8501 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((5223559 : ℝ) / 2500000) ((104541541 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((13512001 : ℝ) / 1000000) ((768855911 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2823229377 : ℝ) / 100000000) ((321509527 : ℝ) / 10000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((4123371 : ℝ) / 50000000) ((9409659 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-124767601 : ℝ) / 50000000) ((-118171673 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_824.1 cov_log_825.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2670391 : ℝ) / 100000000) ((108177 : ℝ) / 4000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-362294533 : ℝ) / 100000000) ((-180514043 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_826.1 cov_log_827.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16638669 : ℝ) / 25000000) ((66588267 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_813.1 cov_log_814.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((109908807 : ℝ) / 100000000) ((110307627 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-126192863 : ℝ) / 50000000) ((-250720459 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((496611 : ℝ) / 4000000) ((13674357 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((9578891 : ℝ) / 25000000) ((9754229 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-107035081 : ℝ) / 50000000) ((-100974657 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((5223559 : ℝ) / 5000000) ((104541541 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-124767601 : ℝ) / 50000000) ((-118171673 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-107035081 : ℝ) / 50000000) ((-100974657 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((301 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((204151 : ℝ) / 6250000) ((835487 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((25835487 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((301 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-5494341 : ℝ) / 2500000) ≤ formC0 k A q vp vm + hfun ((301 : ℝ) / 100) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_12, cov_h_10]
  have hP : ((121372569 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((100974657 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((100974657 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((551 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((551 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((559 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((559 : ℝ) / 200)) (lo := ((551 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((567 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((567 : ℝ) / 200)) (lo := ((559 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((23 : ℝ) / 8) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((23 : ℝ) / 8)) (lo := ((567 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((583 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((583 : ℝ) / 200)) (lo := ((23 : ℝ) / 8)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((591 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((591 : ℝ) / 200)) (lo := ((583 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((599 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((599 : ℝ) / 200)) (lo := ((591 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((301 : ℝ) / 100)) (lo := ((599 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_45 {k : ℝ} (hk : RB k ((10569 : ℝ) / 6400) ((5301 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((10569 : ℝ) / 16969) ((5301 : ℝ) / 8501) ∧
    RB (qa (r1A k)) ((1372561 : ℝ) / 100000000) ((1389587 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((194555399 : ℝ) / 100000000) ((194620759 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((10321289 : ℝ) / 25000000) ((41414063 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((189185937 : ℝ) / 100000000) ((47328711 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((68772439 : ℝ) / 50000000) ((137591731 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139483117 : ℝ) / 50000000) ((8719159 : ℝ) / 3125000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139483117 : ℝ) / 100000000) ((8719159 : ℝ) / 6250000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((194555399 : ℝ) / 100000000) ((194620759 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2671289 : ℝ) / 25000000) ((10814063 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2671289 : ℝ) / 100000000) ((675879 : ℝ) / 25000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1372561 : ℝ) / 100000000) ((1389587 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((194555399 : ℝ) / 100000000) ((194620759 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1372561 : ℝ) / 100000000) ((1389587 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10569 : ℝ) / 16969) ((5301 : ℝ) / 8501) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_45 {k : ℝ} (hk : RB k ((10569 : ℝ) / 6400) ((5301 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_45 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_45 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((41580157 : ℝ) / 100000000)) (ph := ((10505097 : ℝ) / 25000000)) (ml := ((64655779 : ℝ) / 50000000)) (mh := ((129488049 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_45 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_46 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5301 : ℝ) / 8501) ((2127 : ℝ) / 3407))
    (hq : RB (qa a) ((694793 : ℝ) / 50000000) ((43957 : ℝ) / 3125000))
    (hd : RB (D0a a) ((194490031 : ℝ) / 100000000) ((38911081 : ℝ) / 20000000))
    : certE k a ((41532369 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((2098369 : ℝ) / 5000000) ∧ 0 < certE k a ((8085659 : ℝ) / 6250000) ∧ certE k a ((16193321 : ℝ) / 12500000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((19309 : ℝ) / 100000000) ((9893 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((41532369 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((41512583 : ℝ) / 100000000) ((2075653 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((41532369 : ℝ) / 100000000) ((41532369 : ℝ) / 100000000) ((41532369 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((58467631 : ℝ) / 100000000))
  have h3 : RB z3 ((35500483 : ℝ) / 50000000) ((71001783 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((58467631 : ℝ) / 100000000) ((58467631 : ℝ) / 100000000) ((58467631 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-34247671 : ℝ) / 100000000) ((-34246519 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_828.1 cov_log_829.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-21380921 : ℝ) / 100000000) ((-5338807 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((41532369 : ℝ) / 100000000))
  have h6 : RB z6 ((-8786971 : ℝ) / 10000000) ((-21967427 : ℝ) / 25000000) := rb_log (show RB ((41532369 : ℝ) / 100000000) ((41532369 : ℝ) / 100000000) ((41532369 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_830.1 cov_log_830.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66488787 : ℝ) / 100000000) ((33257241 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((4157567 : ℝ) / 6250000) ((66554681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_831.1 cov_log_832.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-32947 : ℝ) / 50000000) ((-659 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((19309 : ℝ) / 100000000) ((9893 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((2098369 : ℝ) / 5000000)) - (z10)
  have h11 : RB z11 ((20973797 : ℝ) / 50000000) ((41948071 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((2098369 : ℝ) / 5000000) ((2098369 : ℝ) / 5000000) ((2098369 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((2901631 : ℝ) / 5000000))
  have h12 : RB z12 ((14456557 : ℝ) / 20000000) ((9035451 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((2901631 : ℝ) / 5000000) ((2901631 : ℝ) / 5000000) ((2901631 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-1622921 : ℝ) / 5000000) ((-101429 : ℝ) / 312500) := rb_log h12 (by norm_num) cov_log_833.1 cov_log_834.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-10131943 : ℝ) / 50000000) ((-10119753 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((2098369 : ℝ) / 5000000))
  have h15 : RB z15 ((-17365551 : ℝ) / 20000000) ((-86827753 : ℝ) / 100000000) := rb_log (show RB ((2098369 : ℝ) / 5000000) ((2098369 : ℝ) / 5000000) ((2098369 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_835.1 cov_log_835.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66563867 : ℝ) / 100000000) ((66588249 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((4157567 : ℝ) / 6250000) ((66554681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_831.1 cov_log_832.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4593 : ℝ) / 50000000) ((67177 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((19309 : ℝ) / 100000000) ((9893 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((8085659 : ℝ) / 6250000)) - (z19)
  have h20 : RB z20 ((64675379 : ℝ) / 50000000) ((25870247 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((8085659 : ℝ) / 6250000) ((8085659 : ℝ) / 6250000) ((8085659 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1835659 : ℝ) / 6250000))
  have h21 : RB z21 ((440409813 : ℝ) / 100000000) ((220205719 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((1835659 : ℝ) / 6250000) ((1835659 : ℝ) / 6250000) ((1835659 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((148253549 : ℝ) / 100000000) ((148253921 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_836.1 cov_log_837.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92447013 : ℝ) / 100000000) ((46277677 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((8085659 : ℝ) / 6250000))
  have h24 : RB z24 ((25751053 : ℝ) / 100000000) ((12875527 : ℝ) / 50000000) := rb_log (show RB ((8085659 : ℝ) / 6250000) ((8085659 : ℝ) / 6250000) ((8085659 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_838.1 cov_log_838.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((66695959 : ℝ) / 100000000) ((66804301 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((4157567 : ℝ) / 6250000) ((66554681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_831.1 cov_log_832.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((70639 : ℝ) / 50000000) ((283229 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((19309 : ℝ) / 100000000) ((9893 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((16193321 : ℝ) / 12500000)) - (z28)
  have h29 : RB z29 ((64763391 : ℝ) / 50000000) ((129527259 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((16193321 : ℝ) / 12500000) ((16193321 : ℝ) / 12500000) ((16193321 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3693321 : ℝ) / 12500000))
  have h30 : RB z30 ((219190909 : ℝ) / 50000000) ((438383433 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((3693321 : ℝ) / 12500000) ((3693321 : ℝ) / 12500000) ((3693321 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((147792007 : ℝ) / 100000000) ((73896189 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_839.1 cov_log_840.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((11519901 : ℝ) / 12500000) ((23066803 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((16193321 : ℝ) / 12500000))
  have h33 : RB z33 ((12943511 : ℝ) / 50000000) ((25887023 : ℝ) / 100000000) := rb_log (show RB ((16193321 : ℝ) / 12500000) ((16193321 : ℝ) / 12500000) ((16193321 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_841.1 cov_log_841.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((13254437 : ℝ) / 20000000) ((6638019 : ℝ) / 10000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((4157567 : ℝ) / 6250000) ((66554681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_831.1 cov_log_832.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-2207 : ℝ) / 781250) ((-70441 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((41532369 : ℝ) / 100000000)) ((-32947 : ℝ) / 50000000) ((-659 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((2098369 : ℝ) / 5000000)) ((4593 : ℝ) / 50000000) ((67177 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((8085659 : ℝ) / 6250000)) ((70639 : ℝ) / 50000000) ((283229 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((16193321 : ℝ) / 12500000)) ((-2207 : ℝ) / 781250) ((-70441 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_46 {k A q d vp vm : ℝ}
    (hk : RB k ((5301 : ℝ) / 3200) ((2127 : ℝ) / 1280))
    (hA : RB A ((5301 : ℝ) / 8501) ((2127 : ℝ) / 3407))
    (hq : RB q ((694793 : ℝ) / 50000000) ((43957 : ℝ) / 3125000))
    (hd : RB d ((194490031 : ℝ) / 100000000) ((38911081 : ℝ) / 20000000))
    (hp : RB vp ((41532369 : ℝ) / 100000000) ((2098369 : ℝ) / 5000000))
    (hm : RB vm ((8085659 : ℝ) / 6250000) ((16193321 : ℝ) / 12500000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((19309 : ℝ) / 100000000) ((9893 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49990107 : ℝ) / 50000000) ((99980691 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((62345031 : ℝ) / 100000000) ((15604559 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((46009 : ℝ) / 100000000) ((1191 : ℝ) / 2500000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((2498809 : ℝ) / 2500000) ((99953991 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((2901631 : ℝ) / 5000000) ((58467631 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58004973 : ℝ) / 100000000) ((58440731 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((21336157 : ℝ) / 20000000) ((53804211 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1336157 : ℝ) / 20000000) ((3804211 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49990107 : ℝ) / 50000000) ((99980691 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((62345031 : ℝ) / 100000000) ((15604559 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((2981 : ℝ) / 20000000) ((3059 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19996941 : ℝ) / 20000000) ((19997019 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1835659 : ℝ) / 6250000) ((3693321 : ℝ) / 12500000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((29366051 : ℝ) / 100000000) ((5908433 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((211037447 : ℝ) / 100000000) ((106276183 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((311037447 : ℝ) / 100000000) ((156276183 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((262866597 : ℝ) / 20000000) ((1496830089 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15997319 : ℝ) / 50000000) ((3215047 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5301 : ℝ) / 1600) ((2127 : ℝ) / 640) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((143871 : ℝ) / 3125000) ((4674827 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50694793 : ℝ) / 50000000) ((3168957 : ℝ) / 3125000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4540011 : ℝ) / 100000000) ((4610757 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((104540011 : ℝ) / 100000000) ((104610757 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((21850791 : ℝ) / 25000000) ((88014199 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((4249761 : ℝ) / 2500000) ((85618191 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53730651 : ℝ) / 100000000) ((54367301 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((7103 : ℝ) / 20000000) ((1473 : ℝ) / 4000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((3998527 : ℝ) / 4000000) ((19992897 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((169927841 : ℝ) / 100000000) ((10698473 : ℝ) / 6250000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((194490031 : ℝ) / 50000000) ((38911081 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1351303 : ℝ) / 25000000) ((5473327 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8501 : ℝ) / 3200) ((3407 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1015361 : ℝ) / 50000000) ((412061 : ℝ) / 20000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3311109 : ℝ) / 100000000) ((1693407 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((103311109 : ℝ) / 100000000) ((51693407 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((678925991 : ℝ) / 50000000) ((1547524941 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1072653 : ℝ) / 100000000) ((271821 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101072653 : ℝ) / 100000000) ((25271821 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32337829 : ℝ) / 100000000) ((32500037 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1390189811 : ℝ) / 100000000) ((790012489 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((2823089 : ℝ) / 10000000) ((16276667 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8501 : ℝ) / 3200) ((3407 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((104540011 : ℝ) / 50000000) ((104610757 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1346327623 : ℝ) / 100000000) ((1528980559 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((281490209 : ℝ) / 10000000) ((127958251 : ℝ) / 4000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((4152233 : ℝ) / 50000000) ((9455813 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-248837679 : ℝ) / 100000000) ((-235854049 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_842.1 cov_log_843.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1351303 : ℝ) / 50000000) ((342083 : ℝ) / 12500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-2888763 : ℝ) / 800000) ((-89960763 : ℝ) / 25000000) := rb_log h49 (by norm_num) cov_log_844.1 cov_log_845.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((4157567 : ℝ) / 6250000) ((66554681 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_831.1 cov_log_832.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((110196313 : ℝ) / 100000000) ((55297581 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-125449531 : ℝ) / 50000000) ((-24924789 : ℝ) / 10000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((12267479 : ℝ) / 100000000) ((13515207 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((37684247 : ℝ) / 100000000) ((23936913 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-42642963 : ℝ) / 20000000) ((-12585879 : ℝ) / 6250000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((104540011 : ℝ) / 100000000) ((104610757 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-248837679 : ℝ) / 100000000) ((-235854049 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-42642963 : ℝ) / 20000000) ((-12585879 : ℝ) / 6250000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((301 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3311109 : ℝ) / 100000000) ((1693407 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((51693407 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((301 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-219076117 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((301 : ℝ) / 100) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_12, cov_h_10]
  have hP : ((120946763 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((12585879 : ℝ) / 6250000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((12585879 : ℝ) / 6250000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1377 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1377 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1397 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1397 : ℝ) / 500)) (lo := ((1377 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1417 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1417 : ℝ) / 500)) (lo := ((1397 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1437 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1437 : ℝ) / 500)) (lo := ((1417 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1457 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1457 : ℝ) / 500)) (lo := ((1437 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1477 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1477 : ℝ) / 500)) (lo := ((1457 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1497 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1497 : ℝ) / 500)) (lo := ((1477 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((301 : ℝ) / 100)) (lo := ((1497 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_46 {k : ℝ} (hk : RB k ((5301 : ℝ) / 3200) ((2127 : ℝ) / 1280)) :
    RB (k / (k + 1)) ((5301 : ℝ) / 8501) ((2127 : ℝ) / 3407) ∧
    RB (qa (r1A k)) ((694793 : ℝ) / 50000000) ((43957 : ℝ) / 3125000) ∧ RB (D0a (r1A k)) ((194490031 : ℝ) / 100000000) ((38911081 : ℝ) / 20000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((20707031 : ℝ) / 50000000) ((41542969 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((189057031 : ℝ) / 100000000) ((94592969 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((137498011 : ℝ) / 100000000) ((1719311 : ℝ) / 1250000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((278919367 : ℝ) / 100000000) ((278966237 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139459683 : ℝ) / 100000000) ((139483119 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((194490031 : ℝ) / 100000000) ((38911081 : ℝ) / 20000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((5407031 : ℝ) / 50000000) ((10942969 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((540703 : ℝ) / 20000000) ((2735743 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((694793 : ℝ) / 50000000) ((43957 : ℝ) / 3125000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((194490031 : ℝ) / 100000000) ((38911081 : ℝ) / 20000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((694793 : ℝ) / 50000000) ((43957 : ℝ) / 3125000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5301 : ℝ) / 8501) ((2127 : ℝ) / 3407) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_46 {k : ℝ} (hk : RB k ((5301 : ℝ) / 3200) ((2127 : ℝ) / 1280)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_46 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_46 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((41532369 : ℝ) / 100000000)) (ph := ((2098369 : ℝ) / 5000000)) (ml := ((8085659 : ℝ) / 6250000)) (mh := ((16193321 : ℝ) / 12500000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_46 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_47 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2127 : ℝ) / 3407) ((2667 : ℝ) / 4267))
    (hq : RB (qa a) ((1406623 : ℝ) / 100000000) ((177959 : ℝ) / 12500000))
    (hd : RB (D0a a) ((194424653 : ℝ) / 100000000) ((97245019 : ℝ) / 50000000))
    : certE k a ((20742551 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((10478759 : ℝ) / 25000000) ∧ 0 < certE k a ((129429373 : ℝ) / 100000000) ∧ certE k a ((129604933 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((3957 : ℝ) / 20000000) ((20269 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((20742551 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((41464833 : ℝ) / 100000000) ((41465317 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((20742551 : ℝ) / 50000000) ((20742551 : ℝ) / 50000000) ((20742551 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((29257449 : ℝ) / 50000000))
  have h3 : RB z3 ((7086201 : ℝ) / 10000000) ((35431419 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((29257449 : ℝ) / 50000000) ((29257449 : ℝ) / 50000000) ((29257449 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-34443573 : ℝ) / 100000000) ((-34442403 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_846.1 cov_log_847.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-21528243 : ℝ) / 100000000) ((-5375623 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((20742551 : ℝ) / 50000000))
  have h6 : RB z6 ((-87983583 : ℝ) / 100000000) ((-87983581 : ℝ) / 100000000) := rb_log (show RB ((20742551 : ℝ) / 50000000) ((20742551 : ℝ) / 50000000) ((20742551 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_848.1 cov_log_848.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33227669 : ℝ) / 50000000) ((66481091 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66487451 : ℝ) / 100000000) ((66521077 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_849.1 cov_log_850.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-65739 : ℝ) / 100000000) ((-159 : ℝ) / 2500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((3957 : ℝ) / 20000000) ((20269 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((10478759 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((41894767 : ℝ) / 100000000) ((41895251 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((10478759 : ℝ) / 25000000) ((10478759 : ℝ) / 25000000) ((10478759 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((14521241 : ℝ) / 25000000))
  have h12 : RB z12 ((36063349 : ℝ) / 50000000) ((72127533 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((14521241 : ℝ) / 25000000) ((14521241 : ℝ) / 25000000) ((14521241 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-1021081 : ℝ) / 3125000) ((-16336717 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_851.1 cov_log_852.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-10211289 : ℝ) / 50000000) ((-20398119 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((10478759 : ℝ) / 25000000))
  have h15 : RB z15 ((-43476279 : ℝ) / 50000000) ((-21738139 : ℝ) / 25000000) := rb_log (show RB ((10478759 : ℝ) / 25000000) ((10478759 : ℝ) / 25000000) ((10478759 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_853.1 cov_log_853.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33264989 : ℝ) / 50000000) ((66554439 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66487451 : ℝ) / 100000000) ((66521077 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_849.1 cov_log_850.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((8901 : ℝ) / 100000000) ((16747 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((3957 : ℝ) / 20000000) ((20269 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((129429373 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((8088069 : ℝ) / 6250000) ((32352397 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((129429373 : ℝ) / 100000000) ((129429373 : ℝ) / 100000000) ((129429373 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((29429373 : ℝ) / 100000000))
  have h21 : RB z21 ((27482981 : ℝ) / 6250000) ((219864671 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((29429373 : ℝ) / 100000000) ((29429373 : ℝ) / 100000000) ((29429373 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((148098547 : ℝ) / 100000000) ((37024731 : ℝ) / 25000000) := rb_log h21 (by norm_num) cov_log_854.1 cov_log_855.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92458353 : ℝ) / 100000000) ((46283083 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((129429373 : ℝ) / 100000000))
  have h24 : RB z24 ((6449129 : ℝ) / 25000000) ((25796517 : ℝ) / 100000000) := rb_log (show RB ((129429373 : ℝ) / 100000000) ((129429373 : ℝ) / 100000000) ((129429373 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_856.1 cov_log_856.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16665459 : ℝ) / 25000000) ((1335393 : ℝ) / 2000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66487451 : ℝ) / 100000000) ((66521077 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_849.1 cov_log_850.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((140759 : ℝ) / 100000000) ((282199 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((3957 : ℝ) / 20000000) ((20269 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129604933 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((16198083 : ℝ) / 12500000) ((32396287 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((129604933 : ℝ) / 100000000) ((129604933 : ℝ) / 100000000) ((129604933 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29604933 : ℝ) / 100000000))
  have h30 : RB z30 ((437713079 : ℝ) / 100000000) ((87542943 : ℝ) / 20000000) := rb_div_signed h29 (show RB ((29604933 : ℝ) / 100000000) ((29604933 : ℝ) / 100000000) ((29604933 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((147639343 : ℝ) / 100000000) ((3690993 : ℝ) / 2500000) := rb_log h30 (by norm_num) cov_log_857.1 cov_log_858.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((9217167 : ℝ) / 10000000) ((92279151 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129604933 : ℝ) / 100000000))
  have h33 : RB z33 ((12966033 : ℝ) / 50000000) ((25932067 : ℝ) / 100000000) := rb_log (show RB ((129604933 : ℝ) / 100000000) ((129604933 : ℝ) / 100000000) ((129604933 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_859.1 cov_log_859.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((66239603 : ℝ) / 100000000) ((13269417 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66487451 : ℝ) / 100000000) ((66521077 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_849.1 cov_log_850.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-140737 : ℝ) / 50000000) ((-70183 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((20742551 : ℝ) / 50000000)) ((-65739 : ℝ) / 100000000) ((-159 : ℝ) / 2500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((10478759 : ℝ) / 25000000)) ((8901 : ℝ) / 100000000) ((16747 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((129429373 : ℝ) / 100000000)) ((140759 : ℝ) / 100000000) ((282199 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129604933 : ℝ) / 100000000)) ((-140737 : ℝ) / 50000000) ((-70183 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_47 {k A q d vp vm : ℝ}
    (hk : RB k ((2127 : ℝ) / 1280) ((2667 : ℝ) / 1600))
    (hA : RB A ((2127 : ℝ) / 3407) ((2667 : ℝ) / 4267))
    (hq : RB q ((1406623 : ℝ) / 100000000) ((177959 : ℝ) / 12500000))
    (hd : RB d ((194424653 : ℝ) / 100000000) ((97245019 : ℝ) / 50000000))
    (hp : RB vp ((20742551 : ℝ) / 50000000) ((10478759 : ℝ) / 25000000))
    (hm : RB vm ((129429373 : ℝ) / 100000000) ((129604933 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((3957 : ℝ) / 20000000) ((20269 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99979731 : ℝ) / 100000000) ((19996043 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((15604409 : ℝ) / 25000000) ((15622641 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((23601 : ℝ) / 50000000) ((48859 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99951141 : ℝ) / 100000000) ((49976399 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((14521241 : ℝ) / 25000000) ((29257449 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7257073 : ℝ) / 12500000) ((29243639 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53360011 : ℝ) / 50000000) ((107637343 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3360011 : ℝ) / 50000000) ((7637343 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99979731 : ℝ) / 100000000) ((19996043 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((15604409 : ℝ) / 25000000) ((15622641 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3053 : ℝ) / 20000000) ((15661 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99984339 : ℝ) / 100000000) ((19996947 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((29429373 : ℝ) / 100000000) ((29604933 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((7356191 : ℝ) / 25000000) ((14800207 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((105433721 : ℝ) / 50000000) ((106187027 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((155433721 : ℝ) / 50000000) ((156187027 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((327338971 : ℝ) / 25000000) ((1488090367 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16006451 : ℝ) / 50000000) ((8042013 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2127 : ℝ) / 640) ((2667 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4674823 : ℝ) / 100000000) ((4746167 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101406623 : ℝ) / 100000000) ((12677959 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4609203 : ℝ) / 100000000) ((4680333 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((104609203 : ℝ) / 100000000) ((104680333 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((87514337 : ℝ) / 100000000) ((88119831 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((85074723 : ℝ) / 50000000) ((171384293 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53693907 : ℝ) / 100000000) ((10864791 : ℝ) / 20000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1821 : ℝ) / 5000000) ((151 : ℝ) / 400000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((399849 : ℝ) / 400000) ((4998179 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((85042607 : ℝ) / 50000000) ((54823 : ℝ) / 32000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((194424653 : ℝ) / 50000000) ((97245019 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5469643 : ℝ) / 100000000) ((5537801 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3407 : ℝ) / 1280) ((4267 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((410191 : ℝ) / 20000000) ((260067 : ℝ) / 12500000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3355891 : ℝ) / 100000000) ((3431767 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((103355891 : ℝ) / 100000000) ((103431767 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((33832411 : ℝ) / 2500000) ((769579081 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((217063 : ℝ) / 20000000) ((1099961 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20217063 : ℝ) / 20000000) ((101099961 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16180171 : ℝ) / 50000000) ((32521889 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((692828391 : ℝ) / 50000000) ((1571680051 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((28419197 : ℝ) / 100000000) ((3269937 : ℝ) / 10000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3407 : ℝ) / 1280) ((4267 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((104609203 : ℝ) / 50000000) ((104680333 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((670684393 : ℝ) / 50000000) ((1520258419 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((350798799 : ℝ) / 12500000) ((3182823151 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((209069 : ℝ) / 2500000) ((4751433 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-24813817 : ℝ) / 10000000) ((-117678837 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_860.1 cov_log_861.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2734821 : ℝ) / 100000000) ((2768901 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-14396417 : ℝ) / 4000000) ((-358671969 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_862.1 cov_log_863.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66487451 : ℝ) / 100000000) ((66521077 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_849.1 cov_log_850.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((110483443 : ℝ) / 100000000) ((110882321 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-124713491 : ℝ) / 50000000) ((-15486853 : ℝ) / 6250000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3030293 : ℝ) / 25000000) ((6678917 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((18534259 : ℝ) / 50000000) ((5875357 : ℝ) / 12500000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-3318101 : ℝ) / 1562500) ((-25098349 : ℝ) / 12500000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((104609203 : ℝ) / 100000000) ((104680333 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-24813817 : ℝ) / 10000000) ((-117678837 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-3318101 : ℝ) / 1562500) ((-25098349 : ℝ) / 12500000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((301 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3355891 : ℝ) / 100000000) ((3431767 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((103431767 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((301 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-6824269 : ℝ) / 3125000) ≤ formC0 k A q vp vm + hfun ((301 : ℝ) / 100) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_12, cov_h_10]
  have hP : ((12051389 : ℝ) / 2000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((25098349 : ℝ) / 12500000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((25098349 : ℝ) / 12500000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2753 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2753 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2793 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2793 : ℝ) / 1000)) (lo := ((2753 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2833 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2833 : ℝ) / 1000)) (lo := ((2793 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2873 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2873 : ℝ) / 1000)) (lo := ((2833 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2913 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2913 : ℝ) / 1000)) (lo := ((2873 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2953 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2953 : ℝ) / 1000)) (lo := ((2913 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2993 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2993 : ℝ) / 1000)) (lo := ((2953 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((301 : ℝ) / 100)) (lo := ((2993 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_47 {k : ℝ} (hk : RB k ((2127 : ℝ) / 1280) ((2667 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((2127 : ℝ) / 3407) ((2667 : ℝ) / 4267) ∧
    RB (qa (r1A k)) ((1406623 : ℝ) / 100000000) ((177959 : ℝ) / 12500000) ∧ RB (D0a (r1A k)) ((194424653 : ℝ) / 100000000) ((97245019 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((5192871 : ℝ) / 12500000) ((2667 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((60457 : ℝ) / 32000) ((23632129 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((137451127 : ℝ) / 100000000) ((34374503 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((278872483 : ℝ) / 100000000) ((278919369 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139436241 : ℝ) / 100000000) ((27891937 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((194424653 : ℝ) / 100000000) ((97245019 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1367871 : ℝ) / 12500000) ((3543 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1367871 : ℝ) / 50000000) ((2767969 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1406623 : ℝ) / 100000000) ((177959 : ℝ) / 12500000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((194424653 : ℝ) / 100000000) ((97245019 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1406623 : ℝ) / 100000000) ((177959 : ℝ) / 12500000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2127 : ℝ) / 3407) ((2667 : ℝ) / 4267) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_47 {k : ℝ} (hk : RB k ((2127 : ℝ) / 1280) ((2667 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_47 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_47 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((20742551 : ℝ) / 50000000)) (ph := ((10478759 : ℝ) / 25000000)) (ml := ((129429373 : ℝ) / 100000000)) (mh := ((129604933 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_47 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_48 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2667 : ℝ) / 4267) ((5367 : ℝ) / 8567))
    (hq : RB (qa a) ((1423671 : ℝ) / 100000000) ((364451 : ℝ) / 25000000))
    (hd : RB (D0a a) ((24286733 : ℝ) / 12500000) ((194424659 : ℝ) / 100000000))
    : certE k a ((20602023 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((42049241 : ℝ) / 100000000) ∧ 0 < certE k a ((129429833 : ℝ) / 100000000) ∧ certE k a ((129779571 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((5067 : ℝ) / 25000000) ((5313 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((20602023 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((20591397 : ℝ) / 50000000) ((20591889 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((20602023 : ℝ) / 50000000) ((20602023 : ℝ) / 50000000) ((20602023 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((29397977 : ℝ) / 50000000))
  have h3 : RB z3 ((1094431 : ℝ) / 1562500) ((70045259 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((29397977 : ℝ) / 50000000) ((29397977 : ℝ) / 50000000) ((29397977 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-35605251 : ℝ) / 100000000) ((-35602859 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_864.1 cov_log_865.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-22305753 : ℝ) / 100000000) ((-22252829 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((20602023 : ℝ) / 50000000))
  have h6 : RB z6 ((-709307 : ℝ) / 800000) ((-88663373 : ℝ) / 100000000) := rb_log (show RB ((20602023 : ℝ) / 50000000) ((20602023 : ℝ) / 50000000) ((20602023 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_866.1 cov_log_866.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((3317881 : ℝ) / 5000000) ((33205273 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33210079 : ℝ) / 50000000) ((2077733 : ℝ) / 3125000) := rb_log hd (by norm_num) cov_log_867.1 cov_log_868.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-32459 : ℝ) / 25000000) ((-2403 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((5067 : ℝ) / 25000000) ((5313 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42049241 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((42027989 : ℝ) / 100000000) ((42028973 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((42049241 : ℝ) / 100000000) ((42049241 : ℝ) / 100000000) ((42049241 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57950759 : ℝ) / 100000000))
  have h12 : RB z12 ((72523621 : ℝ) / 100000000) ((1813133 : ℝ) / 2500000) := rb_div_signed h11 (show RB ((57950759 : ℝ) / 100000000) ((57950759 : ℝ) / 100000000) ((57950759 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-8031447 : ℝ) / 25000000) ((-8030861 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_869.1 cov_log_870.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-20125961 : ℝ) / 100000000) ((-20078093 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42049241 : ℝ) / 100000000))
  have h15 : RB z15 ((-43316443 : ℝ) / 50000000) ((-21658221 : ℝ) / 25000000) := rb_log (show RB ((42049241 : ℝ) / 100000000) ((42049241 : ℝ) / 100000000) ((42049241 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_871.1 cov_log_871.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66506923 : ℝ) / 100000000) ((66554793 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33210079 : ℝ) / 50000000) ((2077733 : ℝ) / 3125000) := rb_log hd (by norm_num) cov_log_867.1 cov_log_868.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((19467 : ℝ) / 100000000) ((26927 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((5067 : ℝ) / 25000000) ((5313 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((129429833 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((129408581 : ℝ) / 100000000) ((25881913 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((129429833 : ℝ) / 100000000) ((129429833 : ℝ) / 100000000) ((129429833 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((29429833 : ℝ) / 100000000))
  have h21 : RB z21 ((219859523 : ℝ) / 50000000) ((43972239 : ℝ) / 10000000) := rb_div_signed h20 (show RB ((29429833 : ℝ) / 100000000) ((29429833 : ℝ) / 100000000) ((29429833 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((7404829 : ℝ) / 5000000) ((148097343 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_872.1 cov_log_873.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((925647 : ℝ) / 1000000) ((5798693 : ℝ) / 6250000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((129429833 : ℝ) / 100000000))
  have h24 : RB z24 ((25796871 : ℝ) / 100000000) ((3224609 : ℝ) / 12500000) := rb_log (show RB ((129429833 : ℝ) / 100000000) ((129429833 : ℝ) / 100000000) ((129429833 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_874.1 cov_log_874.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16691957 : ℝ) / 25000000) ((66982217 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33210079 : ℝ) / 50000000) ((2077733 : ℝ) / 3125000) := rb_log hd (by norm_num) cov_log_867.1 cov_log_868.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((70093 : ℝ) / 25000000) ((562059 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((5067 : ℝ) / 25000000) ((5313 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((129779571 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((129758319 : ℝ) / 100000000) ((129759303 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((129779571 : ℝ) / 100000000) ((129779571 : ℝ) / 100000000) ((129779571 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((29779571 : ℝ) / 100000000))
  have h30 : RB z30 ((435729309 : ℝ) / 100000000) ((217866307 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((29779571 : ℝ) / 100000000) ((29779571 : ℝ) / 100000000) ((29779571 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((147185101 : ℝ) / 100000000) ((73592931 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_875.1 cov_log_876.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91994999 : ℝ) / 100000000) ((92208069 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((129779571 : ℝ) / 100000000))
  have h33 : RB z33 ((26066721 : ℝ) / 100000000) ((13033361 : ℝ) / 50000000) := rb_log (show RB ((129779571 : ℝ) / 100000000) ((129779571 : ℝ) / 100000000) ((129779571 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_877.1 cov_log_877.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((65928277 : ℝ) / 100000000) ((16535337 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33210079 : ℝ) / 50000000) ((2077733 : ℝ) / 3125000) := rb_log hd (by norm_num) cov_log_867.1 cov_log_868.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-559179 : ℝ) / 100000000) ((-27881 : ℝ) / 10000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((20602023 : ℝ) / 50000000)) ((-32459 : ℝ) / 25000000) ((-2403 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42049241 : ℝ) / 100000000)) ((19467 : ℝ) / 100000000) ((26927 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((129429833 : ℝ) / 100000000)) ((70093 : ℝ) / 25000000) ((562059 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((129779571 : ℝ) / 100000000)) ((-559179 : ℝ) / 100000000) ((-27881 : ℝ) / 10000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_48 {k A q d vp vm : ℝ}
    (hk : RB k ((2667 : ℝ) / 1600) ((5367 : ℝ) / 3200))
    (hA : RB A ((2667 : ℝ) / 4267) ((5367 : ℝ) / 8567))
    (hq : RB q ((1423671 : ℝ) / 100000000) ((364451 : ℝ) / 25000000))
    (hd : RB d ((24286733 : ℝ) / 12500000) ((194424659 : ℝ) / 100000000))
    (hp : RB vp ((20602023 : ℝ) / 50000000) ((42049241 : ℝ) / 100000000))
    (hm : RB vm ((129429833 : ℝ) / 100000000) ((129779571 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((5067 : ℝ) / 25000000) ((5313 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((24994687 : ℝ) / 25000000) ((24994933 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((31244823 : ℝ) / 50000000) ((62634671 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((241 : ℝ) / 500000) ((25789 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49974211 : ℝ) / 50000000) ((499759 : ℝ) / 500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57950759 : ℝ) / 100000000) ((29397977 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57920869 : ℝ) / 100000000) ((11753523 : ℝ) / 20000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((3322921 : ℝ) / 3125000) ((108138349 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((197921 : ℝ) / 3125000) ((8138349 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((24994687 : ℝ) / 25000000) ((24994933 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((31244823 : ℝ) / 50000000) ((62634671 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((15617 : ℝ) / 100000000) ((821 : ℝ) / 5000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((4999179 : ℝ) / 5000000) ((99984383 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((29429833 : ℝ) / 100000000) ((29779571 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1177 : ℝ) / 4000) ((29774921 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((209873423 : ℝ) / 100000000) ((106431047 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((309873423 : ℝ) / 100000000) ((156431047 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((24575009 : ℝ) / 2000000) ((1578912799 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((7990741 : ℝ) / 25000000) ((16135621 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2667 : ℝ) / 800) ((5367 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((4746163 : ℝ) / 100000000) ((2445011 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101423671 : ℝ) / 100000000) ((25364451 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4677967 : ℝ) / 100000000) ((2410691 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((104677967 : ℝ) / 100000000) ((52410691 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((5461287 : ℝ) / 6250000) ((3543021 : ℝ) / 4000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((21221891 : ℝ) / 12500000) ((172212663 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53330327 : ℝ) / 100000000) ((2182853 : ℝ) / 4000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1857 : ℝ) / 5000000) ((797 : ℝ) / 2000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((1999203 : ℝ) / 2000000) ((4998143 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((10606717 : ℝ) / 6250000) ((5379647 : ℝ) / 3125000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((24286733 : ℝ) / 6250000) ((194424659 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((553221 : ℝ) / 10000000) ((5668661 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4267 : ℝ) / 1600) ((8567 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1033213 : ℝ) / 50000000) ((1062791 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3385723 : ℝ) / 100000000) ((884503 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((103385723 : ℝ) / 100000000) ((25884503 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((158794067 : ℝ) / 12500000) ((408693731 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1096991 : ℝ) / 100000000) ((140791 : ℝ) / 12500000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101096991 : ℝ) / 100000000) ((12640791 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16156797 : ℝ) / 50000000) ((32634723 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((130266613 : ℝ) / 10000000) ((1667409647 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((26918631 : ℝ) / 100000000) ((443027 : ℝ) / 1250000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4267 : ℝ) / 1600) ((8567 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((104677967 : ℝ) / 50000000) ((52410691 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((630356707 : ℝ) / 50000000) ((1611184041 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1319689171 : ℝ) / 50000000) ((3377730757 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7895463 : ℝ) / 100000000) ((10143251 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-126944097 : ℝ) / 50000000) ((-114418081 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_878.1 cov_log_879.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((553221 : ℝ) / 20000000) ((2834331 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-89693251 : ℝ) / 25000000) ((-14253457 : ℝ) / 4000000) := rb_log h49 (by norm_num) cov_log_880.1 cov_log_881.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33210079 : ℝ) / 50000000) ((2077733 : ℝ) / 3125000) := rb_log hd (by norm_num) cov_log_867.1 cov_log_868.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((1107141 : ℝ) / 1000000) ((111511931 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-31007363 : ℝ) / 12500000) ((-122412247 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((11294343 : ℝ) / 100000000) ((1716947 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((31866971 : ℝ) / 100000000) ((1275657 : ℝ) / 2500000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-216191933 : ℝ) / 100000000) ((-96899107 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((104677967 : ℝ) / 100000000) ((52410691 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-126944097 : ℝ) / 50000000) ((-114418081 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-216191933 : ℝ) / 100000000) ((-96899107 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((301 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3385723 : ℝ) / 100000000) ((884503 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((25884503 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((301 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-28015829 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((301 : ℝ) / 100) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_12, cov_h_10]
  have hP : ((116162767 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((96899107 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((96899107 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1293 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1293 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1313 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1313 : ℝ) / 500)) (lo := ((1293 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1333 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1333 : ℝ) / 500)) (lo := ((1313 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1353 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1353 : ℝ) / 500)) (lo := ((1333 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1373 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1373 : ℝ) / 500)) (lo := ((1353 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1393 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1393 : ℝ) / 500)) (lo := ((1373 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1413 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1413 : ℝ) / 500)) (lo := ((1393 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1433 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1433 : ℝ) / 500)) (lo := ((1413 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1453 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1453 : ℝ) / 500)) (lo := ((1433 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1473 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1473 : ℝ) / 500)) (lo := ((1453 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1493 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1493 : ℝ) / 500)) (lo := ((1473 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((301 : ℝ) / 100)) (lo := ((1493 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_48 {k : ℝ} (hk : RB k ((2667 : ℝ) / 1600) ((5367 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((2667 : ℝ) / 4267) ((5367 : ℝ) / 8567) ∧
    RB (qa (r1A k)) ((1423671 : ℝ) / 100000000) ((364451 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((24286733 : ℝ) / 12500000) ((194424659 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2667 : ℝ) / 6400) ((5241211 : ℝ) / 12500000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((23583789 : ℝ) / 12500000) ((60457 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((536552 : ℝ) / 390625) ((17181391 : ℝ) / 12500000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69694667 : ℝ) / 25000000) ((55774497 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69694667 : ℝ) / 50000000) ((139436243 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((24286733 : ℝ) / 12500000) ((194424659 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3543 : ℝ) / 32000) ((1416211 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((86499 : ℝ) / 3125000) ((1416211 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1423671 : ℝ) / 100000000) ((364451 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((24286733 : ℝ) / 12500000) ((194424659 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1423671 : ℝ) / 100000000) ((364451 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2667 : ℝ) / 4267) ((5367 : ℝ) / 8567) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_48 {k : ℝ} (hk : RB k ((2667 : ℝ) / 1600) ((5367 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_48 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_48 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((20602023 : ℝ) / 50000000)) (ph := ((42049241 : ℝ) / 100000000)) (ml := ((129429833 : ℝ) / 100000000)) (mh := ((129779571 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_48 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_49 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5367 : ℝ) / 8567) ((27 : ℝ) / 43))
    (hq : RB (qa a) ((728901 : ℝ) / 50000000) ((1491981 : ℝ) / 100000000))
    (hd : RB (D0a a) ((194163027 : ℝ) / 100000000) ((48573467 : ℝ) / 25000000))
    : certE k a ((41117119 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((20971823 : ℝ) / 50000000) ∧ 0 < certE k a ((129547019 : ℝ) / 100000000) ∧ certE k a ((16236867 : ℝ) / 12500000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((21251 : ℝ) / 100000000) ((22261 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((41117119 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((20547429 : ℝ) / 50000000) ((10273967 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((41117119 : ℝ) / 100000000) ((41117119 : ℝ) / 100000000) ((41117119 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((58882881 : ℝ) / 100000000))
  have h3 : RB z3 ((69790841 : ℝ) / 100000000) ((69792557 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((58882881 : ℝ) / 100000000) ((58882881 : ℝ) / 100000000) ((58882881 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-35966741 : ℝ) / 100000000) ((-35964281 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_882.1 cov_log_883.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-2822971 : ℝ) / 12500000) ((-901227 : ℝ) / 4000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((41117119 : ℝ) / 100000000))
  have h6 : RB z6 ((-22218641 : ℝ) / 25000000) ((-44437281 : ℝ) / 50000000) := rb_log (show RB ((41117119 : ℝ) / 100000000) ((41117119 : ℝ) / 100000000) ((41117119 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_884.1 cov_log_884.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33145397 : ℝ) / 50000000) ((66343889 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16588199 : ℝ) / 25000000) ((33210081 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_885.1 cov_log_886.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-16171 : ℝ) / 12500000) ((-8907 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((21251 : ℝ) / 100000000) ((22261 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((20971823 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((8384277 : ℝ) / 20000000) ((8384479 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((20971823 : ℝ) / 50000000) ((20971823 : ℝ) / 50000000) ((20971823 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((29028177 : ℝ) / 50000000))
  have h12 : RB z12 ((72208091 : ℝ) / 100000000) ((72209831 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((29028177 : ℝ) / 50000000) ((29028177 : ℝ) / 50000000) ((29028177 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-32561809 : ℝ) / 100000000) ((-16279699 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_887.1 cov_log_888.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-5111447 : ℝ) / 25000000) ((-4079521 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((20971823 : ℝ) / 50000000))
  have h15 : RB z15 ((-3475373 : ℝ) / 4000000) ((-86884323 : ℝ) / 100000000) := rb_log (show RB ((20971823 : ℝ) / 50000000) ((20971823 : ℝ) / 50000000) ((20971823 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_889.1 cov_log_889.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((13287707 : ℝ) / 20000000) ((207771 : ℝ) / 312500) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16588199 : ℝ) / 25000000) ((33210081 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_885.1 cov_log_886.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((18373 : ℝ) / 100000000) ((33481 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((21251 : ℝ) / 100000000) ((22261 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((129547019 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((64762379 : ℝ) / 50000000) ((16190721 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((129547019 : ℝ) / 100000000) ((129547019 : ℝ) / 100000000) ((129547019 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((29547019 : ℝ) / 100000000))
  have h21 : RB z21 ((109592069 : ℝ) / 25000000) ((87674339 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((29547019 : ℝ) / 100000000) ((29547019 : ℝ) / 100000000) ((29547019 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((73894459 : ℝ) / 50000000) ((147789701 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_890.1 cov_log_891.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92585867 : ℝ) / 100000000) ((18559637 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((129547019 : ℝ) / 100000000))
  have h24 : RB z24 ((25887371 : ℝ) / 100000000) ((6471843 : ℝ) / 25000000) := rb_log (show RB ((129547019 : ℝ) / 100000000) ((129547019 : ℝ) / 100000000) ((129547019 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_892.1 cov_log_892.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((13339699 : ℝ) / 20000000) ((33455407 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16588199 : ℝ) / 25000000) ((33210081 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_885.1 cov_log_886.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((278333 : ℝ) / 100000000) ((279009 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((21251 : ℝ) / 100000000) ((22261 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((16236867 : ℝ) / 12500000)) - (z28)
  have h29 : RB z29 ((5194907 : ℝ) / 4000000) ((25974737 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((16236867 : ℝ) / 12500000) ((16236867 : ℝ) / 12500000) ((16236867 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3736867 : ℝ) / 12500000))
  have h30 : RB z30 ((434430349 : ℝ) / 100000000) ((434433729 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((3736867 : ℝ) / 12500000) ((3736867 : ℝ) / 12500000) ((3736867 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((9180409 : ℝ) / 6250000) ((5875493 : ℝ) / 4000000) := rb_log h30 (by norm_num) cov_log_893.1 cov_log_894.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92020553 : ℝ) / 100000000) ((92231577 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((16236867 : ℝ) / 12500000))
  have h33 : RB z33 ((1046223 : ℝ) / 4000000) ((3269447 : ℝ) / 12500000) := rb_log (show RB ((16236867 : ℝ) / 12500000) ((16236867 : ℝ) / 12500000) ((16236867 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_895.1 cov_log_895.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((65864977 : ℝ) / 100000000) ((33038001 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16588199 : ℝ) / 25000000) ((33210081 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_885.1 cov_log_886.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-111037 : ℝ) / 20000000) ((-138397 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((41117119 : ℝ) / 100000000)) ((-16171 : ℝ) / 12500000) ((-8907 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((20971823 : ℝ) / 50000000)) ((18373 : ℝ) / 100000000) ((33481 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((129547019 : ℝ) / 100000000)) ((278333 : ℝ) / 100000000) ((279009 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((16236867 : ℝ) / 12500000)) ((-111037 : ℝ) / 20000000) ((-138397 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_49 {k A q d vp vm : ℝ}
    (hk : RB k ((5367 : ℝ) / 3200) ((27 : ℝ) / 16))
    (hA : RB A ((5367 : ℝ) / 8567) ((27 : ℝ) / 43))
    (hq : RB q ((728901 : ℝ) / 50000000) ((1491981 : ℝ) / 100000000))
    (hd : RB d ((194163027 : ℝ) / 100000000) ((48573467 : ℝ) / 25000000))
    (hp : RB vp ((41117119 : ℝ) / 100000000) ((20971823 : ℝ) / 50000000))
    (hm : RB vm ((129547019 : ℝ) / 100000000) ((16236867 : ℝ) / 12500000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((21251 : ℝ) / 100000000) ((22261 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99977739 : ℝ) / 100000000) ((99978749 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((62633421 : ℝ) / 100000000) ((12555471 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((10133 : ℝ) / 20000000) ((54141 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99945859 : ℝ) / 100000000) ((19989867 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((29028177 : ℝ) / 50000000) ((58882881 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58024921 : ℝ) / 100000000) ((7356631 : ℝ) / 12500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((10642341 : ℝ) / 10000000) ((108190333 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((642341 : ℝ) / 10000000) ((8190333 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99977739 : ℝ) / 100000000) ((99978749 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((62633421 : ℝ) / 100000000) ((12555471 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((409 : ℝ) / 2500000) ((537 : ℝ) / 3125000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((3124463 : ℝ) / 3125000) ((2499591 : ℝ) / 2500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((29547019 : ℝ) / 100000000) ((3736867 : ℝ) / 12500000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((29541941 : ℝ) / 100000000) ((14945023 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((52386521 : ℝ) / 25000000) ((212502473 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((77386521 : ℝ) / 25000000) ((312502473 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1220951577 : ℝ) / 100000000) ((778402749 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15999873 : ℝ) / 50000000) ((4038171 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5367 : ℝ) / 1600) ((27 : ℝ) / 8) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2445007 : ℝ) / 50000000) ((1258859 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50728901 : ℝ) / 50000000) ((101491981 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((301133 : ℝ) / 6250000) ((992617 : ℝ) / 20000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((6551133 : ℝ) / 6250000) ((20992617 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((87603373 : ℝ) / 100000000) ((88777817 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((2126167 : ℝ) / 1250000) ((34497971 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53266001 : ℝ) / 100000000) ((54482673 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((7801 : ℝ) / 20000000) ((41793 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99958207 : ℝ) / 100000000) ((19992199 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1328299 : ℝ) / 781250) ((10776411 : ℝ) / 6250000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((194163027 : ℝ) / 50000000) ((48573467 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((176907 : ℝ) / 3125000) ((724707 : ℝ) / 12500000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8567 : ℝ) / 3200) ((43 : ℝ) / 16) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2106427 : ℝ) / 100000000) ((1082789 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((173781 : ℝ) / 5000000) ((3628613 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((5173781 : ℝ) / 5000000) ((103628613 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((631693607 : ℝ) / 50000000) ((322659189 : ℝ) / 20000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1122293 : ℝ) / 100000000) ((1151691 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101122293 : ℝ) / 100000000) ((101151691 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((8089719 : ℝ) / 25000000) ((32677427 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((129574609 : ℝ) / 10000000) ((411493343 : ℝ) / 25000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5458789 : ℝ) / 20000000) ((17822419 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8567 : ℝ) / 3200) ((43 : ℝ) / 16) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((6551133 : ℝ) / 3125000) ((20992617 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1252951323 : ℝ) / 100000000) ((794555433 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2626640243 : ℝ) / 100000000) ((3335959579 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8025239 : ℝ) / 100000000) ((5115851 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-126128939 : ℝ) / 50000000) ((-56991981 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_896.1 cov_log_897.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((176907 : ℝ) / 6250000) ((724707 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-178235631 : ℝ) / 50000000) ((-177043183 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_898.1 cov_log_899.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16588199 : ℝ) / 25000000) ((33210081 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_885.1 cov_log_886.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((347769 : ℝ) / 312500) ((14010503 : ℝ) / 12500000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-122592591 : ℝ) / 50000000) ((-121001171 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((11020471 : ℝ) / 100000000) ((1677597 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((15458719 : ℝ) / 50000000) ((24585629 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-6695867 : ℝ) / 3125000) ((-48207771 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((6551133 : ℝ) / 6250000) ((20992617 : ℝ) / 20000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-126128939 : ℝ) / 50000000) ((-56991981 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-6695867 : ℝ) / 3125000) ((-48207771 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ (3 : ℝ) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((173781 : ℝ) / 5000000) ((3628613 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((103628613 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : (3 : ℝ) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-222239081 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun (3 : ℝ) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_14, cov_h_10]
  have hP : ((288567571 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((48207771 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((48207771 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2591 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2591 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2631 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2631 : ℝ) / 1000)) (lo := ((2591 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2671 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2671 : ℝ) / 1000)) (lo := ((2631 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2711 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2711 : ℝ) / 1000)) (lo := ((2671 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2751 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2751 : ℝ) / 1000)) (lo := ((2711 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2791 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2791 : ℝ) / 1000)) (lo := ((2751 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2831 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2831 : ℝ) / 1000)) (lo := ((2791 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2871 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2871 : ℝ) / 1000)) (lo := ((2831 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2911 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2911 : ℝ) / 1000)) (lo := ((2871 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2951 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2951 : ℝ) / 1000)) (lo := ((2911 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2991 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2991 : ℝ) / 1000)) (lo := ((2951 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := (3 : ℝ)) (lo := ((2991 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_49 {k : ℝ} (hk : RB k ((5367 : ℝ) / 3200) ((27 : ℝ) / 16)) :
    RB (k / (k + 1)) ((5367 : ℝ) / 8567) ((27 : ℝ) / 43) ∧
    RB (qa (r1A k)) ((728901 : ℝ) / 50000000) ((1491981 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((194163027 : ℝ) / 100000000) ((48573467 : ℝ) / 25000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((41929687 : ℝ) / 100000000) ((27 : ℝ) / 64) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((15073 : ℝ) / 8000) ((188670313 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((17157929 : ℝ) / 12500000) ((137357313 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69671197 : ℝ) / 25000000) ((27877867 : ℝ) / 10000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69671197 : ℝ) / 50000000) ((27877867 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((194163027 : ℝ) / 100000000) ((48573467 : ℝ) / 25000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((11329687 : ℝ) / 100000000) ((927 : ℝ) / 8000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2832421 : ℝ) / 100000000) ((927 : ℝ) / 32000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((728901 : ℝ) / 50000000) ((1491981 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((194163027 : ℝ) / 100000000) ((48573467 : ℝ) / 25000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((728901 : ℝ) / 50000000) ((1491981 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5367 : ℝ) / 8567) ((27 : ℝ) / 43) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_49 {k : ℝ} (hk : RB k ((5367 : ℝ) / 3200) ((27 : ℝ) / 16)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_49 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_49 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((41117119 : ℝ) / 100000000)) (ph := ((20971823 : ℝ) / 50000000)) (ml := ((129547019 : ℝ) / 100000000)) (mh := ((16236867 : ℝ) / 12500000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_49 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
