import LeanProject.EqualityCase

/-!
# EP-1038: the Jensen step of component atomization (Stage 15, fourth batch)

proof.md Lemma 7.2 replaces the roots of each component of `S_f` by their mean. The key inequality
is: for a point `x` on one side of a group of roots `r_1, …, r_n` with mean `c`,
`∏ |x - r_i| ≤ |x - c|^n`, i.e. the new polynomial is at least as large in absolute value at `x`.

* `amgm_prod_le` — `∏ z_i ≤ ((∑ z_i)/n)^n` for nonnegative `z : Fin n → ℝ`, `n ≥ 1`.
* `atomize_right`, `atomize_left` — the one-sided product inequalities.
* `atomize_abs` — the absolute-value form used in Lemma 7.2.
-/

open Real Finset

namespace EP1038

/-- AM–GM with natural powers: `∏ z_i ≤ ((∑ z_i)/n)^n` for `z_i ≥ 0`. -/
theorem amgm_prod_le {n : ℕ} (hn : 0 < n) (z : Fin n → ℝ) (hz : ∀ i, 0 ≤ z i) :
    ∏ i, z i ≤ ((∑ i, z i) / n) ^ n := by
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn.ne'
  have hw : ∀ i ∈ (univ : Finset (Fin n)), (0 : ℝ) ≤ (n : ℝ)⁻¹ := fun _ _ => by positivity
  have hw' : ∑ _i : Fin n, (n : ℝ)⁻¹ = 1 := by
    rw [sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul]; field_simp
  have key := Real.geom_mean_le_arith_mean_weighted univ (fun _ => (n : ℝ)⁻¹) z hw hw'
    (fun i _ => hz i)
  have hrhs : ∑ i, (n : ℝ)⁻¹ * z i = (∑ i, z i) / n := by rw [← mul_sum]; field_simp
  rw [hrhs] at key
  have hlhs : (∏ i, z i ^ (n : ℝ)⁻¹) ^ n = ∏ i, z i := by
    rw [← prod_pow]
    exact prod_congr rfl fun i _ => Real.rpow_inv_natCast_pow (hz i) hn.ne'
  rw [← hlhs]
  exact pow_le_pow_left₀ (prod_nonneg fun i _ => Real.rpow_nonneg (hz i) _) key n

/-- Right-hand side of a group: if `r_i ≤ x` for all `i`, then `∏ (x - r_i) ≤ (x - c)^n` with
`c` the mean of the `r_i`. -/
theorem atomize_right {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) {x : ℝ} (hx : ∀ i, r i ≤ x) :
    ∏ i, (x - r i) ≤ (x - (∑ i, r i) / n) ^ n := by
  have h := amgm_prod_le hn (fun i => x - r i) (fun i => sub_nonneg.mpr (hx i))
  have hsum : (∑ i, (x - r i)) / n = x - (∑ i, r i) / n := by
    have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn.ne'
    rw [sum_sub_distrib, sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp
  rwa [hsum] at h

/-- Left-hand side of a group: if `x ≤ r_i` for all `i`, then `∏ (r_i - x) ≤ (c - x)^n`. -/
theorem atomize_left {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) {x : ℝ} (hx : ∀ i, x ≤ r i) :
    ∏ i, (r i - x) ≤ ((∑ i, r i) / n - x) ^ n := by
  have h := amgm_prod_le hn (fun i => r i - x) (fun i => sub_nonneg.mpr (hx i))
  have hsum : (∑ i, (r i - x)) / n = (∑ i, r i) / n - x := by
    have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn.ne'
    rw [sum_sub_distrib, sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp
  rwa [hsum] at h

/-- Lemma 7.2, Jensen step: if `x` lies on one side of the group, replacing the group by `n` copies
of its mean does not decrease `|f(x)|`: `∏ |x - r_i| ≤ |x - c|^n`. -/
theorem atomize_abs {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) {x : ℝ}
    (hside : (∀ i, r i ≤ x) ∨ (∀ i, x ≤ r i)) :
    ∏ i, |x - r i| ≤ |x - (∑ i, r i) / n| ^ n := by
  rcases hside with h | h
  · have hc : (∑ i, r i) / n ≤ x := by
      have hn' : (0 : ℝ) < n := by exact_mod_cast hn
      rw [div_le_iff₀ hn']
      calc ∑ i, r i ≤ ∑ _i : Fin n, x := sum_le_sum fun i _ => h i
        _ = x * n := by rw [sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul, mul_comm]
    rw [abs_of_nonneg (sub_nonneg.mpr hc)]
    calc ∏ i, |x - r i| = ∏ i, (x - r i) :=
          prod_congr rfl fun i _ => abs_of_nonneg (sub_nonneg.mpr (h i))
      _ ≤ _ := atomize_right hn r h
  · have hc : x ≤ (∑ i, r i) / n := by
      have hn' : (0 : ℝ) < n := by exact_mod_cast hn
      rw [le_div_iff₀ hn']
      calc x * n = ∑ _i : Fin n, x := by
            rw [sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul, mul_comm]
        _ ≤ ∑ i, r i := sum_le_sum fun i _ => h i
    rw [abs_of_nonpos (sub_nonpos.mpr hc), neg_sub]
    calc ∏ i, |x - r i| = ∏ i, (r i - x) :=
          prod_congr rfl fun i _ => by rw [abs_of_nonpos (sub_nonpos.mpr (h i)), neg_sub]
      _ ≤ _ := atomize_left hn r h

end EP1038
