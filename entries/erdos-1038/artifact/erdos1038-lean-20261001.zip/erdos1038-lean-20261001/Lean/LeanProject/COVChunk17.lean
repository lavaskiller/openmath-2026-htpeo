import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk13
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_85 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((12879 : ℝ) / 19279) ((807 : ℝ) / 1207))
    (hq : RB (qa a) ((259299 : ℝ) / 10000000) ((2610861 : ℝ) / 100000000))
    (hd : RB (D0a a) ((37990353 : ℝ) / 20000000) ((95008973 : ℝ) / 50000000))
    : certE k a ((19485493 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((19623559 : ℝ) / 50000000) ∧ 0 < certE k a ((26622321 : ℝ) / 20000000) ∧ certE k a ((2665233 : ℝ) / 2000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((13447 : ℝ) / 20000000) ((34083 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((19485493 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((1945141 : ℝ) / 5000000) ((38903751 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((19485493 : ℝ) / 50000000) ((19485493 : ℝ) / 50000000) ((19485493 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((30514507 : ℝ) / 50000000))
  have h3 : RB z3 ((12748959 : ℝ) / 20000000) ((63746321 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((30514507 : ℝ) / 50000000) ((30514507 : ℝ) / 50000000) ((30514507 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-45028267 : ℝ) / 100000000) ((-45025871 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1530.1 cov_log_1531.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-7526473 : ℝ) / 25000000) ((-7519687 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((19485493 : ℝ) / 50000000))
  have h6 : RB z6 ((-47117639 : ℝ) / 50000000) ((-23558819 : ℝ) / 25000000) := rb_log (show RB ((19485493 : ℝ) / 50000000) ((19485493 : ℝ) / 50000000) ((19485493 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1532.1 cov_log_1532.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((8016173 : ℝ) / 12500000) ((6415653 : ℝ) / 10000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((32079999 : ℝ) / 50000000) ((12838967 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1533.1 cov_log_1534.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-65451 : ℝ) / 100000000) ((-867 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((13447 : ℝ) / 20000000) ((34083 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19623559 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((4897369 : ℝ) / 12500000) ((39179883 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((19623559 : ℝ) / 50000000) ((19623559 : ℝ) / 50000000) ((19623559 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30376441 : ℝ) / 50000000))
  have h12 : RB z12 ((32244521 : ℝ) / 50000000) ((4030661 : ℝ) / 6250000) := rb_div_signed h11 (show RB ((30376441 : ℝ) / 50000000) ((30376441 : ℝ) / 50000000) ((30376441 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-1370859 : ℝ) / 3125000) ((-10966277 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1535.1 cov_log_1536.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-7332449 : ℝ) / 25000000) ((-29303321 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19623559 : ℝ) / 50000000))
  have h15 : RB z15 ((-93529219 : ℝ) / 100000000) ((-93529217 : ℝ) / 100000000) := rb_log (show RB ((19623559 : ℝ) / 50000000) ((19623559 : ℝ) / 50000000) ((19623559 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1537.1 cov_log_1537.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64199421 : ℝ) / 100000000) ((32112949 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((32079999 : ℝ) / 50000000) ((12838967 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1533.1 cov_log_1534.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2293 : ℝ) / 50000000) ((659 : ℝ) / 1000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((13447 : ℝ) / 20000000) ((34083 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((26622321 : ℝ) / 20000000)) - (z19)
  have h20 : RB z20 ((133043439 : ℝ) / 100000000) ((13304437 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((26622321 : ℝ) / 20000000) ((26622321 : ℝ) / 20000000) ((26622321 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((6622321 : ℝ) / 20000000))
  have h21 : RB z21 ((8036061 : ℝ) / 2000000) ((401805863 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((6622321 : ℝ) / 20000000) ((6622321 : ℝ) / 20000000) ((6622321 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((27815837 : ℝ) / 20000000) ((8692493 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_1538.1 cov_log_1539.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((3716377 : ℝ) / 4000000) ((92988791 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((26622321 : ℝ) / 20000000))
  have h24 : RB z24 ((7150443 : ℝ) / 25000000) ((28601773 : ℝ) / 100000000) := rb_log (show RB ((26622321 : ℝ) / 20000000) ((26622321 : ℝ) / 20000000) ((26622321 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1540.1 cov_log_1540.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16076913 : ℝ) / 25000000) ((64387019 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((32079999 : ℝ) / 50000000) ((12838967 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1533.1 cov_log_1534.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((112817 : ℝ) / 100000000) ((227021 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((13447 : ℝ) / 20000000) ((34083 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((2665233 : ℝ) / 2000000)) - (z28)
  have h29 : RB z29 ((33298371 : ℝ) / 25000000) ((26638883 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((2665233 : ℝ) / 2000000) ((2665233 : ℝ) / 2000000) ((2665233 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((665233 : ℝ) / 2000000))
  have h30 : RB z30 ((400441601 : ℝ) / 100000000) ((400444401 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((665233 : ℝ) / 2000000) ((665233 : ℝ) / 2000000) ((665233 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((5549591 : ℝ) / 4000000) ((138740477 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1541.1 cov_log_1542.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92682689 : ℝ) / 100000000) ((4638093 : ℝ) / 5000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((2665233 : ℝ) / 2000000))
  have h33 : RB z33 ((2871443 : ℝ) / 10000000) ((28714431 : ℝ) / 100000000) := rb_log (show RB ((2665233 : ℝ) / 2000000) ((2665233 : ℝ) / 2000000) ((2665233 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1543.1 cov_log_1543.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((31984129 : ℝ) / 50000000) ((6404743 : ℝ) / 10000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((32079999 : ℝ) / 50000000) ((12838967 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1533.1 cov_log_1534.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-226577 : ℝ) / 100000000) ((-14071 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((19485493 : ℝ) / 50000000)) ((-65451 : ℝ) / 100000000) ((-867 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19623559 : ℝ) / 50000000)) ((2293 : ℝ) / 50000000) ((659 : ℝ) / 1000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((26622321 : ℝ) / 20000000)) ((112817 : ℝ) / 100000000) ((227021 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((2665233 : ℝ) / 2000000)) ((-226577 : ℝ) / 100000000) ((-14071 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_85 {k A q d vp vm : ℝ}
    (hk : RB k ((12879 : ℝ) / 6400) ((807 : ℝ) / 400))
    (hA : RB A ((12879 : ℝ) / 19279) ((807 : ℝ) / 1207))
    (hq : RB q ((259299 : ℝ) / 10000000) ((2610861 : ℝ) / 100000000))
    (hd : RB d ((37990353 : ℝ) / 20000000) ((95008973 : ℝ) / 50000000))
    (hp : RB vp ((19485493 : ℝ) / 50000000) ((19623559 : ℝ) / 50000000))
    (hm : RB vm ((26622321 : ℝ) / 20000000) ((2665233 : ℝ) / 2000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((13447 : ℝ) / 20000000) ((34083 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49965917 : ℝ) / 50000000) ((19986553 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((1668943 : ℝ) / 2500000) ((66815031 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((171311 : ℝ) / 100000000) ((34983 : ℝ) / 20000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((19965017 : ℝ) / 20000000) ((99828689 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30376441 : ℝ) / 50000000) ((30514507 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7580827 : ℝ) / 12500000) ((12184893 : ℝ) / 20000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((109574569 : ℝ) / 100000000) ((110171079 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((9574569 : ℝ) / 100000000) ((10171079 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49965917 : ℝ) / 50000000) ((19986553 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((1668943 : ℝ) / 2500000) ((66815031 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((50453 : ℝ) / 100000000) ((5121 : ℝ) / 10000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((9994879 : ℝ) / 10000000) ((99949547 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((6622321 : ℝ) / 20000000) ((665233 : ℝ) / 2000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((4136831 : ℝ) / 12500000) ((33244869 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((40161217 : ℝ) / 20000000) ((25236343 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((60161217 : ℝ) / 20000000) ((37736343 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((983179857 : ℝ) / 100000000) ((1044433437 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16562283 : ℝ) / 50000000) ((33244009 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((12879 : ℝ) / 3200) ((807 : ℝ) / 200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((5217987 : ℝ) / 50000000) ((421393 : ℝ) / 4000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((10259299 : ℝ) / 10000000) ((102610861 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5085219 : ℝ) / 50000000) ((10268563 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((55085219 : ℝ) / 50000000) ((110268563 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((93864487 : ℝ) / 100000000) ((11786333 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((178297249 : ℝ) / 100000000) ((5599037 : ℝ) / 3125000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((6484363 : ℝ) / 12500000) ((26150679 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((128553 : ℝ) / 100000000) ((26281 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19973719 : ℝ) / 20000000) ((99871447 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178062957 : ℝ) / 100000000) ((178938857 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((37990353 : ℝ) / 10000000) ((95008973 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((492543 : ℝ) / 5000000) ((9922209 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((19279 : ℝ) / 6400) ((1207 : ℝ) / 400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((51009 : ℝ) / 1562500) ((3293851 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((6606829 : ℝ) / 100000000) ((13399 : ℝ) / 200000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((106606829 : ℝ) / 100000000) ((213399 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((262034217 : ℝ) / 25000000) ((139300657 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((486447 : ℝ) / 25000000) ((30647 : ℝ) / 1562500) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25486447 : ℝ) / 25000000) ((1593147 : ℝ) / 1562500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33769099 : ℝ) / 100000000) ((1694803 : ℝ) / 5000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1081905967 : ℝ) / 100000000) ((287075329 : ℝ) / 25000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17659821 : ℝ) / 50000000) ((7564667 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((19279 : ℝ) / 6400) ((1207 : ℝ) / 400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((55085219 : ℝ) / 25000000) ((110268563 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1016304423 : ℝ) / 100000000) ((538838723 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((559833517 : ℝ) / 25000000) ((2376678867 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((12674593 : ℝ) / 100000000) ((13474989 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-103278539 : ℝ) / 50000000) ((-12527093 : ℝ) / 6250000) := rb_log h47 (by norm_num) cov_log_1544.1 cov_log_1545.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((492543 : ℝ) / 10000000) ((992221 : ℝ) / 20000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-60215173 : ℝ) / 20000000) ((-37544271 : ℝ) / 12500000) := rb_log h49 (by norm_num) cov_log_1546.1 cov_log_1547.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((32079999 : ℝ) / 50000000) ((12838967 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1533.1 cov_log_1534.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((12911197 : ℝ) / 10000000) ((3237827 : ℝ) / 2500000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-34392779 : ℝ) / 20000000) ((-667348 : ℝ) / 390625) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((450419 : ℝ) / 10000000) ((5380091 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2381699 : ℝ) / 20000000) ((238009 : ℝ) / 1562500) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-800277 : ℝ) / 500000) ((-2431383 : ℝ) / 1562500) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((55085219 : ℝ) / 50000000) ((110268563 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-103278539 : ℝ) / 50000000) ((-12527093 : ℝ) / 6250000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-800277 : ℝ) / 500000) ((-2431383 : ℝ) / 1562500) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((143 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((6606829 : ℝ) / 100000000) ((13399 : ℝ) / 200000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((213399 : ℝ) / 400000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((143 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-2170771 : ℝ) / 1250000) ≤ formC0 k A q vp vm + hfun ((143 : ℝ) / 50) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_33, cov_h_24]
  have hP : ((221660701 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((2431383 : ℝ) / 1562500) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((2431383 : ℝ) / 1562500))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2547 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2547 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2587 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2587 : ℝ) / 1000)) (lo := ((2547 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2627 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2627 : ℝ) / 1000)) (lo := ((2587 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2667 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2667 : ℝ) / 1000)) (lo := ((2627 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2707 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2707 : ℝ) / 1000)) (lo := ((2667 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2747 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2747 : ℝ) / 1000)) (lo := ((2707 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2787 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2787 : ℝ) / 1000)) (lo := ((2747 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2827 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2827 : ℝ) / 1000)) (lo := ((2787 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((143 : ℝ) / 50)) (lo := ((2827 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_85 {k : ℝ} (hk : RB k ((12879 : ℝ) / 6400) ((807 : ℝ) / 400)) :
    RB (k / (k + 1)) ((12879 : ℝ) / 19279) ((807 : ℝ) / 1207) ∧
    RB (qa (r1A k)) ((259299 : ℝ) / 10000000) ((2610861 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((37990353 : ℝ) / 20000000) ((95008973 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((50308593 : ℝ) / 100000000) ((807 : ℝ) / 1600) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((14413 : ℝ) / 8000) ((180291407 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((1073797 : ℝ) / 800000) ((33568159 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275645981 : ℝ) / 100000000) ((275693993 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((13782299 : ℝ) / 10000000) ((137846997 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((37990353 : ℝ) / 20000000) ((95008973 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((19708593 : ℝ) / 100000000) ((1587 : ℝ) / 8000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1231787 : ℝ) / 25000000) ((1587 : ℝ) / 32000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((259299 : ℝ) / 10000000) ((2610861 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((37990353 : ℝ) / 20000000) ((95008973 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((259299 : ℝ) / 10000000) ((2610861 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((12879 : ℝ) / 19279) ((807 : ℝ) / 1207) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_85 {k : ℝ} (hk : RB k ((12879 : ℝ) / 6400) ((807 : ℝ) / 400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_85 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_85 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((19485493 : ℝ) / 50000000)) (ph := ((19623559 : ℝ) / 50000000)) (ml := ((26622321 : ℝ) / 20000000)) (mh := ((2665233 : ℝ) / 2000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_85 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_86 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((807 : ℝ) / 1207) ((2589 : ℝ) / 3869))
    (hq : RB (qa a) ((130543 : ℝ) / 5000000) ((2628743 : ℝ) / 100000000))
    (hd : RB (D0a a) ((189885577 : ℝ) / 100000000) ((47487943 : ℝ) / 25000000))
    : certE k a ((7787929 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((4901869 : ℝ) / 12500000) ∧ 0 < certE k a ((3329043 : ℝ) / 2500000) ∧ certE k a ((26662293 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((13633 : ℝ) / 20000000) ((69103 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((7787929 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((19435271 : ℝ) / 50000000) ((971787 : ℝ) / 2500000) := rb_widen (rb_sub (show RB ((7787929 : ℝ) / 20000000) ((7787929 : ℝ) / 20000000) ((7787929 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((12212071 : ℝ) / 20000000))
  have h3 : RB z3 ((63659213 : ℝ) / 100000000) ((63660751 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((12212071 : ℝ) / 20000000) ((12212071 : ℝ) / 20000000) ((12212071 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22581307 : ℝ) / 50000000) ((-11290049 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_1548.1 cov_log_1549.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-472207 : ℝ) / 1562500) ((-30194099 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((7787929 : ℝ) / 20000000))
  have h6 : RB z6 ((-23578933 : ℝ) / 25000000) ((-9431573 : ℝ) / 10000000) := rb_log (show RB ((7787929 : ℝ) / 20000000) ((7787929 : ℝ) / 20000000) ((7787929 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1550.1 cov_log_1550.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((32047241 : ℝ) / 50000000) ((64121633 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64125147 : ℝ) / 100000000) ((16040001 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1551.1 cov_log_1552.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-32761 : ℝ) / 50000000) ((-1757 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((13633 : ℝ) / 20000000) ((69103 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((4901869 : ℝ) / 12500000)) - (z10)
  have h11 : RB z11 ((39145849 : ℝ) / 100000000) ((39146787 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4901869 : ℝ) / 12500000) ((4901869 : ℝ) / 12500000) ((4901869 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((7598131 : ℝ) / 12500000))
  have h12 : RB z12 ((64400457 : ℝ) / 100000000) ((64402001 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((7598131 : ℝ) / 12500000) ((7598131 : ℝ) / 12500000) ((7598131 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-44004947 : ℝ) / 100000000) ((-11000637 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1553.1 cov_log_1554.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-14723289 : ℝ) / 50000000) ((-459689 : ℝ) / 1562500) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((4901869 : ℝ) / 12500000))
  have h15 : RB z15 ((-9361121 : ℝ) / 10000000) ((-11701401 : ℝ) / 12500000) := rb_log (show RB ((4901869 : ℝ) / 12500000) ((4901869 : ℝ) / 12500000) ((4901869 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1555.1 cov_log_1555.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((6416463 : ℝ) / 10000000) ((32095557 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64125147 : ℝ) / 100000000) ((16040001 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1551.1 cov_log_1552.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2313 : ℝ) / 50000000) ((65967 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((13633 : ℝ) / 20000000) ((69103 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((3329043 : ℝ) / 2500000)) - (z19)
  have h20 : RB z20 ((133092617 : ℝ) / 100000000) ((26618711 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((3329043 : ℝ) / 2500000) ((3329043 : ℝ) / 2500000) ((3329043 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((829043 : ℝ) / 2500000))
  have h21 : RB z21 ((401344131 : ℝ) / 100000000) ((5016837 : ℝ) / 1250000) := rb_div_signed h20 (show RB ((829043 : ℝ) / 2500000) ((829043 : ℝ) / 2500000) ((829043 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((27792981 : ℝ) / 20000000) ((138965613 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1556.1 cov_log_1557.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((11613989 : ℝ) / 12500000) ((92990947 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((3329043 : ℝ) / 2500000))
  have h24 : RB z24 ((14319707 : ℝ) / 50000000) ((5727883 : ℝ) / 20000000) := rb_log (show RB ((3329043 : ℝ) / 2500000) ((3329043 : ℝ) / 2500000) ((3329043 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1558.1 cov_log_1558.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64272497 : ℝ) / 100000000) ((64351533 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64125147 : ℝ) / 100000000) ((16040001 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1551.1 cov_log_1552.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((112493 : ℝ) / 100000000) ((113193 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((13633 : ℝ) / 20000000) ((69103 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((26662293 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((66621181 : ℝ) / 50000000) ((1332433 : ℝ) / 1000000) := rb_widen (rb_sub (show RB ((26662293 : ℝ) / 20000000) ((26662293 : ℝ) / 20000000) ((26662293 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((6662293 : ℝ) / 20000000))
  have h30 : RB z30 ((399989499 : ℝ) / 100000000) ((79998463 : ℝ) / 20000000) := rb_div_signed h29 (show RB ((6662293 : ℝ) / 20000000) ((6662293 : ℝ) / 20000000) ((6662293 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((13862681 : ℝ) / 10000000) ((138627517 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1559.1 cov_log_1560.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46342931 : ℝ) / 50000000) ((18552941 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((26662293 : ℝ) / 20000000))
  have h33 : RB z33 ((7187951 : ℝ) / 25000000) ((5750361 : ℝ) / 20000000) := rb_log (show RB ((26662293 : ℝ) / 20000000) ((26662293 : ℝ) / 20000000) ((26662293 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1561.1 cov_log_1561.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63934057 : ℝ) / 100000000) ((64012901 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64125147 : ℝ) / 100000000) ((16040001 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1551.1 cov_log_1552.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-225947 : ℝ) / 100000000) ((-56123 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((7787929 : ℝ) / 20000000)) ((-32761 : ℝ) / 50000000) ((-1757 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((4901869 : ℝ) / 12500000)) ((2313 : ℝ) / 50000000) ((65967 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((3329043 : ℝ) / 2500000)) ((112493 : ℝ) / 100000000) ((113193 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((26662293 : ℝ) / 20000000)) ((-225947 : ℝ) / 100000000) ((-56123 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_86 {k A q d vp vm : ℝ}
    (hk : RB k ((807 : ℝ) / 400) ((2589 : ℝ) / 1280))
    (hA : RB A ((807 : ℝ) / 1207) ((2589 : ℝ) / 3869))
    (hq : RB q ((130543 : ℝ) / 5000000) ((2628743 : ℝ) / 100000000))
    (hd : RB d ((189885577 : ℝ) / 100000000) ((47487943 : ℝ) / 25000000))
    (hp : RB vp ((7787929 : ℝ) / 20000000) ((4901869 : ℝ) / 12500000))
    (hm : RB vm ((3329043 : ℝ) / 2500000) ((26662293 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((13633 : ℝ) / 20000000) ((69103 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930897 : ℝ) / 100000000) ((19986367 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((66813781 : ℝ) / 100000000) ((66870903 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((679 : ℝ) / 390625) ((88731 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49911269 : ℝ) / 50000000) ((389946 : ℝ) / 390625) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((7598131 : ℝ) / 12500000) ((12212071 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((60677177 : ℝ) / 100000000) ((30477109 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((21922611 : ℝ) / 20000000) ((110207671 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1922611 : ℝ) / 20000000) ((10207671 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930897 : ℝ) / 100000000) ((19986367 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((66813781 : ℝ) / 100000000) ((66870903 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((12783 : ℝ) / 25000000) ((10379 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19989621 : ℝ) / 20000000) ((24987217 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((829043 : ℝ) / 2500000) ((6662293 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((3314451 : ℝ) / 10000000) ((33294433 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((200675533 : ℝ) / 100000000) ((100877797 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((300675533 : ℝ) / 100000000) ((150877797 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((489827699 : ℝ) / 50000000) ((1040252033 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16569701 : ℝ) / 50000000) ((33258443 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((807 : ℝ) / 200) ((2589 : ℝ) / 640) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((526741 : ℝ) / 5000000) ((10634087 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((5130543 : ℝ) / 5000000) ((102628743 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((513249 : ℝ) / 5000000) ((10363511 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((5513249 : ℝ) / 5000000) ((110363511 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((5871673 : ℝ) / 6250000) ((4718591 : ℝ) / 5000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((89195681 : ℝ) / 50000000) ((35852189 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((51852701 : ℝ) / 100000000) ((13069507 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((130389 : ℝ) / 100000000) ((33317 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24966683 : ℝ) / 25000000) ((99869611 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178153623 : ℝ) / 100000000) ((179027209 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((189885577 : ℝ) / 50000000) ((47487943 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((9915293 : ℝ) / 100000000) ((78021 : ℝ) / 781250) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1207 : ℝ) / 400) ((3869 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((820081 : ℝ) / 25000000) ((3309591 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((6657817 : ℝ) / 100000000) ((3375407 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((106657817 : ℝ) / 100000000) ((53375407 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1044879061 : ℝ) / 100000000) ((1110477513 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((979233 : ℝ) / 50000000) ((1974099 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50979233 : ℝ) / 50000000) ((101974099 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((1351537 : ℝ) / 4000000) ((16957499 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((539333743 : ℝ) / 50000000) ((1144392511 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((8845947 : ℝ) / 25000000) ((4734339 : ℝ) / 12500000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1207 : ℝ) / 400) ((3869 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((5513249 : ℝ) / 2500000) ((110363511 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((2531987 : ℝ) / 250000) ((268377619 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2233515967 : ℝ) / 100000000) ((473905541 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((2546921 : ℝ) / 20000000) ((1691647 : ℝ) / 12500000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-206084713 : ℝ) / 100000000) ((-200002603 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1562.1 cov_log_1563.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2478823 : ℝ) / 50000000) ((78021 : ℝ) / 1562500) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-3755299 : ℝ) / 1250000) ((-59941287 : ℝ) / 20000000) := rb_log h49 (by norm_num) cov_log_1564.1 cov_log_1565.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64125147 : ℝ) / 100000000) ((16040001 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1551.1 cov_log_1552.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((32343121 : ℝ) / 25000000) ((64886817 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-42762859 : ℝ) / 25000000) ((-169932801 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2207919 : ℝ) / 50000000) ((211577 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((5829533 : ℝ) / 50000000) ((597949 : ℝ) / 4000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-15939237 : ℝ) / 10000000) ((-38746019 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((5513249 : ℝ) / 5000000) ((110363511 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-206084713 : ℝ) / 100000000) ((-200002603 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-15939237 : ℝ) / 10000000) ((-38746019 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((57 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((6657817 : ℝ) / 100000000) ((3375407 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((53375407 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((57 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-43240563 : ℝ) / 25000000) ≤ formC0 k A q vp vm + hfun ((57 : ℝ) / 20) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_34, cov_h_24]
  have hP : ((88232509 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((38746019 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((38746019 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((509 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((509 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((517 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((517 : ℝ) / 200)) (lo := ((509 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((21 : ℝ) / 8) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((21 : ℝ) / 8)) (lo := ((517 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((533 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((533 : ℝ) / 200)) (lo := ((21 : ℝ) / 8)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((541 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((541 : ℝ) / 200)) (lo := ((533 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((549 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((549 : ℝ) / 200)) (lo := ((541 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((557 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((557 : ℝ) / 200)) (lo := ((549 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((113 : ℝ) / 40) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((113 : ℝ) / 40)) (lo := ((557 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((57 : ℝ) / 20)) (lo := ((113 : ℝ) / 40)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_86 {k : ℝ} (hk : RB k ((807 : ℝ) / 400) ((2589 : ℝ) / 1280)) :
    RB (k / (k + 1)) ((807 : ℝ) / 1207) ((2589 : ℝ) / 3869) ∧
    RB (qa (r1A k)) ((130543 : ℝ) / 5000000) ((2628743 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((189885577 : ℝ) / 100000000) ((47487943 : ℝ) / 25000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((807 : ℝ) / 1600) ((50566407 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((180033593 : ℝ) / 100000000) ((14413 : ℝ) / 8000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((134176597 : ℝ) / 100000000) ((67112313 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275597953 : ℝ) / 100000000) ((275645983 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((2153109 : ℝ) / 1562500) ((8613937 : ℝ) / 6250000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((189885577 : ℝ) / 100000000) ((47487943 : ℝ) / 25000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1587 : ℝ) / 8000) ((19966407 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1587 : ℝ) / 32000) ((2495801 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((130543 : ℝ) / 5000000) ((2628743 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((189885577 : ℝ) / 100000000) ((47487943 : ℝ) / 25000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((130543 : ℝ) / 5000000) ((2628743 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((807 : ℝ) / 1207) ((2589 : ℝ) / 3869) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_86 {k : ℝ} (hk : RB k ((807 : ℝ) / 400) ((2589 : ℝ) / 1280)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_86 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_86 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((7787929 : ℝ) / 20000000)) (ph := ((4901869 : ℝ) / 12500000)) (ml := ((3329043 : ℝ) / 2500000)) (mh := ((26662293 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_86 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_87 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2589 : ℝ) / 3869) ((6489 : ℝ) / 9689))
    (hq : RB (qa a) ((2628741 : ℝ) / 100000000) ((2646637 : ℝ) / 100000000))
    (hd : RB (D0a a) ((189819379 : ℝ) / 100000000) ((11867849 : ℝ) / 6250000))
    : certE k a ((3890839 : ℝ) / 10000000) < 0 ∧ 0 < certE k a ((39182889 : ℝ) / 100000000) ∧ 0 < certE k a ((66605867 : ℝ) / 50000000) ∧ certE k a ((133361181 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((34551 : ℝ) / 50000000) ((70047 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((3890839 : ℝ) / 10000000)) - (z1)
  have h2 : RB z2 ((38838343 : ℝ) / 100000000) ((4854911 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((3890839 : ℝ) / 10000000) ((3890839 : ℝ) / 10000000) ((3890839 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((6109161 : ℝ) / 10000000))
  have h3 : RB z3 ((63573939 : ℝ) / 100000000) ((63575487 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((6109161 : ℝ) / 10000000) ((6109161 : ℝ) / 10000000) ((6109161 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22648329 : ℝ) / 50000000) ((-45294221 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1566.1 cov_log_1567.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-15168233 : ℝ) / 50000000) ((-15154657 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((3890839 : ℝ) / 10000000))
  have h6 : RB z6 ((-94396029 : ℝ) / 100000000) ((-94396027 : ℝ) / 100000000) := rb_log (show RB ((3890839 : ℝ) / 10000000) ((3890839 : ℝ) / 10000000) ((3890839 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1568.1 cov_log_1568.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((64059561 : ℝ) / 100000000) ((12817343 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64090279 : ℝ) / 100000000) ((64125153 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1569.1 cov_log_1570.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-8199 : ℝ) / 12500000) ((-891 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((34551 : ℝ) / 50000000) ((70047 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((39182889 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((19556421 : ℝ) / 50000000) ((39113787 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((39182889 : ℝ) / 100000000) ((39182889 : ℝ) / 100000000) ((39182889 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((60817111 : ℝ) / 100000000))
  have h12 : RB z12 ((8039029 : ℝ) / 12500000) ((64313787 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((60817111 : ℝ) / 100000000) ((60817111 : ℝ) / 100000000) ((60817111 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-8828407 : ℝ) / 20000000) ((-1379363 : ℝ) / 3125000) := rb_log h12 (by norm_num) cov_log_1571.1 cov_log_1572.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-14781591 : ℝ) / 50000000) ((-29536693 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((39182889 : ℝ) / 100000000))
  have h15 : RB z15 ((-18738601 : ℝ) / 20000000) ((-93693003 : ℝ) / 100000000) := rb_log (show RB ((39182889 : ℝ) / 100000000) ((39182889 : ℝ) / 100000000) ((39182889 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1573.1 cov_log_1573.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64129821 : ℝ) / 100000000) ((8019539 : ℝ) / 12500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64090279 : ℝ) / 100000000) ((64125153 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1569.1 cov_log_1570.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1167 : ℝ) / 25000000) ((66033 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((34551 : ℝ) / 50000000) ((70047 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((66605867 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((133141687 : ℝ) / 100000000) ((16642829 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((66605867 : ℝ) / 50000000) ((66605867 : ℝ) / 50000000) ((66605867 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((16605867 : ℝ) / 50000000))
  have h21 : RB z21 ((40088749 : ℝ) / 10000000) ((12527823 : ℝ) / 3125000) := rb_div_signed h20 (show RB ((16605867 : ℝ) / 50000000) ((16605867 : ℝ) / 50000000) ((16605867 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((69425531 : ℝ) / 50000000) ((5554071 : ℝ) / 4000000) := rb_log h21 (by norm_num) cov_log_1574.1 cov_log_1575.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23228573 : ℝ) / 25000000) ((92993 : ℝ) / 100000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((66605867 : ℝ) / 50000000))
  have h24 : RB z24 ((14338483 : ℝ) / 50000000) ((28676967 : ℝ) / 100000000) := rb_log (show RB ((66605867 : ℝ) / 50000000) ((66605867 : ℝ) / 50000000) ((66605867 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1576.1 cov_log_1576.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((2569493 : ℝ) / 4000000) ((32158017 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64090279 : ℝ) / 100000000) ((64125153 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1569.1 cov_log_1570.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((28043 : ℝ) / 25000000) ((45151 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((34551 : ℝ) / 50000000) ((70047 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((133361181 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((66645567 : ℝ) / 50000000) ((133292079 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((133361181 : ℝ) / 100000000) ((133361181 : ℝ) / 100000000) ((133361181 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((33361181 : ℝ) / 100000000))
  have h30 : RB z30 ((199769807 : ℝ) / 50000000) ((24971403 : ℝ) / 6250000) := rb_div_signed h29 (show RB ((33361181 : ℝ) / 100000000) ((33361181 : ℝ) / 100000000) ((33361181 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((138514273 : ℝ) / 100000000) ((27702997 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_1577.1 cov_log_1578.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((3707557 : ℝ) / 4000000) ((46383721 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((133361181 : ℝ) / 100000000))
  have h33 : RB z33 ((2878909 : ℝ) / 10000000) ((7197273 : ℝ) / 25000000) := rb_log (show RB ((133361181 : ℝ) / 100000000) ((133361181 : ℝ) / 100000000) ((133361181 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1579.1 cov_log_1579.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63899833 : ℝ) / 100000000) ((3998647 : ℝ) / 6250000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64090279 : ℝ) / 100000000) ((64125153 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1569.1 cov_log_1570.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-5633 : ℝ) / 2500000) ((-111927 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((3890839 : ℝ) / 10000000)) ((-8199 : ℝ) / 12500000) ((-891 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((39182889 : ℝ) / 100000000)) ((1167 : ℝ) / 25000000) ((66033 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((66605867 : ℝ) / 50000000)) ((28043 : ℝ) / 25000000) ((45151 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((133361181 : ℝ) / 100000000)) ((-5633 : ℝ) / 2500000) ((-111927 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_87 {k A q d vp vm : ℝ}
    (hk : RB k ((2589 : ℝ) / 1280) ((6489 : ℝ) / 3200))
    (hA : RB A ((2589 : ℝ) / 3869) ((6489 : ℝ) / 9689))
    (hq : RB q ((2628741 : ℝ) / 100000000) ((2646637 : ℝ) / 100000000))
    (hd : RB d ((189819379 : ℝ) / 100000000) ((11867849 : ℝ) / 6250000))
    (hp : RB vp ((3890839 : ℝ) / 10000000) ((39182889 : ℝ) / 100000000))
    (hm : RB vm ((66605867 : ℝ) / 50000000) ((133361181 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((34551 : ℝ) / 50000000) ((70047 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99929953 : ℝ) / 100000000) ((49965449 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((33434821 : ℝ) / 50000000) ((66926577 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((176357 : ℝ) / 100000000) ((180031 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99819969 : ℝ) / 100000000) ((99823643 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((60817111 : ℝ) / 100000000) ((6109161 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((60707621 : ℝ) / 100000000) ((60983871 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((27412839 : ℝ) / 25000000) ((110244111 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((2412839 : ℝ) / 25000000) ((10244111 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99929953 : ℝ) / 100000000) ((49965449 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((33434821 : ℝ) / 50000000) ((66926577 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((10363 : ℝ) / 20000000) ((6573 : ℝ) / 12500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((12493427 : ℝ) / 12500000) ((19989637 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((16605867 : ℝ) / 50000000) ((33361181 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((33194269 : ℝ) / 100000000) ((6668779 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((200545383 : ℝ) / 100000000) ((2520261 : ℝ) / 1250000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((300545383 : ℝ) / 100000000) ((3770261 : ℝ) / 1250000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((976170601 : ℝ) / 100000000) ((259030959 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33154203 : ℝ) / 100000000) ((16636423 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2589 : ℝ) / 640) ((6489 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((5317039 : ℝ) / 50000000) ((1341721 : ℝ) / 12500000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102628741 : ℝ) / 100000000) ((102646637 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((10359889 : ℝ) / 100000000) ((10458833 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((110359889 : ℝ) / 100000000) ((110458833 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((18805769 : ℝ) / 20000000) ((94452791 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((178484969 : ℝ) / 100000000) ((89676117 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((2591527 : ℝ) / 5000000) ((13063691 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1653 : ℝ) / 1250000) ((135147 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99864853 : ℝ) / 100000000) ((1248347 : ℝ) / 1250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178243751 : ℝ) / 100000000) ((179115059 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((189819379 : ℝ) / 50000000) ((11867849 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((9979719 : ℝ) / 100000000) ((2010233 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3869 : ℝ) / 1280) ((9689 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((206001 : ℝ) / 6250000) ((831319 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((67089 : ℝ) / 1000000) ((6802227 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((1067089 : ℝ) / 1000000) ((106802227 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((104166091 : ℝ) / 10000000) ((276650833 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((246393 : ℝ) / 12500000) ((198679 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((12746393 : ℝ) / 12500000) ((10198679 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((845193 : ℝ) / 2500000) ((8483477 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((107546863 : ℝ) / 10000000) ((28513431 : ℝ) / 2500000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17723809 : ℝ) / 50000000) ((9481503 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3869 : ℝ) / 1280) ((9689 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((110359889 : ℝ) / 50000000) ((110458833 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((252331201 : ℝ) / 25000000) ((534698341 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1113889733 : ℝ) / 50000000) ((2362486191 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((6397193 : ℝ) / 50000000) ((13591169 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-102808187 : ℝ) / 50000000) ((-99787497 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1580.1 cov_log_1581.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((4989859 : ℝ) / 100000000) ((5025583 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-149888129 : ℝ) / 50000000) ((-299062871 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1582.1 cov_log_1583.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64090279 : ℝ) / 100000000) ((64125153 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1569.1 cov_log_1570.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((129632603 : ℝ) / 100000000) ((130033787 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-34028731 : ℝ) / 20000000) ((-42257271 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1081997 : ℝ) / 25000000) ((5199297 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((11411661 : ℝ) / 100000000) ((293351 : ℝ) / 2000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-79365997 : ℝ) / 50000000) ((-77180767 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((110359889 : ℝ) / 100000000) ((110458833 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-102808187 : ℝ) / 50000000) ((-99787497 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-79365997 : ℝ) / 50000000) ((-77180767 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((57 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((67089 : ℝ) / 1000000) ((6802227 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((106802227 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((57 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-172493913 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((57 : ℝ) / 20) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_34, cov_h_24]
  have hP : ((4390113 : ℝ) / 1000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((77180767 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((77180767 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2539 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2539 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2579 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2579 : ℝ) / 1000)) (lo := ((2539 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2619 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2619 : ℝ) / 1000)) (lo := ((2579 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2659 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2659 : ℝ) / 1000)) (lo := ((2619 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2699 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2699 : ℝ) / 1000)) (lo := ((2659 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2739 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2739 : ℝ) / 1000)) (lo := ((2699 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2779 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2779 : ℝ) / 1000)) (lo := ((2739 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2819 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2819 : ℝ) / 1000)) (lo := ((2779 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((57 : ℝ) / 20)) (lo := ((2819 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_87 {k : ℝ} (hk : RB k ((2589 : ℝ) / 1280) ((6489 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((2589 : ℝ) / 3869) ((6489 : ℝ) / 9689) ∧
    RB (qa (r1A k)) ((2628741 : ℝ) / 100000000) ((2646637 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((189819379 : ℝ) / 100000000) ((11867849 : ℝ) / 6250000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((25283203 : ℝ) / 50000000) ((50695313 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((179904687 : ℝ) / 100000000) ((90016797 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((16766069 : ℝ) / 12500000) ((67088299 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((68887477 : ℝ) / 25000000) ((55119591 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((68887477 : ℝ) / 50000000) ((68899489 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((189819379 : ℝ) / 100000000) ((11867849 : ℝ) / 6250000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((9983203 : ℝ) / 50000000) ((20095313 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((4991601 : ℝ) / 100000000) ((5023829 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((2628741 : ℝ) / 100000000) ((2646637 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((189819379 : ℝ) / 100000000) ((11867849 : ℝ) / 6250000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((2628741 : ℝ) / 100000000) ((2646637 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2589 : ℝ) / 3869) ((6489 : ℝ) / 9689) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_87 {k : ℝ} (hk : RB k ((2589 : ℝ) / 1280) ((6489 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_87 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_87 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((3890839 : ℝ) / 10000000)) (ph := ((39182889 : ℝ) / 100000000)) (ml := ((66605867 : ℝ) / 50000000)) (mh := ((133361181 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_87 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_88 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((6489 : ℝ) / 9689) ((13011 : ℝ) / 19411))
    (hq : RB (qa a) ((529327 : ℝ) / 20000000) ((83267 : ℝ) / 3125000))
    (hd : RB (D0a a) ((189753167 : ℝ) / 100000000) ((94909693 : ℝ) / 50000000))
    : certE k a ((38877217 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((2446933 : ℝ) / 6250000) ∧ 0 < certE k a ((8328853 : ℝ) / 6250000) ∧ certE k a ((133410799 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((35023 : ℝ) / 50000000) ((35499 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((38877217 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((38806219 : ℝ) / 100000000) ((38807171 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((38877217 : ℝ) / 100000000) ((38877217 : ℝ) / 100000000) ((38877217 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((61122783 : ℝ) / 100000000))
  have h3 : RB z3 ((63488959 : ℝ) / 100000000) ((31745259 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((61122783 : ℝ) / 100000000) ((61122783 : ℝ) / 100000000) ((61122783 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22715209 : ℝ) / 50000000) ((-45427961 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1584.1 cov_log_1585.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-30451557 : ℝ) / 100000000) ((-15212201 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((38877217 : ℝ) / 100000000))
  have h6 : RB z6 ((-4723809 : ℝ) / 5000000) ((-47238089 : ℝ) / 50000000) := rb_log (show RB ((38877217 : ℝ) / 100000000) ((38877217 : ℝ) / 100000000) ((38877217 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1586.1 cov_log_1586.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((64024621 : ℝ) / 100000000) ((32025889 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64055391 : ℝ) / 100000000) ((12818057 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1587.1 cov_log_1588.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-513 : ℝ) / 781250) ((-3613 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((35023 : ℝ) / 50000000) ((35499 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((2446933 : ℝ) / 6250000)) - (z10)
  have h11 : RB z11 ((3907993 : ℝ) / 10000000) ((19540441 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((2446933 : ℝ) / 6250000) ((2446933 : ℝ) / 6250000) ((2446933 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((3803067 : ℝ) / 6250000))
  have h12 : RB z12 ((16056091 : ℝ) / 25000000) ((6422593 : ℝ) / 10000000) := rb_div_signed h11 (show RB ((3803067 : ℝ) / 6250000) ((3803067 : ℝ) / 6250000) ((3803067 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-11069689 : ℝ) / 25000000) ((-11069079 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1589.1 cov_log_1590.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-2967961 : ℝ) / 10000000) ((-29653113 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((2446933 : ℝ) / 6250000))
  have h15 : RB z15 ((-93774607 : ℝ) / 100000000) ((-18754921 : ℝ) / 20000000) := rb_log (show RB ((2446933 : ℝ) / 6250000) ((2446933 : ℝ) / 6250000) ((2446933 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1591.1 cov_log_1591.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((12818999 : ℝ) / 20000000) ((32060747 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64055391 : ℝ) / 100000000) ((12818057 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1587.1 cov_log_1588.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((471 : ℝ) / 10000000) ((66103 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((35023 : ℝ) / 50000000) ((35499 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((8328853 : ℝ) / 6250000)) - (z19)
  have h20 : RB z20 ((2663813 : ℝ) / 2000000) ((66595801 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((8328853 : ℝ) / 6250000) ((8328853 : ℝ) / 6250000) ((8328853 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((2078853 : ℝ) / 6250000))
  have h21 : RB z21 ((80086621 : ℝ) / 20000000) ((1564203 : ℝ) / 390625) := rb_div_signed h20 (show RB ((2078853 : ℝ) / 6250000) ((2078853 : ℝ) / 6250000) ((2078853 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((138737653 : ℝ) / 100000000) ((138738371 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1592.1 cov_log_1593.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((11614571 : ℝ) / 12500000) ((92994949 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((8328853 : ℝ) / 6250000))
  have h24 : RB z24 ((7178607 : ℝ) / 25000000) ((28714429 : ℝ) / 100000000) := rb_log (show RB ((8328853 : ℝ) / 6250000) ((8328853 : ℝ) / 6250000) ((8328853 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1594.1 cov_log_1594.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64202139 : ℝ) / 100000000) ((64280521 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64055391 : ℝ) / 100000000) ((12818057 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1587.1 cov_log_1588.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((55927 : ℝ) / 50000000) ((22513 : ℝ) / 10000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((35023 : ℝ) / 50000000) ((35499 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((133410799 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((133339801 : ℝ) / 100000000) ((133340753 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((133410799 : ℝ) / 100000000) ((133410799 : ℝ) / 100000000) ((133410799 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((33410799 : ℝ) / 100000000))
  have h30 : RB z30 ((15963677 : ℝ) / 4000000) ((15963791 : ℝ) / 4000000) := rb_div_signed h29 (show RB ((33410799 : ℝ) / 100000000) ((33410799 : ℝ) / 100000000) ((33410799 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((138402159 : ℝ) / 100000000) ((34600719 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_1595.1 cov_log_1596.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46345939 : ℝ) / 50000000) ((9277007 : ℝ) / 10000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((133410799 : ℝ) / 100000000))
  have h33 : RB z33 ((28826289 : ℝ) / 100000000) ((28826291 : ℝ) / 100000000) := rb_log (show RB ((133410799 : ℝ) / 100000000) ((133410799 : ℝ) / 100000000) ((133410799 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1597.1 cov_log_1597.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63865587 : ℝ) / 100000000) ((63943781 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64055391 : ℝ) / 100000000) ((12818057 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1587.1 cov_log_1588.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-112349 : ℝ) / 50000000) ((-11161 : ℝ) / 10000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((38877217 : ℝ) / 100000000)) ((-513 : ℝ) / 781250) ((-3613 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((2446933 : ℝ) / 6250000)) ((471 : ℝ) / 10000000) ((66103 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((8328853 : ℝ) / 6250000)) ((55927 : ℝ) / 50000000) ((22513 : ℝ) / 10000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((133410799 : ℝ) / 100000000)) ((-112349 : ℝ) / 50000000) ((-11161 : ℝ) / 10000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_88 {k A q d vp vm : ℝ}
    (hk : RB k ((6489 : ℝ) / 3200) ((13011 : ℝ) / 6400))
    (hA : RB A ((6489 : ℝ) / 9689) ((13011 : ℝ) / 19411))
    (hq : RB q ((529327 : ℝ) / 20000000) ((83267 : ℝ) / 3125000))
    (hd : RB d ((189753167 : ℝ) / 100000000) ((94909693 : ℝ) / 50000000))
    (hp : RB vp ((38877217 : ℝ) / 100000000) ((2446933 : ℝ) / 6250000))
    (hm : RB vm ((8328853 : ℝ) / 6250000) ((133410799 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((35023 : ℝ) / 50000000) ((35499 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49964501 : ℝ) / 50000000) ((49964977 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((33462653 : ℝ) / 50000000) ((33491027 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((5591 : ℝ) / 3125000) ((91311 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49908689 : ℝ) / 50000000) ((3119409 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((3803067 : ℝ) / 6250000) ((61122783 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((15184487 : ℝ) / 25000000) ((15253357 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((10968947 : ℝ) / 10000000) ((27570101 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((968947 : ℝ) / 10000000) ((2570101 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49964501 : ℝ) / 50000000) ((49964977 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((33462653 : ℝ) / 50000000) ((33491027 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((52503 : ℝ) / 100000000) ((26639 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49973361 : ℝ) / 50000000) ((99947497 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((2078853 : ℝ) / 6250000) ((33410799 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((16621963 : ℝ) / 50000000) ((16696629 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((100207811 : ℝ) / 50000000) ((100743297 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((150207811 : ℝ) / 50000000) ((150743297 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((486362209 : ℝ) / 50000000) ((1032048193 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((3316897 : ℝ) / 10000000) ((16643609 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((6489 : ℝ) / 1600) ((13011 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((10733759 : ℝ) / 100000000) ((1083387 : ℝ) / 10000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((20529327 : ℝ) / 20000000) ((3208267 : ℝ) / 3125000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1306897 : ℝ) / 12500000) ((10554531 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((13806897 : ℝ) / 12500000) ((110554531 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((73524 : ℝ) / 78125) ((47266791 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((178578071 : ℝ) / 100000000) ((35888613 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((2590421 : ℝ) / 5000000) ((26115783 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((67053 : ℝ) / 50000000) ((1713 : ℝ) / 1250000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((1248287 : ℝ) / 1250000) ((49932947 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178333347 : ℝ) / 100000000) ((89601211 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((189753167 : ℝ) / 50000000) ((94909693 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((10044147 : ℝ) / 100000000) ((10115643 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((9689 : ℝ) / 3200) ((19411 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((662331 : ℝ) / 20000000) ((835227 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3380041 : ℝ) / 50000000) ((3426871 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((53380041 : ℝ) / 50000000) ((53426871 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((519240693 : ℝ) / 50000000) ((551391057 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1983823 : ℝ) / 100000000) ((499871 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101983823 : ℝ) / 100000000) ((25499871 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33826983 : ℝ) / 100000000) ((33952791 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1072308369 : ℝ) / 100000000) ((227346981 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((35511153 : ℝ) / 100000000) ((9494317 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((9689 : ℝ) / 3200) ((19411 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((13806897 : ℝ) / 6250000) ((110554531 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((251473347 : ℝ) / 25000000) ((1065335411 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((17360333 : ℝ) / 781250) ((471110627 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((6426967 : ℝ) / 50000000) ((3412243 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-205152031 : ℝ) / 100000000) ((-199150597 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1598.1 cov_log_1599.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((5022073 : ℝ) / 100000000) ((2528911 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-299132743 : ℝ) / 100000000) ((-149211711 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_1600.1 cov_log_1601.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64055391 : ℝ) / 100000000) ((12818057 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_1587.1 cov_log_1588.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((64946161 : ℝ) / 50000000) ((130293547 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-169240421 : ℝ) / 100000000) ((-1345039 : ℝ) / 800000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1357 : ℝ) / 32000) ((5109701 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((11166219 : ℝ) / 100000000) ((3597251 : ℝ) / 25000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-79037101 : ℝ) / 50000000) ((-153740871 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((13806897 : ℝ) / 12500000) ((110554531 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-205152031 : ℝ) / 100000000) ((-199150597 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-79037101 : ℝ) / 50000000) ((-153740871 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((57 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3380041 : ℝ) / 50000000) ((3426871 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((53426871 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((57 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-17202957 : ℝ) / 10000000) ≤ formC0 k A q vp vm + hfun ((57 : ℝ) / 20) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_34, cov_h_24]
  have hP : ((218433809 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((153740871 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((153740871 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1267 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1267 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1287 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1287 : ℝ) / 500)) (lo := ((1267 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1307 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1307 : ℝ) / 500)) (lo := ((1287 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1327 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1327 : ℝ) / 500)) (lo := ((1307 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1347 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1347 : ℝ) / 500)) (lo := ((1327 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1367 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1367 : ℝ) / 500)) (lo := ((1347 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1387 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1387 : ℝ) / 500)) (lo := ((1367 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1407 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1407 : ℝ) / 500)) (lo := ((1387 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((57 : ℝ) / 20)) (lo := ((1407 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_88 {k : ℝ} (hk : RB k ((6489 : ℝ) / 3200) ((13011 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((6489 : ℝ) / 9689) ((13011 : ℝ) / 19411) ∧
    RB (qa (r1A k)) ((529327 : ℝ) / 20000000) ((83267 : ℝ) / 3125000) ∧ RB (D0a (r1A k)) ((189753167 : ℝ) / 100000000) ((94909693 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((3168457 : ℝ) / 6250000) ((50824219 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((179775781 : ℝ) / 100000000) ((11244043 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((134080491 : ℝ) / 100000000) ((67064277 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((275501847 : ℝ) / 100000000) ((275549911 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((137750923 : ℝ) / 100000000) ((34443739 : ℝ) / 25000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((189753167 : ℝ) / 100000000) ((94909693 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1255957 : ℝ) / 6250000) ((20224219 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1255957 : ℝ) / 25000000) ((1011211 : ℝ) / 20000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((529327 : ℝ) / 20000000) ((83267 : ℝ) / 3125000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((189753167 : ℝ) / 100000000) ((94909693 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((529327 : ℝ) / 20000000) ((83267 : ℝ) / 3125000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((6489 : ℝ) / 9689) ((13011 : ℝ) / 19411) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_88 {k : ℝ} (hk : RB k ((6489 : ℝ) / 3200) ((13011 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_88 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_88 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((38877217 : ℝ) / 100000000)) (ph := ((2446933 : ℝ) / 6250000)) (ml := ((8328853 : ℝ) / 6250000)) (mh := ((133410799 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_88 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_89 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((13011 : ℝ) / 19411) ((3261 : ℝ) / 4861))
    (hq : RB (qa a) ((1332271 : ℝ) / 50000000) ((2682463 : ℝ) / 100000000))
    (hd : RB (D0a a) ((37937389 : ℝ) / 20000000) ((94876587 : ℝ) / 50000000))
    : certE k a ((310769 : ℝ) / 800000) < 0 ∧ 0 < certE k a ((7823813 : ℝ) / 20000000) ∧ 0 < certE k a ((133311463 : ℝ) / 100000000) ∧ certE k a ((133460319 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((70997 : ℝ) / 100000000) ((71957 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((310769 : ℝ) / 800000)) - (z1)
  have h2 : RB z2 ((4846771 : ℝ) / 12500000) ((4846891 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((310769 : ℝ) / 800000) ((310769 : ℝ) / 800000) ((310769 : ℝ) / 800000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((489231 : ℝ) / 800000))
  have h3 : RB z3 ((63404269 : ℝ) / 100000000) ((792573 : ℝ) / 1250000) := rb_div_signed h2 (show RB ((489231 : ℝ) / 800000) ((489231 : ℝ) / 800000) ((489231 : ℝ) / 800000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-45563901 : ℝ) / 100000000) ((-45561421 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1602.1 cov_log_1603.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-15283263 : ℝ) / 50000000) ((-15269683 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((310769 : ℝ) / 800000))
  have h6 : RB z6 ((-94556187 : ℝ) / 100000000) ((-18911237 : ℝ) / 20000000) := rb_log (show RB ((310769 : ℝ) / 800000) ((310769 : ℝ) / 800000) ((310769 : ℝ) / 800000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1604.1 cov_log_1604.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63989659 : ℝ) / 100000000) ((64016821 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((32010243 : ℝ) / 50000000) ((64055397 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1605.1 cov_log_1606.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-32869 : ℝ) / 50000000) ((-733 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((70997 : ℝ) / 100000000) ((71957 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((7823813 : ℝ) / 20000000)) - (z10)
  have h11 : RB z11 ((9761777 : ℝ) / 25000000) ((9762017 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((7823813 : ℝ) / 20000000) ((7823813 : ℝ) / 20000000) ((7823813 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((12176187 : ℝ) / 20000000))
  have h12 : RB z12 ((1603421 : ℝ) / 2500000) ((32069209 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((12176187 : ℝ) / 20000000) ((12176187 : ℝ) / 20000000) ((12176187 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-44415127 : ℝ) / 100000000) ((-8882533 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_1607.1 cov_log_1608.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-931121 : ℝ) / 3125000) ((-29769367 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((7823813 : ℝ) / 20000000))
  have h15 : RB z15 ((-46928013 : ℝ) / 50000000) ((-11732003 : ℝ) / 12500000) := rb_log (show RB ((7823813 : ℝ) / 20000000) ((7823813 : ℝ) / 20000000) ((7823813 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1609.1 cov_log_1609.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((8007519 : ℝ) / 12500000) ((64086659 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((32010243 : ℝ) / 50000000) ((64055397 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1605.1 cov_log_1606.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((951 : ℝ) / 20000000) ((66173 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((70997 : ℝ) / 100000000) ((71957 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133311463 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((66619753 : ℝ) / 50000000) ((66620233 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((133311463 : ℝ) / 100000000) ((133311463 : ℝ) / 100000000) ((133311463 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33311463 : ℝ) / 100000000))
  have h21 : RB z21 ((399980949 : ℝ) / 100000000) ((49997979 : ℝ) / 12500000) := rb_div_signed h20 (show RB ((33311463 : ℝ) / 100000000) ((33311463 : ℝ) / 100000000) ((33311463 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((138624673 : ℝ) / 100000000) ((34656349 : ℝ) / 25000000) := rb_log h21 (by norm_num) cov_log_1610.1 cov_log_1611.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92918737 : ℝ) / 100000000) ((18599359 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133311463 : ℝ) / 100000000))
  have h24 : RB z24 ((28751803 : ℝ) / 100000000) ((7187951 : ℝ) / 25000000) := rb_log (show RB ((133311463 : ℝ) / 100000000) ((133311463 : ℝ) / 100000000) ((133311463 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1612.1 cov_log_1612.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64166933 : ℝ) / 100000000) ((250957 : ℝ) / 390625) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((32010243 : ℝ) / 50000000) ((64055397 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1605.1 cov_log_1606.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((6971 : ℝ) / 6250000) ((112253 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((70997 : ℝ) / 100000000) ((71957 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((133460319 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((66694181 : ℝ) / 50000000) ((66694661 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((133460319 : ℝ) / 100000000) ((133460319 : ℝ) / 100000000) ((133460319 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((33460319 : ℝ) / 100000000))
  have h30 : RB z30 ((199323207 : ℝ) / 50000000) ((99662321 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((33460319 : ℝ) / 100000000) ((33460319 : ℝ) / 100000000) ((33460319 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((27658093 : ℝ) / 20000000) ((34572797 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_1613.1 cov_log_1614.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92694721 : ℝ) / 100000000) ((92772591 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((133460319 : ℝ) / 100000000))
  have h33 : RB z33 ((28863401 : ℝ) / 100000000) ((28863403 : ℝ) / 100000000) := rb_log (show RB ((133460319 : ℝ) / 100000000) ((133460319 : ℝ) / 100000000) ((133460319 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1615.1 cov_log_1615.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((31915659 : ℝ) / 50000000) ((6390919 : ℝ) / 10000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((32010243 : ℝ) / 50000000) ((64055397 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1605.1 cov_log_1606.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-224079 : ℝ) / 100000000) ((-1739 : ℝ) / 1562500) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((310769 : ℝ) / 800000)) ((-32869 : ℝ) / 50000000) ((-733 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((7823813 : ℝ) / 20000000)) ((951 : ℝ) / 20000000) ((66173 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133311463 : ℝ) / 100000000)) ((6971 : ℝ) / 6250000) ((112253 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((133460319 : ℝ) / 100000000)) ((-224079 : ℝ) / 100000000) ((-1739 : ℝ) / 1562500) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_89 {k A q d vp vm : ℝ}
    (hk : RB k ((13011 : ℝ) / 6400) ((3261 : ℝ) / 1600))
    (hA : RB A ((13011 : ℝ) / 19411) ((3261 : ℝ) / 4861))
    (hq : RB q ((1332271 : ℝ) / 50000000) ((2682463 : ℝ) / 100000000))
    (hd : RB d ((37937389 : ℝ) / 20000000) ((94876587 : ℝ) / 50000000))
    (hp : RB vp ((310769 : ℝ) / 800000) ((7823813 : ℝ) / 20000000))
    (hm : RB vm ((133311463 : ℝ) / 100000000) ((133460319 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((70997 : ℝ) / 100000000) ((71957 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99928043 : ℝ) / 100000000) ((99929003 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((16745193 : ℝ) / 25000000) ((33518667 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((181489 : ℝ) / 100000000) ((46309 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24953691 : ℝ) / 25000000) ((99818511 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((12176187 : ℝ) / 20000000) ((489231 : ℝ) / 800000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((60768161 : ℝ) / 100000000) ((7630361 : ℝ) / 12500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((27431849 : ℝ) / 25000000) ((110316543 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((2431849 : ℝ) / 25000000) ((10316543 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99928043 : ℝ) / 100000000) ((99929003 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((16745193 : ℝ) / 25000000) ((33518667 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((53197 : ℝ) / 100000000) ((53977 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99946023 : ℝ) / 100000000) ((99946803 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33311463 : ℝ) / 100000000) ((33460319 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((16646741 : ℝ) / 50000000) ((836063 : ℝ) / 2500000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((100143129 : ℝ) / 50000000) ((25169091 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((150143129 : ℝ) / 50000000) ((37669091 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((19386339 : ℝ) / 2000000) ((257006089 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((4147963 : ℝ) / 12500000) ((16650779 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((13011 : ℝ) / 3200) ((3261 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((10833861 : ℝ) / 100000000) ((1093439 : ℝ) / 10000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((51332271 : ℝ) / 50000000) ((102682463 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5275419 : ℝ) / 50000000) ((10650601 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((55275419 : ℝ) / 50000000) ((110650601 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((47096199 : ℝ) / 50000000) ((47307097 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((89335341 : ℝ) / 50000000) ((179533437 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((51786337 : ℝ) / 100000000) ((52208429 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((135987 : ℝ) / 100000000) ((2779 : ℝ) / 2000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((1997221 : ℝ) / 2000000) ((99864013 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((178422419 : ℝ) / 100000000) ((35857859 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((37937389 : ℝ) / 10000000) ((94876587 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((315893 : ℝ) / 3125000) ((5090059 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((19411 : ℝ) / 6400) ((4861 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((3327241 : ℝ) / 100000000) ((3356487 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1702841 : ℝ) / 25000000) ((1726339 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((26702841 : ℝ) / 25000000) ((26726339 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((207068131 : ℝ) / 20000000) ((549506549 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((399301 : ℝ) / 20000000) ((1006089 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20399301 : ℝ) / 20000000) ((51006089 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16923109 : ℝ) / 50000000) ((6794329 : ℝ) / 20000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1069186873 : ℝ) / 100000000) ((1132984743 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((4446803 : ℝ) / 12500000) ((19014243 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((19411 : ℝ) / 6400) ((4861 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((55275419 : ℝ) / 25000000) ((110650601 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((501250327 : ℝ) / 50000000) ((530662957 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2216545747 : ℝ) / 100000000) ((469745401 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((2582649 : ℝ) / 20000000) ((548263 : ℝ) / 4000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-204691669 : ℝ) / 100000000) ((-198729453 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1616.1 cov_log_1617.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((315893 : ℝ) / 6250000) ((5090059 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-74623331 : ℝ) / 25000000) ((-74447019 : ℝ) / 25000000) := rb_log h49 (by norm_num) cov_log_1618.1 cov_log_1619.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((32010243 : ℝ) / 50000000) ((64055397 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1605.1 cov_log_1606.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((130151647 : ℝ) / 100000000) ((130552907 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-168341677 : ℝ) / 100000000) ((-167235169 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((519219 : ℝ) / 12500000) ((5020629 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((5461369 : ℝ) / 50000000) ((1411303 : ℝ) / 10000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-157418939 : ℝ) / 100000000) ((-153122139 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((55275419 : ℝ) / 50000000) ((110650601 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-204691669 : ℝ) / 100000000) ((-198729453 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-157418939 : ℝ) / 100000000) ((-153122139 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((57 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1702841 : ℝ) / 25000000) ((1726339 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((26726339 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((57 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-21446151 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((57 : ℝ) / 20) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_34, cov_h_24]
  have hP : ((27170729 : ℝ) / 6250000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((153122139 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((153122139 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((316 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((316 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((321 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((321 : ℝ) / 125)) (lo := ((316 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((326 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((326 : ℝ) / 125)) (lo := ((321 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((331 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((331 : ℝ) / 125)) (lo := ((326 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((336 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((336 : ℝ) / 125)) (lo := ((331 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((341 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((341 : ℝ) / 125)) (lo := ((336 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((346 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((346 : ℝ) / 125)) (lo := ((341 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((351 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((351 : ℝ) / 125)) (lo := ((346 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((356 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((356 : ℝ) / 125)) (lo := ((351 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((57 : ℝ) / 20)) (lo := ((356 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_89 {k : ℝ} (hk : RB k ((13011 : ℝ) / 6400) ((3261 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((13011 : ℝ) / 19411) ((3261 : ℝ) / 4861) ∧
    RB (qa (r1A k)) ((1332271 : ℝ) / 50000000) ((2682463 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((37937389 : ℝ) / 20000000) ((94876587 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((25412109 : ℝ) / 50000000) ((3261 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((57487 : ℝ) / 32000) ((89887891 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((33508103 : ℝ) / 25000000) ((33520123 : ℝ) / 25000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((34431721 : ℝ) / 12500000) ((275501849 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((34431721 : ℝ) / 25000000) ((5510037 : ℝ) / 4000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((37937389 : ℝ) / 20000000) ((94876587 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((10112109 : ℝ) / 50000000) ((6513 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2528027 : ℝ) / 50000000) ((2544141 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1332271 : ℝ) / 50000000) ((2682463 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((37937389 : ℝ) / 20000000) ((94876587 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1332271 : ℝ) / 50000000) ((2682463 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((13011 : ℝ) / 19411) ((3261 : ℝ) / 4861) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_89 {k : ℝ} (hk : RB k ((13011 : ℝ) / 6400) ((3261 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_89 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_89 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((310769 : ℝ) / 800000)) (ph := ((7823813 : ℝ) / 20000000)) (ml := ((133311463 : ℝ) / 100000000)) (mh := ((133460319 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_89 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
