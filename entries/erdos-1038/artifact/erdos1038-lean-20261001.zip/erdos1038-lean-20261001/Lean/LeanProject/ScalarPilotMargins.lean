import LeanProject.ScalarIntervals

/-! A three-cell certificate for the scalar rectangle; all bounds are kernel proved. -/
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc

theorem scalar_log_R_bound : (6469 : ℝ) / 10000 ≤ Real.log (6283 / 3290) := by
  have h := log_series_lower (x := (6283 : ℝ) / 3290)
    (t := (2993 : ℝ) / 9573) (by norm_num) (by norm_num) (by norm_num) 6
  norm_num [sum_range_succ] at h
  linarith

theorem scalar_h_R_bound : (1 : ℝ) / 5 ≤ hfun (329 / 200) := by
  have hX : (0 : ℝ) < 329 / 200 := by norm_num
  have hπ : (329 : ℝ) / 200 ≤ π := by linarith [Real.pi_gt_d4]
  have ht := (AE_tail hX (n0 := 4) (by norm_num)).1
  have hs : (∑ n ∈ range 4, tq (329 / 200) n) ≤
      (1 + 1 / 8 + 1 / 27 + 1 / 64) / ((329 : ℝ) / 200) ^ 2 := by
    have h0 := Real.sin_sq_le_one ((1 : ℝ) * (329 / 200))
    have h1 := Real.sin_sq_le_one ((2 : ℝ) * (329 / 200))
    have h2 := Real.sin_sq_le_one ((3 : ℝ) * (329 / 200))
    have h3 := Real.sin_sq_le_one ((4 : ℝ) * (329 / 200))
    norm_num [sum_range_succ, tq, xs] at ht ⊢
    nlinarith
  have hl : Real.log ((329 : ℝ) / 200 / π) ≤ -6469 / 10000 := by
    have he : (6283 : ℝ) / 3290 ≤ π / (329 / 200) := by
      norm_num
      linarith [Real.pi_gt_d4]
    have h := scalar_log_R_bound.trans (Real.log_le_log (by norm_num) he)
    rw [Real.log_div hX.ne' Real.pi_pos.ne']
    rw [Real.log_div Real.pi_pos.ne' hX.ne'] at h
    linarith
  unfold hfun
  norm_num at ht hs
  linarith

theorem scalar_sinc_R_bound : (3 : ℝ) / 5 ≤ EP1038.Arc.sinc (329 / 200) := by
  have hlo : (0 : ℝ) ≤ 329 / 200 - π / 2 := by linarith [Real.pi_lt_d4]
  have hhi : (329 : ℝ) / 200 - π / 2 ≤ 3 / 40 := by linarith [Real.pi_gt_d4]
  have hs : ((329 : ℝ) / 200 - π / 2) ^ 2 ≤ (3 / 40) ^ 2 := by nlinarith
  have hc := Real.one_sub_sq_div_two_le_cos (x := (329 : ℝ) / 200 - π / 2)
  have he : Real.cos ((329 : ℝ) / 200 - π / 2) = Real.sin (329 / 200) := by
    rw [Real.cos_sub, Real.cos_pi_div_two, Real.sin_pi_div_two]
    ring
  rw [he] at hc
  unfold EP1038.Arc.sinc
  norm_num
  nlinarith

theorem scalar_sinc_upper {x : ℝ} (hx : 0 < x) (hxπ : x ≤ π) :
    EP1038.Arc.sinc x ≤ (22 / 7 - x) / x := by
  have h := Real.sin_le (sub_nonneg.mpr hxπ)
  rw [Real.sin_pi_sub] at h
  unfold EP1038.Arc.sinc
  apply (div_le_div_iff_of_pos_right hx).mpr
  linarith [Real.pi_lt_d4]

theorem scalar_three_cells {c0 Ceff api Qm Rm : ℝ}
    (ha : 0 < api) (hQπ : Qm ≤ π) (hRπ : Rm ≤ π)
    (hQhi : Qm ≤ 59 / 20) (hRhi : Rm ≤ 329 / 200)
    (hB : -(207 : ℝ) / 100 ≤ c0 + hfun Qm + hfun Rm)
    (hP : (547 : ℝ) / 100 ≤ -(π * Ceff / api))
    {Q V : ℝ} (hQ : 0 < Q) (hQQ : Q ≤ Qm) (hV : 0 < V) (hVV : V ≤ Rm) :
    (1 : ℝ) / 100 < rhs c0 Ceff api Q V := by
  let B := c0 + hfun Qm + hfun Rm
  let P := -(π * Ceff / api)
  have hP0 : 0 ≤ P := by dsimp [P]; linarith
  have hL := rhs_ge_Lam (c0 := c0) (Ceff := Ceff) ha hQπ hRπ hQ hQQ hV hVV
  have hRm0 : 0 < Rm := hV.trans_le hVV
  have hsR : (3 : ℝ) / 5 ≤ EP1038.Arc.sinc Rm :=
    scalar_sinc_R_bound.trans (sinc_anti hRm0 hRhi (by linarith [Real.pi_gt_d4]))
  have hQpi := hQQ.trans hQπ
  rcases le_or_gt Q (13 / 5) with hfirst | hfirst
  · have hp := div_le_div_of_nonneg_left hP0 hQ hfirst
    have hc := Lam_case1 (B := B) (P := P) (R := V) hP0 hQ hfirst
    have hm : (1 : ℝ) / 100 < B + P / (13 / 5) := by
      dsimp [B, P] at *
      norm_num at *
      linarith
    exact (hm.trans_le hc).trans_le hL
  · rcases le_or_gt Q (14 / 5) with hsecond | hsecond
    · have hsU := scalar_sinc_upper (x := (13 : ℝ) / 5) (by norm_num)
        (by linarith [Real.pi_gt_d4])
      have hdiff : (3 / 5 - ((22 / 7 - 13 / 5) / (13 / 5))) ^ 2 ≤
          (EP1038.Arc.sinc Rm - EP1038.Arc.sinc (13 / 5)) ^ 2 := by
        norm_num at *
        nlinarith [sq_nonneg (EP1038.Arc.sinc Rm - EP1038.Arc.sinc (13 / 5) -
          (3 / 5 - ((22 / 7 - 13 / 5) / (13 / 5))))]
      have hc := Lam_case2 (B := B) (P := P) hP0 hV hVV
        (show Rm ≤ (13 : ℝ) / 5 by linarith) hfirst.le hsecond hQpi
      have hm : (1 : ℝ) / 100 < B + P / (14 / 5) +
          (EP1038.Arc.sinc Rm - EP1038.Arc.sinc (13 / 5)) ^ 2 := by
        dsimp [B, P] at *
        norm_num at *
        linarith
      exact (hm.trans_le hc).trans_le hL
    · have hsU := scalar_sinc_upper (x := (14 : ℝ) / 5) (by norm_num)
        (by linarith [Real.pi_gt_d4])
      have hdiff : (3 / 5 - ((22 / 7 - 14 / 5) / (14 / 5))) ^ 2 ≤
          (EP1038.Arc.sinc Rm - EP1038.Arc.sinc (14 / 5)) ^ 2 := by
        norm_num at *
        nlinarith [sq_nonneg (EP1038.Arc.sinc Rm - EP1038.Arc.sinc (14 / 5) -
          (3 / 5 - ((22 / 7 - 14 / 5) / (14 / 5))))]
      have hc := Lam_case2 (B := B) (P := P) hP0 hV hVV
        (show Rm ≤ (14 : ℝ) / 5 by linarith) hsecond.le (hQQ.trans hQhi) hQpi
      have hm : (1 : ℝ) / 100 < B + P / (59 / 20) +
          (EP1038.Arc.sinc Rm - EP1038.Arc.sinc (14 / 5)) ^ 2 := by
        dsimp [B, P] at *
        norm_num at *
        linarith
      exact (hm.trans_le hc).trans_le hL

end EP1038.ReferenceCert
