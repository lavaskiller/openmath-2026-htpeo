import LeanProject.Stage8Full
import LeanProject.Stage10ComponentBridge

/-!
# Polynomial contracts and the actual atomic normal form (S01--S04)

This module packages the existing root-vector reductions for an arbitrary polynomial.
`NormalData` keeps multiplicities, the main component boundary, and the residual-radius
measure comparison. The coordinates used by the potential are `s i - s main`, with main
atom at zero; the equivalent admissible polynomial has roots `s i - s main - 1`.
-/

open Real Set MeasureTheory Finset Polynomial
open scoped ENNReal

namespace EP1038

/-- The positive-degree polynomial class in the problem, with all roots real in `[-1,1]`. -/
def Admissible (p : ℝ[X]) : Prop :=
  p.Monic ∧ 1 ≤ p.natDegree ∧ Multiset.card p.roots = p.natDegree ∧
    ∀ x ∈ p.roots, x ∈ Icc (-1 : ℝ) 1

/-- The strict polynomial sublevel measure, retaining `ENNReal` until finiteness is proved. -/
noncomputable def sublevelMeasure (p : ℝ[X]) : ℝ≥0∞ :=
  volume {x : ℝ | |p.eval x| < 1}

theorem admissible_measure_finite {p : ℝ[X]} (hp : Admissible p) :
    sublevelMeasure p ≠ ⊤ := by
  have h := (sup_theorem p hp.1 hp.2.1 hp.2.2.1 hp.2.2.2).1
  exact ne_top_of_le_ne_top ENNReal.ofReal_ne_top h

theorem polynomial_root_vector {p : ℝ[X]} (hp : Admissible p) :
    ∃ n : ℕ, ∃ r : Fin n → ℝ, 0 < n ∧ (∀ i, r i ∈ Icc (-1 : ℝ) 1) ∧
      {x : ℝ | |p.eval x| < 1} = sublevel r := by
  let l := p.roots.toList
  let r : Fin l.length → ℝ := fun i => l[i.1]
  have hlen : l.length = p.natDegree := by
    simp only [l, Multiset.length_toList, hp.2.2.1]
  have hdegree := hp.2.1
  refine ⟨l.length, r, by omega, ?_, ?_⟩
  · intro i
    apply hp.2.2.2
    rw [← Multiset.mem_toList]
    exact List.getElem_mem _
  · ext x
    simp only [Set.mem_ofPred_eq, sublevel]
    rw [eval_eq_prod p hp.1 hp.2.2.1 x]

theorem root_vector_polynomial {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Icc (-1 : ℝ) 1) :
    ∃ p : ℝ[X], Admissible p ∧ {x : ℝ | |p.eval x| < 1} = sublevel r := by
  obtain ⟨h1, h2, h3, h4, h5⟩ := Stage7.bridge_vec hn r hr
  exact ⟨_, ⟨h1, h2, h3, h4⟩, h5⟩

/-- The attainable polynomial measures are exactly the positive-degree root-vector measures. -/
theorem attainable_measures_eq :
    {m : ℝ≥0∞ | ∃ p : ℝ[X], Admissible p ∧ sublevelMeasure p = m} =
      {m : ℝ≥0∞ | ∃ n : ℕ, ∃ r : Fin n → ℝ,
        0 < n ∧ (∀ i, r i ∈ Icc (-1 : ℝ) 1) ∧ volume (sublevel r) = m} := by
  ext m
  constructor
  · rintro ⟨p, hp, hm⟩
    obtain ⟨n, r, hn, hr, hset⟩ := polynomial_root_vector hp
    exact ⟨n, r, hn, hr, by simpa only [sublevelMeasure, hset] using hm⟩
  · rintro ⟨n, r, hn, hr, hm⟩
    obtain ⟨p, hp, hset⟩ := root_vector_polynomial hn r hr
    exact ⟨p, hp, by simpa only [sublevelMeasure, hset] using hm⟩

namespace NormalForm

/-- A component-atomized, oriented configuration with its actual main boundary and widths. -/
structure NormalData (n : ℕ) where
  positive_degree : 0 < n
  roots : Fin n → ℝ
  roots_mem : ∀ i, roots i ∈ Icc (-1 : ℝ) 1
  sum_nonpos : ∑ i, roots i ≤ 0
  clustered : ∀ i j, uIcc (roots i) (roots j) ⊆ sublevel roots → roots i = roots j
  main : Fin n
  least : ∀ i, roots main ≤ roots i
  boundary : ℝ
  boundary_ge : roots main + 1 ≤ boundary
  boundary_out : boundary ∉ sublevel roots
  boundary_product : |∏ i, (boundary - roots i)| = 1
  residual_after : ∀ i, roots i ≠ roots main → boundary < roots i
  main_interval : ∀ y, roots main ≤ y → y < boundary → y ∈ sublevel roots
  half_mass : (univ.filter (fun i => roots i ≠ roots main)).card ≤
    (univ.filter (fun i => roots i = roots main)).card
  width_bound : ENNReal.ofReal ((Resid.rhoR roots (roots main) - Resid.ellL roots (roots main)) +
    2 * ∑ v ∈ (univ.filter (fun i => roots i ≠ roots main)).image roots, Stage7.Rv roots v) ≤
    volume (sublevel roots)

namespace NormalData

noncomputable def mainCount {n : ℕ} (a : NormalData n) : ℕ :=
  (univ.filter (fun i => a.roots i = a.roots a.main)).card

noncomputable def residualIndices {n : ℕ} (a : NormalData n) : Finset (Fin n) :=
  univ.filter (fun i => a.roots i ≠ a.roots a.main)

noncomputable def residualCount {n : ℕ} (a : NormalData n) : ℕ := a.residualIndices.card

noncomputable def k {n : ℕ} (a : NormalData n) : ℝ := a.mainCount / a.residualCount

noncomputable def J {n : ℕ} (a : NormalData n) : ℝ :=
  (Resid.rhoR a.roots (a.roots a.main) - Resid.ellL a.roots (a.roots a.main)) +
    2 * ∑ v ∈ a.residualIndices.image a.roots, Stage7.Rv a.roots v

def shiftedRoots {n : ℕ} (a : NormalData n) (i : Fin n) : ℝ :=
  a.roots i - a.roots a.main - 1

def locations {n : ℕ} (a : NormalData n) (i : Fin n) : ℝ :=
  a.roots i - a.roots a.main

def separator {n : ℕ} (a : NormalData n) : ℝ := a.boundary - a.roots a.main

end NormalData

open NormalData

theorem normal_data_of_clustered {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ)
    (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1) (hsum : ∑ i, s i ≤ 0)
    (hcl : ∀ i j, uIcc (s i) (s j) ⊆ sublevel s → s i = s j) :
    ∃ a : NormalData n, a.roots = s := by
  classical
  obtain ⟨i0, r0, -, -, hmin, hge, hout, hprod, hother, hbelow, hhalf⟩ :=
    Resid.setup hn s hs hsum hcl
  obtain ⟨j0, hjmin, -, -, -, hwidth⟩ := Stage7.lemma75 hn s hs hsum hcl
  have heq : s j0 = s i0 := le_antisymm (hmin j0) (hjmin i0) |>.symm
  rw [heq] at hwidth
  exact ⟨⟨hn, s, hs, hsum, hcl, i0, hmin, r0, hge, hout, hprod, hother, hbelow,
    hhalf, hwidth⟩, rfl⟩

/-- Atomization and reflection produce one actual normal-form witness and a measure comparison. -/
theorem root_vector_normal_form {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Icc (-1 : ℝ) 1) :
    ∃ a : NormalData n, volume (sublevel a.roots) ≤ volume (sublevel r) := by
  classical
  have oriented : ∀ t : Fin n → ℝ, (∀ i, t i ∈ Icc (-1 : ℝ) 1) →
      ∑ i, t i ≤ 0 → ∃ a : NormalData n, volume (sublevel a.roots) ≤ volume (sublevel t) := by
    intro t ht hsum
    obtain ⟨s, hroots⟩ := normal_data_of_clustered hn (Atom.cmean t)
      (Atom.cmean_mem_Icc t ht) (by rw [Atom.sum_cmean]; exact hsum)
      (fun i j h => Atom.cmean_eq_of_uIcc t h)
    refine ⟨s, ?_⟩
    rw [hroots]
    exact measure_mono (Atom.sublevel_cmean_subset t)
  rcases le_total (∑ i, r i) 0 with hsum | hsum
  · exact oriented r hr hsum
  · obtain ⟨a, ha⟩ := oriented (fun i => -r i)
      (fun i => ⟨by linarith [(hr i).2], by linarith [(hr i).1]⟩)
      (by simp only [sum_neg_distrib]; linarith)
    exact ⟨a, by simpa only [volume_sublevel_neg] using ha⟩

theorem polynomial_normal_form {p : ℝ[X]} (hp : Admissible p) :
    ∃ n : ℕ, ∃ a : NormalData n, volume (sublevel a.roots) ≤ sublevelMeasure p := by
  obtain ⟨n, r, hn, hr, hset⟩ := polynomial_root_vector hp
  obtain ⟨a, ha⟩ := root_vector_normal_form hn r hr
  exact ⟨n, a, by simpa only [sublevelMeasure, hset] using ha⟩

theorem mainCount_pos {n : ℕ} (a : NormalData n) : 0 < a.mainCount := by
  classical
  apply Finset.card_pos.mpr
  exact ⟨a.main, by simp⟩

theorem count_add {n : ℕ} (a : NormalData n) : a.mainCount + a.residualCount = n := by
  classical
  simpa only [mainCount, residualCount, residualIndices, card_univ, Fintype.card_fin] using
    card_filter_add_card_filter_not (s := (univ : Finset (Fin n)))
      (fun i => a.roots i = a.roots a.main)

theorem one_le_k {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) : 1 ≤ a.k := by
  have hb : (0 : ℝ) < a.residualCount := by exact_mod_cast hres
  have hhalf : (a.residualCount : ℝ) ≤ a.mainCount := by exact_mod_cast a.half_mass
  exact (one_le_div hb).mpr hhalf

theorem shiftedRoots_mem {n : ℕ} (a : NormalData n) (i : Fin n) :
    a.shiftedRoots i ∈ Icc (-1 : ℝ) 1 := by
  exact ⟨by dsimp [shiftedRoots]; linarith [a.least i],
    by dsimp [shiftedRoots]; linarith [(a.roots_mem i).2, (a.roots_mem a.main).1]⟩

theorem shifted_main {n : ℕ} (a : NormalData n) : a.shiftedRoots a.main = -1 := by
  simp [shiftedRoots]

theorem shifted_volume {n : ℕ} (a : NormalData n) :
    volume (sublevel a.shiftedRoots) = volume (sublevel a.roots) := by
  have h : a.shiftedRoots = fun i => a.roots i + -(a.roots a.main + 1) := by
    funext i; dsimp [shiftedRoots]; ring
  rw [h, volume_sublevel_translate]

theorem shifted_sum_nonpos {n : ℕ} (a : NormalData n) : ∑ i, a.shiftedRoots i ≤ 0 := by
  apply le_trans (Finset.sum_le_sum (fun i _ => ?_)) a.sum_nonpos
  dsimp [shiftedRoots]
  linarith [(a.roots_mem a.main).1]

/-- The normalized vector is again the root vector of an admissible polynomial,
with main root `-1` and the same measure as the atomized configuration. -/
theorem normal_form_polynomial {n : ℕ} (a : NormalData n) :
    ∃ q : ℝ[X], Admissible q ∧
      {x : ℝ | |q.eval x| < 1} = sublevel a.shiftedRoots ∧
      sublevelMeasure q = volume (sublevel a.roots) := by
  obtain ⟨q, hq, hset⟩ := root_vector_polynomial a.positive_degree a.shiftedRoots
    (shiftedRoots_mem a)
  refine ⟨q, hq, hset, ?_⟩
  rw [sublevelMeasure, hset, shifted_volume]

theorem separator_ge_one {n : ℕ} (a : NormalData n) : 1 ≤ a.separator := by
  dsimp [separator]; linarith [a.boundary_ge]

theorem residual_location_bounds {n : ℕ} (a : NormalData n) {i : Fin n}
    (hi : i ∈ a.residualIndices) : a.separator < a.locations i ∧ a.locations i ≤ 2 := by
  classical
  have hne := (Finset.mem_filter.mp hi).2
  exact ⟨by dsimp [separator, locations]; linarith [a.residual_after i hne],
    by dsimp [locations]; linarith [(a.roots_mem i).2, (a.roots_mem a.main).1]⟩

theorem single_atom_measure {n : ℕ} (a : NormalData n) (hres : a.residualCount = 0) :
    volume (sublevel a.roots) = ENNReal.ofReal 2 := by
  classical
  have hempty : a.residualIndices = ∅ := Finset.card_eq_zero.mp hres
  have hall : ∀ i, a.roots i = a.roots a.main := by
    intro i
    by_contra h
    have hi : i ∈ a.residualIndices := by simp [residualIndices, h]
    rw [hempty] at hi
    simp at hi
  have heq : a.roots = fun _ => a.roots a.main := funext hall
  rw [heq, Stage7.sublevel_const a.positive_degree, Real.volume_Ioo]
  congr 1; ring

/-- The complete initial case split, with no assumed normal-form data. -/
theorem polynomial_normal_form_cases {p : ℝ[X]} (hp : Admissible p) :
    ENNReal.ofReal 2 ≤ sublevelMeasure p ∨
      ∃ n : ℕ, ∃ a : NormalData n,
        0 < a.residualCount ∧ 1 ≤ a.k ∧
        volume (sublevel a.roots) ≤ sublevelMeasure p ∧
        ENNReal.ofReal a.J ≤ sublevelMeasure p := by
  obtain ⟨n, a, ha⟩ := polynomial_normal_form hp
  rcases Nat.eq_zero_or_pos a.residualCount with hzero | hpos
  · exact Or.inl (by simpa only [single_atom_measure a hzero] using ha)
  · exact Or.inr ⟨n, a, hpos, one_le_k a hpos, ha, a.width_bound.trans ha⟩

end NormalForm
end EP1038
