import LeanProject.COVLogTwo
import LeanProject.COVLogBounds03
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_560 : RB (Real.log ((21190047 : ℝ) / 50000000)) ((-85849143 : ℝ) / 100000000) ((-85849141 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((21190047 : ℝ) / 25000000)) (t := ((-3809953 : ℝ) / 46190047))
    (lo := ((-2066803 : ℝ) / 12500000)) (hi := ((-16534423 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21190047 : ℝ) / 50000000) = Real.log ((21190047 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21190047 : ℝ) / 50000000) = ((21190047 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_561 : RB (Real.log ((48867339 : ℝ) / 25000000)) ((67023343 : ℝ) / 100000000) ((13404669 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((48867339 : ℝ) / 50000000)) (t := ((-1132661 : ℝ) / 98867339))
    (lo := ((-18331 : ℝ) / 800000)) (hi := ((-1145687 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48867339 : ℝ) / 25000000) = Real.log ((48867339 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48867339 : ℝ) / 25000000) = ((48867339 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_562 : RB (Real.log ((97767281 : ℝ) / 50000000)) ((8382087 : ℝ) / 12500000) ((33528349 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((97767281 : ℝ) / 100000000)) (t := ((-2232719 : ℝ) / 197767281))
    (lo := ((-1129011 : ℝ) / 50000000)) (hi := ((-2258021 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97767281 : ℝ) / 50000000) = Real.log ((97767281 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97767281 : ℝ) / 50000000) = ((97767281 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_563 : RB (Real.log ((37364967 : ℝ) / 50000000)) ((-14564473 : ℝ) / 50000000) ((-5825789 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((37364967 : ℝ) / 50000000)) (t := ((-12635033 : ℝ) / 87364967))
    (lo := ((-14564473 : ℝ) / 50000000)) (hi := ((-5825789 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_564 : RB (Real.log ((74730611 : ℝ) / 100000000)) ((-728201 : ℝ) / 2500000) ((-29128039 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74730611 : ℝ) / 100000000)) (t := ((-25269389 : ℝ) / 174730611))
    (lo := ((-728201 : ℝ) / 2500000)) (hi := ((-29128039 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_565 : RB (Real.log ((42776421 : ℝ) / 100000000)) ((-21229579 : ℝ) / 25000000) ((-42459157 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42776421 : ℝ) / 50000000)) (t := ((-7223579 : ℝ) / 92776421))
    (lo := ((-15603597 : ℝ) / 100000000)) (hi := ((-3900899 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42776421 : ℝ) / 100000000) = Real.log ((42776421 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42776421 : ℝ) / 100000000) = ((42776421 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_566 : RB (Real.log ((4512163 : ℝ) / 1000000)) ((150677663 : ℝ) / 100000000) ((75338833 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4512163 : ℝ) / 4000000)) (t := ((512163 : ℝ) / 8512163))
    (lo := ((12048227 : ℝ) / 100000000)) (hi := ((3012057 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4512163 : ℝ) / 1000000) = Real.log ((4512163 : ℝ) / 4000000) + 2 * Real.log 2 := by
    rw [show ((4512163 : ℝ) / 1000000) = ((4512163 : ℝ) / 4000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_567 : RB (Real.log ((451217661 : ℝ) / 100000000)) ((30135593 : ℝ) / 20000000) ((9417373 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((451217661 : ℝ) / 400000000)) (t := ((51217661 : ℝ) / 851217661))
    (lo := ((12048529 : ℝ) / 100000000)) (hi := ((1204853 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((451217661 : ℝ) / 100000000) = Real.log ((451217661 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((451217661 : ℝ) / 100000000) = ((451217661 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_568 : RB (Real.log ((64234351 : ℝ) / 50000000)) ((3131439 : ℝ) / 12500000) ((25051513 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64234351 : ℝ) / 50000000)) (t := ((14234351 : ℝ) / 114234351))
    (lo := ((3131439 : ℝ) / 12500000)) (hi := ((25051513 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_569 : RB (Real.log ((112242151 : ℝ) / 25000000)) ((150178277 : ℝ) / 100000000) ((3754457 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((112242151 : ℝ) / 100000000)) (t := ((12242151 : ℝ) / 212242151))
    (lo := ((11548841 : ℝ) / 100000000)) (hi := ((5774421 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112242151 : ℝ) / 25000000) = Real.log ((112242151 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((112242151 : ℝ) / 25000000) = ((112242151 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_570 : RB (Real.log ((112242489 : ℝ) / 25000000)) ((75089289 : ℝ) / 50000000) ((150178581 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((112242489 : ℝ) / 100000000)) (t := ((12242489 : ℝ) / 212242489))
    (lo := ((5774571 : ℝ) / 50000000)) (hi := ((11549143 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112242489 : ℝ) / 25000000) = Real.log ((112242489 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((112242489 : ℝ) / 25000000) = ((112242489 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_571 : RB (Real.log ((32163017 : ℝ) / 25000000)) ((12597071 : ℝ) / 50000000) ((25194143 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32163017 : ℝ) / 25000000)) (t := ((7163017 : ℝ) / 57163017))
    (lo := ((12597071 : ℝ) / 50000000)) (hi := ((25194143 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_572 : RB (Real.log ((95801 : ℝ) / 1250000)) ((-10274503 : ℝ) / 4000000) ((-25686257 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((95801 : ℝ) / 78125)) (t := ((8838 : ℝ) / 86963))
    (lo := ((20396301 : ℝ) / 100000000)) (hi := ((10198151 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95801 : ℝ) / 1250000) = Real.log ((95801 : ℝ) / 78125) - 4 * Real.log 2 := by
    rw [show ((95801 : ℝ) / 1250000) = ((95801 : ℝ) / 78125) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_573 : RB (Real.log ((8729499 : ℝ) / 100000000)) ((-15240389 : ℝ) / 6250000) ((-12192311 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((8729499 : ℝ) / 12500000)) (t := ((-3770501 : ℝ) / 21229499))
    (lo := ((-35902067 : ℝ) / 100000000)) (hi := ((-17951033 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8729499 : ℝ) / 100000000) = Real.log ((8729499 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8729499 : ℝ) / 100000000) = ((8729499 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_574 : RB (Real.log ((1109687 : ℝ) / 50000000)) ((-190397253 : ℝ) / 50000000) ((-761589 : ℝ) / 200000) := by
  have hm := log_bounds_of_series (x := ((1109687 : ℝ) / 1562500)) (t := ((-452813 : ℝ) / 2672187))
    (lo := ((-34220911 : ℝ) / 100000000)) (hi := ((-3422091 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1109687 : ℝ) / 50000000) = Real.log ((1109687 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1109687 : ℝ) / 50000000) = ((1109687 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_575 : RB (Real.log ((281637 : ℝ) / 12500000)) ((-379286497 : ℝ) / 100000000) ((-379286491 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((281637 : ℝ) / 390625)) (t := ((-54494 : ℝ) / 336131))
    (lo := ((-16356451 : ℝ) / 50000000)) (hi := ((-32712901 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((281637 : ℝ) / 12500000) = Real.log ((281637 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((281637 : ℝ) / 12500000) = ((281637 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_576 : RB (Real.log ((18338373 : ℝ) / 25000000)) ((-3873501 : ℝ) / 12500000) ((-30988007 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((18338373 : ℝ) / 25000000)) (t := ((-6661627 : ℝ) / 43338373))
    (lo := ((-3873501 : ℝ) / 12500000)) (hi := ((-30988007 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_577 : RB (Real.log ((2934167 : ℝ) / 4000000)) ((-30987077 : ℝ) / 100000000) ((-7746769 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2934167 : ℝ) / 4000000)) (t := ((-1065833 : ℝ) / 6934167))
    (lo := ((-30987077 : ℝ) / 100000000)) (hi := ((-7746769 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_578 : RB (Real.log ((42322287 : ℝ) / 100000000)) ((-85985637 : ℝ) / 100000000) ((-17197127 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((42322287 : ℝ) / 50000000)) (t := ((-7677713 : ℝ) / 92322287))
    (lo := ((-8335459 : ℝ) / 50000000)) (hi := ((-16670917 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42322287 : ℝ) / 100000000) = Real.log ((42322287 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42322287 : ℝ) / 100000000) = ((42322287 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_579 : RB (Real.log ((39080829 : ℝ) / 20000000)) ((8373747 : ℝ) / 12500000) ((33494989 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39080829 : ℝ) / 40000000)) (t := ((-919171 : ℝ) / 79080829))
    (lo := ((-1162371 : ℝ) / 50000000)) (hi := ((-2324741 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39080829 : ℝ) / 20000000) = Real.log ((39080829 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39080829 : ℝ) / 20000000) = ((39080829 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_580 : RB (Real.log ((195469363 : ℝ) / 100000000)) ((33511673 : ℝ) / 50000000) ((16755837 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((195469363 : ℝ) / 200000000)) (t := ((-4530637 : ℝ) / 395469363))
    (lo := ((-572843 : ℝ) / 25000000)) (hi := ((-2291371 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195469363 : ℝ) / 100000000) = Real.log ((195469363 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195469363 : ℝ) / 100000000) = ((195469363 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_581 : RB (Real.log ((74535603 : ℝ) / 100000000)) ((-29389329 : ℝ) / 100000000) ((-1836833 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((74535603 : ℝ) / 100000000)) (t := ((-25464397 : ℝ) / 174535603))
    (lo := ((-29389329 : ℝ) / 100000000)) (hi := ((-1836833 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_582 : RB (Real.log ((7453629 : ℝ) / 10000000)) ((-29388407 : ℝ) / 100000000) ((-14694203 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((7453629 : ℝ) / 10000000)) (t := ((-2546371 : ℝ) / 17453629))
    (lo := ((-29388407 : ℝ) / 100000000)) (hi := ((-14694203 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_583 : RB (Real.log ((10678233 : ℝ) / 25000000)) ((-85066847 : ℝ) / 100000000) ((-17013369 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((10678233 : ℝ) / 12500000)) (t := ((-1821767 : ℝ) / 23178233))
    (lo := ((-246127 : ℝ) / 1562500)) (hi := ((-15752127 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10678233 : ℝ) / 25000000) = Real.log ((10678233 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10678233 : ℝ) / 25000000) = ((10678233 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_584 : RB (Real.log ((112615099 : ℝ) / 25000000)) ((150509997 : ℝ) / 100000000) ((15051 : ℝ) / 10000) := by
  have hm := log_bounds_of_series (x := ((112615099 : ℝ) / 100000000)) (t := ((12615099 : ℝ) / 212615099))
    (lo := ((11880561 : ℝ) / 100000000)) (hi := ((5940281 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112615099 : ℝ) / 25000000) = Real.log ((112615099 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((112615099 : ℝ) / 25000000) = ((112615099 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_585 : RB (Real.log ((225230887 : ℝ) / 50000000)) ((150510303 : ℝ) / 100000000) ((75255153 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((225230887 : ℝ) / 200000000)) (t := ((25230887 : ℝ) / 425230887))
    (lo := ((11880867 : ℝ) / 100000000)) (hi := ((2970217 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((225230887 : ℝ) / 50000000) = Real.log ((225230887 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((225230887 : ℝ) / 50000000) = ((225230887 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_586 : RB (Real.log ((64264997 : ℝ) / 50000000)) ((2509921 : ℝ) / 10000000) ((25099211 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64264997 : ℝ) / 50000000)) (t := ((14264997 : ℝ) / 114264997))
    (lo := ((2509921 : ℝ) / 10000000)) (hi := ((25099211 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_587 : RB (Real.log ((448228523 : ℝ) / 100000000)) ((150013301 : ℝ) / 100000000) ((18751663 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((448228523 : ℝ) / 400000000)) (t := ((48228523 : ℝ) / 848228523))
    (lo := ((2276773 : ℝ) / 20000000)) (hi := ((5691933 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((448228523 : ℝ) / 100000000) = Real.log ((448228523 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((448228523 : ℝ) / 100000000) = ((448228523 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_588 : RB (Real.log ((112057473 : ℝ) / 25000000)) ((75006803 : ℝ) / 50000000) ((150013609 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((112057473 : ℝ) / 100000000)) (t := ((12057473 : ℝ) / 212057473))
    (lo := ((1138417 : ℝ) / 10000000)) (hi := ((11384171 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112057473 : ℝ) / 25000000) = Real.log ((112057473 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((112057473 : ℝ) / 25000000) = ((112057473 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_589 : RB (Real.log ((128712849 : ℝ) / 100000000)) ((788793 : ℝ) / 3125000) ((25241377 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((128712849 : ℝ) / 100000000)) (t := ((28712849 : ℝ) / 228712849))
    (lo := ((788793 : ℝ) / 3125000)) (hi := ((25241377 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_590 : RB (Real.log ((7708353 : ℝ) / 100000000)) ((-32035821 : ℝ) / 12500000) ((-256286563 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7708353 : ℝ) / 6250000)) (t := ((1458353 : ℝ) / 13958353))
    (lo := ((5243077 : ℝ) / 25000000)) (hi := ((20972309 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7708353 : ℝ) / 100000000) = Real.log ((7708353 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7708353 : ℝ) / 100000000) = ((7708353 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_591 : RB (Real.log ((876099 : ℝ) / 10000000)) ((-243486131 : ℝ) / 100000000) ((-243486127 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((876099 : ℝ) / 1250000)) (t := ((-373901 : ℝ) / 2126099))
    (lo := ((-17770987 : ℝ) / 50000000)) (hi := ((-35541973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((876099 : ℝ) / 10000000) = Real.log ((876099 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((876099 : ℝ) / 10000000) = ((876099 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_592 : RB (Real.log ((2251591 : ℝ) / 100000000)) ((-94838329 : ℝ) / 25000000) ((-37935331 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((2251591 : ℝ) / 3125000)) (t := ((-873409 : ℝ) / 5376591))
    (lo := ((-32779721 : ℝ) / 100000000)) (hi := ((-819493 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2251591 : ℝ) / 100000000) = Real.log ((2251591 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2251591 : ℝ) / 100000000) = ((2251591 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_593 : RB (Real.log ((1142667 : ℝ) / 50000000)) ((-75573161 : ℝ) / 20000000) ((-377865799 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1142667 : ℝ) / 1562500)) (t := ((-419833 : ℝ) / 2705167))
    (lo := ((-3129221 : ℝ) / 10000000)) (hi := ((-31292209 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1142667 : ℝ) / 50000000) = Real.log ((1142667 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1142667 : ℝ) / 50000000) = ((1142667 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_594 : RB (Real.log ((14636323 : ℝ) / 20000000)) ((-7805649 : ℝ) / 25000000) ((-6244519 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((14636323 : ℝ) / 20000000)) (t := ((-5363677 : ℝ) / 34636323))
    (lo := ((-7805649 : ℝ) / 25000000)) (hi := ((-6244519 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_595 : RB (Real.log ((14636461 : ℝ) / 20000000)) ((-31221653 : ℝ) / 100000000) ((-7805413 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((14636461 : ℝ) / 20000000)) (t := ((-5363539 : ℝ) / 34636461))
    (lo := ((-31221653 : ℝ) / 100000000)) (hi := ((-7805413 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_596 : RB (Real.log ((42265273 : ℝ) / 100000000)) ((-43060221 : ℝ) / 50000000) ((-2153011 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((42265273 : ℝ) / 50000000)) (t := ((-7734727 : ℝ) / 92265273))
    (lo := ((-16805723 : ℝ) / 100000000)) (hi := ((-8402861 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42265273 : ℝ) / 100000000) = Real.log ((42265273 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42265273 : ℝ) / 100000000) = ((42265273 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_597 : RB (Real.log ((97669463 : ℝ) / 50000000)) ((33478297 : ℝ) / 50000000) ((16739149 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((97669463 : ℝ) / 100000000)) (t := ((-2330537 : ℝ) / 197669463))
    (lo := ((-589531 : ℝ) / 25000000)) (hi := ((-2358123 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97669463 : ℝ) / 50000000) = Real.log ((97669463 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97669463 : ℝ) / 50000000) = ((97669463 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_598 : RB (Real.log ((24425519 : ℝ) / 12500000)) ((3349499 : ℝ) / 5000000) ((33494991 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((24425519 : ℝ) / 25000000)) (t := ((-574481 : ℝ) / 49425519))
    (lo := ((-1162369 : ℝ) / 50000000)) (hi := ((-2324737 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24425519 : ℝ) / 12500000) = Real.log ((24425519 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((24425519 : ℝ) / 12500000) = ((24425519 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_599 : RB (Real.log ((3717227 : ℝ) / 5000000)) ((-7411499 : ℝ) / 25000000) ((-5929199 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3717227 : ℝ) / 5000000)) (t := ((-1282773 : ℝ) / 8717227))
    (lo := ((-7411499 : ℝ) / 25000000)) (hi := ((-5929199 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_600 : RB (Real.log ((14869047 : ℝ) / 20000000)) ((-29645061 : ℝ) / 100000000) ((-1482253 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((14869047 : ℝ) / 20000000)) (t := ((-5130953 : ℝ) / 34869047))
    (lo := ((-29645061 : ℝ) / 100000000)) (hi := ((-1482253 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_601 : RB (Real.log ((42650379 : ℝ) / 100000000)) ((-21303351 : ℝ) / 25000000) ((-42606701 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42650379 : ℝ) / 50000000)) (t := ((-7349621 : ℝ) / 92650379))
    (lo := ((-3179737 : ℝ) / 20000000)) (hi := ((-3974671 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42650379 : ℝ) / 100000000) = Real.log ((42650379 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42650379 : ℝ) / 100000000) = ((42650379 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_602 : RB (Real.log ((224854903 : ℝ) / 50000000)) ((150343231 : ℝ) / 100000000) ((75171617 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((224854903 : ℝ) / 200000000)) (t := ((24854903 : ℝ) / 424854903))
    (lo := ((2342759 : ℝ) / 20000000)) (hi := ((2928449 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((224854903 : ℝ) / 50000000) = Real.log ((224854903 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((224854903 : ℝ) / 50000000) = ((224854903 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_603 : RB (Real.log ((449711199 : ℝ) / 100000000)) ((7517177 : ℝ) / 5000000) ((150343543 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((449711199 : ℝ) / 400000000)) (t := ((49711199 : ℝ) / 849711199))
    (lo := ((1464263 : ℝ) / 12500000)) (hi := ((2342821 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((449711199 : ℝ) / 100000000) = Real.log ((449711199 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((449711199 : ℝ) / 100000000) = ((449711199 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_604 : RB (Real.log ((25718223 : ℝ) / 20000000)) ((25146753 : ℝ) / 100000000) ((12573377 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((25718223 : ℝ) / 20000000)) (t := ((5718223 : ℝ) / 45718223))
    (lo := ((25146753 : ℝ) / 100000000)) (hi := ((12573377 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_605 : RB (Real.log ((447493603 : ℝ) / 100000000)) ((29969841 : ℝ) / 20000000) ((18731151 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((447493603 : ℝ) / 400000000)) (t := ((47493603 : ℝ) / 847493603))
    (lo := ((11219769 : ℝ) / 100000000)) (hi := ((1121977 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((447493603 : ℝ) / 100000000) = Real.log ((447493603 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((447493603 : ℝ) / 100000000) = ((447493603 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_606 : RB (Real.log ((447494987 : ℝ) / 100000000)) ((74924757 : ℝ) / 50000000) ((149849517 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((447494987 : ℝ) / 400000000)) (t := ((47494987 : ℝ) / 847494987))
    (lo := ((5610039 : ℝ) / 50000000)) (hi := ((11220079 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((447494987 : ℝ) / 100000000) = Real.log ((447494987 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((447494987 : ℝ) / 100000000) = ((447494987 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_607 : RB (Real.log ((6438673 : ℝ) / 5000000)) ((5057691 : ℝ) / 20000000) ((3161057 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((6438673 : ℝ) / 5000000)) (t := ((1438673 : ℝ) / 11438673))
    (lo := ((5057691 : ℝ) / 20000000)) (hi := ((3161057 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_608 : RB (Real.log ((30288 : ℝ) / 390625)) ((-255699647 : ℝ) / 100000000) ((-127849821 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((484608 : ℝ) / 390625)) (t := ((93983 : ℝ) / 875233))
    (lo := ((21559229 : ℝ) / 100000000)) (hi := ((2155923 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((30288 : ℝ) / 390625) = Real.log ((484608 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((30288 : ℝ) / 390625) = ((484608 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_609 : RB (Real.log ((8793911 : ℝ) / 100000000)) ((-243111067 : ℝ) / 100000000) ((-243111063 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8793911 : ℝ) / 12500000)) (t := ((-3706089 : ℝ) / 21293911))
    (lo := ((-3516691 : ℝ) / 10000000)) (hi := ((-35166909 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8793911 : ℝ) / 100000000) = Real.log ((8793911 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8793911 : ℝ) / 100000000) = ((8793911 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_610 : RB (Real.log ((2283807 : ℝ) / 100000000)) ((-75586529 : ℝ) / 20000000) ((-377932639 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2283807 : ℝ) / 3125000)) (t := ((-841193 : ℝ) / 5408807))
    (lo := ((-627181 : ℝ) / 2000000)) (hi := ((-31359049 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2283807 : ℝ) / 100000000) = Real.log ((2283807 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2283807 : ℝ) / 100000000) = ((2283807 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_611 : RB (Real.log ((579393 : ℝ) / 25000000)) ((-75293003 : ℝ) / 20000000) ((-376465009 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((579393 : ℝ) / 781250)) (t := ((-201857 : ℝ) / 1360643))
    (lo := ((-1494571 : ℝ) / 5000000)) (hi := ((-29891419 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((579393 : ℝ) / 25000000) = Real.log ((579393 : ℝ) / 781250) - 5 * Real.log 2 := by
    rw [show ((579393 : ℝ) / 25000000) = ((579393 : ℝ) / 781250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_612 : RB (Real.log ((9126547 : ℝ) / 12500000)) ((-31454123 : ℝ) / 100000000) ((-15727061 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9126547 : ℝ) / 12500000)) (t := ((-3373453 : ℝ) / 21626547))
    (lo := ((-31454123 : ℝ) / 100000000)) (hi := ((-15727061 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_613 : RB (Real.log ((36506539 : ℝ) / 50000000)) ((-15726581 : ℝ) / 50000000) ((-31453161 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36506539 : ℝ) / 50000000)) (t := ((-13493461 : ℝ) / 86506539))
    (lo := ((-15726581 : ℝ) / 50000000)) (hi := ((-31453161 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_614 : RB (Real.log ((42209031 : ℝ) / 100000000)) ((-107817 : ℝ) / 125000) ((-43126799 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42209031 : ℝ) / 50000000)) (t := ((-7790969 : ℝ) / 92209031))
    (lo := ((-16938881 : ℝ) / 100000000)) (hi := ((-26467 : ℝ) / 156250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42209031 : ℝ) / 100000000) = Real.log ((42209031 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42209031 : ℝ) / 100000000) = ((42209031 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_615 : RB (Real.log ((195273693 : ℝ) / 100000000)) ((33461597 : ℝ) / 50000000) ((16730799 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((195273693 : ℝ) / 200000000)) (t := ((-4726307 : ℝ) / 395273693))
    (lo := ((-597881 : ℝ) / 25000000)) (hi := ((-2391523 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195273693 : ℝ) / 100000000) = Real.log ((195273693 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195273693 : ℝ) / 100000000) = ((195273693 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_616 : RB (Real.log ((19533893 : ℝ) / 10000000)) ((16739149 : ℝ) / 25000000) ((33478299 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((19533893 : ℝ) / 20000000)) (t := ((-466107 : ℝ) / 39533893))
    (lo := ((-1179061 : ℝ) / 50000000)) (hi := ((-2358121 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19533893 : ℝ) / 10000000) = Real.log ((19533893 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((19533893 : ℝ) / 10000000) = ((19533893 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_617 : RB (Real.log ((74156653 : ℝ) / 100000000)) ((-186869 : ℝ) / 625000) ((-29899039 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74156653 : ℝ) / 100000000)) (t := ((-25843347 : ℝ) / 174156653))
    (lo := ((-186869 : ℝ) / 625000)) (hi := ((-29899039 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_618 : RB (Real.log ((74157359 : ℝ) / 100000000)) ((-3737261 : ℝ) / 12500000) ((-29898087 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74157359 : ℝ) / 100000000)) (t := ((-25842641 : ℝ) / 174157359))
    (lo := ((-3737261 : ℝ) / 12500000)) (hi := ((-29898087 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_619 : RB (Real.log ((2129437 : ℝ) / 5000000)) ((-8535803 : ℝ) / 10000000) ((-21339507 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2129437 : ℝ) / 2500000)) (t := ((-370563 : ℝ) / 4629437))
    (lo := ((-16043311 : ℝ) / 100000000)) (hi := ((-1604331 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2129437 : ℝ) / 5000000) = Real.log ((2129437 : ℝ) / 2500000) - 1 * Real.log 2 := by
    rw [show ((2129437 : ℝ) / 5000000) = ((2129437 : ℝ) / 2500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_620 : RB (Real.log ((448964477 : ℝ) / 100000000)) ((75088679 : ℝ) / 50000000) ((150177361 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((448964477 : ℝ) / 400000000)) (t := ((48964477 : ℝ) / 848964477))
    (lo := ((5773961 : ℝ) / 50000000)) (hi := ((11547923 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((448964477 : ℝ) / 100000000) = Real.log ((448964477 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((448964477 : ℝ) / 100000000) = ((448964477 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_621 : RB (Real.log ((112241473 : ℝ) / 25000000)) ((150177673 : ℝ) / 100000000) ((37544419 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((112241473 : ℝ) / 100000000)) (t := ((12241473 : ℝ) / 212241473))
    (lo := ((11548237 : ℝ) / 100000000)) (hi := ((5774119 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112241473 : ℝ) / 25000000) = Real.log ((112241473 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((112241473 : ℝ) / 25000000) = ((112241473 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_622 : RB (Real.log ((25730413 : ℝ) / 20000000)) ((1259707 : ℝ) / 5000000) ((25194141 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((25730413 : ℝ) / 20000000)) (t := ((5730413 : ℝ) / 45730413))
    (lo := ((1259707 : ℝ) / 5000000)) (hi := ((25194141 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_623 : RB (Real.log ((446763757 : ℝ) / 100000000)) ((5987439 : ℝ) / 4000000) ((74842989 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((446763757 : ℝ) / 400000000)) (t := ((46763757 : ℝ) / 846763757))
    (lo := ((11056539 : ℝ) / 100000000)) (hi := ((552827 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((446763757 : ℝ) / 100000000) = Real.log ((446763757 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((446763757 : ℝ) / 100000000) = ((446763757 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_624 : RB (Real.log ((446765163 : ℝ) / 100000000)) ((14968629 : ℝ) / 10000000) ((149686293 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((446765163 : ℝ) / 400000000)) (t := ((46765163 : ℝ) / 846765163))
    (lo := ((5528427 : ℝ) / 50000000)) (hi := ((2211371 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((446765163 : ℝ) / 100000000) = Real.log ((446765163 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((446765163 : ℝ) / 100000000) = ((446765163 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_625 : RB (Real.log ((8052119 : ℝ) / 6250000)) ((12667691 : ℝ) / 50000000) ((25335383 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8052119 : ℝ) / 6250000)) (t := ((1802119 : ℝ) / 14302119))
    (lo := ((12667691 : ℝ) / 50000000)) (hi := ((25335383 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_626 : RB (Real.log ((1560033 : ℝ) / 20000000)) ((-127551267 : ℝ) / 50000000) ((-255102529 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1560033 : ℝ) / 1250000)) (t := ((310033 : ℝ) / 2810033))
    (lo := ((11078171 : ℝ) / 50000000)) (hi := ((22156343 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1560033 : ℝ) / 20000000) = Real.log ((1560033 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1560033 : ℝ) / 20000000) = ((1560033 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_627 : RB (Real.log ((8828223 : ℝ) / 100000000)) ((-242721647 : ℝ) / 100000000) ((-242721643 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8828223 : ℝ) / 12500000)) (t := ((-3671777 : ℝ) / 21328223))
    (lo := ((-3477749 : ℝ) / 10000000)) (hi := ((-34777489 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8828223 : ℝ) / 100000000) = Real.log ((8828223 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8828223 : ℝ) / 100000000) = ((8828223 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_628 : RB (Real.log ((1158011 : ℝ) / 50000000)) ((-188265959 : ℝ) / 50000000) ((-47066489 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((1158011 : ℝ) / 1562500)) (t := ((-404489 : ℝ) / 2720511))
    (lo := ((-29958323 : ℝ) / 100000000)) (hi := ((-14979161 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1158011 : ℝ) / 50000000) = Real.log ((1158011 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1158011 : ℝ) / 50000000) = ((1158011 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_629 : RB (Real.log ((2349811 : ℝ) / 100000000)) ((-187541767 : ℝ) / 50000000) ((-46885441 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((2349811 : ℝ) / 3125000)) (t := ((-775189 : ℝ) / 5474811))
    (lo := ((-28509939 : ℝ) / 100000000)) (hi := ((-14254969 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2349811 : ℝ) / 100000000) = Real.log ((2349811 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2349811 : ℝ) / 100000000) = ((2349811 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_630 : RB (Real.log ((72845703 : ℝ) / 100000000)) ((-3960333 : ℝ) / 12500000) ((-31682663 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((72845703 : ℝ) / 100000000)) (t := ((-27154297 : ℝ) / 172845703))
    (lo := ((-3960333 : ℝ) / 12500000)) (hi := ((-31682663 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_631 : RB (Real.log ((36423207 : ℝ) / 50000000)) ((-3960211 : ℝ) / 12500000) ((-31681687 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36423207 : ℝ) / 50000000)) (t := ((-13576793 : ℝ) / 86423207))
    (lo := ((-3960211 : ℝ) / 12500000)) (hi := ((-31681687 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_632 : RB (Real.log ((42153541 : ℝ) / 100000000)) ((-86385151 : ℝ) / 100000000) ((-86385149 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42153541 : ℝ) / 50000000)) (t := ((-7846459 : ℝ) / 92153541))
    (lo := ((-533451 : ℝ) / 3125000)) (hi := ((-17070431 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42153541 : ℝ) / 100000000) = Real.log ((42153541 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42153541 : ℝ) / 100000000) = ((42153541 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_633 : RB (Real.log ((195208451 : ℝ) / 100000000)) ((33444889 : ℝ) / 50000000) ((3344489 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((195208451 : ℝ) / 200000000)) (t := ((-4791549 : ℝ) / 395208451))
    (lo := ((-121247 : ℝ) / 5000000)) (hi := ((-2424939 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195208451 : ℝ) / 100000000) = Real.log ((195208451 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195208451 : ℝ) / 100000000) = ((195208451 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_634 : RB (Real.log ((195273699 : ℝ) / 100000000)) ((66923197 : ℝ) / 100000000) ((66923199 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((195273699 : ℝ) / 200000000)) (t := ((-4726301 : ℝ) / 395273699))
    (lo := ((-2391521 : ℝ) / 100000000)) (hi := ((-14947 : ℝ) / 625000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195273699 : ℝ) / 100000000) = Real.log ((195273699 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195273699 : ℝ) / 100000000) = ((195273699 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_635 : RB (Real.log ((18492963 : ℝ) / 25000000)) ((-6029711 : ℝ) / 20000000) ((-15074277 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18492963 : ℝ) / 25000000)) (t := ((-6507037 : ℝ) / 43492963))
    (lo := ((-6029711 : ℝ) / 20000000)) (hi := ((-15074277 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_636 : RB (Real.log ((73972569 : ℝ) / 100000000)) ((-15073793 : ℝ) / 50000000) ((-6029517 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((73972569 : ℝ) / 100000000)) (t := ((-26027431 : ℝ) / 173972569))
    (lo := ((-15073793 : ℝ) / 50000000)) (hi := ((-6029517 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_637 : RB (Real.log ((42527991 : ℝ) / 100000000)) ((-85500773 : ℝ) / 100000000) ((-85500771 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42527991 : ℝ) / 50000000)) (t := ((-7472009 : ℝ) / 92527991))
    (lo := ((-8093027 : ℝ) / 50000000)) (hi := ((-16186053 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42527991 : ℝ) / 100000000) = Real.log ((42527991 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42527991 : ℝ) / 100000000) = ((42527991 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_638 : RB (Real.log ((448224353 : ℝ) / 100000000)) ((15001237 : ℝ) / 10000000) ((150012373 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((448224353 : ℝ) / 400000000)) (t := ((48224353 : ℝ) / 848224353))
    (lo := ((5691467 : ℝ) / 50000000)) (hi := ((2276587 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((448224353 : ℝ) / 100000000) = Real.log ((448224353 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((448224353 : ℝ) / 100000000) = ((448224353 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_639 : RB (Real.log ((224112893 : ℝ) / 50000000)) ((15001269 : ℝ) / 10000000) ((150012693 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((224112893 : ℝ) / 200000000)) (t := ((24112893 : ℝ) / 424112893))
    (lo := ((5691627 : ℝ) / 50000000)) (hi := ((2276651 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((224112893 : ℝ) / 50000000) = Real.log ((224112893 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((224112893 : ℝ) / 50000000) = ((224112893 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
