import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk10
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_36 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((462743986403697006519678094278655 : ℝ) / 5192296858534827628530496329220096) ((474692759549400278583981228267929 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((89121249999 : ℝ) / 1000000000000) ((36569 : ℝ) / 400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1089121249999 : ℝ) / 1000000000000) ((436569 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((85371178431 : ℝ) / 1000000000000) ((87481891281 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_519.1 dlower_log_520.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((85371178431 : ℝ) / 500000000000) ((87481891281 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((518183397997 : ℝ) / 1000000000000) ((261202411849 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2417757476881 : ℝ) / 1000000000000) ((-2392263660137 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_521.1 dlower_log_522.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2392263660137 : ℝ) / 1000000000000) ((2417757476881 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((214323977053 : ℝ) / 1000000000000) ((21837259513 : ℝ) / 100000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((78162740487 : ℝ) / 100000000000) ((785676022947 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7942597201 : ℝ) / 1000000000000) ((8358073507 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((20951819827 : ℝ) / 62500000000)) - (z9)
  have h10 : RB z10 ((13074841749 : ℝ) / 40000000000) ((327286520031 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((20951819827 : ℝ) / 62500000000) ((20951819827 : ℝ) / 62500000000) ((20951819827 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((41548180173 : ℝ) / 62500000000))
  have h11 : RB z11 ((491704814693 : ℝ) / 1000000000000) ((492329806427 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((41548180173 : ℝ) / 62500000000) ((41548180173 : ℝ) / 62500000000) ((41548180173 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-709876712681 : ℝ) / 1000000000000) ((-354303224399 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_523.1 dlower_log_524.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-278866556201 : ℝ) / 500000000000) ((-4327079841 : ℝ) / 7812500000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((20951819827 : ℝ) / 62500000000))
  have h14 : RB z14 ((-1092941048899 : ℝ) / 1000000000000) ((-273235262223 : ℝ) / 250000000000) := rb_log (show RB ((20951819827 : ℝ) / 62500000000) ((20951819827 : ℝ) / 62500000000) ((20951819827 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_525.1 dlower_log_525.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((53520793649 : ℝ) / 100000000000) ((539074829251 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1600389099 : ℝ) / 125000000000) ((10445715627 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7942597201 : ℝ) / 1000000000000) ((8358073507 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((363186342639 : ℝ) / 250000000000)) - (z17)
  have h18 : RB z18 ((1444387297049 : ℝ) / 1000000000000) ((288960554671 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((363186342639 : ℝ) / 250000000000) ((363186342639 : ℝ) / 250000000000) ((363186342639 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((113186342639 : ℝ) / 250000000000))
  have h19 : RB z19 ((778878461 : ℝ) / 244140625) ((3191203858321 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((113186342639 : ℝ) / 250000000000) ((113186342639 : ℝ) / 250000000000) ((113186342639 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1160110623197 : ℝ) / 1000000000000) ((1160398230659 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_526.1 dlower_log_527.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((906774255771 : ℝ) / 1000000000000) ((911697066899 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((363186342639 : ℝ) / 250000000000))
  have h22 : RB z22 ((37345512529 : ℝ) / 100000000000) ((93363781323 : ℝ) / 250000000000) := rb_log (show RB ((363186342639 : ℝ) / 250000000000) ((363186342639 : ℝ) / 250000000000) ((363186342639 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_528.1 dlower_log_528.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((533319130479 : ℝ) / 1000000000000) ((538241941609 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((10914306781 : ℝ) / 1000000000000) ((5014635903 : ℝ) / 250000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1089121249999 : ℝ) / 1000000000000) ((436569 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1186185097199 : ℝ) / 1000000000000) ((1191203073507 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((335794969721 : ℝ) / 200000000000) ((421519374321 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((279379063331 : ℝ) / 250000000000))
  have h28 : RB z28 ((938140841119 : ℝ) / 500000000000) ((1884219007579 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((279379063331 : ℝ) / 250000000000) ((279379063331 : ℝ) / 250000000000) ((279379063331 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7942597201 : ℝ) / 1000000000000) ((8358073507 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((7609414814599415703453 : ℝ) / 15625000000000000000000))
  have h30 : RB z30 ((4077287291 : ℝ) / 250000000000) ((42905697 : ℝ) / 2500000000) := rb_div_signed h29 (show RB ((7609414814599415703453 : ℝ) / 15625000000000000000000) ((7609414814599415703453 : ℝ) / 15625000000000000000000) ((7609414814599415703453 : ℝ) / 15625000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((2457094303 : ℝ) / 2500000000) ((245922712709 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((18440804129 : ℝ) / 10000000000) ((1853488998727 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((20951819827 : ℝ) / 62500000000)) ((1600389099 : ℝ) / 125000000000) ((10445715627 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((363186342639 : ℝ) / 250000000000)) ((10914306781 : ℝ) / 1000000000000) ((5014635903 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((20951819827 : ℝ) / 62500000000)) (wl := ((363186342639 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((18440804129 : ℝ) / 10000000000) ≤ D0q (q) * (((363186342639 : ℝ) / 250000000000) - ((20951819827 : ℝ) / 62500000000)) * (1 - (q) ^ 2 / (((363186342639 : ℝ) / 250000000000) * ((20951819827 : ℝ) / 62500000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_37 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((474692759549400278583981228267929 : ℝ) / 5192296858534827628530496329220096) ((243320766347551775324142181128601 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((91422499999 : ℝ) / 1000000000000) ((74979 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1091422499999 : ℝ) / 1000000000000) ((874979 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((87481891279 : ℝ) / 1000000000000) ((44794079201 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_529.1 dlower_log_530.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((87481891279 : ℝ) / 500000000000) ((44794079201 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((102794172751 : ℝ) / 200000000000) ((259091699001 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-47845273203 : ℝ) / 20000000000) ((-1183701826669 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_531.1 dlower_log_532.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1183701826669 : ℝ) / 500000000000) ((47845273203 : ℝ) / 20000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((26855885093 : ℝ) / 125000000000) ((218882570901 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((781117429099 : ℝ) / 1000000000000) ((98144114907 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((4179036753 : ℝ) / 500000000000) ((1756828263 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((330016648199 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((80308126721 : ℝ) / 250000000000) ((321658574693 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((330016648199 : ℝ) / 1000000000000) ((330016648199 : ℝ) / 1000000000000) ((330016648199 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((669983351801 : ℝ) / 1000000000000))
  have h11 : RB z11 ((239731708273 : ℝ) / 500000000000) ((120024838613 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((669983351801 : ℝ) / 1000000000000) ((669983351801 : ℝ) / 1000000000000) ((669983351801 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-735087682573 : ℝ) / 1000000000000) ((-91720276007 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_533.1 dlower_log_534.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-288578119941 : ℝ) / 500000000000) ((-286577224763 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((330016648199 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1108612176707 : ℝ) / 1000000000000) ((-221722435341 : ℝ) / 200000000000) := rb_log (show RB ((330016648199 : ℝ) / 1000000000000) ((330016648199 : ℝ) / 1000000000000) ((330016648199 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_535.1 dlower_log_535.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((531455936823 : ℝ) / 1000000000000) ((535457727181 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((13272538821 : ℝ) / 1000000000000) ((10743431713 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((4179036753 : ℝ) / 500000000000) ((1756828263 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1454570913929 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((722893386307 : ℝ) / 500000000000) ((1446212840423 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1454570913929 : ℝ) / 1000000000000) ((1454570913929 : ℝ) / 1000000000000) ((1454570913929 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((454570913929 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3180552754943 : ℝ) / 1000000000000) ((25451920413 : ℝ) / 8000000000) := rb_div_signed h18 (show RB ((454570913929 : ℝ) / 1000000000000) ((454570913929 : ℝ) / 1000000000000) ((454570913929 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((578527501997 : ℝ) / 500000000000) ((578674828371 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_536.1 dlower_log_537.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((180759166009 : ℝ) / 200000000000) ((908696461591 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1454570913929 : ℝ) / 1000000000000))
  have h22 : RB z22 ((374710952613 : ℝ) / 1000000000000) ((74942190523 : ℝ) / 200000000000) := rb_log (show RB ((1454570913929 : ℝ) / 1000000000000) ((1454570913929 : ℝ) / 1000000000000) ((1454570913929 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_538.1 dlower_log_538.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((52908487743 : ℝ) / 100000000000) ((266992754489 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2725369857 : ℝ) / 250000000000) ((20014645223 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1091422499999 : ℝ) / 1000000000000) ((874979 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((37225096047 : ℝ) / 31250000000) ((239246328263 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((104494811609 : ℝ) / 62500000000) ((167897484861 : ℝ) / 100000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((112455426573 : ℝ) / 100000000000))
  have h28 : RB z28 ((235020172283 : ℝ) / 125000000000) ((944049164029 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((112455426573 : ℝ) / 100000000000) ((112455426573 : ℝ) / 100000000000) ((112455426573 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((4179036753 : ℝ) / 500000000000) ((1756828263 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((480032617582604701863871 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((1741146997 : ℝ) / 100000000000) ((9149525463 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((480032617582604701863871 : ℝ) / 1000000000000000000000000) ((480032617582604701863871 : ℝ) / 1000000000000000000000000) ((480032617582604701863871 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((490850474537 : ℝ) / 500000000000) ((98258853003 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((922878104727 : ℝ) / 500000000000) ((1855223760719 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((330016648199 : ℝ) / 1000000000000)) ((13272538821 : ℝ) / 1000000000000) ((10743431713 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1454570913929 : ℝ) / 1000000000000)) ((2725369857 : ℝ) / 250000000000) ((20014645223 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((330016648199 : ℝ) / 1000000000000)) (wl := ((1454570913929 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((922878104727 : ℝ) / 500000000000) ≤ D0q (q) * (((1454570913929 : ℝ) / 1000000000000) - ((330016648199 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1454570913929 : ℝ) / 1000000000000) * ((330016648199 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_38 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((243320766347551775324142181128601 : ℝ) / 2596148429267413814265248164610048) ((124647576460201705678146874061619 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((93723749999 : ℝ) / 1000000000000) ((3841 : ℝ) / 40000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1093723749999 : ℝ) / 1000000000000) ((43841 : ℝ) / 40000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((55992599 : ℝ) / 625000000) ((18337999697 : ℝ) / 200000000000) := rb_log h1 (by norm_num) dlower_log_539.1 dlower_log_540.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((55992599 : ℝ) / 312500000) ((18337999697 : ℝ) / 100000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((509767183589 : ℝ) / 1000000000000) ((6424635797 : ℝ) / 12500000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-47348073067 : ℝ) / 20000000000) ((-2343146704749 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_541.1 dlower_log_542.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2343146704749 : ℝ) / 1000000000000) ((47348073067 : ℝ) / 20000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((215327531013 : ℝ) / 1000000000000) ((43870139477 : ℝ) / 200000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((156129860523 : ℝ) / 200000000000) ((784672468987 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((8784141313 : ℝ) / 1000000000000) ((14753281 : ℝ) / 1600000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((81231850311 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((315706600619 : ℝ) / 1000000000000) ((316143259931 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((81231850311 : ℝ) / 250000000000) ((81231850311 : ℝ) / 250000000000) ((81231850311 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((168768149689 : ℝ) / 250000000000))
  have h11 : RB z11 ((233831591743 : ℝ) / 500000000000) ((468310016603 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((168768149689 : ℝ) / 250000000000) ((168768149689 : ℝ) / 250000000000) ((168768149689 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-30400277423 : ℝ) / 40000000000) ((-758624773733 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_543.1 dlower_log_544.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-119271303717 : ℝ) / 200000000000) ((-592219900561 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((81231850311 : ℝ) / 250000000000))
  have h14 : RB z14 ((-562076751197 : ℝ) / 500000000000) ((-140519187799 : ℝ) / 125000000000) := rb_log (show RB ((81231850311 : ℝ) / 250000000000) ((81231850311 : ℝ) / 250000000000) ((81231850311 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_545.1 dlower_log_545.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((527796983807 : ℝ) / 1000000000000) ((531933601833 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((13826120047 : ℝ) / 1000000000000) ((5541604561 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((8784141313 : ℝ) / 1000000000000) ((14753281 : ℝ) / 1600000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1456423406727 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((723601303051 : ℝ) / 500000000000) ((723819632707 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((1456423406727 : ℝ) / 1000000000000) ((1456423406727 : ℝ) / 1000000000000) ((1456423406727 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((456423406727 : ℝ) / 1000000000000))
  have h19 : RB z19 ((634149162717 : ℝ) / 200000000000) ((79292562787 : ℝ) / 25000000000) := rb_div_signed h18 (show RB ((456423406727 : ℝ) / 1000000000000) ((456423406727 : ℝ) / 1000000000000) ((456423406727 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((225384147 : ℝ) / 195312500) ((1154268513587 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_546.1 dlower_log_547.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((900843403141 : ℝ) / 1000000000000) ((905722724431 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1456423406727 : ℝ) / 1000000000000))
  have h22 : RB z22 ((187991854411 : ℝ) / 500000000000) ((46997963603 : ℝ) / 125000000000) := rb_log (show RB ((1456423406727 : ℝ) / 1000000000000) ((1456423406727 : ℝ) / 1000000000000) ((1456423406727 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_548.1 dlower_log_548.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((524859694317 : ℝ) / 1000000000000) ((529739015609 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((10888830557 : ℝ) / 1000000000000) ((998591601 : ℝ) / 50000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1093723749999 : ℝ) / 1000000000000) ((43841 : ℝ) / 40000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1196231641311 : ℝ) / 1000000000000) ((1922033281 : ℝ) / 1600000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((832451766479 : ℝ) / 500000000000) ((1671916985751 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1131496005483 : ℝ) / 1000000000000))
  have h28 : RB z28 ((58869740533 : ℝ) / 31250000000) ((1891767390877 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1131496005483 : ℝ) / 1000000000000) ((1131496005483 : ℝ) / 1000000000000) ((1131496005483 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((8784141313 : ℝ) / 1000000000000) ((14753281 : ℝ) / 1600000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((118307968164684334442097 : ℝ) / 250000000000000000000000))
  have h30 : RB z30 ((9281011931 : ℝ) / 500000000000) ((4871185331 : ℝ) / 250000000000) := rb_div_signed h29 (show RB ((118307968164684334442097 : ℝ) / 250000000000000000000000) ((118307968164684334442097 : ℝ) / 250000000000000000000000) ((118307968164684334442097 : ℝ) / 250000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((245128814669 : ℝ) / 250000000000) ((490718988069 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((92356286187 : ℝ) / 50000000000) ((1856652359427 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((81231850311 : ℝ) / 250000000000)) ((13826120047 : ℝ) / 1000000000000) ((5541604561 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1456423406727 : ℝ) / 1000000000000)) ((10888830557 : ℝ) / 1000000000000) ((998591601 : ℝ) / 50000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((81231850311 : ℝ) / 250000000000)) (wl := ((1456423406727 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((92356286187 : ℝ) / 50000000000) ≤ D0q (q) * (((1456423406727 : ℝ) / 1000000000000) - ((81231850311 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((1456423406727 : ℝ) / 1000000000000) * ((81231850311 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_39 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((124647576460201705678146874061619 : ℝ) / 1298074214633706907132624082305024) ((510539078986510094776890630235749 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((96024999999 : ℝ) / 1000000000000) ((78661 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1096024999999 : ℝ) / 1000000000000) ((878661 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((91689998483 : ℝ) / 1000000000000) ((93787430101 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_549.1 dlower_log_550.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((91689998483 : ℝ) / 500000000000) ((93787430101 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((505572320357 : ℝ) / 1000000000000) ((254883591797 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2343146704761 : ℝ) / 1000000000000) ((-1159732123901 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_551.1 dlower_log_552.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1159732123901 : ℝ) / 500000000000) ((2343146704761 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((215766396243 : ℝ) / 1000000000000) ((219777987127 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((780222012873 : ℝ) / 1000000000000) ((784233603757 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((576300039 : ℝ) / 62500000000) ((120850643 : ℝ) / 12500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((320029384589 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((310361333149 : ℝ) / 1000000000000) ((62161716793 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((320029384589 : ℝ) / 1000000000000) ((320029384589 : ℝ) / 1000000000000) ((320029384589 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((679970615411 : ℝ) / 1000000000000))
  have h11 : RB z11 ((456433448909 : ℝ) / 1000000000000) ((457091199121 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((679970615411 : ℝ) / 1000000000000) ((679970615411 : ℝ) / 1000000000000) ((679970615411 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-392156187549 : ℝ) / 500000000000) ((-195718086889 : ℝ) / 250000000000) := rb_log h11 (by norm_num) dlower_log_553.1 dlower_log_554.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-123016824079 : ℝ) / 200000000000) ((-38175889927 : ℝ) / 62500000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((320029384589 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-284835615141 : ℝ) / 250000000000) ((-569671230281 : ℝ) / 500000000000) := rb_log (show RB ((320029384589 : ℝ) / 1000000000000) ((320029384589 : ℝ) / 1000000000000) ((320029384589 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_555.1 dlower_log_555.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((524258340167 : ℝ) / 1000000000000) ((132132055433 : ℝ) / 250000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((14491156573 : ℝ) / 1000000000000) ((183647211 : ℝ) / 8000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((576300039 : ℝ) / 62500000000) ((120850643 : ℝ) / 12500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((729151168377 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((724317142657 : ℝ) / 500000000000) ((144908153613 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((729151168377 : ℝ) / 500000000000) ((729151168377 : ℝ) / 500000000000) ((729151168377 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((229151168377 : ℝ) / 500000000000))
  have h19 : RB z19 ((3160870388691 : ℝ) / 1000000000000) ((3161846274653 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((229151168377 : ℝ) / 500000000000) ((229151168377 : ℝ) / 500000000000) ((229151168377 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((115084742913 : ℝ) / 100000000000) ((575578060557 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_556.1 dlower_log_557.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((179583299533 : ℝ) / 200000000000) ((902775313349 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((729151168377 : ℝ) / 500000000000))
  have h22 : RB z22 ((377272976117 : ℝ) / 1000000000000) ((377272976119 : ℝ) / 1000000000000) := rb_log (show RB ((729151168377 : ℝ) / 500000000000) ((729151168377 : ℝ) / 500000000000) ((729151168377 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_558.1 dlower_log_558.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((260321760773 : ℝ) / 500000000000) ((32843896077 : ℝ) / 62500000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((339885561 : ℝ) / 31250000000) ((31888027 : ℝ) / 1600000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1096024999999 : ℝ) / 1000000000000) ((878661 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((600635400311 : ℝ) / 500000000000) ((15079006893 : ℝ) / 12500000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1657934118433 : ℝ) / 1000000000000) ((1664903532963 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((227654590433 : ℝ) / 200000000000))
  have h28 : RB z28 ((1887181563483 : ℝ) / 1000000000000) ((118444666221 : ℝ) / 62500000000) := rb_widen (rb_mul h27 (show RB ((227654590433 : ℝ) / 200000000000) ((227654590433 : ℝ) / 200000000000) ((227654590433 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((576300039 : ℝ) / 62500000000) ((120850643 : ℝ) / 12500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((233349799688041627942053 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((19757464193 : ℝ) / 1000000000000) ((20715791171 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((233349799688041627942053 : ℝ) / 500000000000000000000000) ((233349799688041627942053 : ℝ) / 500000000000000000000000) ((233349799688041627942053 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((979284208829 : ℝ) / 1000000000000) ((980242535807 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((231010888039 : ℝ) / 125000000000) ((1857671999509 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((320029384589 : ℝ) / 1000000000000)) ((14491156573 : ℝ) / 1000000000000) ((183647211 : ℝ) / 8000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((729151168377 : ℝ) / 500000000000)) ((339885561 : ℝ) / 31250000000) ((31888027 : ℝ) / 1600000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((320029384589 : ℝ) / 1000000000000)) (wl := ((729151168377 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((231010888039 : ℝ) / 125000000000) ≤ D0q (q) * (((729151168377 : ℝ) / 500000000000) - ((320029384589 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((729151168377 : ℝ) / 500000000000) * ((320029384589 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
