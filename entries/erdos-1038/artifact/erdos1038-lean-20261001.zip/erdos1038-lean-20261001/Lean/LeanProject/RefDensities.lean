import LeanProject.BlockEnergy

/-!
# EP-1038, Stage 12, Lemma 12.1(1), (2): the reference densities `α` and `B`

In the angle variable (Stage 12 §0): `α(θ) = (k+1) - k P_{ρ₀}(θ)` (density of `η`) and
`B(θ) = D_ξ - σ₊P_{ρ₊}(θ) - σ₋P_{ρ₋}(θ)` with `D_ξ = σ₊P_{ρ₊}(0) + σ₋P_{ρ₋}(0)` (density of `ξ`).

* `Pq_anti`: `P_ρ` is nonincreasing on `[0, π]`; `Pq_pi`: `P_ρ(π) = (1-ρ)/(1+ρ)`;
  `int_Pq_half`: `∫_0^π P_ρ = π`.
* `alpha_le_api`, `api_eq` (**Lemma 12.1(1)**): `α ≤ a_π := α(π) = 1 + 2kρ₀/(1+ρ₀)` on `[0, π]`.
* `Bf_nonneg`, `Bf_le_bpi`, `bpi_eq`, `int_Bf`, `Rxi_le_bpi` (**Lemma 12.1(2)**):
  `0 ≤ B ≤ b_π := B(π) = ∑ 4σρ/(1-ρ²)`, `R_ξ = (1/π)∫_0^π B = ∑ 2σρ/(1-ρ)`, `R_ξ ≤ b_π`
  (non-strict; the strict form needs `σ, ρ > 0`).
* `block_ineq_ref` (**Theorem 12.8** for the reference, angle form): for an angular interval
  `J = [θ₁, θ₂] ⊆ [0, π]` and `F = 1_J α/a_π`, `G = 1_J B/b_π`, (12.5) holds.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

theorem Pq_anti {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) {x y : ℝ} (hx : 0 ≤ x) (hxy : x ≤ y)
    (hy : y ≤ π) : Pq q y ≤ Pq q x := by
  have hc : Real.cos y ≤ Real.cos x := Real.cos_le_cos_of_nonneg_of_le_pi hx hy hxy
  unfold Pq
  apply div_le_div_of_nonneg_left (by nlinarith) (Pq_den_pos hq0 hq1 x)
  nlinarith

theorem Pq_pi {q : ℝ} (hq0 : 0 ≤ q) : Pq q π = (1 - q) / (1 + q) := by
  unfold Pq
  have h : 1 + q ≠ 0 := by linarith
  rw [Real.cos_pi, show 1 - 2 * q * -1 + q ^ 2 = (1 + q) * (1 + q) by ring,
    show 1 - q ^ 2 = (1 - q) * (1 + q) by ring, mul_div_mul_right _ _ h]

theorem Pq_even (q θ : ℝ) : Pq q (-θ) = Pq q θ := by
  unfold Pq
  rw [Real.cos_neg]

theorem int_Pq_half {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) : ∫ θ in (0 : ℝ)..π, Pq q θ = π := by
  have h := int_Pq hq0 hq1
  rw [int_split ((Pq_cont hq0 hq1).intervalIntegrable _ _)] at h
  simp only [Pq_even] at h
  linarith

/-! ### `α` -/

/-- `α(θ) = (k+1) - k P_{ρ₀}(θ)`. -/
noncomputable def alpha (k ρ0 θ : ℝ) : ℝ := (k + 1) - k * Pq ρ0 θ

theorem alpha_le_api {k ρ0 θ : ℝ} (hk : 0 ≤ k) (h0 : 0 ≤ ρ0) (h1 : ρ0 < 1) (hθ0 : 0 ≤ θ)
    (hθ : θ ≤ π) : alpha k ρ0 θ ≤ alpha k ρ0 π := by
  unfold alpha
  have := Pq_anti h0 h1 hθ0 hθ le_rfl
  nlinarith

theorem api_eq {k ρ0 : ℝ} (h0 : 0 ≤ ρ0) : alpha k ρ0 π = 1 + 2 * k * ρ0 / (1 + ρ0) := by
  unfold alpha
  rw [Pq_pi h0]
  have : 1 + ρ0 ≠ 0 := by linarith
  field_simp
  ring

theorem one_le_api {k ρ0 : ℝ} (hk : 0 ≤ k) (h0 : 0 ≤ ρ0) : 1 ≤ alpha k ρ0 π := by
  rw [api_eq h0]
  have : 0 ≤ 2 * k * ρ0 / (1 + ρ0) := by positivity
  linarith

/-! ### `B` -/

/-- `B(θ) = σ₊(P_{ρ₊}(0) - P_{ρ₊}(θ)) + σ₋(P_{ρ₋}(0) - P_{ρ₋}(θ))`. -/
noncomputable def Bf (sp sm rp rm θ : ℝ) : ℝ :=
  sp * (Pq rp 0 - Pq rp θ) + sm * (Pq rm 0 - Pq rm θ)

section B

variable {sp sm rp rm : ℝ} (hsp : 0 ≤ sp) (hsm : 0 ≤ sm) (hrp0 : 0 ≤ rp) (hrp1 : rp < 1)
  (hrm0 : 0 ≤ rm) (hrm1 : rm < 1)
include hsp hsm hrp0 hrp1 hrm0 hrm1

theorem Bf_nonneg {θ : ℝ} (hθ0 : 0 ≤ θ) (hθ : θ ≤ π) : 0 ≤ Bf sp sm rp rm θ := by
  unfold Bf
  have h1 := Pq_anti hrp0 hrp1 le_rfl hθ0 hθ
  have h2 := Pq_anti hrm0 hrm1 le_rfl hθ0 hθ
  have := mul_nonneg hsp (sub_nonneg.mpr h1)
  have := mul_nonneg hsm (sub_nonneg.mpr h2)
  linarith

theorem Bf_le_bpi {θ : ℝ} (hθ0 : 0 ≤ θ) (hθ : θ ≤ π) :
    Bf sp sm rp rm θ ≤ Bf sp sm rp rm π := by
  unfold Bf
  have h1 := Pq_anti hrp0 hrp1 hθ0 hθ le_rfl
  have h2 := Pq_anti hrm0 hrm1 hθ0 hθ le_rfl
  have := mul_le_mul_of_nonneg_left (sub_le_sub_left h1 (Pq rp 0)) hsp
  have := mul_le_mul_of_nonneg_left (sub_le_sub_left h2 (Pq rm 0)) hsm
  linarith

omit hsp hsm in
theorem bpi_eq : Bf sp sm rp rm π = sp * (4 * rp / (1 - rp ^ 2)) + sm * (4 * rm / (1 - rm ^ 2)) := by
  unfold Bf
  rw [show (0 : ℝ) = 0 from rfl]
  have e0p : Pq rp 0 = (1 + rp) / (1 - rp) := by
    have := Pq_at_zero hrp1; exact this
  have e0m : Pq rm 0 = (1 + rm) / (1 - rm) := by
    have := Pq_at_zero hrm1; exact this
  rw [e0p, e0m, Pq_pi hrp0, Pq_pi hrm0]
  have h1 : 1 - rp ≠ 0 := by linarith
  have h2 : 1 + rp ≠ 0 := by linarith
  have h3 : 1 - rm ≠ 0 := by linarith
  have h4 : 1 + rm ≠ 0 := by linarith
  have h5 : 1 - rp ^ 2 ≠ 0 := by nlinarith
  have h6 : 1 - rm ^ 2 ≠ 0 := by nlinarith
  field_simp
  ring

omit hsp hsm in
/-- `R_ξ = (1/π) ∫_0^π B = σ₊·2ρ₊/(1-ρ₊) + σ₋·2ρ₋/(1-ρ₋)`. -/
theorem int_Bf : 1 / π * ∫ θ in (0 : ℝ)..π, Bf sp sm rp rm θ =
    sp * (2 * rp / (1 - rp)) + sm * (2 * rm / (1 - rm)) := by
  have hπ := Real.pi_pos
  have hcp := Pq_cont hrp0 hrp1
  have hcm := Pq_cont hrm0 hrm1
  unfold Bf
  rw [intervalIntegral.integral_add
      (((intervalIntegrable_const.sub (hcp.intervalIntegrable _ _))).const_mul sp)
      (((intervalIntegrable_const.sub (hcm.intervalIntegrable _ _))).const_mul sm),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
    intervalIntegral.integral_sub intervalIntegrable_const (hcp.intervalIntegrable _ _),
    intervalIntegral.integral_sub intervalIntegrable_const (hcm.intervalIntegrable _ _),
    intervalIntegral.integral_const, intervalIntegral.integral_const, smul_eq_mul, smul_eq_mul,
    int_Pq_half hrp0 hrp1, int_Pq_half hrm0 hrm1, Pq_at_zero hrp1, Pq_at_zero hrm1]
  have h1 : 1 - rp ≠ 0 := by linarith
  have h3 : 1 - rm ≠ 0 := by linarith
  have := hπ.ne'
  field_simp
  ring

theorem Rxi_le_bpi : sp * (2 * rp / (1 - rp)) + sm * (2 * rm / (1 - rm)) ≤
    sp * (4 * rp / (1 - rp ^ 2)) + sm * (4 * rm / (1 - rm ^ 2)) := by
  have key : ∀ r : ℝ, 0 ≤ r → r < 1 → 2 * r / (1 - r) ≤ 4 * r / (1 - r ^ 2) := by
    intro r h0 h1
    have ha : 0 < 1 - r := by linarith
    have hb : 0 < 1 - r ^ 2 := by nlinarith
    rw [div_le_div_iff₀ ha hb]
    nlinarith [mul_nonneg (mul_nonneg h0 ha.le) ha.le]
  have := mul_le_mul_of_nonneg_left (key rp hrp0 hrp1) hsp
  have := mul_le_mul_of_nonneg_left (key rm hrm0 hrm1) hsm
  linarith

end B

/-! ### Theorem 12.8 for the reference densities -/

theorem alpha_cont (k ρ0 : ℝ) (h0 : 0 ≤ ρ0) (h1 : ρ0 < 1) : Continuous (alpha k ρ0) := by
  unfold alpha
  exact continuous_const.sub (continuous_const.mul (Pq_cont h0 h1))

theorem Bf_cont {sp sm rp rm : ℝ} (hrp0 : 0 ≤ rp) (hrp1 : rp < 1) (hrm0 : 0 ≤ rm) (hrm1 : rm < 1) :
    Continuous (Bf sp sm rp rm) := by
  unfold Bf
  exact (continuous_const.mul (continuous_const.sub (Pq_cont hrp0 hrp1))).add
    (continuous_const.mul (continuous_const.sub (Pq_cont hrm0 hrm1)))

/-- **Theorem 12.8** for the reference (angle form): for `J = [θ₁, θ₂] ⊆ [0, π]`, the functions
`F = 1_J α/a_π` and `G = 1_J B/b_π` take values in `[0, 1]` (by (H1) and Lemma 12.1(1), (2)), so
(12.5) holds with `Q = ∫_0^π F`, `R = ∫_0^π G` (assumed positive; Lemma 12.1(4)). -/
theorem block_ineq_ref {k ρ0 sp sm rp rm θ1 θ2 D0 Ceff : ℝ} (hk : 0 ≤ k) (hρ0 : 0 < ρ0)
    (hρ1 : ρ0 < 1) (hH1 : ∀ θ, 0 ≤ alpha k ρ0 θ) (hsp : 0 < sp) (hsm : 0 ≤ sm) (hrp0 : 0 < rp)
    (hrp1 : rp < 1) (hrm0 : 0 ≤ rm) (hrm1 : rm < 1) (hθ1 : 0 ≤ θ1) (hθ2 : θ2 ≤ π) (hD : 0 < D0)
    (hQ : 0 < ∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t)
    (hR : 0 < ∫ t in (0 : ℝ)..π,
      (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) t) :
    rhs (Real.log (2 * (D0 * ρ0) / (alpha k ρ0 π * Bf sp sm rp rm π))) Ceff (alpha k ρ0 π)
        (∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t)
        (∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) t) ≤
      (Real.log (D0 * ρ0) + (∫ t in (0 : ℝ)..π,
          (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t *
          ∫ s in (0 : ℝ)..π, (Real.log |dth D0 ρ0 t - dth D0 ρ0 s| - Real.log (D0 * ρ0)) *
            (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) s) /
          ((∫ t in (0 : ℝ)..π, (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t) *
            (∫ t in (0 : ℝ)..π,
              (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) t))) -
        Real.log (alpha k ρ0 π * (∫ t in (0 : ℝ)..π,
            (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t) / π *
          (Bf sp sm rp rm π * (∫ t in (0 : ℝ)..π,
            (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) t) / π) / 2) -
        Ceff / (alpha k ρ0 π * (∫ t in (0 : ℝ)..π,
          (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) t) / π) := by
  have ha : 0 < alpha k ρ0 π := lt_of_lt_of_le one_pos (one_le_api hk hρ0.le)
  have hbpi : 0 < Bf sp sm rp rm π := by
    rw [bpi_eq hrp0.le hrp1 hrm0 hrm1]
    have h1 : 0 < 1 - rp ^ 2 := by nlinarith
    have h2 : 0 < 1 - rm ^ 2 := by nlinarith
    have : 0 < sp * (4 * rp / (1 - rp ^ 2)) := by positivity
    have : 0 ≤ sm * (4 * rm / (1 - rm ^ 2)) := by positivity
    linarith
  have hFm : Measurable ((Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π)) :=
    ((alpha_cont k ρ0 hρ0.le hρ1).div_const _).measurable.indicator measurableSet_Icc
  have hGm : Measurable ((Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π)) :=
    ((Bf_cont hrp0.le hrp1 hrm0 hrm1).div_const _).measurable.indicator measurableSet_Icc
  have hF0 : ∀ x, 0 ≤ (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) x := by
    intro x
    by_cases hx : x ∈ Icc θ1 θ2
    · rw [indicator_of_mem hx]; exact div_nonneg (hH1 x) ha.le
    · rw [indicator_of_notMem hx]
  have hF1 : ∀ x, (Icc θ1 θ2).indicator (fun θ => alpha k ρ0 θ / alpha k ρ0 π) x ≤ 1 := by
    intro x
    by_cases hx : x ∈ Icc θ1 θ2
    · rw [indicator_of_mem hx, div_le_one ha]
      exact alpha_le_api hk hρ0.le hρ1 (hθ1.trans hx.1) (hx.2.trans hθ2)
    · rw [indicator_of_notMem hx]; exact zero_le_one
  have hG0 : ∀ x, 0 ≤ (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) x := by
    intro x
    by_cases hx : x ∈ Icc θ1 θ2
    · rw [indicator_of_mem hx]
      exact div_nonneg (Bf_nonneg hsp.le hsm hrp0.le hrp1 hrm0 hrm1 (hθ1.trans hx.1)
        (hx.2.trans hθ2)) hbpi.le
    · rw [indicator_of_notMem hx]
  have hG1 : ∀ x, (Icc θ1 θ2).indicator (fun θ => Bf sp sm rp rm θ / Bf sp sm rp rm π) x ≤ 1 := by
    intro x
    by_cases hx : x ∈ Icc θ1 θ2
    · rw [indicator_of_mem hx, div_le_one hbpi]
      exact Bf_le_bpi hsp.le hsm hrp0.le hrp1 hrm0 hrm1 (hθ1.trans hx.1) (hx.2.trans hθ2)
    · rw [indicator_of_notMem hx]; exact zero_le_one
  exact block_ineq_angle hFm hGm hF0 hF1 hG0 hG1 hD hρ0 ha hbpi hQ hR

end EP1038.Arc
