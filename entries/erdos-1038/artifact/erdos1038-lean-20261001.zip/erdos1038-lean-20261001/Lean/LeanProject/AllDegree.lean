import LeanProject.Transition

/-!
# EP-1038: bounds valid in every degree, and the supremum in degree 2

Statements are for root vectors `r : Fin n → [-1, 1]` (the roots of `f ∈ 𝒫`, as in the other
files; Lean RED L-55).

* `one_le_volume_sublevel`: `1 ≤ |S(r)|` for every `n ≥ 1` and `r : Fin n → [-1, 1]`
  (orientation, proof.md Lemma 7.3, together with the reflection `r ↦ -r`).
* `volume_sublevel_le_four`: `|S(r)| ≤ 4` (the `S ⊂ (-2, 2)` part of proof.md Lemma 1.1(a)).
* `deg2_sup`: in degree 2, `|S| ≤ 2√2`, with equality iff `|r₁ - r₀| = 2`; on `[-1, 1]²` this
  means `(r₀, r₁) = (-1, 1)` or `(1, -1)` (Lean RED L-54).
-/

open Real MeasureTheory

namespace EP1038

theorem abs_prod_eq_multiset {n : ℕ} (r : Fin n → ℝ) (x : ℝ) :
    |∏ i, (x - r i)| = ((Finset.univ.val.map r).map fun t => |x - t|).prod := by
  rw [Finset.abs_prod, Multiset.map_map, Finset.prod_eq_multiset_prod]
  rfl

/-- Orientation for root vectors: if `n ≥ 1` and the roots sum to `≤ 0`, then `(-1, 0) ⊆ S(r)`. -/
theorem Ioo_subset_sublevel {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) (hsum : ∑ i, r i ≤ 0) :
    Set.Ioo (-1 : ℝ) 0 ⊆ sublevel r := by
  rintro x ⟨hx1, hx0⟩
  simp only [sublevel, Set.mem_ofPred_eq]
  rw [abs_prod_eq_multiset]
  apply orientation_prod_lt_one _ _ _ _ hx1 hx0
  · intro t ht
    obtain ⟨i, _, rfl⟩ := Multiset.mem_map.mp ht
    exact hr i
  · intro h
    have := congrArg Multiset.card h
    simp at this
    omega
  · rw [← Finset.sum_eq_multiset_sum]
    exact hsum

/-- **`|S(r)| ≥ 1` for every root vector `r ∈ [-1, 1]ⁿ`, `n ≥ 1`** (i.e. for every `f ∈ 𝒫`). -/
theorem one_le_volume_sublevel {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) : ENNReal.ofReal 1 ≤ volume (sublevel r) := by
  have h01 : ENNReal.ofReal 1 = volume (Set.Ioo (-1 : ℝ) 0) := by
    rw [Real.volume_Ioo]; norm_num
  rcases le_or_gt (∑ i, r i) 0 with h | h
  · rw [h01]; exact measure_mono (Ioo_subset_sublevel hn r hr h)
  · have hr' : ∀ i, (fun i => -r i) i ∈ Set.Icc (-1 : ℝ) 1 := fun i =>
      ⟨by linarith [(hr i).2], by linarith [(hr i).1]⟩
    have hs : ∑ i, (fun i => -r i) i ≤ 0 := by
      simp only [Finset.sum_neg_distrib]; linarith
    rw [← volume_sublevel_neg, h01]
    exact measure_mono (Ioo_subset_sublevel hn _ hr' hs)

/-- `S(r) ⊆ (-2, 2)` for roots in `[-1, 1]`. -/
theorem sublevel_subset_Ioo {n : ℕ} (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    sublevel r ⊆ Set.Ioo (-2 : ℝ) 2 := by
  intro x hx
  simp only [sublevel, Set.mem_ofPred_eq] at hx
  by_contra hc
  rw [Set.mem_Ioo, not_and_or, not_lt, not_lt] at hc
  have h1 : ∀ i, 1 ≤ |x - r i| := by
    intro i
    obtain ⟨a, b⟩ := hr i
    rcases hc with h | h
    · rw [abs_of_nonpos (by linarith)]; linarith
    · rw [abs_of_nonneg (by linarith)]; linarith
  have : (1 : ℝ) ≤ |∏ i, (x - r i)| := by
    rw [Finset.abs_prod]
    calc (1 : ℝ) = ∏ _i : Fin n, (1 : ℝ) := by simp
      _ ≤ ∏ i, |x - r i| := by gcongr with i; exact h1 i
  linarith

/-- **`|S(r)| ≤ 4` for every root vector `r ∈ [-1, 1]ⁿ`.** -/
theorem volume_sublevel_le_four {n : ℕ} (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    volume (sublevel r) ≤ ENNReal.ofReal 4 := by
  calc volume (sublevel r) ≤ volume (Set.Ioo (-2 : ℝ) 2) := measure_mono (sublevel_subset_Ioo r hr)
    _ = ENNReal.ofReal 4 := by rw [Real.volume_Ioo]; norm_num

/-- **Degree 2 supremum**: `|S| ≤ 2√2`, with equality iff the roots are `-1` and `1`. -/
theorem deg2_sup (r : Fin 2 → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    volume (sublevel r) ≤ ENNReal.ofReal (2 * √2) ∧
      (volume (sublevel r) = ENNReal.ofReal (2 * √2) ↔ |r 1 - r 0| = 2) := by
  rw [sublevel_fin2, volume_deg2 (r 0) (r 1) (hr 0) (hr 1)]
  have hd : |r 1 - r 0| ≤ 2 := by
    rw [abs_le]
    obtain ⟨a0, b0⟩ := hr 0
    obtain ⟨a1, b1⟩ := hr 1
    constructor <;> linarith
  have hd0 : 0 ≤ |r 1 - r 0| := abs_nonneg _
  have hsq : 0 ≤ 1 + (|r 1 - r 0| / 2) ^ 2 := by positivity
  constructor
  · apply ENNReal.ofReal_le_ofReal
    have : √(1 + (|r 1 - r 0| / 2) ^ 2) ≤ √2 := Real.sqrt_le_sqrt (by nlinarith)
    linarith
  · rw [ENNReal.ofReal_eq_ofReal_iff (by positivity) (by positivity)]
    constructor
    · intro h
      have h1 : √(1 + (|r 1 - r 0| / 2) ^ 2) = √2 := by linarith
      have h2 : (√(1 + (|r 1 - r 0| / 2) ^ 2)) ^ 2 = (√2) ^ 2 := by rw [h1]
      rw [Real.sq_sqrt hsq, Real.sq_sqrt (by norm_num)] at h2
      nlinarith [mul_nonneg hd0 (sub_nonneg.mpr hd)]
    · intro h
      rw [h]; norm_num

end EP1038
