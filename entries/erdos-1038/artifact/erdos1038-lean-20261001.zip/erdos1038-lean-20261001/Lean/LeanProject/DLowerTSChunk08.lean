import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk05
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_16 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((79839677163814435437010121601843 : ℝ) / 1298074214633706907132624082305024) ((325333095228109377780192053402009 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((61506249999 : ℝ) / 1000000000000) ((100251 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1061506249999 : ℝ) / 1000000000000) ((1700251 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((59688890037 : ℝ) / 1000000000000) ((60772257977 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_319.1 dlower_log_320.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((59688890037 : ℝ) / 500000000000) ((60772257977 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((114320532921 : ℝ) / 200000000000) ((286884700243 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1394308241667 : ℝ) / 500000000000) ((-2770081867027 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_321.1 dlower_log_322.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2770081867027 : ℝ) / 1000000000000) ((1394308241667 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((204977151939 : ℝ) / 1000000000000) ((207130845957 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((792869154043 : ℝ) / 1000000000000) ((795022848061 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((945754697 : ℝ) / 250000000000) ((785176797 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((195374411967 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((386822939949 : ℝ) / 1000000000000) ((193482902573 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((195374411967 : ℝ) / 500000000000) ((195374411967 : ℝ) / 500000000000) ((195374411967 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((304625588033 : ℝ) / 500000000000))
  have h11 : RB z11 ((634915376687 : ℝ) / 1000000000000) ((158787467447 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((304625588033 : ℝ) / 500000000000) ((304625588033 : ℝ) / 500000000000) ((304625588033 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-45426355403 : ℝ) / 100000000000) ((-453894292521 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_323.1 dlower_log_324.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-22571869031 : ℝ) / 62500000000) ((-44984847967 : ℝ) / 125000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((195374411967 : ℝ) / 500000000000))
  have h14 : RB z14 ((-939690319451 : ℝ) / 1000000000000) ((-939690319449 : ℝ) / 1000000000000) := rb_log (show RB ((195374411967 : ℝ) / 500000000000) ((195374411967 : ℝ) / 500000000000) ((195374411967 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_325.1 dlower_log_325.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((578540414953 : ℝ) / 1000000000000) ((115962307143 : ℝ) / 200000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((4771014467 : ℝ) / 1000000000000) ((820887111 : ℝ) / 100000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((945754697 : ℝ) / 250000000000) ((785176797 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((179612422527 : ℝ) / 125000000000)) - (z17)
  have h18 : RB z18 ((1432973496231 : ℝ) / 1000000000000) ((358279090357 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((179612422527 : ℝ) / 125000000000) ((179612422527 : ℝ) / 125000000000) ((179612422527 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((54612422527 : ℝ) / 125000000000))
  have h19 : RB z19 ((3279870746263 : ℝ) / 1000000000000) ((3280197744203 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((54612422527 : ℝ) / 125000000000) ((54612422527 : ℝ) / 125000000000) ((54612422527 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1187804014991 : ℝ) / 1000000000000) ((593951854223 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_326.1 dlower_log_327.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((470886582267 : ℝ) / 500000000000) ((944410589511 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((179612422527 : ℝ) / 125000000000))
  have h22 : RB z22 ((362487583917 : ℝ) / 1000000000000) ((362487583919 : ℝ) / 1000000000000) := rb_log (show RB ((179612422527 : ℝ) / 125000000000) ((179612422527 : ℝ) / 125000000000) ((179612422527 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_328.1 dlower_log_328.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((115857116123 : ℝ) / 200000000000) ((290961502797 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5516180129 : ℝ) / 1000000000000) ((10320340989 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1061506249999 : ℝ) / 1000000000000) ((1700251 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((563397759393 : ℝ) / 500000000000) ((225847926797 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((13836744239 : ℝ) / 7812500000) ((1774944936021 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((523075278141 : ℝ) / 500000000000))
  have h28 : RB z28 ((1852840663393 : ℝ) / 1000000000000) ((1856859632189 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((523075278141 : ℝ) / 500000000000) ((523075278141 : ℝ) / 500000000000) ((523075278141 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((945754697 : ℝ) / 250000000000) ((785176797 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((35091671433180969180609 : ℝ) / 62500000000000000000000))
  have h30 : RB z30 ((842217913 : ℝ) / 125000000000) ((6992193277 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((35091671433180969180609 : ℝ) / 62500000000000000000000) ((35091671433180969180609 : ℝ) / 62500000000000000000000) ((35091671433180969180609 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((993007806723 : ℝ) / 1000000000000) ((124157782087 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1839885243363 : ℝ) / 1000000000000) ((461087147159 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((195374411967 : ℝ) / 500000000000)) ((4771014467 : ℝ) / 1000000000000) ((820887111 : ℝ) / 100000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((179612422527 : ℝ) / 125000000000)) ((5516180129 : ℝ) / 1000000000000) ((10320340989 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((195374411967 : ℝ) / 500000000000)) (wl := ((179612422527 : ℝ) / 125000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1839885243363 : ℝ) / 1000000000000) ≤ D0q (q) * (((179612422527 : ℝ) / 125000000000) - ((195374411967 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((179612422527 : ℝ) / 125000000000) * ((195374411967 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_17 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((325333095228109377780192053402009 : ℝ) / 5192296858534827628530496329220096) ((165653740900480506906171810198323 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((62656874999 : ℝ) / 1000000000000) ((25523 : ℝ) / 400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1062656874999 : ℝ) / 1000000000000) ((425523 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((2430890319 : ℝ) / 40000000000) ((61854453499 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_329.1 dlower_log_330.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((2430890319 : ℝ) / 20000000000) ((61854453499 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((569438273561 : ℝ) / 1000000000000) ((57160266461 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-554016373409 : ℝ) / 200000000000) ((-68797113517 : ℝ) / 25000000000) := rb_log hqr (by norm_num) dlower_log_331.1 dlower_log_332.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((68797113517 : ℝ) / 25000000000) ((554016373409 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((205567308437 : ℝ) / 1000000000000) ((5192829279 : ℝ) / 25000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((19807170721 : ℝ) / 25000000000) ((794432691563 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((245367749 : ℝ) / 62500000000) ((4071397057 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((388098104769 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((1500104327 : ℝ) / 3906250000) ((76834444157 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((388098104769 : ℝ) / 1000000000000) ((388098104769 : ℝ) / 1000000000000) ((388098104769 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((611901895231 : ℝ) / 1000000000000))
  have h11 : RB z11 ((627595225157 : ℝ) / 1000000000000) ((313916514869 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((611901895231 : ℝ) / 1000000000000) ((611901895231 : ℝ) / 1000000000000) ((611901895231 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-116464966563 : ℝ) / 250000000000) ((-465481024077 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_333.1 dlower_log_334.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-185047153719 : ℝ) / 500000000000) ((-368794484451 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((388098104769 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-946497123977 : ℝ) / 1000000000000) ((-37859884959 : ℝ) / 40000000000) := rb_log (show RB ((388098104769 : ℝ) / 1000000000000) ((388098104769 : ℝ) / 1000000000000) ((388098104769 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_335.1 dlower_log_335.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((576402816537 : ℝ) / 1000000000000) ((288851319763 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((4800151927 : ℝ) / 1000000000000) ((1652873193 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((245367749 : ℝ) / 62500000000) ((4071397057 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1437615132571 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((716771867757 : ℝ) / 500000000000) ((1433689248587 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1437615132571 : ℝ) / 1000000000000) ((1437615132571 : ℝ) / 1000000000000) ((1437615132571 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((437615132571 : ℝ) / 1000000000000))
  have h19 : RB z19 ((204738083309 : ℝ) / 62500000000) ((3276141846751 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((437615132571 : ℝ) / 1000000000000) ((437615132571 : ℝ) / 1000000000000) ((437615132571 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1186564963119 : ℝ) / 1000000000000) ((593333231909 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_336.1 dlower_log_337.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((470049895921 : ℝ) / 500000000000) ((942726632839 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1437615132571 : ℝ) / 1000000000000))
  have h22 : RB z22 ((22686598919 : ℝ) / 62500000000) ((181492791353 : ℝ) / 500000000000) := rb_log (show RB ((1437615132571 : ℝ) / 1000000000000) ((1437615132571 : ℝ) / 1000000000000) ((1437615132571 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_338.1 dlower_log_338.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((36069638071 : ℝ) / 62500000000) ((115948210027 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2755772263 : ℝ) / 500000000000) ((5151388287 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1062656874999 : ℝ) / 1000000000000) ((425523 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((564619816991 : ℝ) / 500000000000) ((1131686397057 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((353454809601 : ℝ) / 200000000000) ((885551631299 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((524758513901 : ℝ) / 500000000000))
  have h28 : RB z28 ((1854784206173 : ℝ) / 1000000000000) ((1858803032093 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((524758513901 : ℝ) / 500000000000) ((524758513901 : ℝ) / 500000000000) ((524758513901 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((245367749 : ℝ) / 62500000000) ((4071397057 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((557935708338039782331099 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((1407289021 : ℝ) / 200000000000) ((912156409 : ℝ) / 125000000000) := rb_div_signed h29 (show RB ((557935708338039782331099 : ℝ) / 1000000000000000000000000) ((557935708338039782331099 : ℝ) / 1000000000000000000000000) ((557935708338039782331099 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((124087843591 : ℝ) / 125000000000) ((198592710979 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((368249875953 : ℝ) / 200000000000) ((1845723666597 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((388098104769 : ℝ) / 1000000000000)) ((4800151927 : ℝ) / 1000000000000) ((1652873193 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1437615132571 : ℝ) / 1000000000000)) ((2755772263 : ℝ) / 500000000000) ((5151388287 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((388098104769 : ℝ) / 1000000000000)) (wl := ((1437615132571 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((368249875953 : ℝ) / 200000000000) ≤ D0q (q) * (((1437615132571 : ℝ) / 1000000000000) - ((388098104769 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1437615132571 : ℝ) / 1000000000000) * ((388098104769 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_18 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((165653740900480506906171810198323 : ℝ) / 2596148429267413814265248164610048) ((168640934186906324922247593695641 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((63807499999 : ℝ) / 1000000000000) ((103933 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1063807499999 : ℝ) / 1000000000000) ((1703933 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((61854453497 : ℝ) / 1000000000000) ((3146773957 : ℝ) / 50000000000) := rb_log h1 (by norm_num) dlower_log_339.1 dlower_log_340.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((61854453497 : ℝ) / 500000000000) ((3146773957 : ℝ) / 25000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((567276222279 : ℝ) / 1000000000000) ((284719136783 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1375942270349 : ℝ) / 500000000000) ((-136700622373 : ℝ) / 50000000000) := rb_log hqr (by norm_num) dlower_log_341.1 dlower_log_342.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((136700622373 : ℝ) / 50000000000) ((1375942270349 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((206140996793 : ℝ) / 1000000000000) ((104139663683 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((395860336317 : ℝ) / 500000000000) ((793859003207 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((63615579 : ℝ) / 15625000000) ((1054889501 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((7708518613 : ℝ) / 20000000000)) - (z9)
  have h10 : RB z10 ((190603186323 : ℝ) / 500000000000) ((190677266797 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((7708518613 : ℝ) / 20000000000) ((7708518613 : ℝ) / 20000000000) ((7708518613 : ℝ) / 20000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((12291481387 : ℝ) / 20000000000))
  have h11 : RB z11 ((310138672991 : ℝ) / 500000000000) ((310259212529 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((12291481387 : ℝ) / 20000000000) ((12291481387 : ℝ) / 20000000000) ((12291481387 : ℝ) / 20000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-238794284369 : ℝ) / 500000000000) ((-59649997611 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_343.1 dlower_log_344.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-189568992561 : ℝ) / 500000000000) ((-377809089849 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((7708518613 : ℝ) / 20000000000))
  have h14 : RB z14 ((-59587890177 : ℝ) / 62500000000) ((-95340624283 : ℝ) / 100000000000) := rb_log (show RB ((7708518613 : ℝ) / 20000000000) ((7708518613 : ℝ) / 20000000000) ((7708518613 : ℝ) / 20000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_345.1 dlower_log_345.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((143567064427 : ℝ) / 250000000000) ((575597152983 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2414992071 : ℝ) / 500000000000) ((520058169 : ℝ) / 62500000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((63615579 : ℝ) / 15625000000) ((1054889501 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((719170297839 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((717060518837 : ℝ) / 500000000000) ((717134599311 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((719170297839 : ℝ) / 500000000000) ((719170297839 : ℝ) / 500000000000) ((719170297839 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((219170297839 : ℝ) / 500000000000))
  have h19 : RB z19 ((163585240771 : ℝ) / 50000000000) ((818010704897 : ℝ) / 250000000000) := rb_div_signed h18 (show RB ((219170297839 : ℝ) / 500000000000) ((219170297839 : ℝ) / 500000000000) ((219170297839 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1185311199333 : ℝ) / 1000000000000) ((1185414505327 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_346.1 dlower_log_347.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((58652211251 : ℝ) / 62500000000) ((941051977587 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((719170297839 : ℝ) / 500000000000))
  have h22 : RB z22 ((2839766289 : ℝ) / 7812500000) ((181745042497 : ℝ) / 500000000000) := rb_log (show RB ((719170297839 : ℝ) / 500000000000) ((719170297839 : ℝ) / 500000000000) ((719170297839 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_348.1 dlower_log_348.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((287472647511 : ℝ) / 500000000000) ((115512378519 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((344188841 : ℝ) / 62500000000) ((2571417579 : ℝ) / 250000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1063807499999 : ℝ) / 1000000000000) ((1703933 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((565843198527 : ℝ) / 500000000000) ((283533952001 : ℝ) / 250000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1763457238441 : ℝ) / 1000000000000) ((1767274048011 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((263228666257 : ℝ) / 250000000000))
  have h28 : RB z28 ((116048124219 : ℝ) / 62500000000) ((74431550491 : ℝ) / 40000000000) := rb_widen (rb_mul h27 (show RB ((263228666257 : ℝ) / 250000000000) ((263228666257 : ℝ) / 250000000000) ((263228666257 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((63615579 : ℝ) / 15625000000) ((1054889501 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((5543737626808685177307 : ℝ) / 10000000000000000000000))
  have h30 : RB z30 ((7344137349 : ℝ) / 1000000000000) ((304455823 : ℝ) / 40000000000) := rb_div_signed h29 (show RB ((5543737626808685177307 : ℝ) / 10000000000000000000000) ((5543737626808685177307 : ℝ) / 10000000000000000000000) ((5543737626808685177307 : ℝ) / 10000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((39695544177 : ℝ) / 40000000000) ((992655862651 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1842637376637 : ℝ) / 1000000000000) ((461780718507 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((7708518613 : ℝ) / 20000000000)) ((2414992071 : ℝ) / 500000000000) ((520058169 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((719170297839 : ℝ) / 500000000000)) ((344188841 : ℝ) / 62500000000) ((2571417579 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((7708518613 : ℝ) / 20000000000)) (wl := ((719170297839 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1842637376637 : ℝ) / 1000000000000) ≤ D0q (q) * (((719170297839 : ℝ) / 500000000000) - ((7708518613 : ℝ) / 20000000000)) * (1 - (q) ^ 2 / (((719170297839 : ℝ) / 500000000000) * ((7708518613 : ℝ) / 20000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_19 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((168640934186906324922247593695641 : ℝ) / 2596148429267413814265248164610048) ((343256254946664285876646754385919 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((64958124999 : ℝ) / 1000000000000) ((52887 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1064958124999 : ℝ) / 1000000000000) ((852887 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((31467739569 : ℝ) / 500000000000) ((32007668713 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_349.1 dlower_log_350.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((31467739569 : ℝ) / 250000000000) ((32007668713 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((565116505707 : ℝ) / 1000000000000) ((141819055571 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1367006223739 : ℝ) / 500000000000) ((-543290833139 : ℝ) / 200000000000) := rb_log hqr (by norm_num) dlower_log_351.1 dlower_log_352.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((543290833139 : ℝ) / 200000000000) ((1367006223739 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((206698585527 : ℝ) / 1000000000000) ((208829668267 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((791170331733 : ℝ) / 1000000000000) ((793301414473 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((4219558003 : ℝ) / 1000000000000) ((4370366827 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((95683044781 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((378361812297 : ℝ) / 1000000000000) ((378512621121 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((95683044781 : ℝ) / 250000000000) ((95683044781 : ℝ) / 250000000000) ((95683044781 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((154316955219 : ℝ) / 250000000000))
  have h11 : RB z11 ((612962152733 : ℝ) / 1000000000000) ((153301617353 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((154316955219 : ℝ) / 250000000000) ((154316955219 : ℝ) / 250000000000) ((154316955219 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-61181510751 : ℝ) / 125000000000) ((-489053581791 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_353.1 dlower_log_354.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-388283032147 : ℝ) / 1000000000000) ((-19346234227 : ℝ) / 50000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((95683044781 : ℝ) / 250000000000))
  have h14 : RB z14 ((-960419805623 : ℝ) / 1000000000000) ((-960419805621 : ℝ) / 1000000000000) := rb_log (show RB ((95683044781 : ℝ) / 250000000000) ((95683044781 : ℝ) / 250000000000) ((95683044781 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_355.1 dlower_log_355.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((286068386737 : ℝ) / 500000000000) ((573495121083 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((486055119 : ℝ) / 100000000000) ((523663461 : ℝ) / 62500000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((4219558003 : ℝ) / 1000000000000) ((4370366827 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((143907558597 : ℝ) / 100000000000)) - (z17)
  have h18 : RB z18 ((1434705219143 : ℝ) / 1000000000000) ((1434856027967 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((143907558597 : ℝ) / 100000000000) ((143907558597 : ℝ) / 100000000000) ((143907558597 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((43907558597 : ℝ) / 100000000000))
  have h19 : RB z19 ((3267558627687 : ℝ) / 1000000000000) ((3267902096623 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((43907558597 : ℝ) / 100000000000) ((43907558597 : ℝ) / 100000000000) ((43907558597 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((296010777257 : ℝ) / 250000000000) ((296037054589 : ℝ) / 250000000000) := rb_log h19 (by norm_num) dlower_log_356.1 dlower_log_357.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((187355955871 : ℝ) / 200000000000) ((117423307071 : ℝ) / 125000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((143907558597 : ℝ) / 100000000000))
  have h22 : RB z22 ((182000476629 : ℝ) / 500000000000) ((18200047663 : ℝ) / 50000000000) := rb_log (show RB ((143907558597 : ℝ) / 100000000000) ((143907558597 : ℝ) / 100000000000) ((143907558597 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_358.1 dlower_log_358.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((114555765219 : ℝ) / 200000000000) ((57538550331 : ℝ) / 100000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5502603811 : ℝ) / 1000000000000) ((10268997603 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1064958124999 : ℝ) / 1000000000000) ((852887 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1134135808001 : ℝ) / 1000000000000) ((1136587866827 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((439913195093 : ℝ) / 250000000000) ((881728619223 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((528171703423 : ℝ) / 500000000000))
  have h28 : RB z28 ((464699403221 : ℝ) / 250000000000) ((116426026693 : ℝ) / 62500000000) := rb_widen (rb_mul h27 (show RB ((528171703423 : ℝ) / 500000000000) ((528171703423 : ℝ) / 500000000000) ((528171703423 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((4219558003 : ℝ) / 1000000000000) ((4370366827 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((13769513373561132532257 : ℝ) / 25000000000000000000000))
  have h30 : RB z30 ((3830525713 : ℝ) / 500000000000) ((7934860711 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((13769513373561132532257 : ℝ) / 25000000000000000000000) ((13769513373561132532257 : ℝ) / 25000000000000000000000) ((13769513373561132532257 : ℝ) / 25000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((992065139289 : ℝ) / 1000000000000) ((496169474287 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((368809662547 : ℝ) / 200000000000) ((1848545294643 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((95683044781 : ℝ) / 250000000000)) ((486055119 : ℝ) / 100000000000) ((523663461 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((143907558597 : ℝ) / 100000000000)) ((5502603811 : ℝ) / 1000000000000) ((10268997603 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((95683044781 : ℝ) / 250000000000)) (wl := ((143907558597 : ℝ) / 100000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((368809662547 : ℝ) / 200000000000) ≤ D0q (q) * (((143907558597 : ℝ) / 100000000000) - ((95683044781 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((143907558597 : ℝ) / 100000000000) * ((95683044781 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
