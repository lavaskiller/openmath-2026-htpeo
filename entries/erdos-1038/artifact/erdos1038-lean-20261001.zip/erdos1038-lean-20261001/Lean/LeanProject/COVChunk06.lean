import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk02
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_30 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5037 : ℝ) / 8237) ((10107 : ℝ) / 16507))
    (hq : RB (qa a) ((559277 : ℝ) / 50000000) ((113541 : ℝ) / 10000000))
    (hd : RB (D0a a) ((39106911 : ℝ) / 20000000) ((195599749 : ℝ) / 100000000))
    : certE k a ((10609679 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((42840869 : ℝ) / 100000000) ∧ 0 < certE k a ((32101809 : ℝ) / 25000000) ∧ certE k a ((64295559 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((12511 : ℝ) / 100000000) ((3223 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((10609679 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((1325807 : ℝ) / 3125000) ((8485241 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((10609679 : ℝ) / 25000000) ((10609679 : ℝ) / 25000000) ((10609679 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((14390321 : ℝ) / 25000000))
  have h3 : RB z3 ((14741097 : ℝ) / 20000000) ((18426537 : ℝ) / 25000000) := rb_div_signed h2 (show RB ((14390321 : ℝ) / 25000000) ((14390321 : ℝ) / 25000000) ((14390321 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-30509297 : ℝ) / 100000000) ((-30508397 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_540.1 cov_log_541.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-18680407 : ℝ) / 100000000) ((-116601 : ℝ) / 625000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((10609679 : ℝ) / 25000000))
  have h6 : RB z6 ((-42855457 : ℝ) / 50000000) ((-1339233 : ℝ) / 1562500) := rb_log (show RB ((10609679 : ℝ) / 25000000) ((10609679 : ℝ) / 25000000) ((10609679 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_542.1 cov_log_542.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((13406101 : ℝ) / 20000000) ((33527377 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16764173 : ℝ) / 25000000) ((6709003 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_543.1 cov_log_544.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-2381 : ℝ) / 4000000) ((-969 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((12511 : ℝ) / 100000000) ((3223 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42840869 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((42827977 : ℝ) / 100000000) ((21414179 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((42840869 : ℝ) / 100000000) ((42840869 : ℝ) / 100000000) ((42840869 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57159131 : ℝ) / 100000000))
  have h12 : RB z12 ((3746381 : ℝ) / 5000000) ((2341509 : ℝ) / 3125000) := rb_div_signed h11 (show RB ((57159131 : ℝ) / 100000000) ((57159131 : ℝ) / 100000000) ((57159131 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-28864761 : ℝ) / 100000000) ((-7215967 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_545.1 cov_log_546.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-17673481 : ℝ) / 100000000) ((-4412629 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42840869 : ℝ) / 100000000))
  have h15 : RB z15 ((-84767767 : ℝ) / 100000000) ((-16953553 : ℝ) / 20000000) := rb_log (show RB ((42840869 : ℝ) / 100000000) ((42840869 : ℝ) / 100000000) ((42840869 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_547.1 cov_log_547.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16773571 : ℝ) / 25000000) ((67117251 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16764173 : ℝ) / 25000000) ((6709003 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_543.1 cov_log_544.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2127 : ℝ) / 50000000) ((60559 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((12511 : ℝ) / 100000000) ((3223 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((32101809 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((16049293 : ℝ) / 12500000) ((5135789 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((32101809 : ℝ) / 25000000) ((32101809 : ℝ) / 25000000) ((32101809 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((7101809 : ℝ) / 25000000))
  have h21 : RB z21 ((451977601 : ℝ) / 100000000) ((451978943 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((7101809 : ℝ) / 25000000) ((7101809 : ℝ) / 25000000) ((7101809 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((150846243 : ℝ) / 100000000) ((150846543 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_548.1 cov_log_549.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92243841 : ℝ) / 100000000) ((92361181 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((32101809 : ℝ) / 25000000))
  have h24 : RB z24 ((5000731 : ℝ) / 20000000) ((3125457 : ℝ) / 12500000) := rb_log (show RB ((32101809 : ℝ) / 25000000) ((32101809 : ℝ) / 25000000) ((32101809 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_550.1 cov_log_550.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((13448037 : ℝ) / 20000000) ((33678763 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16764173 : ℝ) / 25000000) ((6709003 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_543.1 cov_log_544.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((30031 : ℝ) / 20000000) ((150417 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((12511 : ℝ) / 100000000) ((3223 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((64295559 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((64289113 : ℝ) / 50000000) ((128578607 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((64295559 : ℝ) / 50000000) ((64295559 : ℝ) / 50000000) ((64295559 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((14295559 : ℝ) / 50000000))
  have h30 : RB z30 ((449713879 : ℝ) / 100000000) ((449715213 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((14295559 : ℝ) / 50000000) ((14295559 : ℝ) / 50000000) ((14295559 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((18793017 : ℝ) / 12500000) ((37586109 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_551.1 cov_log_552.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((45968399 : ℝ) / 50000000) ((23013437 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((64295559 : ℝ) / 50000000))
  have h33 : RB z33 ((5029351 : ℝ) / 20000000) ((6286689 : ℝ) / 25000000) := rb_log (show RB ((64295559 : ℝ) / 50000000) ((64295559 : ℝ) / 50000000) ((64295559 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_553.1 cov_log_553.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33395021 : ℝ) / 50000000) ((66906993 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16764173 : ℝ) / 25000000) ((6709003 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_543.1 cov_log_544.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-74997 : ℝ) / 25000000) ((-149699 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((10609679 : ℝ) / 25000000)) ((-2381 : ℝ) / 4000000) ((-969 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42840869 : ℝ) / 100000000)) ((2127 : ℝ) / 50000000) ((60559 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((32101809 : ℝ) / 25000000)) ((30031 : ℝ) / 20000000) ((150417 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((64295559 : ℝ) / 50000000)) ((-74997 : ℝ) / 25000000) ((-149699 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_30 {k A q d vp vm : ℝ}
    (hk : RB k ((5037 : ℝ) / 3200) ((10107 : ℝ) / 6400))
    (hA : RB A ((5037 : ℝ) / 8237) ((10107 : ℝ) / 16507))
    (hq : RB q ((559277 : ℝ) / 50000000) ((113541 : ℝ) / 10000000))
    (hd : RB d ((39106911 : ℝ) / 20000000) ((195599749 : ℝ) / 100000000))
    (hp : RB vp ((10609679 : ℝ) / 25000000) ((42840869 : ℝ) / 100000000))
    (hm : RB vm ((32101809 : ℝ) / 25000000) ((64295559 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((12511 : ℝ) / 100000000) ((3223 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((24996777 : ℝ) / 25000000) ((99987489 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((3057151 : ℝ) / 5000000) ((6122091 : ℝ) / 10000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((29203 : ℝ) / 100000000) ((15189 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49984811 : ℝ) / 50000000) ((99970797 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57159131 : ℝ) / 100000000) ((14390321 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57141767 : ℝ) / 100000000) ((2301779 : ℝ) / 4000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53126751 : ℝ) / 50000000) ((107138637 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3126751 : ℝ) / 50000000) ((7138637 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((24996777 : ℝ) / 25000000) ((99987489 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((3057151 : ℝ) / 5000000) ((6122091 : ℝ) / 10000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((9729 : ℝ) / 100000000) ((251 : ℝ) / 2500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((2499749 : ℝ) / 2500000) ((99990271 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((7101809 : ℝ) / 25000000) ((14295559 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28404383 : ℝ) / 100000000) ((28588337 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((106937 : ℝ) / 50000) ((107766661 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((156937 : ℝ) / 50000) ((157766661 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((350206909 : ℝ) / 25000000) ((1599103991 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31692373 : ℝ) / 100000000) ((31859919 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5037 : ℝ) / 1600) ((10107 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((3521347 : ℝ) / 100000000) ((1793061 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50559277 : ℝ) / 50000000) ((10113541 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1740907 : ℝ) / 50000000) ((1773227 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((51740907 : ℝ) / 50000000) ((51773227 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((85566367 : ℝ) / 100000000) ((43076201 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((83655907 : ℝ) / 50000000) ((168513883 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27247191 : ℝ) / 50000000) ((55089553 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((2271 : ℝ) / 10000000) ((11829 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49988171 : ℝ) / 50000000) ((9997729 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((167272231 : ℝ) / 100000000) ((84237807 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((39106911 : ℝ) / 10000000) ((195599749 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4374319 : ℝ) / 100000000) ((4441719 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8237 : ℝ) / 3200) ((16507 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((847993 : ℝ) / 50000000) ((13481 : ℝ) / 781250) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((52219 : ℝ) / 2000000) ((2675411 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((2052219 : ℝ) / 2000000) ((102675411 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((287480509 : ℝ) / 20000000) ((410471649 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((869853 : ℝ) / 100000000) ((442113 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100869853 : ℝ) / 100000000) ((50442113 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((639361 : ℝ) / 2000000) ((32141633 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((293874119 : ℝ) / 20000000) ((1674028229 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((24920319 : ℝ) / 100000000) ((902703 : ℝ) / 3125000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8237 : ℝ) / 3200) ((16507 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((51740907 : ℝ) / 25000000) ((51773227 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1432520009 : ℝ) / 100000000) ((163096391 : ℝ) / 10000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1482397691 : ℝ) / 50000000) ((337761059 : ℝ) / 10000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1905239 : ℝ) / 25000000) ((2174871 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-257426841 : ℝ) / 100000000) ((-244190647 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_554.1 cov_log_555.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2187159 : ℝ) / 100000000) ((111043 : ℝ) / 5000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-9556417 : ℝ) / 2500000) ((-380727567 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_556.1 cov_log_557.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16764173 : ℝ) / 25000000) ((6709003 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_543.1 cov_log_544.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((1649241 : ℝ) / 1562500) ((52974917 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-34588157 : ℝ) / 12500000) ((-274777733 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((14967433 : ℝ) / 100000000) ((16170817 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((12953659 : ℝ) / 25000000) ((64890089 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-11244531 : ℝ) / 5000000) ((-52471911 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((51740907 : ℝ) / 50000000) ((51773227 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-257426841 : ℝ) / 100000000) ((-244190647 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-11244531 : ℝ) / 5000000) ((-52471911 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((76 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((52219 : ℝ) / 2000000) ((2675411 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((102675411 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((76 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-228356633 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((76 : ℝ) / 25) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_8, cov_h_6]
  have hP : ((7959737 : ℝ) / 1250000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((52471911 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((52471911 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1391 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1391 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1411 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1411 : ℝ) / 500)) (lo := ((1391 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1431 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1431 : ℝ) / 500)) (lo := ((1411 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1451 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1451 : ℝ) / 500)) (lo := ((1431 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1471 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1471 : ℝ) / 500)) (lo := ((1451 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1491 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1491 : ℝ) / 500)) (lo := ((1471 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1511 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1511 : ℝ) / 500)) (lo := ((1491 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((76 : ℝ) / 25)) (lo := ((1511 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_30 {k : ℝ} (hk : RB k ((5037 : ℝ) / 3200) ((10107 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((5037 : ℝ) / 8237) ((10107 : ℝ) / 16507) ∧
    RB (qa (r1A k)) ((559277 : ℝ) / 50000000) ((113541 : ℝ) / 10000000) ∧ RB (D0a (r1A k)) ((39106911 : ℝ) / 20000000) ((195599749 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((19675781 : ℝ) / 50000000) ((39480469 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((191119531 : ℝ) / 100000000) ((95624219 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138245987 : ℝ) / 100000000) ((138292603 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279667343 : ℝ) / 100000000) ((6992849 : ℝ) / 2500000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139833671 : ℝ) / 100000000) ((6992849 : ℝ) / 5000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((39106911 : ℝ) / 20000000) ((195599749 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4375781 : ℝ) / 50000000) ((8880469 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((218789 : ℝ) / 10000000) ((1110059 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((559277 : ℝ) / 50000000) ((113541 : ℝ) / 10000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((39106911 : ℝ) / 20000000) ((195599749 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((559277 : ℝ) / 50000000) ((113541 : ℝ) / 10000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5037 : ℝ) / 8237) ((10107 : ℝ) / 16507) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_30 {k : ℝ} (hk : RB k ((5037 : ℝ) / 3200) ((10107 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_30 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_30 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((10609679 : ℝ) / 25000000)) (ph := ((42840869 : ℝ) / 100000000)) (ml := ((32101809 : ℝ) / 25000000)) (mh := ((64295559 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_30 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_31 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10107 : ℝ) / 16507) ((507 : ℝ) / 827))
    (hq : RB (qa a) ((70963 : ℝ) / 6250000) ((46091 : ℝ) / 4000000))
    (hd : RB (D0a a) ((48867339 : ℝ) / 25000000) ((97767281 : ℝ) / 50000000))
    : certE k a ((21190047 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((42776421 : ℝ) / 100000000) ∧ 0 < certE k a ((64234351 : ℝ) / 50000000) ∧ certE k a ((32163017 : ℝ) / 25000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((12891 : ℝ) / 100000000) ((6639 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((21190047 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((1323963 : ℝ) / 3125000) ((42367203 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((21190047 : ℝ) / 50000000) ((21190047 : ℝ) / 50000000) ((21190047 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((28809953 : ℝ) / 50000000))
  have h3 : RB z3 ((73528089 : ℝ) / 100000000) ((36764381 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((28809953 : ℝ) / 50000000) ((28809953 : ℝ) / 50000000) ((28809953 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-30750269 : ℝ) / 100000000) ((-30749353 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_558.1 cov_log_559.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-18851737 : ℝ) / 100000000) ((-18827389 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((21190047 : ℝ) / 50000000))
  have h6 : RB z6 ((-85849143 : ℝ) / 100000000) ((-85849141 : ℝ) / 100000000) := rb_log (show RB ((21190047 : ℝ) / 50000000) ((21190047 : ℝ) / 50000000) ((21190047 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_560.1 cov_log_560.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((16749351 : ℝ) / 25000000) ((33510877 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67023343 : ℝ) / 100000000) ((33528349 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_561.1 cov_log_562.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-29647 : ℝ) / 50000000) ((-1589 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((12891 : ℝ) / 100000000) ((6639 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42776421 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((42763143 : ℝ) / 100000000) ((4276353 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((42776421 : ℝ) / 100000000) ((42776421 : ℝ) / 100000000) ((42776421 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57223579 : ℝ) / 100000000))
  have h12 : RB z12 ((37364967 : ℝ) / 50000000) ((74730611 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((57223579 : ℝ) / 100000000) ((57223579 : ℝ) / 100000000) ((57223579 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-14564473 : ℝ) / 50000000) ((-29128039 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_563.1 cov_log_564.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-1785777 : ℝ) / 10000000) ((-17834681 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42776421 : ℝ) / 100000000))
  have h15 : RB z15 ((-21229579 : ℝ) / 25000000) ((-42459157 : ℝ) / 50000000) := rb_log (show RB ((42776421 : ℝ) / 100000000) ((42776421 : ℝ) / 100000000) ((42776421 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_565.1 cov_log_565.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((1047821 : ℝ) / 1562500) ((13416727 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67023343 : ℝ) / 100000000) ((33528349 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_561.1 cov_log_562.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1923 : ℝ) / 50000000) ((15073 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((12891 : ℝ) / 100000000) ((6639 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((64234351 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((501779 : ℝ) / 390625) ((128455811 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((64234351 : ℝ) / 50000000) ((64234351 : ℝ) / 50000000) ((64234351 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((14234351 : ℝ) / 50000000))
  have h21 : RB z21 ((4512163 : ℝ) / 1000000) ((451217661 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((14234351 : ℝ) / 50000000) ((14234351 : ℝ) / 50000000) ((14234351 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((150677663 : ℝ) / 100000000) ((9417373 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_566.1 cov_log_567.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92257777 : ℝ) / 100000000) ((92374523 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((64234351 : ℝ) / 50000000))
  have h24 : RB z24 ((3131439 : ℝ) / 12500000) ((25051513 : ℝ) / 100000000) := rb_log (show RB ((64234351 : ℝ) / 50000000) ((64234351 : ℝ) / 50000000) ((64234351 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_568.1 cov_log_568.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((8400783 : ℝ) / 12500000) ((67323011 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67023343 : ℝ) / 100000000) ((33528349 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_561.1 cov_log_562.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((74783 : ℝ) / 50000000) ((74917 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((12891 : ℝ) / 100000000) ((6639 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((32163017 : ℝ) / 25000000)) - (z28)
  have h29 : RB z29 ((12863879 : ℝ) / 10000000) ((128639177 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((32163017 : ℝ) / 25000000) ((32163017 : ℝ) / 25000000) ((32163017 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((7163017 : ℝ) / 25000000))
  have h30 : RB z30 ((112242151 : ℝ) / 25000000) ((112242489 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((7163017 : ℝ) / 25000000) ((7163017 : ℝ) / 25000000) ((7163017 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((150178277 : ℝ) / 100000000) ((150178581 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_569.1 cov_log_570.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91952011 : ℝ) / 100000000) ((92068369 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((32163017 : ℝ) / 25000000))
  have h33 : RB z33 ((12597071 : ℝ) / 50000000) ((25194143 : ℝ) / 100000000) := rb_log (show RB ((32163017 : ℝ) / 25000000) ((32163017 : ℝ) / 25000000) ((32163017 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_571.1 cov_log_571.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((16689467 : ℝ) / 25000000) ((66874227 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67023343 : ℝ) / 100000000) ((33528349 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_561.1 cov_log_562.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-29883 : ℝ) / 10000000) ((-37279 : ℝ) / 25000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((21190047 : ℝ) / 50000000)) ((-29647 : ℝ) / 50000000) ((-1589 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42776421 : ℝ) / 100000000)) ((1923 : ℝ) / 50000000) ((15073 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((64234351 : ℝ) / 50000000)) ((74783 : ℝ) / 50000000) ((74917 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((32163017 : ℝ) / 25000000)) ((-29883 : ℝ) / 10000000) ((-37279 : ℝ) / 25000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_31 {k A q d vp vm : ℝ}
    (hk : RB k ((10107 : ℝ) / 6400) ((507 : ℝ) / 320))
    (hA : RB A ((10107 : ℝ) / 16507) ((507 : ℝ) / 827))
    (hq : RB q ((70963 : ℝ) / 6250000) ((46091 : ℝ) / 4000000))
    (hd : RB d ((48867339 : ℝ) / 25000000) ((97767281 : ℝ) / 50000000))
    (hp : RB vp ((21190047 : ℝ) / 50000000) ((42776421 : ℝ) / 100000000))
    (hm : RB vm ((64234351 : ℝ) / 50000000) ((32163017 : ℝ) / 25000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((12891 : ℝ) / 100000000) ((6639 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49993361 : ℝ) / 50000000) ((99987109 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((61220439 : ℝ) / 100000000) ((61298023 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((6027 : ℝ) / 20000000) ((31331 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99968669 : ℝ) / 100000000) ((19993973 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57223579 : ℝ) / 100000000) ((28809953 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((1144113 : ℝ) / 2000000) ((57602543 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((13285099 : ℝ) / 12500000) ((837139 : ℝ) / 781250) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((785099 : ℝ) / 12500000) ((55889 : ℝ) / 781250) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49993361 : ℝ) / 50000000) ((99987109 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((61220439 : ℝ) / 100000000) ((61298023 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((501 : ℝ) / 5000000) ((323 : ℝ) / 3125000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((3124677 : ℝ) / 3125000) ((4999499 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((14234351 : ℝ) / 50000000) ((7163017 : ℝ) / 25000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28465759 : ℝ) / 100000000) ((14324599 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((213689887 : ℝ) / 100000000) ((430679 : ℝ) / 200000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((313689887 : ℝ) / 100000000) ((630679 : ℝ) / 200000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((349465011 : ℝ) / 25000000) ((796077947 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31711853 : ℝ) / 100000000) ((15939309 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10107 : ℝ) / 3200) ((507 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((717223 : ℝ) / 20000000) ((456409 : ℝ) / 12500000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((6320963 : ℝ) / 6250000) ((4046091 : ℝ) / 4000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3545263 : ℝ) / 100000000) ((3610281 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((103545263 : ℝ) / 100000000) ((103610281 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((85692281 : ℝ) / 100000000) ((43135987 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((167502149 : ℝ) / 100000000) ((168691527 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13611289 : ℝ) / 25000000) ((55032751 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((183 : ℝ) / 781250) ((6097 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24993903 : ℝ) / 25000000) ((781067 : ℝ) / 781250) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((83730649 : ℝ) / 50000000) ((168652013 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((48867339 : ℝ) / 12500000) ((97767281 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4438749 : ℝ) / 100000000) ((281637 : ℝ) / 6250000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16507 : ℝ) / 6400) ((827 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((429383 : ℝ) / 25000000) ((436779 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((663571 : ℝ) / 25000000) ((2718907 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25663571 : ℝ) / 25000000) ((102718907 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1434963219 : ℝ) / 100000000) ((1635445133 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((882541 : ℝ) / 100000000) ((896931 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100882541 : ℝ) / 100000000) ((100896931 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31991723 : ℝ) / 100000000) ((8041137 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((733477471 : ℝ) / 50000000) ((1667609681 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((1259771 : ℝ) / 5000000) ((7283769 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16507 : ℝ) / 6400) ((827 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((103545263 : ℝ) / 50000000) ((103610281 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1429571897 : ℝ) / 100000000) ((101502157 : ℝ) / 6250000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2960507961 : ℝ) / 100000000) ((3365333443 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((95801 : ℝ) / 1250000) ((8729499 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-10274503 : ℝ) / 4000000) ((-12192311 : ℝ) / 5000000) := rb_log h47 (by norm_num) cov_log_572.1 cov_log_573.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1109687 : ℝ) / 50000000) ((281637 : ℝ) / 12500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-190397253 : ℝ) / 50000000) ((-379286491 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_574.1 cov_log_575.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67023343 : ℝ) / 100000000) ((33528349 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_561.1 cov_log_562.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((105844519 : ℝ) / 100000000) ((26560739 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-274949987 : ℝ) / 100000000) ((-54608707 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((7395517 : ℝ) / 50000000) ((63927 : ℝ) / 400000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((25383551 : ℝ) / 50000000) ((15857793 : ℝ) / 25000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-44836577 : ℝ) / 20000000) ((-209612363 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((103545263 : ℝ) / 100000000) ((103610281 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-10274503 : ℝ) / 4000000) ((-12192311 : ℝ) / 5000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-44836577 : ℝ) / 20000000) ((-209612363 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((76 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((663571 : ℝ) / 25000000) ((2718907 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((102718907 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((76 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-227792367 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((76 : ℝ) / 25) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_8, cov_h_6]
  have hP : ((79444003 : ℝ) / 12500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((209612363 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((209612363 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((348 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((348 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((353 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((353 : ℝ) / 125)) (lo := ((348 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((358 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((358 : ℝ) / 125)) (lo := ((353 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((363 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((363 : ℝ) / 125)) (lo := ((358 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((368 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((368 : ℝ) / 125)) (lo := ((363 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((373 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((373 : ℝ) / 125)) (lo := ((368 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((378 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((378 : ℝ) / 125)) (lo := ((373 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((76 : ℝ) / 25)) (lo := ((378 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_31 {k : ℝ} (hk : RB k ((10107 : ℝ) / 6400) ((507 : ℝ) / 320)) :
    RB (k / (k + 1)) ((10107 : ℝ) / 16507) ((507 : ℝ) / 827) ∧
    RB (qa (r1A k)) ((70963 : ℝ) / 6250000) ((46091 : ℝ) / 4000000) ∧ RB (D0a (r1A k)) ((48867339 : ℝ) / 25000000) ((97767281 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((9870117 : ℝ) / 25000000) ((507 : ℝ) / 1280) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((61117 : ℝ) / 32000) ((47779883 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138199357 : ℝ) / 100000000) ((138245989 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279620713 : ℝ) / 100000000) ((139833673 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((34952589 : ℝ) / 25000000) ((139833673 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((48867339 : ℝ) / 25000000) ((97767281 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2220117 : ℝ) / 25000000) ((2883 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2220117 : ℝ) / 100000000) ((281543 : ℝ) / 12500000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((70963 : ℝ) / 6250000) ((46091 : ℝ) / 4000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((48867339 : ℝ) / 25000000) ((97767281 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((70963 : ℝ) / 6250000) ((46091 : ℝ) / 4000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10107 : ℝ) / 16507) ((507 : ℝ) / 827) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_31 {k : ℝ} (hk : RB k ((10107 : ℝ) / 6400) ((507 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_31 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_31 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((21190047 : ℝ) / 50000000)) (ph := ((42776421 : ℝ) / 100000000)) (ml := ((64234351 : ℝ) / 50000000)) (mh := ((32163017 : ℝ) / 25000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_31 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_32 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((507 : ℝ) / 827) ((10173 : ℝ) / 16573))
    (hq : RB (qa a) ((576137 : ℝ) / 50000000) ((4567 : ℝ) / 390625))
    (hd : RB (D0a a) ((39080829 : ℝ) / 20000000) ((195469363 : ℝ) / 100000000))
    : certE k a ((42322287 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((10678233 : ℝ) / 25000000) ∧ 0 < certE k a ((64264997 : ℝ) / 50000000) ∧ certE k a ((128712849 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((13277 : ℝ) / 100000000) ((1367 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42322287 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((42308617 : ℝ) / 100000000) ((4230901 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((42322287 : ℝ) / 100000000) ((42322287 : ℝ) / 100000000) ((42322287 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57677713 : ℝ) / 100000000))
  have h3 : RB z3 ((18338373 : ℝ) / 25000000) ((2934167 : ℝ) / 4000000) := rb_div_signed h2 (show RB ((57677713 : ℝ) / 100000000) ((57677713 : ℝ) / 100000000) ((57677713 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-3873501 : ℝ) / 12500000) ((-7746769 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_576.1 cov_log_577.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-19021361 : ℝ) / 100000000) ((-18996913 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42322287 : ℝ) / 100000000))
  have h6 : RB z6 ((-85985637 : ℝ) / 100000000) ((-17197127 : ℝ) / 20000000) := rb_log (show RB ((42322287 : ℝ) / 100000000) ((42322287 : ℝ) / 100000000) ((42322287 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_578.1 cov_log_578.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33482137 : ℝ) / 50000000) ((16747181 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((8373747 : ℝ) / 12500000) ((16755837 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_579.1 cov_log_580.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-29537 : ℝ) / 50000000) ((-313 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((13277 : ℝ) / 100000000) ((1367 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((10678233 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((21349631 : ℝ) / 50000000) ((8539931 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((10678233 : ℝ) / 25000000) ((10678233 : ℝ) / 25000000) ((10678233 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((14321767 : ℝ) / 25000000))
  have h12 : RB z12 ((74535603 : ℝ) / 100000000) ((7453629 : ℝ) / 10000000) := rb_div_signed h11 (show RB ((14321767 : ℝ) / 25000000) ((14321767 : ℝ) / 25000000) ((14321767 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-29389329 : ℝ) / 100000000) ((-14694203 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_581.1 cov_log_582.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4510011 : ℝ) / 25000000) ((-9008417 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((10678233 : ℝ) / 25000000))
  have h15 : RB z15 ((-85066847 : ℝ) / 100000000) ((-17013369 : ℝ) / 20000000) := rb_log (show RB ((10678233 : ℝ) / 25000000) ((10678233 : ℝ) / 25000000) ((10678233 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_583.1 cov_log_583.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67026801 : ℝ) / 100000000) ((67050013 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((8373747 : ℝ) / 12500000) ((16755837 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_579.1 cov_log_580.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((3453 : ℝ) / 100000000) ((60037 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((13277 : ℝ) / 100000000) ((1367 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((64264997 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((32129081 : ℝ) / 25000000) ((128516717 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((64264997 : ℝ) / 50000000) ((64264997 : ℝ) / 50000000) ((64264997 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((14264997 : ℝ) / 50000000))
  have h21 : RB z21 ((112615099 : ℝ) / 25000000) ((225230887 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((14264997 : ℝ) / 50000000) ((14264997 : ℝ) / 50000000) ((14264997 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((150509997 : ℝ) / 100000000) ((75255153 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_584.1 cov_log_585.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((18454309 : ℝ) / 20000000) ((923877 : ℝ) / 1000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((64264997 : ℝ) / 50000000))
  have h24 : RB z24 ((2509921 : ℝ) / 10000000) ((25099211 : ℝ) / 100000000) := rb_log (show RB ((64264997 : ℝ) / 50000000) ((64264997 : ℝ) / 50000000) ((64264997 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_586.1 cov_log_586.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33586167 : ℝ) / 50000000) ((6728849 : ℝ) / 10000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((8373747 : ℝ) / 12500000) ((16755837 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_579.1 cov_log_580.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((74493 : ℝ) / 50000000) ((149257 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((13277 : ℝ) / 100000000) ((1367 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((128712849 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((128699179 : ℝ) / 100000000) ((32174893 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((128712849 : ℝ) / 100000000) ((128712849 : ℝ) / 100000000) ((128712849 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((28712849 : ℝ) / 100000000))
  have h30 : RB z30 ((448228523 : ℝ) / 100000000) ((112057473 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((28712849 : ℝ) / 100000000) ((28712849 : ℝ) / 100000000) ((28712849 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((150013301 : ℝ) / 100000000) ((150013609 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_587.1 cov_log_588.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91967041 : ℝ) / 100000000) ((92082813 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((128712849 : ℝ) / 100000000))
  have h33 : RB z33 ((788793 : ℝ) / 3125000) ((25241377 : ℝ) / 100000000) := rb_log (show RB ((128712849 : ℝ) / 100000000) ((128712849 : ℝ) / 100000000) ((128712849 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_589.1 cov_log_589.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((2085177 : ℝ) / 3125000) ((66841437 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((8373747 : ℝ) / 12500000) ((16755837 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_579.1 cov_log_580.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-74421 : ℝ) / 25000000) ((-148539 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42322287 : ℝ) / 100000000)) ((-29537 : ℝ) / 50000000) ((-313 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((10678233 : ℝ) / 25000000)) ((3453 : ℝ) / 100000000) ((60037 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((64264997 : ℝ) / 50000000)) ((74493 : ℝ) / 50000000) ((149257 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((128712849 : ℝ) / 100000000)) ((-74421 : ℝ) / 25000000) ((-148539 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_32 {k A q d vp vm : ℝ}
    (hk : RB k ((507 : ℝ) / 320) ((10173 : ℝ) / 6400))
    (hA : RB A ((507 : ℝ) / 827) ((10173 : ℝ) / 16573))
    (hq : RB q ((576137 : ℝ) / 50000000) ((4567 : ℝ) / 390625))
    (hd : RB d ((39080829 : ℝ) / 20000000) ((195469363 : ℝ) / 100000000))
    (hp : RB vp ((42322287 : ℝ) / 100000000) ((10678233 : ℝ) / 25000000))
    (hm : RB vm ((64264997 : ℝ) / 50000000) ((128712849 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((13277 : ℝ) / 100000000) ((1367 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((9998633 : ℝ) / 10000000) ((99986723 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((7662193 : ℝ) / 12500000) ((61374823 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((7771 : ℝ) / 25000000) ((323 : ℝ) / 1000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((999677 : ℝ) / 1000000) ((24992229 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((14321767 : ℝ) / 25000000) ((57677713 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((14317141 : ℝ) / 25000000) ((11531957 : ℝ) / 20000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((21261801 : ℝ) / 20000000) ((5358509 : ℝ) / 5000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1261801 : ℝ) / 20000000) ((358509 : ℝ) / 5000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((9998633 : ℝ) / 10000000) ((99986723 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((7662193 : ℝ) / 12500000) ((61374823 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((2063 : ℝ) / 20000000) ((2659 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24997341 : ℝ) / 25000000) ((19997937 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((14264997 : ℝ) / 50000000) ((28712849 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28526959 : ℝ) / 100000000) ((112148 : ℝ) / 390625) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((213506733 : ℝ) / 100000000) ((215146743 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((313506733 : ℝ) / 100000000) ((315146743 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((697332563 : ℝ) / 50000000) ((1585035993 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31731249 : ℝ) / 100000000) ((15948621 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((507 : ℝ) / 160) ((10173 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((912817 : ℝ) / 25000000) ((464601 : ℝ) / 12500000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50576137 : ℝ) / 50000000) ((395192 : ℝ) / 390625) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((225567 : ℝ) / 6250000) ((3674469 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((6475567 : ℝ) / 6250000) ((103674469 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((42908531 : ℝ) / 50000000) ((43195281 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((10480631 : ℝ) / 6250000) ((84433541 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((1699901 : ℝ) / 3125000) ((6872129 : ℝ) / 12500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((483 : ℝ) / 2000000) ((25131 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99974869 : ℝ) / 100000000) ((1999517 : ℝ) / 2000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((167647953 : ℝ) / 100000000) ((168826301 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((39080829 : ℝ) / 10000000) ((195469363 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2251591 : ℝ) / 50000000) ((1142667 : ℝ) / 25000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((827 : ℝ) / 320) ((16573 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((347799 : ℝ) / 20000000) ((884289 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((674429 : ℝ) / 25000000) ((1381249 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25674429 : ℝ) / 25000000) ((51381249 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((143228923 : ℝ) / 10000000) ((1628822581 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((223807 : ℝ) / 25000000) ((454817 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25223807 : ℝ) / 25000000) ((50454817 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((8003829 : ℝ) / 25000000) ((32187391 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((732152273 : ℝ) / 50000000) ((415252493 : ℝ) / 25000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((12732091 : ℝ) / 50000000) ((29376257 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((827 : ℝ) / 320) ((16573 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((6475567 : ℝ) / 3125000) ((103674469 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((11411171 : ℝ) / 800000) ((323386647 : ℝ) / 20000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1477876047 : ℝ) / 50000000) ((3352693891 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7708353 : ℝ) / 100000000) ((876099 : ℝ) / 10000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-32035821 : ℝ) / 12500000) ((-243486127 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_590.1 cov_log_591.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2251591 : ℝ) / 100000000) ((1142667 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-94838329 : ℝ) / 25000000) ((-377865799 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_592.1 cov_log_593.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((8373747 : ℝ) / 12500000) ((16755837 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_579.1 cov_log_580.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((106137243 : ℝ) / 100000000) ((106535707 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-273216073 : ℝ) / 100000000) ((-67832523 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((7308373 : ℝ) / 50000000) ((3159019 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((24878503 : ℝ) / 50000000) ((62028677 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-223459067 : ℝ) / 100000000) ((-41860283 : ℝ) / 20000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((6475567 : ℝ) / 6250000) ((103674469 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-32035821 : ℝ) / 12500000) ((-243486127 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-223459067 : ℝ) / 100000000) ((-41860283 : ℝ) / 20000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((76 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((674429 : ℝ) / 25000000) ((1381249 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((51381249 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((76 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-5680409 : ℝ) / 2500000) ≤ formC0 k A q vp vm + hfun ((76 : ℝ) / 25) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_8, cov_h_6]
  have hP : ((634216313 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((41860283 : ℝ) / 20000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((41860283 : ℝ) / 20000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((557 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((557 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((113 : ℝ) / 40) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((113 : ℝ) / 40)) (lo := ((557 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((573 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((573 : ℝ) / 200)) (lo := ((113 : ℝ) / 40)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((581 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((581 : ℝ) / 200)) (lo := ((573 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((589 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((589 : ℝ) / 200)) (lo := ((581 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((597 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((597 : ℝ) / 200)) (lo := ((589 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((121 : ℝ) / 40) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((121 : ℝ) / 40)) (lo := ((597 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((76 : ℝ) / 25)) (lo := ((121 : ℝ) / 40)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_32 {k : ℝ} (hk : RB k ((507 : ℝ) / 320) ((10173 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((507 : ℝ) / 827) ((10173 : ℝ) / 16573) ∧
    RB (qa (r1A k)) ((576137 : ℝ) / 50000000) ((4567 : ℝ) / 390625) ∧ RB (D0a (r1A k)) ((39080829 : ℝ) / 20000000) ((195469363 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((507 : ℝ) / 1280) ((19869141 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((95430859 : ℝ) / 50000000) ((61117 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138152711 : ℝ) / 100000000) ((69099679 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279574067 : ℝ) / 100000000) ((55924143 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139787033 : ℝ) / 100000000) ((69905179 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((39080829 : ℝ) / 20000000) ((195469363 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2883 : ℝ) / 32000) ((4569141 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2252343 : ℝ) / 100000000) ((2284571 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((576137 : ℝ) / 50000000) ((4567 : ℝ) / 390625) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((39080829 : ℝ) / 20000000) ((195469363 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((576137 : ℝ) / 50000000) ((4567 : ℝ) / 390625) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((507 : ℝ) / 827) ((10173 : ℝ) / 16573) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_32 {k : ℝ} (hk : RB k ((507 : ℝ) / 320) ((10173 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_32 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_32 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((42322287 : ℝ) / 100000000)) (ph := ((10678233 : ℝ) / 25000000)) (ml := ((64264997 : ℝ) / 50000000)) (mh := ((128712849 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_32 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_33 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10173 : ℝ) / 16573) ((5103 : ℝ) / 8303))
    (hq : RB (qa a) ((1169151 : ℝ) / 100000000) ((29651 : ℝ) / 2500000))
    (hd : RB (D0a a) ((97669463 : ℝ) / 50000000) ((24425519 : ℝ) / 12500000))
    : certE k a ((42265273 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((42650379 : ℝ) / 100000000) ∧ 0 < certE k a ((25718223 : ℝ) / 20000000) ∧ certE k a ((6438673 : ℝ) / 5000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((13669 : ℝ) / 100000000) ((14067 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42265273 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((21125603 : ℝ) / 50000000) ((10562901 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((42265273 : ℝ) / 100000000) ((42265273 : ℝ) / 100000000) ((42265273 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57734727 : ℝ) / 100000000))
  have h3 : RB z3 ((14636323 : ℝ) / 20000000) ((14636461 : ℝ) / 20000000) := rb_div_signed h2 (show RB ((57734727 : ℝ) / 100000000) ((57734727 : ℝ) / 100000000) ((57734727 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-7805649 : ℝ) / 25000000) ((-7805413 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_594.1 cov_log_595.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-19189319 : ℝ) / 100000000) ((-9582389 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42265273 : ℝ) / 100000000))
  have h6 : RB z6 ((-43060221 : ℝ) / 50000000) ((-2153011 : ℝ) / 2500000) := rb_log (show RB ((42265273 : ℝ) / 100000000) ((42265273 : ℝ) / 100000000) ((42265273 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_596.1 cov_log_596.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66931121 : ℝ) / 100000000) ((4184729 : ℝ) / 6250000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33478297 : ℝ) / 50000000) ((33494991 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_597.1 cov_log_598.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-58861 : ℝ) / 100000000) ((-93 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((13669 : ℝ) / 100000000) ((14067 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42650379 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((5329539 : ℝ) / 12500000) ((4263671 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((42650379 : ℝ) / 100000000) ((42650379 : ℝ) / 100000000) ((42650379 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57349621 : ℝ) / 100000000))
  have h12 : RB z12 ((3717227 : ℝ) / 5000000) ((14869047 : ℝ) / 20000000) := rb_div_signed h11 (show RB ((57349621 : ℝ) / 100000000) ((57349621 : ℝ) / 100000000) ((57349621 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-7411499 : ℝ) / 25000000) ((-1482253 : ℝ) / 5000000) := rb_log h12 (by norm_num) cov_log_599.1 cov_log_600.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3644069 : ℝ) / 20000000) ((-9098509 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42650379 : ℝ) / 100000000))
  have h15 : RB z15 ((-21303351 : ℝ) / 25000000) ((-42606701 : ℝ) / 50000000) := rb_log (show RB ((42650379 : ℝ) / 100000000) ((42650379 : ℝ) / 100000000) ((42650379 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_601.1 cov_log_601.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66993057 : ℝ) / 100000000) ((33508193 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33478297 : ℝ) / 50000000) ((33494991 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_597.1 cov_log_598.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((123 : ℝ) / 4000000) ((3737 : ℝ) / 6250000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((13669 : ℝ) / 100000000) ((14067 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((25718223 : ℝ) / 20000000)) - (z19)
  have h20 : RB z20 ((16072131 : ℝ) / 12500000) ((64288723 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((25718223 : ℝ) / 20000000) ((25718223 : ℝ) / 20000000) ((25718223 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((5718223 : ℝ) / 20000000))
  have h21 : RB z21 ((224854903 : ℝ) / 50000000) ((449711199 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((5718223 : ℝ) / 20000000) ((5718223 : ℝ) / 20000000) ((5718223 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((150343231 : ℝ) / 100000000) ((150343543 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_602.1 cov_log_603.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92285143 : ℝ) / 100000000) ((92400711 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((25718223 : ℝ) / 20000000))
  have h24 : RB z24 ((25146753 : ℝ) / 100000000) ((12573377 : ℝ) / 50000000) := rb_log (show RB ((25718223 : ℝ) / 20000000) ((25718223 : ℝ) / 20000000) ((25718223 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_604.1 cov_log_604.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67138389 : ℝ) / 100000000) ((33626979 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33478297 : ℝ) / 50000000) ((33494991 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_597.1 cov_log_598.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((148407 : ℝ) / 100000000) ((74341 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((13669 : ℝ) / 100000000) ((14067 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((6438673 : ℝ) / 5000000)) - (z28)
  have h29 : RB z29 ((128759393 : ℝ) / 100000000) ((128759791 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((6438673 : ℝ) / 5000000) ((6438673 : ℝ) / 5000000) ((6438673 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((1438673 : ℝ) / 5000000))
  have h30 : RB z30 ((447493603 : ℝ) / 100000000) ((447494987 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((1438673 : ℝ) / 5000000) ((1438673 : ℝ) / 5000000) ((1438673 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((29969841 : ℝ) / 20000000) ((149849517 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_605.1 cov_log_606.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((11497737 : ℝ) / 12500000) ((23024271 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((6438673 : ℝ) / 5000000))
  have h33 : RB z33 ((5057691 : ℝ) / 20000000) ((3161057 : ℝ) / 12500000) := rb_log (show RB ((6438673 : ℝ) / 5000000) ((6438673 : ℝ) / 5000000) ((6438673 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_607.1 cov_log_607.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((208417 : ℝ) / 312500) ((66808629 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33478297 : ℝ) / 50000000) ((33494991 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_597.1 cov_log_598.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-148271 : ℝ) / 50000000) ((-29593 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42265273 : ℝ) / 100000000)) ((-58861 : ℝ) / 100000000) ((-93 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42650379 : ℝ) / 100000000)) ((123 : ℝ) / 4000000) ((3737 : ℝ) / 6250000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((25718223 : ℝ) / 20000000)) ((148407 : ℝ) / 100000000) ((74341 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((6438673 : ℝ) / 5000000)) ((-148271 : ℝ) / 50000000) ((-29593 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_33 {k A q d vp vm : ℝ}
    (hk : RB k ((10173 : ℝ) / 6400) ((5103 : ℝ) / 3200))
    (hA : RB A ((10173 : ℝ) / 16573) ((5103 : ℝ) / 8303))
    (hq : RB q ((1169151 : ℝ) / 100000000) ((29651 : ℝ) / 2500000))
    (hd : RB d ((97669463 : ℝ) / 50000000) ((24425519 : ℝ) / 12500000))
    (hp : RB vp ((42265273 : ℝ) / 100000000) ((42650379 : ℝ) / 100000000))
    (hm : RB vm ((25718223 : ℝ) / 20000000) ((6438673 : ℝ) / 5000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((13669 : ℝ) / 100000000) ((14067 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99985933 : ℝ) / 100000000) ((99986331 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((61374337 : ℝ) / 100000000) ((61451313 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((2003 : ℝ) / 6250000) ((33283 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99966717 : ℝ) / 100000000) ((6247997 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57349621 : ℝ) / 100000000) ((57734727 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57330533 : ℝ) / 100000000) ((2308649 : ℝ) / 4000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106338099 : ℝ) / 100000000) ((107187759 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6338099 : ℝ) / 100000000) ((7187759 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99985933 : ℝ) / 100000000) ((99986331 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((61374337 : ℝ) / 100000000) ((61451313 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((5307 : ℝ) / 50000000) ((547 : ℝ) / 5000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((4999453 : ℝ) / 5000000) ((49994693 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((5718223 : ℝ) / 20000000) ((1438673 : ℝ) / 5000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28587987 : ℝ) / 100000000) ((14385203 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((106662271 : ℝ) / 50000000) ((10747751 : ℝ) / 5000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((156662271 : ℝ) / 50000000) ((15747751 : ℝ) / 5000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((695627107 : ℝ) / 50000000) ((788880073 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6350113 : ℝ) / 20000000) ((3191579 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10173 : ℝ) / 3200) ((5103 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((929201 : ℝ) / 25000000) ((3782727 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101169151 : ℝ) / 100000000) ((2529651 : ℝ) / 2500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3673237 : ℝ) / 100000000) ((3739013 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((103673237 : ℝ) / 100000000) ((103739013 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((335706 : ℝ) / 390625) ((86508187 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((16787571 : ℝ) / 10000000) ((16904059 : ℝ) / 10000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((10869877 : ℝ) / 20000000) ((54922369 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((24887 : ℝ) / 100000000) ((25883 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99974117 : ℝ) / 100000000) ((99975113 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((83916129 : ℝ) / 50000000) ((168998521 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((97669463 : ℝ) / 25000000) ((24425519 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2283807 : ℝ) / 50000000) ((4635143 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16573 : ℝ) / 6400) ((8303 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1760371 : ℝ) / 100000000) ((357991 : ℝ) / 20000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((685311 : ℝ) / 25000000) ((2806181 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25685311 : ℝ) / 25000000) ((102806181 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((714695943 : ℝ) / 50000000) ((202754369 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((907913 : ℝ) / 100000000) ((184467 : ℝ) / 20000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100907913 : ℝ) / 100000000) ((20184467 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((2002427 : ℝ) / 6250000) ((32210161 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((730715359 : ℝ) / 50000000) ((1654245113 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((12863301 : ℝ) / 50000000) ((7402561 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16573 : ℝ) / 6400) ((8303 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((103673237 : ℝ) / 50000000) ((103739013 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1423004779 : ℝ) / 100000000) ((50302373 : ℝ) / 3125000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1475275117 : ℝ) / 50000000) ((1669861929 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((30288 : ℝ) / 390625) ((8793911 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-255699647 : ℝ) / 100000000) ((-243111063 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_608.1 cov_log_609.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2283807 : ℝ) / 100000000) ((579393 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-75586529 : ℝ) / 20000000) ((-376465009 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_610.1 cov_log_611.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33478297 : ℝ) / 50000000) ((33494991 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_597.1 cov_log_598.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((53214799 : ℝ) / 50000000) ((106828087 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-271503047 : ℝ) / 100000000) ((-134818461 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((7222263 : ℝ) / 50000000) ((1561079 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((48782191 : ℝ) / 100000000) ((12135913 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-27840107 : ℝ) / 12500000) ((-208957357 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((103673237 : ℝ) / 100000000) ((103739013 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-255699647 : ℝ) / 100000000) ((-243111063 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-27840107 : ℝ) / 12500000) ((-208957357 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((76 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((685311 : ℝ) / 25000000) ((2806181 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((102806181 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((76 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-226629439 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((76 : ℝ) / 25) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_8, cov_h_6]
  have hP : ((632779817 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((208957357 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((208957357 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1393 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1393 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1413 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1413 : ℝ) / 500)) (lo := ((1393 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1433 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1433 : ℝ) / 500)) (lo := ((1413 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1453 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1453 : ℝ) / 500)) (lo := ((1433 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1473 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1473 : ℝ) / 500)) (lo := ((1453 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1493 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1493 : ℝ) / 500)) (lo := ((1473 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1513 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1513 : ℝ) / 500)) (lo := ((1493 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((76 : ℝ) / 25)) (lo := ((1513 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_33 {k : ℝ} (hk : RB k ((10173 : ℝ) / 6400) ((5103 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((10173 : ℝ) / 16573) ((5103 : ℝ) / 8303) ∧
    RB (qa (r1A k)) ((1169151 : ℝ) / 100000000) ((29651 : ℝ) / 2500000) ∧ RB (D0a (r1A k)) ((97669463 : ℝ) / 50000000) ((24425519 : ℝ) / 12500000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((39738281 : ℝ) / 100000000) ((9966797 : ℝ) / 25000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((47683203 : ℝ) / 25000000) ((190861719 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((2762121 : ℝ) / 2000000) ((138152713 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139763703 : ℝ) / 50000000) ((27957407 : ℝ) / 10000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139763703 : ℝ) / 100000000) ((27957407 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((97669463 : ℝ) / 50000000) ((24425519 : ℝ) / 12500000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((9138281 : ℝ) / 100000000) ((2316797 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((228457 : ℝ) / 10000000) ((2316797 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1169151 : ℝ) / 100000000) ((29651 : ℝ) / 2500000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((97669463 : ℝ) / 50000000) ((24425519 : ℝ) / 12500000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1169151 : ℝ) / 100000000) ((29651 : ℝ) / 2500000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10173 : ℝ) / 16573) ((5103 : ℝ) / 8303) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_33 {k : ℝ} (hk : RB k ((10173 : ℝ) / 6400) ((5103 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_33 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_33 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((42265273 : ℝ) / 100000000)) (ph := ((42650379 : ℝ) / 100000000)) (ml := ((25718223 : ℝ) / 20000000)) (mh := ((6438673 : ℝ) / 5000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_33 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_34 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5103 : ℝ) / 8303) ((10239 : ℝ) / 16639))
    (hq : RB (qa a) ((1186039 : ℝ) / 100000000) ((60147 : ℝ) / 5000000))
    (hd : RB (D0a a) ((195273693 : ℝ) / 100000000) ((19533893 : ℝ) / 10000000))
    : certE k a ((42209031 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((2129437 : ℝ) / 5000000) ∧ 0 < certE k a ((25730413 : ℝ) / 20000000) ∧ certE k a ((8052119 : ℝ) / 6250000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((7033 : ℝ) / 50000000) ((14471 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42209031 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((65929 : ℝ) / 156250) ((8438993 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((42209031 : ℝ) / 100000000) ((42209031 : ℝ) / 100000000) ((42209031 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57790969 : ℝ) / 100000000))
  have h3 : RB z3 ((9126547 : ℝ) / 12500000) ((36506539 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((57790969 : ℝ) / 100000000) ((57790969 : ℝ) / 100000000) ((57790969 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-31454123 : ℝ) / 100000000) ((-31453161 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_612.1 cov_log_613.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-19355657 : ℝ) / 100000000) ((-9665511 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42209031 : ℝ) / 100000000))
  have h6 : RB z6 ((-107817 : ℝ) / 125000) ((-43126799 : ℝ) / 50000000) := rb_log (show RB ((42209031 : ℝ) / 100000000) ((42209031 : ℝ) / 100000000) ((42209031 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_614.1 cov_log_614.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66897941 : ℝ) / 100000000) ((33461289 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33461597 : ℝ) / 50000000) ((33478299 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_615.1 cov_log_616.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-58657 : ℝ) / 100000000) ((-77 : ℝ) / 12500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((7033 : ℝ) / 50000000) ((14471 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((2129437 : ℝ) / 5000000)) - (z10)
  have h11 : RB z11 ((42574269 : ℝ) / 100000000) ((21287337 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((2129437 : ℝ) / 5000000) ((2129437 : ℝ) / 5000000) ((2129437 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((2870563 : ℝ) / 5000000))
  have h12 : RB z12 ((74156653 : ℝ) / 100000000) ((74157359 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((2870563 : ℝ) / 5000000) ((2870563 : ℝ) / 5000000) ((2870563 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-186869 : ℝ) / 625000) ((-29898087 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_617.1 cov_log_618.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-18398719 : ℝ) / 100000000) ((-9187639 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((2129437 : ℝ) / 5000000))
  have h15 : RB z15 ((-8535803 : ℝ) / 10000000) ((-21339507 : ℝ) / 25000000) := rb_log (show RB ((2129437 : ℝ) / 5000000) ((2129437 : ℝ) / 5000000) ((2129437 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_619.1 cov_log_619.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66959309 : ℝ) / 100000000) ((2093211 : ℝ) / 3125000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33461597 : ℝ) / 50000000) ((33478299 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_615.1 cov_log_616.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((2711 : ℝ) / 100000000) ((29779 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((7033 : ℝ) / 50000000) ((14471 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((25730413 : ℝ) / 20000000)) - (z19)
  have h20 : RB z20 ((64318797 : ℝ) / 50000000) ((128637999 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((25730413 : ℝ) / 20000000) ((25730413 : ℝ) / 20000000) ((25730413 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((5730413 : ℝ) / 20000000))
  have h21 : RB z21 ((448964477 : ℝ) / 100000000) ((112241473 : ℝ) / 25000000) := rb_div_signed h20 (show RB ((5730413 : ℝ) / 20000000) ((5730413 : ℝ) / 20000000) ((5730413 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((75088679 : ℝ) / 50000000) ((37544419 : ℝ) / 25000000) := rb_log h21 (by norm_num) cov_log_620.1 cov_log_621.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92298573 : ℝ) / 100000000) ((2310339 : ℝ) / 2500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((25730413 : ℝ) / 20000000))
  have h24 : RB z24 ((1259707 : ℝ) / 5000000) ((25194141 : ℝ) / 100000000) := rb_log (show RB ((25730413 : ℝ) / 20000000) ((25730413 : ℝ) / 20000000) ((25730413 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_622.1 cov_log_622.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((4194027 : ℝ) / 6250000) ((3360971 : ℝ) / 5000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33461597 : ℝ) / 50000000) ((33478299 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_615.1 cov_log_616.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((73917 : ℝ) / 50000000) ((148113 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((7033 : ℝ) / 50000000) ((14471 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((8052119 : ℝ) / 6250000)) - (z28)
  have h29 : RB z29 ((128819433 : ℝ) / 100000000) ((64409919 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((8052119 : ℝ) / 6250000) ((8052119 : ℝ) / 6250000) ((8052119 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((1802119 : ℝ) / 6250000))
  have h30 : RB z30 ((446763757 : ℝ) / 100000000) ((446765163 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((1802119 : ℝ) / 6250000) ((1802119 : ℝ) / 6250000) ((1802119 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((5987439 : ℝ) / 4000000) ((149686293 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_623.1 cov_log_624.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91996571 : ℝ) / 100000000) ((46055591 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((8052119 : ℝ) / 6250000))
  have h33 : RB z33 ((12667691 : ℝ) / 50000000) ((25335383 : ℝ) / 100000000) := rb_log (show RB ((8052119 : ℝ) / 6250000) ((8052119 : ℝ) / 6250000) ((8052119 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_625.1 cov_log_625.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((16665297 : ℝ) / 25000000) ((333879 : ℝ) / 500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33461597 : ℝ) / 50000000) ((33478299 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_615.1 cov_log_616.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-29541 : ℝ) / 10000000) ((-73697 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42209031 : ℝ) / 100000000)) ((-58657 : ℝ) / 100000000) ((-77 : ℝ) / 12500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((2129437 : ℝ) / 5000000)) ((2711 : ℝ) / 100000000) ((29779 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((25730413 : ℝ) / 20000000)) ((73917 : ℝ) / 50000000) ((148113 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((8052119 : ℝ) / 6250000)) ((-29541 : ℝ) / 10000000) ((-73697 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_34 {k A q d vp vm : ℝ}
    (hk : RB k ((5103 : ℝ) / 3200) ((10239 : ℝ) / 6400))
    (hA : RB A ((5103 : ℝ) / 8303) ((10239 : ℝ) / 16639))
    (hq : RB q ((1186039 : ℝ) / 100000000) ((60147 : ℝ) / 5000000))
    (hd : RB d ((195273693 : ℝ) / 100000000) ((19533893 : ℝ) / 10000000))
    (hp : RB vp ((42209031 : ℝ) / 100000000) ((2129437 : ℝ) / 5000000))
    (hm : RB vm ((25730413 : ℝ) / 20000000) ((8052119 : ℝ) / 6250000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((7033 : ℝ) / 50000000) ((14471 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99985529 : ℝ) / 100000000) ((49992967 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((61450819 : ℝ) / 100000000) ((12305499 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((33027 : ℝ) / 100000000) ((6857 : ℝ) / 20000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((19993143 : ℝ) / 20000000) ((99966973 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((2870563 : ℝ) / 5000000) ((57790969 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7173947 : ℝ) / 12500000) ((57771883 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53184019 : ℝ) / 50000000) ((26801623 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3184019 : ℝ) / 50000000) ((1801623 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99985529 : ℝ) / 100000000) ((49992967 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((61450819 : ℝ) / 100000000) ((12305499 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((10917 : ℝ) / 100000000) ((11249 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99988751 : ℝ) / 100000000) ((99989083 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((5730413 : ℝ) / 20000000) ((1802119 : ℝ) / 6250000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28648841 : ℝ) / 100000000) ((28830757 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((26642909 : ℝ) / 12500000) ((214764343 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((39142909 : ℝ) / 12500000) ((314764343 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((693818851 : ℝ) / 50000000) ((1570342389 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31769799 : ℝ) / 100000000) ((6386853 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5103 : ℝ) / 1600) ((10239 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((3782723 : ℝ) / 100000000) ((3849033 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101186039 : ℝ) / 100000000) ((5060147 : ℝ) / 5000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3737759 : ℝ) / 100000000) ((1901959 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((103737759 : ℝ) / 100000000) ((51901959 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((3442533 : ℝ) / 4000000) ((86624873 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((168059033 : ℝ) / 100000000) ((169212101 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((54302789 : ℝ) / 100000000) ((54868737 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((5127 : ℝ) / 20000000) ((26649 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99973351 : ℝ) / 100000000) ((19994873 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((84007123 : ℝ) / 50000000) ((42292181 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((195273693 : ℝ) / 50000000) ((19533893 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1158011 : ℝ) / 25000000) ((4699621 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8303 : ℝ) / 3200) ((16639 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((890831 : ℝ) / 50000000) ((113203 : ℝ) / 6250000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((556973 : ℝ) / 20000000) ((2849959 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((20556973 : ℝ) / 20000000) ((102849959 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((713140769 : ℝ) / 50000000) ((201887063 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((184119 : ℝ) / 20000000) ((467517 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20184119 : ℝ) / 20000000) ((50467517 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3206227 : ℝ) / 10000000) ((16116431 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((11393311 : ℝ) / 781250) ((823664683 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((25982757 : ℝ) / 100000000) ((29837221 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8303 : ℝ) / 3200) ((16639 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((103737759 : ℝ) / 50000000) ((51901959 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1419407501 : ℝ) / 100000000) ((801138327 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((588984613 : ℝ) / 20000000) ((3326451889 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1560033 : ℝ) / 20000000) ((8828223 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-127551267 : ℝ) / 50000000) ((-242721643 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_626.1 cov_log_627.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1158011 : ℝ) / 50000000) ((2349811 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-188265959 : ℝ) / 50000000) ((-46885441 : ℝ) / 12500000) := rb_log h49 (by norm_num) cov_log_628.1 cov_log_629.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33461597 : ℝ) / 50000000) ((33478299 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_615.1 cov_log_616.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((5336079 : ℝ) / 5000000) ((21424019 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-134905169 : ℝ) / 50000000) ((-267963433 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((14274323 : ℝ) / 100000000) ((7714401 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((23920329 : ℝ) / 50000000) ((927827 : ℝ) / 1562500) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-2774621 : ℝ) / 1250000) ((-41716501 : ℝ) / 20000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((103737759 : ℝ) / 100000000) ((51901959 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-127551267 : ℝ) / 50000000) ((-242721643 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-2774621 : ℝ) / 1250000) ((-41716501 : ℝ) / 20000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((303 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((556973 : ℝ) / 20000000) ((2849959 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((102849959 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((303 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-225765661 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((303 : ℝ) / 100) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_9, cov_h_6]
  have hP : ((631249717 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((41716501 : ℝ) / 20000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((41716501 : ℝ) / 20000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((279 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((283 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((287 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((283 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((291 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((291 : ℝ) / 100)) (lo := ((287 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((59 : ℝ) / 20) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((291 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((299 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((59 : ℝ) / 20)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((303 : ℝ) / 100)) (lo := ((299 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_34 {k : ℝ} (hk : RB k ((5103 : ℝ) / 3200) ((10239 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((5103 : ℝ) / 8303) ((10239 : ℝ) / 16639) ∧
    RB (qa (r1A k)) ((1186039 : ℝ) / 100000000) ((60147 : ℝ) / 5000000) ∧ RB (D0a (r1A k)) ((195273693 : ℝ) / 100000000) ((19533893 : ℝ) / 10000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((39867187 : ℝ) / 100000000) ((19998047 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((95301953 : ℝ) / 50000000) ((190732813 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138059373 : ℝ) / 100000000) ((138106051 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279480729 : ℝ) / 100000000) ((17470463 : ℝ) / 6250000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((34935091 : ℝ) / 25000000) ((17470463 : ℝ) / 12500000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((195273693 : ℝ) / 100000000) ((19533893 : ℝ) / 10000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((9267187 : ℝ) / 100000000) ((4698047 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((579199 : ℝ) / 25000000) ((73407 : ℝ) / 3125000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1186039 : ℝ) / 100000000) ((60147 : ℝ) / 5000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((195273693 : ℝ) / 100000000) ((19533893 : ℝ) / 10000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1186039 : ℝ) / 100000000) ((60147 : ℝ) / 5000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5103 : ℝ) / 8303) ((10239 : ℝ) / 16639) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_34 {k : ℝ} (hk : RB k ((5103 : ℝ) / 3200) ((10239 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_34 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_34 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((42209031 : ℝ) / 100000000)) (ph := ((2129437 : ℝ) / 5000000)) (ml := ((25730413 : ℝ) / 20000000)) (mh := ((8052119 : ℝ) / 6250000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_34 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
