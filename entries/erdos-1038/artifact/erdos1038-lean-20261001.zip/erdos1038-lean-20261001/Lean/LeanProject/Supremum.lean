import LeanProject.W66Values

/-!
# EP-1038: the supremum, proof.md Theorem 6.7, fully formalised

* `piece_excludes`, `arcsine_branch`: Lemma 6.6′ (four explicit witnesses `δ₀ + h₁ δ_B + h₂ ρ_[c,B]`
  with the twelve certified values of `W66Values.lean`) together with the general-measure
  Lemma 6.3 (`GeneralWitness.lean`) exclude `a = M - 1 ∈ [3/4, 1]`.
* `closedSublevel_subset_Icc2`: `K̄ ⊆ [-2, 2]` (Lemma 6.1, so `M ≤ 2`).
* `sup_le`: **`|S_f| ≤ 2√2`** for every root vector in `[-1, 1]ⁿ`, `n ≥ 1`
  (`M ∈ (√2, 7/4]` is the two-atom branch `SupReduction.lean`/`PhiSeries.lean`,
  `M ∈ [7/4, 2]` the branch above).
* `sup_M_le`, `sup_eq_endpoints`: `|S_f| = 2√2` forces `α = -√2`, `β = √2`, `|f(±√2)| = 1`.
* `sup_theorem`: **Theorem 6.7** for polynomials: for monic `p ∈ ℝ[X]` of degree `≥ 1` with all roots
  real in `[-1, 1]`, `|{|p| < 1}| ≤ 2√2`, with equality iff `p = (X² - 1)^m`, `m ≥ 1`.
-/
open Real MeasureTheory

namespace EP1038

open Arcsine

/-- The piece machinery: a Lemma 6.6′ witness with verified three-point values excludes `a`. -/
theorem piece_excludes {n : ℕ} (hn : 0 < n) (q : Fin n → ℝ) {a Y lo c hi h₁ h₂ : ℝ}
    (hlo0 : 0 < lo) (hloa : lo ≤ a) (haB : a ≤ 2 * √2) (hlc : lo < c) (hch : c < hi) (hhB : hi ≤ 2 * √2)
    (hh₁ : 0 ≤ h₁) (hh₂ : 0 ≤ h₂) (hatomB : h₁ = 0 ∨ hi < 2 * √2)
    (hahi : min (2 * √2) (a + 2) ≤ hi)
    (hWlo : 0 < Wp (2 * √2) h₁ h₂ c lo) (hWc : 0 < Wp (2 * √2) h₁ h₂ c c)
    (hWhi : 0 < Wp (2 * √2) h₁ h₂ c hi)
    (hq : ∀ j, q j ∈ Set.Icc a (a + 2)) (h0 : ∏ j, q j = 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤ volume (Set.Icc 0 Y ∩ General.K q)) : False := by
  have hcB : c < 2 * √2 := lt_of_lt_of_le hch hhB
  have ha0 : 0 < a := lt_of_lt_of_le hlo0 hloa
  have hpos := Wp_pos hlo0 hlc hch hhB hh₁ hh₂ hatomB hWlo hWc hWhi
  apply General.measure_witness_contradiction hn q (a := a) (B := 2 * √2) (Y := Y) ha0 haB hq h0
    hvol (mu (2 * √2) h₁ h₂ c) (mu_compl (lt_trans hlo0 hlc) hcB)
  · intro s hs
    apply mu_atom hcB (lt_of_lt_of_le ha0 hs.1)
    rcases hatomB with h | h
    · exact Or.inl h
    · exact Or.inr (by
        intro hsB
        have : s ≤ hi := hs.2.trans hahi
        linarith)
  · intro x _; exact mu_integrable hcB x
  · intro x hx
    have hx0 : 0 < x := lt_of_lt_of_le ha0 hx.1
    have hxB : x ≤ 2 * √2 := hx.2.trans (min_le_left _ _)
    rw [mu_integral hcB hh₁ hh₂ hx0 hxB]
    exact hpos x ⟨hloa.trans hx.1, hx.2.trans hahi⟩

/-- **Lemma 6.6′ + Lemma 6.3**: the shifted configuration is impossible for `a ∈ [3/4, 1]`. -/
theorem arcsine_branch {n : ℕ} (hn : 0 < n) (q : Fin n → ℝ) {a Y : ℝ}
    (ha1 : 3 / 4 ≤ a) (ha2 : a ≤ 1) (hq : ∀ j, q j ∈ Set.Icc a (a + 2)) (h0 : ∏ j, q j = 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤ volume (Set.Icc 0 Y ∩ General.K q)) : False := by
  have hs1 : (141421356 / 100000000 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have hs2 : √2 < (141421357 / 100000000 : ℝ) := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  rcases le_total a (39 / 50) with hA | hA
  · exact piece_excludes hn q (lo := 3 / 4) (c := 21 / 10) (hi := 139 / 50) (h₁ := 13 / 125)
      (h₂ := 103 / 250) (by norm_num) ha1 (by linarith) (by norm_num) (by norm_num) (by linarith) (by norm_num)
      (by norm_num) (Or.inr (by linarith)) ((min_le_right _ _).trans (by linarith))
      W_P1_lo W_P1_c W_P1_hi hq h0 hvol
  rcases le_total a (81 / 100) with hB | hB
  · exact piece_excludes hn q (lo := 39 / 50) (c := 21 / 10) (hi := 281 / 100) (h₁ := 2 / 25)
      (h₂ := 409 / 1000) (by norm_num) hA (by linarith) (by norm_num) (by norm_num) (by linarith) (by norm_num)
      (by norm_num) (Or.inr (by linarith)) ((min_le_right _ _).trans (by linarith))
      W_P2_lo W_P2_c W_P2_hi hq h0 hvol
  rcases le_total a (9 / 10) with hC | hC
  · exact piece_excludes hn q (lo := 81 / 100) (c := 119 / 50) (hi := 2 * √2) (h₁ := 0)
      (h₂ := 389 / 1000) (by norm_num) hB (by linarith) (by norm_num) (by linarith) le_rfl le_rfl
      (by norm_num) (Or.inl rfl) (min_le_left _ _)
      W_P3_lo W_P3_c W_P3_hi hq h0 hvol
  · exact piece_excludes hn q (lo := 9 / 10) (c := 121 / 50) (hi := 2 * √2) (h₁ := 0)
      (h₂ := 7 / 20) (by norm_num) hC (by linarith) (by norm_num) (by linarith) le_rfl le_rfl
      (by norm_num) (Or.inl rfl) (min_le_left _ _)
      W_P4_lo W_P4_c W_P4_hi hq h0 hvol

/-- `K̄ ⊆ [-2, 2]` (proof.md Lemma 6.1; Math RED M-172). -/
theorem closedSublevel_subset_Icc2 {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) : closedSublevel r ⊆ Set.Icc (-2) 2 := by
  intro x hx
  change |∏ i, (x - r i)| ≤ 1 at hx
  by_contra hc
  rw [Set.mem_Icc, not_and_or, not_le, not_le] at hc
  set t := |x| - 1 with ht
  have ht1 : 1 < t := by
    rw [ht]
    rcases hc with h | h
    · rw [abs_of_neg (by linarith)]; linarith
    · rw [abs_of_pos (by linarith)]; linarith
  have h2 : ∀ i, t ≤ |x - r i| := by
    intro i
    obtain ⟨a, b⟩ := hr i
    rcases hc with h | h
    · rw [ht, abs_of_neg (by linarith), abs_of_neg (by linarith)]; linarith
    · rw [ht, abs_of_pos (by linarith), abs_of_pos (by linarith)]; linarith
  have hp : t ^ n ≤ |∏ i, (x - r i)| := by
    rw [Finset.abs_prod]
    calc t ^ n = ∏ _i : Fin n, t := by simp
      _ ≤ ∏ i, |x - r i| := by gcongr with i; exact h2 i
  have : 1 < t ^ n := one_lt_pow₀ ht1 (Nat.pos_iff_ne_zero.mp hn)
  linarith

/-- The reduction of Lemma 6.3 in the case `M = -α`, for the arcsine range `a ∈ [3/4, 1]`. -/
theorem reduce_left_arc {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤ volume (sublevel r)) {α β : ℝ}
    (hα : |∏ i, (α - r i)| = 1) (_hβ : |∏ i, (β - r i)| ≤ 1)
    (hK : closedSublevel r ⊆ Set.Icc α β)
    (hM1 : 3 / 4 ≤ -α - 1) (hM2 : -α - 1 ≤ 1) : False := by
  have hrK : ∀ i, r i ∈ closedSublevel r := by
    intro i
    change |∏ j, (r i - r j)| ≤ 1
    rw [Finset.prod_eq_zero (Finset.mem_univ i) (sub_self _), abs_zero]
    exact zero_le_one
  have hαr : ∀ i, α ≤ r i := fun i => (hK (hrK i)).1
  set q : Fin n → ℝ := fun j => r j - α with hq
  have hqI : ∀ j, q j ∈ Set.Icc (-α - 1) (-α - 1 + 2) := by
    intro j
    obtain ⟨a, b⟩ := hr j
    exact ⟨by simp only [hq]; linarith, by simp only [hq]; linarith⟩
  have h0 : ∏ j, q j = 1 := by
    rw [← hα, Finset.abs_prod]
    apply Finset.prod_congr rfl
    intro j _
    simp only [hq]
    rw [abs_of_nonpos (by linarith [hαr j])]
    ring
  have hset : Set.Icc 0 (β - α) ∩ General.K q = (fun x => x + α) ⁻¹' closedSublevel r := by
    ext x
    simp only [Set.mem_inter_iff, Set.mem_Icc, Set.mem_preimage, closedSublevel, General.K,
      Set.mem_ofPred_eq]
    have e : ∏ j, (x - q j) = ∏ j, (x + α - r j) := by
      apply Finset.prod_congr rfl; intro j _; simp only [hq]; ring
    rw [e]
    constructor
    · rintro ⟨_, h⟩; exact h
    · intro h
      have := hK h
      exact ⟨⟨by linarith [this.1], by linarith [this.2]⟩, h⟩
  have hvol' : ENNReal.ofReal (2 * √2) ≤ volume (Set.Icc 0 (β - α) ∩ General.K q) := by
    rw [hset, measure_preimage_add_right]
    exact hvol.trans (measure_mono (sublevel_subset_closed r))
  exact arcsine_branch hn q hM1 hM2 hqI h0 hvol'

/-- **The supremum bound (proof.md Theorem 6.7, first part), fully formal**: for every monic
polynomial with all roots in `[-1, 1]` (given by its root vector, `n ≥ 1`), `|S_f| ≤ 2√2`. -/
theorem sup_le {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    volume (sublevel r) ≤ ENNReal.ofReal (2 * √2) := by
  by_contra hc
  push Not at hc
  obtain ⟨α, β, hα, hβ, hK, hM⟩ := sup_counterexample_far hn r hr hc
  have hαK : α ∈ closedSublevel r := by change |∏ i, (α - r i)| ≤ 1; rw [hα]
  have hβK : β ∈ closedSublevel r := by change |∏ i, (β - r i)| ≤ 1; rw [hβ]
  have h2 := closedSublevel_subset_Icc2 hn r hr
  have hα2 := h2 hαK
  have hβ2 := h2 hβK
  rcases le_total β (-α) with hle | hle
  · rw [max_eq_left hle] at hM
    exact reduce_left_arc hn r hr hc.le hα hβ.le hK (by linarith) (by linarith [hα2.1])
  · rw [max_eq_right hle] at hM
    have hr' : ∀ i, (fun i => -r i) i ∈ Set.Icc (-1 : ℝ) 1 := fun i =>
      ⟨by linarith [(hr i).2], by linarith [(hr i).1]⟩
    have hvol' : ENNReal.ofReal (2 * √2) ≤ volume (sublevel (fun i => -r i)) := by
      rw [volume_sublevel_neg]; exact hc.le
    have hα' : |∏ i, (-β - (fun i => -r i) i)| = 1 := by rw [abs_prod_neg]; exact hβ
    have hβ' : |∏ i, (-α - (fun i => -r i) i)| ≤ 1 := by rw [abs_prod_neg]; exact hα.le
    have hK' : closedSublevel (fun i => -r i) ⊆ Set.Icc (-β) (-α) := by
      intro x hx
      have hx' : -x ∈ closedSublevel r := by
        change |∏ i, (-x - r i)| ≤ 1
        have := abs_prod_neg r (-x)
        rw [neg_neg] at this
        rw [← this]; exact hx
      obtain ⟨h1, h2⟩ := hK hx'
      exact ⟨by linarith, by linarith⟩
    exact reduce_left_arc hn _ hr' hvol' hα' hβ' hK' (by linarith) (by linarith [hβ2.2])


/-- If `|S_f| ≥ 2√2`, the extreme points satisfy `max(-α, β) ≤ √2` (both branches excluded). -/
theorem sup_M_le {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤ volume (sublevel r)) {α β : ℝ}
    (hα : |∏ i, (α - r i)| = 1) (hβ : |∏ i, (β - r i)| = 1)
    (hK : closedSublevel r ⊆ Set.Icc α β) : max (-α) β ≤ √2 := by
  by_contra hc
  push Not at hc
  have hαK : α ∈ closedSublevel r := by change |∏ i, (α - r i)| ≤ 1; rw [hα]
  have hβK : β ∈ closedSublevel r := by change |∏ i, (β - r i)| ≤ 1; rw [hβ]
  have h2 := closedSublevel_subset_Icc2 hn r hr
  have hα2 := h2 hαK
  have hβ2 := h2 hβK
  rcases le_total β (-α) with hle | hle
  · rw [max_eq_left hle] at hc
    rcases le_total (-α - 1) (3 / 4) with h34 | h34
    · exact reduce_left hn r hr hvol hα hβ.le hK (by linarith) h34
    · exact reduce_left_arc hn r hr hvol hα hβ.le hK h34 (by linarith [hα2.1])
  · rw [max_eq_right hle] at hc
    have hr' : ∀ i, (fun i => -r i) i ∈ Set.Icc (-1 : ℝ) 1 := fun i =>
      ⟨by linarith [(hr i).2], by linarith [(hr i).1]⟩
    have hvol' : ENNReal.ofReal (2 * √2) ≤ volume (sublevel (fun i => -r i)) := by
      rw [volume_sublevel_neg]; exact hvol
    have hα' : |∏ i, (-β - (fun i => -r i) i)| = 1 := by rw [abs_prod_neg]; exact hβ
    have hβ' : |∏ i, (-α - (fun i => -r i) i)| ≤ 1 := by rw [abs_prod_neg]; exact hα.le
    have hK' : closedSublevel (fun i => -r i) ⊆ Set.Icc (-β) (-α) := by
      intro x hx
      have hx' : -x ∈ closedSublevel r := by
        change |∏ i, (-x - r i)| ≤ 1
        have := abs_prod_neg r (-x)
        rw [neg_neg] at this
        rw [← this]; exact hx
      obtain ⟨h1, h2⟩ := hK hx'
      exact ⟨by linarith, by linarith⟩
    rcases le_total (β - 1) (3 / 4) with h34 | h34
    · exact reduce_left hn _ hr' hvol' hα' hβ' hK' (by linarith) (by linarith)
    · exact reduce_left_arc hn _ hr' hvol' hα' hβ' hK' (by linarith) (by linarith [hβ2.2])

/-- Equality forces the endpoints: if `|S_f| = 2√2` then `|f(√2)| = |f(-√2)| = 1`. -/
theorem sup_eq_endpoints {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (heq : volume (sublevel r) = ENNReal.ofReal (2 * √2)) :
    |∏ i, (√2 - r i)| = 1 ∧ |∏ i, (-√2 - r i)| = 1 := by
  obtain ⟨α, β, hα, hβ, hK⟩ := extreme_points hn r hr
  have hM := sup_M_le hn r hr heq.ge hα hβ hK
  have hlen : ENNReal.ofReal (2 * √2) ≤ ENNReal.ofReal (β - α) := by
    calc ENNReal.ofReal (2 * √2) = volume (sublevel r) := heq.symm
      _ ≤ volume (closedSublevel r) := measure_mono (sublevel_subset_closed r)
      _ ≤ volume (Set.Icc α β) := measure_mono hK
      _ = ENNReal.ofReal (β - α) := Real.volume_Icc
  have hs0 : 0 < √2 := by positivity
  have hαK : α ∈ closedSublevel r := by change |∏ i, (α - r i)| ≤ 1; rw [hα]
  have hab : α ≤ β := (hK hαK).2
  have hba : 2 * √2 ≤ β - α :=
    (ENNReal.ofReal_le_ofReal_iff (by linarith)).mp hlen
  have h1 : -α ≤ √2 := (le_max_left _ _).trans hM
  have h2 : β ≤ √2 := (le_max_right _ _).trans hM
  have eα : α = -√2 := by linarith
  have eβ : β = √2 := by linarith
  rw [eα] at hα; rw [eβ] at hβ
  exact ⟨hβ, hα⟩

open Polynomial in
/-- `p(x) = ∏ (x - r_i)` for the root list of a split monic `p`. -/
theorem eval_eq_prod (p : ℝ[X]) (hm : p.Monic) (hsplit : Multiset.card p.roots = p.natDegree)
    (x : ℝ) : p.eval x = ∏ i : Fin p.roots.toList.length, (x - p.roots.toList[i.1]) := by
  have hp := polyOf_of_split p hm hsplit
  calc p.eval x = (polyOf p.roots).eval x := by rw [hp]
    _ = (p.roots.map (fun r => x - r)).prod := by
        simp [polyOf, Polynomial.eval_multiset_prod, Multiset.map_map]
    _ = ((p.roots.toList : Multiset ℝ).map (fun r => x - r)).prod := by rw [Multiset.coe_toList]
    _ = (p.roots.toList.map (fun r => x - r)).prod := by rw [Multiset.map_coe, Multiset.prod_coe]
    _ = ∏ i : Fin p.roots.toList.length, (x - p.roots.toList[i.1]) :=
        (Fin.prod_univ_fun_getElem _ (fun r => x - r)).symm

open Polynomial in
/-- **proof.md Theorem 6.7, fully formal.** For every monic real polynomial `p` of degree `≥ 1`
whose roots are all real and lie in `[-1, 1]`: `|{x : |p(x)| < 1}| ≤ 2√2`, with equality if and
only if `p = (X² - 1)^m` for some `m ≥ 1`. -/
theorem sup_theorem (p : ℝ[X]) (hm : p.Monic) (hdeg : 1 ≤ p.natDegree)
    (hsplit : Multiset.card p.roots = p.natDegree)
    (hroots : ∀ r ∈ p.roots, r ∈ Set.Icc (-1 : ℝ) 1) :
    volume {x : ℝ | |p.eval x| < 1} ≤ ENNReal.ofReal (2 * √2) ∧
      (volume {x : ℝ | |p.eval x| < 1} = ENNReal.ofReal (2 * √2) ↔
        ∃ m : ℕ, 1 ≤ m ∧ p = (X ^ 2 - 1) ^ m) := by
  set l := p.roots.toList with hl
  set r : Fin l.length → ℝ := fun i => l[i.1] with hrdef
  have hlen : l.length = p.natDegree := by rw [hl, Multiset.length_toList, hsplit]
  have hn : 0 < l.length := by omega
  have hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1 := by
    intro i
    apply hroots
    rw [← Multiset.mem_toList]
    exact List.getElem_mem _
  have hset : {x : ℝ | |p.eval x| < 1} = sublevel r := by
    ext x
    simp only [Set.mem_ofPred_eq, sublevel]
    rw [eval_eq_prod p hm hsplit x]
  refine ⟨hset ▸ sup_le hn r hr, ⟨fun heq => ?_, ?_⟩⟩
  · rw [hset] at heq
    obtain ⟨h1, h2⟩ := sup_eq_endpoints hn r hr heq
    apply thm67_alg p hm hdeg hsplit hroots
    · rw [eval_eq_prod p hm hsplit]; exact h1
    · rw [eval_eq_prod p hm hsplit]; exact h2
  · rintro ⟨m, hm1, rfl⟩
    exact volume_sublevel_sq_sub_one m hm1

end EP1038