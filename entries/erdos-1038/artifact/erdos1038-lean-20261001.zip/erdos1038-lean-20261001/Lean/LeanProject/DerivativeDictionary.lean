import LeanProject.QuantileAngle

/-!
# The actual series width derivative in angle coordinates

Exterior Poisson parameters are constructed from each endpoint. The quantile
change of variables identifies the existing `Stage10.Mdot`, rather than replacing
it by a newly defined formula with an unproved equivalence.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage11
open EP1038.Arc
open AngleReference

theorem Kr_pos {r ρ : ℝ} (hr : 0 < r) (h0 : 0 < ρ) (h1 : ρ < 1) : 0 < Kr r ρ :=
  div_pos (mul_pos hr (by nlinarith)) (by positivity)

theorem exterior_parameter_exists {c r x : ℝ} (hr : 0 < r) (hx : x < c - r) :
    ∃ ρ : ℝ, 0 < ρ ∧ ρ < 1 ∧ x = c - r / 2 * (ρ + 1 / ρ) := by
  let m := c - x
  let K := √(m ^ 2 - r ^ 2)
  have hm : r < m := by dsimp [m]; linarith
  have hD : 0 < m ^ 2 - r ^ 2 := by nlinarith
  have hK : 0 < K := Real.sqrt_pos.mpr hD
  have hK2 : K ^ 2 = m ^ 2 - r ^ 2 := Real.sq_sqrt hD.le
  have hs : 0 < m + K := by linarith
  refine ⟨r / (m + K), div_pos hr hs, (div_lt_one hs).mpr (by linarith), ?_⟩
  have hrn := hr.ne'
  have hsn := hs.ne'
  have heq : r / 2 * (r / (m + K) + 1 / (r / (m + K))) = m := by
    field_simp
    nlinarith [hK2]
  rw [heq]
  dsimp [m]
  ring

noncomputable def exteriorParameter (c r x : ℝ) (hr : 0 < r) (hx : x < c - r) : ℝ :=
  (exterior_parameter_exists hr hx).choose

theorem exteriorParameter_spec {c r x : ℝ} (hr : 0 < r) (hx : x < c - r) :
    0 < exteriorParameter c r x hr hx ∧ exteriorParameter c r x hr hx < 1 ∧
      x = c - r / 2 * (exteriorParameter c r x hr hx + 1 / exteriorParameter c r x hr hx) :=
  (exterior_parameter_exists hr hx).choose_spec

theorem poisson_exterior {c r x ρ : ℝ} (hr : 0 < r) (h0 : 0 < ρ) (h1 : ρ < 1)
    (hx : x = c - r / 2 * (ρ + 1 / ρ)) (θ : ℝ) :
    Pq ρ θ = Kr r ρ / (position c r θ - x) := by
  have hD := Pq_den_pos h0.le h1 θ
  have heq : position c r θ - x = r / (2 * ρ) * (1 - 2 * ρ * cos θ + ρ ^ 2) := by
    rw [hx]
    dsimp [position]
    field_simp
    ring
  rw [heq]
  dsimp [Pq, Kr]
  field_simp

namespace AngleReference

/-- The exterior material integral in `Mdot` is exactly its Poisson integral. -/
theorem integral_velocity_exterior (A : AngleReference) (T : ℝ → ℝ)
    {c r x ρ : ℝ} (hr : 0 < r) (h0 : 0 < ρ) (h1 : ρ < 1)
    (hx : x = c - r / 2 * (ρ + 1 / ρ)) :
    (∫ u in (0 : ℝ)..1, (T u - A.quantile c r u) / (A.quantile c r u - x)) =
      1 / Kr r ρ * (1 / π * ∫ θ in (0 : ℝ)..π, A.angularVelocity c r T θ * Pq ρ θ) := by
  rw [A.integral_cdf]
  have hfun : (∫ θ in (0 : ℝ)..π,
      ((T (A.cdf θ) - A.quantile c r (A.cdf θ)) / (A.quantile c r (A.cdf θ) - x)) *
        alpha A.k A.ρ θ) =
      ∫ θ in (0 : ℝ)..π, 1 / Kr r ρ * (A.angularVelocity c r T θ * Pq ρ θ) := by
    apply intervalIntegral.integral_congr
    intro θ hθ
    rw [uIcc_of_le Real.pi_pos.le] at hθ
    have hK := (Kr_pos hr h0 h1).ne'
    dsimp only
    rw [A.quantile_cdf c r hθ, poisson_exterior hr h0 h1 hx θ]
    simp only [angularVelocity, angularTarget, foldedAngle_eq hθ]
    field_simp
  rw [hfun, intervalIntegral.integral_const_mul]
  ring

/-- Identification with the existing formal series derivative; the endpoint data
are explicit and need not be treated as hypothetical derivative formulas. -/
theorem Mdot_eq_widthVariation (A : AngleReference) (T : ℝ → ℝ)
    {c r ρp ρm : ℝ} (hr : 0 < r)
    (hp0 : 0 < ρp) (hp1 : ρp < 1) (hm0 : 0 < ρm) (hm1 : ρm < 1)
    (hxp : Stage10.xpS A.k (A.quantile c r) = c - r / 2 * (ρp + 1 / ρp))
    (hxm : Stage10.xmS A.k (A.quantile c r) = c - r / 2 * (ρm + 1 / ρm)) :
    Stage10.Mdot A.k (A.quantile c r) T =
      widthVariation r ρp ρm
        (1 / (A.k * Stage10.GS A.k (A.quantile c r) (Stage10.xpS A.k (A.quantile c r))))
        (-(1 / (A.k * Stage10.GS A.k (A.quantile c r) (Stage10.xmS A.k (A.quantile c r)))))
        (A.angularVelocity c r T) := by
  rw [Stage10.Mdot, A.integral_velocity_exterior T hr hp0 hp1 hxp,
    A.integral_velocity_exterior T hr hm0 hm1 hxm]
  dsimp [widthVariation, poissonPair]
  ring

end AngleReference
end EP1038.Stage11
