import LeanProject.Stage10C4

/-!
# EP-1038, Stage 10 Part (c), N3: convergence and the functional equation `Φ = z φ(Φ)`

Abstract setting: `φ_j ≥ 0` with `∑ φ_j wʲ < ∞` for `0 ≤ w < ρ`; `φv w = ∑' φ_j wʲ`.
If `Z > 0`, `0 < r < ρ` and `Z φv(r) ≤ r`, then
* `partial_le`: `∑_{n ≤ N} c_n Zⁿ ≤ r` for every `N`;
* `AC_Phi`, `ev_Phi_le`: `Φ(z)` converges absolutely for `|z| ≤ Z`, and `Φ(Z) ≤ r`;
* `Phi_functional` (**N3**): `Φ(z) = z φv(Φ(z))` for `|z| ≤ Z`.
-/

open Real Set Filter Topology PowerSeries Finset

namespace EP1038.Stage10

/-- `φv w = ∑' φ_j wʲ`. -/
noncomputable def phiv (φ : ℕ → ℝ) (w : ℝ) : ℝ := ∑' j, φ j * w ^ j

theorem phiv_mono {φ : ℕ → ℝ} (hφ : ∀ j, 0 ≤ φ j) {w1 w2 : ℝ} (h0 : 0 ≤ w1) (h12 : w1 ≤ w2)
    (hs : Summable fun j => φ j * w2 ^ j) : phiv φ w1 ≤ phiv φ w2 := by
  have hle : ∀ j, φ j * w1 ^ j ≤ φ j * w2 ^ j := fun j =>
    mul_le_mul_of_nonneg_left (pow_le_pow_left₀ h0 h12 j) (hφ j)
  have hs1 : Summable fun j => φ j * w1 ^ j :=
    hs.of_nonneg_of_le (fun j => mul_nonneg (hφ j) (pow_nonneg h0 j)) hle
  exact hs1.tsum_le_tsum hle hs

/-- A polynomial-like series (finitely many nonzero coefficients) converges everywhere. -/
theorem AC_of_trunc {A : PowerSeries ℝ} {N : ℕ} (h : ∀ m, N < m → coeff m A = 0) (x : ℝ) :
    AC A x := by
  unfold AC
  exact summable_of_ne_finset_zero (s := range (N + 1)) fun m hm => by
    rw [Finset.mem_range, not_lt] at hm
    rw [h m (by omega), zero_mul, norm_zero]

theorem ev_of_trunc {A : PowerSeries ℝ} {N : ℕ} (h : ∀ m, N < m → coeff m A = 0) (x : ℝ) :
    ev A x = ∑ m ∈ range (N + 1), coeff m A * x ^ m := by
  unfold ev
  rw [tsum_eq_sum (s := range (N + 1))]
  intro m hm
  rw [Finset.mem_range, not_lt] at hm
  rw [h m (by omega), zero_mul]

section N3

variable {φ : ℕ → ℝ} {ρ : ℝ} (hφ : ∀ j, 0 ≤ φ j)
  (hconv : ∀ w, 0 ≤ w → w < ρ → Summable fun j => φ j * w ^ j)
include hφ hconv

/-- **N3, bound**: `∑_{n ≤ N} c_n Zⁿ ≤ r`. -/
theorem partial_le {Z r : ℝ} (hZ : 0 < Z) (hr : 0 < r) (hrρ : r < ρ) (hfix : Z * phiv φ r ≤ r) :
    ∀ N, ∑ n ∈ range (N + 1), coeff n (PhiS φ) * Z ^ n ≤ r
  | 0 => by simp [coeff_Phi_zero, hr.le]
  | N + 1 => by
    have ih := partial_le hZ hr hrρ hfix N
    set P := Pinv φ N
    have hPgt : ∀ m, N < m → coeff m P = 0 := coeff_P_gt φ N
    have hPNN : NN P := NN_Pinv hφ N
    have hevP : ev P Z = ∑ n ∈ range (N + 1), coeff n (PhiS φ) * Z ^ n := by
      rw [ev_of_trunc hPgt]
      exact Finset.sum_congr rfl fun n hn =>
        by rw [coeff_P_le φ N n (by rw [Finset.mem_range] at hn; omega)]
    have hevP0 : 0 ≤ ev P Z := ev_nonneg hPNN hZ.le
    have hACP := AC_of_trunc hPgt Z
    -- each inner partial sum is at most `(ev P Z)^j`
    have hinner : ∀ j, ∑ m ∈ range (N + 1), coeff m (P ^ j) * Z ^ m ≤ ev P Z ^ j := by
      intro j
      rw [← (AC_pow hACP j).2]
      unfold ev
      refine ((AC_abs_iff (NN_pow hPNN j) Z).mp (AC_pow hACP j).1 |>.congr fun m => by
        rw [abs_of_pos hZ]).sum_le_tsum _ fun m _ => mul_nonneg (NN_pow hPNN j m) (pow_nonneg hZ.le m)
    have hsumφ : Summable fun j => φ j * ev P Z ^ j := hconv _ hevP0 (by linarith)
    calc ∑ n ∈ range (N + 1 + 1), coeff n (PhiS φ) * Z ^ n
        = coeff 0 (PhiS φ) * Z ^ 0 + ∑ m ∈ range (N + 1), coeff (m + 1) (PhiS φ) * Z ^ (m + 1) := by
          rw [Finset.sum_range_succ', add_comm]
      _ = Z * ∑ m ∈ range (N + 1), ∑ j ∈ range (m + 1), φ j * coeff m (P ^ j) * Z ^ m := by
          rw [coeff_Phi_zero, zero_mul, zero_add, Finset.mul_sum]
          refine Finset.sum_congr rfl fun m hm => ?_
          rw [Finset.mem_range] at hm
          rw [coeff_Phi_succ, Finset.sum_mul, Finset.mul_sum, pow_succ]
          refine Finset.sum_congr rfl fun j _ => ?_
          rw [coeff_pow_agree (N := N) (fun i hi => (coeff_P_le φ N i hi).symm) j m (by omega)]
          ring
      _ ≤ Z * ∑ m ∈ range (N + 1), ∑ j ∈ range (N + 1), φ j * coeff m (P ^ j) * Z ^ m := by
          refine mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun m hm => ?_) hZ.le
          rw [Finset.mem_range] at hm
          exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono (by omega))
            fun j _ _ => mul_nonneg (mul_nonneg (hφ j) (NN_pow hPNN j m)) (pow_nonneg hZ.le m)
      _ = Z * ∑ j ∈ range (N + 1), φ j * ∑ m ∈ range (N + 1), coeff m (P ^ j) * Z ^ m := by
          rw [Finset.sum_comm]
          congr 1
          refine Finset.sum_congr rfl fun j _ => ?_
          rw [Finset.mul_sum]
          refine Finset.sum_congr rfl fun m _ => ?_
          ring
      _ ≤ Z * ∑ j ∈ range (N + 1), φ j * ev P Z ^ j := by
          refine mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun j _ =>
            mul_le_mul_of_nonneg_left (hinner j) (hφ j)) hZ.le
      _ ≤ Z * phiv φ (ev P Z) := by
          refine mul_le_mul_of_nonneg_left ?_ hZ.le
          exact hsumφ.sum_le_tsum _ fun j _ => mul_nonneg (hφ j) (pow_nonneg hevP0 j)
      _ ≤ Z * phiv φ r := by
          refine mul_le_mul_of_nonneg_left ?_ hZ.le
          exact phiv_mono hφ hevP0 (by rw [hevP]; exact ih) (hconv r hr.le hrρ)
      _ ≤ r := hfix

theorem AC_Phi {Z r : ℝ} (hZ : 0 < Z) (hr : 0 < r) (hrρ : r < ρ) (hfix : Z * phiv φ r ≤ r)
    {z : ℝ} (hz : |z| ≤ Z) : AC (PhiS φ) z := by
  have hNN := NN_Phi hφ
  have hsZ : Summable fun n => coeff n (PhiS φ) * Z ^ n :=
    summable_of_sum_range_le (fun n => mul_nonneg (hNN n) (pow_nonneg hZ.le n))
      fun N => (Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono (Nat.le_succ N))
        fun n _ _ => mul_nonneg (hNN n) (pow_nonneg hZ.le n)).trans
        (partial_le hφ hconv hZ hr hrρ hfix N)
  rw [AC_abs_iff hNN]
  exact hsZ.of_nonneg_of_le (fun n => mul_nonneg (hNN n) (pow_nonneg (abs_nonneg z) n))
    fun n => mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (abs_nonneg z) hz n) (hNN n)

theorem ev_Phi_le {Z r : ℝ} (hZ : 0 < Z) (hr : 0 < r) (hrρ : r < ρ) (hfix : Z * phiv φ r ≤ r) :
    ev (PhiS φ) Z ≤ r := by
  have hNN := NN_Phi hφ
  have hAC := AC_Phi hφ hconv hZ hr hrρ hfix (le_of_eq (abs_of_pos hZ))
  have hs : Summable fun n => coeff n (PhiS φ) * Z ^ n := by
    have := (AC_abs_iff hNN Z).mp hAC; simpa [abs_of_pos hZ] using this
  unfold ev
  refine hs.tsum_le_of_sum_range_le fun N => ?_
  rcases N with _ | N
  · simp [hr.le]
  · exact partial_le hφ hconv hZ hr hrρ hfix N

theorem ev_Phi_abs_le {Z r : ℝ} (hZ : 0 < Z) (hr : 0 < r) (hrρ : r < ρ) (hfix : Z * phiv φ r ≤ r)
    {z : ℝ} (hz : |z| ≤ Z) : ev (PhiS φ) |z| ≤ r := by
  have hNN := NN_Phi hφ
  have hAC := AC_Phi hφ hconv hZ hr hrρ hfix (le_of_eq (abs_of_pos hZ))
  have hsZ : Summable fun n => coeff n (PhiS φ) * Z ^ n := by
    have := (AC_abs_iff hNN Z).mp hAC; simpa [abs_of_pos hZ] using this
  refine le_trans ?_ (ev_Phi_le hφ hconv hZ hr hrρ hfix)
  unfold ev
  have hle : ∀ n, coeff n (PhiS φ) * |z| ^ n ≤ coeff n (PhiS φ) * Z ^ n := fun n =>
    mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (abs_nonneg z) hz n) (hNN n)
  exact (hsZ.of_nonneg_of_le (fun n => mul_nonneg (hNN n) (pow_nonneg (abs_nonneg z) n)) hle).tsum_le_tsum
    hle hsZ

/-- **N3, functional equation**: `Φ(z) = z φv(Φ(z))` for `|z| ≤ Z`. -/
theorem Phi_functional {Z r : ℝ} (hZ : 0 < Z) (hr : 0 < r) (hrρ : r < ρ) (hfix : Z * phiv φ r ≤ r)
    {z : ℝ} (hz : |z| ≤ Z) : ev (PhiS φ) z = z * phiv φ (ev (PhiS φ) z) := by
  have hNN := NN_Phi hφ
  have hAC := AC_Phi hφ hconv hZ hr hrρ hfix hz
  have habs := ev_Phi_abs_le hφ hconv hZ hr hrρ hfix hz
  have hs : Summable fun j => φ j * ev (PhiS φ) |z| ^ j :=
    hconv _ (ev_nonneg hNN (abs_nonneg z)) (by linarith)
  obtain ⟨hsum, heq⟩ := comp_ev hNN hφ hAC hs
  have hser : Summable fun n => coeff n (PhiS φ) * z ^ n := hAC.of_norm
  have e : ∀ m, coeff (m + 1) (PhiS φ) * z ^ (m + 1) =
      z * ((∑' j, φ j * coeff m (PhiS φ ^ j)) * z ^ m) := fun m => by
    rw [coeff_Phi_succ_tsum, pow_succ]; ring
  have hL : ev (PhiS φ) z = z * ∑' m, (∑' j, φ j * coeff m (PhiS φ ^ j)) * z ^ m := by
    unfold ev
    rw [hser.tsum_eq_zero_add, coeff_Phi_zero, zero_mul, zero_add]
    simp_rw [e]
    rw [tsum_mul_left]
  calc ev (PhiS φ) z = z * ∑' m, (∑' j, φ j * coeff m (PhiS φ ^ j)) * z ^ m := hL
    _ = z * phiv φ (ev (PhiS φ) z) := by rw [heq]; rfl

end N3

end EP1038.Stage10
