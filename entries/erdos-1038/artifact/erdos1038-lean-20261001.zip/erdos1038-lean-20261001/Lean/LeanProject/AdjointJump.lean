import LeanProject.BernsteinLipschitz
import Mathlib.MeasureTheory.Integral.Prod

/-!
# Positive atomic jumps in the adjoint inequality

The required lower-bound direction can be obtained by Fatou from increasing ramps.
This avoids assuming convergence of principal-value integrals at a jump and retains
the favorable endpoint correction. Exact equality for jumps is a stronger statement.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset
open scoped ENNReal

namespace EP1038.Stage11

open EP1038.Arc

noncomputable def jump (z θ : ℝ) : ℝ := if Real.cos θ < z then 1 else 0

noncomputable def jumpRamp (z : ℝ) (n : ℕ) (θ : ℝ) : ℝ :=
  min 1 (max 0 (((n : ℝ) + 1) / (z + 1) * (z - Real.cos θ)))

theorem measurable_jump (z : ℝ) : Measurable (jump z) :=
  Measurable.ite (measurableSet_lt Real.continuous_cos.measurable measurable_const)
    measurable_const measurable_const

theorem jumpRamp_XLip {z : ℝ} (hz : -1 < z) (n : ℕ) :
    XLip (((n : ℝ) + 1) / (z + 1)) (jumpRamp z n) := by
  intro φ θ
  have hc : 0 < ((n : ℝ) + 1) / (z + 1) := div_pos (by positivity) (by linarith)
  apply le_trans (abs_min_sub_min_le_max 1 _ 1 _)
  simp only [sub_self, abs_zero, max_eq_right (abs_nonneg
    (max 0 (((n : ℝ) + 1) / (z + 1) * (z - Real.cos φ)) -
      max 0 (((n : ℝ) + 1) / (z + 1) * (z - Real.cos θ))))]
  apply le_trans (abs_max_sub_max_le_max 0 _ 0 _)
  simp only [sub_self, abs_zero, max_eq_right (abs_nonneg
    (((n : ℝ) + 1) / (z + 1) * (z - Real.cos φ) -
      ((n : ℝ) + 1) / (z + 1) * (z - Real.cos θ)))]
  rw [← mul_sub, show (z - Real.cos φ) - (z - Real.cos θ) =
    -(Real.cos φ - Real.cos θ) by ring, abs_mul, abs_neg, abs_of_pos hc]

theorem jumpRamp_bounds (z : ℝ) (n : ℕ) (θ : ℝ) : jumpRamp z n θ ∈ Set.Icc (0 : ℝ) 1 :=
  ⟨le_min zero_le_one (le_max_left _ _), min_le_left _ _⟩

theorem jumpRamp_pi {z : ℝ} (hz : -1 < z) (n : ℕ) : jumpRamp z n π = 1 := by
  have hn : (1 : ℝ) ≤ (n : ℝ) + 1 := by linarith [Nat.cast_nonneg (α := ℝ) n]
  simp only [jumpRamp, Real.cos_pi, sub_neg_eq_add]
  rw [div_mul_cancel₀ _ (by linarith : z + 1 ≠ 0), max_eq_right (by linarith), min_eq_left hn]

theorem jumpRamp_tendsto {z : ℝ} (hz : -1 < z) (θ : ℝ) :
    Tendsto (fun n => jumpRamp z n θ) atTop (𝓝 (jump z θ)) := by
  by_cases hθ : Real.cos θ < z
  · have hc : 0 < (z - Real.cos θ) / (z + 1) := div_pos (by linarith) (by linarith)
    have ht : Tendsto (fun n : ℕ => ((n : ℝ) + 1) * ((z - Real.cos θ) / (z + 1)))
        atTop atTop := (tendsto_atTop_add_const_right atTop (1 : ℝ)
          tendsto_natCast_atTop_atTop).atTop_mul_const hc
    simp only [jump, hθ, ite_true]
    apply tendsto_const_nhds.congr' (show (fun _ : ℕ => (1 : ℝ)) =ᶠ[atTop]
        (fun n => jumpRamp z n θ) from ?_)
    filter_upwards [ht.eventually (eventually_ge_atTop 1)] with n hn
    simp only [jumpRamp]
    rw [show ((n : ℝ) + 1) / (z + 1) * (z - Real.cos θ) =
      ((n : ℝ) + 1) * ((z - Real.cos θ) / (z + 1)) by ring,
      max_eq_right (by linarith), min_eq_left hn]
  · have hnonpos : ∀ n : ℕ, ((n : ℝ) + 1) / (z + 1) * (z - Real.cos θ) ≤ 0 := by
      intro n
      exact mul_nonpos_of_nonneg_of_nonpos
        (div_nonneg (show 0 ≤ (n : ℝ) + 1 by positivity) (by linarith))
        (by linarith)
    simp only [jumpRamp, max_eq_left (hnonpos _), min_eq_right zero_le_one, jump, hθ, ite_false]
    exact tendsto_const_nhds

theorem dq_nonneg_of_monotone {f : ℝ → ℝ} (hf : MonotoneOn f (Set.Icc (0 : ℝ) π))
    {θ φ : ℝ} (hθ : θ ∈ Set.Icc (0 : ℝ) π) (hφ : φ ∈ Set.Icc (0 : ℝ) π) :
    0 ≤ (f φ - f θ) / (Real.cos θ - Real.cos φ) := by
  rcases le_total θ φ with h | h
  · exact div_nonneg (sub_nonneg.mpr (hf hθ hφ h))
      (sub_nonneg.mpr (Real.cos_le_cos_of_nonneg_of_le_pi hθ.1 hφ.2 h))
  · exact div_nonneg_of_nonpos (sub_nonpos.mpr (hf hφ hθ h))
      (sub_nonpos.mpr (Real.cos_le_cos_of_nonneg_of_le_pi hφ.1 hθ.2 h))

theorem jumpRamp_monotone {z : ℝ} (hz : -1 < z) (n : ℕ) :
    MonotoneOn (jumpRamp z n) (Set.Icc (0 : ℝ) π) := by
  intro θ hθ φ hφ h
  apply min_le_min le_rfl
  apply max_le_max le_rfl
  exact mul_le_mul_of_nonneg_left (sub_le_sub_left
    (Real.cos_le_cos_of_nonneg_of_le_pi hθ.1 hφ.2 h) z)
      (div_nonneg (by positivity) (by linarith))

theorem jump_monotone (z : ℝ) : MonotoneOn (jump z) (Set.Icc (0 : ℝ) π) := by
  intro θ hθ φ hφ h
  have hc := Real.cos_le_cos_of_nonneg_of_le_pi hθ.1 hφ.2 h
  dsimp [jump]
  split_ifs <;> norm_num <;> linarith

noncomputable def angleMeasure : Measure ℝ := volume.restrict (Set.Ioc (0 : ℝ) π)

instance angleMeasure_finite : IsFiniteMeasure angleMeasure :=
  isFiniteMeasure_restrict.mpr measure_Ioc_lt_top.ne

noncomputable def weightedDQ (B f : ℝ → ℝ) (p : ℝ × ℝ) : ℝ :=
  (f p.2 - f p.1) / (Real.cos p.1 - Real.cos p.2) * B p.1

theorem weightedDQ_measurable {B f : ℝ → ℝ} (hB : Measurable B) (hf : Measurable f) :
    Measurable (weightedDQ B f) := by
  exact ((hf.comp measurable_snd).sub (hf.comp measurable_fst)).div
    ((Real.continuous_cos.measurable.comp measurable_fst).sub
      (Real.continuous_cos.measurable.comp measurable_snd)) |>.mul (hB.comp measurable_fst)

theorem Bxi_bounds {ρ1 ρ2 σ1 σ2 : ℝ} (h10 : 0 ≤ ρ1) (h11 : ρ1 < 1)
    (h20 : 0 ≤ ρ2) (h21 : ρ2 < 1) (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (θ : ℝ) :
    0 ≤ Bxi ρ1 ρ2 σ1 σ2 θ ∧
      Bxi ρ1 ρ2 σ1 σ2 θ ≤ σ1 * Pq ρ1 0 + σ2 * Pq ρ2 0 := by
  have hp1 := Pq_nonneg h10 h11 θ
  have hp2 := Pq_nonneg h20 h21 θ
  have hl1 := Pq_le h10 h11 θ
  have hl2 := Pq_le h20 h21 θ
  rw [← Pq_zero_val h11] at hl1
  rw [← Pq_zero_val h21] at hl2
  dsimp [Bxi]
  constructor
  · nlinarith [mul_nonneg hs1 (sub_nonneg.mpr hl1), mul_nonneg hs2 (sub_nonneg.mpr hl2)]
  · nlinarith [mul_nonneg hs1 hp1, mul_nonneg hs2 hp2]

theorem weightedDQ_integrable {B f : ℝ → ℝ} {M C : ℝ} (hf : XLip M f) (hM : 0 ≤ M)
    (hB : Measurable B) (hC : ∀ θ, |B θ| ≤ C) :
    Integrable (weightedDQ B f) (angleMeasure.prod angleMeasure) := by
  apply (integrable_const (M * C)).mono'
    (weightedDQ_measurable hB hf.continuous.measurable).aestronglyMeasurable
  apply Eventually.of_forall
  intro p
  rw [Real.norm_eq_abs, weightedDQ, abs_mul]
  exact mul_le_mul (dq_bound hf hM p.1 p.2) (hC p.1) (abs_nonneg _) hM

theorem ae_angle_pair : ∀ᵐ p ∂angleMeasure.prod angleMeasure,
    p.1 ∈ Set.Icc (0 : ℝ) π ∧ p.2 ∈ Set.Icc (0 : ℝ) π := by
  apply (Measure.ae_prod_iff_ae_ae (MeasurableSet.prod measurableSet_Icc measurableSet_Icc)).mpr
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with θ hθ
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with φ hφ
  exact ⟨⟨hθ.1.le, hθ.2⟩, ⟨hφ.1.le, hφ.2⟩⟩

theorem weightedDQ_nonneg {B f : ℝ → ℝ} (hB : ∀ θ, 0 ≤ B θ)
    (hf : MonotoneOn f (Set.Icc (0 : ℝ) π)) :
    0 ≤ᵐ[angleMeasure.prod angleMeasure] weightedDQ B f := by
  filter_upwards [ae_angle_pair] with p hp
  exact mul_nonneg (dq_nonneg_of_monotone hf hp.1 hp.2) (hB p.1)

theorem integral_weightedDQ_inner (B f : ℝ → ℝ) (θ : ℝ) :
    (∫ φ, weightedDQ B f (θ, φ) ∂angleMeasure) = π * (HT f θ * B θ) := by
  change (∫ φ in Set.Ioc (0 : ℝ) π,
    (f φ - f θ) / (Real.cos θ - Real.cos φ) * B θ) = _
  rw [MeasureTheory.integral_mul_const]
  rw [HT, intervalIntegral.integral_of_le Real.pi_pos.le]
  field_simp

theorem integral_weightedDQ {B f : ℝ → ℝ}
    (hf : Integrable (weightedDQ B f) (angleMeasure.prod angleMeasure)) :
    (∫ p, weightedDQ B f p ∂angleMeasure.prod angleMeasure) =
      π * ∫ θ in (0 : ℝ)..π, HT f θ * B θ := by
  rw [integral_prod _ hf]
  simp_rw [integral_weightedDQ_inner]
  rw [MeasureTheory.integral_const_mul, intervalIntegral.integral_of_le Real.pi_pos.le]
  rfl

theorem integrable_HT_weight {B f : ℝ → ℝ}
    (hf : Integrable (weightedDQ B f) (angleMeasure.prod angleMeasure)) :
    IntervalIntegrable (fun θ => HT f θ * B θ) volume 0 π := by
  have h := hf.integral_prod_left
  simp_rw [integral_weightedDQ_inner] at h
  have h' := h.const_mul (1 / π)
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le]
  simpa only [← mul_assoc, one_div_mul_cancel Real.pi_ne_zero, one_mul,
    angleMeasure, IntegrableOn] using h'

/-- Fatou for nonnegative real kernels, including finiteness of the limit integral. -/
theorem nonnegative_integral_limit {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {F : ℕ → α → ℝ} {f : α → ℝ} {C : ℝ}
    (hFm : ∀ n, Measurable (F n)) (hfm : Measurable f)
    (hFi : ∀ n, Integrable (F n) μ) (hFn : ∀ n, 0 ≤ᵐ[μ] F n) (hfn : 0 ≤ᵐ[μ] f)
    (hlim : ∀ x, Tendsto (fun n => F n x) atTop (𝓝 (f x)))
    (hInt : Tendsto (fun n => ∫ x, F n x ∂μ) atTop (𝓝 C)) :
    Integrable f μ ∧ (∫ x, f x ∂μ) ≤ C := by
  have hfat := lintegral_liminf_le (fun n => ENNReal.measurable_ofReal.comp (hFm n))
    (u := atTop) (μ := μ)
  have hLI : Tendsto (fun n => ∫⁻ x, ENNReal.ofReal (F n x) ∂μ) atTop
      (𝓝 (ENNReal.ofReal C)) := by
    have h := ENNReal.tendsto_ofReal hInt
    exact h.congr' (Eventually.of_forall fun n => ofReal_integral_eq_lintegral_ofReal (hFi n) (hFn n))
  have hbound : (∫⁻ x, ENNReal.ofReal (f x) ∂μ) ≤ ENNReal.ofReal C := by
    calc
      _ = ∫⁻ x, liminf (fun n => ENNReal.ofReal (F n x)) atTop ∂μ := by
        apply lintegral_congr
        intro x
        exact (ENNReal.tendsto_ofReal (hlim x)).liminf_eq.symm
      _ ≤ _ := hfat
      _ = _ := hLI.liminf_eq
  have hfi : Integrable f μ := ⟨hfm.aestronglyMeasurable,
    (hasFiniteIntegral_iff_ofReal hfn).mpr (lt_of_le_of_lt hbound ENNReal.ofReal_lt_top)⟩
  have hC : 0 ≤ C := ge_of_tendsto' hInt (fun n => integral_nonneg_of_ae (hFn n))
  refine ⟨hfi, ?_⟩
  rw [← ofReal_integral_eq_lintegral_ofReal hfi hfn] at hbound
  exact (ENNReal.ofReal_le_ofReal_iff hC).mp hbound

noncomputable def poissonPair (r ρ1 ρ2 σ1 σ2 : ℝ) (f : ℝ → ℝ) : ℝ :=
  σ1 / Kr r ρ1 * (1 / π * ∫ θ in (0 : ℝ)..π, f θ * Pq ρ1 θ) +
  σ2 / Kr r ρ2 * (1 / π * ∫ θ in (0 : ℝ)..π, f θ * Pq ρ2 θ)

theorem int_ramp_Pq_tendsto {z ρ : ℝ} (hz : -1 < z) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) :
    Tendsto (fun n => ∫ θ in (0 : ℝ)..π, jumpRamp z n θ * Pq ρ θ) atTop
      (𝓝 (∫ θ in (0 : ℝ)..π, jump z θ * Pq ρ θ)) := by
  refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
    (fun θ => |Pq ρ θ|)
    (Eventually.of_forall fun n => ((jumpRamp_XLip hz n).continuous.mul
      (Pq_cont hρ0 hρ1)).aestronglyMeasurable) ?_
    ((Pq_cont hρ0 hρ1).abs.intervalIntegrable _ _)
    (Eventually.of_forall fun θ _ => (jumpRamp_tendsto hz θ).mul tendsto_const_nhds)
  apply Eventually.of_forall
  intro n
  apply Eventually.of_forall
  intro θ _
  rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg (jumpRamp_bounds z n θ).1]
  exact mul_le_of_le_one_left (abs_nonneg _) (jumpRamp_bounds z n θ).2

/-- A positive jump has finite adjoint integral and the favorable inequality direction.
This is sufficient for the lower-bound argument; it does not assert the stronger equality. -/
theorem L_jump_nonneg {r ρ1 ρ2 σ1 σ2 z : ℝ} (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (hz : -1 < z) :
    Integrable (weightedDQ (Bxi ρ1 ρ2 σ1 σ2) (jump z))
      (angleMeasure.prod angleMeasure) ∧ 0 ≤ Lfun r ρ1 ρ2 σ1 σ2 (jump z) := by
  let B := Bxi ρ1 ρ2 σ1 σ2
  have hBm : Measurable B := (Bxi_cont h10.le h11 h20.le h21).measurable
  have hBn : ∀ θ, 0 ≤ B θ := fun θ => (Bxi_bounds h10.le h11 h20.le h21 hs1 hs2 θ).1
  have hBb : ∀ θ, |B θ| ≤ σ1 * Pq ρ1 0 + σ2 * Pq ρ2 0 := by
    intro θ
    rw [abs_of_nonneg (hBn θ)]
    exact (Bxi_bounds h10.le h11 h20.le h21 hs1 hs2 θ).2
  have hFi : ∀ n, Integrable (weightedDQ B (jumpRamp z n))
      (angleMeasure.prod angleMeasure) := fun n =>
    weightedDQ_integrable (jumpRamp_XLip hz n)
      (div_nonneg (by positivity) (by linarith)) hBm hBb
  have hEq : ∀ n, (∫ p, weightedDQ B (jumpRamp z n) p
      ∂angleMeasure.prod angleMeasure) = π ^ 2 * r *
        (Gam r ρ1 ρ2 σ1 σ2 - poissonPair r ρ1 ρ2 σ1 σ2 (jumpRamp z n)) := by
    intro n
    have hL := L_XLip (σ1 := σ1) (σ2 := σ2) hr h10 h11 h20 h21
      (div_nonneg (by positivity) (by linarith)) (jumpRamp_XLip hz n)
    change -poissonPair r ρ1 ρ2 σ1 σ2 (jumpRamp z n) - 1 / (π * r) *
      (∫ θ in (0 : ℝ)..π, HT (jumpRamp z n) θ * B θ) +
        Gam r ρ1 ρ2 σ1 σ2 * jumpRamp z n π = 0 at hL
    rw [jumpRamp_pi hz, mul_one] at hL
    have hI : (∫ θ in (0 : ℝ)..π, HT (jumpRamp z n) θ * B θ) /
        (π * r) = Gam r ρ1 ρ2 σ1 σ2 - poissonPair r ρ1 ρ2 σ1 σ2 (jumpRamp z n) := by
      rw [div_eq_mul_one_div]
      linarith
    rw [div_eq_iff (mul_ne_zero Real.pi_ne_zero hr.ne')] at hI
    rw [integral_weightedDQ (hFi n), hI]
    ring
  have hPt : Tendsto (fun n => poissonPair r ρ1 ρ2 σ1 σ2 (jumpRamp z n)) atTop
      (𝓝 (poissonPair r ρ1 ρ2 σ1 σ2 (jump z))) :=
    (((int_ramp_Pq_tendsto hz h10.le h11).const_mul (1 / π)).const_mul _).add
      (((int_ramp_Pq_tendsto hz h20.le h21).const_mul (1 / π)).const_mul _)
  have hInt : Tendsto (fun n => ∫ p, weightedDQ B (jumpRamp z n) p
      ∂angleMeasure.prod angleMeasure) atTop
      (𝓝 (π ^ 2 * r * (Gam r ρ1 ρ2 σ1 σ2 - poissonPair r ρ1 ρ2 σ1 σ2 (jump z)))) := by
    simp_rw [hEq]
    exact (tendsto_const_nhds.sub hPt).const_mul _
  obtain ⟨hji, hjb⟩ := nonnegative_integral_limit
    (fun n => weightedDQ_measurable hBm (jumpRamp_XLip hz n).continuous.measurable)
    (weightedDQ_measurable hBm (measurable_jump z)) hFi
    (fun n => weightedDQ_nonneg hBn (jumpRamp_monotone hz n))
    (weightedDQ_nonneg hBn (jump_monotone z))
    (fun p => (((jumpRamp_tendsto hz p.2).sub (jumpRamp_tendsto hz p.1)).div_const
      (Real.cos p.1 - Real.cos p.2)).mul_const (B p.1)) hInt
  refine ⟨hji, ?_⟩
  rw [integral_weightedDQ hji] at hjb
  have hI : (∫ θ in (0 : ℝ)..π, HT (jump z) θ * B θ) ≤
      (Gam r ρ1 ρ2 σ1 σ2 - poissonPair r ρ1 ρ2 σ1 σ2 (jump z)) * (π * r) := by
    nlinarith [Real.pi_pos]
  have hD := (div_le_iff₀ (mul_pos Real.pi_pos hr)).mpr hI
  have hjπ : jump z π = 1 := by simp [jump, show -1 < z from hz]
  change 0 ≤ -poissonPair r ρ1 ρ2 σ1 σ2 (jump z) - 1 / (π * r) *
    (∫ θ in (0 : ℝ)..π, HT (jump z) θ * B θ) + Gam r ρ1 ρ2 σ1 σ2 * jump z π
  rw [hjπ, mul_one]
  rw [div_eq_mul_one_div] at hD
  linarith

end EP1038.Stage11
