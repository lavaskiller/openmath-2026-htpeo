import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk00
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_20 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((609 : ℝ) / 1009) ((9777 : ℝ) / 16177))
    (hq : RB (qa a) ((118829 : ℝ) / 12500000) ((7739 : ℝ) / 800000))
    (hd : RB (D0a a) ((12261621 : ℝ) / 6250000) ((196251017 : ℝ) / 100000000))
    : certE k a ((21537313 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((10885829 : ℝ) / 25000000) ∧ 0 < certE k a ((127782799 : ℝ) / 100000000) ∧ certE k a ((63986017 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((9037 : ℝ) / 100000000) ((9359 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((21537313 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((43065267 : ℝ) / 100000000) ((43065589 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((21537313 : ℝ) / 50000000) ((21537313 : ℝ) / 50000000) ((21537313 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((28462687 : ℝ) / 50000000))
  have h3 : RB z3 ((15130429 : ℝ) / 20000000) ((9456589 : ℝ) / 12500000) := rb_div_signed h2 (show RB ((28462687 : ℝ) / 50000000) ((28462687 : ℝ) / 50000000) ((28462687 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-697561 : ℝ) / 2500000) ((-27901689 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_360.1 cov_log_361.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-8431791 : ℝ) / 50000000) ((-16840563 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((21537313 : ℝ) / 50000000))
  have h6 : RB z6 ((-8422361 : ℝ) / 10000000) ((-10527951 : ℝ) / 12500000) := rb_log (show RB ((21537313 : ℝ) / 50000000) ((21537313 : ℝ) / 50000000) ((21537313 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_362.1 cov_log_362.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33680013 : ℝ) / 50000000) ((67383047 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67389267 : ℝ) / 100000000) ((67422437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_363.1 cov_log_364.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-62411 : ℝ) / 100000000) ((-311 : ℝ) / 5000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((9037 : ℝ) / 100000000) ((9359 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((10885829 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((43533957 : ℝ) / 100000000) ((43534279 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((10885829 : ℝ) / 25000000) ((10885829 : ℝ) / 25000000) ((10885829 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((14114171 : ℝ) / 25000000))
  have h12 : RB z12 ((2409699 : ℝ) / 3125000) ((77110939 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((14114171 : ℝ) / 25000000) ((14114171 : ℝ) / 25000000) ((14114171 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-6498311 : ℝ) / 25000000) ((-25992503 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_365.1 cov_log_366.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15709709 : ℝ) / 100000000) ((-196103 : ℝ) / 1250000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((10885829 : ℝ) / 25000000))
  have h15 : RB z15 ((-83141399 : ℝ) / 100000000) ((-83141397 : ℝ) / 100000000) := rb_log (show RB ((10885829 : ℝ) / 25000000) ((10885829 : ℝ) / 25000000) ((10885829 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_367.1 cov_log_367.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((8428961 : ℝ) / 12500000) ((67453159 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67389267 : ℝ) / 100000000) ((67422437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_363.1 cov_log_364.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((9251 : ℝ) / 100000000) ((15973 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((9037 : ℝ) / 100000000) ((9359 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((127782799 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((99823 : ℝ) / 78125) ((63886881 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((127782799 : ℝ) / 100000000) ((127782799 : ℝ) / 100000000) ((127782799 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((27782799 : ℝ) / 100000000))
  have h21 : RB z21 ((367921 : ℝ) / 80000) ((45990241 : ℝ) / 10000000) := rb_div_signed h20 (show RB ((27782799 : ℝ) / 100000000) ((27782799 : ℝ) / 100000000) ((27782799 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((953651 : ℝ) / 625000) ((30516883 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_368.1 cov_log_369.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92094899 : ℝ) / 100000000) ((5763653 : ℝ) / 6250000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((127782799 : ℝ) / 100000000))
  have h24 : RB z24 ((980647 : ℝ) / 4000000) ((1532261 : ℝ) / 6250000) := rb_log (show RB ((127782799 : ℝ) / 100000000) ((127782799 : ℝ) / 100000000) ((127782799 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_370.1 cov_log_370.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67578723 : ℝ) / 100000000) ((67702273 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67389267 : ℝ) / 100000000) ((67422437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_363.1 cov_log_364.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((78143 : ℝ) / 50000000) ((156503 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((9037 : ℝ) / 100000000) ((9359 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((63986017 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((5118507 : ℝ) / 4000000) ((127962997 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((63986017 : ℝ) / 50000000) ((63986017 : ℝ) / 50000000) ((63986017 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((13986017 : ℝ) / 50000000))
  have h30 : RB z30 ((14295827 : ℝ) / 3125000) ((14295863 : ℝ) / 3125000) := rb_div_signed h29 (show RB ((13986017 : ℝ) / 50000000) ((13986017 : ℝ) / 50000000) ((13986017 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((152053339 : ℝ) / 100000000) ((76026797 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_371.1 cov_log_372.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((5735907 : ℝ) / 6250000) ((2871801 : ℝ) / 3125000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((63986017 : ℝ) / 50000000))
  have h33 : RB z33 ((6166039 : ℝ) / 25000000) ((24664157 : ℝ) / 100000000) := rb_log (show RB ((63986017 : ℝ) / 50000000) ((63986017 : ℝ) / 50000000) ((63986017 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_373.1 cov_log_373.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((13422071 : ℝ) / 20000000) ((16808369 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67389267 : ℝ) / 100000000) ((67422437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_363.1 cov_log_364.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-156041 : ℝ) / 50000000) ((-155791 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((21537313 : ℝ) / 50000000)) ((-62411 : ℝ) / 100000000) ((-311 : ℝ) / 5000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((10885829 : ℝ) / 25000000)) ((9251 : ℝ) / 100000000) ((15973 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((127782799 : ℝ) / 100000000)) ((78143 : ℝ) / 50000000) ((156503 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((63986017 : ℝ) / 50000000)) ((-156041 : ℝ) / 50000000) ((-155791 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_20 {k A q d vp vm : ℝ}
    (hk : RB k ((609 : ℝ) / 400) ((9777 : ℝ) / 6400))
    (hA : RB A ((609 : ℝ) / 1009) ((9777 : ℝ) / 16177))
    (hq : RB q ((118829 : ℝ) / 12500000) ((7739 : ℝ) / 800000))
    (hd : RB d ((12261621 : ℝ) / 6250000) ((196251017 : ℝ) / 100000000))
    (hp : RB vp ((21537313 : ℝ) / 50000000) ((10885829 : ℝ) / 25000000))
    (hm : RB vm ((127782799 : ℝ) / 100000000) ((63986017 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((9037 : ℝ) / 100000000) ((9359 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99990641 : ℝ) / 100000000) ((99990963 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((3017557 : ℝ) / 5000000) ((60432197 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((10377 : ℝ) / 50000000) ((679 : ℝ) / 3125000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((3124321 : ℝ) / 3125000) ((49989623 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((14114171 : ℝ) / 25000000) ((28462687 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((56444417 : ℝ) / 100000000) ((1422839 : ℝ) / 2500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106040001 : ℝ) / 100000000) ((107064969 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6040001 : ℝ) / 100000000) ((7064969 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99990641 : ℝ) / 100000000) ((99990963 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((3017557 : ℝ) / 5000000) ((60432197 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((7061 : ℝ) / 100000000) ((293 : ℝ) / 4000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((3999707 : ℝ) / 4000000) ((99992939 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((27782799 : ℝ) / 100000000) ((13986017 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((27780763 : ℝ) / 100000000) ((27970059 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((215770513 : ℝ) / 100000000) ((54383133 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((315770513 : ℝ) / 100000000) ((79383133 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1415434377 : ℝ) / 100000000) ((331125773 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((7873209 : ℝ) / 25000000) ((31668569 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((609 : ℝ) / 200) ((9777 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1447337 : ℝ) / 50000000) ((2955633 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((12618829 : ℝ) / 12500000) ((807739 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2866939 : ℝ) / 100000000) ((2927801 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((102866939 : ℝ) / 100000000) ((102927801 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((84239483 : ℝ) / 100000000) ((663261 : ℝ) / 781250) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((82633009 : ℝ) / 50000000) ((166612027 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27520981 : ℝ) / 50000000) ((13930817 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((16217 : ℝ) / 100000000) ((4251 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24995749 : ℝ) / 25000000) ((99983783 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((41309479 : ℝ) / 25000000) ((10411563 : ℝ) / 6250000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((12261621 : ℝ) / 3125000) ((196251017 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((932503 : ℝ) / 25000000) ((3796967 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1009 : ℝ) / 400) ((16177 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((9223 : ℝ) / 625000) ((37631 : ℝ) / 2500000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1091593 : ℝ) / 50000000) ((561453 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51091593 : ℝ) / 50000000) ((25561453 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((723167971 : ℝ) / 50000000) ((1692811177 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((742843 : ℝ) / 100000000) ((757047 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100742843 : ℝ) / 100000000) ((100757047 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((15863389 : ℝ) / 50000000) ((6381663 : ℝ) / 20000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((2309473 : ℝ) / 156250) ((431179873 : ℝ) / 25000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((872459 : ℝ) / 4000000) ((1622573 : ℝ) / 6250000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1009 : ℝ) / 400) ((16177 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((102866939 : ℝ) / 50000000) ((102927801 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1446927213 : ℝ) / 100000000) ((843648717 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2976819467 : ℝ) / 100000000) ((3473396291 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((907793 : ℝ) / 12500000) ((8491131 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-262246759 : ℝ) / 100000000) ((-246614797 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_374.1 cov_log_375.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((932503 : ℝ) / 50000000) ((474621 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-199095299 : ℝ) / 50000000) ((-7928229 : ℝ) / 2000000) := rb_log h49 (by norm_num) cov_log_376.1 cov_log_377.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67389267 : ℝ) / 100000000) ((67422437 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_363.1 cov_log_364.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((102600159 : ℝ) / 100000000) ((25749577 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-295590439 : ℝ) / 100000000) ((-146706571 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((16858039 : ℝ) / 100000000) ((4551283 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((12987119 : ℝ) / 20000000) ((41732923 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-57663711 : ℝ) / 25000000) ((-6560853 : ℝ) / 3125000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((102866939 : ℝ) / 100000000) ((102927801 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-262246759 : ℝ) / 100000000) ((-246614797 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-57663711 : ℝ) / 25000000) ((-6560853 : ℝ) / 3125000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((153 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1091593 : ℝ) / 50000000) ((561453 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((25561453 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((153 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-46724783 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((153 : ℝ) / 50) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_5, cov_h_3]
  have hP : ((32039421 : ℝ) / 5000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((6560853 : ℝ) / 3125000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((6560853 : ℝ) / 3125000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2737 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2737 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2777 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2777 : ℝ) / 1000)) (lo := ((2737 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2817 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2817 : ℝ) / 1000)) (lo := ((2777 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2857 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2857 : ℝ) / 1000)) (lo := ((2817 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2897 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2897 : ℝ) / 1000)) (lo := ((2857 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2937 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2937 : ℝ) / 1000)) (lo := ((2897 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2977 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2977 : ℝ) / 1000)) (lo := ((2937 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3017 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3017 : ℝ) / 1000)) (lo := ((2977 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3057 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3057 : ℝ) / 1000)) (lo := ((3017 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((153 : ℝ) / 50)) (lo := ((3057 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_20 {k : ℝ} (hk : RB k ((609 : ℝ) / 400) ((9777 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((609 : ℝ) / 1009) ((9777 : ℝ) / 16177) ∧
    RB (qa (r1A k)) ((118829 : ℝ) / 12500000) ((7739 : ℝ) / 800000) ∧ RB (D0a (r1A k)) ((12261621 : ℝ) / 6250000) ((196251017 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((609 : ℝ) / 1600) ((38191407 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((192408593 : ℝ) / 100000000) ((15403 : ℝ) / 8000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((1083683 : ℝ) / 781250) ((138757883 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((14006639 : ℝ) / 5000000) ((7004481 : ℝ) / 2500000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((14006639 : ℝ) / 10000000) ((7004481 : ℝ) / 5000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((12261621 : ℝ) / 6250000) ((196251017 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((597 : ℝ) / 8000) ((7591407 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((597 : ℝ) / 32000) ((474463 : ℝ) / 25000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((118829 : ℝ) / 12500000) ((7739 : ℝ) / 800000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((12261621 : ℝ) / 6250000) ((196251017 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((118829 : ℝ) / 12500000) ((7739 : ℝ) / 800000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((609 : ℝ) / 1009) ((9777 : ℝ) / 16177) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_20 {k : ℝ} (hk : RB k ((609 : ℝ) / 400) ((9777 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_20 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_20 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((21537313 : ℝ) / 50000000)) (ph := ((10885829 : ℝ) / 25000000)) (ml := ((127782799 : ℝ) / 100000000)) (mh := ((63986017 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_20 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_21 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((9777 : ℝ) / 16177) ((981 : ℝ) / 1621))
    (hq : RB (qa a) ((967373 : ℝ) / 100000000) ((15377 : ℝ) / 1562500))
    (hd : RB (D0a a) ((196120847 : ℝ) / 100000000) ((196185939 : ℝ) / 100000000))
    : certE k a ((1343957 : ℝ) / 3125000) < 0 ∧ 0 < certE k a ((43467971 : ℝ) / 100000000) ∧ 0 < certE k a ((127846061 : ℝ) / 100000000) ∧ certE k a ((25606949 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((4679 : ℝ) / 50000000) ((4843 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1343957 : ℝ) / 3125000)) - (z1)
  have h2 : RB z2 ((21498469 : ℝ) / 50000000) ((21498633 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1343957 : ℝ) / 3125000) ((1343957 : ℝ) / 3125000) ((1343957 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((1781043 : ℝ) / 3125000))
  have h3 : RB z3 ((75441991 : ℝ) / 100000000) ((9430321 : ℝ) / 12500000) := rb_div_signed h2 (show RB ((1781043 : ℝ) / 3125000) ((1781043 : ℝ) / 3125000) ((1781043 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-3522577 : ℝ) / 12500000) ((-563597 : ℝ) / 2000000) := rb_log h3 (by norm_num) cov_log_378.1 cov_log_379.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-8527201 : ℝ) / 50000000) ((-17031241 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((1343957 : ℝ) / 3125000))
  have h6 : RB z6 ((-16876321 : ℝ) / 20000000) ((-84381603 : ℝ) / 100000000) := rb_log (show RB ((1343957 : ℝ) / 3125000) ((1343957 : ℝ) / 3125000) ((1343957 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_380.1 cov_log_380.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((67327201 : ℝ) / 100000000) ((16837591 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16839021 : ℝ) / 25000000) ((67389271 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_381.1 cov_log_382.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-6207 : ℝ) / 10000000) ((-143 : ℝ) / 2500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((4679 : ℝ) / 50000000) ((4843 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43467971 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((8691657 : ℝ) / 20000000) ((43458613 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43467971 : ℝ) / 100000000) ((43467971 : ℝ) / 100000000) ((43467971 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56532029 : ℝ) / 100000000))
  have h12 : RB z12 ((3843687 : ℝ) / 5000000) ((76874321 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((56532029 : ℝ) / 100000000) ((56532029 : ℝ) / 100000000) ((56532029 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-13150293 : ℝ) / 50000000) ((-26299829 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_383.1 cov_log_384.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15916641 : ℝ) / 100000000) ((-3179 : ℝ) / 20000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43467971 : ℝ) / 100000000))
  have h15 : RB z15 ((-83314583 : ℝ) / 100000000) ((-83314581 : ℝ) / 100000000) := rb_log (show RB ((43467971 : ℝ) / 100000000) ((43467971 : ℝ) / 100000000) ((43467971 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_385.1 cov_log_385.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((3369897 : ℝ) / 5000000) ((67419583 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16839021 : ℝ) / 25000000) ((67389271 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_381.1 cov_log_382.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((8669 : ℝ) / 100000000) ((63499 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((4679 : ℝ) / 50000000) ((4843 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((127846061 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((1022691 : ℝ) / 800000) ((127836703 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((127846061 : ℝ) / 100000000) ((127846061 : ℝ) / 100000000) ((127846061 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((27846061 : ℝ) / 100000000))
  have h21 : RB z21 ((91816487 : ℝ) / 20000000) ((229541807 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((27846061 : ℝ) / 100000000) ((27846061 : ℝ) / 100000000) ((27846061 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((3810149 : ℝ) / 2500000) ((7620311 : ℝ) / 5000000) := rb_log h21 (by norm_num) cov_log_386.1 cov_log_387.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92110593 : ℝ) / 100000000) ((92233499 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((127846061 : ℝ) / 100000000))
  have h24 : RB z24 ((2456567 : ℝ) / 10000000) ((24565671 : ℝ) / 100000000) := rb_log (show RB ((127846061 : ℝ) / 100000000) ((127846061 : ℝ) / 100000000) ((127846061 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_388.1 cov_log_388.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33772461 : ℝ) / 50000000) ((67667829 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16839021 : ℝ) / 25000000) ((67389271 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_381.1 cov_log_382.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((155651 : ℝ) / 100000000) ((62349 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((4679 : ℝ) / 50000000) ((4843 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((25606949 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((128025059 : ℝ) / 100000000) ((128025387 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((25606949 : ℝ) / 20000000) ((25606949 : ℝ) / 20000000) ((25606949 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((5606949 : ℝ) / 20000000))
  have h30 : RB z30 ((5708321 : ℝ) / 1250000) ((456666851 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((5606949 : ℝ) / 20000000) ((5606949 : ℝ) / 20000000) ((5606949 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((75939069 : ℝ) / 50000000) ((151878397 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_389.1 cov_log_390.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((9179159 : ℝ) / 10000000) ((9191407 : ℝ) / 10000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((25606949 : ℝ) / 20000000))
  have h33 : RB z33 ((6178287 : ℝ) / 25000000) ((24713149 : ℝ) / 100000000) := rb_log (show RB ((25606949 : ℝ) / 20000000) ((25606949 : ℝ) / 20000000) ((25606949 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_391.1 cov_log_391.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67078441 : ℝ) / 100000000) ((33600461 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16839021 : ℝ) / 25000000) ((67389271 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_381.1 cov_log_382.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-31083 : ℝ) / 10000000) ((-77581 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((1343957 : ℝ) / 3125000)) ((-6207 : ℝ) / 10000000) ((-143 : ℝ) / 2500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43467971 : ℝ) / 100000000)) ((8669 : ℝ) / 100000000) ((63499 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((127846061 : ℝ) / 100000000)) ((155651 : ℝ) / 100000000) ((62349 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((25606949 : ℝ) / 20000000)) ((-31083 : ℝ) / 10000000) ((-77581 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_21 {k A q d vp vm : ℝ}
    (hk : RB k ((9777 : ℝ) / 6400) ((981 : ℝ) / 640))
    (hA : RB A ((9777 : ℝ) / 16177) ((981 : ℝ) / 1621))
    (hq : RB q ((967373 : ℝ) / 100000000) ((15377 : ℝ) / 1562500))
    (hd : RB d ((196120847 : ℝ) / 100000000) ((196185939 : ℝ) / 100000000))
    (hp : RB vp ((1343957 : ℝ) / 3125000) ((43467971 : ℝ) / 100000000))
    (hm : RB vm ((127846061 : ℝ) / 100000000) ((25606949 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((4679 : ℝ) / 50000000) ((4843 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49995157 : ℝ) / 50000000) ((49995321 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((15107951 : ℝ) / 25000000) ((7564067 : ℝ) / 12500000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((2691 : ℝ) / 12500000) ((22523 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99977477 : ℝ) / 100000000) ((12497309 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56532029 : ℝ) / 100000000) ((1781043 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((441557 : ℝ) / 781250) ((56981107 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106055861 : ℝ) / 100000000) ((107065269 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6055861 : ℝ) / 100000000) ((7065269 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49995157 : ℝ) / 50000000) ((49995321 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((15107951 : ℝ) / 25000000) ((7564067 : ℝ) / 12500000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((1827 : ℝ) / 25000000) ((7577 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99992423 : ℝ) / 100000000) ((24998173 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((27846061 : ℝ) / 100000000) ((5606949 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((27843951 : ℝ) / 100000000) ((28032697 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((53894033 : ℝ) / 25000000) ((43465481 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((78894033 : ℝ) / 25000000) ((63465481 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((353843569 : ℝ) / 25000000) ((330258571 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31513193 : ℝ) / 100000000) ((1267523 : ℝ) / 4000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((9777 : ℝ) / 3200) ((981 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1477813 : ℝ) / 50000000) ((377121 : ℝ) / 12500000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100967373 : ℝ) / 100000000) ((1577877 : ℝ) / 1562500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1463411 : ℝ) / 50000000) ((2988063 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((51463411 : ℝ) / 50000000) ((102988063 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((8437809 : ℝ) / 10000000) ((85028121 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((10342689 : ℝ) / 6250000) ((83406609 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27491137 : ℝ) / 50000000) ((27827053 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((8407 : ℝ) / 50000000) ((17617 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99982383 : ℝ) / 100000000) ((49991593 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((16545387 : ℝ) / 10000000) ((166785171 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((196120847 : ℝ) / 50000000) ((196185939 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((94861 : ℝ) / 2500000) ((1930721 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16177 : ℝ) / 6400) ((1621 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1498113 : ℝ) / 100000000) ((1527677 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((556371 : ℝ) / 25000000) ((1144159 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25556371 : ℝ) / 25000000) ((51144159 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((361718301 : ℝ) / 25000000) ((1689079687 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((151111 : ℝ) / 20000000) ((48111 : ℝ) / 6250000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20151111 : ℝ) / 20000000) ((6298111 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((7937823 : ℝ) / 25000000) ((31932003 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((92414031 : ℝ) / 6250000) ((172101169 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((4430293 : ℝ) / 20000000) ((52583 : ℝ) / 200000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16177 : ℝ) / 6400) ((1621 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((51463411 : ℝ) / 25000000) ((102988063 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1446887469 : ℝ) / 100000000) ((168298093 : ℝ) / 10000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2978470579 : ℝ) / 100000000) ((3466538921 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((113931 : ℝ) / 1562500) ((1062967 : ℝ) / 12500000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-130922471 : ℝ) / 50000000) ((-123233229 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_392.1 cov_log_393.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((94861 : ℝ) / 5000000) ((1930721 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-396478059 : ℝ) / 100000000) ((-394727667 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_394.1 cov_log_395.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16839021 : ℝ) / 25000000) ((67389271 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_381.1 cov_log_382.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((51448471 : ℝ) / 50000000) ((103295117 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-293581117 : ℝ) / 100000000) ((-5828651 : ℝ) / 2000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4164469 : ℝ) / 25000000) ((8994589 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((7919801 : ℝ) / 12500000) ((2030247 : ℝ) / 2500000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-230222709 : ℝ) / 100000000) ((-21022267 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((51463411 : ℝ) / 50000000) ((102988063 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-130922471 : ℝ) / 50000000) ((-123233229 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-230222709 : ℝ) / 100000000) ((-21022267 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((153 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((556371 : ℝ) / 25000000) ((1144159 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((51144159 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((153 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-116611049 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((153 : ℝ) / 50) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_5, cov_h_3]
  have hP : ((32062673 : ℝ) / 5000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((21022267 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((21022267 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((343 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((343 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((348 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((348 : ℝ) / 125)) (lo := ((343 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((353 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((353 : ℝ) / 125)) (lo := ((348 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((358 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((358 : ℝ) / 125)) (lo := ((353 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((363 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((363 : ℝ) / 125)) (lo := ((358 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((368 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((368 : ℝ) / 125)) (lo := ((363 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((373 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((373 : ℝ) / 125)) (lo := ((368 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((378 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((378 : ℝ) / 125)) (lo := ((373 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((153 : ℝ) / 50)) (lo := ((378 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_21 {k : ℝ} (hk : RB k ((9777 : ℝ) / 6400) ((981 : ℝ) / 640)) :
    RB (k / (k + 1)) ((9777 : ℝ) / 16177) ((981 : ℝ) / 1621) ∧
    RB (qa (r1A k)) ((967373 : ℝ) / 100000000) ((15377 : ℝ) / 1562500) ∧ RB (D0a (r1A k)) ((196120847 : ℝ) / 100000000) ((196185939 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((19095703 : ℝ) / 50000000) ((38320313 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((192279687 : ℝ) / 100000000) ((96204297 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138664951 : ℝ) / 100000000) ((5548457 : ℝ) / 4000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((280086307 : ℝ) / 100000000) ((140066391 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140043153 : ℝ) / 100000000) ((140066391 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((196120847 : ℝ) / 100000000) ((196185939 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3795703 : ℝ) / 50000000) ((7720313 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1897851 : ℝ) / 100000000) ((1930079 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((967373 : ℝ) / 100000000) ((15377 : ℝ) / 1562500) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((196120847 : ℝ) / 100000000) ((196185939 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((967373 : ℝ) / 100000000) ((15377 : ℝ) / 1562500) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((9777 : ℝ) / 16177) ((981 : ℝ) / 1621) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_21 {k : ℝ} (hk : RB k ((9777 : ℝ) / 6400) ((981 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_21 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_21 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((1343957 : ℝ) / 3125000)) (ph := ((43467971 : ℝ) / 100000000)) (ml := ((127846061 : ℝ) / 100000000)) (mh := ((25606949 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_21 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_22 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((981 : ℝ) / 1621) ((9843 : ℝ) / 16243))
    (hq : RB (qa a) ((492063 : ℝ) / 50000000) ((250223 : ℝ) / 25000000))
    (hd : RB (D0a a) ((196055749 : ℝ) / 100000000) ((196120853 : ℝ) / 100000000))
    : certE k a ((8587933 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((43393823 : ℝ) / 100000000) ∧ 0 < certE k a ((63954569 : ℝ) / 50000000) ∧ certE k a ((128097273 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1937 : ℝ) / 20000000) ((5009 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8587933 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((42929647 : ℝ) / 100000000) ((2146499 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((8587933 : ℝ) / 20000000) ((8587933 : ℝ) / 20000000) ((8587933 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11412067 : ℝ) / 20000000))
  have h3 : RB z3 ((18808883 : ℝ) / 25000000) ((75236117 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((11412067 : ℝ) / 20000000) ((11412067 : ℝ) / 20000000) ((11412067 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-28454657 : ℝ) / 100000000) ((-28453879 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_396.1 cov_log_397.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-17243071 : ℝ) / 100000000) ((-688791 : ℝ) / 4000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8587933 : ℝ) / 20000000))
  have h6 : RB z6 ((-84537421 : ℝ) / 100000000) ((-84537419 : ℝ) / 100000000) := rb_log (show RB ((8587933 : ℝ) / 20000000) ((8587933 : ℝ) / 20000000) ((8587933 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_398.1 cov_log_398.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((16823587 : ℝ) / 25000000) ((33658823 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33661443 : ℝ) / 50000000) ((67356089 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_399.1 cov_log_400.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-61741 : ℝ) / 100000000) ((-131 : ℝ) / 2500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1937 : ℝ) / 20000000) ((5009 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43393823 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((8676761 : ℝ) / 20000000) ((21692069 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((43393823 : ℝ) / 100000000) ((43393823 : ℝ) / 100000000) ((43393823 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56606177 : ℝ) / 100000000))
  have h12 : RB z12 ((76641467 : ℝ) / 100000000) ((76642057 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((56606177 : ℝ) / 100000000) ((56606177 : ℝ) / 100000000) ((56606177 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-3325399 : ℝ) / 12500000) ((-26602421 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_401.1 cov_log_402.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-2015139 : ℝ) / 12500000) ((-3219861 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43393823 : ℝ) / 100000000))
  have h15 : RB z15 ((-8348531 : ℝ) / 10000000) ((-20871327 : ℝ) / 25000000) := rb_log (show RB ((43393823 : ℝ) / 100000000) ((43393823 : ℝ) / 100000000) ((43393823 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_403.1 cov_log_403.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16841049 : ℝ) / 25000000) ((13477201 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33661443 : ℝ) / 50000000) ((67356089 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_399.1 cov_log_400.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((8107 : ℝ) / 100000000) ((63119 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1937 : ℝ) / 20000000) ((5009 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((63954569 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((1598739 : ℝ) / 1250000) ((127899453 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((63954569 : ℝ) / 50000000) ((63954569 : ℝ) / 50000000) ((63954569 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((13954569 : ℝ) / 50000000))
  have h21 : RB z21 ((458269689 : ℝ) / 100000000) ((458270883 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((13954569 : ℝ) / 50000000) ((13954569 : ℝ) / 50000000) ((13954569 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((76114383 : ℝ) / 50000000) ((152229029 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_404.1 cov_log_405.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46063053 : ℝ) / 50000000) ((46124187 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((63954569 : ℝ) / 50000000))
  have h24 : RB z24 ((6153749 : ℝ) / 25000000) ((24614997 : ℝ) / 100000000) := rb_log (show RB ((63954569 : ℝ) / 50000000) ((63954569 : ℝ) / 50000000) ((63954569 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_406.1 cov_log_406.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67511109 : ℝ) / 100000000) ((33816689 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33661443 : ℝ) / 50000000) ((67356089 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_399.1 cov_log_400.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((7751 : ℝ) / 5000000) ((77623 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1937 : ℝ) / 20000000) ((5009 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((128097273 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((25617451 : ℝ) / 20000000) ((32021897 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((128097273 : ℝ) / 100000000) ((128097273 : ℝ) / 100000000) ((128097273 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((28097273 : ℝ) / 100000000))
  have h30 : RB z30 ((45587077 : ℝ) / 10000000) ((113967989 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((28097273 : ℝ) / 100000000) ((28097273 : ℝ) / 100000000) ((28097273 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((75851959 : ℝ) / 50000000) ((151704181 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_407.1 cov_log_408.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((45904239 : ℝ) / 50000000) ((3677213 : ℝ) / 4000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((128097273 : ℝ) / 100000000))
  have h33 : RB z33 ((24761973 : ℝ) / 100000000) ((12380987 : ℝ) / 50000000) := rb_log (show RB ((128097273 : ℝ) / 100000000) ((128097273 : ℝ) / 100000000) ((128097273 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_409.1 cov_log_409.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((8380813 : ℝ) / 12500000) ((2099011 : ℝ) / 3125000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33661443 : ℝ) / 50000000) ((67356089 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_399.1 cov_log_400.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-61917 : ℝ) / 20000000) ((-77267 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8587933 : ℝ) / 20000000)) ((-61741 : ℝ) / 100000000) ((-131 : ℝ) / 2500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43393823 : ℝ) / 100000000)) ((8107 : ℝ) / 100000000) ((63119 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((63954569 : ℝ) / 50000000)) ((7751 : ℝ) / 5000000) ((77623 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((128097273 : ℝ) / 100000000)) ((-61917 : ℝ) / 20000000) ((-77267 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_22 {k A q d vp vm : ℝ}
    (hk : RB k ((981 : ℝ) / 640) ((9843 : ℝ) / 6400))
    (hA : RB A ((981 : ℝ) / 1621) ((9843 : ℝ) / 16243))
    (hq : RB q ((492063 : ℝ) / 50000000) ((250223 : ℝ) / 25000000))
    (hd : RB d ((196055749 : ℝ) / 100000000) ((196120853 : ℝ) / 100000000))
    (hp : RB vp ((8587933 : ℝ) / 20000000) ((43393823 : ℝ) / 100000000))
    (hm : RB vm ((63954569 : ℝ) / 50000000) ((128097273 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1937 : ℝ) / 20000000) ((5009 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49994991 : ℝ) / 50000000) ((19998063 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((12102427 : ℝ) / 20000000) ((60592543 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((11159 : ℝ) / 50000000) ((23331 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99976669 : ℝ) / 100000000) ((49988841 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56606177 : ℝ) / 100000000) ((11412067 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((5659297 : ℝ) / 10000000) ((57047601 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53036529 : ℝ) / 50000000) ((53533631 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3036529 : ℝ) / 50000000) ((3533631 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49994991 : ℝ) / 50000000) ((19998063 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((12102427 : ℝ) / 20000000) ((60592543 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((189 : ℝ) / 2500000) ((7833 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99992167 : ℝ) / 100000000) ((2499811 : ℝ) / 2500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((13954569 : ℝ) / 50000000) ((28097273 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((27906951 : ℝ) / 100000000) ((28095149 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((107691429 : ℝ) / 50000000) ((5428087 : ℝ) / 2500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((157691429 : ℝ) / 50000000) ((7928087 : ℝ) / 2500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((707487567 : ℝ) / 50000000) ((1646616911 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15766729 : ℝ) / 50000000) ((15853747 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((981 : ℝ) / 320) ((9843 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((3016961 : ℝ) / 100000000) ((1539341 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50492063 : ℝ) / 50000000) ((25250223 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2987063 : ℝ) / 100000000) ((76217 : ℝ) / 2500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((102987063 : ℝ) / 100000000) ((2576217 : ℝ) / 2500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((16903063 : ℝ) / 20000000) ((10644701 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((165697133 : ℝ) / 100000000) ((41752957 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((10984751 : ℝ) / 20000000) ((217134 : ℝ) / 390625) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((17423 : ℝ) / 100000000) ((57 : ℝ) / 312500) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((312443 : ℝ) / 312500) ((99982577 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((165666909 : ℝ) / 100000000) ((16698273 : ℝ) / 10000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((196055749 : ℝ) / 50000000) ((196120853 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((3858871 : ℝ) / 100000000) ((981479 : ℝ) / 25000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1621 : ℝ) / 640) ((16243 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((190057 : ℝ) / 12500000) ((1550023 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1133947 : ℝ) / 50000000) ((2330927 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51133947 : ℝ) / 50000000) ((102330927 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((144706527 : ℝ) / 10000000) ((33699967 : ℝ) / 2000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((96033 : ℝ) / 12500000) ((782503 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((12596033 : ℝ) / 12500000) ((100782503 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((15887859 : ℝ) / 50000000) ((31955607 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((369710247 : ℝ) / 25000000) ((1716953957 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((11242563 : ℝ) / 50000000) ((13306591 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1621 : ℝ) / 640) ((16243 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((102987063 : ℝ) / 50000000) ((2576217 : ℝ) / 1250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((90406787 : ℝ) / 6250000) ((335664881 : ℝ) / 20000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2979433429 : ℝ) / 100000000) ((3458982291 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7322421 : ℝ) / 100000000) ((4259147 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-130711461 : ℝ) / 50000000) ((-246295409 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_410.1 cov_log_411.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((385887 : ℝ) / 20000000) ((981479 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-394794303 : ℝ) / 100000000) ((-196535883 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_412.1 cov_log_413.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33661443 : ℝ) / 50000000) ((67356089 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_399.1 cov_log_400.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((103193361 : ℝ) / 100000000) ((103591561 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-145800471 : ℝ) / 50000000) ((-57896041 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((16460317 : ℝ) / 100000000) ((17776139 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((96641 : ℝ) / 156250) ((3162293 : ℝ) / 4000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-114875351 : ℝ) / 50000000) ((-1315143 : ℝ) / 625000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((102987063 : ℝ) / 100000000) ((2576217 : ℝ) / 2500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-130711461 : ℝ) / 50000000) ((-246295409 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-114875351 : ℝ) / 50000000) ((-1315143 : ℝ) / 625000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((153 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1133947 : ℝ) / 50000000) ((2330927 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((102330927 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((153 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-116400039 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((153 : ℝ) / 50) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_5, cov_h_3]
  have hP : ((641486603 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((1315143 : ℝ) / 625000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((1315143 : ℝ) / 625000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((11 : ℝ) / 4) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((11 : ℝ) / 4)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((279 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((279 : ℝ) / 100)) (lo := ((11 : ℝ) / 4)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((283 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((287 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((283 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((291 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((291 : ℝ) / 100)) (lo := ((287 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((59 : ℝ) / 20) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((291 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((299 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((59 : ℝ) / 20)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((303 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((303 : ℝ) / 100)) (lo := ((299 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((153 : ℝ) / 50)) (lo := ((303 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_22 {k : ℝ} (hk : RB k ((981 : ℝ) / 640) ((9843 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((981 : ℝ) / 1621) ((9843 : ℝ) / 16243) ∧
    RB (qa (r1A k)) ((492063 : ℝ) / 50000000) ((250223 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((196055749 : ℝ) / 100000000) ((196120853 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((4790039 : ℝ) / 12500000) ((38449219 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((192150781 : ℝ) / 100000000) ((24034961 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((69309231 : ℝ) / 50000000) ((17333119 : ℝ) / 12500000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((140019909 : ℝ) / 50000000) ((280086309 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140019909 : ℝ) / 100000000) ((28008631 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((196055749 : ℝ) / 100000000) ((196120853 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((965039 : ℝ) / 12500000) ((7849219 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((965039 : ℝ) / 50000000) ((392461 : ℝ) / 20000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((492063 : ℝ) / 50000000) ((250223 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((196055749 : ℝ) / 100000000) ((196120853 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((492063 : ℝ) / 50000000) ((250223 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((981 : ℝ) / 1621) ((9843 : ℝ) / 16243) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_22 {k : ℝ} (hk : RB k ((981 : ℝ) / 640) ((9843 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_22 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_22 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((8587933 : ℝ) / 20000000)) (ph := ((43393823 : ℝ) / 100000000)) (ml := ((63954569 : ℝ) / 50000000)) (mh := ((128097273 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_22 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_23 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((9843 : ℝ) / 16243) ((2469 : ℝ) / 4069))
    (hq : RB (qa a) ((100089 : ℝ) / 10000000) ((1017667 : ℝ) / 100000000))
    (hd : RB (D0a a) ((48997659 : ℝ) / 25000000) ((24506969 : ℝ) / 12500000))
    : certE k a ((1714949 : ℝ) / 4000000) < 0 ∧ 0 < certE k a ((2707553 : ℝ) / 6250000) ∧ 0 < certE k a ((127972031 : ℝ) / 100000000) ∧ certE k a ((64079811 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((10017 : ℝ) / 100000000) ((10357 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1714949 : ℝ) / 4000000)) - (z1)
  have h2 : RB z2 ((5357921 : ℝ) / 12500000) ((10715927 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1714949 : ℝ) / 4000000) ((1714949 : ℝ) / 4000000) ((1714949 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((2285051 : ℝ) / 4000000))
  have h3 : RB z3 ((75032667 : ℝ) / 100000000) ((75033263 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((2285051 : ℝ) / 4000000) ((2285051 : ℝ) / 4000000) ((2285051 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-28724661 : ℝ) / 100000000) ((-14361933 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_414.1 cov_log_415.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-4357409 : ℝ) / 25000000) ((-8703103 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((1714949 : ℝ) / 4000000))
  have h6 : RB z6 ((-84691103 : ℝ) / 100000000) ((-84691101 : ℝ) / 100000000) := rb_log (show RB ((1714949 : ℝ) / 4000000) ((1714949 : ℝ) / 4000000) ((1714949 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_416.1 cov_log_416.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((13452293 : ℝ) / 20000000) ((67284897 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67289669 : ℝ) / 100000000) ((6732289 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_417.1 cov_log_418.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-2457 : ℝ) / 4000000) ((-1193 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((10017 : ℝ) / 100000000) ((10357 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((2707553 : ℝ) / 6250000)) - (z10)
  have h11 : RB z11 ((43310491 : ℝ) / 100000000) ((43310831 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((2707553 : ℝ) / 6250000) ((2707553 : ℝ) / 6250000) ((2707553 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((3542447 : ℝ) / 6250000))
  have h12 : RB z12 ((38206721 : ℝ) / 50000000) ((38207021 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((3542447 : ℝ) / 6250000) ((3542447 : ℝ) / 6250000) ((3542447 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-26901157 : ℝ) / 100000000) ((-26900371 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_419.1 cov_log_420.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3264633 : ℝ) / 20000000) ((-16301197 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((2707553 : ℝ) / 6250000))
  have h15 : RB z15 ((-4182681 : ℝ) / 5000000) ((-41826809 : ℝ) / 50000000) := rb_log (show RB ((2707553 : ℝ) / 6250000) ((2707553 : ℝ) / 6250000) ((2707553 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_421.1 cov_log_421.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67330453 : ℝ) / 100000000) ((67352423 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67289669 : ℝ) / 100000000) ((6732289 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_417.1 cov_log_418.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((7563 : ℝ) / 100000000) ((31377 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((10017 : ℝ) / 100000000) ((10357 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((127972031 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((63980837 : ℝ) / 50000000) ((63981007 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((127972031 : ℝ) / 100000000) ((127972031 : ℝ) / 100000000) ((127972031 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((27972031 : ℝ) / 100000000))
  have h21 : RB z21 ((91492587 : ℝ) / 20000000) ((457464151 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((27972031 : ℝ) / 100000000) ((27972031 : ℝ) / 100000000) ((27972031 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((152052567 : ℝ) / 100000000) ((38013209 : ℝ) / 25000000) := rb_log h21 (by norm_num) cov_log_422.1 cov_log_423.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((143971 : ℝ) / 156250) ((3690523 : ℝ) / 4000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((127972031 : ℝ) / 100000000))
  have h24 : RB z24 ((12332077 : ℝ) / 50000000) ((4932831 : ℝ) / 20000000) := rb_log (show RB ((127972031 : ℝ) / 100000000) ((127972031 : ℝ) / 100000000) ((127972031 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_424.1 cov_log_424.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((13495457 : ℝ) / 20000000) ((67598921 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67289669 : ℝ) / 100000000) ((6732289 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_417.1 cov_log_418.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((30879 : ℝ) / 20000000) ((77313 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((10017 : ℝ) / 100000000) ((10357 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((64079811 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((25629853 : ℝ) / 20000000) ((25629921 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((64079811 : ℝ) / 50000000) ((64079811 : ℝ) / 50000000) ((64079811 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((14079811 : ℝ) / 50000000))
  have h30 : RB z30 ((455081623 : ℝ) / 100000000) ((28442677 : ℝ) / 6250000) := rb_div_signed h29 (show RB ((14079811 : ℝ) / 50000000) ((14079811 : ℝ) / 50000000) ((14079811 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((7576533 : ℝ) / 5000000) ((151530929 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_425.1 cov_log_426.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91825173 : ℝ) / 100000000) ((91946391 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((64079811 : ℝ) / 50000000))
  have h33 : RB z33 ((12405317 : ℝ) / 50000000) ((4962127 : ℝ) / 20000000) := rb_log (show RB ((64079811 : ℝ) / 50000000) ((64079811 : ℝ) / 50000000) ((64079811 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_427.1 cov_log_427.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33507269 : ℝ) / 50000000) ((67135757 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67289669 : ℝ) / 100000000) ((6732289 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_417.1 cov_log_418.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-2409 : ℝ) / 781250) ((-19239 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((1714949 : ℝ) / 4000000)) ((-2457 : ℝ) / 4000000) ((-1193 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((2707553 : ℝ) / 6250000)) ((7563 : ℝ) / 100000000) ((31377 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((127972031 : ℝ) / 100000000)) ((30879 : ℝ) / 20000000) ((77313 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((64079811 : ℝ) / 50000000)) ((-2409 : ℝ) / 781250) ((-19239 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_23 {k A q d vp vm : ℝ}
    (hk : RB k ((9843 : ℝ) / 6400) ((2469 : ℝ) / 1600))
    (hA : RB A ((9843 : ℝ) / 16243) ((2469 : ℝ) / 4069))
    (hq : RB q ((100089 : ℝ) / 10000000) ((1017667 : ℝ) / 100000000))
    (hd : RB d ((48997659 : ℝ) / 25000000) ((24506969 : ℝ) / 12500000))
    (hp : RB vp ((1714949 : ℝ) / 4000000) ((2707553 : ℝ) / 6250000))
    (hm : RB vm ((127972031 : ℝ) / 100000000) ((64079811 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((10017 : ℝ) / 100000000) ((10357 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99989643 : ℝ) / 100000000) ((99989983 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((12118427 : ℝ) / 20000000) ((30336111 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((11561 : ℝ) / 50000000) ((24157 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99975843 : ℝ) / 100000000) ((49988439 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((3542447 : ℝ) / 6250000) ((2285051 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((2833273 : ℝ) / 5000000) ((57113067 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((13261443 : ℝ) / 12500000) ((26767727 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((761443 : ℝ) / 12500000) ((1767727 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99989643 : ℝ) / 100000000) ((99989983 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((12118427 : ℝ) / 20000000) ((30336111 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((977 : ℝ) / 12500000) ((4047 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49995953 : ℝ) / 50000000) ((12499023 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((27972031 : ℝ) / 100000000) ((14079811 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((13984883 : ℝ) / 50000000) ((14078711 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((107595317 : ℝ) / 50000000) ((6778773 : ℝ) / 3125000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((157595317 : ℝ) / 50000000) ((9903773 : ℝ) / 3125000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((56569821 : ℝ) / 4000000) ((65664797 : ℝ) / 4000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31553631 : ℝ) / 100000000) ((1982927 : ℝ) / 6250000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((9843 : ℝ) / 3200) ((2469 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((123147 : ℝ) / 4000000) ((125631 : ℝ) / 4000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((10100089 : ℝ) / 10000000) ((101017667 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3047659 : ℝ) / 100000000) ((3109651 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((103047659 : ℝ) / 100000000) ((103109651 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((84651183 : ℝ) / 100000000) ((85285897 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((165908391 : ℝ) / 100000000) ((167207907 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((6858297 : ℝ) / 12500000) ((13879959 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((9021 : ℝ) / 50000000) ((18877 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99981123 : ℝ) / 100000000) ((49990979 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((10367317 : ℝ) / 6250000) ((8358887 : ℝ) / 5000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((48997659 : ℝ) / 12500000) ((24506969 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((3923301 : ℝ) / 100000000) ((399039 : ℝ) / 10000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16243 : ℝ) / 6400) ((4069 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((385677 : ℝ) / 25000000) ((786139 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2310411 : ℝ) / 100000000) ((1186819 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((102310411 : ℝ) / 100000000) ((51186819 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1446920409 : ℝ) / 100000000) ((42014651 : ℝ) / 2500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((780971 : ℝ) / 100000000) ((795227 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100780971 : ℝ) / 100000000) ((100795227 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((6360011 : ℝ) / 20000000) ((31979133 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((92420029 : ℝ) / 6250000) ((1712565173 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((11406169 : ℝ) / 50000000) ((13463143 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16243 : ℝ) / 6400) ((4069 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((103047659 : ℝ) / 50000000) ((103109651 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((361449789 : ℝ) / 25000000) ((1673346757 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((186232773 : ℝ) / 6250000) ((3450764003 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((3677401 : ℝ) / 50000000) ((4267383 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-3262271 : ℝ) / 1250000) ((-15381389 : ℝ) / 6250000) := rb_log h47 (by norm_num) cov_log_428.1 cov_log_429.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((39233 : ℝ) / 2000000) ((399039 : ℝ) / 20000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-393138429 : ℝ) / 100000000) ((-391442839 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_430.1 cov_log_431.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67289669 : ℝ) / 100000000) ((6732289 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_417.1 cov_log_418.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((808511 : ℝ) / 781250) ((20777527 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-289649021 : ℝ) / 100000000) ((-71888801 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((16265307 : ℝ) / 100000000) ((2195747 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((60406797 : ℝ) / 100000000) ((38501043 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-14327639 : ℝ) / 6250000) ((-105276559 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((103047659 : ℝ) / 100000000) ((103109651 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-3262271 : ℝ) / 1250000) ((-15381389 : ℝ) / 6250000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-14327639 : ℝ) / 6250000) ((-105276559 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((61 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2310411 : ℝ) / 100000000) ((1186819 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((51186819 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((61 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-58021113 : ℝ) / 25000000) ≤ formC0 k A q vp vm + hfun ((61 : ℝ) / 20) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_7, cov_h_3]
  have hP : ((320752041 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((105276559 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((105276559 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1379 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1379 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1399 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1399 : ℝ) / 500)) (lo := ((1379 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1419 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1419 : ℝ) / 500)) (lo := ((1399 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1439 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1439 : ℝ) / 500)) (lo := ((1419 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1459 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1459 : ℝ) / 500)) (lo := ((1439 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1479 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1479 : ℝ) / 500)) (lo := ((1459 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1499 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1499 : ℝ) / 500)) (lo := ((1479 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1519 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1519 : ℝ) / 500)) (lo := ((1499 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((61 : ℝ) / 20)) (lo := ((1519 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_23 {k : ℝ} (hk : RB k ((9843 : ℝ) / 6400) ((2469 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((9843 : ℝ) / 16243) ((2469 : ℝ) / 4069) ∧
    RB (qa (r1A k)) ((100089 : ℝ) / 10000000) ((1017667 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((48997659 : ℝ) / 25000000) ((24506969 : ℝ) / 12500000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((19224609 : ℝ) / 50000000) ((2469 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((61447 : ℝ) / 32000) ((96075391 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138571957 : ℝ) / 100000000) ((138618463 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279993313 : ℝ) / 100000000) ((14001991 : ℝ) / 5000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((8749791 : ℝ) / 6250000) ((14001991 : ℝ) / 10000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((48997659 : ℝ) / 25000000) ((24506969 : ℝ) / 12500000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3924609 : ℝ) / 50000000) ((2553 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((30661 : ℝ) / 1562500) ((498633 : ℝ) / 25000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((100089 : ℝ) / 10000000) ((1017667 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((48997659 : ℝ) / 25000000) ((24506969 : ℝ) / 12500000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((100089 : ℝ) / 10000000) ((1017667 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((9843 : ℝ) / 16243) ((2469 : ℝ) / 4069) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_23 {k : ℝ} (hk : RB k ((9843 : ℝ) / 6400) ((2469 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_23 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_23 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((1714949 : ℝ) / 4000000)) (ph := ((2707553 : ℝ) / 6250000)) (ml := ((127972031 : ℝ) / 100000000)) (mh := ((64079811 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_23 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_24 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2469 : ℝ) / 4069) ((9909 : ℝ) / 16309))
    (hq : RB (qa a) ((508833 : ℝ) / 50000000) ((517227 : ℝ) / 50000000))
    (hd : RB (D0a a) ((39185103 : ℝ) / 20000000) ((195990643 : ℝ) / 100000000))
    : certE k a ((42808781 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((43249023 : ℝ) / 100000000) ∧ 0 < certE k a ((128034741 : ℝ) / 100000000) ∧ certE k a ((4006931 : ℝ) / 3125000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((2589 : ℝ) / 25000000) ((10701 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42808781 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((33436 : ℝ) / 78125) ((1711937 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((42808781 : ℝ) / 100000000) ((42808781 : ℝ) / 100000000) ((42808781 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57191219 : ℝ) / 100000000))
  have h3 : RB z3 ((37416653 : ℝ) / 50000000) ((7483391 : ℝ) / 10000000) := rb_div_signed h2 (show RB ((57191219 : ℝ) / 100000000) ((57191219 : ℝ) / 100000000) ((57191219 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-14495357 : ℝ) / 50000000) ((-14494953 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_432.1 cov_log_433.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-17614139 : ℝ) / 100000000) ((-17590581 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42808781 : ℝ) / 100000000))
  have h6 : RB z6 ((-10605337 : ℝ) / 12500000) ((-42421347 : ℝ) / 50000000) := rb_log (show RB ((42808781 : ℝ) / 100000000) ((42808781 : ℝ) / 100000000) ((42808781 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_434.1 cov_log_434.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((13445711 : ℝ) / 20000000) ((13450423 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67256437 : ℝ) / 100000000) ((2691587 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_435.1 cov_log_436.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-191 : ℝ) / 312500) ((-2161 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((2589 : ℝ) / 25000000) ((10701 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43249023 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((21619161 : ℝ) / 50000000) ((43238667 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43249023 : ℝ) / 100000000) ((43249023 : ℝ) / 100000000) ((43249023 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56750977 : ℝ) / 100000000))
  have h12 : RB z12 ((19047391 : ℝ) / 25000000) ((76190173 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((56750977 : ℝ) / 100000000) ((56750977 : ℝ) / 100000000) ((56750977 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-27194569 : ℝ) / 100000000) ((-27193769 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_437.1 cov_log_438.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-413071 : ℝ) / 2500000) ((-4125179 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43249023 : ℝ) / 100000000))
  have h15 : RB z15 ((-20954889 : ℝ) / 25000000) ((-41909777 : ℝ) / 50000000) := rb_log (show RB ((43249023 : ℝ) / 100000000) ((43249023 : ℝ) / 100000000) ((43249023 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_439.1 cov_log_439.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33648357 : ℝ) / 50000000) ((1682971 : ℝ) / 2500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67256437 : ℝ) / 100000000) ((2691587 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_435.1 cov_log_436.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((7039 : ℝ) / 100000000) ((62403 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((2589 : ℝ) / 25000000) ((10701 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((128034741 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((3200601 : ℝ) / 2500000) ((25604877 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((128034741 : ℝ) / 100000000) ((128034741 : ℝ) / 100000000) ((128034741 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((28034741 : ℝ) / 100000000))
  have h21 : RB z21 ((45666211 : ℝ) / 10000000) ((228331671 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((28034741 : ℝ) / 100000000) ((28034741 : ℝ) / 100000000) ((28034741 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((37969339 : ℝ) / 25000000) ((151877629 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_440.1 cov_log_441.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23039149 : ℝ) / 25000000) ((92277603 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((128034741 : ℝ) / 100000000))
  have h24 : RB z24 ((4942629 : ℝ) / 20000000) ((12356573 : ℝ) / 50000000) := rb_log (show RB ((128034741 : ℝ) / 100000000) ((128034741 : ℝ) / 100000000) ((128034741 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_442.1 cov_log_442.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((1348869 : ℝ) / 2000000) ((33782229 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67256437 : ℝ) / 100000000) ((2691587 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_435.1 cov_log_436.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((6151 : ℝ) / 4000000) ((308021 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((2589 : ℝ) / 25000000) ((10701 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((4006931 : ℝ) / 3125000)) - (z28)
  have h29 : RB z29 ((128211091 : ℝ) / 100000000) ((32052859 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4006931 : ℝ) / 3125000) ((4006931 : ℝ) / 3125000) ((4006931 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((881931 : ℝ) / 3125000))
  have h30 : RB z30 ((28393637 : ℝ) / 6250000) ((56787427 : ℝ) / 12500000) := rb_div_signed h29 (show RB ((881931 : ℝ) / 3125000) ((881931 : ℝ) / 3125000) ((881931 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((3783959 : ℝ) / 2500000) ((151358633 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_443.1 cov_log_444.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((45920839 : ℝ) / 50000000) ((91962273 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((4006931 : ℝ) / 3125000))
  have h33 : RB z33 ((6214783 : ℝ) / 25000000) ((24859133 : ℝ) / 100000000) := rb_log (show RB ((4006931 : ℝ) / 3125000) ((4006931 : ℝ) / 3125000) ((4006931 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_445.1 cov_log_445.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((13396509 : ℝ) / 20000000) ((67103141 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67256437 : ℝ) / 100000000) ((2691587 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_435.1 cov_log_436.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-30713 : ℝ) / 10000000) ((-9581 : ℝ) / 6250000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42808781 : ℝ) / 100000000)) ((-191 : ℝ) / 312500) ((-2161 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43249023 : ℝ) / 100000000)) ((7039 : ℝ) / 100000000) ((62403 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((128034741 : ℝ) / 100000000)) ((6151 : ℝ) / 4000000) ((308021 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((4006931 : ℝ) / 3125000)) ((-30713 : ℝ) / 10000000) ((-9581 : ℝ) / 6250000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_24 {k A q d vp vm : ℝ}
    (hk : RB k ((2469 : ℝ) / 1600) ((9909 : ℝ) / 6400))
    (hA : RB A ((2469 : ℝ) / 4069) ((9909 : ℝ) / 16309))
    (hq : RB q ((508833 : ℝ) / 50000000) ((517227 : ℝ) / 50000000))
    (hd : RB d ((39185103 : ℝ) / 20000000) ((195990643 : ℝ) / 100000000))
    (hp : RB vp ((42808781 : ℝ) / 100000000) ((43249023 : ℝ) / 100000000))
    (hm : RB vm ((128034741 : ℝ) / 100000000) ((4006931 : ℝ) / 3125000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((2589 : ℝ) / 25000000) ((10701 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99989299 : ℝ) / 100000000) ((24997411 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((30335903 : ℝ) / 50000000) ((15187893 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((4789 : ℝ) / 20000000) ((12499 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49987501 : ℝ) / 50000000) ((19995211 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56750977 : ℝ) / 100000000) ((57191219 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((5673679 : ℝ) / 10000000) ((2287101 : ℝ) / 4000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((26527821 : ℝ) / 25000000) ((107076153 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1527821 : ℝ) / 25000000) ((7076153 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99989299 : ℝ) / 100000000) ((24997411 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((30335903 : ℝ) / 50000000) ((15187893 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((2019 : ℝ) / 25000000) ((4179 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49995821 : ℝ) / 50000000) ((24997981 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((28034741 : ℝ) / 100000000) ((881931 : ℝ) / 3125000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((28032397 : ℝ) / 100000000) ((28219513 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((214999479 : ℝ) / 100000000) ((216719149 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((314999479 : ℝ) / 100000000) ((316719149 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((282639451 : ℝ) / 20000000) ((51134917 : ℝ) / 3125000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15786857 : ℝ) / 50000000) ((6349217 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2469 : ℝ) / 800) ((9909 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((3140771 : ℝ) / 100000000) ((800813 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50508833 : ℝ) / 50000000) ((50517227 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3108613 : ℝ) / 100000000) ((1585491 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((103108613 : ℝ) / 100000000) ((51585491 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((42392859 : ℝ) / 50000000) ((85413011 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((83058427 : ℝ) / 50000000) ((16740151 : ℝ) / 10000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((54810111 : ℝ) / 100000000) ((55454673 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((9337 : ℝ) / 50000000) ((4881 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24995119 : ℝ) / 25000000) ((49990663 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((166084421 : ℝ) / 100000000) ((669481 : ℝ) / 400000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((39185103 : ℝ) / 10000000) ((195990643 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1993867 : ℝ) / 50000000) ((4054867 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4069 : ℝ) / 1600) ((16309 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((195609 : ℝ) / 12500000) ((1594443 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1176519 : ℝ) / 50000000) ((2416453 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51176519 : ℝ) / 50000000) ((102416453 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1446450323 : ℝ) / 100000000) ((209482273 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((198419 : ℝ) / 25000000) ((201987 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25198419 : ℝ) / 25000000) ((25201987 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((15912153 : ℝ) / 50000000) ((32002577 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1478274629 : ℝ) / 100000000) ((1707860761 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((4626621 : ℝ) / 20000000) ((27230867 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4069 : ℝ) / 1600) ((16309 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((103108613 : ℝ) / 50000000) ((51585491 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1444770969 : ℝ) / 100000000) ((1668063429 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1489683307 : ℝ) / 50000000) ((3441914841 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1847173 : ℝ) / 25000000) ((4276549 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-260521951 : ℝ) / 100000000) ((-122943831 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_446.1 cov_log_447.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1993867 : ℝ) / 100000000) ((1013717 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-97877357 : ℝ) / 25000000) ((-194919961 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_448.1 cov_log_449.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67256437 : ℝ) / 100000000) ((2691587 : ℝ) / 4000000) := rb_log hd (by norm_num) cov_log_435.1 cov_log_436.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((103785089 : ℝ) / 100000000) ((104183343 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-287724339 : ℝ) / 100000000) ((-285656579 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((16072797 : ℝ) / 100000000) ((17358627 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((59024183 : ℝ) / 100000000) ((37519017 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-57175039 : ℝ) / 25000000) ((-42123709 : ℝ) / 20000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((103108613 : ℝ) / 100000000) ((51585491 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-260521951 : ℝ) / 100000000) ((-122943831 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-57175039 : ℝ) / 25000000) ((-42123709 : ℝ) / 20000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((61 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1176519 : ℝ) / 50000000) ((2416453 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((102416453 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((61 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-231624723 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((61 : ℝ) / 20) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_7, cov_h_3]
  have hP : ((128264391 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((42123709 : ℝ) / 20000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((42123709 : ℝ) / 20000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2763 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2763 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2803 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2803 : ℝ) / 1000)) (lo := ((2763 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2843 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2843 : ℝ) / 1000)) (lo := ((2803 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2883 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2883 : ℝ) / 1000)) (lo := ((2843 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2923 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2923 : ℝ) / 1000)) (lo := ((2883 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2963 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2963 : ℝ) / 1000)) (lo := ((2923 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3003 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3003 : ℝ) / 1000)) (lo := ((2963 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3043 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3043 : ℝ) / 1000)) (lo := ((3003 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((61 : ℝ) / 20)) (lo := ((3043 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_24 {k : ℝ} (hk : RB k ((2469 : ℝ) / 1600) ((9909 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((2469 : ℝ) / 4069) ((9909 : ℝ) / 16309) ∧
    RB (qa (r1A k)) ((508833 : ℝ) / 50000000) ((517227 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((39185103 : ℝ) / 20000000) ((195990643 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2469 : ℝ) / 6400) ((4838379 : ℝ) / 12500000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((23986621 : ℝ) / 12500000) ((61447 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138525437 : ℝ) / 100000000) ((69285979 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279946793 : ℝ) / 100000000) ((55998663 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((34993349 : ℝ) / 25000000) ((69998329 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((39185103 : ℝ) / 20000000) ((195990643 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2553 : ℝ) / 32000) ((1013379 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1994531 : ℝ) / 100000000) ((1013379 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((508833 : ℝ) / 50000000) ((517227 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((39185103 : ℝ) / 20000000) ((195990643 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((508833 : ℝ) / 50000000) ((517227 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2469 : ℝ) / 4069) ((9909 : ℝ) / 16309) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_24 {k : ℝ} (hk : RB k ((2469 : ℝ) / 1600) ((9909 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_24 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_24 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((42808781 : ℝ) / 100000000)) (ph := ((43249023 : ℝ) / 100000000)) (ml := ((128034741 : ℝ) / 100000000)) (mh := ((4006931 : ℝ) / 3125000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_24 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
