import LeanProject.COVLogTwo
import LeanProject.COVLogBounds18
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1760 : RB (Real.log ((6689469 : ℝ) / 50000000)) ((-100574427 : ℝ) / 50000000) ((-4022977 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((6689469 : ℝ) / 6250000)) (t := ((439469 : ℝ) / 12939469))
    (lo := ((6795303 : ℝ) / 100000000)) (hi := ((849413 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6689469 : ℝ) / 50000000) = Real.log ((6689469 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6689469 : ℝ) / 50000000) = ((6689469 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1761 : RB (Real.log ((7079929 : ℝ) / 50000000)) ((-48868979 : ℝ) / 25000000) ((-24434489 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((7079929 : ℝ) / 6250000)) (t := ((829929 : ℝ) / 13329929))
    (lo := ((12468241 : ℝ) / 100000000)) (hi := ((6234121 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7079929 : ℝ) / 50000000) = Real.log ((7079929 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((7079929 : ℝ) / 50000000) = ((7079929 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1762 : RB (Real.log ((2656001 : ℝ) / 50000000)) ((-18345009 : ℝ) / 6250000) ((-293520139 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2656001 : ℝ) / 3125000)) (t := ((-468999 : ℝ) / 5781001))
    (lo := ((-4065317 : ℝ) / 25000000)) (hi := ((-16261267 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2656001 : ℝ) / 50000000) = Real.log ((2656001 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2656001 : ℝ) / 50000000) = ((2656001 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1763 : RB (Real.log ((534797 : ℝ) / 10000000)) ((-146422659 : ℝ) / 50000000) ((-292845313 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((534797 : ℝ) / 625000)) (t := ((-90203 : ℝ) / 1159797))
    (lo := ((-7793221 : ℝ) / 50000000)) (hi := ((-15586441 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((534797 : ℝ) / 10000000) = Real.log ((534797 : ℝ) / 625000) - 4 * Real.log 2 := by
    rw [show ((534797 : ℝ) / 10000000) = ((534797 : ℝ) / 625000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1764 : RB (Real.log ((62654329 : ℝ) / 100000000)) ((-23376871 : ℝ) / 50000000) ((-2337687 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((62654329 : ℝ) / 50000000)) (t := ((12654329 : ℝ) / 112654329))
    (lo := ((22560977 : ℝ) / 100000000)) (hi := ((11280489 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62654329 : ℝ) / 100000000) = Real.log ((62654329 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62654329 : ℝ) / 100000000) = ((62654329 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1765 : RB (Real.log ((62655997 : ℝ) / 100000000)) ((-1168777 : ℝ) / 2500000) ((-23375539 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((62655997 : ℝ) / 50000000)) (t := ((12655997 : ℝ) / 112655997))
    (lo := ((22563639 : ℝ) / 100000000)) (hi := ((564091 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62655997 : ℝ) / 100000000) = Real.log ((62655997 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62655997 : ℝ) / 100000000) = ((62655997 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1766 : RB (Real.log ((19284833 : ℝ) / 50000000)) ((-95270409 : ℝ) / 100000000) ((-95270407 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19284833 : ℝ) / 25000000)) (t := ((-5715167 : ℝ) / 44284833))
    (lo := ((-2595569 : ℝ) / 10000000)) (hi := ((-25955689 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19284833 : ℝ) / 50000000) = Real.log ((19284833 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19284833 : ℝ) / 50000000) = ((19284833 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1767 : RB (Real.log ((9454519 : ℝ) / 5000000)) ((63705491 : ℝ) / 100000000) ((63705493 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9454519 : ℝ) / 10000000)) (t := ((-545481 : ℝ) / 19454519))
    (lo := ((-5609227 : ℝ) / 100000000)) (hi := ((-2804613 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9454519 : ℝ) / 5000000) = Real.log ((9454519 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((9454519 : ℝ) / 5000000) = ((9454519 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1768 : RB (Real.log ((189156719 : ℝ) / 100000000)) ((7967571 : ℝ) / 12500000) ((6374057 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((189156719 : ℝ) / 200000000)) (t := ((-10843281 : ℝ) / 389156719))
    (lo := ((-111483 : ℝ) / 2000000)) (hi := ((-5574149 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189156719 : ℝ) / 100000000) = Real.log ((189156719 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189156719 : ℝ) / 100000000) = ((189156719 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1769 : RB (Real.log ((63363631 : ℝ) / 100000000)) ((-9125603 : ℝ) / 20000000) ((-45628013 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63363631 : ℝ) / 50000000)) (t := ((13363631 : ℝ) / 113363631))
    (lo := ((1480419 : ℝ) / 6250000)) (hi := ((4737341 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63363631 : ℝ) / 100000000) = Real.log ((63363631 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63363631 : ℝ) / 100000000) = ((63363631 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1770 : RB (Real.log ((63365307 : ℝ) / 100000000)) ((-4562537 : ℝ) / 10000000) ((-5703171 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((63365307 : ℝ) / 50000000)) (t := ((13365307 : ℝ) / 113365307))
    (lo := ((23689349 : ℝ) / 100000000)) (hi := ((473787 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63365307 : ℝ) / 100000000) = Real.log ((63365307 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63365307 : ℝ) / 100000000) = ((63365307 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1771 : RB (Real.log ((9709097 : ℝ) / 25000000)) ((-11822657 : ℝ) / 12500000) ((-47290627 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9709097 : ℝ) / 12500000)) (t := ((-2790903 : ℝ) / 22209097))
    (lo := ((-25266537 : ℝ) / 100000000)) (hi := ((-3158317 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9709097 : ℝ) / 25000000) = Real.log ((9709097 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9709097 : ℝ) / 25000000) = ((9709097 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1772 : RB (Real.log ((198004507 : ℝ) / 50000000)) ((68813339 : ℝ) / 50000000) ((137626681 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((198004507 : ℝ) / 200000000)) (t := ((-1995493 : ℝ) / 398004507))
    (lo := ((-501379 : ℝ) / 50000000)) (hi := ((-1002757 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((198004507 : ℝ) / 50000000) = Real.log ((198004507 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((198004507 : ℝ) / 50000000) = ((198004507 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1773 : RB (Real.log ((396012049 : ℝ) / 100000000)) ((27525489 : ℝ) / 20000000) ((17203431 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((396012049 : ℝ) / 400000000)) (t := ((-3987951 : ℝ) / 796012049))
    (lo := ((-1001991 : ℝ) / 100000000)) (hi := ((-100199 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((396012049 : ℝ) / 100000000) = Real.log ((396012049 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((396012049 : ℝ) / 100000000) = ((396012049 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1774 : RB (Real.log ((4179857 : ℝ) / 3125000)) ((1163371 : ℝ) / 4000000) ((29084277 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4179857 : ℝ) / 6250000)) (t := ((-2070143 : ℝ) / 10429857))
    (lo := ((-40230443 : ℝ) / 100000000)) (hi := ((-20115221 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4179857 : ℝ) / 3125000) = Real.log ((4179857 : ℝ) / 6250000) + 1 * Real.log 2 := by
    rw [show ((4179857 : ℝ) / 3125000) = ((4179857 : ℝ) / 6250000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1775 : RB (Real.log ((197365867 : ℝ) / 50000000)) ((137303619 : ℝ) / 100000000) ((68651811 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((197365867 : ℝ) / 200000000)) (t := ((-2634133 : ℝ) / 397365867))
    (lo := ((-1325817 : ℝ) / 100000000)) (hi := ((-165727 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197365867 : ℝ) / 50000000) = Real.log ((197365867 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((197365867 : ℝ) / 50000000) = ((197365867 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1776 : RB (Real.log ((98683689 : ℝ) / 25000000)) ((2145381 : ℝ) / 1562500) ((137304387 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((98683689 : ℝ) / 100000000)) (t := ((-1316311 : ℝ) / 198683689))
    (lo := ((-331263 : ℝ) / 25000000)) (hi := ((-1325051 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98683689 : ℝ) / 25000000) = Real.log ((98683689 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((98683689 : ℝ) / 25000000) = ((98683689 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1777 : RB (Real.log ((13390171 : ℝ) / 10000000)) ((29193583 : ℝ) / 100000000) ((5838717 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((13390171 : ℝ) / 20000000)) (t := ((-6609829 : ℝ) / 33390171))
    (lo := ((-8024227 : ℝ) / 20000000)) (hi := ((-20060567 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13390171 : ℝ) / 10000000) = Real.log ((13390171 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((13390171 : ℝ) / 10000000) = ((13390171 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1778 : RB (Real.log ((537441 : ℝ) / 4000000)) ((-200723069 : ℝ) / 100000000) ((-40144613 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((537441 : ℝ) / 500000)) (t := ((37441 : ℝ) / 1037441))
    (lo := ((225659 : ℝ) / 3125000)) (hi := ((7221089 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((537441 : ℝ) / 4000000) = Real.log ((537441 : ℝ) / 500000) - 3 * Real.log 2 := by
    rw [show ((537441 : ℝ) / 4000000) = ((537441 : ℝ) / 500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1779 : RB (Real.log ((14215533 : ℝ) / 100000000)) ((-97541749 : ℝ) / 50000000) ((-97541747 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((14215533 : ℝ) / 12500000)) (t := ((1715533 : ℝ) / 26715533))
    (lo := ((12860659 : ℝ) / 100000000)) (hi := ((643033 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14215533 : ℝ) / 100000000) = Real.log ((14215533 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((14215533 : ℝ) / 100000000) = ((14215533 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1780 : RB (Real.log ((5344217 : ℝ) / 100000000)) ((-292915519 : ℝ) / 100000000) ((-146457757 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5344217 : ℝ) / 6250000)) (t := ((-905783 : ℝ) / 11594217))
    (lo := ((-15656643 : ℝ) / 100000000)) (hi := ((-7828321 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5344217 : ℝ) / 100000000) = Real.log ((5344217 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5344217 : ℝ) / 100000000) = ((5344217 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1781 : RB (Real.log ((538021 : ℝ) / 10000000)) ((-146122141 : ℝ) / 50000000) ((-292244277 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((538021 : ℝ) / 625000)) (t := ((-86979 : ℝ) / 1163021))
    (lo := ((-7492703 : ℝ) / 50000000)) (hi := ((-2997081 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((538021 : ℝ) / 10000000) = Real.log ((538021 : ℝ) / 625000) - 4 * Real.log 2 := by
    rw [show ((538021 : ℝ) / 10000000) = ((538021 : ℝ) / 625000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1782 : RB (Real.log ((2502891 : ℝ) / 4000000)) ((-46884791 : ℝ) / 100000000) ((-46884789 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2502891 : ℝ) / 2000000)) (t := ((502891 : ℝ) / 4502891))
    (lo := ((2803741 : ℝ) / 12500000)) (hi := ((22429929 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2502891 : ℝ) / 4000000) = Real.log ((2502891 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((2502891 : ℝ) / 4000000) = ((2502891 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1783 : RB (Real.log ((62573953 : ℝ) / 100000000)) ((-4688211 : ℝ) / 10000000) ((-11720527 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((62573953 : ℝ) / 50000000)) (t := ((12573953 : ℝ) / 112573953))
    (lo := ((22432609 : ℝ) / 100000000)) (hi := ((2243261 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62573953 : ℝ) / 100000000) = Real.log ((62573953 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62573953 : ℝ) / 100000000) = ((62573953 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1784 : RB (Real.log ((19269647 : ℝ) / 50000000)) ((-47674593 : ℝ) / 50000000) ((-1489831 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((19269647 : ℝ) / 25000000)) (t := ((-5730353 : ℝ) / 44269647))
    (lo := ((-26034467 : ℝ) / 100000000)) (hi := ((-13017233 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19269647 : ℝ) / 50000000) = Real.log ((19269647 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19269647 : ℝ) / 50000000) = ((19269647 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1785 : RB (Real.log ((94512017 : ℝ) / 50000000)) ((31835199 : ℝ) / 50000000) ((19897 : ℝ) / 31250) := by
  have hm := log_bounds_of_series (x := ((94512017 : ℝ) / 100000000)) (t := ((-5487983 : ℝ) / 194512017))
    (lo := ((-35277 : ℝ) / 625000)) (hi := ((-5644319 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94512017 : ℝ) / 50000000) = Real.log ((94512017 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94512017 : ℝ) / 50000000) = ((94512017 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1786 : RB (Real.log ((189090387 : ℝ) / 100000000)) ((12741099 : ℝ) / 20000000) ((63705497 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((189090387 : ℝ) / 200000000)) (t := ((-10909613 : ℝ) / 389090387))
    (lo := ((-5609223 : ℝ) / 100000000)) (hi := ((-2804611 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189090387 : ℝ) / 100000000) = Real.log ((189090387 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189090387 : ℝ) / 100000000) = ((189090387 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1787 : RB (Real.log ((12655843 : ℝ) / 20000000)) ((-2860083 : ℝ) / 6250000) ((-22880663 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12655843 : ℝ) / 10000000)) (t := ((2655843 : ℝ) / 22655843))
    (lo := ((23553391 : ℝ) / 100000000)) (hi := ((1472087 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12655843 : ℝ) / 20000000) = Real.log ((12655843 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((12655843 : ℝ) / 20000000) = ((12655843 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1788 : RB (Real.log ((63280901 : ℝ) / 100000000)) ((-5719833 : ℝ) / 12500000) ((-22879331 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((63280901 : ℝ) / 50000000)) (t := ((13280901 : ℝ) / 113280901))
    (lo := ((4711211 : ℝ) / 20000000)) (hi := ((2944507 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63280901 : ℝ) / 100000000) = Real.log ((63280901 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63280901 : ℝ) / 100000000) = ((63280901 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1789 : RB (Real.log ((38805397 : ℝ) / 100000000)) ((-94661087 : ℝ) / 100000000) ((-18932217 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((38805397 : ℝ) / 50000000)) (t := ((-11194603 : ℝ) / 88805397))
    (lo := ((-396037 : ℝ) / 1562500)) (hi := ((-25346367 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38805397 : ℝ) / 100000000) = Real.log ((38805397 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38805397 : ℝ) / 100000000) = ((38805397 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1790 : RB (Real.log ((15823127 : ℝ) / 4000000)) ((537179 : ℝ) / 390625) ((137517827 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((15823127 : ℝ) / 16000000)) (t := ((-176873 : ℝ) / 31823127))
    (lo := ((-277903 : ℝ) / 25000000)) (hi := ((-1111611 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15823127 : ℝ) / 4000000) = Real.log ((15823127 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((15823127 : ℝ) / 4000000) = ((15823127 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1791 : RB (Real.log ((15823249 : ℝ) / 4000000)) ((27503719 : ℝ) / 20000000) ((68759299 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((15823249 : ℝ) / 16000000)) (t := ((-176751 : ℝ) / 31823249))
    (lo := ((-1110841 : ℝ) / 100000000)) (hi := ((-27771 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15823249 : ℝ) / 4000000) = Real.log ((15823249 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((15823249 : ℝ) / 4000000) = ((15823249 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1792 : RB (Real.log ((66902139 : ℝ) / 50000000)) ((29120793 : ℝ) / 100000000) ((5824159 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((66902139 : ℝ) / 100000000)) (t := ((-33097861 : ℝ) / 166902139))
    (lo := ((-1607757 : ℝ) / 4000000)) (hi := ((-10048481 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66902139 : ℝ) / 50000000) = Real.log ((66902139 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((66902139 : ℝ) / 50000000) = ((66902139 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1793 : RB (Real.log ((197153491 : ℝ) / 50000000)) ((34298989 : ℝ) / 25000000) ((137195959 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((197153491 : ℝ) / 200000000)) (t := ((-2846509 : ℝ) / 397153491))
    (lo := ((-35837 : ℝ) / 2500000)) (hi := ((-1433479 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197153491 : ℝ) / 50000000) = Real.log ((197153491 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((197153491 : ℝ) / 50000000) = ((197153491 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1794 : RB (Real.log ((394310019 : ℝ) / 100000000)) ((68598363 : ℝ) / 50000000) ((137196729 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((394310019 : ℝ) / 400000000)) (t := ((-5689981 : ℝ) / 794310019))
    (lo := ((-143271 : ℝ) / 10000000)) (hi := ((-1432709 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((394310019 : ℝ) / 100000000) = Real.log ((394310019 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((394310019 : ℝ) / 100000000) = ((394310019 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1795 : RB (Real.log ((8371893 : ℝ) / 6250000)) ((5845971 : ℝ) / 20000000) ((29229857 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8371893 : ℝ) / 12500000)) (t := ((-4128107 : ℝ) / 20871893))
    (lo := ((-40084863 : ℝ) / 100000000)) (hi := ((-20042431 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8371893 : ℝ) / 6250000) = Real.log ((8371893 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((8371893 : ℝ) / 6250000) = ((8371893 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1796 : RB (Real.log ((13492851 : ℝ) / 100000000)) ((-200301023 : ℝ) / 100000000) ((-200301019 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13492851 : ℝ) / 12500000)) (t := ((992851 : ℝ) / 25992851))
    (lo := ((3821567 : ℝ) / 50000000)) (hi := ((1528627 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13492851 : ℝ) / 100000000) = Real.log ((13492851 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13492851 : ℝ) / 100000000) = ((13492851 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1797 : RB (Real.log ((7135489 : ℝ) / 50000000)) ((-7787769 : ℝ) / 4000000) ((-194694221 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7135489 : ℝ) / 6250000)) (t := ((885489 : ℝ) / 13385489))
    (lo := ((3312483 : ℝ) / 25000000)) (hi := ((13249933 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7135489 : ℝ) / 50000000) = Real.log ((7135489 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((7135489 : ℝ) / 50000000) = ((7135489 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1798 : RB (Real.log ((5376431 : ℝ) / 100000000)) ((-146157273 : ℝ) / 50000000) ((-292314541 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5376431 : ℝ) / 6250000)) (t := ((-873569 : ℝ) / 11626431))
    (lo := ((-1505567 : ℝ) / 10000000)) (hi := ((-15055669 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5376431 : ℝ) / 100000000) = Real.log ((5376431 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5376431 : ℝ) / 100000000) = ((5376431 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1799 : RB (Real.log ((169139 : ℝ) / 3125000)) ((-145823437 : ℝ) / 50000000) ((-291646869 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((338278 : ℝ) / 390625)) (t := ((-52347 : ℝ) / 728903))
    (lo := ((-7193999 : ℝ) / 50000000)) (hi := ((-14387997 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((169139 : ℝ) / 3125000) = Real.log ((338278 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((169139 : ℝ) / 3125000) = ((338278 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1800 : RB (Real.log ((7811307 : ℝ) / 12500000)) ((-11753909 : ℝ) / 25000000) ((-23507817 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((7811307 : ℝ) / 6250000)) (t := ((1561307 : ℝ) / 14061307))
    (lo := ((22299083 : ℝ) / 100000000)) (hi := ((5574771 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7811307 : ℝ) / 12500000) = Real.log ((7811307 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((7811307 : ℝ) / 12500000) = ((7811307 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1801 : RB (Real.log ((62492147 : ℝ) / 100000000)) ((-4701293 : ℝ) / 10000000) ((-734577 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((62492147 : ℝ) / 50000000)) (t := ((12492147 : ℝ) / 112492147))
    (lo := ((22301789 : ℝ) / 100000000)) (hi := ((2230179 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62492147 : ℝ) / 100000000) = Real.log ((62492147 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62492147 : ℝ) / 100000000) = ((62492147 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1802 : RB (Real.log ((7701797 : ℝ) / 20000000)) ((-95427861 : ℝ) / 100000000) ((-95427859 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7701797 : ℝ) / 10000000)) (t := ((-2298203 : ℝ) / 17701797))
    (lo := ((-13056571 : ℝ) / 50000000)) (hi := ((-26113141 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7701797 : ℝ) / 20000000) = Real.log ((7701797 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((7701797 : ℝ) / 20000000) = ((7701797 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1803 : RB (Real.log ((47239419 : ℝ) / 25000000)) ((31817643 : ℝ) / 50000000) ((7954411 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((47239419 : ℝ) / 50000000)) (t := ((-2760581 : ℝ) / 97239419))
    (lo := ((-709929 : ℝ) / 12500000)) (hi := ((-5679431 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47239419 : ℝ) / 25000000) = Real.log ((47239419 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((47239419 : ℝ) / 25000000) = ((47239419 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1804 : RB (Real.log ((189024041 : ℝ) / 100000000)) ((31835201 : ℝ) / 50000000) ((15917601 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((189024041 : ℝ) / 200000000)) (t := ((-10975959 : ℝ) / 389024041))
    (lo := ((-1411079 : ℝ) / 25000000)) (hi := ((-1128863 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189024041 : ℝ) / 100000000) = Real.log ((189024041 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189024041 : ℝ) / 100000000) = ((189024041 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1805 : RB (Real.log ((63195081 : ℝ) / 100000000)) ((-45894373 : ℝ) / 100000000) ((-45894371 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63195081 : ℝ) / 50000000)) (t := ((13195081 : ℝ) / 113195081))
    (lo := ((11710173 : ℝ) / 50000000)) (hi := ((23420347 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63195081 : ℝ) / 100000000) = Real.log ((63195081 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63195081 : ℝ) / 100000000) = ((63195081 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1806 : RB (Real.log ((63196779 : ℝ) / 100000000)) ((-45891687 : ℝ) / 100000000) ((-9178337 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((63196779 : ℝ) / 50000000)) (t := ((13196779 : ℝ) / 113196779))
    (lo := ((2927879 : ℝ) / 12500000)) (hi := ((23423033 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63196779 : ℝ) / 100000000) = Real.log ((63196779 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63196779 : ℝ) / 100000000) = ((63196779 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1807 : RB (Real.log ((9693621 : ℝ) / 25000000)) ((-4737039 : ℝ) / 5000000) ((-47370389 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9693621 : ℝ) / 12500000)) (t := ((-2806379 : ℝ) / 22193621))
    (lo := ((-25426061 : ℝ) / 100000000)) (hi := ((-1271303 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9693621 : ℝ) / 25000000) = Real.log ((9693621 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9693621 : ℝ) / 25000000) = ((9693621 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1808 : RB (Real.log ((395149369 : ℝ) / 100000000)) ((27481873 : ℝ) / 20000000) ((17176171 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((395149369 : ℝ) / 400000000)) (t := ((-4850631 : ℝ) / 795149369))
    (lo := ((-1220071 : ℝ) / 100000000)) (hi := ((-122007 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((395149369 : ℝ) / 100000000) = Real.log ((395149369 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((395149369 : ℝ) / 100000000) = ((395149369 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1809 : RB (Real.log ((395152439 : ℝ) / 100000000)) ((68705071 : ℝ) / 50000000) ((27482029 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((395152439 : ℝ) / 400000000)) (t := ((-4847561 : ℝ) / 795152439))
    (lo := ((-609647 : ℝ) / 50000000)) (hi := ((-1219293 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((395152439 : ℝ) / 100000000) = Real.log ((395152439 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((395152439 : ℝ) / 100000000) = ((395152439 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1810 : RB (Real.log ((133853039 : ℝ) / 100000000)) ((7289307 : ℝ) / 25000000) ((2915723 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((133853039 : ℝ) / 200000000)) (t := ((-66146961 : ℝ) / 333853039))
    (lo := ((-4015749 : ℝ) / 10000000)) (hi := ((-40157489 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133853039 : ℝ) / 100000000) = Real.log ((133853039 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133853039 : ℝ) / 100000000) = ((133853039 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1811 : RB (Real.log ((393884217 : ℝ) / 100000000)) ((137088681 : ℝ) / 100000000) ((34272171 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((393884217 : ℝ) / 400000000)) (t := ((-6115783 : ℝ) / 793884217))
    (lo := ((-308151 : ℝ) / 20000000)) (hi := ((-770377 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((393884217 : ℝ) / 100000000) = Real.log ((393884217 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((393884217 : ℝ) / 100000000) = ((393884217 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1812 : RB (Real.log ((196943637 : ℝ) / 50000000)) ((137089457 : ℝ) / 100000000) ((6854473 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((196943637 : ℝ) / 200000000)) (t := ((-3056363 : ℝ) / 396943637))
    (lo := ((-1539979 : ℝ) / 100000000)) (hi := ((-769989 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196943637 : ℝ) / 50000000) = Real.log ((196943637 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((196943637 : ℝ) / 50000000) = ((196943637 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1813 : RB (Real.log ((66999387 : ℝ) / 50000000)) ((14633023 : ℝ) / 50000000) ((228641 : ℝ) / 781250) := by
  have hm := log_bounds_of_series (x := ((66999387 : ℝ) / 100000000)) (t := ((-33000613 : ℝ) / 166999387))
    (lo := ((-1251521 : ℝ) / 3125000)) (hi := ((-40048671 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66999387 : ℝ) / 50000000) = Real.log ((66999387 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((66999387 : ℝ) / 50000000) = ((66999387 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1814 : RB (Real.log ((13549409 : ℝ) / 100000000)) ((-199882729 : ℝ) / 100000000) ((-7995309 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((13549409 : ℝ) / 12500000)) (t := ((1049409 : ℝ) / 26049409))
    (lo := ((2015357 : ℝ) / 25000000)) (hi := ((8061429 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13549409 : ℝ) / 100000000) = Real.log ((13549409 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13549409 : ℝ) / 100000000) = ((13549409 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1815 : RB (Real.log ((14326193 : ℝ) / 100000000)) ((-48577017 : ℝ) / 25000000) ((-6072127 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((14326193 : ℝ) / 12500000)) (t := ((1826193 : ℝ) / 26826193))
    (lo := ((13636089 : ℝ) / 100000000)) (hi := ((1363609 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14326193 : ℝ) / 100000000) = Real.log ((14326193 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((14326193 : ℝ) / 100000000) = ((14326193 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1816 : RB (Real.log ((1081729 : ℝ) / 20000000)) ((-291717163 : ℝ) / 100000000) ((-145858579 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1081729 : ℝ) / 1250000)) (t := ((-168271 : ℝ) / 2331729))
    (lo := ((-14458287 : ℝ) / 100000000)) (hi := ((-7229143 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1081729 : ℝ) / 20000000) = Real.log ((1081729 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1081729 : ℝ) / 20000000) = ((1081729 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1817 : RB (Real.log ((5444687 : ℝ) / 100000000)) ((-72763249 : ℝ) / 25000000) ((-291052991 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5444687 : ℝ) / 6250000)) (t := ((-805313 : ℝ) / 11694687))
    (lo := ((-344853 : ℝ) / 2500000)) (hi := ((-13794119 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5444687 : ℝ) / 100000000) = Real.log ((5444687 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5444687 : ℝ) / 100000000) = ((5444687 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1818 : RB (Real.log ((62408873 : ℝ) / 100000000)) ((-23573137 : ℝ) / 50000000) ((-1473321 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((62408873 : ℝ) / 50000000)) (t := ((12408873 : ℝ) / 112408873))
    (lo := ((4433689 : ℝ) / 20000000)) (hi := ((11084223 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62408873 : ℝ) / 100000000) = Real.log ((62408873 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62408873 : ℝ) / 100000000) = ((62408873 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1819 : RB (Real.log ((62410573 : ℝ) / 100000000)) ((-942871 : ℝ) / 2000000) ((-11785887 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((62410573 : ℝ) / 50000000)) (t := ((12410573 : ℝ) / 112410573))
    (lo := ((22171169 : ℝ) / 100000000)) (hi := ((2217117 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((62410573 : ℝ) / 100000000) = Real.log ((62410573 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((62410573 : ℝ) / 100000000) = ((62410573 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1820 : RB (Real.log ((38478739 : ℝ) / 100000000)) ((-19101287 : ℝ) / 20000000) ((-95506433 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38478739 : ℝ) / 50000000)) (t := ((-11521261 : ℝ) / 88478739))
    (lo := ((-6547929 : ℝ) / 25000000)) (hi := ((-5238343 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38478739 : ℝ) / 100000000) = Real.log ((38478739 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38478739 : ℝ) / 100000000) = ((38478739 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1821 : RB (Real.log ((23611413 : ℝ) / 12500000)) ((12720031 : ℝ) / 20000000) ((63600157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((23611413 : ℝ) / 25000000)) (t := ((-1388587 : ℝ) / 48611413))
    (lo := ((-5714563 : ℝ) / 100000000)) (hi := ((-2857281 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23611413 : ℝ) / 12500000) = Real.log ((23611413 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((23611413 : ℝ) / 12500000) = ((23611413 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1822 : RB (Real.log ((94478841 : ℝ) / 50000000)) ((63635289 : ℝ) / 100000000) ((63635291 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((94478841 : ℝ) / 100000000)) (t := ((-5521159 : ℝ) / 194478841))
    (lo := ((-5679429 : ℝ) / 100000000)) (hi := ((-1419857 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94478841 : ℝ) / 50000000) = Real.log ((94478841 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94478841 : ℝ) / 50000000) = ((94478841 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1823 : RB (Real.log ((63111221 : ℝ) / 100000000)) ((-23013581 : ℝ) / 50000000) ((-1150679 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((63111221 : ℝ) / 50000000)) (t := ((13111221 : ℝ) / 113111221))
    (lo := ((23287557 : ℝ) / 100000000)) (hi := ((11643779 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63111221 : ℝ) / 100000000) = Real.log ((63111221 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63111221 : ℝ) / 100000000) = ((63111221 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1824 : RB (Real.log ((1972279 : ℝ) / 3125000)) ((-46024457 : ℝ) / 100000000) ((-9204891 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1972279 : ℝ) / 1562500)) (t := ((409779 : ℝ) / 3534779))
    (lo := ((11645131 : ℝ) / 50000000)) (hi := ((23290263 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1972279 : ℝ) / 3125000) = Real.log ((1972279 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((1972279 : ℝ) / 3125000) = ((1972279 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1825 : RB (Real.log ((19371823 : ℝ) / 50000000)) ((-94820343 : ℝ) / 100000000) ((-94820341 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19371823 : ℝ) / 25000000)) (t := ((-5628177 : ℝ) / 44371823))
    (lo := ((-3188203 : ℝ) / 12500000)) (hi := ((-25505623 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19371823 : ℝ) / 50000000) = Real.log ((19371823 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19371823 : ℝ) / 50000000) = ((19371823 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1826 : RB (Real.log ((15788903 : ℝ) / 4000000)) ((68650649 : ℝ) / 50000000) ((137301301 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((15788903 : ℝ) / 16000000)) (t := ((-211097 : ℝ) / 31788903))
    (lo := ((-664069 : ℝ) / 50000000)) (hi := ((-1328137 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15788903 : ℝ) / 4000000) = Real.log ((15788903 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((15788903 : ℝ) / 4000000) = ((15788903 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1827 : RB (Real.log ((394725659 : ℝ) / 100000000)) ((429069 : ℝ) / 312500) ((137302083 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((394725659 : ℝ) / 400000000)) (t := ((-5274341 : ℝ) / 794725659))
    (lo := ((-331839 : ℝ) / 25000000)) (hi := ((-265471 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((394725659 : ℝ) / 100000000) = Real.log ((394725659 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((394725659 : ℝ) / 100000000) = ((394725659 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1828 : RB (Real.log ((33475427 : ℝ) / 25000000)) ((14596791 : ℝ) / 50000000) ((1824599 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((33475427 : ℝ) / 50000000)) (t := ((-16524573 : ℝ) / 83475427))
    (lo := ((-2507571 : ℝ) / 6250000)) (hi := ((-8024227 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33475427 : ℝ) / 25000000) = Real.log ((33475427 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33475427 : ℝ) / 25000000) = ((33475427 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1829 : RB (Real.log ((393463421 : ℝ) / 100000000)) ((136981791 : ℝ) / 100000000) ((68490897 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((393463421 : ℝ) / 400000000)) (t := ((-6536579 : ℝ) / 793463421))
    (lo := ((-329529 : ℝ) / 20000000)) (hi := ((-411911 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((393463421 : ℝ) / 100000000) = Real.log ((393463421 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((393463421 : ℝ) / 100000000) = ((393463421 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1830 : RB (Real.log ((393466491 : ℝ) / 100000000)) ((34245643 : ℝ) / 25000000) ((5479303 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((393466491 : ℝ) / 400000000)) (t := ((-6533509 : ℝ) / 793466491))
    (lo := ((-102929 : ℝ) / 6250000)) (hi := ((-1646863 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((393466491 : ℝ) / 100000000) = Real.log ((393466491 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((393466491 : ℝ) / 100000000) = ((393466491 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1831 : RB (Real.log ((134047169 : ℝ) / 100000000)) ((5860431 : ℝ) / 20000000) ((29302157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((134047169 : ℝ) / 200000000)) (t := ((-65952831 : ℝ) / 334047169))
    (lo := ((-40012563 : ℝ) / 100000000)) (hi := ((-20006281 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((134047169 : ℝ) / 100000000) = Real.log ((134047169 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((134047169 : ℝ) / 100000000) = ((134047169 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1832 : RB (Real.log ((340143 : ℝ) / 2500000)) ((-199467993 : ℝ) / 100000000) ((-199467989 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((340143 : ℝ) / 312500)) (t := ((27643 : ℝ) / 652643))
    (lo := ((2119041 : ℝ) / 25000000)) (hi := ((1695233 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((340143 : ℝ) / 2500000) = Real.log ((340143 : ℝ) / 312500) - 3 * Real.log 2 := by
    rw [show ((340143 : ℝ) / 2500000) = ((340143 : ℝ) / 312500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1833 : RB (Real.log ((3595293 : ℝ) / 25000000)) ((-193925037 : ℝ) / 100000000) ((-193925033 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3595293 : ℝ) / 3125000)) (t := ((470293 : ℝ) / 6720293))
    (lo := ((175239 : ℝ) / 1250000)) (hi := ((14019121 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3595293 : ℝ) / 25000000) = Real.log ((3595293 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((3595293 : ℝ) / 25000000) = ((3595293 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1834 : RB (Real.log ((5440861 : ℝ) / 100000000)) ((-291123291 : ℝ) / 100000000) ((-145561643 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5440861 : ℝ) / 6250000)) (t := ((-809139 : ℝ) / 11690861))
    (lo := ((-2772883 : ℝ) / 20000000)) (hi := ((-6932207 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5440861 : ℝ) / 100000000) = Real.log ((5440861 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5440861 : ℝ) / 100000000) = ((5440861 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1835 : RB (Real.log ((2738463 : ℝ) / 50000000)) ((-290462623 : ℝ) / 100000000) ((-145231309 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2738463 : ℝ) / 3125000)) (t := ((-386537 : ℝ) / 5863463))
    (lo := ((-13203747 : ℝ) / 100000000)) (hi := ((-6601873 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2738463 : ℝ) / 50000000) = Real.log ((2738463 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2738463 : ℝ) / 50000000) = ((2738463 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1836 : RB (Real.log ((66103491 : ℝ) / 100000000)) ((-2587179 : ℝ) / 6250000) ((-20697431 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((66103491 : ℝ) / 50000000)) (t := ((16103491 : ℝ) / 116103491))
    (lo := ((5583971 : ℝ) / 20000000)) (hi := ((1744991 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66103491 : ℝ) / 100000000) = Real.log ((66103491 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66103491 : ℝ) / 100000000) = ((66103491 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1837 : RB (Real.log ((33051747 : ℝ) / 50000000)) ((-2069743 : ℝ) / 5000000) ((-20697429 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((33051747 : ℝ) / 25000000)) (t := ((8051747 : ℝ) / 58051747))
    (lo := ((27919859 : ℝ) / 100000000)) (hi := ((1395993 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33051747 : ℝ) / 50000000) = Real.log ((33051747 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((33051747 : ℝ) / 50000000) = ((33051747 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1838 : RB (Real.log ((497979 : ℝ) / 1250000)) ((-46017047 : ℝ) / 50000000) ((-23008523 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((497979 : ℝ) / 625000)) (t := ((-127021 : ℝ) / 1122979))
    (lo := ((-36351 : ℝ) / 160000)) (hi := ((-11359687 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((497979 : ℝ) / 1250000) = Real.log ((497979 : ℝ) / 625000) - 1 * Real.log 2 := by
    rw [show ((497979 : ℝ) / 1250000) = ((497979 : ℝ) / 625000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1839 : RB (Real.log ((23733541 : ℝ) / 12500000)) ((64116063 : ℝ) / 100000000) ((12823213 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((23733541 : ℝ) / 25000000)) (t := ((-1266459 : ℝ) / 48733541))
    (lo := ((-1039731 : ℝ) / 20000000)) (hi := ((-2599327 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23733541 : ℝ) / 12500000) = Real.log ((23733541 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((23733541 : ℝ) / 12500000) = ((23733541 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
