import LeanProject.SupReduction
import Mathlib.Analysis.SpecialFunctions.Integrals.PosLogEqCircleAverage

/-!
# EP-1038: arcsine potentials (proof.md Lemma 6.5), roadmap 15c part 1

* `cos_factor`: `2w(z - cos θ) = (w - e^{iθ})(w - e^{-iθ})` when `2z = w + w⁻¹`.
* `avg_out`: for real `w`, `|w| > 1`: `(2π)⁻¹ ∫₀^{2π} log|s(z - cos θ)| dθ = log(s|w|/2)`,
  via Mathlib's `circleAverage_log_norm_sub_const₂`.
* `avg_in`: for `|z| ≤ 1`: `(2π)⁻¹ ∫₀^{2π} log|s(z - cos θ)| dθ = log(s/2)`, via
  `circleAverage_log_norm_sub_const₁`; the countable set `{cos θ = z}` is handled almost everywhere.
* `U c d x`: the arcsine potential of `[c, d]` as a `θ`-average.
  `U_inside`: `U = log((d - c)/4)` on `[c, d]`; `U_left`: `U = log(((c+d)/2 - x + √((c-x)(d-x)))/2)`
  for `x < c` (Lemma 6.5 (i), (ii)).

The arcsine branch is completed in `GeneralWitness.lean` (Lemma 6.3 for a general measure),
`Witness66.lean`/`W66Values.lean` (Lemma 6.6′, which replaces Lemma 6.6) and `Supremum.lean`.
-/
open Real Complex MeasureTheory

namespace EP1038.Arcsine

/-- Algebraic core of Lemma 6.5: if `2z = w + w⁻¹` then
`2w (z - cos θ) = (w - e^{iθ})(w - e^{-iθ})`. -/
theorem cos_factor {w z : ℂ} (hw : w ≠ 0) (hz : 2 * z = w + w⁻¹) (θ : ℝ) :
    2 * w * (z - Complex.cos θ) =
      (w - Complex.exp (θ * Complex.I)) * (w - Complex.exp (-(θ * Complex.I))) := by
  have hcos : Complex.cos θ = (Complex.exp (θ * Complex.I) + Complex.exp (-(θ * Complex.I))) / 2 := by
    rw [Complex.cos]; ring_nf
  have hprod : Complex.exp (θ * Complex.I) * Complex.exp (-(θ * Complex.I)) = 1 := by
    rw [← Complex.exp_add, add_neg_cancel, Complex.exp_zero]
  have hz' : 2 * w * z = w * w + 1 := by
    have : 2 * w * z = w * (2 * z) := by ring
    rw [this, hz, mul_add, mul_inv_cancel₀ hw]
  rw [hcos]
  linear_combination hz' - hprod

/-- For real `w` with `|w| > 1` and `2z = w + 1/w`: `|z - cos θ| = ‖w - e^{iθ}‖² / (2|w|)`. -/
theorem abs_sub_cos_eq {w z : ℝ} (hw : 1 < |w|) (hz : 2 * z = w + w⁻¹) (θ : ℝ) :
    |z - Real.cos θ| = ‖(w : ℂ) - Complex.exp (θ * Complex.I)‖ ^ 2 / (2 * |w|) := by
  have hw0 : (w : ℂ) ≠ 0 := by
    rw [Ne, Complex.ofReal_eq_zero]; intro h; rw [h, abs_zero] at hw; linarith
  have hzc : 2 * (z : ℂ) = (w : ℂ) + (w : ℂ)⁻¹ := by exact_mod_cast congrArg (fun x : ℝ => (x : ℂ)) hz
  have hf := cos_factor hw0 hzc θ
  have hconj : ‖(w : ℂ) - Complex.exp (-(θ * Complex.I))‖ = ‖(w : ℂ) - Complex.exp (θ * Complex.I)‖ := by
    have hc : (starRingEnd ℂ) (-((θ : ℂ) * Complex.I)) = (θ : ℂ) * Complex.I := by
      simp [Complex.conj_ofReal]
    rw [← Complex.norm_conj, map_sub, Complex.conj_ofReal, ← Complex.exp_conj, hc]
  have hn := congrArg norm hf
  simp only [norm_mul] at hn
  rw [hconj] at hn
  have h2w : ‖(2 : ℂ)‖ * ‖(w : ℂ)‖ = 2 * |w| := by
    rw [Complex.norm_ofNat, Complex.norm_real, Real.norm_eq_abs]
  have hzcos : ‖(z : ℂ) - Complex.cos θ‖ = |z - Real.cos θ| := by
    rw [← Complex.ofReal_cos, ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
  rw [h2w, hzcos] at hn
  have hpos : (0 : ℝ) < 2 * |w| := by linarith
  rw [eq_div_iff hpos.ne', mul_comm, hn, sq]

theorem norm_sub_exp_pos {w : ℝ} (hw : 1 < |w|) (θ : ℝ) :
    0 < ‖(w : ℂ) - Complex.exp (θ * Complex.I)‖ := by
  have h1 := norm_sub_norm_le (w : ℂ) (Complex.exp (θ * Complex.I))
  rw [Complex.norm_exp_ofReal_mul_I, Complex.norm_real, Real.norm_eq_abs] at h1
  linarith

/-- **Lemma 6.5, outside case**: for real `w` with `|w| > 1` and `2z = w + 1/w`,
`(2π)⁻¹ ∫₀^{2π} log|z - cos θ| dθ = log(|w|/2)`. -/
theorem avg_out {w z s : ℝ} (hs : 0 < s) (hw : 1 < |w|) (hz : 2 * z = w + w⁻¹) :
    (2 * π)⁻¹ * ∫ θ in (0 : ℝ)..2 * π, Real.log |s * (z - Real.cos θ)| =
      Real.log (s * |w| / 2) := by
  set g : ℝ → ℝ := fun θ => Real.log ‖(w : ℂ) - Complex.exp (θ * Complex.I)‖ with hg
  have hwpos : (0 : ℝ) < |w| := by linarith
  have hpt : ∀ θ : ℝ, Real.log |s * (z - Real.cos θ)| =
      2 * g θ - (Real.log (2 * |w|) - Real.log s) := by
    intro θ
    have hp := norm_sub_exp_pos hw θ
    rw [abs_mul, abs_of_pos hs, abs_sub_cos_eq hw hz θ,
      Real.log_mul hs.ne' (by positivity), Real.log_div (by positivity) (by positivity),
      Real.log_pow]
    simp only [hg]
    push_cast
    ring
  have hcirc : ∀ θ : ℝ, Real.log ‖circleMap 0 1 θ - (w : ℂ)‖ = g θ := by
    intro θ
    simp only [hg, circleMap, zero_add, Complex.ofReal_one, one_mul]
    rw [norm_sub_rev]
  have hint : IntervalIntegrable g volume 0 (2 * π) := by
    have h := circleIntegrable_log_norm_sub_const (a := (w : ℂ)) (c := 0) 1
    unfold CircleIntegrable at h
    exact h.congr (fun θ _ => hcirc θ)
  have havg := circleAverage_log_norm_sub_const₂ (a := (w : ℂ))
    (by rw [Complex.norm_real, Real.norm_eq_abs]; exact hw)
  rw [circleAverage_def, smul_eq_mul, Complex.norm_real, Real.norm_eq_abs] at havg
  have hg_int : ∫ θ in (0 : ℝ)..2 * π, g θ = 2 * π * Real.log |w| := by
    have e : (∫ θ in (0 : ℝ)..2 * π, Real.log ‖circleMap 0 1 θ - (w : ℂ)‖) =
        ∫ θ in (0 : ℝ)..2 * π, g θ :=
      intervalIntegral.integral_congr (fun θ _ => hcirc θ)
    rw [e] at havg
    have hπ : (0 : ℝ) < 2 * π := by positivity
    field_simp at havg
    linarith
  rw [intervalIntegral.integral_congr (fun θ _ => hpt θ), intervalIntegral.integral_sub
    (hint.const_mul 2) intervalIntegrable_const, intervalIntegral.integral_const_mul,
    intervalIntegral.integral_const, hg_int, smul_eq_mul,
    Real.log_div (by positivity : s * |w| ≠ 0) (by norm_num), Real.log_mul hs.ne' hwpos.ne',
    Real.log_mul (by norm_num) hwpos.ne']
  have hπ : (0 : ℝ) < π := Real.pi_pos
  field_simp
  ring

/-- The set `{θ : cos θ = cos ψ}` is countable. -/
theorem countable_cos_eq (ψ : ℝ) : {θ : ℝ | Real.cos θ = Real.cos ψ}.Countable := by
  have hsub : {θ : ℝ | Real.cos θ = Real.cos ψ} ⊆
      ⋃ k : ℤ, ({ψ - 2 * k * π, 2 * k * π - ψ} : Set ℝ) := by
    intro θ hθ
    rw [Set.mem_ofPred_eq, Real.cos_eq_cos_iff] at hθ
    obtain ⟨k, hk | hk⟩ := hθ
    · refine Set.mem_iUnion.mpr ⟨k, ?_⟩
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
      left; linarith
    · refine Set.mem_iUnion.mpr ⟨k, ?_⟩
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
      right; linarith
  exact (Set.countable_iUnion fun k => (Set.toFinite _).countable).mono hsub

/-- **Lemma 6.5, inside case**: for `|z| ≤ 1`, `(2π)⁻¹ ∫₀^{2π} log|z - cos θ| dθ = -log 2`. -/
theorem avg_in {z s : ℝ} (hs : 0 < s) (hz : |z| ≤ 1) :
    (2 * π)⁻¹ * ∫ θ in (0 : ℝ)..2 * π, Real.log |s * (z - Real.cos θ)| = Real.log (s / 2) := by
  obtain ⟨hz1, hz2⟩ := abs_le.mp hz
  set ψ := Real.arccos z with hψ
  have hcψ : Real.cos ψ = z := Real.cos_arccos hz1 hz2
  set a : ℂ := Complex.exp (ψ * Complex.I) with ha
  set b : ℂ := Complex.exp ((-ψ : ℝ) * Complex.I) with hb
  have ha1 : ‖a‖ = 1 := Complex.norm_exp_ofReal_mul_I ψ
  have hb1 : ‖b‖ = 1 := Complex.norm_exp_ofReal_mul_I (-ψ)
  have ha0 : a ≠ 0 := Complex.exp_ne_zero _
  have hainv : a⁻¹ = b := by
    rw [ha, hb, ← Complex.exp_neg]; congr 1; push_cast; ring
  have hza : 2 * (z : ℂ) = a + a⁻¹ := by
    rw [hainv, ← hcψ, Complex.ofReal_cos, Complex.cos, ha, hb]; push_cast; ring_nf
  -- pointwise identity off the countable set {cos θ = z}
  have hpt : ∀ θ : ℝ, Real.cos θ ≠ z →
      Real.log |s * (z - Real.cos θ)| = Real.log ‖circleMap 0 1 θ - a‖ +
        Real.log ‖circleMap 0 1 θ - b‖ - (Real.log 2 - Real.log s) := by
    intro θ hθ
    have hf := cos_factor ha0 hza θ
    have hn := congrArg norm hf
    simp only [norm_mul] at hn
    have hca : (starRingEnd ℂ) a = b := by
      rw [ha, hb, ← Complex.exp_conj]; congr 1
      rw [map_mul, Complex.conj_ofReal, Complex.conj_I]; push_cast; ring
    have hce : (starRingEnd ℂ) (Complex.exp (-(θ * Complex.I))) = Complex.exp (θ * Complex.I) := by
      rw [← Complex.exp_conj]; congr 1
      rw [map_neg, map_mul, Complex.conj_ofReal, Complex.conj_I]; ring
    have hconj : ‖a - Complex.exp (-(θ * Complex.I))‖ = ‖b - Complex.exp (θ * Complex.I)‖ := by
      rw [← Complex.norm_conj, map_sub, hca, hce]
    rw [hconj, ha1, Complex.norm_ofNat] at hn
    have hzcos : ‖(z : ℂ) - Complex.cos θ‖ = |z - Real.cos θ| := by
      rw [← Complex.ofReal_cos, ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
    rw [hzcos] at hn
    have hpos : 0 < |z - Real.cos θ| := abs_pos.mpr (sub_ne_zero.mpr (Ne.symm hθ))
    have hcm : ∀ c : ℂ, ‖circleMap 0 1 θ - c‖ = ‖c - Complex.exp (θ * Complex.I)‖ := by
      intro c; simp only [circleMap, zero_add, Complex.ofReal_one, one_mul]; rw [norm_sub_rev]
    rw [hcm a, hcm b]
    have hA : 0 < ‖a - Complex.exp (θ * Complex.I)‖ := by
      rcases (norm_nonneg (a - Complex.exp (θ * Complex.I))).lt_or_eq with h | h
      · exact h
      · rw [← h, zero_mul] at hn; linarith
    have hB : 0 < ‖b - Complex.exp (θ * Complex.I)‖ := by
      rcases (norm_nonneg (b - Complex.exp (θ * Complex.I))).lt_or_eq with h | h
      · exact h
      · rw [← h, mul_zero] at hn; linarith
    have : |z - Real.cos θ| = ‖a - Complex.exp (θ * Complex.I)‖ *
        ‖b - Complex.exp (θ * Complex.I)‖ / 2 := by linarith
    rw [abs_mul, abs_of_pos hs, Real.log_mul hs.ne' hpos.ne', this,
      Real.log_div (by positivity) (by norm_num), Real.log_mul hA.ne' hB.ne']
    ring
  have hae : ∀ᵐ θ ∂(volume : Measure ℝ), θ ∈ Set.uIoc (0 : ℝ) (2 * π) →
      Real.log |s * (z - Real.cos θ)| = Real.log ‖circleMap 0 1 θ - a‖ +
        Real.log ‖circleMap 0 1 θ - b‖ - (Real.log 2 - Real.log s) := by
    have hnull : volume {θ : ℝ | Real.cos θ = Real.cos ψ} = 0 :=
      (countable_cos_eq ψ).measure_zero volume
    filter_upwards [measure_eq_zero_iff_ae_notMem.mp hnull] with θ hθ _
    apply hpt
    intro h; exact hθ (by rw [h, hcψ])
  have hIa : IntervalIntegrable (fun θ => Real.log ‖circleMap 0 1 θ - a‖) volume 0 (2 * π) :=
    circleIntegrable_log_norm_sub_const (a := a) (c := 0) 1
  have hIb : IntervalIntegrable (fun θ => Real.log ‖circleMap 0 1 θ - b‖) volume 0 (2 * π) :=
    circleIntegrable_log_norm_sub_const (a := b) (c := 0) 1
  have hca := circleAverage_log_norm_sub_const₁ ha1
  have hcb := circleAverage_log_norm_sub_const₁ hb1
  rw [circleAverage_def, smul_eq_mul] at hca hcb
  have hπ : (0 : ℝ) < 2 * π := by positivity
  have hIa0 : ∫ θ in (0 : ℝ)..2 * π, Real.log ‖circleMap 0 1 θ - a‖ = 0 := by
    rcases mul_eq_zero.mp hca with h | h
    · exact absurd h (inv_ne_zero hπ.ne')
    · exact h
  have hIb0 : ∫ θ in (0 : ℝ)..2 * π, Real.log ‖circleMap 0 1 θ - b‖ = 0 := by
    rcases mul_eq_zero.mp hcb with h | h
    · exact absurd h (inv_ne_zero hπ.ne')
    · exact h
  rw [intervalIntegral.integral_congr_ae hae, intervalIntegral.integral_sub (hIa.add hIb)
    intervalIntegrable_const, intervalIntegral.integral_add hIa hIb, hIa0, hIb0,
    intervalIntegral.integral_const, smul_eq_mul, Real.log_div hs.ne' (by norm_num)]
  field_simp
  ring

/-- The arcsine potential of `[c, d]`, written as a `θ`-average
(the arcsine law of `[c, d]` is the image of the uniform law on `[0, 2π]` under
`θ ↦ (c+d)/2 + (d-c)/2 · cos θ`). -/
noncomputable def U (c d x : ℝ) : ℝ :=
  (2 * π)⁻¹ * ∫ θ in (0 : ℝ)..2 * π, Real.log |x - ((c + d) / 2 + (d - c) / 2 * Real.cos θ)|

theorem U_integrand {c d x : ℝ} (hcd : c < d) (θ : ℝ) :
    x - ((c + d) / 2 + (d - c) / 2 * Real.cos θ) =
      (d - c) / 2 * ((x - (c + d) / 2) / ((d - c) / 2) - Real.cos θ) := by
  have hdc : d - c ≠ 0 := (sub_pos.mpr hcd).ne'
  field_simp
  ring

/-- **Lemma 6.5 (i)**: on `[c, d]` the arcsine potential is constant, `log((d - c)/4)`. -/
theorem U_inside {c d x : ℝ} (hcd : c < d) (hx : x ∈ Set.Icc c d) :
    U c d x = Real.log ((d - c) / 4) := by
  have hh : (0 : ℝ) < (d - c) / 2 := by linarith
  have hz : |(x - (c + d) / 2) / ((d - c) / 2)| ≤ 1 := by
    rw [abs_div, abs_of_pos hh, div_le_one hh, abs_le]
    obtain ⟨h1, h2⟩ := hx
    constructor <;> linarith
  rw [U, intervalIntegral.integral_congr (fun θ _ => by rw [U_integrand hcd θ]), avg_in hh hz]
  congr 1; ring

/-- **Lemma 6.5 (ii)**: to the left of `[c, d]`,
`U = log(((c+d)/2 - x + √((c-x)(d-x)))/2)`. -/
theorem U_left {c d x : ℝ} (hcd : c < d) (hx : x < c) :
    U c d x = Real.log (((c + d) / 2 - x + √((c - x) * (d - x))) / 2) := by
  set h := (d - c) / 2 with hhdef
  set m := (c + d) / 2 with hm
  have hh : (0 : ℝ) < h := by rw [hhdef]; linarith
  set S := √((c - x) * (d - x)) with hS
  have hS0 : 0 ≤ S := Real.sqrt_nonneg _
  have hS2 : S ^ 2 = (c - x) * (d - x) := Real.sq_sqrt (by nlinarith)
  set w := (x - m - S) / h with hw
  have hprod : w * ((x - m + S) / h) = 1 := by
    rw [hw, div_mul_div_comm, div_eq_one_iff_eq (by positivity)]
    rw [hm, hhdef] at *
    nlinarith
  have hwinv : w⁻¹ = (x - m + S) / h := (eq_inv_of_mul_eq_one_right hprod).symm
  have hwneg : w < 0 := by
    rw [hw]; apply div_neg_of_neg_of_pos _ hh; rw [hm]; linarith
  have habs : |w| = (m - x + S) / h := by
    rw [abs_of_neg hwneg, hw]; ring
  have hw1 : 1 < |w| := by
    rw [habs, lt_div_iff₀ hh, one_mul, hm, hhdef]; linarith
  have hz : 2 * ((x - m) / h) = w + w⁻¹ := by
    rw [hwinv, hw]; field_simp; ring
  rw [U, intervalIntegral.integral_congr (fun θ _ => by rw [U_integrand hcd θ]),
    ← hm, ← hhdef, avg_out hh hw1 hz, habs]
  congr 1
  field_simp

end EP1038.Arcsine
