import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk01
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_25 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((9909 : ℝ) / 16309) ((4971 : ℝ) / 8171))
    (hq : RB (qa a) ((258613 : ℝ) / 25000000) ((262813 : ℝ) / 25000000))
    (hd : RB (D0a a) ((195860383 : ℝ) / 100000000) ((97962761 : ℝ) / 50000000))
    : certE k a ((5343101 : ℝ) / 12500000) < 0 ∧ 0 < certE k a ((43178323 : ℝ) / 100000000) ∧ 0 < certE k a ((12809727 : ℝ) / 10000000) ∧ certE k a ((16035473 : ℝ) / 12500000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((107 : ℝ) / 1000000) ((2763 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((5343101 : ℝ) / 12500000)) - (z1)
  have h2 : RB z2 ((10683439 : ℝ) / 25000000) ((10683527 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((5343101 : ℝ) / 12500000) ((5343101 : ℝ) / 12500000) ((5343101 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((7156899 : ℝ) / 12500000))
  have h3 : RB z3 ((37318673 : ℝ) / 50000000) ((37318981 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((7156899 : ℝ) / 12500000) ((7156899 : ℝ) / 12500000) ((7156899 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-29252919 : ℝ) / 100000000) ((-29252093 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_450.1 cov_log_451.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1779663 : ℝ) / 10000000) ((-8886473 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((5343101 : ℝ) / 12500000))
  have h6 : RB z6 ((-42496123 : ℝ) / 50000000) ((-21248061 : ℝ) / 25000000) := rb_log (show RB ((5343101 : ℝ) / 12500000) ((5343101 : ℝ) / 12500000) ((5343101 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_452.1 cov_log_452.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33597807 : ℝ) / 50000000) ((672193 : ℝ) / 1000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16805797 : ℝ) / 25000000) ((67256443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_453.1 cov_log_454.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-60829 : ℝ) / 100000000) ((-243 : ℝ) / 6250000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((107 : ℝ) / 1000000) ((2763 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43178323 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((43167271 : ℝ) / 100000000) ((43167623 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43178323 : ℝ) / 100000000) ((43178323 : ℝ) / 100000000) ((43178323 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56821677 : ℝ) / 100000000))
  have h12 : RB z12 ((75969723 : ℝ) / 100000000) ((9496293 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((56821677 : ℝ) / 100000000) ((56821677 : ℝ) / 100000000) ((56821677 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-27483531 : ℝ) / 100000000) ((-27482713 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_455.1 cov_log_456.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-8360093 : ℝ) / 50000000) ((-16697909 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43178323 : ℝ) / 100000000))
  have h15 : RB z15 ((-83983161 : ℝ) / 100000000) ((-83983159 : ℝ) / 100000000) := rb_log (show RB ((43178323 : ℝ) / 100000000) ((43178323 : ℝ) / 100000000) ((43178323 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_457.1 cov_log_457.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67262973 : ℝ) / 100000000) ((16821313 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16805797 : ℝ) / 25000000) ((67256443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_453.1 cov_log_454.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((653 : ℝ) / 10000000) ((3879 : ℝ) / 6250000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((107 : ℝ) / 1000000) ((2763 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((12809727 : ℝ) / 10000000)) - (z19)
  have h20 : RB z20 ((64043109 : ℝ) / 50000000) ((12808657 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((12809727 : ℝ) / 10000000) ((12809727 : ℝ) / 10000000) ((12809727 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((2809727 : ℝ) / 10000000))
  have h21 : RB z21 ((56983391 : ℝ) / 12500000) ((227934191 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((2809727 : ℝ) / 10000000) ((2809727 : ℝ) / 10000000) ((2809727 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((151703119 : ℝ) / 100000000) ((151703397 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_458.1 cov_log_459.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46085787 : ℝ) / 50000000) ((46145979 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((12809727 : ℝ) / 10000000))
  have h24 : RB z24 ((24761971 : ℝ) / 100000000) ((6190493 : ℝ) / 25000000) := rb_log (show RB ((12809727 : ℝ) / 10000000) ((12809727 : ℝ) / 10000000) ((12809727 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_460.1 cov_log_460.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33704801 : ℝ) / 50000000) ((67529987 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16805797 : ℝ) / 25000000) ((67256443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_453.1 cov_log_454.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((153159 : ℝ) / 100000000) ((306799 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((107 : ℝ) / 1000000) ((2763 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((16035473 : ℝ) / 12500000)) - (z28)
  have h29 : RB z29 ((32068183 : ℝ) / 25000000) ((32068271 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((16035473 : ℝ) / 12500000) ((16035473 : ℝ) / 12500000) ((16035473 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3535473 : ℝ) / 12500000))
  have h30 : RB z30 ((90704081 : ℝ) / 20000000) ((453521651 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((3535473 : ℝ) / 12500000) ((3535473 : ℝ) / 12500000) ((3535473 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((151187007 : ℝ) / 100000000) ((30237457 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_461.1 cov_log_462.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18371599 : ℝ) / 20000000) ((91977971 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((16035473 : ℝ) / 12500000))
  have h33 : RB z33 ((6226867 : ℝ) / 25000000) ((24907469 : ℝ) / 100000000) := rb_log (show RB ((16035473 : ℝ) / 12500000) ((16035473 : ℝ) / 12500000) ((16035473 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_463.1 cov_log_463.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33475263 : ℝ) / 50000000) ((67070503 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16805797 : ℝ) / 25000000) ((67256443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_453.1 cov_log_454.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-305917 : ℝ) / 100000000) ((-30537 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((5343101 : ℝ) / 12500000)) ((-60829 : ℝ) / 100000000) ((-243 : ℝ) / 6250000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43178323 : ℝ) / 100000000)) ((653 : ℝ) / 10000000) ((3879 : ℝ) / 6250000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((12809727 : ℝ) / 10000000)) ((153159 : ℝ) / 100000000) ((306799 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((16035473 : ℝ) / 12500000)) ((-305917 : ℝ) / 100000000) ((-30537 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_25 {k A q d vp vm : ℝ}
    (hk : RB k ((9909 : ℝ) / 6400) ((4971 : ℝ) / 3200))
    (hA : RB A ((9909 : ℝ) / 16309) ((4971 : ℝ) / 8171))
    (hq : RB q ((258613 : ℝ) / 25000000) ((262813 : ℝ) / 25000000))
    (hd : RB d ((195860383 : ℝ) / 100000000) ((97962761 : ℝ) / 50000000))
    (hp : RB vp ((5343101 : ℝ) / 12500000) ((43178323 : ℝ) / 100000000))
    (hm : RB vm ((12809727 : ℝ) / 10000000) ((16035473 : ℝ) / 12500000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((107 : ℝ) / 1000000) ((2763 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((24997237 : ℝ) / 25000000) ((999893 : ℝ) / 1000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((15187787 : ℝ) / 25000000) ((30415299 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((1239 : ℝ) / 5000000) ((101 : ℝ) / 390625) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((390524 : ℝ) / 390625) ((4998761 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56821677 : ℝ) / 100000000) ((7156899 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11361397 : ℝ) / 20000000) ((11448201 : ℝ) / 20000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106132217 : ℝ) / 100000000) ((21416591 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6132217 : ℝ) / 100000000) ((1416591 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((24997237 : ℝ) / 25000000) ((999893 : ℝ) / 1000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((15187787 : ℝ) / 25000000) ((30415299 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((417 : ℝ) / 5000000) ((2157 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24997843 : ℝ) / 25000000) ((4999583 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((2809727 : ℝ) / 10000000) ((3535473 : ℝ) / 12500000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((5618969 : ℝ) / 20000000) ((14140713 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((26851169 : ℝ) / 12500000) ((108259359 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((39351169 : ℝ) / 12500000) ((158259359 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((705920057 : ℝ) / 50000000) ((815365797 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((7898427 : ℝ) / 25000000) ((15882629 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((9909 : ℝ) / 3200) ((4971 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((640649 : ℝ) / 20000000) ((3266109 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((25258613 : ℝ) / 25000000) ((25262813 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3169921 : ℝ) / 100000000) ((3232669 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((103169921 : ℝ) / 100000000) ((103232669 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((84918947 : ℝ) / 100000000) ((2673093 : ℝ) / 3125000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((83161287 : ℝ) / 50000000) ((83796343 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13688733 : ℝ) / 25000000) ((55390787 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((19317 : ℝ) / 100000000) ((4037 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19995963 : ℝ) / 20000000) ((99980683 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((166289001 : ℝ) / 100000000) ((167560313 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((195860383 : ℝ) / 50000000) ((97962761 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4052163 : ℝ) / 100000000) ((2059671 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16309 : ℝ) / 6400) ((8171 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((6199 : ℝ) / 390625) ((808259 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1197883 : ℝ) / 50000000) ((307421 : ℝ) / 12500000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51197883 : ℝ) / 50000000) ((12807421 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1445664499 : ℝ) / 100000000) ((334167457 : ℝ) / 20000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((806377 : ℝ) / 100000000) ((820667 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100806377 : ℝ) / 100000000) ((100820667 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3981059 : ℝ) / 12500000) ((6405189 : ℝ) / 20000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1477512971 : ℝ) / 100000000) ((170286323 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((23447303 : ℝ) / 100000000) ((27527091 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16309 : ℝ) / 6400) ((8171 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((103169921 : ℝ) / 50000000) ((103232669 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((721716911 : ℝ) / 50000000) ((415624213 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2978379067 : ℝ) / 100000000) ((686495949 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((928003 : ℝ) / 12500000) ((4286623 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-2600449 : ℝ) / 1000000) ((-30706547 : ℝ) / 12500000) := rb_log h47 (by norm_num) cov_log_464.1 cov_log_465.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2026081 : ℝ) / 100000000) ((2059671 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-194953343 : ℝ) / 50000000) ((-48532799 : ℝ) / 12500000) := rb_log h49 (by norm_num) cov_log_466.1 cov_log_467.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16805797 : ℝ) / 25000000) ((67256443 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_453.1 cov_log_454.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((104080401 : ℝ) / 100000000) ((104478681 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-57165257 : ℝ) / 20000000) ((-283783711 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((7941367 : ℝ) / 50000000) ((17154047 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((11539711 : ℝ) / 20000000) ((73160001 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-22812773 : ℝ) / 10000000) ((-21062371 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((103169921 : ℝ) / 100000000) ((103232669 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-2600449 : ℝ) / 1000000) ((-30706547 : ℝ) / 12500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-22812773 : ℝ) / 10000000) ((-21062371 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((61 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1197883 : ℝ) / 50000000) ((307421 : ℝ) / 12500000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((161 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((12807421 : ℝ) / 25000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((61 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((161 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-28893459 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((61 : ℝ) / 20) + hfun ((161 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_7, cov_h_3]
  have hP : ((640954449 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((21062371 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((21062371 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((62063957 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((161 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((157 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2767 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2767 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2807 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2807 : ℝ) / 1000)) (lo := ((2767 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2847 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2847 : ℝ) / 1000)) (lo := ((2807 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2887 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2887 : ℝ) / 1000)) (lo := ((2847 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2927 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2927 : ℝ) / 1000)) (lo := ((2887 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2967 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2967 : ℝ) / 1000)) (lo := ((2927 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3007 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3007 : ℝ) / 1000)) (lo := ((2967 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3047 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3047 : ℝ) / 1000)) (lo := ((3007 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((61 : ℝ) / 20)) (lo := ((3047 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_25 {k : ℝ} (hk : RB k ((9909 : ℝ) / 6400) ((4971 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((9909 : ℝ) / 16309) ((4971 : ℝ) / 8171) ∧
    RB (qa (r1A k)) ((258613 : ℝ) / 25000000) ((262813 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((195860383 : ℝ) / 100000000) ((97962761 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((38707031 : ℝ) / 100000000) ((19417969 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((95882031 : ℝ) / 50000000) ((191892969 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138478901 : ℝ) / 100000000) ((69262719 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279900257 : ℝ) / 100000000) ((55989359 : ℝ) / 20000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((8746883 : ℝ) / 6250000) ((69986699 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((195860383 : ℝ) / 100000000) ((97962761 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((8107031 : ℝ) / 100000000) ((4117969 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2026757 : ℝ) / 100000000) ((411797 : ℝ) / 20000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((258613 : ℝ) / 25000000) ((262813 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((195860383 : ℝ) / 100000000) ((97962761 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((258613 : ℝ) / 25000000) ((262813 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((9909 : ℝ) / 16309) ((4971 : ℝ) / 8171) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_25 {k : ℝ} (hk : RB k ((9909 : ℝ) / 6400) ((4971 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_25 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_25 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((5343101 : ℝ) / 12500000)) (ph := ((43178323 : ℝ) / 100000000)) (ml := ((12809727 : ℝ) / 10000000)) (mh := ((16035473 : ℝ) / 12500000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_25 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_26 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((4971 : ℝ) / 8171) ((399 : ℝ) / 655))
    (hq : RB (qa a) ((841 : ℝ) / 80000) ((1068061 : ℝ) / 100000000))
    (hd : RB (D0a a) ((195795241 : ℝ) / 100000000) ((195860389 : ℝ) / 100000000))
    : certE k a ((5335223 : ℝ) / 12500000) < 0 ∧ 0 < certE k a ((1724349 : ℝ) / 4000000) ∧ 0 < certE k a ((128159619 : ℝ) / 100000000) ∧ certE k a ((128345599 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((11051 : ℝ) / 100000000) ((713 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((5335223 : ℝ) / 12500000)) - (z1)
  have h2 : RB z2 ((5333797 : ℝ) / 12500000) ((42670733 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((5335223 : ℝ) / 12500000) ((5335223 : ℝ) / 12500000) ((5335223 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((7164777 : ℝ) / 12500000))
  have h3 : RB z3 ((74444703 : ℝ) / 100000000) ((74445327 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((7164777 : ℝ) / 12500000) ((7164777 : ℝ) / 12500000) ((7164777 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-14755679 : ℝ) / 50000000) ((-29510519 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_468.1 cov_log_469.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-4494287 : ℝ) / 25000000) ((-3590669 : ℝ) / 20000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((5335223 : ℝ) / 12500000))
  have h6 : RB z6 ((-42569899 : ℝ) / 50000000) ((-21284949 : ℝ) / 25000000) := rb_log (show RB ((5335223 : ℝ) / 12500000) ((5335223 : ℝ) / 12500000) ((5335223 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_470.1 cov_log_470.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((8395331 : ℝ) / 12500000) ((67186453 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67189923 : ℝ) / 100000000) ((67223193 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_471.1 cov_log_472.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-12109 : ℝ) / 20000000) ((-347 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((11051 : ℝ) / 100000000) ((713 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((1724349 : ℝ) / 4000000)) - (z10)
  have h11 : RB z11 ((43097317 : ℝ) / 100000000) ((21548837 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1724349 : ℝ) / 4000000) ((1724349 : ℝ) / 4000000) ((1724349 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((2275651 : ℝ) / 4000000))
  have h12 : RB z12 ((3030153 : ℝ) / 4000000) ((75754453 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((2275651 : ℝ) / 4000000) ((2275651 : ℝ) / 4000000) ((2275651 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-44429 : ℝ) / 160000) ((-5553459 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_473.1 cov_log_474.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-422881 : ℝ) / 2500000) ((-8446409 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((1724349 : ℝ) / 4000000))
  have h15 : RB z15 ((-84144479 : ℝ) / 100000000) ((-84144477 : ℝ) / 100000000) := rb_log (show RB ((1724349 : ℝ) / 4000000) ((1724349 : ℝ) / 4000000) ((1724349 : ℝ) / 4000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_475.1 cov_log_475.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67229237 : ℝ) / 100000000) ((67251661 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67189923 : ℝ) / 100000000) ((67223193 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_471.1 cov_log_472.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1511 : ℝ) / 25000000) ((30869 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((11051 : ℝ) / 100000000) ((713 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((128159619 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((128148211 : ℝ) / 100000000) ((16018571 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((128159619 : ℝ) / 100000000) ((128159619 : ℝ) / 100000000) ((128159619 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((28159619 : ℝ) / 100000000))
  have h21 : RB z21 ((455077929 : ℝ) / 100000000) ((455079197 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((28159619 : ℝ) / 100000000) ((28159619 : ℝ) / 100000000) ((28159619 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((18941231 : ℝ) / 12500000) ((15153013 : ℝ) / 10000000) := rb_log h21 (by norm_num) cov_log_476.1 cov_log_477.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((737491 : ℝ) / 800000) ((92306141 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((128159619 : ℝ) / 100000000))
  have h24 : RB z24 ((3101329 : ℝ) / 12500000) ((24810633 : ℝ) / 100000000) := rb_log (show RB ((128159619 : ℝ) / 100000000) ((128159619 : ℝ) / 100000000) ((128159619 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_478.1 cov_log_478.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33687871 : ℝ) / 50000000) ((67495509 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67189923 : ℝ) / 100000000) ((67223193 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_471.1 cov_log_472.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((152549 : ℝ) / 100000000) ((152793 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((11051 : ℝ) / 100000000) ((713 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((128345599 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((128334191 : ℝ) / 100000000) ((32083637 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((128345599 : ℝ) / 100000000) ((128345599 : ℝ) / 100000000) ((128345599 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((28345599 : ℝ) / 100000000))
  have h30 : RB z30 ((226374103 : ℝ) / 50000000) ((226374733 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((28345599 : ℝ) / 100000000) ((28345599 : ℝ) / 100000000) ((28345599 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((75508297 : ℝ) / 50000000) ((37754219 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_479.1 cov_log_480.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((45937063 : ℝ) / 50000000) ((91993487 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((128345599 : ℝ) / 100000000))
  have h33 : RB z33 ((24955643 : ℝ) / 100000000) ((6238911 : ℝ) / 25000000) := rb_log (show RB ((128345599 : ℝ) / 100000000) ((128345599 : ℝ) / 100000000) ((128345599 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_481.1 cov_log_481.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33459241 : ℝ) / 50000000) ((16759461 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67189923 : ℝ) / 100000000) ((67223193 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_471.1 cov_log_472.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-304711 : ℝ) / 100000000) ((-152079 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((5335223 : ℝ) / 12500000)) ((-12109 : ℝ) / 20000000) ((-347 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((1724349 : ℝ) / 4000000)) ((1511 : ℝ) / 25000000) ((30869 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((128159619 : ℝ) / 100000000)) ((152549 : ℝ) / 100000000) ((152793 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((128345599 : ℝ) / 100000000)) ((-304711 : ℝ) / 100000000) ((-152079 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_26 {k A q d vp vm : ℝ}
    (hk : RB k ((4971 : ℝ) / 3200) ((399 : ℝ) / 256))
    (hA : RB A ((4971 : ℝ) / 8171) ((399 : ℝ) / 655))
    (hq : RB q ((841 : ℝ) / 80000) ((1068061 : ℝ) / 100000000))
    (hd : RB d ((195795241 : ℝ) / 100000000) ((195860389 : ℝ) / 100000000))
    (hp : RB vp ((5335223 : ℝ) / 12500000) ((1724349 : ℝ) / 4000000))
    (hm : RB vm ((128159619 : ℝ) / 100000000) ((128345599 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((11051 : ℝ) / 100000000) ((713 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((6249287 : ℝ) / 6250000) ((99988949 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((30415083 : ℝ) / 50000000) ((60909299 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((5127 : ℝ) / 20000000) ((26729 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99973271 : ℝ) / 100000000) ((19994873 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((2275651 : ℝ) / 4000000) ((7164777 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((14219017 : ℝ) / 25000000) ((57303523 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106154321 : ℝ) / 100000000) ((107091263 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6154321 : ℝ) / 100000000) ((7091263 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((6249287 : ℝ) / 6250000) ((99988949 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((30415083 : ℝ) / 50000000) ((60909299 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((861 : ℝ) / 10000000) ((4451 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49995549 : ℝ) / 50000000) ((9999139 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((28159619 : ℝ) / 100000000) ((28345599 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((3519639 : ℝ) / 12500000) ((28343159 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((8584811 : ℝ) / 4000000) ((54079853 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((12584811 : ℝ) / 4000000) ((79079853 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1410186027 : ℝ) / 100000000) ((1624874621 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((15806807 : ℝ) / 50000000) ((7946087 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((4971 : ℝ) / 1600) ((399 : ℝ) / 128) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1633051 : ℝ) / 50000000) ((3329347 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((80841 : ℝ) / 80000) ((101068061 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1615793 : ℝ) / 50000000) ((411839 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((51615793 : ℝ) / 50000000) ((12911839 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((42525447 : ℝ) / 50000000) ((17132763 : ℝ) / 20000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((83262801 : ℝ) / 50000000) ((83890741 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((54700811 : ℝ) / 100000000) ((6916019 : ℝ) / 12500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((19973 : ℝ) / 100000000) ((2607 : ℝ) / 12500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((12497393 : ℝ) / 12500000) ((99980027 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((166490871 : ℝ) / 100000000) ((41936993 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((195795241 : ℝ) / 50000000) ((195860389 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2058297 : ℝ) / 50000000) ((4183817 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8171 : ℝ) / 3200) ((655 : ℝ) / 256) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((50279 : ℝ) / 3125000) ((204813 : ℝ) / 12500000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2438601 : ℝ) / 100000000) ((1251191 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((102438601 : ℝ) / 100000000) ((51251191 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1444574837 : ℝ) / 100000000) ((208191899 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((819077 : ℝ) / 100000000) ((104173 : ℝ) / 12500000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100819077 : ℝ) / 100000000) ((12604173 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31872553 : ℝ) / 100000000) ((16024617 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((147644739 : ℝ) / 10000000) ((848792213 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((950199 : ℝ) / 4000000) ((27814989 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8171 : ℝ) / 3200) ((655 : ℝ) / 256) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((51615793 : ℝ) / 25000000) ((12911839 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1441799641 : ℝ) / 100000000) ((1656658969 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((372098159 : ℝ) / 12500000) ((1711241111 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((932597 : ℝ) / 12500000) ((4297579 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-6488777 : ℝ) / 2500000) ((-61349279 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_482.1 cov_log_483.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2058297 : ℝ) / 100000000) ((2091909 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-388329131 : ℝ) / 100000000) ((-386709313 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_484.1 cov_log_485.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67189923 : ℝ) / 100000000) ((67223193 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_471.1 cov_log_472.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((52187673 : ℝ) / 50000000) ((104773649 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-56790757 : ℝ) / 20000000) ((-17620979 : ℝ) / 6250000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((627803 : ℝ) / 4000000) ((16952177 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1410667 : ℝ) / 2500000) ((71362639 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-45505421 : ℝ) / 20000000) ((-8422921 : ℝ) / 4000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((51615793 : ℝ) / 50000000) ((12911839 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-6488777 : ℝ) / 2500000) ((-61349279 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-45505421 : ℝ) / 20000000) ((-8422921 : ℝ) / 4000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((61 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2438601 : ℝ) / 100000000) ((1251191 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((51251191 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((61 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-230751179 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((61 : ℝ) / 20) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_7, cov_h_6]
  have hP : ((640415317 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((8422921 : ℝ) / 4000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((8422921 : ℝ) / 4000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2769 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2769 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2809 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2809 : ℝ) / 1000)) (lo := ((2769 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2849 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2849 : ℝ) / 1000)) (lo := ((2809 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2889 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2889 : ℝ) / 1000)) (lo := ((2849 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2929 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2929 : ℝ) / 1000)) (lo := ((2889 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2969 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2969 : ℝ) / 1000)) (lo := ((2929 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3009 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3009 : ℝ) / 1000)) (lo := ((2969 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3049 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3049 : ℝ) / 1000)) (lo := ((3009 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((61 : ℝ) / 20)) (lo := ((3049 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_26 {k : ℝ} (hk : RB k ((4971 : ℝ) / 3200) ((399 : ℝ) / 256)) :
    RB (k / (k + 1)) ((4971 : ℝ) / 8171) ((399 : ℝ) / 655) ∧
    RB (qa (r1A k)) ((841 : ℝ) / 80000) ((1068061 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((195795241 : ℝ) / 100000000) ((195860389 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((38835937 : ℝ) / 100000000) ((9741211 : ℝ) / 25000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((47908789 : ℝ) / 25000000) ((191764063 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((2768647 : ℝ) / 2000000) ((138478903 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139926853 : ℝ) / 50000000) ((13995013 : ℝ) / 5000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139926853 : ℝ) / 100000000) ((13995013 : ℝ) / 10000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((195795241 : ℝ) / 100000000) ((195860389 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((8235937 : ℝ) / 100000000) ((2091211 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((257373 : ℝ) / 12500000) ((2091211 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((841 : ℝ) / 80000) ((1068061 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((195795241 : ℝ) / 100000000) ((195860389 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((841 : ℝ) / 80000) ((1068061 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((4971 : ℝ) / 8171) ((399 : ℝ) / 655) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_26 {k : ℝ} (hk : RB k ((4971 : ℝ) / 3200) ((399 : ℝ) / 256)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_26 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_26 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((5335223 : ℝ) / 12500000)) (ph := ((1724349 : ℝ) / 4000000)) (ml := ((128159619 : ℝ) / 100000000)) (mh := ((128345599 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_26 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_27 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((399 : ℝ) / 655) ((1251 : ℝ) / 2051))
    (hq : RB (qa a) ((1068059 : ℝ) / 100000000) ((1084881 : ℝ) / 100000000))
    (hd : RB (D0a a) ((97865043 : ℝ) / 50000000) ((39159049 : ℝ) / 20000000))
    : certE k a ((8523937 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((10760051 : ℝ) / 25000000) ∧ 0 < certE k a ((128221789 : ℝ) / 100000000) ∧ certE k a ((128407239 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((11407 : ℝ) / 100000000) ((1177 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8523937 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((8521583 : ℝ) / 20000000) ((21304139 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((8523937 : ℝ) / 20000000) ((8523937 : ℝ) / 20000000) ((8523937 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11476063 : ℝ) / 20000000))
  have h3 : RB z3 ((37127641 : ℝ) / 50000000) ((18563979 : ℝ) / 25000000) := rb_div_signed h2 (show RB ((11476063 : ℝ) / 20000000) ((11476063 : ℝ) / 20000000) ((11476063 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-1860383 : ℝ) / 6250000) ((-29765273 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_486.1 cov_log_487.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-9077871 : ℝ) / 50000000) ((-9065911 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8523937 : ℝ) / 20000000))
  have h6 : RB z6 ((-21321349 : ℝ) / 25000000) ((-42642697 : ℝ) / 50000000) := rb_log (show RB ((8523937 : ℝ) / 20000000) ((8523937 : ℝ) / 20000000) ((8523937 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_488.1 cov_log_488.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((16782413 : ℝ) / 25000000) ((33576787 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67156641 : ℝ) / 100000000) ((67189927 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_489.1 cov_log_490.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-2411 : ℝ) / 4000000) ((-3067 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((11407 : ℝ) / 100000000) ((1177 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((10760051 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((21514217 : ℝ) / 50000000) ((43028797 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((10760051 : ℝ) / 25000000) ((10760051 : ℝ) / 25000000) ((10760051 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((14239949 : ℝ) / 25000000))
  have h12 : RB z12 ((37770881 : ℝ) / 50000000) ((75542401 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((14239949 : ℝ) / 25000000) ((14239949 : ℝ) / 25000000) ((14239949 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-5609691 : ℝ) / 20000000) ((-3505951 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_491.1 cov_log_492.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-8554027 : ℝ) / 50000000) ((-17085489 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((10760051 : ℝ) / 25000000))
  have h15 : RB z15 ((-42151777 : ℝ) / 50000000) ((-1317243 : ℝ) / 1562500) := rb_log (show RB ((10760051 : ℝ) / 25000000) ((10760051 : ℝ) / 25000000) ((10760051 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_493.1 cov_log_493.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33597749 : ℝ) / 50000000) ((13443613 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67156641 : ℝ) / 100000000) ((67189927 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_489.1 cov_log_490.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((5571 : ℝ) / 100000000) ((3839 : ℝ) / 6250000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((11407 : ℝ) / 100000000) ((1177 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((128221789 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((128210019 : ℝ) / 100000000) ((64105191 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((128221789 : ℝ) / 100000000) ((128221789 : ℝ) / 100000000) ((128221789 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((28221789 : ℝ) / 100000000))
  have h21 : RB z21 ((227147221 : ℝ) / 50000000) ((454295729 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((28221789 : ℝ) / 100000000) ((28221789 : ℝ) / 100000000) ((28221789 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((30271507 : ℝ) / 20000000) ((151357821 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_494.1 cov_log_495.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46100501 : ℝ) / 50000000) ((46160077 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((128221789 : ℝ) / 100000000))
  have h24 : RB z24 ((2485913 : ℝ) / 10000000) ((24859131 : ℝ) / 100000000) := rb_log (show RB ((128221789 : ℝ) / 100000000) ((128221789 : ℝ) / 100000000) ((128221789 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_496.1 cov_log_496.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67341871 : ℝ) / 100000000) ((2108157 : ℝ) / 3125000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67156641 : ℝ) / 100000000) ((67189927 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_489.1 cov_log_490.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((18993 : ℝ) / 12500000) ((304383 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((11407 : ℝ) / 100000000) ((1177 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((128407239 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((128395469 : ℝ) / 100000000) ((16049479 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((128407239 : ℝ) / 100000000) ((128407239 : ℝ) / 100000000) ((128407239 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((28407239 : ℝ) / 100000000))
  have h30 : RB z30 ((225990757 : ℝ) / 50000000) ((451982793 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((28407239 : ℝ) / 100000000) ((28407239 : ℝ) / 100000000) ((28407239 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((150847109 : ℝ) / 100000000) ((30169479 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_497.1 cov_log_498.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((9189007 : ℝ) / 10000000) ((92008821 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((128407239 : ℝ) / 100000000))
  have h33 : RB z33 ((12501829 : ℝ) / 50000000) ((25003659 : ℝ) / 100000000) := rb_log (show RB ((128407239 : ℝ) / 100000000) ((128407239 : ℝ) / 100000000) ((128407239 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_499.1 cov_log_499.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((66886411 : ℝ) / 100000000) ((67005163 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67156641 : ℝ) / 100000000) ((67189927 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_489.1 cov_log_490.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-75879 : ℝ) / 25000000) ((-75739 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8523937 : ℝ) / 20000000)) ((-2411 : ℝ) / 4000000) ((-3067 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((10760051 : ℝ) / 25000000)) ((5571 : ℝ) / 100000000) ((3839 : ℝ) / 6250000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((128221789 : ℝ) / 100000000)) ((18993 : ℝ) / 12500000) ((304383 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((128407239 : ℝ) / 100000000)) ((-75879 : ℝ) / 25000000) ((-75739 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_27 {k A q d vp vm : ℝ}
    (hk : RB k ((399 : ℝ) / 256) ((1251 : ℝ) / 800))
    (hA : RB A ((399 : ℝ) / 655) ((1251 : ℝ) / 2051))
    (hq : RB q ((1068059 : ℝ) / 100000000) ((1084881 : ℝ) / 100000000))
    (hd : RB d ((97865043 : ℝ) / 50000000) ((39159049 : ℝ) / 20000000))
    (hp : RB vp ((8523937 : ℝ) / 20000000) ((10760051 : ℝ) / 25000000))
    (hm : RB vm ((128221789 : ℝ) / 100000000) ((128407239 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((11407 : ℝ) / 100000000) ((1177 : ℝ) / 10000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((9998823 : ℝ) / 10000000) ((99988593 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((3045443 : ℝ) / 5000000) ((381173 : ℝ) / 625000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((26503 : ℝ) / 100000000) ((27617 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99972383 : ℝ) / 100000000) ((99973497 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((14239949 : ℝ) / 25000000) ((11476063 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11388813 : ℝ) / 20000000) ((14341277 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106177539 : ℝ) / 100000000) ((10710103 : ℝ) / 10000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6177539 : ℝ) / 100000000) ((710103 : ℝ) / 10000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((9998823 : ℝ) / 10000000) ((99988593 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((3045443 : ℝ) / 5000000) ((381173 : ℝ) / 625000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((8883 : ℝ) / 100000000) ((459 : ℝ) / 5000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((4999541 : ℝ) / 5000000) ((99991117 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((28221789 : ℝ) / 100000000) ((28407239 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((14109599 : ℝ) / 50000000) ((7101179 : ℝ) / 25000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((214432209 : ℝ) / 100000000) ((108060619 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((314432209 : ℝ) / 100000000) ((158060619 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1408246409 : ℝ) / 100000000) ((404691901 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((3954179 : ℝ) / 12500000) ((15901679 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((399 : ℝ) / 128) ((1251 : ℝ) / 400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((166467 : ℝ) / 5000000) ((1696483 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101068059 : ℝ) / 100000000) ((101084881 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((411701 : ℝ) / 12500000) ((3357111 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((12911701 : ℝ) / 12500000) ((103357111 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((17036317 : ℝ) / 20000000) ((42893777 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((166725989 : ℝ) / 100000000) ((10497997 : ℝ) / 6250000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27323861 : ℝ) / 50000000) ((27633369 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((20639 : ℝ) / 100000000) ((10769 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49989231 : ℝ) / 50000000) ((99979361 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((166690079 : ℝ) / 100000000) ((83966643 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((97865043 : ℝ) / 25000000) ((39159049 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((167241 : ℝ) / 4000000) ((4248291 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((655 : ℝ) / 256) ((2051 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1630823 : ℝ) / 100000000) ((1660401 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2481537 : ℝ) / 100000000) ((2545493 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((102481537 : ℝ) / 100000000) ((102545493 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((360798141 : ℝ) / 25000000) ((1659973221 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((415887 : ℝ) / 50000000) ((423049 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50415887 : ℝ) / 50000000) ((50423049 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((637931 : ℝ) / 2000000) ((16036223 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((737544557 : ℝ) / 50000000) ((1692045667 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((6014023 : ℝ) / 25000000) ((3511843 : ℝ) / 12500000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((655 : ℝ) / 256) ((2051 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((12911701 : ℝ) / 6250000) ((103357111 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1439879841 : ℝ) / 100000000) ((825285481 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2974607677 : ℝ) / 100000000) ((3411964923 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((3749443 : ℝ) / 50000000) ((269337 : ℝ) / 3125000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-10361663 : ℝ) / 4000000) ((-245122617 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_500.1 cov_log_501.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((130657 : ℝ) / 6250000) ((1062073 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-386776123 : ℝ) / 100000000) ((-192590017 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_502.1 cov_log_503.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67156641 : ℝ) / 100000000) ((67189927 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_489.1 cov_log_490.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((654187 : ℝ) / 625000) ((105068249 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-282106203 : ℝ) / 100000000) ((-56022357 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((15509761 : ℝ) / 100000000) ((16752969 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((13801301 : ℝ) / 25000000) ((2785651 : ℝ) / 4000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-226900999 : ℝ) / 100000000) ((-21047051 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((12911701 : ℝ) / 12500000) ((103357111 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-10361663 : ℝ) / 4000000) ((-245122617 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-226900999 : ℝ) / 100000000) ((-21047051 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((61 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2481537 : ℝ) / 100000000) ((2545493 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((102545493 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((61 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-115120837 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((61 : ℝ) / 20) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_7, cov_h_6]
  have hP : ((319858547 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((21047051 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((21047051 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((693 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((693 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((703 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((703 : ℝ) / 250)) (lo := ((693 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((713 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((713 : ℝ) / 250)) (lo := ((703 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((723 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((723 : ℝ) / 250)) (lo := ((713 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((733 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((733 : ℝ) / 250)) (lo := ((723 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((743 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((743 : ℝ) / 250)) (lo := ((733 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((753 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((753 : ℝ) / 250)) (lo := ((743 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((61 : ℝ) / 20)) (lo := ((753 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_27 {k : ℝ} (hk : RB k ((399 : ℝ) / 256) ((1251 : ℝ) / 800)) :
    RB (k / (k + 1)) ((399 : ℝ) / 655) ((1251 : ℝ) / 2051) ∧
    RB (qa (r1A k)) ((1068059 : ℝ) / 100000000) ((1084881 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((97865043 : ℝ) / 50000000) ((39159049 : ℝ) / 20000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((38964843 : ℝ) / 100000000) ((1251 : ℝ) / 3200) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((30641 : ℝ) / 16000) ((191635157 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138385783 : ℝ) / 100000000) ((138432351 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279807139 : ℝ) / 100000000) ((69963427 : ℝ) / 25000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139903569 : ℝ) / 100000000) ((69963427 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((97865043 : ℝ) / 50000000) ((39159049 : ℝ) / 20000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((8364843 : ℝ) / 100000000) ((1359 : ℝ) / 16000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((209121 : ℝ) / 10000000) ((1061719 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1068059 : ℝ) / 100000000) ((1084881 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((97865043 : ℝ) / 50000000) ((39159049 : ℝ) / 20000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1068059 : ℝ) / 100000000) ((1084881 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((399 : ℝ) / 655) ((1251 : ℝ) / 2051) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_27 {k : ℝ} (hk : RB k ((399 : ℝ) / 256) ((1251 : ℝ) / 800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_27 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_27 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((8523937 : ℝ) / 20000000)) (ph := ((10760051 : ℝ) / 25000000)) (ml := ((128221789 : ℝ) / 100000000)) (mh := ((128407239 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_27 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_28 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1251 : ℝ) / 2051) ((10041 : ℝ) / 16441))
    (hq : RB (qa a) ((13561 : ℝ) / 1250000) ((1101713 : ℝ) / 100000000))
    (hd : RB (D0a a) ((195664921 : ℝ) / 100000000) ((48932523 : ℝ) / 25000000))
    : certE k a ((42558489 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((42972737 : ℝ) / 100000000) ∧ 0 < certE k a ((128283781 : ℝ) / 100000000) ∧ certE k a ((25693741 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((11769 : ℝ) / 100000000) ((6069 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42558489 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((42546351 : ℝ) / 100000000) ((265917 : ℝ) / 625000) := rb_widen (rb_sub (show RB ((42558489 : ℝ) / 100000000) ((42558489 : ℝ) / 100000000) ((42558489 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57441511 : ℝ) / 100000000))
  have h3 : RB z3 ((18517249 : ℝ) / 25000000) ((1851741 : ℝ) / 2500000) := rb_div_signed h2 (show RB ((57441511 : ℝ) / 100000000) ((57441511 : ℝ) / 100000000) ((57441511 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-6003463 : ℝ) / 20000000) ((-6003289 : ℝ) / 20000000) := rb_log h3 (by norm_num) cov_log_504.1 cov_log_505.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-9166227 : ℝ) / 50000000) ((-18308421 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42558489 : ℝ) / 100000000))
  have h6 : RB z6 ((-42714543 : ℝ) / 50000000) ((-21357271 : ℝ) / 25000000) := rb_log (show RB ((42558489 : ℝ) / 100000000) ((42558489 : ℝ) / 100000000) ((42558489 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_506.1 cov_log_506.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((6709663 : ℝ) / 10000000) ((13424133 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33561671 : ℝ) / 50000000) ((33578323 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_507.1 cov_log_508.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-3751 : ℝ) / 6250000) ((-2677 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((11769 : ℝ) / 100000000) ((6069 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42972737 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((42960599 : ℝ) / 100000000) ((5370121 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((42972737 : ℝ) / 100000000) ((42972737 : ℝ) / 100000000) ((42972737 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57027263 : ℝ) / 100000000))
  have h12 : RB z12 ((235417 : ℝ) / 312500) ((9416761 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((57027263 : ℝ) / 100000000) ((57027263 : ℝ) / 100000000) ((57027263 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-14162303 : ℝ) / 50000000) ((-5664749 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_509.1 cov_log_510.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-17298667 : ℝ) / 100000000) ((-3455193 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42972737 : ℝ) / 100000000))
  have h15 : RB z15 ((-84460431 : ℝ) / 100000000) ((-84460429 : ℝ) / 100000000) := rb_log (show RB ((42972737 : ℝ) / 100000000) ((42972737 : ℝ) / 100000000) ((42972737 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_511.1 cov_log_511.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33580881 : ℝ) / 50000000) ((33592233 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33561671 : ℝ) / 50000000) ((33578323 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_507.1 cov_log_508.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1279 : ℝ) / 25000000) ((15281 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((11769 : ℝ) / 100000000) ((6069 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((128283781 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((128271643 : ℝ) / 100000000) ((32068003 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((128283781 : ℝ) / 100000000) ((128283781 : ℝ) / 100000000) ((128283781 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((28283781 : ℝ) / 100000000))
  have h21 : RB z21 ((453516603 : ℝ) / 100000000) ((453517909 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((28283781 : ℝ) / 100000000) ((28283781 : ℝ) / 100000000) ((28283781 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((151186169 : ℝ) / 100000000) ((7559323 : ℝ) / 5000000) := rb_log h21 (by norm_num) cov_log_512.1 cov_log_513.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46107727 : ℝ) / 50000000) ((46166999 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((128283781 : ℝ) / 100000000))
  have h24 : RB z24 ((12453733 : ℝ) / 50000000) ((24907467 : ℝ) / 100000000) := rb_log (show RB ((128283781 : ℝ) / 100000000) ((128283781 : ℝ) / 100000000) ((128283781 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_514.1 cov_log_514.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67307987 : ℝ) / 100000000) ((16856633 : ℝ) / 25000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33561671 : ℝ) / 50000000) ((33578323 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_507.1 cov_log_508.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((151341 : ℝ) / 100000000) ((30319 : ℝ) / 10000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((11769 : ℝ) / 100000000) ((6069 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((25693741 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((128456567 : ℝ) / 100000000) ((16057117 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((25693741 : ℝ) / 20000000) ((25693741 : ℝ) / 20000000) ((25693741 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((5693741 : ℝ) / 20000000))
  have h30 : RB z30 ((112805067 : ℝ) / 25000000) ((90244313 : ℝ) / 20000000) := rb_div_signed h29 (show RB ((5693741 : ℝ) / 20000000) ((5693741 : ℝ) / 20000000) ((5693741 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((150678543 : ℝ) / 100000000) ((150678833 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_515.1 cov_log_516.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91905829 : ℝ) / 100000000) ((3680959 : ℝ) / 4000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((25693741 : ℝ) / 20000000))
  have h33 : RB z33 ((12525757 : ℝ) / 50000000) ((5010303 : ℝ) / 20000000) := rb_log (show RB ((25693741 : ℝ) / 20000000) ((25693741 : ℝ) / 20000000) ((25693741 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_517.1 cov_log_517.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33427157 : ℝ) / 50000000) ((66972461 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33561671 : ℝ) / 50000000) ((33578323 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_507.1 cov_log_508.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-75583 : ℝ) / 25000000) ((-150881 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42558489 : ℝ) / 100000000)) ((-3751 : ℝ) / 6250000) ((-2677 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42972737 : ℝ) / 100000000)) ((1279 : ℝ) / 25000000) ((15281 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((128283781 : ℝ) / 100000000)) ((151341 : ℝ) / 100000000) ((30319 : ℝ) / 10000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((25693741 : ℝ) / 20000000)) ((-75583 : ℝ) / 25000000) ((-150881 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_28 {k A q d vp vm : ℝ}
    (hk : RB k ((1251 : ℝ) / 800) ((10041 : ℝ) / 6400))
    (hA : RB A ((1251 : ℝ) / 2051) ((10041 : ℝ) / 16441))
    (hq : RB q ((13561 : ℝ) / 1250000) ((1101713 : ℝ) / 100000000))
    (hd : RB d ((195664921 : ℝ) / 100000000) ((48932523 : ℝ) / 25000000))
    (hp : RB vp ((42558489 : ℝ) / 100000000) ((42972737 : ℝ) / 100000000))
    (hm : RB vm ((128283781 : ℝ) / 100000000) ((25693741 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((11769 : ℝ) / 100000000) ((6069 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49993931 : ℝ) / 50000000) ((99988231 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((60987233 : ℝ) / 100000000) ((3053287 : ℝ) / 5000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((27387 : ℝ) / 100000000) ((28521 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99971479 : ℝ) / 100000000) ((99972613 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57027263 : ℝ) / 100000000) ((57441511 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((28505499 : ℝ) / 50000000) ((2871289 : ℝ) / 5000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((26550459 : ℝ) / 25000000) ((107112211 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1550459 : ℝ) / 25000000) ((7112211 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49993931 : ℝ) / 50000000) ((99988231 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((60987233 : ℝ) / 100000000) ((3053287 : ℝ) / 5000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((229 : ℝ) / 2500000) ((4731 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49995269 : ℝ) / 50000000) ((2499771 : ℝ) / 2500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((28283781 : ℝ) / 100000000) ((5693741 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1767569 : ℝ) / 6250000) ((14233049 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((42849029 : ℝ) / 20000000) ((107962087 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((62849029 : ℝ) / 20000000) ((157962087 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((703016263 : ℝ) / 50000000) ((80621287 : ℝ) / 5000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((7913291 : ℝ) / 25000000) ((3182229 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1251 : ℝ) / 400) ((10041 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1696481 : ℝ) / 50000000) ((3456969 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((1263561 : ℝ) / 1250000) ((101101713 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((838997 : ℝ) / 25000000) ((854967 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((25838997 : ℝ) / 25000000) ((25854967 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((21327761 : ℝ) / 25000000) ((10738777 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((83461893 : ℝ) / 50000000) ((33630429 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27297819 : ℝ) / 50000000) ((55206519 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((10659 : ℝ) / 50000000) ((22233 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99977767 : ℝ) / 100000000) ((49989341 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((166886673 : ℝ) / 100000000) ((168116299 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((195664921 : ℝ) / 50000000) ((48932523 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4245459 : ℝ) / 100000000) ((67387 : ℝ) / 1562500) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((2051 : ℝ) / 800) ((16441 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((206579 : ℝ) / 12500000) ((1682211 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2524577 : ℝ) / 100000000) ((80897 : ℝ) / 3125000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((102524577 : ℝ) / 100000000) ((3205897 : ℝ) / 3125000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1441528899 : ℝ) / 100000000) ((165416667 : ℝ) / 10000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((84447 : ℝ) / 10000000) ((85881 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((10084447 : ℝ) / 10000000) ((10085881 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((6384093 : ℝ) / 20000000) ((1002987 : ℝ) / 3125000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((368362341 : ℝ) / 25000000) ((843131127 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((4870139 : ℝ) / 20000000) ((2836649 : ℝ) / 10000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((2051 : ℝ) / 800) ((16441 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((25838997 : ℝ) / 12500000) ((25854967 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((143768569 : ℝ) / 10000000) ((164424803 : ℝ) / 10000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1485934249 : ℝ) / 50000000) ((680191657 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1884579 : ℝ) / 25000000) ((4322039 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-258517141 : ℝ) / 100000000) ((-61207393 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_518.1 cov_log_519.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2122729 : ℝ) / 100000000) ((67387 : ℝ) / 3125000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-385246771 : ℝ) / 100000000) ((-383673743 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_520.1 cov_log_521.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33561671 : ℝ) / 50000000) ((33578323 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_507.1 cov_log_508.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((52482063 : ℝ) / 50000000) ((52681241 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-56056529 : ℝ) / 20000000) ((-278311261 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3831687 : ℝ) / 25000000) ((132451 : ℝ) / 800000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2161247 : ℝ) / 4000000) ((33995693 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-22625147 : ℝ) / 10000000) ((-1682559 : ℝ) / 800000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((25838997 : ℝ) / 25000000) ((25854967 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-258517141 : ℝ) / 100000000) ((-61207393 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-22625147 : ℝ) / 10000000) ((-1682559 : ℝ) / 800000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((76 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2524577 : ℝ) / 100000000) ((80897 : ℝ) / 3125000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((3205897 : ℝ) / 6250000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((76 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-229446933 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((76 : ℝ) / 25) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_8, cov_h_6]
  have hP : ((638871331 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((1682559 : ℝ) / 800000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((1682559 : ℝ) / 800000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1389 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1389 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1409 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1409 : ℝ) / 500)) (lo := ((1389 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1429 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1429 : ℝ) / 500)) (lo := ((1409 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1449 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1449 : ℝ) / 500)) (lo := ((1429 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1469 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1469 : ℝ) / 500)) (lo := ((1449 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1489 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1489 : ℝ) / 500)) (lo := ((1469 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1509 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1509 : ℝ) / 500)) (lo := ((1489 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((76 : ℝ) / 25)) (lo := ((1509 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_28 {k : ℝ} (hk : RB k ((1251 : ℝ) / 800) ((10041 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((1251 : ℝ) / 2051) ((10041 : ℝ) / 16441) ∧
    RB (qa (r1A k)) ((13561 : ℝ) / 1250000) ((1101713 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((195664921 : ℝ) / 100000000) ((48932523 : ℝ) / 25000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((1251 : ℝ) / 3200) ((39222657 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((191377343 : ℝ) / 100000000) ((30641 : ℝ) / 16000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((43231 : ℝ) / 31250) ((17298223 : ℝ) / 12500000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69940139 : ℝ) / 25000000) ((279807141 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69940139 : ℝ) / 50000000) ((139903571 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((195664921 : ℝ) / 100000000) ((48932523 : ℝ) / 25000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1359 : ℝ) / 16000) ((8622657 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2123437 : ℝ) / 100000000) ((431133 : ℝ) / 20000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((13561 : ℝ) / 1250000) ((1101713 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((195664921 : ℝ) / 100000000) ((48932523 : ℝ) / 25000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((13561 : ℝ) / 1250000) ((1101713 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1251 : ℝ) / 2051) ((10041 : ℝ) / 16441) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_28 {k : ℝ} (hk : RB k ((1251 : ℝ) / 800) ((10041 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_28 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_28 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((42558489 : ℝ) / 100000000)) (ph := ((42972737 : ℝ) / 100000000)) (ml := ((128283781 : ℝ) / 100000000)) (mh := ((25693741 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_28 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_29 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((10041 : ℝ) / 16441) ((5037 : ℝ) / 8237))
    (hq : RB (qa a) ((68857 : ℝ) / 6250000) ((279639 : ℝ) / 25000000))
    (hd : RB (D0a a) ((97799871 : ℝ) / 50000000) ((7826597 : ℝ) / 4000000))
    : certE k a ((21249087 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((429063 : ℝ) / 1000000) ∧ 0 < certE k a ((32086399 : ℝ) / 25000000) ∧ certE k a ((64264999 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((12137 : ℝ) / 100000000) ((391 : ℝ) / 3125000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((21249087 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((21242831 : ℝ) / 50000000) ((42486037 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((21249087 : ℝ) / 50000000) ((21249087 : ℝ) / 50000000) ((21249087 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((28750913 : ℝ) / 50000000))
  have h3 : RB z3 ((73885761 : ℝ) / 100000000) ((36943207 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((28750913 : ℝ) / 50000000) ((28750913 : ℝ) / 50000000) ((28750913 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-15132503 : ℝ) / 50000000) ((-30264121 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_522.1 cov_log_523.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-740293 : ℝ) / 4000000) ((-1155199 : ℝ) / 6250000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((21249087 : ℝ) / 50000000))
  have h6 : RB z6 ((-85570909 : ℝ) / 100000000) ((-85570907 : ℝ) / 100000000) := rb_log (show RB ((21249087 : ℝ) / 50000000) ((21249087 : ℝ) / 50000000) ((21249087 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_524.1 cov_log_524.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33531791 : ℝ) / 50000000) ((2683509 : ℝ) / 4000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((2683601 : ℝ) / 4000000) ((33561673 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_525.1 cov_log_526.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-14941 : ℝ) / 25000000) ((-23 : ℝ) / 1000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((12137 : ℝ) / 100000000) ((391 : ℝ) / 3125000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((429063 : ℝ) / 1000000)) - (z10)
  have h11 : RB z11 ((10723447 : ℝ) / 25000000) ((42894163 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((429063 : ℝ) / 1000000) ((429063 : ℝ) / 1000000) ((429063 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((570937 : ℝ) / 1000000))
  have h12 : RB z12 ((37564379 : ℝ) / 50000000) ((9391177 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((570937 : ℝ) / 1000000) ((570937 : ℝ) / 1000000) ((570937 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-14298339 : ℝ) / 50000000) ((-28595801 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_527.1 cov_log_528.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-2185891 : ℝ) / 12500000) ((-4366073 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((429063 : ℝ) / 1000000))
  have h15 : RB z15 ((-84615153 : ℝ) / 100000000) ((-84615151 : ℝ) / 100000000) := rb_log (show RB ((429063 : ℝ) / 1000000) ((429063 : ℝ) / 1000000) ((429063 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_529.1 cov_log_529.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67128023 : ℝ) / 100000000) ((67150861 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((2683601 : ℝ) / 4000000) ((33561673 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_525.1 cov_log_526.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4677 : ℝ) / 100000000) ((15209 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((12137 : ℝ) / 100000000) ((391 : ℝ) / 3125000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((32086399 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((32083271 : ℝ) / 25000000) ((128333459 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((32086399 : ℝ) / 25000000) ((32086399 : ℝ) / 25000000) ((32086399 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((7086399 : ℝ) / 25000000))
  have h21 : RB z21 ((113186087 : ℝ) / 25000000) ((56593209 : ℝ) / 12500000) := rb_div_signed h20 (show RB ((7086399 : ℝ) / 25000000) ((7086399 : ℝ) / 25000000) ((7086399 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((75507871 : ℝ) / 50000000) ((75508019 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_530.1 cov_log_531.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46114867 : ℝ) / 50000000) ((46173837 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((32086399 : ℝ) / 25000000))
  have h24 : RB z24 ((623891 : ℝ) / 2500000) ((24955641 : ℝ) / 100000000) := rb_log (show RB ((32086399 : ℝ) / 25000000) ((32086399 : ℝ) / 25000000) ((32086399 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_532.1 cov_log_532.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67274093 : ℝ) / 100000000) ((33696017 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((2683601 : ℝ) / 4000000) ((33561673 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_525.1 cov_log_526.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((150747 : ℝ) / 100000000) ((302009 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((12137 : ℝ) / 100000000) ((391 : ℝ) / 3125000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((64264999 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((64258743 : ℝ) / 50000000) ((128517861 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((64264999 : ℝ) / 50000000) ((64264999 : ℝ) / 50000000) ((64264999 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((14264999 : ℝ) / 50000000))
  have h30 : RB z30 ((90092881 : ℝ) / 20000000) ((450465721 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((14264999 : ℝ) / 50000000) ((14264999 : ℝ) / 50000000) ((14264999 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((150510887 : ℝ) / 100000000) ((75255591 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_533.1 cov_log_534.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((22980351 : ℝ) / 25000000) ((1840779 : ℝ) / 2000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((64264999 : ℝ) / 50000000))
  have h33 : RB z33 ((25099213 : ℝ) / 100000000) ((12549607 : ℝ) / 50000000) := rb_log (show RB ((64264999 : ℝ) / 50000000) ((64264999 : ℝ) / 50000000) ((64264999 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_535.1 cov_log_535.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6682219 : ℝ) / 10000000) ((66939737 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((2683601 : ℝ) / 4000000) ((33561673 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_525.1 cov_log_526.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-75289 : ℝ) / 25000000) ((-9393 : ℝ) / 6250000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((21249087 : ℝ) / 50000000)) ((-14941 : ℝ) / 25000000) ((-23 : ℝ) / 1000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((429063 : ℝ) / 1000000)) ((4677 : ℝ) / 100000000) ((15209 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((32086399 : ℝ) / 25000000)) ((150747 : ℝ) / 100000000) ((302009 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((64264999 : ℝ) / 50000000)) ((-75289 : ℝ) / 25000000) ((-9393 : ℝ) / 6250000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_29 {k A q d vp vm : ℝ}
    (hk : RB k ((10041 : ℝ) / 6400) ((5037 : ℝ) / 3200))
    (hA : RB A ((10041 : ℝ) / 16441) ((5037 : ℝ) / 8237))
    (hq : RB q ((68857 : ℝ) / 6250000) ((279639 : ℝ) / 25000000))
    (hd : RB d ((97799871 : ℝ) / 50000000) ((7826597 : ℝ) / 4000000))
    (hp : RB vp ((21249087 : ℝ) / 50000000) ((429063 : ℝ) / 1000000))
    (hm : RB vm ((32086399 : ℝ) / 25000000) ((64264999 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((12137 : ℝ) / 100000000) ((391 : ℝ) / 3125000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((3124609 : ℝ) / 3125000) ((99987863 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((12213057 : ℝ) / 20000000) ((61143483 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((28287 : ℝ) / 100000000) ((14721 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49985279 : ℝ) / 50000000) ((99971713 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((570937 : ℝ) / 1000000) ((28750913 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((5707689 : ℝ) / 10000000) ((57485561 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((10622717 : ℝ) / 10000000) ((107124763 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((622717 : ℝ) / 10000000) ((7124763 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((3124609 : ℝ) / 3125000) ((99987863 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((12213057 : ℝ) / 20000000) ((61143483 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((4721 : ℝ) / 50000000) ((9749 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99990251 : ℝ) / 100000000) ((49995279 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((7086399 : ℝ) / 25000000) ((14264999 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1771427 : ℝ) / 6250000) ((5705461 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((107029537 : ℝ) / 50000000) ((107864103 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((157029537 : ℝ) / 50000000) ((157864103 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((701777729 : ℝ) / 50000000) ((1605865907 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31672811 : ℝ) / 100000000) ((3980143 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((10041 : ℝ) / 3200) ((5037 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((691393 : ℝ) / 20000000) ((704271 : ℝ) / 20000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((6318857 : ℝ) / 6250000) ((25279639 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((854681 : ℝ) / 25000000) ((3482983 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((25854681 : ℝ) / 25000000) ((103482983 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((1334989 : ℝ) / 1562500) ((5376989 : ℝ) / 6250000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((83559521 : ℝ) / 50000000) ((21041763 : ℝ) / 12500000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27272267 : ℝ) / 50000000) ((55147467 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((2751 : ℝ) / 12500000) ((1147 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4998853 : ℝ) / 5000000) ((12497249 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((652659 : ℝ) / 390625) ((84148529 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((97799871 : ℝ) / 25000000) ((7826597 : ℝ) / 2000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4309891 : ℝ) / 100000000) ((1094311 : ℝ) / 25000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((16441 : ℝ) / 6400) ((8237 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1674353 : ℝ) / 100000000) ((1703933 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((641929 : ℝ) / 25000000) ((263201 : ℝ) / 10000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25641929 : ℝ) / 25000000) ((10263201 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((179949347 : ℝ) / 12500000) ((1648132459 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((857163 : ℝ) / 100000000) ((871519 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100857163 : ℝ) / 100000000) ((100871519 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((15972149 : ℝ) / 50000000) ((16059323 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((735769537 : ℝ) / 50000000) ((336050221 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((12319379 : ℝ) / 50000000) ((14315177 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((16441 : ℝ) / 6400) ((8237 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((25854681 : ℝ) / 12500000) ((103482983 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1435228269 : ℝ) / 100000000) ((1637707051 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((742147381 : ℝ) / 25000000) ((3389496219 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((378951 : ℝ) / 5000000) ((2167749 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-257978633 : ℝ) / 100000000) ((-61129663 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_536.1 cov_log_537.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((430989 : ℝ) / 20000000) ((1094311 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-47967563 : ℝ) / 12500000) ((-191094903 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_538.1 cov_log_539.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((2683601 : ℝ) / 4000000) ((33561673 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_525.1 cov_log_526.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((105257959 : ℝ) / 100000000) ((52828171 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-55696509 : ℝ) / 20000000) ((-34566683 : ℝ) / 12500000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((15145989 : ℝ) / 100000000) ((2045293 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((52901857 : ℝ) / 100000000) ((13281793 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-14098793 : ℝ) / 6250000) ((-210124499 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((25854681 : ℝ) / 25000000) ((103482983 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-257978633 : ℝ) / 100000000) ((-61129663 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-14098793 : ℝ) / 6250000) ((-210124499 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((76 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((641929 : ℝ) / 25000000) ((263201 : ℝ) / 10000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((81 : ℝ) / 50) := by
    have hu : (1 + q / vp) / 2 ≤ ((10263201 : ℝ) / 20000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((76 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((81 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-9156337 : ℝ) / 4000000) ≤ formC0 k A q vp vm + hfun ((76 : ℝ) / 25) + hfun ((81 : ℝ) / 50) := by
    linarith [hc0.1, cov_h_8, cov_h_6]
  have hP : ((637888563 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((210124499 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((210124499 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((15413383 : ℝ) / 25000000) ≤ EP1038.Arc.sinc ((81 : ℝ) / 50) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((197 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2781 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2781 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2821 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2821 : ℝ) / 1000)) (lo := ((2781 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2861 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2861 : ℝ) / 1000)) (lo := ((2821 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2901 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2901 : ℝ) / 1000)) (lo := ((2861 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2941 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2941 : ℝ) / 1000)) (lo := ((2901 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2981 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2981 : ℝ) / 1000)) (lo := ((2941 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3021 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3021 : ℝ) / 1000)) (lo := ((2981 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((76 : ℝ) / 25)) (lo := ((3021 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_29 {k : ℝ} (hk : RB k ((10041 : ℝ) / 6400) ((5037 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((10041 : ℝ) / 16441) ((5037 : ℝ) / 8237) ∧
    RB (qa (r1A k)) ((68857 : ℝ) / 6250000) ((279639 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((97799871 : ℝ) / 50000000) ((7826597 : ℝ) / 4000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((306427 : ℝ) / 781250) ((39351563 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((191248437 : ℝ) / 100000000) ((2990271 : ℝ) / 1562500) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((138292601 : ℝ) / 100000000) ((138339201 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((279713957 : ℝ) / 100000000) ((139880279 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69928489 : ℝ) / 50000000) ((139880279 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((97799871 : ℝ) / 50000000) ((7826597 : ℝ) / 4000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((134729 : ℝ) / 1562500) ((8751563 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((134729 : ℝ) / 6250000) ((2187891 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((68857 : ℝ) / 6250000) ((279639 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((97799871 : ℝ) / 50000000) ((7826597 : ℝ) / 4000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((68857 : ℝ) / 6250000) ((279639 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((10041 : ℝ) / 16441) ((5037 : ℝ) / 8237) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_29 {k : ℝ} (hk : RB k ((10041 : ℝ) / 6400) ((5037 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_29 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_29 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((21249087 : ℝ) / 50000000)) (ph := ((429063 : ℝ) / 1000000)) (ml := ((32086399 : ℝ) / 25000000)) (mh := ((64264999 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_29 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
