import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog11
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_840 : RB (Real.log ((14380751 : ℝ) / 12800000)) ((29111351329 : ℝ) / 250000000000) ((116445405317 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((14380751 : ℝ) / 12800000)) (t := ((1580751 : ℝ) / 27180751))
    (lo := ((29111351329 : ℝ) / 250000000000)) (hi := ((116445405317 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_841 : RB (Real.log ((123460214843 : ℝ) / 1000000000000)) ((-522959080459 : ℝ) / 250000000000) ((-1045918160917 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((123460214843 : ℝ) / 125000000000)) (t := ((-1539785157 : ℝ) / 248460214843))
    (lo := ((-3098695039 : ℝ) / 250000000000)) (hi := ((-2478956031 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123460214843 : ℝ) / 1000000000000) = Real.log ((123460214843 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123460214843 : ℝ) / 1000000000000) = ((123460214843 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_842 : RB (Real.log ((1580751 : ℝ) / 12800000)) ((-2091545120359 : ℝ) / 1000000000000) ((-2091545120357 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1580751 : ℝ) / 1600000)) (t := ((-19249 : ℝ) / 3180751))
    (lo := ((-12103578679 : ℝ) / 1000000000000)) (hi := ((-6051789339 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1580751 : ℝ) / 12800000) = Real.log ((1580751 : ℝ) / 1600000) - 3 * Real.log 2 := by
    rw [show ((1580751 : ℝ) / 12800000) = ((1580751 : ℝ) / 1600000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_843 : RB (Real.log ((266859902059 : ℝ) / 1000000000000)) ((-1321031469681 : ℝ) / 1000000000000) ((-1321031469679 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((266859902059 : ℝ) / 250000000000)) (t := ((16859902059 : ℝ) / 516859902059))
    (lo := ((65262891439 : ℝ) / 1000000000000)) (hi := ((815786143 : ℝ) / 12500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((266859902059 : ℝ) / 1000000000000) = Real.log ((266859902059 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((266859902059 : ℝ) / 1000000000000) = ((266859902059 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_844 : RB (Real.log ((266871325773 : ℝ) / 1000000000000)) ((-132098866269 : ℝ) / 100000000000) ((-41280895709 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((266871325773 : ℝ) / 250000000000)) (t := ((16871325773 : ℝ) / 516871325773))
    (lo := ((6530569843 : ℝ) / 100000000000)) (hi := ((65305698431 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((266871325773 : ℝ) / 1000000000000) = Real.log ((266871325773 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((266871325773 : ℝ) / 1000000000000) = ((266871325773 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_845 : RB (Real.log ((13917837623 : ℝ) / 62500000000)) ((-1501995257079 : ℝ) / 1000000000000) ((-1501995257077 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((13917837623 : ℝ) / 15625000000)) (t := ((-1707162377 : ℝ) / 29542837623))
    (lo := ((-115700895959 : ℝ) / 1000000000000)) (hi := ((-57850447979 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13917837623 : ℝ) / 62500000000) = Real.log ((13917837623 : ℝ) / 15625000000) - 2 * Real.log 2 := by
    rw [show ((13917837623 : ℝ) / 62500000000) = ((13917837623 : ℝ) / 15625000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_846 : RB (Real.log ((75237795837 : ℝ) / 25000000000)) ((550888942019 : ℝ) / 500000000000) ((27544447101 : ℝ) / 25000000000) := by
  have hm := log_bounds_of_series (x := ((75237795837 : ℝ) / 100000000000)) (t := ((-24762204163 : ℝ) / 175237795837))
    (lo := ((-284516477081 : ℝ) / 1000000000000)) (hi := ((-7112911927 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((75237795837 : ℝ) / 25000000000) = Real.log ((75237795837 : ℝ) / 100000000000) + 2 * Real.log 2 := by
    rw [show ((75237795837 : ℝ) / 25000000000) = ((75237795837 : ℝ) / 100000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_847 : RB (Real.log ((3009529953943 : ℝ) / 1000000000000)) ((275445976271 : ℝ) / 250000000000) ((550891952543 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3009529953943 : ℝ) / 4000000000000)) (t := ((-990470046057 : ℝ) / 7009529953943))
    (lo := ((-56902091207 : ℝ) / 200000000000)) (hi := ((-142255228017 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3009529953943 : ℝ) / 1000000000000) = Real.log ((3009529953943 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3009529953943 : ℝ) / 1000000000000) = ((3009529953943 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_848 : RB (Real.log ((1490043740537 : ℝ) / 1000000000000)) ((39880547559 : ℝ) / 100000000000) ((49850684449 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((1490043740537 : ℝ) / 2000000000000)) (t := ((-509956259463 : ℝ) / 3490043740537))
    (lo := ((-294341704969 : ℝ) / 1000000000000)) (hi := ((-36792713121 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1490043740537 : ℝ) / 1000000000000) = Real.log ((1490043740537 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1490043740537 : ℝ) / 1000000000000) = ((1490043740537 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_849 : RB (Real.log ((561748085937 : ℝ) / 500000000000)) ((23289081063 : ℝ) / 200000000000) ((29111351329 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((561748085937 : ℝ) / 500000000000)) (t := ((61748085937 : ℝ) / 1061748085937))
    (lo := ((23289081063 : ℝ) / 200000000000)) (hi := ((29111351329 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_850 : RB (Real.log ((1123532128907 : ℝ) / 1000000000000)) ((7279838087 : ℝ) / 62500000000) ((116477409393 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1123532128907 : ℝ) / 1000000000000)) (t := ((123532128907 : ℝ) / 2123532128907))
    (lo := ((7279838087 : ℝ) / 62500000000)) (hi := ((116477409393 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_851 : RB (Real.log ((61748085937 : ℝ) / 500000000000)) ((-2091545120367 : ℝ) / 1000000000000) ((-418309024073 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((61748085937 : ℝ) / 62500000000)) (t := ((-751914063 : ℝ) / 124248085937))
    (lo := ((-12103578687 : ℝ) / 1000000000000)) (hi := ((-6051789343 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61748085937 : ℝ) / 500000000000) = Real.log ((61748085937 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61748085937 : ℝ) / 500000000000) = ((61748085937 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_852 : RB (Real.log ((123532128907 : ℝ) / 1000000000000)) ((-261406750457 : ℝ) / 125000000000) ((-1045627001827 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((123532128907 : ℝ) / 125000000000)) (t := ((-1467871093 : ℝ) / 248532128907))
    (lo := ((-1476557747 : ℝ) / 125000000000)) (hi := ((-472498479 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123532128907 : ℝ) / 1000000000000) = Real.log ((123532128907 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123532128907 : ℝ) / 1000000000000) = ((123532128907 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_853 : RB (Real.log ((159477928829 : ℝ) / 500000000000)) ((-1142702563021 : ℝ) / 1000000000000) ((-1142702563019 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((159477928829 : ℝ) / 125000000000)) (t := ((34477928829 : ℝ) / 284477928829))
    (lo := ((243591798099 : ℝ) / 1000000000000)) (hi := ((2435917981 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((159477928829 : ℝ) / 500000000000) = Real.log ((159477928829 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((159477928829 : ℝ) / 500000000000) = ((159477928829 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_854 : RB (Real.log ((39870969339 : ℝ) / 125000000000)) ((-228533052743 : ℝ) / 200000000000) ((-1142665263713 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((39870969339 : ℝ) / 31250000000)) (t := ((8620969339 : ℝ) / 71120969339))
    (lo := ((48725819481 : ℝ) / 200000000000)) (hi := ((121814548703 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39870969339 : ℝ) / 125000000000) = Real.log ((39870969339 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((39870969339 : ℝ) / 125000000000) = ((39870969339 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_855 : RB (Real.log ((253394412399 : ℝ) / 1000000000000)) ((-42900251933 : ℝ) / 31250000000) ((-686404030927 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((253394412399 : ℝ) / 250000000000)) (t := ((3394412399 : ℝ) / 503394412399))
    (lo := ((105361713 : ℝ) / 7812500000)) (hi := ((2697259853 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((253394412399 : ℝ) / 1000000000000) = Real.log ((253394412399 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((253394412399 : ℝ) / 1000000000000) = ((253394412399 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_856 : RB (Real.log ((752338375089 : ℝ) / 250000000000)) ((220345054351 : ℝ) / 200000000000) ((1101725271757 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((752338375089 : ℝ) / 1000000000000)) (t := ((-247661624911 : ℝ) / 1752338375089))
    (lo := ((-71142272341 : ℝ) / 250000000000)) (hi := ((-284569089363 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((752338375089 : ℝ) / 250000000000) = Real.log ((752338375089 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((752338375089 : ℝ) / 250000000000) = ((752338375089 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_857 : RB (Real.log ((3009371624833 : ℝ) / 1000000000000)) ((275432823613 : ℝ) / 250000000000) ((550865647227 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3009371624833 : ℝ) / 4000000000000)) (t := ((-990628375167 : ℝ) / 7009371624833))
    (lo := ((-284563066667 : ℝ) / 1000000000000)) (hi := ((-142281533333 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3009371624833 : ℝ) / 1000000000000) = Real.log ((3009371624833 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3009371624833 : ℝ) / 1000000000000) = ((3009371624833 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_858 : RB (Real.log ((46564935453 : ℝ) / 31250000000)) ((398828423619 : ℝ) / 1000000000000) ((398828423621 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((46564935453 : ℝ) / 62500000000)) (t := ((-15935064547 : ℝ) / 109064935453))
    (lo := ((-14715937847 : ℝ) / 50000000000)) (hi := ((-294318756939 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((46564935453 : ℝ) / 31250000000) = Real.log ((46564935453 : ℝ) / 62500000000) + 1 * Real.log 2 := by
    rw [show ((46564935453 : ℝ) / 31250000000) = ((46564935453 : ℝ) / 62500000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_859 : RB (Real.log ((561766064453 : ℝ) / 500000000000)) ((116477409391 : ℝ) / 1000000000000) ((7279838087 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((561766064453 : ℝ) / 500000000000)) (t := ((61766064453 : ℝ) / 1061766064453))
    (lo := ((116477409391 : ℝ) / 1000000000000)) (hi := ((7279838087 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_860 : RB (Real.log ((561775053711 : ℝ) / 500000000000)) ((23298682209 : ℝ) / 200000000000) ((58246705523 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((561775053711 : ℝ) / 500000000000)) (t := ((61775053711 : ℝ) / 1061775053711))
    (lo := ((23298682209 : ℝ) / 200000000000)) (hi := ((58246705523 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_861 : RB (Real.log ((61766064453 : ℝ) / 500000000000)) ((-130703375229 : ℝ) / 62500000000) ((-1045627001831 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((61766064453 : ℝ) / 62500000000)) (t := ((-733935547 : ℝ) / 124266064453))
    (lo := ((-369139437 : ℝ) / 31250000000)) (hi := ((-11812461983 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61766064453 : ℝ) / 500000000000) = Real.log ((61766064453 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61766064453 : ℝ) / 500000000000) = ((61766064453 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_862 : RB (Real.log ((61775053711 : ℝ) / 500000000000)) ((-2091108477087 : ℝ) / 1000000000000) ((-418221695417 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((61775053711 : ℝ) / 62500000000)) (t := ((-724946289 : ℝ) / 124275053711))
    (lo := ((-11666935407 : ℝ) / 1000000000000)) (hi := ((-5833467703 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61775053711 : ℝ) / 500000000000) = Real.log ((61775053711 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61775053711 : ℝ) / 500000000000) = ((61775053711 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_863 : RB (Real.log ((47791454429 : ℝ) / 200000000000)) ((-143147052067 : ℝ) / 100000000000) ((-357867630167 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((47791454429 : ℝ) / 50000000000)) (t := ((-2208545571 : ℝ) / 97791454429))
    (lo := ((-903523191 : ℝ) / 20000000000)) (hi := ((-45176159549 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47791454429 : ℝ) / 200000000000) = Real.log ((47791454429 : ℝ) / 50000000000) - 2 * Real.log 2 := by
    rw [show ((47791454429 : ℝ) / 200000000000) = ((47791454429 : ℝ) / 50000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_864 : RB (Real.log ((238962861121 : ℝ) / 1000000000000)) ((-57257885277 : ℝ) / 40000000000) ((-1431447131923 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((238962861121 : ℝ) / 250000000000)) (t := ((-11037138879 : ℝ) / 488962861121))
    (lo := ((-9030554161 : ℝ) / 200000000000)) (hi := ((-11288192701 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((238962861121 : ℝ) / 1000000000000) = Real.log ((238962861121 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((238962861121 : ℝ) / 1000000000000) = ((238962861121 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_865 : RB (Real.log ((102595104329 : ℝ) / 500000000000)) ((-395954470729 : ℝ) / 250000000000) ((-791908941457 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((102595104329 : ℝ) / 125000000000)) (t := ((-22404895671 : ℝ) / 227595104329))
    (lo := ((-49380880449 : ℝ) / 250000000000)) (hi := ((-39504704359 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((102595104329 : ℝ) / 500000000000) = Real.log ((102595104329 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((102595104329 : ℝ) / 500000000000) = ((102595104329 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_866 : RB (Real.log ((188060168909 : ℝ) / 62500000000)) ((110159540227 : ℝ) / 100000000000) ((34424856321 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((188060168909 : ℝ) / 250000000000)) (t := ((-61939831091 : ℝ) / 438060168909))
    (lo := ((-284698958849 : ℝ) / 1000000000000)) (hi := ((-278026327 : ℝ) / 976562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((188060168909 : ℝ) / 62500000000) = Real.log ((188060168909 : ℝ) / 250000000000) + 2 * Real.log 2 := by
    rw [show ((188060168909 : ℝ) / 62500000000) = ((188060168909 : ℝ) / 250000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_867 : RB (Real.log ((3008971765039 : ℝ) / 1000000000000)) ((1101598414099 : ℝ) / 1000000000000) ((1101598414101 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3008971765039 : ℝ) / 4000000000000)) (t := ((-991028234961 : ℝ) / 7008971765039))
    (lo := ((-14234797351 : ℝ) / 50000000000)) (hi := ((-284695947019 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008971765039 : ℝ) / 1000000000000) = Real.log ((3008971765039 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008971765039 : ℝ) / 1000000000000) = ((3008971765039 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_868 : RB (Real.log ((1490171056789 : ℝ) / 1000000000000)) ((398890916581 : ℝ) / 1000000000000) ((398890916583 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1490171056789 : ℝ) / 2000000000000)) (t := ((-509828943211 : ℝ) / 3490171056789))
    (lo := ((-147128131989 : ℝ) / 500000000000)) (hi := ((-294256263977 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1490171056789 : ℝ) / 1000000000000) = Real.log ((1490171056789 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1490171056789 : ℝ) / 1000000000000) = ((1490171056789 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_869 : RB (Real.log ((1123550107421 : ℝ) / 1000000000000)) ((29123352761 : ℝ) / 250000000000) ((23298682209 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1123550107421 : ℝ) / 1000000000000)) (t := ((123550107421 : ℝ) / 2123550107421))
    (lo := ((29123352761 : ℝ) / 250000000000)) (hi := ((23298682209 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_870 : RB (Real.log ((561784042969 : ℝ) / 500000000000)) ((116509412443 : ℝ) / 1000000000000) ((29127353111 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((561784042969 : ℝ) / 500000000000)) (t := ((61784042969 : ℝ) / 1061784042969))
    (lo := ((116509412443 : ℝ) / 1000000000000)) (hi := ((29127353111 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_871 : RB (Real.log ((123550107421 : ℝ) / 1000000000000)) ((-418221695419 : ℝ) / 200000000000) ((-2091108477093 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123550107421 : ℝ) / 125000000000)) (t := ((-1449892579 : ℝ) / 248550107421))
    (lo := ((-2333387083 : ℝ) / 200000000000)) (hi := ((-5833467707 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123550107421 : ℝ) / 1000000000000) = Real.log ((123550107421 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123550107421 : ℝ) / 1000000000000) = ((123550107421 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_872 : RB (Real.log ((61784042969 : ℝ) / 500000000000)) ((-418192594337 : ℝ) / 200000000000) ((-2090962971683 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((61784042969 : ℝ) / 62500000000)) (t := ((-715957031 : ℝ) / 124284042969))
    (lo := ((-2304286001 : ℝ) / 200000000000)) (hi := ((-2880357501 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61784042969 : ℝ) / 500000000000) = Real.log ((61784042969 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61784042969 : ℝ) / 500000000000) = ((61784042969 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_873 : RB (Real.log ((5424908479 : ℝ) / 20000000000)) ((-1304731244501 : ℝ) / 1000000000000) ((-1304731244499 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((5424908479 : ℝ) / 5000000000)) (t := ((424908479 : ℝ) / 10424908479))
    (lo := ((81563116619 : ℝ) / 1000000000000)) (hi := ((4078155831 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5424908479 : ℝ) / 20000000000) = Real.log ((5424908479 : ℝ) / 5000000000) - 2 * Real.log 2 := by
    rw [show ((5424908479 : ℝ) / 20000000000) = ((5424908479 : ℝ) / 5000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_874 : RB (Real.log ((271251159441 : ℝ) / 1000000000000)) ((-13047100997 : ℝ) / 10000000000) ((-652355049849 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((271251159441 : ℝ) / 250000000000)) (t := ((21251159441 : ℝ) / 521251159441))
    (lo := ((4079213071 : ℝ) / 50000000000)) (hi := ((81584261421 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((271251159441 : ℝ) / 1000000000000) = Real.log ((271251159441 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((271251159441 : ℝ) / 1000000000000) = ((271251159441 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_875 : RB (Real.log ((112690472829 : ℝ) / 500000000000)) ((-1489963216629 : ℝ) / 1000000000000) ((-1489963216627 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((112690472829 : ℝ) / 125000000000)) (t := ((-12309527171 : ℝ) / 237690472829))
    (lo := ((-103668855509 : ℝ) / 1000000000000)) (hi := ((-25917213877 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112690472829 : ℝ) / 500000000000) = Real.log ((112690472829 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((112690472829 : ℝ) / 500000000000) = ((112690472829 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_876 : RB (Real.log ((1504441773427 : ℝ) / 500000000000)) ((1101569095287 : ℝ) / 1000000000000) ((1101569095289 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1504441773427 : ℝ) / 2000000000000)) (t := ((-495558226573 : ℝ) / 3504441773427))
    (lo := ((-35590658229 : ℝ) / 125000000000)) (hi := ((-284725265831 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1504441773427 : ℝ) / 500000000000) = Real.log ((1504441773427 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1504441773427 : ℝ) / 500000000000) = ((1504441773427 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_877 : RB (Real.log ((1504446305177 : ℝ) / 500000000000)) ((1101572107529 : ℝ) / 1000000000000) ((1101572107531 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1504446305177 : ℝ) / 2000000000000)) (t := ((-495553694823 : ℝ) / 3504446305177))
    (lo := ((-28472225359 : ℝ) / 100000000000)) (hi := ((-284722253589 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1504446305177 : ℝ) / 500000000000) = Real.log ((1504446305177 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1504446305177 : ℝ) / 500000000000) = ((1504446305177 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_878 : RB (Real.log ((46568379979 : ℝ) / 31250000000)) ((398902393411 : ℝ) / 1000000000000) ((398902393413 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((46568379979 : ℝ) / 62500000000)) (t := ((-15931620021 : ℝ) / 109068379979))
    (lo := ((-73561196787 : ℝ) / 250000000000)) (hi := ((-294244787147 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((46568379979 : ℝ) / 31250000000) = Real.log ((46568379979 : ℝ) / 62500000000) + 1 * Real.log 2 := by
    rw [show ((46568379979 : ℝ) / 31250000000) = ((46568379979 : ℝ) / 62500000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_879 : RB (Real.log ((1123568085937 : ℝ) / 1000000000000)) ((58254706221 : ℝ) / 500000000000) ((116509412443 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1123568085937 : ℝ) / 1000000000000)) (t := ((123568085937 : ℝ) / 2123568085937))
    (lo := ((58254706221 : ℝ) / 500000000000)) (hi := ((116509412443 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_880 : RB (Real.log ((561793032227 : ℝ) / 500000000000)) ((7282838349 : ℝ) / 62500000000) ((23305082717 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((561793032227 : ℝ) / 500000000000)) (t := ((61793032227 : ℝ) / 1061793032227))
    (lo := ((7282838349 : ℝ) / 62500000000)) (hi := ((23305082717 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_881 : RB (Real.log ((123568085937 : ℝ) / 1000000000000)) ((-2090962971693 : ℝ) / 1000000000000) ((-2090962971691 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123568085937 : ℝ) / 125000000000)) (t := ((-1431914063 : ℝ) / 248568085937))
    (lo := ((-11521430013 : ℝ) / 1000000000000)) (hi := ((-2880357503 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123568085937 : ℝ) / 1000000000000) = Real.log ((123568085937 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123568085937 : ℝ) / 1000000000000) = ((123568085937 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_882 : RB (Real.log ((61793032227 : ℝ) / 500000000000)) ((-522704371863 : ℝ) / 250000000000) ((-41816349749 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((61793032227 : ℝ) / 62500000000)) (t := ((-706967773 : ℝ) / 124293032227))
    (lo := ((-2843986443 : ℝ) / 250000000000)) (hi := ((-11375945771 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61793032227 : ℝ) / 500000000000) = Real.log ((61793032227 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61793032227 : ℝ) / 500000000000) = ((61793032227 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_883 : RB (Real.log ((41852487413 : ℝ) / 125000000000)) ((-68385156609 : ℝ) / 62500000000) ((-1094162505737 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((41852487413 : ℝ) / 62500000000)) (t := ((-20647512587 : ℝ) / 104352487413))
    (lo := ((-783233057 : ℝ) / 1953125000)) (hi := ((-200507662589 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41852487413 : ℝ) / 125000000000) = Real.log ((41852487413 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((41852487413 : ℝ) / 125000000000) = ((41852487413 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_884 : RB (Real.log ((10463310079 : ℝ) / 31250000000)) ((-1094144516461 : ℝ) / 1000000000000) ((-218828903291 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((10463310079 : ℝ) / 15625000000)) (t := ((-5161689921 : ℝ) / 26088310079))
    (lo := ((-400997335901 : ℝ) / 1000000000000)) (hi := ((-50124666987 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10463310079 : ℝ) / 31250000000) = Real.log ((10463310079 : ℝ) / 15625000000) - 1 * Real.log 2 := by
    rw [show ((10463310079 : ℝ) / 31250000000) = ((10463310079 : ℝ) / 15625000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_885 : RB (Real.log ((65569410303 : ℝ) / 250000000000)) ((-41823488657 : ℝ) / 31250000000) ((-669175818511 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((65569410303 : ℝ) / 62500000000)) (t := ((3069410303 : ℝ) / 128069410303))
    (lo := ((93638133 : ℝ) / 1953125000)) (hi := ((47942724097 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65569410303 : ℝ) / 250000000000) = Real.log ((65569410303 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((65569410303 : ℝ) / 250000000000) = ((65569410303 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_886 : RB (Real.log ((601760877961 : ℝ) / 200000000000)) ((27538569679 : ℝ) / 25000000000) ((550771393581 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((601760877961 : ℝ) / 800000000000)) (t := ((-198239122039 : ℝ) / 1401760877961))
    (lo := ((-284751573959 : ℝ) / 1000000000000)) (hi := ((-142375786979 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((601760877961 : ℝ) / 200000000000) = Real.log ((601760877961 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((601760877961 : ℝ) / 200000000000) = ((601760877961 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_887 : RB (Real.log ((3008813454307 : ℝ) / 1000000000000)) ((220309159963 : ℝ) / 200000000000) ((1101545799817 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3008813454307 : ℝ) / 4000000000000)) (t := ((-991186545693 : ℝ) / 7008813454307))
    (lo := ((-35593570163 : ℝ) / 125000000000)) (hi := ((-284748561303 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008813454307 : ℝ) / 1000000000000) = Real.log ((3008813454307 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008813454307 : ℝ) / 1000000000000) = ((3008813454307 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_888 : RB (Real.log ((59608210529 : ℝ) / 40000000000)) ((398913871021 : ℝ) / 1000000000000) ((24932116939 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((59608210529 : ℝ) / 80000000000)) (t := ((-20391789471 : ℝ) / 139608210529))
    (lo := ((-147116654769 : ℝ) / 500000000000)) (hi := ((-9194790923 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((59608210529 : ℝ) / 40000000000) = Real.log ((59608210529 : ℝ) / 80000000000) + 1 * Real.log 2 := by
    rw [show ((59608210529 : ℝ) / 40000000000) = ((59608210529 : ℝ) / 80000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_889 : RB (Real.log ((1123586064453 : ℝ) / 1000000000000)) ((116525413583 : ℝ) / 1000000000000) ((7282838349 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((1123586064453 : ℝ) / 1000000000000)) (t := ((123586064453 : ℝ) / 2123586064453))
    (lo := ((116525413583 : ℝ) / 1000000000000)) (hi := ((7282838349 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_890 : RB (Real.log ((1123595053711 : ℝ) / 1000000000000)) ((58266707029 : ℝ) / 500000000000) ((116533414059 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1123595053711 : ℝ) / 1000000000000)) (t := ((123595053711 : ℝ) / 2123595053711))
    (lo := ((58266707029 : ℝ) / 500000000000)) (hi := ((116533414059 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_891 : RB (Real.log ((123586064453 : ℝ) / 1000000000000)) ((-104540874373 : ℝ) / 50000000000) ((-1045408743729 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((123586064453 : ℝ) / 125000000000)) (t := ((-1413935547 : ℝ) / 248586064453))
    (lo := ((-568797289 : ℝ) / 50000000000)) (hi := ((-11375945779 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123586064453 : ℝ) / 1000000000000) = Real.log ((123586064453 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123586064453 : ℝ) / 1000000000000) = ((123586064453 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_892 : RB (Real.log ((123595053711 : ℝ) / 1000000000000)) ((-2090744753279 : ℝ) / 1000000000000) ((-2090744753277 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123595053711 : ℝ) / 125000000000)) (t := ((-1404946289 : ℝ) / 248595053711))
    (lo := ((-11303211599 : ℝ) / 1000000000000)) (hi := ((-5651605799 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123595053711 : ℝ) / 1000000000000) = Real.log ((123595053711 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123595053711 : ℝ) / 1000000000000) = ((123595053711 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_893 : RB (Real.log ((31161961993 : ℝ) / 125000000000)) ((-1389115553167 : ℝ) / 1000000000000) ((-277823110633 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((31161961993 : ℝ) / 31250000000)) (t := ((-88038007 : ℝ) / 62411961993))
    (lo := ((-2821192047 : ℝ) / 1000000000000)) (hi := ((-1410596023 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31161961993 : ℝ) / 125000000000) = Real.log ((31161961993 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((31161961993 : ℝ) / 125000000000) = ((31161961993 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_894 : RB (Real.log ((7790578591 : ℝ) / 31250000000)) ((-1389104245503 : ℝ) / 1000000000000) ((-1389104245501 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((7790578591 : ℝ) / 7812500000)) (t := ((-21921409 : ℝ) / 15603078591))
    (lo := ((-2809884383 : ℝ) / 1000000000000)) (hi := ((-1404942191 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7790578591 : ℝ) / 31250000000) = Real.log ((7790578591 : ℝ) / 7812500000) - 2 * Real.log 2 := by
    rw [show ((7790578591 : ℝ) / 31250000000) = ((7790578591 : ℝ) / 7812500000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_895 : RB (Real.log ((211776470619 : ℝ) / 1000000000000)) ((-1552223944437 : ℝ) / 1000000000000) ((-310444788887 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((211776470619 : ℝ) / 250000000000)) (t := ((-38223529381 : ℝ) / 461776470619))
    (lo := ((-165929583317 : ℝ) / 1000000000000)) (hi := ((-41482395829 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((211776470619 : ℝ) / 1000000000000) = Real.log ((211776470619 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((211776470619 : ℝ) / 1000000000000) = ((211776470619 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_896 : RB (Real.log ((3008609050983 : ℝ) / 1000000000000)) ((550738931323 : ℝ) / 500000000000) ((137684732831 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((3008609050983 : ℝ) / 4000000000000)) (t := ((-991390949017 : ℝ) / 7008609050983))
    (lo := ((-284816498473 : ℝ) / 1000000000000)) (hi := ((-35602062309 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3008609050983 : ℝ) / 1000000000000) = Real.log ((3008609050983 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3008609050983 : ℝ) / 1000000000000) = ((3008609050983 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_897 : RB (Real.log ((30086135833 : ℝ) / 10000000000)) ((550739684547 : ℝ) / 500000000000) ((137684921137 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((30086135833 : ℝ) / 40000000000)) (t := ((-9913864167 : ℝ) / 70086135833))
    (lo := ((-11392599681 : ℝ) / 40000000000)) (hi := ((-35601874003 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((30086135833 : ℝ) / 10000000000) = Real.log ((30086135833 : ℝ) / 40000000000) + 2 * Real.log 2 := by
    rw [show ((30086135833 : ℝ) / 10000000000) = ((30086135833 : ℝ) / 40000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_898 : RB (Real.log ((29805036597 : ℝ) / 20000000000)) ((398945118997 : ℝ) / 1000000000000) ((398945118999 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((29805036597 : ℝ) / 40000000000)) (t := ((-10194963403 : ℝ) / 69805036597))
    (lo := ((-147101030781 : ℝ) / 500000000000)) (hi := ((-294202061561 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((29805036597 : ℝ) / 20000000000) = Real.log ((29805036597 : ℝ) / 40000000000) + 1 * Real.log 2 := by
    rw [show ((29805036597 : ℝ) / 20000000000) = ((29805036597 : ℝ) / 40000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_899 : RB (Real.log ((112359505371 : ℝ) / 100000000000)) ((116533414057 : ℝ) / 1000000000000) ((58266707029 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((112359505371 : ℝ) / 100000000000)) (t := ((12359505371 : ℝ) / 212359505371))
    (lo := ((116533414057 : ℝ) / 1000000000000)) (hi := ((58266707029 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
