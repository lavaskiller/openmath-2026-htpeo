import LeanProject.DLowerMLogs
import LeanProject.DLowerMNumeric04
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_param_7_point {q : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200)) :
    RB (delta (q)) ((128455245375073759 : ℝ) / 200000000000000000) ((802845283594211 : ℝ) / 1250000000000000) ∧
    RB (delta1 (q)) ((-487442639806546203 : ℝ) / 250000000000000000) ((-1949770559226184809 : ℝ) / 1000000000000000000) ∧
    RB (delta2 (q)) ((1900802616812594721 : ℝ) / 1000000000000000000) ((237600327101574341 : ℝ) / 125000000000000000) ∧
    RB (aval (q)) ((824460287188576099 : ℝ) / 1000000000000000000) ((103057535898572013 : ℝ) / 125000000000000000) ∧
    RB (aval1 (q)) ((-1329429692271643261 : ℝ) / 1000000000000000000) ((-1329429692271643119 : ℝ) / 1000000000000000000) ∧
    RB (aval2 (q)) ((4356254935624629199 : ℝ) / 100000000000000000) ((43562549356246351283 : ℝ) / 1000000000000000000) ∧
    RB (D0q (q)) ((1900802616812594721 : ℝ) / 1000000000000000000) ((237600327101574341 : ℝ) / 125000000000000000) ∧
    RB (d01 (q)) ((-3706128981161288301 : ℝ) / 1000000000000000000) ((-3706128981161288283 : ℝ) / 1000000000000000000) ∧
    RB (d02 (q)) ((10839151764244823401 : ℝ) / 1000000000000000000) ((10839151764244823471 : ℝ) / 1000000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1025761718749999999 : ℝ) / 1000000000000000000) ((52519 : ℝ) / 51200) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-1829432829155142297 : ℝ) / 500000000000000000) ((-1829432829155142277 : ℝ) / 500000000000000000) := rb_log hq (by norm_num) dlower_m_log_336.1 dlower_m_log_337.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((5087095368457651 : ℝ) / 200000000000000000) ((25435476842288257 : ℝ) / 1000000000000000000) := rb_log h1 (by norm_num) dlower_m_log_338.1 dlower_m_log_339.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((5087095368457651 : ℝ) / 100000000000000000) ((25435476842288257 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((128455245375073759 : ℝ) / 200000000000000000) ((802845283594211 : ℝ) / 1250000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((128455245375073759 : ℝ) / 200000000000000000) ((802845283594211 : ℝ) / 1250000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-487442639806546203 : ℝ) / 250000000000000000) ((-1949770559226184809 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-487442639806546203 : ℝ) / 250000000000000000) ((-1949770559226184809 : ℝ) / 1000000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((1052187103652954099 : ℝ) / 1000000000000000000) ((526093551826477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((1900802616812594721 : ℝ) / 1000000000000000000) ((237600327101574341 : ℝ) / 125000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((1900802616812594721 : ℝ) / 1000000000000000000) ((237600327101574341 : ℝ) / 125000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-802845283594211 : ℝ) / 1250000000000000) ((-128455245375073759 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((1829432829155142277 : ℝ) / 500000000000000000) ((1829432829155142297 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-175539712811423901 : ℝ) / 1000000000000000000) ((-21942464101427987 : ℝ) / 125000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((824460287188576099 : ℝ) / 1000000000000000000) ((103057535898572013 : ℝ) / 125000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((824460287188576099 : ℝ) / 1000000000000000000) ((103057535898572013 : ℝ) / 125000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((1949770559226184809 : ℝ) / 1000000000000000000) ((487442639806546203 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((1829432829155142277 : ℝ) / 500000000000000000) ((1829432829155142297 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((266444677300152113 : ℝ) / 500000000000000000) ((266444677300152117 : ℝ) / 500000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((1829432829155142277 : ℝ) / 500000000000000000) ((1829432829155142297 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((13387297905562351961 : ℝ) / 1000000000000000000) ((2677459581112470451 : ℝ) / 200000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((172439901732780679 : ℝ) / 500000000000000000) ((17243990173278069 : ℝ) / 50000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((1862319046871947353 : ℝ) / 1000000000000000000) ((1862319046871947487 : ℝ) / 1000000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-1329429692271643261 : ℝ) / 1000000000000000000) ((-1329429692271643119 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-1329429692271643261 : ℝ) / 1000000000000000000) ((-1329429692271643119 : ℝ) / 1000000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-237600327101574341 : ℝ) / 125000000000000000) ((-1900802616812594721 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((1829432829155142277 : ℝ) / 500000000000000000) ((1829432829155142297 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-519505987462357943 : ℝ) / 1000000000000000000) ((-103901197492471587 : ℝ) / 200000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-487442639806546203 : ℝ) / 125000000000000000) ((-1949770559226184809 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((1829432829155142277 : ℝ) / 500000000000000000) ((1829432829155142297 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((13387297905562351961 : ℝ) / 1000000000000000000) ((2677459581112470451 : ℝ) / 200000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((172439901732780679 : ℝ) / 500000000000000000) ((17243990173278069 : ℝ) / 50000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-11306957030441957641 : ℝ) / 1000000000000000000) ((-5653478515220978451 : ℝ) / 500000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((10787451042979598959 : ℝ) / 1000000000000000000) ((5393725521489799853 : ℝ) / 500000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-829432829155142297 : ℝ) / 500000000000000000) ((-829432829155142277 : ℝ) / 500000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-1065449975912654367 : ℝ) / 1000000000000000000) ((-266362493978163583 : ℝ) / 250000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((1829432829155142277 : ℝ) / 500000000000000000) ((1829432829155142297 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((13387297905562351961 : ℝ) / 1000000000000000000) ((2677459581112470451 : ℝ) / 200000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((8884696499435059 : ℝ) / 1000000000000000000) ((4442348249717537 : ℝ) / 500000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-16253955453146297 : ℝ) / 500000000000000000) ((-32507910906292537 : ℝ) / 1000000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((266362493978163583 : ℝ) / 250000000000000000) ((1065449975912654367 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((32507910906292537 : ℝ) / 1000000000000000000) ((16253955453146297 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((32775098313266693031 : ℝ) / 1000000000000000000) ((32775098313266751577 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((4356254935624629199 : ℝ) / 100000000000000000) ((43562549356246351283 : ℝ) / 1000000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((4356254935624629199 : ℝ) / 100000000000000000) ((43562549356246351283 : ℝ) / 1000000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((1052187103652954099 : ℝ) / 1000000000000000000) ((526093551826477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((1900802616812594721 : ℝ) / 1000000000000000000) ((237600327101574341 : ℝ) / 125000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((1900802616812594721 : ℝ) / 1000000000000000000) ((237600327101574341 : ℝ) / 125000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((1052187103652954099 : ℝ) / 1000000000000000000) ((526093551826477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((1079293251889638599 : ℝ) / 1000000000000000000) ((269823312972409651 : ℝ) / 250000000000000000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-3706128981161288301 : ℝ) / 1000000000000000000) ((-3706128981161288283 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-3706128981161288301 : ℝ) / 1000000000000000000) ((-3706128981161288283 : ℝ) / 1000000000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((1052187103652954099 : ℝ) / 1000000000000000000) ((526093551826477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((1107097701093592373 : ℝ) / 1000000000000000000) ((55354885054679619 : ℝ) / 50000000000000000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((10839151764244823401 : ℝ) / 1000000000000000000) ((10839151764244823471 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((10839151764244823401 : ℝ) / 1000000000000000000) ((10839151764244823471 : ℝ) / 1000000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_param_7_slab {q : ℝ} (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280)) :
    RB (delta (q)) ((128447629156335727 : ℝ) / 200000000000000000) ((40144644293384851 : ℝ) / 62500000000000000) ∧
    RB (delta1 (q)) ((-1949807684984195897 : ℝ) / 1000000000000000000) ((-1949733434881949733 : ℝ) / 1000000000000000000) ∧
    RB (delta2 (q)) ((95036511677414153 : ℝ) / 50000000000000000) ((1900875004211714651 : ℝ) / 1000000000000000000) ∧
    RB (aval (q)) ((412206754883826709 : ℝ) / 500000000000000000) ((824507072600771523 : ℝ) / 1000000000000000000) ∧
    RB (aval1 (q)) ((-133184612547997687 : ℝ) / 100000000000000000) ((-331754189813364111 : ℝ) / 250000000000000000) ∧
    RB (aval2 (q)) ((21731047972880423571 : ℝ) / 500000000000000000) ((21831642279174888059 : ℝ) / 500000000000000000) ∧
    RB (D0q (q)) ((95036511677414153 : ℝ) / 50000000000000000) ((1900875004211714651 : ℝ) / 1000000000000000000) ∧
    RB (d01 (q)) ((-3706340691406366971 : ℝ) / 1000000000000000000) ((-1852958643520032229 : ℝ) / 500000000000000000) ∧
    RB (d02 (q)) ((10838326262173531997 : ℝ) / 1000000000000000000) ((5419988672455329287 : ℝ) / 500000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1025742187499999999 : ℝ) / 1000000000000000000) ((1313 : ℝ) / 1280) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-457453011995643333 : ℝ) / 125000000000000000) ((-1829053897723591307 : ℝ) / 500000000000000000) := rb_log hq (by norm_num) dlower_m_log_340.1 dlower_m_log_341.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((25416435932893847 : ℝ) / 1000000000000000000) ((25454517389133337 : ℝ) / 1000000000000000000) := rb_log h1 (by norm_num) dlower_m_log_342.1 dlower_m_log_343.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((25416435932893847 : ℝ) / 500000000000000000) ((25454517389133337 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((128447629156335727 : ℝ) / 200000000000000000) ((40144644293384851 : ℝ) / 62500000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((128447629156335727 : ℝ) / 200000000000000000) ((40144644293384851 : ℝ) / 62500000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-1949807684984195897 : ℝ) / 1000000000000000000) ((-1949733434881949733 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-1949807684984195897 : ℝ) / 1000000000000000000) ((-1949733434881949733 : ℝ) / 1000000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((526073517608642577 : ℝ) / 500000000000000000) ((1723969 : ℝ) / 1638400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((95036511677414153 : ℝ) / 50000000000000000) ((1900875004211714651 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((95036511677414153 : ℝ) / 50000000000000000) ((1900875004211714651 : ℝ) / 1000000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-40144644293384851 : ℝ) / 62500000000000000) ((-128447629156335727 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((1829053897723591307 : ℝ) / 500000000000000000) ((457453011995643333 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-87793245116173291 : ℝ) / 500000000000000000) ((-175492927399228477 : ℝ) / 1000000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((412206754883826709 : ℝ) / 500000000000000000) ((824507072600771523 : ℝ) / 1000000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((412206754883826709 : ℝ) / 500000000000000000) ((824507072600771523 : ℝ) / 1000000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((1949733434881949733 : ℝ) / 1000000000000000000) ((1949807684984195897 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((1829053897723591307 : ℝ) / 500000000000000000) ((457453011995643333 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((266384385903403793 : ℝ) / 500000000000000000) ((266504952015204781 : ℝ) / 500000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((1829053897723591307 : ℝ) / 500000000000000000) ((457453011995643333 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((13381752643111446437 : ℝ) / 1000000000000000000) ((13392848523768717 : ℝ) / 1000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((10764862050549857 : ℝ) / 31250000000000000) ((86321094000853059 : ℝ) / 250000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((930013331641933003 : ℝ) / 500000000000000000) ((233076862160848057 : ℝ) / 125000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-133184612547997687 : ℝ) / 100000000000000000) ((-331754189813364111 : ℝ) / 250000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-133184612547997687 : ℝ) / 100000000000000000) ((-331754189813364111 : ℝ) / 250000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-1900875004211714651 : ℝ) / 1000000000000000000) ((-95036511677414153 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((1829053897723591307 : ℝ) / 500000000000000000) ((457453011995643333 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-519633403525590647 : ℝ) / 1000000000000000000) ((-129844635931590577 : ℝ) / 250000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-1949807684984195897 : ℝ) / 500000000000000000) ((-1949733434881949733 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((1829053897723591307 : ℝ) / 500000000000000000) ((457453011995643333 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((13381752643111446437 : ℝ) / 1000000000000000000) ((13392848523768717 : ℝ) / 1000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((10764862050549857 : ℝ) / 31250000000000000) ((86321094000853059 : ℝ) / 250000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-1415055062239367249 : ℝ) / 125000000000000000) ((-564674676986450641 : ℝ) / 50000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((10773860136203422173 : ℝ) / 1000000000000000000) ((2700265488547143921 : ℝ) / 250000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-207453011995643333 : ℝ) / 125000000000000000) ((-829053897723591307 : ℝ) / 500000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-533000151946009739 : ℝ) / 500000000000000000) ((-212980015210829089 : ℝ) / 200000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((1829053897723591307 : ℝ) / 500000000000000000) ((457453011995643333 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((13381752643111446437 : ℝ) / 1000000000000000000) ((13392848523768717 : ℝ) / 1000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((8867555114140441 : ℝ) / 1000000000000000000) ((2225465704709493 : ℝ) / 250000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-16288735835397833 : ℝ) / 500000000000000000) ((-16219236244797339 : ℝ) / 500000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((212980015210829089 : ℝ) / 200000000000000000) ((533000151946009739 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((16219236244797339 : ℝ) / 500000000000000000) ((16288735835397833 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((32688235809557424969 : ℝ) / 1000000000000000000) ((16431111302080600217 : ℝ) / 500000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((21731047972880423571 : ℝ) / 500000000000000000) ((21831642279174888059 : ℝ) / 500000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((21731047972880423571 : ℝ) / 500000000000000000) ((21831642279174888059 : ℝ) / 500000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((526073517608642577 : ℝ) / 500000000000000000) ((1723969 : ℝ) / 1638400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((95036511677414153 : ℝ) / 50000000000000000) ((1900875004211714651 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((95036511677414153 : ℝ) / 50000000000000000) ((1900875004211714651 : ℝ) / 1000000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((526073517608642577 : ℝ) / 500000000000000000) ((1723969 : ℝ) / 1638400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((107923160147541761 : ℝ) / 100000000000000000) ((539677452325820923 : ℝ) / 500000000000000000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-3706340691406366971 : ℝ) / 1000000000000000000) ((-1852958643520032229 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-3706340691406366971 : ℝ) / 1000000000000000000) ((-1852958643520032229 : ℝ) / 500000000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((526073517608642577 : ℝ) / 500000000000000000) ((1723969 : ℝ) / 1638400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((553506691858261543 : ℝ) / 500000000000000000) ((276795505821797997 : ℝ) / 250000000000000000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((10838326262173531997 : ℝ) / 1000000000000000000) ((5419988672455329287 : ℝ) / 500000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((10838326262173531997 : ℝ) / 1000000000000000000) ((5419988672455329287 : ℝ) / 500000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_7_point_plus_branch {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((459244524763373 : ℝ) / 1000000000000000) ((28702782797711 : ℝ) / 62500000000000)) :
    RB (phi q (v)) ((92137930130839131 : ℝ) / 200000000000000000) ((115172412663549667 : ℝ) / 250000000000000000) ∧
    RB (psi1 q (v)) ((-1695426189709627699 : ℝ) / 1000000000000000000) ((-847713094854778949 : ℝ) / 500000000000000000) ∧
    RB (psi2 q (v)) ((-10627714662907004197 : ℝ) / 1000000000000000000) ((-2125542932580802567 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((229290429305209449 : ℝ) / 500000000000000000) ((458580858610421899 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((33797217202289 : ℝ) / 62500000000000) ((540755475236627 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-155923729635373981 : ℝ) / 200000000000000000) ((-779618648176863359 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_344.1 dlower_m_log_345.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-61478808893601453 : ℝ) / 100000000000000000) ((-30739404446800449 : ℝ) / 50000000000000000) := rb_log h3 (by norm_num) dlower_m_log_346.1 dlower_m_log_347.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-6593222369634437 : ℝ) / 40000000000000000) ((-164830559240848829 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-67948125104586903 : ℝ) / 500000000000000000) ((-135896250209163831 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-778172477084540543 : ℝ) / 1000000000000000000) ((-778172477084534009 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_348.1 dlower_m_log_349.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((642276226875360203 : ℝ) / 1000000000000000000) ((80284528359422089 : ℝ) / 125000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-8597 : ℝ) / 1000000000000000000) ((7917 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-8597 : ℝ) / 1000000000000000000) ((7917 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((219130639648524499 : ℝ) / 1000000000000000000) ((54782659912135151 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-112354095319471309 : ℝ) / 1000000000000000000) ((-112354095319470569 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-9263148969390397 : ℝ) / 100000000000000000) ((-92631489693903359 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((126499149954620529 : ℝ) / 1000000000000000000) ((25299829990927449 : ℝ) / 200000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((1038134854590402669 : ℝ) / 500000000000000000) ((2076269709180822057 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((1038134854590402669 : ℝ) / 500000000000000000) ((2076269709180822057 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((1090320257838683353 : ℝ) / 500000000000000000) ((2180640515677380977 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((924632339193989711 : ℝ) / 500000000000000000) ((924632339193994841 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((251869074629084133 : ℝ) / 62500000000000000) ((4029905194065370659 : ℝ) / 1000000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((1661248396820924883 : ℝ) / 500000000000000000) ((830624198410467503 : ℝ) / 250000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((544372303902396119 : ℝ) / 250000000000000000) ((2177489215609598701 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((229001515606450213 : ℝ) / 200000000000000000) ((35781486813508923 : ℝ) / 31250000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((229001515606450213 : ℝ) / 200000000000000000) ((35781486813508923 : ℝ) / 31250000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((2284503781237399 : ℝ) / 7812500000000000) ((292416483998390317 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((3419779850733396963 : ℝ) / 1000000000000000000) ((1709889925366717457 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((13143525242741813 : ℝ) / 62500000000000000) ((210296403883871761 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((2377596529306825893 : ℝ) / 500000000000000000) ((4755193058613714037 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-667706603940158537 : ℝ) / 500000000000000000) ((-166926650985027109 : ℝ) / 125000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-1100995156884423897 : ℝ) / 1000000000000000000) ((-1100995156884341277 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((52726383381284079 : ℝ) / 250000000000000000) ((210905533525139073 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((4741459284096043449 : ℝ) / 1000000000000000000) ((4741459284096105431 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((113764503975363111 : ℝ) / 31250000000000000) ((1820232063605882077 : ℝ) / 500000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((113764503975363111 : ℝ) / 31250000000000000) ((1820232063605882077 : ℝ) / 500000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((1090320257838683353 : ℝ) / 500000000000000000) ((2180640515677380977 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((924632339193989711 : ℝ) / 500000000000000000) ((924632339193994841 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((251869074629084133 : ℝ) / 62500000000000000) ((4029905194065370659 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-1339368905507555633 : ℝ) / 250000000000000000) ((-5357475622030189347 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((25761718749999999 : ℝ) / 500000000000000000) ((1319 : ℝ) / 25600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((13143525242741813 : ℝ) / 62500000000000000) ((210296403883871761 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((122501946177957157 : ℝ) / 500000000000000000) ((61250973088979383 : ℝ) / 250000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((201995979454076099 : ℝ) / 1000000000000000000) ((40399195890815751 : ℝ) / 200000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-5155479642576146433 : ℝ) / 1000000000000000000) ((-5034648088453233 : ℝ) / 976562500000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-5155479642576146433 : ℝ) / 1000000000000000000) ((-5034648088453233 : ℝ) / 976562500000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-7180439372347692157 : ℝ) / 1000000000000000000) ((-7180439372347155451 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-1329429692271643261 : ℝ) / 500000000000000000) ((-1329429692271643119 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-112354095319471309 : ℝ) / 1000000000000000000) ((-112354095319470569 : ℝ) / 1000000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((149366870366022617 : ℝ) / 500000000000000000) ((149366870366023617 : ℝ) / 500000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-6881705631615646923 : ℝ) / 1000000000000000000) ((-6881705631615108217 : ℝ) / 1000000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-2180640515677380977 : ℝ) / 500000000000000000) ((-1090320257838683353 : ℝ) / 250000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((663666152954101 : ℝ) / 250000000000000000) ((331833076477051 : ℝ) / 125000000000000000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((13143525242741813 : ℝ) / 62500000000000000) ((210296403883871761 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((3155860683764167 : ℝ) / 250000000000000000) ((6311721367528427 : ℝ) / 500000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-546738059261227351 : ℝ) / 125000000000000000) ((-6834225740765297 : ℝ) / 1562500000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-450763817355436243 : ℝ) / 125000000000000000) ((-901527634710866559 : ℝ) / 250000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-10487816170459136867 : ℝ) / 1000000000000000000) ((-10487816170458574453 : ℝ) / 1000000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-2477723757454346319 : ℝ) / 200000000000000000) ((-6194309393635584587 : ℝ) / 500000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-2477723757454346319 : ℝ) / 200000000000000000) ((-6194309393635584587 : ℝ) / 500000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-2076269709180822057 : ℝ) / 1000000000000000000) ((-1038134854590402669 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-1813323989304060683 : ℝ) / 1000000000000000000) ((-1813323989303991489 : ℝ) / 1000000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-1813323989304060683 : ℝ) / 1000000000000000000) ((-1813323989303991489 : ℝ) / 1000000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((1813323989303991489 : ℝ) / 1000000000000000000) ((1813323989304060683 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((20550899313658389 : ℝ) / 6250000000000000) ((3288143890185593183 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((5985184938664900671 : ℝ) / 500000000000000000) ((2394073975466238073 : ℝ) / 200000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-5155479642576146433 : ℝ) / 500000000000000000) ((-5034648088453233 : ℝ) / 488281250000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((3739421964900651611 : ℝ) / 200000000000000000) ((3739421964900820299 : ℝ) / 200000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((30667479701833059397 : ℝ) / 1000000000000000000) ((1533373985091764593 : ℝ) / 50000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((9139430457280663901 : ℝ) / 500000000000000000) ((9139430457282061343 : ℝ) / 500000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-9139430457282061343 : ℝ) / 500000000000000000) ((-9139430457280663901 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-3192793002466795519 : ℝ) / 200000000000000000) ((-15963965012331056061 : ℝ) / 1000000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-3192793002466795519 : ℝ) / 200000000000000000) ((-15963965012331056061 : ℝ) / 1000000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((289025178164531 : ℝ) / 200000000000000000) ((361281472705667 : ℝ) / 250000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((92137930130839131 : ℝ) / 200000000000000000) ((115172412663549667 : ℝ) / 250000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((92137930130839131 : ℝ) / 200000000000000000) ((115172412663549667 : ℝ) / 250000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((52726383381284079 : ℝ) / 250000000000000000) ((210905533525139073 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((1573373021232263 : ℝ) / 500000000000000000) ((3146746042464573 : ℝ) / 1000000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((996853253957535427 : ℝ) / 1000000000000000000) ((498426626978767737 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-112976119951063259 : ℝ) / 62500000000000000) ((-903808959608471541 : ℝ) / 500000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((25761718749999999 : ℝ) / 500000000000000000) ((1319 : ℝ) / 25600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((22438345901476889 : ℝ) / 200000000000000000) ((3505991547105787 : ℝ) / 31250000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-1695426189709627699 : ℝ) / 1000000000000000000) ((-847713094854778949 : ℝ) / 500000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-1695426189709627699 : ℝ) / 1000000000000000000) ((-847713094854778949 : ℝ) / 500000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((663666152954101 : ℝ) / 500000000000000000) ((331833076477051 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((52726383381284079 : ℝ) / 250000000000000000) ((210905533525139073 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((96857211513716859 : ℝ) / 1000000000000000000) ((96857211513718759 : ℝ) / 1000000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((6852005571728647 : ℝ) / 500000000000000000) ((856500696466099 : ℝ) / 62500000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((1813323989303991489 : ℝ) / 1000000000000000000) ((1813323989304060683 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((20550899313658389 : ℝ) / 6250000000000000) ((3288143890185593183 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((22530380256195473 : ℝ) / 500000000000000000) ((2253038025619767 : ℝ) / 50000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((25761718749999999 : ℝ) / 250000000000000000) ((1319 : ℝ) / 12800) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((52726383381284079 : ℝ) / 250000000000000000) ((210905533525139073 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((244296281082917229 : ℝ) / 500000000000000000) ((97718512433168173 : ℝ) / 200000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-442988306985427413 : ℝ) / 500000000000000000) ((-885976613970809399 : ℝ) / 1000000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((186207474896640069 : ℝ) / 200000000000000000) ((465518687241625083 : ℝ) / 500000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((544372303902396119 : ℝ) / 125000000000000000) ((4354978431219197401 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((5286015805702369297 : ℝ) / 1000000000000000000) ((5286015805702447567 : ℝ) / 1000000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((52726383381284079 : ℝ) / 250000000000000000) ((210905533525139073 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((1573373021232263 : ℝ) / 500000000000000000) ((3146746042464573 : ℝ) / 1000000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((996853253957535427 : ℝ) / 1000000000000000000) ((498426626978767737 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-7956865234304686747 : ℝ) / 500000000000000000) ((-7956865234303230201 : ℝ) / 500000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-10627714662907004197 : ℝ) / 1000000000000000000) ((-2125542932580802567 : ℝ) / 200000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-10627714662907004197 : ℝ) / 1000000000000000000) ((-2125542932580802567 : ℝ) / 200000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_7_point_plus_lo_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((459244524763373 : ℝ) / 1000000000000000) ((459244524763373 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-413 : ℝ) / 200000000000000000) ((-2051 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((2076269709180821411 : ℝ) / 1000000000000000000) ((519067427295205363 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((229290429305209449 : ℝ) / 500000000000000000) ((458580858610418899 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((540755475236627 : ℝ) / 1000000000000000) ((540755475236627 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-155923729635373981 : ℝ) / 200000000000000000) ((-779618648176869901 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_344.1 dlower_m_log_350.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-307394044468004491 : ℝ) / 500000000000000000) ((-30739404446800449 : ℝ) / 50000000000000000) := rb_log h3 (by norm_num) dlower_m_log_347.1 dlower_m_log_347.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-6593222369634437 : ℝ) / 40000000000000000) ((-164830559240860919 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-67948125104586903 : ℝ) / 500000000000000000) ((-135896250209173799 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-778172477084540543 : ℝ) / 1000000000000000000) ((-778172477084540541 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_348.1 dlower_m_log_348.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((128455245375073347 : ℝ) / 200000000000000000) ((80284528359420843 : ℝ) / 125000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-413 : ℝ) / 200000000000000000) ((-2051 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-413 : ℝ) / 200000000000000000) ((-2051 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((54782659912135143 : ℝ) / 250000000000000000) ((54782659912135151 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-112354095319471309 : ℝ) / 1000000000000000000) ((-14044261914933913 : ℝ) / 125000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-9263148969390397 : ℝ) / 100000000000000000) ((-23157872423475991 : ℝ) / 250000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((63249574977318301 : ℝ) / 500000000000000000) ((790619687216479 : ℝ) / 6250000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2076269709180821411 : ℝ) / 1000000000000000000) ((519067427295205363 : ℝ) / 250000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2076269709180821411 : ℝ) / 1000000000000000000) ((519067427295205363 : ℝ) / 250000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_7_point_plus_hi_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((28702782797711 : ℝ) / 62500000000000) ((28702782797711 : ℝ) / 62500000000000)) :
    RB (E q (v)) ((137 : ℝ) / 100000000000000000) ((277 : ℝ) / 200000000000000000) ∧
    RB (Eq q (v)) ((259533713647600743 : ℝ) / 125000000000000000) ((1038134854590402993 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((229290429305210949 : ℝ) / 500000000000000000) ((458580858610421899 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((33797217202289 : ℝ) / 62500000000000) ((33797217202289 : ℝ) / 62500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-194904662044215841 : ℝ) / 250000000000000000) ((-779618648176863359 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_351.1 dlower_m_log_345.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-61478808893601453 : ℝ) / 100000000000000000) ((-9606063889625227 : ℝ) / 15625000000000000) := rb_log h3 (by norm_num) dlower_m_log_346.1 dlower_m_log_346.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-41207639810212209 : ℝ) / 250000000000000000) ((-164830559240848829 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-135896250209163839 : ℝ) / 1000000000000000000) ((-135896250209163831 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-778172477084534011 : ℝ) / 1000000000000000000) ((-778172477084534009 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_349.1 dlower_m_log_349.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((64227622687537017 : ℝ) / 100000000000000000) ((32113811343768509 : ℝ) / 50000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((137 : ℝ) / 100000000000000000) ((277 : ℝ) / 200000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((137 : ℝ) / 100000000000000000) ((277 : ℝ) / 200000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((219130639648524499 : ℝ) / 1000000000000000000) ((219130639648524533 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-56177047659735287 : ℝ) / 500000000000000000) ((-112354095319470569 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-23157872423475841 : ℝ) / 250000000000000000) ((-92631489693903359 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((25299829990924227 : ℝ) / 200000000000000000) ((63249574977310587 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((259533713647600743 : ℝ) / 125000000000000000) ((1038134854590402993 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((259533713647600743 : ℝ) / 125000000000000000) ((1038134854590402993 : ℝ) / 500000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_7_point_minus_branch {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((1140244881307 : ℝ) / 800000000000) ((1425306101633753 : ℝ) / 1000000000000000)) :
    RB (phi q (v)) ((178221466530768129 : ℝ) / 125000000000000000) ((285154346449229607 : ℝ) / 200000000000000000) ∧
    RB (psi1 q (v)) ((733847718444989 : ℝ) / 3906250000000000) ((11741563495120281 : ℝ) / 62500000000000000) ∧
    RB (psi2 q (v)) ((5174858050293918891 : ℝ) / 200000000000000000) ((25874290251470046857 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712321217740397949 : ℝ) / 500000000000000000) ((1424642435480798899 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425306101633753 : ℝ) / 1000000000000000) ((-340244881307 : ℝ) / 800000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353920859764686863 : ℝ) / 1000000000000000000) ((353920859764688971 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_352.1 dlower_m_log_353.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((340244881307 : ℝ) / 800000000000) ((425306101633753 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854946130167220277 : ℝ) / 1000000000000000000) ((-427473065083606611 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_354.1 dlower_m_log_355.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((241773397986380017 : ℝ) / 200000000000000000) ((9444273358843041 : ℝ) / 7812500000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((7973302605536351 : ℝ) / 8000000000000000) ((996662825692051437 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354386598816678667 : ℝ) / 1000000000000000000) ((177193299408340387 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_356.1 dlower_m_log_357.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642276226875363101 : ℝ) / 1000000000000000000) ((64227622687537277 : ℝ) / 100000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-5699 : ℝ) / 1000000000000000000) ((159 : ℝ) / 40000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-5699 : ℝ) / 1000000000000000000) ((159 : ℝ) / 40000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-200887958802815723 : ℝ) / 125000000000000000) ((-160710367042251343 : ℝ) / 100000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-9041468268950517 : ℝ) / 250000000000000000) ((-36165873075801989 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-14908663051250683 : ℝ) / 500000000000000000) ((-29817326102501299 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-32738419930500543 : ℝ) / 20000000000000000) ((-1636920996525014729 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((312849562701157659 : ℝ) / 1000000000000000000) ((312849562701170083 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((312849562701157659 : ℝ) / 1000000000000000000) ((312849562701170083 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((70193051610351097 : ℝ) / 100000000000000000) ((701930516103512449 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((340244881307 : ℝ) / 800000000000) ((425306101633753 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-587811928960488131 : ℝ) / 250000000000000000) ((-1175623857920967969 : ℝ) / 500000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-824658599869220777 : ℝ) / 500000000000000000) ((-1649317199738423489 : ℝ) / 1000000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-1359796532161413661 : ℝ) / 1000000000000000000) ((-679898266080699379 : ℝ) / 500000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((701603675767438931 : ℝ) / 1000000000000000000) ((87700459470930051 : ℝ) / 125000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-2061400207928854069 : ℝ) / 1000000000000000000) ((-2061400207928837689 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-2061400207928854069 : ℝ) / 1000000000000000000) ((-2061400207928837689 : ℝ) / 1000000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((340244881307 : ℝ) / 800000000000) ((425306101633753 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((45221320021724421 : ℝ) / 250000000000000000) ((180885280086900237 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((2764182910625960553 : ℝ) / 500000000000000000) ((2764182910625999567 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((1014803034486326851 : ℝ) / 500000000000000000) ((1014803034486331127 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((492706449437341273 : ℝ) / 1000000000000000000) ((9854128988746867 : ℝ) / 20000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((1258914842953644439 : ℝ) / 250000000000000000) ((5035659371814657861 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((4151701171870091487 : ℝ) / 1000000000000000000) ((4151701171870157557 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((507874370838599421 : ℝ) / 250000000000000000) ((2031497483354406237 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((246123858925190787 : ℝ) / 500000000000000000) ((492247717850383647 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((4643948889720473061 : ℝ) / 1000000000000000000) ((1160987222430135301 : ℝ) / 250000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((4643948889720473061 : ℝ) / 1000000000000000000) ((1160987222430135301 : ℝ) / 250000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((70193051610351097 : ℝ) / 100000000000000000) ((701930516103512449 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((340244881307 : ℝ) / 800000000000) ((425306101633753 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-587811928960488131 : ℝ) / 250000000000000000) ((-1175623857920967969 : ℝ) / 500000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-824658599869220777 : ℝ) / 500000000000000000) ((-1649317199738423489 : ℝ) / 1000000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((2192651257306580487 : ℝ) / 1000000000000000000) ((2192651257306604739 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((25761718749999999 : ℝ) / 500000000000000000) ((1319 : ℝ) / 25600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((1014803034486326851 : ℝ) / 500000000000000000) ((1014803034486331127 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((12692964976715881 : ℝ) / 500000000000000000) ((25385929953431871 : ℝ) / 1000000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((10464845549977713 : ℝ) / 500000000000000000) ((20929691099955517 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((2213580948406535913 : ℝ) / 1000000000000000000) ((4323400289856563 : ℝ) / 1953125000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((2213580948406535913 : ℝ) / 1000000000000000000) ((4323400289856563 : ℝ) / 1953125000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((13165331978511321697 : ℝ) / 250000000000000000) ((5266132791404575763 : ℝ) / 100000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-1329429692271643261 : ℝ) / 500000000000000000) ((-1329429692271643119 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-9041468268950517 : ℝ) / 250000000000000000) ((-36165873075801989 : ℝ) / 1000000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((48079985513898741 : ℝ) / 500000000000000000) ((12019996378474713 : ℝ) / 125000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((5275748788507308427 : ℝ) / 100000000000000000) ((26378743942536777667 : ℝ) / 500000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-701930516103512449 : ℝ) / 500000000000000000) ((-70193051610351097 : ℝ) / 50000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((663666152954101 : ℝ) / 250000000000000000) ((331833076477051 : ℝ) / 125000000000000000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((1014803034486326851 : ℝ) / 500000000000000000) ((1014803034486331127 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((653985187667509 : ℝ) / 500000000000000000) ((653985187667513 : ℝ) / 500000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-351292250645589981 : ℝ) / 250000000000000000) ((-702584501291178479 : ℝ) / 500000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-1158506039417537501 : ℝ) / 1000000000000000000) ((-1158506039417535047 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((51598981845655546769 : ℝ) / 1000000000000000000) ((51598981845656020287 : ℝ) / 1000000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((49698179228842952041 : ℝ) / 1000000000000000000) ((24849089614421712783 : ℝ) / 500000000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((49698179228842952041 : ℝ) / 1000000000000000000) ((24849089614421712783 : ℝ) / 500000000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-312849562701170083 : ℝ) / 1000000000000000000) ((-312849562701157659 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((312849562701157659 : ℝ) / 1000000000000000000) ((312849562701170083 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((2061400207928837689 : ℝ) / 1000000000000000000) ((2061400207928854069 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((151765562794565877 : ℝ) / 1000000000000000000) ((151765562794573111 : ℝ) / 1000000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((151765562794565877 : ℝ) / 1000000000000000000) ((151765562794573111 : ℝ) / 1000000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((11516393025175659 : ℝ) / 500000000000000000) ((4606557210070703 : ℝ) / 200000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((106963081205698203 : ℝ) / 1000000000000000000) ((13370385150713747 : ℝ) / 125000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((2213580948406535913 : ℝ) / 500000000000000000) ((4323400289856563 : ℝ) / 976562500000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((671890716852493629 : ℝ) / 1000000000000000000) ((134378143370506609 : ℝ) / 200000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((97356724757273979 : ℝ) / 125000000000000000) ((778853798058243021 : ℝ) / 1000000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((50477033026901143873 : ℝ) / 1000000000000000000) ((50477033026901668587 : ℝ) / 1000000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-50477033026901668587 : ℝ) / 1000000000000000000) ((-50477033026901143873 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((50477033026901143873 : ℝ) / 1000000000000000000) ((50477033026901668587 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((2061400207928837689 : ℝ) / 1000000000000000000) ((2061400207928854069 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((24486770124864214591 : ℝ) / 1000000000000000000) ((6121692531216165927 : ℝ) / 250000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((24486770124864214591 : ℝ) / 1000000000000000000) ((6121692531216165927 : ℝ) / 250000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((58203826549379 : ℝ) / 125000000000000000) ((93126122479007 : ℝ) / 200000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((178221466530768129 : ℝ) / 125000000000000000) ((285154346449229607 : ℝ) / 200000000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((178221466530768129 : ℝ) / 125000000000000000) ((285154346449229607 : ℝ) / 200000000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((507874370838599421 : ℝ) / 250000000000000000) ((2031497483354406237 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((163344074603099 : ℝ) / 500000000000000000) ((326688149206201 : ℝ) / 1000000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((999673311850793799 : ℝ) / 1000000000000000000) ((499836655925396901 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((75857991391871641 : ℝ) / 500000000000000000) ((30343196556750103 : ℝ) / 200000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((25761718749999999 : ℝ) / 500000000000000000) ((1319 : ℝ) / 25600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((18074516569086951 : ℝ) / 500000000000000000) ((36149033138173981 : ℝ) / 1000000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((733847718444989 : ℝ) / 3906250000000000) ((11741563495120281 : ℝ) / 62500000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((733847718444989 : ℝ) / 3906250000000000) ((11741563495120281 : ℝ) / 62500000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((663666152954101 : ℝ) / 500000000000000000) ((331833076477051 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((507874370838599421 : ℝ) / 250000000000000000) ((2031497483354406237 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((1447752879239315247 : ℝ) / 500000000000000000) ((144775287923932439 : ℝ) / 50000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((22920560631273 : ℝ) / 50000000000000000) ((91682242525093 : ℝ) / 200000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((11516393025175659 : ℝ) / 500000000000000000) ((4606557210070703 : ℝ) / 200000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((2639621845871 : ℝ) / 250000000000000000) ((5279243691743 : ℝ) / 500000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((25761718749999999 : ℝ) / 250000000000000000) ((1319 : ℝ) / 12800) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((507874370838599421 : ℝ) / 250000000000000000) ((2031497483354406237 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((3170286815647721 : ℝ) / 62500000000000000) ((50724589050363753 : ℝ) / 1000000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((1539649160950299 : ℝ) / 200000000000000000) ((962280725593987 : ℝ) / 125000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-1921921829342103 : ℝ) / 250000000000000000) ((-7687687317368009 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((701603675767438931 : ℝ) / 500000000000000000) ((87700459470930051 : ℝ) / 62500000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((27910393284350189 : ℝ) / 20000000000000000) ((1395519664217512807 : ℝ) / 1000000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((507874370838599421 : ℝ) / 250000000000000000) ((2031497483354406237 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((163344074603099 : ℝ) / 500000000000000000) ((326688149206201 : ℝ) / 1000000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((999673311850793799 : ℝ) / 1000000000000000000) ((499836655925396901 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((4895754117450417001 : ℝ) / 200000000000000000) ((489575411745050681 : ℝ) / 20000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((5174858050293918891 : ℝ) / 200000000000000000) ((25874290251470046857 : ℝ) / 1000000000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((5174858050293918891 : ℝ) / 200000000000000000) ((25874290251470046857 : ℝ) / 1000000000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_7_point_minus_lo_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((1140244881307 : ℝ) / 800000000000) ((1140244881307 : ℝ) / 800000000000)) :
    RB (E q (v)) ((2221 : ℝ) / 1000000000000000000) ((1119 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((156424781350580229 : ℝ) / 500000000000000000) ((312849562701160643 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712321217740397949 : ℝ) / 500000000000000000) ((1424642435480795899 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-340244881307 : ℝ) / 800000000000) ((-340244881307 : ℝ) / 800000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353920859764686863 : ℝ) / 1000000000000000000) ((70784171952937373 : ℝ) / 200000000000000000) := rb_log h2 (by norm_num) dlower_m_log_352.1 dlower_m_log_358.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((340244881307 : ℝ) / 800000000000) ((340244881307 : ℝ) / 800000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854946130167220277 : ℝ) / 1000000000000000000) ((-34197845206688811 : ℝ) / 40000000000000000) := rb_log h5 (by norm_num) dlower_m_log_354.1 dlower_m_log_354.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604433494965953569 : ℝ) / 500000000000000000) ((604433494965953571 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((99666282569204969 : ℝ) / 100000000000000000) ((9966628256920497 : ℝ) / 10000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354386598816678667 : ℝ) / 1000000000000000000) ((354386598816678669 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_356.1 dlower_m_log_356.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642276226875371021 : ℝ) / 1000000000000000000) ((642276226875371033 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((2221 : ℝ) / 1000000000000000000) ((1119 : ℝ) / 500000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((2221 : ℝ) / 1000000000000000000) ((1119 : ℝ) / 500000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-321420734084504597 : ℝ) / 200000000000000000) ((-1607103670422522807 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-9041468268950517 : ℝ) / 250000000000000000) ((-7233174615160413 : ℝ) / 200000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-14908663051250683 : ℝ) / 500000000000000000) ((-14908663051250681 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1636920996525024351 : ℝ) / 1000000000000000000) ((-1636920996525024169 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((156424781350580229 : ℝ) / 500000000000000000) ((312849562701160643 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((156424781350580229 : ℝ) / 500000000000000000) ((312849562701160643 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_7_point_minus_hi_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((1425306101633753 : ℝ) / 1000000000000000) ((1425306101633753 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-3963 : ℝ) / 1000000000000000000) ((-789 : ℝ) / 200000000000000000) ∧
    RB (Eq q (v)) ((156424781350583549 : ℝ) / 500000000000000000) ((78212390675291821 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712321217740399449 : ℝ) / 500000000000000000) ((1424642435480798899 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425306101633753 : ℝ) / 1000000000000000) ((-425306101633753 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((44240107470586121 : ℝ) / 125000000000000000) ((353920859764688971 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_359.1 dlower_m_log_353.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425306101633753 : ℝ) / 1000000000000000) ((425306101633753 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-106868266270901653 : ℝ) / 125000000000000000) ((-427473065083606611 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_355.1 dlower_m_log_355.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((120886698993190219 : ℝ) / 100000000000000000) ((241773397986380439 : ℝ) / 200000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996662825692045611 : ℝ) / 1000000000000000000) ((498331412846022811 : ℝ) / 500000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((88596649704170193 : ℝ) / 250000000000000000) ((177193299408340387 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_357.1 dlower_m_log_357.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642276226875364837 : ℝ) / 1000000000000000000) ((12845524537507297 : ℝ) / 20000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-3963 : ℝ) / 1000000000000000000) ((-789 : ℝ) / 200000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-3963 : ℝ) / 1000000000000000000) ((-789 : ℝ) / 200000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-200887958802814551 : ℝ) / 125000000000000000) ((-1607103670422516229 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-4520734134475249 : ℝ) / 125000000000000000) ((-36165873075801989 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29817326102501303 : ℝ) / 1000000000000000000) ((-29817326102501299 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1636920996525017711 : ℝ) / 1000000000000000000) ((-204615124565627191 : ℝ) / 125000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((156424781350583549 : ℝ) / 500000000000000000) ((78212390675291821 : ℝ) / 250000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((156424781350583549 : ℝ) / 500000000000000000) ((78212390675291821 : ℝ) / 250000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_7_slab_plus_branch {q v : ℝ} (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280))
    (hv : RB v ((229600127079083589 : ℝ) / 500000000000000000) ((91857759073716483 : ℝ) / 200000000000000000)) :
    RB (phi q (v)) ((14395095329722753 : ℝ) / 31250000000000000) ((460736252867884147 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((-848650639348087209 : ℝ) / 500000000000000000) ((-338710873485672557 : ℝ) / 200000000000000000) ∧
    RB (psi2 q (v)) ((-671129535101431887 : ℝ) / 62500000000000000) ((-525881995966196477 : ℝ) / 50000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((229267790653302339 : ℝ) / 500000000000000000) ((458626135151297259 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((108142240926283517 : ℝ) / 200000000000000000) ((270399872920916411 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-31188695462979319 : ℝ) / 40000000000000000) ((-779519921191090073 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_360.1 dlower_m_log_361.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-614869960353886683 : ℝ) / 1000000000000000000) ((-307353112110259129 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_362.1 dlower_m_log_363.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-165011162353964717 : ℝ) / 1000000000000000000) ((-16464996083720339 : ℝ) / 100000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-34013217604729521 : ℝ) / 250000000000000000) ((-135739652096905529 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-38913444024830217 : ℝ) / 50000000000000000) ((-97259510370648867 : ℝ) / 125000000000000000) := rb_log hv (by norm_num) dlower_m_log_364.1 dlower_m_log_365.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((160505803136568213 : ℝ) / 250000000000000000) ((642529228399698811 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-72774036971191 : ℝ) / 250000000000000000) ((18192663626261 : ℝ) / 62500000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-72774036971191 : ℝ) / 250000000000000000) ((18192663626261 : ℝ) / 62500000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((109246628720697081 : ℝ) / 500000000000000000) ((3433898081907427 : ℝ) / 15625000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-112450379211732727 : ℝ) / 1000000000000000000) ((-112257830624972333 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18543226595342481 : ℝ) / 200000000000000000) ((-92546872144436211 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((125777124464681757 : ℝ) / 1000000000000000000) ((127222605097639117 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((207551055934663149 : ℝ) / 100000000000000000) ((1038515145040917507 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((207551055934663149 : ℝ) / 100000000000000000) ((1038515145040917507 : ℝ) / 500000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((2180425238239219921 : ℝ) / 1000000000000000000) ((1090427919628923407 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((1849113295057777323 : ℝ) / 1000000000000000000) ((1849416086507144323 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((1007384633324249311 : ℝ) / 250000000000000000) ((4030271925764991137 : ℝ) / 1000000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((664401200995875973 : ℝ) / 200000000000000000) ((1661493853648783403 : ℝ) / 500000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((34019989508911991 : ℝ) / 15625000000000000) ((1088849571559208537 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((1144306861860962791 : ℝ) / 1000000000000000000) ((572854189363599691 : ℝ) / 500000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((1144306861860962791 : ℝ) / 1000000000000000000) ((572854189363599691 : ℝ) / 500000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((292368606813958741 : ℝ) / 1000000000000000000) ((292464365102590977 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((3419219977959430653 : ℝ) / 1000000000000000000) ((1710169930515700569 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((210254879324185869 : ℝ) / 1000000000000000000) ((10516896592190799 : ℝ) / 50000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((594281777443819867 : ℝ) / 125000000000000000) ((4756132191625047391 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-668456106832808369 : ℝ) / 500000000000000000) ((-666957179259578899 : ℝ) / 500000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-1102293575613654831 : ℝ) / 1000000000000000000) ((-27492425450906171 : ℝ) / 25000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((52716218354731333 : ℝ) / 250000000000000000) ((52736549387780893 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((4740545274619829979 : ℝ) / 1000000000000000000) ((4742373557938687981 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((909562924751543787 : ℝ) / 250000000000000000) ((3642676539902441141 : ℝ) / 1000000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((909562924751543787 : ℝ) / 250000000000000000) ((3642676539902441141 : ℝ) / 1000000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((2180425238239219921 : ℝ) / 1000000000000000000) ((1090427919628923407 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((1849113295057777323 : ℝ) / 1000000000000000000) ((1849416086507144323 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((1007384633324249311 : ℝ) / 250000000000000000) ((4030271925764991137 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-5367702048960828411 : ℝ) / 1000000000000000000) ((-2673632582871353687 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((25742187499999999 : ℝ) / 500000000000000000) ((33 : ℝ) / 640) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((210254879324185869 : ℝ) / 1000000000000000000) ((10516896592190799 : ℝ) / 50000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((122384903542336649 : ℝ) / 500000000000000000) ((245238066130666507 : ℝ) / 1000000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((25223941967978369 : ℝ) / 125000000000000000) ((101100259997835129 : ℝ) / 500000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-5165910513217001459 : ℝ) / 1000000000000000000) ((-1286266161436759279 : ℝ) / 250000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-5165910513217001459 : ℝ) / 1000000000000000000) ((-1286266161436759279 : ℝ) / 250000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-3602464668582607761 : ℝ) / 500000000000000000) ((-7156032395372299713 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-133184612547997687 : ℝ) / 50000000000000000) ((-331754189813364111 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-112450379211732727 : ℝ) / 1000000000000000000) ((-112257830624972333 : ℝ) / 1000000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((744840112983871 : ℝ) / 2500000000000000) ((299533203723800737 : ℝ) / 1000000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-3453496645985833561 : ℝ) / 500000000000000000) ((-214265599739015593 : ℝ) / 31250000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-1090427919628923407 : ℝ) / 250000000000000000) ((-2180425238239219921 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((165665054321289 : ℝ) / 62500000000000000) ((1089 : ℝ) / 409600) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((210254879324185869 : ℝ) / 1000000000000000000) ((10516896592190799 : ℝ) / 50000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((3150455134156243 : ℝ) / 250000000000000000) ((3161271946215623 : ℝ) / 250000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-109358919157513903 : ℝ) / 25000000000000000) ((-2186726148507532407 : ℝ) / 500000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-450836011486731097 : ℝ) / 125000000000000000) ((-3605533157983595413 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-5256840691932757949 : ℝ) / 500000000000000000) ((-10462032349632094389 : ℝ) / 1000000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-12414556388077230549 : ℝ) / 1000000000000000000) ((-12362762583180377449 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-12414556388077230549 : ℝ) / 1000000000000000000) ((-12362762583180377449 : ℝ) / 1000000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-1038515145040917507 : ℝ) / 500000000000000000) ((-207551055934663149 : ℝ) / 100000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-453774760797991553 : ℝ) / 250000000000000000) ((-452888055521680019 : ℝ) / 250000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-453774760797991553 : ℝ) / 250000000000000000) ((-452888055521680019 : ℝ) / 250000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((452888055521680019 : ℝ) / 250000000000000000) ((453774760797991553 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((410215181668416647 : ℝ) / 125000000000000000) ((131783381463855649 : ℝ) / 40000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((74623304083162183 : ℝ) / 6250000000000000) ((375034556255782183 : ℝ) / 31250000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-5165910513217001459 : ℝ) / 500000000000000000) ((-1286266161436759279 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((18641106583565736669 : ℝ) / 1000000000000000000) ((3750655691902199389 : ℝ) / 200000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((30580835236871685949 : ℝ) / 1000000000000000000) ((30754384259696026801 : ℝ) / 1000000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((90831394243972277 : ℝ) / 5000000000000000) ((2298952709564456169 : ℝ) / 125000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-2298952709564456169 : ℝ) / 125000000000000000) ((-90831394243972277 : ℝ) / 5000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-16072281211882040147 : ℝ) / 1000000000000000000) ((-15855936105639639883 : ℝ) / 1000000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-16072281211882040147 : ℝ) / 1000000000000000000) ((-15855936105639639883 : ℝ) / 1000000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((721398196480459 : ℝ) / 500000000000000000) ((361864374825433 : ℝ) / 250000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((14395095329722753 : ℝ) / 31250000000000000) ((460736252867884147 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((14395095329722753 : ℝ) / 31250000000000000) ((460736252867884147 : ℝ) / 1000000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((52716218354731333 : ℝ) / 250000000000000000) ((52736549387780893 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((98167836304053 : ℝ) / 31250000000000000) ((3152126955929707 : ℝ) / 1000000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((996847873044070293 : ℝ) / 1000000000000000000) ((31151832163695947 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-1809397144128039423 : ℝ) / 1000000000000000000) ((-902920989747703083 : ℝ) / 500000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((25742187499999999 : ℝ) / 500000000000000000) ((33 : ℝ) / 640) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((22419173086373001 : ℝ) / 200000000000000000) ((112287612067043381 : ℝ) / 1000000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-848650639348087209 : ℝ) / 500000000000000000) ((-338710873485672557 : ℝ) / 200000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-848650639348087209 : ℝ) / 500000000000000000) ((-338710873485672557 : ℝ) / 200000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((165665054321289 : ℝ) / 125000000000000000) ((1089 : ℝ) / 819200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((52716218354731333 : ℝ) / 250000000000000000) ((52736549387780893 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((48414601733500131 : ℝ) / 500000000000000000) ((24221306240209639 : ℝ) / 250000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((854955202861177 : ℝ) / 62500000000000000) ((13728768341857173 : ℝ) / 1000000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((452888055521680019 : ℝ) / 250000000000000000) ((453774760797991553 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((410215181668416647 : ℝ) / 125000000000000000) ((131783381463855649 : ℝ) / 40000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((44891597294087133 : ℝ) / 1000000000000000000) ((45230587885596721 : ℝ) / 1000000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((25742187499999999 : ℝ) / 250000000000000000) ((33 : ℝ) / 320) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((52716218354731333 : ℝ) / 250000000000000000) ((52736549387780893 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((488128021246010599 : ℝ) / 1000000000000000000) ((244528636581213599 : ℝ) / 500000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-887687388583193663 : ℝ) / 1000000000000000000) ((-55266837596937763 : ℝ) / 62500000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((929160998845091341 : ℝ) / 1000000000000000000) ((58307373529299399 : ℝ) / 62500000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((34019989508911991 : ℝ) / 7812500000000000) ((4355398286236834147 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((5283719655985826189 : ℝ) / 1000000000000000000) ((5288316262705624531 : ℝ) / 1000000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((52716218354731333 : ℝ) / 250000000000000000) ((52736549387780893 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((98167836304053 : ℝ) / 31250000000000000) ((3152126955929707 : ℝ) / 1000000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((996847873044070293 : ℝ) / 1000000000000000000) ((31151832163695947 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-16021792217608736381 : ℝ) / 1000000000000000000) ((-15805956182029554071 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-671129535101431887 : ℝ) / 62500000000000000) ((-525881995966196477 : ℝ) / 50000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-671129535101431887 : ℝ) / 62500000000000000) ((-525881995966196477 : ℝ) / 50000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_7_slab_plus_lo_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((229600127079083589 : ℝ) / 500000000000000000) ((229600127079083589 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-25343305549011 : ℝ) / 500000000000000000) ((-6335826387251 : ℝ) / 125000000000000000) ∧
    RB (Eq q (v)) ((2076497946261721509 : ℝ) / 1000000000000000000) ((2076497946261721551 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((114634147001303269 : ℝ) / 250000000000000000) ((458536588005213077 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270399872920916411 : ℝ) / 500000000000000000) ((270399872920916411 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-389857595556177253 : ℝ) / 500000000000000000) ((-389857595556177251 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_366.1 dlower_m_log_367.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-30735311211025913 : ℝ) / 50000000000000000) ((-307353112110259129 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_363.1 dlower_m_log_363.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-20626120861479531 : ℝ) / 125000000000000000) ((-82504483445918121 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-3401083505808339 : ℝ) / 25000000000000000) ((-136043340232333553 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-38913444024830217 : ℝ) / 50000000000000000) ((-389134440248302169 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_364.1 dlower_m_log_364.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((321112770132135389 : ℝ) / 500000000000000000) ((642225540264270787 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-25343305549011 : ℝ) / 500000000000000000) ((-6335826387251 : ℝ) / 125000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-25343305549011 : ℝ) / 500000000000000000) ((-6335826387251 : ℝ) / 125000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((109683910038537801 : ℝ) / 500000000000000000) ((43873564015415127 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-28091235709316087 : ℝ) / 250000000000000000) ((-56182471418632171 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-46320216520769451 : ℝ) / 500000000000000000) ((-5790027065096181 : ℝ) / 62500000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((1267273870355367 : ℝ) / 10000000000000000) ((126727387035536739 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2076497946261721509 : ℝ) / 1000000000000000000) ((2076497946261721551 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2076497946261721509 : ℝ) / 1000000000000000000) ((2076497946261721551 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_7_slab_plus_lo_slope {q v : ℝ} (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280))
    (hv : RB v ((229600127079083589 : ℝ) / 500000000000000000) ((229600127079083589 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-49149308235681 : ℝ) / 500000000000000000) ((-153911527289 : ℝ) / 50000000000000000) ∧
    RB (Eq q (v)) ((259498006899640241 : ℝ) / 125000000000000000) ((2077012419765010197 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((229267790653302339 : ℝ) / 500000000000000000) ((229268796970441011 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270399872920916411 : ℝ) / 500000000000000000) ((270399872920916411 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-31188695462979319 : ℝ) / 40000000000000000) ((-779712997318899733 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_360.1 dlower_m_log_368.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-30735311211025913 : ℝ) / 50000000000000000) ((-307353112110259129 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_363.1 dlower_m_log_363.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-165011162353964717 : ℝ) / 1000000000000000000) ((-165006773098381473 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-34013217604729521 : ℝ) / 250000000000000000) ((-27206762589094297 : ℝ) / 200000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-38913444024830217 : ℝ) / 50000000000000000) ((-389134440248302169 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_364.1 dlower_m_log_364.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((321108005038843127 : ℝ) / 500000000000000000) ((128447013510226571 : ℝ) / 200000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-49149308235681 : ℝ) / 500000000000000000) ((-153911527289 : ℝ) / 50000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-49149308235681 : ℝ) / 500000000000000000) ((-153911527289 : ℝ) / 50000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((1094833766459423 : ℝ) / 5000000000000000) ((3433898081907427 : ℝ) / 15625000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-112450379211732727 : ℝ) / 1000000000000000000) ((-22455901404951209 : ℝ) / 200000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18543226595342481 : ℝ) / 200000000000000000) ((-23141185615315257 : ℝ) / 250000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((25250124063034439 : ℝ) / 200000000000000000) ((1272047347808143 : ℝ) / 10000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((259498006899640241 : ℝ) / 125000000000000000) ((2077012419765010197 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((259498006899640241 : ℝ) / 125000000000000000) ((2077012419765010197 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_7_slab_plus_hi_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((91857759073716483 : ℝ) / 200000000000000000) ((91857759073716483 : ℝ) / 200000000000000000)) :
    RB (E q (v)) ((12673436498619 : ℝ) / 250000000000000000) ((50693745994489 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((12975259211579873 : ℝ) / 6250000000000000) ((2076041473852779721 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458625129215628313 : ℝ) / 1000000000000000000) ((229312564607814157 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((108142240926283517 : ℝ) / 200000000000000000) ((108142240926283517 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-194880528640254031 : ℝ) / 250000000000000000) ((-19488052864025403 : ℝ) / 25000000000000000) := rb_log h2 (by norm_num) dlower_m_log_369.1 dlower_m_log_370.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-614869960353886683 : ℝ) / 1000000000000000000) ((-614869960353886681 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_362.1 dlower_m_log_362.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-164652154207129443 : ℝ) / 1000000000000000000) ((-164652154207129437 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-6787458117191383 : ℝ) / 50000000000000000) ((-67874581171913827 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-389038041482595469 : ℝ) / 500000000000000000) ((-97259510370648867 : ℝ) / 125000000000000000) := rb_log hv (by norm_num) dlower_m_log_365.1 dlower_m_log_365.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((160581730155340819 : ℝ) / 250000000000000000) ((160581730155340821 : ℝ) / 250000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((12673436498619 : ℝ) / 250000000000000000) ((50693745994489 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((12673436498619 : ℝ) / 250000000000000000) ((50693745994489 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((13680841418715451 : ℝ) / 62500000000000000) ((13680841418715453 : ℝ) / 62500000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-5617162494793827 : ℝ) / 50000000000000000) ((-22468649979175307 : ℝ) / 200000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18524509614570469 : ℝ) / 200000000000000000) ((-92622548072852339 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((126270914626594871 : ℝ) / 1000000000000000000) ((126270914626594909 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((12975259211579873 : ℝ) / 6250000000000000) ((2076041473852779721 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((12975259211579873 : ℝ) / 6250000000000000) ((2076041473852779721 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_7_slab_plus_hi_slope {q v : ℝ} (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280))
    (hv : RB v ((91857759073716483 : ℝ) / 200000000000000000) ((91857759073716483 : ℝ) / 200000000000000000)) :
    RB (E q (v)) ((1549391859237 : ℝ) / 500000000000000000) ((49142543303387 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((2075528458969079879 : ℝ) / 1000000000000000000) ((2076555069925680767 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((91724824503403983 : ℝ) / 200000000000000000) ((458626135151297259 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((108142240926283517 : ℝ) / 200000000000000000) ((108142240926283517 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-779524309599292791 : ℝ) / 1000000000000000000) ((-779519921191090073 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_371.1 dlower_m_log_361.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-614869960353886683 : ℝ) / 1000000000000000000) ((-614869960353886681 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_362.1 dlower_m_log_362.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-16465434924540611 : ℝ) / 100000000000000000) ((-16464996083720339 : ℝ) / 100000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-67879337743657423 : ℝ) / 500000000000000000) ((-135739652096905529 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-389038041482595469 : ℝ) / 500000000000000000) ((-97259510370648867 : ℝ) / 125000000000000000) := rb_log hv (by norm_num) dlower_m_log_365.1 dlower_m_log_365.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((64231740747787609 : ℝ) / 100000000000000000) ((642336430868285409 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((1549391859237 : ℝ) / 500000000000000000) ((49142543303387 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((1549391859237 : ℝ) / 500000000000000000) ((49142543303387 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((109246628720697081 : ℝ) / 500000000000000000) ((219294257085921081 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-56214334864261827 : ℝ) / 500000000000000000) ((-112257830624972333 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-5793639584641501 : ℝ) / 62500000000000000) ((-92546872144436211 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((62897512043565073 : ℝ) / 500000000000000000) ((12674738494148487 : ℝ) / 100000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2075528458969079879 : ℝ) / 1000000000000000000) ((2076555069925680767 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2075528458969079879 : ℝ) / 1000000000000000000) ((2076555069925680767 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_7_slab_minus_branch {q v : ℝ} (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280))
    (hv : RB v ((1425302396419815667 : ℝ) / 1000000000000000000) ((44540931463990203 : ℝ) / 31250000000000000)) :
    RB (phi q (v)) ((28515346401108723 : ℝ) / 20000000000000000) ((1425776144975814307 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((37275221804173667 : ℝ) / 200000000000000000) ((23668997650535107 : ℝ) / 125000000000000000) ∧
    RB (psi2 q (v)) ((25808979945615462327 : ℝ) / 1000000000000000000) ((1621236859561960523 : ℝ) / 62500000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424637723568253167 : ℝ) / 1000000000000000000) ((71232357331520067 : ℝ) / 50000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-13290931463990203 : ℝ) / 31250000000000000) ((-425302396419815667 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353917552324014333 : ℝ) / 1000000000000000000) ((353924166658893073 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_372.1 dlower_m_log_373.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425302396419815667 : ℝ) / 1000000000000000000) ((13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-427477421040484347 : ℝ) / 500000000000000000) ((-854937418329363553 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_374.1 dlower_m_log_375.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604427485326688943 : ℝ) / 500000000000000000) ((1208879008739861767 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((199319273831284987 : ℝ) / 200000000000000000) ((996729292624625919 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35438399922158389 : ℝ) / 100000000000000000) ((354389198405017087 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_376.1 dlower_m_log_377.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((80275896343925981 : ℝ) / 125000000000000000) ((642345293403042029 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-13392242843721 : ℝ) / 125000000000000000) ((53573810681697 : ℝ) / 500000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-13392242843721 : ℝ) / 125000000000000000) ((53573810681697 : ℝ) / 500000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1610040823964259991 : ℝ) / 1000000000000000000) ((-401042701390969429 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-1809670597197607 : ℝ) / 50000000000000000) ((-564661475143289 : ℝ) / 15625000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29841724129341779 : ℝ) / 1000000000000000000) ((-14896465553710703 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-163988254809360177 : ℝ) / 100000000000000000) ((-816981868335649561 : ℝ) / 500000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((309850886788347963 : ℝ) / 1000000000000000000) ((12633757932515871 : ℝ) / 40000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((309850886788347963 : ℝ) / 1000000000000000000) ((12633757932515871 : ℝ) / 40000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((701928194897393579 : ℝ) / 1000000000000000000) ((701932837700889971 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((425302396419815667 : ℝ) / 1000000000000000000) ((13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-2351268199798481203 : ℝ) / 1000000000000000000) ((-587806808060579037 : ℝ) / 250000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-206167500612635953 : ℝ) / 125000000000000000) ((-1649294394541426177 : ℝ) / 1000000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-679946249582168957 : ℝ) / 500000000000000000) ((-1359700580444014079 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((701601851889077359 : ℝ) / 1000000000000000000) ((140321099931057019 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-2061497998819623009 : ℝ) / 1000000000000000000) ((-1030651216166545719 : ℝ) / 500000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-2061497998819623009 : ℝ) / 1000000000000000000) ((-1030651216166545719 : ℝ) / 500000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((425302396419815667 : ℝ) / 1000000000000000000) ((13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((90441064200219017 : ℝ) / 500000000000000000) ((45222107950204099 : ℝ) / 250000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((110565389952757249 : ℝ) / 20000000000000000) ((5528462147383590527 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((81183705736549381 : ℝ) / 40000000000000000) ((2029619492402144257 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((98540638158382669 : ℝ) / 200000000000000000) ((24635485432141197 : ℝ) / 50000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((503555978899503851 : ℝ) / 100000000000000000) ((2517879478295838591 : ℝ) / 500000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((830276703858052793 : ℝ) / 200000000000000000) ((4152018875622519431 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((253935865155008671 : ℝ) / 125000000000000000) ((507877011374047347 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((492245158574182843 : ℝ) / 1000000000000000000) ((492250277146542253 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((580453584733055851 : ℝ) / 125000000000000000) ((1161067288192265421 : ℝ) / 250000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((580453584733055851 : ℝ) / 125000000000000000) ((1161067288192265421 : ℝ) / 250000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((701928194897393579 : ℝ) / 1000000000000000000) ((701932837700889971 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((425302396419815667 : ℝ) / 1000000000000000000) ((13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-2351268199798481203 : ℝ) / 1000000000000000000) ((-587806808060579037 : ℝ) / 250000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-206167500612635953 : ℝ) / 125000000000000000) ((-1649294394541426177 : ℝ) / 1000000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((547160325624813737 : ℝ) / 250000000000000000) ((1098333547563319807 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((25742187499999999 : ℝ) / 500000000000000000) ((33 : ℝ) / 640) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((81183705736549381 : ℝ) / 40000000000000000) ((2029619492402144257 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((6341628959606853 : ℝ) / 250000000000000000) ((2540534435189561 : ℝ) / 100000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((2614062294116839 : ℝ) / 125000000000000000) ((4189377219999199 : ℝ) / 200000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((110477690042609483 : ℝ) / 50000000000000000) ((2217613981226635609 : ℝ) / 1000000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((110477690042609483 : ℝ) / 50000000000000000) ((2217613981226635609 : ℝ) / 1000000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((52539370719047022869 : ℝ) / 1000000000000000000) ((52783628155224390337 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-133184612547997687 : ℝ) / 50000000000000000) ((-331754189813364111 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-1809670597197607 : ℝ) / 50000000000000000) ((-564661475143289 : ℝ) / 15625000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((9591235082495021 : ℝ) / 100000000000000000) ((96408110930906751 : ℝ) / 1000000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((52635283069871973079 : ℝ) / 1000000000000000000) ((826250566658676517 : ℝ) / 15625000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-1403865675401779941 : ℝ) / 1000000000000000000) ((-701928194897393579 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((165665054321289 : ℝ) / 62500000000000000) ((1089 : ℝ) / 409600) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((81183705736549381 : ℝ) / 40000000000000000) ((2029619492402144257 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((261195842773807 : ℝ) / 200000000000000000) ((654981534072309 : ℝ) / 500000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-1405175638469924559 : ℝ) / 1000000000000000000) ((-1405162369008656193 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-1158577252164757567 : ℝ) / 1000000000000000000) ((-579217420213928399 : ℝ) / 500000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((6434588227213401939 : ℝ) / 125000000000000000) ((5172160142572744029 : ℝ) / 100000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((49575830813495500861 : ℝ) / 1000000000000000000) ((4982087119217915723 : ℝ) / 100000000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((49575830813495500861 : ℝ) / 1000000000000000000) ((4982087119217915723 : ℝ) / 100000000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-12633757932515871 : ℝ) / 40000000000000000) ((-309850886788347963 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((309850886788347963 : ℝ) / 1000000000000000000) ((12633757932515871 : ℝ) / 40000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((1030651216166545719 : ℝ) / 500000000000000000) ((2061497998819623009 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((150303753370492261 : ℝ) / 1000000000000000000) ((76612714213752671 : ℝ) / 500000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((150303753370492261 : ℝ) / 1000000000000000000) ((76612714213752671 : ℝ) / 500000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((22591218277257763 : ℝ) / 1000000000000000000) ((23478031916792563 : ℝ) / 1000000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((104905229060169591 : ℝ) / 1000000000000000000) ((54519149699443593 : ℝ) / 500000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((110477690042609483 : ℝ) / 25000000000000000) ((2217613981226635609 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((26568338363369703 : ℝ) / 40000000000000000) ((33979485236027703 : ℝ) / 50000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((384556844072206083 : ℝ) / 500000000000000000) ((394314002059720623 : ℝ) / 500000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((50344944501639913027 : ℝ) / 1000000000000000000) ((12652374799074649619 : ℝ) / 250000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-12652374799074649619 : ℝ) / 250000000000000000) ((-50344944501639913027 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((50344944501639913027 : ℝ) / 1000000000000000000) ((12652374799074649619 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((1030651216166545719 : ℝ) / 500000000000000000) ((2061497998819623009 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((24421534500866132509 : ℝ) / 1000000000000000000) ((6138048740743987119 : ℝ) / 250000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((24421534500866132509 : ℝ) / 1000000000000000000) ((6138048740743987119 : ℝ) / 250000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((464923635620483 : ℝ) / 1000000000000000000) ((466338128127811 : ℝ) / 1000000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((28515346401108723 : ℝ) / 20000000000000000) ((1425776144975814307 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((28515346401108723 : ℝ) / 20000000000000000) ((1425776144975814307 : ℝ) / 1000000000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((253935865155008671 : ℝ) / 125000000000000000) ((507877011374047347 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((163095641869167 : ℝ) / 500000000000000000) ((20449087212089 : ℝ) / 62500000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((62479550912787911 : ℝ) / 62500000000000000) ((499836904358130833 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((7512728808875831 : ℝ) / 50000000000000000) ((76587723814152609 : ℝ) / 500000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((25742187499999999 : ℝ) / 500000000000000000) ((33 : ℝ) / 640) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((7224306568670343 : ℝ) / 200000000000000000) ((18088266787987819 : ℝ) / 500000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((37275221804173667 : ℝ) / 200000000000000000) ((23668997650535107 : ℝ) / 125000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((37275221804173667 : ℝ) / 200000000000000000) ((23668997650535107 : ℝ) / 125000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((165665054321289 : ℝ) / 125000000000000000) ((1089 : ℝ) / 819200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((253935865155008671 : ℝ) / 125000000000000000) ((507877011374047347 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((1447741588569492099 : ℝ) / 500000000000000000) ((361941042491961851 : ℝ) / 125000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((457712817481781 : ℝ) / 1000000000000000000) ((45911014562983 : ℝ) / 100000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((22591218277257763 : ℝ) / 1000000000000000000) ((23478031916792563 : ℝ) / 1000000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((10340290168029 : ℝ) / 1000000000000000000) ((10779002652421 : ℝ) / 1000000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((25742187499999999 : ℝ) / 250000000000000000) ((33 : ℝ) / 320) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((253935865155008671 : ℝ) / 125000000000000000) ((507877011374047347 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((50685868671935387 : ℝ) / 1000000000000000000) ((5076330983073717 : ℝ) / 100000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((952284538029467 : ℝ) / 125000000000000000) ((7778229897212897 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-1941972401761217 : ℝ) / 250000000000000000) ((-1521499460316663 : ℝ) / 200000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((701601851889077359 : ℝ) / 500000000000000000) ((1403210999310570189 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((27908716283422197 : ℝ) / 20000000000000000) ((697801751004493437 : ℝ) / 500000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((253935865155008671 : ℝ) / 125000000000000000) ((507877011374047347 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((163095641869167 : ℝ) / 500000000000000000) ((20449087212089 : ℝ) / 62500000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((62479550912787911 : ℝ) / 62500000000000000) ((499836904358130833 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((24413544131444352477 : ℝ) / 1000000000000000000) ((12272093125491190747 : ℝ) / 500000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((25808979945615462327 : ℝ) / 1000000000000000000) ((1621236859561960523 : ℝ) / 62500000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((25808979945615462327 : ℝ) / 1000000000000000000) ((1621236859561960523 : ℝ) / 62500000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_7_slab_minus_lo_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((1425302396419815667 : ℝ) / 1000000000000000000) ((1425302396419815667 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((7637960654541 : ℝ) / 1000000000000000000) ((7637960654559 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((78210340216007551 : ℝ) / 250000000000000000) ((78210340216007597 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((284927746053372313 : ℝ) / 200000000000000000) ((712319365133430783 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425302396419815667 : ℝ) / 1000000000000000000) ((-425302396419815667 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353918258958575569 : ℝ) / 1000000000000000000) ((88479564739643893 : ℝ) / 250000000000000000) := rb_log h2 (by norm_num) dlower_m_log_378.1 dlower_m_log_379.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425302396419815667 : ℝ) / 1000000000000000000) ((425302396419815667 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-427477421040484347 : ℝ) / 500000000000000000) ((-213738710520242173 : ℝ) / 250000000000000000) := rb_log h5 (by norm_num) dlower_m_log_374.1 dlower_m_log_374.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208873101039544261 : ℝ) / 1000000000000000000) ((604436550519772133 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996667864057607233 : ℝ) / 1000000000000000000) ((249166966014401811 : ℝ) / 250000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35438399922158389 : ℝ) / 100000000000000000) ((88595999805395973 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_376.1 dlower_m_log_376.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642283864836023341 : ℝ) / 1000000000000000000) ((321141932418011677 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((7637960654541 : ℝ) / 1000000000000000000) ((7637960654559 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((7637960654541 : ℝ) / 1000000000000000000) ((7637960654559 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-321422358942093689 : ℝ) / 200000000000000000) ((-803555897355234133 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-361659671363481 : ℝ) / 10000000000000000) ((-18082983568174049 : ℝ) / 500000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-372717545646077 : ℝ) / 12500000000000000) ((-14908701825843079 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-327385839672430921 : ℝ) / 200000000000000000) ((-204616149795269303 : ℝ) / 125000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((78210340216007551 : ℝ) / 250000000000000000) ((78210340216007597 : ℝ) / 250000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((78210340216007551 : ℝ) / 250000000000000000) ((78210340216007597 : ℝ) / 250000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_7_slab_minus_lo_slope {q v : ℝ} (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280))
    (hv : RB v ((1425302396419815667 : ℝ) / 1000000000000000000) ((1425302396419815667 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-4378719155123 : ℝ) / 50000000000000000) ((2571471597527 : ℝ) / 25000000000000000) ∧
    RB (Eq q (v)) ((309857814521534397 : ℝ) / 1000000000000000000) ((157910335865570473 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424637723568253167 : ℝ) / 1000000000000000000) ((1424639736202530511 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425302396419815667 : ℝ) / 1000000000000000000) ((-425302396419815667 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353917552324014333 : ℝ) / 1000000000000000000) ((353918965057105977 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_372.1 dlower_m_log_380.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425302396419815667 : ℝ) / 1000000000000000000) ((425302396419815667 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-427477421040484347 : ℝ) / 500000000000000000) ((-213738710520242173 : ℝ) / 250000000000000000) := rb_log h5 (by norm_num) dlower_m_log_374.1 dlower_m_log_374.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((48354895776199321 : ℝ) / 40000000000000000) ((1208873807138074671 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((124576341691579881 : ℝ) / 125000000000000000) ((199345000773432721 : ℝ) / 200000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35438399922158389 : ℝ) / 100000000000000000) ((88595999805395973 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_376.1 dlower_m_log_376.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((160556683577763789 : ℝ) / 250000000000000000) ((128468200929115943 : ℝ) / 200000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-4378719155123 : ℝ) / 50000000000000000) ((2571471597527 : ℝ) / 25000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-4378719155123 : ℝ) / 50000000000000000) ((2571471597527 : ℝ) / 25000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1610033896231073557 : ℝ) / 1000000000000000000) ((-320838785434853361 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-1809670597197607 : ℝ) / 50000000000000000) ((-36138522386884233 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29841724129341779 : ℝ) / 1000000000000000000) ((-14896543039394073 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-204984452545051917 : ℝ) / 125000000000000000) ((-1633987013253054951 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((309857814521534397 : ℝ) / 1000000000000000000) ((157910335865570473 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((309857814521534397 : ℝ) / 1000000000000000000) ((157910335865570473 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_7_slab_minus_hi_center {q v : ℝ} (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hv : RB v ((44540931463990203 : ℝ) / 31250000000000000) ((44540931463990203 : ℝ) / 31250000000000000)) :
    RB (E q (v)) ((-7637896899593 : ℝ) / 1000000000000000000) ((-954737112447 : ℝ) / 125000000000000000) ∧
    RB (Eq q (v)) ((9776805138937037 : ℝ) / 31250000000000000) ((312857764445985367 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((663666152954101 : ℝ) / 1000000000000000000) ((331833076477051 : ℝ) / 500000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712323070347366197 : ℝ) / 500000000000000000) ((284929228138946479 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-13290931463990203 : ℝ) / 31250000000000000) ((-13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((707846921128071 : ℝ) / 2000000000000000) ((176961730282017751 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_381.1 dlower_m_log_382.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((13290931463990203 : ℝ) / 31250000000000000) ((13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-170987483665872711 : ℝ) / 200000000000000000) ((-854937418329363553 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_375.1 dlower_m_log_375.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208860878893399053 : ℝ) / 1000000000000000000) ((1208860878893399057 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((498328893691743147 : ℝ) / 500000000000000000) ((31145555855733947 : ℝ) / 31250000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70877839681003417 : ℝ) / 200000000000000000) ((354389198405017087 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_377.1 dlower_m_log_377.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642268588978469207 : ℝ) / 1000000000000000000) ((642268588978469219 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-7637896899593 : ℝ) / 1000000000000000000) ((-954737112447 : ℝ) / 125000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-7637896899593 : ℝ) / 1000000000000000000) ((-954737112447 : ℝ) / 125000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1607095546226479721 : ℝ) / 1000000000000000000) ((-1607095546226479543 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-1319 : ℝ) / 25600) ((-25761718749999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-7233155803149049 : ℝ) / 200000000000000000) ((-36165779015745243 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-931789017303747 : ℝ) / 31250000000000000) ((-14908624276859951 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-13095302358241597 : ℝ) / 8000000000000000) ((-327382558956039889 : ℝ) / 200000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((9776805138937037 : ℝ) / 31250000000000000) ((312857764445985367 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((9776805138937037 : ℝ) / 31250000000000000) ((312857764445985367 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_7_slab_minus_hi_slope {q v : ℝ} (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280))
    (hv : RB v ((44540931463990203 : ℝ) / 31250000000000000) ((44540931463990203 : ℝ) / 31250000000000000)) :
    RB (E q (v)) ((-25712416476471 : ℝ) / 250000000000000000) ((87582431500523 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((38734280971124467 : ℝ) / 125000000000000000) ((63167409138079761 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((165665054321289 : ℝ) / 250000000000000000) ((1089 : ℝ) / 1638400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((356161283499030999 : ℝ) / 250000000000000000) ((71232357331520067 : ℝ) / 50000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-13290931463990203 : ℝ) / 31250000000000000) ((-13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((35392275393314989 : ℝ) / 100000000000000000) ((353924166658893073 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_383.1 dlower_m_log_373.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((13290931463990203 : ℝ) / 31250000000000000) ((13290931463990203 : ℝ) / 31250000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-170987483665872711 : ℝ) / 200000000000000000) ((-854937418329363553 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_375.1 dlower_m_log_375.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208860172262513443 : ℝ) / 1000000000000000000) ((302215396247064157 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996600657433268819 : ℝ) / 1000000000000000000) ((996714926618196243 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70877839681003417 : ℝ) / 200000000000000000) ((354389198405017087 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_377.1 dlower_m_log_377.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((160552864757062933 : ℝ) / 250000000000000000) ((321162864106589579 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-25712416476471 : ℝ) / 250000000000000000) ((87582431500523 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-25712416476471 : ℝ) / 250000000000000000) ((87582431500523 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1610017618208193361 : ℝ) / 1000000000000000000) ((-802088854093187843 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-33 : ℝ) / 640) ((-25742187499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-18096611840229781 : ℝ) / 500000000000000000) ((-564661475143289 : ℝ) / 15625000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-7460392226190159 : ℝ) / 250000000000000000) ((-14896465553710703 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1639859187112953997 : ℝ) / 1000000000000000000) ((-408492659823449273 : ℝ) / 250000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((38734280971124467 : ℝ) / 125000000000000000) ((63167409138079761 : ℝ) / 200000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((38734280971124467 : ℝ) / 125000000000000000) ((63167409138079761 : ℝ) / 200000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_7_point_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((25761718749999999 : ℝ) / 1000000000000000000) ((1319 : ℝ) / 51200))
    (hplus : RB (vPlus q) ((459244524763373 : ℝ) / 1000000000000000) ((28702782797711 : ℝ) / 62500000000000))
    (hminus : RB (vMinus q) ((1140244881307 : ℝ) / 800000000000) ((1425306101633753 : ℝ) / 1000000000000000)) :
RB (Lam q) ((917215273064458849 : ℝ) / 500000000000000000) ((1834430546128929141 : ℝ) / 1000000000000000000) ∧
    RB (lam1 q) ((3046180097056477 : ℝ) / 1000000000000000000) ((3046180097225383 : ℝ) / 1000000000000000000) ∧
    RB (lam2 q) ((164710843432903499 : ℝ) / 2500000000000000) ((32942168686584291349 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_point hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_7_point_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_7_point_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((241270520397986591 : ℝ) / 250000000000000000) ((48254104079597619 : ℝ) / 50000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((941645602815737541 : ℝ) / 500000000000000000) ((376658241126310439 : ℝ) / 200000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((3650200491437360729 : ℝ) / 100000000000000000) ((18251002457188525527 : ℝ) / 500000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((917215273064458849 : ℝ) / 500000000000000000) ((1834430546128929141 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-1788359335893698891 : ℝ) / 500000000000000000) ((-3576718671787375467 : ℝ) / 1000000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((3579764851884454259 : ℝ) / 1000000000000000000) ((71595297037692017 : ℝ) / 20000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((3046180097056477 : ℝ) / 1000000000000000000) ((3046180097225383 : ℝ) / 1000000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((10460671147328412037 : ℝ) / 1000000000000000000) ((10460671147328477313 : ℝ) / 1000000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-3706128981161288301 : ℝ) / 500000000000000000) ((-3706128981161288283 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-6979720117157278837 : ℝ) / 500000000000000000) ((-1744930029289248253 : ℝ) / 125000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-3498769086986145637 : ℝ) / 1000000000000000000) ((-3498769086985508711 : ℝ) / 1000000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((69383106460147545237 : ℝ) / 1000000000000000000) ((69383106460154091409 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((164710843432903499 : ℝ) / 2500000000000000) ((32942168686584291349 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((917215273064458849 : ℝ) / 500000000000000000) ((1834430546128929141 : ℝ) / 1000000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((3046180097056477 : ℝ) / 1000000000000000000) ((3046180097225383 : ℝ) / 1000000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((164710843432903499 : ℝ) / 2500000000000000) ((32942168686584291349 : ℝ) / 500000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

theorem dlower_m_7_slab_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((25742187499999999 : ℝ) / 1000000000000000000) ((33 : ℝ) / 1280))
    (hplus : RB (vPlus q) ((229600127079083589 : ℝ) / 500000000000000000) ((91857759073716483 : ℝ) / 200000000000000000))
    (hminus : RB (vMinus q) ((1425302396419815667 : ℝ) / 1000000000000000000) ((44540931463990203 : ℝ) / 31250000000000000)) :
RB (Lam q) ((1834263725716744559 : ℝ) / 1000000000000000000) ((458649343732347649 : ℝ) / 250000000000000000) ∧
    RB (lam1 q) ((-1935683466637919 : ℝ) / 500000000000000000) ((9966708938252211 : ℝ) / 1000000000000000000) ∧
    RB (lam2 q) ((65521266723731085129 : ℝ) / 1000000000000000000) ((16562079714485721011 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_7_slab hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_7_slab_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_7_slab_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((965031067187552003 : ℝ) / 1000000000000000000) ((965133094424686211 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((23499130955615389 : ℝ) / 12500000000000000) ((943326629950227637 : ℝ) / 500000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((36326619864939391867 : ℝ) / 1000000000000000000) ((229236639466339241 : ℝ) / 6250000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((1834263725716744559 : ℝ) / 1000000000000000000) ((458649343732347649 : ℝ) / 250000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-3577112060489157951 : ℝ) / 1000000000000000000) ((-715265062884214177 : ℝ) / 200000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((3573240693555882113 : ℝ) / 1000000000000000000) ((448286502919915387 : ℝ) / 125000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((-1935683466637919 : ℝ) / 500000000000000000) ((9966708938252211 : ℝ) / 1000000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((10459321559312195121 : ℝ) / 1000000000000000000) ((1046202087838711797 : ℝ) / 100000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-3706340691406366971 : ℝ) / 500000000000000000) ((-1852958643520032229 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-111881275963896473 : ℝ) / 8000000000000000) ((-6966866851106670381 : ℝ) / 500000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-881459484043716001 : ℝ) / 250000000000000000) ((-433964102978277849 : ℝ) / 125000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((69047104659905949133 : ℝ) / 1000000000000000000) ((17430007920442276709 : ℝ) / 250000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((65521266723731085129 : ℝ) / 1000000000000000000) ((16562079714485721011 : ℝ) / 250000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((1834263725716744559 : ℝ) / 1000000000000000000) ((458649343732347649 : ℝ) / 250000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((-1935683466637919 : ℝ) / 500000000000000000) ((9966708938252211 : ℝ) / 1000000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((65521266723731085129 : ℝ) / 1000000000000000000) ((16562079714485721011 : ℝ) / 250000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

end EP1038.DLowerCert
