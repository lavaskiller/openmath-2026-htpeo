import LeanProject.ScalarIntervals

/-! Rational bounds for the actual pilot reference data. -/
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

noncomputable def certSp (k v : ℝ) : ℝ :=
  D0a (r1A k) * (1 - (qa (r1A k)) ^ 2 / v ^ 2) / ((k + 1) * certEprime k (r1A k) v)
noncomputable def certSm (k v : ℝ) : ℝ :=
  D0a (r1A k) * (1 - (qa (r1A k)) ^ 2 / v ^ 2) /
    ((k + 1) * (k / (k + 1) * (1 / (v - 1) - 1 / (v - (qa (r1A k)) ^ 2)) + 1 / v))
noncomputable def certBp (k vp vm : ℝ) : ℝ :=
  certSp k vp * (4 * (qa (r1A k) / vp) / (1 - (qa (r1A k) / vp) ^ 2)) +
  certSm k vm * (4 * (qa (r1A k) / vm) / (1 - (qa (r1A k) / vm) ^ 2))
noncomputable def certXi (k vp vm : ℝ) : ℝ :=
  certSp k vp * (2 * (qa (r1A k) / vp) / (1 - qa (r1A k) / vp)) +
  certSm k vm * (2 * (qa (r1A k) / vm) / (1 - qa (r1A k) / vm))
noncomputable def certApi (k : ℝ) : ℝ := 1 + 2 * k * qa (r1A k) / (1 + qa (r1A k))
noncomputable def certWidth (k vp vm : ℝ) : ℝ :=
  D0a (r1A k) * (vm - vp) * (1 - (qa (r1A k)) ^ 2 / (vp * vm))

set_option maxHeartbeats 1000000 in
theorem pilot_rational_bounds {k vp vm : ℝ} (hk : k ∈ pilotSlab)
    (hvp : RB vp (2027 / 5000) (4057 / 10000))
    (hvm : RB vm (131 / 100) (6551 / 5000)) :
    RB (certSp k vp) ((1683 : ℝ) / 500) ((857 : ℝ) / 250) ∧
    RB (certSm k vm) ((733 : ℝ) / 2500) ((367 : ℝ) / 1250) ∧
    RB (certBp k vp vm) ((6379 : ℝ) / 10000) ((6501 : ℝ) / 10000) ∧
    RB (certXi k vp vm) ((3333 : ℝ) / 10000) ((1699 : ℝ) / 5000) ∧
    RB (certApi k) ((533 : ℝ) / 500) ((21321 : ℝ) / 20000) ∧
    RB (certWidth k vp vm) ((17417 : ℝ) / 10000) ((4357 : ℝ) / 2500) ∧
    RB (qa (r1A k) / vp) ((4603 : ℝ) / 100000) ((461 : ℝ) / 10000) ∧
    RB (qa (r1A k) / vm) ((57 : ℝ) / 4000) ((1427 : ℝ) / 100000) := by
  have hq := pilot_q_bounds hk
  have hd := pilot_D0_bounds hk
  have hA := pilot_A_bounds hk
  let z1 : ℝ := qa (r1A k) * qa (r1A k)
  have h1 : RB z1 ((348867 : ℝ) / 1000000000) ((349167 : ℝ) / 1000000000) :=
    rb_widen (rb_mul hq hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := vp - z1
  have h2 : RB z2 ((405050833 : ℝ) / 1000000000) ((405351133 : ℝ) / 1000000000) :=
    rb_widen (rb_sub hvp h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (1 : ℝ) / z2
  have h3 : RB z3 ((38546827 : ℝ) / 15625000) ((617206483 : ℝ) / 250000000) :=
    rb_widen (rb_div (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (1 : ℝ) - vp
  have h4 : RB z4 ((5943 : ℝ) / 10000) ((2973 : ℝ) / 5000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hvp) (by norm_num) (by norm_num)
  let z5 : ℝ := (1 : ℝ) / z4
  have h5 : RB z5 ((420450723 : ℝ) / 250000000) ((84132593 : ℝ) / 50000000) :=
    rb_widen (rb_div (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := z3 + z5
  have h6 : RB z6 ((207439991 : ℝ) / 50000000) ((129733681 : ℝ) / 31250000) :=
    rb_widen (rb_add h3 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := k / (k + 1) * z6
  have h7 : RB z7 ((1333542799 : ℝ) / 500000000) ((53378261 : ℝ) / 20000000) :=
    rb_widen (rb_mul hA h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (1 : ℝ) / vp
  have h8 : RB z8 ((2464875523 : ℝ) / 1000000000) ((616674889 : ℝ) / 250000000) :=
    rb_widen (rb_div (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hvp (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z9 : ℝ := z7 - z8
  have h9 : RB z9 ((100193021 : ℝ) / 500000000) ((204037527 : ℝ) / 1000000000) :=
    rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := vm - (1 : ℝ)
  have h10 : RB z10 ((31 : ℝ) / 100) ((1551 : ℝ) / 5000) :=
    rb_widen (rb_sub hvm (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z11 : ℝ := (1 : ℝ) / z10
  have h11 : RB z11 ((3223726627 : ℝ) / 1000000000) ((806451613 : ℝ) / 250000000) :=
    rb_widen (rb_div (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := vm - z1
  have h12 : RB z12 ((1309650833 : ℝ) / 1000000000) ((1309851133 : ℝ) / 1000000000) :=
    rb_widen (rb_sub hvm h1) (by norm_num) (by norm_num)
  let z13 : ℝ := (1 : ℝ) / z12
  have h13 : RB z13 ((152689107 : ℝ) / 200000000) ((763562299 : ℝ) / 1000000000) :=
    rb_widen (rb_div (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z14 : ℝ := z11 - z13
  have h14 : RB z14 ((307520541 : ℝ) / 125000000) ((2462360917 : ℝ) / 1000000000) :=
    rb_widen (rb_sub h11 h13) (by norm_num) (by norm_num)
  let z15 : ℝ := k / (k + 1) * z14
  have h15 : RB z15 ((158153421 : ℝ) / 100000000) ((316601823 : ℝ) / 200000000) :=
    rb_widen (rb_mul hA h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (1 : ℝ) / vm
  have h16 : RB z16 ((763242253 : ℝ) / 1000000000) ((763358779 : ℝ) / 1000000000) :=
    rb_widen (rb_div (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hvm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z17 : ℝ := z15 + z16
  have h17 : RB z17 ((2344776463 : ℝ) / 1000000000) ((1173183947 : ℝ) / 500000000) :=
    rb_widen (rb_add h15 h16) (by norm_num) (by norm_num)
  let z18 : ℝ := qa (r1A k) / vp
  have h18 : RB z18 ((9207789 : ℝ) / 200000000) ((11523187 : ℝ) / 250000000) :=
    rb_widen (rb_div hq hvp (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z19 : ℝ := qa (r1A k) / vm
  have h19 : RB z19 ((7127919 : ℝ) / 500000000) ((14264123 : ℝ) / 1000000000) :=
    rb_widen (rb_div hq hvm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := vp * vp
  have h20 : RB z20 ((4108729 : ℝ) / 25000000) ((16459249 : ℝ) / 100000000) :=
    rb_widen (rb_mul hvp hvp (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := z1 / z20
  have h21 : RB z21 ((105979 : ℝ) / 50000000) ((8299 : ℝ) / 3906250) :=
    rb_widen (rb_div h1 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := (1 : ℝ) - z21
  have h22 : RB z22 ((3897951 : ℝ) / 3906250) ((49894021 : ℝ) / 50000000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h21) (by norm_num) (by norm_num)
  let z23 : ℝ := D0a (r1A k) * z22
  have h23 : RB z23 ((480801591 : ℝ) / 250000000) ((60101371 : ℝ) / 31250000) :=
    rb_widen (rb_mul hd h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := k + (1 : ℝ)
  have h24 : RB z24 ((14 : ℝ) / 5) ((14001 : ℝ) / 5000) :=
    rb_widen (rb_add hk (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z25 : ℝ := z24 * z9
  have h25 : RB z25 ((561080917 : ℝ) / 1000000000) ((142836471 : ℝ) / 250000000) :=
    rb_widen (rb_mul h24 h9 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := z23 / z25
  have h26 : RB z26 ((3366098221 : ℝ) / 1000000000) ((856936947 : ℝ) / 250000000) :=
    rb_widen (rb_div h23 h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := vm * vm
  have h27 : RB z27 ((17161 : ℝ) / 10000) ((42915601 : ℝ) / 25000000) :=
    rb_widen (rb_mul hvm hvm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := z1 / z27
  have h28 : RB z28 ((50807 : ℝ) / 250000000) ((101733 : ℝ) / 500000000) :=
    rb_widen (rb_div h1 h27 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (1 : ℝ) - z28
  have h29 : RB z29 ((499898267 : ℝ) / 500000000) ((249949193 : ℝ) / 250000000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := D0a (r1A k) * z29
  have h30 : RB z30 ((1926908859 : ℝ) / 1000000000) ((1926937313 : ℝ) / 1000000000) :=
    rb_widen (rb_mul hd h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := k + (1 : ℝ)
  have h31 : RB z31 ((14 : ℝ) / 5) ((14001 : ℝ) / 5000) :=
    rb_widen (rb_add hk (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z32 : ℝ := z31 * z17
  have h32 : RB z32 ((410335881 : ℝ) / 62500000) ((6570299377 : ℝ) / 1000000000) :=
    rb_widen (rb_mul h31 h17 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := z30 / z32
  have h33 : RB z33 ((58655131 : ℝ) / 200000000) ((293500003 : ℝ) / 1000000000) :=
    rb_widen (rb_div h30 h32 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := (4 : ℝ) * z18
  have h34 : RB z34 ((9207789 : ℝ) / 50000000) ((11523187 : ℝ) / 62500000) :=
    rb_widen (rb_mul (show RB ((4 : ℝ)) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := z18 * z18
  have h35 : RB z35 ((66237 : ℝ) / 31250000) ((1062271 : ℝ) / 500000000) :=
    rb_widen (rb_mul h18 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z36 : ℝ := (1 : ℝ) - z35
  have h36 : RB z36 ((498937729 : ℝ) / 500000000) ((31183763 : ℝ) / 31250000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := z34 / z36
  have h37 : RB z37 ((92273471 : ℝ) / 500000000) ((18476353 : ℝ) / 100000000) :=
    rb_widen (rb_div h34 h36 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := z26 * z37
  have h38 : RB z38 ((621203133 : ℝ) / 1000000000) ((316661391 : ℝ) / 500000000) :=
    rb_widen (rb_mul h26 h37 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z39 : ℝ := (4 : ℝ) * z19
  have h39 : RB z39 ((7127919 : ℝ) / 125000000) ((14264123 : ℝ) / 250000000) :=
    rb_widen (rb_mul (show RB ((4 : ℝ)) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z40 : ℝ := z19 * z19
  have h40 : RB z40 ((50807 : ℝ) / 250000000) ((101733 : ℝ) / 500000000) :=
    rb_widen (rb_mul h19 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (1 : ℝ) - z40
  have h41 : RB z41 ((499898267 : ℝ) / 500000000) ((249949193 : ℝ) / 250000000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h40) (by norm_num) (by norm_num)
  let z42 : ℝ := z39 / z41
  have h42 : RB z42 ((57034943 : ℝ) / 1000000000) ((7133513 : ℝ) / 125000000) :=
    rb_widen (rb_div h39 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := z33 * z42
  have h43 : RB z43 ((209087 : ℝ) / 12500000) ((16749489 : ℝ) / 1000000000) :=
    rb_widen (rb_mul h33 h42 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := z38 + z43
  have h44 : RB z44 ((637930093 : ℝ) / 1000000000) ((650072271 : ℝ) / 1000000000) :=
    rb_widen (rb_add h38 h43) (by norm_num) (by norm_num)
  let z45 : ℝ := (2 : ℝ) * z18
  have h45 : RB z45 ((9207789 : ℝ) / 100000000) ((11523187 : ℝ) / 125000000) :=
    rb_widen (rb_mul (show RB ((2 : ℝ)) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z46 : ℝ := (1 : ℝ) - z18
  have h46 : RB z46 ((238476813 : ℝ) / 250000000) ((190792211 : ℝ) / 200000000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h18) (by norm_num) (by norm_num)
  let z47 : ℝ := z45 / z46
  have h47 : RB z47 ((24130411 : ℝ) / 250000000) ((19327979 : ℝ) / 200000000) :=
    rb_widen (rb_div h45 h46 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := z26 * z47
  have h48 : RB z48 ((162450667 : ℝ) / 500000000) ((331257187 : ℝ) / 1000000000) :=
    rb_widen (rb_mul h26 h47 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := (2 : ℝ) * z19
  have h49 : RB z49 ((7127919 : ℝ) / 250000000) ((14264123 : ℝ) / 500000000) :=
    rb_widen (rb_mul (show RB ((2 : ℝ)) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := (1 : ℝ) - z19
  have h50 : RB z50 ((985735877 : ℝ) / 1000000000) ((492872081 : ℝ) / 500000000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z51 : ℝ := z49 / z50
  have h51 : RB z51 ((7231003 : ℝ) / 250000000) ((5788213 : ℝ) / 200000000) :=
    rb_widen (rb_div h49 h50 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z52 : ℝ := z33 * z51
  have h52 : RB z52 ((2120677 : ℝ) / 250000000) ((8494203 : ℝ) / 1000000000) :=
    rb_widen (rb_mul h33 h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := z48 + z52
  have h53 : RB z53 ((166692021 : ℝ) / 500000000) ((33975139 : ℝ) / 100000000) :=
    rb_widen (rb_add h48 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (2 : ℝ) * k
  have h54 : RB z54 ((18 : ℝ) / 5) ((9001 : ℝ) / 2500) :=
    rb_widen (rb_mul (show RB ((2 : ℝ)) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := z54 * qa (r1A k)
  have h55 : RB z55 ((84051 : ℝ) / 1250000) ((2691083 : ℝ) / 40000000) :=
    rb_widen (rb_mul h54 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z56 : ℝ := (1 : ℝ) + qa (r1A k)
  have h56 : RB z56 ((509339 : ℝ) / 500000) ((509343 : ℝ) / 500000) :=
    rb_widen (rb_add (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z57 : ℝ := z55 / z56
  have h57 : RB z57 ((13201477 : ℝ) / 200000000) ((13208703 : ℝ) / 200000000) :=
    rb_widen (rb_div h55 h56 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z58 : ℝ := (1 : ℝ) + z57
  have h58 : RB z58 ((213201477 : ℝ) / 200000000) ((213208703 : ℝ) / 200000000) :=
    rb_widen (rb_add (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h57) (by norm_num) (by norm_num)
  let z59 : ℝ := vm - vp
  have h59 : RB z59 ((9043 : ℝ) / 10000) ((1131 : ℝ) / 1250) :=
    rb_widen (rb_sub hvm hvp) (by norm_num) (by norm_num)
  let z60 : ℝ := D0a (r1A k) * z59
  have h60 : RB z60 ((871429147 : ℝ) / 500000000) ((21798091 : ℝ) / 12500000) :=
    rb_widen (rb_mul hd h59 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z61 : ℝ := vp * vm
  have h61 : RB z61 ((265537 : ℝ) / 500000) ((26577407 : ℝ) / 50000000) :=
    rb_widen (rb_mul hvp hvm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z62 : ℝ := z1 / z61
  have h62 : RB z62 ((328161 : ℝ) / 500000000) ((328737 : ℝ) / 500000000) :=
    rb_widen (rb_div h1 h61 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z63 : ℝ := (1 : ℝ) - z62
  have h63 : RB z63 ((499671263 : ℝ) / 500000000) ((499671839 : ℝ) / 500000000) :=
    rb_widen (rb_sub (show RB ((1 : ℝ)) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := z60 * z63
  have h64 : RB z64 ((1741712409 : ℝ) / 1000000000) ((348540551 : ℝ) / 200000000) :=
    rb_widen (rb_mul h60 h63 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · have h := rb_widen h26 (show ((1683 : ℝ) / 500) ≤ ((3366098221 : ℝ) / 1000000000) by norm_num) (show ((856936947 : ℝ) / 250000000) ≤ ((857 : ℝ) / 250) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h
  · have h := rb_widen h33 (show ((733 : ℝ) / 2500) ≤ ((58655131 : ℝ) / 200000000) by norm_num) (show ((293500003 : ℝ) / 1000000000) ≤ ((367 : ℝ) / 1250) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h
  · have h := rb_widen h44 (show ((6379 : ℝ) / 10000) ≤ ((637930093 : ℝ) / 1000000000) by norm_num) (show ((650072271 : ℝ) / 1000000000) ≤ ((6501 : ℝ) / 10000) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h
  · have h := rb_widen h53 (show ((3333 : ℝ) / 10000) ≤ ((166692021 : ℝ) / 500000000) by norm_num) (show ((33975139 : ℝ) / 100000000) ≤ ((1699 : ℝ) / 5000) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h
  · have h := rb_widen h58 (show ((533 : ℝ) / 500) ≤ ((213201477 : ℝ) / 200000000) by norm_num) (show ((213208703 : ℝ) / 200000000) ≤ ((21321 : ℝ) / 20000) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h
  · have h := rb_widen h64 (show ((17417 : ℝ) / 10000) ≤ ((1741712409 : ℝ) / 1000000000) by norm_num) (show ((348540551 : ℝ) / 200000000) ≤ ((4357 : ℝ) / 2500) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h
  · have h := rb_widen h18 (show ((4603 : ℝ) / 100000) ≤ ((9207789 : ℝ) / 200000000) by norm_num) (show ((11523187 : ℝ) / 250000000) ≤ ((461 : ℝ) / 10000) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h
  · have h := rb_widen h19 (show ((57 : ℝ) / 4000) ≤ ((7127919 : ℝ) / 500000000) by norm_num) (show ((14264123 : ℝ) / 1000000000) ≤ ((1427 : ℝ) / 100000) by norm_num)
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, certSp, certSm, certBp, certXi, certApi, certWidth, certEprime, ← sq] using h

end EP1038.ReferenceCert
