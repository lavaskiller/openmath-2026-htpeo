import LeanProject.DLowerMLogs
import LeanProject.DLowerMNumeric05
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_param_8_point {q : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800)) :
    RB (delta (q)) ((642085828657352319 : ℝ) / 1000000000000000000) ((160521457164338081 : ℝ) / 250000000000000000) ∧
    RB (delta1 (q)) ((-974792475820577261 : ℝ) / 500000000000000000) ((-1949584951641154519 : ℝ) / 1000000000000000000) ∧
    RB (delta2 (q)) ((1900440741832821403 : ℝ) / 1000000000000000000) ((190044074183282141 : ℝ) / 100000000000000000) ∧
    RB (aval (q)) ((206082666848199059 : ℝ) / 250000000000000000) ((10304133342409953 : ℝ) / 12500000000000000) ∧
    RB (aval1 (q)) ((-1325187809142431461 : ℝ) / 1000000000000000000) ((-1325187809142431319 : ℝ) / 1000000000000000000) ∧
    RB (aval2 (q)) ((43311637489289075157 : ℝ) / 1000000000000000000) ((43311637489289132789 : ℝ) / 1000000000000000000) ∧
    RB (D0q (q)) ((1900440741832821403 : ℝ) / 1000000000000000000) ((190044074183282141 : ℝ) / 100000000000000000) ∧
    RB (d01 (q)) ((-1852535335881510477 : ℝ) / 500000000000000000) ((-463133833970377617 : ℝ) / 125000000000000000) ∧
    RB (d02 (q)) ((10835025039654253591 : ℝ) / 1000000000000000000) ((1083502503965425367 : ℝ) / 100000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1025859374999999999 : ℝ) / 1000000000000000000) ((13131 : ℝ) / 12800) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-3655082074530645673 : ℝ) / 1000000000000000000) ((-3655082074530645633 : ℝ) / 1000000000000000000) := rb_log hq (by norm_num) dlower_m_log_384.1 dlower_m_log_385.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((25530675951296493 : ℝ) / 1000000000000000000) ((5106135190259299 : ℝ) / 200000000000000000) := rb_log h1 (by norm_num) dlower_m_log_386.1 dlower_m_log_387.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((25530675951296493 : ℝ) / 500000000000000000) ((5106135190259299 : ℝ) / 100000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((642085828657352319 : ℝ) / 1000000000000000000) ((160521457164338081 : ℝ) / 250000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((642085828657352319 : ℝ) / 1000000000000000000) ((160521457164338081 : ℝ) / 250000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-974792475820577261 : ℝ) / 500000000000000000) ((-1949584951641154519 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-974792475820577261 : ℝ) / 500000000000000000) ((-1949584951641154519 : ℝ) / 1000000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((526193728637695311 : ℝ) / 500000000000000000) ((172423161 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((1900440741832821403 : ℝ) / 1000000000000000000) ((190044074183282141 : ℝ) / 100000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((1900440741832821403 : ℝ) / 1000000000000000000) ((190044074183282141 : ℝ) / 100000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-160521457164338081 : ℝ) / 250000000000000000) ((-642085828657352319 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((3655082074530645633 : ℝ) / 1000000000000000000) ((3655082074530645673 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-43917333151800941 : ℝ) / 250000000000000000) ((-2195866657590047 : ℝ) / 12500000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((206082666848199059 : ℝ) / 250000000000000000) ((10304133342409953 : ℝ) / 12500000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((206082666848199059 : ℝ) / 250000000000000000) ((10304133342409953 : ℝ) / 12500000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((1949584951641154519 : ℝ) / 1000000000000000000) ((974792475820577261 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((3655082074530645633 : ℝ) / 1000000000000000000) ((3655082074530645673 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((266695099027496327 : ℝ) / 500000000000000000) ((266695099027496331 : ℝ) / 500000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((3655082074530645633 : ℝ) / 1000000000000000000) ((3655082074530645673 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((13359624971555248157 : ℝ) / 1000000000000000000) ((13359624971555248451 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((345471551998811481 : ℝ) / 1000000000000000000) ((345471551998811503 : ℝ) / 1000000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((1858578007197423981 : ℝ) / 1000000000000000000) ((371715601439484823 : ℝ) / 200000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-1325187809142431461 : ℝ) / 1000000000000000000) ((-1325187809142431319 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-1325187809142431461 : ℝ) / 1000000000000000000) ((-1325187809142431319 : ℝ) / 1000000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-190044074183282141 : ℝ) / 100000000000000000) ((-1900440741832821403 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((3655082074530645633 : ℝ) / 1000000000000000000) ((3655082074530645673 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-519944751740454351 : ℝ) / 1000000000000000000) ((-519944751740454343 : ℝ) / 1000000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-974792475820577261 : ℝ) / 250000000000000000) ((-1949584951641154519 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((3655082074530645633 : ℝ) / 1000000000000000000) ((3655082074530645673 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((13359624971555248157 : ℝ) / 1000000000000000000) ((13359624971555248451 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((345471551998811481 : ℝ) / 1000000000000000000) ((345471551998811503 : ℝ) / 1000000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-11286515143497903069 : ℝ) / 1000000000000000000) ((-2821628785874475583 : ℝ) / 250000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((10766570391757447981 : ℝ) / 1000000000000000000) ((5383285195878724363 : ℝ) / 500000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-1655082074530645673 : ℝ) / 1000000000000000000) ((-1655082074530645633 : ℝ) / 1000000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-1062704745320939387 : ℝ) / 1000000000000000000) ((-132838093165117419 : ℝ) / 125000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((3655082074530645633 : ℝ) / 1000000000000000000) ((3655082074530645673 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((13359624971555248157 : ℝ) / 1000000000000000000) ((13359624971555248451 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((2233419603742313 : ℝ) / 250000000000000000) ((8933678414969267 : ℝ) / 1000000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-32653327834175519 : ℝ) / 1000000000000000000) ((-32653327834175463 : ℝ) / 1000000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((132838093165117419 : ℝ) / 125000000000000000) ((1062704745320939387 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((32653327834175463 : ℝ) / 1000000000000000000) ((32653327834175519 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((4068133387191453397 : ℝ) / 125000000000000000) ((32545067097531684063 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((43311637489289075157 : ℝ) / 1000000000000000000) ((43311637489289132789 : ℝ) / 1000000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((43311637489289075157 : ℝ) / 1000000000000000000) ((43311637489289132789 : ℝ) / 1000000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((526193728637695311 : ℝ) / 500000000000000000) ((172423161 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((1900440741832821403 : ℝ) / 1000000000000000000) ((190044074183282141 : ℝ) / 100000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((1900440741832821403 : ℝ) / 1000000000000000000) ((190044074183282141 : ℝ) / 100000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((526193728637695311 : ℝ) / 500000000000000000) ((172423161 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((43184061567134857 : ℝ) / 40000000000000000) ((107960153917837143 : ℝ) / 100000000000000000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-1852535335881510477 : ℝ) / 500000000000000000) ((-463133833970377617 : ℝ) / 125000000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-1852535335881510477 : ℝ) / 500000000000000000) ((-463133833970377617 : ℝ) / 125000000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((526193728637695311 : ℝ) / 500000000000000000) ((172423161 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((1107519360230562121 : ℝ) / 1000000000000000000) ((1107519360230562129 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((10835025039654253591 : ℝ) / 1000000000000000000) ((1083502503965425367 : ℝ) / 100000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((10835025039654253591 : ℝ) / 1000000000000000000) ((1083502503965425367 : ℝ) / 100000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_param_8_slab {q : ℝ} (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200)) :
    RB (delta (q)) ((641933523132395799 : ℝ) / 1000000000000000000) ((321119072890839319 : ℝ) / 500000000000000000) ∧
    RB (delta1 (q)) ((-243716679360243717 : ℝ) / 125000000000000000) ((-974718245507158087 : ℝ) / 500000000000000000) ∧
    RB (delta2 (q)) ((475037829062276253 : ℝ) / 250000000000000000) ((1900730233548283067 : ℝ) / 1000000000000000000) ∧
    RB (aval (q)) ((412071929005039839 : ℝ) / 500000000000000000) ((824517603354571701 : ℝ) / 1000000000000000000) ∧
    RB (aval1 (q)) ((-1334825526621368691 : ℝ) / 1000000000000000000) ((-263121121182735241 : ℝ) / 200000000000000000) ∧
    RB (aval2 (q)) ((42915252069462822863 : ℝ) / 1000000000000000000) ((21856236589107218363 : ℝ) / 500000000000000000) ∧
    RB (D0q (q)) ((475037829062276253 : ℝ) / 250000000000000000) ((1900730233548283067 : ℝ) / 1000000000000000000) ∧
    RB (d01 (q)) ((-926479321760016119 : ℝ) / 250000000000000000) ((-3704224314344889453 : ℝ) / 1000000000000000000) ∧
    RB (d02 (q)) ((2707931268482404717 : ℝ) / 250000000000000000) ((2709581565543383019 : ℝ) / 250000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1025781249999999999 : ℝ) / 1000000000000000000) ((3283 : ℝ) / 3200) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-731621559089436531 : ℝ) / 200000000000000000) ((-3652065480991219991 : ℝ) / 1000000000000000000) := rb_log hq (by norm_num) dlower_m_log_388.1 dlower_m_log_389.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((3181814673641667 : ℝ) / 125000000000000000) ((5121365742754951 : ℝ) / 200000000000000000) := rb_log h1 (by norm_num) dlower_m_log_390.1 dlower_m_log_391.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((3181814673641667 : ℝ) / 62500000000000000) ((5121365742754951 : ℝ) / 100000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((641933523132395799 : ℝ) / 1000000000000000000) ((321119072890839319 : ℝ) / 500000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((641933523132395799 : ℝ) / 1000000000000000000) ((321119072890839319 : ℝ) / 500000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-243716679360243717 : ℝ) / 125000000000000000) ((-974718245507158087 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-243716679360243717 : ℝ) / 125000000000000000) ((-974718245507158087 : ℝ) / 500000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((1052227172851562497 : ℝ) / 1000000000000000000) ((10778089 : ℝ) / 10240000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((475037829062276253 : ℝ) / 250000000000000000) ((1900730233548283067 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((475037829062276253 : ℝ) / 250000000000000000) ((1900730233548283067 : ℝ) / 1000000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-321119072890839319 : ℝ) / 500000000000000000) ((-641933523132395799 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((3652065480991219991 : ℝ) / 1000000000000000000) ((731621559089436531 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-87928070994960161 : ℝ) / 500000000000000000) ((-175482396645428299 : ℝ) / 1000000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((412071929005039839 : ℝ) / 500000000000000000) ((824517603354571701 : ℝ) / 1000000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((412071929005039839 : ℝ) / 500000000000000000) ((824517603354571701 : ℝ) / 1000000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((974718245507158087 : ℝ) / 500000000000000000) ((243716679360243717 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((3652065480991219991 : ℝ) / 1000000000000000000) ((731621559089436531 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((106581686490515721 : ℝ) / 200000000000000000) ((533871433858509487 : ℝ) / 1000000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((3652065480991219991 : ℝ) / 1000000000000000000) ((731621559089436531 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((533503291097905241 : ℝ) / 40000000000000000) ((6690876321555723369 : ℝ) / 500000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((85964885772611681 : ℝ) / 250000000000000000) ((6941784183614063 : ℝ) / 20000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((462369259943046423 : ℝ) / 250000000000000000) ((58366686221060853 : ℝ) / 31250000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-1334825526621368691 : ℝ) / 1000000000000000000) ((-263121121182735241 : ℝ) / 200000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-1334825526621368691 : ℝ) / 1000000000000000000) ((-263121121182735241 : ℝ) / 200000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-1900730233548283067 : ℝ) / 1000000000000000000) ((-475037829062276253 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((3652065480991219991 : ℝ) / 1000000000000000000) ((731621559089436531 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-520453492261151671 : ℝ) / 1000000000000000000) ((-103887114459229457 : ℝ) / 200000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-243716679360243717 : ℝ) / 62500000000000000) ((-974718245507158087 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((3652065480991219991 : ℝ) / 1000000000000000000) ((731621559089436531 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((533503291097905241 : ℝ) / 40000000000000000) ((6690876321555723369 : ℝ) / 500000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((85964885772611681 : ℝ) / 250000000000000000) ((6941784183614063 : ℝ) / 20000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-5670144900905378407 : ℝ) / 500000000000000000) ((-5616528660213667873 : ℝ) / 500000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((428504153126647363 : ℝ) / 40000000000000000) ((10820854229514609529 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-331621559089436531 : ℝ) / 200000000000000000) ((-1652065480991219991 : ℝ) / 1000000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-532450038027072739 : ℝ) / 500000000000000000) ((-106051621465810991 : ℝ) / 100000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((3652065480991219991 : ℝ) / 1000000000000000000) ((731621559089436531 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((533503291097905241 : ℝ) / 40000000000000000) ((6690876321555723369 : ℝ) / 500000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((4432564422650283 : ℝ) / 500000000000000000) ((1125328295390561 : ℝ) / 125000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-32932577678444009 : ℝ) / 1000000000000000000) ((-129504124161847 : ℝ) / 4000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((106051621465810991 : ℝ) / 100000000000000000) ((532450038027072739 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((129504124161847 : ℝ) / 4000000000000000) ((32932577678444009 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((8050662060324159697 : ℝ) / 250000000000000000) ((32891618948699827197 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((42915252069462822863 : ℝ) / 1000000000000000000) ((21856236589107218363 : ℝ) / 500000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((42915252069462822863 : ℝ) / 1000000000000000000) ((21856236589107218363 : ℝ) / 500000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((1052227172851562497 : ℝ) / 1000000000000000000) ((10778089 : ℝ) / 10240000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((475037829062276253 : ℝ) / 250000000000000000) ((1900730233548283067 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((475037829062276253 : ℝ) / 250000000000000000) ((1900730233548283067 : ℝ) / 1000000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((1052227172851562497 : ℝ) / 1000000000000000000) ((10778089 : ℝ) / 10240000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((1079354904651641841 : ℝ) / 1000000000000000000) ((13498102640914917 : ℝ) / 12500000000000000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-926479321760016119 : ℝ) / 250000000000000000) ((-3704224314344889453 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-926479321760016119 : ℝ) / 250000000000000000) ((-3704224314344889453 : ℝ) / 1000000000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((1052227172851562497 : ℝ) / 1000000000000000000) ((10778089 : ℝ) / 10240000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((55359101164359599 : ℝ) / 50000000000000000) ((1107856774253091813 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((2707931268482404717 : ℝ) / 250000000000000000) ((2709581565543383019 : ℝ) / 250000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((2707931268482404717 : ℝ) / 250000000000000000) ((2709581565543383019 : ℝ) / 250000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_8_point_plus_branch {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((459067366224799 : ℝ) / 1000000000000000) ((229533683112401 : ℝ) / 500000000000000)) :
    RB (phi q (v)) ((9210480620591053 : ℝ) / 20000000000000000) ((460524031029555663 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((-339292711721229127 : ℝ) / 200000000000000000) ((-339292711721215149 : ℝ) / 200000000000000000) ∧
    RB (psi2 q (v)) ((-5308807773746654401 : ℝ) / 500000000000000000) ((-10617615547490316073 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((3667189271595267 : ℝ) / 8000000000000000) ((28649916184338211 : ℝ) / 62500000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270466316887599 : ℝ) / 500000000000000) ((540932633775201 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-3046937652691103 : ℝ) / 3906250000000000) ((-780016039088915819 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_392.1 dlower_m_log_393.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-38403783097599047 : ℝ) / 62500000000000000) ((-153615132390394801 : ℝ) / 250000000000000000) := rb_log h3 (by norm_num) dlower_m_log_394.1 dlower_m_log_395.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-41388877381835791 : ℝ) / 250000000000000000) ((-165555509527331067 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-136472483659229227 : ℝ) / 1000000000000000000) ((-68236241829609627 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-77855831231657951 : ℝ) / 100000000000000000) ((-778558312316572973 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_396.1 dlower_m_log_397.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((321042914328671873 : ℝ) / 500000000000000000) ((5016295536385627 : ℝ) / 7812500000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-4289 : ℝ) / 500000000000000000) ((7937 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-4289 : ℝ) / 500000000000000000) ((7937 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((219392142961982771 : ℝ) / 1000000000000000000) ((219392142961998827 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-56412414162088541 : ℝ) / 500000000000000000) ((-56412414162088169 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18600993206189311 : ℝ) / 200000000000000000) ((-4650248301547297 : ℝ) / 50000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((15798397116379527 : ℝ) / 125000000000000000) ((126387176931052887 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((415194425714438147 : ℝ) / 200000000000000000) ((2075972128572207409 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((415194425714438147 : ℝ) / 200000000000000000) ((2075972128572207409 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((2181507254606430797 : ℝ) / 1000000000000000000) ((2181507254606445079 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((369731806720900001 : ℝ) / 200000000000000000) ((924329516802255129 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((2015083144105465401 : ℝ) / 500000000000000000) ((4030166288210955337 : ℝ) / 1000000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((3322189666064864973 : ℝ) / 1000000000000000000) ((664437933212977043 : ℝ) / 200000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((2178329529767330847 : ℝ) / 1000000000000000000) ((2178329529767345083 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((114386013629751989 : ℝ) / 100000000000000000) ((17872814629649287 : ℝ) / 15625000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((114386013629751989 : ℝ) / 100000000000000000) ((17872814629649287 : ℝ) / 15625000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((914400357134289 : ℝ) / 3125000000000000) ((146304057141487863 : ℝ) / 500000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((27340321780220191 : ℝ) / 8000000000000000) ((854385055631890447 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((105064665263308007 : ℝ) / 500000000000000000) ((210129330526618767 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((297435868868780429 : ℝ) / 62500000000000000) ((951794780380109843 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-67071683968651267 : ℝ) / 50000000000000000) ((-335358419843231269 : ℝ) / 250000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-552892460090370113 : ℝ) / 500000000000000000) ((-1105784920180657569 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((8429713869302949 : ℝ) / 40000000000000000) ((210742846732576481 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((1186279885064090177 : ℝ) / 250000000000000000) ((4745119540256422763 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((1819667310037810241 : ℝ) / 500000000000000000) ((1819667310037882597 : ℝ) / 500000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((1819667310037810241 : ℝ) / 500000000000000000) ((1819667310037882597 : ℝ) / 500000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((2181507254606430797 : ℝ) / 1000000000000000000) ((2181507254606445079 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((369731806720900001 : ℝ) / 200000000000000000) ((924329516802255129 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((2015083144105465401 : ℝ) / 500000000000000000) ((4030166288210955337 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-2670363616976980453 : ℝ) / 500000000000000000) ((-5340727233953927819 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((25859374999999999 : ℝ) / 500000000000000000) ((331 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((105064665263308007 : ℝ) / 500000000000000000) ((210129330526618767 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((49225636297783159 : ℝ) / 200000000000000000) ((24612818148891903 : ℝ) / 100000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((202891008110933233 : ℝ) / 1000000000000000000) ((101445504055467951 : ℝ) / 500000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-5137836225843027673 : ℝ) / 1000000000000000000) ((-5137836225842991917 : ℝ) / 1000000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-5137836225843027673 : ℝ) / 1000000000000000000) ((-5137836225842991917 : ℝ) / 1000000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-7170480213002840379 : ℝ) / 1000000000000000000) ((-448155013312644181 : ℝ) / 62500000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-1325187809142431461 : ℝ) / 500000000000000000) ((-1325187809142431319 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-56412414162088541 : ℝ) / 500000000000000000) ((-56412414162088169 : ℝ) / 500000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((37378521765946543 : ℝ) / 125000000000000000) ((299028174127574349 : ℝ) / 1000000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-1374290407775053607 : ℝ) / 200000000000000000) ((-6871452038874732547 : ℝ) / 1000000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-2181507254606445079 : ℝ) / 500000000000000000) ((-2181507254606430797 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((20897102355957 : ℝ) / 7812500000000000) ((109561 : ℝ) / 40960000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((105064665263308007 : ℝ) / 500000000000000000) ((210129330526618767 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((2545888377275969 : ℝ) / 200000000000000000) ((1553886949021 : ℝ) / 122070312500000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-437574395109927019 : ℝ) / 100000000000000000) ((-4375743951099241439 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-3607059931549652551 : ℝ) / 1000000000000000000) ((-112720622860925901 : ℝ) / 31250000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-5239255985212460293 : ℝ) / 500000000000000000) ((-10478511970424361379 : ℝ) / 1000000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-3094738178064435499 : ℝ) / 250000000000000000) ((-6189476356128591391 : ℝ) / 500000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-3094738178064435499 : ℝ) / 250000000000000000) ((-6189476356128591391 : ℝ) / 500000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-2075972128572207409 : ℝ) / 1000000000000000000) ((-415194425714438147 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-1814882836368242549 : ℝ) / 1000000000000000000) ((-1814882836368173267 : ℝ) / 1000000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-1814882836368242549 : ℝ) / 1000000000000000000) ((-1814882836368173267 : ℝ) / 1000000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((1814882836368173267 : ℝ) / 1000000000000000000) ((1814882836368242549 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((1646899854871892791 : ℝ) / 500000000000000000) ((164689985487201853 : ℝ) / 50000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((299680982881639723 : ℝ) / 25000000000000000) ((5993619657633490393 : ℝ) / 500000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-5137836225843027673 : ℝ) / 500000000000000000) ((-5137836225842991917 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((18649141564706159219 : ℝ) / 1000000000000000000) ((745965662588280037 : ℝ) / 40000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((30636380879971748139 : ℝ) / 1000000000000000000) ((30636380879973981711 : ℝ) / 1000000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((18257428167714006143 : ℝ) / 1000000000000000000) ((18257428167716798929 : ℝ) / 1000000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-18257428167716798929 : ℝ) / 1000000000000000000) ((-18257428167714006143 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-199515521919631047 : ℝ) / 12500000000000000) ((-15961241753567561113 : ℝ) / 1000000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-199515521919631047 : ℝ) / 12500000000000000) ((-15961241753567561113 : ℝ) / 1000000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((29133296095073 : ℝ) / 20000000000000000) ((1456664804753663 : ℝ) / 1000000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((9210480620591053 : ℝ) / 20000000000000000) ((460524031029555663 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((9210480620591053 : ℝ) / 20000000000000000) ((460524031029555663 : ℝ) / 1000000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((8429713869302949 : ℝ) / 40000000000000000) ((210742846732576481 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((3173095959167641 : ℝ) / 1000000000000000000) ((396636994895961 : ℝ) / 125000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((124603363005104039 : ℝ) / 125000000000000000) ((996826904040832359 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-452281009743449943 : ℝ) / 250000000000000000) ((-28267563108964541 : ℝ) / 15625000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((25859374999999999 : ℝ) / 500000000000000000) ((331 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((112660480367654137 : ℝ) / 1000000000000000000) ((112660480367654879 : ℝ) / 1000000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-339292711721229127 : ℝ) / 200000000000000000) ((-339292711721215149 : ℝ) / 200000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-339292711721229127 : ℝ) / 200000000000000000) ((-339292711721215149 : ℝ) / 200000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((20897102355957 : ℝ) / 15625000000000000) ((109561 : ℝ) / 81920000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((8429713869302949 : ℝ) / 40000000000000000) ((210742846732576481 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((96745163600239107 : ℝ) / 1000000000000000000) ((19349032720048201 : ℝ) / 200000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((13824097257280531 : ℝ) / 1000000000000000000) ((1728012157160103 : ℝ) / 125000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((1814882836368173267 : ℝ) / 1000000000000000000) ((1814882836368242549 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((1646899854871892791 : ℝ) / 500000000000000000) ((164689985487201853 : ℝ) / 50000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((1821352301340019 : ℝ) / 40000000000000000) ((45533807533504917 : ℝ) / 1000000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((25859374999999999 : ℝ) / 250000000000000000) ((331 : ℝ) / 3200) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((8429713869302949 : ℝ) / 40000000000000000) ((210742846732576481 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((490823302445267291 : ℝ) / 1000000000000000000) ((49082330244527373 : ℝ) / 100000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-445393393648753073 : ℝ) / 500000000000000000) ((-445393393648730227 : ℝ) / 500000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((936320594830960929 : ℝ) / 1000000000000000000) ((936320594831011063 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((871331811906932339 : ℝ) / 200000000000000000) ((2178329529767345083 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((165405614198925707 : ℝ) / 31250000000000000) ((5292979654365701229 : ℝ) / 1000000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((8429713869302949 : ℝ) / 40000000000000000) ((210742846732576481 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((3173095959167641 : ℝ) / 1000000000000000000) ((396636994895961 : ℝ) / 125000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((124603363005104039 : ℝ) / 125000000000000000) ((996826904040832359 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-7955297600929465713 : ℝ) / 500000000000000000) ((-7955297600928008651 : ℝ) / 500000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-5308807773746654401 : ℝ) / 500000000000000000) ((-10617615547490316073 : ℝ) / 1000000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-5308807773746654401 : ℝ) / 500000000000000000) ((-10617615547490316073 : ℝ) / 1000000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_8_point_plus_lo_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((459067366224799 : ℝ) / 1000000000000000) ((459067366224799 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-2043 : ℝ) / 1000000000000000000) ((-203 : ℝ) / 100000000000000000) ∧
    RB (Eq q (v)) ((1037986064286103379 : ℝ) / 500000000000000000) ((5189930321430517 : ℝ) / 2500000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((3667189271595267 : ℝ) / 8000000000000000) ((57299832368676047 : ℝ) / 125000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((540932633775201 : ℝ) / 1000000000000000) ((540932633775201 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-3046937652691103 : ℝ) / 3906250000000000) ((-195004009772230591 : ℝ) / 250000000000000000) := rb_log h2 (by norm_num) dlower_m_log_392.1 dlower_m_log_398.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-307230264780789603 : ℝ) / 500000000000000000) ((-153615132390394801 : ℝ) / 250000000000000000) := rb_log h3 (by norm_num) dlower_m_log_395.1 dlower_m_log_395.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-41388877381835791 : ℝ) / 250000000000000000) ((-82777754763671579 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-136472483659229227 : ℝ) / 1000000000000000000) ((-136472483659229221 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-77855831231657951 : ℝ) / 100000000000000000) ((-194639578079144877 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_396.1 dlower_m_log_396.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((642085828657350281 : ℝ) / 1000000000000000000) ((642085828657350289 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-2043 : ℝ) / 1000000000000000000) ((-203 : ℝ) / 100000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-2043 : ℝ) / 1000000000000000000) ((-203 : ℝ) / 100000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((109696071480999397 : ℝ) / 500000000000000000) ((219392142961998827 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-56412414162088541 : ℝ) / 500000000000000000) ((-28206207081044269 : ℝ) / 250000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18600993206189311 : ℝ) / 200000000000000000) ((-93004966030946549 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((126387176931052239 : ℝ) / 1000000000000000000) ((63193588465526139 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((1037986064286103379 : ℝ) / 500000000000000000) ((5189930321430517 : ℝ) / 2500000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((1037986064286103379 : ℝ) / 500000000000000000) ((5189930321430517 : ℝ) / 2500000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_8_point_plus_hi_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((229533683112401 : ℝ) / 500000000000000) ((229533683112401 : ℝ) / 500000000000000)) :
    RB (E q (v)) ((347 : ℝ) / 250000000000000000) ((701 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((2075972128572191343 : ℝ) / 1000000000000000000) ((2075972128572191387 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((3667189271595291 : ℝ) / 8000000000000000) ((28649916184338211 : ℝ) / 62500000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270466316887599 : ℝ) / 500000000000000) ((270466316887599 : ℝ) / 500000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-48751002443057239 : ℝ) / 62500000000000000) ((-780016039088915819 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_399.1 dlower_m_log_393.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-38403783097599047 : ℝ) / 62500000000000000) ((-2457842118246339 : ℝ) / 4000000000000000) := rb_log h3 (by norm_num) dlower_m_log_394.1 dlower_m_log_394.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-82777754763665537 : ℝ) / 500000000000000000) ((-165555509527331067 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-136472483659219261 : ℝ) / 1000000000000000000) ((-68236241829609627 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-31142332492662919 : ℝ) / 40000000000000000) ((-778558312316572973 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_397.1 dlower_m_log_397.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((40130364291084607 : ℝ) / 62500000000000000) ((642085828657353721 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((347 : ℝ) / 250000000000000000) ((701 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((347 : ℝ) / 250000000000000000) ((701 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((219392142961982771 : ℝ) / 1000000000000000000) ((43878428592396561 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-14103103540522043 : ℝ) / 125000000000000000) ((-56412414162088169 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-93004966030945947 : ℝ) / 1000000000000000000) ((-4650248301547297 : ℝ) / 50000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((15798397116379603 : ℝ) / 125000000000000000) ((25277435386207373 : ℝ) / 200000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2075972128572191343 : ℝ) / 1000000000000000000) ((2075972128572191387 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2075972128572191343 : ℝ) / 1000000000000000000) ((2075972128572191387 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_8_point_minus_branch {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((178165129878877 : ℝ) / 125000000000000) ((1425321039031019 : ℝ) / 1000000000000000)) :
    RB (phi q (v)) ((285158040319311297 : ℝ) / 200000000000000000) ((11138985949973121 : ℝ) / 7812500000000000) ∧
    RB (psi1 q (v)) ((23798128179975117 : ℝ) / 125000000000000000) ((761540101759233 : ℝ) / 4000000000000000) ∧
    RB (psi2 q (v)) ((25735738486540919433 : ℝ) / 1000000000000000000) ((5147147697308273753 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((11397218654045003 : ℝ) / 8000000000000000) ((178081541469453547 : ℝ) / 125000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425321039031019 : ℝ) / 1000000000000000) ((-53165129878877 : ℝ) / 125000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353927806237858619 : ℝ) / 1000000000000000000) ((44240975779732591 : ℝ) / 125000000000000000) := rb_log h2 (by norm_num) dlower_m_log_400.1 dlower_m_log_401.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((53165129878877 : ℝ) / 125000000000000) ((425321039031019 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-213727752315691039 : ℝ) / 250000000000000000) ((-854911009262757101 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_402.1 dlower_m_log_403.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((30220970387515393 : ℝ) / 25000000000000000) ((302209703875156221 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((124560363443992479 : ℝ) / 125000000000000000) ((7785022715249589 : ℝ) / 7812500000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354397078894590683 : ℝ) / 1000000000000000000) ((35439707889459279 : ℝ) / 100000000000000000) := rb_log hv (by norm_num) dlower_m_log_404.1 dlower_m_log_405.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((321042914328673521 : ℝ) / 500000000000000000) ((642085828657356709 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-2641 : ℝ) / 500000000000000000) ((439 : ℝ) / 100000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-2641 : ℝ) / 500000000000000000) ((439 : ℝ) / 100000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1601938461519605007 : ℝ) / 1000000000000000000) ((-1601938461519592691 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-36302716703005027 : ℝ) / 1000000000000000000) ((-9075679175751237 : ℝ) / 250000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-14962721343979873 : ℝ) / 500000000000000000) ((-46758504199937 : ℝ) / 1562500000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1631863904207564753 : ℝ) / 1000000000000000000) ((-1631863904207552371 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((158860523716794883 : ℝ) / 500000000000000000) ((317721047433602151 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((158860523716794883 : ℝ) / 500000000000000000) ((317721047433602151 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((701925640178947679 : ℝ) / 1000000000000000000) ((350962820089474579 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((53165129878877 : ℝ) / 125000000000000) ((425321039031019 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-293895642418207609 : ℝ) / 125000000000000000) ((-2351165139345644287 : ℝ) / 1000000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-1649239499166713193 : ℝ) / 1000000000000000000) ((-1649239499166695129 : ℝ) / 1000000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-271903739407731541 : ℝ) / 200000000000000000) ((-1359518697038642807 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((175399080736195669 : ℝ) / 250000000000000000) ((701596322944784153 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-1030557509991720929 : ℝ) / 500000000000000000) ((-2061115019983425483 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-1030557509991720929 : ℝ) / 500000000000000000) ((-2061115019983425483 : ℝ) / 1000000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((53165129878877 : ℝ) / 125000000000000) ((425321039031019 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((36179597248484607 : ℝ) / 200000000000000000) ((45224496560606397 : ℝ) / 250000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((1381994378118555727 : ℝ) / 250000000000000000) ((221119100498972037 : ℝ) / 40000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((405926853275348093 : ℝ) / 200000000000000000) ((2029634266376749017 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((61587450542578191 : ℝ) / 125000000000000000) ((98539920868125521 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((5035277908133595303 : ℝ) / 1000000000000000000) ((5035277908133675397 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((83014679970399391 : ℝ) / 20000000000000000) ((830146799704007119 : ℝ) / 200000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((406308012860891007 : ℝ) / 200000000000000000) ((507885016076115897 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((246118700184819893 : ℝ) / 500000000000000000) ((492237400369641859 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((580371424861201167 : ℝ) / 125000000000000000) ((2321485699444838727 : ℝ) / 500000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((580371424861201167 : ℝ) / 125000000000000000) ((2321485699444838727 : ℝ) / 500000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((701925640178947679 : ℝ) / 1000000000000000000) ((350962820089474579 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((53165129878877 : ℝ) / 125000000000000) ((425321039031019 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-293895642418207609 : ℝ) / 125000000000000000) ((-2351165139345644287 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-1649239499166713193 : ℝ) / 1000000000000000000) ((-1649239499166695129 : ℝ) / 1000000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((10927760393259367 : ℝ) / 5000000000000000) ((1092776039325948787 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((25859374999999999 : ℝ) / 500000000000000000) ((331 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((405926853275348093 : ℝ) / 200000000000000000) ((2029634266376749017 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((1019272306479669 : ℝ) / 40000000000000000) ((12740903830995917 : ℝ) / 500000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((21005435516384507 : ℝ) / 1000000000000000000) ((10502717758192299 : ℝ) / 500000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((2206557514168257907 : ℝ) / 1000000000000000000) ((551639378542070543 : ℝ) / 250000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((2206557514168257907 : ℝ) / 1000000000000000000) ((551639378542070543 : ℝ) / 250000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((52356788559944267391 : ℝ) / 1000000000000000000) ((52356788559944733967 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-1325187809142431461 : ℝ) / 500000000000000000) ((-1325187809142431319 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-36302716703005027 : ℝ) / 1000000000000000000) ((-9075679175751237 : ℝ) / 250000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((96215835227146949 : ℝ) / 1000000000000000000) ((96215835227147169 : ℝ) / 1000000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((2622650219758570717 : ℝ) / 50000000000000000) ((3278312774698242571 : ℝ) / 62500000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-350962820089474579 : ℝ) / 250000000000000000) ((-701925640178947679 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((20897102355957 : ℝ) / 7812500000000000) ((109561 : ℝ) / 40960000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((405926853275348093 : ℝ) / 200000000000000000) ((2029634266376749017 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((164735905002329 : ℝ) / 125000000000000000) ((1317887240018641 : ℝ) / 1000000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-1405169167597916957 : ℝ) / 1000000000000000000) ((-140516916759791399 : ℝ) / 100000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-1158324037725770839 : ℝ) / 1000000000000000000) ((-1158324037725768387 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((51294680357445643501 : ℝ) / 1000000000000000000) ((51294680357446112749 : ℝ) / 1000000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((49394239615612822091 : ℝ) / 1000000000000000000) ((24697119807806645673 : ℝ) / 500000000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((49394239615612822091 : ℝ) / 1000000000000000000) ((24697119807806645673 : ℝ) / 500000000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-317721047433602151 : ℝ) / 1000000000000000000) ((-158860523716794883 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((158860523716794883 : ℝ) / 500000000000000000) ((317721047433602151 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((2061115019983425483 : ℝ) / 1000000000000000000) ((1030557509991720929 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((154150081074147043 : ℝ) / 1000000000000000000) ((77075040537077139 : ℝ) / 500000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((154150081074147043 : ℝ) / 1000000000000000000) ((77075040537077139 : ℝ) / 500000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((11881123747583053 : ℝ) / 500000000000000000) ((23762247495168337 : ℝ) / 1000000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((11032743549339249 : ℝ) / 100000000000000000) ((27581858873351117 : ℝ) / 250000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((2206557514168257907 : ℝ) / 500000000000000000) ((551639378542070543 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((680282039407610637 : ℝ) / 1000000000000000000) ((2657351716436133 : ℝ) / 3906250000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((790609474901003127 : ℝ) / 1000000000000000000) ((197652368725263629 : ℝ) / 250000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((25092424545256912609 : ℝ) / 500000000000000000) ((25092424545257172931 : ℝ) / 500000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-25092424545257172931 : ℝ) / 500000000000000000) ((-25092424545256912609 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((25092424545256912609 : ℝ) / 500000000000000000) ((25092424545257172931 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((2061115019983425483 : ℝ) / 1000000000000000000) ((1030557509991720929 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((6087099531558043453 : ℝ) / 250000000000000000) ((24348398126232619857 : ℝ) / 1000000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((6087099531558043453 : ℝ) / 250000000000000000) ((24348398126232619857 : ℝ) / 1000000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((93832513108097 : ℝ) / 200000000000000000) ((58645320692561 : ℝ) / 125000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((285158040319311297 : ℝ) / 200000000000000000) ((11138985949973121 : ℝ) / 7812500000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((285158040319311297 : ℝ) / 200000000000000000) ((11138985949973121 : ℝ) / 7812500000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((406308012860891007 : ℝ) / 200000000000000000) ((507885016076115897 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((65832546169309 : ℝ) / 200000000000000000) ((82290682711637 : ℝ) / 250000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((249917709317288363 : ℝ) / 250000000000000000) ((199934167453830691 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((154099340612500459 : ℝ) / 1000000000000000000) ((77049670306253847 : ℝ) / 500000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((25859374999999999 : ℝ) / 500000000000000000) ((331 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((36285684827300477 : ℝ) / 1000000000000000000) ((9071421206825139 : ℝ) / 250000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((23798128179975117 : ℝ) / 125000000000000000) ((761540101759233 : ℝ) / 4000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((23798128179975117 : ℝ) / 125000000000000000) ((761540101759233 : ℝ) / 4000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((20897102355957 : ℝ) / 15625000000000000) ((109561 : ℝ) / 81920000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((406308012860891007 : ℝ) / 200000000000000000) ((507885016076115897 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((2895596795287562909 : ℝ) / 1000000000000000000) ((579119359057516239 : ℝ) / 200000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((461878723224799 : ℝ) / 1000000000000000000) ((461878723224803 : ℝ) / 1000000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((11881123747583053 : ℝ) / 500000000000000000) ((23762247495168337 : ℝ) / 1000000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((5487638267009 : ℝ) / 500000000000000000) ((10975276534021 : ℝ) / 1000000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((25859374999999999 : ℝ) / 250000000000000000) ((331 : ℝ) / 3200) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((406308012860891007 : ℝ) / 200000000000000000) ((507885016076115897 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((50915806100734613 : ℝ) / 1000000000000000000) ((5091580610073483 : ℝ) / 100000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((7848675638383791 : ℝ) / 1000000000000000000) ((3924337819192097 : ℝ) / 500000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-122464068153909 : ℝ) / 15625000000000000) ((-783770036184977 : ℝ) / 100000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((175399080736195669 : ℝ) / 125000000000000000) ((701596322944784153 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((174419368190964397 : ℝ) / 125000000000000000) ((174419368190964817 : ℝ) / 125000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((406308012860891007 : ℝ) / 200000000000000000) ((507885016076115897 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((65832546169309 : ℝ) / 200000000000000000) ((82290682711637 : ℝ) / 250000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((249917709317288363 : ℝ) / 250000000000000000) ((199934167453830691 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((24340383541013204257 : ℝ) / 1000000000000000000) ((24340383541013650229 : ℝ) / 1000000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((25735738486540919433 : ℝ) / 1000000000000000000) ((5147147697308273753 : ℝ) / 200000000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((25735738486540919433 : ℝ) / 1000000000000000000) ((5147147697308273753 : ℝ) / 200000000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_8_point_minus_lo_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((178165129878877 : ℝ) / 125000000000000) ((178165129878877 : ℝ) / 125000000000000)) :
    RB (E q (v)) ((2637 : ℝ) / 1000000000000000000) ((2653 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((317721047433592557 : ℝ) / 1000000000000000000) ((158860523716796371 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((11397218654045003 : ℝ) / 8000000000000000) ((44520385367363293 : ℝ) / 31250000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-53165129878877 : ℝ) / 125000000000000) ((-53165129878877 : ℝ) / 125000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353927806237858619 : ℝ) / 1000000000000000000) ((176963903118929311 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_400.1 dlower_m_log_406.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((53165129878877 : ℝ) / 125000000000000) ((53165129878877 : ℝ) / 125000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-213727752315691039 : ℝ) / 250000000000000000) ((-427455504631382077 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_402.1 dlower_m_log_402.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208838815500622773 : ℝ) / 1000000000000000000) ((604419407750311389 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((498241453775972823 : ℝ) / 500000000000000000) ((199296581510389131 : ℝ) / 200000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354397078894590683 : ℝ) / 1000000000000000000) ((70879415778918137 : ℝ) / 200000000000000000) := rb_log hv (by norm_num) dlower_m_log_404.1 dlower_m_log_404.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642085828657354961 : ℝ) / 1000000000000000000) ((160521457164338743 : ℝ) / 250000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((2637 : ℝ) / 1000000000000000000) ((2653 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((2637 : ℝ) / 1000000000000000000) ((2653 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-200242307689950277 : ℝ) / 125000000000000000) ((-1601938461519602037 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-36302716703005027 : ℝ) / 1000000000000000000) ((-1452108668120201 : ℝ) / 40000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-14962721343979873 : ℝ) / 500000000000000000) ((-29925442687959743 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-815931952103780981 : ℝ) / 500000000000000000) ((-81593195210378089 : ℝ) / 50000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((317721047433592557 : ℝ) / 1000000000000000000) ((158860523716796371 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((317721047433592557 : ℝ) / 1000000000000000000) ((158860523716796371 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_8_point_minus_hi_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((1425321039031019 : ℝ) / 1000000000000000) ((1425321039031019 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-1773 : ℝ) / 500000000000000000) ((-3529 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((12708841897343967 : ℝ) / 40000000000000000) ((317721047433599361 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((11397218654045027 : ℝ) / 8000000000000000) ((178081541469453547 : ℝ) / 125000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425321039031019 : ℝ) / 1000000000000000) ((-425321039031019 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((14157112249514429 : ℝ) / 40000000000000000) ((44240975779732591 : ℝ) / 125000000000000000) := rb_log h2 (by norm_num) dlower_m_log_407.1 dlower_m_log_401.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425321039031019 : ℝ) / 1000000000000000) ((425321039031019 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854911009262757103 : ℝ) / 1000000000000000000) ((-854911009262757101 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_403.1 dlower_m_log_403.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604419407750308913 : ℝ) / 500000000000000000) ((1208838815500617831 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((15570045430499087 : ℝ) / 15625000000000000) ((498241453775970789 : ℝ) / 500000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((88599269723648197 : ℝ) / 250000000000000000) ((35439707889459279 : ℝ) / 100000000000000000) := rb_log hv (by norm_num) dlower_m_log_405.1 dlower_m_log_405.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((321042914328674389 : ℝ) / 500000000000000000) ((64208582865734879 : ℝ) / 100000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-1773 : ℝ) / 500000000000000000) ((-3529 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-1773 : ℝ) / 500000000000000000) ((-3529 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1601938461519595661 : ℝ) / 1000000000000000000) ((-1601938461519595481 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-36302716703004951 : ℝ) / 1000000000000000000) ((-9075679175751237 : ℝ) / 250000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29925442687959683 : ℝ) / 1000000000000000000) ((-46758504199937 : ℝ) / 1562500000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-101991494012972209 : ℝ) / 62500000000000000) ((-1631863904207555161 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((12708841897343967 : ℝ) / 40000000000000000) ((317721047433599361 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((12708841897343967 : ℝ) / 40000000000000000) ((317721047433599361 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_8_slab_plus_branch {q v : ℝ} (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200))
    (hv : RB v ((458890131572811697 : ℝ) / 1000000000000000000) ((459244600876789863 : ℝ) / 1000000000000000000)) :
    RB (phi q (v)) ((230168724649562329 : ℝ) / 500000000000000000) ((460710646581333969 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((-851997403681540477 : ℝ) / 500000000000000000) ((-844492311336329869 : ℝ) / 500000000000000000) ∧
    RB (psi2 q (v)) ((-5530219496345404579 : ℝ) / 500000000000000000) ((-5089664540783751749 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458217377666561697 : ℝ) / 1000000000000000000) ((114644982006306841 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((540755399123210137 : ℝ) / 1000000000000000000) ((541109868427188303 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-390205791870024551 : ℝ) / 500000000000000000) ((-779620677450700827 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_408.1 dlower_m_log_409.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-153697057422468061 : ℝ) / 250000000000000000) ((-30706646839274423 : ℝ) / 50000000000000000) := rb_log h3 (by norm_num) dlower_m_log_410.1 dlower_m_log_411.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-83139323477280321 : ℝ) / 500000000000000000) ((-164832447760828583 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-68549835738007647 : ℝ) / 500000000000000000) ((-135845649422854187 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-155788892467805149 : ℝ) / 200000000000000000) ((-778172311348409893 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_412.1 dlower_m_log_413.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((641072639872394599 : ℝ) / 1000000000000000000) ((321549406458085779 : ℝ) / 500000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-1165505909284039 : ℝ) / 1000000000000000000) ((1165289783775759 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-1165505909284039 : ℝ) / 1000000000000000000) ((1165289783775759 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((54213623077654817 : ℝ) / 250000000000000000) ((221952982487010053 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-3537826867796461 : ℝ) / 31250000000000000) ((-112439504759928013 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-746752135710451 : ℝ) / 8000000000000000) ((-9266632724558979 : ℝ) / 100000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((123510475346812893 : ℝ) / 1000000000000000000) ((129286655241420263 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2072946966361129067 : ℝ) / 1000000000000000000) ((2079020090123369999 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2072946966361129067 : ℝ) / 1000000000000000000) ((2079020090123369999 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((2180644940798603981 : ℝ) / 1000000000000000000) ((1091185154404691579 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((462013381361275207 : ℝ) / 250000000000000000) ((1849264938679145419 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((4028698466243704809 : ℝ) / 1000000000000000000) ((4031635247488528577 : ℝ) / 1000000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((103757096772793051 : ℝ) / 31250000000000000) ((20775963949119107 : ℝ) / 6250000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((2177488854720991483 : ℝ) / 1000000000000000000) ((2179170854192428569 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((1141056242536949063 : ℝ) / 1000000000000000000) ((1146665377138065637 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((1141056242536949063 : ℝ) / 1000000000000000000) ((1146665377138065637 : ℝ) / 1000000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((146208200840451147 : ℝ) / 500000000000000000) ((292799889709289037 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((3415301832910065931 : ℝ) / 1000000000000000000) ((3419780813427983471 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((104981582597810217 : ℝ) / 500000000000000000) ((21029555038762271 : ℝ) / 100000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((1188803089457636763 : ℝ) / 250000000000000000) ((4762740164772762413 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-673719165931348241 : ℝ) / 500000000000000000) ((-1335431544402563581 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-111098662405551253 : ℝ) / 100000000000000000) ((-550293852556143887 : ℝ) / 500000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((21058015285491243 : ℝ) / 100000000000000000) ((210905603434482021 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((948291542486827029 : ℝ) / 200000000000000000) ((4748785611761758787 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((726094217675724523 : ℝ) / 200000000000000000) ((3648197906649471013 : ℝ) / 1000000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((726094217675724523 : ℝ) / 200000000000000000) ((3648197906649471013 : ℝ) / 1000000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((2180644940798603981 : ℝ) / 1000000000000000000) ((1091185154404691579 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((462013381361275207 : ℝ) / 250000000000000000) ((1849264938679145419 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((4028698466243704809 : ℝ) / 1000000000000000000) ((4031635247488528577 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-2690764821187073627 : ℝ) / 500000000000000000) ((-1325044571681511817 : ℝ) / 250000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((25781249999999999 : ℝ) / 500000000000000000) ((83 : ℝ) / 1600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((104981582597810217 : ℝ) / 500000000000000000) ((21029555038762271 : ℝ) / 100000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((61297659300159393 : ℝ) / 250000000000000000) ((247067146047587051 : ℝ) / 1000000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((202072357690483211 : ℝ) / 1000000000000000000) ((101855605563405209 : ℝ) / 500000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-5179457284683664043 : ℝ) / 1000000000000000000) ((-101929341511984737 : ℝ) / 20000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-5179457284683664043 : ℝ) / 1000000000000000000) ((-101929341511984737 : ℝ) / 20000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-7268450895111019697 : ℝ) / 1000000000000000000) ((-7073826044882521489 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-1334825526621368691 : ℝ) / 500000000000000000) ((-263121121182735241 : ℝ) / 100000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-3537826867796461 : ℝ) / 31250000000000000) ((-112439504759928013 : ℝ) / 1000000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((147926042788318773 : ℝ) / 500000000000000000) ((37779052895213107 : ℝ) / 125000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-6972598809534382151 : ℝ) / 1000000000000000000) ((-6771593621720816633 : ℝ) / 1000000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-1091185154404691579 : ℝ) / 250000000000000000) ((-2180644940798603981 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((664672851562499 : ℝ) / 250000000000000000) ((6889 : ℝ) / 2560000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((104981582597810217 : ℝ) / 500000000000000000) ((21029555038762271 : ℝ) / 100000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((197541284854029 : ℝ) / 15625000000000000) ((12816608201218579 : ℝ) / 1000000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-875511445163996979 : ℝ) / 200000000000000000) ((-2186966261913932909 : ℝ) / 500000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-3609372992380581567 : ℝ) / 1000000000000000000) ((-1802374812431631047 : ℝ) / 500000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-5290985900957481859 : ℝ) / 500000000000000000) ((-10376343246584078727 : ℝ) / 1000000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-2496540407092649357 : ℝ) / 200000000000000000) ((-12276494562833183739 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-2496540407092649357 : ℝ) / 200000000000000000) ((-12276494562833183739 : ℝ) / 1000000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-2079020090123369999 : ℝ) / 1000000000000000000) ((-2072946966361129067 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-911006842879634963 : ℝ) / 500000000000000000) ((-1807804619979847329 : ℝ) / 1000000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-911006842879634963 : ℝ) / 500000000000000000) ((-1807804619979847329 : ℝ) / 1000000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((1807804619979847329 : ℝ) / 1000000000000000000) ((911006842879634963 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((408519693002560027 : ℝ) / 125000000000000000) ((1659866935547039809 : ℝ) / 500000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((11864951475832839059 : ℝ) / 1000000000000000000) ((378470192473711441 : ℝ) / 31250000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-5179457284683664043 : ℝ) / 500000000000000000) ((-101929341511984737 : ℝ) / 10000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((18426833449686964443 : ℝ) / 1000000000000000000) ((2359260514374795733 : ℝ) / 125000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((15145892462759901751 : ℝ) / 500000000000000000) ((3873141284269641497 : ℝ) / 125000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((17809082890056556717 : ℝ) / 1000000000000000000) ((18708635711323948237 : ℝ) / 1000000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-18708635711323948237 : ℝ) / 1000000000000000000) ((-17809082890056556717 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-8197946347380915961 : ℝ) / 500000000000000000) ((-15531194405211584641 : ℝ) / 1000000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-8197946347380915961 : ℝ) / 500000000000000000) ((-15531194405211584641 : ℝ) / 1000000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((1447317726312961 : ℝ) / 1000000000000000000) ((733022852272053 : ℝ) / 500000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((230168724649562329 : ℝ) / 500000000000000000) ((460710646581333969 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((230168724649562329 : ℝ) / 500000000000000000) ((460710646581333969 : ℝ) / 1000000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((21058015285491243 : ℝ) / 100000000000000000) ((210905603434482021 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((3151518218286599 : ℝ) / 1000000000000000000) ((79869101756413 : ℝ) / 25000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((24920130898243587 : ℝ) / 25000000000000000) ((996848481781713401 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-1816271576434632073 : ℝ) / 1000000000000000000) ((-180202911073389197 : ℝ) / 100000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((25781249999999999 : ℝ) / 500000000000000000) ((83 : ℝ) / 1600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((112276769071551119 : ℝ) / 1000000000000000000) ((14130561007654029 : ℝ) / 125000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-851997403681540477 : ℝ) / 500000000000000000) ((-844492311336329869 : ℝ) / 500000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-851997403681540477 : ℝ) / 500000000000000000) ((-844492311336329869 : ℝ) / 500000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((664672851562499 : ℝ) / 500000000000000000) ((6889 : ℝ) / 5120000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((21058015285491243 : ℝ) / 100000000000000000) ((210905603434482021 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((96633154050213563 : ℝ) / 1000000000000000000) ((48428629835973609 : ℝ) / 500000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((1715598948942307 : ℝ) / 125000000000000000) ((6961936747924179 : ℝ) / 500000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((1807804619979847329 : ℝ) / 1000000000000000000) ((911006842879634963 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((408519693002560027 : ℝ) / 125000000000000000) ((1659866935547039809 : ℝ) / 500000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((22427390589997629 : ℝ) / 500000000000000000) ((1848942178439877 : ℝ) / 40000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((25781249999999999 : ℝ) / 250000000000000000) ((83 : ℝ) / 800) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((21058015285491243 : ℝ) / 100000000000000000) ((210905603434482021 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((488962826594770167 : ℝ) / 1000000000000000000) ((19707460288811299 : ℝ) / 40000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-897681558944288027 : ℝ) / 1000000000000000000) ((-220987314229107617 : ℝ) / 250000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((464402019048212863 : ℝ) / 500000000000000000) ((117988139175660619 : ℝ) / 125000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((2177488854720991483 : ℝ) / 500000000000000000) ((4358341708384857137 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((1320945436884602173 : ℝ) / 250000000000000000) ((5302246821790142089 : ℝ) / 1000000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((21058015285491243 : ℝ) / 100000000000000000) ((210905603434482021 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((3151518218286599 : ℝ) / 1000000000000000000) ((79869101756413 : ℝ) / 25000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((24920130898243587 : ℝ) / 25000000000000000) ((996848481781713401 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-326884414804584357 : ℝ) / 20000000000000000) ((-15481575903357645587 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-5530219496345404579 : ℝ) / 500000000000000000) ((-5089664540783751749 : ℝ) / 500000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-5530219496345404579 : ℝ) / 500000000000000000) ((-5089664540783751749 : ℝ) / 500000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_8_slab_plus_lo_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((458890131572811697 : ℝ) / 1000000000000000000) ((458890131572811697 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-50668624982687 : ℝ) / 250000000000000000) ((-101337249965367 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((519220686309999251 : ℝ) / 250000000000000000) ((1038441372619998523 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((28638839018588817 : ℝ) / 62500000000000000) ((458221424297421073 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((541109868427188303 : ℝ) / 1000000000000000000) ((541109868427188303 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-780402752532006123 : ℝ) / 1000000000000000000) ((-780402752532006119 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_414.1 dlower_m_log_415.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-307066468392744231 : ℝ) / 500000000000000000) ((-30706646839274423 : ℝ) / 50000000000000000) := rb_log h3 (by norm_num) dlower_m_log_411.1 dlower_m_log_411.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-166269815746517663 : ℝ) / 1000000000000000000) ((-166269815746517657 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-137061308181604167 : ℝ) / 1000000000000000000) ((-428316588067513 : ℝ) / 3125000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-155788892467805149 : ℝ) / 200000000000000000) ((-778944462339025743 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_412.1 dlower_m_log_412.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((80235394269677697 : ℝ) / 125000000000000000) ((128376630831484317 : ℝ) / 200000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-50668624982687 : ℝ) / 250000000000000000) ((-101337249965367 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-50668624982687 : ℝ) / 250000000000000000) ((-101337249965367 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((110169366427821731 : ℝ) / 500000000000000000) ((110169366427821747 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-56434233819707369 : ℝ) / 500000000000000000) ((-28217116909853683 : ℝ) / 250000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-93040939256800977 : ℝ) / 1000000000000000000) ((-9304093925680097 : ℝ) / 100000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((25459558719768497 : ℝ) / 200000000000000000) ((31824448399710631 : ℝ) / 250000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((519220686309999251 : ℝ) / 250000000000000000) ((1038441372619998523 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((519220686309999251 : ℝ) / 250000000000000000) ((1038441372619998523 : ℝ) / 500000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_8_slab_plus_lo_slope {q v : ℝ} (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200))
    (hv : RB v ((458890131572811697 : ℝ) / 1000000000000000000) ((458890131572811697 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-393354918668189 : ℝ) / 1000000000000000000) ((-12052046758663 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((103741319625205891 : ℝ) / 50000000000000000) ((16631587250126347 : ℝ) / 8000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458217377666561697 : ℝ) / 1000000000000000000) ((229112729360624599 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((541109868427188303 : ℝ) / 1000000000000000000) ((541109868427188303 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-390205791870024551 : ℝ) / 500000000000000000) ((-31215757921669803 : ℝ) / 40000000000000000) := rb_log h2 (by norm_num) dlower_m_log_408.1 dlower_m_log_416.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-307066468392744231 : ℝ) / 500000000000000000) ((-30706646839274423 : ℝ) / 50000000000000000) := rb_log h3 (by norm_num) dlower_m_log_411.1 dlower_m_log_411.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-83139323477280321 : ℝ) / 500000000000000000) ((-166261011256256613 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-68549835738007647 : ℝ) / 500000000000000000) ((-137022991253388609 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-155788892467805149 : ℝ) / 200000000000000000) ((-778944462339025743 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_412.1 dlower_m_log_412.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((641844790863010449 : ℝ) / 1000000000000000000) ((40120091942852321 : ℝ) / 62500000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-393354918668189 : ℝ) / 1000000000000000000) ((-12052046758663 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-393354918668189 : ℝ) / 1000000000000000000) ((-12052046758663 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((218733918453608021 : ℝ) / 1000000000000000000) ((221952982487010053 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-3537826867796461 : ℝ) / 31250000000000000) ((-112526484547352149 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-746752135710451 : ℝ) / 8000000000000000) ((-46369005551583207 : ℝ) / 500000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((62694950744900823 : ℝ) / 500000000000000000) ((129214971383843639 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((103741319625205891 : ℝ) / 50000000000000000) ((16631587250126347 : ℝ) / 8000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((103741319625205891 : ℝ) / 50000000000000000) ((16631587250126347 : ℝ) / 8000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_8_slab_plus_hi_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((459244600876789863 : ℝ) / 1000000000000000000) ((459244600876789863 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((202788819159977 : ℝ) / 1000000000000000000) ((202788819159991 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((16211418280763147 : ℝ) / 7812500000000000) ((2075061539937682857 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((229287946800699619 : ℝ) / 500000000000000000) ((458575893601399239 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((540755399123210137 : ℝ) / 1000000000000000000) ((540755399123210137 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-779629475135310183 : ℝ) / 1000000000000000000) ((-779629475135310179 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_417.1 dlower_m_log_418.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-153697057422468061 : ℝ) / 250000000000000000) ((-307394114844936121 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_410.1 dlower_m_log_410.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-164841245445437941 : ℝ) / 1000000000000000000) ((-32968249089087587 : ℝ) / 200000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-16985461733987199 : ℝ) / 125000000000000000) ((-27176738774379517 : ℝ) / 200000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-155634462269681979 : ℝ) / 200000000000000000) ((-778172311348409893 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_413.1 dlower_m_log_413.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((642288617476512301 : ℝ) / 1000000000000000000) ((64228861747651231 : ℝ) / 100000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((202788819159977 : ℝ) / 1000000000000000000) ((202788819159991 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((202788819159977 : ℝ) / 1000000000000000000) ((202788819159991 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((109222804454074841 : ℝ) / 500000000000000000) ((109222804454074857 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-28195305685297689 : ℝ) / 250000000000000000) ((-451124890964763 : ℝ) / 4000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18593804122324277 : ℝ) / 200000000000000000) ((-92969020611621379 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((125476588296528297 : ℝ) / 1000000000000000000) ((25095317659305667 : ℝ) / 200000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((16211418280763147 : ℝ) / 7812500000000000) ((2075061539937682857 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((16211418280763147 : ℝ) / 7812500000000000) ((2075061539937682857 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_8_slab_plus_hi_slope {q v : ℝ} (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200))
    (hv : RB v ((459244600876789863 : ℝ) / 1000000000000000000) ((459244600876789863 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((12381080043033 : ℝ) / 1000000000000000000) ((393138793159909 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((414603823983113223 : ℝ) / 200000000000000000) ((415422637781382133 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458571846970539863 : ℝ) / 1000000000000000000) ((114644982006306841 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((540755399123210137 : ℝ) / 1000000000000000000) ((540755399123210137 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-779638299516989143 : ℝ) / 1000000000000000000) ((-779620677450700827 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_419.1 dlower_m_log_409.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-153697057422468061 : ℝ) / 250000000000000000) ((-307394114844936121 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_410.1 dlower_m_log_410.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-164850069827116901 : ℝ) / 1000000000000000000) ((-164832447760828583 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-67960892243344111 : ℝ) / 500000000000000000) ((-135845649422854187 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-155634462269681979 : ℝ) / 200000000000000000) ((-778172311348409893 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_413.1 dlower_m_log_413.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((642250526861721671 : ℝ) / 1000000000000000000) ((160581665481388927 : ℝ) / 250000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((12381080043033 : ℝ) / 1000000000000000000) ((393138793159909 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((12381080043033 : ℝ) / 1000000000000000000) ((393138793159909 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((54213623077654817 : ℝ) / 250000000000000000) ((220046081270550719 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-28280737436620601 : ℝ) / 250000000000000000) ((-112439504759928013 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-93271863409369327 : ℝ) / 1000000000000000000) ((-9266632724558979 : ℝ) / 100000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((123582628901249941 : ℝ) / 1000000000000000000) ((127379754024960929 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((414603823983113223 : ℝ) / 200000000000000000) ((415422637781382133 : ℝ) / 200000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((414603823983113223 : ℝ) / 200000000000000000) ((415422637781382133 : ℝ) / 200000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_8_slab_minus_branch {q v : ℝ} (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200))
    (hv : RB v ((712652992656081193 : ℝ) / 500000000000000000) ((712668046374936091 : ℝ) / 500000000000000000)) :
    RB (phi q (v)) ((1425772312415603763 : ℝ) / 1000000000000000000) ((142580809940190533 : ℝ) / 100000000000000000) ∧
    RB (psi1 q (v)) ((184444939851058869 : ℝ) / 1000000000000000000) ((49073579507714273 : ℝ) / 250000000000000000) ∧
    RB (psi2 q (v)) ((127389145629809007 : ℝ) / 5000000000000000) ((41594621054380477 : ℝ) / 1600000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712316615702956193 : ℝ) / 500000000000000000) ((1424671419898309683 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-212668046374936091 : ℝ) / 500000000000000000) ((-212652992656081193 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((176957199561391861 : ℝ) / 500000000000000000) ((353941204604873611 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_420.1 dlower_m_log_421.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((212652992656081193 : ℝ) / 500000000000000000) ((212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854946403668124859 : ℝ) / 1000000000000000000) ((-170975123222023401 : ℝ) / 200000000000000000) := rb_log h5 (by norm_num) dlower_m_log_422.1 dlower_m_log_423.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208790015232900727 : ℝ) / 1000000000000000000) ((120888760827299847 : ℝ) / 100000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996216866678105787 : ℝ) / 1000000000000000000) ((249187278374573251 : ℝ) / 250000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((44298314650627737 : ℝ) / 125000000000000000) ((70881528094522633 : ℝ) / 200000000000000000) := rb_log hv (by norm_num) dlower_m_log_424.1 dlower_m_log_425.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((320904613102746311 : ℝ) / 500000000000000000) ((160590649073317777 : ℝ) / 250000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-13403736755813 : ℝ) / 31250000000000000) ((429073160875309 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-13403736755813 : ℝ) / 31250000000000000) ((429073160875309 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-806827019169526023 : ℝ) / 500000000000000000) ((-6361163681651529 : ℝ) / 4000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-3641288077269311 : ℝ) / 100000000000000000) ((-36192555897331351 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-1876441324121043 : ℝ) / 62500000000000000) ((-745696816211803 : ℝ) / 25000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-821838549762494367 : ℝ) / 500000000000000000) ((-162011879306135437 : ℝ) / 100000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((3821992393616593 : ℝ) / 12500000000000000) ((164807320910297683 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((3821992393616593 : ℝ) / 12500000000000000) ((164807320910297683 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((175479058896152013 : ℝ) / 250000000000000000) ((140387010207973433 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((212652992656081193 : ℝ) / 500000000000000000) ((212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-2351248358910417643 : ℝ) / 1000000000000000000) ((-293885240708948897 : ℝ) / 125000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-1649332123325809591 : ℝ) / 1000000000000000000) ((-1649146874631724011 : ℝ) / 1000000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-1359903369460303409 : ℝ) / 1000000000000000000) ((-54365370707370169 : ℝ) / 40000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((350794456509804703 : ℝ) / 500000000000000000) ((701603733026481121 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-206150710248678453 : ℝ) / 100000000000000000) ((-2060723180703863631 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-206150710248678453 : ℝ) / 100000000000000000) ((-2060723180703863631 : ℝ) / 1000000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((212652992656081193 : ℝ) / 500000000000000000) ((212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((180885181142349287 : ℝ) / 1000000000000000000) ((353341390226031 : ℝ) / 1953125000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((1381896555304909339 : ℝ) / 250000000000000000) ((2764184422639466073 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((2029579844026051909 : ℝ) / 1000000000000000000) ((63427770458595807 : ℝ) / 31250000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((492686401777266991 : ℝ) / 1000000000000000000) ((246356407939170461 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((2517436702670648217 : ℝ) / 500000000000000000) ((1007136488700333031 : ℝ) / 200000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((518682499108790469 : ℝ) / 125000000000000000) ((415200881957068637 : ℝ) / 100000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((2031497151766674059 : ℝ) / 1000000000000000000) ((507895744323868059 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((492227002872037053 : ℝ) / 1000000000000000000) ((123061949549173449 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((928337399148472161 : ℝ) / 200000000000000000) ((2322128308883690083 : ℝ) / 500000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((928337399148472161 : ℝ) / 200000000000000000) ((2322128308883690083 : ℝ) / 500000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((175479058896152013 : ℝ) / 250000000000000000) ((140387010207973433 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((212652992656081193 : ℝ) / 500000000000000000) ((212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-2351248358910417643 : ℝ) / 1000000000000000000) ((-293885240708948897 : ℝ) / 125000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-1649332123325809591 : ℝ) / 1000000000000000000) ((-1649146874631724011 : ℝ) / 1000000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((2169626873240514677 : ℝ) / 1000000000000000000) ((1100785310045957 : ℝ) / 500000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((25781249999999999 : ℝ) / 500000000000000000) ((83 : ℝ) / 1600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((2029579844026051909 : ℝ) / 1000000000000000000) ((63427770458595807 : ℝ) / 31250000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((3175517823955041 : ℝ) / 125000000000000000) ((3194934665461117 : ℝ) / 125000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((5234167021228161 : ℝ) / 250000000000000000) ((5268559746480881 : ℝ) / 250000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((2190563541325427321 : ℝ) / 1000000000000000000) ((555661214769459381 : ℝ) / 250000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((2190563541325427321 : ℝ) / 1000000000000000000) ((555661214769459381 : ℝ) / 250000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((810555128168277189 : ℝ) / 15625000000000000) ((52843467152109246423 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-1334825526621368691 : ℝ) / 500000000000000000) ((-263121121182735241 : ℝ) / 100000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-3641288077269311 : ℝ) / 100000000000000000) ((-36192555897331351 : ℝ) / 1000000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((47615129430873207 : ℝ) / 500000000000000000) ((97209685506422383 : ℝ) / 1000000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((5197075846163148651 : ℝ) / 100000000000000000) ((26470338418807834403 : ℝ) / 500000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-140387010207973433 : ℝ) / 100000000000000000) ((-280766494233843221 : ℝ) / 200000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((664672851562499 : ℝ) / 250000000000000000) ((6889 : ℝ) / 2560000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((2029579844026051909 : ℝ) / 1000000000000000000) ((63427770458595807 : ℝ) / 31250000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((327475275595363 : ℝ) / 250000000000000000) ((331474471541591 : ℝ) / 250000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-702597999982950347 : ℝ) / 500000000000000000) ((-1405142372271597557 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-579304419067657629 : ℝ) / 500000000000000000) ((-1158039455737350017 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((12703037405874042813 : ℝ) / 250000000000000000) ((51782637381878318789 : ℝ) / 1000000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((9782283877989577637 : ℝ) / 200000000000000000) ((49882486065629213777 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((9782283877989577637 : ℝ) / 200000000000000000) ((49882486065629213777 : ℝ) / 1000000000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-164807320910297683 : ℝ) / 500000000000000000) ((-3821992393616593 : ℝ) / 12500000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((3821992393616593 : ℝ) / 12500000000000000) ((164807320910297683 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((2060723180703863631 : ℝ) / 1000000000000000000) ((206150710248678453 : ℝ) / 100000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((9269898679966091 : ℝ) / 62500000000000000) ((79975477761164337 : ℝ) / 500000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((9269898679966091 : ℝ) / 62500000000000000) ((79975477761164337 : ℝ) / 500000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((21998341513430291 : ℝ) / 1000000000000000000) ((12792154086252983 : ℝ) / 500000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((51054707865394353 : ℝ) / 500000000000000000) ((118820092541160901 : ℝ) / 1000000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((2190563541325427321 : ℝ) / 500000000000000000) ((555661214769459381 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((649801666563661579 : ℝ) / 1000000000000000000) ((711028337992583347 : ℝ) / 1000000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((150382216458890057 : ℝ) / 200000000000000000) ((103731053816718031 : ℝ) / 125000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((4966333047224233847 : ℝ) / 100000000000000000) ((2028493379846518321 : ℝ) / 40000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-2028493379846518321 : ℝ) / 40000000000000000) ((-4966333047224233847 : ℝ) / 100000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((4966333047224233847 : ℝ) / 100000000000000000) ((2028493379846518321 : ℝ) / 40000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((2060723180703863631 : ℝ) / 1000000000000000000) ((206150710248678453 : ℝ) / 100000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((12045393977137827871 : ℝ) / 500000000000000000) ((24608998904375685579 : ℝ) / 1000000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((12045393977137827871 : ℝ) / 500000000000000000) ((24608998904375685579 : ℝ) / 1000000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((466327103441377 : ℝ) / 1000000000000000000) ((118001663008287 : ℝ) / 250000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((1425772312415603763 : ℝ) / 1000000000000000000) ((142580809940190533 : ℝ) / 100000000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((1425772312415603763 : ℝ) / 1000000000000000000) ((142580809940190533 : ℝ) / 100000000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((2031497151766674059 : ℝ) / 1000000000000000000) ((507895744323868059 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((327169925615019 : ℝ) / 1000000000000000000) ((82790407269947 : ℝ) / 250000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((249917209592730053 : ℝ) / 250000000000000000) ((999672830074384981 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((148269261523485261 : ℝ) / 1000000000000000000) ((159898624380108383 : ℝ) / 1000000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((25781249999999999 : ℝ) / 500000000000000000) ((83 : ℝ) / 1600) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((4521959790946701 : ℝ) / 125000000000000000) ((36395693650748709 : ℝ) / 1000000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((184444939851058869 : ℝ) / 1000000000000000000) ((49073579507714273 : ℝ) / 250000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((184444939851058869 : ℝ) / 1000000000000000000) ((49073579507714273 : ℝ) / 250000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((664672851562499 : ℝ) / 500000000000000000) ((6889 : ℝ) / 5120000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((2031497151766674059 : ℝ) / 1000000000000000000) ((507895744323868059 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((2895505049557650857 : ℝ) / 1000000000000000000) ((2895688542955480687 : ℝ) / 1000000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((91815516993979 : ℝ) / 200000000000000000) ((23234423519751 : ℝ) / 50000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((21998341513430291 : ℝ) / 1000000000000000000) ((12792154086252983 : ℝ) / 500000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((315592046729 : ℝ) / 31250000000000000) ((11888733030797 : ℝ) / 1000000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((25781249999999999 : ℝ) / 250000000000000000) ((83 : ℝ) / 800) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((2031497151766674059 : ℝ) / 1000000000000000000) ((507895744323868059 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((50760909671178819 : ℝ) / 1000000000000000000) ((25535354531453491 : ℝ) / 500000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((941096979109477 : ℝ) / 125000000000000000) ((8168808713814823 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-1631741953663899 : ℝ) / 200000000000000000) ((-7516887099845019 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((1403177826039218813 : ℝ) / 1000000000000000000) ((701603733026481121 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((697509558135449659 : ℝ) / 500000000000000000) ((1395690578953117223 : ℝ) / 1000000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((2031497151766674059 : ℝ) / 1000000000000000000) ((507895744323868059 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((327169925615019 : ℝ) / 1000000000000000000) ((82790407269947 : ℝ) / 250000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((249917209592730053 : ℝ) / 250000000000000000) ((999672830074384981 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((12041405004845451041 : ℝ) / 500000000000000000) ((12300473790017340451 : ℝ) / 500000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((127389145629809007 : ℝ) / 5000000000000000) ((41594621054380477 : ℝ) / 1600000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((127389145629809007 : ℝ) / 5000000000000000) ((41594621054380477 : ℝ) / 1600000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_8_slab_minus_lo_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((712652992656081193 : ℝ) / 500000000000000000) ((712652992656081193 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((31027972132889 : ℝ) / 1000000000000000000) ((6205594426581 : ℝ) / 200000000000000000) ∧
    RB (Eq q (v)) ((317687829777715711 : ℝ) / 1000000000000000000) ((158843914888857947 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424637278036771761 : ℝ) / 1000000000000000000) ((712318639018385881 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-212652992656081193 : ℝ) / 500000000000000000) ((-212652992656081193 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((88479309897697101 : ℝ) / 250000000000000000) ((176958619795394203 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_426.1 dlower_m_log_427.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((212652992656081193 : ℝ) / 500000000000000000) ((212652992656081193 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854946403668124859 : ℝ) / 1000000000000000000) ((-854946403668124857 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_422.1 dlower_m_log_422.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208863643258913261 : ℝ) / 1000000000000000000) ((241772728651782653 : ℝ) / 200000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996503373834507111 : ℝ) / 1000000000000000000) ((12456292172931339 : ℝ) / 12500000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((44298314650627737 : ℝ) / 125000000000000000) ((177193258602510949 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_424.1 dlower_m_log_424.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642116856629485213 : ℝ) / 1000000000000000000) ((80264607078685653 : ℝ) / 125000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((31027972132889 : ℝ) / 1000000000000000000) ((6205594426581 : ℝ) / 200000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((31027972132889 : ℝ) / 1000000000000000000) ((6205594426581 : ℝ) / 200000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-320394272592443421 : ℝ) / 200000000000000000) ((-1601971362962216927 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-36303100303026797 : ℝ) / 1000000000000000000) ((-7260620060605359 : ℝ) / 200000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29925758901221703 : ℝ) / 1000000000000000000) ((-29925758901221701 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-203987140232929851 : ℝ) / 125000000000000000) ((-407974280465859657 : ℝ) / 250000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((317687829777715711 : ℝ) / 1000000000000000000) ((158843914888857947 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((317687829777715711 : ℝ) / 1000000000000000000) ((158843914888857947 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_8_slab_minus_lo_slope {q v : ℝ} (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200))
    (hv : RB v ((712652992656081193 : ℝ) / 500000000000000000) ((712652992656081193 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-69891435487809 : ℝ) / 200000000000000000) ((205824264621061 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((305787600520888833 : ℝ) / 1000000000000000000) ((164760441474849843 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712316615702956193 : ℝ) / 500000000000000000) ((1424641312460599887 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-212652992656081193 : ℝ) / 500000000000000000) ((-212652992656081193 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((176957199561391861 : ℝ) / 500000000000000000) ((353920071482230389 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_420.1 dlower_m_log_428.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((212652992656081193 : ℝ) / 500000000000000000) ((212652992656081193 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854946403668124859 : ℝ) / 1000000000000000000) ((-854946403668124857 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_422.1 dlower_m_log_422.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208860802790908579 : ℝ) / 1000000000000000000) ((75554154696897203 : ℝ) / 62500000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996275205809261491 : ℝ) / 1000000000000000000) ((996731688866659817 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((44298314650627737 : ℝ) / 125000000000000000) ((177193258602510949 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_424.1 dlower_m_log_424.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((641888688604239593 : ℝ) / 1000000000000000000) ((642345171661637921 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-69891435487809 : ℝ) / 200000000000000000) ((205824264621061 : ℝ) / 500000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-69891435487809 : ℝ) / 200000000000000000) ((205824264621061 : ℝ) / 500000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1613625829307490653 : ℝ) / 1000000000000000000) ((-19879800611512829 : ℝ) / 12500000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-3641288077269311 : ℝ) / 100000000000000000) ((-9048330191783979 : ℝ) / 250000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-1876441324121043 : ℝ) / 62500000000000000) ((-2982850301122373 : ℝ) / 100000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1643648890493427341 : ℝ) / 1000000000000000000) ((-32404251038645001 : ℝ) / 20000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((305787600520888833 : ℝ) / 1000000000000000000) ((164760441474849843 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((305787600520888833 : ℝ) / 1000000000000000000) ((164760441474849843 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_8_slab_minus_hi_center {q v : ℝ} (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hv : RB v ((712668046374936091 : ℝ) / 500000000000000000) ((712668046374936091 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-31026919968491 : ℝ) / 1000000000000000000) ((-15513459984237 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((158877131785332407 : ℝ) / 500000000000000000) ((158877131785332499 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((20897102355957 : ℝ) / 31250000000000000) ((109561 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424667385474481557 : ℝ) / 1000000000000000000) ((712333692737240779 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-212668046374936091 : ℝ) / 500000000000000000) ((-212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353938372773277787 : ℝ) / 1000000000000000000) ((353938372773277789 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_429.1 dlower_m_log_430.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((212668046374936091 : ℝ) / 500000000000000000) ((212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854875616110117007 : ℝ) / 1000000000000000000) ((-170975123222023401 : ℝ) / 200000000000000000) := rb_log h5 (by norm_num) dlower_m_log_423.1 dlower_m_log_423.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((151101748610424349 : ℝ) / 125000000000000000) ((302203497220848699 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((498231221104998499 : ℝ) / 500000000000000000) ((62278902638124813 : ℝ) / 62500000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354407640472613163 : ℝ) / 1000000000000000000) ((70881528094522633 : ℝ) / 200000000000000000) := rb_log hv (by norm_num) dlower_m_log_425.1 dlower_m_log_425.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642054801737383833 : ℝ) / 1000000000000000000) ((128410960347476769 : ℝ) / 200000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-31026919968491 : ℝ) / 1000000000000000000) ((-15513459984237 : ℝ) / 500000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-31026919968491 : ℝ) / 1000000000000000000) ((-15513459984237 : ℝ) / 500000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1601905561589109449 : ℝ) / 1000000000000000000) ((-1601905561589109271 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-331 : ℝ) / 6400) ((-25859374999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-7260466622217959 : ℝ) / 200000000000000000) ((-36302333111089793 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-935160202543133 : ℝ) / 31250000000000000) ((-29925126481380253 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-326366137614097941 : ℝ) / 200000000000000000) ((-407957672017622381 : ℝ) / 250000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((158877131785332407 : ℝ) / 500000000000000000) ((158877131785332499 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((158877131785332407 : ℝ) / 500000000000000000) ((158877131785332499 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_8_slab_minus_hi_slope {q v : ℝ} (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200))
    (hv : RB v ((712668046374936091 : ℝ) / 500000000000000000) ((712668046374936091 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-6429730377591 : ℝ) / 15625000000000000) ((69916861121617 : ℝ) / 200000000000000000) ∧
    RB (Eq q (v)) ((38231814375831543 : ℝ) / 125000000000000000) ((329586838808268917 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((664672851562499 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 10240000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712331669421811091 : ℝ) / 500000000000000000) ((1424671419898309683 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-212668046374936091 : ℝ) / 500000000000000000) ((-212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((88483883091325171 : ℝ) / 250000000000000000) ((353941204604873611 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_431.1 dlower_m_log_421.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((212668046374936091 : ℝ) / 500000000000000000) ((212668046374936091 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854875616110117007 : ℝ) / 1000000000000000000) ((-170975123222023401 : ℝ) / 200000000000000000) := rb_log h5 (by norm_num) dlower_m_log_423.1 dlower_m_log_423.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208811148475417689 : ℝ) / 1000000000000000000) ((604408410357495309 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996234283510125979 : ℝ) / 1000000000000000000) ((996690747910617047 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((354407640472613163 : ℝ) / 1000000000000000000) ((70881528094522633 : ℝ) / 200000000000000000) := rb_log hv (by norm_num) dlower_m_log_425.1 dlower_m_log_425.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((320913321518756407 : ℝ) / 500000000000000000) ((160570776859500971 : ℝ) / 250000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-6429730377591 : ℝ) / 15625000000000000) ((69916861121617 : ℝ) / 200000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-6429730377591 : ℝ) / 15625000000000000) ((69916861121617 : ℝ) / 200000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-806779774649827987 : ℝ) / 500000000000000000) ((-1590318723425208699 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-83 : ℝ) / 1600) ((-25781249999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-284469619207689 : ℝ) / 7812500000000000) ((-36192555897331351 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-1876401669250491 : ℝ) / 62500000000000000) ((-745696816211803 : ℝ) / 25000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-164358197600766383 : ℝ) / 100000000000000000) ((-1620146596073680819 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((38231814375831543 : ℝ) / 125000000000000000) ((329586838808268917 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((38231814375831543 : ℝ) / 125000000000000000) ((329586838808268917 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_8_point_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((25859374999999999 : ℝ) / 1000000000000000000) ((331 : ℝ) / 12800))
    (hplus : RB (vPlus q) ((459067366224799 : ℝ) / 1000000000000000) ((229533683112401 : ℝ) / 500000000000000))
    (hminus : RB (vMinus q) ((178165129878877 : ℝ) / 125000000000000) ((1425321039031019 : ℝ) / 1000000000000000)) :
RB (Lam q) ((917215578629238879 : ℝ) / 500000000000000000) ((1834431157258489199 : ℝ) / 1000000000000000000) ∧
    RB (lam1 q) ((9464543777535751 : ℝ) / 1000000000000000000) ((2366135944426199 : ℝ) / 250000000000000000) ∧
    RB (lam2 q) ((32782131767478822399 : ℝ) / 500000000000000000) ((65564263534964823909 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_point hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_8_point_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_8_point_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((482633085283500411 : ℝ) / 500000000000000000) ((482633085283503419 : ℝ) / 500000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((1886848584045876681 : ℝ) / 1000000000000000000) ((377369716809190777 : ℝ) / 200000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((18176677017015617753 : ℝ) / 500000000000000000) ((36353354034034677567 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((917215578629238879 : ℝ) / 500000000000000000) ((1834431157258489199 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-3576379379012818791 : ℝ) / 1000000000000000000) ((-1788189689506398241 : ℝ) / 500000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((1792921961395177271 : ℝ) / 500000000000000000) ((1792921961395250639 : ℝ) / 500000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((9464543777535751 : ℝ) / 1000000000000000000) ((2366135944426199 : ℝ) / 250000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((10458683128024627591 : ℝ) / 1000000000000000000) ((2614670782006173213 : ℝ) / 250000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-1852535335881510477 : ℝ) / 250000000000000000) ((-463133833970377617 : ℝ) / 62500000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-559272588064499781 : ℝ) / 40000000000000000) ((-13981814701611922363 : ℝ) / 1000000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-1761565786793933467 : ℝ) / 500000000000000000) ((-3523131573587229511 : ℝ) / 1000000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((17271848777136377933 : ℝ) / 250000000000000000) ((3454369755427602671 : ℝ) / 50000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((32782131767478822399 : ℝ) / 500000000000000000) ((65564263534964823909 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((917215578629238879 : ℝ) / 500000000000000000) ((1834431157258489199 : ℝ) / 1000000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((9464543777535751 : ℝ) / 1000000000000000000) ((2366135944426199 : ℝ) / 250000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((32782131767478822399 : ℝ) / 500000000000000000) ((65564263534964823909 : ℝ) / 1000000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

theorem dlower_m_8_slab_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((25781249999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 3200))
    (hplus : RB (vPlus q) ((458890131572811697 : ℝ) / 1000000000000000000) ((459244600876789863 : ℝ) / 1000000000000000000))
    (hminus : RB (vMinus q) ((712652992656081193 : ℝ) / 500000000000000000) ((712668046374936091 : ℝ) / 500000000000000000)) :
RB (Lam q) ((458440798649135421 : ℝ) / 250000000000000000) ((183509925425387099 : ℝ) / 100000000000000000) ∧
    RB (lam1 q) ((-1815472321627541 : ℝ) / 100000000000000000) ((18566052846898787 : ℝ) / 500000000000000000) ∧
    RB (lam2 q) ((320613250525507271 : ℝ) / 5000000000000000) ((13404077227613561767 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_8_slab hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_8_slab_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_8_slab_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((482530832917134897 : ℝ) / 500000000000000000) ((3771369726963987 : ℝ) / 3906250000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((1873429562523718607 : ℝ) / 1000000000000000000) ((950144562696969023 : ℝ) / 500000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((17828579103764652449 : ℝ) / 500000000000000000) ((37057077151678607283 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((458440798649135421 : ℝ) / 250000000000000000) ((183509925425387099 : ℝ) / 100000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-715590874469140859 : ℝ) / 200000000000000000) ((-714960977485096971 : ℝ) / 200000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((711959929825885777 : ℝ) / 200000000000000000) ((3611936993119282429 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((-1815472321627541 : ℝ) / 100000000000000000) ((18566052846898787 : ℝ) / 500000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((10453282643705347123 : ℝ) / 1000000000000000000) ((10464085902366720883 : ℝ) / 1000000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-926479321760016119 : ℝ) / 125000000000000000) ((-3704224314344889453 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-3521157160085819889 : ℝ) / 250000000000000000) ((-555168266937029421 : ℝ) / 40000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-3631345996637932433 : ℝ) / 1000000000000000000) ((-1707560385529507321 : ℝ) / 500000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((67753996101739386633 : ℝ) / 1000000000000000000) ((70435506909126823477 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((320613250525507271 : ℝ) / 5000000000000000) ((13404077227613561767 : ℝ) / 200000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((458440798649135421 : ℝ) / 250000000000000000) ((183509925425387099 : ℝ) / 100000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((-1815472321627541 : ℝ) / 100000000000000000) ((18566052846898787 : ℝ) / 500000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((320613250525507271 : ℝ) / 5000000000000000) ((13404077227613561767 : ℝ) / 200000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

end EP1038.DLowerCert
