import LeanProject.DLowerMLogs
import LeanProject.DLowerMNumeric02
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_param_5_point {q : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600)) :
    RB (delta (q)) ((642466643220851717 : ℝ) / 1000000000000000000) ((321233321610425861 : ℝ) / 500000000000000000) ∧
    RB (delta1 (q)) ((-60936131317362989 : ℝ) / 31250000000000000) ((-389991240431123129 : ℝ) / 200000000000000000) ∧
    RB (delta2 (q)) ((1901164595162576093 : ℝ) / 1000000000000000000) ((1901164595162576099 : ℝ) / 1000000000000000000) ∧
    RB (aval (q)) ((824590322431219193 : ℝ) / 1000000000000000000) ((412295161215609599 : ℝ) / 500000000000000000) ∧
    RB (aval1 (q)) ((-1333696202239576781 : ℝ) / 1000000000000000000) ((-666848101119788319 : ℝ) / 500000000000000000) ∧
    RB (aval2 (q)) ((43816001051050639171 : ℝ) / 1000000000000000000) ((43816001051050698121 : ℝ) / 1000000000000000000) ∧
    RB (D0q (q)) ((1901164595162576093 : ℝ) / 1000000000000000000) ((1901164595162576099 : ℝ) / 1000000000000000000) ∧
    RB (d01 (q)) ((-1853593846827967711 : ℝ) / 500000000000000000) ((-926796923413983851 : ℝ) / 250000000000000000) ∧
    RB (d02 (q)) ((1355410056712380693 : ℝ) / 125000000000000000) ((10843280453699045623 : ℝ) / 1000000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1025664062499999999 : ℝ) / 1000000000000000000) ((26257 : ℝ) / 25600) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-915665902995760843 : ℝ) / 250000000000000000) ((-3662663611983043331 : ℝ) / 1000000000000000000) := rb_log hq (by norm_num) dlower_m_log_240.1 dlower_m_log_241.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((12670134334773397 : ℝ) / 500000000000000000) ((6335067167386699 : ℝ) / 250000000000000000) := rb_log h1 (by norm_num) dlower_m_log_242.1 dlower_m_log_243.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((12670134334773397 : ℝ) / 250000000000000000) ((6335067167386699 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((642466643220851717 : ℝ) / 1000000000000000000) ((321233321610425861 : ℝ) / 500000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((642466643220851717 : ℝ) / 1000000000000000000) ((321233321610425861 : ℝ) / 500000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-60936131317362989 : ℝ) / 31250000000000000) ((-389991240431123129 : ℝ) / 200000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-60936131317362989 : ℝ) / 31250000000000000) ((-389991240431123129 : ℝ) / 200000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((16437293267250061 : ℝ) / 15625000000000000) ((1051986769104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((1901164595162576093 : ℝ) / 1000000000000000000) ((1901164595162576099 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((1901164595162576093 : ℝ) / 1000000000000000000) ((1901164595162576099 : ℝ) / 1000000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-321233321610425861 : ℝ) / 500000000000000000) ((-642466643220851717 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((3662663611983043331 : ℝ) / 1000000000000000000) ((915665902995760843 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-175409677568780807 : ℝ) / 1000000000000000000) ((-87704838784390401 : ℝ) / 500000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((824590322431219193 : ℝ) / 1000000000000000000) ((412295161215609599 : ℝ) / 500000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((824590322431219193 : ℝ) / 1000000000000000000) ((412295161215609599 : ℝ) / 500000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((389991240431123129 : ℝ) / 200000000000000000) ((60936131317362989 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((3662663611983043331 : ℝ) / 1000000000000000000) ((915665902995760843 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((532387466808579837 : ℝ) / 1000000000000000000) ((106477493361715969 : ℝ) / 200000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((3662663611983043331 : ℝ) / 1000000000000000000) ((915665902995760843 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((6707552367272336697 : ℝ) / 500000000000000000) ((419222022954521053 : ℝ) / 31250000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((344286086351400393 : ℝ) / 1000000000000000000) ((68857217270280083 : ℝ) / 200000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((1866083669048156483 : ℝ) / 1000000000000000000) ((933041834524078309 : ℝ) / 500000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-1333696202239576781 : ℝ) / 1000000000000000000) ((-666848101119788319 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-1333696202239576781 : ℝ) / 1000000000000000000) ((-666848101119788319 : ℝ) / 500000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-1901164595162576099 : ℝ) / 1000000000000000000) ((-1901164595162576093 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((3662663611983043331 : ℝ) / 1000000000000000000) ((915665902995760843 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-259533060713326809 : ℝ) / 500000000000000000) ((-519066121426653609 : ℝ) / 1000000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-60936131317362989 : ℝ) / 15625000000000000) ((-389991240431123129 : ℝ) / 100000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((3662663611983043331 : ℝ) / 1000000000000000000) ((915665902995760843 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((6707552367272336697 : ℝ) / 500000000000000000) ((419222022954521053 : ℝ) / 31250000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((344286086351400393 : ℝ) / 1000000000000000000) ((68857217270280083 : ℝ) / 200000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-707970885064087977 : ℝ) / 62500000000000000) ((-1132753416102540689 : ℝ) / 100000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((1351058504949844159 : ℝ) / 125000000000000000) ((10808468039598754023 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-415665902995760843 : ℝ) / 250000000000000000) ((-1662663611983043331 : ℝ) / 1000000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-106820590959620257 : ℝ) / 100000000000000000) ((-213641181919240507 : ℝ) / 200000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((3662663611983043331 : ℝ) / 1000000000000000000) ((915665902995760843 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((6707552367272336697 : ℝ) / 500000000000000000) ((419222022954521053 : ℝ) / 31250000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((8835779638002733 : ℝ) / 1000000000000000000) ((2208944909500687 : ℝ) / 250000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-32362488563613373 : ℝ) / 1000000000000000000) ((-32362488563613317 : ℝ) / 1000000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((213641181919240507 : ℝ) / 200000000000000000) ((106820590959620257 : ℝ) / 100000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((32362488563613317 : ℝ) / 1000000000000000000) ((32362488563613373 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((33007533011451885899 : ℝ) / 1000000000000000000) ((16503766505725972049 : ℝ) / 500000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((43816001051050639171 : ℝ) / 1000000000000000000) ((43816001051050698121 : ℝ) / 1000000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((43816001051050639171 : ℝ) / 1000000000000000000) ((43816001051050698121 : ℝ) / 1000000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((16437293267250061 : ℝ) / 15625000000000000) ((1051986769104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((1901164595162576093 : ℝ) / 1000000000000000000) ((1901164595162576099 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((1901164595162576093 : ℝ) / 1000000000000000000) ((1901164595162576099 : ℝ) / 1000000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((16437293267250061 : ℝ) / 15625000000000000) ((1051986769104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((67436563955966383 : ℝ) / 62500000000000000) ((1078985023295462133 : ℝ) / 1000000000000000000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-1853593846827967711 : ℝ) / 500000000000000000) ((-926796923413983851 : ℝ) / 250000000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-1853593846827967711 : ℝ) / 500000000000000000) ((-926796923413983851 : ℝ) / 250000000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((16437293267250061 : ℝ) / 15625000000000000) ((1051986769104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((553338081184940411 : ℝ) / 500000000000000000) ((110667616236988083 : ℝ) / 100000000000000000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((1355410056712380693 : ℝ) / 125000000000000000) ((10843280453699045623 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((1355410056712380693 : ℝ) / 125000000000000000) ((10843280453699045623 : ℝ) / 1000000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_param_5_slab {q : ℝ} (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800)) :
    RB (delta (q)) ((642390474507141663 : ℝ) / 1000000000000000000) ((64254281483550873 : ℝ) / 100000000000000000) ∧
    RB (delta1 (q)) ((-97501523461304083 : ℝ) / 50000000000000000) ((-243735242592733643 : ℝ) / 125000000000000000) ∧
    RB (delta2 (q)) ((1901019791415639047 : ℝ) / 1000000000000000000) ((1901309415455046107 : ℝ) / 1000000000000000000) ∧
    RB (aval (q)) ((824496648277044343 : ℝ) / 1000000000000000000) ((824684028874456519 : ℝ) / 1000000000000000000) ∧
    RB (aval1 (q)) ((-334639324150751299 : ℝ) / 250000000000000000) ((-1328849232570718897 : ℝ) / 1000000000000000000) ∧
    RB (aval2 (q)) ((10903367157546830503 : ℝ) / 250000000000000000) ((8803935102635850617 : ℝ) / 200000000000000000) ∧
    RB (D0q (q)) ((1901019791415639047 : ℝ) / 1000000000000000000) ((1901309415455046107 : ℝ) / 1000000000000000000) ∧
    RB (d01 (q)) ((-3707611291563770599 : ℝ) / 1000000000000000000) ((-741352832054845907 : ℝ) / 200000000000000000) ∧
    RB (d02 (q)) ((5420814371030939681 : ℝ) / 500000000000000000) ((10844932479894027357 : ℝ) / 1000000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1025624999999999999 : ℝ) / 1000000000000000000) ((13129 : ℝ) / 12800) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-1832093420761782421 : ℝ) / 500000000000000000) ((-3661142699142336641 : ℝ) / 1000000000000000000) := rb_log hq (by norm_num) dlower_m_log_244.1 dlower_m_log_245.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((2530218286221829 : ℝ) / 100000000000000000) ((25378353026401823 : ℝ) / 1000000000000000000) := rb_log h1 (by norm_num) dlower_m_log_246.1 dlower_m_log_247.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((2530218286221829 : ℝ) / 50000000000000000) ((25378353026401823 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((642390474507141663 : ℝ) / 1000000000000000000) ((64254281483550873 : ℝ) / 100000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((642390474507141663 : ℝ) / 1000000000000000000) ((64254281483550873 : ℝ) / 100000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-97501523461304083 : ℝ) / 50000000000000000) ((-243735242592733643 : ℝ) / 125000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-97501523461304083 : ℝ) / 50000000000000000) ((-243735242592733643 : ℝ) / 125000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((1051906640624999997 : ℝ) / 1000000000000000000) ((172370641 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((1901019791415639047 : ℝ) / 1000000000000000000) ((1901309415455046107 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((1901019791415639047 : ℝ) / 1000000000000000000) ((1901309415455046107 : ℝ) / 1000000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-64254281483550873 : ℝ) / 100000000000000000) ((-642390474507141663 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((3661142699142336641 : ℝ) / 1000000000000000000) ((1832093420761782421 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-175503351722955657 : ℝ) / 1000000000000000000) ((-175315971125543481 : ℝ) / 1000000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((824496648277044343 : ℝ) / 1000000000000000000) ((824684028874456519 : ℝ) / 1000000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((824496648277044343 : ℝ) / 1000000000000000000) ((824684028874456519 : ℝ) / 1000000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((243735242592733643 : ℝ) / 125000000000000000) ((97501523461304083 : ℝ) / 50000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((3661142699142336641 : ℝ) / 1000000000000000000) ((1832093420761782421 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((266072941292905029 : ℝ) / 500000000000000000) ((532628916562825581 : ℝ) / 1000000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((3661142699142336641 : ℝ) / 1000000000000000000) ((1832093420761782421 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((13403965863483234109 : ℝ) / 1000000000000000000) ((13426265209594438091 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((17173831262587893 : ℝ) / 50000000000000000) ((172548486482678521 : ℝ) / 500000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((930739074566772239 : ℝ) / 500000000000000000) ((935351589594407627 : ℝ) / 500000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-334639324150751299 : ℝ) / 250000000000000000) ((-1328849232570718897 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-334639324150751299 : ℝ) / 250000000000000000) ((-1328849232570718897 : ℝ) / 1000000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-1901309415455046107 : ℝ) / 1000000000000000000) ((-1901019791415639047 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((3661142699142336641 : ℝ) / 1000000000000000000) ((1832093420761782421 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-519321308044193133 : ℝ) / 1000000000000000000) ((-518810823147107071 : ℝ) / 1000000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-97501523461304083 : ℝ) / 25000000000000000) ((-243735242592733643 : ℝ) / 62500000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((3661142699142336641 : ℝ) / 1000000000000000000) ((1832093420761782421 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((13403965863483234109 : ℝ) / 1000000000000000000) ((13426265209594438091 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((17173831262587893 : ℝ) / 50000000000000000) ((172548486482678521 : ℝ) / 500000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-5677330932772409109 : ℝ) / 500000000000000000) ((-2825121767929286203 : ℝ) / 250000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((10781165763672951679 : ℝ) / 1000000000000000000) ((10835851042397711147 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-832093420761782421 : ℝ) / 500000000000000000) ((-1661142699142336641 : ℝ) / 1000000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-267327824391191509 : ℝ) / 250000000000000000) ((-1067102246726119699 : ℝ) / 1000000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((3661142699142336641 : ℝ) / 1000000000000000000) ((1832093420761782421 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((13403965863483234109 : ℝ) / 1000000000000000000) ((13426265209594438091 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((4400794261038141 : ℝ) / 500000000000000000) ((8870070633250193 : ℝ) / 1000000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-2031349756108747 : ℝ) / 62500000000000000) ((-4027983944806821 : ℝ) / 125000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((1067102246726119699 : ℝ) / 1000000000000000000) ((267327824391191509 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((4027983944806821 : ℝ) / 125000000000000000) ((2031349756108747 : ℝ) / 62500000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((32832302866514370333 : ℝ) / 1000000000000000000) ((16591912235390770969 : ℝ) / 500000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((10903367157546830503 : ℝ) / 250000000000000000) ((8803935102635850617 : ℝ) / 200000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((10903367157546830503 : ℝ) / 250000000000000000) ((8803935102635850617 : ℝ) / 200000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((1051906640624999997 : ℝ) / 1000000000000000000) ((172370641 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((1901019791415639047 : ℝ) / 1000000000000000000) ((1901309415455046107 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((1901019791415639047 : ℝ) / 1000000000000000000) ((1901309415455046107 : ℝ) / 1000000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((1051906640624999997 : ℝ) / 1000000000000000000) ((172370641 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((53943087414550781 : ℝ) / 50000000000000000) ((539554153845071793 : ℝ) / 500000000000000000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-3707611291563770599 : ℝ) / 1000000000000000000) ((-741352832054845907 : ℝ) / 200000000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-3707611291563770599 : ℝ) / 1000000000000000000) ((-741352832054845907 : ℝ) / 200000000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((1051906640624999997 : ℝ) / 1000000000000000000) ((172370641 : ℝ) / 163840000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((553253790295486447 : ℝ) / 500000000000000000) ((69177797713202613 : ℝ) / 62500000000000000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((5420814371030939681 : ℝ) / 500000000000000000) ((10844932479894027357 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((5420814371030939681 : ℝ) / 500000000000000000) ((10844932479894027357 : ℝ) / 1000000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_5_point_plus_branch {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((459421531057623 : ℝ) / 1000000000000000) ((229710765528813 : ℝ) / 500000000000000)) :
    RB (phi q (v)) ((230427584462490613 : ℝ) / 500000000000000000) ((230427584462492119 : ℝ) / 500000000000000000) ∧
    RB (psi1 q (v)) ((-211798478762509419 : ℝ) / 125000000000000000) ((-1694387830100005641 : ℝ) / 1000000000000000000) ∧
    RB (psi2 q (v)) ((-5318952753811370413 : ℝ) / 500000000000000000) ((-1063790550761975097 : ℝ) / 100000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458762886953619093 : ℝ) / 1000000000000000000) ((229381443476811047 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270289234471187 : ℝ) / 500000000000000) ((540578468942377 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-155844357711176751 : ℝ) / 200000000000000000) ((-779221788555877211 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_248.1 dlower_m_log_249.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-24604618960338739 : ℝ) / 40000000000000000) ((-615115474008462923 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_250.1 dlower_m_log_251.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-5128322329606901 : ℝ) / 31250000000000000) ((-5128322329606523 : ℝ) / 31250000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-67660239412828411 : ℝ) / 500000000000000000) ((-67660239412823423 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-388893561023253589 : ℝ) / 500000000000000000) ((-388893561023250323 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_252.1 dlower_m_log_253.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((40154165201302739 : ℝ) / 62500000000000000) ((160616660805215083 : ℝ) / 250000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-3949 : ℝ) / 500000000000000000) ((1723 : ℝ) / 200000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-3949 : ℝ) / 500000000000000000) ((1723 : ℝ) / 200000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((218867968475412419 : ℝ) / 1000000000000000000) ((6839624014857143 : ℝ) / 31250000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-2797094450078591 : ℝ) / 25000000000000000) ((-111883778003142903 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18451656115687033 : ℝ) / 200000000000000000) ((-18451656115686911 : ℝ) / 200000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((63304843948488627 : ℝ) / 500000000000000000) ((126609687896994021 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2076565890052592899 : ℝ) / 1000000000000000000) ((2076565890052609669 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2076565890052592899 : ℝ) / 1000000000000000000) ((2076565890052609669 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((87191011168354899 : ℝ) / 40000000000000000) ((435955055841777347 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((369974039830504263 : ℝ) / 200000000000000000) ((1849870199152531583 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((402964547836139379 : ℝ) / 100000000000000000) ((2014822739180709159 : ℝ) / 500000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((51918854129461347 : ℝ) / 15625000000000000) ((664561332857109291 : ℝ) / 200000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((435330054165253457 : ℝ) / 200000000000000000) ((4353300541652563 : ℝ) / 2000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((286539098364811177 : ℝ) / 250000000000000000) ((114615639345927917 : ℝ) / 100000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((286539098364811177 : ℝ) / 250000000000000000) ((114615639345927917 : ℝ) / 100000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((292225081084081211 : ℝ) / 1000000000000000000) ((58445016216816891 : ℝ) / 200000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((427752469214073609 : ℝ) / 125000000000000000) ((3422019753712626861 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((210463386446019091 : ℝ) / 1000000000000000000) ((42092677289204369 : ℝ) / 200000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((4751420267850117957 : ℝ) / 1000000000000000000) ((1187855066962545033 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-66470025706879563 : ℝ) / 50000000000000000) ((-166175064267186387 : ℝ) / 125000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-1096210798592944953 : ℝ) / 1000000000000000000) ((-68513174912053897 : ℝ) / 62500000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((105534071599665227 : ℝ) / 500000000000000000) ((52767035799833303 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((2368903200744031353 : ℝ) / 500000000000000000) ((947561280297624923 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((3641595602895117753 : ℝ) / 1000000000000000000) ((3641595602895262263 : ℝ) / 1000000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((3641595602895117753 : ℝ) / 1000000000000000000) ((3641595602895262263 : ℝ) / 1000000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((87191011168354899 : ℝ) / 40000000000000000) ((435955055841777347 : ℝ) / 200000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((369974039830504263 : ℝ) / 200000000000000000) ((1849870199152531583 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((402964547836139379 : ℝ) / 100000000000000000) ((2014822739180709159 : ℝ) / 500000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-5374322870862506287 : ℝ) / 1000000000000000000) ((-5374322870862472997 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((25664062499999999 : ℝ) / 500000000000000000) ((657 : ℝ) / 12800) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((210463386446019091 : ℝ) / 1000000000000000000) ((42092677289204369 : ℝ) / 200000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((121940746717872163 : ℝ) / 500000000000000000) ((30485186679468441 : ℝ) / 125000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((1256889495669923 : ℝ) / 6250000000000000) ((201102319307190323 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-5173220551555318607 : ℝ) / 1000000000000000000) ((-2586610275777641337 : ℝ) / 500000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-5173220551555318607 : ℝ) / 1000000000000000000) ((-2586610275777641337 : ℝ) / 500000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-7190482450693847647 : ℝ) / 1000000000000000000) ((-7190482450693307973 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-1333696202239576781 : ℝ) / 500000000000000000) ((-666848101119788319 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-2797094450078591 : ℝ) / 25000000000000000) ((-111883778003142903 : ℝ) / 1000000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((149218969815007573 : ℝ) / 500000000000000000) ((59687587926003429 : ℝ) / 200000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-6892044511063832501 : ℝ) / 1000000000000000000) ((-1723011127765822707 : ℝ) / 250000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-435955055841777347 : ℝ) / 100000000000000000) ((-4359550558417744951 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((329322052001953 : ℝ) / 125000000000000000) ((658644104003907 : ℝ) / 250000000000000000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((210463386446019091 : ℝ) / 1000000000000000000) ((42092677289204369 : ℝ) / 200000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((12517979780256559 : ℝ) / 1000000000000000000) ((12517979780256743 : ℝ) / 1000000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-4372068538198030213 : ℝ) / 1000000000000000000) ((-437206853819800151 : ℝ) / 100000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-1802582702802051461 : ℝ) / 500000000000000000) ((-3605165405604079231 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-10497209916667935423 : ℝ) / 1000000000000000000) ((-10497209916667370059 : ℝ) / 1000000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-6199187255915255761 : ℝ) / 500000000000000000) ((-1549796813978743269 : ℝ) / 125000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-6199187255915255761 : ℝ) / 500000000000000000) ((-1549796813978743269 : ℝ) / 125000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-2076565890052609669 : ℝ) / 1000000000000000000) ((-2076565890052592899 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-1811764870747936613 : ℝ) / 1000000000000000000) ((-362352974149573501 : ℝ) / 200000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-1811764870747936613 : ℝ) / 1000000000000000000) ((-362352974149573501 : ℝ) / 200000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((362352974149573501 : ℝ) / 200000000000000000) ((1811764870747936613 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((1641245973438018523 : ℝ) / 500000000000000000) ((1641245973438143731 : ℝ) / 500000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((11953508240282410961 : ℝ) / 1000000000000000000) ((11953508240283797229 : ℝ) / 1000000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-5173220551555318607 : ℝ) / 500000000000000000) ((-2586610275777641337 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((4686329631969384279 : ℝ) / 250000000000000000) ((18745318527878382343 : ℝ) / 1000000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((30698826768159948077 : ℝ) / 1000000000000000000) ((7674706692040544893 : ℝ) / 250000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((3660090451265887311 : ℝ) / 200000000000000000) ((915022612816611671 : ℝ) / 50000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-915022612816611671 : ℝ) / 50000000000000000) ((-3660090451265887311 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-7983401026582052173 : ℝ) / 500000000000000000) ((-15966802053161184051 : ℝ) / 1000000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-7983401026582052173 : ℝ) / 500000000000000000) ((-15966802053161184051 : ℝ) / 1000000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((716818933679113 : ℝ) / 500000000000000000) ((716818933679119 : ℝ) / 500000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((230427584462490613 : ℝ) / 500000000000000000) ((230427584462492119 : ℝ) / 500000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((230427584462490613 : ℝ) / 500000000000000000) ((230427584462492119 : ℝ) / 500000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((105534071599665227 : ℝ) / 500000000000000000) ((52767035799833303 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((124821130090083 : ℝ) / 40000000000000000) ((3120528252252121 : ℝ) / 1000000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((996879471747747879 : ℝ) / 1000000000000000000) ((39875178869909917 : ℝ) / 40000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-225763900910291231 : ℝ) / 125000000000000000) ((-225763900910282609 : ℝ) / 125000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((25664062499999999 : ℝ) / 500000000000000000) ((657 : ℝ) / 12800) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((3491355536945453 : ℝ) / 31250000000000000) ((111723377182255231 : ℝ) / 1000000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-211798478762509419 : ℝ) / 125000000000000000) ((-1694387830100005641 : ℝ) / 1000000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-211798478762509419 : ℝ) / 125000000000000000) ((-1694387830100005641 : ℝ) / 1000000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((329322052001953 : ℝ) / 250000000000000000) ((658644104003907 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((105534071599665227 : ℝ) / 500000000000000000) ((52767035799833303 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((48484624753063007 : ℝ) / 500000000000000000) ((24242312376531979 : ℝ) / 250000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((2716919466154199 : ℝ) / 200000000000000000) ((13584597330771283 : ℝ) / 1000000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((362352974149573501 : ℝ) / 200000000000000000) ((1811764870747936613 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((1641245973438018523 : ℝ) / 500000000000000000) ((1641245973438143731 : ℝ) / 500000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((44591331339809499 : ℝ) / 1000000000000000000) ((44591331339813847 : ℝ) / 1000000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((25664062499999999 : ℝ) / 250000000000000000) ((657 : ℝ) / 6400) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((105534071599665227 : ℝ) / 500000000000000000) ((52767035799833303 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((243182719201379459 : ℝ) / 500000000000000000) ((486365438402765293 : ℝ) / 1000000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-220294953911012397 : ℝ) / 250000000000000000) ((-35247192625760177 : ℝ) / 40000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((231442786745953481 : ℝ) / 250000000000000000) ((185154229396772687 : ℝ) / 200000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((4353300541652534571 : ℝ) / 1000000000000000000) ((4353300541652562999 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((1055814337727269699 : ℝ) / 200000000000000000) ((2639535844318213217 : ℝ) / 500000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((105534071599665227 : ℝ) / 500000000000000000) ((52767035799833303 : ℝ) / 250000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((124821130090083 : ℝ) / 40000000000000000) ((3120528252252121 : ℝ) / 1000000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((996879471747747879 : ℝ) / 1000000000000000000) ((39875178869909917 : ℝ) / 40000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-15916977196259089321 : ℝ) / 1000000000000000000) ((-3979244299064044351 : ℝ) / 250000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-5318952753811370413 : ℝ) / 500000000000000000) ((-1063790550761975097 : ℝ) / 100000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-5318952753811370413 : ℝ) / 500000000000000000) ((-1063790550761975097 : ℝ) / 100000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_5_point_plus_lo_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((459421531057623 : ℝ) / 1000000000000000) ((459421531057623 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-171 : ℝ) / 125000000000000000) ((-677 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((2076565890052609023 : ℝ) / 1000000000000000000) ((1038282945026304533 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458762886953619093 : ℝ) / 1000000000000000000) ((229381443476809547 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((540578468942377 : ℝ) / 1000000000000000) ((540578468942377 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-155844357711176751 : ℝ) / 200000000000000000) ((-779221788555883751 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_248.1 dlower_m_log_254.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-24604618960338517 : ℝ) / 40000000000000000) ((-615115474008462923 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_251.1 dlower_m_log_251.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-5128322329606901 : ℝ) / 31250000000000000) ((-82053157273710413 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-67660239412828411 : ℝ) / 500000000000000000) ((-27064095765131363 : ℝ) / 200000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-388893561023253589 : ℝ) / 500000000000000000) ((-97223390255813397 : ℝ) / 125000000000000000) := rb_log hv (by norm_num) dlower_m_log_252.1 dlower_m_log_252.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((321233321610425177 : ℝ) / 500000000000000000) ((642466643220850363 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-171 : ℝ) / 125000000000000000) ((-677 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-171 : ℝ) / 125000000000000000) ((-677 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((218867968475428543 : ℝ) / 1000000000000000000) ((6839624014857143 : ℝ) / 31250000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-2797094450078591 : ℝ) / 25000000000000000) ((-55941889001571817 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-18451656115687033 : ℝ) / 200000000000000000) ((-46129140289217579 : ℝ) / 500000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((63304843948496689 : ℝ) / 500000000000000000) ((63304843948496709 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2076565890052609023 : ℝ) / 1000000000000000000) ((1038282945026304533 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2076565890052609023 : ℝ) / 1000000000000000000) ((1038282945026304533 : ℝ) / 500000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_5_point_plus_hi_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((229710765528813 : ℝ) / 500000000000000) ((229710765528813 : ℝ) / 500000000000000)) :
    RB (E q (v)) ((2071 : ℝ) / 1000000000000000000) ((417 : ℝ) / 200000000000000000) ∧
    RB (Eq q (v)) ((2076565890052593503 : ℝ) / 1000000000000000000) ((259570736256574193 : ℝ) / 125000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458762886953622093 : ℝ) / 1000000000000000000) ((229381443476811047 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270289234471187 : ℝ) / 500000000000000) ((270289234471187 : ℝ) / 500000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-155844357711175443 : ℝ) / 200000000000000000) ((-779221788555877211 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_255.1 dlower_m_log_249.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-24604618960338739 : ℝ) / 40000000000000000) ((-615115474008468473 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_250.1 dlower_m_log_250.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-82053157273704371 : ℝ) / 500000000000000000) ((-5128322329606523 : ℝ) / 31250000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-135320478825646853 : ℝ) / 1000000000000000000) ((-67660239412823423 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-97223390255812581 : ℝ) / 125000000000000000) ((-388893561023250323 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_253.1 dlower_m_log_253.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((642466643220853793 : ℝ) / 1000000000000000000) ((321233321610426901 : ℝ) / 500000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((2071 : ℝ) / 1000000000000000000) ((417 : ℝ) / 200000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((2071 : ℝ) / 1000000000000000000) ((417 : ℝ) / 200000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((218867968475412419 : ℝ) / 1000000000000000000) ((218867968475412451 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-27970944500785727 : ℝ) / 250000000000000000) ((-111883778003142903 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-92258280578434561 : ℝ) / 1000000000000000000) ((-18451656115686911 : ℝ) / 200000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((63304843948488929 : ℝ) / 500000000000000000) ((15826210987122237 : ℝ) / 125000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2076565890052593503 : ℝ) / 1000000000000000000) ((259570736256574193 : ℝ) / 125000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2076565890052593503 : ℝ) / 1000000000000000000) ((259570736256574193 : ℝ) / 125000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_5_point_minus_branch {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((356322849440411 : ℝ) / 250000000000000) ((1425291397761647 : ℝ) / 1000000000000000)) :
    RB (phi q (v)) ((142575350965331631 : ℝ) / 100000000000000000) ((1425753509653319313 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((9266570356903231 : ℝ) / 50000000000000000) ((185331407138071931 : ℝ) / 1000000000000000000) ∧
    RB (psi2 q (v)) ((26014254748654160029 : ℝ) / 1000000000000000000) ((26014254748654614409 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424632753657640093 : ℝ) / 1000000000000000000) ((712316376828821547 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425291397761647 : ℝ) / 1000000000000000) ((-106322849440411 : ℝ) / 250000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((88478515943617399 : ℝ) / 250000000000000000) ((70782812754894341 : ℝ) / 200000000000000000) := rb_log h2 (by norm_num) dlower_m_log_256.1 dlower_m_log_257.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((106322849440411 : ℝ) / 250000000000000) ((425291397761647 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-427490351605282159 : ℝ) / 500000000000000000) ((-427490351605278631 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_258.1 dlower_m_log_259.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604447383492513429 : ℝ) / 500000000000000000) ((1208894766985036023 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996842925693596891 : ℝ) / 1000000000000000000) ((124605365711700557 : ℝ) / 125000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35437628247274779 : ℝ) / 100000000000000000) ((354376282472749897 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_260.1 dlower_m_log_261.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((321233321610423497 : ℝ) / 500000000000000000) ((321233321610428333 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-591 : ℝ) / 125000000000000000) ((4949 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-591 : ℝ) / 125000000000000000) ((4949 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-403074589908810163 : ℝ) / 250000000000000000) ((-322459671927045651 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-7205804424785097 : ℝ) / 200000000000000000) ((-36029022123925407 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-14854591485024623 : ℝ) / 500000000000000000) ((-29709182970049181 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-821003771302644949 : ℝ) / 500000000000000000) ((-410501885651319359 : ℝ) / 250000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((307948659550325747 : ℝ) / 1000000000000000000) ((76987164887584553 : ℝ) / 250000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((307948659550325747 : ℝ) / 1000000000000000000) ((76987164887584553 : ℝ) / 250000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((701935286432641147 : ℝ) / 1000000000000000000) ((350967643216321313 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((106322849440411 : ℝ) / 250000000000000) ((425291397761647 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-2351329007036378801 : ℝ) / 1000000000000000000) ((-2351329007036362213 : ℝ) / 1000000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-824696860301868827 : ℝ) / 500000000000000000) ((-1649393720603719587 : ℝ) / 1000000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-85004631243041519 : ℝ) / 62500000000000000) ((-1360074099888649397 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((350805456894798107 : ℝ) / 500000000000000000) ((175402728447399423 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-515421253419565499 : ℝ) / 250000000000000000) ((-2061685013678245611 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-515421253419565499 : ℝ) / 250000000000000000) ((-2061685013678245611 : ℝ) / 1000000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((106322849440411 : ℝ) / 250000000000000) ((425291397761647 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((180872773010052891 : ℝ) / 1000000000000000000) ((180872773010055443 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((2764374049665302551 : ℝ) / 500000000000000000) ((552874809933068311 : ℝ) / 100000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((2029578482794150241 : ℝ) / 1000000000000000000) ((2029578482794158793 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((49271314633927397 : ℝ) / 100000000000000000) ((492713146339276047 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((1007206990598265811 : ℝ) / 200000000000000000) ((251801747649570457 : ℝ) / 50000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((4152665685662009817 : ℝ) / 1000000000000000000) ((103816642141551897 : ℝ) / 25000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((2031455568533340891 : ℝ) / 1000000000000000000) ((2031455568533349443 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((492257874348672211 : ℝ) / 1000000000000000000) ((123064468587168571 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((1161230890002670507 : ℝ) / 250000000000000000) ((1161230890002687541 : ℝ) / 250000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((1161230890002670507 : ℝ) / 250000000000000000) ((1161230890002687541 : ℝ) / 250000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((701935286432641147 : ℝ) / 1000000000000000000) ((350967643216321313 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((106322849440411 : ℝ) / 250000000000000) ((425291397761647 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-2351329007036378801 : ℝ) / 1000000000000000000) ((-2351329007036362213 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-824696860301868827 : ℝ) / 500000000000000000) ((-1649393720603719587 : ℝ) / 1000000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((1099895070583493081 : ℝ) / 500000000000000000) ((439958028233402099 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((25664062499999999 : ℝ) / 500000000000000000) ((657 : ℝ) / 12800) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((2029578482794150241 : ℝ) / 1000000000000000000) ((2029578482794158793 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((5058008392889109 : ℝ) / 200000000000000000) ((12645020982222827 : ℝ) / 500000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((4170784771552243 : ℝ) / 200000000000000000) ((10426961928880653 : ℝ) / 500000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((2220644065024747377 : ℝ) / 1000000000000000000) ((2220644065024771801 : ℝ) / 1000000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((2220644065024747377 : ℝ) / 1000000000000000000) ((2220644065024771801 : ℝ) / 1000000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((2648446719041277717 : ℝ) / 50000000000000000) ((52968934380826027179 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-1333696202239576781 : ℝ) / 500000000000000000) ((-666848101119788319 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-7205804424785097 : ℝ) / 200000000000000000) ((-36029022123925407 : ℝ) / 1000000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((96103539954170001 : ℝ) / 1000000000000000000) ((4805176997708511 : ℝ) / 50000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((53065037920779724341 : ℝ) / 1000000000000000000) ((53065037920780197399 : ℝ) / 1000000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-350967643216321313 : ℝ) / 250000000000000000) ((-701935286432641147 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((329322052001953 : ℝ) / 125000000000000000) ((658644104003907 : ℝ) / 250000000000000000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((2029578482794150241 : ℝ) / 1000000000000000000) ((2029578482794158793 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((649045217603153 : ℝ) / 500000000000000000) ((649045217603157 : ℝ) / 500000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-702584331650245783 : ℝ) / 500000000000000000) ((-7025843316502443 : ℝ) / 5000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-289672120285299407 : ℝ) / 250000000000000000) ((-579344240570597587 : ℝ) / 500000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((51906349439638526713 : ℝ) / 1000000000000000000) ((2076253977585560089 : ℝ) / 40000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((25002592422237975307 : ℝ) / 500000000000000000) ((12501296211119106533 : ℝ) / 250000000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((25002592422237975307 : ℝ) / 500000000000000000) ((12501296211119106533 : ℝ) / 250000000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-76987164887584553 : ℝ) / 250000000000000000) ((-307948659550325747 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((307948659550325747 : ℝ) / 1000000000000000000) ((76987164887584553 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((2061685013678245611 : ℝ) / 1000000000000000000) ((515421253419565499 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((149367462782742493 : ℝ) / 1000000000000000000) ((149367462782749727 : ℝ) / 1000000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((149367462782742493 : ℝ) / 1000000000000000000) ((149367462782749727 : ℝ) / 1000000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((22310638938153963 : ℝ) / 1000000000000000000) ((178485111505249 : ℝ) / 8000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((12953901555340381 : ℝ) / 125000000000000000) ((103631212442734611 : ℝ) / 1000000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((2220644065024747377 : ℝ) / 500000000000000000) ((2220644065024771801 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((165845984868150977 : ℝ) / 250000000000000000) ((331691969736321667 : ℝ) / 500000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((191753787978831739 : ℝ) / 250000000000000000) ((153403030383075589 : ℝ) / 200000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((5077219999639127757 : ℝ) / 100000000000000000) ((50772199996391804077 : ℝ) / 1000000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-50772199996391804077 : ℝ) / 1000000000000000000) ((-5077219999639127757 : ℝ) / 100000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((5077219999639127757 : ℝ) / 100000000000000000) ((50772199996391804077 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((2061685013678245611 : ℝ) / 1000000000000000000) ((515421253419565499 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((4925311059598610083 : ℝ) / 200000000000000000) ((24626555297993501509 : ℝ) / 1000000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((4925311059598610083 : ℝ) / 200000000000000000) ((24626555297993501509 : ℝ) / 1000000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((46211189167231 : ℝ) / 100000000000000000) ((462111891672313 : ℝ) / 1000000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((142575350965331631 : ℝ) / 100000000000000000) ((1425753509653319313 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((142575350965331631 : ℝ) / 100000000000000000) ((1425753509653319313 : ℝ) / 1000000000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((2031455568533340891 : ℝ) / 1000000000000000000) ((2031455568533349443 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((5065980415457 : ℝ) / 15625000000000000) ((324222746589251 : ℝ) / 1000000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((999675777253410749 : ℝ) / 1000000000000000000) ((15619934019584543 : ℝ) / 15625000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((37329758613427001 : ℝ) / 250000000000000000) ((149319034453715237 : ℝ) / 1000000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((25664062499999999 : ℝ) / 500000000000000000) ((657 : ℝ) / 12800) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((4501546585544577 : ℝ) / 125000000000000000) ((18006186342178347 : ℝ) / 500000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((9266570356903231 : ℝ) / 50000000000000000) ((185331407138071931 : ℝ) / 1000000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((9266570356903231 : ℝ) / 50000000000000000) ((185331407138071931 : ℝ) / 1000000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((329322052001953 : ℝ) / 250000000000000000) ((658644104003907 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((2031455568533340891 : ℝ) / 1000000000000000000) ((2031455568533349443 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((180963509172847539 : ℝ) / 62500000000000000) ((2895416146765578909 : ℝ) / 1000000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((45495643501171 : ℝ) / 100000000000000000) ((90991287002343 : ℝ) / 200000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((22310638938153963 : ℝ) / 1000000000000000000) ((178485111505249 : ℝ) / 8000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((2030073750827 : ℝ) / 200000000000000000) ((5075184377069 : ℝ) / 500000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((25664062499999999 : ℝ) / 250000000000000000) ((657 : ℝ) / 6400) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((2031455568533340891 : ℝ) / 1000000000000000000) ((2031455568533349443 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((50533347413605879 : ℝ) / 1000000000000000000) ((10106669482721219 : ℝ) / 200000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((1887009472272293 : ℝ) / 250000000000000000) ((7548037889089571 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-1884471880083859 : ℝ) / 250000000000000000) ((-3768943760167517 : ℝ) / 500000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((350805456894798107 : ℝ) / 250000000000000000) ((1403221827579195383 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((43615123126839281 : ℝ) / 31250000000000000) ((1395683940058860349 : ℝ) / 1000000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((2031455568533340891 : ℝ) / 1000000000000000000) ((2031455568533349443 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((5065980415457 : ℝ) / 15625000000000000) ((324222746589251 : ℝ) / 1000000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((999675777253410749 : ℝ) / 1000000000000000000) ((15619934019584543 : ℝ) / 15625000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((24618570808595303037 : ℝ) / 1000000000000000000) ((1230928540429787703 : ℝ) / 50000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((26014254748654160029 : ℝ) / 1000000000000000000) ((26014254748654614409 : ℝ) / 1000000000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((26014254748654160029 : ℝ) / 1000000000000000000) ((26014254748654614409 : ℝ) / 1000000000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_5_point_minus_lo_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((356322849440411 : ℝ) / 250000000000000) ((356322849440411 : ℝ) / 250000000000000)) :
    RB (E q (v)) ((1597 : ℝ) / 500000000000000000) ((803 : ℝ) / 250000000000000000) ∧
    RB (Eq q (v)) ((76987164887582139 : ℝ) / 250000000000000000) ((153974329775164371 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424632753657640093 : ℝ) / 1000000000000000000) ((712316376828820047 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-106322849440411 : ℝ) / 250000000000000) ((-106322849440411 : ℝ) / 250000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((88478515943617399 : ℝ) / 250000000000000000) ((353914063774469599 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_256.1 dlower_m_log_262.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((106322849440411 : ℝ) / 250000000000000) ((106322849440411 : ℝ) / 250000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-427490351605282159 : ℝ) / 500000000000000000) ((-213745175802641079 : ℝ) / 250000000000000000) := rb_log h5 (by norm_num) dlower_m_log_258.1 dlower_m_log_258.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((151111845873129239 : ℝ) / 125000000000000000) ((1208894766985033917 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((249210731423400677 : ℝ) / 250000000000000000) ((996842925693602719 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35437628247274779 : ℝ) / 100000000000000000) ((22148517654546737 : ℝ) / 62500000000000000) := rb_log hv (by norm_num) dlower_m_log_260.1 dlower_m_log_260.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((160616660805213729 : ℝ) / 250000000000000000) ((642466643220854929 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((1597 : ℝ) / 500000000000000000) ((803 : ℝ) / 250000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((1597 : ℝ) / 500000000000000000) ((803 : ℝ) / 250000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1612298359635237843 : ℝ) / 1000000000000000000) ((-1612298359635237663 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-7205804424785097 : ℝ) / 200000000000000000) ((-36029022123925483 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-14854591485024623 : ℝ) / 500000000000000000) ((-29709182970049243 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1642007542605287089 : ℝ) / 1000000000000000000) ((-821003771302643453 : ℝ) / 500000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((76987164887582139 : ℝ) / 250000000000000000) ((153974329775164371 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((76987164887582139 : ℝ) / 250000000000000000) ((153974329775164371 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_5_point_minus_hi_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((1425291397761647 : ℝ) / 1000000000000000) ((1425291397761647 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-2991 : ℝ) / 1000000000000000000) ((-2973 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((153974329775167609 : ℝ) / 500000000000000000) ((307948659550335403 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1424632753657643093 : ℝ) / 1000000000000000000) ((712316376828821547 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425291397761647 : ℝ) / 1000000000000000) ((-425291397761647 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((176957031887235851 : ℝ) / 500000000000000000) ((70782812754894341 : ℝ) / 200000000000000000) := rb_log h2 (by norm_num) dlower_m_log_263.1 dlower_m_log_257.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425291397761647 : ℝ) / 1000000000000000) ((425291397761647 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-53436293950659829 : ℝ) / 62500000000000000) ((-427490351605278631 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_259.1 dlower_m_log_259.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((302223691746257241 : ℝ) / 250000000000000000) ((1208894766985028969 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((249210731423399657 : ℝ) / 250000000000000000) ((996842925693598639 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70875256494549979 : ℝ) / 200000000000000000) ((354376282472749897 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_261.1 dlower_m_log_261.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642466643220848731 : ℝ) / 1000000000000000000) ((80308330402606093 : ℝ) / 125000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-2991 : ℝ) / 1000000000000000000) ((-2973 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-2991 : ℝ) / 1000000000000000000) ((-2973 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-403074589908807811 : ℝ) / 250000000000000000) ((-201537294954403883 : ℝ) / 125000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-36029022123925409 : ℝ) / 1000000000000000000) ((-36029022123925407 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29709182970049183 : ℝ) / 1000000000000000000) ((-29709182970049181 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1642007542605280427 : ℝ) / 1000000000000000000) ((-328401508521056049 : ℝ) / 200000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((153974329775167609 : ℝ) / 500000000000000000) ((307948659550335403 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((153974329775167609 : ℝ) / 500000000000000000) ((307948659550335403 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_5_slab_plus_branch {q v : ℝ} (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800))
    (hv : RB v ((229666532988022349 : ℝ) / 500000000000000000) ((229754998069601837 : ℝ) / 500000000000000000)) :
    RB (phi q (v)) ((230381033902602101 : ℝ) / 500000000000000000) ((460948278474401549 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((-424533928676162453 : ℝ) / 250000000000000000) ((-845326500704161793 : ℝ) / 500000000000000000) ∧
    RB (psi2 q (v)) ((-10859073853232446909 : ℝ) / 1000000000000000000) ((-2083573643869490109 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458672415341279073 : ℝ) / 1000000000000000000) ((18354134220568147 : ℝ) / 40000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270245001930398163 : ℝ) / 500000000000000000) ((270333467011977651 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-779419015787944653 : ℝ) / 1000000000000000000) ((-779024606865563189 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_264.1 dlower_m_log_265.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-615279136318489877 : ℝ) / 1000000000000000000) ((-614951838479409107 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_266.1 dlower_m_log_267.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-82233588654267773 : ℝ) / 500000000000000000) ((-5117045954596041 : ℝ) / 31250000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-135633454400412689 : ℝ) / 1000000000000000000) ((-33751897909152357 : ℝ) / 250000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-777979698131867343 : ℝ) / 1000000000000000000) ((-777594583039550201 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_268.1 dlower_m_log_269.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((80245141079892189 : ℝ) / 125000000000000000) ((128594421299051583 : ℝ) / 200000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-290843098185609 : ℝ) / 500000000000000000) ((145407997029063 : ℝ) / 250000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-290843098185609 : ℝ) / 500000000000000000) ((145407997029063 : ℝ) / 250000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((27199130359176203 : ℝ) / 125000000000000000) ((220148740238040461 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-7004760952562237 : ℝ) / 62500000000000000) ((-111691457377636129 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-92427431738584023 : ℝ) / 1000000000000000000) ((-5755577015564959 : ℝ) / 62500000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((125165611134825601 : ℝ) / 1000000000000000000) ((128059507989001117 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((415009510375338949 : ℝ) / 200000000000000000) ((2078089977215082777 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((415009510375338949 : ℝ) / 200000000000000000) ((2078089977215082777 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((87173820392301373 : ℝ) / 40000000000000000) ((218020523265158987 : ℝ) / 100000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((1849567519429055839 : ℝ) / 1000000000000000000) ((231271622244828527 : ℝ) / 125000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((1007228257309147541 : ℝ) / 250000000000000000) ((2015189105305109043 : ℝ) / 500000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((415228161100660269 : ℝ) / 125000000000000000) ((332378854061385749 : ℝ) / 100000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((1088115610543824403 : ℝ) / 500000000000000000) ((544267370494590279 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((286188951706730259 : ℝ) / 250000000000000000) ((286889329881552171 : ℝ) / 250000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((286188951706730259 : ℝ) / 250000000000000000) ((286889329881552171 : ℝ) / 250000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((292129444273443627 : ℝ) / 1000000000000000000) ((73080183386716009 : ℝ) / 250000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((855225002231737711 : ℝ) / 250000000000000000) ((1711570024184149287 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((105190192297501409 : ℝ) / 500000000000000000) ((210546401866644189 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((189981874044730467 : ℝ) / 40000000000000000) ((4753294856481373119 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-53295793902176891 : ℝ) / 40000000000000000) ((-1326406802749963101 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-68675296933296767 : ℝ) / 62500000000000000) ((-54680898155960763 : ℝ) / 50000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((210986865498953431 : ℝ) / 1000000000000000000) ((6598419892245343 : ℝ) / 31250000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((4735982327636638963 : ℝ) / 1000000000000000000) ((4739631529361529623 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((3637177576703890691 : ℝ) / 1000000000000000000) ((3646013566242314363 : ℝ) / 1000000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((3637177576703890691 : ℝ) / 1000000000000000000) ((3646013566242314363 : ℝ) / 1000000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((87173820392301373 : ℝ) / 40000000000000000) ((218020523265158987 : ℝ) / 100000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((1849567519429055839 : ℝ) / 1000000000000000000) ((231271622244828527 : ℝ) / 125000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((1007228257309147541 : ℝ) / 250000000000000000) ((2015189105305109043 : ℝ) / 500000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-1078978432376414207 : ℝ) / 200000000000000000) ((-1070763597399042637 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((25624999999999999 : ℝ) / 500000000000000000) ((329 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((105190192297501409 : ℝ) / 500000000000000000) ((210546401866644189 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((243414276119810901 : ℝ) / 1000000000000000000) ((244349063715995587 : ℝ) / 1000000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((100347127401783541 : ℝ) / 500000000000000000) ((201510770317008521 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-5194197907078503953 : ℝ) / 1000000000000000000) ((-644038402084775583 : ℝ) / 125000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-5194197907078503953 : ℝ) / 1000000000000000000) ((-644038402084775583 : ℝ) / 125000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-723979177769025267 : ℝ) / 100000000000000000) ((-3570753971520021981 : ℝ) / 500000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-334639324150751299 : ℝ) / 125000000000000000) ((-1328849232570718897 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-7004760952562237 : ℝ) / 62500000000000000) ((-111691457377636129 : ℝ) / 1000000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((148421107420976929 : ℝ) / 500000000000000000) ((18752547768023999 : ℝ) / 62500000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-1735737390712074703 : ℝ) / 250000000000000000) ((-3420733589375829989 : ℝ) / 500000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-218020523265158987 : ℝ) / 50000000000000000) ((-4358691019615068651 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((656640624999999 : ℝ) / 250000000000000000) ((108241 : ℝ) / 40960000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((105190192297501409 : ℝ) / 500000000000000000) ((210546401866644189 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((1247498165114029 : ℝ) / 100000000000000000) ((12561069056650399 : ℝ) / 1000000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-4372971534359830139 : ℝ) / 1000000000000000000) ((-4371166001266208941 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-3606319783109178587 : ℝ) / 1000000000000000000) ((-22525073231915999 : ℝ) / 6250000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-10549269345957477399 : ℝ) / 1000000000000000000) ((-5222739447929109909 : ℝ) / 500000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-6225289380706261753 : ℝ) / 500000000000000000) ((-2469299737454771773 : ℝ) / 200000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-6225289380706261753 : ℝ) / 500000000000000000) ((-2469299737454771773 : ℝ) / 200000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-2078089977215082777 : ℝ) / 1000000000000000000) ((-415009510375338949 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-1815312894524827907 : ℝ) / 1000000000000000000) ((-1808229982562804277 : ℝ) / 1000000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-1815312894524827907 : ℝ) / 1000000000000000000) ((-1808229982562804277 : ℝ) / 1000000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((1808229982562804277 : ℝ) / 1000000000000000000) ((1815312894524827907 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((3269695669839079459 : ℝ) / 1000000000000000000) ((329536090502810897 : ℝ) / 100000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((11892463772984507681 : ℝ) / 1000000000000000000) ((2402986113079407239 : ℝ) / 200000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-5194197907078503953 : ℝ) / 500000000000000000) ((-644038402084775583 : ℝ) / 62500000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((9316556388572240657 : ℝ) / 500000000000000000) ((754327554994678569 : ℝ) / 40000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((6105115310025797799 : ℝ) / 200000000000000000) ((1543655972013200021 : ℝ) / 50000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((18074997788716465489 : ℝ) / 1000000000000000000) ((3705324150598028311 : ℝ) / 200000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-3705324150598028311 : ℝ) / 200000000000000000) ((-18074997788716465489 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-16183906334000571091 : ℝ) / 1000000000000000000) ((-15750845279065519099 : ℝ) / 1000000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-16183906334000571091 : ℝ) / 1000000000000000000) ((-15750845279065519099 : ℝ) / 1000000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((89312614322469 : ℝ) / 62500000000000000) ((11506258681583 : ℝ) / 8000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((230381033902602101 : ℝ) / 500000000000000000) ((460948278474401549 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((230381033902602101 : ℝ) / 500000000000000000) ((460948278474401549 : ℝ) / 1000000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((210986865498953431 : ℝ) / 1000000000000000000) ((6598419892245343 : ℝ) / 31250000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((194364899725517 : ℝ) / 62500000000000000) ((626248115685573 : ℝ) / 200000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((199373751884314427 : ℝ) / 200000000000000000) ((62305635100274483 : ℝ) / 62500000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-28276055699771747 : ℝ) / 15625000000000000) ((-1802567979466273713 : ℝ) / 1000000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((25624999999999999 : ℝ) / 500000000000000000) ((329 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((27882962520185499 : ℝ) / 250000000000000000) ((111914978057950127 : ℝ) / 1000000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-424533928676162453 : ℝ) / 250000000000000000) ((-845326500704161793 : ℝ) / 500000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-424533928676162453 : ℝ) / 250000000000000000) ((-845326500704161793 : ℝ) / 500000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((656640624999999 : ℝ) / 500000000000000000) ((108241 : ℝ) / 81920000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((210986865498953431 : ℝ) / 1000000000000000000) ((6598419892245343 : ℝ) / 31250000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((19382648762061929 : ℝ) / 200000000000000000) ((48512638387368037 : ℝ) / 500000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((13535454818119691 : ℝ) / 1000000000000000000) ((272677132161103 : ℝ) / 20000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((1808229982562804277 : ℝ) / 1000000000000000000) ((1815312894524827907 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((3269695669839079459 : ℝ) / 1000000000000000000) ((329536090502810897 : ℝ) / 100000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((22128409004054229 : ℝ) / 500000000000000000) ((11232119512736021 : ℝ) / 250000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((25624999999999999 : ℝ) / 250000000000000000) ((329 : ℝ) / 3200) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((210986865498953431 : ℝ) / 1000000000000000000) ((6598419892245343 : ℝ) / 31250000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((242719094291377737 : ℝ) / 500000000000000000) ((97458673322496453 : ℝ) / 200000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-176917986365610663 : ℝ) / 200000000000000000) ((-35111355491052609 : ℝ) / 40000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((922040705284423683 : ℝ) / 1000000000000000000) ((929518409878997399 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((1088115610543824403 : ℝ) / 250000000000000000) ((544267370494590279 : ℝ) / 125000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((1054900629491944259 : ℝ) / 200000000000000000) ((5283657373835719631 : ℝ) / 1000000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((210986865498953431 : ℝ) / 1000000000000000000) ((6598419892245343 : ℝ) / 31250000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((194364899725517 : ℝ) / 62500000000000000) ((626248115685573 : ℝ) / 200000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((199373751884314427 : ℝ) / 200000000000000000) ((62305635100274483 : ℝ) / 62500000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-4033394250173042051 : ℝ) / 250000000000000000) ((-122668168696743517 : ℝ) / 7812500000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-10859073853232446909 : ℝ) / 1000000000000000000) ((-2083573643869490109 : ℝ) / 200000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-10859073853232446909 : ℝ) / 1000000000000000000) ((-2083573643869490109 : ℝ) / 200000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_5_slab_plus_lo_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((229666532988022349 : ℝ) / 500000000000000000) ((229666532988022349 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-101380569953421 : ℝ) / 1000000000000000000) ((-50690284976703 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((2077023542942455877 : ℝ) / 1000000000000000000) ((25962794286780699 : ℝ) / 12500000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458674421872040791 : ℝ) / 1000000000000000000) ((57334302734005099 : ℝ) / 125000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270333467011977651 : ℝ) / 500000000000000000) ((270333467011977651 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-194853660287161807 : ℝ) / 250000000000000000) ((-779414641148647223 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_270.1 dlower_m_log_271.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-614951838479409109 : ℝ) / 1000000000000000000) ((-614951838479409107 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_267.1 dlower_m_log_267.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-164462802669238121 : ℝ) / 1000000000000000000) ((-82231401334619057 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-1695180443512113 : ℝ) / 12500000000000000) ((-16951804435121129 : ℝ) / 125000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-777979698131867343 : ℝ) / 1000000000000000000) ((-777979698131867341 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_268.1 dlower_m_log_268.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((642365262650898301 : ℝ) / 1000000000000000000) ((642365262650898311 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-101380569953421 : ℝ) / 1000000000000000000) ((-50690284976703 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-101380569953421 : ℝ) / 1000000000000000000) ((-50690284976703 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((10967170766481989 : ℝ) / 50000000000000000) ((109671707664819907 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-55952678580275533 : ℝ) / 500000000000000000) ((-5595267858027553 : ℝ) / 50000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-23069018635699887 : ℝ) / 250000000000000000) ((-46138037271399771 : ℝ) / 500000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((15883417598355029 : ℝ) / 125000000000000000) ((7941708799177517 : ℝ) / 62500000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2077023542942455877 : ℝ) / 1000000000000000000) ((25962794286780699 : ℝ) / 12500000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2077023542942455877 : ℝ) / 1000000000000000000) ((25962794286780699 : ℝ) / 12500000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_5_slab_plus_lo_slope {q v : ℝ} (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800))
    (hv : RB v ((229666532988022349 : ℝ) / 500000000000000000) ((229666532988022349 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((-98285552027039 : ℝ) / 500000000000000000) ((-3102284178389 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((518998743436863751 : ℝ) / 250000000000000000) ((129878403415663761 : ℝ) / 62500000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458672415341279073 : ℝ) / 1000000000000000000) ((458676425351044699 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270333467011977651 : ℝ) / 500000000000000000) ((270333467011977651 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-779419015787944653 : ℝ) / 1000000000000000000) ((-779410273181887341 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_264.1 dlower_m_log_272.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-614951838479409109 : ℝ) / 1000000000000000000) ((-614951838479409107 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_267.1 dlower_m_log_267.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-82233588654267773 : ℝ) / 500000000000000000) ((-20557304337809779 : ℝ) / 125000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-135633454400412689 : ℝ) / 1000000000000000000) ((-67797714096541229 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-777979698131867343 : ℝ) / 1000000000000000000) ((-777979698131867341 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_268.1 dlower_m_log_268.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((160586560932863663 : ℝ) / 250000000000000000) ((128476853987756977 : ℝ) / 200000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-98285552027039 : ℝ) / 500000000000000000) ((-3102284178389 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-98285552027039 : ℝ) / 500000000000000000) ((-3102284178389 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((218540464744169883 : ℝ) / 1000000000000000000) ((220148740238040461 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-7004760952562237 : ℝ) / 62500000000000000) ((-55867270659023057 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-92427431738584023 : ℝ) / 1000000000000000000) ((-18424950962700389 : ℝ) / 200000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((6305651650279293 : ℝ) / 50000000000000000) ((32005996356134629 : ℝ) / 250000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((518998743436863751 : ℝ) / 250000000000000000) ((129878403415663761 : ℝ) / 62500000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((518998743436863751 : ℝ) / 250000000000000000) ((129878403415663761 : ℝ) / 62500000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_5_slab_plus_hi_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((229754998069601837 : ℝ) / 500000000000000000) ((229754998069601837 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((25352267334579 : ℝ) / 250000000000000000) ((10140906933833 : ℝ) / 100000000000000000) ∧
    RB (Eq q (v)) ((415221648835452521 : ℝ) / 200000000000000000) ((2076108244177262647 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458851352035199767 : ℝ) / 1000000000000000000) ((57356419004399971 : ℝ) / 125000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270245001930398163 : ℝ) / 500000000000000000) ((270245001930398163 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-779028973148066549 : ℝ) / 1000000000000000000) ((-155805794629613309 : ℝ) / 200000000000000000) := rb_log h2 (by norm_num) dlower_m_log_273.1 dlower_m_log_274.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-615279136318489877 : ℝ) / 1000000000000000000) ((-4922233090547919 : ℝ) / 8000000000000000) := rb_log h3 (by norm_num) dlower_m_log_266.1 dlower_m_log_266.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-81874918414788337 : ℝ) / 500000000000000000) ((-40937459207394167 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-135026530749360163 : ℝ) / 1000000000000000000) ((-33756632687340039 : ℝ) / 250000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-777594583039550203 : ℝ) / 1000000000000000000) ((-777594583039550201 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_269.1 dlower_m_log_269.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((321284026145095019 : ℝ) / 500000000000000000) ((642568052290190047 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((25352267334579 : ℝ) / 250000000000000000) ((10140906933833 : ℝ) / 100000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((25352267334579 : ℝ) / 250000000000000000) ((10140906933833 : ℝ) / 100000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((109196267748478379 : ℝ) / 500000000000000000) ((218392535496956791 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-55931103583260747 : ℝ) / 500000000000000000) ((-6991387947907593 : ℝ) / 62500000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-46120246737654899 : ℝ) / 500000000000000000) ((-2882515421103431 : ℝ) / 31250000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((1576900525270587 : ℝ) / 12500000000000000) ((126152042021646999 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((415221648835452521 : ℝ) / 200000000000000000) ((2076108244177262647 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((415221648835452521 : ℝ) / 200000000000000000) ((2076108244177262647 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_5_slab_plus_hi_slope {q v : ℝ} (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800))
    (hv : RB v ((229754998069601837 : ℝ) / 500000000000000000) ((229754998069601837 : ℝ) / 500000000000000000)) :
    RB (E q (v)) ((1257347167599 : ℝ) / 200000000000000000) ((24564611974889 : ℝ) / 125000000000000000) ∧
    RB (Eq q (v)) ((2075083191462406467 : ℝ) / 1000000000000000000) ((103856781466512379 : ℝ) / 50000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((458849345504438049 : ℝ) / 1000000000000000000) ((18354134220568147 : ℝ) / 40000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((270245001930398163 : ℝ) / 500000000000000000) ((270245001930398163 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-155806669220105439 : ℝ) / 200000000000000000) ((-779024606865563189 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_275.1 dlower_m_log_265.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-615279136318489877 : ℝ) / 1000000000000000000) ((-4922233090547919 : ℝ) / 8000000000000000) := rb_log h3 (by norm_num) dlower_m_log_266.1 dlower_m_log_266.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-4093855244550933 : ℝ) / 25000000000000000) ((-5117045954596041 : ℝ) / 31250000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-33761370367050869 : ℝ) / 250000000000000000) ((-33751897909152357 : ℝ) / 250000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-777594583039550203 : ℝ) / 1000000000000000000) ((-777594583039550201 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_269.1 dlower_m_log_269.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((25701964062853869 : ℝ) / 40000000000000000) ((25703479656117631 : ℝ) / 40000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((1257347167599 : ℝ) / 200000000000000000) ((24564611974889 : ℝ) / 125000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((1257347167599 : ℝ) / 200000000000000000) ((24564611974889 : ℝ) / 125000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((27199130359176203 : ℝ) / 125000000000000000) ((13699649522075329 : ℝ) / 62500000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-112032959191619447 : ℝ) / 1000000000000000000) ((-111691457377636129 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-92391792152872301 : ℝ) / 1000000000000000000) ((-5755577015564959 : ℝ) / 62500000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((125201250720537323 : ℝ) / 1000000000000000000) ((794407250651037 : ℝ) / 6250000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2075083191462406467 : ℝ) / 1000000000000000000) ((103856781466512379 : ℝ) / 50000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2075083191462406467 : ℝ) / 1000000000000000000) ((103856781466512379 : ℝ) / 50000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_5_slab_minus_branch {q v : ℝ} (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800))
    (hv : RB v ((285056820885700373 : ℝ) / 200000000000000000) ((1425298691094789243 : ℝ) / 1000000000000000000)) :
    RB (phi q (v)) ((1425744808299979937 : ℝ) / 1000000000000000000) ((35644055329055583 : ℝ) / 25000000000000000) ∧
    RB (psi1 q (v)) ((91168966730591693 : ℝ) / 500000000000000000) ((7532681805898051 : ℝ) / 40000000000000000) ∧
    RB (psi2 q (v)) ((12941351154230908231 : ℝ) / 500000000000000000) ((3268321668329839967 : ℝ) / 125000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((17807793172421703 : ℝ) / 12500000000000000) ((356160512617447311 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425298691094789243 : ℝ) / 1000000000000000000) ((-85056820885700373 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((88476883962632403 : ℝ) / 250000000000000000) ((353920589513675741 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_276.1 dlower_m_log_277.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((85056820885700373 : ℝ) / 200000000000000000) ((425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854997852383385623 : ℝ) / 1000000000000000000) ((-854963554331824787 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_278.1 dlower_m_log_279.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208871090182354399 : ℝ) / 1000000000000000000) ((302229610474265341 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((996710162054367807 : ℝ) / 1000000000000000000) ((49848786562214957 : ℝ) / 50000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70874233075505011 : ℝ) / 200000000000000000) ((177190699770894089 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_280.1 dlower_m_log_281.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642328762512579629 : ℝ) / 1000000000000000000) ((128520913173354817 : ℝ) / 200000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-214052322929101 : ℝ) / 1000000000000000000) ((107045679816211 : ℝ) / 500000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-214052322929101 : ℝ) / 1000000000000000000) ((107045679816211 : ℝ) / 500000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-202275825174905959 : ℝ) / 125000000000000000) ((-803203710232874979 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-18042048185822877 : ℝ) / 500000000000000000) ((-359739486722997 : ℝ) / 10000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29757977974062979 : ℝ) / 1000000000000000000) ((-7415100026400383 : ℝ) / 250000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1647964579373310651 : ℝ) / 1000000000000000000) ((-163606782057135149 : ℝ) / 100000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((301917361368558493 : ℝ) / 1000000000000000000) ((31396264865473017 : ℝ) / 100000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((301917361368558493 : ℝ) / 1000000000000000000) ((31396264865473017 : ℝ) / 100000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((701930705800969797 : ℝ) / 1000000000000000000) ((43871241789234959 : ℝ) / 62500000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((85056820885700373 : ℝ) / 200000000000000000) ((425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-117568466536481911 : ℝ) / 50000000000000000) ((-2351288684726102591 : ℝ) / 1000000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-1649438624928668423 : ℝ) / 1000000000000000000) ((-1649348816098343247 : ℝ) / 1000000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-1360265690587317847 : ℝ) / 1000000000000000000) ((-339970642678198801 : ℝ) / 250000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((350803661803648977 : ℝ) / 500000000000000000) ((701614504008638601 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-64433756081123639 : ℝ) / 31250000000000000) ((-1030744947160046579 : ℝ) / 500000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-64433756081123639 : ℝ) / 31250000000000000) ((-1030744947160046579 : ℝ) / 500000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((85056820885700373 : ℝ) / 200000000000000000) ((425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((180866569479552879 : ℝ) / 1000000000000000000) ((180878976646940963 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((2764279239460502733 : ℝ) / 500000000000000000) ((5528937729495946783 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((405910397019838747 : ℝ) / 200000000000000000) ((507401242991691381 : ℝ) / 250000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((246353357873123807 : ℝ) / 500000000000000000) ((492719579169156047 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((5035838899751849419 : ℝ) / 1000000000000000000) ((5036231013749699169 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((4152032294108558557 : ℝ) / 1000000000000000000) ((64895301293149849 : ℝ) / 15625000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((2031434778336556609 : ℝ) / 1000000000000000000) ((2031476358836519449 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((492252836539395713 : ℝ) / 1000000000000000000) ((30766432014705497 : ℝ) / 62500000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((464428513064795427 : ℝ) / 100000000000000000) ((290347637187304893 : ℝ) / 62500000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((464428513064795427 : ℝ) / 100000000000000000) ((290347637187304893 : ℝ) / 62500000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((701930705800969797 : ℝ) / 1000000000000000000) ((43871241789234959 : ℝ) / 62500000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((85056820885700373 : ℝ) / 200000000000000000) ((425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-117568466536481911 : ℝ) / 50000000000000000) ((-2351288684726102591 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-1649438624928668423 : ℝ) / 1000000000000000000) ((-1649348816098343247 : ℝ) / 1000000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((2191735908513707197 : ℝ) / 1000000000000000000) ((2207868106697096659 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((25624999999999999 : ℝ) / 500000000000000000) ((329 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((405910397019838747 : ℝ) / 200000000000000000) ((507401242991691381 : ℝ) / 250000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((25251219181995189 : ℝ) / 1000000000000000000) ((25328865866664429 : ℝ) / 1000000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((10409772790232021 : ℝ) / 500000000000000000) ((835532445989661 : ℝ) / 40000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((2212555454094171239 : ℝ) / 1000000000000000000) ((278594552230854773 : ℝ) / 125000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((2212555454094171239 : ℝ) / 1000000000000000000) ((278594552230854773 : ℝ) / 125000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((2108922454784338509 : ℝ) / 40000000000000000) ((6652024691775860969 : ℝ) / 125000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-334639324150751299 : ℝ) / 125000000000000000) ((-1328849232570718897 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-18042048185822877 : ℝ) / 500000000000000000) ((-359739486722997 : ℝ) / 10000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((2987747130357743 : ℝ) / 31250000000000000) ((96601260979184899 : ℝ) / 1000000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((52818669277779910501 : ℝ) / 1000000000000000000) ((53312798795186072651 : ℝ) / 1000000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-43871241789234959 : ℝ) / 31250000000000000) ((-280772282320387919 : ℝ) / 200000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((656640624999999 : ℝ) / 250000000000000000) ((108241 : ℝ) / 40960000) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((405910397019838747 : ℝ) / 200000000000000000) ((507401242991691381 : ℝ) / 250000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((1294124983077251 : ℝ) / 1000000000000000000) ((1302062010958219 : ℝ) / 1000000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-1405181799266476907 : ℝ) / 1000000000000000000) ((-702577768292508423 : ℝ) / 500000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-579415493760068003 : ℝ) / 500000000000000000) ((-289636507555569537 : ℝ) / 250000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((10331967658051954899 : ℝ) / 200000000000000000) ((52154252764963794503 : ℝ) / 1000000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((12439632218701182097 : ℝ) / 250000000000000000) ((785206765211689929 : ℝ) / 15625000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((12439632218701182097 : ℝ) / 250000000000000000) ((785206765211689929 : ℝ) / 15625000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-31396264865473017 : ℝ) / 100000000000000000) ((-301917361368558493 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((301917361368558493 : ℝ) / 1000000000000000000) ((31396264865473017 : ℝ) / 100000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((1030744947160046579 : ℝ) / 500000000000000000) ((64433756081123639 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((146428178591492729 : ℝ) / 1000000000000000000) ((2379670353343213 : ℝ) / 15625000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((146428178591492729 : ℝ) / 1000000000000000000) ((2379670353343213 : ℝ) / 15625000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((21441211485622089 : ℝ) / 1000000000000000000) ((5798738934354547 : ℝ) / 250000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((99579099685752801 : ℝ) / 1000000000000000000) ((53876804744187937 : ℝ) / 500000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((2212555454094171239 : ℝ) / 500000000000000000) ((278594552230854773 : ℝ) / 62500000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((647960930351365197 : ℝ) / 1000000000000000000) ((135774862652762601 : ℝ) / 200000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((373770015018558999 : ℝ) / 500000000000000000) ((786627922752188879 : ℝ) / 1000000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((25253034452420923193 : ℝ) / 500000000000000000) ((10207972179260068867 : ℝ) / 200000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-10207972179260068867 : ℝ) / 200000000000000000) ((-25253034452420923193 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((25253034452420923193 : ℝ) / 500000000000000000) ((10207972179260068867 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((1030744947160046579 : ℝ) / 500000000000000000) ((64433756081123639 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((24495152064225028667 : ℝ) / 1000000000000000000) ((24758724763544849053 : ℝ) / 1000000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((24495152064225028667 : ℝ) / 1000000000000000000) ((24758724763544849053 : ℝ) / 1000000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((57587983934759 : ℝ) / 125000000000000000) ((463522067434077 : ℝ) / 1000000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((1425744808299979937 : ℝ) / 1000000000000000000) ((35644055329055583 : ℝ) / 25000000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((1425744808299979937 : ℝ) / 1000000000000000000) ((35644055329055583 : ℝ) / 25000000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((2031434778336556609 : ℝ) / 1000000000000000000) ((2031476358836519449 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((323233210243251 : ℝ) / 1000000000000000000) ((325213805439819 : ℝ) / 1000000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((999674786194560181 : ℝ) / 1000000000000000000) ((999676766789756749 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((18297569765788671 : ℝ) / 125000000000000000) ((38062418637689299 : ℝ) / 250000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((25624999999999999 : ℝ) / 500000000000000000) ((329 : ℝ) / 6400) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((17978687667437009 : ℝ) / 500000000000000000) ((36067370596694079 : ℝ) / 1000000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((91168966730591693 : ℝ) / 500000000000000000) ((7532681805898051 : ℝ) / 40000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((91168966730591693 : ℝ) / 500000000000000000) ((7532681805898051 : ℝ) / 40000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((656640624999999 : ℝ) / 500000000000000000) ((108241 : ℝ) / 81920000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((2031434778336556609 : ℝ) / 1000000000000000000) ((2031476358836519449 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((361921462343291411 : ℝ) / 125000000000000000) ((72386514880992489 : ℝ) / 25000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((113391393769881 : ℝ) / 250000000000000000) ((11408736140021 : ℝ) / 25000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((21441211485622089 : ℝ) / 1000000000000000000) ((5798738934354547 : ℝ) / 250000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((9724995417877 : ℝ) / 1000000000000000000) ((10585005191507 : ℝ) / 1000000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((25624999999999999 : ℝ) / 250000000000000000) ((329 : ℝ) / 3200) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((2031434778336556609 : ℝ) / 1000000000000000000) ((2031476358836519449 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((25227957872644029 : ℝ) / 500000000000000000) ((50610780664190543 : ℝ) / 1000000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((7388167841748349 : ℝ) / 1000000000000000000) ((7707966355592331 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-3849120680087227 : ℝ) / 500000000000000000) ((-3688791418278421 : ℝ) / 500000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((1403214647214595909 : ℝ) / 1000000000000000000) ((701614504008638601 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((279103281170884291 : ℝ) / 200000000000000000) ((34896285629518009 : ℝ) / 25000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((2031434778336556609 : ℝ) / 1000000000000000000) ((2031476358836519449 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((323233210243251 : ℝ) / 1000000000000000000) ((325213805439819 : ℝ) / 1000000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((999674786194560181 : ℝ) / 1000000000000000000) ((999676766789756749 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((24487185902607395007 : ℝ) / 1000000000000000000) ((1546920120091124961 : ℝ) / 62500000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((12941351154230908231 : ℝ) / 500000000000000000) ((3268321668329839967 : ℝ) / 125000000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((12941351154230908231 : ℝ) / 500000000000000000) ((3268321668329839967 : ℝ) / 125000000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_5_slab_minus_lo_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((285056820885700373 : ℝ) / 200000000000000000) ((285056820885700373 : ℝ) / 200000000000000000)) :
    RB (E q (v)) ((15036679181523 : ℝ) / 1000000000000000000) ((15036679181541 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((307932463473955903 : ℝ) / 1000000000000000000) ((30793246347395609 : ℝ) / 100000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712312730162248979 : ℝ) / 500000000000000000) ((1424625460324497959 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-85056820885700373 : ℝ) / 200000000000000000) ((-85056820885700373 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((70781788862695401 : ℝ) / 200000000000000000) ((22119309019592313 : ℝ) / 62500000000000000) := rb_log h2 (by norm_num) dlower_m_log_282.1 dlower_m_log_283.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((85056820885700373 : ℝ) / 200000000000000000) ((85056820885700373 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854997852383385623 : ℝ) / 1000000000000000000) ((-854997852383385621 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_278.1 dlower_m_log_278.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604453398348431313 : ℝ) / 500000000000000000) ((1208906796696862631 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((498426422638779151 : ℝ) / 500000000000000000) ((996852845277558313 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70874233075505011 : ℝ) / 200000000000000000) ((354371165377525057 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_280.1 dlower_m_log_280.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((128496335980006649 : ℝ) / 200000000000000000) ((321240839950016629 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((15036679181523 : ℝ) / 1000000000000000000) ((15036679181541 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((15036679181523 : ℝ) / 1000000000000000000) ((15036679181541 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-403078600904054459 : ℝ) / 250000000000000000) ((-322462880723243531 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-36029206573570991 : ℝ) / 1000000000000000000) ((-9007301643392747 : ℝ) / 250000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-14854667532720953 : ℝ) / 500000000000000000) ((-29709335065441903 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-821011869340829871 : ℝ) / 500000000000000000) ((-821011869340829779 : ℝ) / 500000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((307932463473955903 : ℝ) / 1000000000000000000) ((30793246347395609 : ℝ) / 100000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((307932463473955903 : ℝ) / 1000000000000000000) ((30793246347395609 : ℝ) / 100000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_5_slab_minus_lo_slope {q v : ℝ} (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800))
    (hv : RB v ((285056820885700373 : ℝ) / 200000000000000000) ((285056820885700373 : ℝ) / 200000000000000000)) :
    RB (E q (v)) ((-175539530111639 : ℝ) / 1000000000000000000) ((205647517685167 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((150965533348969071 : ℝ) / 500000000000000000) ((313916768024361809 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((17807793172421703 : ℝ) / 12500000000000000) ((712313731901750933 : ℝ) / 500000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-85056820885700373 : ℝ) / 200000000000000000) ((-85056820885700373 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((88476883962632403 : ℝ) / 250000000000000000) ((353910350632296191 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_276.1 dlower_m_log_284.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((85056820885700373 : ℝ) / 200000000000000000) ((85056820885700373 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854997852383385623 : ℝ) / 1000000000000000000) ((-854997852383385621 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_278.1 dlower_m_log_278.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1208905388233915233 : ℝ) / 1000000000000000000) ((604454101507840907 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((249184610170730537 : ℝ) / 250000000000000000) ((199393457480470377 : ℝ) / 200000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((70874233075505011 : ℝ) / 200000000000000000) ((354371165377525057 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_280.1 dlower_m_log_280.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((642367275305397091 : ℝ) / 1000000000000000000) ((64259612202482683 : ℝ) / 100000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-175539530111639 : ℝ) / 1000000000000000000) ((205647517685167 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-175539530111639 : ℝ) / 1000000000000000000) ((205647517685167 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1618192896069868023 : ℝ) / 1000000000000000000) ((-1606452997405245243 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-18042048185822877 : ℝ) / 500000000000000000) ((-1438972680287143 : ℝ) / 40000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29757977974062979 : ℝ) / 1000000000000000000) ((-1853793987279663 : ℝ) / 62500000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-823975437021965501 : ℝ) / 500000000000000000) ((-1636113701201719851 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((150965533348969071 : ℝ) / 500000000000000000) ((313916768024361809 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((150965533348969071 : ℝ) / 500000000000000000) ((313916768024361809 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_5_slab_minus_hi_center {q v : ℝ} (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hv : RB v ((1425298691094789243 : ℝ) / 1000000000000000000) ((1425298691094789243 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-7518216052739 : ℝ) / 500000000000000000) ((-15036432105461 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((1924780345424249 : ℝ) / 6250000000000000) ((12318594210715201 : ℝ) / 40000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((329322052001953 : ℝ) / 500000000000000000) ((658644104003907 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((178080005873848167 : ℝ) / 125000000000000000) ((1424640046990785337 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425298691094789243 : ℝ) / 1000000000000000000) ((-425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353919183209255623 : ℝ) / 1000000000000000000) ((566270693134809 : ℝ) / 1600000000000000) := rb_log h2 (by norm_num) dlower_m_log_285.1 dlower_m_log_286.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425298691094789243 : ℝ) / 1000000000000000000) ((425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854963554331824789 : ℝ) / 1000000000000000000) ((-854963554331824787 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_279.1 dlower_m_log_279.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((120888273754108041 : ℝ) / 100000000000000000) ((604441368770540207 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((498416503165267211 : ℝ) / 500000000000000000) ((31151031447829201 : ℝ) / 31250000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((22148837471361761 : ℝ) / 62500000000000000) ((177190699770894089 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_281.1 dlower_m_log_281.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((160612901697186561 : ℝ) / 250000000000000000) ((40153225424296641 : ℝ) / 62500000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-7518216052739 : ℝ) / 500000000000000000) ((-15036432105461 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-7518216052739 : ℝ) / 500000000000000000) ((-15036432105461 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-806141158005761001 : ℝ) / 500000000000000000) ((-1612282316011521823 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-657 : ℝ) / 12800) ((-25664062499999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-9007209419042113 : ℝ) / 250000000000000000) ((-720576753523369 : ℝ) / 20000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29709030876213803 : ℝ) / 1000000000000000000) ((-148545154381069 : ℝ) / 5000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-328398269377547161 : ℝ) / 200000000000000000) ((-1641991346887735623 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((1924780345424249 : ℝ) / 6250000000000000) ((12318594210715201 : ℝ) / 40000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((1924780345424249 : ℝ) / 6250000000000000) ((12318594210715201 : ℝ) / 40000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_5_slab_minus_hi_slope {q v : ℝ} (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800))
    (hv : RB v ((1425298691094789243 : ℝ) / 1000000000000000000) ((1425298691094789243 : ℝ) / 1000000000000000000)) :
    RB (E q (v)) ((-12850648486717 : ℝ) / 62500000000000000) ((175572140025569 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((2415708607707511 : ℝ) / 8000000000000000) ((313949042686768993 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((656640624999999 : ℝ) / 1000000000000000000) ((108241 : ℝ) / 163840000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((712319020230011809 : ℝ) / 500000000000000000) ((356160512617447311 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-425298691094789243 : ℝ) / 1000000000000000000) ((-425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353917774760729271 : ℝ) / 1000000000000000000) ((353920589513675741 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_287.1 dlower_m_log_277.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((425298691094789243 : ℝ) / 1000000000000000000) ((425298691094789243 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-854963554331824789 : ℝ) / 1000000000000000000) ((-854963554331824787 : ℝ) / 1000000000000000000) := rb_log h5 (by norm_num) dlower_m_log_279.1 dlower_m_log_279.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((604440664546277029 : ℝ) / 500000000000000000) ((120888414384550053 : ℝ) / 100000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((249179651000377359 : ℝ) / 250000000000000000) ((62309215386809713 : ℝ) / 62500000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((22148837471361761 : ℝ) / 62500000000000000) ((177190699770894089 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_281.1 dlower_m_log_281.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((321168602229860629 : ℝ) / 500000000000000000) ((2510023619715497 : ℝ) / 3906250000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-12850648486717 : ℝ) / 62500000000000000) ((175572140025569 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-12850648486717 : ℝ) / 62500000000000000) ((175572140025569 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-404540172873017913 : ℝ) / 250000000000000000) ((-321284205286742227 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-329 : ℝ) / 6400) ((-25624999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-18041863455857403 : ℝ) / 500000000000000000) ((-359739486722997 : ℝ) / 10000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-29757673286358617 : ℝ) / 1000000000000000000) ((-7415100026400383 : ℝ) / 250000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1647918364778430269 : ℝ) / 1000000000000000000) ((-1636081426539312667 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((2415708607707511 : ℝ) / 8000000000000000) ((313949042686768993 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((2415708607707511 : ℝ) / 8000000000000000) ((313949042686768993 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_5_point_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((25664062499999999 : ℝ) / 1000000000000000000) ((657 : ℝ) / 25600))
    (hplus : RB (vPlus q) ((459421531057623 : ℝ) / 1000000000000000) ((229710765528813 : ℝ) / 500000000000000))
    (hminus : RB (vMinus q) ((356322849440411 : ℝ) / 250000000000000) ((1425291397761647 : ℝ) / 1000000000000000)) :
RB (Lam q) ((1834430563323820851 : ℝ) / 1000000000000000000) ((1834430563323832293 : ℝ) / 1000000000000000000) ∧
    RB (lam1 q) ((-1701795847052219 : ℝ) / 500000000000000000) ((-3403591693935677 : ℝ) / 1000000000000000000) ∧
    RB (lam2 q) ((33103754342821926677 : ℝ) / 500000000000000000) ((66207508685651038073 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_point hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_5_point_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_5_point_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((120612292591041509 : ℝ) / 125000000000000000) ((964898340728338087 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((1879719237238070261 : ℝ) / 1000000000000000000) ((1879719237238147283 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((36652160256273910999 : ℝ) / 1000000000000000000) ((7330432051255471047 : ℝ) / 200000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((1834430563323820851 : ℝ) / 1000000000000000000) ((1834430563323832293 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-3577059254377126613 : ℝ) / 1000000000000000000) ((-447132406797138037 : ℝ) / 125000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((142946226507320887 : ℝ) / 40000000000000000) ((3573655662683168619 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((-1701795847052219 : ℝ) / 500000000000000000) ((-3403591693935677 : ℝ) / 1000000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((418506532713046593 : ℝ) / 40000000000000000) ((2615665829456557531 : ℝ) / 250000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-1853593846827967711 : ℝ) / 250000000000000000) ((-926796923413983851 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-6968472023817581349 : ℝ) / 500000000000000000) ((-13936944047634591559 : ℝ) / 1000000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-3474280729808997873 : ℝ) / 1000000000000000000) ((-694856145961672287 : ℝ) / 200000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((69681789415452851227 : ℝ) / 1000000000000000000) ((17420447353864849877 : ℝ) / 250000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((33103754342821926677 : ℝ) / 500000000000000000) ((66207508685651038073 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((1834430563323820851 : ℝ) / 1000000000000000000) ((1834430563323832293 : ℝ) / 1000000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((-1701795847052219 : ℝ) / 500000000000000000) ((-3403591693935677 : ℝ) / 1000000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((33103754342821926677 : ℝ) / 500000000000000000) ((66207508685651038073 : ℝ) / 1000000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

theorem dlower_m_5_slab_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((25624999999999999 : ℝ) / 1000000000000000000) ((329 : ℝ) / 12800))
    (hplus : RB (vPlus q) ((229666532988022349 : ℝ) / 500000000000000000) ((229754998069601837 : ℝ) / 500000000000000000))
    (hminus : RB (vMinus q) ((285056820885700373 : ℝ) / 200000000000000000) ((1425298691094789243 : ℝ) / 1000000000000000000)) :
RB (Lam q) ((1834097297887553403 : ℝ) / 1000000000000000000) ((366952772456557709 : ℝ) / 200000000000000000) ∧
    RB (lam1 q) ((-3450519791470219 : ℝ) / 200000000000000000) ((5228597701778033 : ℝ) / 500000000000000000) ∧
    RB (lam2 q) ((32739800847092321359 : ℝ) / 500000000000000000) ((66939075525821881531 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_5_slab hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_5_slab_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_5_slab_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((241199132456394597 : ℝ) / 250000000000000000) ((482500072678509559 : ℝ) / 500000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((468247733717376743 : ℝ) / 250000000000000000) ((1886452759852101087 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((36300570527809267007 : ℝ) / 1000000000000000000) ((7401129439974233329 : ℝ) / 200000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((1834097297887553403 : ℝ) / 1000000000000000000) ((366952772456557709 : ℝ) / 200000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-1788922717643182009 : ℝ) / 500000000000000000) ((-3576273198714400723 : ℝ) / 1000000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((3560592836329012923 : ℝ) / 1000000000000000000) ((3586730394117956789 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((-3450519791470219 : ℝ) / 200000000000000000) ((5228597701778033 : ℝ) / 500000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((10459965787998551891 : ℝ) / 1000000000000000000) ((10465361419484794213 : ℝ) / 1000000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-3707611291563770599 : ℝ) / 500000000000000000) ((-741352832054845907 : ℝ) / 100000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-6994233553429288083 : ℝ) / 500000000000000000) ((-13885471339785624307 : ℝ) / 1000000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-141140052754400971 : ℝ) / 40000000000000000) ((-1710054960150415047 : ℝ) / 500000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((69008103013044666993 : ℝ) / 1000000000000000000) ((562873483568981693 : ℝ) / 8000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((32739800847092321359 : ℝ) / 500000000000000000) ((66939075525821881531 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((1834097297887553403 : ℝ) / 1000000000000000000) ((366952772456557709 : ℝ) / 200000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((-3450519791470219 : ℝ) / 200000000000000000) ((5228597701778033 : ℝ) / 500000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((32739800847092321359 : ℝ) / 500000000000000000) ((66939075525821881531 : ℝ) / 1000000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

end EP1038.DLowerCert
