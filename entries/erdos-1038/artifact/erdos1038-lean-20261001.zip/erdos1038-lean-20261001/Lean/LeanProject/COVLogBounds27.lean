import LeanProject.COVLogTwo
import LeanProject.COVLogBounds23
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2160 : RB (Real.log ((66293237 : ℝ) / 100000000)) ((-41108231 : ℝ) / 100000000) ((-41108229 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66293237 : ℝ) / 50000000)) (t := ((16293237 : ℝ) / 116293237))
    (lo := ((3525811 : ℝ) / 12500000)) (hi := ((28206489 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66293237 : ℝ) / 100000000) = Real.log ((66293237 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((66293237 : ℝ) / 100000000) = ((66293237 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2161 : RB (Real.log ((8663969 : ℝ) / 12500000)) ((-9163893 : ℝ) / 25000000) ((-36655571 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8663969 : ℝ) / 12500000)) (t := ((-3836031 : ℝ) / 21163969))
    (lo := ((-9163893 : ℝ) / 25000000)) (hi := ((-36655571 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2162 : RB (Real.log ((4067787 : ℝ) / 5000000)) ((-515847 : ℝ) / 2500000) ((-20633879 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4067787 : ℝ) / 5000000)) (t := ((-932213 : ℝ) / 9067787))
    (lo := ((-515847 : ℝ) / 2500000)) (hi := ((-20633879 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2163 : RB (Real.log ((81355743 : ℝ) / 100000000)) ((-5158469 : ℝ) / 25000000) ((-165071 : ℝ) / 800000) := by
  have hm := log_bounds_of_series (x := ((81355743 : ℝ) / 100000000)) (t := ((-18644257 : ℝ) / 181355743))
    (lo := ((-5158469 : ℝ) / 25000000)) (hi := ((-165071 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2164 : RB (Real.log ((22448997 : ℝ) / 50000000)) ((-20019427 : ℝ) / 25000000) ((-40038853 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((22448997 : ℝ) / 25000000)) (t := ((-2551003 : ℝ) / 47448997))
    (lo := ((-10762989 : ℝ) / 100000000)) (hi := ((-2690747 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22448997 : ℝ) / 50000000) = Real.log ((22448997 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22448997 : ℝ) / 50000000) = ((22448997 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2165 : RB (Real.log ((8205389 : ℝ) / 10000000)) ((-4944849 : ℝ) / 25000000) ((-3955879 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((8205389 : ℝ) / 10000000)) (t := ((-1794611 : ℝ) / 18205389))
    (lo := ((-4944849 : ℝ) / 25000000)) (hi := ((-3955879 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2166 : RB (Real.log ((20513473 : ℝ) / 25000000)) ((-9889697 : ℝ) / 50000000) ((-19779393 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20513473 : ℝ) / 25000000)) (t := ((-4486527 : ℝ) / 45513473))
    (lo := ((-9889697 : ℝ) / 50000000)) (hi := ((-19779393 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2167 : RB (Real.log ((22554651 : ℝ) / 50000000)) ((-19902043 : ℝ) / 25000000) ((-7960817 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((22554651 : ℝ) / 25000000)) (t := ((-2445349 : ℝ) / 47554651))
    (lo := ((-10293453 : ℝ) / 100000000)) (hi := ((-2573363 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22554651 : ℝ) / 50000000) = Real.log ((22554651 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22554651 : ℝ) / 50000000) = ((22554651 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2168 : RB (Real.log ((70507447 : ℝ) / 20000000)) ((62999303 : ℝ) / 50000000) ((125998609 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70507447 : ℝ) / 80000000)) (t := ((-9492553 : ℝ) / 150507447))
    (lo := ((-1263083 : ℝ) / 10000000)) (hi := ((-12630829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70507447 : ℝ) / 20000000) = Real.log ((70507447 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((70507447 : ℝ) / 20000000) = ((70507447 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2169 : RB (Real.log ((352537239 : ℝ) / 100000000)) ((125998607 : ℝ) / 100000000) ((12599861 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((352537239 : ℝ) / 400000000)) (t := ((-47462761 : ℝ) / 752537239))
    (lo := ((-12630829 : ℝ) / 100000000)) (hi := ((-3157707 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((352537239 : ℝ) / 100000000) = Real.log ((352537239 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((352537239 : ℝ) / 100000000) = ((352537239 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2170 : RB (Real.log ((6978533 : ℝ) / 5000000)) ((416751 : ℝ) / 1250000) ((16670041 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6978533 : ℝ) / 10000000)) (t := ((-3021467 : ℝ) / 16978533))
    (lo := ((-17987319 : ℝ) / 50000000)) (hi := ((-35974637 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6978533 : ℝ) / 5000000) = Real.log ((6978533 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((6978533 : ℝ) / 5000000) = ((6978533 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2171 : RB (Real.log ((348919223 : ℝ) / 100000000)) ((4998681 : ℝ) / 4000000) ((31241757 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((348919223 : ℝ) / 400000000)) (t := ((-51080777 : ℝ) / 748919223))
    (lo := ((-13662411 : ℝ) / 100000000)) (hi := ((-1366241 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((348919223 : ℝ) / 100000000) = Real.log ((348919223 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((348919223 : ℝ) / 100000000) = ((348919223 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2172 : RB (Real.log ((348919227 : ℝ) / 100000000)) ((62483513 : ℝ) / 50000000) ((124967029 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((348919227 : ℝ) / 400000000)) (t := ((-51080773 : ℝ) / 748919227))
    (lo := ((-1366241 : ℝ) / 10000000)) (hi := ((-13662409 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((348919227 : ℝ) / 100000000) = Real.log ((348919227 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((348919227 : ℝ) / 100000000) = ((348919227 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2173 : RB (Real.log ((28029163 : ℝ) / 20000000)) ((16875661 : ℝ) / 50000000) ((8437831 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((28029163 : ℝ) / 40000000)) (t := ((-11970837 : ℝ) / 68029163))
    (lo := ((-8890849 : ℝ) / 25000000)) (hi := ((-7112679 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28029163 : ℝ) / 20000000) = Real.log ((28029163 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((28029163 : ℝ) / 20000000) = ((28029163 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2174 : RB (Real.log ((17065421 : ℝ) / 25000000)) ((-19091079 : ℝ) / 50000000) ((-38182157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17065421 : ℝ) / 25000000)) (t := ((-7934579 : ℝ) / 42065421))
    (lo := ((-19091079 : ℝ) / 50000000)) (hi := ((-38182157 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2175 : RB (Real.log ((35621599 : ℝ) / 50000000)) ((-8476771 : ℝ) / 25000000) ((-33907083 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35621599 : ℝ) / 50000000)) (t := ((-14378401 : ℝ) / 85621599))
    (lo := ((-8476771 : ℝ) / 25000000)) (hi := ((-33907083 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2176 : RB (Real.log ((40800603 : ℝ) / 50000000)) ((-4066523 : ℝ) / 20000000) ((-10166307 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((40800603 : ℝ) / 50000000)) (t := ((-9199397 : ℝ) / 90800603))
    (lo := ((-4066523 : ℝ) / 20000000)) (hi := ((-10166307 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2177 : RB (Real.log ((81601209 : ℝ) / 100000000)) ((-20332611 : ℝ) / 100000000) ((-2033261 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((81601209 : ℝ) / 100000000)) (t := ((-18398791 : ℝ) / 181601209))
    (lo := ((-20332611 : ℝ) / 100000000)) (hi := ((-2033261 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2178 : RB (Real.log ((22486237 : ℝ) / 50000000)) ((-79911959 : ℝ) / 100000000) ((-79911957 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22486237 : ℝ) / 25000000)) (t := ((-2513763 : ℝ) / 47486237))
    (lo := ((-264931 : ℝ) / 2500000)) (hi := ((-10597239 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22486237 : ℝ) / 50000000) = Real.log ((22486237 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22486237 : ℝ) / 50000000) = ((22486237 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2179 : RB (Real.log ((5141307 : ℝ) / 6250000)) ((-9763707 : ℝ) / 50000000) ((-19527413 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5141307 : ℝ) / 6250000)) (t := ((-1108693 : ℝ) / 11391307))
    (lo := ((-9763707 : ℝ) / 50000000)) (hi := ((-19527413 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2180 : RB (Real.log ((16452183 : ℝ) / 20000000)) ((-1952741 : ℝ) / 10000000) ((-19527409 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16452183 : ℝ) / 20000000)) (t := ((-3547817 : ℝ) / 36452183))
    (lo := ((-1952741 : ℝ) / 10000000)) (hi := ((-19527409 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2181 : RB (Real.log ((903433 : ℝ) / 2000000)) ((-19867513 : ℝ) / 25000000) ((-1589401 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((903433 : ℝ) / 1000000)) (t := ((-96567 : ℝ) / 1903433))
    (lo := ((-10155333 : ℝ) / 100000000)) (hi := ((-2538833 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((903433 : ℝ) / 2000000) = Real.log ((903433 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((903433 : ℝ) / 2000000) = ((903433 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2182 : RB (Real.log ((35128403 : ℝ) / 10000000)) ((125642491 : ℝ) / 100000000) ((62821247 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((35128403 : ℝ) / 40000000)) (t := ((-4871597 : ℝ) / 75128403))
    (lo := ((-2597389 : ℝ) / 20000000)) (hi := ((-202921 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35128403 : ℝ) / 10000000) = Real.log ((35128403 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((35128403 : ℝ) / 10000000) = ((35128403 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2183 : RB (Real.log ((175642017 : ℝ) / 50000000)) ((31410623 : ℝ) / 25000000) ((25128499 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((175642017 : ℝ) / 200000000)) (t := ((-24357983 : ℝ) / 375642017))
    (lo := ((-202921 : ℝ) / 1562500)) (hi := ((-12986943 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((175642017 : ℝ) / 50000000) = Real.log ((175642017 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((175642017 : ℝ) / 50000000) = ((175642017 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2184 : RB (Real.log ((139768007 : ℝ) / 100000000)) ((1046293 : ℝ) / 3125000) ((16740689 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((139768007 : ℝ) / 200000000)) (t := ((-60231993 : ℝ) / 339768007))
    (lo := ((-17916671 : ℝ) / 50000000)) (hi := ((-35833341 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((139768007 : ℝ) / 100000000) = Real.log ((139768007 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((139768007 : ℝ) / 100000000) = ((139768007 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2185 : RB (Real.log ((86951329 : ℝ) / 25000000)) ((124647269 : ℝ) / 100000000) ((15580909 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((86951329 : ℝ) / 100000000)) (t := ((-13048671 : ℝ) / 186951329))
    (lo := ((-13982167 : ℝ) / 100000000)) (hi := ((-6991083 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86951329 : ℝ) / 25000000) = Real.log ((86951329 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((86951329 : ℝ) / 25000000) = ((86951329 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2186 : RB (Real.log ((8695133 : ℝ) / 2500000)) ((124647271 : ℝ) / 100000000) ((62323637 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8695133 : ℝ) / 10000000)) (t := ((-1304867 : ℝ) / 18695133))
    (lo := ((-2796433 : ℝ) / 20000000)) (hi := ((-3495541 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8695133 : ℝ) / 2500000) = Real.log ((8695133 : ℝ) / 10000000) + 2 * Real.log 2 := by
    rw [show ((8695133 : ℝ) / 2500000) = ((8695133 : ℝ) / 10000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2187 : RB (Real.log ((70163137 : ℝ) / 50000000)) ((6776001 : ℝ) / 20000000) ((33880007 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70163137 : ℝ) / 100000000)) (t := ((-29836863 : ℝ) / 170163137))
    (lo := ((-35434713 : ℝ) / 100000000)) (hi := ((-4429339 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70163137 : ℝ) / 50000000) = Real.log ((70163137 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70163137 : ℝ) / 50000000) = ((70163137 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2188 : RB (Real.log ((14041407 : ℝ) / 20000000)) ((-35372167 : ℝ) / 100000000) ((-17686083 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((14041407 : ℝ) / 20000000)) (t := ((-5958593 : ℝ) / 34041407))
    (lo := ((-35372167 : ℝ) / 100000000)) (hi := ((-17686083 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2189 : RB (Real.log ((2926171 : ℝ) / 4000000)) ((-15629981 : ℝ) / 50000000) ((-31259961 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2926171 : ℝ) / 4000000)) (t := ((-1073829 : ℝ) / 6926171))
    (lo := ((-15629981 : ℝ) / 50000000)) (hi := ((-31259961 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2190 : RB (Real.log ((81832811 : ℝ) / 100000000)) ((-2506149 : ℝ) / 12500000) ((-20049191 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((81832811 : ℝ) / 100000000)) (t := ((-18167189 : ℝ) / 181832811))
    (lo := ((-2506149 : ℝ) / 12500000)) (hi := ((-20049191 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2191 : RB (Real.log ((40916407 : ℝ) / 50000000)) ((-5012297 : ℝ) / 25000000) ((-20049187 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40916407 : ℝ) / 50000000)) (t := ((-9083593 : ℝ) / 90916407))
    (lo := ((-5012297 : ℝ) / 25000000)) (hi := ((-20049187 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2192 : RB (Real.log ((11260641 : ℝ) / 25000000)) ((-79756229 : ℝ) / 100000000) ((-79756227 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11260641 : ℝ) / 12500000)) (t := ((-1239359 : ℝ) / 23760641))
    (lo := ((-1044151 : ℝ) / 10000000)) (hi := ((-10441509 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11260641 : ℝ) / 25000000) = Real.log ((11260641 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11260641 : ℝ) / 25000000) = ((11260641 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2193 : RB (Real.log ((16491447 : ℝ) / 20000000)) ((-241113 : ℝ) / 1250000) ((-19289039 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16491447 : ℝ) / 20000000)) (t := ((-3508553 : ℝ) / 36491447))
    (lo := ((-241113 : ℝ) / 1250000)) (hi := ((-19289039 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2194 : RB (Real.log ((41228619 : ℝ) / 50000000)) ((-4822259 : ℝ) / 25000000) ((-3857807 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((41228619 : ℝ) / 50000000)) (t := ((-8771381 : ℝ) / 91228619))
    (lo := ((-4822259 : ℝ) / 25000000)) (hi := ((-3857807 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2195 : RB (Real.log ((9046129 : ℝ) / 20000000)) ((-4958721 : ℝ) / 6250000) ((-39669767 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9046129 : ℝ) / 10000000)) (t := ((-953871 : ℝ) / 19046129))
    (lo := ((-10024817 : ℝ) / 100000000)) (hi := ((-626551 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9046129 : ℝ) / 20000000) = Real.log ((9046129 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((9046129 : ℝ) / 20000000) = ((9046129 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2196 : RB (Real.log ((21879997 : ℝ) / 6250000)) ((125299137 : ℝ) / 100000000) ((6264957 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((21879997 : ℝ) / 25000000)) (t := ((-3120003 : ℝ) / 46879997))
    (lo := ((-13330299 : ℝ) / 100000000)) (hi := ((-6665149 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21879997 : ℝ) / 6250000) = Real.log ((21879997 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((21879997 : ℝ) / 6250000) = ((21879997 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2197 : RB (Real.log ((70015991 : ℝ) / 20000000)) ((62649569 : ℝ) / 50000000) ((125299141 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70015991 : ℝ) / 80000000)) (t := ((-9984009 : ℝ) / 150015991))
    (lo := ((-6665149 : ℝ) / 50000000)) (hi := ((-13330297 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70015991 : ℝ) / 20000000) = Real.log ((70015991 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((70015991 : ℝ) / 20000000) = ((70015991 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2198 : RB (Real.log ((139959481 : ℝ) / 100000000)) ((33618277 : ℝ) / 100000000) ((33618279 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((139959481 : ℝ) / 200000000)) (t := ((-60040519 : ℝ) / 339959481))
    (lo := ((-35696441 : ℝ) / 100000000)) (hi := ((-892411 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((139959481 : ℝ) / 100000000) = Real.log ((139959481 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((139959481 : ℝ) / 100000000) = ((139959481 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2199 : RB (Real.log ((346732637 : ℝ) / 100000000)) ((124338379 : ℝ) / 100000000) ((62169191 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((346732637 : ℝ) / 400000000)) (t := ((-53267363 : ℝ) / 746732637))
    (lo := ((-14291057 : ℝ) / 100000000)) (hi := ((-893191 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((346732637 : ℝ) / 100000000) = Real.log ((346732637 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((346732637 : ℝ) / 100000000) = ((346732637 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2200 : RB (Real.log ((2167079 : ℝ) / 625000)) ((6216919 : ℝ) / 5000000) ((124338383 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2167079 : ℝ) / 2500000)) (t := ((-332921 : ℝ) / 4667079))
    (lo := ((-893191 : ℝ) / 6250000)) (hi := ((-2858211 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2167079 : ℝ) / 625000) = Real.log ((2167079 : ℝ) / 2500000) + 2 * Real.log 2 := by
    rw [show ((2167079 : ℝ) / 625000) = ((2167079 : ℝ) / 2500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2201 : RB (Real.log ((70250797 : ℝ) / 50000000)) ((265663 : ℝ) / 781250) ((17002433 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((70250797 : ℝ) / 100000000)) (t := ((-29749203 : ℝ) / 170250797))
    (lo := ((-17654927 : ℝ) / 50000000)) (hi := ((-35309853 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70250797 : ℝ) / 50000000) = Real.log ((70250797 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70250797 : ℝ) / 50000000) = ((70250797 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2202 : RB (Real.log ((18032603 : ℝ) / 25000000)) ((-32669443 : ℝ) / 100000000) ((-16334721 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18032603 : ℝ) / 25000000)) (t := ((-6967397 : ℝ) / 43032603))
    (lo := ((-32669443 : ℝ) / 100000000)) (hi := ((-16334721 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2203 : RB (Real.log ((37522903 : ℝ) / 50000000)) ((-1794197 : ℝ) / 6250000) ((-28707151 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37522903 : ℝ) / 50000000)) (t := ((-12477097 : ℝ) / 87522903))
    (lo := ((-1794197 : ℝ) / 6250000)) (hi := ((-28707151 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2204 : RB (Real.log ((41074383 : ℝ) / 50000000)) ((-19663837 : ℝ) / 100000000) ((-4915959 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((41074383 : ℝ) / 50000000)) (t := ((-8925617 : ℝ) / 91074383))
    (lo := ((-19663837 : ℝ) / 100000000)) (hi := ((-4915959 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2205 : RB (Real.log ((82148769 : ℝ) / 100000000)) ((-19663833 : ℝ) / 100000000) ((-2457979 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((82148769 : ℝ) / 100000000)) (t := ((-17851231 : ℝ) / 182148769))
    (lo := ((-19663833 : ℝ) / 100000000)) (hi := ((-2457979 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2206 : RB (Real.log ((45137893 : ℝ) / 100000000)) ((-79544811 : ℝ) / 100000000) ((-79544809 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45137893 : ℝ) / 50000000)) (t := ((-4862107 : ℝ) / 95137893))
    (lo := ((-2557523 : ℝ) / 25000000)) (hi := ((-10230091 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45137893 : ℝ) / 100000000) = Real.log ((45137893 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45137893 : ℝ) / 100000000) = ((45137893 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2207 : RB (Real.log ((20612161 : ℝ) / 25000000)) ((-19299459 : ℝ) / 100000000) ((-9649729 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((20612161 : ℝ) / 25000000)) (t := ((-4387839 : ℝ) / 45612161))
    (lo := ((-19299459 : ℝ) / 100000000)) (hi := ((-9649729 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2208 : RB (Real.log ((82448647 : ℝ) / 100000000)) ((-3859891 : ℝ) / 20000000) ((-9649727 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((82448647 : ℝ) / 100000000)) (t := ((-17551353 : ℝ) / 182448647))
    (lo := ((-3859891 : ℝ) / 20000000)) (hi := ((-9649727 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2209 : RB (Real.log ((22614033 : ℝ) / 50000000)) ((-39672619 : ℝ) / 50000000) ((-19836309 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((22614033 : ℝ) / 25000000)) (t := ((-2385967 : ℝ) / 47614033))
    (lo := ((-10030519 : ℝ) / 100000000)) (hi := ((-5015259 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22614033 : ℝ) / 50000000) = Real.log ((22614033 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22614033 : ℝ) / 50000000) = ((22614033 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2210 : RB (Real.log ((174191503 : ℝ) / 50000000)) ((124813227 : ℝ) / 100000000) ((12481323 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((174191503 : ℝ) / 200000000)) (t := ((-25808497 : ℝ) / 374191503))
    (lo := ((-13816209 : ℝ) / 100000000)) (hi := ((-863513 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((174191503 : ℝ) / 50000000) = Real.log ((174191503 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((174191503 : ℝ) / 50000000) = ((174191503 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2211 : RB (Real.log ((34838301 : ℝ) / 10000000)) ((124813229 : ℝ) / 100000000) ((7800827 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((34838301 : ℝ) / 40000000)) (t := ((-5161699 : ℝ) / 74838301))
    (lo := ((-13816207 : ℝ) / 100000000)) (hi := ((-6908103 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34838301 : ℝ) / 10000000) = Real.log ((34838301 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((34838301 : ℝ) / 10000000) = ((34838301 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2212 : RB (Real.log ((140232483 : ℝ) / 100000000)) ((6762629 : ℝ) / 20000000) ((33813147 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((140232483 : ℝ) / 200000000)) (t := ((-59767517 : ℝ) / 340232483))
    (lo := ((-35501573 : ℝ) / 100000000)) (hi := ((-8875393 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((140232483 : ℝ) / 100000000) = Real.log ((140232483 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((140232483 : ℝ) / 100000000) = ((140232483 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2213 : RB (Real.log ((346756361 : ℝ) / 100000000)) ((124345221 : ℝ) / 100000000) ((15543153 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((346756361 : ℝ) / 400000000)) (t := ((-53243639 : ℝ) / 746756361))
    (lo := ((-2856843 : ℝ) / 20000000)) (hi := ((-7142107 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((346756361 : ℝ) / 100000000) = Real.log ((346756361 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((346756361 : ℝ) / 100000000) = ((346756361 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2214 : RB (Real.log ((86689091 : ℝ) / 25000000)) ((62172611 : ℝ) / 50000000) ((4973809 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((86689091 : ℝ) / 100000000)) (t := ((-13310909 : ℝ) / 186689091))
    (lo := ((-7142107 : ℝ) / 50000000)) (hi := ((-14284213 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86689091 : ℝ) / 25000000) = Real.log ((86689091 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((86689091 : ℝ) / 25000000) = ((86689091 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2215 : RB (Real.log ((1404977 : ℝ) / 1000000)) ((34002093 : ℝ) / 100000000) ((6800419 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1404977 : ℝ) / 2000000)) (t := ((-595023 : ℝ) / 3404977))
    (lo := ((-282501 : ℝ) / 800000)) (hi := ((-2207039 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1404977 : ℝ) / 1000000) = Real.log ((1404977 : ℝ) / 2000000) + 1 * Real.log 2 := by
    rw [show ((1404977 : ℝ) / 1000000) = ((1404977 : ℝ) / 2000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2216 : RB (Real.log ((37139473 : ℝ) / 50000000)) ((-3716783 : ℝ) / 12500000) ((-29734263 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37139473 : ℝ) / 50000000)) (t := ((-12860527 : ℝ) / 87139473))
    (lo := ((-3716783 : ℝ) / 12500000)) (hi := ((-29734263 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2217 : RB (Real.log ((37862687 : ℝ) / 50000000)) ((-2780569 : ℝ) / 10000000) ((-27805689 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37862687 : ℝ) / 50000000)) (t := ((-12137313 : ℝ) / 87862687))
    (lo := ((-2780569 : ℝ) / 10000000)) (hi := ((-27805689 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2218 : RB (Real.log ((16450263 : ℝ) / 20000000)) ((-19539081 : ℝ) / 100000000) ((-488477 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((16450263 : ℝ) / 20000000)) (t := ((-3549737 : ℝ) / 36450263))
    (lo := ((-19539081 : ℝ) / 100000000)) (hi := ((-488477 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2219 : RB (Real.log ((41125659 : ℝ) / 50000000)) ((-9769539 : ℝ) / 50000000) ((-19539077 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41125659 : ℝ) / 50000000)) (t := ((-8874341 : ℝ) / 91125659))
    (lo := ((-9769539 : ℝ) / 50000000)) (hi := ((-19539077 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2220 : RB (Real.log ((45168763 : ℝ) / 100000000)) ((-19869111 : ℝ) / 25000000) ((-39738221 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((45168763 : ℝ) / 50000000)) (t := ((-4831237 : ℝ) / 95168763))
    (lo := ((-406469 : ℝ) / 4000000)) (hi := ((-2540431 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45168763 : ℝ) / 100000000) = Real.log ((45168763 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45168763 : ℝ) / 100000000) = ((45168763 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2221 : RB (Real.log ((16508681 : ℝ) / 20000000)) ((-19184591 : ℝ) / 100000000) ((-1918459 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((16508681 : ℝ) / 20000000)) (t := ((-3491319 : ℝ) / 36508681))
    (lo := ((-19184591 : ℝ) / 100000000)) (hi := ((-1918459 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2222 : RB (Real.log ((5158963 : ℝ) / 6250000)) ((-4796147 : ℝ) / 25000000) ((-19184587 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5158963 : ℝ) / 6250000)) (t := ((-1091037 : ℝ) / 11408963))
    (lo := ((-4796147 : ℝ) / 25000000)) (hi := ((-19184587 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2223 : RB (Real.log ((45256499 : ℝ) / 100000000)) ((-9910299 : ℝ) / 12500000) ((-7928239 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((45256499 : ℝ) / 50000000)) (t := ((-4743501 : ℝ) / 95256499))
    (lo := ((-9967673 : ℝ) / 100000000)) (hi := ((-1245959 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45256499 : ℝ) / 100000000) = Real.log ((45256499 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45256499 : ℝ) / 100000000) = ((45256499 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2224 : RB (Real.log ((347830667 : ℝ) / 100000000)) ((62327279 : ℝ) / 50000000) ((124654561 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((347830667 : ℝ) / 400000000)) (t := ((-52169333 : ℝ) / 747830667))
    (lo := ((-6987439 : ℝ) / 50000000)) (hi := ((-13974877 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((347830667 : ℝ) / 100000000) = Real.log ((347830667 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((347830667 : ℝ) / 100000000) = ((347830667 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2225 : RB (Real.log ((34783067 : ℝ) / 10000000)) ((124654559 : ℝ) / 100000000) ((62327281 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((34783067 : ℝ) / 40000000)) (t := ((-5216933 : ℝ) / 74783067))
    (lo := ((-13974877 : ℝ) / 100000000)) (hi := ((-3493719 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34783067 : ℝ) / 10000000) = Real.log ((34783067 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((34783067 : ℝ) / 10000000) = ((34783067 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2226 : RB (Real.log ((140322149 : ℝ) / 100000000)) ((6775413 : ℝ) / 20000000) ((33877067 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((140322149 : ℝ) / 200000000)) (t := ((-59677851 : ℝ) / 340322149))
    (lo := ((-35437653 : ℝ) / 100000000)) (hi := ((-8859413 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((140322149 : ℝ) / 100000000) = Real.log ((140322149 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((140322149 : ℝ) / 100000000) = ((140322149 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2227 : RB (Real.log ((346234169 : ℝ) / 100000000)) ((62097257 : ℝ) / 50000000) ((124194517 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((346234169 : ℝ) / 400000000)) (t := ((-53765831 : ℝ) / 746234169))
    (lo := ((-7217461 : ℝ) / 50000000)) (hi := ((-14434921 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((346234169 : ℝ) / 100000000) = Real.log ((346234169 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((346234169 : ℝ) / 100000000) = ((346234169 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2228 : RB (Real.log ((86558543 : ℝ) / 25000000)) ((24838903 : ℝ) / 20000000) ((62097259 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((86558543 : ℝ) / 100000000)) (t := ((-13441457 : ℝ) / 186558543))
    (lo := ((-14434921 : ℝ) / 100000000)) (hi := ((-360873 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86558543 : ℝ) / 25000000) = Real.log ((86558543 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((86558543 : ℝ) / 25000000) = ((86558543 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2229 : RB (Real.log ((4393237 : ℝ) / 3125000)) ((17031601 : ℝ) / 50000000) ((8515801 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4393237 : ℝ) / 6250000)) (t := ((-1856763 : ℝ) / 10643237))
    (lo := ((-8812879 : ℝ) / 25000000)) (hi := ((-7050303 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4393237 : ℝ) / 3125000) = Real.log ((4393237 : ℝ) / 6250000) + 1 * Real.log 2 := by
    rw [show ((4393237 : ℝ) / 3125000) = ((4393237 : ℝ) / 6250000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2230 : RB (Real.log ((75221541 : ℝ) / 100000000)) ((-5694651 : ℝ) / 20000000) ((-14236627 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((75221541 : ℝ) / 100000000)) (t := ((-24778459 : ℝ) / 175221541))
    (lo := ((-5694651 : ℝ) / 20000000)) (hi := ((-14236627 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2231 : RB (Real.log ((76660797 : ℝ) / 100000000)) ((-26577973 : ℝ) / 100000000) ((-6644493 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((76660797 : ℝ) / 100000000)) (t := ((-23339203 : ℝ) / 176660797))
    (lo := ((-26577973 : ℝ) / 100000000)) (hi := ((-6644493 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2232 : RB (Real.log ((41175583 : ℝ) / 50000000)) ((-9708879 : ℝ) / 50000000) ((-19417757 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41175583 : ℝ) / 50000000)) (t := ((-8824417 : ℝ) / 91175583))
    (lo := ((-9708879 : ℝ) / 50000000)) (hi := ((-19417757 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2233 : RB (Real.log ((82351169 : ℝ) / 100000000)) ((-9708877 : ℝ) / 50000000) ((-19417753 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((82351169 : ℝ) / 100000000)) (t := ((-17648831 : ℝ) / 182351169))
    (lo := ((-9708877 : ℝ) / 50000000)) (hi := ((-19417753 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2234 : RB (Real.log ((45198787 : ℝ) / 100000000)) ((-15881999 : ℝ) / 20000000) ((-79409993 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45198787 : ℝ) / 50000000)) (t := ((-4801213 : ℝ) / 95198787))
    (lo := ((-2523819 : ℝ) / 25000000)) (hi := ((-403811 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45198787 : ℝ) / 100000000) = Real.log ((45198787 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45198787 : ℝ) / 100000000) = ((45198787 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2235 : RB (Real.log ((3305431 : ℝ) / 4000000)) ((-19072749 : ℝ) / 100000000) ((-4768187 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((3305431 : ℝ) / 4000000)) (t := ((-694569 : ℝ) / 7305431))
    (lo := ((-19072749 : ℝ) / 100000000)) (hi := ((-4768187 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2236 : RB (Real.log ((82635777 : ℝ) / 100000000)) ((-19072747 : ℝ) / 100000000) ((-9536373 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((82635777 : ℝ) / 100000000)) (t := ((-17364223 : ℝ) / 182635777))
    (lo := ((-19072747 : ℝ) / 100000000)) (hi := ((-9536373 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2237 : RB (Real.log ((22642093 : ℝ) / 50000000)) ((-4951327 : ℝ) / 6250000) ((-7922123 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((22642093 : ℝ) / 25000000)) (t := ((-2357907 : ℝ) / 47642093))
    (lo := ((-9906513 : ℝ) / 100000000)) (hi := ((-619157 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22642093 : ℝ) / 50000000) = Real.log ((22642093 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22642093 : ℝ) / 50000000) = ((22642093 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2238 : RB (Real.log ((173644327 : ℝ) / 50000000)) ((12449861 : ℝ) / 10000000) ((124498613 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((173644327 : ℝ) / 200000000)) (t := ((-26355673 : ℝ) / 373644327))
    (lo := ((-7065413 : ℝ) / 50000000)) (hi := ((-565233 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((173644327 : ℝ) / 50000000) = Real.log ((173644327 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((173644327 : ℝ) / 50000000) = ((173644327 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2239 : RB (Real.log ((173644329 : ℝ) / 50000000)) ((124498611 : ℝ) / 100000000) ((62249307 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((173644329 : ℝ) / 200000000)) (t := ((-26355671 : ℝ) / 373644329))
    (lo := ((-565233 : ℝ) / 4000000)) (hi := ((-1766353 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((173644329 : ℝ) / 50000000) = Real.log ((173644329 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((173644329 : ℝ) / 50000000) = ((173644329 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
