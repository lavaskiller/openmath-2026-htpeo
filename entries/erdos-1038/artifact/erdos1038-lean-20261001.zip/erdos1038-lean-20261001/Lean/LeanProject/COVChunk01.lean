import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_5 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((18597 : ℝ) / 31397) ((1863 : ℝ) / 3143))
    (hq : RB (qa a) ((362851 : ℝ) / 50000000) ((366999 : ℝ) / 50000000))
    (hd : RB (D0a a) ((197096019 : ℝ) / 100000000) ((197128489 : ℝ) / 100000000))
    : certE k a ((44309367 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((22265493 : ℝ) / 50000000) ∧ 0 < certE k a ((126942817 : ℝ) / 100000000) ∧ certE k a ((63520711 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((2633 : ℝ) / 50000000) ((1347 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((44309367 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((44303979 : ℝ) / 100000000) ((44304101 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((44309367 : ℝ) / 100000000) ((44309367 : ℝ) / 100000000) ((44309367 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((55690633 : ℝ) / 100000000))
  have h3 : RB z3 ((15910747 : ℝ) / 20000000) ((15910791 : ℝ) / 20000000) := rb_div_signed h2 (show RB ((55690633 : ℝ) / 100000000) ((55690633 : ℝ) / 100000000) ((55690633 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22873749 : ℝ) / 100000000) ((-22873471 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_90.1 cov_log_91.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-13558319 : ℝ) / 100000000) ((-6774181 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((44309367 : ℝ) / 100000000))
  have h6 : RB z6 ((-8139741 : ℝ) / 10000000) ((-2543669 : ℝ) / 3125000) := rb_log (show RB ((44309367 : ℝ) / 100000000) ((44309367 : ℝ) / 100000000) ((44309367 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_92.1 cov_log_92.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((67839089 : ℝ) / 100000000) ((8481131 : ℝ) / 12500000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33926041 : ℝ) / 50000000) ((67868557 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_93.1 cov_log_94.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-7367 : ℝ) / 25000000) ((-1517 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((2633 : ℝ) / 50000000) ((1347 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22265493 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((22262799 : ℝ) / 50000000) ((1113143 : ℝ) / 2500000) := rb_widen (rb_sub (show RB ((22265493 : ℝ) / 50000000) ((22265493 : ℝ) / 50000000) ((22265493 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27734507 : ℝ) / 50000000))
  have h12 : RB z12 ((40135559 : ℝ) / 50000000) ((80271339 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((27734507 : ℝ) / 50000000) ((27734507 : ℝ) / 50000000) ((27734507 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-21976031 : ℝ) / 100000000) ((-4395151 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_95.1 cov_log_96.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-65131 : ℝ) / 500000) ((-13016629 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22265493 : ℝ) / 50000000))
  have h15 : RB z15 ((-40449247 : ℝ) / 50000000) ((-20224623 : ℝ) / 25000000) := rb_log (show RB ((22265493 : ℝ) / 50000000) ((22265493 : ℝ) / 50000000) ((22265493 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_97.1 cov_log_97.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16968073 : ℝ) / 25000000) ((13576373 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33926041 : ℝ) / 50000000) ((67868557 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_93.1 cov_log_94.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((747 : ℝ) / 20000000) ((29783 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((2633 : ℝ) / 50000000) ((1347 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((126942817 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((126937429 : ℝ) / 100000000) ((126937551 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((126942817 : ℝ) / 100000000) ((126942817 : ℝ) / 100000000) ((126942817 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((26942817 : ℝ) / 100000000))
  have h21 : RB z21 ((11778411 : ℝ) / 2500000) ((235568447 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((26942817 : ℝ) / 100000000) ((26942817 : ℝ) / 100000000) ((26942817 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((77498877 : ℝ) / 50000000) ((77498927 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_98.1 cov_log_99.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((45903959 : ℝ) / 50000000) ((3674973 : ℝ) / 4000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((126942817 : ℝ) / 100000000))
  have h24 : RB z24 ((23856653 : ℝ) / 100000000) ((11928327 : ℝ) / 50000000) := rb_log (show RB ((126942817 : ℝ) / 100000000) ((126942817 : ℝ) / 100000000) ((126942817 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_100.1 cov_log_100.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((2123477 : ℝ) / 3125000) ((8502209 : ℝ) / 12500000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33926041 : ℝ) / 50000000) ((67868557 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_93.1 cov_log_94.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((82707 : ℝ) / 100000000) ((16559 : ℝ) / 10000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((2633 : ℝ) / 50000000) ((1347 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((63520711 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((63518017 : ℝ) / 50000000) ((31759039 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((63520711 : ℝ) / 50000000) ((63520711 : ℝ) / 50000000) ((63520711 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((13520711 : ℝ) / 50000000))
  have h30 : RB z30 ((58722889 : ℝ) / 12500000) ((117445891 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((13520711 : ℝ) / 50000000) ((13520711 : ℝ) / 50000000) ((13520711 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((154710093 : ℝ) / 100000000) ((9669387 : ℝ) / 6250000) := rb_log h30 (by norm_num) cov_log_101.1 cov_log_102.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((22909383 : ℝ) / 25000000) ((18340763 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((63520711 : ℝ) / 50000000))
  have h33 : RB z33 ((239343 : ℝ) / 1000000) ((23934301 : ℝ) / 100000000) := rb_log (show RB ((63520711 : ℝ) / 50000000) ((63520711 : ℝ) / 50000000) ((63520711 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_103.1 cov_log_103.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67703231 : ℝ) / 100000000) ((13553903 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33926041 : ℝ) / 50000000) ((67868557 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_93.1 cov_log_94.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-82663 : ℝ) / 50000000) ((-82567 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((44309367 : ℝ) / 100000000)) ((-7367 : ℝ) / 25000000) ((-1517 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22265493 : ℝ) / 50000000)) ((747 : ℝ) / 20000000) ((29783 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((126942817 : ℝ) / 100000000)) ((82707 : ℝ) / 100000000) ((16559 : ℝ) / 10000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((63520711 : ℝ) / 50000000)) ((-82663 : ℝ) / 50000000) ((-82567 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_5 {k A q d vp vm : ℝ}
    (hk : RB k ((18597 : ℝ) / 12800) ((1863 : ℝ) / 1280))
    (hA : RB A ((18597 : ℝ) / 31397) ((1863 : ℝ) / 3143))
    (hq : RB q ((362851 : ℝ) / 50000000) ((366999 : ℝ) / 50000000))
    (hd : RB d ((197096019 : ℝ) / 100000000) ((197128489 : ℝ) / 100000000))
    (hp : RB vp ((44309367 : ℝ) / 100000000) ((22265493 : ℝ) / 50000000))
    (hm : RB vm ((126942817 : ℝ) / 100000000) ((63520711 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((2633 : ℝ) / 50000000) ((1347 : ℝ) / 25000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((24998653 : ℝ) / 25000000) ((49997367 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((29614291 : ℝ) / 50000000) ((29635729 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((473 : ℝ) / 4000000) ((19 : ℝ) / 156250) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((156231 : ℝ) / 156250) ((3999527 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27734507 : ℝ) / 50000000) ((55690633 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((13865567 : ℝ) / 25000000) ((3480253 : ℝ) / 6250000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53182719 : ℝ) / 50000000) ((4274723 : ℝ) / 4000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3182719 : ℝ) / 50000000) ((274723 : ℝ) / 4000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((24998653 : ℝ) / 25000000) ((49997367 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((29614291 : ℝ) / 50000000) ((29635729 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((829 : ℝ) / 20000000) ((849 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19999151 : ℝ) / 20000000) ((19999171 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((26942817 : ℝ) / 100000000) ((13520711 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((26941673 : ℝ) / 100000000) ((13520151 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((219038167 : ℝ) / 100000000) ((109999587 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((319038167 : ℝ) / 100000000) ((159999587 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((291202411 : ℝ) / 20000000) ((392745951 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((195313 : ℝ) / 625000) ((31344213 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((18597 : ℝ) / 6400) ((1863 : ℝ) / 640) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2108731 : ℝ) / 100000000) ((2136623 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50362851 : ℝ) / 50000000) ((50366999 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((418673 : ℝ) / 20000000) ((212123 : ℝ) / 10000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((20418673 : ℝ) / 20000000) ((10212123 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((82411831 : ℝ) / 100000000) ((16546411 : ℝ) / 20000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((81215219 : ℝ) / 50000000) ((3261769 : ℝ) / 2000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((28123779 : ℝ) / 50000000) ((28286399 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((2327 : ℝ) / 25000000) ((479 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4999521 : ℝ) / 5000000) ((24997673 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((162414877 : ℝ) / 100000000) ((16307327 : ℝ) / 10000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((197096019 : ℝ) / 50000000) ((197128489 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2860659 : ℝ) / 100000000) ((2893839 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((122644531 : ℝ) / 50000000) ((3143 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((233003 : ℝ) / 20000000) ((1179767 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((203707 : ℝ) / 12500000) ((1656531 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((12703707 : ℝ) / 12500000) ((101656531 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((739870021 : ℝ) / 50000000) ((798503819 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((17851 : ℝ) / 3125000) ((144553 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((3142851 : ℝ) / 3125000) ((25144553 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3142859 : ℝ) / 10000000) ((630509 : ℝ) / 2000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((188896079 : ℝ) / 12500000) ((50891659 : ℝ) / 3125000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17605341 : ℝ) / 100000000) ((600403 : ℝ) / 3125000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((122644531 : ℝ) / 50000000) ((3143 : ℝ) / 1280) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((20418673 : ℝ) / 10000000) ((10212123 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((297452427 : ℝ) / 20000000) ((1602328017 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((3036791919 : ℝ) / 100000000) ((40907927 : ℝ) / 1250000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1873789 : ℝ) / 25000000) ((8085733 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-2024151 : ℝ) / 781250) ((-251506903 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_104.1 cov_log_105.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1430329 : ℝ) / 100000000) ((36173 : ℝ) / 2500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-26545411 : ℝ) / 6250000) ((-211786651 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_106.1 cov_log_107.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33926041 : ℝ) / 50000000) ((67868557 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_93.1 cov_log_94.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((98581653 : ℝ) / 100000000) ((24695141 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-326144923 : ℝ) / 100000000) ((-162396369 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((20369777 : ℝ) / 100000000) ((21028171 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((106021377 : ℝ) / 100000000) ((59720999 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-110061773 : ℝ) / 50000000) ((-10267537 : ℝ) / 5000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((20418673 : ℝ) / 20000000) ((10212123 : ℝ) / 10000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-2024151 : ℝ) / 781250) ((-251506903 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-110061773 : ℝ) / 50000000) ((-10267537 : ℝ) / 5000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((203707 : ℝ) / 12500000) ((1656531 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((101656531 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-2309341 : ℝ) / 1000000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((631709341 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((10267537 : ℝ) / 5000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((10267537 : ℝ) / 5000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2729 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2729 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2769 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2769 : ℝ) / 1000)) (lo := ((2729 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2809 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2809 : ℝ) / 1000)) (lo := ((2769 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2849 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2849 : ℝ) / 1000)) (lo := ((2809 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2889 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2889 : ℝ) / 1000)) (lo := ((2849 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2929 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2929 : ℝ) / 1000)) (lo := ((2889 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2969 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2969 : ℝ) / 1000)) (lo := ((2929 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3009 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3009 : ℝ) / 1000)) (lo := ((2969 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3049 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3049 : ℝ) / 1000)) (lo := ((3009 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((3049 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_5 {k : ℝ} (hk : RB k ((18597 : ℝ) / 12800) ((1863 : ℝ) / 1280)) :
    RB (k / (k + 1)) ((18597 : ℝ) / 31397) ((1863 : ℝ) / 3143) ∧
    RB (qa (r1A k)) ((362851 : ℝ) / 50000000) ((366999 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((197096019 : ℝ) / 100000000) ((197128489 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((7264453 : ℝ) / 20000000) ((36386719 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((194213281 : ℝ) / 100000000) ((38855547 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((5574417 : ℝ) / 4000000) ((139383549 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((280781781 : ℝ) / 100000000) ((140402453 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((14039089 : ℝ) / 10000000) ((140402453 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((197096019 : ℝ) / 100000000) ((197128489 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1144453 : ℝ) / 20000000) ((5786719 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((715283 : ℝ) / 50000000) ((36167 : ℝ) / 2500000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((362851 : ℝ) / 50000000) ((366999 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((197096019 : ℝ) / 100000000) ((197128489 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((362851 : ℝ) / 50000000) ((366999 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((18597 : ℝ) / 31397) ((1863 : ℝ) / 3143) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_5 {k : ℝ} (hk : RB k ((18597 : ℝ) / 12800) ((1863 : ℝ) / 1280)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_5 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_5 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((44309367 : ℝ) / 100000000)) (ph := ((22265493 : ℝ) / 50000000)) (ml := ((126942817 : ℝ) / 100000000)) (mh := ((63520711 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_5 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_6 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1863 : ℝ) / 3143) ((18663 : ℝ) / 31463))
    (hq : RB (qa a) ((733997 : ℝ) / 100000000) ((92787 : ℝ) / 12500000))
    (hd : RB (D0a a) ((98531777 : ℝ) / 50000000) ((98548013 : ℝ) / 50000000))
    : certE k a ((8853077 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((44485239 : ℝ) / 100000000) ∧ 0 < certE k a ((25395147 : ℝ) / 20000000) ∧ certE k a ((127074189 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((5387 : ℝ) / 100000000) ((5511 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8853077 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((22129937 : ℝ) / 50000000) ((22129999 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((8853077 : ℝ) / 20000000) ((8853077 : ℝ) / 20000000) ((8853077 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11146923 : ℝ) / 20000000))
  have h3 : RB z3 ((79411823 : ℝ) / 100000000) ((39706023 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((11146923 : ℝ) / 20000000) ((11146923 : ℝ) / 20000000) ((11146923 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-23052293 : ℝ) / 100000000) ((-23052011 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_108.1 cov_log_109.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-13673997 : ℝ) / 100000000) ((-6831991 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8853077 : ℝ) / 20000000))
  have h6 : RB z6 ((-81496721 : ℝ) / 100000000) ((-81496719 : ℝ) / 100000000) := rb_log (show RB ((8853077 : ℝ) / 20000000) ((8853077 : ℝ) / 20000000) ((8853077 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_110.1 cov_log_110.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33911361 : ℝ) / 50000000) ((67832739 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67835609 : ℝ) / 100000000) ((8481511 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_111.1 cov_log_112.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-14683 : ℝ) / 50000000) ((-287 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((5387 : ℝ) / 100000000) ((5511 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((44485239 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((2779983 : ℝ) / 6250000) ((11119963 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((44485239 : ℝ) / 100000000) ((44485239 : ℝ) / 100000000) ((44485239 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((55514761 : ℝ) / 100000000))
  have h12 : RB z12 ((10015293 : ℝ) / 12500000) ((10015321 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((55514761 : ℝ) / 100000000) ((55514761 : ℝ) / 100000000) ((55514761 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-11080771 : ℝ) / 50000000) ((-11080631 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_113.1 cov_log_114.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-13145627 : ℝ) / 100000000) ((-6567997 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((44485239 : ℝ) / 100000000))
  have h15 : RB z15 ((-81001277 : ℝ) / 100000000) ((-3240051 : ℝ) / 4000000) := rb_log (show RB ((44485239 : ℝ) / 100000000) ((44485239 : ℝ) / 100000000) ((44485239 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_115.1 cov_log_115.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((2120489 : ℝ) / 3125000) ((67865283 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67835609 : ℝ) / 100000000) ((8481511 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_111.1 cov_log_112.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((89 : ℝ) / 2500000) ((14837 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((5387 : ℝ) / 100000000) ((5511 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((25395147 : ℝ) / 20000000)) - (z19)
  have h20 : RB z20 ((7935639 : ℝ) / 6250000) ((31742587 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((25395147 : ℝ) / 20000000) ((25395147 : ℝ) / 20000000) ((25395147 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((5395147 : ℝ) / 20000000))
  have h21 : RB z21 ((470683093 : ℝ) / 100000000) ((235341777 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((5395147 : ℝ) / 20000000) ((5395147 : ℝ) / 20000000) ((5395147 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((38725371 : ℝ) / 25000000) ((30980317 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_116.1 cov_log_117.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((91817201 : ℝ) / 100000000) ((22970857 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((25395147 : ℝ) / 20000000))
  have h24 : RB z24 ((23882581 : ℝ) / 100000000) ((11941291 : ℝ) / 50000000) := rb_log (show RB ((25395147 : ℝ) / 20000000) ((25395147 : ℝ) / 20000000) ((25395147 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_118.1 cov_log_118.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67934619 : ℝ) / 100000000) ((68000847 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67835609 : ℝ) / 100000000) ((8481511 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_111.1 cov_log_112.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((82531 : ℝ) / 100000000) ((82619 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((5387 : ℝ) / 100000000) ((5511 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((127074189 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((63534339 : ℝ) / 50000000) ((63534401 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((127074189 : ℝ) / 100000000) ((127074189 : ℝ) / 100000000) ((127074189 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((27074189 : ℝ) / 100000000))
  have h30 : RB z30 ((234667561 : ℝ) / 50000000) ((469335581 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((27074189 : ℝ) / 100000000) ((27074189 : ℝ) / 100000000) ((27074189 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((154614687 : ℝ) / 100000000) ((154614787 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_119.1 cov_log_120.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91647203 : ℝ) / 100000000) ((91713307 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((127074189 : ℝ) / 100000000))
  have h33 : RB z33 ((23960089 : ℝ) / 100000000) ((2396009 : ℝ) / 10000000) := rb_log (show RB ((127074189 : ℝ) / 100000000) ((127074189 : ℝ) / 100000000) ((127074189 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_121.1 cov_log_121.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67687113 : ℝ) / 100000000) ((33876609 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67835609 : ℝ) / 100000000) ((8481511 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_111.1 cov_log_112.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-6599 : ℝ) / 4000000) ((-82391 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8853077 : ℝ) / 20000000)) ((-14683 : ℝ) / 50000000) ((-287 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((44485239 : ℝ) / 100000000)) ((89 : ℝ) / 2500000) ((14837 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((25395147 : ℝ) / 20000000)) ((82531 : ℝ) / 100000000) ((82619 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((127074189 : ℝ) / 100000000)) ((-6599 : ℝ) / 4000000) ((-82391 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_6 {k A q d vp vm : ℝ}
    (hk : RB k ((1863 : ℝ) / 1280) ((18663 : ℝ) / 12800))
    (hA : RB A ((1863 : ℝ) / 3143) ((18663 : ℝ) / 31463))
    (hq : RB q ((733997 : ℝ) / 100000000) ((92787 : ℝ) / 12500000))
    (hd : RB d ((98531777 : ℝ) / 50000000) ((98548013 : ℝ) / 50000000))
    (hp : RB vp ((8853077 : ℝ) / 20000000) ((44485239 : ℝ) / 100000000))
    (hm : RB vm ((25395147 : ℝ) / 20000000) ((127074189 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((5387 : ℝ) / 100000000) ((5511 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99994489 : ℝ) / 100000000) ((99994613 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((59271311 : ℝ) / 100000000) ((29657049 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((12109 : ℝ) / 100000000) ((249 : ℝ) / 2000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((1999751 : ℝ) / 2000000) ((99987891 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((55514761 : ℝ) / 100000000) ((11146923 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((55507849 : ℝ) / 100000000) ((55727867 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106358477 : ℝ) / 100000000) ((106857137 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6358477 : ℝ) / 100000000) ((6857137 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99994489 : ℝ) / 100000000) ((99994613 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((59271311 : ℝ) / 100000000) ((29657049 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((4239 : ℝ) / 100000000) ((4341 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99995659 : ℝ) / 100000000) ((99995761 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((5395147 : ℝ) / 20000000) ((27074189 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((26974563 : ℝ) / 100000000) ((13536521 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((54732777 : ℝ) / 25000000) ((43977801 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((79732777 : ℝ) / 25000000) ((63977801 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((729167289 : ℝ) / 50000000) ((1572703653 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31260843 : ℝ) / 100000000) ((15677367 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1863 : ℝ) / 640) ((18663 : ℝ) / 6400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2136619 : ℝ) / 100000000) ((432921 : ℝ) / 20000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100733997 : ℝ) / 100000000) ((12592787 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((16967 : ℝ) / 800000) ((2148833 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((816967 : ℝ) / 800000) ((102148833 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((644457 : ℝ) / 781250) ((20702201 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((162558703 : ℝ) / 100000000) ((81606431 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((56206297 : ℝ) / 100000000) ((56529257 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((9529 : ℝ) / 100000000) ((1961 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19998039 : ℝ) / 20000000) ((99990471 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((40635691 : ℝ) / 25000000) ((16319731 : ℝ) / 10000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((98531777 : ℝ) / 25000000) ((98548013 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2892881 : ℝ) / 100000000) ((365759 : ℝ) / 12500000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3143 : ℝ) / 1280) ((15362793 : ℝ) / 6250000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((588451 : ℝ) / 50000000) ((148957 : ℝ) / 12500000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((824989 : ℝ) / 50000000) ((1676923 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((50824989 : ℝ) / 50000000) ((101676923 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1482396777 : ℝ) / 100000000) ((1599076683 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((144403 : ℝ) / 25000000) ((584597 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25144403 : ℝ) / 25000000) ((100584597 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31441409 : ℝ) / 100000000) ((31538033 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((756919093 : ℝ) / 50000000) ((407653679 : ℝ) / 25000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17816391 : ℝ) / 100000000) ((19431319 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3143 : ℝ) / 1280) ((15362793 : ℝ) / 6250000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((816967 : ℝ) / 400000) ((102148833 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1489595421 : ℝ) / 100000000) ((1604058387 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((608475151 : ℝ) / 20000000) ((1638526923 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1498583 : ℝ) / 20000000) ((8079367 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-16195077 : ℝ) / 6250000) ((-50317133 : ℝ) / 20000000) := rb_log h47 (by norm_num) cov_log_122.1 cov_log_123.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((36161 : ℝ) / 2500000) ((365759 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-52950811 : ℝ) / 12500000) ((-84493129 : ℝ) / 20000000) := rb_log h49 (by norm_num) cov_log_124.1 cov_log_125.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67835609 : ℝ) / 100000000) ((8481511 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_111.1 cov_log_112.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((98732609 : ℝ) / 100000000) ((3957261 : ℝ) / 4000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-324873879 : ℝ) / 100000000) ((-8088353 : ℝ) / 2500000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((20245737 : ℝ) / 100000000) ((5225071 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((3255977 : ℝ) / 3125000) ((117309303 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-44136523 : ℝ) / 20000000) ((-206224817 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((816967 : ℝ) / 800000) ((102148833 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-16195077 : ℝ) / 6250000) ((-50317133 : ℝ) / 20000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-44136523 : ℝ) / 20000000) ((-206224817 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((824989 : ℝ) / 50000000) ((1676923 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((101676923 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-57741001 : ℝ) / 25000000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((158556697 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((206224817 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((206224817 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((137 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((137 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((139 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((139 : ℝ) / 50)) (lo := ((137 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((141 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((141 : ℝ) / 50)) (lo := ((139 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((143 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((143 : ℝ) / 50)) (lo := ((141 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((29 : ℝ) / 10) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((29 : ℝ) / 10)) (lo := ((143 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((147 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((147 : ℝ) / 50)) (lo := ((29 : ℝ) / 10)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((149 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((149 : ℝ) / 50)) (lo := ((147 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((151 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((151 : ℝ) / 50)) (lo := ((149 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((153 : ℝ) / 50) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((153 : ℝ) / 50)) (lo := ((151 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((153 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_6 {k : ℝ} (hk : RB k ((1863 : ℝ) / 1280) ((18663 : ℝ) / 12800)) :
    RB (k / (k + 1)) ((1863 : ℝ) / 3143) ((18663 : ℝ) / 31463) ∧
    RB (qa (r1A k)) ((733997 : ℝ) / 100000000) ((92787 : ℝ) / 12500000) ∧ RB (D0a (r1A k)) ((98531777 : ℝ) / 50000000) ((98548013 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((18193359 : ℝ) / 50000000) ((9112793 : ℝ) / 25000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((48537207 : ℝ) / 25000000) ((97106641 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((69668649 : ℝ) / 50000000) ((69680213 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((140379327 : ℝ) / 50000000) ((280781783 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140379327 : ℝ) / 100000000) ((35097723 : ℝ) / 25000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((98531777 : ℝ) / 50000000) ((98548013 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2893359 : ℝ) / 50000000) ((1462793 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1446679 : ℝ) / 100000000) ((1462793 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((733997 : ℝ) / 100000000) ((92787 : ℝ) / 12500000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((98531777 : ℝ) / 50000000) ((98548013 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((733997 : ℝ) / 100000000) ((92787 : ℝ) / 12500000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1863 : ℝ) / 3143) ((18663 : ℝ) / 31463) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_6 {k : ℝ} (hk : RB k ((1863 : ℝ) / 1280) ((18663 : ℝ) / 12800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_6 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_6 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((8853077 : ℝ) / 20000000)) (ph := ((44485239 : ℝ) / 100000000)) (ml := ((25395147 : ℝ) / 20000000)) (mh := ((127074189 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_6 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_7 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((18663 : ℝ) / 31463) ((2337 : ℝ) / 3937))
    (hq : RB (qa a) ((371147 : ℝ) / 50000000) ((187649 : ℝ) / 25000000))
    (hd : RB (D0a a) ((98515543 : ℝ) / 50000000) ((197063561 : ℝ) / 100000000))
    : certE k a ((22110877 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((8887971 : ℝ) / 20000000) ∧ 0 < certE k a ((127008603 : ℝ) / 100000000) ∧ certE k a ((63553453 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((551 : ℝ) / 10000000) ((2817 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((22110877 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((1105403 : ℝ) / 2500000) ((11054061 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((22110877 : ℝ) / 50000000) ((22110877 : ℝ) / 50000000) ((22110877 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((27889123 : ℝ) / 50000000))
  have h3 : RB z3 ((39635631 : ℝ) / 50000000) ((39635743 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((27889123 : ℝ) / 50000000) ((27889123 : ℝ) / 50000000) ((27889123 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-5807363 : ℝ) / 25000000) ((-23229169 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_126.1 cov_log_127.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1723623 : ℝ) / 12500000) ((-6889457 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((22110877 : ℝ) / 50000000))
  have h6 : RB z6 ((-10199417 : ℝ) / 12500000) ((-40797667 : ℝ) / 50000000) := rb_log (show RB ((22110877 : ℝ) / 50000000) ((22110877 : ℝ) / 50000000) ((22110877 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_128.1 cov_log_128.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((1356127 : ℝ) / 2000000) ((33908211 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((16954783 : ℝ) / 25000000) ((13567123 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_129.1 cov_log_130.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-5853 : ℝ) / 20000000) ((-271 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((551 : ℝ) / 10000000) ((2817 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((8887971 : ℝ) / 20000000)) - (z10)
  have h11 : RB z11 ((44434221 : ℝ) / 100000000) ((8886869 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((8887971 : ℝ) / 20000000) ((8887971 : ℝ) / 20000000) ((8887971 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((11112029 : ℝ) / 20000000))
  have h12 : RB z12 ((79974991 : ℝ) / 100000000) ((15995043 : ℝ) / 20000000) := rb_div_signed h11 (show RB ((11112029 : ℝ) / 20000000) ((11112029 : ℝ) / 20000000) ((11112029 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-11172811 : ℝ) / 50000000) ((-22345341 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_131.1 cov_log_132.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-1658043 : ℝ) / 12500000) ((-13254651 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((8887971 : ℝ) / 20000000))
  have h15 : RB z15 ((-1622067 : ℝ) / 2000000) ((-20275837 : ℝ) / 25000000) := rb_log (show RB ((8887971 : ℝ) / 20000000) ((8887971 : ℝ) / 20000000) ((8887971 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_133.1 cov_log_133.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16959751 : ℝ) / 25000000) ((67848699 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((16954783 : ℝ) / 25000000) ((13567123 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_129.1 cov_log_130.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((3389 : ℝ) / 100000000) ((29567 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((551 : ℝ) / 10000000) ((2817 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((127008603 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((127002969 : ℝ) / 100000000) ((127003093 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((127008603 : ℝ) / 100000000) ((127008603 : ℝ) / 100000000) ((127008603 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((27008603 : ℝ) / 100000000))
  have h21 : RB z21 ((29389471 : ℝ) / 6250000) ((470231997 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((27008603 : ℝ) / 100000000) ((27008603 : ℝ) / 100000000) ((27008603 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((154805501 : ℝ) / 100000000) ((77402801 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_134.1 cov_log_135.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((91826433 : ℝ) / 100000000) ((71791 : ℝ) / 78125) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((127008603 : ℝ) / 100000000))
  have h24 : RB z24 ((23908463 : ℝ) / 100000000) ((1494279 : ℝ) / 6250000) := rb_log (show RB ((127008603 : ℝ) / 100000000) ((127008603 : ℝ) / 100000000) ((127008603 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_136.1 cov_log_136.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67917969 : ℝ) / 100000000) ((67984017 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((16954783 : ℝ) / 25000000) ((13567123 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_129.1 cov_log_130.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((41177 : ℝ) / 50000000) ((32977 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((551 : ℝ) / 10000000) ((2817 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((63553453 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((15887659 : ℝ) / 12500000) ((31775349 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((63553453 : ℝ) / 50000000) ((63553453 : ℝ) / 50000000) ((63553453 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((13553453 : ℝ) / 50000000))
  have h30 : RB z30 ((234444447 : ℝ) / 50000000) ((468889353 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((13553453 : ℝ) / 50000000) ((13553453 : ℝ) / 50000000) ((13553453 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((30903913 : ℝ) / 20000000) ((77259833 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_137.1 cov_log_138.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91656823 : ℝ) / 100000000) ((91722749 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((63553453 : ℝ) / 50000000))
  have h33 : RB z33 ((2998229 : ℝ) / 12500000) ((23985833 : ℝ) / 100000000) := rb_log (show RB ((63553453 : ℝ) / 50000000) ((63553453 : ℝ) / 50000000) ((63553453 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_139.1 cov_log_139.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6767099 : ℝ) / 10000000) ((67736917 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((16954783 : ℝ) / 25000000) ((13567123 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_129.1 cov_log_130.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-1317 : ℝ) / 800000) ((-16443 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((22110877 : ℝ) / 50000000)) ((-5853 : ℝ) / 20000000) ((-271 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((8887971 : ℝ) / 20000000)) ((3389 : ℝ) / 100000000) ((29567 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((127008603 : ℝ) / 100000000)) ((41177 : ℝ) / 50000000) ((32977 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((63553453 : ℝ) / 50000000)) ((-1317 : ℝ) / 800000) ((-16443 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_7 {k A q d vp vm : ℝ}
    (hk : RB k ((18663 : ℝ) / 12800) ((2337 : ℝ) / 1600))
    (hA : RB A ((18663 : ℝ) / 31463) ((2337 : ℝ) / 3937))
    (hq : RB q ((371147 : ℝ) / 50000000) ((187649 : ℝ) / 25000000))
    (hd : RB d ((98515543 : ℝ) / 50000000) ((197063561 : ℝ) / 100000000))
    (hp : RB vp ((22110877 : ℝ) / 50000000) ((8887971 : ℝ) / 20000000))
    (hm : RB vm ((127008603 : ℝ) / 100000000) ((63553453 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((551 : ℝ) / 10000000) ((2817 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49997183 : ℝ) / 50000000) ((9999449 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((59313951 : ℝ) / 100000000) ((7419581 : ℝ) / 12500000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((6199 : ℝ) / 50000000) ((12741 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99987259 : ℝ) / 100000000) ((49993801 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((11112029 : ℝ) / 20000000) ((27889123 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27776533 : ℝ) / 50000000) ((55771331 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((26588011 : ℝ) / 25000000) ((21369351 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1588011 : ℝ) / 25000000) ((1369351 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49997183 : ℝ) / 50000000) ((9999449 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((59313951 : ℝ) / 100000000) ((7419581 : ℝ) / 12500000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((2167 : ℝ) / 50000000) ((1109 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24998891 : ℝ) / 25000000) ((49997833 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((27008603 : ℝ) / 100000000) ((13553453 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((6751851 : ℝ) / 25000000) ((6776433 : ℝ) / 25000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((218824383 : ℝ) / 100000000) ((219779169 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((318824383 : ℝ) / 100000000) ((319779169 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((365136477 : ℝ) / 25000000) ((3935741 : ℝ) / 250000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((1563579 : ℝ) / 5000000) ((3136523 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((18663 : ℝ) / 6400) ((2337 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1082299 : ℝ) / 50000000) ((2192679 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50371147 : ℝ) / 50000000) ((25187649 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2148471 : ℝ) / 100000000) ((2176523 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((102148471 : ℝ) / 100000000) ((102176523 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((20642187 : ℝ) / 25000000) ((2590161 : ℝ) / 3125000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((1626861 : ℝ) / 1000000) ((163336433 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((56165431 : ℝ) / 100000000) ((451889 : ℝ) / 800000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((4877 : ℝ) / 50000000) ((627 : ℝ) / 6250000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((6249373 : ℝ) / 6250000) ((49995123 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((162669779 : ℝ) / 100000000) ((81660251 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((98515543 : ℝ) / 25000000) ((197063561 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2925099 : ℝ) / 100000000) ((2958303 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((245804687 : ℝ) / 100000000) ((3937 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((594381 : ℝ) / 50000000) ((601759 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1670333 : ℝ) / 100000000) ((848673 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((101670333 : ℝ) / 100000000) ((50848673 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((23202217 : ℝ) / 1562500) ((1601017657 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((583991 : ℝ) / 100000000) ((590981 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100583991 : ℝ) / 100000000) ((100590981 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31454203 : ℝ) / 100000000) ((31550593 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1516396091 : ℝ) / 100000000) ((6530273 : ℝ) / 400000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((901317 : ℝ) / 5000000) ((19648253 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((245804687 : ℝ) / 100000000) ((3937 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((102148471 : ℝ) / 50000000) ((102176523 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((93238593 : ℝ) / 6250000) ((160566163 : ℝ) / 10000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((761934377 : ℝ) / 25000000) ((65624369 : ℝ) / 2000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((3745631 : ℝ) / 50000000) ((2018403 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-51828659 : ℝ) / 20000000) ((-251656921 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_140.1 cov_log_141.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1462549 : ℝ) / 100000000) ((92447 : ℝ) / 6250000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-3300773 : ℝ) / 781250) ((-421370123 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_142.1 cov_log_143.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((16954783 : ℝ) / 25000000) ((13567123 : ℝ) / 20000000) := rb_log hd (by norm_num) cov_log_129.1 cov_log_130.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((98883473 : ℝ) / 100000000) ((24770599 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-323615471 : ℝ) / 100000000) ((-322287727 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4024509 : ℝ) / 20000000) ((20773269 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((51206957 : ℝ) / 50000000) ((57619209 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-221201557 : ℝ) / 100000000) ((-207049309 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((102148471 : ℝ) / 100000000) ((102176523 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-51828659 : ℝ) / 20000000) ((-251656921 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-221201557 : ℝ) / 100000000) ((-207049309 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1670333 : ℝ) / 100000000) ((848673 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((50848673 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-230986067 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((636589879 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((207049309 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((207049309 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((11 : ℝ) / 4) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((11 : ℝ) / 4)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((279 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((279 : ℝ) / 100)) (lo := ((11 : ℝ) / 4)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((283 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((287 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((283 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((291 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((291 : ℝ) / 100)) (lo := ((287 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((59 : ℝ) / 20) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((291 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((299 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((59 : ℝ) / 20)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((303 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((303 : ℝ) / 100)) (lo := ((299 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((307 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((307 : ℝ) / 100)) (lo := ((303 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((307 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_7 {k : ℝ} (hk : RB k ((18663 : ℝ) / 12800) ((2337 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((18663 : ℝ) / 31463) ((2337 : ℝ) / 3937) ∧
    RB (qa (r1A k)) ((371147 : ℝ) / 50000000) ((187649 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((98515543 : ℝ) / 50000000) ((197063561 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((36451171 : ℝ) / 100000000) ((2337 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((62107 : ℝ) / 32000) ((194148829 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((17414271 : ℝ) / 12500000) ((1393373 : ℝ) / 1000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((70183881 : ℝ) / 25000000) ((280758657 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((70183881 : ℝ) / 50000000) ((140379329 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((98515543 : ℝ) / 50000000) ((197063561 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((5851171 : ℝ) / 100000000) ((1893 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((182849 : ℝ) / 12500000) ((1478907 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((371147 : ℝ) / 50000000) ((187649 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((98515543 : ℝ) / 50000000) ((197063561 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((371147 : ℝ) / 50000000) ((187649 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((18663 : ℝ) / 31463) ((2337 : ℝ) / 3937) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_7 {k : ℝ} (hk : RB k ((18663 : ℝ) / 12800) ((2337 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_7 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_7 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((22110877 : ℝ) / 50000000)) (ph := ((8887971 : ℝ) / 20000000)) (ml := ((127008603 : ℝ) / 100000000)) (mh := ((63553453 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_7 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_8 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2337 : ℝ) / 3937) ((9381 : ℝ) / 15781))
    (hq : RB (qa a) ((150119 : ℝ) / 20000000) ((153441 : ℝ) / 20000000))
    (hd : RB (D0a a) ((196966137 : ℝ) / 100000000) ((197031089 : ℝ) / 100000000))
    : certE k a ((11012337 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((44480333 : ℝ) / 100000000) ∧ 0 < certE k a ((63504377 : ℝ) / 50000000) ∧ certE k a ((127204907 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((5633 : ℝ) / 100000000) ((5887 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((11012337 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((44043461 : ℝ) / 100000000) ((8808743 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((11012337 : ℝ) / 25000000) ((11012337 : ℝ) / 25000000) ((11012337 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((13987663 : ℝ) / 25000000))
  have h3 : RB z3 ((15743681 : ℝ) / 20000000) ((3935943 : ℝ) / 5000000) := rb_div_signed h2 (show RB ((13987663 : ℝ) / 25000000) ((13987663 : ℝ) / 25000000) ((13987663 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-598233 : ℝ) / 2500000) ((-23928741 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_144.1 cov_log_145.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-14224761 : ℝ) / 100000000) ((-14204081 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((11012337 : ℝ) / 25000000))
  have h6 : RB z6 ((-16397193 : ℝ) / 20000000) ((-81985963 : ℝ) / 100000000) := rb_log (show RB ((11012337 : ℝ) / 25000000) ((11012337 : ℝ) / 25000000) ((11012337 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_146.1 cov_log_146.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33880601 : ℝ) / 50000000) ((16945471 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67786163 : ℝ) / 100000000) ((529837 : ℝ) / 781250) := rb_log hd (by norm_num) cov_log_147.1 cov_log_148.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-28967 : ℝ) / 50000000) ((-4279 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((5633 : ℝ) / 100000000) ((5887 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((44480333 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((22237223 : ℝ) / 50000000) ((444747 : ℝ) / 1000000) := rb_widen (rb_sub (show RB ((44480333 : ℝ) / 100000000) ((44480333 : ℝ) / 100000000) ((44480333 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((55519667 : ℝ) / 100000000))
  have h12 : RB z12 ((320423 : ℝ) / 400000) ((80106209 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((55519667 : ℝ) / 100000000) ((55519667 : ℝ) / 100000000) ((55519667 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-4436451 : ℝ) / 20000000) ((-22181681 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_149.1 cov_log_150.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-659311 : ℝ) / 5000000) ((-13167027 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((44480333 : ℝ) / 100000000))
  have h15 : RB z15 ((-40506153 : ℝ) / 50000000) ((-5063269 : ℝ) / 6250000) := rb_log (show RB ((44480333 : ℝ) / 100000000) ((44480333 : ℝ) / 100000000) ((44480333 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_151.1 cov_log_151.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16956521 : ℝ) / 25000000) ((67845279 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67786163 : ℝ) / 100000000) ((529837 : ℝ) / 781250) := rb_log hd (by norm_num) cov_log_147.1 cov_log_148.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1737 : ℝ) / 25000000) ((14779 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((5633 : ℝ) / 100000000) ((5887 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((63504377 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((127002867 : ℝ) / 100000000) ((127003121 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((63504377 : ℝ) / 50000000) ((63504377 : ℝ) / 50000000) ((63504377 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((13504377 : ℝ) / 50000000))
  have h21 : RB z21 ((47022853 : ℝ) / 10000000) ((470229471 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((13504377 : ℝ) / 50000000) ((13504377 : ℝ) / 50000000) ((13504377 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((77402431 : ℝ) / 50000000) ((30961013 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_152.1 cov_log_153.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((2297301 : ℝ) / 2500000) ((2300593 : ℝ) / 2500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((63504377 : ℝ) / 50000000))
  have h24 : RB z24 ((11954291 : ℝ) / 50000000) ((23908583 : ℝ) / 100000000) := rb_log (show RB ((63504377 : ℝ) / 50000000) ((63504377 : ℝ) / 50000000) ((63504377 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_154.1 cov_log_154.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67983457 : ℝ) / 100000000) ((34057569 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67786163 : ℝ) / 100000000) ((529837 : ℝ) / 781250) := rb_log hd (by norm_num) cov_log_147.1 cov_log_148.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((164321 : ℝ) / 100000000) ((13159 : ℝ) / 4000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((5633 : ℝ) / 100000000) ((5887 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((127204907 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((6359951 : ℝ) / 5000000) ((63599637 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((127204907 : ℝ) / 100000000) ((127204907 : ℝ) / 100000000) ((127204907 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((27204907 : ℝ) / 100000000))
  have h30 : RB z30 ((233779553 : ℝ) / 50000000) ((11689001 : ℝ) / 2500000) := rb_div_signed h29 (show RB ((27204907 : ℝ) / 100000000) ((27204907 : ℝ) / 100000000) ((27204907 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((77117779 : ℝ) / 50000000) ((154235761 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_155.1 cov_log_156.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91554101 : ℝ) / 100000000) ((45842649 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((127204907 : ℝ) / 100000000))
  have h33 : RB z33 ((3007863 : ℝ) / 12500000) ((4812581 : ℝ) / 20000000) := rb_log (show RB ((127204907 : ℝ) / 100000000) ((127204907 : ℝ) / 100000000) ((127204907 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_157.1 cov_log_157.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((16872799 : ℝ) / 25000000) ((33811197 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67786163 : ℝ) / 100000000) ((529837 : ℝ) / 781250) := rb_log hd (by norm_num) cov_log_147.1 cov_log_148.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-16397 : ℝ) / 5000000) ((-163769 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((11012337 : ℝ) / 25000000)) ((-28967 : ℝ) / 50000000) ((-4279 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((44480333 : ℝ) / 100000000)) ((1737 : ℝ) / 25000000) ((14779 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((63504377 : ℝ) / 50000000)) ((164321 : ℝ) / 100000000) ((13159 : ℝ) / 4000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((127204907 : ℝ) / 100000000)) ((-16397 : ℝ) / 5000000) ((-163769 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_8 {k A q d vp vm : ℝ}
    (hk : RB k ((2337 : ℝ) / 1600) ((9381 : ℝ) / 6400))
    (hA : RB A ((2337 : ℝ) / 3937) ((9381 : ℝ) / 15781))
    (hq : RB q ((150119 : ℝ) / 20000000) ((153441 : ℝ) / 20000000))
    (hd : RB d ((196966137 : ℝ) / 100000000) ((197031089 : ℝ) / 100000000))
    (hp : RB vp ((11012337 : ℝ) / 25000000) ((44480333 : ℝ) / 100000000))
    (hm : RB vm ((63504377 : ℝ) / 50000000) ((127204907 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((5633 : ℝ) / 100000000) ((5887 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99994113 : ℝ) / 100000000) ((99994367 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((7419553 : ℝ) / 12500000) ((29720777 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((1583 : ℝ) / 12500000) ((2673 : ℝ) / 20000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((19997327 : ℝ) / 20000000) ((12498417 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((55519667 : ℝ) / 100000000) ((13987663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27756123 : ℝ) / 50000000) ((55943567 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((21220107 : ℝ) / 20000000) ((107078273 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1220107 : ℝ) / 20000000) ((7078273 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99994113 : ℝ) / 100000000) ((99994367 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((7419553 : ℝ) / 12500000) ((29720777 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((1107 : ℝ) / 25000000) ((1159 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24998841 : ℝ) / 25000000) ((24998893 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((13504377 : ℝ) / 50000000) ((27204907 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((27007501 : ℝ) / 100000000) ((27203703 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((109096221 : ℝ) / 50000000) ((220092759 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((159096221 : ℝ) / 50000000) ((320092759 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1412773991 : ℝ) / 100000000) ((1639200497 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((1952559 : ℝ) / 6250000) ((31427523 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2337 : ℝ) / 800) ((9381 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((87707 : ℝ) / 4000000) ((224911 : ℝ) / 10000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((20150119 : ℝ) / 20000000) ((20153441 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((108799 : ℝ) / 5000000) ((446471 : ℝ) / 20000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((5108799 : ℝ) / 5000000) ((20446471 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((82528421 : ℝ) / 100000000) ((83155559 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((81276521 : ℝ) / 50000000) ((640009 : ℝ) / 390625) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((1748329 : ℝ) / 3125000) ((56581167 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1991 : ℝ) / 20000000) ((10523 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99989477 : ℝ) / 100000000) ((19998009 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((634906 : ℝ) / 390625) ((81912997 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((196966137 : ℝ) / 50000000) ((197031089 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((591367 : ℝ) / 20000000) ((604653 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3937 : ℝ) / 1600) ((15781 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1199147 : ℝ) / 100000000) ((614329 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((421869 : ℝ) / 25000000) ((348339 : ℝ) / 20000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25421869 : ℝ) / 25000000) ((20348339 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1436614213 : ℝ) / 100000000) ((1667750371 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((590067 : ℝ) / 100000000) ((604057 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100590067 : ℝ) / 100000000) ((100604057 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((15712643 : ℝ) / 50000000) ((7904341 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1468039499 : ℝ) / 100000000) ((339873547 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((17603951 : ℝ) / 100000000) ((10439709 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3937 : ℝ) / 1600) ((15781 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((5108799 : ℝ) / 2500000) ((20446471 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((288802987 : ℝ) / 20000000) ((83531401 : ℝ) / 5000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1475436411 : ℝ) / 50000000) ((3415844737 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((3601781 : ℝ) / 50000000) ((8356109 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-13152973 : ℝ) / 5000000) ((-248217729 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_158.1 cov_log_159.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1478417 : ℝ) / 100000000) ((1511633 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-421419833 : ℝ) / 100000000) ((-83839593 : ℝ) / 20000000) := rb_log h49 (by norm_num) cov_log_160.1 cov_log_161.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67786163 : ℝ) / 100000000) ((529837 : ℝ) / 781250) := rb_log hd (by norm_num) cov_log_147.1 cov_log_148.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((24752541 : ℝ) / 25000000) ((49704009 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-322409669 : ℝ) / 100000000) ((-319789947 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((19617053 : ℝ) / 100000000) ((2613389 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((46977011 : ℝ) / 50000000) ((29690937 : ℝ) / 25000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-228455647 : ℝ) / 100000000) ((-201026199 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((5108799 : ℝ) / 5000000) ((20446471 : ℝ) / 20000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-13152973 : ℝ) / 5000000) ((-248217729 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-228455647 : ℝ) / 100000000) ((-201026199 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((421869 : ℝ) / 25000000) ((348339 : ℝ) / 20000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((20348339 : ℝ) / 40000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-29362779 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((19304181 : ℝ) / 3125000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((201026199 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((201026199 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((328 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((328 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((333 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((333 : ℝ) / 125)) (lo := ((328 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((338 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((338 : ℝ) / 125)) (lo := ((333 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((343 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((343 : ℝ) / 125)) (lo := ((338 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((348 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((348 : ℝ) / 125)) (lo := ((343 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((353 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((353 : ℝ) / 125)) (lo := ((348 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((358 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((358 : ℝ) / 125)) (lo := ((353 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((363 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((363 : ℝ) / 125)) (lo := ((358 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((368 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((368 : ℝ) / 125)) (lo := ((363 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((373 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((373 : ℝ) / 125)) (lo := ((368 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((378 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((378 : ℝ) / 125)) (lo := ((373 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((383 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((383 : ℝ) / 125)) (lo := ((378 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((383 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_8 {k : ℝ} (hk : RB k ((2337 : ℝ) / 1600) ((9381 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((2337 : ℝ) / 3937) ((9381 : ℝ) / 15781) ∧
    RB (qa (r1A k)) ((150119 : ℝ) / 20000000) ((153441 : ℝ) / 20000000) ∧ RB (D0a (r1A k)) ((196966137 : ℝ) / 100000000) ((197031089 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2337 : ℝ) / 6400) ((9161133 : ℝ) / 25000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((48488867 : ℝ) / 25000000) ((62107 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((27853579 : ℝ) / 20000000) ((139314169 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((280689251 : ℝ) / 100000000) ((140367763 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((1122757 : ℝ) / 800000) ((140367763 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((196966137 : ℝ) / 100000000) ((197031089 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1893 : ℝ) / 32000) ((1511133 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((739453 : ℝ) / 50000000) ((1511133 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((150119 : ℝ) / 20000000) ((153441 : ℝ) / 20000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((196966137 : ℝ) / 100000000) ((197031089 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((150119 : ℝ) / 20000000) ((153441 : ℝ) / 20000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2337 : ℝ) / 3937) ((9381 : ℝ) / 15781) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_8 {k : ℝ} (hk : RB k ((2337 : ℝ) / 1600) ((9381 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_8 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_8 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((11012337 : ℝ) / 25000000)) (ph := ((44480333 : ℝ) / 100000000)) (ml := ((63504377 : ℝ) / 50000000)) (mh := ((127204907 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_8 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_9 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((9381 : ℝ) / 15781) ((4707 : ℝ) / 7907))
    (hq : RB (qa a) ((767203 : ℝ) / 100000000) ((31353 : ℝ) / 4000000))
    (hd : RB (D0a a) ((196901183 : ℝ) / 100000000) ((769399 : ℝ) / 390625))
    : certE k a ((21982943 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((11097499 : ℝ) / 25000000) ∧ 0 < certE k a ((127074337 : ℝ) / 100000000) ∧ certE k a ((31817473 : ℝ) / 25000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((2943 : ℝ) / 50000000) ((24 : ℝ) / 390625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((21982943 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((21979871 : ℝ) / 50000000) ((1099 : ℝ) / 2500) := rb_widen (rb_sub (show RB ((21982943 : ℝ) / 50000000) ((21982943 : ℝ) / 50000000) ((21982943 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((28017057 : ℝ) / 50000000))
  have h3 : RB z3 ((19612937 : ℝ) / 25000000) ((78452209 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((28017057 : ℝ) / 50000000) ((28017057 : ℝ) / 50000000) ((28017057 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-24268643 : ℝ) / 100000000) ((-12134027 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_162.1 cov_log_163.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1444701 : ℝ) / 10000000) ((-360653 : ℝ) / 2500000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((21982943 : ℝ) / 50000000))
  have h6 : RB z6 ((-82175619 : ℝ) / 100000000) ((-82175617 : ℝ) / 100000000) := rb_log (show RB ((21982943 : ℝ) / 50000000) ((21982943 : ℝ) / 50000000) ((21982943 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_164.1 cov_log_164.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((67728607 : ℝ) / 100000000) ((67749499 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((3387659 : ℝ) / 5000000) ((8473271 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_165.1 cov_log_166.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-57561 : ℝ) / 100000000) ((-3681 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((2943 : ℝ) / 50000000) ((24 : ℝ) / 390625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((11097499 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((11095963 : ℝ) / 25000000) ((4438411 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((11097499 : ℝ) / 25000000) ((11097499 : ℝ) / 25000000) ((11097499 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((13902501 : ℝ) / 25000000))
  have h12 : RB z12 ((79812711 : ℝ) / 100000000) ((9976647 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((13902501 : ℝ) / 25000000) ((13902501 : ℝ) / 25000000) ((13902501 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-22548741 : ℝ) / 100000000) ((-11274079 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_167.1 cov_log_168.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-335579 : ℝ) / 2500000) ((-1340373 : ℝ) / 10000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((11097499 : ℝ) / 25000000))
  have h15 : RB z15 ((-81215607 : ℝ) / 100000000) ((-16243121 : ℝ) / 20000000) := rb_log (show RB ((11097499 : ℝ) / 25000000) ((11097499 : ℝ) / 25000000) ((11097499 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_169.1 cov_log_169.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((13558489 : ℝ) / 20000000) ((67811877 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((3387659 : ℝ) / 5000000) ((8473271 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_165.1 cov_log_166.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((6277 : ℝ) / 100000000) ((58697 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((2943 : ℝ) / 50000000) ((24 : ℝ) / 390625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((127074337 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((127068193 : ℝ) / 100000000) ((127068451 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((127074337 : ℝ) / 100000000) ((127074337 : ℝ) / 100000000) ((127074337 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((27074337 : ℝ) / 100000000))
  have h21 : RB z21 ((93866153 : ℝ) / 20000000) ((469331719 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((27074337 : ℝ) / 100000000) ((27074337 : ℝ) / 100000000) ((27074337 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((77306879 : ℝ) / 50000000) ((30922793 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_170.1 cov_log_171.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((91909997 : ℝ) / 100000000) ((11505121 : ℝ) / 12500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((127074337 : ℝ) / 100000000))
  have h24 : RB z24 ((4792041 : ℝ) / 20000000) ((11980103 : ℝ) / 50000000) := rb_log (show RB ((127074337 : ℝ) / 100000000) ((127074337 : ℝ) / 100000000) ((127074337 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_172.1 cov_log_172.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67949791 : ℝ) / 100000000) ((68080763 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((3387659 : ℝ) / 5000000) ((8473271 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_165.1 cov_log_166.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((163623 : ℝ) / 100000000) ((327583 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((2943 : ℝ) / 50000000) ((24 : ℝ) / 390625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((31817473 : ℝ) / 25000000)) - (z28)
  have h29 : RB z29 ((31815937 : ℝ) / 25000000) ((63632003 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((31817473 : ℝ) / 25000000) ((31817473 : ℝ) / 25000000) ((31817473 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((6817473 : ℝ) / 25000000))
  have h30 : RB z30 ((233341129 : ℝ) / 50000000) ((233341603 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((6817473 : ℝ) / 25000000) ((6817473 : ℝ) / 25000000) ((6817473 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((38511961 : ℝ) / 25000000) ((154048051 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_173.1 cov_log_174.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((9157359 : ℝ) / 10000000) ((45852041 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((31817473 : ℝ) / 25000000))
  have h33 : RB z33 ((24113977 : ℝ) / 100000000) ((12056989 : ℝ) / 50000000) := rb_log (show RB ((31817473 : ℝ) / 25000000) ((31817473 : ℝ) / 25000000) ((31817473 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_175.1 cov_log_175.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((16864903 : ℝ) / 25000000) ((13518021 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((3387659 : ℝ) / 5000000) ((8473271 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_165.1 cov_log_166.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-81639 : ℝ) / 25000000) ((-6523 : ℝ) / 4000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((21982943 : ℝ) / 50000000)) ((-57561 : ℝ) / 100000000) ((-3681 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((11097499 : ℝ) / 25000000)) ((6277 : ℝ) / 100000000) ((58697 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((127074337 : ℝ) / 100000000)) ((163623 : ℝ) / 100000000) ((327583 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((31817473 : ℝ) / 25000000)) ((-81639 : ℝ) / 25000000) ((-6523 : ℝ) / 4000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_9 {k A q d vp vm : ℝ}
    (hk : RB k ((9381 : ℝ) / 6400) ((4707 : ℝ) / 3200))
    (hA : RB A ((9381 : ℝ) / 15781) ((4707 : ℝ) / 7907))
    (hq : RB q ((767203 : ℝ) / 100000000) ((31353 : ℝ) / 4000000))
    (hd : RB d ((196901183 : ℝ) / 100000000) ((769399 : ℝ) / 390625))
    (hp : RB vp ((21982943 : ℝ) / 50000000) ((11097499 : ℝ) / 25000000))
    (hm : RB vm ((127074337 : ℝ) / 100000000) ((31817473 : ℝ) / 25000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((2943 : ℝ) / 50000000) ((24 : ℝ) / 390625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((390601 : ℝ) / 390625) ((49997057 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((59441249 : ℝ) / 100000000) ((59526027 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((13259 : ℝ) / 100000000) ((559 : ℝ) / 4000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((3999441 : ℝ) / 4000000) ((99986741 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((13902501 : ℝ) / 25000000) ((28017057 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((6950279 : ℝ) / 12500000) ((11205337 : ℝ) / 20000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106094531 : ℝ) / 100000000) ((53528451 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6094531 : ℝ) / 100000000) ((3528451 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((390601 : ℝ) / 390625) ((49997057 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((59441249 : ℝ) / 100000000) ((59526027 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((289 : ℝ) / 6250000) ((967 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19999033 : ℝ) / 20000000) ((6249711 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((27074337 : ℝ) / 100000000) ((6817473 : ℝ) / 25000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((27073027 : ℝ) / 100000000) ((3408579 : ℝ) / 12500000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((108991989 : ℝ) / 50000000) ((109936039 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((158991989 : ℝ) / 50000000) ((159936039 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1417052411 : ℝ) / 100000000) ((410203837 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31262497 : ℝ) / 100000000) ((15724063 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((9381 : ℝ) / 3200) ((4707 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2249103 : ℝ) / 100000000) ((576479 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100767203 : ℝ) / 100000000) ((4031353 : ℝ) / 4000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2231611 : ℝ) / 100000000) ((57209 : ℝ) / 2500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((102231611 : ℝ) / 100000000) ((2557209 : ℝ) / 2500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((82684341 : ℝ) / 100000000) ((41652003 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((32561289 : ℝ) / 20000000) ((164080689 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((27934679 : ℝ) / 50000000) ((564951 : ℝ) / 1000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((5209 : ℝ) / 50000000) ((5499 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49994501 : ℝ) / 50000000) ((49994791 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((162788539 : ℝ) / 100000000) ((41015899 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((196901183 : ℝ) / 50000000) ((1538798 : ℝ) / 390625) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((3021263 : ℝ) / 100000000) ((154387 : ℝ) / 5000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((15781 : ℝ) / 6400) ((7907 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1222719 : ℝ) / 100000000) ((313059 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((432081 : ℝ) / 25000000) ((1782803 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25432081 : ℝ) / 25000000) ((101782803 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1441543667 : ℝ) / 100000000) ((835033927 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((120563 : ℝ) / 20000000) ((77103 : ℝ) / 12500000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20120563 : ℝ) / 20000000) ((12577103 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3931369 : ℝ) / 12500000) ((15821053 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1472994619 : ℝ) / 100000000) ((42542749 : ℝ) / 2500000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((3602117 : ℝ) / 20000000) ((852377 : ℝ) / 4000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((15781 : ℝ) / 6400) ((7907 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((102231611 : ℝ) / 50000000) ((2557209 : ℝ) / 1250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((362078727 : ℝ) / 25000000) ((836131737 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((118450853 : ℝ) / 4000000) ((684212353 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7207649 : ℝ) / 100000000) ((4172089 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-263002741 : ℝ) / 100000000) ((-248360613 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_176.1 cov_log_177.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1510631 : ℝ) / 100000000) ((154387 : ℝ) / 10000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-10481607 : ℝ) / 2500000) ((-417087793 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_178.1 cov_log_179.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((3387659 : ℝ) / 5000000) ((8473271 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_165.1 cov_log_166.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((4965567 : ℝ) / 5000000) ((99709217 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-15997647 : ℝ) / 5000000) ((-19836161 : ℝ) / 6250000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((19379451 : ℝ) / 100000000) ((20654509 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((11367887 : ℝ) / 12500000) ((22935967 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-57252461 : ℝ) / 25000000) ((-202698741 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((102231611 : ℝ) / 100000000) ((2557209 : ℝ) / 2500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-263002741 : ℝ) / 100000000) ((-248360613 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-57252461 : ℝ) / 25000000) ((-202698741 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((432081 : ℝ) / 25000000) ((1782803 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((101782803 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-234845513 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((311266157 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((202698741 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((202698741 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((529 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((529 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((537 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((537 : ℝ) / 200)) (lo := ((529 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((109 : ℝ) / 40) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((109 : ℝ) / 40)) (lo := ((537 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((553 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((553 : ℝ) / 200)) (lo := ((109 : ℝ) / 40)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((561 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((561 : ℝ) / 200)) (lo := ((553 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((569 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((569 : ℝ) / 200)) (lo := ((561 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((577 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((577 : ℝ) / 200)) (lo := ((569 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((117 : ℝ) / 40) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((117 : ℝ) / 40)) (lo := ((577 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((593 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((593 : ℝ) / 200)) (lo := ((117 : ℝ) / 40)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((601 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((601 : ℝ) / 200)) (lo := ((593 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((609 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((609 : ℝ) / 200)) (lo := ((601 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((609 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_9 {k : ℝ} (hk : RB k ((9381 : ℝ) / 6400) ((4707 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((9381 : ℝ) / 15781) ((4707 : ℝ) / 7907) ∧
    RB (qa (r1A k)) ((767203 : ℝ) / 100000000) ((31353 : ℝ) / 4000000) ∧ RB (D0a (r1A k)) ((196901183 : ℝ) / 100000000) ((769399 : ℝ) / 390625) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((36644531 : ℝ) / 100000000) ((18386719 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((96913281 : ℝ) / 50000000) ((193955469 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((17402701 : ℝ) / 12500000) ((139267897 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((70160741 : ℝ) / 25000000) ((140344627 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((70160741 : ℝ) / 50000000) ((140344627 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((196901183 : ℝ) / 100000000) ((769399 : ℝ) / 390625) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((6044531 : ℝ) / 100000000) ((3086719 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((377783 : ℝ) / 25000000) ((4823 : ℝ) / 312500) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((767203 : ℝ) / 100000000) ((31353 : ℝ) / 4000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((196901183 : ℝ) / 100000000) ((769399 : ℝ) / 390625) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((767203 : ℝ) / 100000000) ((31353 : ℝ) / 4000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((9381 : ℝ) / 15781) ((4707 : ℝ) / 7907) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_9 {k : ℝ} (hk : RB k ((9381 : ℝ) / 6400) ((4707 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_9 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_9 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((21982943 : ℝ) / 50000000)) (ph := ((11097499 : ℝ) / 25000000)) (ml := ((127074337 : ℝ) / 100000000)) (mh := ((31817473 : ℝ) / 25000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_9 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
