import LeanProject.ArcEnergy

/-!
# EP-1038, Stage 12, Lemma 12.7(b), (e): consequences of the sine series of the arc energy

* `AE Q R = (1/(4QR)) ∫_{-Q}^{Q} ∫_{-R}^{R} log|1 - e^{i(θ-φ)}| dφ dθ` (the arc energy `𝒜(Q, R)`),
  `xs n X = sin((n+1)X)/((n+1)X)` (the `x_{n+1}(X)` of Lemma 12.7).
* `AE_series`: `𝒜(Q, R) = -∑_{n ≥ 1} x_n(Q) x_n(R)/n` for `Q, R > 0` (Lemma 12.7(a), normalized).
* `AE_combo`, `AE_combo_nonneg` (**Lemma 12.7(b)**):
  `2𝒜(Q, R) - 𝒜(Q, Q) - 𝒜(R, R) = ∑_{n ≥ 1} (x_n(Q) - x_n(R))²/n ≥ 0`.
* `AE_tail` (**Lemma 12.7(e)**): for `n₀ ≥ 1`,
  `-1/(2 n₀² Q²) ≤ 𝒜(Q, Q) + ∑_{n ≤ n₀} sin²(nQ)/(n³Q²) ≤ 0`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- The arc energy `𝒜(Q, R)`. -/
noncomputable def AE (Q R : ℝ) : ℝ :=
  1 / (4 * Q * R) * ∫ θ in (-Q)..Q, ∫ φ in (-R)..R, Kl 1 (θ - φ)

/-- `xs n X = x_{n+1}(X) = sin((n+1)X)/((n+1)X)`. -/
noncomputable def xs (n : ℕ) (X : ℝ) : ℝ := Real.sin ((n + 1) * X) / ((n + 1) * X)

/-- The terms of `-𝒜(Q, Q)`: `tq Q n = x_{n+1}(Q)²/(n+1) = sin²((n+1)Q)/((n+1)³Q²)`. -/
noncomputable def tq (Q : ℝ) (n : ℕ) : ℝ := xs n Q * xs n Q / ((n : ℝ) + 1)

theorem summable_inv_cube : Summable (fun n : ℕ => 1 / ((n : ℝ) + 1) ^ 3) := by
  have h := (summable_nat_add_iff 1).mpr (summable_one_div_nat_pow.mpr (by norm_num : 1 < 3))
  exact h.congr (fun n => by norm_num)

theorem abs_xs_le {X : ℝ} (hX : 0 < X) (n : ℕ) : |xs n X| ≤ 1 / (((n : ℝ) + 1) * X) := by
  have hp : (0 : ℝ) < ((n : ℝ) + 1) * X := mul_pos (by positivity) hX
  unfold xs
  rw [abs_div, abs_of_pos hp]
  exact div_le_div_of_nonneg_right (Real.abs_sin_le_one _) hp.le

theorem summable_xx {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R) :
    Summable (fun n : ℕ => xs n Q * xs n R / ((n : ℝ) + 1)) := by
  refine Summable.of_norm_bounded (summable_inv_cube.mul_left (1 / (Q * R))) (fun n => ?_)
  have hn : (0 : ℝ) < (n : ℝ) + 1 := by positivity
  have hQ0 := hQ.ne'
  have hR0 := hR.ne'
  have hn0 := hn.ne'
  have h1 := abs_xs_le hQ n
  have h2 := abs_xs_le hR n
  have h12 : |xs n Q| * |xs n R| ≤ 1 / (((n : ℝ) + 1) * Q) * (1 / (((n : ℝ) + 1) * R)) :=
    mul_le_mul h1 h2 (abs_nonneg _) ((abs_nonneg _).trans h1)
  rw [Real.norm_eq_abs, abs_div, abs_mul, abs_of_pos hn]
  calc |xs n Q| * |xs n R| / ((n : ℝ) + 1)
      ≤ 1 / (((n : ℝ) + 1) * Q) * (1 / (((n : ℝ) + 1) * R)) / ((n : ℝ) + 1) :=
        div_le_div_of_nonneg_right h12 hn.le
    _ = 1 / (Q * R) * (1 / ((n : ℝ) + 1) ^ 3) := by
        field_simp
        try ring

/-- **Lemma 12.7(a)**, normalized: `𝒜(Q, R) = -∑_{n ≥ 1} x_n(Q) x_n(R)/n`. -/
theorem AE_series {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R) :
    AE Q R = -∑' n : ℕ, xs n Q * xs n R / ((n : ℝ) + 1) := by
  have hQ0 := hQ.ne'
  have hR0 := hR.ne'
  unfold AE
  rw [arc_series hR.le, mul_neg, ← tsum_mul_left]
  congr 1
  refine tsum_congr (fun n => ?_)
  have hn0 : (n : ℝ) + 1 ≠ 0 := by positivity
  unfold xs
  field_simp
  try ring

/-- **Lemma 12.7(b)**: `2𝒜(Q, R) - 𝒜(Q, Q) - 𝒜(R, R) = ∑_{n ≥ 1} (x_n(Q) - x_n(R))²/n`. -/
theorem AE_combo {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R) :
    2 * AE Q R - AE Q Q - AE R R = ∑' n : ℕ, (xs n Q - xs n R) ^ 2 / ((n : ℝ) + 1) := by
  rw [AE_series hQ hR, AE_series hQ hQ, AE_series hR hR]
  have s1 := summable_xx hQ hR
  have s2 := summable_xx hQ hQ
  have s3 := summable_xx hR hR
  have e : ∀ n : ℕ, (xs n Q - xs n R) ^ 2 / ((n : ℝ) + 1) =
      (xs n Q * xs n Q / ((n : ℝ) + 1) + xs n R * xs n R / ((n : ℝ) + 1)) -
        2 * (xs n Q * xs n R / ((n : ℝ) + 1)) := by
    intro n; ring
  rw [tsum_congr e, (s2.add s3).tsum_sub (s1.mul_left 2), s2.tsum_add s3, tsum_mul_left]
  ring

theorem AE_combo_nonneg {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R) :
    0 ≤ 2 * AE Q R - AE Q Q - AE R R := by
  rw [AE_combo hQ hR]
  exact tsum_nonneg (fun n => div_nonneg (sq_nonneg _) (by positivity))

theorem tq_nonneg (Q : ℝ) (n : ℕ) : 0 ≤ tq Q n :=
  div_nonneg (mul_self_nonneg _) (by positivity)

theorem tq_le {Q : ℝ} (hQ : 0 < Q) (n : ℕ) : tq Q n ≤ 1 / Q ^ 2 * (1 / ((n : ℝ) + 1) ^ 3) := by
  have hn : (0 : ℝ) < (n : ℝ) + 1 := by positivity
  have hQ0 := hQ.ne'
  have hn0 := hn.ne'
  have h1 := abs_xs_le hQ n
  have hsq : xs n Q * xs n Q ≤ 1 / (((n : ℝ) + 1) * Q) * (1 / (((n : ℝ) + 1) * Q)) :=
    calc xs n Q * xs n Q = |xs n Q| * |xs n Q| := (abs_mul_abs_self _).symm
      _ ≤ _ := mul_le_mul h1 h1 (abs_nonneg _) ((abs_nonneg _).trans h1)
  unfold tq
  calc xs n Q * xs n Q / ((n : ℝ) + 1)
      ≤ 1 / (((n : ℝ) + 1) * Q) * (1 / (((n : ℝ) + 1) * Q)) / ((n : ℝ) + 1) :=
        div_le_div_of_nonneg_right hsq hn.le
    _ = 1 / Q ^ 2 * (1 / ((n : ℝ) + 1) ^ 3) := by
        field_simp
        try ring

theorem inv_cube_le_tele {m : ℝ} (hm : 0 < m) :
    1 / (m + 1) ^ 3 ≤ (1 / m ^ 2 - 1 / (m + 1) ^ 2) / 2 := by
  have hp : 0 < m + 1 := by linarith
  have hm0 := hm.ne'
  have hp0 := hp.ne'
  have e : (1 / m ^ 2 - 1 / (m + 1) ^ 2) / 2 = (2 * m + 1) / (2 * m ^ 2 * (m + 1) ^ 2) := by
    field_simp
    try ring
  rw [e, div_le_div_iff₀ (pow_pos hp 3) (mul_pos (mul_pos two_pos (pow_pos hm 2)) (pow_pos hp 2))]
  nlinarith [mul_nonneg (sq_nonneg (m + 1)) (by linarith : (0 : ℝ) ≤ 3 * m + 1)]

/-- **Lemma 12.7(e)**: for `n₀ ≥ 1`,
`-1/(2 n₀² Q²) ≤ 𝒜(Q, Q) + ∑_{n ≤ n₀} sin²(nQ)/(n³Q²) ≤ 0`. -/
theorem AE_tail {Q : ℝ} (hQ : 0 < Q) {n0 : ℕ} (hn0 : 1 ≤ n0) :
    -(1 / (2 * (n0 : ℝ) ^ 2 * Q ^ 2)) ≤ AE Q Q + ∑ n ∈ Finset.range n0, tq Q n ∧
      AE Q Q + ∑ n ∈ Finset.range n0, tq Q n ≤ 0 := by
  have hs : Summable (tq Q) := summable_xx hQ hQ
  have hA : AE Q Q = -∑' n, tq Q n := AE_series hQ hQ
  have hsplit := hs.sum_add_tsum_nat_add n0
  have key : AE Q Q + ∑ n ∈ Finset.range n0, tq Q n = -∑' i, tq Q (i + n0) := by
    rw [hA, ← hsplit]; ring
  rw [key]
  constructor
  · rw [neg_le_neg_iff]
    set g : ℕ → ℝ := fun i => 1 / ((i : ℝ) + n0) ^ 2 with hg
    have hn0r : (1 : ℝ) ≤ n0 := by exact_mod_cast hn0
    have hterm : ∀ i : ℕ, tq Q (i + n0) ≤ 1 / Q ^ 2 * ((g i - g (i + 1)) / 2) := by
      intro i
      have hm : (0 : ℝ) < (i : ℝ) + n0 := by
        have := (Nat.cast_nonneg i : (0 : ℝ) ≤ i); linarith
      have h1 := tq_le hQ (i + n0)
      push_cast at h1
      have h2 := inv_cube_le_tele hm
      have e1 : g (i + 1) = 1 / ((i : ℝ) + n0 + 1) ^ 2 := by
        simp only [hg, Nat.cast_add, Nat.cast_one]; ring
      have e0 : g i = 1 / ((i : ℝ) + n0) ^ 2 := by simp only [hg]
      rw [e1, e0]
      exact h1.trans (mul_le_mul_of_nonneg_left h2 (by positivity))
    apply Real.tsum_le_of_sum_range_le (fun i => tq_nonneg Q _)
    intro N
    have hgN : 0 ≤ g N := by simp only [hg]; positivity
    have hQ0 := hQ.ne'
    have hn00 : (n0 : ℝ) ≠ 0 := (by linarith : (0 : ℝ) < n0).ne'
    calc ∑ i ∈ Finset.range N, tq Q (i + n0)
        ≤ ∑ i ∈ Finset.range N, 1 / Q ^ 2 * ((g i - g (i + 1)) / 2) :=
          Finset.sum_le_sum (fun i _ => hterm i)
      _ = 1 / Q ^ 2 * ((g 0 - g N) / 2) := by
          rw [← Finset.mul_sum, ← Finset.sum_div, Finset.sum_range_sub']
      _ ≤ 1 / Q ^ 2 * (g 0 / 2) :=
          mul_le_mul_of_nonneg_left (by linarith) (by positivity)
      _ = 1 / (2 * (n0 : ℝ) ^ 2 * Q ^ 2) := by
          simp only [hg, Nat.cast_zero, zero_add]
          field_simp
          try ring
  · rw [neg_nonpos]
    exact tsum_nonneg (fun i => tq_nonneg Q _)

end EP1038.Arc
