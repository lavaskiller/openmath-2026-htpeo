import LeanProject.DImplicitRoots

/-! Exact implicit first/second derivatives and the replay's true width derivatives. -/
open Real Set Filter Topology
open scoped ContDiff
namespace EP1038.DLowerCert
open EP1038.Stage9

theorem hasDerivAt_E_along {q t : ℝ} {r : ℝ → ℝ}
    (hq : q ∈ Qadm) (hr : HasDerivAt r t q)
    (hx : r q - q ^ 2 ≠ 0) (hy : 1 - r q ≠ 0) (hv : r q ≠ 0) :
    HasDerivAt (fun x => E x (r x)) (Eq q (r q) + Ev q (r q) * t) q := by
  have hX := hr.sub ((hasDerivAt_id q).pow 2)
  have hY := hr.const_sub 1
  have h := (((hasDerivAt_aval hq.1 hq.2.1).mul ((hX.log hx).sub (hY.log hy))).sub
    (hr.log hv)).sub (hasDerivAt_delta hq.1)
  convert h using 1
  · rfl
  · unfold Eq Ev
    simp only [id_eq, Pi.add_apply, Pi.sub_apply, Pi.mul_apply, Pi.div_apply, Pi.pow_apply, Pi.neg_apply, Nat.cast_ofNat, Nat.reduceSub, pow_one]
    ring

theorem hasDerivAt_Ev_along {q t : ℝ} {r : ℝ → ℝ}
    (hq : q ∈ Qadm) (hr : HasDerivAt r t q)
    (hx : r q - q ^ 2 ≠ 0) (hy : 1 - r q ≠ 0) (hv : r q ≠ 0) :
    HasDerivAt (fun x => Ev x (r x)) (Evq q (r q) + Evv q (r q) * t) q := by
  have hX := hr.sub ((hasDerivAt_id q).pow 2)
  have hY := hr.const_sub 1
  have h := ((hasDerivAt_aval hq.1 hq.2.1).mul
    (((hasDerivAt_const q (1 : ℝ)).div hX hx).add
      ((hasDerivAt_const q (1 : ℝ)).div hY hy))).sub
        ((hasDerivAt_const q (1 : ℝ)).div hr hv)
  convert h using 1
  · rfl
  · unfold Evq Evv
    simp only [id_eq, Pi.add_apply, Pi.sub_apply, Pi.mul_apply, Pi.div_apply, Pi.pow_apply, Pi.neg_apply, Nat.cast_ofNat, Nat.reduceSub, pow_one]
    field_simp [hx, hy, hv]
    <;> ring

theorem hasDerivAt_Eq_along {q t : ℝ} {r : ℝ → ℝ}
    (hq : q ∈ Qadm) (hr : HasDerivAt r t q)
    (hx : r q - q ^ 2 ≠ 0) (hy : 1 - r q ≠ 0) :
    HasDerivAt (fun x => Eq x (r x)) (Eqq q (r q) + Evq q (r q) * t) q := by
  have hX := hr.sub ((hasDerivAt_id q).pow 2)
  have hY := hr.const_sub 1
  have h := (((hasDerivAt_aval1 hq.1 hq.2.1).mul ((hX.log hx).sub (hY.log hy))).add
    ((hasDerivAt_aval hq.1 hq.2.1).mul
      (((hasDerivAt_id q).const_mul (-2)).div hX hx))).sub (hasDerivAt_delta1 hq.1)
  convert h using 1
  · rfl
  · unfold Eqq Evq
    simp only [id_eq, Pi.add_apply, Pi.sub_apply, Pi.mul_apply, Pi.div_apply, Pi.pow_apply, Pi.neg_apply, Nat.cast_ofNat, Nat.reduceSub, pow_one]
    field_simp [hx, hy]
    <;> ring

noncomputable def rootSlope (q v : ℝ) : ℝ := -Eq q v / Ev q v
noncomputable def rootCurvature (q v : ℝ) : ℝ :=
  -(Evv q v * (rootSlope q v) ^ 2 + 2 * Evq q v * rootSlope q v + Eqq q v) / Ev q v

theorem implicit_first_derivative {q : ℝ} {r : ℝ → ℝ} (hq : q ∈ Qadm)
    (hc : ContDiffAt ℝ ∞ r q) (hz : ∀ x ∈ Qadm, E x (r x) = 0)
    (hx : r q - q ^ 2 ≠ 0) (hy : 1 - r q ≠ 0) (hv : r q ≠ 0)
    (hn : Ev q (r q) ≠ 0) : HasDerivAt r (rootSlope q (r q)) q := by
  have hr := (hc.differentiableAt (by simp)).hasDerivAt
  have he := hasDerivAt_E_along hq hr hx hy hv
  have hzero : (fun x => E x (r x)) =ᶠ[𝓝 q] fun _ => 0 := by
    filter_upwards [Qadm_mem_nhds hq] with x hxa
    exact hz x hxa
  have hd := he.unique ((hasDerivAt_const q (0 : ℝ)).congr_of_eventuallyEq hzero)
  have hs : deriv r q = rootSlope q (r q) := by
    unfold rootSlope
    apply (eq_div_iff hn).mpr
    linarith
  rwa [hs] at hr

theorem implicit_second_derivative {q : ℝ} {r : ℝ → ℝ} (hq : q ∈ Qadm)
    (hc : ∀ x ∈ Qadm, ContDiffAt ℝ ∞ r x) (hz : ∀ x ∈ Qadm, E x (r x) = 0)
    (hx : ∀ x ∈ Qadm, r x - x ^ 2 ≠ 0) (hy : ∀ x ∈ Qadm, 1 - r x ≠ 0)
    (hv : ∀ x ∈ Qadm, r x ≠ 0) (hn : ∀ x ∈ Qadm, Ev x (r x) ≠ 0) :
    HasDerivAt (deriv r) (rootCurvature q (r q)) q := by
  have hr := implicit_first_derivative hq (hc q hq) hz (hx q hq) (hy q hq) (hv q hq) (hn q hq)
  have hEv := hasDerivAt_Ev_along hq hr (hx q hq) (hy q hq) (hv q hq)
  have hEq := hasDerivAt_Eq_along hq hr (hx q hq) (hy q hq)
  have hS := ((hEq.neg).div hEv (hn q hq))
  have he : deriv r =ᶠ[𝓝 q] fun x => -Eq x (r x) / Ev x (r x) := by
    filter_upwards [Qadm_mem_nhds hq] with x hxa
    exact (implicit_first_derivative hxa (hc x hxa) hz (hx x hxa) (hy x hxa)
      (hv x hxa) (hn x hxa)).deriv
  convert hS.congr_of_eventuallyEq he using 1
  unfold rootCurvature rootSlope
  simp only [Pi.neg_apply]
  field_simp [hn q hq]
  <;> ring

theorem vPlus_denominators {q : ℝ} (hq : q ∈ Qadm) :
    vPlus q - q ^ 2 ≠ 0 ∧ 1 - vPlus q ≠ 0 ∧ vPlus q ≠ 0 := by
  have hv := vPlus_mem hq
  have hx : 0 < vPlus q - q ^ 2 := by nlinarith [mul_pos hq.1 (sub_pos.mpr hq.2.1)]
  exact ⟨hx.ne', (sub_pos.mpr hv.2).ne', (hq.1.trans hv.1).ne'⟩

theorem vMinus_denominators {q : ℝ} (hq : q ∈ Qadm) :
    vMinus q - q ^ 2 ≠ 0 ∧ 1 - vMinus q ≠ 0 ∧ vMinus q ≠ 0 := by
  have hv := vMinus_mem hq
  have hx : 0 < vMinus q - q ^ 2 := by nlinarith [hq.1, hq.2.1]
  exact ⟨hx.ne', (by linarith), (zero_lt_one.trans hv).ne'⟩

theorem vPlus_hasDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt vPlus (rootSlope q (vPlus q)) q :=
  implicit_first_derivative hq (vPlus_contDiffAt hq) (fun _ hx => E_vPlus hx)
    (vPlus_denominators hq).1 (vPlus_denominators hq).2.1 (vPlus_denominators hq).2.2
    (Ev_vPlus_pos hq).ne'

theorem vMinus_hasDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt vMinus (rootSlope q (vMinus q)) q :=
  implicit_first_derivative hq (vMinus_contDiffAt hq) (fun _ hx => E_vMinus hx)
    (vMinus_denominators hq).1 (vMinus_denominators hq).2.1 (vMinus_denominators hq).2.2
    (Ev_vMinus_neg hq).ne

theorem vPlus_hasSecondDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt (deriv vPlus) (rootCurvature q (vPlus q)) q :=
  implicit_second_derivative hq (fun _ hx => vPlus_contDiffAt hx) (fun _ hx => E_vPlus hx)
    (fun _ hx => (vPlus_denominators hx).1) (fun _ hx => (vPlus_denominators hx).2.1)
    (fun _ hx => (vPlus_denominators hx).2.2) (fun _ hx => (Ev_vPlus_pos hx).ne')

theorem vMinus_hasSecondDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt (deriv vMinus) (rootCurvature q (vMinus q)) q :=
  implicit_second_derivative hq (fun _ hx => vMinus_contDiffAt hx) (fun _ hx => E_vMinus hx)
    (fun _ hx => (vMinus_denominators hx).1) (fun _ hx => (vMinus_denominators hx).2.1)
    (fun _ hx => (vMinus_denominators hx).2.2) (fun _ hx => (Ev_vMinus_neg hx).ne)

end EP1038.DLowerCert
