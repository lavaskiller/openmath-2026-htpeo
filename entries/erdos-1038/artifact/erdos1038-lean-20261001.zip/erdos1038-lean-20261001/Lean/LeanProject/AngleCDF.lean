import LeanProject.AtomicVelocity
import LeanProject.DistFn
import LeanProject.RefPositivity
import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts

/-!
# A reference probability coordinate and its inverse

The cumulative angular mass is constructed from the reference density. It is
strictly increasing even when the density vanishes at the left endpoint.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage11
open EP1038.Arc

structure AngleReference where
  k : ℝ
  ρ : ℝ
  k_pos : 0 < k
  rho_pos : 0 < ρ
  rho_lt_one : ρ < 1
  density_zero_nonneg : 0 ≤ alpha k ρ 0

namespace AngleReference

/-- The paper's reference density on `[a,2]`, with its positivity hypothesis discharged. -/
noncomputable def ofInterval (k a : ℝ) (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) : AngleReference where
  k := k
  ρ := qa a
  k_pos := hk
  rho_pos := qa_pos ha ha2
  rho_lt_one := qa_lt_one ha
  density_zero_nonneg := (eta_nonneg_iff ha ha2 hk).mpr hH1 0

noncomputable def cdf (A : AngleReference) (θ : ℝ) : ℝ :=
  1 / π * ∫ t in (0 : ℝ)..θ, alpha A.k A.ρ t

theorem cdf_zero (A : AngleReference) : A.cdf 0 = 0 := by simp [cdf]

theorem cdf_pi (A : AngleReference) : A.cdf π = 1 := by
  rw [cdf]
  change 1 / π * ∫ t in (0 : ℝ)..π, ((A.k + 1) - A.k * Pq A.ρ t) = 1
  rw [eta_dist A.rho_pos.le A.rho_lt_one]
  simp

theorem cdf_hasDerivAt (A : AngleReference) (θ : ℝ) :
    HasDerivAt A.cdf (1 / π * alpha A.k A.ρ θ) θ := by
  have hc := alpha_cont A.k A.ρ A.rho_pos.le A.rho_lt_one
  exact (intervalIntegral.integral_hasDerivAt_right (hc.intervalIntegrable _ _)
    hc.stronglyMeasurable.stronglyMeasurableAtFilter hc.continuousAt).const_mul (1 / π)

theorem cdf_continuous (A : AngleReference) : Continuous A.cdf :=
  continuous_iff_continuousAt.mpr fun θ => (A.cdf_hasDerivAt θ).continuousAt

theorem cdf_strictMonoOn (A : AngleReference) : StrictMonoOn A.cdf (Icc (0 : ℝ) π) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc _ _) A.cdf_continuous.continuousOn
  intro θ hθ
  rw [interior_Icc] at hθ
  rw [(A.cdf_hasDerivAt θ).deriv]
  exact mul_pos (one_div_pos.mpr Real.pi_pos)
    (alpha_pos A.k_pos A.rho_pos A.rho_lt_one A.density_zero_nonneg hθ.1 hθ.2.le)

theorem cdf_mem (A : AngleReference) {θ : ℝ} (hθ : θ ∈ Icc (0 : ℝ) π) :
    A.cdf θ ∈ Icc (0 : ℝ) 1 := by
  have hm := A.cdf_strictMonoOn.monotoneOn
  constructor
  · simpa only [A.cdf_zero] using hm ⟨le_rfl, Real.pi_pos.le⟩ hθ hθ.1
  · simpa only [A.cdf_pi] using hm hθ ⟨Real.pi_pos.le, le_rfl⟩ hθ.2

theorem cdf_image (A : AngleReference) : A.cdf '' Icc (0 : ℝ) π = Icc (0 : ℝ) 1 := by
  simpa only [A.cdf_zero, A.cdf_pi] using
    A.cdf_continuous.continuousOn.image_Icc_of_monotoneOn Real.pi_pos.le
      A.cdf_strictMonoOn.monotoneOn

theorem cdf_surjective (A : AngleReference) {u : ℝ} (hu : u ∈ Icc (0 : ℝ) 1) :
    ∃ θ ∈ Icc (0 : ℝ) π, A.cdf θ = u := by
  rw [← A.cdf_image] at hu
  exact hu

noncomputable def inverse (A : AngleReference) (u : ℝ) : ℝ :=
  if hu : u ∈ Icc (0 : ℝ) 1 then (A.cdf_surjective hu).choose
  else if u ≤ 0 then 0 else π

theorem inverse_mem (A : AngleReference) (u : ℝ) : A.inverse u ∈ Icc (0 : ℝ) π := by
  unfold inverse
  split_ifs with hu h0
  · exact (A.cdf_surjective hu).choose_spec.1
  · exact ⟨le_rfl, Real.pi_pos.le⟩
  · exact ⟨Real.pi_pos.le, le_rfl⟩

theorem cdf_inverse (A : AngleReference) {u : ℝ} (hu : u ∈ Icc (0 : ℝ) 1) :
    A.cdf (A.inverse u) = u := by
  rw [inverse, dif_pos hu]
  exact (A.cdf_surjective hu).choose_spec.2

theorem inverse_cdf (A : AngleReference) {θ : ℝ} (hθ : θ ∈ Icc (0 : ℝ) π) :
    A.inverse (A.cdf θ) = θ :=
  A.cdf_strictMonoOn.injOn (A.inverse_mem _) hθ (A.cdf_inverse (A.cdf_mem hθ))

theorem inverse_zero (A : AngleReference) : A.inverse 0 = 0 := by
  simpa only [A.cdf_zero] using A.inverse_cdf ⟨le_rfl, Real.pi_pos.le⟩

theorem inverse_one (A : AngleReference) : A.inverse 1 = π := by
  simpa only [A.cdf_pi] using A.inverse_cdf ⟨Real.pi_pos.le, le_rfl⟩

theorem inverse_of_nonpos (A : AngleReference) {u : ℝ} (hu : u ≤ 0) : A.inverse u = 0 := by
  rcases eq_or_lt_of_le hu with h | h
  · simpa only [h] using A.inverse_zero
  · simp [inverse, show u ∉ Icc (0 : ℝ) 1 from fun hmem => not_le_of_gt h hmem.1, hu]

theorem inverse_of_one_le (A : AngleReference) {u : ℝ} (hu : 1 ≤ u) : A.inverse u = π := by
  rcases eq_or_lt_of_le hu with h | h
  · simpa only [← h] using A.inverse_one
  · simp [inverse, show u ∉ Icc (0 : ℝ) 1 from fun hmem => not_le_of_gt h hmem.2,
      show ¬ u ≤ 0 by linarith]

theorem inverse_monotone (A : AngleReference) : Monotone A.inverse := by
  intro u v huv
  by_cases hu : u ≤ 0
  · rw [A.inverse_of_nonpos hu]; exact (A.inverse_mem v).1
  by_cases hv : 1 ≤ v
  · rw [A.inverse_of_one_le hv]; exact (A.inverse_mem u).2
  have hu' : u ∈ Icc (0 : ℝ) 1 := ⟨by linarith, by linarith⟩
  have hv' : v ∈ Icc (0 : ℝ) 1 := ⟨by linarith, by linarith⟩
  by_contra h
  have ht := A.cdf_strictMonoOn (A.inverse_mem v) (A.inverse_mem u) (lt_of_not_ge h)
  rw [A.cdf_inverse hv', A.cdf_inverse hu'] at ht
  linarith

theorem inverse_measurable (A : AngleReference) : Measurable A.inverse := A.inverse_monotone.measurable

theorem inverse_interior (A : AngleReference) {u : ℝ} (hu : u ∈ Ioo (0 : ℝ) 1) :
    A.inverse u ∈ Ioo (0 : ℝ) π := by
  have hm := A.inverse_mem u
  have hc := A.cdf_inverse ⟨hu.1.le, hu.2.le⟩
  constructor
  · by_contra h
    have heq : A.inverse u = 0 := by linarith [hm.1]
    rw [heq, A.cdf_zero] at hc
    linarith [hu.1]
  · by_contra h
    have heq : A.inverse u = π := by linarith [hm.2]
    rw [heq, A.cdf_pi] at hc
    linarith [hu.2]

/-- Change of variables for every real integrand, including step functions.
The monotone substitution theorem also handles totalized integrals. -/
theorem integral_cdf (A : AngleReference) (g : ℝ → ℝ) :
    (∫ u in (0 : ℝ)..1, g u) =
      1 / π * ∫ θ in (0 : ℝ)..π, g (A.cdf θ) * alpha A.k A.ρ θ := by
  have h := intervalIntegral.integral_comp_mul_deriv_of_deriv_nonneg
    (f := A.cdf) (f' := fun θ => 1 / π * alpha A.k A.ρ θ) (g := g)
    (a := 0) (b := π) A.cdf_continuous.continuousOn
    (fun θ _ => A.cdf_hasDerivAt θ) (fun θ _ => by
      exact mul_nonneg (one_div_pos.mpr Real.pi_pos).le
        (alpha_bounds A.k_pos.le A.rho_pos.le A.rho_lt_one A.density_zero_nonneg θ).1)
  rw [A.cdf_zero, A.cdf_pi] at h
  have hfun : (fun θ => (g ∘ A.cdf) θ * (1 / π * alpha A.k A.ρ θ)) =
      (fun θ => 1 / π * (g (A.cdf θ) * alpha A.k A.ρ θ)) := by funext θ; simp; ring
  rw [hfun, intervalIntegral.integral_const_mul] at h
  exact h.symm

noncomputable def position (c r θ : ℝ) : ℝ := c - r * cos θ

noncomputable def quantile (A : AngleReference) (c r u : ℝ) : ℝ := position c r (A.inverse u)

theorem quantile_cdf (A : AngleReference) (c r : ℝ) {θ : ℝ} (hθ : θ ∈ Icc (0 : ℝ) π) :
    A.quantile c r (A.cdf θ) = position c r θ := by rw [quantile, A.inverse_cdf hθ]

theorem position_bounds {c r θ : ℝ} (hr : 0 ≤ r) : position c r θ ∈ Icc (c - r) (c + r) := by
  dsimp [position]
  have hc := Real.cos_le_one θ
  have hl := Real.neg_one_le_cos θ
  constructor <;> nlinarith

theorem position_mono {c r : ℝ} (hr : 0 ≤ r) : MonotoneOn (position c r) (Icc (0 : ℝ) π) := by
  intro θ hθ φ hφ h
  dsimp [position]
  have hc := Real.cos_le_cos_of_nonneg_of_le_pi hθ.1 hφ.2 h
  nlinarith

theorem quantile_monotone (A : AngleReference) {c r : ℝ} (hr : 0 ≤ r) : Monotone (A.quantile c r) :=
  fun u v huv => position_mono hr (A.inverse_mem u) (A.inverse_mem v) (A.inverse_monotone huv)

theorem quantile_measurable (A : AngleReference) {c r : ℝ} (hr : 0 ≤ r) :
    Measurable (A.quantile c r) := (A.quantile_monotone hr).measurable

theorem quantile_bounds (A : AngleReference) {c r : ℝ} (hr : 0 ≤ r) (u : ℝ) :
    A.quantile c r u ∈ Icc (c - r) (c + r) := position_bounds hr

/-- The constructed reference quantile has precisely the reference angular law. -/
theorem integral_quantile (A : AngleReference) (c r : ℝ) (g : ℝ → ℝ) :
    (∫ u in (0 : ℝ)..1, g (A.quantile c r u)) =
      1 / π * ∫ θ in (0 : ℝ)..π, g (position c r θ) * alpha A.k A.ρ θ := by
  rw [A.integral_cdf]
  congr 1
  apply intervalIntegral.integral_congr
  intro θ hθ
  rw [uIcc_of_le Real.pi_pos.le] at hθ
  change g (A.quantile c r (A.cdf θ)) * _ = g (position c r θ) * _
  rw [A.quantile_cdf c r hθ]

end AngleReference
end EP1038.Stage11
