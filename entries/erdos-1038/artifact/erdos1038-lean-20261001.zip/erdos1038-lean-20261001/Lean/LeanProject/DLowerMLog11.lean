import LeanProject.DLowerMTools
import LeanProject.DLowerMLog08
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_440 : RB (Real.log ((915921361878951 : ℝ) / 2000000000000000)) ((-780971948030357107 : ℝ) / 1000000000000000000) ((-156194389606071421 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((915921361878951 : ℝ) / 1000000000000000)) (t := ((-84078638121049 : ℝ) / 1915921361878951))
    (lo := ((-87824767470411797 : ℝ) / 1000000000000000000)) (hi := ((-21956191867602949 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((915921361878951 : ℝ) / 2000000000000000) = Real.log ((915921361878951 : ℝ) / 1000000000000000) - 1 * Real.log 2 := by
    rw [show ((915921361878951 : ℝ) / 2000000000000000) = ((915921361878951 : ℝ) / 1000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_441 : RB (Real.log ((457960680939478501 : ℝ) / 1000000000000000000)) ((-390485974015175277 : ℝ) / 500000000000000000) ((-97621493503793819 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((457960680939478501 : ℝ) / 500000000000000000)) (t := ((-42039319060521499 : ℝ) / 957960680939478501))
    (lo := ((-21956191867601311 : ℝ) / 250000000000000000)) (hi := ((-87824767470405243 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457960680939478501 : ℝ) / 1000000000000000000) = Real.log ((457960680939478501 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((457960680939478501 : ℝ) / 1000000000000000000) = ((457960680939478501 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_442 : RB (Real.log ((541358435271459 : ℝ) / 1000000000000000)) ((-613673677428350083 : ℝ) / 1000000000000000000) ((-613673677428350081 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((541358435271459 : ℝ) / 500000000000000)) (t := ((41358435271459 : ℝ) / 1041358435271459))
    (lo := ((79473503131595227 : ℝ) / 1000000000000000000)) (hi := ((19868375782898807 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((541358435271459 : ℝ) / 1000000000000000) = Real.log ((541358435271459 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((541358435271459 : ℝ) / 1000000000000000) = ((541358435271459 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_443 : RB (Real.log ((270679217635731 : ℝ) / 500000000000000)) ((-306836838714172271 : ℝ) / 500000000000000000) ((-30683683871417227 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((270679217635731 : ℝ) / 250000000000000)) (t := ((20679217635731 : ℝ) / 520679217635731))
    (lo := ((620886743215631 : ℝ) / 7812500000000000)) (hi := ((79473503131600769 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270679217635731 : ℝ) / 500000000000000) = Real.log ((270679217635731 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((270679217635731 : ℝ) / 500000000000000) = ((270679217635731 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_444 : RB (Real.log ((229320782364269 : ℝ) / 500000000000000)) ((-779486278717373367 : ℝ) / 1000000000000000000) ((-155897255743474673 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((229320782364269 : ℝ) / 250000000000000)) (t := ((-20679217635731 : ℝ) / 479320782364269))
    (lo := ((-86339098157428057 : ℝ) / 1000000000000000000)) (hi := ((-10792387269678507 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229320782364269 : ℝ) / 500000000000000) = Real.log ((229320782364269 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((229320782364269 : ℝ) / 500000000000000) = ((229320782364269 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_445 : RB (Real.log ((458641564728541 : ℝ) / 1000000000000000)) ((-389743139358683413 : ℝ) / 500000000000000000) ((-97435784839670853 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((458641564728541 : ℝ) / 500000000000000)) (t := ((-41358435271459 : ℝ) / 958641564728541))
    (lo := ((-21584774539355379 : ℝ) / 250000000000000000)) (hi := ((-17267819631484303 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458641564728541 : ℝ) / 1000000000000000) = Real.log ((458641564728541 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((458641564728541 : ℝ) / 1000000000000000) = ((458641564728541 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_446 : RB (Real.log ((457960680939475501 : ℝ) / 1000000000000000000)) ((-156194389606071421 : ℝ) / 200000000000000000) ((-780971948030357103 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((457960680939475501 : ℝ) / 500000000000000000)) (t := ((-42039319060524499 : ℝ) / 957960680939475501))
    (lo := ((-17564953494082359 : ℝ) / 200000000000000000)) (hi := ((-43912383735205897 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457960680939475501 : ℝ) / 1000000000000000000) = Real.log ((457960680939475501 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((457960680939475501 : ℝ) / 1000000000000000000) = ((457960680939475501 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_447 : RB (Real.log ((915921361878957 : ℝ) / 2000000000000000)) ((-195242987007587639 : ℝ) / 250000000000000000) ((-390485974015175277 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((915921361878957 : ℝ) / 1000000000000000)) (t := ((-84078638121043 : ℝ) / 1915921361878957))
    (lo := ((-43912383735202623 : ℝ) / 500000000000000000)) (hi := ((-17564953494081049 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((915921361878957 : ℝ) / 2000000000000000) = Real.log ((915921361878957 : ℝ) / 1000000000000000) - 1 * Real.log 2 := by
    rw [show ((915921361878957 : ℝ) / 2000000000000000) = ((915921361878957 : ℝ) / 1000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_448 : RB (Real.log ((2849353899818327 : ℝ) / 2000000000000000)) ((70789017240348291 : ℝ) / 200000000000000000) ((353945086201741457 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((2849353899818327 : ℝ) / 4000000000000000)) (t := ((-1150646100181673 : ℝ) / 6849353899818327))
    (lo := ((-169601047179101927 : ℝ) / 500000000000000000)) (hi := ((-339202094358203853 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2849353899818327 : ℝ) / 2000000000000000) = Real.log ((2849353899818327 : ℝ) / 4000000000000000) + 1 * Real.log 2 := by
    rw [show ((2849353899818327 : ℝ) / 2000000000000000) = ((2849353899818327 : ℝ) / 4000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_449 : RB (Real.log ((1424676949909166501 : ℝ) / 1000000000000000000)) ((176972543100871781 : ℝ) / 500000000000000000) ((88486271550435891 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424676949909166501 : ℝ) / 2000000000000000000)) (t := ((-575323050090833499 : ℝ) / 3424676949909166501))
    (lo := ((-339202094358201747 : ℝ) / 1000000000000000000)) (hi := ((-169601047179100873 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424676949909166501 : ℝ) / 1000000000000000000) = Real.log ((1424676949909166501 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424676949909166501 : ℝ) / 1000000000000000000) = ((1424676949909166501 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_450 : RB (Real.log ((212678916849113 : ℝ) / 500000000000000)) ((-427412251332854871 : ℝ) / 500000000000000000) ((-42741225133285487 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((212678916849113 : ℝ) / 250000000000000)) (t := ((-37321083150887 : ℝ) / 462678916849113))
    (lo := ((-10104832631610277 : ℝ) / 62500000000000000)) (hi := ((-161677322105764431 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212678916849113 : ℝ) / 500000000000000) = Real.log ((212678916849113 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212678916849113 : ℝ) / 500000000000000) = ((212678916849113 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_451 : RB (Real.log ((425357833698229 : ℝ) / 1000000000000000)) ((-854824502665702689 : ℝ) / 1000000000000000000) ((-854824502665702687 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((425357833698229 : ℝ) / 500000000000000)) (t := ((-74642166301771 : ℝ) / 925357833698229))
    (lo := ((-161677322105757379 : ℝ) / 1000000000000000000)) (hi := ((-80838661052878689 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425357833698229 : ℝ) / 1000000000000000) = Real.log ((425357833698229 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425357833698229 : ℝ) / 1000000000000000) = ((425357833698229 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_452 : RB (Real.log ((712678916849113 : ℝ) / 500000000000000)) ((70884578712921547 : ℝ) / 200000000000000000) ((354422893564607737 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712678916849113 : ℝ) / 1000000000000000)) (t := ((-287321083150887 : ℝ) / 1712678916849113))
    (lo := ((-169362143497668787 : ℝ) / 500000000000000000)) (hi := ((-338724286995337573 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712678916849113 : ℝ) / 500000000000000) = Real.log ((712678916849113 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712678916849113 : ℝ) / 500000000000000) = ((712678916849113 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_453 : RB (Real.log ((1425357833698229 : ℝ) / 1000000000000000)) ((354422893564609839 : ℝ) / 1000000000000000000) ((354422893564609841 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425357833698229 : ℝ) / 2000000000000000)) (t := ((-574642166301771 : ℝ) / 3425357833698229))
    (lo := ((-33872428699533547 : ℝ) / 100000000000000000)) (hi := ((-338724286995335469 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425357833698229 : ℝ) / 1000000000000000) = Real.log ((1425357833698229 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425357833698229 : ℝ) / 1000000000000000) = ((1425357833698229 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_454 : RB (Real.log ((1424676949909163501 : ℝ) / 1000000000000000000)) ((22121567887608841 : ℝ) / 62500000000000000) ((176972543100870729 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424676949909163501 : ℝ) / 2000000000000000000)) (t := ((-575323050090836499 : ℝ) / 3424676949909163501))
    (lo := ((-339202094358203853 : ℝ) / 1000000000000000000)) (hi := ((-84800523589550963 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424676949909163501 : ℝ) / 1000000000000000000) = Real.log ((1424676949909163501 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424676949909163501 : ℝ) / 1000000000000000000) = ((1424676949909163501 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_455 : RB (Real.log ((2849353899818333 : ℝ) / 2000000000000000)) ((353945086201743561 : ℝ) / 1000000000000000000) ((353945086201743563 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((2849353899818333 : ℝ) / 4000000000000000)) (t := ((-1150646100181667 : ℝ) / 6849353899818333))
    (lo := ((-84800523589550437 : ℝ) / 250000000000000000)) (hi := ((-339202094358201747 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2849353899818333 : ℝ) / 2000000000000000) = Real.log ((2849353899818333 : ℝ) / 4000000000000000) + 1 * Real.log 2 := by
    rw [show ((2849353899818333 : ℝ) / 2000000000000000) = ((2849353899818333 : ℝ) / 4000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_456 : RB (Real.log ((228798651209220841 : ℝ) / 500000000000000000)) ((-390882866999259549 : ℝ) / 500000000000000000) ((-97720716749814887 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((228798651209220841 : ℝ) / 250000000000000000)) (t := ((-21201348790779159 : ℝ) / 478798651209220841))
    (lo := ((-22154638359643447 : ℝ) / 250000000000000000)) (hi := ((-88618553438573787 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((228798651209220841 : ℝ) / 500000000000000000) = Real.log ((228798651209220841 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((228798651209220841 : ℝ) / 500000000000000000) = ((228798651209220841 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_457 : RB (Real.log ((229162005316193387 : ℝ) / 500000000000000000)) ((-48761181137179591 : ℝ) / 62500000000000000) ((-390089449097436727 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((229162005316193387 : ℝ) / 250000000000000000)) (t := ((-20837994683806613 : ℝ) / 479162005316193387))
    (lo := ((-43515858817464073 : ℝ) / 500000000000000000)) (hi := ((-17406343526985629 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229162005316193387 : ℝ) / 500000000000000000) = Real.log ((229162005316193387 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229162005316193387 : ℝ) / 500000000000000000) = ((229162005316193387 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_458 : RB (Real.log ((541003235461363227 : ℝ) / 1000000000000000000)) ((-153582504908364717 : ℝ) / 250000000000000000) ((-307165009816729433 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((541003235461363227 : ℝ) / 500000000000000000)) (t := ((41003235461363227 : ℝ) / 1041003235461363227))
    (lo := ((39408580463243221 : ℝ) / 500000000000000000)) (hi := ((78817160926486443 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((541003235461363227 : ℝ) / 1000000000000000000) = Real.log ((541003235461363227 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((541003235461363227 : ℝ) / 1000000000000000000) = ((541003235461363227 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_459 : RB (Real.log ((270856817540779159 : ℝ) / 500000000000000000)) ((-613017765725783413 : ℝ) / 1000000000000000000) ((-613017765725783411 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((270856817540779159 : ℝ) / 250000000000000000)) (t := ((20856817540779159 : ℝ) / 520856817540779159))
    (lo := ((80129414834161897 : ℝ) / 1000000000000000000)) (hi := ((40064707417080949 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270856817540779159 : ℝ) / 500000000000000000) = Real.log ((270856817540779159 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((270856817540779159 : ℝ) / 500000000000000000) = ((270856817540779159 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_460 : RB (Real.log ((229143182459220841 : ℝ) / 500000000000000000)) ((-780261039342236393 : ℝ) / 1000000000000000000) ((-780261039342236391 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229143182459220841 : ℝ) / 250000000000000000)) (t := ((-20856817540779159 : ℝ) / 479143182459220841))
    (lo := ((-87113858782291083 : ℝ) / 1000000000000000000)) (hi := ((-43556929391145541 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229143182459220841 : ℝ) / 500000000000000000) = Real.log ((229143182459220841 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229143182459220841 : ℝ) / 500000000000000000) = ((229143182459220841 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_461 : RB (Real.log ((458996764538636773 : ℝ) / 1000000000000000000)) ((-194678029470466907 : ℝ) / 250000000000000000) ((-389356058940933813 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((458996764538636773 : ℝ) / 500000000000000000)) (t := ((-41003235461363227 : ℝ) / 958996764538636773))
    (lo := ((-42782468660961159 : ℝ) / 500000000000000000)) (hi := ((-85564937321922317 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458996764538636773 : ℝ) / 1000000000000000000) = Real.log ((458996764538636773 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458996764538636773 : ℝ) / 1000000000000000000) = ((458996764538636773 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_462 : RB (Real.log ((228802740564689591 : ℝ) / 500000000000000000)) ((-781747860995760053 : ℝ) / 1000000000000000000) ((-781747860995760051 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((228802740564689591 : ℝ) / 250000000000000000)) (t := ((-21197259435310409 : ℝ) / 478802740564689591))
    (lo := ((-88600680435814743 : ℝ) / 1000000000000000000)) (hi := ((-44300340217907371 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((228802740564689591 : ℝ) / 500000000000000000) = Real.log ((228802740564689591 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((228802740564689591 : ℝ) / 500000000000000000) = ((228802740564689591 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_463 : RB (Real.log ((457605481129379183 : ℝ) / 1000000000000000000)) ((-781747860995760051 : ℝ) / 1000000000000000000) ((-781747860995760049 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((457605481129379183 : ℝ) / 500000000000000000)) (t := ((-42394518870620817 : ℝ) / 957605481129379183))
    (lo := ((-88600680435814741 : ℝ) / 1000000000000000000)) (hi := ((-4430034021790737 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457605481129379183 : ℝ) / 1000000000000000000) = Real.log ((457605481129379183 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((457605481129379183 : ℝ) / 1000000000000000000) = ((457605481129379183 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_464 : RB (Real.log ((457613611012191683 : ℝ) / 1000000000000000000)) ((-781730095014078681 : ℝ) / 1000000000000000000) ((-781730095014078679 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((457613611012191683 : ℝ) / 500000000000000000)) (t := ((-42386388987808317 : ℝ) / 957613611012191683))
    (lo := ((-88582914454133371 : ℝ) / 1000000000000000000)) (hi := ((-8858291445413337 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457613611012191683 : ℝ) / 1000000000000000000) = Real.log ((457613611012191683 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((457613611012191683 : ℝ) / 1000000000000000000) = ((457613611012191683 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_465 : RB (Real.log ((458315880749574273 : ℝ) / 1000000000000000000)) ((-195049159159784907 : ℝ) / 250000000000000000) ((-390098318319569813 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((458315880749574273 : ℝ) / 500000000000000000)) (t := ((-41684119250425727 : ℝ) / 958315880749574273))
    (lo := ((-43524728039597159 : ℝ) / 500000000000000000)) (hi := ((-87049456079194317 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458315880749574273 : ℝ) / 1000000000000000000) = Real.log ((458315880749574273 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458315880749574273 : ℝ) / 1000000000000000000) = ((458315880749574273 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_466 : RB (Real.log ((229157940374787137 : ℝ) / 500000000000000000)) ((-390098318319569813 : ℝ) / 500000000000000000) ((-97524579579892453 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((229157940374787137 : ℝ) / 250000000000000000)) (t := ((-20842059625212863 : ℝ) / 479157940374787137))
    (lo := ((-21762364019798579 : ℝ) / 250000000000000000)) (hi := ((-17409891215838863 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229157940374787137 : ℝ) / 500000000000000000) = Real.log ((229157940374787137 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229157940374787137 : ℝ) / 500000000000000000) = ((229157940374787137 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_467 : RB (Real.log ((458307702038636773 : ℝ) / 1000000000000000000)) ((-390107240969053519 : ℝ) / 500000000000000000) ((-195053620484526759 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((458307702038636773 : ℝ) / 500000000000000000)) (t := ((-41692297961363227 : ℝ) / 958307702038636773))
    (lo := ((-1360426584033777 : ℝ) / 15625000000000000)) (hi := ((-87067301378161727 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458307702038636773 : ℝ) / 1000000000000000000) = Real.log ((458307702038636773 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458307702038636773 : ℝ) / 1000000000000000000) = ((458307702038636773 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_468 : RB (Real.log ((1424637556681120273 : ℝ) / 1000000000000000000)) ((5529959924694511 : ℝ) / 15625000000000000) ((176958717590224353 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424637556681120273 : ℝ) / 2000000000000000000)) (t := ((-575362443318879727 : ℝ) / 3424637556681120273))
    (lo := ((-67845949075899321 : ℝ) / 200000000000000000)) (hi := ((-84807436344874151 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424637556681120273 : ℝ) / 1000000000000000000) = Real.log ((1424637556681120273 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424637556681120273 : ℝ) / 1000000000000000000) = ((1424637556681120273 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_469 : RB (Real.log ((1424716294309085431 : ℝ) / 1000000000000000000)) ((353972702186305373 : ℝ) / 1000000000000000000) ((2831781617490443 : ℝ) / 8000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424716294309085431 : ℝ) / 2000000000000000000)) (t := ((-575283705690914569 : ℝ) / 3424716294309085431))
    (lo := ((-1324900306147031 : ℝ) / 3906250000000000)) (hi := ((-67834895674727987 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424716294309085431 : ℝ) / 1000000000000000000) = Real.log ((1424716294309085431 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424716294309085431 : ℝ) / 1000000000000000000) = ((1424716294309085431 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_470 : RB (Real.log ((425326619181120273 : ℝ) / 1000000000000000000)) ((-85489788949443121 : ℝ) / 100000000000000000) ((-106862236186803901 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((425326619181120273 : ℝ) / 500000000000000000)) (t := ((-74673380818879727 : ℝ) / 925326619181120273))
    (lo := ((-1617507089344859 : ℝ) / 10000000000000000)) (hi := ((-161750708934485899 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425326619181120273 : ℝ) / 1000000000000000000) = Real.log ((425326619181120273 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425326619181120273 : ℝ) / 1000000000000000000) = ((425326619181120273 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_471 : RB (Real.log ((42538904821533543 : ℝ) / 100000000000000000)) ((-213687780305552749 : ℝ) / 250000000000000000) ((-427375560611105497 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((42538904821533543 : ℝ) / 50000000000000000)) (t := ((-7461095178466457 : ℝ) / 92538904821533543))
    (lo := ((-80801970331132843 : ℝ) / 500000000000000000)) (hi := ((-32320788132453137 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42538904821533543 : ℝ) / 100000000000000000) = Real.log ((42538904821533543 : ℝ) / 50000000000000000) - 1 * Real.log 2 := by
    rw [show ((42538904821533543 : ℝ) / 100000000000000000) = ((42538904821533543 : ℝ) / 50000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_472 : RB (Real.log ((1425326619181120273 : ℝ) / 1000000000000000000)) ((177200496949860839 : ℝ) / 500000000000000000) ((4430012423746521 : ℝ) / 12500000000000000) := by
  have hm := log_bounds_of_series (x := ((1425326619181120273 : ℝ) / 2000000000000000000)) (t := ((-574673380818879727 : ℝ) / 3425326619181120273))
    (lo := ((-338746186660223631 : ℝ) / 1000000000000000000)) (hi := ((-33874618666022363 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425326619181120273 : ℝ) / 1000000000000000000) = Real.log ((1425326619181120273 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425326619181120273 : ℝ) / 1000000000000000000) = ((1425326619181120273 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_473 : RB (Real.log ((142538904821533543 : ℝ) / 100000000000000000)) ((35444479274991157 : ℝ) / 100000000000000000) ((88611198187477893 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((142538904821533543 : ℝ) / 200000000000000000)) (t := ((-57461095178466457 : ℝ) / 342538904821533543))
    (lo := ((-338702387810033739 : ℝ) / 1000000000000000000)) (hi := ((-169351193905016869 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142538904821533543 : ℝ) / 100000000000000000) = Real.log ((142538904821533543 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142538904821533543 : ℝ) / 100000000000000000) = ((142538904821533543 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_474 : RB (Real.log ((1424645735392057773 : ℝ) / 1000000000000000000)) ((44240397008802421 : ℝ) / 125000000000000000) ((35392317607041937 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424645735392057773 : ℝ) / 2000000000000000000)) (t := ((-575354264607942227 : ℝ) / 3424645735392057773))
    (lo := ((-339224004489525941 : ℝ) / 1000000000000000000)) (hi := ((-16961200224476297 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424645735392057773 : ℝ) / 1000000000000000000) = Real.log ((1424645735392057773 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424645735392057773 : ℝ) / 1000000000000000000) = ((1424645735392057773 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_475 : RB (Real.log ((712322867696028887 : ℝ) / 500000000000000000)) ((353923176070419369 : ℝ) / 1000000000000000000) ((353923176070419371 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712322867696028887 : ℝ) / 1000000000000000000)) (t := ((-287677132303971113 : ℝ) / 1712322867696028887))
    (lo := ((-16961200224476297 : ℝ) / 50000000000000000)) (hi := ((-339224004489525939 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712322867696028887 : ℝ) / 500000000000000000) = Real.log ((712322867696028887 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712322867696028887 : ℝ) / 500000000000000000) = ((712322867696028887 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_476 : RB (Real.log ((712326932637435137 : ℝ) / 500000000000000000)) ((176964441326878493 : ℝ) / 500000000000000000) ((88482220663439247 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((712326932637435137 : ℝ) / 1000000000000000000)) (t := ((-287673067362564863 : ℝ) / 1712326932637435137))
    (lo := ((-339218297906188323 : ℝ) / 1000000000000000000)) (hi := ((-169609148953094161 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712326932637435137 : ℝ) / 500000000000000000) = Real.log ((712326932637435137 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712326932637435137 : ℝ) / 500000000000000000) = ((712326932637435137 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_477 : RB (Real.log ((142470816442627293 : ℝ) / 100000000000000000)) ((70793399170604561 : ℝ) / 200000000000000000) ((353966995853022807 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((142470816442627293 : ℝ) / 200000000000000000)) (t := ((-57529183557372707 : ℝ) / 342470816442627293))
    (lo := ((-42397523088365313 : ℝ) / 125000000000000000)) (hi := ((-339180184706922503 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142470816442627293 : ℝ) / 100000000000000000) = Real.log ((142470816442627293 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142470816442627293 : ℝ) / 100000000000000000) = ((142470816442627293 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_478 : RB (Real.log ((1424708164426272931 : ℝ) / 1000000000000000000)) ((70793399170604561 : ℝ) / 200000000000000000) ((353966995853022807 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424708164426272931 : ℝ) / 2000000000000000000)) (t := ((-575291835573727069 : ℝ) / 3424708164426272931))
    (lo := ((-42397523088365313 : ℝ) / 125000000000000000)) (hi := ((-339180184706922503 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424708164426272931 : ℝ) / 1000000000000000000) = Real.log ((1424708164426272931 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424708164426272931 : ℝ) / 1000000000000000000) = ((1424708164426272931 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_479 : RB (Real.log ((142469998571533543 : ℝ) / 100000000000000000)) ((353961255214611901 : ℝ) / 1000000000000000000) ((353961255214611903 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((142469998571533543 : ℝ) / 200000000000000000)) (t := ((-57530001428466457 : ℝ) / 342469998571533543))
    (lo := ((-10599560167041669 : ℝ) / 31250000000000000)) (hi := ((-339185925345333407 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142469998571533543 : ℝ) / 100000000000000000) = Real.log ((142469998571533543 : ℝ) / 200000000000000000) + 1 * Real.log 2 := by
    rw [show ((142469998571533543 : ℝ) / 100000000000000000) = ((142469998571533543 : ℝ) / 200000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
