import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_0 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((36 : ℝ) / 61) ((3693 : ℝ) / 6253))
    (hq : RB (qa a) ((684269 : ℝ) / 100000000) ((692551 : ℝ) / 100000000))
    (hd : RB (D0a a) ((197258311 : ℝ) / 100000000) ((39458153 : ℝ) / 20000000))
    : certE k a ((5570111 : ℝ) / 12500000) < 0 ∧ 0 < certE k a ((11184749 : ℝ) / 25000000) ∧ 0 < certE k a ((7923591 : ℝ) / 6250000) ∧ certE k a ((31719207 : ℝ) / 25000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((2341 : ℝ) / 50000000) ((4797 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((5570111 : ℝ) / 12500000)) - (z1)
  have h2 : RB z2 ((44556091 : ℝ) / 100000000) ((22278103 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((5570111 : ℝ) / 12500000) ((5570111 : ℝ) / 12500000) ((5570111 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((6929889 : ℝ) / 12500000))
  have h3 : RB z3 ((10046177 : ℝ) / 12500000) ((642957 : ℝ) / 800000) := rb_div_signed h2 (show RB ((6929889 : ℝ) / 12500000) ((6929889 : ℝ) / 12500000) ((6929889 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-21853649 : ℝ) / 100000000) ((-21853387 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_0.1 cov_log_1.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-12906689 : ℝ) / 100000000) ((-322427 : ℝ) / 2500000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((5570111 : ℝ) / 12500000))
  have h6 : RB z6 ((-10103921 : ℝ) / 12500000) ((-40415683 : ℝ) / 50000000) := rb_log (show RB ((5570111 : ℝ) / 12500000) ((5570111 : ℝ) / 12500000) ((5570111 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2.1 cov_log_2.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((67924677 : ℝ) / 100000000) ((4245893 : ℝ) / 6250000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((6793439 : ℝ) / 10000000) ((67950843 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-13083 : ℝ) / 50000000) ((-51 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((2341 : ℝ) / 50000000) ((4797 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((11184749 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((44734199 : ℝ) / 100000000) ((22367157 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((11184749 : ℝ) / 25000000) ((11184749 : ℝ) / 25000000) ((11184749 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((13815251 : ℝ) / 25000000))
  have h12 : RB z12 ((80950753 : ℝ) / 100000000) ((40475481 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((13815251 : ℝ) / 25000000) ((13815251 : ℝ) / 25000000) ((13815251 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-21132921 : ℝ) / 100000000) ((-10566331 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_5.1 cov_log_6.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-1248103 : ℝ) / 10000000) ((-6235867 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((11184749 : ℝ) / 25000000))
  have h15 : RB z15 ((-80432469 : ℝ) / 100000000) ((-80432467 : ℝ) / 100000000) := rb_log (show RB ((11184749 : ℝ) / 25000000) ((11184749 : ℝ) / 25000000) ((11184749 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_7.1 cov_log_7.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67951437 : ℝ) / 100000000) ((13592147 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((6793439 : ℝ) / 10000000) ((67950843 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((297 : ℝ) / 50000000) ((5269 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((2341 : ℝ) / 50000000) ((4797 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((7923591 : ℝ) / 6250000)) - (z19)
  have h20 : RB z20 ((126772659 : ℝ) / 100000000) ((63386387 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((7923591 : ℝ) / 6250000) ((7923591 : ℝ) / 6250000) ((7923591 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1673591 : ℝ) / 6250000))
  have h21 : RB z21 ((118357639 : ℝ) / 25000000) ((473430987 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((1673591 : ℝ) / 6250000) ((1673591 : ℝ) / 6250000) ((1673591 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((31096701 : ℝ) / 20000000) ((155483599 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_8.1 cov_log_9.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((91760757 : ℝ) / 100000000) ((11478509 : ℝ) / 12500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((7923591 : ℝ) / 6250000))
  have h24 : RB z24 ((741447 : ℝ) / 3125000) ((4745261 : ℝ) / 20000000) := rb_log (show RB ((7923591 : ℝ) / 6250000) ((7923591 : ℝ) / 6250000) ((7923591 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_10.1 cov_log_10.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((17008613 : ℝ) / 25000000) ((8512721 : ℝ) / 12500000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((6793439 : ℝ) / 10000000) ((67950843 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((83609 : ℝ) / 100000000) ((83689 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((2341 : ℝ) / 50000000) ((4797 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((31719207 : ℝ) / 25000000)) - (z28)
  have h29 : RB z29 ((126872031 : ℝ) / 100000000) ((63436073 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((31719207 : ℝ) / 25000000) ((31719207 : ℝ) / 25000000) ((31719207 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((6719207 : ℝ) / 25000000))
  have h30 : RB z30 ((472049867 : ℝ) / 100000000) ((59006287 : ℝ) / 12500000) := rb_div_signed h29 (show RB ((6719207 : ℝ) / 25000000) ((6719207 : ℝ) / 25000000) ((6719207 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((38797861 : ℝ) / 25000000) ((77595769 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_11.1 cov_log_12.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91588393 : ℝ) / 100000000) ((45827791 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((31719207 : ℝ) / 25000000))
  have h33 : RB z33 ((23804657 : ℝ) / 100000000) ((11902329 : ℝ) / 50000000) := rb_log (show RB ((31719207 : ℝ) / 25000000) ((31719207 : ℝ) / 25000000) ((31719207 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_13.1 cov_log_13.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((13556747 : ℝ) / 20000000) ((2714037 : ℝ) / 4000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((6793439 : ℝ) / 10000000) ((67950843 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-41777 : ℝ) / 25000000) ((-16693 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((5570111 : ℝ) / 12500000)) ((-13083 : ℝ) / 50000000) ((-51 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((11184749 : ℝ) / 25000000)) ((297 : ℝ) / 50000000) ((5269 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((7923591 : ℝ) / 6250000)) ((83609 : ℝ) / 100000000) ((83689 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((31719207 : ℝ) / 25000000)) ((-41777 : ℝ) / 25000000) ((-16693 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_0 {k A q d vp vm : ℝ}
    (hk : RB k ((36 : ℝ) / 25) ((3693 : ℝ) / 2560))
    (hA : RB A ((36 : ℝ) / 61) ((3693 : ℝ) / 6253))
    (hq : RB q ((684269 : ℝ) / 100000000) ((692551 : ℝ) / 100000000))
    (hd : RB d ((197258311 : ℝ) / 100000000) ((39458153 : ℝ) / 20000000))
    (hp : RB vp ((5570111 : ℝ) / 12500000) ((11184749 : ℝ) / 25000000))
    (hm : RB vm ((7923591 : ℝ) / 6250000) ((31719207 : ℝ) / 25000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((2341 : ℝ) / 50000000) ((4797 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99995203 : ℝ) / 100000000) ((49997659 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((29506781 : ℝ) / 50000000) ((59056887 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((2093 : ℝ) / 20000000) ((5383 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49994617 : ℝ) / 50000000) ((19997907 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((13815251 : ℝ) / 25000000) ((6929889 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27627527 : ℝ) / 50000000) ((55433311 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106458663 : ℝ) / 100000000) ((106880517 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6458663 : ℝ) / 100000000) ((6880517 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99995203 : ℝ) / 100000000) ((49997659 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((29506781 : ℝ) / 50000000) ((59056887 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((369 : ℝ) / 10000000) ((473 : ℝ) / 12500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((12499527 : ℝ) / 12500000) ((9999631 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1673591 : ℝ) / 6250000) ((6719207 : ℝ) / 25000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((13388221 : ℝ) / 50000000) ((26875837 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((54894627 : ℝ) / 25000000) ((110277697 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((79894627 : ℝ) / 25000000) ((160277697 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1453379157 : ℝ) / 100000000) ((48384627 : ℝ) / 3125000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((1949741 : ℝ) / 6250000) ((1955701 : ℝ) / 6250000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((72 : ℝ) / 25) ((3693 : ℝ) / 1280) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((985347 : ℝ) / 50000000) ((999059 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((100684269 : ℝ) / 100000000) ((100692551 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1957139 : ℝ) / 100000000) ((1984539 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((101957139 : ℝ) / 100000000) ((101984539 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((4101923 : ℝ) / 5000000) ((4115797 : ℝ) / 5000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((1011423 : ℝ) / 625000) ((40600437 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((1412329 : ℝ) / 2500000) ((2838171 : ℝ) / 5000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1031 : ℝ) / 12500000) ((2123 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24997877 : ℝ) / 25000000) ((12498969 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((161813937 : ℝ) / 100000000) ((81194177 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((197258311 : ℝ) / 50000000) ((39458153 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1349777 : ℝ) / 50000000) ((2732679 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((61 : ℝ) / 25) ((244257813 : ℝ) / 100000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((552603 : ℝ) / 50000000) ((1119951 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((382367 : ℝ) / 25000000) ((194271 : ℝ) / 12500000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((25382367 : ℝ) / 25000000) ((12694271 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((737804063 : ℝ) / 50000000) ((1572371373 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((539317 : ℝ) / 100000000) ((546273 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100539317 : ℝ) / 100000000) ((100546273 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((313641 : ℝ) / 1000000) ((3932769 : ℝ) / 12500000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((753486113 : ℝ) / 50000000) ((64153341 : ℝ) / 4000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((16655147 : ℝ) / 100000000) ((359243 : ℝ) / 2000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((61 : ℝ) / 25) ((244257813 : ℝ) / 100000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((101957139 : ℝ) / 50000000) ((101984539 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1484575013 : ℝ) / 100000000) ((19744991 : ℝ) / 1250000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((3027260419 : ℝ) / 100000000) ((402736761 : ℝ) / 12500000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1514637 : ℝ) / 20000000) ((806861 : ℝ) / 10000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-258055651 : ℝ) / 100000000) ((-50343779 : ℝ) / 20000000) := rb_log h47 (by norm_num) cov_log_14.1 cov_log_15.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1349777 : ℝ) / 100000000) ((68317 : ℝ) / 5000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-86104617 : ℝ) / 20000000) ((-85860691 : ℝ) / 20000000) := rb_log h49 (by norm_num) cov_log_16.1 cov_log_17.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((6793439 : ℝ) / 10000000) ((67950843 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((97825521 : ℝ) / 100000000) ((245061 : ℝ) / 250000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-83174391 : ℝ) / 25000000) ((-66255811 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((21054693 : ℝ) / 100000000) ((21629111 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((117216997 : ℝ) / 100000000) ((64932213 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-215480567 : ℝ) / 100000000) ((-201414629 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((101957139 : ℝ) / 100000000) ((101984539 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-258055651 : ℝ) / 100000000) ((-50343779 : ℝ) / 20000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-215480567 : ℝ) / 100000000) ((-201414629 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((309 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((382367 : ℝ) / 25000000) ((194271 : ℝ) / 12500000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((12694271 : ℝ) / 25000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((309 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-46037329 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((309 : ℝ) / 100) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_0, cov_h_1]
  have hP : ((310215677 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((201414629 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((201414629 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2689 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2689 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2729 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2729 : ℝ) / 1000)) (lo := ((2689 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2769 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2769 : ℝ) / 1000)) (lo := ((2729 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2809 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2809 : ℝ) / 1000)) (lo := ((2769 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2849 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2849 : ℝ) / 1000)) (lo := ((2809 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2889 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2889 : ℝ) / 1000)) (lo := ((2849 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2929 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2929 : ℝ) / 1000)) (lo := ((2889 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2969 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2969 : ℝ) / 1000)) (lo := ((2929 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3009 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3009 : ℝ) / 1000)) (lo := ((2969 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3049 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3049 : ℝ) / 1000)) (lo := ((3009 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3089 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3089 : ℝ) / 1000)) (lo := ((3049 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((309 : ℝ) / 100)) (lo := ((3089 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_0 {k : ℝ} (hk : RB k ((36 : ℝ) / 25) ((3693 : ℝ) / 2560)) :
    RB (k / (k + 1)) ((36 : ℝ) / 61) ((3693 : ℝ) / 6253) ∧
    RB (qa (r1A k)) ((684269 : ℝ) / 100000000) ((692551 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((197258311 : ℝ) / 100000000) ((39458153 : ℝ) / 20000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((9 : ℝ) / 25) ((18032227 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((97267773 : ℝ) / 50000000) ((973 : ℝ) / 500) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((34869 : ℝ) / 25000) ((4359347 : ℝ) / 3125000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((70224339 : ℝ) / 25000000) ((280920461 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((70224339 : ℝ) / 50000000) ((140460231 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((197258311 : ℝ) / 100000000) ((39458153 : ℝ) / 20000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((27 : ℝ) / 500) ((2732227 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((27 : ℝ) / 2000) ((683057 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((684269 : ℝ) / 100000000) ((692551 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((197258311 : ℝ) / 100000000) ((39458153 : ℝ) / 20000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((684269 : ℝ) / 100000000) ((692551 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((36 : ℝ) / 61) ((3693 : ℝ) / 6253) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_0 {k : ℝ} (hk : RB k ((36 : ℝ) / 25) ((3693 : ℝ) / 2560)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_0 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_0 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((5570111 : ℝ) / 12500000)) (ph := ((11184749 : ℝ) / 25000000)) (ml := ((7923591 : ℝ) / 6250000)) (mh := ((31719207 : ℝ) / 25000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_0 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_1 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((3693 : ℝ) / 6253) ((9249 : ℝ) / 15649))
    (hq : RB (qa a) ((13851 : ℝ) / 2000000) ((140167 : ℝ) / 20000000))
    (hd : RB (D0a a) ((197225857 : ℝ) / 100000000) ((39451663 : ℝ) / 20000000))
    : certE k a ((1390277 : ℝ) / 3125000) < 0 ∧ 0 < certE k a ((44717649 : ℝ) / 100000000) ∧ 0 < certE k a ((126810631 : ℝ) / 100000000) ∧ certE k a ((15863731 : ℝ) / 12500000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1199 : ℝ) / 25000000) ((307 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1390277 : ℝ) / 3125000)) - (z1)
  have h2 : RB z2 ((2780247 : ℝ) / 6250000) ((11121017 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1390277 : ℝ) / 3125000) ((1390277 : ℝ) / 3125000) ((1390277 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((1734723 : ℝ) / 3125000))
  have h3 : RB z3 ((16027037 : ℝ) / 20000000) ((16027079 : ℝ) / 20000000) := rb_div_signed h2 (show RB ((1734723 : ℝ) / 3125000) ((1734723 : ℝ) / 3125000) ((1734723 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22145517 : ℝ) / 100000000) ((-11072627 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_18.1 cov_log_19.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-104709 : ℝ) / 800000) ((-13078909 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((1390277 : ℝ) / 3125000))
  have h6 : RB z6 ((-80993129 : ℝ) / 100000000) ((-80993127 : ℝ) / 100000000) := rb_log (show RB ((1390277 : ℝ) / 3125000) ((1390277 : ℝ) / 3125000) ((1390277 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_20.1 cov_log_20.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33952251 : ℝ) / 50000000) ((3395711 : ℝ) / 5000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((4244871 : ℝ) / 6250000) ((33967197 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_21.1 cov_log_22.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-7473 : ℝ) / 25000000) ((-929 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1199 : ℝ) / 25000000) ((307 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((44717649 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((44712737 : ℝ) / 100000000) ((44712853 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((44717649 : ℝ) / 100000000) ((44717649 : ℝ) / 100000000) ((44717649 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((55282351 : ℝ) / 100000000))
  have h12 : RB z12 ((2527521 : ℝ) / 3125000) ((40440441 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((55282351 : ℝ) / 100000000) ((55282351 : ℝ) / 100000000) ((55282351 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-21219531 : ℝ) / 100000000) ((-2121927 : ℝ) / 10000000) := rb_log h12 (by norm_num) cov_log_23.1 cov_log_24.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-12541341 : ℝ) / 100000000) ((-6266013 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((44717649 : ℝ) / 100000000))
  have h15 : RB z15 ((-40240097 : ℝ) / 50000000) ((-1257503 : ℝ) / 1562500) := rb_log (show RB ((44717649 : ℝ) / 100000000) ((44717649 : ℝ) / 100000000) ((44717649 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_25.1 cov_log_25.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67938851 : ℝ) / 100000000) ((8493521 : ℝ) / 12500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((4244871 : ℝ) / 6250000) ((33967197 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_21.1 cov_log_22.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4457 : ℝ) / 100000000) ((3779 : ℝ) / 12500000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1199 : ℝ) / 25000000) ((307 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((126810631 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((126805719 : ℝ) / 100000000) ((25361167 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((126810631 : ℝ) / 100000000) ((126810631 : ℝ) / 100000000) ((126810631 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((26810631 : ℝ) / 100000000))
  have h21 : RB z21 ((472968051 : ℝ) / 100000000) ((94593697 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((26810631 : ℝ) / 100000000) ((26810631 : ℝ) / 100000000) ((26810631 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((31077153 : ℝ) / 20000000) ((7769293 : ℝ) / 5000000) := rb_log h21 (by norm_num) cov_log_26.1 cov_log_27.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((91770291 : ℝ) / 100000000) ((91837423 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((126810631 : ℝ) / 100000000))
  have h24 : RB z24 ((23752469 : ℝ) / 100000000) ((2375247 : ℝ) / 10000000) := rb_log (show RB ((126810631 : ℝ) / 100000000) ((126810631 : ℝ) / 100000000) ((126810631 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_28.1 cov_log_28.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((68017821 : ℝ) / 100000000) ((34042477 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((4244871 : ℝ) / 6250000) ((33967197 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_21.1 cov_log_22.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((83427 : ℝ) / 100000000) ((83509 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1199 : ℝ) / 25000000) ((307 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((15863731 : ℝ) / 12500000)) - (z28)
  have h29 : RB z29 ((15863117 : ℝ) / 12500000) ((31726263 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((15863731 : ℝ) / 12500000) ((15863731 : ℝ) / 12500000) ((15863731 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3363731 : ℝ) / 12500000))
  have h30 : RB z30 ((29474557 : ℝ) / 6250000) ((3684323 : ℝ) / 781250) := rb_div_signed h29 (show RB ((3363731 : ℝ) / 12500000) ((3363731 : ℝ) / 12500000) ((3363731 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((31018919 : ℝ) / 20000000) ((155094689 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_29.1 cov_log_30.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91598327 : ℝ) / 100000000) ((22916333 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((15863731 : ℝ) / 12500000))
  have h33 : RB z33 ((23830679 : ℝ) / 100000000) ((595767 : ℝ) / 2500000) := rb_log (show RB ((15863731 : ℝ) / 12500000) ((15863731 : ℝ) / 12500000) ((15863731 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_31.1 cov_log_31.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67767647 : ℝ) / 100000000) ((67834653 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((4244871 : ℝ) / 6250000) ((33967197 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_21.1 cov_log_22.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-166747 : ℝ) / 100000000) ((-83283 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((1390277 : ℝ) / 3125000)) ((-7473 : ℝ) / 25000000) ((-929 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((44717649 : ℝ) / 100000000)) ((4457 : ℝ) / 100000000) ((3779 : ℝ) / 12500000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((126810631 : ℝ) / 100000000)) ((83427 : ℝ) / 100000000) ((83509 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((15863731 : ℝ) / 12500000)) ((-166747 : ℝ) / 100000000) ((-83283 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_1 {k A q d vp vm : ℝ}
    (hk : RB k ((3693 : ℝ) / 2560) ((9249 : ℝ) / 6400))
    (hA : RB A ((3693 : ℝ) / 6253) ((9249 : ℝ) / 15649))
    (hq : RB q ((13851 : ℝ) / 2000000) ((140167 : ℝ) / 20000000))
    (hd : RB d ((197225857 : ℝ) / 100000000) ((39451663 : ℝ) / 20000000))
    (hp : RB vp ((1390277 : ℝ) / 3125000) ((44717649 : ℝ) / 100000000))
    (hm : RB vm ((126810631 : ℝ) / 100000000) ((15863731 : ℝ) / 12500000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1199 : ℝ) / 25000000) ((307 : ℝ) / 6250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((6249693 : ℝ) / 6250000) ((24998801 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((236227 : ℝ) / 400000) ((3693749 : ℝ) / 6250000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((429 : ℝ) / 4000000) ((11041 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99988959 : ℝ) / 100000000) ((3999571 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((55282351 : ℝ) / 100000000) ((1734723 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((55276247 : ℝ) / 100000000) ((55505183 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53199311 : ℝ) / 50000000) ((21383501 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3199311 : ℝ) / 50000000) ((1383501 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((6249693 : ℝ) / 6250000) ((24998801 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((236227 : ℝ) / 400000) ((3693749 : ℝ) / 6250000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3779 : ℝ) / 100000000) ((1937 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49998063 : ℝ) / 50000000) ((99996221 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((26810631 : ℝ) / 100000000) ((3363731 : ℝ) / 12500000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((3351199 : ℝ) / 12500000) ((840901 : ℝ) / 3125000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((219469763 : ℝ) / 100000000) ((22044343 : ℝ) / 10000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((319469763 : ℝ) / 100000000) ((32044343 : ℝ) / 10000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1445607917 : ℝ) / 100000000) ((1562836499 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((7801689 : ℝ) / 25000000) ((31301867 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((3693 : ℝ) / 1280) ((9249 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((999057 : ℝ) / 50000000) ((2025633 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((2013851 : ℝ) / 2000000) ((20140167 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1984207 : ℝ) / 100000000) ((2011701 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((101984207 : ℝ) / 100000000) ((102011701 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((41046491 : ℝ) / 50000000) ((10302623 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((161908587 : ℝ) / 100000000) ((32516449 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((56416609 : ℝ) / 100000000) ((56751101 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((169 : ℝ) / 2000000) ((8707 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99991293 : ℝ) / 100000000) ((1999831 : ℝ) / 2000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((161894489 : ℝ) / 100000000) ((162568507 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((197225857 : ℝ) / 50000000) ((39451663 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((109271 : ℝ) / 4000000) ((2764911 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((61064453 : ℝ) / 25000000) ((15649 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((558609 : ℝ) / 50000000) ((226393 : ℝ) / 20000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1548717 : ℝ) / 100000000) ((315061 : ℝ) / 20000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((101548717 : ℝ) / 100000000) ((20315061 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((366999073 : ℝ) / 25000000) ((1587455941 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((272851 : ℝ) / 50000000) ((552663 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50272851 : ℝ) / 50000000) ((100552663 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31377051 : ℝ) / 100000000) ((31474861 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1499373343 : ℝ) / 100000000) ((809465401 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((4187817 : ℝ) / 25000000) ((18325731 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((61064453 : ℝ) / 25000000) ((15649 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((101984207 : ℝ) / 50000000) ((102011701 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1476814673 : ℝ) / 100000000) ((797069183 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1506117733 : ℝ) / 50000000) ((3252415327 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7510043 : ℝ) / 100000000) ((1623483 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-32361613 : ℝ) / 12500000) ((-251115843 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_32.1 cov_log_33.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1365887 : ℝ) / 100000000) ((172807 : ℝ) / 12500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-429336621 : ℝ) / 100000000) ((-85626171 : ℝ) / 20000000) := rb_log h49 (by norm_num) cov_log_34.1 cov_log_35.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((4244871 : ℝ) / 6250000) ((33967197 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_21.1 cov_log_22.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((3061779 : ℝ) / 3125000) ((19635163 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-331359693 : ℝ) / 100000000) ((-2062219 : ℝ) / 625000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1043727 : ℝ) / 5000000) ((21548559 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((113908361 : ℝ) / 100000000) ((16079797 : ℝ) / 12500000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-54362833 : ℝ) / 25000000) ((-25164583 : ℝ) / 12500000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((101984207 : ℝ) / 100000000) ((102011701 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-32361613 : ℝ) / 12500000) ((-251115843 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-54362833 : ℝ) / 25000000) ((-25164583 : ℝ) / 12500000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((309 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1548717 : ℝ) / 100000000) ((315061 : ℝ) / 20000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((20315061 : ℝ) / 40000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((309 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-115511949 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((309 : ℝ) / 100) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_0, cov_h_1]
  have hP : ((154991117 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((25164583 : ℝ) / 12500000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((25164583 : ℝ) / 12500000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1339 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1339 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1359 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1359 : ℝ) / 500)) (lo := ((1339 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1379 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1379 : ℝ) / 500)) (lo := ((1359 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1399 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1399 : ℝ) / 500)) (lo := ((1379 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1419 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1419 : ℝ) / 500)) (lo := ((1399 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1439 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1439 : ℝ) / 500)) (lo := ((1419 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1459 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1459 : ℝ) / 500)) (lo := ((1439 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1479 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1479 : ℝ) / 500)) (lo := ((1459 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1499 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1499 : ℝ) / 500)) (lo := ((1479 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1519 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1519 : ℝ) / 500)) (lo := ((1499 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1539 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1539 : ℝ) / 500)) (lo := ((1519 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((309 : ℝ) / 100)) (lo := ((1539 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_1 {k : ℝ} (hk : RB k ((3693 : ℝ) / 2560) ((9249 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((3693 : ℝ) / 6253) ((9249 : ℝ) / 15649) ∧
    RB (qa (r1A k)) ((13851 : ℝ) / 2000000) ((140167 : ℝ) / 20000000) ∧ RB (D0a (r1A k)) ((197225857 : ℝ) / 100000000) ((39451663 : ℝ) / 20000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((36064453 : ℝ) / 100000000) ((36128907 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((194471093 : ℝ) / 100000000) ((194535547 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((34863223 : ℝ) / 25000000) ((139476001 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((35109281 : ℝ) / 12500000) ((140448679 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((35109281 : ℝ) / 25000000) ((140448679 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((197225857 : ℝ) / 100000000) ((39451663 : ℝ) / 20000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((5464453 : ℝ) / 100000000) ((5528907 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1366113 : ℝ) / 100000000) ((1382227 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((13851 : ℝ) / 2000000) ((140167 : ℝ) / 20000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((197225857 : ℝ) / 100000000) ((39451663 : ℝ) / 20000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((13851 : ℝ) / 2000000) ((140167 : ℝ) / 20000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((3693 : ℝ) / 6253) ((9249 : ℝ) / 15649) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_1 {k : ℝ} (hk : RB k ((3693 : ℝ) / 2560) ((9249 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_1 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_1 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((1390277 : ℝ) / 3125000)) (ph := ((44717649 : ℝ) / 100000000)) (ml := ((126810631 : ℝ) / 100000000)) (mh := ((15863731 : ℝ) / 12500000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_1 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_2 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((9249 : ℝ) / 15649) ((18531 : ℝ) / 31331))
    (hq : RB (qa a) ((350417 : ℝ) / 50000000) ((354561 : ℝ) / 50000000))
    (hd : RB (D0a a) ((197193401 : ℝ) / 100000000) ((24653233 : ℝ) / 12500000))
    : certE k a ((888869 : ℝ) / 2000000) < 0 ∧ 0 < certE k a ((11167607 : ℝ) / 25000000) ∧ 0 < certE k a ((63421877 : ℝ) / 50000000) ∧ certE k a ((63471409 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((4911 : ℝ) / 100000000) ((5029 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((888869 : ℝ) / 2000000)) - (z1)
  have h2 : RB z2 ((44438421 : ℝ) / 100000000) ((44438539 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((888869 : ℝ) / 2000000) ((888869 : ℝ) / 2000000) ((888869 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((1111131 : ℝ) / 2000000))
  have h3 : RB z3 ((39993863 : ℝ) / 50000000) ((79987939 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((1111131 : ℝ) / 2000000) ((1111131 : ℝ) / 2000000) ((1111131 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22329699 : ℝ) / 100000000) ((-2791179 : ℝ) / 12500000) := rb_log h3 (by norm_num) cov_log_36.1 cov_log_37.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-13207101 : ℝ) / 100000000) ((-13197323 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((888869 : ℝ) / 2000000))
  have h6 : RB z6 ((-81095261 : ℝ) / 100000000) ((-81095259 : ℝ) / 100000000) := rb_log (show RB ((888869 : ℝ) / 2000000) ((888869 : ℝ) / 2000000) ((888869 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_38.1 cov_log_38.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((33944079 : ℝ) / 50000000) ((33948969 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67901479 : ℝ) / 100000000) ((33958971 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_39.1 cov_log_40.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-3723 : ℝ) / 12500000) ((-3541 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((4911 : ℝ) / 100000000) ((5029 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((11167607 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((44665399 : ℝ) / 100000000) ((44665517 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((11167607 : ℝ) / 25000000) ((11167607 : ℝ) / 25000000) ((11167607 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((13832393 : ℝ) / 25000000))
  have h12 : RB z12 ((10090761 : ℝ) / 12500000) ((40363151 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((13832393 : ℝ) / 25000000) ((13832393 : ℝ) / 25000000) ((13832393 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-535271 : ℝ) / 2500000) ((-10705287 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_41.1 cov_log_42.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-12663633 : ℝ) / 100000000) ((-3163563 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((11167607 : ℝ) / 25000000))
  have h15 : RB z15 ((-10073231 : ℝ) / 12500000) ((-40292923 : ℝ) / 50000000) := rb_log (show RB ((11167607 : ℝ) / 25000000) ((11167607 : ℝ) / 25000000) ((11167607 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_43.1 cov_log_43.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((67922213 : ℝ) / 100000000) ((16982899 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67901479 : ℝ) / 100000000) ((33958971 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_39.1 cov_log_40.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((4271 : ℝ) / 100000000) ((30117 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((4911 : ℝ) / 100000000) ((5029 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((63421877 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((5073549 : ℝ) / 4000000) ((126838843 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((63421877 : ℝ) / 50000000) ((63421877 : ℝ) / 50000000) ((63421877 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((13421877 : ℝ) / 50000000))
  have h21 : RB z21 ((472507403 : ℝ) / 100000000) ((472507843 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((13421877 : ℝ) / 50000000) ((13421877 : ℝ) / 50000000) ((13421877 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((77644161 : ℝ) / 50000000) ((77644209 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_44.1 cov_log_45.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((45889887 : ℝ) / 50000000) ((91846723 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((63421877 : ℝ) / 50000000))
  have h24 : RB z24 ((4755717 : ℝ) / 20000000) ((11889293 : ℝ) / 50000000) := rb_log (show RB ((63421877 : ℝ) / 50000000) ((63421877 : ℝ) / 50000000) ((63421877 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_46.1 cov_log_46.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((17000297 : ℝ) / 25000000) ((34034069 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67901479 : ℝ) / 100000000) ((33958971 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_39.1 cov_log_40.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((41623 : ℝ) / 50000000) ((166659 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((4911 : ℝ) / 100000000) ((5029 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((63471409 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((126937789 : ℝ) / 100000000) ((126937907 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((63471409 : ℝ) / 50000000) ((63471409 : ℝ) / 50000000) ((63471409 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((13471409 : ℝ) / 50000000))
  have h30 : RB z30 ((471137759 : ℝ) / 100000000) ((235569099 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((13471409 : ℝ) / 50000000) ((13471409 : ℝ) / 50000000) ((13471409 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((77499017 : ℝ) / 50000000) ((15499813 : ℝ) / 10000000) := rb_log h30 (by norm_num) cov_log_47.1 cov_log_48.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((45804103 : ℝ) / 50000000) ((9167503 : ℝ) / 10000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((63471409 : ℝ) / 50000000))
  have h33 : RB z33 ((11928327 : ℝ) / 50000000) ((4771331 : ℝ) / 20000000) := rb_log (show RB ((63471409 : ℝ) / 50000000) ((63471409 : ℝ) / 50000000) ((63471409 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_49.1 cov_log_49.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67751551 : ℝ) / 100000000) ((8477297 : ℝ) / 12500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67901479 : ℝ) / 100000000) ((33958971 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_39.1 cov_log_40.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-166391 : ℝ) / 100000000) ((-83103 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((888869 : ℝ) / 2000000)) ((-3723 : ℝ) / 12500000) ((-3541 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((11167607 : ℝ) / 25000000)) ((4271 : ℝ) / 100000000) ((30117 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((63421877 : ℝ) / 50000000)) ((41623 : ℝ) / 50000000) ((166659 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((63471409 : ℝ) / 50000000)) ((-166391 : ℝ) / 100000000) ((-83103 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_2 {k A q d vp vm : ℝ}
    (hk : RB k ((9249 : ℝ) / 6400) ((18531 : ℝ) / 12800))
    (hA : RB A ((9249 : ℝ) / 15649) ((18531 : ℝ) / 31331))
    (hq : RB q ((350417 : ℝ) / 50000000) ((354561 : ℝ) / 50000000))
    (hd : RB d ((197193401 : ℝ) / 100000000) ((24653233 : ℝ) / 12500000))
    (hp : RB vp ((888869 : ℝ) / 2000000) ((11167607 : ℝ) / 25000000))
    (hm : RB vm ((63421877 : ℝ) / 50000000) ((63471409 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((4911 : ℝ) / 100000000) ((5029 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99994971 : ℝ) / 100000000) ((99995089 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((11819969 : ℝ) / 20000000) ((5914299 : ℝ) / 10000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((10993 : ℝ) / 100000000) ((2829 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24997171 : ℝ) / 25000000) ((99989007 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((13832393 : ℝ) / 25000000) ((1111131 : ℝ) / 2000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((5532331 : ℝ) / 10000000) ((55550443 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106389511 : ℝ) / 100000000) ((106904287 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6389511 : ℝ) / 100000000) ((6904287 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99994971 : ℝ) / 100000000) ((99995089 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((11819969 : ℝ) / 20000000) ((5914299 : ℝ) / 10000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((967 : ℝ) / 25000000) ((793 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19999207 : ℝ) / 20000000) ((24999033 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((13421877 : ℝ) / 50000000) ((13471409 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((26842689 : ℝ) / 100000000) ((1683861 : ℝ) / 6250000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((43872271 : ℝ) / 20000000) ((110165919 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((63872271 : ℝ) / 20000000) ((160165919 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((36209387 : ℝ) / 2500000) ((313012999 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31217627 : ℝ) / 100000000) ((31312493 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((9249 : ℝ) / 3200) ((18531 : ℝ) / 6400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2025629 : ℝ) / 100000000) ((2053241 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50350417 : ℝ) / 50000000) ((50354561 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((402273 : ℝ) / 20000000) ((254869 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((20402273 : ℝ) / 20000000) ((12754869 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((41086663 : ℝ) / 50000000) ((10312421 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((20255047 : ℝ) / 12500000) ((40677523 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((2818687 : ℝ) / 5000000) ((56705901 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((433 : ℝ) / 5000000) ((8921 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99991079 : ℝ) / 100000000) ((4999567 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((506331 : ℝ) / 312500) ((81348001 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((197193401 : ℝ) / 50000000) ((24653233 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((690999 : ℝ) / 25000000) ((349643 : ℝ) / 12500000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((15649 : ℝ) / 6400) ((122386719 : ℝ) / 50000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((225841 : ℝ) / 20000000) ((571977 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1568899 : ℝ) / 100000000) ((1595561 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((101568899 : ℝ) / 100000000) ((101595561 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((367774757 : ℝ) / 25000000) ((795018281 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((276043 : ℝ) / 50000000) ((139763 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50276043 : ℝ) / 50000000) ((25139763 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((1255599 : ℝ) / 4000000) ((31487547 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1502489003 : ℝ) / 100000000) ((1621524109 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((848309 : ℝ) / 5000000) ((1854949 : ℝ) / 10000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((15649 : ℝ) / 6400) ((122386719 : ℝ) / 50000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((20402273 : ℝ) / 10000000) ((12754869 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1479593107 : ℝ) / 100000000) ((99773593 : ℝ) / 6250000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((3018706249 : ℝ) / 100000000) ((1628926859 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((375271 : ℝ) / 5000000) ((1621711 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-3236931 : ℝ) / 1250000) ((-5024501 : ℝ) / 2000000) := rb_log h47 (by norm_num) cov_log_50.1 cov_log_51.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((690999 : ℝ) / 50000000) ((349643 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-428163997 : ℝ) / 100000000) ((-213485923 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_52.1 cov_log_53.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((67901479 : ℝ) / 100000000) ((33958971 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_39.1 cov_log_40.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((49064123 : ℝ) / 50000000) ((4916357 : ℝ) / 5000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-330035751 : ℝ) / 100000000) ((-164322353 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4149409 : ℝ) / 20000000) ((2677141 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((111846983 : ℝ) / 100000000) ((63117119 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-6818399 : ℝ) / 3125000) ((-50602617 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((20402273 : ℝ) / 20000000) ((12754869 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-3236931 : ℝ) / 1250000) ((-5024501 : ℝ) / 2000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-6818399 : ℝ) / 3125000) ((-50602617 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1568899 : ℝ) / 100000000) ((1595561 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((101595561 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-57699313 : ℝ) / 25000000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((623166421 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((50602617 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((50602617 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1347 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1347 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1367 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1367 : ℝ) / 500)) (lo := ((1347 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1387 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1387 : ℝ) / 500)) (lo := ((1367 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1407 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1407 : ℝ) / 500)) (lo := ((1387 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1427 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1427 : ℝ) / 500)) (lo := ((1407 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1447 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1447 : ℝ) / 500)) (lo := ((1427 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1467 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1467 : ℝ) / 500)) (lo := ((1447 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1487 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1487 : ℝ) / 500)) (lo := ((1467 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1507 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1507 : ℝ) / 500)) (lo := ((1487 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1527 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1527 : ℝ) / 500)) (lo := ((1507 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((1527 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_2 {k : ℝ} (hk : RB k ((9249 : ℝ) / 6400) ((18531 : ℝ) / 12800)) :
    RB (k / (k + 1)) ((9249 : ℝ) / 15649) ((18531 : ℝ) / 31331) ∧
    RB (qa (r1A k)) ((350417 : ℝ) / 50000000) ((354561 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((197193401 : ℝ) / 100000000) ((24653233 : ℝ) / 12500000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((18064453 : ℝ) / 50000000) ((452417 : ℝ) / 1250000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((2430083 : ℝ) / 1250000) ((97235547 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((139429781 : ℝ) / 100000000) ((69726447 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((280851137 : ℝ) / 100000000) ((280874251 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((4388299 : ℝ) / 3125000) ((70218563 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((197193401 : ℝ) / 100000000) ((24653233 : ℝ) / 12500000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2764453 : ℝ) / 50000000) ((69917 : ℝ) / 1250000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((691113 : ℝ) / 50000000) ((69917 : ℝ) / 5000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((350417 : ℝ) / 50000000) ((354561 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((197193401 : ℝ) / 100000000) ((24653233 : ℝ) / 12500000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((350417 : ℝ) / 50000000) ((354561 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((9249 : ℝ) / 15649) ((18531 : ℝ) / 31331) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_2 {k : ℝ} (hk : RB k ((9249 : ℝ) / 6400) ((18531 : ℝ) / 12800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_2 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_2 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((888869 : ℝ) / 2000000)) (ph := ((11167607 : ℝ) / 25000000)) (ml := ((63421877 : ℝ) / 50000000)) (mh := ((63471409 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_2 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_3 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((18531 : ℝ) / 31331) ((4641 : ℝ) / 7841))
    (hq : RB (qa a) ((554 : ℝ) / 78125) ((717411 : ℝ) / 100000000))
    (hd : RB (D0a a) ((12322559 : ℝ) / 6250000) ((3081147 : ℝ) / 1562500))
    : certE k a ((22199199 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((44623579 : ℝ) / 100000000) ∧ 0 < certE k a ((63438413 : ℝ) / 50000000) ∧ certE k a ((126975737 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1257 : ℝ) / 25000000) ((5147 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((22199199 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((44393251 : ℝ) / 100000000) ((4439337 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((22199199 : ℝ) / 50000000) ((22199199 : ℝ) / 50000000) ((22199199 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((27800801 : ℝ) / 50000000))
  have h3 : RB z3 ((19960419 : ℝ) / 25000000) ((79841891 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((27800801 : ℝ) / 50000000) ((27800801 : ℝ) / 50000000) ((27800801 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-22512457 : ℝ) / 100000000) ((-11256093 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_54.1 cov_log_55.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-13324871 : ℝ) / 100000000) ((-13315033 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((22199199 : ℝ) / 50000000))
  have h6 : RB z6 ((-81196681 : ℝ) / 100000000) ((-81196679 : ℝ) / 100000000) := rb_log (show RB ((22199199 : ℝ) / 50000000) ((22199199 : ℝ) / 50000000) ((22199199 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_56.1 cov_log_56.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((1060497 : ℝ) / 1562500) ((4242603 : ℝ) / 6250000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33942509 : ℝ) / 50000000) ((16975371 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_57.1 cov_log_58.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-7419 : ℝ) / 25000000) ((-337 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1257 : ℝ) / 25000000) ((5147 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((44623579 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((697163 : ℝ) / 1562500) ((44618551 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((44623579 : ℝ) / 100000000) ((44623579 : ℝ) / 100000000) ((44623579 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((55376421 : ℝ) / 100000000))
  have h12 : RB z12 ((40286489 : ℝ) / 50000000) ((40286597 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((55376421 : ℝ) / 100000000) ((55376421 : ℝ) / 100000000) ((55376421 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-10800343 : ℝ) / 50000000) ((-21600417 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_59.1 cov_log_60.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3196301 : ℝ) / 25000000) ((-12775759 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((44623579 : ℝ) / 100000000))
  have h15 : RB z15 ((-4034539 : ℝ) / 5000000) ((-40345389 : ℝ) / 50000000) := rb_log (show RB ((44623579 : ℝ) / 100000000) ((44623579 : ℝ) / 100000000) ((44623579 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_61.1 cov_log_61.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33952787 : ℝ) / 50000000) ((67915021 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33942509 : ℝ) / 50000000) ((16975371 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_57.1 cov_log_58.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((409 : ℝ) / 10000000) ((30003 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1257 : ℝ) / 25000000) ((5147 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((63438413 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((126871679 : ℝ) / 100000000) ((63435899 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((63438413 : ℝ) / 50000000) ((63438413 : ℝ) / 50000000) ((63438413 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((13438413 : ℝ) / 50000000))
  have h21 : RB z21 ((472048593 : ℝ) / 100000000) ((118012259 : ℝ) / 25000000) := rb_div_signed h20 (show RB ((13438413 : ℝ) / 50000000) ((13438413 : ℝ) / 50000000) ((13438413 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((77595587 : ℝ) / 50000000) ((155191271 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_62.1 cov_log_63.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((91789207 : ℝ) / 100000000) ((45927987 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((63438413 : ℝ) / 50000000))
  have h24 : RB z24 ((4760931 : ℝ) / 20000000) ((1487791 : ℝ) / 6250000) := rb_log (show RB ((63438413 : ℝ) / 50000000) ((63438413 : ℝ) / 50000000) ((63438413 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_64.1 cov_log_64.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67984551 : ℝ) / 100000000) ((68051319 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33942509 : ℝ) / 50000000) ((16975371 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_57.1 cov_log_58.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((83067 : ℝ) / 100000000) ((166301 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1257 : ℝ) / 25000000) ((5147 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((126975737 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((12697059 : ℝ) / 10000000) ((126970709 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((126975737 : ℝ) / 100000000) ((126975737 : ℝ) / 100000000) ((126975737 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((26975737 : ℝ) / 100000000))
  have h30 : RB z30 ((94136883 : ℝ) / 20000000) ((470684857 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((26975737 : ℝ) / 100000000) ((26975737 : ℝ) / 100000000) ((26975737 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((30980353 : ℝ) / 20000000) ((154901861 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_65.1 cov_log_66.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91618033 : ℝ) / 100000000) ((22921169 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((126975737 : ℝ) / 100000000))
  have h33 : RB z33 ((23882583 : ℝ) / 100000000) ((2985323 : ℝ) / 12500000) := rb_log (show RB ((126975737 : ℝ) / 100000000) ((126975737 : ℝ) / 100000000) ((126975737 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_67.1 cov_log_67.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((67735449 : ℝ) / 100000000) ((67802093 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33942509 : ℝ) / 50000000) ((16975371 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_57.1 cov_log_58.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-33207 : ℝ) / 20000000) ((-3317 : ℝ) / 4000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((22199199 : ℝ) / 50000000)) ((-7419 : ℝ) / 25000000) ((-337 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((44623579 : ℝ) / 100000000)) ((409 : ℝ) / 10000000) ((30003 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((63438413 : ℝ) / 50000000)) ((83067 : ℝ) / 100000000) ((166301 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((126975737 : ℝ) / 100000000)) ((-33207 : ℝ) / 20000000) ((-3317 : ℝ) / 4000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_3 {k A q d vp vm : ℝ}
    (hk : RB k ((18531 : ℝ) / 12800) ((4641 : ℝ) / 3200))
    (hA : RB A ((18531 : ℝ) / 31331) ((4641 : ℝ) / 7841))
    (hq : RB q ((554 : ℝ) / 78125) ((717411 : ℝ) / 100000000))
    (hd : RB d ((12322559 : ℝ) / 6250000) ((3081147 : ℝ) / 1562500))
    (hp : RB vp ((22199199 : ℝ) / 50000000) ((44623579 : ℝ) / 100000000))
    (hm : RB vm ((63438413 : ℝ) / 50000000) ((126975737 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1257 : ℝ) / 25000000) ((5147 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99994853 : ℝ) / 100000000) ((24998743 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((59142849 : ℝ) / 100000000) ((59185903 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((11267 : ℝ) / 100000000) ((11593 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99988407 : ℝ) / 100000000) ((99988733 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((55376421 : ℝ) / 100000000) ((27800801 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((55370001 : ℝ) / 100000000) ((27797669 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((2127619 : ℝ) / 2000000) ((53445821 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((127619 : ℝ) / 2000000) ((3445821 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99994853 : ℝ) / 100000000) ((24998743 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((59142849 : ℝ) / 100000000) ((59185903 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3959 : ℝ) / 100000000) ((4057 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99995943 : ℝ) / 100000000) ((99996041 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((13438413 : ℝ) / 50000000) ((26975737 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((5375147 : ℝ) / 20000000) ((2697467 : ℝ) / 10000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((1370333 : ℝ) / 625000) ((110110297 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((1995333 : ℝ) / 625000) ((160110297 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((362758251 : ℝ) / 25000000) ((391791191 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((3903559 : ℝ) / 12500000) ((31323093 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((18531 : ℝ) / 6400) ((4641 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1026617 : ℝ) / 50000000) ((2080941 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((78679 : ℝ) / 78125) ((100717411 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((127413 : ℝ) / 6250000) ((2066289 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((6377413 : ℝ) / 6250000) ((102066289 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((82253247 : ℝ) / 100000000) ((82577339 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((81085639 : ℝ) / 50000000) ((16283707 : ℝ) / 10000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((28165639 : ℝ) / 50000000) ((56661119 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((8873 : ℝ) / 100000000) ((4569 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49995431 : ℝ) / 50000000) ((99991127 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((81078229 : ℝ) / 50000000) ((81411311 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((12322559 : ℝ) / 3125000) ((3081147 : ℝ) / 781250) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((559243 : ℝ) / 20000000) ((4527 : ℝ) / 160000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((244773437 : ℝ) / 100000000) ((7841 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((570583 : ℝ) / 50000000) ((288979 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((317823 : ℝ) / 20000000) ((1615849 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((20317823 : ℝ) / 20000000) ((101615849 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1474091587 : ℝ) / 100000000) ((1592487781 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((139617 : ℝ) / 25000000) ((565439 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25139617 : ℝ) / 25000000) ((100565439 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((31402873 : ℝ) / 100000000) ((15750103 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((75274723 : ℝ) / 5000000) ((1623987987 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((1718019 : ℝ) / 10000000) ((18771937 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((244773437 : ℝ) / 100000000) ((7841 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((6377413 : ℝ) / 3125000) ((102066289 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((370565369 : ℝ) / 25000000) ((1598487857 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1512478977 : ℝ) / 50000000) ((407879309 : ℝ) / 12500000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1500281 : ℝ) / 20000000) ((50627 : ℝ) / 625000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-259007989 : ℝ) / 100000000) ((-251326661 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_68.1 cov_log_69.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1398107 : ℝ) / 100000000) ((44209 : ℝ) / 3125000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-427005107 : ℝ) / 100000000) ((-425826117 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_70.1 cov_log_71.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33942509 : ℝ) / 50000000) ((16975371 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_57.1 cov_log_58.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((49139737 : ℝ) / 50000000) ((24619593 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-328725633 : ℝ) / 100000000) ((-65469549 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((824817 : ℝ) / 4000000) ((2128659 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((109847081 : ℝ) / 100000000) ((30975487 : ℝ) / 25000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-27359819 : ℝ) / 12500000) ((-203445797 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((6377413 : ℝ) / 6250000) ((102066289 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-259007989 : ℝ) / 100000000) ((-251326661 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-27359819 : ℝ) / 12500000) ((-203445797 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((317823 : ℝ) / 20000000) ((1615849 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((101615849 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-230850761 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((125237231 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((203445797 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((203445797 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2707 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2707 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2747 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2747 : ℝ) / 1000)) (lo := ((2707 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2787 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2787 : ℝ) / 1000)) (lo := ((2747 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2827 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2827 : ℝ) / 1000)) (lo := ((2787 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2867 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2867 : ℝ) / 1000)) (lo := ((2827 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2907 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2907 : ℝ) / 1000)) (lo := ((2867 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2947 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2947 : ℝ) / 1000)) (lo := ((2907 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2987 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2987 : ℝ) / 1000)) (lo := ((2947 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3027 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3027 : ℝ) / 1000)) (lo := ((2987 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((3067 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((3067 : ℝ) / 1000)) (lo := ((3027 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((3067 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_3 {k : ℝ} (hk : RB k ((18531 : ℝ) / 12800) ((4641 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((18531 : ℝ) / 31331) ((4641 : ℝ) / 7841) ∧
    RB (qa (r1A k)) ((554 : ℝ) / 78125) ((717411 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((12322559 : ℝ) / 6250000) ((3081147 : ℝ) / 1562500) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((36193359 : ℝ) / 100000000) ((36257813 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((194342187 : ℝ) / 100000000) ((194406641 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((69703333 : ℝ) / 50000000) ((69714891 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((140414011 : ℝ) / 50000000) ((280851139 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140414011 : ℝ) / 100000000) ((14042557 : ℝ) / 10000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((12322559 : ℝ) / 6250000) ((3081147 : ℝ) / 1562500) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((5593359 : ℝ) / 100000000) ((5657813 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1398339 : ℝ) / 100000000) ((707227 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((554 : ℝ) / 78125) ((717411 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((12322559 : ℝ) / 6250000) ((3081147 : ℝ) / 1562500) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((554 : ℝ) / 78125) ((717411 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((18531 : ℝ) / 31331) ((4641 : ℝ) / 7841) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_3 {k : ℝ} (hk : RB k ((18531 : ℝ) / 12800) ((4641 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_3 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_3 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((22199199 : ℝ) / 50000000)) (ph := ((44623579 : ℝ) / 100000000)) (ml := ((63438413 : ℝ) / 50000000)) (mh := ((126975737 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_3 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_4 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((4641 : ℝ) / 7841) ((18597 : ℝ) / 31397))
    (hq : RB (qa a) ((71741 : ℝ) / 10000000) ((725703 : ℝ) / 100000000))
    (hd : RB (D0a a) ((98564241 : ℝ) / 50000000) ((49290237 : ℝ) / 25000000))
    : certE k a ((5544213 : ℝ) / 12500000) < 0 ∧ 0 < certE k a ((44577099 : ℝ) / 100000000) ∧ 0 < certE k a ((126909847 : ℝ) / 100000000) ∧ certE k a ((25401721 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((2573 : ℝ) / 50000000) ((5267 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((5544213 : ℝ) / 12500000)) - (z1)
  have h2 : RB z2 ((44348437 : ℝ) / 100000000) ((22174279 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((5544213 : ℝ) / 12500000) ((5544213 : ℝ) / 12500000) ((5544213 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((6955787 : ℝ) / 12500000))
  have h3 : RB z3 ((15939403 : ℝ) / 20000000) ((79697233 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((6955787 : ℝ) / 12500000) ((6955787 : ℝ) / 12500000) ((6955787 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-11346903 : ℝ) / 50000000) ((-22693531 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_72.1 cov_log_73.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1680243 : ℝ) / 12500000) ((-6716023 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((5544213 : ℝ) / 12500000))
  have h6 : RB z6 ((-40648699 : ℝ) / 50000000) ((-20324349 : ℝ) / 25000000) := rb_log (show RB ((5544213 : ℝ) / 12500000) ((5544213 : ℝ) / 12500000) ((5544213 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_74.1 cov_log_74.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((16963863 : ℝ) / 25000000) ((8483169 : ℝ) / 12500000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((8483569 : ℝ) / 12500000) ((33942511 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_75.1 cov_log_76.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-2957 : ℝ) / 10000000) ((-1 : ℝ) / 31250) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((2573 : ℝ) / 50000000) ((5267 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((44577099 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((5571479 : ℝ) / 12500000) ((44571953 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((44577099 : ℝ) / 100000000) ((44577099 : ℝ) / 100000000) ((44577099 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((55422901 : ℝ) / 100000000))
  have h12 : RB z12 ((40210663 : ℝ) / 50000000) ((16084309 : ℝ) / 20000000) := rb_div_signed h11 (show RB ((55422901 : ℝ) / 100000000) ((55422901 : ℝ) / 100000000) ((55422901 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-544727 : ℝ) / 2500000) ((-21788807 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_77.1 cov_log_78.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-12906059 : ℝ) / 100000000) ((-257931 : ℝ) / 2000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((44577099 : ℝ) / 100000000))
  have h15 : RB z15 ((-16158999 : ℝ) / 20000000) ((-80794993 : ℝ) / 100000000) := rb_log (show RB ((44577099 : ℝ) / 100000000) ((44577099 : ℝ) / 100000000) ((44577099 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_79.1 cov_log_79.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33944467 : ℝ) / 50000000) ((13579689 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((8483569 : ℝ) / 12500000) ((33942511 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_75.1 cov_log_76.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((489 : ℝ) / 12500000) ((29893 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((2573 : ℝ) / 50000000) ((5267 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((126909847 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((6345229 : ℝ) / 5000000) ((126904701 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((126909847 : ℝ) / 100000000) ((126909847 : ℝ) / 100000000) ((126909847 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((26909847 : ℝ) / 100000000))
  have h21 : RB z21 ((471591607 : ℝ) / 100000000) ((471592057 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((26909847 : ℝ) / 100000000) ((26909847 : ℝ) / 100000000) ((26909847 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((77547159 : ℝ) / 50000000) ((9693401 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_80.1 cov_log_81.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((22949647 : ℝ) / 25000000) ((45932587 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((126909847 : ℝ) / 100000000))
  have h24 : RB z24 ((11915339 : ℝ) / 50000000) ((23830679 : ℝ) / 100000000) := rb_log (show RB ((126909847 : ℝ) / 100000000) ((126909847 : ℝ) / 100000000) ((126909847 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_82.1 cov_log_82.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((67967909 : ℝ) / 100000000) ((1063039 : ℝ) / 1562500) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((8483569 : ℝ) / 12500000) ((33942511 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_75.1 cov_log_76.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((82887 : ℝ) / 100000000) ((20743 : ℝ) / 12500000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((2573 : ℝ) / 50000000) ((5267 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((25401721 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((63501669 : ℝ) / 50000000) ((127003459 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((25401721 : ℝ) / 20000000) ((25401721 : ℝ) / 20000000) ((25401721 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((5401721 : ℝ) / 20000000))
  have h30 : RB z30 ((117558217 : ℝ) / 25000000) ((470233317 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((5401721 : ℝ) / 20000000) ((5401721 : ℝ) / 20000000) ((5401721 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((19350723 : ℝ) / 12500000) ((154805883 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_83.1 cov_log_84.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((2863369 : ℝ) / 3125000) ((91694271 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((25401721 : ℝ) / 20000000))
  have h33 : RB z33 ((4781693 : ℝ) / 20000000) ((11954233 : ℝ) / 50000000) := rb_log (show RB ((25401721 : ℝ) / 20000000) ((25401721 : ℝ) / 20000000) ((25401721 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_85.1 cov_log_85.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((33859671 : ℝ) / 50000000) ((33892903 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((8483569 : ℝ) / 12500000) ((33942511 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_75.1 cov_log_76.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-2071 : ℝ) / 1250000) ((-41373 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((5544213 : ℝ) / 12500000)) ((-2957 : ℝ) / 10000000) ((-1 : ℝ) / 31250) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((44577099 : ℝ) / 100000000)) ((489 : ℝ) / 12500000) ((29893 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((126909847 : ℝ) / 100000000)) ((82887 : ℝ) / 100000000) ((20743 : ℝ) / 12500000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((25401721 : ℝ) / 20000000)) ((-2071 : ℝ) / 1250000) ((-41373 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_4 {k A q d vp vm : ℝ}
    (hk : RB k ((4641 : ℝ) / 3200) ((18597 : ℝ) / 12800))
    (hA : RB A ((4641 : ℝ) / 7841) ((18597 : ℝ) / 31397))
    (hq : RB q ((71741 : ℝ) / 10000000) ((725703 : ℝ) / 100000000))
    (hd : RB d ((98564241 : ℝ) / 50000000) ((49290237 : ℝ) / 25000000))
    (hp : RB vp ((5544213 : ℝ) / 12500000) ((44577099 : ℝ) / 100000000))
    (hm : RB vm ((126909847 : ℝ) / 100000000) ((25401721 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((2573 : ℝ) / 50000000) ((5267 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99994733 : ℝ) / 100000000) ((49997427 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((59185761 : ℝ) / 100000000) ((29614363 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((1443 : ℝ) / 12500000) ((19 : ℝ) / 160000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((159981 : ℝ) / 160000) ((12498557 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((55422901 : ℝ) / 100000000) ((6955787 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((55416319 : ℝ) / 100000000) ((55639873 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53186463 : ℝ) / 50000000) ((4275183 : ℝ) / 4000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3186463 : ℝ) / 50000000) ((275183 : ℝ) / 4000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99994733 : ℝ) / 100000000) ((49997427 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((59185761 : ℝ) / 100000000) ((29614363 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((4051 : ℝ) / 100000000) ((4151 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99995849 : ℝ) / 100000000) ((99995949 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((26909847 : ℝ) / 100000000) ((5401721 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((26908729 : ℝ) / 100000000) ((27007511 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((219145559 : ℝ) / 100000000) ((220109713 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((319145559 : ℝ) / 100000000) ((320109713 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((363394541 : ℝ) / 25000000) ((196142243 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31239289 : ℝ) / 100000000) ((6266733 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((4641 : ℝ) / 1600) ((18597 : ℝ) / 6400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2080937 : ℝ) / 100000000) ((421747 : ℝ) / 20000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((10071741 : ℝ) / 10000000) ((100725703 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((258243 : ℝ) / 12500000) ((418743 : ℝ) / 20000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((12758243 : ℝ) / 12500000) ((20418743 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((20583187 : ℝ) / 25000000) ((82654901 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((10143831 : ℝ) / 6250000) ((162963187 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((56289217 : ℝ) / 100000000) ((3538547 : ℝ) / 6250000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((9089 : ℝ) / 100000000) ((4679 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49995321 : ℝ) / 50000000) ((99990911 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((162286107 : ℝ) / 100000000) ((20368547 : ℝ) / 12500000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((98564241 : ℝ) / 25000000) ((49290237 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1414219 : ℝ) / 50000000) ((1430803 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((7841 : ℝ) / 3200) ((245289063 : ℝ) / 100000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((72069 : ℝ) / 6250000) ((583927 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((201171 : ℝ) / 12500000) ((1636173 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((12701171 : ℝ) / 12500000) ((101636173 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((295394317 : ℝ) / 20000000) ((398702939 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((564851 : ℝ) / 100000000) ((285913 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100564851 : ℝ) / 100000000) ((50285913 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((490871 : ℝ) / 1562500) ((787821 : ℝ) / 2500000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1508387329 : ℝ) / 100000000) ((406581149 : ℝ) / 25000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((8696637 : ℝ) / 50000000) ((18993097 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((7841 : ℝ) / 3200) ((245289063 : ℝ) / 100000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((12758243 : ℝ) / 6250000) ((20418743 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1484817453 : ℝ) / 100000000) ((1600471609 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((30309859 : ℝ) / 1000000) ((3267961847 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((7497983 : ℝ) / 100000000) ((2023179 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-129526809 : ℝ) / 50000000) ((-125710289 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_86.1 cov_log_87.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1414219 : ℝ) / 100000000) ((1430803 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-425859281 : ℝ) / 100000000) ((-84938687 : ℝ) / 20000000) := rb_log h49 (by norm_num) cov_log_88.1 cov_log_89.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((8483569 : ℝ) / 12500000) ((33942511 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_75.1 cov_log_76.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((98430609 : ℝ) / 100000000) ((98629513 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-5116073 : ℝ) / 1562500) ((-163031961 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((20494671 : ℝ) / 100000000) ((21156941 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((107905893 : ℝ) / 100000000) ((24327727 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-219522779 : ℝ) / 100000000) ((-204425287 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((12758243 : ℝ) / 12500000) ((20418743 : ℝ) / 20000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-129526809 : ℝ) / 50000000) ((-125710289 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-219522779 : ℝ) / 100000000) ((-204425287 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((77 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((201171 : ℝ) / 12500000) ((1636173 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((8 : ℝ) / 5) := by
    have hu : (1 + q / vp) / 2 ≤ ((101636173 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((77 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((8 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-23089639 : ℝ) / 10000000) ≤ formC0 k A q vp vm + hfun ((77 : ℝ) / 25) + hfun ((8 : ℝ) / 5) := by
    linarith [hc0.1, cov_h_2, cov_h_1]
  have hP : ((629031903 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((204425287 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((204425287 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((62473263 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((8 : ℝ) / 5) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((117 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1359 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1359 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1379 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1379 : ℝ) / 500)) (lo := ((1359 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1399 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1399 : ℝ) / 500)) (lo := ((1379 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1419 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1419 : ℝ) / 500)) (lo := ((1399 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1439 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1439 : ℝ) / 500)) (lo := ((1419 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1459 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1459 : ℝ) / 500)) (lo := ((1439 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1479 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1479 : ℝ) / 500)) (lo := ((1459 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1499 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1499 : ℝ) / 500)) (lo := ((1479 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1519 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1519 : ℝ) / 500)) (lo := ((1499 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1539 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1539 : ℝ) / 500)) (lo := ((1519 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((77 : ℝ) / 25)) (lo := ((1539 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_4 {k : ℝ} (hk : RB k ((4641 : ℝ) / 3200) ((18597 : ℝ) / 12800)) :
    RB (k / (k + 1)) ((4641 : ℝ) / 7841) ((18597 : ℝ) / 31397) ∧
    RB (qa (r1A k)) ((71741 : ℝ) / 10000000) ((725703 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((98564241 : ℝ) / 50000000) ((49290237 : ℝ) / 25000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((9064453 : ℝ) / 25000000) ((18161133 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((97138867 : ℝ) / 50000000) ((48585547 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((139383547 : ℝ) / 100000000) ((139406667 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((280804903 : ℝ) / 100000000) ((35103503 : ℝ) / 12500000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((140402451 : ℝ) / 100000000) ((35103503 : ℝ) / 25000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((98564241 : ℝ) / 50000000) ((49290237 : ℝ) / 25000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((1414453 : ℝ) / 25000000) ((2861133 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1414453 : ℝ) / 100000000) ((1430567 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((71741 : ℝ) / 10000000) ((725703 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((98564241 : ℝ) / 50000000) ((49290237 : ℝ) / 25000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((71741 : ℝ) / 10000000) ((725703 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((4641 : ℝ) / 7841) ((18597 : ℝ) / 31397) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_4 {k : ℝ} (hk : RB k ((4641 : ℝ) / 3200) ((18597 : ℝ) / 12800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_4 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_4 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((5544213 : ℝ) / 12500000)) (ph := ((44577099 : ℝ) / 100000000)) (ml := ((126909847 : ℝ) / 100000000)) (mh := ((25401721 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_4 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
