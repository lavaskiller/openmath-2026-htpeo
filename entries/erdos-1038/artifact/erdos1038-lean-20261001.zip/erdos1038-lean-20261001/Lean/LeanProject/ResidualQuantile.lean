import LeanProject.AtomicQuantile

/-! The residual step quantile of the actual polynomial normal form, including
the boundary identity that excludes the swallowed case in Lemma 10.7. -/

open Real Set MeasureTheory Finset intervalIntegral
open scoped ENNReal

namespace EP1038.NormalForm

namespace NormalData

noncomputable def sortedLocations {n : ℕ} (a : NormalData n) : List ℝ :=
  (a.residualIndices.val.map a.locations).sort (· ≤ ·)

noncomputable def orderedAtoms {n : ℕ} (a : NormalData n) (j : Fin a.sortedLocations.length) : ℝ :=
  a.sortedLocations[j.1]

end NormalData

open NormalData

theorem sorted_length {n : ℕ} (a : NormalData n) : a.sortedLocations.length = a.residualCount := by
  classical
  simp [sortedLocations, residualCount]

theorem orderedAtoms_monotone {n : ℕ} (a : NormalData n) : Monotone a.orderedAtoms := by
  classical
  intro i j hij
  exact List.Pairwise.rel_get_of_le (Multiset.pairwise_sort _ _) hij

theorem orderedAtoms_bounds {n : ℕ} (a : NormalData n) (j : Fin a.sortedLocations.length) :
    a.separator < a.orderedAtoms j ∧ a.orderedAtoms j ≤ 2 := by
  classical
  have hmem : a.orderedAtoms j ∈ a.residualIndices.val.map a.locations := by
    apply (Multiset.mem_sort (r := (· ≤ ·))).mp
    exact List.getElem_mem j.isLt
  obtain ⟨i, hi, heq⟩ := Multiset.mem_map.mp hmem
  rw [← heq]
  exact residual_location_bounds a hi

theorem orderedAtoms_sum {n : ℕ} (a : NormalData n) (g : ℝ → ℝ) :
    (∑ j : Fin a.sortedLocations.length, g (a.orderedAtoms j)) =
      ∑ i ∈ a.residualIndices, g (a.locations i) := by
  classical
  change (∑ j : Fin a.sortedLocations.length, g a.sortedLocations[j.1]) = _
  rw [Fin.sum_univ_fun_getElem]
  change ((a.sortedLocations : Multiset ℝ).map g).sum = _
  rw [sortedLocations, Multiset.sort_eq, Multiset.map_map]
  rfl

theorem sorted_length_pos {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    0 < a.sortedLocations.length := by simpa only [sorted_length] using hres

namespace NormalData

noncomputable def residualQuantile {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) : ℝ → ℝ :=
  AtomicQuantile.step (sorted_length_pos a hres) a.orderedAtoms

noncomputable def firstLocation {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) : ℝ :=
  a.orderedAtoms ⟨0, sorted_length_pos a hres⟩

end NormalData

theorem measurable_residualQuantile {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    Measurable (a.residualQuantile hres) := AtomicQuantile.measurable_step _ _

theorem monotone_residualQuantile {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    Monotone (a.residualQuantile hres) :=
  AtomicQuantile.monotone_step _ _ (orderedAtoms_monotone a)

theorem firstLocation_bounds {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    a.separator < a.firstLocation hres ∧ a.firstLocation hres ≤ 2 := orderedAtoms_bounds a _

theorem firstLocation_pos {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    0 < a.firstLocation hres := by
  linarith [(firstLocation_bounds a hres).1, separator_ge_one a]

theorem residualQuantile_bounds {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) (u : ℝ) :
    a.firstLocation hres ≤ a.residualQuantile hres u ∧ a.residualQuantile hres u ≤ 2 := by
  apply AtomicQuantile.step_bounds
  intro j
  exact ⟨orderedAtoms_monotone a (by change (0 : ℕ) ≤ j.1; omega),
    (orderedAtoms_bounds a j).2⟩

theorem residual_first_atom_positive {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    0 < volume ({u | a.residualQuantile hres u = a.firstLocation hres} ∩ Ioc (0 : ℝ) 1) :=
  AtomicQuantile.first_atom_positive _ _

/-- The probability law of the quantile retains every residual root with its multiplicity. -/
theorem integral_residualQuantile {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount)
    (g : ℝ → ℝ) :
    (∫ u in (0 : ℝ)..1, g (a.residualQuantile hres u)) =
      (∑ i ∈ a.residualIndices, g (a.locations i)) / a.residualCount := by
  rw [residualQuantile, AtomicQuantile.integral_step, orderedAtoms_sum, sorted_length]

theorem log_product_split {n : ℕ} (a : NormalData n) (x : ℝ) :
    (∑ i, Real.log |x - a.locations i|) =
      a.mainCount * Real.log |x| + ∑ i ∈ a.residualIndices, Real.log |x - a.locations i| := by
  classical
  rw [← Finset.sum_filter_add_sum_filter_not univ (fun i => a.roots i = a.roots a.main)]
  congr 1
  rw [Finset.sum_congr rfl (fun i hi => by
    rw [show a.locations i = 0 by simp [locations, (Finset.mem_filter.mp hi).2]]),
    Finset.sum_const, nsmul_eq_mul]
  simp only [sub_zero, mainCount]

theorem potential_eq_log_sum {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) (x : ℝ) :
    Stage10.WS a.k (a.residualQuantile hres) x =
      (∑ i, Real.log |x - a.locations i|) / a.residualCount := by
  rw [Stage10.WS, integral_residualQuantile a hres (fun t => Real.log |x - t|),
    log_product_split]
  dsimp [k]
  ring

/-- The actual polynomial boundary gives a zero of the normalized residual potential. -/
theorem potential_zero_at_separator {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    Stage10.WS a.k (a.residualQuantile hres) a.separator = 0 := by
  classical
  have hne : ∀ i, a.boundary - a.roots i ≠ 0 := by
    intro i
    by_cases hi : a.roots i = a.roots a.main
    · rw [hi]
      linarith [a.boundary_ge]
    · linarith [a.residual_after i hi]
  have hlog : (∑ i, Real.log |a.boundary - a.roots i|) = 0 := by
    rw [← Real.log_prod (fun i _ => abs_ne_zero.mpr (hne i)), ← Finset.abs_prod,
      a.boundary_product, Real.log_one]
  rw [potential_eq_log_sum]
  have heq : ∀ i, a.separator - a.locations i = a.boundary - a.roots i := by
    intro i; dsimp [separator, locations]; ring
  simp_rw [heq]
  rw [hlog, zero_div]

/-- The normal form itself supplies every target hypothesis of the supporting theorem:
the genuine residual quantile is separated or in contact, and cannot be swallowed. -/
theorem residualQuantile_admissible {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount) :
    let T := a.residualQuantile hres
    let a₁ := a.firstLocation hres
    0 < Stage10.yc a.k a₁ T ∧ Stage10.yc a.k a₁ T < a₁ ∧
      (Stage10.RS a.k T < Stage10.PsiS a.k T (Stage10.yc a.k a₁ T) ∨
       Stage10.RS a.k T = Stage10.PsiS a.k T (Stage10.yc a.k a₁ T)) := by
  dsimp only
  have hm := measurable_residualQuantile a hres
  have ha := firstLocation_pos a hres
  have hl := fun u => (residualQuantile_bounds a hres u).1
  have hu := fun u => (residualQuantile_bounds a hres u).2
  have hk : 0 < a.k := lt_of_lt_of_le zero_lt_one (one_le_k a hres)
  have hatom := residual_first_atom_positive a hres
  refine ⟨Stage10.yc_pos hm ha hl hu hk, Stage10.yc_lt hm ha hl hu hk hatom, ?_⟩
  rcases Stage10.sep_or_contact_or_swallow hm ha hl hu hk hatom with h | h | h
  · exact Or.inl h
  · exact Or.inr h
  · have hz := potential_zero_at_separator a hres
    have hn := h a.separator (by linarith [separator_ge_one a]) (firstLocation_bounds a hres).1
    linarith

end EP1038.NormalForm
