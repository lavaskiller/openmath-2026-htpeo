import LeanProject.GeneralWitness

/-!
# EP-1038: the witnesses of proof.md Lemma 6.6′ (roadmap 15c part 3), general part

* `integrand_integrable`: `θ ↦ log|x - s(θ)|` is integrable on `[0, 2π]` for every `x` (inside the
  support via the circle-average functions, a.e.).
* `U_concave`: the arcsine potential is concave on `(-∞, c]` (a `θ`-average of `log(s(θ) - x)`).
* `Wp`, `Wp_pos`: `W = log x + h₁ log(B - x) + h₂ U_c`; positivity on `[lo, hi]` from the three
  values `W(lo), W(c), W(hi)` (concavity on `[lo, c]`, `U_c` constant on `[c, hi]`).
* `rho` (arcsine measure as an image of Lebesgue measure), `mu = δ₀ + h₁ δ_B + h₂ ρ_[c,B]`, with
  `mu_integral` (`∫ log|x - s| dμ = W(x)`), `mu_integrable`, `mu_compl` (support in `[0, B]`),
  `mu_atom` (no atoms at positive points other than possibly `B`).
-/
open Real Complex MeasureTheory

namespace EP1038.Arcsine

/-- The countable set `{θ : cos θ = z}` (empty unless `|z| ≤ 1`). -/
theorem countable_cos_eq' (z : ℝ) : {θ : ℝ | Real.cos θ = z}.Countable := by
  by_cases hz : |z| ≤ 1
  · obtain ⟨h1, h2⟩ := abs_le.mp hz
    have : {θ : ℝ | Real.cos θ = z} = {θ : ℝ | Real.cos θ = Real.cos (Real.arccos z)} := by
      rw [Real.cos_arccos h1 h2]
    rw [this]; exact countable_cos_eq _
  · have : {θ : ℝ | Real.cos θ = z} = ∅ := by
      ext θ
      simp only [Set.mem_ofPred_eq, Set.mem_empty_iff_false, iff_false]
      intro h
      apply hz
      rw [← h]; exact Real.abs_cos_le_one θ
    rw [this]; exact Set.countable_empty

/-- Pointwise identity behind `avg_in`, off the set `{cos θ = z}`. -/
theorem inside_pointwise {z s : ℝ} (hs : 0 < s) (hz : |z| ≤ 1) (θ : ℝ) (hθ : Real.cos θ ≠ z) :
    Real.log |s * (z - Real.cos θ)| =
      Real.log ‖circleMap 0 1 θ - Complex.exp (Real.arccos z * Complex.I)‖ +
        Real.log ‖circleMap 0 1 θ - Complex.exp ((-Real.arccos z : ℝ) * Complex.I)‖ -
          (Real.log 2 - Real.log s) := by
  obtain ⟨hz1, hz2⟩ := abs_le.mp hz
  set ψ := Real.arccos z with hψ
  have hcψ : Real.cos ψ = z := Real.cos_arccos hz1 hz2
  set a : ℂ := Complex.exp (ψ * Complex.I) with ha
  set b : ℂ := Complex.exp ((-ψ : ℝ) * Complex.I) with hb
  have ha1 : ‖a‖ = 1 := Complex.norm_exp_ofReal_mul_I ψ
  have ha0 : a ≠ 0 := Complex.exp_ne_zero _
  have hainv : a⁻¹ = b := by
    rw [ha, hb, ← Complex.exp_neg]; congr 1; push_cast; ring
  have hza : 2 * (z : ℂ) = a + a⁻¹ := by
    rw [hainv, ← hcψ, Complex.ofReal_cos, Complex.cos, ha, hb]; push_cast; ring_nf
  have hf := cos_factor ha0 hza θ
  have hn := congrArg norm hf
  simp only [norm_mul] at hn
  have hca : (starRingEnd ℂ) a = b := by
    rw [ha, hb, ← Complex.exp_conj]; congr 1
    rw [map_mul, Complex.conj_ofReal, Complex.conj_I]; push_cast; ring
  have hce : (starRingEnd ℂ) (Complex.exp (-(θ * Complex.I))) = Complex.exp (θ * Complex.I) := by
    rw [← Complex.exp_conj]; congr 1
    rw [map_neg, map_mul, Complex.conj_ofReal, Complex.conj_I]; ring
  have hconj : ‖a - Complex.exp (-(θ * Complex.I))‖ = ‖b - Complex.exp (θ * Complex.I)‖ := by
    rw [← Complex.norm_conj, map_sub, hca, hce]
  rw [hconj, ha1, Complex.norm_ofNat] at hn
  have hzcos : ‖(z : ℂ) - Complex.cos θ‖ = |z - Real.cos θ| := by
    rw [← Complex.ofReal_cos, ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
  rw [hzcos] at hn
  have hpos : 0 < |z - Real.cos θ| := abs_pos.mpr (sub_ne_zero.mpr (Ne.symm hθ))
  have hcm : ∀ c : ℂ, ‖circleMap 0 1 θ - c‖ = ‖c - Complex.exp (θ * Complex.I)‖ := by
    intro c; simp only [circleMap, zero_add, Complex.ofReal_one, one_mul]; rw [norm_sub_rev]
  rw [hcm a, hcm b]
  have hA : 0 < ‖a - Complex.exp (θ * Complex.I)‖ := by
    rcases (norm_nonneg (a - Complex.exp (θ * Complex.I))).lt_or_eq with h | h
    · exact h
    · rw [← h, zero_mul] at hn; linarith
  have hB : 0 < ‖b - Complex.exp (θ * Complex.I)‖ := by
    rcases (norm_nonneg (b - Complex.exp (θ * Complex.I))).lt_or_eq with h | h
    · exact h
    · rw [← h, mul_zero] at hn; linarith
  have : |z - Real.cos θ| = ‖a - Complex.exp (θ * Complex.I)‖ *
      ‖b - Complex.exp (θ * Complex.I)‖ / 2 := by linarith
  rw [abs_mul, abs_of_pos hs, Real.log_mul hs.ne' hpos.ne', this,
    Real.log_div (by positivity) (by norm_num), Real.log_mul hA.ne' hB.ne']
  ring

/-- Integrability of the arcsine-potential integrand, for every `x`. -/
theorem integrand_integrable {c d x : ℝ} (hcd : c < d) :
    IntervalIntegrable (fun θ => Real.log |x - ((c + d) / 2 + (d - c) / 2 * Real.cos θ)|)
      volume 0 (2 * π) := by
  have hh : (0 : ℝ) < (d - c) / 2 := by linarith
  set s := (d - c) / 2 with hsdef
  set z := (x - (c + d) / 2) / s with hzdef
  have heq : (fun θ => Real.log |x - ((c + d) / 2 + (d - c) / 2 * Real.cos θ)|) =
      fun θ => Real.log |s * (z - Real.cos θ)| := by
    funext θ; rw [U_integrand hcd θ]
  rw [heq]
  by_cases hz : |z| ≤ 1
  · set g : ℝ → ℝ := fun θ =>
      Real.log ‖circleMap 0 1 θ - Complex.exp (Real.arccos z * Complex.I)‖ +
        Real.log ‖circleMap 0 1 θ - Complex.exp ((-Real.arccos z : ℝ) * Complex.I)‖ -
          (Real.log 2 - Real.log s) with hg
    have hgi : IntervalIntegrable g volume 0 (2 * π) := by
      have h1 : IntervalIntegrable (fun θ => Real.log ‖circleMap 0 1 θ -
          Complex.exp (Real.arccos z * Complex.I)‖) volume 0 (2 * π) :=
        circleIntegrable_log_norm_sub_const (c := 0) 1
      have h2 : IntervalIntegrable (fun θ => Real.log ‖circleMap 0 1 θ -
          Complex.exp ((-Real.arccos z : ℝ) * Complex.I)‖) volume 0 (2 * π) :=
        circleIntegrable_log_norm_sub_const (c := 0) 1
      exact (h1.add h2).sub intervalIntegrable_const
    apply hgi.congr_ae
    have hnull : volume {θ : ℝ | Real.cos θ = z} = 0 := (countable_cos_eq' z).measure_zero volume
    have := measure_eq_zero_iff_ae_notMem.mp hnull
    filter_upwards [ae_restrict_of_ae this] with θ hθ
    exact (inside_pointwise hh hz θ hθ).symm
  · push Not at hz
    apply Continuous.intervalIntegrable
    apply Continuous.log (by fun_prop)
    intro θ
    rw [abs_ne_zero]
    exact mul_ne_zero hh.ne' (sub_ne_zero.mpr (fun h => by
      rw [h] at hz; linarith [Real.abs_cos_le_one θ]))

/-- **Concavity of the arcsine potential to the left of its support**: for `x₁, x₂ ≤ c` and
`t ∈ [0, 1]`, `U(t x₁ + (1-t) x₂) ≥ t U(x₁) + (1-t) U(x₂)`. -/
theorem U_concave {c d x₁ x₂ t : ℝ} (hcd : c < d) (h1 : x₁ ≤ c) (h2 : x₂ ≤ c)
    (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    t * U c d x₁ + (1 - t) * U c d x₂ ≤ U c d (t * x₁ + (1 - t) * x₂) := by
  set sθ : ℝ → ℝ := fun θ => (c + d) / 2 + (d - c) / 2 * Real.cos θ with hsθ
  have hI : ∀ x, IntervalIntegrable (fun θ => Real.log |x - sθ θ|) volume 0 (2 * π) :=
    fun x => integrand_integrable hcd
  -- pointwise concavity off {cos θ = -1}
  have hpt : ∀ θ : ℝ, Real.cos θ ≠ -1 →
      t * Real.log |x₁ - sθ θ| + (1 - t) * Real.log |x₂ - sθ θ| ≤
        Real.log |t * x₁ + (1 - t) * x₂ - sθ θ| := by
    intro θ hθ
    have hc1 : -1 < Real.cos θ := lt_of_le_of_ne (Real.neg_one_le_cos θ) (Ne.symm hθ)
    have hs : c < sθ θ := by
      simp only [hsθ]; nlinarith
    have p1 : 0 < sθ θ - x₁ := by linarith
    have p2 : 0 < sθ θ - x₂ := by linarith
    rw [abs_sub_comm, abs_of_pos p1, abs_sub_comm x₂, abs_of_pos p2, abs_sub_comm,
      abs_of_pos (by nlinarith)]
    have hcc := (strictConcaveOn_log_Ioi.concaveOn).2 (Set.mem_Ioi.mpr p1) (Set.mem_Ioi.mpr p2)
      ht0 (by linarith : (0 : ℝ) ≤ 1 - t) (by ring)
    simp only [smul_eq_mul] at hcc
    have e : t * (sθ θ - x₁) + (1 - t) * (sθ θ - x₂) = sθ θ - (t * x₁ + (1 - t) * x₂) := by ring
    rw [e] at hcc
    exact hcc
  have hae : ∀ᵐ θ ∂(volume : Measure ℝ), θ ∈ Set.Ioc (0 : ℝ) (2 * π) →
      t * Real.log |x₁ - sθ θ| + (1 - t) * Real.log |x₂ - sθ θ| ≤
        Real.log |t * x₁ + (1 - t) * x₂ - sθ θ| := by
    have hnull : volume {θ : ℝ | Real.cos θ = -1} = 0 :=
      (countable_cos_eq' (-1)).measure_zero volume
    filter_upwards [measure_eq_zero_iff_ae_notMem.mp hnull] with θ hθ _
    exact hpt θ hθ
  have hmono := intervalIntegral.integral_mono_ae_restrict (by positivity : (0 : ℝ) ≤ 2 * π)
    (((hI x₁).const_mul t).add ((hI x₂).const_mul (1 - t))) (hI _)
    (by
      rw [Filter.EventuallyLE, ae_restrict_iff' measurableSet_Icc]
      have hnull : volume {θ : ℝ | Real.cos θ = -1} = 0 :=
        (countable_cos_eq' (-1)).measure_zero volume
      filter_upwards [measure_eq_zero_iff_ae_notMem.mp hnull] with θ hθ _
      exact hpt θ hθ)
  rw [intervalIntegral.integral_add ((hI x₁).const_mul t) ((hI x₂).const_mul (1 - t)),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul] at hmono
  simp only [U]
  have hπ : (0 : ℝ) < (2 * π)⁻¹ := by positivity
  have := mul_le_mul_of_nonneg_left hmono hπ.le
  linarith [this]

/-- The witness potential `W(x) = log x + h₁ log(B - x) + h₂ U_c(x)` on `[c, B]`-supported arcsine. -/
noncomputable def Wp (B h₁ h₂ c x : ℝ) : ℝ := Real.log x + h₁ * Real.log (B - x) + h₂ * U c B x

/-- Concavity of `log` in the two-point form. -/
theorem log_two_point {p r t : ℝ} (hp : 0 < p) (hr : 0 < r) (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    t * Real.log p + (1 - t) * Real.log r ≤ Real.log (t * p + (1 - t) * r) := by
  have h := (strictConcaveOn_log_Ioi.concaveOn).2 (Set.mem_Ioi.mpr hp) (Set.mem_Ioi.mpr hr)
    ht0 (by linarith : (0 : ℝ) ≤ 1 - t) (by ring)
  simpa [smul_eq_mul] using h

/-- **Three-point positivity** (proof.md Lemma 6.6′(i)): if `lo < c < hi ≤ B`, `h₁, h₂ ≥ 0`,
`h₁ = 0 ∨ hi < B`, and `W > 0` at `lo`, `c`, `hi`, then `W > 0` on `[lo, hi]`. -/
theorem Wp_pos {B h₁ h₂ c lo hi : ℝ} (hlo : 0 < lo) (hlc : lo < c) (hch : c < hi) (hhB : hi ≤ B)
    (hh₁ : 0 ≤ h₁) (hh₂ : 0 ≤ h₂) (hatom : h₁ = 0 ∨ hi < B)
    (hWlo : 0 < Wp B h₁ h₂ c lo) (hWc : 0 < Wp B h₁ h₂ c c) (hWhi : 0 < Wp B h₁ h₂ c hi) :
    ∀ x ∈ Set.Icc lo hi, 0 < Wp B h₁ h₂ c x := by
  have hcB : c < B := lt_of_lt_of_le hch hhB
  intro x ⟨hx1, hx2⟩
  rcases le_total x c with hxc | hxc
  · -- x ∈ [lo, c]: x = t lo + (1-t) c
    set t := (c - x) / (c - lo) with htdef
    have hcl : 0 < c - lo := by linarith
    have ht0 : 0 ≤ t := div_nonneg (by linarith) hcl.le
    have ht1 : t ≤ 1 := (div_le_one hcl).mpr (by linarith)
    have hx : x = t * lo + (1 - t) * c := by rw [htdef]; field_simp; ring
    have e1 : t * Real.log lo + (1 - t) * Real.log c ≤ Real.log x := by
      rw [hx]; exact log_two_point hlo (by linarith) ht0 ht1
    have e2 : t * (h₁ * Real.log (B - lo)) + (1 - t) * (h₁ * Real.log (B - c)) ≤
        h₁ * Real.log (B - x) := by
      have := log_two_point (by linarith : 0 < B - lo) (by linarith : 0 < B - c) ht0 ht1
      have e : t * (B - lo) + (1 - t) * (B - c) = B - x := by rw [hx]; ring
      rw [e] at this
      nlinarith
    have e3 : t * (h₂ * U c B lo) + (1 - t) * (h₂ * U c B c) ≤ h₂ * U c B x := by
      have := U_concave (c := c) (d := B) hcB hlc.le le_rfl ht0 ht1
      rw [← hx] at this
      nlinarith
    have : t * Wp B h₁ h₂ c lo + (1 - t) * Wp B h₁ h₂ c c ≤ Wp B h₁ h₂ c x := by
      simp only [Wp]; nlinarith
    have hpos : 0 < t * Wp B h₁ h₂ c lo + (1 - t) * Wp B h₁ h₂ c c := by
      rcases ht0.lt_or_eq with h | h
      · nlinarith
      · rw [← h]; simp; exact hWc
    linarith
  · -- x ∈ [c, hi]: U is constant there
    set t := (hi - x) / (hi - c) with htdef
    have hhc : 0 < hi - c := by linarith
    have ht0 : 0 ≤ t := div_nonneg (by linarith) hhc.le
    have ht1 : t ≤ 1 := (div_le_one hhc).mpr (by linarith)
    have hx : x = t * c + (1 - t) * hi := by rw [htdef]; field_simp; ring
    have hUc : U c B c = Real.log ((B - c) / 4) := U_inside hcB ⟨le_rfl, hcB.le⟩
    have hUx : U c B x = Real.log ((B - c) / 4) := U_inside hcB ⟨hxc, by linarith⟩
    have hUhi : U c B hi = Real.log ((B - c) / 4) := U_inside hcB ⟨hch.le, hhB⟩
    have e1 : t * Real.log c + (1 - t) * Real.log hi ≤ Real.log x := by
      rw [hx]; exact log_two_point (by linarith) (by linarith) ht0 ht1
    have e2 : t * (h₁ * Real.log (B - c)) + (1 - t) * (h₁ * Real.log (B - hi)) ≤
        h₁ * Real.log (B - x) := by
      rcases hatom with h0 | hlt
      · rw [h0]; simp
      · have := log_two_point (by linarith : 0 < B - c) (by linarith : 0 < B - hi) ht0 ht1
        have e : t * (B - c) + (1 - t) * (B - hi) = B - x := by rw [hx]; ring
        rw [e] at this
        nlinarith
    have : t * Wp B h₁ h₂ c c + (1 - t) * Wp B h₁ h₂ c hi ≤ Wp B h₁ h₂ c x := by
      simp only [Wp]; rw [hUc, hUx, hUhi]; nlinarith
    have hpos : 0 < t * Wp B h₁ h₂ c c + (1 - t) * Wp B h₁ h₂ c hi := by
      rcases ht0.lt_or_eq with h | h
      · nlinarith
      · rw [← h]; simp; exact hWhi
    linarith

/-- The arcsine measure of `[c, d]`: the image of `(2π)⁻¹ · Lebesgue` on `(0, 2π]` under
`θ ↦ (c+d)/2 + (d-c)/2 · cos θ`. -/
noncomputable def rho (c d : ℝ) : Measure ℝ :=
  ENNReal.ofReal (2 * π)⁻¹ •
    Measure.map (fun θ => (c + d) / 2 + (d - c) / 2 * Real.cos θ)
      (volume.restrict (Set.Ioc (0 : ℝ) (2 * π)))

theorem sθ_measurable (c d : ℝ) :
    Measurable (fun θ : ℝ => (c + d) / 2 + (d - c) / 2 * Real.cos θ) :=
  (by fun_prop : Continuous (fun θ : ℝ => (c + d) / 2 + (d - c) / 2 * Real.cos θ)).measurable

theorem logabs_measurable (x : ℝ) : Measurable (fun s : ℝ => Real.log |x - s|) :=
  Real.measurable_log.comp (continuous_abs.measurable.comp (measurable_const.sub measurable_id))

theorem rho_integrable {c d : ℝ} (hcd : c < d) (x : ℝ) :
    Integrable (fun s => Real.log |x - s|) (rho c d) := by
  apply Integrable.smul_measure _ ENNReal.ofReal_ne_top
  rw [integrable_map_measure (logabs_measurable x).aestronglyMeasurable
    (sθ_measurable c d).aemeasurable]
  have h := (integrand_integrable (x := x) hcd)
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le (by positivity)] at h
  exact h

theorem rho_integral {c d : ℝ} (_hcd : c < d) (x : ℝ) :
    ∫ s, Real.log |x - s| ∂(rho c d) = U c d x := by
  rw [rho, integral_smul_measure, integral_map (sθ_measurable c d).aemeasurable
    (logabs_measurable x).aestronglyMeasurable,
    ENNReal.toReal_ofReal (by positivity), smul_eq_mul, U,
    intervalIntegral.integral_of_le (by positivity)]

theorem rho_compl {c d : ℝ} (hc : 0 ≤ c) (hcd : c < d) : rho c d (Set.Icc 0 d)ᶜ = 0 := by
  rw [rho, Measure.smul_apply, Measure.map_apply (sθ_measurable c d)
    measurableSet_Icc.compl]
  have : (fun θ => (c + d) / 2 + (d - c) / 2 * Real.cos θ) ⁻¹' (Set.Icc 0 d)ᶜ = ∅ := by
    ext θ
    simp only [Set.mem_preimage, Set.mem_compl_iff, Set.mem_Icc, Set.mem_empty_iff_false,
      iff_false, not_not]
    have h1 := Real.neg_one_le_cos θ
    have h2 := Real.cos_le_one θ
    constructor <;> nlinarith
  rw [this, measure_empty, smul_zero]

theorem rho_singleton {c d : ℝ} (hcd : c < d) (s : ℝ) : rho c d {s} = 0 := by
  rw [rho, Measure.smul_apply, Measure.map_apply (sθ_measurable c d) (measurableSet_singleton s)]
  have hh : (0 : ℝ) < (d - c) / 2 := by linarith
  have hsub : (fun θ => (c + d) / 2 + (d - c) / 2 * Real.cos θ) ⁻¹' {s} ⊆
      {θ | Real.cos θ = (s - (c + d) / 2) / ((d - c) / 2)} := by
    intro θ hθ
    simp only [Set.mem_preimage, Set.mem_singleton_iff] at hθ
    simp only [Set.mem_ofPred_eq]
    rw [eq_div_iff hh.ne']
    linarith
  have hnull : volume ((fun θ => (c + d) / 2 + (d - c) / 2 * Real.cos θ) ⁻¹' {s}) = 0 :=
    measure_mono_null hsub ((countable_cos_eq' _).measure_zero volume)
  rw [Measure.restrict_apply' measurableSet_Ioc, measure_mono_null Set.inter_subset_left hnull,
    smul_zero]

/-- The witness measure `μ = δ₀ + h₁ δ_B + h₂ ρ_[c, B]` (proof.md Lemma 6.6′). -/
noncomputable def mu (B h₁ h₂ c : ℝ) : Measure ℝ :=
  Measure.dirac 0 + ENNReal.ofReal h₁ • Measure.dirac B + ENNReal.ofReal h₂ • rho c B

theorem mu_integrable {B h₁ h₂ c : ℝ} (hcB : c < B) (x : ℝ) :
    Integrable (fun s => Real.log |x - s|) (mu B h₁ h₂ c) := by
  refine ((integrable_dirac enorm_lt_top).add_measure
    ((integrable_dirac enorm_lt_top).smul_measure ENNReal.ofReal_ne_top)).add_measure
    ((rho_integrable hcB x).smul_measure ENNReal.ofReal_ne_top)

theorem mu_integral {B h₁ h₂ c x : ℝ} (hcB : c < B) (hh₁ : 0 ≤ h₁) (hh₂ : 0 ≤ h₂) (hx0 : 0 < x)
    (hxB : x ≤ B) : ∫ s, Real.log |x - s| ∂(mu B h₁ h₂ c) = Wp B h₁ h₂ c x := by
  have i0 := integrable_dirac (a := (0 : ℝ)) (f := fun s : ℝ => Real.log |x - s|) enorm_lt_top
  have iB := (integrable_dirac (a := B) (f := fun s : ℝ => Real.log |x - s|)
    enorm_lt_top).smul_measure
    (ENNReal.ofReal_ne_top (r := h₁))
  have iρ := (rho_integrable hcB x).smul_measure (ENNReal.ofReal_ne_top (r := h₂))
  rw [mu, integral_add_measure (i0.add_measure iB) iρ, integral_add_measure i0 iB,
    integral_dirac, integral_smul_measure, integral_dirac, integral_smul_measure,
    rho_integral hcB, ENNReal.toReal_ofReal hh₁, ENNReal.toReal_ofReal hh₂, smul_eq_mul,
    smul_eq_mul, Wp, sub_zero, abs_of_pos hx0, abs_sub_comm, abs_of_nonneg (by linarith)]

theorem mu_compl {B h₁ h₂ c : ℝ} (hc : 0 < c) (hcB : c < B) :
    mu B h₁ h₂ c (Set.Icc 0 B)ᶜ = 0 := by
  have hB : (0 : ℝ) ≤ B := by linarith
  simp only [mu, Measure.add_apply, Measure.smul_apply, smul_eq_mul,
    Measure.dirac_apply' _ measurableSet_Icc.compl, rho_compl hc.le hcB, mul_zero, add_zero]
  simp [Set.indicator_apply, hB]

theorem mu_atom {B h₁ h₂ c s : ℝ} (hcB : c < B) (hs : 0 < s) (hB : h₁ = 0 ∨ s ≠ B) :
    mu B h₁ h₂ c {s} = 0 := by
  simp only [mu, Measure.add_apply, Measure.smul_apply, smul_eq_mul,
    Measure.dirac_apply' _ (measurableSet_singleton s), rho_singleton hcB, mul_zero, add_zero]
  have h0 : Set.indicator {s} (1 : ℝ → ENNReal) 0 = 0 := by
    simp [Set.indicator_apply, (ne_of_lt hs)]
  rw [h0, zero_add]
  rcases hB with h | h
  · rw [h, ENNReal.ofReal_zero, zero_mul]
  · have : Set.indicator {s} (1 : ℝ → ENNReal) B = 0 := by simp [Set.indicator_apply, Ne.symm h]
    rw [this, mul_zero]

end EP1038.Arcsine
