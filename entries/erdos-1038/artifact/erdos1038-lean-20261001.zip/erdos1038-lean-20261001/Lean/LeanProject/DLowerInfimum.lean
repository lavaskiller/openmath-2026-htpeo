import LeanProject.DLowerCoverage
import LeanProject.DTargetComparison

/-!
# Numerical-D obligation 5 implies obligation 6

The actual family is nonempty and `Dval = sInf (Lam '' Qadm)`.
A uniform family lower bound therefore transfers to this real infimum.
The strict upper bound is already certified by an actual admissible witness.

The numerical lower-bound inputs remain explicit: none of the results below
claims an unconditional lower certificate for the T, M or S regions.
-/

open Real Set

namespace EP1038.DLowerCert
open EP1038.Stage9

/-- Exact rational lower endpoint, 1.8344304757. -/
noncomputable def dLowerTarget : ℝ := 18344304757 / 10000000000

/-- Exact rational upper endpoint, 1.8344304757628. -/
noncomputable def dUpperTarget : ℝ := 18344304757628 / 10000000000000

/-- Statement 5, for the actual family width and admissible parameters. -/
def NumericalFamilyLower : Prop := ∀ q ∈ Qadm, dLowerTarget ≤ Lam q

/-- Statement 6, with the already proved strict upper endpoint. -/
def NumericalDEnclosure : Prop := dLowerTarget ≤ Dval ∧ Dval < dUpperTarget

/-- A uniform lower bound passes to the infimum of the nonempty actual family. -/
theorem le_Dval_of_family_lower {L : ℝ} (hfamily : ∀ q ∈ Qadm, L ≤ Lam q) :
    L ≤ Dval := by
  apply le_csInf (Qadm_nonempty.image Lam)
  rintro y ⟨q, hq, rfl⟩
  exact hfamily q hq

/-- No positivity assumption on L is needed for the actual real infimum. -/
theorem le_Dval_iff_family_lower {L : ℝ} :
    L ≤ Dval ↔ ∀ q ∈ Qadm, L ≤ Lam q := by
  constructor
  · intro h q hq
    exact h.trans (Dval_le_Lam hq)
  · exact le_Dval_of_family_lower

/-- The previously certified actual witness supplies the strict numerical upper bound. -/
theorem Dval_lt_dUpperTarget : Dval < dUpperTarget := by
  simpa only [dUpperTarget, EP1038.ReferenceCert.pilotTarget] using
    EP1038.ReferenceCert.Dval_lt_pilotTarget

/-- The complete proved implication 5 => 6; statement 5 is its only input. -/
theorem numerical_enclosure_of_family_lower (h5 : NumericalFamilyLower) :
    NumericalDEnclosure :=
  ⟨le_Dval_of_family_lower h5, Dval_lt_dUpperTarget⟩

/-- With the upper bound already certified, statements 5 and 6 are equivalent. -/
theorem numerical_enclosure_iff_family_lower :
    NumericalDEnclosure ↔ NumericalFamilyLower := by
  constructor
  · intro h6
    exact le_Dval_iff_family_lower.mp h6.1
  · exact numerical_enclosure_of_family_lower

/-- The proved region assembler feeds directly into 5 => 6.
The numerical statements 2 and 4 remain the two explicit inputs. -/
theorem numerical_enclosure_of_region_bounds
    (hTS : ∀ q, q ∈ Qadm → q ∈ TRegion ∪ SRegion → dLowerTarget ≤ Lam q)
    (hM : ∀ q, q ∈ Qadm → q ∈ MRegion → dLowerTarget ≤ Lam q) :
    NumericalDEnclosure :=
  numerical_enclosure_of_family_lower (family_lower_of_region_bounds hTS hM)

/-- Interface for the exact replay leaves of the independent numerical certificate.
Only the actual width lower bounds on these leaves remain to be supplied. -/
theorem numerical_enclosure_of_actual_leaf_bounds
    (hT : ∀ r, 0 < r → r ≤ rho1 → tailQ r ∈ Qadm →
      ∀ s ∈ tLeaves, r ∈ Icc (dyad s.1) (dyad s.2) → dLowerTarget ≤ Lam (tailQ r))
    (hM : ∀ q, q ∈ Qadm → ∀ s ∈ mLeaves,
      q ∈ Icc (dyad s.1) (dyad s.2) → dLowerTarget ≤ Lam q)
    (hS : ∀ q, q ∈ Qadm → ∀ s ∈ sLeaves,
      q ∈ Icc (dyad s.1) (dyad s.2) → dLowerTarget ≤ Lam q) :
    NumericalDEnclosure :=
  numerical_enclosure_of_family_lower (family_lower_of_actual_leaf_bounds hT hM hS)

end EP1038.DLowerCert
