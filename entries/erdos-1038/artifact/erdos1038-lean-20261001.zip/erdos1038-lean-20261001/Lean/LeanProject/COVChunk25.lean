import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk21
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_125 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1113 : ℝ) / 1433) ((567 : ℝ) / 727))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((22448997 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((22554651 : ℝ) / 50000000) ∧ 0 < certE k a ((6978533 : ℝ) / 5000000) ∧ certE k a ((28029163 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((22448997 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((8965729 : ℝ) / 20000000) ((22414323 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22448997 : ℝ) / 50000000) ((22448997 : ℝ) / 50000000) ((22448997 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((27551003 : ℝ) / 50000000))
  have h3 : RB z3 ((4067787 : ℝ) / 5000000) ((81355743 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((27551003 : ℝ) / 50000000) ((27551003 : ℝ) / 50000000) ((27551003 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-515847 : ℝ) / 2500000) ((-165071 : ℝ) / 800000) := rb_log h3 (by norm_num) cov_log_2162.1 cov_log_2163.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-4023181 : ℝ) / 25000000) ((-1602617 : ℝ) / 10000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((22448997 : ℝ) / 50000000))
  have h6 : RB z6 ((-20019427 : ℝ) / 25000000) ((-40038853 : ℝ) / 50000000) := rb_log (show RB ((22448997 : ℝ) / 50000000) ((22448997 : ℝ) / 50000000) ((22448997 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2164.1 cov_log_2164.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((31992491 : ℝ) / 50000000) ((32025769 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-26217 : ℝ) / 20000000) ((-2581 : ℝ) / 4000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22554651 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((45039953 : ℝ) / 100000000) ((22519977 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22554651 : ℝ) / 50000000) ((22554651 : ℝ) / 50000000) ((22554651 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27445349 : ℝ) / 50000000))
  have h12 : RB z12 ((8205389 : ℝ) / 10000000) ((20513473 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((27445349 : ℝ) / 50000000) ((27445349 : ℝ) / 50000000) ((27445349 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-4944849 : ℝ) / 25000000) ((-19779393 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2165.1 cov_log_2166.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15426297 : ℝ) / 100000000) ((-15362501 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22554651 : ℝ) / 50000000))
  have h15 : RB z15 ((-19902043 : ℝ) / 25000000) ((-7960817 : ℝ) / 10000000) := rb_log (show RB ((22554651 : ℝ) / 50000000) ((22554651 : ℝ) / 50000000) ((22554651 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2167.1 cov_log_2167.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64181873 : ℝ) / 100000000) ((64245671 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((32903 : ℝ) / 50000000) ((16201 : ℝ) / 12500000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((6978533 : ℝ) / 5000000)) - (z19)
  have h20 : RB z20 ((139501311 : ℝ) / 100000000) ((544927 : ℝ) / 390625) := rb_widen (rb_sub (show RB ((6978533 : ℝ) / 5000000) ((6978533 : ℝ) / 5000000) ((6978533 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1978533 : ℝ) / 5000000))
  have h21 : RB z21 ((70507447 : ℝ) / 20000000) ((352537239 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((1978533 : ℝ) / 5000000) ((1978533 : ℝ) / 5000000) ((1978533 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((62999303 : ℝ) / 50000000) ((12599861 : ℝ) / 10000000) := rb_log h21 (by norm_num) cov_log_2168.1 cov_log_2169.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((97862141 : ℝ) / 100000000) ((49134259 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((6978533 : ℝ) / 5000000))
  have h24 : RB z24 ((416751 : ℝ) / 1250000) ((16670041 : ℝ) / 50000000) := rb_log (show RB ((6978533 : ℝ) / 5000000) ((6978533 : ℝ) / 5000000) ((6978533 : ℝ) / 5000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2170.1 cov_log_2170.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64522059 : ℝ) / 100000000) ((32464219 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((50749 : ℝ) / 12500000) ((6499 : ℝ) / 800000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((28029163 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((70038233 : ℝ) / 50000000) ((140076467 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((28029163 : ℝ) / 20000000) ((28029163 : ℝ) / 20000000) ((28029163 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8029163 : ℝ) / 20000000))
  have h30 : RB z30 ((348919223 : ℝ) / 100000000) ((348919227 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((8029163 : ℝ) / 20000000) ((8029163 : ℝ) / 20000000) ((8029163 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((4998681 : ℝ) / 4000000) ((124967029 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_2171.1 cov_log_2172.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((2426523 : ℝ) / 2500000) ((97463969 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((28029163 : ℝ) / 20000000))
  have h33 : RB z33 ((16875661 : ℝ) / 50000000) ((8437831 : ℝ) / 25000000) := rb_log (show RB ((28029163 : ℝ) / 20000000) ((28029163 : ℝ) / 20000000) ((28029163 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2173.1 cov_log_2173.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((15827399 : ℝ) / 25000000) ((63712647 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-806471 : ℝ) / 100000000) ((-50427 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((22448997 : ℝ) / 50000000)) ((-26217 : ℝ) / 20000000) ((-2581 : ℝ) / 4000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22554651 : ℝ) / 50000000)) ((32903 : ℝ) / 50000000) ((16201 : ℝ) / 12500000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((6978533 : ℝ) / 5000000)) ((50749 : ℝ) / 12500000) ((6499 : ℝ) / 800000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((28029163 : ℝ) / 20000000)) ((-806471 : ℝ) / 100000000) ((-50427 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_125 {k A q d vp vm : ℝ}
    (hk : RB k ((1113 : ℝ) / 320) ((567 : ℝ) / 160))
    (hA : RB A ((1113 : ℝ) / 1433) ((567 : ℝ) / 727))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((22448997 : ℝ) / 50000000) ((22554651 : ℝ) / 50000000))
    (hm : RB vm ((6978533 : ℝ) / 5000000) ((28029163 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((38807681 : ℝ) / 50000000) ((38968831 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((153733 : ℝ) / 100000000) ((7723 : ℝ) / 5000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((4992277 : ℝ) / 5000000) ((99846267 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27445349 : ℝ) / 50000000) ((27551003 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((54805913 : ℝ) / 100000000) ((55017297 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((141074473 : ℝ) / 100000000) ((142206667 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((41074473 : ℝ) / 100000000) ((42206667 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((38807681 : ℝ) / 50000000) ((38968831 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((24741 : ℝ) / 50000000) ((6211 : ℝ) / 12500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((12493789 : ℝ) / 12500000) ((49975259 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1978533 : ℝ) / 5000000) ((8029163 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((19775499 : ℝ) / 50000000) ((40125951 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((193429339 : ℝ) / 100000000) ((4926403 : ℝ) / 2500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((293429339 : ℝ) / 100000000) ((7426403 : ℝ) / 2500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((236929393 : ℝ) / 100000000) ((48692043 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((4207959 : ℝ) / 12500000) ((8519939 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1113 : ℝ) / 160) ((567 : ℝ) / 80) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((18318609 : ℝ) / 100000000) ((18664251 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((17848583 : ℝ) / 100000000) ((9092679 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((117848583 : ℝ) / 100000000) ((59092679 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((47230679 : ℝ) / 50000000) ((95247821 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((179352201 : ℝ) / 100000000) ((180845449 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((31332213 : ℝ) / 50000000) ((63218799 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((21939 : ℝ) / 20000000) ((27667 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24972333 : ℝ) / 25000000) ((19978061 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((35830743 : ℝ) / 20000000) ((180647071 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1433 : ℝ) / 320) ((727 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((275103 : ℝ) / 12500000) ((1116539 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2918913 : ℝ) / 50000000) ((1173061 : ℝ) / 20000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((52918913 : ℝ) / 50000000) ((21173061 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((125380459 : ℝ) / 50000000) ((2577399 : ℝ) / 1000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((375809 : ℝ) / 20000000) ((188679 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20375809 : ℝ) / 20000000) ((10188679 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((34296227 : ℝ) / 100000000) ((3472277 : ℝ) / 10000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((57011429 : ℝ) / 20000000) ((29246267 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((3136803 : ℝ) / 50000000) ((163273 : ℝ) / 2500000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1433 : ℝ) / 320) ((727 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((117848583 : ℝ) / 50000000) ((59092679 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((54118613 : ℝ) / 20000000) ((277539971 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((127556037 : ℝ) / 20000000) ((656023217 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((17065421 : ℝ) / 25000000) ((35621599 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-19091079 : ℝ) / 50000000) ((-33907083 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2174.1 cov_log_2175.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((223003681 : ℝ) / 100000000) ((227211313 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-76569591 : ℝ) / 100000000) ((-36180947 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((349497 : ℝ) / 12500000) ((4289333 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((8562273 : ℝ) / 20000000) ((34185547 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-16879113 : ℝ) / 50000000) ((-9977 : ℝ) / 250000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((117848583 : ℝ) / 100000000) ((59092679 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-19091079 : ℝ) / 50000000) ((-33907083 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-16879113 : ℝ) / 50000000) ((-9977 : ℝ) / 250000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((267 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2918913 : ℝ) / 50000000) ((1173061 : ℝ) / 20000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((21173061 : ℝ) / 40000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((267 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-1191349 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((267 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_53, cov_h_25]
  have hP : ((2651999 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((9977 : ℝ) / 250000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((9977 : ℝ) / 250000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((267 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_125 {k : ℝ} (hk : RB k ((1113 : ℝ) / 320) ((567 : ℝ) / 160)) :
    RB (k / (k + 1)) ((1113 : ℝ) / 1433) ((567 : ℝ) / 727) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1113 : ℝ) / 1433) ((567 : ℝ) / 727) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_125 {k : ℝ} (hk : RB k ((1113 : ℝ) / 320) ((567 : ℝ) / 160)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_125 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_125 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((22448997 : ℝ) / 50000000)) (ph := ((22554651 : ℝ) / 50000000)) (ml := ((6978533 : ℝ) / 5000000)) (mh := ((28029163 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_125 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_126 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((567 : ℝ) / 727) ((231 : ℝ) / 295))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((22486237 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((903433 : ℝ) / 2000000) ∧ 0 < certE k a ((139768007 : ℝ) / 100000000) ∧ certE k a ((70163137 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((22486237 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((14369 : ℝ) / 32000) ((22451563 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22486237 : ℝ) / 50000000) ((22486237 : ℝ) / 50000000) ((22486237 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((27513763 : ℝ) / 50000000))
  have h3 : RB z3 ((40800603 : ℝ) / 50000000) ((81601209 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((27513763 : ℝ) / 50000000) ((27513763 : ℝ) / 50000000) ((27513763 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-4066523 : ℝ) / 20000000) ((-2033261 : ℝ) / 10000000) := rb_log h3 (by norm_num) cov_log_2176.1 cov_log_2177.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-248773 : ℝ) / 1562500) ((-15857757 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((22486237 : ℝ) / 50000000))
  have h6 : RB z6 ((-79911959 : ℝ) / 100000000) ((-79911957 : ℝ) / 100000000) := rb_log (show RB ((22486237 : ℝ) / 50000000) ((22486237 : ℝ) / 50000000) ((22486237 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2178.1 cov_log_2178.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((12798097 : ℝ) / 20000000) ((32027101 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-62791 : ℝ) / 50000000) ((-61861 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((903433 : ℝ) / 2000000)) - (z10)
  have h11 : RB z11 ((45102301 : ℝ) / 100000000) ((22551151 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((903433 : ℝ) / 2000000) ((903433 : ℝ) / 2000000) ((903433 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((1096567 : ℝ) / 2000000))
  have h12 : RB z12 ((5141307 : ℝ) / 6250000) ((16452183 : ℝ) / 20000000) := rb_div_signed h11 (show RB ((1096567 : ℝ) / 2000000) ((1096567 : ℝ) / 2000000) ((1096567 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-9763707 : ℝ) / 50000000) ((-19527409 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2179.1 cov_log_2180.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15290959 : ℝ) / 100000000) ((-15229767 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((903433 : ℝ) / 2000000))
  have h15 : RB z15 ((-19867513 : ℝ) / 25000000) ((-1589401 : ℝ) / 2000000) := rb_log (show RB ((903433 : ℝ) / 2000000) ((903433 : ℝ) / 2000000) ((903433 : ℝ) / 2000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2181.1 cov_log_2181.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64179091 : ℝ) / 100000000) ((12848057 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((3939 : ℝ) / 6250000) ((62111 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((139768007 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((69849329 : ℝ) / 50000000) ((139698659 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((139768007 : ℝ) / 100000000) ((139768007 : ℝ) / 100000000) ((139768007 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((39768007 : ℝ) / 100000000))
  have h21 : RB z21 ((35128403 : ℝ) / 10000000) ((175642017 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((39768007 : ℝ) / 100000000) ((39768007 : ℝ) / 100000000) ((39768007 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((125642491 : ℝ) / 100000000) ((25128499 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_2182.1 cov_log_2183.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((97990773 : ℝ) / 100000000) ((98384463 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((139768007 : ℝ) / 100000000))
  have h24 : RB z24 ((1046293 : ℝ) / 3125000) ((16740689 : ℝ) / 50000000) := rb_log (show RB ((139768007 : ℝ) / 100000000) ((139768007 : ℝ) / 100000000) ((139768007 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2184.1 cov_log_2184.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((12901879 : ℝ) / 20000000) ((64903087 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((24583 : ℝ) / 6250000) ((49189 : ℝ) / 6250000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((70163137 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((5610277 : ℝ) / 4000000) ((70128463 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((70163137 : ℝ) / 50000000) ((70163137 : ℝ) / 50000000) ((70163137 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((20163137 : ℝ) / 50000000))
  have h30 : RB z30 ((86951329 : ℝ) / 25000000) ((8695133 : ℝ) / 2500000) := rb_div_signed h29 (show RB ((20163137 : ℝ) / 50000000) ((20163137 : ℝ) / 50000000) ((20163137 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((124647269 : ℝ) / 100000000) ((62323637 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_2185.1 cov_log_2186.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((48607291 : ℝ) / 50000000) ((48802577 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((70163137 : ℝ) / 50000000))
  have h33 : RB z33 ((6776001 : ℝ) / 20000000) ((33880007 : ℝ) / 100000000) := rb_log (show RB ((70163137 : ℝ) / 50000000) ((70163137 : ℝ) / 50000000) ((70163137 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2187.1 cov_log_2187.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((2533383 : ℝ) / 4000000) ((63725149 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-195373 : ℝ) / 25000000) ((-195457 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((22486237 : ℝ) / 50000000)) ((-62791 : ℝ) / 50000000) ((-61861 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((903433 : ℝ) / 2000000)) ((3939 : ℝ) / 6250000) ((62111 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((139768007 : ℝ) / 100000000)) ((24583 : ℝ) / 6250000) ((49189 : ℝ) / 6250000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((70163137 : ℝ) / 50000000)) ((-195373 : ℝ) / 25000000) ((-195457 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_126 {k A q d vp vm : ℝ}
    (hk : RB k ((567 : ℝ) / 160) ((231 : ℝ) / 64))
    (hA : RB A ((567 : ℝ) / 727) ((231 : ℝ) / 295))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((22486237 : ℝ) / 50000000) ((903433 : ℝ) / 2000000))
    (hm : RB vm ((139768007 : ℝ) / 100000000) ((70163137 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((3896883 : ℝ) / 5000000) ((39125391 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((153521 : ℝ) / 100000000) ((38551 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24961449 : ℝ) / 25000000) ((99846479 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((1096567 : ℝ) / 2000000) ((27513763 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27371901 : ℝ) / 50000000) ((6867881 : ℝ) / 12500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((70925861 : ℝ) / 50000000) ((28587997 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((20925861 : ℝ) / 50000000) ((8587997 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((3896883 : ℝ) / 5000000) ((39125391 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((49419 : ℝ) / 100000000) ((24809 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49975191 : ℝ) / 50000000) ((99950581 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((39768007 : ℝ) / 100000000) ((20163137 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((19874137 : ℝ) / 50000000) ((20153173 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((12085203 : ℝ) / 6250000) ((98432931 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((18335203 : ℝ) / 6250000) ((148432931 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((116441587 : ℝ) / 50000000) ((47787759 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33685247 : ℝ) / 100000000) ((34087433 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((567 : ℝ) / 80) ((231 : ℝ) / 32) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((18664243 : ℝ) / 100000000) ((9504943 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((18185349 : ℝ) / 100000000) ((4630531 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((118185349 : ℝ) / 100000000) ((29630531 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((94596357 : ℝ) / 100000000) ((476769 : ℝ) / 500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((179608521 : ℝ) / 100000000) ((18104667 : ℝ) / 10000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((6285713 : ℝ) / 10000000) ((31693847 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((54701 : ℝ) / 50000000) ((13791 : ℝ) / 12500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((12486209 : ℝ) / 12500000) ((49945299 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((89705181 : ℝ) / 50000000) ((90424301 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((727 : ℝ) / 160) ((295 : ℝ) / 64) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((216949 : ℝ) / 10000000) ((1100413 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5829769 : ℝ) / 100000000) ((5855591 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105829769 : ℝ) / 100000000) ((105855591 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((9858389 : ℝ) / 4000000) ((126465037 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((469157 : ℝ) / 25000000) ((942063 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((25469157 : ℝ) / 25000000) ((50942063 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((34317393 : ℝ) / 100000000) ((8682421 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((140388559 : ℝ) / 50000000) ((143829879 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((6091431 : ℝ) / 100000000) ((6330891 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((727 : ℝ) / 160) ((295 : ℝ) / 64) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((118185349 : ℝ) / 50000000) ((29630531 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((266568421 : ℝ) / 100000000) ((68256557 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((630089637 : ℝ) / 100000000) ((64719297 : ℝ) / 10000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((14041407 : ℝ) / 20000000) ((2926171 : ℝ) / 4000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-35372167 : ℝ) / 100000000) ((-31259961 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2188.1 cov_log_2189.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((113605649 : ℝ) / 50000000) ((23141893 : ℝ) / 10000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-36180987 : ℝ) / 50000000) ((-68154277 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((518889 : ℝ) / 20000000) ((2016343 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((10245181 : ℝ) / 25000000) ((13240521 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-5021 : ℝ) / 16000) ((-243959 : ℝ) / 12500000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((118185349 : ℝ) / 100000000) ((29630531 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-35372167 : ℝ) / 100000000) ((-31259961 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-5021 : ℝ) / 16000) ((-243959 : ℝ) / 12500000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((133 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5829769 : ℝ) / 100000000) ((5855591 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((105855591 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((133 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((453773 : ℝ) / 25000000) ≤ formC0 k A q vp vm + hfun ((133 : ℝ) / 50) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_54, cov_h_25]
  have hP : ((5173023 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((243959 : ℝ) / 12500000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((243959 : ℝ) / 12500000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((133 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_126 {k : ℝ} (hk : RB k ((567 : ℝ) / 160) ((231 : ℝ) / 64)) :
    RB (k / (k + 1)) ((567 : ℝ) / 727) ((231 : ℝ) / 295) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((567 : ℝ) / 727) ((231 : ℝ) / 295) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_126 {k : ℝ} (hk : RB k ((567 : ℝ) / 160) ((231 : ℝ) / 64)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_126 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_126 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((22486237 : ℝ) / 50000000)) (ph := ((903433 : ℝ) / 2000000)) (ml := ((139768007 : ℝ) / 100000000)) (mh := ((70163137 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_126 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_127 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((231 : ℝ) / 295) ((147 : ℝ) / 187))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((11260641 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((9046129 : ℝ) / 20000000) ∧ 0 < certE k a ((139959481 : ℝ) / 100000000) ∧ certE k a ((70250797 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((11260641 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((8994643 : ℝ) / 20000000) ((1405413 : ℝ) / 3125000) := rb_widen (rb_sub (show RB ((11260641 : ℝ) / 25000000) ((11260641 : ℝ) / 25000000) ((11260641 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((13739359 : ℝ) / 25000000))
  have h3 : RB z3 ((81832811 : ℝ) / 100000000) ((40916407 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((13739359 : ℝ) / 25000000) ((13739359 : ℝ) / 25000000) ((13739359 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2506149 : ℝ) / 12500000) ((-20049187 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2190.1 cov_log_2191.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-3152119 : ℝ) / 20000000) ((-3924883 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((11260641 : ℝ) / 25000000))
  have h6 : RB z6 ((-79756229 : ℝ) / 100000000) ((-79756227 : ℝ) / 100000000) := rb_log (show RB ((11260641 : ℝ) / 25000000) ((11260641 : ℝ) / 25000000) ((11260641 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2192.1 cov_log_2192.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((3999727 : ℝ) / 6250000) ((64056697 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-24087 : ℝ) / 20000000) ((-29683 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((9046129 : ℝ) / 20000000)) - (z10)
  have h11 : RB z11 ((2822581 : ℝ) / 6250000) ((45161297 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((9046129 : ℝ) / 20000000) ((9046129 : ℝ) / 20000000) ((9046129 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((10953871 : ℝ) / 20000000))
  have h12 : RB z12 ((16491447 : ℝ) / 20000000) ((41228619 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((10953871 : ℝ) / 20000000) ((10953871 : ℝ) / 20000000) ((10953871 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-241113 : ℝ) / 1250000) ((-3857807 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_2193.1 cov_log_2194.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15163043 : ℝ) / 100000000) ((-3020859 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((9046129 : ℝ) / 20000000))
  have h15 : RB z15 ((-4958721 : ℝ) / 6250000) ((-39669767 : ℝ) / 50000000) := rb_log (show RB ((9046129 : ℝ) / 20000000) ((9046129 : ℝ) / 20000000) ((9046129 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2195.1 cov_log_2195.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64176491 : ℝ) / 100000000) ((64235241 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((7553 : ℝ) / 12500000) ((59589 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((139959481 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((34972533 : ℝ) / 25000000) ((139890133 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((139959481 : ℝ) / 100000000) ((139959481 : ℝ) / 100000000) ((139959481 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((39959481 : ℝ) / 100000000))
  have h21 : RB z21 ((21879997 : ℝ) / 6250000) ((70015991 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((39959481 : ℝ) / 100000000) ((39959481 : ℝ) / 100000000) ((39959481 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((125299137 : ℝ) / 100000000) ((125299141 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2196.1 cov_log_2197.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((19623119 : ℝ) / 20000000) ((49248593 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((139959481 : ℝ) / 100000000))
  have h24 : RB z24 ((33618277 : ℝ) / 100000000) ((33618279 : ℝ) / 100000000) := rb_log (show RB ((139959481 : ℝ) / 100000000) ((139959481 : ℝ) / 100000000) ((139959481 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2198.1 cov_log_2198.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16124329 : ℝ) / 25000000) ((64878909 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((381249 : ℝ) / 100000000) ((381423 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((70250797 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((28086449 : ℝ) / 20000000) ((70216123 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((70250797 : ℝ) / 50000000) ((70250797 : ℝ) / 50000000) ((70250797 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((20250797 : ℝ) / 50000000))
  have h30 : RB z30 ((346732637 : ℝ) / 100000000) ((2167079 : ℝ) / 625000) := rb_div_signed h29 (show RB ((20250797 : ℝ) / 50000000) ((20250797 : ℝ) / 50000000) ((20250797 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((124338379 : ℝ) / 100000000) ((124338383 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_2199.1 cov_log_2200.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((97363273 : ℝ) / 100000000) ((48870969 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((70250797 : ℝ) / 50000000))
  have h33 : RB z33 ((265663 : ℝ) / 781250) ((17002433 : ℝ) / 50000000) := rb_log (show RB ((70250797 : ℝ) / 50000000) ((70250797 : ℝ) / 50000000) ((70250797 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2201.1 cov_log_2201.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63358407 : ℝ) / 100000000) ((31868537 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-37883 : ℝ) / 5000000) ((-378989 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((11260641 : ℝ) / 25000000)) ((-24087 : ℝ) / 20000000) ((-29683 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((9046129 : ℝ) / 20000000)) ((7553 : ℝ) / 12500000) ((59589 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((139959481 : ℝ) / 100000000)) ((381249 : ℝ) / 100000000) ((381423 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((70250797 : ℝ) / 50000000)) ((-37883 : ℝ) / 5000000) ((-378989 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_127 {k A q d vp vm : ℝ}
    (hk : RB k ((231 : ℝ) / 64) ((147 : ℝ) / 40))
    (hA : RB A ((231 : ℝ) / 295) ((147 : ℝ) / 187))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((11260641 : ℝ) / 25000000) ((9046129 : ℝ) / 20000000))
    (hm : RB vm ((139959481 : ℝ) / 100000000) ((70250797 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((3912539 : ℝ) / 5000000) ((9819389 : ℝ) / 12500000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((3833 : ℝ) / 2500000) ((38491 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24961509 : ℝ) / 25000000) ((2496167 : ℝ) / 2500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((10953871 : ℝ) / 20000000) ((13739359 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((54685029 : ℝ) / 100000000) ((6859147 : ℝ) / 12500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((35650743 : ℝ) / 25000000) ((1149201 : ℝ) / 800000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((10650743 : ℝ) / 25000000) ((349201 : ℝ) / 800000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((3912539 : ℝ) / 5000000) ((9819389 : ℝ) / 12500000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((49357 : ℝ) / 100000000) ((991 : ℝ) / 2000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((1999009 : ℝ) / 2000000) ((99950643 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((39959481 : ℝ) / 100000000) ((20250797 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((39939681 : ℝ) / 100000000) ((10120401 : ℝ) / 25000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((193299603 : ℝ) / 100000000) ((24585547 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((293299603 : ℝ) / 100000000) ((37085547 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((114547209 : ℝ) / 50000000) ((234725409 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33705853 : ℝ) / 100000000) ((3409483 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((231 : ℝ) / 32) ((147 : ℝ) / 20) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((19009877 : ℝ) / 100000000) ((30243 : ℝ) / 156250) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((9261057 : ℝ) / 50000000) ((1885889 : ℝ) / 10000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((59261057 : ℝ) / 50000000) ((11885889 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((23682209 : ℝ) / 25000000) ((9545903 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((179860057 : ℝ) / 100000000) ((181246469 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((31520669 : ℝ) / 50000000) ((31774889 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((109123 : ℝ) / 100000000) ((55003 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49944997 : ℝ) / 50000000) ((99890877 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((898311 : ℝ) / 500000) ((11315543 : ℝ) / 6250000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((295 : ℝ) / 64) ((187 : ℝ) / 40) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((534759 : ℝ) / 25000000) ((542373 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1164433 : ℝ) / 20000000) ((5846479 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((21164433 : ℝ) / 20000000) ((105846479 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((242432673 : ℝ) / 100000000) ((248448581 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((937143 : ℝ) / 50000000) ((470387 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50937143 : ℝ) / 50000000) ((25470387 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((34337597 : ℝ) / 100000000) ((34736341 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((27677027 : ℝ) / 10000000) ((141592461 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((1184043 : ℝ) / 20000000) ((245747 : ℝ) / 4000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((295 : ℝ) / 64) ((187 : ℝ) / 40) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((59261057 : ℝ) / 25000000) ((11885889 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((262800271 : ℝ) / 100000000) ((268820239 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((622952873 : ℝ) / 100000000) ((127806701 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((18032603 : ℝ) / 25000000) ((37522903 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-32669443 : ℝ) / 100000000) ((-28707151 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2202.1 cov_log_2203.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((115709457 : ℝ) / 50000000) ((235626547 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-34077179 : ℝ) / 50000000) ((-3197333 : ℝ) / 5000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2394359 : ℝ) / 100000000) ((236303 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((9743187 : ℝ) / 25000000) ((63863357 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-2918161 : ℝ) / 10000000) ((-83303 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((59261057 : ℝ) / 50000000) ((11885889 : ℝ) / 10000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-32669443 : ℝ) / 100000000) ((-28707151 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-2918161 : ℝ) / 10000000) ((-83303 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((133 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1164433 : ℝ) / 20000000) ((5846479 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((105846479 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((133 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((564727 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((133 : ℝ) / 50) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_54, cov_h_25]
  have hP : ((110087 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((83303 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((83303 : ℝ) / 100000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((133 : ℝ) / 50)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_127 {k : ℝ} (hk : RB k ((231 : ℝ) / 64) ((147 : ℝ) / 40)) :
    RB (k / (k + 1)) ((231 : ℝ) / 295) ((147 : ℝ) / 187) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((231 : ℝ) / 295) ((147 : ℝ) / 187) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_127 {k : ℝ} (hk : RB k ((231 : ℝ) / 64) ((147 : ℝ) / 40)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_127 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_127 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((11260641 : ℝ) / 25000000)) (ph := ((9046129 : ℝ) / 20000000)) (ml := ((139959481 : ℝ) / 100000000)) (mh := ((70250797 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_127 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_128 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((147 : ℝ) / 187) ((2373 : ℝ) / 3013))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((45137893 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((22614033 : ℝ) / 50000000) ∧ 0 < certE k a ((140232483 : ℝ) / 100000000) ∧ certE k a ((1404977 : ℝ) / 1000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((45137893 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((176049 : ℝ) / 390625) ((9013709 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((45137893 : ℝ) / 100000000) ((45137893 : ℝ) / 100000000) ((45137893 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((54862107 : ℝ) / 100000000))
  have h3 : RB z3 ((41074383 : ℝ) / 50000000) ((82148769 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((54862107 : ℝ) / 100000000) ((54862107 : ℝ) / 100000000) ((54862107 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-19663837 : ℝ) / 100000000) ((-2457979 : ℝ) / 12500000) := rb_log h3 (by norm_num) cov_log_2204.1 cov_log_2205.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-3097397 : ℝ) / 20000000) ((-120763 : ℝ) / 781250) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((45137893 : ℝ) / 100000000))
  have h6 : RB z6 ((-79544811 : ℝ) / 100000000) ((-79544809 : ℝ) / 100000000) := rb_log (show RB ((45137893 : ℝ) / 100000000) ((45137893 : ℝ) / 100000000) ((45137893 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2206.1 cov_log_2206.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((2001807 : ℝ) / 3125000) ((64087147 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-58243 : ℝ) / 100000000) ((-7229 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22614033 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((45158717 : ℝ) / 100000000) ((22579359 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22614033 : ℝ) / 50000000) ((22614033 : ℝ) / 50000000) ((22614033 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27385967 : ℝ) / 50000000))
  have h12 : RB z12 ((20612161 : ℝ) / 25000000) ((82448647 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((27385967 : ℝ) / 50000000) ((27385967 : ℝ) / 50000000) ((27385967 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-19299459 : ℝ) / 100000000) ((-9649727 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_2207.1 cov_log_2208.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-7600003 : ℝ) / 50000000) ((-3792807 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22614033 : ℝ) / 50000000))
  have h15 : RB z15 ((-39672619 : ℝ) / 50000000) ((-19836309 : ℝ) / 25000000) := rb_log (show RB ((22614033 : ℝ) / 50000000) ((22614033 : ℝ) / 50000000) ((22614033 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2209.1 cov_log_2209.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((6414523 : ℝ) / 10000000) ((6417401 : ℝ) / 10000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((29163 : ℝ) / 100000000) ((57947 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((140232483 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((70081567 : ℝ) / 50000000) ((28032627 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((140232483 : ℝ) / 100000000) ((140232483 : ℝ) / 100000000) ((140232483 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((40232483 : ℝ) / 100000000))
  have h21 : RB z21 ((174191503 : ℝ) / 50000000) ((34838301 : ℝ) / 10000000) := rb_div_signed h20 (show RB ((40232483 : ℝ) / 100000000) ((40232483 : ℝ) / 100000000) ((40232483 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((124813227 : ℝ) / 100000000) ((7800827 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_2210.1 cov_log_2211.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((9811521 : ℝ) / 10000000) ((19660259 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((140232483 : ℝ) / 100000000))
  have h24 : RB z24 ((6762629 : ℝ) / 20000000) ((33813147 : ℝ) / 100000000) := rb_log (show RB ((140232483 : ℝ) / 100000000) ((140232483 : ℝ) / 100000000) ((140232483 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2212.1 cov_log_2212.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64302063 : ℝ) / 100000000) ((1289763 : ℝ) / 2000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((46499 : ℝ) / 25000000) ((372087 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((1404977 : ℝ) / 1000000)) - (z28)
  have h29 : RB z29 ((140428351 : ℝ) / 100000000) ((2194193 : ℝ) / 1562500) := rb_widen (rb_sub (show RB ((1404977 : ℝ) / 1000000) ((1404977 : ℝ) / 1000000) ((1404977 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((404977 : ℝ) / 1000000))
  have h30 : RB z30 ((346756361 : ℝ) / 100000000) ((86689091 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((404977 : ℝ) / 1000000) ((404977 : ℝ) / 1000000) ((404977 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((124345221 : ℝ) / 100000000) ((4973809 : ℝ) / 4000000) := rb_log h30 (by norm_num) cov_log_2213.1 cov_log_2214.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((6109207 : ℝ) / 6250000) ((48966349 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((1404977 : ℝ) / 1000000))
  have h33 : RB z33 ((34002093 : ℝ) / 100000000) ((6800419 : ℝ) / 20000000) := rb_log (show RB ((1404977 : ℝ) / 1000000) ((1404977 : ℝ) / 1000000) ((1404977 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2215.1 cov_log_2215.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63745217 : ℝ) / 100000000) ((12786121 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-7417 : ℝ) / 2000000) ((-92729 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((45137893 : ℝ) / 100000000)) ((-58243 : ℝ) / 100000000) ((-7229 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22614033 : ℝ) / 50000000)) ((29163 : ℝ) / 100000000) ((57947 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((140232483 : ℝ) / 100000000)) ((46499 : ℝ) / 25000000) ((372087 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((1404977 : ℝ) / 1000000)) ((-7417 : ℝ) / 2000000) ((-92729 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_128 {k A q d vp vm : ℝ}
    (hk : RB k ((147 : ℝ) / 40) ((2373 : ℝ) / 640))
    (hA : RB A ((147 : ℝ) / 187) ((2373 : ℝ) / 3013))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((45137893 : ℝ) / 100000000) ((22614033 : ℝ) / 50000000))
    (hm : RB vm ((140232483 : ℝ) / 100000000) ((1404977 : ℝ) / 1000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((7855511 : ℝ) / 10000000) ((15740819 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((153329 : ℝ) / 100000000) ((153639 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99846361 : ℝ) / 100000000) ((99846671 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27385967 : ℝ) / 50000000) ((54862107 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27343891 : ℝ) / 50000000) ((13694497 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((17925793 : ℝ) / 12500000) ((71957659 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((5425793 : ℝ) / 12500000) ((21957659 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((7855511 : ℝ) / 10000000) ((15740819 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((24679 : ℝ) / 50000000) ((49453 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99950547 : ℝ) / 100000000) ((49975321 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((40232483 : ℝ) / 100000000) ((404977 : ℝ) / 1000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((20106293 : ℝ) / 50000000) ((2529857 : ℝ) / 6250000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((38814007 : ℝ) / 20000000) ((97860027 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((58814007 : ℝ) / 20000000) ((147860027 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((227710977 : ℝ) / 100000000) ((230381071 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6763153 : ℝ) / 20000000) ((6801101 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((147 : ℝ) / 20) ((2373 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2419439 : ℝ) / 12500000) ((19528337 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((18858881 : ℝ) / 100000000) ((19027273 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((118858881 : ℝ) / 100000000) ((119027273 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((95004417 : ℝ) / 100000000) ((95359807 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((90191649 : ℝ) / 50000000) ((7242323 : ℝ) / 4000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((15824497 : ℝ) / 25000000) ((63544393 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((109133 : ℝ) / 100000000) ((2739 : ℝ) / 2500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((2497261 : ℝ) / 2500000) ((99890867 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((18018567 : ℝ) / 10000000) ((180860481 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((187 : ℝ) / 40) ((3013 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2124127 : ℝ) / 100000000) ((1069519 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5822497 : ℝ) / 100000000) ((1458533 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105822497 : ℝ) / 100000000) ((26458533 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((240969441 : ℝ) / 100000000) ((243821807 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((937169 : ℝ) / 50000000) ((375577 : ℝ) / 20000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50937169 : ℝ) / 50000000) ((20375577 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((17224793 : ℝ) / 50000000) ((3464409 : ℝ) / 10000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((275419027 : ℝ) / 100000000) ((278465897 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5850249 : ℝ) / 100000000) ((1489123 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((187 : ℝ) / 40) ((3013 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((118858881 : ℝ) / 50000000) ((119027273 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((130763371 : ℝ) / 50000000) ((16524161 : ℝ) / 6250000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((310847759 : ℝ) / 50000000) ((78673033 : ℝ) / 12500000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((37139473 : ℝ) / 50000000) ((37862687 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-3716783 : ℝ) / 12500000) ((-27805689 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2216.1 cov_log_2217.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((235626531 : ℝ) / 100000000) ((47546071 : ℝ) / 20000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-63946741 : ℝ) / 100000000) ((-15460713 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1291283 : ℝ) / 50000000) ((1628689 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((43357163 : ℝ) / 100000000) ((27839653 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-10294789 : ℝ) / 50000000) ((-3081773 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((118858881 : ℝ) / 100000000) ((119027273 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-3716783 : ℝ) / 12500000) ((-27805689 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-10294789 : ℝ) / 50000000) ((-3081773 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((53 : ℝ) / 20) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5822497 : ℝ) / 100000000) ((1458533 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((26458533 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((53 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((764799 : ℝ) / 10000000) ≤ formC0 k A q vp vm + hfun ((53 : ℝ) / 20) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_55, cov_h_25]
  have hP : ((3253503 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((3081773 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((3081773 : ℝ) / 50000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((53 : ℝ) / 20)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_128 {k : ℝ} (hk : RB k ((147 : ℝ) / 40) ((2373 : ℝ) / 640)) :
    RB (k / (k + 1)) ((147 : ℝ) / 187) ((2373 : ℝ) / 3013) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((147 : ℝ) / 187) ((2373 : ℝ) / 3013) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_128 {k : ℝ} (hk : RB k ((147 : ℝ) / 40) ((2373 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_128 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_128 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((45137893 : ℝ) / 100000000)) (ph := ((22614033 : ℝ) / 50000000)) (ml := ((140232483 : ℝ) / 100000000)) (mh := ((1404977 : ℝ) / 1000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_128 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_129 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2373 : ℝ) / 3013) ((1197 : ℝ) / 1517))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((45168763 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((45256499 : ℝ) / 100000000) ∧ 0 < certE k a ((140322149 : ℝ) / 100000000) ∧ certE k a ((4393237 : ℝ) / 3125000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((45168763 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((22549707 : ℝ) / 50000000) ((9019883 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((45168763 : ℝ) / 100000000) ((45168763 : ℝ) / 100000000) ((45168763 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((54831237 : ℝ) / 100000000))
  have h3 : RB z3 ((16450263 : ℝ) / 20000000) ((41125659 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((54831237 : ℝ) / 100000000) ((54831237 : ℝ) / 100000000) ((54831237 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-19539081 : ℝ) / 100000000) ((-19539077 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2218.1 cov_log_2219.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-963591 : ℝ) / 6250000) ((-615549 : ℝ) / 4000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((45168763 : ℝ) / 100000000))
  have h6 : RB z6 ((-19869111 : ℝ) / 25000000) ((-39738221 : ℝ) / 50000000) := rb_log (show RB ((45168763 : ℝ) / 100000000) ((45168763 : ℝ) / 100000000) ((45168763 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2220.1 cov_log_2220.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((32029493 : ℝ) / 50000000) ((64087719 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-57081 : ℝ) / 100000000) ((-3543 : ℝ) / 12500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((45256499 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((903743 : ℝ) / 2000000) ((45187151 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((45256499 : ℝ) / 100000000) ((45256499 : ℝ) / 100000000) ((45256499 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((54743501 : ℝ) / 100000000))
  have h12 : RB z12 ((16508681 : ℝ) / 20000000) ((5158963 : ℝ) / 6250000) := rb_div_signed h11 (show RB ((54743501 : ℝ) / 100000000) ((54743501 : ℝ) / 100000000) ((54743501 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-19184591 : ℝ) / 100000000) ((-19184587 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2221.1 cov_log_2222.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15137743 : ℝ) / 100000000) ((-15109533 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((45256499 : ℝ) / 100000000))
  have h15 : RB z15 ((-9910299 : ℝ) / 12500000) ((-7928239 : ℝ) / 10000000) := rb_log (show RB ((45256499 : ℝ) / 100000000) ((45256499 : ℝ) / 100000000) ((45256499 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2223.1 cov_log_2223.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64144647 : ℝ) / 100000000) ((64172859 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1429 : ℝ) / 5000000) ((14199 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((140322149 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((43829 : ℝ) / 31250) ((140252801 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((140322149 : ℝ) / 100000000) ((140322149 : ℝ) / 100000000) ((140322149 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((40322149 : ℝ) / 100000000))
  have h21 : RB z21 ((347830667 : ℝ) / 100000000) ((34783067 : ℝ) / 10000000) := rb_div_signed h20 (show RB ((40322149 : ℝ) / 100000000) ((40322149 : ℝ) / 100000000) ((40322149 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((62327279 : ℝ) / 50000000) ((62327281 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_2224.1 cov_log_2225.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((24544081 : ℝ) / 25000000) ((98359599 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((140322149 : ℝ) / 100000000))
  have h24 : RB z24 ((6775413 : ℝ) / 20000000) ((33877067 : ℝ) / 100000000) := rb_log (show RB ((140322149 : ℝ) / 100000000) ((140322149 : ℝ) / 100000000) ((140322149 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2226.1 cov_log_2226.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64299257 : ℝ) / 100000000) ((32241267 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((18319 : ℝ) / 10000000) ((366471 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((4393237 : ℝ) / 3125000)) - (z28)
  have h29 : RB z29 ((28102847 : ℝ) / 20000000) ((35128559 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((4393237 : ℝ) / 3125000) ((4393237 : ℝ) / 3125000) ((4393237 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((1268237 : ℝ) / 3125000))
  have h30 : RB z30 ((346234169 : ℝ) / 100000000) ((86558543 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((1268237 : ℝ) / 3125000) ((1268237 : ℝ) / 3125000) ((1268237 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((62097257 : ℝ) / 50000000) ((62097259 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_2227.1 cov_log_2228.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((97813999 : ℝ) / 100000000) ((48998299 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((4393237 : ℝ) / 3125000))
  have h33 : RB z33 ((17031601 : ℝ) / 50000000) ((8515801 : ℝ) / 25000000) := rb_log (show RB ((4393237 : ℝ) / 3125000) ((4393237 : ℝ) / 3125000) ((4393237 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2229.1 cov_log_2229.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((12750159 : ℝ) / 20000000) ((15983349 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-45659 : ℝ) / 12500000) ((-182667 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((45168763 : ℝ) / 100000000)) ((-57081 : ℝ) / 100000000) ((-3543 : ℝ) / 12500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((45256499 : ℝ) / 100000000)) ((1429 : ℝ) / 5000000) ((14199 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((140322149 : ℝ) / 100000000)) ((18319 : ℝ) / 10000000) ((366471 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((4393237 : ℝ) / 3125000)) ((-45659 : ℝ) / 12500000) ((-182667 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_129 {k A q d vp vm : ℝ}
    (hk : RB k ((2373 : ℝ) / 640) ((1197 : ℝ) / 320))
    (hA : RB A ((2373 : ℝ) / 3013) ((1197 : ℝ) / 1517))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((45168763 : ℝ) / 100000000) ((45256499 : ℝ) / 100000000))
    (hm : RB vm ((140322149 : ℝ) / 100000000) ((4393237 : ℝ) / 3125000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((78704093 : ℝ) / 100000000) ((9856377 : ℝ) / 12500000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((153233 : ℝ) / 100000000) ((76767 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49923233 : ℝ) / 50000000) ((99846767 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((54743501 : ℝ) / 100000000) ((54831237 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((54659451 : ℝ) / 100000000) ((27373609 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((4492471 : ℝ) / 3125000) ((28851741 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1367471 : ℝ) / 3125000) ((8851741 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((78704093 : ℝ) / 100000000) ((9856377 : ℝ) / 12500000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((3083 : ℝ) / 6250000) ((24711 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49975289 : ℝ) / 50000000) ((6246917 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((40322149 : ℝ) / 100000000) ((1268237 : ℝ) / 3125000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((2015111 : ℝ) / 5000000) ((8112713 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((194026567 : ℝ) / 100000000) ((6114041 : ℝ) / 3125000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((294026567 : ℝ) / 100000000) ((9239041 : ℝ) / 3125000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((56486063 : ℝ) / 25000000) ((114262021 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((2113991 : ℝ) / 6250000) ((34010533 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2373 : ℝ) / 320) ((1197 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((19528329 : ℝ) / 100000000) ((9850577 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((297301 : ℝ) / 1562500) ((2399457 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((1859801 : ℝ) / 1562500) ((14899457 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((1901313 : ℝ) / 2000000) ((95414821 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((4512489 : ℝ) / 2500000) ((18116253 : ℝ) / 10000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((31690889 : ℝ) / 50000000) ((63623209 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((108997 : ℝ) / 100000000) ((21883 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19978117 : ℝ) / 20000000) ((99891003 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((90151033 : ℝ) / 50000000) ((180965069 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3013 : ℝ) / 640) ((1517 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((84377 : ℝ) / 4000000) ((2124129 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5818839 : ℝ) / 100000000) ((1166029 : ℝ) / 20000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105818839 : ℝ) / 100000000) ((21166029 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1867903 : ℝ) / 781250) ((120923663 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1873193 : ℝ) / 100000000) ((375337 : ℝ) / 20000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101873193 : ℝ) / 100000000) ((20375337 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((17228721 : ℝ) / 50000000) ((8662201 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((136774513 : ℝ) / 50000000) ((27649613 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5770311 : ℝ) / 100000000) ((1174627 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3013 : ℝ) / 640) ((1517 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((1859801 : ℝ) / 781250) ((14899457 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((64942027 : ℝ) / 25000000) ((10501383 : ℝ) / 4000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((618389743 : ℝ) / 100000000) ((312929809 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((75221541 : ℝ) / 100000000) ((76660797 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-5694651 : ℝ) / 20000000) ((-6644493 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_2230.1 cov_log_2231.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((237730339 : ℝ) / 100000000) ((59958541 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-61842933 : ℝ) / 100000000) ((-59739043 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1238989 : ℝ) / 50000000) ((1570491 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((21095871 : ℝ) / 50000000) ((6804187 : ℝ) / 12500000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-19651191 : ℝ) / 100000000) ((-5305547 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((1859801 : ℝ) / 1562500) ((14899457 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-5694651 : ℝ) / 20000000) ((-6644493 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-19651191 : ℝ) / 100000000) ((-5305547 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((66 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5818839 : ℝ) / 100000000) ((1166029 : ℝ) / 20000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((21166029 : ℝ) / 40000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((66 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((9102907 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((66 : ℝ) / 25) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_56, cov_h_25]
  have hP : ((13983207 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((5305547 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((5305547 : ℝ) / 100000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((66 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_129 {k : ℝ} (hk : RB k ((2373 : ℝ) / 640) ((1197 : ℝ) / 320)) :
    RB (k / (k + 1)) ((2373 : ℝ) / 3013) ((1197 : ℝ) / 1517) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2373 : ℝ) / 3013) ((1197 : ℝ) / 1517) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_129 {k : ℝ} (hk : RB k ((2373 : ℝ) / 640) ((1197 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_129 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_129 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((45168763 : ℝ) / 100000000)) (ph := ((45256499 : ℝ) / 100000000)) (ml := ((140322149 : ℝ) / 100000000)) (mh := ((4393237 : ℝ) / 3125000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_129 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
