import LeanProject.R1PilotActual
import LeanProject.ScalarPilotMargins

/-! Unconditional actual scalar positivity on the pilot slab at the paper's rational target. -/
open Real Set Finset Polynomial
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

noncomputable def pilotTarget : ℝ := 18344304757628 / 10000000000000

theorem pilot_log_scalar_argument : -(227 : ℝ) / 100 ≤ Real.log (519 / 5000) := by
  have h := log_bounds_of_series (x := (519 : ℝ) / 5000) (t := -(4481 : ℝ) / 5519)
    (lo := -(227 : ℝ) / 100) (hi := 0) (by norm_num) (by norm_num) 24
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact h.1

theorem pilot_log_two_lower : (693147 : ℝ) / 1000000 ≤ Real.log 2 := by
  have h := log_series_lower (x := (2 : ℝ)) (t := (1 : ℝ) / 3)
    (by norm_num) (by norm_num) (by norm_num) 8
  norm_num [sum_range_succ] at h
  linarith

theorem pilot_log_H_upper : Real.log ((2881 : ℝ) / 80000) ≤ -(33238 : ℝ) / 10000 := by
  have h := log_series_upper (x := (2881 : ℝ) / 2500) (t := (381 : ℝ) / 5381)
    (by norm_num) (by norm_num) (by norm_num) 3
  have hh : Real.log ((2881 : ℝ) / 2500) ≤ 14187 / 100000 := by
    norm_num [sum_range_succ] at h
    linarith
  have he : Real.log ((2881 : ℝ) / 80000) = Real.log (2881 / 2500) - 5 * Real.log 2 := by
    rw [show (2881 : ℝ) / 80000 = (2881 / 2500) / 2 ^ 5 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  linarith [pilot_log_two_lower]

theorem pilot_Qmax_bound {k : ℝ} (hk : k ∈ pilotSlab) :
    π / api (pilotReference hk).angles ≤ 59 / 20 := by
  have ha := (pilot_actual_bounds hk).2.2.2.2.1
  apply (div_le_iff₀ (api_pos _)).mpr
  linarith [Real.pi_lt_d4, ha.1]

theorem pilot_Rmax_bound {k : ℝ} (hk : k ∈ pilotSlab) :
    π * totalXi (pilotReference hk) / bpi (pilotReference hk) ≤ 329 / 200 := by
  let R := pilotReference hk
  obtain ⟨_, _, _, _, _, _, hp, hm⟩ := pilot_actual_bounds hk
  let tp := R.sigmaPlus * (4 * R.rhoPlus / (1 - R.rhoPlus ^ 2))
  let tm := R.sigmaMinus * (4 * R.rhoMinus / (1 - R.rhoMinus ^ 2))
  have hdp : 0 < 1 - R.rhoPlus ^ 2 := by nlinarith [R.rhoPlus_spec.1, R.rhoPlus_spec.2.1]
  have hdm : 0 < 1 - R.rhoMinus ^ 2 := by nlinarith [R.rhoMinus_spec.1, R.rhoMinus_spec.2.1]
  have htp : 0 ≤ tp := by
    dsimp [tp]
    exact mul_nonneg R.sigmaPlus_pos.le (div_nonneg (by linarith [R.rhoPlus_spec.1]) hdp.le)
  have htm : 0 ≤ tm := by
    dsimp [tm]
    exact mul_nonneg R.sigmaMinus_pos.le (div_nonneg (by linarith [R.rhoMinus_spec.1]) hdm.le)
  have hbp : bpi R = tp + tm := by
    rw [bpi, refB_eq, bpi_eq R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
      R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1]
  have hxi : totalXi R = tp * ((1 + R.rhoPlus) / 2) + tm * ((1 + R.rhoMinus) / 2) := by
    rw [totalXi_formula]
    dsimp [tp, tm]
    have hpn : 1 - R.rhoPlus ≠ 0 := by linarith [R.rhoPlus_spec.2.1]
    have hmn : 1 - R.rhoMinus ≠ 0 := by linarith [R.rhoMinus_spec.2.1]
    have hps : 1 - R.rhoPlus ^ 2 ≠ 0 := by nlinarith [R.rhoPlus_spec.1, R.rhoPlus_spec.2.1]
    have hms : 1 - R.rhoMinus ^ 2 ≠ 0 := by nlinarith [R.rhoMinus_spec.1, R.rhoMinus_spec.2.1]
    field_simp [hpn, hmn, hps, hms]
    <;> ring
  have hx : 2 * totalXi R ≤ (10461 : ℝ) / 10000 * bpi R := by
    rw [hxi, hbp]
    nlinarith [mul_nonneg htp (sub_nonneg.mpr hp.2),
      mul_nonneg htm (show (0 : ℝ) ≤ 461 / 10000 - R.rhoMinus by linarith [hm.2])]
  have hb := (bpi_pos R).le
  have hx0 := (totalXi_pos R).le
  have hpi := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hx0
  apply (div_le_iff₀ (bpi_pos R)).mpr
  nlinarith

theorem pilot_scalarC0_lower {k : ℝ} (hk : k ∈ pilotSlab) :
    -(227 : ℝ) / 100 ≤ scalarC0 (pilotReference hk) := by
  let R := pilotReference hk
  obtain ⟨_, _, hb, _, ha, _, _, _⟩ := pilot_actual_bounds hk
  have hrad : 2 * (R.r / 2) = (2 - r1A k) / 2 := by
    change 2 * (((2 - r1A k) / 2) / 2) = (2 - r1A k) / 2
    ring
  have hH : (9 : ℝ) / 125 ≤ (2 - r1A k) / 2 := by linarith [(pilot_a_bounds hk).2]
  have hprod : api R.angles * bpi R ≤ (106605 : ℝ) / 100000 * (6501 / 10000) :=
    mul_le_mul ha.2 hb.2 (bpi_pos R).le (by norm_num)
  have harg : (519 : ℝ) / 5000 ≤ 2 * (R.r / 2) / (api R.angles * bpi R) := by
    apply (le_div_iff₀ (mul_pos (api_pos _) (bpi_pos R))).mpr
    rw [hrad]
    nlinarith
  exact pilot_log_scalar_argument.trans (Real.log_le_log (by norm_num) harg)

theorem pilot_Ceff_upper {k L : ℝ} (hk : k ∈ pilotSlab) (hL : L ≤ pilotTarget) :
    calibratedCeff (pilotReference hk) L ≤ -(186 : ℝ) / 100 := by
  let R := pilotReference hk
  obtain ⟨_, _, _, hxi, _, hw, _, _⟩ := pilot_actual_bounds hk
  have hd := (pilot_reference_dictionary hk).2.2.2.2.2.2.2.2
  have hH : R.r / 2 ≤ (2881 : ℝ) / 80000 := by
    change ((2 - r1A k) / 2) / 2 ≤ (2881 : ℝ) / 80000
    unfold r1A
    linarith [hk.2]
  have hlogH := (Real.log_le_log (div_pos R.radius_pos (by norm_num)) hH).trans pilot_log_H_upper
  have hlogD : Real.log (refD0 R) ≤ (65613511 : ℝ) / 100000000 := by
    rw [hd]
    exact (Real.log_le_log (D0a_pos (r1_a_pos (pilot_slab_subset hk))) (pilot_D0_bounds hk).2).trans pilot_log_Dhi.2
  have hk0 := (r1_k_pos (pilot_slab_subset hk)).le
  have hprod := (mul_le_mul_of_nonneg_left hlogD hk0).trans
    (mul_le_mul_of_nonneg_right hk.2 (by norm_num : (0 : ℝ) ≤ 65613511 / 100000000))
  have hc : refConstant R ≤ -(21426 : ℝ) / 10000 := by
    unfold refConstant
    rw [pilotReference_k]
    linarith
  have hdiv : (L - referenceWidth R) / totalXi R ≤ (279 : ℝ) / 1000 := by
    apply (div_le_iff₀ (totalXi_pos R)).mpr
    unfold pilotTarget at hL
    linarith [hw.1, hxi.1]
  unfold calibratedCeff
  linarith

theorem pilot_scalar_P_lower {k L : ℝ} (hk : k ∈ pilotSlab) (hL : L ≤ pilotTarget) :
    (547 : ℝ) / 100 ≤ -(π * calibratedCeff (pilotReference hk) L / api (pilotReference hk).angles) := by
  let R := pilotReference hk
  have hc := pilot_Ceff_upper hk hL
  have ha := (pilot_actual_bounds hk).2.2.2.2.1
  have hpi := mul_le_mul_of_nonneg_left Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ 186 / 100)
  have hp := mul_le_mul_of_nonneg_left (show (186 : ℝ) / 100 ≤ -calibratedCeff R L by linarith) Real.pi_pos.le
  rw [← neg_div, neg_mul_eq_mul_neg]
  apply (le_div_iff₀ (api_pos R.angles)).mpr
  linarith [ha.2]

theorem pilot_scalar_margin {k L : ℝ} (hk : k ∈ pilotSlab) (hL : L ≤ pilotTarget)
    {Q V : ℝ} (hQ : Q ∈ Ioc (0 : ℝ) (π / api (pilotReference hk).angles))
    (hV : V ∈ Ioc (0 : ℝ) (π * totalXi (pilotReference hk) / bpi (pilotReference hk))) :
    (1 : ℝ) / 100 < rhs (scalarC0 (pilotReference hk))
      (calibratedCeff (pilotReference hk) L) (api (pilotReference hk).angles) Q V := by
  let R := pilotReference hk
  have hrect := rectangle_upper_bounds R
  have hQm : 0 < π / api R.angles := div_pos Real.pi_pos (api_pos _)
  have hRm : 0 < π * totalXi R / bpi R := div_pos (mul_pos Real.pi_pos (totalXi_pos R)) (bpi_pos R)
  have hhQ := hfun_nonneg hQm hrect.1
  have hhR : (1 : ℝ) / 5 ≤ hfun (π * totalXi R / bpi R) :=
    scalar_h_R_bound.trans (hfun_anti hRm (pilot_Rmax_bound hk) (by linarith [Real.pi_gt_d4]))
  have hB : -(207 : ℝ) / 100 ≤ scalarC0 R + hfun (π / api R.angles) +
      hfun (π * totalXi R / bpi R) := by linarith [pilot_scalarC0_lower hk]
  exact scalar_three_cells (api_pos _) hrect.1 hrect.2 (pilot_Qmax_bound hk)
    (pilot_Rmax_bound hk) hB (pilot_scalar_P_lower hk hL) hQ.1 hQ.2 hV.1 hV.2

theorem pilot_scalar_positive {k L : ℝ} (hk : k ∈ pilotSlab) (hL : L ≤ pilotTarget) :
    ScalarPositive (pilotReference hk) (calibratedCeff (pilotReference hk) L) := by
  intro Q V hQ hV
  exact lt_trans (by norm_num : (0 : ℝ) < 1 / 100) (pilot_scalar_margin hk hL hQ hV)

theorem pilot_normal_form_lower {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (hk : a.k ∈ pilotSlab) : pilotTarget < a.J :=
  pilot_normal_form_strict_lower a hres hk (pilot_scalar_positive hk le_rfl)

theorem pilot_polynomial_lower {p : ℝ[X]} {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (hk : a.k ∈ pilotSlab)
    (hJ : a.J ≤ (EP1038.sublevelMeasure p).toReal) :
    pilotTarget < (EP1038.sublevelMeasure p).toReal :=
  (pilot_normal_form_lower a hres hk).trans_le hJ

end EP1038.ReferenceCert
