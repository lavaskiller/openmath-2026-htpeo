import LeanProject.RefPotential

/-!
# EP-1038, Stage 10, Proposition 10.3(1)–(3) and the parameters of `I = [a, 2]`

For `0 < a < 2`: `q(a) = (√2 - √a)/(√2 + √a)` and `D₀(a) = ((√a + √2)/2)²`.

* `qa_pos`, `qa_lt_one`, `D0a_pos`; `D0a_mul_qa`: `D₀q = (2 - a)/4 = H`;
  `dth_a`: `d(θ) = D₀(1 - 2q cos θ + q²) = (a + 2)/2 - ((2 - a)/2) cos θ` (identity (K));
  `ratio_qa`: `(1 + q)/(1 - q) = √2/√a`.
* In the angle variable, `η_{k,a}` has density `((k + 1) - k P_q(θ))/π` on `[0, π]`.
  `eta_mass` (**Proposition 10.3(2)**): `(1/2π) ∫_{-π}^{π} ((k + 1) - k P_q) = 1`.
  `eta_nonneg_iff` (**Proposition 10.3(3)**): the density is `≥ 0` everywhere iff `a ≥ 2(k/(k+1))²`.
* `platform_a`: Proposition 10.3(4) in terms of `a`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- `q(a) = (√2 - √a)/(√2 + √a)`. -/
noncomputable def qa (a : ℝ) : ℝ := (√2 - √a) / (√2 + √a)

/-- `D₀(a) = ((√a + √2)/2)²`. -/
noncomputable def D0a (a : ℝ) : ℝ := ((√a + √2) / 2) ^ 2

section params

variable {a : ℝ} (ha0 : 0 < a) (ha2 : a < 2)
include ha0

include ha2 in
theorem sqrt_lt_sqrt2 : √a < √2 := Real.sqrt_lt_sqrt ha0.le ha2

include ha2 in
theorem qa_pos : 0 < qa a := by
  have hs := sqrt_lt_sqrt2 ha0 ha2
  have ha := Real.sqrt_pos.mpr ha0
  unfold qa
  exact div_pos (by linarith) (by linarith)

theorem qa_lt_one : qa a < 1 := by
  have ha := Real.sqrt_pos.mpr ha0
  have h2 := Real.sqrt_pos.mpr (show (0 : ℝ) < 2 by norm_num)
  unfold qa
  rw [div_lt_one (by linarith)]
  linarith

theorem D0a_pos : 0 < D0a a := by
  have ha := Real.sqrt_pos.mpr ha0
  have h2 := Real.sqrt_pos.mpr (show (0 : ℝ) < 2 by norm_num)
  unfold D0a
  positivity

theorem D0a_mul_qa : D0a a * qa a = (2 - a) / 4 := by
  have ha := Real.sqrt_pos.mpr ha0
  have h2 := Real.sqrt_pos.mpr (show (0 : ℝ) < 2 by norm_num)
  have hs : √a ^ 2 = a := Real.sq_sqrt ha0.le
  have ht : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have hne : √2 + √a ≠ 0 := by linarith
  unfold D0a qa
  rw [show ((√a + √2) / 2) ^ 2 * ((√2 - √a) / (√2 + √a)) = (√2 + √a) * (√2 - √a) / 4 by
    field_simp; ring]
  rw [show (√2 + √a) * (√2 - √a) = √2 ^ 2 - √a ^ 2 by ring, hs, ht]

theorem D0a_mul_one_add : D0a a * (1 + qa a ^ 2) = (a + 2) / 2 := by
  have ha := Real.sqrt_pos.mpr ha0
  have h2 := Real.sqrt_pos.mpr (show (0 : ℝ) < 2 by norm_num)
  have hs : √a ^ 2 = a := Real.sq_sqrt ha0.le
  have ht : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have hne : √2 + √a ≠ 0 := by linarith
  unfold D0a qa
  rw [show ((√a + √2) / 2) ^ 2 * (1 + ((√2 - √a) / (√2 + √a)) ^ 2) =
      ((√2 + √a) ^ 2 + (√2 - √a) ^ 2) / 4 by field_simp; ring]
  rw [show (√2 + √a) ^ 2 + (√2 - √a) ^ 2 = 2 * √2 ^ 2 + 2 * √a ^ 2 by ring, hs, ht]
  ring

/-- Identity (K): `d(θ) = (a + 2)/2 - ((2 - a)/2) cos θ`. -/
theorem dth_a (θ : ℝ) : dth (D0a a) (qa a) θ = (a + 2) / 2 - ((2 - a) / 2) * Real.cos θ := by
  have h1 := D0a_mul_qa ha0
  have h2 := D0a_mul_one_add ha0
  unfold dth
  linear_combination h2 - 2 * Real.cos θ * h1

/-- `(1 + q)/(1 - q) = √2/√a`. -/
theorem ratio_qa : (1 + qa a) / (1 - qa a) = √2 / √a := by
  have ha := Real.sqrt_pos.mpr ha0
  have h2 := Real.sqrt_pos.mpr (show (0 : ℝ) < 2 by norm_num)
  have hne : √2 + √a ≠ 0 := by linarith
  unfold qa
  rw [show 1 + (√2 - √a) / (√2 + √a) = 2 * √2 / (√2 + √a) by field_simp; ring,
    show 1 - (√2 - √a) / (√2 + √a) = 2 * √a / (√2 + √a) by field_simp; ring]
  field_simp

end params

/-- `P_q(0) = (1 + q)/(1 - q)`. -/
theorem Pq_at_zero {q : ℝ} (hq1 : q < 1) : Pq q 0 = (1 + q) / (1 - q) := by
  unfold Pq
  have h : 1 - q ≠ 0 := by linarith
  rw [Real.cos_zero, show 1 - 2 * q * 1 + q ^ 2 = (1 - q) * (1 - q) by ring,
    show 1 - q ^ 2 = (1 + q) * (1 - q) by ring, mul_div_mul_right _ _ h]

/-- **Proposition 10.3(2)**: `η_{k,a}` has total mass `1`. -/
theorem eta_mass {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (k : ℝ) :
    1 / (2 * π) * ∫ θ in (-π)..π, ((k + 1) - k * Pq q θ) = 1 := by
  rw [intervalIntegral.integral_sub intervalIntegrable_const
    (((Pq_cont hq0 hq1).intervalIntegrable _ _).const_mul k), intervalIntegral.integral_const_mul,
    int_Pq hq0 hq1, intervalIntegral.integral_const, smul_eq_mul]
  have hπ := Real.pi_pos.ne'
  field_simp
  ring

/-- **Proposition 10.3(3)**: for `k > 0` and `0 < a < 2`, the angle density `(k+1) - k P_q` of
`η_{k,a}` is nonnegative everywhere iff `a ≥ 2(k/(k+1))²`. -/
theorem eta_nonneg_iff {a k : ℝ} (ha0 : 0 < a) (ha2 : a < 2) (hk : 0 < k) :
    (∀ θ, 0 ≤ (k + 1) - k * Pq (qa a) θ) ↔ 2 * (k / (k + 1)) ^ 2 ≤ a := by
  have hq0 := (qa_pos ha0 ha2).le
  have hq1 := qa_lt_one ha0
  have hr := ratio_qa ha0
  have hsa := Real.sqrt_pos.mpr ha0
  have hs2 := Real.sqrt_pos.mpr (show (0 : ℝ) < 2 by norm_num)
  have hsq2 : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have hsqa : √a ^ 2 = a := Real.sq_sqrt ha0.le
  have hk1 : 0 < k + 1 := by linarith
  -- the condition is `k √2 ≤ (k + 1) √a`
  have key : 2 * (k / (k + 1)) ^ 2 ≤ a ↔ k * √2 ≤ (k + 1) * √a := by
    rw [div_pow, ← mul_div_assoc, div_le_iff₀ (by positivity)]
    constructor
    · intro h
      have h' : (k * √2) ^ 2 ≤ ((k + 1) * √a) ^ 2 := by
        rw [mul_pow, mul_pow, hsq2, hsqa]; linarith
      exact (pow_le_pow_iff_left₀ (by positivity) (by positivity) two_ne_zero).mp h'
    · intro h
      have h' := pow_le_pow_left₀ (by positivity) h 2
      rw [mul_pow, mul_pow, hsq2, hsqa] at h'
      linarith
  rw [key]
  constructor
  · intro h
    have h0 := h 0
    rw [Pq_at_zero hq1, hr] at h0
    rw [mul_div_assoc', sub_nonneg, div_le_iff₀ hsa] at h0
    linarith
  · intro h θ
    have hle := Pq_le hq0 hq1 θ
    rw [hr] at hle
    have hb : k * (√2 / √a) ≤ k + 1 := by
      rw [mul_div_assoc', div_le_iff₀ hsa]; linarith
    nlinarith [mul_le_mul_of_nonneg_left hle hk.le]

/-- **Proposition 10.3(4)** in terms of `a`: for `x = d(φ) = (a+2)/2 - ((2-a)/2) cos φ`,
`k log x + (1/2π) ∫ log|x - d(θ)| ((k+1) - k P_q(θ)) dθ = log H + k log D₀(a)`, `H = (2 - a)/4`. -/
theorem platform_a {a k : ℝ} (ha0 : 0 < a) (ha2 : a < 2) (φ : ℝ) :
    k * Real.log (dth (D0a a) (qa a) φ) + 1 / (2 * π) *
        ∫ θ in (-π)..π, Real.log |dth (D0a a) (qa a) φ - dth (D0a a) (qa a) θ| *
          ((k + 1) - k * Pq (qa a) θ) =
      Real.log ((2 - a) / 4) + k * Real.log (D0a a) := by
  rw [platform (D0a_pos ha0) (qa_pos ha0 ha2) (qa_lt_one ha0) φ, D0a_mul_qa ha0]

end EP1038.Arc
