import LeanProject.DLowerMTools
import LeanProject.DLowerMLog09
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_480 : RB (Real.log ((26874999999999999 : ℝ) / 1000000000000000000)) ((-3616558792534310221 : ℝ) / 1000000000000000000) ((-3616558792534310219 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((26874999999999999 : ℝ) / 31250000000000000)) (t := ((-4375000000000001 : ℝ) / 58124999999999999))
    (lo := ((-150822889734583673 : ℝ) / 1000000000000000000)) (hi := ((-18852861216822959 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((26874999999999999 : ℝ) / 1000000000000000000) = Real.log ((26874999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((26874999999999999 : ℝ) / 1000000000000000000) = ((26874999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_481 : RB (Real.log ((43 : ℝ) / 1600)) ((-452069849066788773 : ℝ) / 125000000000000000) ((-1808279396267155091 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((43 : ℝ) / 50)) (t := ((-7 : ℝ) / 93))
    (lo := ((-37705722433645909 : ℝ) / 250000000000000000)) (hi := ((-30164577946916727 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43 : ℝ) / 1600) = Real.log ((43 : ℝ) / 50) - 5 * Real.log 2 := by
    rw [show ((43 : ℝ) / 1600) = ((43 : ℝ) / 50) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_482 : RB (Real.log ((1026874999999999999 : ℝ) / 1000000000000000000)) ((26520209809395473 : ℝ) / 1000000000000000000) ((13260104904697737 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1026874999999999999 : ℝ) / 1000000000000000000)) (t := ((26874999999999999 : ℝ) / 2026874999999999999))
    (lo := ((26520209809395473 : ℝ) / 1000000000000000000)) (hi := ((13260104904697737 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_483 : RB (Real.log ((1643 : ℝ) / 1600)) ((13260104904697737 : ℝ) / 500000000000000000) ((1060808392375819 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((1643 : ℝ) / 1600)) (t := ((43 : ℝ) / 3243))
    (lo := ((13260104904697737 : ℝ) / 500000000000000000)) (hi := ((1060808392375819 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_484 : RB (Real.log ((26249999999999999 : ℝ) / 1000000000000000000)) ((-3640089289944504339 : ℝ) / 1000000000000000000) ((-3640089289944504337 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((26249999999999999 : ℝ) / 31250000000000000)) (t := ((-5000000000000001 : ℝ) / 57499999999999999))
    (lo := ((-174353387144777791 : ℝ) / 1000000000000000000)) (hi := ((-17435338714477779 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((26249999999999999 : ℝ) / 1000000000000000000) = Real.log ((26249999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((26249999999999999 : ℝ) / 1000000000000000000) = ((26249999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_485 : RB (Real.log ((11 : ℝ) / 400)) ((-898392318577402861 : ℝ) / 250000000000000000) ((-1796784637154805721 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((22 : ℝ) / 25)) (t := ((-3 : ℝ) / 47))
    (lo := ((-3994792859683903 : ℝ) / 31250000000000000)) (hi := ((-25566674301976979 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11 : ℝ) / 400) = Real.log ((22 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((11 : ℝ) / 400) = ((22 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_486 : RB (Real.log ((1026249999999999999 : ℝ) / 1000000000000000000)) ((6477845446125231 : ℝ) / 250000000000000000) ((1036455271380037 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((1026249999999999999 : ℝ) / 1000000000000000000)) (t := ((26249999999999999 : ℝ) / 2026249999999999999))
    (lo := ((6477845446125231 : ℝ) / 250000000000000000)) (hi := ((1036455271380037 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_487 : RB (Real.log ((411 : ℝ) / 400)) ((27128667388252619 : ℝ) / 1000000000000000000) ((1356433369412631 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((411 : ℝ) / 400)) (t := ((11 : ℝ) / 811))
    (lo := ((27128667388252619 : ℝ) / 1000000000000000000)) (hi := ((1356433369412631 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_488 : RB (Real.log ((114123408126587 : ℝ) / 250000000000000)) ((-156836105510369517 : ℝ) / 200000000000000000) ((-784180527551847583 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((114123408126587 : ℝ) / 125000000000000)) (t := ((-10876591873413 : ℝ) / 239123408126587))
    (lo := ((-3641333879676091 : ℝ) / 40000000000000000)) (hi := ((-45516673495951137 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114123408126587 : ℝ) / 250000000000000) = Real.log ((114123408126587 : ℝ) / 125000000000000) - 1 * Real.log 2 := by
    rw [show ((114123408126587 : ℝ) / 250000000000000) = ((114123408126587 : ℝ) / 125000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_489 : RB (Real.log ((456493632506351001 : ℝ) / 1000000000000000000)) ((-784180527551841011 : ℝ) / 1000000000000000000) ((-784180527551841009 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((456493632506351001 : ℝ) / 500000000000000000)) (t := ((-43506367493648999 : ℝ) / 956493632506351001))
    (lo := ((-91033346991895701 : ℝ) / 1000000000000000000)) (hi := ((-910333469918957 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((456493632506351001 : ℝ) / 1000000000000000000) = Real.log ((456493632506351001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((456493632506351001 : ℝ) / 1000000000000000000) = ((456493632506351001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_490 : RB (Real.log ((542784101868649 : ℝ) / 1000000000000000)) ((-611043640564858203 : ℝ) / 1000000000000000000) ((-611043640564858201 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((542784101868649 : ℝ) / 500000000000000)) (t := ((42784101868649 : ℝ) / 1042784101868649))
    (lo := ((82103539995087107 : ℝ) / 1000000000000000000)) (hi := ((20525884998771777 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((542784101868649 : ℝ) / 1000000000000000) = Real.log ((542784101868649 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((542784101868649 : ℝ) / 1000000000000000) = ((542784101868649 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_491 : RB (Real.log ((135696025467163 : ℝ) / 250000000000000)) ((-152760910141213169 : ℝ) / 250000000000000000) ((-305521820282426337 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((135696025467163 : ℝ) / 125000000000000)) (t := ((10696025467163 : ℝ) / 260696025467163))
    (lo := ((41051769997546317 : ℝ) / 500000000000000000)) (hi := ((16420707999018527 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((135696025467163 : ℝ) / 250000000000000) = Real.log ((135696025467163 : ℝ) / 125000000000000) - 1 * Real.log 2 := by
    rw [show ((135696025467163 : ℝ) / 250000000000000) = ((135696025467163 : ℝ) / 125000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_492 : RB (Real.log ((114303974532837 : ℝ) / 250000000000000)) ((-39129978742516001 : ℝ) / 50000000000000000) ((-391299787425160009 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((114303974532837 : ℝ) / 125000000000000)) (t := ((-10696025467163 : ℝ) / 239303974532837))
    (lo := ((-8945239429037471 : ℝ) / 100000000000000000)) (hi := ((-89452394290374709 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114303974532837 : ℝ) / 250000000000000) = Real.log ((114303974532837 : ℝ) / 125000000000000) - 1 * Real.log 2 := by
    rw [show ((114303974532837 : ℝ) / 250000000000000) = ((114303974532837 : ℝ) / 125000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_493 : RB (Real.log ((457215898131351 : ℝ) / 1000000000000000)) ((-391299787425156729 : ℝ) / 500000000000000000) ((-48912473428144591 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((457215898131351 : ℝ) / 500000000000000)) (t := ((-42784101868649 : ℝ) / 957215898131351))
    (lo := ((-22363098572592037 : ℝ) / 250000000000000000)) (hi := ((-89452394290368147 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457215898131351 : ℝ) / 1000000000000000) = Real.log ((457215898131351 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((457215898131351 : ℝ) / 1000000000000000) = ((457215898131351 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_494 : RB (Real.log ((456493632506348001 : ℝ) / 1000000000000000000)) ((-392090263775923791 : ℝ) / 500000000000000000) ((-39209026377592379 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((456493632506348001 : ℝ) / 500000000000000000)) (t := ((-43506367493651999 : ℝ) / 956493632506348001))
    (lo := ((-1422396046748473 : ℝ) / 15625000000000000)) (hi := ((-91033346991902271 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((456493632506348001 : ℝ) / 1000000000000000000) = Real.log ((456493632506348001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((456493632506348001 : ℝ) / 1000000000000000000) = ((456493632506348001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_495 : RB (Real.log ((456493632506351 : ℝ) / 1000000000000000)) ((-784180527551841013 : ℝ) / 1000000000000000000) ((-784180527551841011 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((456493632506351 : ℝ) / 500000000000000)) (t := ((-43506367493649 : ℝ) / 956493632506351))
    (lo := ((-91033346991895703 : ℝ) / 1000000000000000000)) (hi := ((-45516673495947851 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((456493632506351 : ℝ) / 1000000000000000) = Real.log ((456493632506351 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((456493632506351 : ℝ) / 1000000000000000) = ((456493632506351 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_496 : RB (Real.log ((284953529969207 : ℝ) / 200000000000000)) ((11062773365201443 : ℝ) / 31250000000000000) ((177004373843223089 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((284953529969207 : ℝ) / 400000000000000)) (t := ((-115046470030793 : ℝ) / 684953529969207))
    (lo := ((-339138432873499133 : ℝ) / 1000000000000000000)) (hi := ((-84784608218374783 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284953529969207 : ℝ) / 200000000000000) = Real.log ((284953529969207 : ℝ) / 400000000000000) + 1 * Real.log 2 := by
    rw [show ((284953529969207 : ℝ) / 200000000000000) = ((284953529969207 : ℝ) / 400000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_497 : RB (Real.log ((1424767649846038001 : ℝ) / 1000000000000000000)) ((177004373843224141 : ℝ) / 500000000000000000) ((88502186921612071 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424767649846038001 : ℝ) / 2000000000000000000)) (t := ((-575232350153961999 : ℝ) / 3424767649846038001))
    (lo := ((-339138432873497027 : ℝ) / 1000000000000000000)) (hi := ((-169569216436748513 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424767649846038001 : ℝ) / 1000000000000000000) = Real.log ((1424767649846038001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424767649846038001 : ℝ) / 1000000000000000000) = ((1424767649846038001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_498 : RB (Real.log ((85097983094207 : ℝ) / 200000000000000)) ((-53407126979385433 : ℝ) / 62500000000000000) ((-427257015835083463 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((85097983094207 : ℝ) / 100000000000000)) (t := ((-14902016905793 : ℝ) / 185097983094207))
    (lo := ((-80683425555110809 : ℝ) / 500000000000000000)) (hi := ((-161366851110221617 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85097983094207 : ℝ) / 200000000000000) = Real.log ((85097983094207 : ℝ) / 100000000000000) - 1 * Real.log 2 := by
    rw [show ((85097983094207 : ℝ) / 200000000000000) = ((85097983094207 : ℝ) / 100000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_499 : RB (Real.log ((212744957735519 : ℝ) / 500000000000000)) ((-427257015835079939 : ℝ) / 500000000000000000) ((-213628507917539969 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((212744957735519 : ℝ) / 250000000000000)) (t := ((-37255042264481 : ℝ) / 462744957735519))
    (lo := ((-20170856388776821 : ℝ) / 125000000000000000)) (hi := ((-161366851110214567 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212744957735519 : ℝ) / 500000000000000) = Real.log ((212744957735519 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212744957735519 : ℝ) / 500000000000000) = ((212744957735519 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_500 : RB (Real.log ((285097983094207 : ℝ) / 200000000000000)) ((35451555496537317 : ℝ) / 100000000000000000) ((88628888741343293 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((285097983094207 : ℝ) / 400000000000000)) (t := ((-114902016905793 : ℝ) / 685097983094207))
    (lo := ((-338631625594572139 : ℝ) / 1000000000000000000)) (hi := ((-169315812797286069 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285097983094207 : ℝ) / 200000000000000) = Real.log ((285097983094207 : ℝ) / 400000000000000) + 1 * Real.log 2 := by
    rw [show ((285097983094207 : ℝ) / 200000000000000) = ((285097983094207 : ℝ) / 400000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_501 : RB (Real.log ((712744957735519 : ℝ) / 500000000000000)) ((177257777482687637 : ℝ) / 500000000000000000) ((88628888741343819 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((712744957735519 : ℝ) / 1000000000000000)) (t := ((-287255042264481 : ℝ) / 1712744957735519))
    (lo := ((-67726325118914007 : ℝ) / 200000000000000000)) (hi := ((-169315812797285017 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712744957735519 : ℝ) / 500000000000000) = Real.log ((712744957735519 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712744957735519 : ℝ) / 500000000000000) = ((712744957735519 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_502 : RB (Real.log ((1424767649846035001 : ℝ) / 1000000000000000000)) ((354008747686446177 : ℝ) / 1000000000000000000) ((354008747686446179 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424767649846035001 : ℝ) / 2000000000000000000)) (t := ((-575232350153964999 : ℝ) / 3424767649846035001))
    (lo := ((-84784608218374783 : ℝ) / 250000000000000000)) (hi := ((-339138432873499131 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424767649846035001 : ℝ) / 1000000000000000000) = Real.log ((1424767649846035001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424767649846035001 : ℝ) / 1000000000000000000) = ((1424767649846035001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_503 : RB (Real.log ((712383824923019 : ℝ) / 500000000000000)) ((177004373843224141 : ℝ) / 500000000000000000) ((88502186921612071 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((712383824923019 : ℝ) / 1000000000000000)) (t := ((-287616175076981 : ℝ) / 1712383824923019))
    (lo := ((-339138432873497027 : ℝ) / 1000000000000000000)) (hi := ((-169569216436748513 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712383824923019 : ℝ) / 500000000000000) = Real.log ((712383824923019 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712383824923019 : ℝ) / 500000000000000) = ((712383824923019 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_504 : RB (Real.log ((227514557887082721 : ℝ) / 500000000000000000)) ((-787393871366053417 : ℝ) / 1000000000000000000) ((-157478774273210683 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((227514557887082721 : ℝ) / 250000000000000000)) (t := ((-22485442112917279 : ℝ) / 477514557887082721))
    (lo := ((-94246690806108107 : ℝ) / 1000000000000000000)) (hi := ((-47123345403054053 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((227514557887082721 : ℝ) / 500000000000000000) = Real.log ((227514557887082721 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((227514557887082721 : ℝ) / 500000000000000000) = ((227514557887082721 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_505 : RB (Real.log ((457957367988534129 : ℝ) / 1000000000000000000)) ((-97622397774363731 : ℝ) / 125000000000000000) ((-390489591097454923 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((457957367988534129 : ℝ) / 500000000000000000)) (t := ((-42042632011465871 : ℝ) / 957957367988534129))
    (lo := ((-43916000817482269 : ℝ) / 500000000000000000)) (hi := ((-87832001634964537 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457957367988534129 : ℝ) / 1000000000000000000) = Real.log ((457957367988534129 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((457957367988534129 : ℝ) / 1000000000000000000) = ((457957367988534129 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_506 : RB (Real.log ((33834598094466617 : ℝ) / 62500000000000000)) ((-306841332762427639 : ℝ) / 500000000000000000) ((-153420666381213819 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((33834598094466617 : ℝ) / 31250000000000000)) (t := ((2584598094466617 : ℝ) / 65084598094466617))
    (lo := ((4966532189693127 : ℝ) / 62500000000000000)) (hi := ((79464515035090033 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33834598094466617 : ℝ) / 62500000000000000) = Real.log ((33834598094466617 : ℝ) / 31250000000000000) - 1 * Real.log 2 := by
    rw [show ((33834598094466617 : ℝ) / 62500000000000000) = ((33834598094466617 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_507 : RB (Real.log ((272107317112917279 : ℝ) / 500000000000000000)) ((-608411561730617611 : ℝ) / 1000000000000000000) ((-608411561730617609 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((272107317112917279 : ℝ) / 250000000000000000)) (t := ((22107317112917279 : ℝ) / 522107317112917279))
    (lo := ((84735618829327699 : ℝ) / 1000000000000000000)) (hi := ((847356188293277 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((272107317112917279 : ℝ) / 500000000000000000) = Real.log ((272107317112917279 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((272107317112917279 : ℝ) / 500000000000000000) = ((272107317112917279 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_508 : RB (Real.log ((227892682887082721 : ℝ) / 500000000000000000)) ((-392866634684188177 : ℝ) / 500000000000000000) ((-24554164667761761 : ℝ) / 31250000000000000) := by
  have hm := log_bounds_of_series (x := ((227892682887082721 : ℝ) / 250000000000000000)) (t := ((-22107317112917279 : ℝ) / 477892682887082721))
    (lo := ((-23146522202107761 : ℝ) / 250000000000000000)) (hi := ((-92586088808431043 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((227892682887082721 : ℝ) / 500000000000000000) = Real.log ((227892682887082721 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((227892682887082721 : ℝ) / 500000000000000000) = ((227892682887082721 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_509 : RB (Real.log ((28665401905533383 : ℝ) / 62500000000000000)) ((-779475669704671697 : ℝ) / 1000000000000000000) ((-155895133940934339 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((28665401905533383 : ℝ) / 31250000000000000)) (t := ((-2584598094466617 : ℝ) / 59915401905533383))
    (lo := ((-86328489144726387 : ℝ) / 1000000000000000000)) (hi := ((-43164244572363193 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28665401905533383 : ℝ) / 62500000000000000) = Real.log ((28665401905533383 : ℝ) / 31250000000000000) - 1 * Real.log 2 := by
    rw [show ((28665401905533383 : ℝ) / 62500000000000000) = ((28665401905533383 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_510 : RB (Real.log ((227531550074582721 : ℝ) / 500000000000000000)) ((-393659594000039873 : ℝ) / 500000000000000000) ((-6150931156250623 : ℝ) / 7812500000000000) := by
  have hm := log_bounds_of_series (x := ((227531550074582721 : ℝ) / 250000000000000000)) (t := ((-22468449925417279 : ℝ) / 477531550074582721))
    (lo := ((-23543001860033609 : ℝ) / 250000000000000000)) (hi := ((-18834401488026887 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((227531550074582721 : ℝ) / 500000000000000000) = Real.log ((227531550074582721 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((227531550074582721 : ℝ) / 500000000000000000) = ((227531550074582721 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_511 : RB (Real.log ((455063100149165443 : ℝ) / 1000000000000000000)) ((-6150931156250623 : ℝ) / 7812500000000000) ((-393659594000039871 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((455063100149165443 : ℝ) / 500000000000000000)) (t := ((-44936899850834557 : ℝ) / 955063100149165443))
    (lo := ((-47086003720067217 : ℝ) / 500000000000000000)) (hi := ((-94172007440134433 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((455063100149165443 : ℝ) / 1000000000000000000) = Real.log ((455063100149165443 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((455063100149165443 : ℝ) / 1000000000000000000) = ((455063100149165443 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_512 : RB (Real.log ((455096303274165443 : ℝ) / 1000000000000000000)) ((-196811556719861403 : ℝ) / 250000000000000000) ((-78724622687944561 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((455096303274165443 : ℝ) / 500000000000000000)) (t := ((-44903696725834557 : ℝ) / 955096303274165443))
    (lo := ((-47049523159750151 : ℝ) / 500000000000000000)) (hi := ((-94099046319500301 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((455096303274165443 : ℝ) / 1000000000000000000) = Real.log ((455096303274165443 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((455096303274165443 : ℝ) / 1000000000000000000) = ((455096303274165443 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_513 : RB (Real.log ((28620260303970883 : ℝ) / 62500000000000000)) ((-781051687478232139 : ℝ) / 1000000000000000000) ((-781051687478232137 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28620260303970883 : ℝ) / 31250000000000000)) (t := ((-2629739696029117 : ℝ) / 59870260303970883))
    (lo := ((-87904506918286829 : ℝ) / 1000000000000000000)) (hi := ((-21976126729571707 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28620260303970883 : ℝ) / 62500000000000000) = Real.log ((28620260303970883 : ℝ) / 31250000000000000) - 1 * Real.log 2 := by
    rw [show ((28620260303970883 : ℝ) / 62500000000000000) = ((28620260303970883 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_514 : RB (Real.log ((457924164863534129 : ℝ) / 1000000000000000000)) ((-781051687478232137 : ℝ) / 1000000000000000000) ((-156210337495646427 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((457924164863534129 : ℝ) / 500000000000000000)) (t := ((-42075835136465871 : ℝ) / 957924164863534129))
    (lo := ((-87904506918286827 : ℝ) / 1000000000000000000)) (hi := ((-43952253459143413 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457924164863534129 : ℝ) / 1000000000000000000) = Real.log ((457924164863534129 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((457924164863534129 : ℝ) / 1000000000000000000) = ((457924164863534129 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_515 : RB (Real.log ((28618136280533383 : ℝ) / 62500000000000000)) ((-781125904212634863 : ℝ) / 1000000000000000000) ((-781125904212634861 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28618136280533383 : ℝ) / 31250000000000000)) (t := ((-2631863719466617 : ℝ) / 59868136280533383))
    (lo := ((-87978723652689553 : ℝ) / 1000000000000000000)) (hi := ((-5498670228293097 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28618136280533383 : ℝ) / 62500000000000000) = Real.log ((28618136280533383 : ℝ) / 31250000000000000) - 1 * Real.log 2 := by
    rw [show ((28618136280533383 : ℝ) / 62500000000000000) = ((28618136280533383 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_516 : RB (Real.log ((712297232554005651 : ℝ) / 500000000000000000)) ((176943593664625201 : ℝ) / 500000000000000000) ((88471796832312601 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((712297232554005651 : ℝ) / 1000000000000000000)) (t := ((-287702767445994349 : ℝ) / 1712297232554005651))
    (lo := ((-339259993230694907 : ℝ) / 1000000000000000000)) (hi := ((-169629996615347453 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712297232554005651 : ℝ) / 500000000000000000) = Real.log ((712297232554005651 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712297232554005651 : ℝ) / 500000000000000000) = ((712297232554005651 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_517 : RB (Real.log ((1424940053334060807 : ℝ) / 1000000000000000000)) ((354129744999990827 : ℝ) / 1000000000000000000) ((354129744999990829 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424940053334060807 : ℝ) / 2000000000000000000)) (t := ((-575059946665939193 : ℝ) / 3424940053334060807))
    (lo := ((-169508717779977241 : ℝ) / 500000000000000000)) (hi := ((-339017435559954481 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424940053334060807 : ℝ) / 1000000000000000000) = Real.log ((1424940053334060807 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424940053334060807 : ℝ) / 1000000000000000000) = ((1424940053334060807 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_518 : RB (Real.log ((212675357554005651 : ℝ) / 500000000000000000)) ((-427420619169553883 : ℝ) / 500000000000000000) ((-213710309584776941 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((212675357554005651 : ℝ) / 250000000000000000)) (t := ((-37324642445994349 : ℝ) / 462675357554005651))
    (lo := ((-20211757222395307 : ℝ) / 125000000000000000)) (hi := ((-32338811555832491 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212675357554005651 : ℝ) / 500000000000000000) = Real.log ((212675357554005651 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((212675357554005651 : ℝ) / 500000000000000000) = ((212675357554005651 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_519 : RB (Real.log ((212814557917030403 : ℝ) / 500000000000000000)) ((-213546733007601407 : ℝ) / 250000000000000000) ((-427093466015202813 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((212814557917030403 : ℝ) / 250000000000000000)) (t := ((-37185442082969597 : ℝ) / 462814557917030403))
    (lo := ((-80519875735230159 : ℝ) / 500000000000000000)) (hi := ((-161039751470460317 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212814557917030403 : ℝ) / 500000000000000000) = Real.log ((212814557917030403 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((212814557917030403 : ℝ) / 500000000000000000) = ((212814557917030403 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
