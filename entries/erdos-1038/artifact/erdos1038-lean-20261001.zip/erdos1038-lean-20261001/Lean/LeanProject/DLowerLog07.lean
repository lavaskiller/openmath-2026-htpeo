import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog04
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_420 : RB (Real.log ((1718661 : ℝ) / 1600000)) ((17885467507 : ℝ) / 250000000000) ((71541870029 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1718661 : ℝ) / 1600000)) (t := ((118661 : ℝ) / 3318661))
    (lo := ((17885467507 : ℝ) / 250000000000)) (hi := ((71541870029 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_421 : RB (Real.log ((73012499999 : ℝ) / 1000000000000)) ((-261712461963 : ℝ) / 100000000000) ((-654281154907 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((73012499999 : ℝ) / 62500000000)) (t := ((10512499999 : ℝ) / 135512499999))
    (lo := ((15546410261 : ℝ) / 100000000000)) (hi := ((155464102611 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((73012499999 : ℝ) / 1000000000000) = Real.log ((73012499999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((73012499999 : ℝ) / 1000000000000) = ((73012499999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_422 : RB (Real.log ((118661 : ℝ) / 1600000)) ((-1300744109997 : ℝ) / 500000000000) ((-325186027499 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((118661 : ℝ) / 100000)) (t := ((18661 : ℝ) / 218661))
    (lo := ((85550251123 : ℝ) / 500000000000)) (hi := ((171100502247 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((118661 : ℝ) / 1600000) = Real.log ((118661 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((118661 : ℝ) / 1600000) = ((118661 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_423 : RB (Real.log ((561866878161 : ℝ) / 1000000000000)) ((-576490328747 : ℝ) / 1000000000000) ((-115298065749 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((561866878161 : ℝ) / 500000000000)) (t := ((61866878161 : ℝ) / 1061866878161))
    (lo := ((116656851813 : ℝ) / 1000000000000)) (hi := ((58328425907 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((561866878161 : ℝ) / 1000000000000) = Real.log ((561866878161 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((561866878161 : ℝ) / 1000000000000) = ((561866878161 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_424 : RB (Real.log ((22485313347 : ℝ) / 40000000000)) ((-115203419633 : ℝ) / 200000000000) ((-576017098163 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((22485313347 : ℝ) / 20000000000)) (t := ((2485313347 : ℝ) / 42485313347))
    (lo := ((23426016479 : ℝ) / 200000000000)) (hi := ((29282520599 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22485313347 : ℝ) / 40000000000) = Real.log ((22485313347 : ℝ) / 20000000000) - 1 * Real.log 2 := by
    rw [show ((22485313347 : ℝ) / 40000000000) = ((22485313347 : ℝ) / 20000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_425 : RB (Real.log ((363262103323 : ℝ) / 1000000000000)) ((-1012630657547 : ℝ) / 1000000000000) ((-202526131509 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((363262103323 : ℝ) / 500000000000)) (t := ((-136737896677 : ℝ) / 863262103323))
    (lo := ((-319483476987 : ℝ) / 1000000000000)) (hi := ((-159741738493 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((363262103323 : ℝ) / 1000000000000) = Real.log ((363262103323 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((363262103323 : ℝ) / 1000000000000) = ((363262103323 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_426 : RB (Real.log ((3237478279663 : ℝ) / 1000000000000)) ((1174794718017 : ℝ) / 1000000000000) ((1174794718019 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3237478279663 : ℝ) / 4000000000000)) (t := ((-762521720337 : ℝ) / 7237478279663))
    (lo := ((-105749821551 : ℝ) / 500000000000)) (hi := ((-211499643101 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3237478279663 : ℝ) / 1000000000000) = Real.log ((3237478279663 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3237478279663 : ℝ) / 1000000000000) = ((3237478279663 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_427 : RB (Real.log ((1618929639321 : ℝ) / 500000000000)) ((234982478993 : ℝ) / 200000000000) ((1174912394967 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1618929639321 : ℝ) / 2000000000000)) (t := ((-381070360679 : ℝ) / 3618929639321))
    (lo := ((-105690983077 : ℝ) / 500000000000)) (hi := ((-211381966153 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1618929639321 : ℝ) / 500000000000) = Real.log ((1618929639321 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1618929639321 : ℝ) / 500000000000) = ((1618929639321 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_428 : RB (Real.log ((1444473512851 : ℝ) / 1000000000000)) ((367744904203 : ℝ) / 1000000000000) ((73548980841 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1444473512851 : ℝ) / 2000000000000)) (t := ((-555526487149 : ℝ) / 3444473512851))
    (lo := ((-81350569089 : ℝ) / 250000000000)) (hi := ((-65080455271 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1444473512851 : ℝ) / 1000000000000) = Real.log ((1444473512851 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1444473512851 : ℝ) / 1000000000000) = ((1444473512851 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_429 : RB (Real.log ((1074163124999 : ℝ) / 1000000000000)) ((71541870027 : ℝ) / 1000000000000) ((17885467507 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1074163124999 : ℝ) / 1000000000000)) (t := ((74163124999 : ℝ) / 2074163124999))
    (lo := ((71541870027 : ℝ) / 1000000000000)) (hi := ((17885467507 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_430 : RB (Real.log ((860251 : ℝ) / 800000)) ((72612479461 : ℝ) / 1000000000000) ((36306239731 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((860251 : ℝ) / 800000)) (t := ((60251 : ℝ) / 1660251))
    (lo := ((72612479461 : ℝ) / 1000000000000)) (hi := ((36306239731 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_431 : RB (Real.log ((74163124999 : ℝ) / 1000000000000)) ((-2601488220007 : ℝ) / 1000000000000) ((-520297644001 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((74163124999 : ℝ) / 62500000000)) (t := ((11663124999 : ℝ) / 136663124999))
    (lo := ((171100502233 : ℝ) / 1000000000000)) (hi := ((85550251117 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((74163124999 : ℝ) / 1000000000000) = Real.log ((74163124999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((74163124999 : ℝ) / 1000000000000) = ((74163124999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_432 : RB (Real.log ((60251 : ℝ) / 800000)) ((-103443702317 : ℝ) / 40000000000) ((-2586092557923 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((60251 : ℝ) / 50000)) (t := ((10251 : ℝ) / 110251))
    (lo := ((37299232863 : ℝ) / 200000000000)) (hi := ((46624041079 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((60251 : ℝ) / 800000) = Real.log ((60251 : ℝ) / 50000) - 4 * Real.log 2 := by
    rw [show ((60251 : ℝ) / 800000) = ((60251 : ℝ) / 50000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_433 : RB (Real.log ((277294461781 : ℝ) / 500000000000)) ((-589528117941 : ℝ) / 1000000000000) ((-589528117939 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((277294461781 : ℝ) / 250000000000)) (t := ((27294461781 : ℝ) / 527294461781))
    (lo := ((103619062619 : ℝ) / 1000000000000)) (hi := ((5180953131 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((277294461781 : ℝ) / 500000000000) = Real.log ((277294461781 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((277294461781 : ℝ) / 500000000000) = ((277294461781 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_434 : RB (Real.log ((554857825413 : ℝ) / 1000000000000)) ((-589043368481 : ℝ) / 1000000000000) ((-589043368479 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((554857825413 : ℝ) / 500000000000)) (t := ((54857825413 : ℝ) / 1054857825413))
    (lo := ((104103812079 : ℝ) / 1000000000000)) (hi := ((1301297651 : ℝ) / 12500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((554857825413 : ℝ) / 1000000000000) = Real.log ((554857825413 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((554857825413 : ℝ) / 1000000000000) = ((554857825413 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_435 : RB (Real.log ((360391789759 : ℝ) / 1000000000000)) ((-1020563534421 : ℝ) / 1000000000000) ((-1020563534419 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((360391789759 : ℝ) / 500000000000)) (t := ((-139608210241 : ℝ) / 860391789759))
    (lo := ((-327416353861 : ℝ) / 1000000000000)) (hi := ((-16370817693 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((360391789759 : ℝ) / 1000000000000) = Real.log ((360391789759 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((360391789759 : ℝ) / 1000000000000) = ((360391789759 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_436 : RB (Real.log ((646608880321 : ℝ) / 200000000000)) ((1173424232519 : ℝ) / 1000000000000) ((1173424232521 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((646608880321 : ℝ) / 800000000000)) (t := ((-153391119679 : ℝ) / 1446608880321))
    (lo := ((-1064350643 : ℝ) / 5000000000)) (hi := ((-212870128599 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((646608880321 : ℝ) / 200000000000) = Real.log ((646608880321 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((646608880321 : ℝ) / 200000000000) = ((646608880321 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_437 : RB (Real.log ((3233430657909 : ℝ) / 1000000000000)) ((1173543696771 : ℝ) / 1000000000000) ((1173543696773 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3233430657909 : ℝ) / 4000000000000)) (t := ((-766569342091 : ℝ) / 7233430657909))
    (lo := ((-53187666087 : ℝ) / 250000000000)) (hi := ((-212750664347 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3233430657909 : ℝ) / 1000000000000) = Real.log ((3233430657909 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3233430657909 : ℝ) / 1000000000000) = ((3233430657909 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_438 : RB (Real.log ((722639513649 : ℝ) / 500000000000)) ((184151200699 : ℝ) / 500000000000) ((1841512007 : ℝ) / 5000000000) := by
  have hm := log_bounds_of_series (x := ((722639513649 : ℝ) / 1000000000000)) (t := ((-277360486351 : ℝ) / 1722639513649))
    (lo := ((-324844779161 : ℝ) / 1000000000000)) (hi := ((-8121119479 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((722639513649 : ℝ) / 500000000000) = Real.log ((722639513649 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((722639513649 : ℝ) / 500000000000) = ((722639513649 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_439 : RB (Real.log ((1075313749999 : ℝ) / 1000000000000)) ((3630623973 : ℝ) / 50000000000) ((72612479461 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1075313749999 : ℝ) / 1000000000000)) (t := ((75313749999 : ℝ) / 2075313749999))
    (lo := ((3630623973 : ℝ) / 50000000000)) (hi := ((72612479461 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_440 : RB (Real.log ((1722343 : ℝ) / 1600000)) ((18420485979 : ℝ) / 250000000000) ((73681943917 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1722343 : ℝ) / 1600000)) (t := ((122343 : ℝ) / 3322343))
    (lo := ((18420485979 : ℝ) / 250000000000)) (hi := ((73681943917 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_441 : RB (Real.log ((75313749999 : ℝ) / 1000000000000)) ((-2586092557939 : ℝ) / 1000000000000) ((-2586092557937 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((75313749999 : ℝ) / 62500000000)) (t := ((12813749999 : ℝ) / 137813749999))
    (lo := ((186496164301 : ℝ) / 1000000000000)) (hi := ((93248082151 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((75313749999 : ℝ) / 1000000000000) = Real.log ((75313749999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((75313749999 : ℝ) / 1000000000000) = ((75313749999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_442 : RB (Real.log ((122343 : ℝ) / 1600000)) ((-257093033289 : ℝ) / 100000000000) ((-321366291611 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((122343 : ℝ) / 100000)) (t := ((22343 : ℝ) / 222343))
    (lo := ((4033167787 : ℝ) / 20000000000)) (hi := ((201658389351 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((122343 : ℝ) / 1600000) = Real.log ((122343 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((122343 : ℝ) / 1600000) = ((122343 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_443 : RB (Real.log ((21892714067 : ℝ) / 40000000000)) ((-602725563651 : ℝ) / 1000000000000) ((-602725563649 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((21892714067 : ℝ) / 20000000000)) (t := ((1892714067 : ℝ) / 41892714067))
    (lo := ((90421616909 : ℝ) / 1000000000000)) (hi := ((9042161691 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21892714067 : ℝ) / 40000000000) = Real.log ((21892714067 : ℝ) / 20000000000) - 1 * Real.log 2 := by
    rw [show ((21892714067 : ℝ) / 40000000000) = ((21892714067 : ℝ) / 20000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_444 : RB (Real.log ((109517932809 : ℝ) / 200000000000)) ((-150557265189 : ℝ) / 250000000000) ((-301114530377 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((109517932809 : ℝ) / 100000000000)) (t := ((9517932809 : ℝ) / 209517932809))
    (lo := ((22729529951 : ℝ) / 250000000000)) (hi := ((18183623961 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((109517932809 : ℝ) / 200000000000) = Real.log ((109517932809 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((109517932809 : ℝ) / 200000000000) = ((109517932809 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_445 : RB (Real.log ((35749904373 : ℝ) / 100000000000)) ((-1028622591733 : ℝ) / 1000000000000) ((-1028622591731 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((35749904373 : ℝ) / 50000000000)) (t := ((-14250095627 : ℝ) / 85749904373))
    (lo := ((-335475411173 : ℝ) / 1000000000000)) (hi := ((-83868852793 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35749904373 : ℝ) / 100000000000) = Real.log ((35749904373 : ℝ) / 50000000000) - 1 * Real.log 2 := by
    rw [show ((35749904373 : ℝ) / 100000000000) = ((35749904373 : ℝ) / 50000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_446 : RB (Real.log ((3228579630681 : ℝ) / 1000000000000)) ((234408459539 : ℝ) / 200000000000) ((1172042297697 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3228579630681 : ℝ) / 4000000000000)) (t := ((-771420369319 : ℝ) / 7228579630681))
    (lo := ((-3347688491 : ℝ) / 15625000000)) (hi := ((-214252063423 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3228579630681 : ℝ) / 1000000000000) = Real.log ((3228579630681 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3228579630681 : ℝ) / 1000000000000) = ((3228579630681 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_447 : RB (Real.log ((5166353789 : ℝ) / 1600000000)) ((1172163547209 : ℝ) / 1000000000000) ((1172163547211 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((5166353789 : ℝ) / 6400000000)) (t := ((-1233646211 : ℝ) / 11566353789))
    (lo := ((-21413081391 : ℝ) / 100000000000)) (hi := ((-214130813909 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5166353789 : ℝ) / 1600000000) = Real.log ((5166353789 : ℝ) / 6400000000) + 2 * Real.log 2 := by
    rw [show ((5166353789 : ℝ) / 1600000000) = ((5166353789 : ℝ) / 6400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_448 : RB (Real.log ((1446092742511 : ℝ) / 1000000000000)) ((368865258961 : ℝ) / 1000000000000) ((368865258963 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1446092742511 : ℝ) / 2000000000000)) (t := ((-553907257489 : ℝ) / 3446092742511))
    (lo := ((-162140960799 : ℝ) / 500000000000)) (hi := ((-324281921597 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1446092742511 : ℝ) / 1000000000000) = Real.log ((1446092742511 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1446092742511 : ℝ) / 1000000000000) = ((1446092742511 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_449 : RB (Real.log ((1076464374999 : ℝ) / 1000000000000)) ((14736388783 : ℝ) / 200000000000) ((18420485979 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1076464374999 : ℝ) / 1000000000000)) (t := ((76464374999 : ℝ) / 2076464374999))
    (lo := ((14736388783 : ℝ) / 200000000000)) (hi := ((18420485979 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_450 : RB (Real.log ((215523 : ℝ) / 200000)) ((37375132919 : ℝ) / 500000000000) ((74750265839 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((215523 : ℝ) / 200000)) (t := ((15523 : ℝ) / 415523))
    (lo := ((37375132919 : ℝ) / 500000000000)) (hi := ((74750265839 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_451 : RB (Real.log ((76464374999 : ℝ) / 1000000000000)) ((-2570930332903 : ℝ) / 1000000000000) ((-2570930332901 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((76464374999 : ℝ) / 62500000000)) (t := ((13964374999 : ℝ) / 138964374999))
    (lo := ((201658389337 : ℝ) / 1000000000000)) (hi := ((100829194669 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((76464374999 : ℝ) / 1000000000000) = Real.log ((76464374999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((76464374999 : ℝ) / 1000000000000) = ((76464374999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_452 : RB (Real.log ((15523 : ℝ) / 200000)) ((-159749660719 : ℝ) / 62500000000) ((-1277997285751 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((15523 : ℝ) / 12500)) (t := ((3023 : ℝ) / 28023))
    (lo := ((13537134421 : ℝ) / 62500000000)) (hi := ((216594150737 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15523 : ℝ) / 200000) = Real.log ((15523 : ℝ) / 12500) - 4 * Real.log 2 := by
    rw [show ((15523 : ℝ) / 200000) = ((15523 : ℝ) / 12500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_453 : RB (Real.log ((540054261681 : ℝ) / 1000000000000)) ((-308042829939 : ℝ) / 500000000000) ((-154021414969 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((540054261681 : ℝ) / 500000000000)) (t := ((40054261681 : ℝ) / 1040054261681))
    (lo := ((38530760341 : ℝ) / 500000000000)) (hi := ((77061520683 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540054261681 : ℝ) / 1000000000000) = Real.log ((540054261681 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((540054261681 : ℝ) / 1000000000000) = ((540054261681 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_454 : RB (Real.log ((540328948919 : ℝ) / 1000000000000)) ((-24623086409 : ℝ) / 40000000000) ((-615577160223 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((540328948919 : ℝ) / 500000000000)) (t := ((40328948919 : ℝ) / 1040328948919))
    (lo := ((15514004067 : ℝ) / 200000000000)) (hi := ((4848126271 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540328948919 : ℝ) / 1000000000000) = Real.log ((540328948919 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((540328948919 : ℝ) / 1000000000000) = ((540328948919 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_455 : RB (Real.log ((354583837397 : ℝ) / 1000000000000)) ((-518405233099 : ℝ) / 500000000000) ((-259202616549 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((354583837397 : ℝ) / 500000000000)) (t := ((-145416162603 : ℝ) / 854583837397))
    (lo := ((-171831642819 : ℝ) / 500000000000)) (hi := ((-343663285637 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((354583837397 : ℝ) / 1000000000000) = Real.log ((354583837397 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((354583837397 : ℝ) / 1000000000000) = ((354583837397 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_456 : RB (Real.log ((3224084970187 : ℝ) / 1000000000000)) ((1170649179813 : ℝ) / 1000000000000) ((234129835963 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3224084970187 : ℝ) / 4000000000000)) (t := ((-775915029813 : ℝ) / 7224084970187))
    (lo := ((-107822590653 : ℝ) / 500000000000)) (hi := ((-43129036261 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3224084970187 : ℝ) / 1000000000000) = Real.log ((3224084970187 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3224084970187 : ℝ) / 1000000000000) = ((3224084970187 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_457 : RB (Real.log ((644896332509 : ℝ) / 200000000000)) ((146346526567 : ℝ) / 125000000000) ((585386106269 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((644896332509 : ℝ) / 800000000000)) (t := ((-155103667491 : ℝ) / 1444896332509))
    (lo := ((-215522148583 : ℝ) / 1000000000000)) (hi := ((-107761074291 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((644896332509 : ℝ) / 200000000000) = Real.log ((644896332509 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((644896332509 : ℝ) / 200000000000) = ((644896332509 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_458 : RB (Real.log ((1446914540181 : ℝ) / 1000000000000)) ((23089586619 : ℝ) / 62500000000) ((369433385907 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1446914540181 : ℝ) / 2000000000000)) (t := ((-553085459819 : ℝ) / 3446914540181))
    (lo := ((-64742758931 : ℝ) / 200000000000)) (hi := ((-323713794653 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1446914540181 : ℝ) / 1000000000000) = Real.log ((1446914540181 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1446914540181 : ℝ) / 1000000000000) = ((1446914540181 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_459 : RB (Real.log ((1077614999999 : ℝ) / 1000000000000)) ((37375132919 : ℝ) / 500000000000) ((74750265839 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1077614999999 : ℝ) / 1000000000000)) (t := ((77614999999 : ℝ) / 2077614999999))
    (lo := ((37375132919 : ℝ) / 500000000000)) (hi := ((74750265839 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_460 : RB (Real.log ((69041 : ℝ) / 64000)) ((75817447667 : ℝ) / 1000000000000) ((18954361917 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((69041 : ℝ) / 64000)) (t := ((5041 : ℝ) / 133041))
    (lo := ((75817447667 : ℝ) / 1000000000000)) (hi := ((18954361917 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_461 : RB (Real.log ((77614999999 : ℝ) / 1000000000000)) ((-2555994571517 : ℝ) / 1000000000000) ((-511198914303 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((77614999999 : ℝ) / 62500000000)) (t := ((15114999999 : ℝ) / 140114999999))
    (lo := ((216594150723 : ℝ) / 1000000000000)) (hi := ((54148537681 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((77614999999 : ℝ) / 1000000000000) = Real.log ((77614999999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((77614999999 : ℝ) / 1000000000000) = ((77614999999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_462 : RB (Real.log ((5041 : ℝ) / 64000)) ((-127063930413 : ℝ) / 50000000000) ((-1270639304129 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((5041 : ℝ) / 4000)) (t := ((1041 : ℝ) / 9041))
    (lo := ((11565505699 : ℝ) / 50000000000)) (hi := ((231310113981 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5041 : ℝ) / 64000) = Real.log ((5041 : ℝ) / 4000) - 4 * Real.log 2 := by
    rw [show ((5041 : ℝ) / 64000) = ((5041 : ℝ) / 4000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_463 : RB (Real.log ((266399401799 : ℝ) / 500000000000)) ((-314805702629 : ℝ) / 500000000000) ((-78701425657 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((266399401799 : ℝ) / 250000000000)) (t := ((16399401799 : ℝ) / 516399401799))
    (lo := ((31767887651 : ℝ) / 500000000000)) (hi := ((63535775303 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((266399401799 : ℝ) / 500000000000) = Real.log ((266399401799 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((266399401799 : ℝ) / 500000000000) = ((266399401799 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_464 : RB (Real.log ((106615266047 : ℝ) / 200000000000)) ((-314545328187 : ℝ) / 500000000000) ((-157272664093 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((106615266047 : ℝ) / 100000000000)) (t := ((6615266047 : ℝ) / 206615266047))
    (lo := ((32028262093 : ℝ) / 500000000000)) (hi := ((64056524187 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((106615266047 : ℝ) / 200000000000) = Real.log ((106615266047 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((106615266047 : ℝ) / 200000000000) = ((106615266047 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_465 : RB (Real.log ((43955771137 : ℝ) / 125000000000)) ((-104512981037 : ℝ) / 100000000000) ((-16330153287 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((43955771137 : ℝ) / 62500000000)) (t := ((-18544228863 : ℝ) / 106455771137))
    (lo := ((-35198262981 : ℝ) / 100000000000)) (hi := ((-351982629809 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43955771137 : ℝ) / 125000000000) = Real.log ((43955771137 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((43955771137 : ℝ) / 125000000000) = ((43955771137 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_466 : RB (Real.log ((804890347849 : ℝ) / 250000000000)) ((46769805457 : ℝ) / 40000000000) ((1169245136427 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((804890347849 : ℝ) / 1000000000000)) (t := ((-195109652151 : ℝ) / 1804890347849))
    (lo := ((-108524612347 : ℝ) / 500000000000)) (hi := ((-217049224693 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((804890347849 : ℝ) / 250000000000) = Real.log ((804890347849 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((804890347849 : ℝ) / 250000000000) = ((804890347849 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_467 : RB (Real.log ((321996326241 : ℝ) / 100000000000)) ((11693699503 : ℝ) / 10000000000) ((584684975151 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((321996326241 : ℝ) / 400000000000)) (t := ((-78003673759 : ℝ) / 721996326241))
    (lo := ((-216924410819 : ℝ) / 1000000000000)) (hi := ((-108462205409 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((321996326241 : ℝ) / 100000000000) = Real.log ((321996326241 : ℝ) / 400000000000) + 2 * Real.log 2 := by
    rw [show ((321996326241 : ℝ) / 100000000000) = ((321996326241 : ℝ) / 400000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_468 : RB (Real.log ((1447744306677 : ℝ) / 1000000000000)) ((370006694583 : ℝ) / 1000000000000) ((74001338917 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1447744306677 : ℝ) / 2000000000000)) (t := ((-552255693323 : ℝ) / 3447744306677))
    (lo := ((-40392560747 : ℝ) / 125000000000)) (hi := ((-12925619439 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1447744306677 : ℝ) / 1000000000000) = Real.log ((1447744306677 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1447744306677 : ℝ) / 1000000000000) = ((1447744306677 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_469 : RB (Real.log ((1078765624999 : ℝ) / 1000000000000)) ((37908723833 : ℝ) / 500000000000) ((75817447667 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1078765624999 : ℝ) / 1000000000000)) (t := ((78765624999 : ℝ) / 2078765624999))
    (lo := ((37908723833 : ℝ) / 500000000000)) (hi := ((75817447667 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_470 : RB (Real.log ((863933 : ℝ) / 800000)) ((9610436479 : ℝ) / 125000000000) ((76883491833 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((863933 : ℝ) / 800000)) (t := ((63933 : ℝ) / 1663933))
    (lo := ((9610436479 : ℝ) / 125000000000)) (hi := ((76883491833 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_471 : RB (Real.log ((78765624999 : ℝ) / 1000000000000)) ((-2541278608273 : ℝ) / 1000000000000) ((-2541278608271 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((78765624999 : ℝ) / 62500000000)) (t := ((16265624999 : ℝ) / 141265624999))
    (lo := ((231310113967 : ℝ) / 1000000000000)) (hi := ((14456882123 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((78765624999 : ℝ) / 1000000000000) = Real.log ((78765624999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((78765624999 : ℝ) / 1000000000000) = ((78765624999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_472 : RB (Real.log ((63933 : ℝ) / 800000)) ((-505355213533 : ℝ) / 200000000000) ((-2526776067663 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((63933 : ℝ) / 50000)) (t := ((13933 : ℝ) / 113933))
    (lo := ((9832506183 : ℝ) / 40000000000)) (hi := ((15363290911 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63933 : ℝ) / 800000) = Real.log ((63933 : ℝ) / 50000) - 4 * Real.log 2 := by
    rw [show ((63933 : ℝ) / 800000) = ((63933 : ℝ) / 50000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_473 : RB (Real.log ((131388047103 : ℝ) / 250000000000)) ((-643305781681 : ℝ) / 1000000000000) ((-643305781679 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((131388047103 : ℝ) / 125000000000)) (t := ((6388047103 : ℝ) / 256388047103))
    (lo := ((49841398879 : ℝ) / 1000000000000)) (hi := ((311508743 : ℝ) / 6250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((131388047103 : ℝ) / 250000000000) = Real.log ((131388047103 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((131388047103 : ℝ) / 250000000000) = ((131388047103 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_474 : RB (Real.log ((26291625959 : ℝ) / 50000000000)) ((-642772521547 : ℝ) / 1000000000000) ((-128554504309 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((26291625959 : ℝ) / 25000000000)) (t := ((1291625959 : ℝ) / 51291625959))
    (lo := ((50374659013 : ℝ) / 1000000000000)) (hi := ((25187329507 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((26291625959 : ℝ) / 50000000000) = Real.log ((26291625959 : ℝ) / 25000000000) - 1 * Real.log 2 := by
    rw [show ((26291625959 : ℝ) / 50000000000) = ((26291625959 : ℝ) / 25000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_475 : RB (Real.log ((174343034433 : ℝ) / 500000000000)) ((-1053583277731 : ℝ) / 1000000000000) ((-1053583277729 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((174343034433 : ℝ) / 250000000000)) (t := ((-75656965567 : ℝ) / 424343034433))
    (lo := ((-360436097171 : ℝ) / 1000000000000)) (hi := ((-36043609717 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((174343034433 : ℝ) / 500000000000) = Real.log ((174343034433 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((174343034433 : ℝ) / 500000000000) = ((174343034433 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_476 : RB (Real.log ((200938114691 : ℝ) / 62500000000)) ((1167830416799 : ℝ) / 1000000000000) ((1167830416801 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((200938114691 : ℝ) / 250000000000)) (t := ((-49061885309 : ℝ) / 450938114691))
    (lo := ((-341349913 : ℝ) / 1562500000)) (hi := ((-218463944319 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((200938114691 : ℝ) / 62500000000) = Real.log ((200938114691 : ℝ) / 250000000000) + 2 * Real.log 2 := by
    rw [show ((200938114691 : ℝ) / 62500000000) = ((200938114691 : ℝ) / 250000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_477 : RB (Real.log ((803854214609 : ℝ) / 250000000000)) ((1167957009761 : ℝ) / 1000000000000) ((1167957009763 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((803854214609 : ℝ) / 1000000000000)) (t := ((-196145785391 : ℝ) / 1803854214609))
    (lo := ((-109168675679 : ℝ) / 500000000000)) (hi := ((-218337351357 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((803854214609 : ℝ) / 250000000000) = Real.log ((803854214609 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((803854214609 : ℝ) / 250000000000) = ((803854214609 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_478 : RB (Real.log ((724290966401 : ℝ) / 500000000000)) ((370585100521 : ℝ) / 1000000000000) ((370585100523 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((724290966401 : ℝ) / 1000000000000)) (t := ((-275709033599 : ℝ) / 1724290966401))
    (lo := ((-161281040019 : ℝ) / 500000000000)) (hi := ((-322562080037 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((724290966401 : ℝ) / 500000000000) = Real.log ((724290966401 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((724290966401 : ℝ) / 500000000000) = ((724290966401 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_479 : RB (Real.log ((1079916249999 : ℝ) / 1000000000000)) ((9610436479 : ℝ) / 125000000000) ((76883491833 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1079916249999 : ℝ) / 1000000000000)) (t := ((79916249999 : ℝ) / 2079916249999))
    (lo := ((9610436479 : ℝ) / 125000000000)) (hi := ((76883491833 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
