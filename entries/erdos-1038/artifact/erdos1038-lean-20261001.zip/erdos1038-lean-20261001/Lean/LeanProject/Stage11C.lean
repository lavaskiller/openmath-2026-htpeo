import LeanProject.Stage11B
import Mathlib.Algebra.Polynomial.Sequence
import Mathlib.RingTheory.Polynomial.Chebyshev
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Chebyshev.Basic

/-!
# EP-1038, Stage 11, Lemma 11.7 (part 1): `𝓛` on polynomials in `cos θ`, and the limit lemma

* `L_cosPoly`: `𝓛` vanishes on finite cosine polynomials (from `L_cos`, Lemma 11.6).
* `poly_cos`: every polynomial in `cos θ` is a finite cosine polynomial (Chebyshev `T` span).
* `L_poly`: hence `𝓛(P ∘ cos) = 0` for every real polynomial `P`.
* `XLip M f`: `|f φ - f θ| ≤ M |cos φ - cos θ|` (Lipschitz in the variable `x = cos θ`).
* `HT_abs_le`: for such `f`, `|HT f| ≤ M` (constant domination; Math RED M-257);
  `HT_continuous`: `HT f` is continuous.
* `L_limit`: if `p n → f` uniformly, all `XLip M`, and `𝓛(p n) = 0`, then `𝓛 f = 0`.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset Polynomial

namespace EP1038.Stage11

open EP1038.Arc EP1038.Stage9

/-- `𝓛` on a finite cosine polynomial is the corresponding combination of `𝓛(cos n·)`. -/
theorem Lfun_cosPoly {r ρ1 ρ2 σ1 σ2 : ℝ} (h10 : 0 ≤ ρ1) (h11 : ρ1 < 1) (h20 : 0 ≤ ρ2)
    (h21 : ρ2 < 1) (s : Finset ℕ) (c : ℕ → ℝ) :
    Lfun r ρ1 ρ2 σ1 σ2 (cosPoly s c) =
      ∑ n ∈ s, c n * Lfun r ρ1 ρ2 σ1 σ2 (fun θ => Real.cos ((n : ℝ) * θ)) := by
  have hπ := Real.pi_pos
  have hcos : ∀ n : ℕ, Continuous fun θ : ℝ => Real.cos ((n : ℝ) * θ) := fun n => by fun_prop
  have hP1 := Pq_cont h10 h11
  have hP2 := Pq_cont h20 h21
  have hB : Continuous (Bxi ρ1 ρ2 σ1 σ2) := by
    unfold Bxi; exact ((continuous_const.sub (continuous_const.mul hP1)).sub
      (continuous_const.mul hP2))
  have ePq : ∀ ρ, Continuous (Pq ρ) → ∫ θ in (0 : ℝ)..π, cosPoly s c θ * Pq ρ θ =
      ∑ n ∈ s, c n * ∫ θ in (0 : ℝ)..π, Real.cos ((n : ℝ) * θ) * Pq ρ θ := by
    intro ρ hP
    have : (fun θ => cosPoly s c θ * Pq ρ θ) =
        fun θ => ∑ n ∈ s, c n * (Real.cos ((n : ℝ) * θ) * Pq ρ θ) := by
      funext θ; unfold cosPoly; rw [Finset.sum_mul]
      exact Finset.sum_congr rfl (fun n _ => by ring)
    rw [this, intervalIntegral.integral_finsetSum
      (f := fun n θ => c n * (Real.cos ((n : ℝ) * θ) * Pq ρ θ)) (fun n _ =>
      (continuous_const.mul ((hcos n).mul hP)).intervalIntegrable _ _)]
    exact Finset.sum_congr rfl (fun n _ => intervalIntegral.integral_const_mul _ _)
  have eH : ∫ θ in (0 : ℝ)..π, HT (cosPoly s c) θ * Bxi ρ1 ρ2 σ1 σ2 θ =
      ∑ n ∈ s, c n * ∫ θ in (0 : ℝ)..π,
        HT (fun φ => Real.cos ((n : ℝ) * φ)) θ * Bxi ρ1 ρ2 σ1 σ2 θ := by
    rw [intervalIntegral.integral_congr (g := fun θ =>
      ∑ n ∈ s, c n * (-(Vn θ n) * Bxi ρ1 ρ2 σ1 σ2 θ)) (fun θ hθ => by
        rw [uIcc_of_le hπ.le] at hθ
        simp only
        rw [HT_cosPoly hθ, neg_mul, Finset.sum_mul, ← Finset.sum_neg_distrib]
        exact Finset.sum_congr rfl (fun n _ => by ring))]
    rw [intervalIntegral.integral_finsetSum
      (f := fun n θ => c n * (-(Vn θ n) * Bxi ρ1 ρ2 σ1 σ2 θ)) (fun n _ =>
      (continuous_const.mul (((Vn_cont n).neg).mul hB)).intervalIntegrable _ _)]
    refine Finset.sum_congr rfl (fun n _ => ?_)
    rw [intervalIntegral.integral_const_mul]
    congr 1
    refine intervalIntegral.integral_congr (fun θ hθ => ?_)
    rw [uIcc_of_le hπ.le] at hθ
    rw [HT_cos hθ]
  unfold Lfun
  rw [ePq ρ1 hP1, ePq ρ2 hP2, eH]
  have ev : cosPoly s c π = ∑ n ∈ s, c n * Real.cos ((n : ℝ) * π) := rfl
  rw [ev]
  simp only [Finset.mul_sum]
  rw [← Finset.sum_add_distrib, ← Finset.sum_neg_distrib, ← Finset.sum_sub_distrib,
    ← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl (fun n _ => by ring)

/-- `𝓛` vanishes on finite cosine polynomials. -/
theorem L_cosPoly {r ρ1 ρ2 σ1 σ2 : ℝ} (hr : 0 < r) (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2)
    (h21 : ρ2 < 1) (s : Finset ℕ) (c : ℕ → ℝ) : Lfun r ρ1 ρ2 σ1 σ2 (cosPoly s c) = 0 := by
  rw [Lfun_cosPoly h10.le h11 h20.le h21]
  exact Finset.sum_eq_zero (fun n _ => by rw [L_cos hr h10 h11 h20 h21 n, mul_zero])

/-- Every polynomial in `cos θ` is a finite cosine polynomial. -/
theorem poly_cos (P : ℝ[X]) :
    ∃ (m : ℕ) (c : ℕ → ℝ), ∀ θ, P.eval (Real.cos θ) = cosPoly (Finset.range m) c θ := by
  have hmem : P ∈ Polynomial.degreeLT ℝ (P.natDegree + 1) := by
    rw [Polynomial.mem_degreeLT]
    exact (Polynomial.degree_le_natDegree).trans_lt (by exact_mod_cast Nat.lt_succ_self _)
  rw [← Polynomial.Sequence.span_degreeLT (Polynomial.Chebyshev.chebyshevTsequence ℝ)
      (by simp),
    show Set.Iio (P.natDegree + 1) = ((Finset.range (P.natDegree + 1) : Finset ℕ) : Set ℕ) by
      simp,
    Submodule.mem_span_image_finset_iff_exists_fun'] at hmem
  obtain ⟨c, hc⟩ := hmem
  refine ⟨P.natDegree + 1, c, fun θ => ?_⟩
  conv_lhs => rw [← hc]
  rw [Polynomial.eval_finsetSum]
  unfold cosPoly
  refine Finset.sum_congr rfl (fun n _ => ?_)
  rw [Polynomial.smul_eq_C_mul, Polynomial.eval_mul, Polynomial.eval_C]
  congr 1
  change (Polynomial.Chebyshev.T ℝ (n : ℤ)).eval (Real.cos θ) = _
  rw [Polynomial.Chebyshev.T_real_cos]
  norm_cast

/-- `𝓛(P ∘ cos) = 0` for every real polynomial `P`. -/
theorem L_poly {r ρ1 ρ2 σ1 σ2 : ℝ} (hr : 0 < r) (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2)
    (h21 : ρ2 < 1) (P : ℝ[X]) : Lfun r ρ1 ρ2 σ1 σ2 (fun θ => P.eval (Real.cos θ)) = 0 := by
  obtain ⟨m, c, hc⟩ := poly_cos P
  have : (fun θ => P.eval (Real.cos θ)) = cosPoly (Finset.range m) c := funext hc
  rw [this]
  exact L_cosPoly hr h10 h11 h20 h21 _ _

/-- Lipschitz in the variable `x = cos θ`. -/
def XLip (M : ℝ) (f : ℝ → ℝ) : Prop :=
  ∀ φ θ, |f φ - f θ| ≤ M * |Real.cos φ - Real.cos θ|

theorem XLip.continuous {M : ℝ} {f : ℝ → ℝ} (hf : XLip M f) : Continuous f := by
  rw [continuous_iff_continuousAt]
  intro θ
  rw [ContinuousAt, tendsto_iff_norm_sub_tendsto_zero]
  have h : Tendsto (fun φ => M * |Real.cos φ - Real.cos θ|) (𝓝 θ) (𝓝 0) := by
    have := ((Real.continuous_cos.tendsto θ).sub_const (Real.cos θ)).abs.const_mul M
    simpa using this
  exact squeeze_zero (fun _ => norm_nonneg _) (fun φ => by rw [Real.norm_eq_abs]; exact hf φ θ) h

/-- The difference quotient of an `XLip M` function is bounded by `M`. -/
theorem dq_bound {M : ℝ} {f : ℝ → ℝ} (hf : XLip M f) (hM : 0 ≤ M) (θ φ : ℝ) :
    |(f φ - f θ) / (Real.cos θ - Real.cos φ)| ≤ M := by
  rcases eq_or_ne (Real.cos θ - Real.cos φ) 0 with h | h
  · rw [h, div_zero, abs_zero]; exact hM
  · rw [abs_div, div_le_iff₀ (abs_pos.mpr h), abs_sub_comm (Real.cos θ)]; exact hf φ θ

/-- Constant domination of the transform (Math RED M-257). -/
theorem HT_abs_le {M : ℝ} {f : ℝ → ℝ} (hf : XLip M f) (hM : 0 ≤ M) (θ : ℝ) : |HT f θ| ≤ M := by
  have hπ := Real.pi_pos
  unfold HT
  have h := intervalIntegral.norm_integral_le_of_norm_le_const (a := 0) (b := π) (C := M)
    (f := fun φ => (f φ - f θ) / (Real.cos θ - Real.cos φ))
    (fun φ _ => by rw [Real.norm_eq_abs]; exact dq_bound hf hM θ φ)
  rw [Real.norm_eq_abs, sub_zero, abs_of_pos hπ] at h
  rw [abs_mul, abs_of_pos (by positivity : (0 : ℝ) < 1 / π)]
  have h2 := mul_le_mul_of_nonneg_left h (by positivity : (0 : ℝ) ≤ 1 / π)
  rwa [show 1 / π * (M * π) = M by field_simp] at h2

theorem dq_meas {f : ℝ → ℝ} (hfc : Continuous f) (θ : ℝ) :
    Measurable fun φ => (f φ - f θ) / (Real.cos θ - Real.cos φ) :=
  (hfc.measurable.sub measurable_const).div (measurable_const.sub Real.continuous_cos.measurable)

/-- `HT f` is continuous for `XLip` functions. -/
theorem HT_continuous {M : ℝ} {f : ℝ → ℝ} (hf : XLip M f) (hM : 0 ≤ M) : Continuous (HT f) := by
  have hfc := hf.continuous
  change Continuous (fun θ => 1 / π * ∫ φ in (0 : ℝ)..π, (f φ - f θ) / (Real.cos θ - Real.cos φ))
  refine continuous_const.mul ?_
  rw [continuous_iff_continuousAt]
  intro θ0
  refine intervalIntegral.continuousAt_of_dominated_interval (bound := fun _ => M)
    (Eventually.of_forall (fun θ => (dq_meas hfc θ).aestronglyMeasurable))
    (Eventually.of_forall (fun θ => Eventually.of_forall (fun φ _ => by
      rw [Real.norm_eq_abs]; exact dq_bound hf hM θ φ)))
    intervalIntegrable_const ?_
  filter_upwards [ae_ne_real (Real.arccos (Real.cos θ0))] with φ hφ hmem
  rw [uIoc_of_le Real.pi_pos.le] at hmem
  have hne : Real.cos θ0 - Real.cos φ ≠ 0 := by
    intro h
    apply hφ
    have : Real.cos φ = Real.cos θ0 := by linarith
    rw [← this, Real.arccos_cos hmem.1.le hmem.2]
  exact (continuousAt_const.sub hfc.continuousAt).div
    (Real.continuous_cos.continuousAt.sub continuousAt_const) hne

/-- Pointwise convergence of the transforms. -/
theorem HT_tendsto {M : ℝ} {p : ℕ → ℝ → ℝ} {f : ℝ → ℝ} (hp : ∀ n, XLip M (p n))
    (hM : 0 ≤ M) (hlim : ∀ φ, Tendsto (fun n => p n φ) atTop (𝓝 (f φ))) (θ : ℝ) :
    Tendsto (fun n => HT (p n) θ) atTop (𝓝 (HT f θ)) := by
  unfold HT
  refine Tendsto.const_mul _ ?_
  refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence (fun _ => M)
    (Eventually.of_forall (fun n => (dq_meas (hp n).continuous θ).aestronglyMeasurable))
    (Eventually.of_forall (fun n => Eventually.of_forall (fun φ _ => by
      rw [Real.norm_eq_abs]; exact dq_bound (hp n) hM θ φ)))
    intervalIntegrable_const ?_
  exact Eventually.of_forall (fun φ _ => ((hlim φ).sub (hlim θ)).div_const _)

theorem Bxi_cont {ρ1 ρ2 σ1 σ2 : ℝ} (h10 : 0 ≤ ρ1) (h11 : ρ1 < 1) (h20 : 0 ≤ ρ2)
    (h21 : ρ2 < 1) : Continuous (Bxi ρ1 ρ2 σ1 σ2) := by
  unfold Bxi
  exact ((continuous_const.sub (continuous_const.mul (Pq_cont h10 h11))).sub
    (continuous_const.mul (Pq_cont h20 h21)))

/-- Convergence of `∫ p_n P` for uniformly convergent `p_n`. -/
theorem int_mul_tendsto {p : ℕ → ℝ → ℝ} {f g : ℝ → ℝ} {ε : ℕ → ℝ}
    (hpc : ∀ n, Continuous (p n)) (hfc : Continuous f) (hg : Continuous g)
    (hε : Tendsto ε atTop (𝓝 0)) (hpe : ∀ n θ, |p n θ - f θ| ≤ ε n) :
    Tendsto (fun n => ∫ θ in (0 : ℝ)..π, p n θ * g θ) atTop
      (𝓝 (∫ θ in (0 : ℝ)..π, f θ * g θ)) := by
  have hlim : ∀ θ, Tendsto (fun n => p n θ) atTop (𝓝 (f θ)) := by
    intro θ
    rw [tendsto_iff_norm_sub_tendsto_zero]
    exact squeeze_zero (fun _ => norm_nonneg _)
      (fun n => by rw [Real.norm_eq_abs]; exact hpe n θ) hε
  have hev : ∀ᶠ n in atTop, ε n < 1 := hε.eventually (gt_mem_nhds one_pos)
  refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
    (fun θ => (|f θ| + 1) * |g θ|)
    (Eventually.of_forall (fun n => ((hpc n).mul hg).aestronglyMeasurable))
    ?_ (((hfc.abs.add continuous_const).mul hg.abs).intervalIntegrable _ _)
    (Eventually.of_forall (fun θ _ => (hlim θ).mul tendsto_const_nhds))
  filter_upwards [hev] with n hn
  refine Eventually.of_forall (fun θ _ => ?_)
  rw [Real.norm_eq_abs, abs_mul]
  have h1 : |p n θ| ≤ |f θ| + 1 := by
    have := hpe n θ
    have := abs_sub_abs_le_abs_sub (p n θ) (f θ)
    linarith
  exact mul_le_mul_of_nonneg_right h1 (abs_nonneg _)

/-- **Limit lemma.** If `p n → f` uniformly, with `p n` and `f` all `XLip M`, and
`𝓛(p n) = 0` for all `n`, then `𝓛 f = 0`. -/
theorem L_limit {r ρ1 ρ2 σ1 σ2 M : ℝ} (h10 : 0 ≤ ρ1) (h11 : ρ1 < 1) (h20 : 0 ≤ ρ2)
    (h21 : ρ2 < 1) (hM : 0 ≤ M) {p : ℕ → ℝ → ℝ} {f : ℝ → ℝ} {ε : ℕ → ℝ}
    (hp : ∀ n, XLip M (p n)) (hf : XLip M f)
    (hε : Tendsto ε atTop (𝓝 0)) (hpe : ∀ n θ, |p n θ - f θ| ≤ ε n)
    (hL : ∀ n, Lfun r ρ1 ρ2 σ1 σ2 (p n) = 0) : Lfun r ρ1 ρ2 σ1 σ2 f = 0 := by
  have hlim : ∀ θ, Tendsto (fun n => p n θ) atTop (𝓝 (f θ)) := by
    intro θ
    rw [tendsto_iff_norm_sub_tendsto_zero]
    exact squeeze_zero (fun _ => norm_nonneg _)
      (fun n => by rw [Real.norm_eq_abs]; exact hpe n θ) hε
  have hpc : ∀ n, Continuous (p n) := fun n => (hp n).continuous
  have hfc := hf.continuous
  have hB := Bxi_cont (σ1 := σ1) (σ2 := σ2) h10 h11 h20 h21
  have t1 := int_mul_tendsto hpc hfc (Pq_cont h10 h11) hε hpe
  have t2 := int_mul_tendsto hpc hfc (Pq_cont h20 h21) hε hpe
  have t3 : Tendsto (fun n => ∫ θ in (0 : ℝ)..π, HT (p n) θ * Bxi ρ1 ρ2 σ1 σ2 θ) atTop
      (𝓝 (∫ θ in (0 : ℝ)..π, HT f θ * Bxi ρ1 ρ2 σ1 σ2 θ)) := by
    refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
      (fun θ => M * |Bxi ρ1 ρ2 σ1 σ2 θ|)
      (Eventually.of_forall (fun n => ((HT_continuous (hp n) hM).mul hB).aestronglyMeasurable))
      (Eventually.of_forall (fun n => Eventually.of_forall (fun θ _ => by
        rw [Real.norm_eq_abs, abs_mul]
        exact mul_le_mul_of_nonneg_right (HT_abs_le (hp n) hM θ) (abs_nonneg _))))
      ((continuous_const.mul hB.abs).intervalIntegrable _ _)
      (Eventually.of_forall (fun θ _ => (HT_tendsto hp hM hlim θ).mul tendsto_const_nhds))
  have hT : Tendsto (fun n => Lfun r ρ1 ρ2 σ1 σ2 (p n)) atTop (𝓝 (Lfun r ρ1 ρ2 σ1 σ2 f)) := by
    unfold Lfun
    exact ((((t1.const_mul (1 / π)).const_mul _).add ((t2.const_mul (1 / π)).const_mul _)).neg.sub
      (t3.const_mul _)).add ((hlim π).const_mul _)
  have h0 : Tendsto (fun n => Lfun r ρ1 ρ2 σ1 σ2 (p n)) atTop (𝓝 0) := by
    simp only [hL]; exact tendsto_const_nhds
  exact tendsto_nhds_unique hT h0

end EP1038.Stage11
