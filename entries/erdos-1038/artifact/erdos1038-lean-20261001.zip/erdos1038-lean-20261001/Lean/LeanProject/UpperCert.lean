import LeanProject.N3Main

/-!
# EP-1038: upper bounds for the fixed-degree minima (Phase I, result.md table), general part

For the corner roots `(-1, 1, …, 1)` (`m` copies of `1`), i.e. `f = (x + 1)(x - 1)^m`, the
sublevel set `S = {x : |f(x)| < 1}` is contained in `(a₁, b₁) ∪ (b₂, a₂)` as soon as

* `(-1 - a₁)(1 - a₁)^m ≥ 1` with `a₁ ≤ -1` (outer left; `|f|` is monotone on `x ≤ a₁`),
* `(a₂ + 1)(a₂ - 1)^m ≥ 1` with `a₂ ≥ 1` (outer right),
* a chain `b₁ = p₀ < p₁ < ⋯ < p_N = b₂` in `(-1, 1)` with `(1 + p_k)(1 - p_{k+1})^m ≥ 1`
  (on `[p_k, p_{k+1}]`, `|f(x)| = (1 + x)(1 - x)^m ≥ (1 + p_k)(1 - p_{k+1})^m`).

All numbers are integers scaled by `s > 0`; `midOK` is the integer chain test, evaluated by the
kernel (`decide`) in `UpperMain.lean`. Result: `|S| ≤ (b₁ - a₁) + (a₂ - b₂)`.
-/

open Real MeasureTheory

namespace EP1038

/-- The corner roots `(-1, 1, …, 1)` with `m` copies of `1`. -/
def corner (m : ℕ) : Fin (m + 1) → ℝ := Fin.cons (-1) (fun _ => 1)

theorem corner_mem (m : ℕ) (i : Fin (m + 1)) : corner m i ∈ Set.Icc (-1 : ℝ) 1 := by
  refine Fin.cases ?_ (fun j => ?_) i <;> simp [corner]

theorem prod_corner (m : ℕ) (x : ℝ) : ∏ i, (x - corner m i) = (x + 1) * (x - 1) ^ m := by
  rw [Fin.prod_univ_succ]
  simp [corner, Finset.prod_const]

/-- `S(corner m)` is the sublevel set of the polynomial `(x + 1)(x - 1)^m`. -/
theorem sublevel_corner (m : ℕ) :
    sublevel (corner m) = {x : ℝ | |(x + 1) * (x - 1) ^ m| < 1} := by
  ext x; simp only [sublevel, Set.mem_ofPred_eq, prod_corner]

/-- Integer chain test (all numbers scaled by `s`). For a chain of length ≥ 2 the final call also
tests the last point, `(s + p_N)(s - p_N)^m ≥ s^(m+1)`; this is implied by the last piece and
changes nothing (Lean RED L-49). -/
def midOK (s : ℤ) (m : ℕ) : List ℤ → Bool
  | [] => true
  | [p] => decide (-s < p) && decide (p < s) && decide (s ^ (m + 1) ≤ (s + p) * (s - p) ^ m)
  | p :: q :: rest => decide (-s < p) && decide (p < q) && decide (q < s) &&
      decide (s ^ (m + 1) ≤ (s + p) * (s - q) ^ m) && midOK s m (q :: rest)

/-- Scaling: `s^(m+1) ≤ u v^m` in `ℤ` gives `1 ≤ (u/s)(v/s)^m` in `ℝ`. -/
theorem scale_le {s : ℤ} (hs : 0 < s) {m : ℕ} {u v : ℤ} (h : s ^ (m + 1) ≤ u * v ^ m) :
    (1 : ℝ) ≤ ((u : ℝ) / s) * ((v : ℝ) / s) ^ m := by
  have hs' : (0 : ℝ) < s := by exact_mod_cast hs
  have h' : (s : ℝ) ^ (m + 1) ≤ (u : ℝ) * (v : ℝ) ^ m := by exact_mod_cast h
  rw [div_pow, div_mul_div_comm, ← pow_succ', le_div_iff₀ (pow_pos hs' _), one_mul]
  exact h'

/-- One middle piece: on `[p/s, q/s] ⊂ (-1, 1)`, `(1 + x)(1 - x)^m ≥ 1`. -/
theorem piece_real {s : ℤ} (hs : 0 < s) {m : ℕ} {p q : ℤ} (hp : -s < p) (hq : q < s)
    (h : s ^ (m + 1) ≤ (s + p) * (s - q) ^ m) {x : ℝ} (hx1 : (p : ℝ) / s ≤ x)
    (hx2 : x ≤ (q : ℝ) / s) : 1 ≤ (1 + x) * (1 - x) ^ m := by
  have hs' : (0 : ℝ) < s := by exact_mod_cast hs
  have hp' : (-s : ℝ) < p := by exact_mod_cast hp
  have hq' : (q : ℝ) < s := by exact_mod_cast hq
  have h0 := scale_le hs h
  push_cast at h0
  have e1 : ((s : ℝ) + p) / s ≤ 1 + x := by rw [add_div, div_self hs'.ne']; linarith
  have e2 : ((s : ℝ) - q) / s ≤ 1 - x := by rw [sub_div, div_self hs'.ne']; linarith
  have n1 : 0 ≤ ((s : ℝ) - q) / s := div_nonneg (by linarith) hs'.le
  have n2 : 0 ≤ 1 + x := by
    have : 0 ≤ ((s : ℝ) + p) / s := div_nonneg (by linarith) hs'.le
    linarith
  calc (1 : ℝ) ≤ (((s : ℝ) + p) / s) * (((s : ℝ) - q) / s) ^ m := h0
    _ ≤ (1 + x) * (1 - x) ^ m :=
        mul_le_mul e1 (pow_le_pow_left₀ n1 e2 m) (pow_nonneg n1 m) n2

/-- Soundness of the chain test: on `[p/s, (last)/s]`, `(1 + x)(1 - x)^m ≥ 1`. -/
theorem midOK_sound {s : ℤ} (hs : 0 < s) {m : ℕ} :
    ∀ (L : List ℤ) (p : ℤ), midOK s m (p :: L) = true →
      ∀ x : ℝ, (p : ℝ) / s ≤ x → x ≤ (L.getLastD p : ℝ) / s → 1 ≤ (1 + x) * (1 - x) ^ m := by
  intro L
  induction L with
  | nil =>
    intro p h x hx1 hx2
    simp only [midOK, Bool.and_eq_true, decide_eq_true_eq] at h
    obtain ⟨⟨h1, h2⟩, h3⟩ := h
    exact piece_real hs h1 h2 h3 hx1 (by simpa using hx2)
  | cons q rest ih =>
    intro p h x hx1 hx2
    simp only [midOK, Bool.and_eq_true, decide_eq_true_eq] at h
    obtain ⟨⟨⟨⟨h1, h2⟩, h3⟩, h4⟩, h5⟩ := h
    rw [List.getLastD_cons] at hx2
    rcases le_or_gt x ((q : ℝ) / s) with hxq | hxq
    · exact piece_real hs h1 h3 h4 hx1 hxq
    · exact ih q h5 x hxq.le hx2

theorem corner_left {m : ℕ} {a x : ℝ} (ha : a ≤ -1) (hx : x ≤ a)
    (h : 1 ≤ (-1 - a) * (1 - a) ^ m) : 1 ≤ |(x + 1) * (x - 1) ^ m| := by
  rw [abs_mul, abs_pow, abs_of_nonpos (by linarith : x + 1 ≤ 0),
    abs_of_nonpos (by linarith : x - 1 ≤ 0)]
  calc (1 : ℝ) ≤ (-1 - a) * (1 - a) ^ m := h
    _ ≤ -(x + 1) * (-(x - 1)) ^ m :=
        mul_le_mul (by linarith) (pow_le_pow_left₀ (by linarith) (by linarith) m)
          (pow_nonneg (by linarith) m) (by linarith)

theorem corner_right {m : ℕ} {a x : ℝ} (ha : 1 ≤ a) (hx : a ≤ x)
    (h : 1 ≤ (a + 1) * (a - 1) ^ m) : 1 ≤ |(x + 1) * (x - 1) ^ m| := by
  rw [abs_of_nonneg (mul_nonneg (by linarith) (pow_nonneg (by linarith) m))]
  calc (1 : ℝ) ≤ (a + 1) * (a - 1) ^ m := h
    _ ≤ (x + 1) * (x - 1) ^ m :=
        mul_le_mul (by linarith) (pow_le_pow_left₀ (by linarith) (by linarith) m)
          (pow_nonneg (by linarith) m) (by linarith)

theorem corner_mid {m : ℕ} {x : ℝ} (h1 : -1 < x) (h2 : x < 1)
    (h : 1 ≤ (1 + x) * (1 - x) ^ m) : 1 ≤ |(x + 1) * (x - 1) ^ m| := by
  rw [abs_mul, abs_pow, abs_of_pos (by linarith : 0 < x + 1),
    abs_of_neg (by linarith : x - 1 < 0)]
  calc (1 : ℝ) ≤ (1 + x) * (1 - x) ^ m := h
    _ = (x + 1) * (-(x - 1)) ^ m := by ring

/-- The last point of a valid chain lies in `(-s, s)`. -/
theorem midOK_last {s : ℤ} {m : ℕ} :
    ∀ (L : List ℤ) (p : ℤ), midOK s m (p :: L) = true → -s < L.getLastD p ∧ L.getLastD p < s := by
  intro L
  induction L with
  | nil =>
    intro p h
    simp only [midOK, Bool.and_eq_true, decide_eq_true_eq] at h
    exact ⟨h.1.1, h.1.2⟩
  | cons q rest ih =>
    intro p h
    simp only [midOK, Bool.and_eq_true, decide_eq_true_eq] at h
    rw [List.getLastD_cons]
    exact ih q h.2

/-- **Upper bound for the corner polynomial** `(x + 1)(x - 1)^m` from an integer certificate. -/
theorem corner_upper {m : ℕ} (s : ℤ) (hs : 0 < s) (A1 A2 p : ℤ) (L : List ℤ)
    (hA1 : A1 ≤ -s) (hA2 : s ≤ A2)
    (hl : s ^ (m + 1) ≤ (-s - A1) * (s - A1) ^ m)
    (hr : s ^ (m + 1) ≤ (A2 + s) * (A2 - s) ^ m)
    (hmid : midOK s m (p :: L) = true) :
    volume (sublevel (corner m)) ≤
      ENNReal.ofReal (((p - A1 : ℤ) : ℝ) / s) + ENNReal.ofReal (((A2 - L.getLastD p : ℤ) : ℝ) / s) := by
  have hs' : (0 : ℝ) < s := by exact_mod_cast hs
  set e := L.getLastD p with he
  have hA1' : (A1 : ℝ) / s ≤ -1 := by
    rw [div_le_iff₀ hs']; have : (A1 : ℝ) ≤ -s := by exact_mod_cast hA1
    linarith
  have hA2' : 1 ≤ (A2 : ℝ) / s := by
    rw [le_div_iff₀ hs']; have : (s : ℝ) ≤ A2 := by exact_mod_cast hA2
    linarith
  have hl' : 1 ≤ (-1 - (A1 : ℝ) / s) * (1 - (A1 : ℝ) / s) ^ m := by
    have := scale_le hs hl
    push_cast at this
    have k1 : ((-(s : ℝ) - A1) / s) = -1 - (A1 : ℝ) / s := by field_simp
    have k2 : (((s : ℝ) - A1) / s) = 1 - (A1 : ℝ) / s := by field_simp
    rwa [k1, k2] at this
  have hr' : 1 ≤ ((A2 : ℝ) / s + 1) * ((A2 : ℝ) / s - 1) ^ m := by
    have := scale_le hs hr
    push_cast at this
    have k1 : (((A2 : ℝ) + s) / s) = (A2 : ℝ) / s + 1 := by field_simp
    have k2 : (((A2 : ℝ) - s) / s) = (A2 : ℝ) / s - 1 := by field_simp
    rwa [k1, k2] at this
  obtain ⟨hp1, hp2⟩ : -s < p ∧ p < s := by
    cases L with
    | nil => simp only [midOK, Bool.and_eq_true, decide_eq_true_eq] at hmid; exact hmid.1
    | cons q rest =>
      simp only [midOK, Bool.and_eq_true, decide_eq_true_eq] at hmid
      exact ⟨hmid.1.1.1.1, lt_trans hmid.1.1.1.2 hmid.1.1.2⟩
  obtain ⟨he1, he2⟩ := midOK_last L p hmid
  rw [← he] at he1 he2
  have hp1' : (-1 : ℝ) < (p : ℝ) / s := by
    rw [lt_div_iff₀ hs']; have : (-s : ℝ) < p := by exact_mod_cast hp1
    linarith
  have he2' : (e : ℝ) / s < 1 := by
    rw [div_lt_iff₀ hs']; have : (e : ℝ) < s := by exact_mod_cast he2
    linarith
  have hsub : sublevel (corner m) ⊆
      Set.Ioo ((A1 : ℝ) / s) ((p : ℝ) / s) ∪ Set.Ioo ((e : ℝ) / s) ((A2 : ℝ) / s) := by
    intro x hx
    rw [sublevel_corner, Set.mem_ofPred_eq] at hx
    have c1 : (A1 : ℝ) / s < x := by
      by_contra hc
      exact absurd hx (not_lt.mpr (corner_left hA1' (not_lt.mp hc) hl'))
    have c2 : x < (A2 : ℝ) / s := by
      by_contra hc
      exact absurd hx (not_lt.mpr (corner_right hA2' (not_lt.mp hc) hr'))
    rcases lt_or_ge x ((p : ℝ) / s) with h1 | h1
    · exact Or.inl ⟨c1, h1⟩
    · rcases lt_or_ge ((e : ℝ) / s) x with h2 | h2
      · exact Or.inr ⟨h2, c2⟩
      · exfalso
        have hm := midOK_sound hs L p hmid x h1 (by rw [← he]; exact h2)
        exact absurd hx (not_lt.mpr (corner_mid (by linarith) (by linarith) hm))
  calc volume (sublevel (corner m))
      ≤ volume (Set.Ioo ((A1 : ℝ) / s) ((p : ℝ) / s) ∪ Set.Ioo ((e : ℝ) / s) ((A2 : ℝ) / s)) :=
        measure_mono hsub
    _ ≤ volume (Set.Ioo ((A1 : ℝ) / s) ((p : ℝ) / s)) +
          volume (Set.Ioo ((e : ℝ) / s) ((A2 : ℝ) / s)) := measure_union_le _ _
    _ = _ := by
        rw [Real.volume_Ioo, Real.volume_Ioo]
        push_cast
        rw [sub_div, sub_div]

end EP1038
