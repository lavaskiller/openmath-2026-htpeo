import LeanProject.MaterialDictionary

/-! Absolute integrability of the angular logarithmic distance kernel. -/

open Real Set MeasureTheory Filter Topology intervalIntegral

namespace EP1038.Stage12
open EP1038.Arc EP1038.Stage11

theorem ae_angle_prod {p : ℝ × ℝ → Prop} (hm : MeasurableSet {z | p z})
    (hp : ∀ θ, ∀ᵐ φ ∂volume, p (θ, φ)) :
    ∀ᵐ z ∂angleMeasure.prod angleMeasure, p z :=
  (Measure.ae_prod_iff_ae_ae hm).mpr (Eventually.of_forall fun θ => ae_restrict_of_ae (hp θ))

theorem Lsin_joint_integrable :
    Integrable (fun p : ℝ × ℝ => Circ.Lsin (p.1 - p.2))
      (angleMeasure.prod angleMeasure) := by
  have hm : Measurable (fun p : ℝ × ℝ => Circ.Lsin (p.1 - p.2)) :=
    Circ.Lsin_measurable.comp (measurable_fst.sub measurable_snd)
  apply (integrable_prod_iff hm.aestronglyMeasurable).mpr
  refine ⟨Eventually.of_forall fun θ => ?_, ?_⟩
  · exact (intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le).mp
      (Circ.Lsin_ii θ 0 π)
  · apply (integrable_const (∫ s in (-π)..π, Circ.Lsin s)).mono'
      hm.stronglyMeasurable.norm.integral_prod_right'.aestronglyMeasurable
    refine Eventually.of_forall fun θ => ?_
    simp only [Real.norm_eq_abs, abs_of_nonneg (Circ.Lsin_nonneg _)]
    rw [abs_of_nonneg (MeasureTheory.integral_nonneg fun φ => Circ.Lsin_nonneg _)]
    change (∫ φ in Ioc (0 : ℝ) π, Circ.Lsin (θ - φ)) ≤ _
    rw [← intervalIntegral.integral_of_le Real.pi_pos.le]
    calc
      _ ≤ ∫ φ in (-π)..π, Circ.Lsin (θ - φ) :=
        intervalIntegral.integral_mono_interval (by linarith [Real.pi_pos]) Real.pi_pos.le le_rfl
          (Eventually.of_forall fun _ => Circ.Lsin_nonneg _) (Circ.Lsin_ii θ _ _)
      _ = _ := Circ.int_Lsin_shift θ

theorem Kl_joint_integrable :
    Integrable (fun p : ℝ × ℝ => Kl 1 (p.1 - p.2))
      (angleMeasure.prod angleMeasure) := by
  have hm : Measurable (fun p : ℝ × ℝ => Kl 1 (p.1 - p.2)) :=
    Kl1_measurable.comp (measurable_fst.sub measurable_snd)
  apply ((integrable_const (Real.log 2)).add Lsin_joint_integrable).mono' hm.aestronglyMeasurable
  have ha : ∀ᵐ p ∂(angleMeasure.prod angleMeasure),
      Real.sin ((p.1 - p.2) / 2) ≠ 0 := by
    apply ae_angle_prod
    · exact ((Real.continuous_sin.comp
        ((continuous_fst.sub continuous_snd).div_const 2)).stronglyMeasurable.measurableSet_eq_fun
          stronglyMeasurable_const).compl
    · exact Circ.ae_sin_ne
  filter_upwards [ha] with p hp
  rw [Real.norm_eq_abs, Kl_one_eq hp]
  change |Real.log 2 - Circ.Lsin (p.1 - p.2)| ≤ Real.log 2 + Circ.Lsin (p.1 - p.2)
  have h0 := Circ.Lsin_nonneg (p.1 - p.2)
  have h2 : 0 < Real.log 2 := Real.log_pos one_lt_two
  exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem Lsin_joint_add_integrable :
    Integrable (fun p : ℝ × ℝ => Circ.Lsin (p.1 + p.2))
      (angleMeasure.prod angleMeasure) := by
  have hm : Measurable (fun p : ℝ × ℝ => Circ.Lsin (p.1 + p.2)) :=
    Circ.Lsin_measurable.comp (measurable_fst.add measurable_snd)
  have heq (θ φ : ℝ) : Circ.Lsin (θ + φ) = Circ.Lsin (-θ - φ) := by
    rw [show -θ - φ = -(θ + φ) by ring, Lsin_neg]
  apply (integrable_prod_iff hm.aestronglyMeasurable).mpr
  refine ⟨Eventually.of_forall fun θ => ?_, ?_⟩
  · simp_rw [heq θ]
    exact (intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le).mp
      (Circ.Lsin_ii (-θ) 0 π)
  · apply (integrable_const (∫ s in (-π)..π, Circ.Lsin s)).mono'
      hm.stronglyMeasurable.norm.integral_prod_right'.aestronglyMeasurable
    refine Eventually.of_forall fun θ => ?_
    simp only [Real.norm_eq_abs, abs_of_nonneg (Circ.Lsin_nonneg _)]
    rw [abs_of_nonneg (MeasureTheory.integral_nonneg fun φ => Circ.Lsin_nonneg _)]
    simp_rw [heq θ]
    change (∫ φ in Ioc (0 : ℝ) π, Circ.Lsin (-θ - φ)) ≤ _
    rw [← intervalIntegral.integral_of_le Real.pi_pos.le]
    calc
      _ ≤ ∫ φ in (-π)..π, Circ.Lsin (-θ - φ) :=
        intervalIntegral.integral_mono_interval (by linarith [Real.pi_pos]) Real.pi_pos.le le_rfl
          (Eventually.of_forall fun _ => Circ.Lsin_nonneg _) (Circ.Lsin_ii (-θ) _ _)
      _ = _ := Circ.int_Lsin_shift (-θ)

theorem Kl_joint_add_integrable :
    Integrable (fun p : ℝ × ℝ => Kl 1 (p.1 + p.2))
      (angleMeasure.prod angleMeasure) := by
  have hm : Measurable (fun p : ℝ × ℝ => Kl 1 (p.1 + p.2)) :=
    Kl1_measurable.comp (measurable_fst.add measurable_snd)
  apply ((integrable_const (Real.log 2)).add Lsin_joint_add_integrable).mono' hm.aestronglyMeasurable
  have ha : ∀ᵐ p ∂(angleMeasure.prod angleMeasure),
      Real.sin ((p.1 + p.2) / 2) ≠ 0 := by
    apply ae_angle_prod
    · exact ((Real.continuous_sin.comp
        ((continuous_fst.add continuous_snd).div_const 2)).stronglyMeasurable.measurableSet_eq_fun
          stronglyMeasurable_const).compl
    · intro θ
      filter_upwards [Circ.ae_sin_ne (-θ)] with φ hφ
      simpa only [show (-θ - φ) / 2 = -((θ + φ) / 2) by ring, Real.sin_neg, neg_ne_zero] using hφ
  filter_upwards [ha] with p hp
  rw [Real.norm_eq_abs, Kl_one_eq hp]
  change |Real.log 2 - Circ.Lsin (p.1 + p.2)| ≤ Real.log 2 + Circ.Lsin (p.1 + p.2)
  have h0 := Circ.Lsin_nonneg (p.1 + p.2)
  have h2 : 0 < Real.log 2 := Real.log_pos one_lt_two
  exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem log_distance_joint_integrable {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) :
    Integrable (fun p : ℝ × ℝ => Real.log |dth D0 q p.1 - dth D0 q p.2|)
      (angleMeasure.prod angleMeasure) := by
  have hd : Continuous (dth D0 q) := by unfold dth; fun_prop
  have hm : Measurable (fun p : ℝ × ℝ => Real.log |dth D0 q p.1 - dth D0 q p.2|) :=
    Real.measurable_log.comp (continuous_abs.measurable.comp ((hd.measurable.comp measurable_fst).sub
      (hd.measurable.comp measurable_snd)))
  have hs : Measurable (fun p : ℝ × ℝ => Real.log (D0 * q) + Kl 1 (p.2 + p.1) +
      Kl 1 (p.2 - p.1)) :=
    (measurable_const.add (Kl1_measurable.comp (measurable_snd.add measurable_fst))).add
      (Kl1_measurable.comp (measurable_snd.sub measurable_fst))
  have heq : (fun p : ℝ × ℝ => Real.log |dth D0 q p.1 - dth D0 q p.2|) =ᵐ[
      angleMeasure.prod angleMeasure]
        (fun p => Real.log (D0 * q) + Kl 1 (p.2 + p.1) + Kl 1 (p.2 - p.1)) := by
    apply ae_angle_prod (hm.stronglyMeasurable.measurableSet_eq_fun hs.stronglyMeasurable)
    exact log_dist_eq hD hq
  apply (((integrable_const (Real.log (D0 * q))).add Kl_joint_add_integrable).add
    Kl_joint_integrable).congr
  filter_upwards [heq] with p hp
  rw [hp, add_comm p.2 p.1, show p.2 - p.1 = -(p.1 - p.2) by ring, Kl1_even]
  rfl

theorem weighted_log_distance_integrable {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q)
    {F G : ℝ → ℝ} {a b : ℝ} (hFm : Measurable F) (hGm : Measurable G)
    (hF : ∀ θ, |F θ| ≤ a) (hG : ∀ θ, |G θ| ≤ b) :
    Integrable (fun p : ℝ × ℝ => F p.1 *
      (Real.log |dth D0 q p.1 - dth D0 q p.2| * G p.2))
        (angleMeasure.prod angleMeasure) := by
  have hf := log_distance_joint_integrable hD hq
  have hd : Continuous (dth D0 q) := by unfold dth; fun_prop
  have hm : Measurable (fun p : ℝ × ℝ => F p.1 *
      (Real.log |dth D0 q p.1 - dth D0 q p.2| * G p.2)) :=
    (hFm.comp measurable_fst).mul ((Real.measurable_log.comp
      (continuous_abs.measurable.comp ((hd.measurable.comp measurable_fst).sub
        (hd.measurable.comp measurable_snd)))).mul
        (hGm.comp measurable_snd))
  apply (hf.norm.const_mul (a * b)).mono' hm.aestronglyMeasurable
  refine Eventually.of_forall fun p => ?_
  rw [Real.norm_eq_abs, abs_mul, abs_mul]
  change _ ≤ a * b * |Real.log (|dth D0 q p.1 - dth D0 q p.2|)|
  have ha : 0 ≤ a := (abs_nonneg _).trans (hF p.1)
  have hb : 0 ≤ b := (abs_nonneg _).trans (hG p.2)
  calc
    _ ≤ a * (|Real.log (|dth D0 q p.1 - dth D0 q p.2|)| * b) :=
      mul_le_mul (hF p.1) (mul_le_mul_of_nonneg_left (hG p.2) (abs_nonneg _))
        (mul_nonneg (abs_nonneg _) (abs_nonneg _)) ha
    _ = _ := by ring

end EP1038.Stage12
