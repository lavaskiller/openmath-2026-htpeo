import LeanProject.COVLogTwo
import LeanProject.COVLogBounds25
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2320 : RB (Real.log ((83144571 : ℝ) / 100000000)) ((-1153683 : ℝ) / 6250000) ((-18458927 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83144571 : ℝ) / 100000000)) (t := ((-16855429 : ℝ) / 183144571))
    (lo := ((-1153683 : ℝ) / 6250000)) (hi := ((-18458927 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2321 : RB (Real.log ((1419881 : ℝ) / 3125000)) ((-78886123 : ℝ) / 100000000) ((-78886121 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1419881 : ℝ) / 1562500)) (t := ((-142619 : ℝ) / 2982381))
    (lo := ((-2392851 : ℝ) / 25000000)) (hi := ((-9571403 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1419881 : ℝ) / 3125000) = Real.log ((1419881 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((1419881 : ℝ) / 3125000) = ((1419881 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2322 : RB (Real.log ((344238153 : ℝ) / 100000000)) ((123616353 : ℝ) / 100000000) ((30904089 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((344238153 : ℝ) / 400000000)) (t := ((-55761847 : ℝ) / 744238153))
    (lo := ((-15013083 : ℝ) / 100000000)) (hi := ((-7506541 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((344238153 : ℝ) / 100000000) = Real.log ((344238153 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((344238153 : ℝ) / 100000000) = ((344238153 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2323 : RB (Real.log ((86059539 : ℝ) / 25000000)) ((61808177 : ℝ) / 50000000) ((123616357 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((86059539 : ℝ) / 100000000)) (t := ((-13940461 : ℝ) / 186059539))
    (lo := ((-7506541 : ℝ) / 50000000)) (hi := ((-15013081 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86059539 : ℝ) / 25000000) = Real.log ((86059539 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((86059539 : ℝ) / 25000000) = ((86059539 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2324 : RB (Real.log ((563661 : ℝ) / 400000)) ((6859769 : ℝ) / 20000000) ((34298847 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((563661 : ℝ) / 800000)) (t := ((-236339 : ℝ) / 1363661))
    (lo := ((-35015873 : ℝ) / 100000000)) (hi := ((-547123 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((563661 : ℝ) / 400000) = Real.log ((563661 : ℝ) / 800000) + 1 * Real.log 2 := by
    rw [show ((563661 : ℝ) / 400000) = ((563661 : ℝ) / 800000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2325 : RB (Real.log ((68566207 : ℝ) / 20000000)) ((3850211 : ℝ) / 3125000) ((24641351 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((68566207 : ℝ) / 80000000)) (t := ((-11433793 : ℝ) / 148566207))
    (lo := ((-3855671 : ℝ) / 25000000)) (hi := ((-15422683 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68566207 : ℝ) / 20000000) = Real.log ((68566207 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((68566207 : ℝ) / 20000000) = ((68566207 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2326 : RB (Real.log ((342831039 : ℝ) / 100000000)) ((61603377 : ℝ) / 50000000) ((123206757 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((342831039 : ℝ) / 400000000)) (t := ((-57168961 : ℝ) / 742831039))
    (lo := ((-7711341 : ℝ) / 50000000)) (hi := ((-15422681 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342831039 : ℝ) / 100000000) = Real.log ((342831039 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((342831039 : ℝ) / 100000000) = ((342831039 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2327 : RB (Real.log ((141152339 : ℝ) / 100000000)) ((34466953 : ℝ) / 100000000) ((6893391 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((141152339 : ℝ) / 200000000)) (t := ((-58847661 : ℝ) / 341152339))
    (lo := ((-6969553 : ℝ) / 20000000)) (hi := ((-8711941 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141152339 : ℝ) / 100000000) = Real.log ((141152339 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141152339 : ℝ) / 100000000) = ((141152339 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2328 : RB (Real.log ((81689331 : ℝ) / 100000000)) ((-20224679 : ℝ) / 100000000) ((-10112339 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((81689331 : ℝ) / 100000000)) (t := ((-18310669 : ℝ) / 181689331))
    (lo := ((-20224679 : ℝ) / 100000000)) (hi := ((-10112339 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2329 : RB (Real.log ((41542193 : ℝ) / 50000000)) ((-926567 : ℝ) / 5000000) ((-18531339 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41542193 : ℝ) / 50000000)) (t := ((-8457807 : ℝ) / 91542193))
    (lo := ((-926567 : ℝ) / 5000000)) (hi := ((-18531339 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2330 : RB (Real.log ((83022577 : ℝ) / 100000000)) ((-18605761 : ℝ) / 100000000) ((-58143 : ℝ) / 312500) := by
  have hm := log_bounds_of_series (x := ((83022577 : ℝ) / 100000000)) (t := ((-16977423 : ℝ) / 183022577))
    (lo := ((-18605761 : ℝ) / 100000000)) (hi := ((-58143 : ℝ) / 312500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2331 : RB (Real.log ((83022579 : ℝ) / 100000000)) ((-9302879 : ℝ) / 50000000) ((-18605757 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83022579 : ℝ) / 100000000)) (t := ((-16977421 : ℝ) / 183022579))
    (lo := ((-9302879 : ℝ) / 50000000)) (hi := ((-18605757 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2332 : RB (Real.log ((45399823 : ℝ) / 100000000)) ((-78966199 : ℝ) / 100000000) ((-78966197 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45399823 : ℝ) / 50000000)) (t := ((-4600177 : ℝ) / 95399823))
    (lo := ((-241287 : ℝ) / 2500000)) (hi := ((-9651479 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45399823 : ℝ) / 100000000) = Real.log ((45399823 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45399823 : ℝ) / 100000000) = ((45399823 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2333 : RB (Real.log ((2598221 : ℝ) / 3125000)) ((-18460731 : ℝ) / 100000000) ((-1846073 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((2598221 : ℝ) / 3125000)) (t := ((-526779 : ℝ) / 5723221))
    (lo := ((-18460731 : ℝ) / 100000000)) (hi := ((-1846073 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2334 : RB (Real.log ((41571537 : ℝ) / 50000000)) ((-2307591 : ℝ) / 12500000) ((-18460727 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41571537 : ℝ) / 50000000)) (t := ((-8428463 : ℝ) / 91571537))
    (lo := ((-2307591 : ℝ) / 12500000)) (hi := ((-18460727 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2335 : RB (Real.log ((22717873 : ℝ) / 50000000)) ((-15777421 : ℝ) / 20000000) ((-78887103 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22717873 : ℝ) / 25000000)) (t := ((-2282127 : ℝ) / 47717873))
    (lo := ((-4786193 : ℝ) / 50000000)) (hi := ((-1914477 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22717873 : ℝ) / 50000000) = Real.log ((22717873 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22717873 : ℝ) / 50000000) = ((22717873 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2336 : RB (Real.log ((68706037 : ℝ) / 20000000)) ((123410479 : ℝ) / 100000000) ((61705241 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((68706037 : ℝ) / 80000000)) (t := ((-11293963 : ℝ) / 148706037))
    (lo := ((-15218957 : ℝ) / 100000000)) (hi := ((-3804739 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68706037 : ℝ) / 20000000) = Real.log ((68706037 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((68706037 : ℝ) / 20000000) = ((68706037 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2337 : RB (Real.log ((85882547 : ℝ) / 25000000)) ((1542631 : ℝ) / 1250000) ((123410483 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((85882547 : ℝ) / 100000000)) (t := ((-14117453 : ℝ) / 185882547))
    (lo := ((-3804739 : ℝ) / 25000000)) (hi := ((-3043791 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85882547 : ℝ) / 25000000) = Real.log ((85882547 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((85882547 : ℝ) / 25000000) = ((85882547 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2338 : RB (Real.log ((28206839 : ℝ) / 20000000)) ((34383219 : ℝ) / 100000000) ((34383221 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((28206839 : ℝ) / 40000000)) (t := ((-11793161 : ℝ) / 68206839))
    (lo := ((-34931499 : ℝ) / 100000000)) (hi := ((-17465749 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28206839 : ℝ) / 20000000) = Real.log ((28206839 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((28206839 : ℝ) / 20000000) = ((28206839 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2339 : RB (Real.log ((42854471 : ℝ) / 12500000)) ((123208133 : ℝ) / 100000000) ((15401017 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((42854471 : ℝ) / 50000000)) (t := ((-7145529 : ℝ) / 92854471))
    (lo := ((-15421303 : ℝ) / 100000000)) (hi := ((-7710651 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42854471 : ℝ) / 12500000) = Real.log ((42854471 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((42854471 : ℝ) / 12500000) = ((42854471 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2340 : RB (Real.log ((342835771 : ℝ) / 100000000)) ((61604067 : ℝ) / 50000000) ((123208137 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((342835771 : ℝ) / 400000000)) (t := ((-57164229 : ℝ) / 742835771))
    (lo := ((-7710651 : ℝ) / 50000000)) (hi := ((-15421301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342835771 : ℝ) / 100000000) = Real.log ((342835771 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((342835771 : ℝ) / 100000000) = ((342835771 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2341 : RB (Real.log ((141151537 : ℝ) / 100000000)) ((6893277 : ℝ) / 20000000) ((34466387 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((141151537 : ℝ) / 200000000)) (t := ((-58848463 : ℝ) / 341151537))
    (lo := ((-34848333 : ℝ) / 100000000)) (hi := ((-8712083 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141151537 : ℝ) / 100000000) = Real.log ((141151537 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141151537 : ℝ) / 100000000) = ((141151537 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2342 : RB (Real.log ((82716451 : ℝ) / 100000000)) ((-296487 : ℝ) / 1562500) ((-18975167 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((82716451 : ℝ) / 100000000)) (t := ((-17283549 : ℝ) / 182716451))
    (lo := ((-296487 : ℝ) / 1562500)) (hi := ((-18975167 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2343 : RB (Real.log ((16682377 : ℝ) / 20000000)) ((-18137939 : ℝ) / 100000000) ((-9068969 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16682377 : ℝ) / 20000000)) (t := ((-3317623 : ℝ) / 36682377))
    (lo := ((-18137939 : ℝ) / 100000000)) (hi := ((-9068969 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2344 : RB (Real.log ((83063209 : ℝ) / 100000000)) ((-579901 : ℝ) / 3125000) ((-18556831 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83063209 : ℝ) / 100000000)) (t := ((-16936791 : ℝ) / 183063209))
    (lo := ((-579901 : ℝ) / 3125000)) (hi := ((-18556831 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2345 : RB (Real.log ((20765803 : ℝ) / 25000000)) ((-4639207 : ℝ) / 25000000) ((-18556827 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20765803 : ℝ) / 25000000)) (t := ((-4234197 : ℝ) / 45765803))
    (lo := ((-4639207 : ℝ) / 25000000)) (hi := ((-18556827 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2346 : RB (Real.log ((22705971 : ℝ) / 50000000)) ((-78939509 : ℝ) / 100000000) ((-78939507 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22705971 : ℝ) / 25000000)) (t := ((-2294029 : ℝ) / 47705971))
    (lo := ((-962479 : ℝ) / 10000000)) (hi := ((-9624789 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22705971 : ℝ) / 50000000) = Real.log ((22705971 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22705971 : ℝ) / 50000000) = ((22705971 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2347 : RB (Real.log ((83182297 : ℝ) / 100000000)) ((-4603391 : ℝ) / 25000000) ((-18413563 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83182297 : ℝ) / 100000000)) (t := ((-16817703 : ℝ) / 183182297))
    (lo := ((-4603391 : ℝ) / 25000000)) (hi := ((-18413563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2348 : RB (Real.log ((831823 : ℝ) / 1000000)) ((-18413561 : ℝ) / 100000000) ((-460339 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((831823 : ℝ) / 1000000)) (t := ((-168177 : ℝ) / 1831823))
    (lo := ((-18413561 : ℝ) / 100000000)) (hi := ((-460339 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2349 : RB (Real.log ((4544743 : ℝ) / 10000000)) ((-78861393 : ℝ) / 100000000) ((-78861391 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4544743 : ℝ) / 5000000)) (t := ((-455257 : ℝ) / 9544743))
    (lo := ((-4773337 : ℝ) / 50000000)) (hi := ((-9546673 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4544743 : ℝ) / 10000000) = Real.log ((4544743 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((4544743 : ℝ) / 10000000) = ((4544743 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2350 : RB (Real.log ((85824177 : ℝ) / 25000000)) ((30835623 : ℝ) / 25000000) ((24668499 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((85824177 : ℝ) / 100000000)) (t := ((-14175823 : ℝ) / 185824177))
    (lo := ((-477717 : ℝ) / 3125000)) (hi := ((-15286943 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85824177 : ℝ) / 25000000) = Real.log ((85824177 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((85824177 : ℝ) / 25000000) = ((85824177 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2351 : RB (Real.log ((343296711 : ℝ) / 100000000)) ((123342493 : ℝ) / 100000000) ((3854453 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((343296711 : ℝ) / 400000000)) (t := ((-56703289 : ℝ) / 743296711))
    (lo := ((-15286943 : ℝ) / 100000000)) (hi := ((-7643471 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((343296711 : ℝ) / 100000000) = Real.log ((343296711 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((343296711 : ℝ) / 100000000) = ((343296711 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2352 : RB (Real.log ((141073573 : ℝ) / 100000000)) ((268837 : ℝ) / 781250) ((17205569 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((141073573 : ℝ) / 200000000)) (t := ((-58926427 : ℝ) / 341073573))
    (lo := ((-17451791 : ℝ) / 50000000)) (hi := ((-34903581 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141073573 : ℝ) / 100000000) = Real.log ((141073573 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141073573 : ℝ) / 100000000) = ((141073573 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2353 : RB (Real.log ((68521657 : ℝ) / 20000000)) ((61570879 : ℝ) / 50000000) ((123141761 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68521657 : ℝ) / 80000000)) (t := ((-11478343 : ℝ) / 148521657))
    (lo := ((-7743839 : ℝ) / 50000000)) (hi := ((-15487677 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68521657 : ℝ) / 20000000) = Real.log ((68521657 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((68521657 : ℝ) / 20000000) = ((68521657 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2354 : RB (Real.log ((10706509 : ℝ) / 3125000)) ((61570879 : ℝ) / 50000000) ((123141761 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10706509 : ℝ) / 12500000)) (t := ((-1793491 : ℝ) / 23206509))
    (lo := ((-7743839 : ℝ) / 50000000)) (hi := ((-15487677 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10706509 : ℝ) / 3125000) = Real.log ((10706509 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((10706509 : ℝ) / 3125000) = ((10706509 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2355 : RB (Real.log ((141190123 : ℝ) / 100000000)) ((17246859 : ℝ) / 50000000) ((862343 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((141190123 : ℝ) / 200000000)) (t := ((-58809877 : ℝ) / 341190123))
    (lo := ((-34821 : ℝ) / 100000)) (hi := ((-34820999 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141190123 : ℝ) / 100000000) = Real.log ((141190123 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141190123 : ℝ) / 100000000) = ((141190123 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2356 : RB (Real.log ((16633581 : ℝ) / 20000000)) ((-18430867 : ℝ) / 100000000) ((-9215433 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16633581 : ℝ) / 20000000)) (t := ((-3366419 : ℝ) / 36633581))
    (lo := ((-18430867 : ℝ) / 100000000)) (hi := ((-9215433 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2357 : RB (Real.log ((41930983 : ℝ) / 50000000)) ((-17599801 : ℝ) / 100000000) ((-87999 : ℝ) / 500000) := by
  have hm := log_bounds_of_series (x := ((41930983 : ℝ) / 50000000)) (t := ((-8069017 : ℝ) / 91930983))
    (lo := ((-17599801 : ℝ) / 100000000)) (hi := ((-87999 : ℝ) / 500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2358 : RB (Real.log ((83103363 : ℝ) / 100000000)) ((-9254251 : ℝ) / 50000000) ((-18508501 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83103363 : ℝ) / 100000000)) (t := ((-16896637 : ℝ) / 183103363))
    (lo := ((-9254251 : ℝ) / 50000000)) (hi := ((-18508501 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2359 : RB (Real.log ((41551683 : ℝ) / 50000000)) ((-9254249 : ℝ) / 50000000) ((-18508497 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41551683 : ℝ) / 50000000)) (t := ((-8448317 : ℝ) / 91551683))
    (lo := ((-9254249 : ℝ) / 50000000)) (hi := ((-18508497 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2360 : RB (Real.log ((45423913 : ℝ) / 100000000)) ((-616509 : ℝ) / 781250) ((-1578263 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((45423913 : ℝ) / 50000000)) (t := ((-4576087 : ℝ) / 95423913))
    (lo := ((-9598433 : ℝ) / 100000000)) (hi := ((-299951 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45423913 : ℝ) / 100000000) = Real.log ((45423913 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45423913 : ℝ) / 100000000) = ((45423913 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2361 : RB (Real.log ((16644213 : ℝ) / 20000000)) ((-18366969 : ℝ) / 100000000) ((-2295871 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((16644213 : ℝ) / 20000000)) (t := ((-3355787 : ℝ) / 36644213))
    (lo := ((-18366969 : ℝ) / 100000000)) (hi := ((-2295871 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2362 : RB (Real.log ((20805267 : ℝ) / 25000000)) ((-3673393 : ℝ) / 20000000) ((-4591741 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((20805267 : ℝ) / 25000000)) (t := ((-4194733 : ℝ) / 45805267))
    (lo := ((-3673393 : ℝ) / 20000000)) (hi := ((-4591741 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2363 : RB (Real.log ((45458973 : ℝ) / 100000000)) ((-78835997 : ℝ) / 100000000) ((-15767199 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((45458973 : ℝ) / 50000000)) (t := ((-4541027 : ℝ) / 95458973))
    (lo := ((-4760639 : ℝ) / 50000000)) (hi := ((-9521277 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45458973 : ℝ) / 100000000) = Real.log ((45458973 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45458973 : ℝ) / 100000000) = ((45458973 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2364 : RB (Real.log ((42883157 : ℝ) / 12500000)) ((123275049 : ℝ) / 100000000) ((30818763 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((42883157 : ℝ) / 50000000)) (t := ((-7116843 : ℝ) / 92883157))
    (lo := ((-15354387 : ℝ) / 100000000)) (hi := ((-7677193 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42883157 : ℝ) / 12500000) = Real.log ((42883157 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((42883157 : ℝ) / 12500000) = ((42883157 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2365 : RB (Real.log ((17153263 : ℝ) / 5000000)) ((2465501 : ℝ) / 2000000) ((123275053 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17153263 : ℝ) / 20000000)) (t := ((-2846737 : ℝ) / 37153263))
    (lo := ((-7677193 : ℝ) / 50000000)) (hi := ((-3070877 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17153263 : ℝ) / 5000000) = Real.log ((17153263 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((17153263 : ℝ) / 5000000) = ((17153263 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2366 : RB (Real.log ((35278171 : ℝ) / 25000000)) ((4304857 : ℝ) / 12500000) ((17219429 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((35278171 : ℝ) / 50000000)) (t := ((-14721829 : ℝ) / 85278171))
    (lo := ((-17437931 : ℝ) / 50000000)) (hi := ((-34875861 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35278171 : ℝ) / 25000000) = Real.log ((35278171 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((35278171 : ℝ) / 25000000) = ((35278171 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2367 : RB (Real.log ((1369531 : ℝ) / 400000)) ((123075907 : ℝ) / 100000000) ((12307591 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((1369531 : ℝ) / 1600000)) (t := ((-230469 : ℝ) / 2969531))
    (lo := ((-15553529 : ℝ) / 100000000)) (hi := ((-1944191 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1369531 : ℝ) / 400000) = Real.log ((1369531 : ℝ) / 1600000) + 2 * Real.log 2 := by
    rw [show ((1369531 : ℝ) / 400000) = ((1369531 : ℝ) / 1600000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2368 : RB (Real.log ((342382753 : ℝ) / 100000000)) ((30768977 : ℝ) / 25000000) ((123075911 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((342382753 : ℝ) / 400000000)) (t := ((-57617247 : ℝ) / 742382753))
    (lo := ((-1944191 : ℝ) / 12500000)) (hi := ((-15553527 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342382753 : ℝ) / 100000000) = Real.log ((342382753 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((342382753 : ℝ) / 100000000) = ((342382753 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2369 : RB (Real.log ((2824569 : ℝ) / 2000000)) ((1726043 : ℝ) / 5000000) ((17260431 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2824569 : ℝ) / 4000000)) (t := ((-1175431 : ℝ) / 6824569))
    (lo := ((-17396929 : ℝ) / 50000000)) (hi := ((-34793857 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2824569 : ℝ) / 2000000) = Real.log ((2824569 : ℝ) / 4000000) + 1 * Real.log 2 := by
    rw [show ((2824569 : ℝ) / 2000000) = ((2824569 : ℝ) / 4000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2370 : RB (Real.log ((10452291 : ℝ) / 12500000)) ((-8945373 : ℝ) / 50000000) ((-3578149 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((10452291 : ℝ) / 12500000)) (t := ((-2047709 : ℝ) / 22952291))
    (lo := ((-8945373 : ℝ) / 50000000)) (hi := ((-3578149 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2371 : RB (Real.log ((16862207 : ℝ) / 20000000)) ((-17065743 : ℝ) / 100000000) ((-8532871 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16862207 : ℝ) / 20000000)) (t := ((-3137793 : ℝ) / 36862207))
    (lo := ((-17065743 : ℝ) / 100000000)) (hi := ((-8532871 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2372 : RB (Real.log ((83143051 : ℝ) / 100000000)) ((-4615189 : ℝ) / 25000000) ((-3692151 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((83143051 : ℝ) / 100000000)) (t := ((-16856949 : ℝ) / 183143051))
    (lo := ((-4615189 : ℝ) / 25000000)) (hi := ((-3692151 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2373 : RB (Real.log ((41571527 : ℝ) / 50000000)) ((-1153797 : ℝ) / 6250000) ((-18460751 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41571527 : ℝ) / 50000000)) (t := ((-8428473 : ℝ) / 91571527))
    (lo := ((-1153797 : ℝ) / 6250000)) (hi := ((-18460751 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2374 : RB (Real.log ((2271787 : ℝ) / 5000000)) ((-39443559 : ℝ) / 50000000) ((-19721779 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2271787 : ℝ) / 2500000)) (t := ((-228213 : ℝ) / 4771787))
    (lo := ((-9572399 : ℝ) / 100000000)) (hi := ((-4786199 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2271787 : ℝ) / 5000000) = Real.log ((2271787 : ℝ) / 2500000) - 1 * Real.log 2 := by
    rw [show ((2271787 : ℝ) / 5000000) = ((2271787 : ℝ) / 2500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2375 : RB (Real.log ((83259393 : ℝ) / 100000000)) ((-4580231 : ℝ) / 25000000) ((-18320923 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83259393 : ℝ) / 100000000)) (t := ((-16740607 : ℝ) / 183259393))
    (lo := ((-4580231 : ℝ) / 25000000)) (hi := ((-18320923 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2376 : RB (Real.log ((20814849 : ℝ) / 25000000)) ((-458023 : ℝ) / 2500000) ((-18320919 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20814849 : ℝ) / 25000000)) (t := ((-4185151 : ℝ) / 45814849))
    (lo := ((-458023 : ℝ) / 2500000)) (hi := ((-18320919 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2377 : RB (Real.log ((2273519 : ℝ) / 5000000)) ((-19702727 : ℝ) / 25000000) ((-39405453 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2273519 : ℝ) / 2500000)) (t := ((-226481 : ℝ) / 4773519))
    (lo := ((-9496189 : ℝ) / 100000000)) (hi := ((-2374047 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2273519 : ℝ) / 5000000) = Real.log ((2273519 : ℝ) / 2500000) - 1 * Real.log 2 := by
    rw [show ((2273519 : ℝ) / 5000000) = ((2273519 : ℝ) / 2500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2378 : RB (Real.log ((342835803 : ℝ) / 100000000)) ((123208143 : ℝ) / 100000000) ((61604073 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((342835803 : ℝ) / 400000000)) (t := ((-57164197 : ℝ) / 742835803))
    (lo := ((-15421293 : ℝ) / 100000000)) (hi := ((-3855323 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342835803 : ℝ) / 100000000) = Real.log ((342835803 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((342835803 : ℝ) / 100000000) = ((342835803 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2379 : RB (Real.log ((342835807 : ℝ) / 100000000)) ((7700509 : ℝ) / 6250000) ((123208147 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((342835807 : ℝ) / 400000000)) (t := ((-57164193 : ℝ) / 742835807))
    (lo := ((-3855323 : ℝ) / 25000000)) (hi := ((-15421291 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342835807 : ℝ) / 100000000) = Real.log ((342835807 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((342835807 : ℝ) / 100000000) = ((342835807 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2380 : RB (Real.log ((141151531 : ℝ) / 100000000)) ((34466381 : ℝ) / 100000000) ((34466383 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((141151531 : ℝ) / 200000000)) (t := ((-58848469 : ℝ) / 341151531))
    (lo := ((-34848337 : ℝ) / 100000000)) (hi := ((-2178021 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141151531 : ℝ) / 100000000) = Real.log ((141151531 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141151531 : ℝ) / 100000000) = ((141151531 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2381 : RB (Real.log ((34215913 : ℝ) / 10000000)) ((123010573 : ℝ) / 100000000) ((7688161 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((34215913 : ℝ) / 40000000)) (t := ((-5784087 : ℝ) / 74215913))
    (lo := ((-15618863 : ℝ) / 100000000)) (hi := ((-7809431 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34215913 : ℝ) / 10000000) = Real.log ((34215913 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((34215913 : ℝ) / 10000000) = ((34215913 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2382 : RB (Real.log ((171079567 : ℝ) / 50000000)) ((61505287 : ℝ) / 50000000) ((123010577 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((171079567 : ℝ) / 200000000)) (t := ((-28920433 : ℝ) / 371079567))
    (lo := ((-7809431 : ℝ) / 50000000)) (hi := ((-15618861 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((171079567 : ℝ) / 50000000) = Real.log ((171079567 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((171079567 : ℝ) / 50000000) = ((171079567 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2383 : RB (Real.log ((70633261 : ℝ) / 50000000)) ((17273907 : ℝ) / 50000000) ((4318477 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((70633261 : ℝ) / 100000000)) (t := ((-29366739 : ℝ) / 170633261))
    (lo := ((-4345863 : ℝ) / 12500000)) (hi := ((-34766903 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70633261 : ℝ) / 50000000) = Real.log ((70633261 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70633261 : ℝ) / 50000000) = ((70633261 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2384 : RB (Real.log ((4203387 : ℝ) / 5000000)) ((-17354729 : ℝ) / 100000000) ((-2169341 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4203387 : ℝ) / 5000000)) (t := ((-796613 : ℝ) / 9203387))
    (lo := ((-17354729 : ℝ) / 100000000)) (hi := ((-2169341 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2385 : RB (Real.log ((84759107 : ℝ) / 100000000)) ((-16535699 : ℝ) / 100000000) ((-8267849 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((84759107 : ℝ) / 100000000)) (t := ((-15240893 : ℝ) / 184759107))
    (lo := ((-16535699 : ℝ) / 100000000)) (hi := ((-8267849 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2386 : RB (Real.log ((83182273 : ℝ) / 100000000)) ((-18413593 : ℝ) / 100000000) ((-2301699 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((83182273 : ℝ) / 100000000)) (t := ((-16817727 : ℝ) / 183182273))
    (lo := ((-18413593 : ℝ) / 100000000)) (hi := ((-2301699 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2387 : RB (Real.log ((20795569 : ℝ) / 25000000)) ((-18413589 : ℝ) / 100000000) ((-4603397 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((20795569 : ℝ) / 25000000)) (t := ((-4204431 : ℝ) / 45795569))
    (lo := ((-18413589 : ℝ) / 100000000)) (hi := ((-4603397 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2388 : RB (Real.log ((45447423 : ℝ) / 100000000)) ((-2464419 : ℝ) / 3125000) ((-39430703 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((45447423 : ℝ) / 50000000)) (t := ((-4552577 : ℝ) / 95447423))
    (lo := ((-9546689 : ℝ) / 100000000)) (hi := ((-149167 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45447423 : ℝ) / 100000000) = Real.log ((45447423 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45447423 : ℝ) / 100000000) = ((45447423 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2389 : RB (Real.log ((83297283 : ℝ) / 100000000)) ((-9137713 : ℝ) / 50000000) ((-731017 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((83297283 : ℝ) / 100000000)) (t := ((-16702717 : ℝ) / 183297283))
    (lo := ((-9137713 : ℝ) / 50000000)) (hi := ((-731017 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2390 : RB (Real.log ((41648643 : ℝ) / 50000000)) ((-9137711 : ℝ) / 50000000) ((-18275421 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41648643 : ℝ) / 50000000)) (t := ((-8351357 : ℝ) / 91648643))
    (lo := ((-9137711 : ℝ) / 50000000)) (hi := ((-18275421 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2391 : RB (Real.log ((11370413 : ℝ) / 25000000)) ((-78786121 : ℝ) / 100000000) ((-78786119 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11370413 : ℝ) / 12500000)) (t := ((-1129587 : ℝ) / 23870413))
    (lo := ((-4735701 : ℝ) / 50000000)) (hi := ((-9471401 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11370413 : ℝ) / 25000000) = Real.log ((11370413 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11370413 : ℝ) / 25000000) = ((11370413 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2392 : RB (Real.log ((1070651 : ℝ) / 312500)) ((15392721 : ℝ) / 12500000) ((123141771 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1070651 : ℝ) / 1250000)) (t := ((-179349 : ℝ) / 2320651))
    (lo := ((-3871917 : ℝ) / 25000000)) (hi := ((-15487667 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1070651 : ℝ) / 312500) = Real.log ((1070651 : ℝ) / 1250000) + 2 * Real.log 2 := by
    rw [show ((1070651 : ℝ) / 312500) = ((1070651 : ℝ) / 1250000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2393 : RB (Real.log ((342608323 : ℝ) / 100000000)) ((123141769 : ℝ) / 100000000) ((30785443 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((342608323 : ℝ) / 400000000)) (t := ((-57391677 : ℝ) / 742608323))
    (lo := ((-15487667 : ℝ) / 100000000)) (hi := ((-7743833 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342608323 : ℝ) / 100000000) = Real.log ((342608323 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((342608323 : ℝ) / 100000000) = ((342608323 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2394 : RB (Real.log ((141190117 : ℝ) / 100000000)) ((17246857 : ℝ) / 50000000) ((8623429 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((141190117 : ℝ) / 200000000)) (t := ((-58809883 : ℝ) / 341190117))
    (lo := ((-8705251 : ℝ) / 25000000)) (hi := ((-34821003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((141190117 : ℝ) / 100000000) = Real.log ((141190117 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((141190117 : ℝ) / 100000000) = ((141190117 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2395 : RB (Real.log ((341937411 : ℝ) / 100000000)) ((15368219 : ℝ) / 12500000) ((24589151 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((341937411 : ℝ) / 400000000)) (t := ((-58062589 : ℝ) / 741937411))
    (lo := ((-3920921 : ℝ) / 25000000)) (hi := ((-15683683 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((341937411 : ℝ) / 100000000) = Real.log ((341937411 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((341937411 : ℝ) / 100000000) = ((341937411 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2396 : RB (Real.log ((170968707 : ℝ) / 50000000)) ((122945753 : ℝ) / 100000000) ((30736439 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((170968707 : ℝ) / 200000000)) (t := ((-29031293 : ℝ) / 370968707))
    (lo := ((-15683683 : ℝ) / 100000000)) (hi := ((-7841841 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((170968707 : ℝ) / 50000000) = Real.log ((170968707 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((170968707 : ℝ) / 50000000) = ((170968707 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2397 : RB (Real.log ((7065217 : ℝ) / 5000000)) ((34574581 : ℝ) / 100000000) ((34574583 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7065217 : ℝ) / 10000000)) (t := ((-2934783 : ℝ) / 17065217))
    (lo := ((-34740137 : ℝ) / 100000000)) (hi := ((-4342517 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7065217 : ℝ) / 5000000) = Real.log ((7065217 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((7065217 : ℝ) / 5000000) = ((7065217 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2398 : RB (Real.log ((8451613 : ℝ) / 10000000)) ((-16822779 : ℝ) / 100000000) ((-8411389 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8451613 : ℝ) / 10000000)) (t := ((-1548387 : ℝ) / 18451613))
    (lo := ((-16822779 : ℝ) / 100000000)) (hi := ((-8411389 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2399 : RB (Real.log ((42603091 : ℝ) / 50000000)) ((-800481 : ℝ) / 5000000) ((-16009619 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42603091 : ℝ) / 50000000)) (t := ((-7396909 : ℝ) / 92603091))
    (lo := ((-800481 : ℝ) / 5000000)) (hi := ((-16009619 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
