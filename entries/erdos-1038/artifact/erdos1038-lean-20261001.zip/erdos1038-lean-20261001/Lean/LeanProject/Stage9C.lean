import LeanProject.Stage9B

/-!
# EP-1038, Stage 9, Definition 9.3: the terminal family, `q_s`, `Λ(q)` and `D`

In the `p = 1/u` variable of `Stage9B`:
* `Aq q = log H / log q` with `H = D₀ q = 2q/(1+q)²`; this is the choice `C(A) = 0` (`CA_Aq`).
* `0 < A(q)` for `0 < q < 1` (`Aq_pos`); `A(q) < s ↔ f(q) > 0` where
  `f(q) = (1+q) log(2/(1+q)²) + 2q log q` (`Aq_lt_s_iff`); `C(A) > 0` for `A > A(q)` (`CA_pos`).
* `f` is strictly decreasing on `[0, 1]`, `f(0) = log 2 > 0 > f(1)`, so there is a unique
  `q_s ∈ (0, 1)` with `{q ∈ (0,1) : f q > 0} = (0, q_s)` (`exists_qs`).
* `Lam q = |{V_{μ_{A(q)}} < 0}|` and `Lam q = H(p₋ + 1/p₋ - p₊ - 1/p₊)` with `G_{A(q)}(p±) = 0` (`Lam_eq`).
* `Dval = inf {Lam q : 0 < q < 1, f q > 0} = inf_{0 < q < q_s} Λ(q)`.
-/

open Real Set Filter Topology MeasureTheory

namespace EP1038.Stage9

open Arc

/-- `A(q) = log H / log q`, `H = D₀ q`. -/
noncomputable def Aq (q : ℝ) : ℝ := Real.log (D0q q * q) / Real.log q

/-- `f(q) = (1+q) log(2/(1+q)²) + 2q log q`. -/
noncomputable def fq (q : ℝ) : ℝ := (1 + q) * Real.log (2 / (1 + q) ^ 2) + 2 * (q * Real.log q)

theorem log_q_neg {q : ℝ} (hq : 0 < q) (hq1 : q < 1) : Real.log q < 0 := Real.log_neg hq hq1

theorem log_H_eq {q : ℝ} (hq : 0 < q) :
    Real.log (D0q q * q) = Real.log (2 / (1 + q) ^ 2) + Real.log q := by
  unfold D0q
  rw [Real.log_mul (by positivity) hq.ne']

theorem H_lt_one {q : ℝ} (hq : 0 < q) : D0q q * q < 1 := by
  unfold D0q
  rw [div_mul_eq_mul_div, div_lt_one (by positivity)]
  nlinarith

theorem CA_Aq {q : ℝ} (hq : 0 < q) (hq1 : q < 1) : CA (Aq q) q = 0 := by
  unfold CA Aq
  rw [div_mul_cancel₀ _ (log_q_neg hq hq1).ne, sub_self]

theorem Aq_pos {q : ℝ} (hq : 0 < q) (hq1 : q < 1) : 0 < Aq q := by
  unfold Aq
  have hH : Real.log (D0q q * q) < 0 :=
    Real.log_neg (mul_pos (D0q_pos q hq.le) hq) (H_lt_one hq)
  exact div_pos_of_neg_of_neg hH (log_q_neg hq hq1)

/-- `A(q) < s ↔ f(q) > 0`, written as `A(q)(1+q) < 1 - q`. -/
theorem Aq_lt_s_iff {q : ℝ} (hq : 0 < q) (hq1 : q < 1) : Aq q * (1 + q) < 1 - q ↔ 0 < fq q := by
  have hτ := log_q_neg hq hq1
  unfold Aq fq
  rw [log_H_eq hq, div_mul_eq_mul_div, div_lt_iff_of_neg hτ]
  constructor <;> intro h <;> nlinarith

theorem CA_pos {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA : Aq q < A) : 0 < CA A q := by
  have hτ := log_q_neg hq hq1
  have e : CA A q = (Aq q - A) * Real.log q := by
    unfold CA Aq
    rw [sub_mul, div_mul_cancel₀ _ hτ.ne]
  rw [e]
  exact mul_pos_of_neg_of_neg (by linarith) hτ

/-! ### `f` and `q_s` -/

theorem fq_eq {q : ℝ} (hq : 0 ≤ q) :
    fq q = (1 + q) * (Real.log 2 - 2 * Real.log (1 + q)) + 2 * (q * Real.log q) := by
  unfold fq
  rw [Real.log_div (by norm_num) (by positivity), Real.log_pow]
  push_cast
  ring

theorem fq_continuousOn : ContinuousOn fq (Icc 0 1) := by
  intro q hq
  have h1 : (0 : ℝ) < 1 + q := by linarith [hq.1]
  have hc : ContinuousAt (fun q : ℝ => (1 + q) * Real.log (2 / (1 + q) ^ 2)) q := by
    refine (continuous_const.add continuous_id).continuousAt.mul ?_
    exact (continuousAt_const.div ((continuous_const.add continuous_id).pow 2).continuousAt
      (pow_pos h1 2).ne').log (div_pos two_pos (pow_pos h1 2)).ne'
  exact (hc.add ((Real.continuous_mul_log.const_mul 2).continuousAt)).continuousWithinAt

theorem hasDerivAt_fq {q : ℝ} (hq : 0 < q) :
    HasDerivAt fq (Real.log 2 - 2 * Real.log (1 + q) + 2 * Real.log q) q := by
  have h1 : (0 : ℝ) < 1 + q := by linarith
  have d1 : HasDerivAt (fun x : ℝ => 1 + x) 1 q := by simpa using (hasDerivAt_id q).const_add 1
  have d2 := d1.log h1.ne'
  have d3 : HasDerivAt (fun x => x * Real.log x) (Real.log q + 1) q := Real.hasDerivAt_mul_log hq.ne'
  have := (d1.mul ((d2.const_mul 2).const_sub (Real.log 2))).add (d3.const_mul 2)
  have heq : fq =ᶠ[𝓝 q] fun x => (1 + x) * (Real.log 2 - 2 * Real.log (1 + x)) + 2 * (x * Real.log x) := by
    filter_upwards [Ioi_mem_nhds hq] with x hx
    exact fq_eq (le_of_lt hx)
  refine (this.congr_of_eventuallyEq heq).congr_deriv ?_
  field_simp
  ring

theorem deriv_fq_neg {q : ℝ} (hq : 0 < q) (hq1 : q < 1) :
    Real.log 2 - 2 * Real.log (1 + q) + 2 * Real.log q < 0 := by
  have h1 : (0 : ℝ) < 1 + q := by linarith
  have e1 : Real.log 2 + 2 * Real.log q = Real.log (2 * q ^ 2) := by
    rw [Real.log_mul (by norm_num) (by positivity), Real.log_pow]; push_cast; ring
  have e2 : 2 * Real.log (1 + q) = Real.log ((1 + q) ^ 2) := by
    rw [Real.log_pow]; push_cast; ring
  have : Real.log (2 * q ^ 2) < Real.log ((1 + q) ^ 2) :=
    Real.log_lt_log (by positivity) (by nlinarith)
  linarith

theorem fq_strictAntiOn : StrictAntiOn fq (Icc 0 1) := by
  refine strictAntiOn_of_deriv_neg (convex_Icc 0 1) fq_continuousOn ?_
  intro q hq
  rw [interior_Icc] at hq
  rw [(hasDerivAt_fq hq.1).deriv]
  exact deriv_fq_neg hq.1 hq.2

theorem fq_zero : fq 0 = Real.log 2 := by
  unfold fq
  simp

theorem fq_one : fq 1 = -(2 * Real.log 2) := by
  unfold fq
  rw [show (2 : ℝ) / (1 + 1) ^ 2 = 2⁻¹ by norm_num, Real.log_inv, Real.log_one]
  ring

/-- **Definition 9.3**: `f` has a unique zero `q_s ∈ (0, 1)`, and `{q ∈ (0,1) : f q > 0} = (0, q_s)`. -/
theorem exists_qs : ∃ qs, 0 < qs ∧ qs < 1 ∧ fq qs = 0 ∧
    ∀ q, 0 < q → q < 1 → (0 < fq q ↔ q < qs) := by
  have hl2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  obtain ⟨qs, hqsI, hqs⟩ := intermediate_value_Icc' (zero_le_one' ℝ) fq_continuousOn
    (show (0 : ℝ) ∈ Icc (fq 1) (fq 0) by rw [fq_zero, fq_one]; constructor <;> linarith)
  have hqs0 : 0 < qs := by
    rcases hqsI.1.lt_or_eq with h | h
    · exact h
    · rw [← h, fq_zero] at hqs; linarith
  have hqs1 : qs < 1 := by
    rcases hqsI.2.lt_or_eq with h | h
    · exact h
    · rw [h, fq_one] at hqs; linarith
  refine ⟨qs, hqs0, hqs1, hqs, fun q hq hq1 => ?_⟩
  rw [← hqs]
  exact StrictAntiOn.lt_iff_gt fq_strictAntiOn ⟨hqs0.le, hqs1.le⟩ ⟨hq.le, hq1.le⟩

/-! ### `Λ(q)` and `D` -/

/-- `Λ(q) = |E_{μ_{A(q)}}|` (in the shifted variable `y = x + 1`). -/
noncomputable def Lam (q : ℝ) : ℝ := (volume {y | VA (Aq q) q y < 0}).toReal

/-- The admissible parameters `0 < q < q_s`. -/
def Qadm : Set ℝ := {q | 0 < q ∧ q < 1 ∧ 0 < fq q}

/-- **Definition 9.3**: `D = inf_{0 < q < q_s} Λ(q)`. -/
noncomputable def Dval : ℝ := sInf (Lam '' Qadm)

/-- `Λ(q) = H(p₋ + 1/p₋ - p₊ - 1/p₊)` with `G_{A(q)}(p±) = 0`, `0 < p₋ < q < p₊ < 1`. -/
theorem Lam_eq {q : ℝ} (hq : q ∈ Qadm) :
    ∃ pm pp, 0 < pm ∧ pm < q ∧ q < pp ∧ pp < 1 ∧ GA (Aq q) q pm = 0 ∧ GA (Aq q) q pp = 0 ∧
      Lam q = D0q q * q * (pm + 1 / pm - pp - 1 / pp) := by
  obtain ⟨hq0, hq1, hf⟩ := hq
  have hC : 0 ≤ CA (Aq q) q := (CA_Aq hq0 hq1).symm.le
  obtain ⟨pm, pp, hpm0, hpmq, hqpp, hpp1, hGm, hGp, hvol, -⟩ :=
    volume_sublevel_VA hq0 hq1 (Aq_pos hq0 hq1) ((Aq_lt_s_iff hq0 hq1).mpr hf) hC
  rw [CA_Aq hq0 hq1] at hGm hGp
  refine ⟨pm, pp, hpm0, hpmq, hqpp, hpp1, hGm, hGp, ?_⟩
  unfold Lam
  rw [hvol, ENNReal.toReal_ofReal]
  have hlt := xoff_strictMonoOn (D0q_pos q hq0.le) hq0 ⟨hpm0, by linarith⟩ ⟨by linarith, hpp1⟩
    (by linarith)
  have hlen : xoff (D0q q) q pp - xoff (D0q q) q pm =
      D0q q * q * (pm + 1 / pm - pp - 1 / pp) := by
    unfold xoff; ring
  linarith

theorem Lam_nonneg (q : ℝ) : 0 ≤ Lam q := ENNReal.toReal_nonneg

theorem Qadm_nonempty : Qadm.Nonempty := by
  obtain ⟨qs, hqs0, hqs1, -, hiff⟩ := exists_qs
  exact ⟨qs / 2, by linarith, by linarith, (hiff _ (by linarith) (by linarith)).mpr (by linarith)⟩

theorem Dval_le_Lam {q : ℝ} (hq : q ∈ Qadm) : Dval ≤ Lam q :=
  csInf_le ⟨0, by rintro _ ⟨x, -, rfl⟩; exact Lam_nonneg x⟩ ⟨q, hq, rfl⟩

theorem exists_Lam_lt {ε : ℝ} (hε : 0 < ε) : ∃ q ∈ Qadm, Lam q < Dval + ε := by
  obtain ⟨_, ⟨q, hq, rfl⟩, h⟩ := exists_lt_of_csInf_lt (Qadm_nonempty.image Lam)
    (lt_add_of_pos_right Dval hε)
  exact ⟨q, hq, h⟩

end EP1038.Stage9
