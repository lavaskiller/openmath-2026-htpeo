import LeanProject.ReferenceSeparation

/-!
# The first reference row and its certificate interface

The entire R1 interval satisfies the basic reference hypotheses. A certified
negative exterior value supplies the actual separated reference. The numeric
certificate value and scalar margins remain explicit inputs.
-/

open Real Set

namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

noncomputable def r1A (k : ℝ) : ℝ := 1153 / 500 - k / 4

theorem r1_k_pos {k : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) : 0 < k := by
  linarith [hk.1]

theorem r1_a_bounds {k : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) :
    1781 / 1000 ≤ r1A k ∧ r1A k ≤ 973 / 500 := by
  unfold r1A
  constructor <;> linarith [hk.1, hk.2]

theorem r1_a_mem {k : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) : r1A k ∈ Ico (1 : ℝ) 2 := by
  have h := r1_a_bounds hk
  constructor <;> linarith [h.1, h.2]

theorem r1_a_pos {k : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) : 0 < r1A k :=
  lt_of_lt_of_le zero_lt_one (r1_a_mem hk).1

theorem r1_H1_strict {k : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) :
    2 * (k / (k + 1)) ^ 2 < r1A k := by
  have hk0 := r1_k_pos hk
  have hden : 0 < k + 1 := by linarith
  have hrat : k / (k + 1) ≤ (21 : ℝ) / 31 := by
    apply (div_le_iff₀ hden).mpr
    linarith [hk.2]
  have hnn : 0 ≤ k / (k + 1) := (div_pos hk0 hden).le
  have hprod := mul_nonneg (sub_nonneg.mpr hrat)
    (show (0 : ℝ) ≤ 21 / 31 + k / (k + 1) by positivity)
  have hsq : 2 * (k / (k + 1)) ^ 2 < 1 := by nlinarith
  exact hsq.trans_le (r1_a_mem hk).1

theorem r1_H1 {k : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) :
    2 * (k / (k + 1)) ^ 2 ≤ r1A k := (r1_H1_strict hk).le

theorem r1_density_nonneg {k : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) :
    ∀ θ, 0 ≤ alpha k (qa (r1A k)) θ :=
  (eta_nonneg_iff (r1_a_pos hk) (r1_a_mem hk).2 (r1_k_pos hk)).mpr (r1_H1 hk)

noncomputable def r1Reference {k v : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10))
    (hvq : qa (r1A k) < v) (hv1 : v < 1) (hE : certE k (r1A k) v < 0) : SeparatedReference :=
  referenceOfCertificate (r1_k_pos hk) (r1_a_pos hk) (r1_a_mem hk).2 (r1_H1 hk) hvq hv1 hE

theorem r1Reference_k {k v : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10))
    (hvq : qa (r1A k) < v) (hv1 : v < 1) (hE : certE k (r1A k) v < 0) :
    (r1Reference hk hvq hv1 hE).angles.k = k := rfl

theorem r1Reference_separator {k v : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10))
    (hvq : qa (r1A k) < v) (hv1 : v < 1) (hE : certE k (r1A k) v < 0) :
    (r1Reference hk hvq hv1 hE).separator = certPoint (r1A k) v := rfl

theorem r1Reference_platform {k v : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10))
    (hvq : qa (r1A k) < v) (hv1 : v < 1) (hE : certE k (r1A k) v < 0) :
    let R := r1Reference hk hvq hv1 hE
    (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) :=
  referenceOfCertificate_platform (r1_k_pos hk) (r1_a_pos hk) (r1_a_mem hk).2 (r1_H1 hk) hvq hv1 hE

theorem r1_certificate_reference_exists {k v : ℝ} (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10))
    (hvq : qa (r1A k) < v) (hv1 : v < 1) (hE : certE k (r1A k) v < 0) :
    ∃ R : SeparatedReference, R.angles.k = k ∧
      (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) :=
  ⟨r1Reference hk hvq hv1 hE, r1Reference_k hk hvq hv1 hE, r1Reference_platform hk hvq hv1 hE⟩

theorem r1_reference_exists_of_upper_bound {k v ehi : ℝ}
    (hk : k ∈ Icc (36 / 25 : ℝ) (21 / 10)) (hvq : qa (r1A k) < v) (hv1 : v < 1)
    (hbound : certE k (r1A k) v ≤ ehi) (hneg : ehi < 0) :
    ∃ R : SeparatedReference, R.angles.k = k ∧
      (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) :=
  r1_certificate_reference_exists hk hvq hv1 (hbound.trans_lt hneg)

/-- A whole parameter slab supplies eligible references from a common certified
test point and a negative upper bound. No interval checker is assumed sound. -/
theorem r1_reference_on_slab {lo hi v ehi : ℝ}
    (hsub : Icc lo hi ⊆ Icc (36 / 25 : ℝ) (21 / 10))
    (hvq : ∀ k ∈ Icc lo hi, qa (r1A k) < v) (hv1 : v < 1)
    (hbound : ∀ k ∈ Icc lo hi, certE k (r1A k) v ≤ ehi) (hneg : ehi < 0) :
    ∀ k ∈ Icc lo hi, ∃ R : SeparatedReference, R.angles.k = k ∧
      (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) := by
  intro k hk
  exact r1_reference_exists_of_upper_bound (hsub hk) (hvq k hk) hv1 (hbound k hk) hneg

theorem r1_normal_form_strict_lower {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (hk : a.k ∈ Icc (36 / 25 : ℝ) (21 / 10)) {v L : ℝ}
    (hvq : qa (r1A a.k) < v) (hv1 : v < 1) (hE : certE a.k (r1A a.k) v < 0)
    (hscalar : ScalarPositive (r1Reference hk hvq hv1 hE)
      (calibratedCeff (r1Reference hk hvq hv1 hE) L)) : L < a.J :=
  normal_form_strict_lower_of_scalarPositive (r1Reference hk hvq hv1 hE) a hres
    (r1Reference_k hk hvq hv1 hE) (r1Reference_platform hk hvq hv1 hE) rfl hscalar

end EP1038.ReferenceCert
