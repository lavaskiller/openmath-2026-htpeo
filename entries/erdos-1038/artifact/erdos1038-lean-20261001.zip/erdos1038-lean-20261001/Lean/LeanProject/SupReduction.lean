import LeanProject.PhiSeries

/-!
# EP-1038: the reduction of Lemma 6.3 (roadmap 15b) and the formal partial supremum

* `extreme_points` (proof.md Lemma 6.1): for roots in `[-1, 1]`, `n ≥ 1`, the closed sublevel set
  `K̄ = {|f| ≤ 1}` has a least and a greatest element `α ≤ β` with `|f(α)| = |f(β)| = 1`.
* `reduce_left`: the case `M = -α` of Lemma 6.3. Shift by `M`, take `y = β + M = max(K̄ + M)`
  (so Lemma 6.2 is not needed), and apply `two_atom_branch`; volumes are translation invariant.
* `sup_two_atom`: if `|S_f| ≥ 2√2`, then `M = max(-α, β) ∉ (√2, 7/4]` (the case `M = β` by the
  reflection `r ↦ -r`).
* `sup_counterexample_far`: if `|S_f| > 2√2`, then `M > 7/4`.

The arcsine branch `M ∈ (7/4, 2]` and the full `sup ≤ 2√2` are in `Supremum.lean` (Lemma 6.6′).
-/
open Real MeasureTheory

namespace EP1038

/-- The closed sublevel set `K̄ = {x : |∏ (x - r_i)| ≤ 1}`. -/
def closedSublevel {n : ℕ} (r : Fin n → ℝ) : Set ℝ := {x : ℝ | |∏ i, (x - r i)| ≤ 1}

theorem continuous_absProd {n : ℕ} (r : Fin n → ℝ) :
    Continuous fun x : ℝ => |∏ i, (x - r i)| := by fun_prop

theorem sublevel_subset_closed {n : ℕ} (r : Fin n → ℝ) : sublevel r ⊆ closedSublevel r := by
  intro x hx
  have h : |∏ i, (x - r i)| < 1 := hx
  exact le_of_lt h

theorem closedSublevel_subset_Icc {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) : closedSublevel r ⊆ Set.Icc (-3) 3 := by
  intro x hx
  simp only [closedSublevel, Set.mem_ofPred_eq] at hx
  by_contra hc
  rw [Set.mem_Icc, not_and_or, not_le, not_le] at hc
  have h2 : ∀ i, (2 : ℝ) ≤ |x - r i| := by
    intro i
    obtain ⟨a, b⟩ := hr i
    rcases hc with h | h
    · rw [abs_of_neg (by linarith)]; linarith
    · rw [abs_of_pos (by linarith)]; linarith
  have hp : (2 : ℝ) ^ n ≤ |∏ i, (x - r i)| := by
    rw [Finset.abs_prod]
    calc (2 : ℝ) ^ n = ∏ _i : Fin n, (2 : ℝ) := by simp
      _ ≤ ∏ i, |x - r i| := by gcongr with i; exact h2 i
  have h22 : (2 : ℝ) ≤ 2 ^ n := le_self_pow₀ (by norm_num) (Nat.pos_iff_ne_zero.mp hn)
  linarith

/-- **Lemma 6.1 (extreme points)**: `K̄` has a least and a greatest element `α ≤ β`, both with
`|f| = 1`, and `K̄ ⊆ [α, β]`. -/
theorem extreme_points {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    ∃ α β : ℝ, |∏ i, (α - r i)| = 1 ∧ |∏ i, (β - r i)| = 1 ∧
      closedSublevel r ⊆ Set.Icc α β := by
  set K := closedSublevel r with hK
  have hclosed : IsClosed K := isClosed_le (continuous_absProd r) continuous_const
  have hne : K.Nonempty := by
    refine ⟨r ⟨0, hn⟩, ?_⟩
    show |∏ i, (r ⟨0, hn⟩ - r i)| ≤ 1
    rw [Finset.prod_eq_zero (Finset.mem_univ ⟨0, hn⟩) (sub_self _), abs_zero]
    exact zero_le_one
  have hsub := closedSublevel_subset_Icc hn r hr
  have hbb : BddBelow K := ⟨-3, fun x hx => (hsub hx).1⟩
  have hba : BddAbove K := ⟨3, fun x hx => (hsub hx).2⟩
  have hopen : IsOpen {x : ℝ | |∏ i, (x - r i)| < 1} := isOpen_lt (continuous_absProd r) continuous_const
  refine ⟨sInf K, sSup K, ?_, ?_, fun x hx => ⟨csInf_le hbb hx, le_csSup hba hx⟩⟩
  · have hmem : sInf K ∈ K := hclosed.csInf_mem hne hbb
    apply le_antisymm hmem
    by_contra hlt
    push Not at hlt
    obtain ⟨ε, hε, hball⟩ := Metric.isOpen_iff.mp hopen (sInf K) hlt
    have hx : sInf K - ε / 2 ∈ Metric.ball (sInf K) ε := by
      rw [Metric.mem_ball, Real.dist_eq, abs_of_neg (by linarith)]; linarith
    have h' : |∏ i, (sInf K - ε / 2 - r i)| < 1 := hball hx
    have hxK : sInf K - ε / 2 ∈ K := le_of_lt h'
    have := csInf_le hbb hxK
    linarith
  · have hmem : sSup K ∈ K := hclosed.csSup_mem hne hba
    apply le_antisymm hmem
    by_contra hlt
    push Not at hlt
    obtain ⟨ε, hε, hball⟩ := Metric.isOpen_iff.mp hopen (sSup K) hlt
    have hx : sSup K + ε / 2 ∈ Metric.ball (sSup K) ε := by
      rw [Metric.mem_ball, Real.dist_eq, abs_of_pos (by linarith)]; linarith
    have h' : |∏ i, (sSup K + ε / 2 - r i)| < 1 := hball hx
    have hxK : sSup K + ε / 2 ∈ K := le_of_lt h'
    have := le_csSup hba hxK
    linarith

/-- The reduction of Lemma 6.3 in the case `M = -α` (the left end is the farther one). -/
theorem reduce_left {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤ volume (sublevel r)) {α β : ℝ}
    (hα : |∏ i, (α - r i)| = 1) (hβ : |∏ i, (β - r i)| ≤ 1)
    (hK : closedSublevel r ⊆ Set.Icc α β)
    (hM1 : √2 - 1 < -α - 1) (hM2 : -α - 1 ≤ 3 / 4) : False := by
  have hrK : ∀ i, r i ∈ closedSublevel r := by
    intro i
    show |∏ j, (r i - r j)| ≤ 1
    rw [Finset.prod_eq_zero (Finset.mem_univ i) (sub_self _), abs_zero]
    exact zero_le_one
  have hαr : ∀ i, α ≤ r i := fun i => (hK (hrK i)).1
  set q : Fin n → ℝ := fun j => r j - α with hq
  have hqI : ∀ j, q j ∈ Set.Icc (-α - 1) (-α - 1 + 2) := by
    intro j
    obtain ⟨a, b⟩ := hr j
    exact ⟨by simp only [hq]; linarith, by simp only [hq]; linarith⟩
  have h0 : ∏ j, q j = 1 := by
    rw [← hα, Finset.abs_prod]
    apply Finset.prod_congr rfl
    intro j _
    simp only [hq]
    rw [abs_of_nonpos (by linarith [hαr j])]
    ring
  have hy : |∏ j, ((β - α) - q j)| ≤ 1 := by
    have : ∏ j, ((β - α) - q j) = ∏ j, (β - r j) := by
      apply Finset.prod_congr rfl; intro j _; simp only [hq]; ring
    rw [this]; exact hβ
  have hset : Set.Icc 0 (β - α) ∩ {x | |∏ j, (x - q j)| ≤ 1} =
      (fun x => x + α) ⁻¹' closedSublevel r := by
    ext x
    simp only [Set.mem_inter_iff, Set.mem_Icc, Set.mem_ofPred_eq, Set.mem_preimage, closedSublevel]
    have e : ∏ j, (x - q j) = ∏ j, (x + α - r j) := by
      apply Finset.prod_congr rfl; intro j _; simp only [hq]; ring
    rw [e]
    constructor
    · rintro ⟨_, h⟩; exact h
    · intro h
      have := hK h
      exact ⟨⟨by linarith [this.1], by linarith [this.2]⟩, h⟩
  have hvol' : ENNReal.ofReal (2 * √2) ≤
      volume (Set.Icc 0 (β - α) ∩ {x | |∏ j, (x - q j)| ≤ 1}) := by
    rw [hset, measure_preimage_add_right]
    exact hvol.trans (measure_mono (sublevel_subset_closed r))
  exact two_atom_branch hn q (a := -α - 1) hM1 hM2 hqI h0 hy hvol'

theorem abs_prod_neg {n : ℕ} (r : Fin n → ℝ) (x : ℝ) :
    |∏ i, (-x - (fun i => -r i) i)| = |∏ i, (x - r i)| := by
  have : ∏ i, (-x - (fun i => -r i) i) = (-1) ^ n * ∏ i, (x - r i) := by
    rw [show ((-1 : ℝ) ^ n) = ∏ _i : Fin n, (-1 : ℝ) by simp, ← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl; intro i _; ring
  rw [this, abs_mul, abs_pow, abs_neg, abs_one, one_pow, one_mul]

/-- **Formal partial supremum (Lemmas 6.1, 6.3, 6.4)**: if `|S_f| ≥ 2√2`, the extreme points
`α = min K̄`, `β = max K̄` satisfy `M = max(-α, β) ∉ (√2, 7/4]`. -/
theorem sup_two_atom {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤ volume (sublevel r)) :
    ∃ α β : ℝ, |∏ i, (α - r i)| = 1 ∧ |∏ i, (β - r i)| = 1 ∧ closedSublevel r ⊆ Set.Icc α β ∧
      ¬ (√2 < max (-α) β ∧ max (-α) β ≤ 7 / 4) := by
  obtain ⟨α, β, hα, hβ, hK⟩ := extreme_points hn r hr
  refine ⟨α, β, hα, hβ, hK, ?_⟩
  rintro ⟨h1, h2⟩
  rcases le_total β (-α) with hle | hle
  · rw [max_eq_left hle] at h1 h2
    exact reduce_left hn r hr hvol hα hβ.le hK (by linarith) (by linarith)
  · rw [max_eq_right hle] at h1 h2
    -- reflect: r ↦ -r, α ↦ -β, β ↦ -α
    have hr' : ∀ i, (fun i => -r i) i ∈ Set.Icc (-1 : ℝ) 1 := fun i =>
      ⟨by linarith [(hr i).2], by linarith [(hr i).1]⟩
    have hvol' : ENNReal.ofReal (2 * √2) ≤ volume (sublevel (fun i => -r i)) := by
      rw [volume_sublevel_neg]; exact hvol
    have hα' : |∏ i, (-β - (fun i => -r i) i)| = 1 := by rw [abs_prod_neg]; exact hβ
    have hβ' : |∏ i, (-α - (fun i => -r i) i)| ≤ 1 := by rw [abs_prod_neg]; exact hα.le
    have hK' : closedSublevel (fun i => -r i) ⊆ Set.Icc (-β) (-α) := by
      intro x hx
      have hx' : -x ∈ closedSublevel r := by
        show |∏ i, (-x - r i)| ≤ 1
        have := abs_prod_neg r (-x)
        rw [neg_neg] at this
        rw [← this]; exact hx
      obtain ⟨h1, h2⟩ := hK hx'
      exact ⟨by linarith, by linarith⟩
    exact reduce_left hn _ hr' hvol' hα' hβ' hK' (by linarith) (by linarith)


/-- **Any counterexample to `sup ≤ 2√2` must reach beyond `7/4`**: if `|S_f| > 2√2`, then the
extreme points of `K̄` satisfy `max(-α, β) > 7/4`. (The range `M ∈ (7/4, 2]` is excluded in
`Supremum.lean` via proof.md Lemma 6.6′.) -/
theorem sup_counterexample_far {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (h : ENNReal.ofReal (2 * √2) < volume (sublevel r)) :
    ∃ α β : ℝ, |∏ i, (α - r i)| = 1 ∧ |∏ i, (β - r i)| = 1 ∧ closedSublevel r ⊆ Set.Icc α β ∧
      7 / 4 < max (-α) β := by
  obtain ⟨α, β, hα, hβ, hK, hnot⟩ := sup_two_atom hn r hr h.le
  refine ⟨α, β, hα, hβ, hK, ?_⟩
  have hlen : ENNReal.ofReal (2 * √2) < ENNReal.ofReal (β - α) := by
    calc ENNReal.ofReal (2 * √2) < volume (sublevel r) := h
      _ ≤ volume (closedSublevel r) := measure_mono (sublevel_subset_closed r)
      _ ≤ volume (Set.Icc α β) := measure_mono hK
      _ = ENNReal.ofReal (β - α) := Real.volume_Icc
  have hba : 2 * √2 < β - α := ((ENNReal.ofReal_lt_ofReal_iff').mp hlen).1
  have hM : √2 < max (-α) β := by
    rcases le_total β (-α) with hle | hle
    · rw [max_eq_left hle]; linarith
    · rw [max_eq_right hle]; linarith
  by_contra hc
  push Not at hc
  exact hnot ⟨hM, hc⟩


/-- **Positive form of the partial supremum** (Lean RED L-77): if `K̄ = {|f| ≤ 1}` lies in
`[-7/4, 7/4]`, then `|S_f| ≤ 2√2`. -/
theorem sup_le_of_near {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (hK : closedSublevel r ⊆ Set.Icc (-(7 / 4)) (7 / 4)) :
    volume (sublevel r) ≤ ENNReal.ofReal (2 * √2) := by
  by_contra hc
  push Not at hc
  obtain ⟨α, β, hα, hβ, _, hM⟩ := sup_counterexample_far hn r hr hc
  have hαK : α ∈ closedSublevel r := by
    change |∏ i, (α - r i)| ≤ 1; rw [hα]
  have hβK : β ∈ closedSublevel r := by
    change |∏ i, (β - r i)| ≤ 1; rw [hβ]
  have h1 := hK hαK
  have h2 := hK hβK
  rcases le_total β (-α) with hle | hle
  · rw [max_eq_left hle] at hM; linarith [h1.1]
  · rw [max_eq_right hle] at hM; linarith [h2.2]

end EP1038