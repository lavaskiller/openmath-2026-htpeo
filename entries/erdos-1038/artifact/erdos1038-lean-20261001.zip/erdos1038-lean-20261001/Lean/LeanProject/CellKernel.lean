import LeanProject.CircSym
import LeanProject.Riesz
import Mathlib.MeasureTheory.Function.Floor
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-!
# EP-1038, Stage 12b §2: cells, step functions and the cell kernel (Lemma 2.1)

* `win K r x = ∫_{-r}^{r} K(x - t) dt` (convolution with the arc `[-r, r]`); `win_symDec`:
  it is again symmetric decreasing (for `0 ≤ r ≤ π`), and `win_bdd`: bounded and measurable
  (measurability via the continuity of the primitive).
* `hs n = 2π/n`, `cidx n θ` (the cell `((j - ½)h, (j + ½)h]` has index `j mod n`), and the step
  function `st n a θ = a (cidx n θ)`.
* `int_st_mul`: `∫_𝕋 st(a) w = ∑ᵢ aᵢ ∫_{-h/2}^{h/2} w(i h + t) dt` for bounded periodic `w`.
-/

open Real MeasureTheory Set Interval

namespace EP1038.Circ

variable {K : ℝ → ℝ}

theorem Bdd.comp_add_right {F : ℝ → ℝ} (hF : Bdd F) (c : ℝ) : Bdd (fun u => F (u + c)) := by
  obtain ⟨M, hM⟩ := hF.bdd
  exact ⟨hF.meas.comp (measurable_id.add measurable_const), M, fun u => hM _⟩

/-- Convolution with the arc `[-r, r]`. -/
noncomputable def win (K : ℝ → ℝ) (r x : ℝ) : ℝ := ∫ t in (-r)..r, K (x - t)

theorem win_eq (r x : ℝ) : win K r x = ∫ s in (x - r)..(x + r), K s := by
  unfold win
  rw [intervalIntegral.integral_comp_sub_left K x, sub_neg_eq_add]

theorem win_bdd (hKb : Bdd K) (r : ℝ) : Bdd (win K r) := by
  obtain ⟨M, hM⟩ := hKb.bdd
  have hint := hKb.ii
  refine ⟨?_, M * |2 * r|, fun x => ?_⟩
  · have hP := intervalIntegral.continuous_primitive (μ := volume) hint 0
    have e : win K r = fun x => (∫ s in (0 : ℝ)..(x + r), K s) - ∫ s in (0 : ℝ)..(x - r), K s := by
      funext x
      rw [win_eq, intervalIntegral.integral_interval_sub_left (hint _ _) (hint _ _)]
    rw [e]
    exact ((hP.comp (continuous_id.add continuous_const)).sub
      (hP.comp (continuous_id.sub continuous_const))).measurable
  · unfold win
    have := intervalIntegral.norm_integral_le_of_norm_le_const (a := -r) (b := r) (C := M)
      (f := fun t => K (x - t)) (fun t _ => by rw [Real.norm_eq_abs]; exact hM _)
    rw [Real.norm_eq_abs, show r - -r = 2 * r by ring] at this
    exact this

/-- Convolution with a centred arc keeps a function symmetric decreasing. -/
theorem win_symDec (hK : SymDecC K) (hKb : Bdd K) {r : ℝ} (hr0 : 0 ≤ r) (hr : r ≤ π) :
    SymDecC (win K r) := by
  have hint := hKb.ii
  refine ⟨fun x => ?_, fun x => ?_, ?_⟩
  · unfold win
    refine intervalIntegral.integral_congr (fun t _ => ?_)
    show K (x + 2 * π - t) = K (x - t)
    rw [show x + 2 * π - t = (x - t) + 2 * π by ring, hK.per]
  · unfold win
    have h := intervalIntegral.integral_comp_neg (a := -r) (b := r) (fun t => K (-x - t))
    rw [neg_neg] at h
    rw [← h]
    refine intervalIntegral.integral_congr (fun t _ => ?_)
    show K (-x - -t) = K (x - t)
    rw [show -x - -t = -(x - t) by ring, hK.even]
  · intro x hx y hy hxy
    obtain ⟨hx0, hxπ⟩ := hx
    obtain ⟨hy0, hyπ⟩ := hy
    rw [win_eq, win_eq]
    have e1 : ∫ s in (x - r)..(x + r), K s =
        (∫ s in (x - r)..(y - r), K s) + ∫ s in (y - r)..(x + r), K s :=
      (intervalIntegral.integral_add_adjacent_intervals (hint _ _) (hint _ _)).symm
    have e2 : ∫ s in (y - r)..(y + r), K s =
        (∫ s in (y - r)..(x + r), K s) + ∫ s in (x + r)..(y + r), K s :=
      (intervalIntegral.integral_add_adjacent_intervals (hint _ _) (hint _ _)).symm
    have e3 : ∫ s in (x + r)..(y + r), K s = ∫ t in (x - r)..(y - r), K (t + 2 * r) := by
      rw [intervalIntegral.integral_comp_add_right K (2 * r)]
      congr 1 <;> ring
    have hmono : ∫ t in (x - r)..(y - r), K (t + 2 * r) ≤ ∫ t in (x - r)..(y - r), K t := by
      refine intervalIntegral.integral_mono_on (by linarith) ((hKb.comp_add_right _).ii _ _)
        (hint _ _) (fun t ht => ?_)
      obtain ⟨ht1, ht2⟩ := ht
      exact hK.le_of (abs_le.mpr ⟨by linarith, by linarith⟩) (by linarith) (by linarith)
        (abs_le.mpr ⟨by linarith, by linarith⟩) (abs_le.mpr ⟨by linarith, by linarith⟩)
    linarith

/-! ### Cells and step functions -/

variable {n : ℕ} [NeZero n]

/-- The mesh `h = 2π/n`. -/
noncomputable def hs (n : ℕ) : ℝ := 2 * π / n

theorem hs_pos : 0 < hs n := by
  unfold hs
  have : (0 : ℝ) < n := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne n)
  positivity

theorem n_mul_hs : (n : ℝ) * hs n = 2 * π := by
  unfold hs
  have : (n : ℝ) ≠ 0 := by exact_mod_cast NeZero.ne n
  field_simp

/-- The cell index: `θ ∈ ((j - ½)h, (j + ½)h]` has index `j mod n`. -/
noncomputable def cidx (n : ℕ) (θ : ℝ) : ZMod n := ((⌈θ / hs n - 1 / 2⌉ : ℤ) : ZMod n)

/-- The step function `st(a) = ∑ᵢ aᵢ 1_{Cᵢ}`. -/
noncomputable def st (n : ℕ) (a : ZMod n → ℝ) (θ : ℝ) : ℝ := a (cidx n θ)

theorem cidx_of_mem (j : ℤ) {θ : ℝ} (h1 : (j - 1 / 2) * hs n < θ) (h2 : θ ≤ (j + 1 / 2) * hs n) :
    cidx n θ = (j : ZMod n) := by
  have hp : 0 < hs n := hs_pos (n := n)
  unfold cidx
  congr 1
  rw [Int.ceil_eq_iff]
  constructor
  · have : (j : ℝ) - 1 / 2 < θ / hs n := by rw [lt_div_iff₀ hp]; exact h1
    linarith
  · have : θ / hs n ≤ (j : ℝ) + 1 / 2 := by rw [div_le_iff₀ hp]; exact h2
    linarith

theorem cidx_periodic (θ : ℝ) : cidx n (θ + 2 * π) = cidx n θ := by
  have hp : 0 < hs n := hs_pos (n := n)
  unfold cidx
  have e : (θ + 2 * π) / hs n - 1 / 2 = (θ / hs n - 1 / 2) + (n : ℤ) := by
    rw [← n_mul_hs (n := n), Int.cast_natCast]
    field_simp
    ring
  rw [e, Int.ceil_add_intCast, Int.cast_add, Int.cast_natCast, ZMod.natCast_self, add_zero]

theorem st_periodic (a : ZMod n → ℝ) : Function.Periodic (st n a) (2 * π) := fun θ => by
  unfold st; rw [cidx_periodic]

theorem st_bdd (a : ZMod n → ℝ) : Bdd (st n a) := by
  refine ⟨?_, ∑ i, |a i|, fun θ => ?_⟩
  · have hm : Measurable (fun θ : ℝ => ⌈θ / hs n - 1 / 2⌉) :=
      Int.measurable_ceil.comp ((measurable_id.div_const _).sub_const _)
    exact (measurable_of_countable (fun k : ℤ => a (k : ZMod n))).comp hm
  · exact Finset.single_le_sum (f := fun i => |a i|) (fun i _ => abs_nonneg _) (Finset.mem_univ _)

/-- **Integration against a step function**, cell by cell. -/
theorem int_st_mul (a : ZMod n → ℝ) {w : ℝ → ℝ} (hw : Function.Periodic w (2 * π))
    (hwb : Bdd w) :
    ∫ θ in (-π)..π, st n a θ * w θ =
      ∑ i : ZMod n, a i * ∫ t in (-(hs n / 2))..(hs n / 2), w (i.val * hs n + t) := by
  have hp : 0 < hs n := hs_pos (n := n)
  have hnh : (n : ℝ) * hs n = 2 * π := n_mul_hs (n := n)
  have hF : Bdd (fun θ => st n a θ * w θ) := (st_bdd a).mul hwb
  have hFper : Function.Periodic (fun θ => st n a θ * w θ) (2 * π) := fun θ => by
    show st n a (θ + 2 * π) * w (θ + 2 * π) = st n a θ * w θ
    rw [st_periodic a θ, hw θ]
  have e1 : ∫ θ in (-π)..π, st n a θ * w θ =
      ∫ θ in (-(hs n / 2))..(-(hs n / 2) + 2 * π), st n a θ * w θ := by
    have := hFper.intervalIntegral_add_eq (-π) (-(hs n / 2))
    rw [show -π + 2 * π = π by ring] at this
    exact this
  have e2 : ∫ θ in (-(hs n / 2))..(-(hs n / 2) + 2 * π), st n a θ * w θ =
      ∑ k ∈ Finset.range n, ∫ θ in ((k : ℝ) * hs n - hs n / 2)..(((k + 1 : ℕ) : ℝ) * hs n - hs n / 2),
        st n a θ * w θ := by
    rw [intervalIntegral.sum_integral_adjacent_intervals
      (a := fun k : ℕ => (k : ℝ) * hs n - hs n / 2) (fun k _ => hF.ii _ _)]
    congr 1
    · simp
    · rw [hnh]; ring
  have e3 : ∀ k : ℕ, ∫ θ in ((k : ℝ) * hs n - hs n / 2)..(((k + 1 : ℕ) : ℝ) * hs n - hs n / 2),
      st n a θ * w θ = a (k : ZMod n) * ∫ t in (-(hs n / 2))..(hs n / 2), w (k * hs n + t) := by
    intro k
    have hle : (k : ℝ) * hs n - hs n / 2 ≤ ((k + 1 : ℕ) : ℝ) * hs n - hs n / 2 := by
      push_cast; nlinarith
    have hcell : ∀ θ ∈ Ι ((k : ℝ) * hs n - hs n / 2) (((k + 1 : ℕ) : ℝ) * hs n - hs n / 2),
        st n a θ * w θ = a (k : ZMod n) * w θ := by
      intro θ hθ
      rw [uIoc_of_le hle] at hθ
      obtain ⟨h1, h2⟩ := hθ
      have hc := cidx_of_mem (n := n) (k : ℤ) (θ := θ) (by push_cast; linarith)
        (by push_cast at h2 ⊢; linarith)
      unfold st
      rw [hc, Int.cast_natCast]
    rw [intervalIntegral.integral_congr_ae (Filter.Eventually.of_forall hcell),
      intervalIntegral.integral_const_mul, intervalIntegral.integral_comp_add_left w]
    congr 2; push_cast; ring
  rw [e1, e2, Finset.sum_congr rfl (fun k _ => e3 k)]
  refine Finset.sum_nbij' (fun k => (k : ZMod n)) (fun i => i.val) ?_ ?_ ?_ ?_ ?_
  · intros; exact Finset.mem_univ _
  · intro i _; exact Finset.mem_range.mpr (ZMod.val_lt i)
  · intro k hk; exact ZMod.val_cast_of_lt (Finset.mem_range.mp hk)
  · intro i _; exact ZMod.natCast_zmod_val i
  · intro k hk; rw [ZMod.val_cast_of_lt (Finset.mem_range.mp hk)]

/-! ### The cell kernel (Lemma 2.1) -/

theorem hs_le : hs n ≤ 2 * π := by
  unfold hs
  have : (1 : ℝ) ≤ n := by exact_mod_cast Nat.one_le_iff_ne_zero.mpr (NeZero.ne n)
  exact div_le_self (by positivity) this

theorem Bdd.fsum {ι : Type*} [Fintype ι] {f : ι → ℝ → ℝ} (hf : ∀ i, Bdd (f i)) :
    Bdd (fun x => ∑ i, f i x) := by
  choose M hM using fun i => (hf i).bdd
  refine ⟨Finset.measurable_sum _ (fun i _ => (hf i).meas), ∑ i, M i, fun x => ?_⟩
  exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i _ => hM i x)

theorem Bdd.const_mul' {F : ℝ → ℝ} (hF : Bdd F) (c : ℝ) : Bdd (fun x => c * F x) := by
  obtain ⟨M, hM⟩ := hF.bdd
  refine ⟨hF.meas.const_mul c, |c| * M, fun x => ?_⟩
  rw [abs_mul]
  exact mul_le_mul_of_nonneg_left (hM x) (abs_nonneg c)

theorem Bdd.comp_sub_right {F : ℝ → ℝ} (hF : Bdd F) (c : ℝ) : Bdd (fun u => F (u - c)) := by
  obtain ⟨M, hM⟩ := hF.bdd
  exact ⟨hF.meas.comp (measurable_id.sub measurable_const), M, fun u => hM _⟩

theorem win_def (F : ℝ → ℝ) (r x : ℝ) : win F r x = ∫ t in (-r)..r, F (x - t) := rfl

/-- `I_K(u, v) = ∫_𝕋 u · (K * v)`. -/
noncomputable def IK (K u v : ℝ → ℝ) : ℝ := ∫ θ in (-π)..π, u θ * conv K v θ

/-- The cell kernel `c_d = Ψ₂(d h)`, with `Ψ₂ = (K * 1_{[-h/2,h/2]}) * 1_{[-h/2,h/2]}`. -/
noncomputable def ckern (K : ℝ → ℝ) (n : ℕ) (d : ZMod n) : ℝ :=
  win (win K (hs n / 2)) (hs n / 2) (d.val * hs n)

theorem conv_st (hK : SymDecC K) (hKb : Bdd K) (b : ZMod n → ℝ) (θ : ℝ) :
    conv K (st n b) θ = ∑ j : ZMod n, b j * win K (hs n / 2) (θ - j.val * hs n) := by
  unfold conv
  have hw : Function.Periodic (fun u => K (θ - u)) (2 * π) := fun u => by
    show K (θ - (u + 2 * π)) = K (θ - u)
    rw [show θ - (u + 2 * π) = (θ - u) - 2 * π by ring, hK.per.sub_eq]
  have e := int_st_mul b hw (hKb.comp_sub θ)
  have ec : ∫ u in (-π)..π, K (θ - u) * st n b u = ∫ u in (-π)..π, st n b u * K (θ - u) :=
    intervalIntegral.integral_congr (fun u _ => mul_comm _ _)
  rw [ec, e]
  refine Finset.sum_congr rfl (fun j _ => ?_)
  congr 1
  rw [win_def]
  refine intervalIntegral.integral_congr (fun t _ => ?_)
  show K (θ - (j.val * hs n + t)) = K (θ - j.val * hs n - t)
  rw [show θ - (j.val * hs n + t) = θ - j.val * hs n - t by ring]

theorem cell_int (hK : SymDecC K) (hKb : Bdd K) (i j : ZMod n) :
    ∫ t in (-(hs n / 2))..(hs n / 2), win K (hs n / 2) (i.val * hs n + t - j.val * hs n) =
      ckern K n (i - j) := by
  have hp : 0 < hs n := hs_pos (n := n)
  have hle : hs n ≤ 2 * π := hs_le (n := n)
  have hκ : SymDecC (win K (hs n / 2)) := win_symDec hK hKb (by positivity) (by linarith)
  have hκb : Bdd (win K (hs n / 2)) := win_bdd hKb _
  have hκ2 : SymDecC (win (win K (hs n / 2)) (hs n / 2)) :=
    win_symDec hκ hκb (by positivity) (by linarith)
  have e1 : ckern K n (i - j) =
      win (win K (hs n / 2)) (hs n / 2) ((i.val : ℝ) * hs n - j.val * hs n) := by
    unfold ckern
    rw [Riesz.vsub]
    split_ifs with hij
    · rw [Nat.cast_sub hij]; ring_nf
    · have hjn : j.val ≤ i.val + n := by have := ZMod.val_lt j; omega
      rw [show ((i.val + n - j.val : ℕ) : ℝ) * hs n = (i.val * hs n - j.val * hs n) + 2 * π by
        rw [Nat.cast_sub hjn, Nat.cast_add, ← n_mul_hs (n := n)]; ring, hκ2.per]
  rw [e1, win_def (win K (hs n / 2)) (hs n / 2)]
  have h := intervalIntegral.integral_comp_neg (a := -(hs n / 2)) (b := hs n / 2)
    (fun t => win K (hs n / 2) (i.val * hs n + t - j.val * hs n))
  rw [neg_neg] at h
  rw [← h]
  refine intervalIntegral.integral_congr (fun t _ => ?_)
  show win K (hs n / 2) (i.val * hs n + -t - j.val * hs n) =
    win K (hs n / 2) (i.val * hs n - j.val * hs n - t)
  congr 1; ring

/-- **Lemma 2.1, first part**: `I_K(st(a), st(b)) = S_c(a, b)` for the cell kernel `c`. -/
theorem IK_st (hK : SymDecC K) (hKb : Bdd K) (a b : ZMod n → ℝ) :
    IK K (st n a) (st n b) = Riesz.S (ckern K n) a b := by
  have hp : 0 < hs n := hs_pos (n := n)
  have hle : hs n ≤ 2 * π := hs_le (n := n)
  have hκ : SymDecC (win K (hs n / 2)) := win_symDec hK hKb (by positivity) (by linarith)
  have hκb : Bdd (win K (hs n / 2)) := win_bdd hKb _
  unfold IK
  simp_rw [conv_st hK hKb b]
  have hwper : Function.Periodic
      (fun θ => ∑ j : ZMod n, b j * win K (hs n / 2) (θ - j.val * hs n)) (2 * π) := by
    intro θ
    refine Finset.sum_congr rfl (fun j _ => ?_)
    rw [show θ + 2 * π - j.val * hs n = (θ - j.val * hs n) + 2 * π by ring, hκ.per]
  have hwb : Bdd (fun θ => ∑ j : ZMod n, b j * win K (hs n / 2) (θ - j.val * hs n)) :=
    Bdd.fsum (fun j => (hκb.comp_sub_right _).const_mul' (b j))
  rw [int_st_mul a hwper hwb]
  unfold Riesz.S
  refine Finset.sum_congr rfl (fun i _ => ?_)
  have hij : ∀ j : ZMod n, IntervalIntegrable
      (fun t => b j * win K (hs n / 2) (i.val * hs n + t - j.val * hs n)) volume
      (-(hs n / 2)) (hs n / 2) := by
    intro j
    refine Bdd.ii ⟨?_, ?_⟩ _ _
    · exact (hκb.meas.comp ((measurable_const.add measurable_id).sub measurable_const)).const_mul _
    · obtain ⟨M, hM⟩ := hκb.bdd
      exact ⟨|b j| * M, fun t => by
        rw [abs_mul]; exact mul_le_mul_of_nonneg_left (hM _) (abs_nonneg _)⟩
  rw [intervalIntegral.integral_finsetSum (fun j _ => hij j), Finset.mul_sum]
  refine Finset.sum_congr rfl (fun j _ => ?_)
  rw [intervalIntegral.integral_const_mul, cell_int hK hKb i j]
  ring

/-- **Lemma 2.1, second part**: the cell kernel is symmetric decreasing on `ℤ_n`. -/
theorem ckern_symDec (hK : SymDecC K) (hKb : Bdd K) : Riesz.SymDec (ckern K n) := by
  have hp : 0 < hs n := hs_pos (n := n)
  have hle : hs n ≤ 2 * π := hs_le (n := n)
  have hnh : (n : ℝ) * hs n = 2 * π := n_mul_hs (n := n)
  have hκ : SymDecC (win K (hs n / 2)) := win_symDec hK hKb (by positivity) (by linarith)
  have hκb : Bdd (win K (hs n / 2)) := win_bdd hKb _
  have hκ2 : SymDecC (win (win K (hs n / 2)) (hs n / 2)) :=
    win_symDec hκ hκb (by positivity) (by linarith)
  have key : ∀ x : ZMod n,
      ckern K n x = win (win K (hs n / 2)) (hs n / 2) ((Riesz.nrm x : ℝ) * hs n) := by
    intro x
    unfold ckern
    rw [Riesz.nrm_eq]
    rcases le_total x.val (n - x.val) with h | h
    · rw [min_eq_left h]
    · rw [min_eq_right h, hκ2.eq_sub (x.val * hs n)]
      congr 1
      rw [Nat.cast_sub (le_of_lt (ZMod.val_lt x)), ← hnh]; ring
  have hhalf : ∀ x : ZMod n, (Riesz.nrm x : ℝ) * hs n ≤ π := by
    intro x
    have h1 : 2 * Riesz.nrm x ≤ n := by
      rw [Riesz.nrm_eq]; have := ZMod.val_lt x; omega
    have h2 : (2 * Riesz.nrm x : ℝ) ≤ n := by exact_mod_cast h1
    nlinarith
  intro x y hxy
  rw [key x, key y]
  exact hκ2.anti ⟨by positivity, hhalf x⟩ ⟨by positivity, hhalf y⟩
    (mul_le_mul_of_nonneg_right (by exact_mod_cast hxy) hp.le)

end EP1038.Circ
