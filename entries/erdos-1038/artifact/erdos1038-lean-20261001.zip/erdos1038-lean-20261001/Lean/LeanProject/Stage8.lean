import LeanProject.N3Main

/-!
# EP-1038: building blocks of Proposition 8.1 (small mass ratio)

* `tlog_le` — `t log(a/t) ≤ a/e` for `t, a > 0` (used for the pair term).
* `amgm_eps` — `(K+1) K^(-K/(K+1)) ≤ b + b^(-K)` for `b, K > 0`, the source of the constant
  `ε_K = 2 - (K+1) K^(-K/(K+1))` in proof.md Proposition 8.1: `2 - b - b^(-K) ≤ ε_K`.
-/

open Real

namespace EP1038

theorem log_le_div_exp {y : ℝ} (hy : 0 < y) : Real.log y ≤ y / Real.exp 1 := by
  have he : 0 < Real.exp 1 := Real.exp_pos 1
  have h := Real.log_le_sub_one_of_pos (div_pos hy he)
  rw [Real.log_div hy.ne' he.ne', Real.log_exp] at h
  linarith

theorem tlog_le {t a : ℝ} (ht : 0 < t) (ha : 0 < a) : t * Real.log (a / t) ≤ a / Real.exp 1 := by
  have h := log_le_div_exp (div_pos ha ht)
  have he : 0 < Real.exp 1 := Real.exp_pos 1
  calc t * Real.log (a / t) ≤ t * ((a / t) / Real.exp 1) := mul_le_mul_of_nonneg_left h ht.le
    _ = a / Real.exp 1 := by field_simp

theorem amgm_eps {b K : ℝ} (hb : 0 < b) (hK : 0 < K) :
    (K + 1) * K ^ (-K / (K + 1)) ≤ b + b ^ (-K) := by
  have hK1 : 0 < K + 1 := by linarith
  set w₁ := K / (K + 1) with hw₁
  set w₂ := 1 / (K + 1) with hw₂
  have hw : w₁ + w₂ = 1 := by rw [hw₁, hw₂]; field_simp
  have hp₁ : 0 ≤ b * (K + 1) / K := by positivity
  have hp₂ : 0 ≤ (K + 1) * b ^ (-K) := by positivity
  have key := Real.geom_mean_le_arith_mean2_weighted (by positivity : 0 ≤ w₁)
    (by positivity : 0 ≤ w₂) hp₁ hp₂ hw
  have hrhs : w₁ * (b * (K + 1) / K) + w₂ * ((K + 1) * b ^ (-K)) = b + b ^ (-K) := by
    rw [hw₁, hw₂]; field_simp
  have hlhs : (b * (K + 1) / K) ^ w₁ * ((K + 1) * b ^ (-K)) ^ w₂ = (K + 1) * K ^ (-K / (K + 1)) := by
    rw [Real.div_rpow (by positivity) hK.le, Real.mul_rpow hb.le hK1.le,
      Real.mul_rpow hK1.le (by positivity), ← Real.rpow_mul hb.le]
    have e1 : (K + 1) ^ w₁ * (K + 1) ^ w₂ = K + 1 := by
      rw [← Real.rpow_add hK1, hw, Real.rpow_one]
    have e2 : b ^ w₁ * b ^ (-K * w₂) = 1 := by
      rw [← Real.rpow_add hb, hw₁, hw₂]
      have : K / (K + 1) + -K * (1 / (K + 1)) = 0 := by field_simp; ring
      rw [this, Real.rpow_zero]
    have e3 : (K ^ w₁)⁻¹ = K ^ (-K / (K + 1)) := by
      rw [hw₁, ← Real.rpow_neg hK.le, neg_div]
    calc b ^ w₁ * (K + 1) ^ w₁ / K ^ w₁ * ((K + 1) ^ w₂ * b ^ (-K * w₂))
        = ((K + 1) ^ w₁ * (K + 1) ^ w₂) * (b ^ w₁ * b ^ (-K * w₂)) * (K ^ w₁)⁻¹ := by ring
      _ = (K + 1) * K ^ (-K / (K + 1)) := by rw [e1, e2, e3, mul_one]
  rw [hlhs, hrhs] at key
  exact key

end EP1038
