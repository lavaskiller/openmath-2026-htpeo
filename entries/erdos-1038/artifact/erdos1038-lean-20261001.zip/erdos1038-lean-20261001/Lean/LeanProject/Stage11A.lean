import LeanProject.Stage10C13

/-!
# EP-1038, Stage 11, §11.1 and Lemma 11.6: the transform of `cos nφ` and the functional `𝓛`

* `HT f θ = (1/π) ∫_0^π (f φ - f θ)/(cos θ - cos φ) dφ` (the difference-quotient form of the finite
  Hilbert transform; Lean route R1).
* `HT_cos`: `HT (cos n·) θ = -V_n(θ)` with `V_n = U_{n-1}(cos θ)` given by `V₀ = 0`, `V₁ = 1`,
  `V_{n+2} = V_n + 2 cos((n+1)θ)` (Lemma 11.2(iii)); proved by the Chebyshev recurrence, with the
  integrand identity `cos nφ - cos nθ = r_n(φ)(cos θ - cos φ)` (no principal value).
* `int_Pq_cos`: `(1/π) ∫_0^π P_ρ cos kθ = ρᵏ` (Lemma 11.2(i)); `int_V`, `int_PV`: the Chebyshev
  integrals `ε_n`, `S_n(ρ)` (Lemma 11.2(vi)) and the closed form `S_closed`.
* `L_cos` (**Lemma 11.6**): `𝓛(cos n·) = 0` for all `n`, for arbitrary `ρ± ∈ (0,1)`, real `σ±`, `r > 0`.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage11

open EP1038.Arc EP1038.Stage9

/-- The difference-quotient transform. -/
noncomputable def HT (f : ℝ → ℝ) (θ : ℝ) : ℝ :=
  1 / π * ∫ φ in (0 : ℝ)..π, (f φ - f θ) / (Real.cos θ - Real.cos φ)

/-- `V_n(θ) = U_{n-1}(cos θ)`. -/
noncomputable def Vn (θ : ℝ) : ℕ → ℝ
  | 0 => 0
  | 1 => 1
  | n + 2 => Vn θ n + 2 * Real.cos ((n + 1) * θ)

/-- The integrand recurrence `r_n(φ)` (for fixed `θ`). -/
noncomputable def rr (θ : ℝ) : ℕ → ℝ → ℝ
  | 0 => fun _ => 0
  | 1 => fun _ => -1
  | n + 2 => fun φ => 2 * Real.cos θ * rr θ (n + 1) φ - rr θ n φ - 2 * Real.cos ((n + 1) * φ)

theorem cos_rec (n : ℕ) (x : ℝ) :
    Real.cos (((n + 2 : ℕ) : ℝ) * x) =
      2 * Real.cos x * Real.cos (((n + 1 : ℕ) : ℝ) * x) - Real.cos ((n : ℝ) * x) := by
  have h1 : ((n + 2 : ℕ) : ℝ) * x = ((n + 1 : ℕ) : ℝ) * x + x := by push_cast; ring
  have h2 : (n : ℝ) * x = ((n + 1 : ℕ) : ℝ) * x - x := by push_cast; ring
  rw [h1, h2, Real.cos_add, Real.cos_sub]
  ring

/-- `cos nφ - cos nθ = r_n(φ) (cos θ - cos φ)` for all `φ`. -/
theorem cos_diff_eq (θ : ℝ) : ∀ (n : ℕ) (φ : ℝ), Real.cos ((n : ℝ) * φ) - Real.cos ((n : ℝ) * θ) =
    rr θ n φ * (Real.cos θ - Real.cos φ)
  | 0, φ => by simp [rr]
  | 1, φ => by simp [rr]
  | n + 2, φ => by
    have h1 := cos_diff_eq θ n φ
    have h2 := cos_diff_eq θ (n + 1) φ
    rw [cos_rec n φ, cos_rec n θ]
    simp only [rr]
    push_cast at h2 ⊢
    linear_combination (-1 : ℝ) * h1 + 2 * Real.cos θ * h2

theorem Vn_C (θ : ℝ) : ∀ n : ℕ, Real.cos θ * Vn θ (n + 1) = Vn θ n + Real.cos ((n + 1) * θ)
  | 0 => by simp [Vn]
  | 1 => by
    simp only [Vn]
    have := Real.cos_two_mul θ
    push_cast
    rw [show ((1 : ℝ) + 1) * θ = 2 * θ by ring, this]
    ring
  | n + 2 => by
    have ih := Vn_C θ n
    have hr := cos_rec (n + 1) θ
    simp only [Vn] at ih ⊢
    push_cast at hr ih ⊢
    ring_nf at hr ih ⊢
    linear_combination ih - hr

theorem Vn_step (θ : ℝ) (n : ℕ) : Vn θ (n + 2) = 2 * Real.cos θ * Vn θ (n + 1) - Vn θ n := by
  have h := Vn_C θ n
  show Vn θ n + 2 * Real.cos ((n + 1) * θ) = _
  linear_combination -2 * h

theorem rr_cont (θ : ℝ) : ∀ n, Continuous (rr θ n)
  | 0 => continuous_const
  | 1 => continuous_const
  | n + 2 => by
    simp only [rr]
    exact ((continuous_const.mul (rr_cont θ (n + 1))).sub (rr_cont θ n)).sub
      (continuous_const.mul (Real.continuous_cos.comp (continuous_const.mul continuous_id)))

theorem int_cos_succ (n : ℕ) : ∫ φ in (0 : ℝ)..π, Real.cos ((n + 1) * φ) = 0 := by
  have hk : ((n : ℝ) + 1) ≠ 0 := by positivity
  rw [intervalIntegral.integral_comp_mul_left (fun x => Real.cos x) hk, integral_cos]
  have : Real.sin (((n : ℝ) + 1) * π) = 0 := by
    rw [show ((n : ℝ) + 1) = ((n + 1 : ℕ) : ℝ) by push_cast; ring]
    exact Real.sin_nat_mul_pi _
  simp [this]

/-- `HT (cos n·) θ = (1/π) ∫ r_n`. -/
theorem HT_cos_rr {θ : ℝ} (hθ : θ ∈ Icc 0 π) (n : ℕ) :
    HT (fun φ => Real.cos ((n : ℝ) * φ)) θ = 1 / π * ∫ φ in (0 : ℝ)..π, rr θ n φ := by
  unfold HT
  congr 1
  refine intervalIntegral.integral_congr_ae ?_
  filter_upwards [EP1038.Stage9.ae_ne_real θ] with φ hφ hmem
  rw [uIoc_of_le Real.pi_pos.le] at hmem
  have hne : Real.cos θ - Real.cos φ ≠ 0 := by
    intro h
    exact hφ (Real.injOn_cos ⟨hmem.1.le, hmem.2⟩ hθ (by linarith)).symm.symm
  rw [div_eq_iff hne]
  exact cos_diff_eq θ n φ

/-- Recurrence for `J_n = ∫_0^π r_n`. -/
theorem int_rr (θ : ℝ) : ∀ n, ∫ φ in (0 : ℝ)..π, rr θ n φ = -(π * Vn θ n)
  | 0 => by simp [rr, Vn]
  | 1 => by simp [rr, Vn]
  | n + 2 => by
    have h1 := int_rr θ n
    have h2 := int_rr θ (n + 1)
    have hi : ∀ m, IntervalIntegrable (rr θ m) volume 0 π := fun m => (rr_cont θ m).intervalIntegrable _ _
    have hc : IntervalIntegrable (fun φ => 2 * Real.cos ((n + 1) * φ)) volume 0 π :=
      (continuous_const.mul (Real.continuous_cos.comp (continuous_const.mul continuous_id))).intervalIntegrable _ _
    simp only [rr]
    rw [intervalIntegral.integral_sub (((hi (n + 1)).const_mul _).sub (hi n)) hc,
      intervalIntegral.integral_sub ((hi (n + 1)).const_mul _) (hi n),
      intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul, int_cos_succ, h1, h2]
    -- `V_{n+2} = 2 cos θ V_{n+1} - V_n`
    have hC := Vn_step θ n
    linear_combination π * hC

/-- **Lemma 11.2(iii)**: `HT (cos n·) θ = -U_{n-1}(cos θ)` for `θ ∈ [0, π]`. -/
theorem HT_cos {θ : ℝ} (hθ : θ ∈ Icc 0 π) (n : ℕ) :
    HT (fun φ => Real.cos ((n : ℝ) * φ)) θ = -Vn θ n := by
  rw [HT_cos_rr hθ, int_rr]
  field_simp

theorem Vn_cont : ∀ n, Continuous fun θ => Vn θ n
  | 0 => continuous_const
  | 1 => continuous_const
  | n + 2 => by
    simp only [Vn]
    exact (Vn_cont n).add (continuous_const.mul
      (Real.continuous_cos.comp (continuous_const.mul continuous_id)))

/-- `∫_{-π}^{π} P_q cos kθ = 2π qᵏ`. -/
theorem int_Pq_cos {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (k : ℕ) :
    ∫ θ in (-π)..π, Pq q θ * Real.cos ((k : ℝ) * θ) = 2 * π * q ^ k := by
  rcases Nat.eq_zero_or_pos k with hk | hk
  · subst hk; simpa using int_Pq hq0 hq1
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence (μ := volume)
    (a := -π) (b := π)
    (F := fun (m : ℕ) (θ : ℝ) => Real.cos (((j + 1 : ℕ) : ℝ) * θ) *
      (2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ))))
    (f := fun θ => Real.cos (((j + 1 : ℕ) : ℝ) * θ) * (Pq q θ - 1)) (fun m _ => 2 * q ^ (m + 1))
    (fun m => (by fun_prop : Continuous _).aestronglyMeasurable)
    (fun m => by
      refine Filter.Eventually.of_forall fun θ _ => ?_
      rw [norm_mul, Real.norm_eq_abs, Real.norm_eq_abs, abs_mul, abs_of_pos (by norm_num : (0:ℝ) < 2),
        abs_mul, abs_of_nonneg (pow_nonneg hq0 _)]
      have h1 := Real.abs_cos_le_one (((j + 1 : ℕ) : ℝ) * θ)
      have h2 := Real.abs_cos_le_one ((m + 1) * θ)
      have h3 := pow_nonneg hq0 (m + 1)
      calc |Real.cos (((j + 1 : ℕ) : ℝ) * θ)| * (2 * (q ^ (m + 1) * |Real.cos ((m + 1) * θ)|))
          ≤ 1 * (2 * (q ^ (m + 1) * 1)) := by gcongr
        _ = 2 * q ^ (m + 1) := by ring)
    (Filter.Eventually.of_forall fun θ _ => (summable_pow_succ hq0 hq1).mul_left 2)
    intervalIntegrable_const
    (Filter.Eventually.of_forall fun θ _ => (Pq_hasSum hq0 hq1 θ).mul_left _)
  have hterm : ∀ m : ℕ, (∫ θ in (-π)..π, Real.cos (((j + 1 : ℕ) : ℝ) * θ) *
      (2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ)))) = if m = j then 2 * π * q ^ (j + 1) else 0 := by
    intro m
    have e : (fun θ : ℝ => Real.cos (((j + 1 : ℕ) : ℝ) * θ) *
        (2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ)))) =
        fun θ => (2 * q ^ (m + 1)) * (Real.cos ((m + 1) * (θ + 0)) * Real.cos ((j + 1) * θ)) := by
      funext θ; push_cast; ring_nf
    rw [e, intervalIntegral.integral_const_mul, orth m j 0]
    split_ifs with h
    · subst h; simp; ring
    · simp
  simp_rw [hterm] at h
  have hs : HasSum (fun m : ℕ => if m = j then 2 * π * q ^ (j + 1) else 0) (2 * π * q ^ (j + 1)) :=
    hasSum_ite_eq j _
  have hval := h.unique hs
  have hci : IntervalIntegrable (fun θ => Real.cos (((j + 1 : ℕ) : ℝ) * θ)) volume (-π) π :=
    (by fun_prop : Continuous _).intervalIntegrable _ _
  have e2 : ∫ θ in (-π)..π, Pq q θ * Real.cos (((j + 1 : ℕ) : ℝ) * θ) =
      (∫ θ in (-π)..π, Real.cos (((j + 1 : ℕ) : ℝ) * θ) * (Pq q θ - 1)) +
        ∫ θ in (-π)..π, Real.cos (((j + 1 : ℕ) : ℝ) * θ) := by
    have h1 : IntervalIntegrable (fun θ => Real.cos (((j + 1 : ℕ) : ℝ) * θ) * (Pq q θ - 1))
        volume (-π) π :=
      (((by fun_prop : Continuous fun θ => Real.cos (((j + 1 : ℕ) : ℝ) * θ)).mul
        ((Pq_cont hq0 hq1).sub continuous_const))).intervalIntegrable _ _
    rw [← intervalIntegral.integral_add (f := fun θ => Real.cos (((j + 1 : ℕ) : ℝ) * θ) *
      (Pq q θ - 1)) (g := fun θ => Real.cos (((j + 1 : ℕ) : ℝ) * θ)) h1 hci]
    refine intervalIntegral.integral_congr fun θ _ => ?_
    ring
  have hcos0 : ∫ θ in (-π)..π, Real.cos (((j + 1 : ℕ) : ℝ) * θ) = 0 := by
    have := orth0 j 0
    simpa using this
  rw [e2, hval, hcos0, add_zero]

theorem Pq_even {q : ℝ} (θ : ℝ) : Pq q (-θ) = Pq q θ := by simp [Pq, Real.cos_neg]

/-- **Lemma 11.2(i)**: `∫_0^π P_q cos kθ = π qᵏ`. -/
theorem int_Pq_cos_half {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (k : ℕ) :
    ∫ θ in (0 : ℝ)..π, Pq q θ * Real.cos ((k : ℝ) * θ) = π * q ^ k := by
  have hi : IntervalIntegrable (fun θ => Pq q θ * Real.cos ((k : ℝ) * θ)) volume (-π) π :=
    ((Pq_cont hq0 hq1).mul (by fun_prop)).intervalIntegrable _ _
  have h := int_split hi
  simp only [Pq_even, mul_neg, Real.cos_neg] at h
  rw [int_Pq_cos hq0 hq1] at h
  linarith

/-- `ε_n`. -/
def epsn : ℕ → ℝ
  | 0 => 0
  | 1 => 1
  | n + 2 => epsn n

/-- `S_n(ρ)`. -/
def Sn (ρ : ℝ) : ℕ → ℝ
  | 0 => 0
  | 1 => 1
  | n + 2 => Sn ρ n + 2 * ρ ^ (n + 1)

theorem int_V : ∀ n, ∫ θ in (0 : ℝ)..π, Vn θ n = π * epsn n
  | 0 => by simp [Vn, epsn]
  | 1 => by simp [Vn, epsn]
  | n + 2 => by
    simp only [Vn, epsn]
    have hc : IntervalIntegrable (fun θ => 2 * Real.cos (((n : ℝ) + 1) * θ)) volume 0 π :=
      (continuous_const.mul (Real.continuous_cos.comp (continuous_const.mul continuous_id))).intervalIntegrable _ _
    rw [intervalIntegral.integral_add (f := fun θ => Vn θ n)
      (g := fun θ => 2 * Real.cos (((n : ℝ) + 1) * θ)) ((Vn_cont n).intervalIntegrable _ _) hc,
      intervalIntegral.integral_const_mul, int_cos_succ, int_V n]
    ring

theorem int_PV {ρ : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ < 1) :
    ∀ n, ∫ θ in (0 : ℝ)..π, Pq ρ θ * Vn θ n = π * Sn ρ n
  | 0 => by simp [Vn, Sn]
  | 1 => by
    simp only [Vn, Sn, mul_one]
    have := int_Pq_cos_half h0 h1 0
    simpa using this
  | n + 2 => by
    simp only [Vn, Sn]
    have hP := Pq_cont h0 h1
    have e : (fun θ => Pq ρ θ * (Vn θ n + 2 * Real.cos ((n + 1) * θ))) =
        fun θ => Pq ρ θ * Vn θ n + 2 * (Pq ρ θ * Real.cos (((n + 1 : ℕ) : ℝ) * θ)) := by
      funext θ; push_cast; ring
    have hA : IntervalIntegrable (fun θ => Pq ρ θ * Vn θ n) volume 0 π :=
      (hP.mul (Vn_cont n)).intervalIntegrable _ _
    have hB : IntervalIntegrable (fun θ => 2 * (Pq ρ θ * Real.cos (((n + 1 : ℕ) : ℝ) * θ)))
        volume 0 π :=
      ((hP.mul (by fun_prop : Continuous fun θ => Real.cos (((n + 1 : ℕ) : ℝ) * θ))).intervalIntegrable
        _ _).const_mul _
    rw [e, intervalIntegral.integral_add hA hB, intervalIntegral.integral_const_mul,
      int_PV h0 h1 n, int_Pq_cos_half h0 h1]
    ring

/-- **Lemma 11.2(vi)**, closed form: `(1-ρ²) S_n = (1+ρ)² ε_n - 2ρ^{n+1} + 2ρ(-1)ⁿ`. -/
theorem S_closed (ρ : ℝ) : ∀ n, (1 - ρ ^ 2) * Sn ρ n = (1 + ρ) ^ 2 * epsn n - 2 * ρ ^ (n + 1) +
    2 * ρ * (-1) ^ n
  | 0 => by simp [Sn, epsn]
  | 1 => by simp [Sn, epsn]; ring
  | n + 2 => by
    have ih := S_closed ρ n
    simp only [Sn, epsn]
    rw [pow_succ (-1 : ℝ) (n + 1), pow_succ (-1 : ℝ) n]
    linear_combination ih

/-- `K = r(1-ρ²)/(2ρ)`. -/
noncomputable def Kr (r ρ : ℝ) : ℝ := r * (1 - ρ ^ 2) / (2 * ρ)

/-- `B(θ) = D - σ₁ P_{ρ₁} - σ₂ P_{ρ₂}`, `D = σ₁ P_{ρ₁}(0) + σ₂ P_{ρ₂}(0)`. -/
noncomputable def Bxi (ρ1 ρ2 σ1 σ2 θ : ℝ) : ℝ :=
  σ1 * Pq ρ1 0 + σ2 * Pq ρ2 0 - σ1 * Pq ρ1 θ - σ2 * Pq ρ2 θ

/-- `Γ = σ₁/K₁ + σ₂/K₂`. -/
noncomputable def Gam (r ρ1 ρ2 σ1 σ2 : ℝ) : ℝ := σ1 / Kr r ρ1 + σ2 / Kr r ρ2

/-- The functional `𝓛` of §11.4. -/
noncomputable def Lfun (r ρ1 ρ2 σ1 σ2 : ℝ) (f : ℝ → ℝ) : ℝ :=
  -(σ1 / Kr r ρ1 * (1 / π * ∫ θ in (0 : ℝ)..π, f θ * Pq ρ1 θ) +
      σ2 / Kr r ρ2 * (1 / π * ∫ θ in (0 : ℝ)..π, f θ * Pq ρ2 θ)) -
    1 / (π * r) * (∫ θ in (0 : ℝ)..π, HT f θ * Bxi ρ1 ρ2 σ1 σ2 θ) + Gam r ρ1 ρ2 σ1 σ2 * f π

theorem Pq_zero_val {ρ : ℝ} (h1 : ρ < 1) : Pq ρ 0 = (1 + ρ) / (1 - ρ) := by
  unfold Pq
  rw [Real.cos_zero, show 1 - 2 * ρ * 1 + ρ ^ 2 = (1 - ρ) ^ 2 by ring,
    show (1 : ℝ) - ρ ^ 2 = (1 - ρ) * (1 + ρ) by ring]
  have : (1 - ρ) ≠ 0 := by linarith
  field_simp

/-- The per-`ρ` coefficient identity behind Lemma 11.6. -/
theorem coef_zero {r ρ : ℝ} (hr : 0 < r) (h0 : 0 < ρ) (h1 : ρ < 1) (n : ℕ) :
    -(1 / Kr r ρ * ρ ^ n) + 1 / r * ((1 + ρ) / (1 - ρ) * epsn n - Sn ρ n) +
      1 / Kr r ρ * (-1) ^ n = 0 := by
  have hq : (1 - ρ ^ 2) ≠ 0 := by nlinarith
  have hS : Sn ρ n = ((1 + ρ) ^ 2 * epsn n - 2 * ρ ^ (n + 1) + 2 * ρ * (-1) ^ n) / (1 - ρ ^ 2) := by
    rw [eq_div_iff hq]; linarith [S_closed ρ n]
  have h1' : (1 - ρ) ≠ 0 := by linarith
  have h2' : (1 + ρ) ≠ 0 := by linarith
  rw [hS]
  unfold Kr
  rw [show (1 : ℝ) - ρ ^ 2 = (1 - ρ) * (1 + ρ) by ring]
  field_simp
  ring

/-- **Lemma 11.6**: `𝓛(cos n·) = 0`. -/
theorem L_cos {r ρ1 ρ2 σ1 σ2 : ℝ} (hr : 0 < r) (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2)
    (h21 : ρ2 < 1) (n : ℕ) : Lfun r ρ1 ρ2 σ1 σ2 (fun θ => Real.cos ((n : ℝ) * θ)) = 0 := by
  have hπ := Real.pi_pos
  unfold Lfun
  -- the Poisson terms
  have e1 : ∫ θ in (0 : ℝ)..π, Real.cos ((n : ℝ) * θ) * Pq ρ1 θ = π * ρ1 ^ n := by
    rw [← int_Pq_cos_half h10.le h11 n]; congr 1; funext θ; ring
  have e2 : ∫ θ in (0 : ℝ)..π, Real.cos ((n : ℝ) * θ) * Pq ρ2 θ = π * ρ2 ^ n := by
    rw [← int_Pq_cos_half h20.le h21 n]; congr 1; funext θ; ring
  -- the transform term
  have hB : ∫ θ in (0 : ℝ)..π, HT (fun φ => Real.cos ((n : ℝ) * φ)) θ * Bxi ρ1 ρ2 σ1 σ2 θ =
      -(Pq ρ1 0 * σ1 + Pq ρ2 0 * σ2) * (π * epsn n) + σ1 * (π * Sn ρ1 n) + σ2 * (π * Sn ρ2 n) := by
    have hP1 := Pq_cont h10.le h11
    have hP2 := Pq_cont h20.le h21
    have hVc := Vn_cont n
    rw [intervalIntegral.integral_congr (g := fun θ => -(Pq ρ1 0 * σ1 + Pq ρ2 0 * σ2) * Vn θ n +
      σ1 * (Pq ρ1 θ * Vn θ n) + σ2 * (Pq ρ2 θ * Vn θ n)) (fun θ hθ => by
        rw [uIcc_of_le hπ.le] at hθ
        simp only
        rw [HT_cos hθ, Bxi]; ring)]
    have i1 : IntervalIntegrable (fun θ => -(Pq ρ1 0 * σ1 + Pq ρ2 0 * σ2) * Vn θ n) volume 0 π :=
      (hVc.intervalIntegrable _ _).const_mul _
    have i2 : IntervalIntegrable (fun θ => σ1 * (Pq ρ1 θ * Vn θ n)) volume 0 π :=
      ((hP1.mul hVc).intervalIntegrable _ _).const_mul _
    have i3 : IntervalIntegrable (fun θ => σ2 * (Pq ρ2 θ * Vn θ n)) volume 0 π :=
      ((hP2.mul hVc).intervalIntegrable _ _).const_mul _
    rw [intervalIntegral.integral_add (i1.add i2) i3, intervalIntegral.integral_add i1 i2,
      intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
      intervalIntegral.integral_const_mul, int_V, int_PV h10.le h11, int_PV h20.le h21]
  rw [e1, e2, hB]
  simp only []
  rw [Real.cos_nat_mul_pi, Gam, Pq_zero_val h11, Pq_zero_val h21]
  have hr' : r ≠ 0 := hr.ne'
  have hπ' : π ≠ 0 := hπ.ne'
  have c1 := coef_zero hr h10 h11 n (r := r)
  have c2 := coef_zero hr h20 h21 n (r := r)
  calc -(σ1 / Kr r ρ1 * (1 / π * (π * ρ1 ^ n)) + σ2 / Kr r ρ2 * (1 / π * (π * ρ2 ^ n))) -
        1 / (π * r) * (-((1 + ρ1) / (1 - ρ1) * σ1 + (1 + ρ2) / (1 - ρ2) * σ2) * (π * epsn n) +
          σ1 * (π * Sn ρ1 n) + σ2 * (π * Sn ρ2 n)) + (σ1 / Kr r ρ1 + σ2 / Kr r ρ2) * (-1) ^ n
      = σ1 * (-(1 / Kr r ρ1 * ρ1 ^ n) + 1 / r * ((1 + ρ1) / (1 - ρ1) * epsn n - Sn ρ1 n) +
          1 / Kr r ρ1 * (-1) ^ n) +
        σ2 * (-(1 / Kr r ρ2 * ρ2 ^ n) + 1 / r * ((1 + ρ2) / (1 - ρ2) * epsn n - Sn ρ2 n) +
          1 / Kr r ρ2 * (-1) ^ n) := by
        field_simp
        ring
    _ = 0 := by rw [c1, c2]; ring

end EP1038.Stage11
