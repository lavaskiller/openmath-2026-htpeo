import LeanProject.Orientation

/-!
# EP-1038: the equality case of the supremum, algebraic part (Stage 15, third batch)

proof.md Theorem 6.7 shows that `|S_f| = 2√2` forces `α = -√2`, `β = √2`, hence `|f(±√2)| = 1`.
This file formalises the remaining algebra: a monic polynomial with all roots in `[-1,1]` and
`|f(√2)| = |f(-√2)| = 1` is `(X^2 - 1)^m`.
-/

open Real Polynomial

namespace EP1038

/-- The monic polynomial with root multiset `s`. -/
noncomputable def polyOf (s : Multiset ℝ) : ℝ[X] := (s.map fun r => X - C r).prod

theorem two_sub_sq_prod_eq_one (s : Multiset ℝ) (hs : ∀ r ∈ s, r ∈ Set.Icc (-1 : ℝ) 1)
    (h1 : |(polyOf s).eval √2| = 1) (h2 : |(polyOf s).eval (-√2)| = 1) :
    (s.map fun r => 2 - r ^ 2).prod = 1 := by
  have hsq2 : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  unfold polyOf at h1 h2
  rw [abs_eval_prod] at h1 h2
  have hmul : (s.map fun r => |√2 - r| * |-√2 - r|).prod = 1 := by
    rw [Multiset.prod_map_mul, h1, h2, one_mul]
  have hfun : ∀ r ∈ s, |√2 - r| * |-√2 - r| = 2 - r ^ 2 := by
    intro r hr
    obtain ⟨hr1, hr2⟩ := hs r hr
    rw [← abs_mul]
    have : (√2 - r) * (-√2 - r) = r ^ 2 - 2 := by nlinarith
    rw [this, abs_of_nonpos (by nlinarith)]; ring
  rw [Multiset.map_congr rfl hfun] at hmul
  exact hmul

/-- Equality case (algebraic part). -/
theorem eq_case_poly (s : Multiset ℝ) (hs : ∀ r ∈ s, r ∈ Set.Icc (-1 : ℝ) 1)
    (h1 : |(polyOf s).eval √2| = 1) (h2 : |(polyOf s).eval (-√2)| = 1) :
    ∃ m : ℕ, polyOf s = (X ^ 2 - 1) ^ m := by
  have hsq := sq_eq_one_of_two_sub_sq s hs (two_sub_sq_prod_eq_one s hs h1 h2)
  have hpm : ∀ r ∈ s, r = 1 ∨ r = -1 := by
    intro r hr
    have := hsq r hr
    have : (r - 1) * (r + 1) = 0 := by nlinarith
    rcases mul_eq_zero.mp this with h | h
    · left; linarith
    · right; linarith
  -- split s into the roots equal to 1 and the rest (all equal to -1)
  set a := Multiset.count (1 : ℝ) s with ha
  have hsplit := Multiset.filter_add_not (fun r => r = (1 : ℝ)) s
  have hA : s.filter (fun r => r = (1 : ℝ)) = Multiset.replicate a 1 := by
    rw [ha, Multiset.filter_eq']
  have hBall : ∀ r ∈ s.filter (fun r => ¬ r = (1 : ℝ)), r = -1 := by
    intro r hr
    obtain ⟨hrs, hr1⟩ := Multiset.mem_filter.mp hr
    rcases hpm r hrs with h | h
    · exact absurd h hr1
    · exact h
  set b := Multiset.card (s.filter (fun r => ¬ r = (1 : ℝ))) with hb
  have hB : s.filter (fun r => ¬ r = (1 : ℝ)) = Multiset.replicate b (-1) :=
    Multiset.eq_replicate_of_mem hBall
  have hs' : s = Multiset.replicate a 1 + Multiset.replicate b (-1) := by
    rw [← hA, ← hB, hsplit]
  have hpoly : polyOf s = (X - C 1) ^ a * (X - C (-1)) ^ b := by
    unfold polyOf
    rw [hs', Multiset.map_add, Multiset.prod_add, Multiset.map_replicate, Multiset.map_replicate,
      Multiset.prod_replicate, Multiset.prod_replicate]
  -- evaluate at √2
  have hs1 : (1 : ℝ) < √2 := by
    rw [show (1 : ℝ) = √1 by simp]; exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
  have hev : (√2 + 1) ^ b * (√2 - 1) ^ a = 1 := by
    have := h1
    rw [hpoly] at this
    simp only [eval_mul, eval_pow, eval_sub, eval_X, eval_C, abs_mul, abs_pow] at this
    rw [abs_of_pos (by linarith : (0:ℝ) < √2 - 1), show √2 - (-1) = √2 + 1 by ring,
      abs_of_pos (by linarith : (0:ℝ) < √2 + 1)] at this
    linarith [this, mul_comm ((√2 - 1) ^ a) ((√2 + 1) ^ b)]
  have hab : b = a := pow_balance b a hev
  refine ⟨a, ?_⟩
  rw [hpoly, hab, ← mul_pow]
  congr 1
  simp only [map_one, map_neg]
  ring

end EP1038
