import LeanProject.COVLogTwo
import LeanProject.COVLogBounds15
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1520 : RB (Real.log ((402264251 : ℝ) / 100000000)) ((69596951 : ℝ) / 50000000) ((27838781 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((402264251 : ℝ) / 400000000)) (t := ((2264251 : ℝ) / 802264251))
    (lo := ((282233 : ℝ) / 50000000)) (hi := ((564467 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((402264251 : ℝ) / 100000000) = Real.log ((402264251 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((402264251 : ℝ) / 100000000) = ((402264251 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1521 : RB (Real.log ((402267047 : ℝ) / 100000000)) ((139194597 : ℝ) / 100000000) ((695973 : ℝ) / 500000) := by
  have hm := log_bounds_of_series (x := ((402267047 : ℝ) / 400000000)) (t := ((2267047 : ℝ) / 802267047))
    (lo := ((565161 : ℝ) / 100000000)) (hi := ((282581 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((402267047 : ℝ) / 100000000) = Real.log ((402267047 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((402267047 : ℝ) / 100000000) = ((402267047 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1522 : RB (Real.log ((13306139 : ℝ) / 10000000)) ((28564041 : ℝ) / 100000000) ((14282021 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((13306139 : ℝ) / 10000000)) (t := ((3306139 : ℝ) / 23306139))
    (lo := ((28564041 : ℝ) / 100000000)) (hi := ((14282021 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1523 : RB (Real.log ((400895933 : ℝ) / 100000000)) ((8678323 : ℝ) / 6250000) ((138853171 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((400895933 : ℝ) / 400000000)) (t := ((895933 : ℝ) / 800895933))
    (lo := ((55933 : ℝ) / 25000000)) (hi := ((223733 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((400895933 : ℝ) / 100000000) = Real.log ((400895933 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((400895933 : ℝ) / 100000000) = ((400895933 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1524 : RB (Real.log ((100224679 : ℝ) / 25000000)) ((69426931 : ℝ) / 50000000) ((27770773 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((100224679 : ℝ) / 100000000)) (t := ((224679 : ℝ) / 200224679))
    (lo := ((112213 : ℝ) / 50000000)) (hi := ((224427 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((100224679 : ℝ) / 25000000) = Real.log ((100224679 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((100224679 : ℝ) / 25000000) = ((100224679 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1525 : RB (Real.log ((16651467 : ℝ) / 12500000)) ((28676967 : ℝ) / 100000000) ((3584621 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((16651467 : ℝ) / 12500000)) (t := ((4151467 : ℝ) / 29151467))
    (lo := ((28676967 : ℝ) / 100000000)) (hi := ((3584621 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1526 : RB (Real.log ((3153587 : ℝ) / 25000000)) ((-51758383 : ℝ) / 25000000) ((-25879191 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((3153587 : ℝ) / 3125000)) (t := ((28587 : ℝ) / 6278587))
    (lo := ((1457 : ℝ) / 160000)) (hi := ((455313 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3153587 : ℝ) / 25000000) = Real.log ((3153587 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((3153587 : ℝ) / 25000000) = ((3153587 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1527 : RB (Real.log ((6708309 : ℝ) / 50000000)) ((-200867613 : ℝ) / 100000000) ((-200867609 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6708309 : ℝ) / 6250000)) (t := ((458309 : ℝ) / 12958309))
    (lo := ((110571 : ℝ) / 1562500)) (hi := ((1415309 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6708309 : ℝ) / 50000000) = Real.log ((6708309 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6708309 : ℝ) / 50000000) = ((6708309 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1528 : RB (Real.log ((152913 : ℝ) / 3125000)) ((-301732047 : ℝ) / 100000000) ((-150866021 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((305826 : ℝ) / 390625)) (t := ((-84799 : ℝ) / 696451))
    (lo := ((-24473171 : ℝ) / 100000000)) (hi := ((-2447317 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((152913 : ℝ) / 3125000) = Real.log ((305826 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((152913 : ℝ) / 3125000) = ((305826 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1529 : RB (Real.log ((2464433 : ℝ) / 50000000)) ((-301006129 : ℝ) / 100000000) ((-75251531 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2464433 : ℝ) / 3125000)) (t := ((-660567 : ℝ) / 5589433))
    (lo := ((-23747253 : ℝ) / 100000000)) (hi := ((-5936813 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2464433 : ℝ) / 50000000) = Real.log ((2464433 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2464433 : ℝ) / 50000000) = ((2464433 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1530 : RB (Real.log ((12748959 : ℝ) / 20000000)) ((-45028267 : ℝ) / 100000000) ((-9005653 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((12748959 : ℝ) / 10000000)) (t := ((2748959 : ℝ) / 22748959))
    (lo := ((6071613 : ℝ) / 25000000)) (hi := ((24286453 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12748959 : ℝ) / 20000000) = Real.log ((12748959 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((12748959 : ℝ) / 20000000) = ((12748959 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1531 : RB (Real.log ((63746321 : ℝ) / 100000000)) ((-45025873 : ℝ) / 100000000) ((-45025871 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63746321 : ℝ) / 50000000)) (t := ((13746321 : ℝ) / 113746321))
    (lo := ((12144423 : ℝ) / 50000000)) (hi := ((24288847 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63746321 : ℝ) / 100000000) = Real.log ((63746321 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63746321 : ℝ) / 100000000) = ((63746321 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1532 : RB (Real.log ((19485493 : ℝ) / 50000000)) ((-47117639 : ℝ) / 50000000) ((-23558819 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((19485493 : ℝ) / 25000000)) (t := ((-5514507 : ℝ) / 44485493))
    (lo := ((-24920559 : ℝ) / 100000000)) (hi := ((-12460279 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19485493 : ℝ) / 50000000) = Real.log ((19485493 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19485493 : ℝ) / 50000000) = ((19485493 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1533 : RB (Real.log ((37990353 : ℝ) / 20000000)) ((32079999 : ℝ) / 50000000) ((401 : ℝ) / 625) := by
  have hm := log_bounds_of_series (x := ((37990353 : ℝ) / 40000000)) (t := ((-2009647 : ℝ) / 77990353))
    (lo := ((-32217 : ℝ) / 625000)) (hi := ((-5154719 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37990353 : ℝ) / 20000000) = Real.log ((37990353 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((37990353 : ℝ) / 20000000) = ((37990353 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1534 : RB (Real.log ((95008973 : ℝ) / 50000000)) ((64194833 : ℝ) / 100000000) ((12838967 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((95008973 : ℝ) / 100000000)) (t := ((-4991027 : ℝ) / 195008973))
    (lo := ((-1023977 : ℝ) / 20000000)) (hi := ((-1279971 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95008973 : ℝ) / 50000000) = Real.log ((95008973 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95008973 : ℝ) / 50000000) = ((95008973 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1535 : RB (Real.log ((32244521 : ℝ) / 50000000)) ((-1370859 : ℝ) / 3125000) ((-21933743 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((32244521 : ℝ) / 25000000)) (t := ((7244521 : ℝ) / 57244521))
    (lo := ((25447231 : ℝ) / 100000000)) (hi := ((397613 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32244521 : ℝ) / 50000000) = Real.log ((32244521 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32244521 : ℝ) / 50000000) = ((32244521 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1536 : RB (Real.log ((4030661 : ℝ) / 6250000)) ((-4386511 : ℝ) / 10000000) ((-10966277 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4030661 : ℝ) / 3125000)) (t := ((905661 : ℝ) / 7155661))
    (lo := ((25449609 : ℝ) / 100000000)) (hi := ((2544961 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4030661 : ℝ) / 6250000) = Real.log ((4030661 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((4030661 : ℝ) / 6250000) = ((4030661 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1537 : RB (Real.log ((19623559 : ℝ) / 50000000)) ((-93529219 : ℝ) / 100000000) ((-93529217 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19623559 : ℝ) / 25000000)) (t := ((-5376441 : ℝ) / 44623559))
    (lo := ((-48429 : ℝ) / 200000)) (hi := ((-24214499 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19623559 : ℝ) / 50000000) = Real.log ((19623559 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19623559 : ℝ) / 50000000) = ((19623559 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1538 : RB (Real.log ((8036061 : ℝ) / 2000000)) ((27815837 : ℝ) / 20000000) ((34769797 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((8036061 : ℝ) / 8000000)) (t := ((36061 : ℝ) / 16036061))
    (lo := ((449749 : ℝ) / 100000000)) (hi := ((1799 : ℝ) / 400000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8036061 : ℝ) / 2000000) = Real.log ((8036061 : ℝ) / 8000000) + 2 * Real.log 2 := by
    rw [show ((8036061 : ℝ) / 2000000) = ((8036061 : ℝ) / 8000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1539 : RB (Real.log ((401805863 : ℝ) / 100000000)) ((27815977 : ℝ) / 20000000) ((8692493 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((401805863 : ℝ) / 400000000)) (t := ((1805863 : ℝ) / 801805863))
    (lo := ((450449 : ℝ) / 100000000)) (hi := ((9009 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((401805863 : ℝ) / 100000000) = Real.log ((401805863 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((401805863 : ℝ) / 100000000) = ((401805863 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1540 : RB (Real.log ((26622321 : ℝ) / 20000000)) ((7150443 : ℝ) / 25000000) ((28601773 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((26622321 : ℝ) / 20000000)) (t := ((6622321 : ℝ) / 46622321))
    (lo := ((7150443 : ℝ) / 25000000)) (hi := ((28601773 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1541 : RB (Real.log ((400441601 : ℝ) / 100000000)) ((5549591 : ℝ) / 4000000) ((69369889 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((400441601 : ℝ) / 400000000)) (t := ((441601 : ℝ) / 800441601))
    (lo := ((110339 : ℝ) / 100000000)) (hi := ((5517 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((400441601 : ℝ) / 100000000) = Real.log ((400441601 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((400441601 : ℝ) / 100000000) = ((400441601 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1542 : RB (Real.log ((400444401 : ℝ) / 100000000)) ((69370237 : ℝ) / 50000000) ((138740477 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((400444401 : ℝ) / 400000000)) (t := ((444401 : ℝ) / 800444401))
    (lo := ((55519 : ℝ) / 50000000)) (hi := ((111039 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((400444401 : ℝ) / 100000000) = Real.log ((400444401 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((400444401 : ℝ) / 100000000) = ((400444401 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1543 : RB (Real.log ((2665233 : ℝ) / 2000000)) ((2871443 : ℝ) / 10000000) ((28714431 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2665233 : ℝ) / 2000000)) (t := ((665233 : ℝ) / 4665233))
    (lo := ((2871443 : ℝ) / 10000000)) (hi := ((28714431 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1544 : RB (Real.log ((12674593 : ℝ) / 100000000)) ((-103278539 : ℝ) / 50000000) ((-103278537 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12674593 : ℝ) / 12500000)) (t := ((174593 : ℝ) / 25174593))
    (lo := ((1387079 : ℝ) / 100000000)) (hi := ((34677 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12674593 : ℝ) / 100000000) = Real.log ((12674593 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12674593 : ℝ) / 100000000) = ((12674593 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1545 : RB (Real.log ((13474989 : ℝ) / 100000000)) ((-50108373 : ℝ) / 25000000) ((-12527093 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((13474989 : ℝ) / 12500000)) (t := ((974989 : ℝ) / 25974989))
    (lo := ((1502133 : ℝ) / 20000000)) (hi := ((3755333 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13474989 : ℝ) / 100000000) = Real.log ((13474989 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13474989 : ℝ) / 100000000) = ((13474989 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1546 : RB (Real.log ((492543 : ℝ) / 10000000)) ((-60215173 : ℝ) / 20000000) ((-15053793 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((492543 : ℝ) / 625000)) (t := ((-132457 : ℝ) / 1117543))
    (lo := ((-23816989 : ℝ) / 100000000)) (hi := ((-5954247 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((492543 : ℝ) / 10000000) = Real.log ((492543 : ℝ) / 625000) - 4 * Real.log 2 := by
    rw [show ((492543 : ℝ) / 10000000) = ((492543 : ℝ) / 625000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1547 : RB (Real.log ((992221 : ℝ) / 20000000)) ((-300354173 : ℝ) / 100000000) ((-37544271 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((992221 : ℝ) / 1250000)) (t := ((-257779 : ℝ) / 2242221))
    (lo := ((-23095297 : ℝ) / 100000000)) (hi := ((-90216 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((992221 : ℝ) / 20000000) = Real.log ((992221 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((992221 : ℝ) / 20000000) = ((992221 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1548 : RB (Real.log ((63659213 : ℝ) / 100000000)) ((-22581307 : ℝ) / 50000000) ((-11290653 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((63659213 : ℝ) / 50000000)) (t := ((13659213 : ℝ) / 113659213))
    (lo := ((4830421 : ℝ) / 20000000)) (hi := ((12076053 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63659213 : ℝ) / 100000000) = Real.log ((63659213 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63659213 : ℝ) / 100000000) = ((63659213 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1549 : RB (Real.log ((63660751 : ℝ) / 100000000)) ((-22580099 : ℝ) / 50000000) ((-11290049 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((63660751 : ℝ) / 50000000)) (t := ((13660751 : ℝ) / 113660751))
    (lo := ((24154521 : ℝ) / 100000000)) (hi := ((12077261 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63660751 : ℝ) / 100000000) = Real.log ((63660751 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63660751 : ℝ) / 100000000) = ((63660751 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1550 : RB (Real.log ((7787929 : ℝ) / 20000000)) ((-23578933 : ℝ) / 25000000) ((-9431573 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((7787929 : ℝ) / 10000000)) (t := ((-2212071 : ℝ) / 17787929))
    (lo := ((-25001013 : ℝ) / 100000000)) (hi := ((-6250253 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7787929 : ℝ) / 20000000) = Real.log ((7787929 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((7787929 : ℝ) / 20000000) = ((7787929 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1551 : RB (Real.log ((189885577 : ℝ) / 100000000)) ((64125147 : ℝ) / 100000000) ((64125149 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((189885577 : ℝ) / 200000000)) (t := ((-10114423 : ℝ) / 389885577))
    (lo := ((-5189571 : ℝ) / 100000000)) (hi := ((-518957 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189885577 : ℝ) / 100000000) = Real.log ((189885577 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189885577 : ℝ) / 100000000) = ((189885577 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1552 : RB (Real.log ((47487943 : ℝ) / 25000000)) ((32080001 : ℝ) / 50000000) ((16040001 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((47487943 : ℝ) / 50000000)) (t := ((-2512057 : ℝ) / 97487943))
    (lo := ((-1288679 : ℝ) / 25000000)) (hi := ((-1030943 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47487943 : ℝ) / 25000000) = Real.log ((47487943 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((47487943 : ℝ) / 25000000) = ((47487943 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1553 : RB (Real.log ((64400457 : ℝ) / 100000000)) ((-44004947 : ℝ) / 100000000) ((-8800989 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((64400457 : ℝ) / 50000000)) (t := ((14400457 : ℝ) / 114400457))
    (lo := ((6327443 : ℝ) / 25000000)) (hi := ((25309773 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64400457 : ℝ) / 100000000) = Real.log ((64400457 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64400457 : ℝ) / 100000000) = ((64400457 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1554 : RB (Real.log ((64402001 : ℝ) / 100000000)) ((-880051 : ℝ) / 2000000) ((-11000637 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((64402001 : ℝ) / 50000000)) (t := ((14402001 : ℝ) / 114402001))
    (lo := ((25312169 : ℝ) / 100000000)) (hi := ((2531217 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64402001 : ℝ) / 100000000) = Real.log ((64402001 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64402001 : ℝ) / 100000000) = ((64402001 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1555 : RB (Real.log ((4901869 : ℝ) / 12500000)) ((-9361121 : ℝ) / 10000000) ((-11701401 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4901869 : ℝ) / 6250000)) (t := ((-1348131 : ℝ) / 11151869))
    (lo := ((-24296491 : ℝ) / 100000000)) (hi := ((-2429649 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4901869 : ℝ) / 12500000) = Real.log ((4901869 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((4901869 : ℝ) / 12500000) = ((4901869 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1556 : RB (Real.log ((401344131 : ℝ) / 100000000)) ((27792981 : ℝ) / 20000000) ((34741227 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((401344131 : ℝ) / 400000000)) (t := ((1344131 : ℝ) / 801344131))
    (lo := ((335469 : ℝ) / 100000000)) (hi := ((33547 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((401344131 : ℝ) / 100000000) = Real.log ((401344131 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((401344131 : ℝ) / 100000000) = ((401344131 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1557 : RB (Real.log ((5016837 : ℝ) / 1250000)) ((13896561 : ℝ) / 10000000) ((138965613 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5016837 : ℝ) / 5000000)) (t := ((16837 : ℝ) / 10016837))
    (lo := ((168087 : ℝ) / 50000000)) (hi := ((13447 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5016837 : ℝ) / 1250000) = Real.log ((5016837 : ℝ) / 5000000) + 2 * Real.log 2 := by
    rw [show ((5016837 : ℝ) / 1250000) = ((5016837 : ℝ) / 5000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1558 : RB (Real.log ((3329043 : ℝ) / 2500000)) ((14319707 : ℝ) / 50000000) ((5727883 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3329043 : ℝ) / 2500000)) (t := ((829043 : ℝ) / 5829043))
    (lo := ((14319707 : ℝ) / 50000000)) (hi := ((5727883 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1559 : RB (Real.log ((399989499 : ℝ) / 100000000)) ((13862681 : ℝ) / 10000000) ((138626813 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((399989499 : ℝ) / 400000000)) (t := ((-10501 : ℝ) / 799989499))
    (lo := ((-1313 : ℝ) / 50000000)) (hi := ((-21 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((399989499 : ℝ) / 100000000) = Real.log ((399989499 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((399989499 : ℝ) / 100000000) = ((399989499 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1560 : RB (Real.log ((79998463 : ℝ) / 20000000)) ((69313757 : ℝ) / 50000000) ((138627517 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((79998463 : ℝ) / 80000000)) (t := ((-1537 : ℝ) / 159998463))
    (lo := ((-961 : ℝ) / 50000000)) (hi := ((-1921 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((79998463 : ℝ) / 20000000) = Real.log ((79998463 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((79998463 : ℝ) / 20000000) = ((79998463 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1561 : RB (Real.log ((26662293 : ℝ) / 20000000)) ((7187951 : ℝ) / 25000000) ((5750361 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((26662293 : ℝ) / 20000000)) (t := ((6662293 : ℝ) / 46662293))
    (lo := ((7187951 : ℝ) / 25000000)) (hi := ((5750361 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1562 : RB (Real.log ((2546921 : ℝ) / 20000000)) ((-206084713 : ℝ) / 100000000) ((-206084709 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2546921 : ℝ) / 2500000)) (t := ((46921 : ℝ) / 5046921))
    (lo := ((464861 : ℝ) / 25000000)) (hi := ((371889 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2546921 : ℝ) / 20000000) = Real.log ((2546921 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((2546921 : ℝ) / 20000000) = ((2546921 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1563 : RB (Real.log ((1691647 : ℝ) / 12500000)) ((-200002607 : ℝ) / 100000000) ((-200002603 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1691647 : ℝ) / 1562500)) (t := ((129147 : ℝ) / 3254147))
    (lo := ((158831 : ℝ) / 2000000)) (hi := ((7941551 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1691647 : ℝ) / 12500000) = Real.log ((1691647 : ℝ) / 1562500) - 3 * Real.log 2 := by
    rw [show ((1691647 : ℝ) / 12500000) = ((1691647 : ℝ) / 1562500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1564 : RB (Real.log ((2478823 : ℝ) / 50000000)) ((-3755299 : ℝ) / 1250000) ((-60084783 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((2478823 : ℝ) / 3125000)) (t := ((-646177 : ℝ) / 5603823))
    (lo := ((-5791261 : ℝ) / 25000000)) (hi := ((-23165043 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2478823 : ℝ) / 50000000) = Real.log ((2478823 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2478823 : ℝ) / 50000000) = ((2478823 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1565 : RB (Real.log ((78021 : ℝ) / 1562500)) ((-7492661 : ℝ) / 2500000) ((-59941287 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((312084 : ℝ) / 390625)) (t := ((-78541 : ℝ) / 702709))
    (lo := ((-5611891 : ℝ) / 25000000)) (hi := ((-22447563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((78021 : ℝ) / 1562500) = Real.log ((312084 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((78021 : ℝ) / 1562500) = ((312084 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1566 : RB (Real.log ((63573939 : ℝ) / 100000000)) ((-22648329 : ℝ) / 50000000) ((-2831041 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((63573939 : ℝ) / 50000000)) (t := ((13573939 : ℝ) / 113573939))
    (lo := ((24018061 : ℝ) / 100000000)) (hi := ((12009031 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63573939 : ℝ) / 100000000) = Real.log ((63573939 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63573939 : ℝ) / 100000000) = ((63573939 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1567 : RB (Real.log ((63575487 : ℝ) / 100000000)) ((-45294223 : ℝ) / 100000000) ((-45294221 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63575487 : ℝ) / 50000000)) (t := ((13575487 : ℝ) / 113575487))
    (lo := ((1501281 : ℝ) / 6250000)) (hi := ((24020497 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63575487 : ℝ) / 100000000) = Real.log ((63575487 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63575487 : ℝ) / 100000000) = ((63575487 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1568 : RB (Real.log ((3890839 : ℝ) / 10000000)) ((-94396029 : ℝ) / 100000000) ((-94396027 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3890839 : ℝ) / 5000000)) (t := ((-1109161 : ℝ) / 8890839))
    (lo := ((-2508131 : ℝ) / 10000000)) (hi := ((-25081309 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3890839 : ℝ) / 10000000) = Real.log ((3890839 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((3890839 : ℝ) / 10000000) = ((3890839 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1569 : RB (Real.log ((189819379 : ℝ) / 100000000)) ((64090279 : ℝ) / 100000000) ((64090281 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((189819379 : ℝ) / 200000000)) (t := ((-10180621 : ℝ) / 389819379))
    (lo := ((-5224439 : ℝ) / 100000000)) (hi := ((-2612219 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189819379 : ℝ) / 100000000) = Real.log ((189819379 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189819379 : ℝ) / 100000000) = ((189819379 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1570 : RB (Real.log ((11867849 : ℝ) / 6250000)) ((64125151 : ℝ) / 100000000) ((64125153 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11867849 : ℝ) / 12500000)) (t := ((-632151 : ℝ) / 24367849))
    (lo := ((-5189567 : ℝ) / 100000000)) (hi := ((-2594783 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11867849 : ℝ) / 6250000) = Real.log ((11867849 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((11867849 : ℝ) / 6250000) = ((11867849 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1571 : RB (Real.log ((8039029 : ℝ) / 12500000)) ((-8828407 : ℝ) / 20000000) ((-44142033 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8039029 : ℝ) / 6250000)) (t := ((1789029 : ℝ) / 14289029))
    (lo := ((6293171 : ℝ) / 25000000)) (hi := ((5034537 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8039029 : ℝ) / 12500000) = Real.log ((8039029 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((8039029 : ℝ) / 12500000) = ((8039029 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1572 : RB (Real.log ((64313787 : ℝ) / 100000000)) ((-22069809 : ℝ) / 50000000) ((-1379363 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((64313787 : ℝ) / 50000000)) (t := ((14313787 : ℝ) / 114313787))
    (lo := ((25175101 : ℝ) / 100000000)) (hi := ((12587551 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64313787 : ℝ) / 100000000) = Real.log ((64313787 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64313787 : ℝ) / 100000000) = ((64313787 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1573 : RB (Real.log ((39182889 : ℝ) / 100000000)) ((-18738601 : ℝ) / 20000000) ((-93693003 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39182889 : ℝ) / 50000000)) (t := ((-10817111 : ℝ) / 89182889))
    (lo := ((-12189143 : ℝ) / 50000000)) (hi := ((-4875657 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39182889 : ℝ) / 100000000) = Real.log ((39182889 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39182889 : ℝ) / 100000000) = ((39182889 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1574 : RB (Real.log ((40088749 : ℝ) / 10000000)) ((69425531 : ℝ) / 50000000) ((27770213 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((40088749 : ℝ) / 40000000)) (t := ((88749 : ℝ) / 80088749))
    (lo := ((110813 : ℝ) / 50000000)) (hi := ((221627 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40088749 : ℝ) / 10000000) = Real.log ((40088749 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((40088749 : ℝ) / 10000000) = ((40088749 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1575 : RB (Real.log ((12527823 : ℝ) / 3125000)) ((34712943 : ℝ) / 25000000) ((5554071 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((12527823 : ℝ) / 12500000)) (t := ((27823 : ℝ) / 25027823))
    (lo := ((1737 : ℝ) / 781250)) (hi := ((222337 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12527823 : ℝ) / 3125000) = Real.log ((12527823 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((12527823 : ℝ) / 3125000) = ((12527823 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1576 : RB (Real.log ((66605867 : ℝ) / 50000000)) ((14338483 : ℝ) / 50000000) ((28676967 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66605867 : ℝ) / 50000000)) (t := ((16605867 : ℝ) / 116605867))
    (lo := ((14338483 : ℝ) / 50000000)) (hi := ((28676967 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1577 : RB (Real.log ((199769807 : ℝ) / 50000000)) ((138514273 : ℝ) / 100000000) ((34628569 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((199769807 : ℝ) / 200000000)) (t := ((-230193 : ℝ) / 399769807))
    (lo := ((-115163 : ℝ) / 100000000)) (hi := ((-57581 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((199769807 : ℝ) / 50000000) = Real.log ((199769807 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((199769807 : ℝ) / 50000000) = ((199769807 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1578 : RB (Real.log ((24971403 : ℝ) / 6250000)) ((69257491 : ℝ) / 50000000) ((27702997 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((24971403 : ℝ) / 25000000)) (t := ((-28597 : ℝ) / 49971403))
    (lo := ((-57227 : ℝ) / 50000000)) (hi := ((-114453 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24971403 : ℝ) / 6250000) = Real.log ((24971403 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((24971403 : ℝ) / 6250000) = ((24971403 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1579 : RB (Real.log ((133361181 : ℝ) / 100000000)) ((2878909 : ℝ) / 10000000) ((7197273 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((133361181 : ℝ) / 200000000)) (t := ((-66638819 : ℝ) / 333361181))
    (lo := ((-10131407 : ℝ) / 25000000)) (hi := ((-40525627 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133361181 : ℝ) / 100000000) = Real.log ((133361181 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133361181 : ℝ) / 100000000) = ((133361181 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1580 : RB (Real.log ((6397193 : ℝ) / 50000000)) ((-102808187 : ℝ) / 50000000) ((-20561637 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((6397193 : ℝ) / 6250000)) (t := ((147193 : ℝ) / 12647193))
    (lo := ((2327783 : ℝ) / 100000000)) (hi := ((290973 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6397193 : ℝ) / 50000000) = Real.log ((6397193 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6397193 : ℝ) / 50000000) = ((6397193 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1581 : RB (Real.log ((13591169 : ℝ) / 100000000)) ((-99787499 : ℝ) / 50000000) ((-99787497 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((13591169 : ℝ) / 12500000)) (t := ((1091169 : ℝ) / 26091169))
    (lo := ((8369159 : ℝ) / 100000000)) (hi := ((209229 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13591169 : ℝ) / 100000000) = Real.log ((13591169 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13591169 : ℝ) / 100000000) = ((13591169 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1582 : RB (Real.log ((4989859 : ℝ) / 100000000)) ((-149888129 : ℝ) / 50000000) ((-299776253 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4989859 : ℝ) / 6250000)) (t := ((-1260141 : ℝ) / 11239859))
    (lo := ((-11258691 : ℝ) / 50000000)) (hi := ((-22517381 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4989859 : ℝ) / 100000000) = Real.log ((4989859 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4989859 : ℝ) / 100000000) = ((4989859 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1583 : RB (Real.log ((5025583 : ℝ) / 100000000)) ((-74765719 : ℝ) / 25000000) ((-299062871 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5025583 : ℝ) / 6250000)) (t := ((-1224417 : ℝ) / 11275583))
    (lo := ((-5451 : ℝ) / 25000)) (hi := ((-21803999 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5025583 : ℝ) / 100000000) = Real.log ((5025583 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5025583 : ℝ) / 100000000) = ((5025583 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1584 : RB (Real.log ((63488959 : ℝ) / 100000000)) ((-22715209 : ℝ) / 50000000) ((-2839401 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((63488959 : ℝ) / 50000000)) (t := ((13488959 : ℝ) / 113488959))
    (lo := ((23884301 : ℝ) / 100000000)) (hi := ((11942151 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63488959 : ℝ) / 100000000) = Real.log ((63488959 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63488959 : ℝ) / 100000000) = ((63488959 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1585 : RB (Real.log ((31745259 : ℝ) / 50000000)) ((-45427963 : ℝ) / 100000000) ((-45427961 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((31745259 : ℝ) / 25000000)) (t := ((6745259 : ℝ) / 56745259))
    (lo := ((5971689 : ℝ) / 25000000)) (hi := ((23886757 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31745259 : ℝ) / 50000000) = Real.log ((31745259 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31745259 : ℝ) / 50000000) = ((31745259 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1586 : RB (Real.log ((38877217 : ℝ) / 100000000)) ((-4723809 : ℝ) / 5000000) ((-47238089 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((38877217 : ℝ) / 50000000)) (t := ((-11122783 : ℝ) / 88877217))
    (lo := ((-25161461 : ℝ) / 100000000)) (hi := ((-1258073 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38877217 : ℝ) / 100000000) = Real.log ((38877217 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((38877217 : ℝ) / 100000000) = ((38877217 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1587 : RB (Real.log ((189753167 : ℝ) / 100000000)) ((64055391 : ℝ) / 100000000) ((64055393 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((189753167 : ℝ) / 200000000)) (t := ((-10246833 : ℝ) / 389753167))
    (lo := ((-5259327 : ℝ) / 100000000)) (hi := ((-2629663 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((189753167 : ℝ) / 100000000) = Real.log ((189753167 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((189753167 : ℝ) / 100000000) = ((189753167 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1588 : RB (Real.log ((94909693 : ℝ) / 50000000)) ((64090283 : ℝ) / 100000000) ((12818057 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((94909693 : ℝ) / 100000000)) (t := ((-5090307 : ℝ) / 194909693))
    (lo := ((-1044887 : ℝ) / 20000000)) (hi := ((-2612217 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94909693 : ℝ) / 50000000) = Real.log ((94909693 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((94909693 : ℝ) / 50000000) = ((94909693 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1589 : RB (Real.log ((16056091 : ℝ) / 25000000)) ((-11069689 : ℝ) / 25000000) ((-22139377 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16056091 : ℝ) / 12500000)) (t := ((3556091 : ℝ) / 28556091))
    (lo := ((25035963 : ℝ) / 100000000)) (hi := ((6258991 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16056091 : ℝ) / 25000000) = Real.log ((16056091 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((16056091 : ℝ) / 25000000) = ((16056091 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1590 : RB (Real.log ((6422593 : ℝ) / 10000000)) ((-22138159 : ℝ) / 50000000) ((-11069079 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((6422593 : ℝ) / 5000000)) (t := ((1422593 : ℝ) / 11422593))
    (lo := ((25038401 : ℝ) / 100000000)) (hi := ((12519201 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6422593 : ℝ) / 10000000) = Real.log ((6422593 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((6422593 : ℝ) / 10000000) = ((6422593 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1591 : RB (Real.log ((2446933 : ℝ) / 6250000)) ((-93774607 : ℝ) / 100000000) ((-18754921 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((2446933 : ℝ) / 3125000)) (t := ((-678067 : ℝ) / 5571933))
    (lo := ((-1528743 : ℝ) / 6250000)) (hi := ((-24459887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2446933 : ℝ) / 6250000) = Real.log ((2446933 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((2446933 : ℝ) / 6250000) = ((2446933 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1592 : RB (Real.log ((80086621 : ℝ) / 20000000)) ((138737653 : ℝ) / 100000000) ((17342207 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((80086621 : ℝ) / 80000000)) (t := ((86621 : ℝ) / 160086621))
    (lo := ((108217 : ℝ) / 100000000)) (hi := ((54109 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((80086621 : ℝ) / 20000000) = Real.log ((80086621 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((80086621 : ℝ) / 20000000) = ((80086621 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1593 : RB (Real.log ((1564203 : ℝ) / 390625)) ((2167787 : ℝ) / 1562500) ((138738371 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1564203 : ℝ) / 1562500)) (t := ((1703 : ℝ) / 3126703))
    (lo := ((27233 : ℝ) / 25000000)) (hi := ((108933 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1564203 : ℝ) / 390625) = Real.log ((1564203 : ℝ) / 1562500) + 2 * Real.log 2 := by
    rw [show ((1564203 : ℝ) / 390625) = ((1564203 : ℝ) / 1562500) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1594 : RB (Real.log ((8328853 : ℝ) / 6250000)) ((7178607 : ℝ) / 25000000) ((28714429 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8328853 : ℝ) / 6250000)) (t := ((2078853 : ℝ) / 14578853))
    (lo := ((7178607 : ℝ) / 25000000)) (hi := ((28714429 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1595 : RB (Real.log ((15963677 : ℝ) / 4000000)) ((138402159 : ℝ) / 100000000) ((69201081 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((15963677 : ℝ) / 16000000)) (t := ((-36323 : ℝ) / 31963677))
    (lo := ((-227277 : ℝ) / 100000000)) (hi := ((-56819 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15963677 : ℝ) / 4000000) = Real.log ((15963677 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((15963677 : ℝ) / 4000000) = ((15963677 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1596 : RB (Real.log ((15963791 : ℝ) / 4000000)) ((138402873 : ℝ) / 100000000) ((34600719 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((15963791 : ℝ) / 16000000)) (t := ((-36209 : ℝ) / 31963791))
    (lo := ((-226563 : ℝ) / 100000000)) (hi := ((-113281 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15963791 : ℝ) / 4000000) = Real.log ((15963791 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((15963791 : ℝ) / 4000000) = ((15963791 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1597 : RB (Real.log ((133410799 : ℝ) / 100000000)) ((28826289 : ℝ) / 100000000) ((28826291 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133410799 : ℝ) / 200000000)) (t := ((-66589201 : ℝ) / 333410799))
    (lo := ((-40488429 : ℝ) / 100000000)) (hi := ((-10122107 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133410799 : ℝ) / 100000000) = Real.log ((133410799 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133410799 : ℝ) / 100000000) = ((133410799 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1598 : RB (Real.log ((6426967 : ℝ) / 50000000)) ((-205152031 : ℝ) / 100000000) ((-205152027 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6426967 : ℝ) / 6250000)) (t := ((176967 : ℝ) / 12676967))
    (lo := ((1396063 : ℝ) / 50000000)) (hi := ((2792127 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6426967 : ℝ) / 50000000) = Real.log ((6426967 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6426967 : ℝ) / 50000000) = ((6426967 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1599 : RB (Real.log ((3412243 : ℝ) / 25000000)) ((-199150601 : ℝ) / 100000000) ((-199150597 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3412243 : ℝ) / 3125000)) (t := ((287243 : ℝ) / 6537243))
    (lo := ((2198389 : ℝ) / 25000000)) (hi := ((8793557 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3412243 : ℝ) / 25000000) = Real.log ((3412243 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((3412243 : ℝ) / 25000000) = ((3412243 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
