import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk07
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_55 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1113 : ℝ) / 1753) ((2799 : ℝ) / 4399))
    (hq : RB (qa a) ((103973 : ℝ) / 6250000) ((1698027 : ℝ) / 100000000))
    (hd : RB (D0a a) ((38675411 : ℝ) / 20000000) ((19350817 : ℝ) / 10000000))
    : certE k a ((10156453 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((41360009 : ℝ) / 100000000) ∧ 0 < certE k a ((65118749 : ℝ) / 50000000) ∧ certE k a ((130574971 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((13837 : ℝ) / 50000000) ((28833 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((10156453 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((40596979 : ℝ) / 100000000) ((20299069 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((10156453 : ℝ) / 25000000) ((10156453 : ℝ) / 25000000) ((10156453 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((14843547 : ℝ) / 25000000))
  have h3 : RB z3 ((34187397 : ℝ) / 50000000) ((68376747 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((14843547 : ℝ) / 25000000) ((14843547 : ℝ) / 25000000) ((14843547 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-19008297 : ℝ) / 50000000) ((-38013737 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_990.1 cov_log_991.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-6047309 : ℝ) / 25000000) ((-24135361 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((10156453 : ℝ) / 25000000))
  have h6 : RB z6 ((-90076657 : ℝ) / 100000000) ((-18015331 : ℝ) / 20000000) := rb_log (show RB ((10156453 : ℝ) / 25000000) ((10156453 : ℝ) / 25000000) ((10156453 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_992.1 cov_log_992.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((65887419 : ℝ) / 100000000) ((4121331 : ℝ) / 6250000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((32973587 : ℝ) / 50000000) ((16503739 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_993.1 cov_log_994.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-127537 : ℝ) / 100000000) ((-2939 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((13837 : ℝ) / 50000000) ((28833 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((41360009 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((5166397 : ℝ) / 12500000) ((8266467 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((41360009 : ℝ) / 100000000) ((41360009 : ℝ) / 100000000) ((41360009 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((58639991 : ℝ) / 100000000))
  have h12 : RB z12 ((17620729 : ℝ) / 25000000) ((35242447 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((58639991 : ℝ) / 100000000) ((58639991 : ℝ) / 100000000) ((58639991 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-2186249 : ℝ) / 6250000) ((-4372147 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_995.1 cov_log_996.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-22257099 : ℝ) / 100000000) ((-11103707 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((41360009 : ℝ) / 100000000))
  have h15 : RB z15 ((-3531423 : ℝ) / 4000000) ((-88285573 : ℝ) / 100000000) := rb_log (show RB ((41360009 : ℝ) / 100000000) ((41360009 : ℝ) / 100000000) ((41360009 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_997.1 cov_log_997.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33014237 : ℝ) / 50000000) ((66078161 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((32973587 : ℝ) / 50000000) ((16503739 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_993.1 cov_log_994.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((6759 : ℝ) / 50000000) ((130987 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((13837 : ℝ) / 50000000) ((28833 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((65118749 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((26041733 : ℝ) / 20000000) ((4069057 : ℝ) / 3125000) := rb_widen (rb_sub (show RB ((65118749 : ℝ) / 50000000) ((65118749 : ℝ) / 50000000) ((65118749 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((15118749 : ℝ) / 50000000))
  have h21 : RB z21 ((215309919 : ℝ) / 50000000) ((53827959 : ℝ) / 12500000) := rb_div_signed h20 (show RB ((15118749 : ℝ) / 50000000) ((15118749 : ℝ) / 50000000) ((15118749 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((73002773 : ℝ) / 50000000) ((3650161 : ℝ) / 2500000) := rb_log h21 (by norm_num) cov_log_998.1 cov_log_999.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92700611 : ℝ) / 100000000) ((72579 : ℝ) / 78125) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((65118749 : ℝ) / 50000000))
  have h24 : RB z24 ((528379 : ℝ) / 2000000) ((26418951 : ℝ) / 100000000) := rb_log (show RB ((65118749 : ℝ) / 50000000) ((65118749 : ℝ) / 50000000) ((65118749 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1000.1 cov_log_1000.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((3314083 : ℝ) / 5000000) ((6648217 : ℝ) / 10000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((32973587 : ℝ) / 50000000) ((16503739 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_993.1 cov_log_994.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((16669 : ℝ) / 6250000) ((133749 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((13837 : ℝ) / 50000000) ((28833 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((130574971 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((65273069 : ℝ) / 50000000) ((130547297 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((130574971 : ℝ) / 100000000) ((130574971 : ℝ) / 100000000) ((130574971 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((30574971 : ℝ) / 100000000))
  have h30 : RB z30 ((213485301 : ℝ) / 50000000) ((213487197 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((30574971 : ℝ) / 100000000) ((30574971 : ℝ) / 100000000) ((30574971 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((145154497 : ℝ) / 100000000) ((36288847 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_1001.1 cov_log_1002.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92160271 : ℝ) / 100000000) ((23089903 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((130574971 : ℝ) / 100000000))
  have h33 : RB z33 ((3334717 : ℝ) / 12500000) ((26677737 : ℝ) / 100000000) := rb_log (show RB ((130574971 : ℝ) / 100000000) ((130574971 : ℝ) / 100000000) ((130574971 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1003.1 cov_log_1003.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((32741267 : ℝ) / 50000000) ((16420469 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((32973587 : ℝ) / 50000000) ((16503739 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_993.1 cov_log_994.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-266211 : ℝ) / 50000000) ((-132649 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((10156453 : ℝ) / 25000000)) ((-127537 : ℝ) / 100000000) ((-2939 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((41360009 : ℝ) / 100000000)) ((6759 : ℝ) / 50000000) ((130987 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((65118749 : ℝ) / 50000000)) ((16669 : ℝ) / 6250000) ((133749 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((130574971 : ℝ) / 100000000)) ((-266211 : ℝ) / 50000000) ((-132649 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_55 {k A q d vp vm : ℝ}
    (hk : RB k ((1113 : ℝ) / 640) ((2799 : ℝ) / 1600))
    (hA : RB A ((1113 : ℝ) / 1753) ((2799 : ℝ) / 4399))
    (hq : RB q ((103973 : ℝ) / 6250000) ((1698027 : ℝ) / 100000000))
    (hd : RB d ((38675411 : ℝ) / 20000000) ((19350817 : ℝ) / 10000000))
    (hp : RB vp ((10156453 : ℝ) / 25000000) ((41360009 : ℝ) / 100000000))
    (hm : RB vm ((65118749 : ℝ) / 50000000) ((130574971 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((13837 : ℝ) / 50000000) ((28833 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99971167 : ℝ) / 100000000) ((49986163 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((63472851 : ℝ) / 100000000) ((63610489 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((6691 : ℝ) / 10000000) ((70973 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99929027 : ℝ) / 100000000) ((9993309 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((58639991 : ℝ) / 100000000) ((14843547 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((14649593 : ℝ) / 25000000) ((59334461 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53487341 : ℝ) / 50000000) ((108553339 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3487341 : ℝ) / 50000000) ((8553339 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99971167 : ℝ) / 100000000) ((49986163 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((63472851 : ℝ) / 100000000) ((63610489 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((21193 : ℝ) / 100000000) ((22139 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99977861 : ℝ) / 100000000) ((99978807 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((15118749 : ℝ) / 50000000) ((30574971 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((30230803 : ℝ) / 100000000) ((7642123 : ℝ) / 25000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((10382071 : ℝ) / 5000000) ((210416141 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((15382071 : ℝ) / 5000000) ((310416141 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((233826813 : ℝ) / 20000000) ((358439281 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((32214819 : ℝ) / 100000000) ((1015793 : ℝ) / 3125000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1113 : ℝ) / 320) ((2799 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((5786097 : ℝ) / 100000000) ((1485243 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((6353973 : ℝ) / 6250000) ((101698027 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5689487 : ℝ) / 100000000) ((2921879 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((105689487 : ℝ) / 100000000) ((52921879 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((88877489 : ℝ) / 100000000) ((89949159 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((17186867 : ℝ) / 10000000) ((43514743 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52910041 : ℝ) / 100000000) ((2700291 : ℝ) / 5000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((25621 : ℝ) / 50000000) ((10899 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19989101 : ℝ) / 20000000) ((49974379 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((17177501 : ℝ) / 10000000) ((173969781 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((38675411 : ℝ) / 10000000) ((19350817 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((6433917 : ℝ) / 100000000) ((3285821 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1753 : ℝ) / 640) ((4399 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1170069 : ℝ) / 50000000) ((2399231 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((804433 : ℝ) / 20000000) ((1044919 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((20804433 : ℝ) / 20000000) ((26044919 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((608079283 : ℝ) / 50000000) ((1493683527 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((79627 : ℝ) / 6250000) ((1303793 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((6329627 : ℝ) / 6250000) ((101303793 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16312623 : ℝ) / 50000000) ((32929179 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((312195953 : ℝ) / 25000000) ((763306353 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((913227 : ℝ) / 3125000) ((18313483 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1753 : ℝ) / 640) ((4399 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((105689487 : ℝ) / 50000000) ((52921879 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((300337221 : ℝ) / 25000000) ((117301 : ℝ) / 8000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((507879789 : ℝ) / 20000000) ((620778933 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((4412299 : ℝ) / 50000000) ((5413437 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-242762717 : ℝ) / 100000000) ((-5557847 : ℝ) / 2500000) := rb_log h47 (by norm_num) cov_log_1004.1 cov_log_1005.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1608479 : ℝ) / 50000000) ((3285821 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-68734681 : ℝ) / 20000000) ((-341555363 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1006.1 cov_log_1007.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((32973587 : ℝ) / 50000000) ((16503739 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_993.1 cov_log_994.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((114686257 : ℝ) / 100000000) ((57742457 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-57246787 : ℝ) / 25000000) ((-226070449 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4736633 : ℝ) / 50000000) ((5834019 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((3233023 : ℝ) / 12500000) ((4990903 : ℝ) / 12500000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-50780741 : ℝ) / 25000000) ((-7445729 : ℝ) / 4000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((105689487 : ℝ) / 100000000) ((52921879 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-242762717 : ℝ) / 100000000) ((-5557847 : ℝ) / 2500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-50780741 : ℝ) / 25000000) ((-7445729 : ℝ) / 4000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((149 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((804433 : ℝ) / 20000000) ((1044919 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((41 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((26044919 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((149 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((41 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-106168363 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((149 : ℝ) / 50) + hfun ((41 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_16, cov_h_13]
  have hP : ((276241581 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((7445729 : ℝ) / 4000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((7445729 : ℝ) / 4000000))
    linarith [hap.2]
  have hS : ((60829403 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((41 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((277 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((649 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((659 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((659 : ℝ) / 250)) (lo := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((669 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((669 : ℝ) / 250)) (lo := ((659 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((679 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((679 : ℝ) / 250)) (lo := ((669 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((689 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((689 : ℝ) / 250)) (lo := ((679 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((699 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((699 : ℝ) / 250)) (lo := ((689 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((709 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((709 : ℝ) / 250)) (lo := ((699 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((719 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((719 : ℝ) / 250)) (lo := ((709 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((729 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((729 : ℝ) / 250)) (lo := ((719 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((739 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((739 : ℝ) / 250)) (lo := ((729 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((149 : ℝ) / 50)) (lo := ((739 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_55 {k : ℝ} (hk : RB k ((1113 : ℝ) / 640) ((2799 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((1113 : ℝ) / 1753) ((2799 : ℝ) / 4399) ∧
    RB (qa (r1A k)) ((103973 : ℝ) / 6250000) ((1698027 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((38675411 : ℝ) / 20000000) ((19350817 : ℝ) / 10000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((21738281 : ℝ) / 50000000) ((2799 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((59797 : ℝ) / 32000) ((93561719 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((68349401 : ℝ) / 50000000) ((13679307 : ℝ) / 10000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((139060079 : ℝ) / 50000000) ((278214427 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139060079 : ℝ) / 100000000) ((69553607 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((38675411 : ℝ) / 20000000) ((19350817 : ℝ) / 10000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((6438281 : ℝ) / 50000000) ((4203 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((160957 : ℝ) / 5000000) ((1641797 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((103973 : ℝ) / 6250000) ((1698027 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((38675411 : ℝ) / 20000000) ((19350817 : ℝ) / 10000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((103973 : ℝ) / 6250000) ((1698027 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1113 : ℝ) / 1753) ((2799 : ℝ) / 4399) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_55 {k : ℝ} (hk : RB k ((1113 : ℝ) / 640) ((2799 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_55 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_55 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((10156453 : ℝ) / 25000000)) (ph := ((41360009 : ℝ) / 100000000)) (ml := ((65118749 : ℝ) / 50000000)) (mh := ((130574971 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_55 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_56 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2799 : ℝ) / 4399) ((5631 : ℝ) / 8831))
    (hq : RB (qa a) ((849013 : ℝ) / 50000000) ((433133 : ℝ) / 25000000))
    (hd : RB (D0a a) ((193245897 : ℝ) / 100000000) ((193377059 : ℝ) / 100000000))
    : certE k a ((40548269 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((20634947 : ℝ) / 50000000) ∧ 0 < certE k a ((130350543 : ℝ) / 100000000) ∧ certE k a ((130686353 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((901 : ℝ) / 3125000) ((30017 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40548269 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((10129563 : ℝ) / 25000000) ((40519437 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((40548269 : ℝ) / 100000000) ((40548269 : ℝ) / 100000000) ((40548269 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59451731 : ℝ) / 100000000))
  have h3 : RB z3 ((68153191 : ℝ) / 100000000) ((13631037 : ℝ) / 20000000) := rb_div_signed h2 (show RB ((59451731 : ℝ) / 100000000) ((59451731 : ℝ) / 100000000) ((59451731 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-38341221 : ℝ) / 100000000) ((-19169147 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_1008.1 cov_log_1009.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-12223951 : ℝ) / 50000000) ((-24393927 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40548269 : ℝ) / 100000000))
  have h6 : RB z6 ((-90267711 : ℝ) / 100000000) ((-90267709 : ℝ) / 100000000) := rb_log (show RB ((40548269 : ℝ) / 100000000) ((40548269 : ℝ) / 100000000) ((40548269 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1010.1 cov_log_1010.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((65819807 : ℝ) / 100000000) ((8234223 : ℝ) / 12500000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((32939663 : ℝ) / 50000000) ((32973589 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1011.1 cov_log_1012.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-127371 : ℝ) / 100000000) ((-2771 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((901 : ℝ) / 3125000) ((30017 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((20634947 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((41239877 : ℝ) / 100000000) ((20620531 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((20634947 : ℝ) / 50000000) ((20634947 : ℝ) / 50000000) ((20634947 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((29365053 : ℝ) / 50000000))
  have h12 : RB z12 ((70219313 : ℝ) / 100000000) ((70221331 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((29365053 : ℝ) / 50000000) ((29365053 : ℝ) / 50000000) ((29365053 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-883867 : ℝ) / 2500000) ((-17675903 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_1013.1 cov_log_1014.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-22543563 : ℝ) / 100000000) ((-22493681 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((20634947 : ℝ) / 50000000))
  have h15 : RB z15 ((-88503693 : ℝ) / 100000000) ((-88503691 : ℝ) / 100000000) := rb_log (show RB ((20634947 : ℝ) / 50000000) ((20634947 : ℝ) / 50000000) ((20634947 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1015.1 cov_log_1015.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((1030627 : ℝ) / 1562500) ((16502503 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((32939663 : ℝ) / 50000000) ((32973589 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1011.1 cov_log_1012.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((259 : ℝ) / 2000000) ((65343 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((901 : ℝ) / 3125000) ((30017 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((130350543 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((65160263 : ℝ) / 50000000) ((130321711 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((130350543 : ℝ) / 100000000) ((130350543 : ℝ) / 100000000) ((130350543 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((30350543 : ℝ) / 100000000))
  have h21 : RB z21 ((85876899 : ℝ) / 20000000) ((429388401 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((30350543 : ℝ) / 100000000) ((30350543 : ℝ) / 100000000) ((30350543 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((72859129 : ℝ) / 50000000) ((145719171 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1016.1 cov_log_1017.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46358877 : ℝ) / 50000000) ((11614549 : ℝ) / 12500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((130350543 : ℝ) / 100000000))
  have h24 : RB z24 ((1656607 : ℝ) / 6250000) ((26505713 : ℝ) / 100000000) := rb_log (show RB ((130350543 : ℝ) / 100000000) ((130350543 : ℝ) / 100000000) ((130350543 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1018.1 cov_log_1018.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((66212041 : ℝ) / 100000000) ((1660267 : ℝ) / 2500000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((32939663 : ℝ) / 50000000) ((32973589 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1011.1 cov_log_1012.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((264863 : ℝ) / 100000000) ((265677 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((901 : ℝ) / 3125000) ((30017 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((130686353 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((8166021 : ℝ) / 6250000) ((130657521 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((130686353 : ℝ) / 100000000) ((130686353 : ℝ) / 100000000) ((130686353 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((30686353 : ℝ) / 100000000))
  have h30 : RB z30 ((425779941 : ℝ) / 100000000) ((106445951 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((30686353 : ℝ) / 100000000) ((30686353 : ℝ) / 100000000) ((30686353 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((28975049 : ℝ) / 20000000) ((28975231 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_1019.1 cov_log_1020.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92181361 : ℝ) / 100000000) ((92378851 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((130686353 : ℝ) / 100000000))
  have h33 : RB z33 ((26763001 : ℝ) / 100000000) ((13381501 : ℝ) / 50000000) := rb_log (show RB ((130686353 : ℝ) / 100000000) ((130686353 : ℝ) / 100000000) ((130686353 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1021.1 cov_log_1021.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((65418359 : ℝ) / 100000000) ((1312317 : ℝ) / 2000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((32939663 : ℝ) / 50000000) ((32973589 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1011.1 cov_log_1012.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-528819 : ℝ) / 100000000) ((-65869 : ℝ) / 25000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40548269 : ℝ) / 100000000)) ((-127371 : ℝ) / 100000000) ((-2771 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((20634947 : ℝ) / 50000000)) ((259 : ℝ) / 2000000) ((65343 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((130350543 : ℝ) / 100000000)) ((264863 : ℝ) / 100000000) ((265677 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((130686353 : ℝ) / 100000000)) ((-528819 : ℝ) / 100000000) ((-65869 : ℝ) / 25000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_56 {k A q d vp vm : ℝ}
    (hk : RB k ((2799 : ℝ) / 1600) ((5631 : ℝ) / 3200))
    (hA : RB A ((2799 : ℝ) / 4399) ((5631 : ℝ) / 8831))
    (hq : RB q ((849013 : ℝ) / 50000000) ((433133 : ℝ) / 25000000))
    (hd : RB d ((193245897 : ℝ) / 100000000) ((193377059 : ℝ) / 100000000))
    (hp : RB vp ((40548269 : ℝ) / 100000000) ((20634947 : ℝ) / 50000000))
    (hm : RB vm ((130350543 : ℝ) / 100000000) ((130686353 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((901 : ℝ) / 3125000) ((30017 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99969983 : ℝ) / 100000000) ((3124099 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((31804499 : ℝ) / 50000000) ((63745629 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((34931 : ℝ) / 50000000) ((18507 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24981493 : ℝ) / 25000000) ((49965069 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((29365053 : ℝ) / 50000000) ((59451731 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58686629 : ℝ) / 100000000) ((59410197 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((4282699 : ℝ) / 4000000) ((108620363 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((282699 : ℝ) / 4000000) ((8620363 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99969983 : ℝ) / 100000000) ((3124099 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((31804499 : ℝ) / 50000000) ((63745629 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((22061 : ℝ) / 100000000) ((5757 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24994243 : ℝ) / 25000000) ((99977939 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((30350543 : ℝ) / 100000000) ((30686353 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((30343553 : ℝ) / 100000000) ((958737 : ℝ) / 3125000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((207333313 : ℝ) / 100000000) ((210079647 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((307333313 : ℝ) / 100000000) ((310079647 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((290010989 : ℝ) / 25000000) ((1414932491 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16124889 : ℝ) / 50000000) ((8134491 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2799 : ℝ) / 800) ((5631 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((742621 : ℝ) / 12500000) ((609743 : ℝ) / 10000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((50849013 : ℝ) / 50000000) ((25433133 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5839791 : ℝ) / 100000000) ((5995623 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((105839791 : ℝ) / 100000000) ((105995623 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((89080649 : ℝ) / 100000000) ((22534521 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((172144699 : ℝ) / 100000000) ((21788297 : ℝ) / 12500000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((6606861 : ℝ) / 12500000) ((1348353 : ℝ) / 2500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((53457 : ℝ) / 100000000) ((7099 : ℝ) / 12500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((12492901 : ℝ) / 12500000) ((99946543 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((86023467 : ℝ) / 50000000) ((87106599 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((193245897 : ℝ) / 50000000) ((193377059 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((6562731 : ℝ) / 100000000) ((6700639 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4399 : ℝ) / 1600) ((8831 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((237807 : ℝ) / 10000000) ((48743 : ℝ) / 2000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2057221 : ℝ) / 50000000) ((854553 : ℝ) / 20000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((52057221 : ℝ) / 50000000) ((20854553 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1207773291 : ℝ) / 100000000) ((92211827 : ℝ) / 6250000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1299313 : ℝ) / 100000000) ((1329133 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101299313 : ℝ) / 100000000) ((101329133 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32668803 : ℝ) / 100000000) ((32970437 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((620221047 : ℝ) / 50000000) ((1508359669 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((29498581 : ℝ) / 100000000) ((9190247 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4399 : ℝ) / 1600) ((8831 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((105839791 : ℝ) / 50000000) ((105995623 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((596146867 : ℝ) / 50000000) ((289494091 : ℝ) / 20000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((315480299 : ℝ) / 12500000) ((1534255327 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1791993 : ℝ) / 20000000) ((10934469 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-24124039 : ℝ) / 10000000) ((-221325009 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1022.1 cov_log_1023.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((656273 : ℝ) / 20000000) ((41879 : ℝ) / 1250000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-170845537 : ℝ) / 50000000) ((-339611431 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1024.1 cov_log_1025.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((32939663 : ℝ) / 50000000) ((32973589 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1011.1 cov_log_1012.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((23049529 : ℝ) / 20000000) ((4641857 : ℝ) / 4000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-226443429 : ℝ) / 100000000) ((-111782503 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((9229849 : ℝ) / 100000000) ((5698057 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1569233 : ℝ) / 6250000) ((19316377 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-201335701 : ℝ) / 100000000) ((-46233063 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((105839791 : ℝ) / 100000000) ((105995623 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-24124039 : ℝ) / 10000000) ((-221325009 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-201335701 : ℝ) / 100000000) ((-46233063 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((297 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2057221 : ℝ) / 50000000) ((854553 : ℝ) / 20000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((41 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((20854553 : ℝ) / 40000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((297 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((41 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-105282197 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((297 : ℝ) / 100) + hfun ((41 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_18, cov_h_13]
  have hP : ((548102509 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((46233063 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((46233063 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((60829403 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((41 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((277 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2597 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2597 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2637 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2637 : ℝ) / 1000)) (lo := ((2597 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2677 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2677 : ℝ) / 1000)) (lo := ((2637 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2717 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2717 : ℝ) / 1000)) (lo := ((2677 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2757 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2757 : ℝ) / 1000)) (lo := ((2717 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2797 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2797 : ℝ) / 1000)) (lo := ((2757 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2837 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2837 : ℝ) / 1000)) (lo := ((2797 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2877 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2877 : ℝ) / 1000)) (lo := ((2837 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2917 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2917 : ℝ) / 1000)) (lo := ((2877 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2957 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2957 : ℝ) / 1000)) (lo := ((2917 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((297 : ℝ) / 100)) (lo := ((2957 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_56 {k : ℝ} (hk : RB k ((2799 : ℝ) / 1600) ((5631 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((2799 : ℝ) / 4399) ((5631 : ℝ) / 8831) ∧
    RB (qa (r1A k)) ((849013 : ℝ) / 50000000) ((433133 : ℝ) / 25000000) ∧ RB (D0a (r1A k)) ((193245897 : ℝ) / 100000000) ((193377059 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2799 : ℝ) / 6400) ((10998047 : ℝ) / 25000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((46651953 : ℝ) / 25000000) ((59797 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((136604469 : ℝ) / 100000000) ((136698803 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((11121033 : ℝ) / 4000000) ((1738251 : ℝ) / 625000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((8688307 : ℝ) / 6250000) ((1738251 : ℝ) / 1250000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((193245897 : ℝ) / 100000000) ((193377059 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((4203 : ℝ) / 32000) ((3348047 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((3283593 : ℝ) / 100000000) ((3348047 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((849013 : ℝ) / 50000000) ((433133 : ℝ) / 25000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((193245897 : ℝ) / 100000000) ((193377059 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((849013 : ℝ) / 50000000) ((433133 : ℝ) / 25000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2799 : ℝ) / 4399) ((5631 : ℝ) / 8831) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_56 {k : ℝ} (hk : RB k ((2799 : ℝ) / 1600) ((5631 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_56 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_56 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40548269 : ℝ) / 100000000)) (ph := ((20634947 : ℝ) / 50000000)) (ml := ((130350543 : ℝ) / 100000000)) (mh := ((130686353 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_56 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_57 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5631 : ℝ) / 8831) ((177 : ℝ) / 277))
    (hq : RB (qa a) ((1732531 : ℝ) / 100000000) ((353417 : ℝ) / 20000000))
    (hd : RB (D0a a) ((24139337 : ℝ) / 12500000) ((193245903 : ℝ) / 100000000))
    : certE k a ((40471791 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((41181529 : ℝ) / 100000000) ∧ 0 < certE k a ((130463027 : ℝ) / 100000000) ∧ certE k a ((26159439 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((469 : ℝ) / 1562500) ((15613 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40471791 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((8088113 : ℝ) / 20000000) ((1617671 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((40471791 : ℝ) / 100000000) ((40471791 : ℝ) / 100000000) ((40471791 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59528209 : ℝ) / 100000000))
  have h3 : RB z3 ((8491891 : ℝ) / 12500000) ((67937161 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((59528209 : ℝ) / 100000000) ((59528209 : ℝ) / 100000000) ((59528209 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-19330847 : ℝ) / 50000000) ((-38658701 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1026.1 cov_log_1027.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-6176101 : ℝ) / 25000000) ((-24650339 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40471791 : ℝ) / 100000000))
  have h6 : RB z6 ((-90456499 : ℝ) / 100000000) ((-90456497 : ℝ) / 100000000) := rb_log (show RB ((40471791 : ℝ) / 100000000) ((40471791 : ℝ) / 100000000) ((40471791 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1028.1 cov_log_1028.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((65752093 : ℝ) / 100000000) ((822577 : ℝ) / 1250000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((6581141 : ℝ) / 10000000) ((16469833 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1029.1 cov_log_1030.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-127239 : ℝ) / 100000000) ((-21 : ℝ) / 400000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((469 : ℝ) / 1562500) ((15613 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((41181529 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((41150303 : ℝ) / 100000000) ((41151513 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((41181529 : ℝ) / 100000000) ((41181529 : ℝ) / 100000000) ((41181529 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((58818471 : ℝ) / 100000000))
  have h12 : RB z12 ((69961531 : ℝ) / 100000000) ((69963589 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((58818471 : ℝ) / 100000000) ((58818471 : ℝ) / 100000000) ((58818471 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-17861233 : ℝ) / 50000000) ((-35719523 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_1031.1 cov_log_1032.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-22826269 : ℝ) / 100000000) ((-22776201 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((41181529 : ℝ) / 100000000))
  have h15 : RB z15 ((-88718037 : ℝ) / 100000000) ((-17743607 : ℝ) / 20000000) := rb_log (show RB ((41181529 : ℝ) / 100000000) ((41181529 : ℝ) / 100000000) ((41181529 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1033.1 cov_log_1033.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((32945883 : ℝ) / 50000000) ((16485459 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((6581141 : ℝ) / 10000000) ((16469833 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1029.1 cov_log_1030.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((6217 : ℝ) / 50000000) ((65213 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((469 : ℝ) / 1562500) ((15613 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((130463027 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((130431801 : ℝ) / 100000000) ((130433011 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((130463027 : ℝ) / 100000000) ((130463027 : ℝ) / 100000000) ((130463027 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((30463027 : ℝ) / 100000000))
  have h21 : RB z21 ((214082141 : ℝ) / 50000000) ((85633651 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((30463027 : ℝ) / 100000000) ((30463027 : ℝ) / 100000000) ((30463027 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((145433677 : ℝ) / 100000000) ((9089663 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_1034.1 cov_log_1035.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23183587 : ℝ) / 25000000) ((4646557 : ℝ) / 5000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((130463027 : ℝ) / 100000000))
  have h24 : RB z24 ((830999 : ℝ) / 3125000) ((26591969 : ℝ) / 100000000) := rb_log (show RB ((130463027 : ℝ) / 100000000) ((130463027 : ℝ) / 100000000) ((130463027 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1036.1 cov_log_1036.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((66142379 : ℝ) / 100000000) ((16584793 : ℝ) / 25000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((6581141 : ℝ) / 10000000) ((16469833 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1029.1 cov_log_1030.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((263047 : ℝ) / 100000000) ((263881 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((469 : ℝ) / 1562500) ((15613 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((26159439 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((130765969 : ℝ) / 100000000) ((130767179 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((26159439 : ℝ) / 20000000) ((26159439 : ℝ) / 20000000) ((26159439 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((6159439 : ℝ) / 20000000))
  have h30 : RB z30 ((424603503 : ℝ) / 100000000) ((424607433 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((6159439 : ℝ) / 20000000) ((6159439 : ℝ) / 20000000) ((6159439 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((144598561 : ℝ) / 100000000) ((144599489 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1037.1 cov_log_1038.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18440369 : ℝ) / 20000000) ((23099377 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((26159439 : ℝ) / 20000000))
  have h33 : RB z33 ((1342389 : ℝ) / 5000000) ((26847781 : ℝ) / 100000000) := rb_log (show RB ((26159439 : ℝ) / 20000000) ((26159439 : ℝ) / 20000000) ((26159439 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1039.1 cov_log_1039.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((4084629 : ℝ) / 6250000) ((2048429 : ℝ) / 3125000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((6581141 : ℝ) / 10000000) ((16469833 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1029.1 cov_log_1030.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-131317 : ℝ) / 25000000) ((-130841 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40471791 : ℝ) / 100000000)) ((-127239 : ℝ) / 100000000) ((-21 : ℝ) / 400000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((41181529 : ℝ) / 100000000)) ((6217 : ℝ) / 50000000) ((65213 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((130463027 : ℝ) / 100000000)) ((263047 : ℝ) / 100000000) ((263881 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((26159439 : ℝ) / 20000000)) ((-131317 : ℝ) / 25000000) ((-130841 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_57 {k A q d vp vm : ℝ}
    (hk : RB k ((5631 : ℝ) / 3200) ((177 : ℝ) / 100))
    (hA : RB A ((5631 : ℝ) / 8831) ((177 : ℝ) / 277))
    (hq : RB q ((1732531 : ℝ) / 100000000) ((353417 : ℝ) / 20000000))
    (hd : RB d ((24139337 : ℝ) / 12500000) ((193245903 : ℝ) / 100000000))
    (hp : RB vp ((40471791 : ℝ) / 100000000) ((41181529 : ℝ) / 100000000))
    (hm : RB vm ((130463027 : ℝ) / 100000000) ((26159439 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((469 : ℝ) / 1562500) ((15613 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49984387 : ℝ) / 50000000) ((1562031 : ℝ) / 1562500) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((31872051 : ℝ) / 50000000) ((31939869 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((72887 : ℝ) / 100000000) ((15431 : ℝ) / 20000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((19984569 : ℝ) / 20000000) ((99927113 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((58818471 : ℝ) / 100000000) ((59528209 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58773089 : ℝ) / 100000000) ((59484821 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53580141 : ℝ) / 50000000) ((54344377 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3580141 : ℝ) / 50000000) ((4344377 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49984387 : ℝ) / 50000000) ((1562031 : ℝ) / 1562500) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((31872051 : ℝ) / 50000000) ((31939869 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((5737 : ℝ) / 25000000) ((4787 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19995213 : ℝ) / 20000000) ((24994263 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((30463027 : ℝ) / 100000000) ((6159439 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((6091147 : ℝ) / 20000000) ((1924383 : ℝ) / 6250000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((103513863 : ℝ) / 50000000) ((209746171 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((153513863 : ℝ) / 50000000) ((309746171 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1150913007 : ℝ) / 100000000) ((17457413 : ℝ) / 1250000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((32284499 : ℝ) / 100000000) ((32570349 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5631 : ℝ) / 1600) ((177 : ℝ) / 50) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((3048713 : ℝ) / 50000000) ((6255481 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101732531 : ℝ) / 100000000) ((20353417 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((119831 : ℝ) / 2000000) ((6148949 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((2119831 : ℝ) / 2000000) ((106148949 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((44640749 : ℝ) / 50000000) ((22581351 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((172415693 : ℝ) / 100000000) ((174550143 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52800723 : ℝ) / 100000000) ((10772857 : ℝ) / 20000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((2229 : ℝ) / 4000000) ((2957 : ℝ) / 5000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((4997043 : ℝ) / 5000000) ((3997771 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((86156863 : ℝ) / 50000000) ((1395623 : ℝ) / 800000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((24139337 : ℝ) / 6250000) ((193245903 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((6691543 : ℝ) / 100000000) ((6829639 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8831 : ℝ) / 3200) ((277 : ℝ) / 100) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2415719 : ℝ) / 100000000) ((618697 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((2103529 : ℝ) / 50000000) ((2183107 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((52103529 : ℝ) / 50000000) ((52183107 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((149916573 : ℝ) / 12500000) ((1457571281 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1324593 : ℝ) / 100000000) ((169309 : ℝ) / 12500000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101324593 : ℝ) / 100000000) ((12669309 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32712137 : ℝ) / 100000000) ((16505753 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1232044721 : ℝ) / 100000000) ((1490582787 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((14881369 : ℝ) / 50000000) ((9222191 : ℝ) / 25000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8831 : ℝ) / 3200) ((277 : ℝ) / 100) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((2119831 : ℝ) / 1000000) ((106148949 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((591598753 : ℝ) / 50000000) ((1429163389 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((39190293 : ℝ) / 1562500) ((1517041917 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((454781 : ℝ) / 5000000) ((1104387 : ℝ) / 10000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-59934431 : ℝ) / 25000000) ((-110164733 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1040.1 cov_log_1041.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((3345771 : ℝ) / 100000000) ((170741 : ℝ) / 5000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-84936827 : ℝ) / 25000000) ((-16885227 : ℝ) / 5000000) := rb_log h49 (by norm_num) cov_log_1042.1 cov_log_1043.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((6581141 : ℝ) / 10000000) ((16469833 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1029.1 cov_log_1030.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((23161503 : ℝ) / 20000000) ((58303209 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-223939793 : ℝ) / 100000000) ((-110549061 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2247543 : ℝ) / 25000000) ((5564661 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2437103 : ℝ) / 10000000) ((9348369 : ℝ) / 25000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-199568763 : ℝ) / 100000000) ((-91852323 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((2119831 : ℝ) / 2000000) ((106148949 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-59934431 : ℝ) / 25000000) ((-110164733 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-199568763 : ℝ) / 100000000) ((-91852323 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((297 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((2103529 : ℝ) / 50000000) ((2183107 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((41 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((52183107 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((297 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((41 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-6533179 : ℝ) / 3125000) ≤ formC0 k A q vp vm + hfun ((297 : ℝ) / 100) + hfun ((41 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_18, cov_h_13]
  have hP : ((271838841 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((91852323 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((91852323 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((60829403 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((41 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((277 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((519 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((519 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((527 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((527 : ℝ) / 200)) (lo := ((519 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((107 : ℝ) / 40) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((107 : ℝ) / 40)) (lo := ((527 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((543 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((543 : ℝ) / 200)) (lo := ((107 : ℝ) / 40)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((551 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((551 : ℝ) / 200)) (lo := ((543 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((559 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((559 : ℝ) / 200)) (lo := ((551 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((567 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((567 : ℝ) / 200)) (lo := ((559 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((23 : ℝ) / 8) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((23 : ℝ) / 8)) (lo := ((567 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((583 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((583 : ℝ) / 200)) (lo := ((23 : ℝ) / 8)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((591 : ℝ) / 200) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((591 : ℝ) / 200)) (lo := ((583 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((297 : ℝ) / 100)) (lo := ((591 : ℝ) / 200)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_57 {k : ℝ} (hk : RB k ((5631 : ℝ) / 3200) ((177 : ℝ) / 100)) :
    RB (k / (k + 1)) ((5631 : ℝ) / 8831) ((177 : ℝ) / 277) ∧
    RB (qa (r1A k)) ((1732531 : ℝ) / 100000000) ((353417 : ℝ) / 20000000) ∧ RB (D0a (r1A k)) ((24139337 : ℝ) / 12500000) ((193245903 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((43992187 : ℝ) / 100000000) ((177 : ℝ) / 400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((3727 : ℝ) / 2000) ((186607813 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((17063759 : ℝ) / 12500000) ((136604471 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69482857 : ℝ) / 25000000) ((69506457 : ℝ) / 25000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69482857 : ℝ) / 50000000) ((69506457 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((24139337 : ℝ) / 12500000) ((193245903 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((13392187 : ℝ) / 100000000) ((273 : ℝ) / 2000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1674023 : ℝ) / 50000000) ((273 : ℝ) / 8000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1732531 : ℝ) / 100000000) ((353417 : ℝ) / 20000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((24139337 : ℝ) / 12500000) ((193245903 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1732531 : ℝ) / 100000000) ((353417 : ℝ) / 20000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5631 : ℝ) / 8831) ((177 : ℝ) / 277) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_57 {k : ℝ} (hk : RB k ((5631 : ℝ) / 3200) ((177 : ℝ) / 100)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_57 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_57 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40471791 : ℝ) / 100000000)) (ph := ((41181529 : ℝ) / 100000000)) (ml := ((130463027 : ℝ) / 100000000)) (mh := ((26159439 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_57 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_58 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((177 : ℝ) / 277) ((5697 : ℝ) / 8897))
    (hq : RB (qa a) ((441771 : ℝ) / 25000000) ((900843 : ℝ) / 50000000))
    (hd : RB (D0a a) ((192983449 : ℝ) / 100000000) ((1931147 : ℝ) / 1000000))
    : certE k a ((40396323 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((20547409 : ℝ) / 50000000) ∧ 0 < certE k a ((32643739 : ℝ) / 25000000) ∧ certE k a ((130907503 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1249 : ℝ) / 4000000) ((32461 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40396323 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((20181931 : ℝ) / 50000000) ((20182549 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((40396323 : ℝ) / 100000000) ((40396323 : ℝ) / 100000000) ((40396323 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59603677 : ℝ) / 100000000))
  have h3 : RB z3 ((33860211 : ℝ) / 50000000) ((67722497 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((59603677 : ℝ) / 100000000) ((59603677 : ℝ) / 100000000) ((59603677 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-121807 : ℝ) / 312500) ((-1559007 : ℝ) / 4000000) := rb_log h3 (by norm_num) cov_log_1044.1 cov_log_1045.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-24958867 : ℝ) / 100000000) ((-12452357 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40396323 : ℝ) / 100000000))
  have h6 : RB z6 ((-90643143 : ℝ) / 100000000) ((-90643141 : ℝ) / 100000000) := rb_log (show RB ((40396323 : ℝ) / 100000000) ((40396323 : ℝ) / 100000000) ((40396323 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1046.1 cov_log_1046.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((32842137 : ℝ) / 50000000) ((65738429 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((1027241 : ℝ) / 1562500) ((32905707 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1047.1 cov_log_1048.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-6357 : ℝ) / 5000000) ((-999 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1249 : ℝ) / 4000000) ((32461 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((20547409 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((41062357 : ℝ) / 100000000) ((41063593 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((20547409 : ℝ) / 50000000) ((20547409 : ℝ) / 50000000) ((20547409 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((29452591 : ℝ) / 50000000))
  have h12 : RB z12 ((69709243 : ℝ) / 100000000) ((69711343 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((29452591 : ℝ) / 50000000) ((29452591 : ℝ) / 50000000) ((29452591 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-36083727 : ℝ) / 100000000) ((-18040357 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_1049.1 cov_log_1050.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-5776357 : ℝ) / 25000000) ((-4611037 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((20547409 : ℝ) / 50000000))
  have h15 : RB z15 ((-88928817 : ℝ) / 100000000) ((-17785763 : ℝ) / 20000000) := rb_log (show RB ((20547409 : ℝ) / 50000000) ((20547409 : ℝ) / 50000000) ((20547409 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1051.1 cov_log_1051.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((65823387 : ℝ) / 100000000) ((2058551 : ℝ) / 3125000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((1027241 : ℝ) / 1562500) ((32905707 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1047.1 cov_log_1048.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((11973 : ℝ) / 100000000) ((4069 : ℝ) / 3125000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1249 : ℝ) / 4000000) ((32461 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((32643739 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((26108499 : ℝ) / 20000000) ((130543731 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((32643739 : ℝ) / 25000000) ((32643739 : ℝ) / 25000000) ((32643739 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((7643739 : ℝ) / 25000000))
  have h21 : RB z21 ((426958897 : ℝ) / 100000000) ((21348147 : ℝ) / 5000000) := rb_div_signed h20 (show RB ((7643739 : ℝ) / 25000000) ((7643739 : ℝ) / 25000000) ((7643739 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((36287939 : ℝ) / 25000000) ((72576353 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_1052.1 cov_log_1053.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((57969 : ℝ) / 62500) ((23236343 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((32643739 : ℝ) / 25000000))
  have h24 : RB z24 ((1067109 : ℝ) / 4000000) ((13338863 : ℝ) / 50000000) := rb_log (show RB ((32643739 : ℝ) / 25000000) ((32643739 : ℝ) / 25000000) ((32643739 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1054.1 cov_log_1054.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33036337 : ℝ) / 50000000) ((66267647 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((1027241 : ℝ) / 1562500) ((32905707 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1047.1 cov_log_1048.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((13063 : ℝ) / 5000000) ((524223 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1249 : ℝ) / 4000000) ((32461 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((130907503 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((65437521 : ℝ) / 50000000) ((65438139 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((130907503 : ℝ) / 100000000) ((130907503 : ℝ) / 100000000) ((130907503 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((30907503 : ℝ) / 100000000))
  have h30 : RB z30 ((423441007 : ℝ) / 100000000) ((423445007 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((30907503 : ℝ) / 100000000) ((30907503 : ℝ) / 100000000) ((30907503 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((144324401 : ℝ) / 100000000) ((144325349 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1055.1 cov_log_1056.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92221729 : ℝ) / 100000000) ((11551949 : ℝ) / 12500000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((130907503 : ℝ) / 100000000))
  have h33 : RB z33 ((336651 : ℝ) / 1250000) ((26932081 : ℝ) / 100000000) := rb_log (show RB ((130907503 : ℝ) / 100000000) ((130907503 : ℝ) / 100000000) ((130907503 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1057.1 cov_log_1057.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((4080603 : ℝ) / 6250000) ((8185439 : ℝ) / 12500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((1027241 : ℝ) / 1562500) ((32905707 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1047.1 cov_log_1048.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-260883 : ℝ) / 50000000) ((-32489 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40396323 : ℝ) / 100000000)) ((-6357 : ℝ) / 5000000) ((-999 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((20547409 : ℝ) / 50000000)) ((11973 : ℝ) / 100000000) ((4069 : ℝ) / 3125000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((32643739 : ℝ) / 25000000)) ((13063 : ℝ) / 5000000) ((524223 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((130907503 : ℝ) / 100000000)) ((-260883 : ℝ) / 50000000) ((-32489 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_58 {k A q d vp vm : ℝ}
    (hk : RB k ((177 : ℝ) / 100) ((5697 : ℝ) / 3200))
    (hA : RB A ((177 : ℝ) / 277) ((5697 : ℝ) / 8897))
    (hq : RB q ((441771 : ℝ) / 25000000) ((900843 : ℝ) / 50000000))
    (hd : RB d ((192983449 : ℝ) / 100000000) ((1931147 : ℝ) / 1000000))
    (hp : RB vp ((40396323 : ℝ) / 100000000) ((20547409 : ℝ) / 50000000))
    (hm : RB vm ((32643739 : ℝ) / 25000000) ((130907503 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1249 : ℝ) / 4000000) ((32461 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99967539 : ℝ) / 100000000) ((3998751 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((31939087 : ℝ) / 50000000) ((32006413 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((37991 : ℝ) / 50000000) ((80357 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99919643 : ℝ) / 100000000) ((49962009 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((29452591 : ℝ) / 50000000) ((59603677 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58857847 : ℝ) / 100000000) ((59558389 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((4290121 : ℝ) / 4000000) ((21751671 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((290121 : ℝ) / 4000000) ((1751671 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99967539 : ℝ) / 100000000) ((3998751 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((31939087 : ℝ) / 50000000) ((32006413 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((5963 : ℝ) / 25000000) ((24861 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99975139 : ℝ) / 100000000) ((24994037 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((7643739 : ℝ) / 25000000) ((30907503 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((15283677 : ℝ) / 50000000) ((30900131 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((41344921 : ℝ) / 20000000) ((10470783 : ℝ) / 5000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((61344921 : ℝ) / 20000000) ((15470783 : ℝ) / 5000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((570883459 : ℝ) / 50000000) ((34468377 : ℝ) / 2500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((4039873 : ℝ) / 12500000) ((32602537 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((177 : ℝ) / 50) ((5697 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((6255477 : ℝ) / 100000000) ((6415129 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((25441771 : ℝ) / 25000000) ((50900843 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((6144767 : ℝ) / 100000000) ((6303737 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((106144767 : ℝ) / 100000000) ((106303737 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((44740069 : ℝ) / 50000000) ((4525559 : ℝ) / 5000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((1349077 : ℝ) / 781250) ((87395197 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((1318687 : ℝ) / 2500000) ((53796201 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((58043 : ℝ) / 100000000) ((61541 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99938459 : ℝ) / 100000000) ((99941957 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((34515117 : ℝ) / 20000000) ((174688941 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((192983449 : ℝ) / 50000000) ((1931147 : ℝ) / 500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((6820359 : ℝ) / 100000000) ((3479321 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((277 : ℝ) / 100) ((8897 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((245309 : ℝ) / 10000000) ((1256073 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((268751 : ℝ) / 6250000) ((178401 : ℝ) / 4000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((6518751 : ℝ) / 6250000) ((4178401 : ℝ) / 4000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((595431539 : ℝ) / 50000000) ((144022701 : ℝ) / 10000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((84367 : ℝ) / 6250000) ((137981 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((6334367 : ℝ) / 6250000) ((10137981 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((2047203 : ℝ) / 6250000) ((33052391 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((611809163 : ℝ) / 50000000) ((1473279401 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((15008229 : ℝ) / 50000000) ((3701093 : ℝ) / 10000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((277 : ℝ) / 100) ((8897 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((106144767 : ℝ) / 50000000) ((106303737 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((587042951 : ℝ) / 50000000) ((1411337617 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((249246149 : ℝ) / 10000000) ((1500304629 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((4615729 : ℝ) / 50000000) ((11154887 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-119127661 : ℝ) / 50000000) ((-6854039 : ℝ) / 3125000) := rb_log h47 (by norm_num) cov_log_1058.1 cov_log_1059.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((3410179 : ℝ) / 100000000) ((3479321 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-168920273 : ℝ) / 50000000) ((-167916651 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_1060.1 cov_log_1061.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((1027241 : ℝ) / 1562500) ((32905707 : ℝ) / 50000000) := rb_log hd (by norm_num) cov_log_1047.1 cov_log_1048.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((5818293 : ℝ) / 5000000) ((117164883 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-110737343 : ℝ) / 50000000) ((-218668419 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4377053 : ℝ) / 50000000) ((10867463 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((11826379 : ℝ) / 50000000) ((7241003 : ℝ) / 20000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-24727741 : ℝ) / 12500000) ((-45615851 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((106144767 : ℝ) / 100000000) ((106303737 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-119127661 : ℝ) / 50000000) ((-6854039 : ℝ) / 3125000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-24727741 : ℝ) / 12500000) ((-45615851 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((74 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((268751 : ℝ) / 6250000) ((178401 : ℝ) / 4000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((33 : ℝ) / 20) := by
    have hu : (1 + q / vp) / 2 ≤ ((4178401 : ℝ) / 8000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((74 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((33 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-41486221 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((74 : ℝ) / 25) + hfun ((33 : ℝ) / 20) := by
    linarith [hc0.1, cov_h_19, cov_h_17]
  have hP : ((107843581 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((45615851 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((45615851 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((3020787 : ℝ) / 5000000) ≤ EP1038.Arc.sinc ((33 : ℝ) / 20) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((317 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1297 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1297 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1317 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1317 : ℝ) / 500)) (lo := ((1297 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1337 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1337 : ℝ) / 500)) (lo := ((1317 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1357 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1357 : ℝ) / 500)) (lo := ((1337 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1377 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1377 : ℝ) / 500)) (lo := ((1357 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1397 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1397 : ℝ) / 500)) (lo := ((1377 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1417 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1417 : ℝ) / 500)) (lo := ((1397 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1437 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1437 : ℝ) / 500)) (lo := ((1417 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1457 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1457 : ℝ) / 500)) (lo := ((1437 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1477 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1477 : ℝ) / 500)) (lo := ((1457 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((74 : ℝ) / 25)) (lo := ((1477 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_58 {k : ℝ} (hk : RB k ((177 : ℝ) / 100) ((5697 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((177 : ℝ) / 277) ((5697 : ℝ) / 8897) ∧
    RB (qa (r1A k)) ((441771 : ℝ) / 25000000) ((900843 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((192983449 : ℝ) / 100000000) ((1931147 : ℝ) / 1000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((177 : ℝ) / 400) ((44507813 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((186092187 : ℝ) / 100000000) ((3727 : ℝ) / 2000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((13641561 : ℝ) / 10000000) ((136510073 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((138918483 : ℝ) / 50000000) ((27793143 : ℝ) / 10000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((138918483 : ℝ) / 100000000) ((27793143 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((192983449 : ℝ) / 100000000) ((1931147 : ℝ) / 1000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((273 : ℝ) / 2000) ((13907813 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((273 : ℝ) / 8000) ((1738477 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((441771 : ℝ) / 25000000) ((900843 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((192983449 : ℝ) / 100000000) ((1931147 : ℝ) / 1000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((441771 : ℝ) / 25000000) ((900843 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((177 : ℝ) / 277) ((5697 : ℝ) / 8897) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_58 {k : ℝ} (hk : RB k ((177 : ℝ) / 100) ((5697 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_58 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_58 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40396323 : ℝ) / 100000000)) (ph := ((20547409 : ℝ) / 50000000)) (ml := ((32643739 : ℝ) / 25000000)) (mh := ((130907503 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_58 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_59 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5697 : ℝ) / 8897) ((573 : ℝ) / 893))
    (hq : RB (qa a) ((450421 : ℝ) / 25000000) ((1836333 : ℝ) / 100000000))
    (hd : RB (D0a a) ((96426077 : ℝ) / 50000000) ((48245863 : ℝ) / 25000000))
    : certE k a ((10080453 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((4100967 : ℝ) / 10000000) ∧ 0 < certE k a ((130686339 : ℝ) / 100000000) ∧ certE k a ((26203457 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1623 : ℝ) / 5000000) ((16861 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((10080453 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((4028809 : ℝ) / 10000000) ((5036169 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((10080453 : ℝ) / 25000000) ((10080453 : ℝ) / 25000000) ((10080453 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((14919547 : ℝ) / 25000000))
  have h3 : RB z3 ((33754451 : ℝ) / 50000000) ((33755509 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((14919547 : ℝ) / 25000000) ((14919547 : ℝ) / 25000000) ((14919547 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-613923 : ℝ) / 1562500) ((-39287937 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1062.1 cov_log_1063.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-5042281 : ℝ) / 20000000) ((-12578587 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((10080453 : ℝ) / 25000000))
  have h6 : RB z6 ((-22706941 : ℝ) / 25000000) ((-45413881 : ℝ) / 50000000) := rb_log (show RB ((10080453 : ℝ) / 25000000) ((10080453 : ℝ) / 25000000) ((10080453 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1064.1 cov_log_1064.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((65616357 : ℝ) / 100000000) ((6567059 : ℝ) / 10000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((32837683 : ℝ) / 50000000) ((65743427 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1065.1 cov_log_1066.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-12707 : ℝ) / 10000000) ((-597 : ℝ) / 12500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1623 : ℝ) / 5000000) ((16861 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((4100967 : ℝ) / 10000000)) - (z10)
  have h11 : RB z11 ((10243987 : ℝ) / 25000000) ((4097721 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((4100967 : ℝ) / 10000000) ((4100967 : ℝ) / 10000000) ((4100967 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((5899033 : ℝ) / 10000000))
  have h12 : RB z12 ((542673 : ℝ) / 781250) ((17366071 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((5899033 : ℝ) / 10000000) ((5899033 : ℝ) / 10000000) ((5899033 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-9109707 : ℝ) / 25000000) ((-18217873 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_1067.1 cov_log_1068.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-11690621 : ℝ) / 50000000) ((-4666167 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((4100967 : ℝ) / 10000000))
  have h15 : RB z15 ((-89136231 : ℝ) / 100000000) ((-89136229 : ℝ) / 100000000) := rb_log (show RB ((4100967 : ℝ) / 10000000) ((4100967 : ℝ) / 10000000) ((4100967 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1069.1 cov_log_1069.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((65754987 : ℝ) / 100000000) ((16451349 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((32837683 : ℝ) / 50000000) ((65743427 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1065.1 cov_log_1066.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((289 : ℝ) / 2500000) ((13003 : ℝ) / 10000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1623 : ℝ) / 5000000) ((16861 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((130686339 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((130652617 : ℝ) / 100000000) ((130653879 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((130686339 : ℝ) / 100000000) ((130686339 : ℝ) / 100000000) ((130686339 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((30686339 : ℝ) / 100000000))
  have h21 : RB z21 ((26610501 : ℝ) / 6250000) ((42577213 : ℝ) / 10000000) := rb_div_signed h20 (show RB ((30686339 : ℝ) / 100000000) ((30686339 : ℝ) / 100000000) ((30686339 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((36218111 : ℝ) / 25000000) ((144873413 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1070.1 cov_log_1071.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92765911 : ℝ) / 100000000) ((92959089 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((130686339 : ℝ) / 100000000))
  have h24 : RB z24 ((2676299 : ℝ) / 10000000) ((26762991 : ℝ) / 100000000) := rb_log (show RB ((130686339 : ℝ) / 100000000) ((130686339 : ℝ) / 100000000) ((130686339 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1072.1 cov_log_1072.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((1650073 : ℝ) / 2500000) ((66196099 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((32837683 : ℝ) / 50000000) ((65743427 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1065.1 cov_log_1066.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((259493 : ℝ) / 100000000) ((520733 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1623 : ℝ) / 5000000) ((16861 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((26203457 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((130983563 : ℝ) / 100000000) ((5239393 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((26203457 : ℝ) / 20000000) ((26203457 : ℝ) / 20000000) ((26203457 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((6203457 : ℝ) / 20000000))
  have h30 : RB z30 ((1319663 : ℝ) / 312500) ((42229623 : ℝ) / 10000000) := rb_div_signed h29 (show RB ((6203457 : ℝ) / 20000000) ((6203457 : ℝ) / 20000000) ((6203457 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((1800659 : ℝ) / 1250000) ((144053687 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1073.1 cov_log_1074.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46120509 : ℝ) / 50000000) ((18486621 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((26203457 : ℝ) / 20000000))
  have h33 : RB z33 ((27015907 : ℝ) / 100000000) ((6753977 : ℝ) / 25000000) := rb_log (show RB ((26203457 : ℝ) / 20000000) ((26203457 : ℝ) / 20000000) ((26203457 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1075.1 cov_log_1075.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6522511 : ℝ) / 10000000) ((32708599 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((32837683 : ℝ) / 50000000) ((65743427 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1065.1 cov_log_1066.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-518317 : ℝ) / 100000000) ((-32271 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((10080453 : ℝ) / 25000000)) ((-12707 : ℝ) / 10000000) ((-597 : ℝ) / 12500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((4100967 : ℝ) / 10000000)) ((289 : ℝ) / 2500000) ((13003 : ℝ) / 10000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((130686339 : ℝ) / 100000000)) ((259493 : ℝ) / 100000000) ((520733 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((26203457 : ℝ) / 20000000)) ((-518317 : ℝ) / 100000000) ((-32271 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_59 {k A q d vp vm : ℝ}
    (hk : RB k ((5697 : ℝ) / 3200) ((573 : ℝ) / 320))
    (hA : RB A ((5697 : ℝ) / 8897) ((573 : ℝ) / 893))
    (hq : RB q ((450421 : ℝ) / 25000000) ((1836333 : ℝ) / 100000000))
    (hd : RB d ((96426077 : ℝ) / 50000000) ((48245863 : ℝ) / 25000000))
    (hp : RB vp ((10080453 : ℝ) / 25000000) ((4100967 : ℝ) / 10000000))
    (hm : RB vm ((130686339 : ℝ) / 100000000) ((26203457 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1623 : ℝ) / 5000000) ((16861 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49983139 : ℝ) / 50000000) ((4998377 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((32005613 : ℝ) / 50000000) ((32072453 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((4947 : ℝ) / 6250000) ((83633 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99916367 : ℝ) / 100000000) ((6245053 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((5899033 : ℝ) / 10000000) ((14919547 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((29470497 : ℝ) / 50000000) ((7453869 : ℝ) / 12500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53672819 : ℝ) / 50000000) ((5441451 : ℝ) / 5000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3672819 : ℝ) / 50000000) ((441451 : ℝ) / 5000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49983139 : ℝ) / 50000000) ((4998377 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((32005613 : ℝ) / 50000000) ((32072453 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((991 : ℝ) / 4000000) ((6451 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24993549 : ℝ) / 25000000) ((3999009 : ℝ) / 4000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((30686339 : ℝ) / 100000000) ((6203457 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1533921 : ℝ) / 5000000) ((31009601 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((103211947 : ℝ) / 50000000) ((209088037 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((153211947 : ℝ) / 50000000) ((309088037 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((141578567 : ℝ) / 12500000) ((1361352139 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((32353241 : ℝ) / 100000000) ((32634531 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5697 : ℝ) / 1600) ((573 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((6415121 : ℝ) / 100000000) ((411023 : ℝ) / 6250000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((25450421 : ℝ) / 25000000) ((101836333 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3149721 : ℝ) / 50000000) ((322999 : ℝ) / 5000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((53149721 : ℝ) / 50000000) ((5322999 : ℝ) / 5000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((89676669 : ℝ) / 100000000) ((90695473 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((172943387 : ℝ) / 100000000) ((35005451 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((52695099 : ℝ) / 100000000) ((53729757 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((60413 : ℝ) / 100000000) ((12799 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19987201 : ℝ) / 20000000) ((99939587 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((172832711 : ℝ) / 100000000) ((43730379 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((96426077 : ℝ) / 25000000) ((48245863 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1737293 : ℝ) / 25000000) ((3543819 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8897 : ℝ) / 3200) ((893 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((311273 : ℝ) / 12500000) ((318653 : ℝ) / 12500000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((878663 : ℝ) / 20000000) ((4554193 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((20878663 : ℝ) / 20000000) ((104554193 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((47295539 : ℝ) / 4000000) ((1423350743 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1375149 : ℝ) / 100000000) ((702573 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101375149 : ℝ) / 100000000) ((50702573 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16399073 : ℝ) / 50000000) ((16546547 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1215186621 : ℝ) / 100000000) ((1456443837 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((15130191 : ℝ) / 50000000) ((2320501 : ℝ) / 6250000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8897 : ℝ) / 3200) ((893 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((53149721 : ℝ) / 25000000) ((5322999 : ℝ) / 2500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1164981777 : ℝ) / 100000000) ((139398667 : ℝ) / 10000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((154796141 : ℝ) / 6250000) ((2968075861 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((936739 : ℝ) / 10000000) ((563367 : ℝ) / 5000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-236793571 : ℝ) / 100000000) ((-21832619 : ℝ) / 10000000) := rb_log h47 (by norm_num) cov_log_1076.1 cov_log_1077.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1737293 : ℝ) / 50000000) ((3543819 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-33596949 : ℝ) / 10000000) ((-166998261 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_1078.1 cov_log_1079.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((32837683 : ℝ) / 50000000) ((65743427 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1065.1 cov_log_1066.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((4676907 : ℝ) / 4000000) ((3678807 : ℝ) / 3125000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-43809363 : ℝ) / 20000000) ((-108137349 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((8521531 : ℝ) / 100000000) ((10610337 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((11475877 : ℝ) / 50000000) ((35063461 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-196095061 : ℝ) / 100000000) ((-181211237 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((53149721 : ℝ) / 50000000) ((5322999 : ℝ) / 5000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-236793571 : ℝ) / 100000000) ((-21832619 : ℝ) / 10000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-196095061 : ℝ) / 100000000) ((-181211237 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((74 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((878663 : ℝ) / 20000000) ((4554193 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((33 : ℝ) / 20) := by
    have hu : (1 + q / vp) / 2 ≤ ((104554193 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((74 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((33 : ℝ) / 20) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-102984677 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((74 : ℝ) / 25) + hfun ((33 : ℝ) / 20) := by
    linarith [hc0.1, cov_h_19, cov_h_17]
  have hP : ((534731549 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((181211237 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((181211237 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((3020787 : ℝ) / 5000000) ≤ EP1038.Arc.sinc ((33 : ℝ) / 20) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((317 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((259 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((259 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((263 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((263 : ℝ) / 100)) (lo := ((259 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((267 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((267 : ℝ) / 100)) (lo := ((263 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((271 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((271 : ℝ) / 100)) (lo := ((267 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((11 : ℝ) / 4) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((11 : ℝ) / 4)) (lo := ((271 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((279 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((279 : ℝ) / 100)) (lo := ((11 : ℝ) / 4)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((283 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((279 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((287 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((287 : ℝ) / 100)) (lo := ((283 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((291 : ℝ) / 100) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((291 : ℝ) / 100)) (lo := ((287 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((59 : ℝ) / 20) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((59 : ℝ) / 20)) (lo := ((291 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((74 : ℝ) / 25)) (lo := ((59 : ℝ) / 20)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_59 {k : ℝ} (hk : RB k ((5697 : ℝ) / 3200) ((573 : ℝ) / 320)) :
    RB (k / (k + 1)) ((5697 : ℝ) / 8897) ((573 : ℝ) / 893) ∧
    RB (qa (r1A k)) ((450421 : ℝ) / 25000000) ((1836333 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((96426077 : ℝ) / 50000000) ((48245863 : ℝ) / 25000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((11126953 : ℝ) / 25000000) ((573 : ℝ) / 1280) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((59467 : ℝ) / 32000) ((46523047 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((68160541 : ℝ) / 50000000) ((136415611 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((138871219 : ℝ) / 50000000) ((34729621 : ℝ) / 12500000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((138871219 : ℝ) / 100000000) ((34729621 : ℝ) / 25000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((96426077 : ℝ) / 50000000) ((48245863 : ℝ) / 25000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3476953 : ℝ) / 25000000) ((4533 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((3476953 : ℝ) / 100000000) ((3541407 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((450421 : ℝ) / 25000000) ((1836333 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((96426077 : ℝ) / 50000000) ((48245863 : ℝ) / 25000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((450421 : ℝ) / 25000000) ((1836333 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5697 : ℝ) / 8897) ((573 : ℝ) / 893) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_59 {k : ℝ} (hk : RB k ((5697 : ℝ) / 3200) ((573 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_59 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_59 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((10080453 : ℝ) / 25000000)) (ph := ((4100967 : ℝ) / 10000000)) (ml := ((130686339 : ℝ) / 100000000)) (mh := ((26203457 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_59 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
