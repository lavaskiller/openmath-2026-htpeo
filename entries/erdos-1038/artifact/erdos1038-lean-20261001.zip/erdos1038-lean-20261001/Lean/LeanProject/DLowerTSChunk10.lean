import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk07
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_24 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((183576900619035415002626511182233 : ℝ) / 2596148429267413814265248164610048) ((373128187810922466037404589359103 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((70711249999 : ℝ) / 1000000000000) ((114979 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1070711249999 : ℝ) / 1000000000000) ((1714979 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((6832314727 : ℝ) / 100000000000) ((21686627 : ℝ) / 312500000) := rb_log h1 (by norm_num) dlower_log_399.1 dlower_log_400.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((6832314727 : ℝ) / 50000000000) ((21686627 : ℝ) / 156250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((554352767759 : ℝ) / 1000000000000) ((27825044301 : ℝ) / 50000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1324575297849 : ℝ) / 500000000000) ((-1316504702617 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_401.1 dlower_log_402.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1316504702617 : ℝ) / 500000000000) ((1324575297849 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((52314199187 : ℝ) / 250000000000) ((211355449363 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((788644550637 : ℝ) / 1000000000000) ((197685800813 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1250020219 : ℝ) / 250000000000) ((5164129079 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((368935648159 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((9094287977 : ℝ) / 25000000000) ((363935567283 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((368935648159 : ℝ) / 1000000000000) ((368935648159 : ℝ) / 1000000000000) ((368935648159 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((631064351841 : ℝ) / 1000000000000))
  have h11 : RB z11 ((576441242511 : ℝ) / 1000000000000) ((115340239461 : ℝ) / 200000000000) := rb_div_signed h10 (show RB ((631064351841 : ℝ) / 1000000000000) ((631064351841 : ℝ) / 1000000000000) ((631064351841 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-137720466381 : ℝ) / 250000000000) ((-55043100223 : ℝ) / 100000000000) := rb_log h11 (by norm_num) dlower_log_403.1 dlower_log_404.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-217803045479 : ℝ) / 500000000000) ((-43409441041 : ℝ) / 100000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((368935648159 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-124641630673 : ℝ) / 125000000000) ((-498566522691 : ℝ) / 500000000000) := rb_log (show RB ((368935648159 : ℝ) / 1000000000000) ((368935648159 : ℝ) / 1000000000000) ((368935648159 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_405.1 dlower_log_405.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((70190869303 : ℝ) / 125000000000) ((281519317487 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1256517101 : ℝ) / 250000000000) ((1737173443 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1250020219 : ℝ) / 250000000000) ((5164129079 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((721443792253 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1437723455427 : ℝ) / 1000000000000) ((143788750363 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((721443792253 : ℝ) / 500000000000) ((721443792253 : ℝ) / 500000000000) ((721443792253 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((221443792253 : ℝ) / 500000000000))
  have h19 : RB z19 ((3246249174111 : ℝ) / 1000000000000) ((3246619580077 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((221443792253 : ℝ) / 500000000000) ((221443792253 : ℝ) / 500000000000) ((221443792253 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((58875011479 : ℝ) / 50000000000) ((47104573033 : ℝ) / 40000000000) := rb_log h19 (by norm_num) dlower_log_406.1 dlower_log_407.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((116078642429 : ℝ) / 125000000000) ((931190524199 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((721443792253 : ℝ) / 500000000000))
  have h22 : RB z22 ((18332318637 : ℝ) / 50000000000) ((183323186371 : ℝ) / 500000000000) := rb_log (show RB ((721443792253 : ℝ) / 500000000000) ((721443792253 : ℝ) / 500000000000) ((721443792253 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_408.1 dlower_log_408.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((56198276669 : ℝ) / 100000000000) ((564544151459 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((548188067 : ℝ) / 100000000000) ((101913837 : ℝ) / 10000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1070711249999 : ℝ) / 1000000000000) ((1714979 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((573211290437 : ℝ) / 500000000000) ((1148887879079 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1740813909189 : ℝ) / 1000000000000) ((13956459221 : ℝ) / 8000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1073951936347 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1869550468593 : ℝ) / 1000000000000) ((936785400309 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((1073951936347 : ℝ) / 1000000000000) ((1073951936347 : ℝ) / 1000000000000) ((1073951936347 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1250020219 : ℝ) / 250000000000) ((5164129079 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((266166333105147497912227 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((2348193711 : ℝ) / 250000000000) ((9700943427 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((266166333105147497912227 : ℝ) / 500000000000000000000000) ((266166333105147497912227 : ℝ) / 500000000000000000000000) ((266166333105147497912227 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((990299056573 : ℝ) / 1000000000000) ((247651806289 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1851414065263 : ℝ) / 1000000000000) ((927986385967 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((368935648159 : ℝ) / 1000000000000)) ((1256517101 : ℝ) / 250000000000) ((1737173443 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((721443792253 : ℝ) / 500000000000)) ((548188067 : ℝ) / 100000000000) ((101913837 : ℝ) / 10000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((368935648159 : ℝ) / 1000000000000)) (wl := ((721443792253 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1851414065263 : ℝ) / 1000000000000) ≤ D0q (q) * (((721443792253 : ℝ) / 500000000000) - ((368935648159 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((721443792253 : ℝ) / 500000000000) * ((368935648159 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_25 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((373128187810922466037404589359103 : ℝ) / 5192296858534827628530496329220096) ((94775643595943525517389039088435 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((71861874999 : ℝ) / 1000000000000) ((5841 : ℝ) / 80000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1071861874999 : ℝ) / 1000000000000) ((85841 : ℝ) / 80000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((34698603199 : ℝ) / 500000000000) ((35235056581 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_409.1 dlower_log_410.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((34698603199 : ℝ) / 250000000000) ((35235056581 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((110441390847 : ℝ) / 200000000000) ((138588191941 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-10532037621 : ℝ) / 4000000000) ((-1308562309807 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_411.1 dlower_log_412.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1308562309807 : ℝ) / 500000000000) ((10532037621 : ℝ) / 4000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((209724641747 : ℝ) / 1000000000000) ((52954372483 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((197045627517 : ℝ) / 250000000000) ((790275358253 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2582064539 : ℝ) / 500000000000) ((5330825157 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((366110033793 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((90194802159 : ℝ) / 250000000000) ((72189180943 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((366110033793 : ℝ) / 1000000000000) ((366110033793 : ℝ) / 1000000000000) ((366110033793 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((633889966207 : ℝ) / 1000000000000))
  have h11 : RB z11 ((35571947407 : ℝ) / 62500000000) ((284707065861 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((633889966207 : ℝ) / 1000000000000) ((633889966207 : ℝ) / 1000000000000) ((633889966207 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-563609223701 : ℝ) / 1000000000000) ((-22525891433 : ℝ) / 40000000000) := rb_log h11 (by norm_num) dlower_log_413.1 dlower_log_414.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-55675810147 : ℝ) / 125000000000) ((-443862841279 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((366110033793 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-200964270397 : ℝ) / 200000000000) ((-1004821351983 : ℝ) / 1000000000000) := rb_log (show RB ((366110033793 : ℝ) / 1000000000000) ((366110033793 : ℝ) / 1000000000000) ((366110033793 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_415.1 dlower_log_415.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((559414870807 : ℝ) / 1000000000000) ((280479255353 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((5062103043 : ℝ) / 1000000000000) ((8751556471 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2582064539 : ℝ) / 500000000000) ((5330825157 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((721838161213 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1438345497269 : ℝ) / 1000000000000) ((359628048337 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((721838161213 : ℝ) / 500000000000) ((721838161213 : ℝ) / 500000000000) ((721838161213 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((221838161213 : ℝ) / 500000000000))
  have h19 : RB z19 ((3241880227919 : ℝ) / 1000000000000) ((1621127971719 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((221838161213 : ℝ) / 500000000000) ((221838161213 : ℝ) / 500000000000) ((221838161213 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1176153478743 : ℝ) / 1000000000000) ((588134683177 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_416.1 dlower_log_417.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((9270236011 : ℝ) / 10000000000) ((464788347449 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((721838161213 : ℝ) / 500000000000))
  have h22 : RB z22 ((183596430949 : ℝ) / 500000000000) ((367192861901 : ℝ) / 1000000000000) := rb_log (show RB ((721838161213 : ℝ) / 500000000000) ((721838161213 : ℝ) / 500000000000) ((721838161213 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_418.1 dlower_log_418.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((559830739199 : ℝ) / 1000000000000) ((562383833 : ℝ) / 1000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1095594287 : ℝ) / 200000000000) ((2035375753 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1071861874999 : ℝ) / 1000000000000) ((85841 : ℝ) / 80000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((287221969769 : ℝ) / 250000000000) ((1151355825157 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1737082452097 : ℝ) / 1000000000000) ((348162781839 : ℝ) / 200000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1077566288633 : ℝ) / 1000000000000))
  have h28 : RB z28 ((374364298191 : ℝ) / 200000000000) ((468960595833 : ℝ) / 250000000000) := rb_widen (rb_mul h27 (show RB ((1077566288633 : ℝ) / 1000000000000) ((1077566288633 : ℝ) / 1000000000000) ((1077566288633 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2582064539 : ℝ) / 500000000000) ((5330825157 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((264272193594768411870909 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((4885236891 : ℝ) / 500000000000) ((5042930439 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((264272193594768411870909 : ℝ) / 500000000000000000000000) ((264272193594768411870909 : ℝ) / 500000000000000000000000) ((264272193594768411870909 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((494957069561 : ℝ) / 500000000000) ((495114763109 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((28952227497 : ℝ) / 15625000000) ((1857514514507 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((366110033793 : ℝ) / 1000000000000)) ((5062103043 : ℝ) / 1000000000000) ((8751556471 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((721838161213 : ℝ) / 500000000000)) ((1095594287 : ℝ) / 200000000000) ((2035375753 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((366110033793 : ℝ) / 1000000000000)) (wl := ((721838161213 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((28952227497 : ℝ) / 15625000000) ≤ D0q (q) * (((721838161213 : ℝ) / 500000000000) - ((366110033793 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((721838161213 : ℝ) / 500000000000) * ((366110033793 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_26 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((94775643595943525517389039088435 : ℝ) / 1298074214633706907132624082305024) ((48134620119578217262713465418547 : ℝ) / 649037107316853453566312041152512)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((73012499999 : ℝ) / 1000000000000) ((118661 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1073012499999 : ℝ) / 1000000000000) ((1718661 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((1761752829 : ℝ) / 25000000000) ((71541870029 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_419.1 dlower_log_420.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((1761752829 : ℝ) / 12500000000) ((71541870029 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((550063440501 : ℝ) / 1000000000000) ((431411683 : ℝ) / 781250000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-261712461963 : ℝ) / 100000000000) ((-325186027499 : ℝ) / 125000000000) := rb_log hqr (by norm_num) dlower_log_421.1 dlower_log_422.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((325186027499 : ℝ) / 125000000000) ((261712461963 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((210178543419 : ℝ) / 1000000000000) ((53066447697 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((196933552303 : ℝ) / 250000000000) ((789821456581 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1332706289 : ℝ) / 250000000000) ((550016911 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((363262103323 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((357761934213 : ℝ) / 1000000000000) ((357931278167 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((363262103323 : ℝ) / 1000000000000) ((363262103323 : ℝ) / 1000000000000) ((363262103323 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((636737896677 : ℝ) / 1000000000000))
  have h11 : RB z11 ((561866878161 : ℝ) / 1000000000000) ((22485313347 : ℝ) / 40000000000) := rb_div_signed h10 (show RB ((636737896677 : ℝ) / 1000000000000) ((636737896677 : ℝ) / 1000000000000) ((636737896677 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-576490328747 : ℝ) / 1000000000000) ((-576017098163 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_423.1 dlower_log_424.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-113831107789 : ℝ) / 250000000000) ((-226874186657 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((363262103323 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1012630657547 : ℝ) / 1000000000000) ((-202526131509 : ℝ) / 200000000000) := rb_log (show RB ((363262103323 : ℝ) / 1000000000000) ((363262103323 : ℝ) / 1000000000000) ((363262103323 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_425.1 dlower_log_425.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((557306226389 : ℝ) / 1000000000000) ((558882284233 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((5099272149 : ℝ) / 1000000000000) ((2204710933 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1332706289 : ℝ) / 250000000000) ((550016911 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1444473512851 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1438973343741 : ℝ) / 1000000000000) ((287828537539 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((1444473512851 : ℝ) / 1000000000000) ((1444473512851 : ℝ) / 1000000000000) ((1444473512851 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((444473512851 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3237478279663 : ℝ) / 1000000000000) ((1618929639321 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((444473512851 : ℝ) / 1000000000000) ((444473512851 : ℝ) / 1000000000000) ((444473512851 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1174794718017 : ℝ) / 1000000000000) ((1174912394967 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_426.1 dlower_log_427.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((925425988183 : ℝ) / 1000000000000) ((231992754787 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1444473512851 : ℝ) / 1000000000000))
  have h22 : RB z22 ((367744904203 : ℝ) / 1000000000000) ((73548980841 : ℝ) / 200000000000) := rb_log (show RB ((1444473512851 : ℝ) / 1000000000000) ((1444473512851 : ℝ) / 1000000000000) ((1444473512851 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_428.1 dlower_log_428.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((278840541989 : ℝ) / 500000000000) ((112045222989 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2737064869 : ℝ) / 500000000000) ((2540668611 : ℝ) / 250000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1073012499999 : ℝ) / 1000000000000) ((1718661 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((575677912577 : ℝ) / 500000000000) ((115382641911 : ℝ) / 100000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1733362979799 : ℝ) / 1000000000000) ((868541226051 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((135151426191 : ℝ) / 125000000000))
  have h28 : RB z28 ((468532957653 : ℝ) / 250000000000) ((234769170813 : ℝ) / 125000000000) := rb_widen (rb_mul h27 (show RB ((135151426191 : ℝ) / 125000000000) ((135151426191 : ℝ) / 125000000000) ((135151426191 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1332706289 : ℝ) / 250000000000) ((550016911 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((524722486472616730303873 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((10159322867 : ℝ) / 1000000000000) ((83856427 : ℝ) / 8000000000) := rb_div_signed h29 (show RB ((524722486472616730303873 : ℝ) / 1000000000000000000000000) ((524722486472616730303873 : ℝ) / 1000000000000000000000000) ((524722486472616730303873 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((7916143573 : ℝ) / 8000000000) ((989840677133 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1854487080731 : ℝ) / 1000000000000) ((92953630003 : ℝ) / 50000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((363262103323 : ℝ) / 1000000000000)) ((5099272149 : ℝ) / 1000000000000) ((2204710933 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1444473512851 : ℝ) / 1000000000000)) ((2737064869 : ℝ) / 500000000000) ((2540668611 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((363262103323 : ℝ) / 1000000000000)) (wl := ((1444473512851 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1854487080731 : ℝ) / 1000000000000) ≤ D0q (q) * (((1444473512851 : ℝ) / 1000000000000) - ((363262103323 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1444473512851 : ℝ) / 1000000000000) * ((363262103323 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_27 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((48134620119578217262713465418547 : ℝ) / 649037107316853453566312041152512) ((391051347529477374133859290343013 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((74163124999 : ℝ) / 1000000000000) ((60251 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1074163124999 : ℝ) / 1000000000000) ((860251 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((71541870027 : ℝ) / 1000000000000) ((36306239731 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_429.1 dlower_log_430.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((71541870027 : ℝ) / 500000000000) ((36306239731 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((109584444327 : ℝ) / 200000000000) ((275031720253 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2601488220007 : ℝ) / 1000000000000) ((-2586092557923 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_431.1 dlower_log_432.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2586092557923 : ℝ) / 1000000000000) ((2601488220007 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((42123751891 : ℝ) / 200000000000) ((212700600689 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((787299399311 : ℝ) / 1000000000000) ((157876248109 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((5500169109 : ℝ) / 1000000000000) ((283608047 : ℝ) / 50000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((360391789759 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((354719628819 : ℝ) / 1000000000000) ((7097832413 : ℝ) / 20000000000) := rb_widen (rb_sub (show RB ((360391789759 : ℝ) / 1000000000000) ((360391789759 : ℝ) / 1000000000000) ((360391789759 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((639608210241 : ℝ) / 1000000000000))
  have h11 : RB z11 ((277294461781 : ℝ) / 500000000000) ((554857825413 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((639608210241 : ℝ) / 1000000000000) ((639608210241 : ℝ) / 1000000000000) ((639608210241 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-589528117941 : ℝ) / 1000000000000) ((-589043368479 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_433.1 dlower_log_434.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-465362437077 : ℝ) / 1000000000000) ((-463753490171 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((360391789759 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1020563534421 : ℝ) / 1000000000000) ((-1020563534419 : ℝ) / 1000000000000) := rb_log (show RB ((360391789759 : ℝ) / 1000000000000) ((360391789759 : ℝ) / 1000000000000) ((360391789759 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_435.1 dlower_log_435.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((277600548671 : ℝ) / 500000000000) ((2227240177 : ℝ) / 4000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1284414209 : ℝ) / 250000000000) ((1777564523 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((5500169109 : ℝ) / 1000000000000) ((283608047 : ℝ) / 50000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((722639513649 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((719803433179 : ℝ) / 500000000000) ((1439778858189 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((722639513649 : ℝ) / 500000000000) ((722639513649 : ℝ) / 500000000000) ((722639513649 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((222639513649 : ℝ) / 500000000000))
  have h19 : RB z19 ((646608880321 : ℝ) / 200000000000) ((3233430657909 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((222639513649 : ℝ) / 500000000000) ((222639513649 : ℝ) / 500000000000) ((222639513649 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1173424232519 : ℝ) / 1000000000000) ((1173543696773 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_436.1 dlower_log_437.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((923836193399 : ℝ) / 1000000000000) ((926373379193 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((722639513649 : ℝ) / 500000000000))
  have h22 : RB z22 ((184151200699 : ℝ) / 500000000000) ((1841512007 : ℝ) / 5000000000) := rb_log (show RB ((722639513649 : ℝ) / 500000000000) ((722639513649 : ℝ) / 500000000000) ((722639513649 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_438.1 dlower_log_438.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((555533791999 : ℝ) / 1000000000000) ((111614195559 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5470351493 : ℝ) / 1000000000000) ((31714863 : ℝ) / 3125000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1074163124999 : ℝ) / 1000000000000) ((860251 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1153826419107 : ℝ) / 1000000000000) ((57814983047 : ℝ) / 50000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((13512933133 : ℝ) / 7812500000) ((346672595961 : ℝ) / 200000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1084887237539 : ℝ) / 1000000000000))
  have h28 : RB z28 ((938240556653 : ℝ) / 500000000000) ((940251687407 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((1084887237539 : ℝ) / 1000000000000) ((1084887237539 : ℝ) / 1000000000000) ((1084887237539 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((5500169109 : ℝ) / 1000000000000) ((283608047 : ℝ) / 50000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((260433347674536418920591 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((1055964829 : ℝ) / 100000000000) ((2177970291 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((260433347674536418920591 : ℝ) / 500000000000000000000000) ((260433347674536418920591 : ℝ) / 500000000000000000000000) ((260433347674536418920591 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((197822029709 : ℝ) / 200000000000) ((98944035171 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1856046512723 : ℝ) / 1000000000000) ((232580740071 : ℝ) / 125000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((360391789759 : ℝ) / 1000000000000)) ((1284414209 : ℝ) / 250000000000) ((1777564523 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((722639513649 : ℝ) / 500000000000)) ((5470351493 : ℝ) / 1000000000000) ((31714863 : ℝ) / 3125000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((360391789759 : ℝ) / 1000000000000)) (wl := ((722639513649 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1856046512723 : ℝ) / 1000000000000) ≤ D0q (q) * (((722639513649 : ℝ) / 500000000000) - ((360391789759 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((722639513649 : ℝ) / 500000000000) * ((360391789759 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
