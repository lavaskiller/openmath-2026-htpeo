import LeanProject.CertificateArithmetic
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_two : RB (Real.log 2) ((34657359 : ℝ) / 50000000) ((69314719 : ℝ) / 100000000) := by
  exact log_bounds_of_series (t := (1 : ℝ) / 3) (by norm_num) (by norm_num) 12
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
end EP1038.ReferenceCert
