import LeanProject.Stage10C1

/-!
# EP-1038, Stage 10 Part (c), N5 continued: `m_ℓ(S_t)` and `R(S_t)` are log-convex

For `S_t = (1-t) S₀ + t S₁` (`Seg`) with `a ≤ S₀, S₁ ≤ 2`:
* `LCOn_integral`: an integral over `[0,1]` of pointwise-LC positive integrable functions is LC;
* `LCOn_mom`: `t ↦ m_ℓ(S_t) = ∫_0^1 S_t^{-ℓ}` is LC;
* `LCOn_RS`: `t ↦ R(S_t) = exp(-(1/k) ∫ log S_t)` is LC.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

/-- The quantile segment `S_t = (1-t) S₀ + t S₁`. -/
def Seg (S0 S1 : ℝ → ℝ) (t : ℝ) : ℝ → ℝ := fun u => (1 - t) * S0 u + t * S1 u

/-- `m_ℓ(S) = ∫_0^1 S(u)^{-ℓ} du`. -/
noncomputable def mom (ℓ : ℕ) (S : ℝ → ℝ) : ℝ := ∫ u in (0 : ℝ)..1, 1 / S u ^ ℓ

theorem Seg_mid (S0 S1 : ℝ → ℝ) (t0 t1 l u : ℝ) :
    Seg S0 S1 ((1 - l) * t0 + l * t1) u = (1 - l) * Seg S0 S1 t0 u + l * Seg S0 S1 t1 u := by
  unfold Seg; ring

theorem Seg_bounds {S0 S1 : ℝ → ℝ} {a : ℝ} (h0a : ∀ u, a ≤ S0 u) (h1a : ∀ u, a ≤ S1 u)
    (h02 : ∀ u, S0 u ≤ 2) (h12 : ∀ u, S1 u ≤ 2) {t : ℝ} (ht : t ∈ Icc (0 : ℝ) 1) (u : ℝ) :
    a ≤ Seg S0 S1 t u ∧ Seg S0 S1 t u ≤ 2 := by
  unfold Seg
  obtain ⟨ht0, ht1⟩ := ht
  have := h0a u; have := h1a u; have := h02 u; have := h12 u
  constructor <;> nlinarith

theorem Seg_measurable {S0 S1 : ℝ → ℝ} (h0 : Measurable S0) (h1 : Measurable S1) (t : ℝ) :
    Measurable (Seg S0 S1 t) :=
  (measurable_const.mul h0).add (measurable_const.mul h1)

/-- Pointwise normalised AM–GM: `x^(1-l) y^l ≤ A^(1-l) B^l ((1-l) x/A + l y/B)`. -/
theorem rpow_le_normalized {x y A B l : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) (hA : 0 < A) (hB : 0 < B)
    (hl : l ∈ Icc (0 : ℝ) 1) :
    x ^ (1 - l) * y ^ l ≤ A ^ (1 - l) * B ^ l * ((1 - l) * (x / A) + l * (y / B)) := by
  have h := Real.geom_mean_le_arith_mean2_weighted (sub_nonneg.mpr hl.2) hl.1
    (div_nonneg hx hA.le) (div_nonneg hy hB.le) (by ring)
  rw [Real.div_rpow hx hA.le, Real.div_rpow hy hB.le] at h
  have hApos : 0 < A ^ (1 - l) := Real.rpow_pos_of_pos hA _
  have hBpos : 0 < B ^ l := Real.rpow_pos_of_pos hB _
  have e : x ^ (1 - l) / A ^ (1 - l) * (y ^ l / B ^ l) * (A ^ (1 - l) * B ^ l) =
      x ^ (1 - l) * y ^ l := by field_simp
  calc x ^ (1 - l) * y ^ l = x ^ (1 - l) / A ^ (1 - l) * (y ^ l / B ^ l) *
        (A ^ (1 - l) * B ^ l) := e.symm
    _ ≤ ((1 - l) * (x / A) + l * (y / B)) * (A ^ (1 - l) * B ^ l) :=
        mul_le_mul_of_nonneg_right h (by positivity)
    _ = A ^ (1 - l) * B ^ l * ((1 - l) * (x / A) + l * (y / B)) := by ring

/-- An integral over `[0, 1]` of pointwise-LC, positive-mass, integrable functions is LC. -/
theorem LCOn_integral {F : ℝ → ℝ → ℝ}
    (hint : ∀ t ∈ Icc (0 : ℝ) 1, IntervalIntegrable (F t) volume 0 1)
    (hpos : ∀ t ∈ Icc (0 : ℝ) 1, 0 < ∫ u in (0 : ℝ)..1, F t u)
    (hnn : ∀ t ∈ Icc (0 : ℝ) 1, ∀ u ∈ Icc (0 : ℝ) 1, 0 ≤ F t u)
    (hlc : ∀ u ∈ Icc (0 : ℝ) 1, ∀ t0 ∈ Icc (0 : ℝ) 1, ∀ t1 ∈ Icc (0 : ℝ) 1, ∀ l ∈ Icc (0 : ℝ) 1,
      F ((1 - l) * t0 + l * t1) u ≤ F t0 u ^ (1 - l) * F t1 u ^ l) :
    LCOn fun t => ∫ u in (0 : ℝ)..1, F t u := by
  refine ⟨fun t ht => (hpos t ht).le, fun t0 h0 t1 h1 l hl => ?_⟩
  set A := ∫ u in (0 : ℝ)..1, F t0 u
  set B := ∫ u in (0 : ℝ)..1, F t1 u
  have hA := hpos t0 h0
  have hB := hpos t1 h1
  have hRi : IntervalIntegrable (fun u => A ^ (1 - l) * B ^ l *
      ((1 - l) * (F t0 u / A) + l * (F t1 u / B))) volume 0 1 :=
    ((((hint t0 h0).div_const A).const_mul (1 - l)).add
      (((hint t1 h1).div_const B).const_mul l)).const_mul _
  calc ∫ u in (0 : ℝ)..1, F ((1 - l) * t0 + l * t1) u
      ≤ ∫ u in (0 : ℝ)..1, A ^ (1 - l) * B ^ l * ((1 - l) * (F t0 u / A) + l * (F t1 u / B)) := by
        refine intervalIntegral.integral_mono_on zero_le_one (hint _ (mid_mem h0 h1 hl)) hRi
          fun u hu => ?_
        exact (hlc u hu t0 h0 t1 h1 l hl).trans
          (rpow_le_normalized (hnn t0 h0 u hu) (hnn t1 h1 u hu) hA hB hl)
    _ = A ^ (1 - l) * B ^ l := by
        rw [intervalIntegral.integral_const_mul, intervalIntegral.integral_add
          (((hint t0 h0).div_const A).const_mul (1 - l)) (((hint t1 h1).div_const B).const_mul l),
          intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
          intervalIntegral.integral_div, intervalIntegral.integral_div, div_self hA.ne',
          div_self hB.ne']
        ring

section seg

variable {S0 S1 : ℝ → ℝ} {a : ℝ} (hm0 : Measurable S0) (hm1 : Measurable S1) (ha : 0 < a)
  (h0a : ∀ u, a ≤ S0 u) (h1a : ∀ u, a ≤ S1 u) (h02 : ∀ u, S0 u ≤ 2) (h12 : ∀ u, S1 u ≤ 2)
include hm0 hm1 ha h0a h1a h02 h12

theorem ii_inv_pow {t : ℝ} (ht : t ∈ Icc (0 : ℝ) 1) (ℓ : ℕ) :
    IntervalIntegrable (fun u => 1 / Seg S0 S1 t u ^ ℓ) volume 0 1 := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le zero_le_one]
  refine Measure.integrableOn_of_bounded (M := 1 / a ^ ℓ) measure_Ioc_lt_top.ne
    ((measurable_const.div ((Seg_measurable hm0 hm1 t).pow_const ℓ)).aestronglyMeasurable) ?_
  refine Eventually.of_forall fun u => ?_
  have hb := Seg_bounds h0a h1a h02 h12 ht u
  have hpos : 0 < Seg S0 S1 t u := by linarith [hb.1]
  rw [Real.norm_eq_abs, abs_of_pos (by positivity)]
  exact one_div_le_one_div_of_le (by positivity) (pow_le_pow_left₀ ha.le hb.1 ℓ)

/-- `t ↦ m_ℓ(S_t)` is log-convex. -/
theorem LCOn_mom (ℓ : ℕ) : LCOn fun t => mom ℓ (Seg S0 S1 t) := by
  unfold mom
  refine LCOn_integral (fun t ht => ii_inv_pow hm0 hm1 ha h0a h1a h02 h12 ht ℓ) (fun t ht => ?_)
    (fun t ht u _ => ?_) (fun u _ t0 h0 t1 h1 l hl => ?_)
  · have h : ∫ _ in (0 : ℝ)..1, 1 / (2 : ℝ) ^ ℓ ≤ ∫ u in (0 : ℝ)..1, 1 / Seg S0 S1 t u ^ ℓ := by
      refine intervalIntegral.integral_mono_on zero_le_one intervalIntegrable_const
        (ii_inv_pow hm0 hm1 ha h0a h1a h02 h12 ht ℓ) fun u _ => ?_
      have hb := Seg_bounds h0a h1a h02 h12 ht u
      exact one_div_le_one_div_of_le (pow_pos (by linarith [hb.1]) ℓ) (pow_le_pow_left₀
        (by linarith [hb.1]) hb.2 ℓ)
    simp only [intervalIntegral.integral_const, sub_zero, one_smul] at h
    exact lt_of_lt_of_le (by positivity) h
  · have hb := Seg_bounds h0a h1a h02 h12 ht u
    have : 0 < Seg S0 S1 t u := by linarith [hb.1]
    positivity
  · have b0 := Seg_bounds h0a h1a h02 h12 h0 u
    have b1 := Seg_bounds h0a h1a h02 h12 h1 u
    set x := Seg S0 S1 t0 u
    set y := Seg S0 S1 t1 u
    have hx : 0 < x := by linarith [b0.1]
    have hy : 0 < y := by linarith [b1.1]
    rw [Seg_mid]
    have hgm := Real.geom_mean_le_arith_mean2_weighted (sub_nonneg.mpr hl.2) hl.1 hx.le hy.le
      (by ring)
    have hgpos : 0 < x ^ (1 - l) * y ^ l := by positivity
    calc 1 / ((1 - l) * x + l * y) ^ ℓ ≤ 1 / (x ^ (1 - l) * y ^ l) ^ ℓ :=
          one_div_le_one_div_of_le (pow_pos hgpos ℓ) (pow_le_pow_left₀ hgpos.le hgm ℓ)
      _ = (1 / x ^ ℓ) ^ (1 - l) * (1 / y ^ ℓ) ^ l := by
          rw [Real.div_rpow zero_le_one (by positivity), Real.div_rpow zero_le_one (by positivity),
            Real.one_rpow, Real.one_rpow, ← Real.rpow_natCast x ℓ, ← Real.rpow_natCast y ℓ,
            ← Real.rpow_mul hx.le, ← Real.rpow_mul hy.le, mul_pow, ← Real.rpow_natCast
            (x ^ (1 - l)) ℓ, ← Real.rpow_natCast (y ^ l) ℓ, ← Real.rpow_mul hx.le,
            ← Real.rpow_mul hy.le]
          field_simp

/-- `t ↦ R(S_t)` is log-convex. -/
theorem LCOn_RS {k : ℝ} (hk : 0 < k) : LCOn fun t => RS k (Seg S0 S1 t) := by
  unfold RS
  refine LCOn_exp fun t0 h0 t1 h1 l hl => ?_
  have hL : ∀ t ∈ Icc (0 : ℝ) 1, IntervalIntegrable (fun u => Real.log (Seg S0 S1 t u - 0))
      volume 0 1 := fun t ht =>
    ii_log (Seg_measurable hm0 hm1 t) ha (fun u => (Seg_bounds h0a h1a h02 h12 ht u).1)
      (fun u => (Seg_bounds h0a h1a h02 h12 ht u).2) ha
  have hconc : (1 - l) * LS (Seg S0 S1 t0) 0 + l * LS (Seg S0 S1 t1) 0 ≤
      LS (Seg S0 S1 ((1 - l) * t0 + l * t1)) 0 := by
    unfold LS
    rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_const_mul,
      ← intervalIntegral.integral_add ((hL t0 h0).const_mul _) ((hL t1 h1).const_mul _)]
    refine intervalIntegral.integral_mono_on zero_le_one
      (((hL t0 h0).const_mul _).add ((hL t1 h1).const_mul _)) (hL _ (mid_mem h0 h1 hl))
      fun u _ => ?_
    have b0 := Seg_bounds h0a h1a h02 h12 h0 u
    have b1 := Seg_bounds h0a h1a h02 h12 h1 u
    simp only [sub_zero]
    rw [Seg_mid]
    exact (strictConcaveOn_log_Ioi.concaveOn).2 (show 0 < Seg S0 S1 t0 u by linarith [b0.1])
      (show 0 < Seg S0 S1 t1 u by linarith [b1.1]) (sub_nonneg.mpr hl.2) hl.1 (by ring)
  have hk' : 0 < 1 / k := by positivity
  nlinarith [mul_le_mul_of_nonneg_left hconc hk'.le]

end seg

end EP1038.Stage10
