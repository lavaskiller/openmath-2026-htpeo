import LeanProject.ResidualQuantile

/-! Identification of the normal form's main component with the component used
in the convex supporting theorem. The comparison is made below the first residual
atom, so the only logarithmic singularity there is the main atom at zero. -/

open Real Set MeasureTheory Finset Polynomial
open scoped ENNReal

namespace EP1038.NormalForm

open NormalData

theorem firstLocation_le_residual {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount)
    {i : Fin n} (hi : i ∈ a.residualIndices) : a.firstLocation hres ≤ a.locations i := by
  classical
  have hm : a.locations i ∈ a.sortedLocations := by
    apply (Multiset.mem_sort (r := (· ≤ ·))).mpr
    exact Multiset.mem_map.mpr ⟨i, hi, rfl⟩
  obtain ⟨j, hj, heq⟩ := List.mem_iff_getElem.mp hm
  rw [← heq]
  exact orderedAtoms_monotone a (show (⟨0, sorted_length_pos a hres⟩ : Fin _) ≤ ⟨j, hj⟩ from
    by change (0 : ℕ) ≤ j; omega)

/-- Exact sign-set identification below the first residual atom, with zero inserted explicitly. -/
theorem correctedNegSet_iff_sublevel {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount)
    {x : ℝ} (hx : x < a.firstLocation hres) :
    x ∈ Stage10.correctedNegSet a.k (a.residualQuantile hres) ↔ x ∈ sublevel a.locations := by
  classical
  by_cases hx0 : x = 0
  · subst x
    have hloc : a.locations a.main = 0 := by simp [locations]
    constructor
    · intro _; simpa only [hloc] using Atom.root_mem a.locations a.main
    · intro _; exact Or.inl rfl
  have hne : ∀ i : Fin n, x - a.locations i ≠ 0 := by
    intro i
    by_cases hi : a.roots i = a.roots a.main
    · simpa [locations, hi] using hx0
    · have hiO : i ∈ a.residualIndices := by simp [residualIndices, hi]
      linarith [firstLocation_le_residual a hres hiO]
  have hpos : 0 < |∏ i, (x - a.locations i)| :=
    abs_pos.mpr (Finset.prod_ne_zero_iff.mpr fun i _ => hne i)
  have hlog : Real.log |∏ i, (x - a.locations i)| = ∑ i, Real.log |x - a.locations i| := by
    rw [Finset.abs_prod, Real.log_prod fun i _ => abs_ne_zero.mpr (hne i)]
  have hb : (0 : ℝ) < a.residualCount := by exact_mod_cast hres
  change (x = 0 ∨ Stage10.WS a.k (a.residualQuantile hres) x < 0) ↔ _
  simp only [hx0, false_or, potential_eq_log_sum, div_lt_iff₀ hb, zero_mul]
  rw [← hlog]
  exact Real.log_neg_iff hpos

theorem locations_sublevel_iff {n : ℕ} (a : NormalData n) (x : ℝ) :
    x ∈ sublevel a.locations ↔ x + a.roots a.main ∈ sublevel a.roots :=
  Atom.mem_sublevel_shift a.roots (a.roots a.main) x

/-- Any nonnegative potential cut before the residual support isolates precisely the
original main component. This works for both separation and contact cuts. -/
theorem correctedNegSet_main {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount)
    {r : ℝ} (hr0 : 0 < r) (hra : r < a.firstLocation hres)
    (hWr : 0 ≤ Stage10.WS a.k (a.residualQuantile hres) r) :
    Stage10.correctedNegSet a.k (a.residualQuantile hres) ∩ Iio r =
      Ioo (Resid.ellL a.roots (a.roots a.main) - a.roots a.main)
        (Resid.rhoR a.roots (a.roots a.main) - a.roots a.main) := by
  have hout : r + a.roots a.main ∉ sublevel a.roots := by
    intro hmem
    have hneg := (correctedNegSet_iff_sublevel a hres hra).mpr
      ((locations_sublevel_iff a r).mpr hmem)
    rcases hneg with hzero | hneg
    · linarith
    · exact not_lt_of_ge hWr hneg
  have hmainright : Resid.rhoR a.roots (a.roots a.main) ≤ r + a.roots a.main := by
    obtain ⟨-, -, hbelow⟩ := Resid.rhoR_props a.roots_mem (a.roots a.main)
      (by linarith [(a.roots_mem a.main).2])
    by_contra h
    exact hout (hbelow _ (by linarith) (lt_of_not_ge h))
  have hotherleft : ∀ i, a.roots i ≠ a.roots a.main →
      r + a.roots a.main ≤ Resid.ellL a.roots (a.roots i) := by
    intro i hi
    have hfirst := firstLocation_le_residual a hres (i := i)
      (by classical exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hi⟩)
    have hrootgt : r + a.roots a.main < a.roots i := by dsimp [locations] at hfirst; linarith
    obtain ⟨-, hright, hcomp, -⟩ := Resid.comp_props a.roots_mem i
    by_contra h
    exact hout (hcomp ⟨lt_of_not_ge h, hrootgt.trans hright⟩)
  ext x
  constructor
  · rintro ⟨hx, hxr⟩
    change x < r at hxr
    have hxloc := (correctedNegSet_iff_sublevel a hres (hxr.trans hra)).mp hx
    have hxS := (locations_sublevel_iff a x).mp hxloc
    rw [Stage7.lemma71_union a.roots a.roots_mem] at hxS
    obtain ⟨i, hi⟩ := Set.mem_iUnion.mp hxS
    by_cases heq : a.roots i = a.roots a.main
    · rw [heq] at hi
      exact ⟨by linarith [hi.1], by linarith [hi.2]⟩
    · have hleft := hotherleft i heq
      linarith [hi.1]
  · intro hx
    have hxS := (Resid.comp_props a.roots_mem a.main).2.2.1
      (show x + a.roots a.main ∈ Set.Ioo _ _ from ⟨by linarith [hx.1], by linarith [hx.2]⟩)
    have hxr : x < r := by linarith [hx.2]
    exact ⟨(correctedNegSet_iff_sublevel a hres (hxr.trans hra)).mpr
      ((locations_sublevel_iff a x).mpr hxS), hxr⟩

theorem volume_correctedNegSet_main {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount)
    {r : ℝ} (hr0 : 0 < r) (hra : r < a.firstLocation hres)
    (hWr : 0 ≤ Stage10.WS a.k (a.residualQuantile hres) r) :
    (volume (Stage10.correctedNegSet a.k (a.residualQuantile hres) ∩ Iio r)).toReal =
      Resid.rhoR a.roots (a.roots a.main) - Resid.ellL a.roots (a.roots a.main) := by
  rw [correctedNegSet_main a hres hr0 hra hWr, Real.volume_Ioo]
  have hc := Resid.comp_props a.roots_mem a.main
  rw [ENNReal.toReal_ofReal (by linarith [hc.1, hc.2.1])]
  ring

/-- The actual polynomial target can now be passed to either branch of the supporting
theorem. Only the separated reference hypotheses remain as inputs. -/
theorem supporting_inequality_normal_form {n : ℕ} (a : NormalData n) (hres : 0 < a.residualCount)
    {T₀ : ℝ → ℝ} {a₀ r₀ : ℝ}
    (hm₀ : Measurable T₀) (ha₀ : 0 < a₀) (hl₀ : ∀ u, a₀ ≤ T₀ u) (hu₀ : ∀ u, T₀ u ≤ 2)
    (hr₀ : 0 < r₀) (hr₀a : r₀ < a₀)
    (hsep₀ : Stage10.RS a.k T₀ < Stage10.PsiS a.k T₀ r₀) :
    (volume (Stage10.correctedNegSet a.k T₀ ∩ Iio r₀)).toReal +
      Stage10.Mdot a.k T₀ (a.residualQuantile hres) ≤
        Resid.rhoR a.roots (a.roots a.main) - Resid.ellL a.roots (a.roots a.main) := by
  have hm := measurable_residualQuantile a hres
  have ha := firstLocation_pos a hres
  have hl := fun u => (residualQuantile_bounds a hres u).1
  have hu := fun u => (residualQuantile_bounds a hres u).2
  have hk : 0 < a.k := lt_of_lt_of_le zero_lt_one (one_le_k a hres)
  obtain ⟨hyc0, hyca, hsep | hcon⟩ := residualQuantile_admissible a hres
  · have hWr : 0 ≤ Stage10.WS a.k (a.residualQuantile hres)
        (Stage10.yc a.k (a.firstLocation hres) (a.residualQuantile hres)) := by
      exact (Stage10.WS_pos_iff hm ha hl hu hk hyca hyc0.ne').mpr
        (by rw [abs_of_pos (Stage10.PsiS_pos hm ha hl hu hyc0)]; exact hsep) |>.le
    have h := Stage10.convex_supporting_sep_component hm₀ hm ha₀ hl₀ hu₀ ha hl hu hk
      hr₀ hr₀a hsep₀ hyc0 hyca hsep
    rwa [volume_correctedNegSet_main a hres hyc0 hyca hWr] at h
  · have hWr := (Stage10.contact_right hm ha hl hu hk
      (residual_first_atom_positive a hres) hcon).1
    have h := Stage10.convex_supporting_contact_component hm₀ hm ha₀ hl₀ hu₀ ha hl hu hk
      hr₀ hr₀a hsep₀ (residual_first_atom_positive a hres) hcon
    rwa [volume_correctedNegSet_main a hres hyc0 hyca (by rw [hWr])] at h

theorem J_nonneg {n : ℕ} (a : NormalData n) : 0 ≤ a.J := by
  classical
  have hc := Resid.comp_props a.roots_mem a.main
  have hrad : 0 ≤ ∑ v ∈ a.residualIndices.image a.roots, Stage7.Rv a.roots v :=
    Finset.sum_nonneg fun v _ => (Real.exp_pos _).le
  dsimp [J]
  linarith [hc.1, hc.2.1]

theorem J_le_polynomial_measure {n : ℕ} (a : NormalData n) {p : ℝ[X]} (hp : Admissible p)
    (hmeasure : volume (sublevel a.roots) ≤ sublevelMeasure p) :
    a.J ≤ (sublevelMeasure p).toReal := by
  have hJ : ENNReal.ofReal a.J ≤ sublevelMeasure p := a.width_bound.trans hmeasure
  calc
    a.J = (ENNReal.ofReal a.J).toReal := (ENNReal.toReal_ofReal (J_nonneg a)).symm
    _ ≤ (sublevelMeasure p).toReal := ENNReal.toReal_mono (admissible_measure_finite hp) hJ

/-- End-to-end polynomial reduction for the next stage of the sharp lower-bound proof.
The target and its admissibility are constructed from the polynomial, not assumed.
The remaining input is a separated reference model for the resulting `k`. -/
theorem polynomial_supporting_reduction {p : ℝ[X]} (hp : Admissible p) :
    ENNReal.ofReal 2 ≤ sublevelMeasure p ∨
      ∃ n : ℕ, ∃ a : NormalData n, ∃ hres : 0 < a.residualCount,
        1 ≤ a.k ∧ a.J ≤ (sublevelMeasure p).toReal ∧
          ∀ (T₀ : ℝ → ℝ) (a₀ r₀ : ℝ),
            Measurable T₀ → 0 < a₀ → (∀ u, a₀ ≤ T₀ u) → (∀ u, T₀ u ≤ 2) →
            0 < r₀ → r₀ < a₀ → Stage10.RS a.k T₀ < Stage10.PsiS a.k T₀ r₀ →
            (volume (Stage10.correctedNegSet a.k T₀ ∩ Iio r₀)).toReal +
              Stage10.Mdot a.k T₀ (a.residualQuantile hres) +
                2 * ∑ v ∈ a.residualIndices.image a.roots, Stage7.Rv a.roots v ≤
                  (sublevelMeasure p).toReal := by
  classical
  obtain ⟨n, a, hmeasure⟩ := polynomial_normal_form hp
  rcases Nat.eq_zero_or_pos a.residualCount with hzero | hres
  · exact Or.inl (by simpa only [single_atom_measure a hzero] using hmeasure)
  have hJ := J_le_polynomial_measure a hp hmeasure
  refine Or.inr ⟨n, a, hres, one_le_k a hres, hJ, ?_⟩
  intro T₀ a₀ r₀ hm₀ ha₀ hl₀ hu₀ hr₀ hr₀a hsep₀
  have hs := supporting_inequality_normal_form a hres hm₀ ha₀ hl₀ hu₀ hr₀ hr₀a hsep₀
  dsimp [J] at hJ
  linarith

end EP1038.NormalForm
