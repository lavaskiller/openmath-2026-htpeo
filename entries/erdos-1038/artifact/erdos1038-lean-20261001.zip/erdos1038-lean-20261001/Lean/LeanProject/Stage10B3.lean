import LeanProject.Stage10B2

/-!
# EP-1038, Stage 10, Definition 10.5 and Lemma 10.6 (the main component of an admissible `S`)

With `R = R(S)` and `W_S < 0 ⟺ |Ψ_S| < R` on `(-∞, a) \ {0}` ((10.2)):
* `exists_xminus`: the unique `x₋ < 0` with `Ψ_S(x₋) = -R`;
* strictly separated (`R < Ψ_S(r)` for some `r ∈ (0, a)`): `exists_xplus` gives `x₊ ∈ (0, y_c)`,
  `x₊ < r`, `Ψ_S(x₊) = R`;
* contact (`y_c < a`, `R = Ψ_S(y_c)`): `x₊ = y_c`;
* `main_component_sep`, `main_component_contact` (**Lemma 10.6**): `W_S < 0` on `(x₋, x₊) \ {0}`,
  `W_S(x±) = 0`, so the main component is `(x₋, x₊)` and `M_k(S) = x₊ - x₋`; in the separated case the
  crossings are simple: `W_S'(x₋) = k G_S(x₋) < 0 < k G_S(x₊) = W_S'(x₊)` (`hasDerivAt_WS`).
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

section comp

variable {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
  (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
include hSm ha hSa hS2 hk

theorem RS_pos : 0 < RS k S := Real.exp_pos _

/-- `Ψ_S` is strictly increasing on `(-∞, y_c]` when `y_c < a`. -/
theorem PsiS_strictMonoOn_Iic (hyc : yc k a S < a) : StrictMonoOn (PsiS k S) (Iic (yc k a S)) := by
  refine strictMonoOn_of_deriv_pos (convex_Iic _) ?_ ?_
  · intro y hy
    exact (PsiS_continuousAt hSm ha hSa hS2 (lt_of_le_of_lt hy hyc)).continuousWithinAt
  · intro y hy
    rw [interior_Iic] at hy
    rw [(hasDerivAt_PsiS hSm ha hSa hS2 (lt_trans hy hyc)).deriv]
    exact PsiS_deriv_pos hSm ha hSa hS2 hk hy

/-- `W_S < 0 ⟺ |Ψ_S| < R` on `(-∞, a) \ {0}`. -/
theorem WS_neg_iff {y : ℝ} (hy : y < a) (hy0 : y ≠ 0) :
    WS k S y < 0 ↔ |PsiS k S y| < RS k S := by
  rw [WS_eq hSm ha hSa hS2 hk hy hy0]
  have hR := RS_pos hSm ha hSa hS2 hk
  have hΨ : 0 < |PsiS k S y| := by
    unfold PsiS; rw [abs_mul]; exact mul_pos (abs_pos.mpr hy0) (by positivity)
  constructor
  · intro h
    have h' : Real.log (|PsiS k S y| / RS k S) < 0 := by
      by_contra hc; push Not at hc; nlinarith
    have := (Real.log_neg_iff (div_pos hΨ hR)).mp h'
    rwa [div_lt_one hR] at this
  · intro h
    have : Real.log (|PsiS k S y| / RS k S) < 0 :=
      Real.log_neg (div_pos hΨ hR) ((div_lt_one hR).mpr h)
    exact mul_neg_of_pos_of_neg hk this

theorem WS_zero_of_abs {y : ℝ} (hy : y < a) (hy0 : y ≠ 0) (h : |PsiS k S y| = RS k S) :
    WS k S y = 0 := by
  rw [WS_eq hSm ha hSa hS2 hk hy hy0, h, div_self (RS_pos hSm ha hSa hS2 hk).ne', Real.log_one,
    mul_zero]

/-- `W_S' = k G_S` on `(-∞, a) \ {0}`. -/
theorem hasDerivAt_WS {y : ℝ} (hy : y < a) (hy0 : y ≠ 0) :
    HasDerivAt (WS k S) (k * GS k S y) y := by
  have hL := hasDerivAt_LS hSm ha hSa hS2 hy
  have hlog : HasDerivAt (fun x => k * Real.log x) (k * y⁻¹) y :=
    (Real.hasDerivAt_log hy0).const_mul k
  have heq : WS k S =ᶠ[𝓝 y] fun x => k * Real.log x + LS S x := by
    filter_upwards [Iio_mem_nhds hy] with x hx
    unfold WS LS
    rw [Real.log_abs]
    congr 1
    refine intervalIntegral.integral_congr fun u _ => ?_
    rw [abs_sub_comm, Real.log_abs]
  refine ((hlog.add hL).congr_of_eventuallyEq heq).congr_deriv ?_
  unfold GS
  field_simp
  ring

theorem exists_xminus : ∃ xm, xm < 0 ∧ PsiS k S xm = -RS k S := by
  have hR := RS_pos hSm ha hSa hS2 hk
  set y0 := -RS k S - 1
  have hy0 : y0 < 0 := by linarith
  have hlt : PsiS k S y0 < -RS k S := by
    have := PsiS_lt_of_neg hSm ha hSa hS2 hk hy0; linarith
  have hcont : ContinuousOn (PsiS k S) (Icc y0 0) := fun y hy =>
    (PsiS_continuousAt hSm ha hSa hS2 (by linarith [hy.2])).continuousWithinAt
  obtain ⟨xm, hxm, hΨ⟩ := intermediate_value_Icc hy0.le hcont
    ⟨hlt.le, by rw [PsiS_zero]; linarith⟩
  refine ⟨xm, lt_of_le_of_ne hxm.2 ?_, hΨ⟩
  rintro rfl
  rw [PsiS_zero] at hΨ
  linarith

/-- The separated case: `x₊ ∈ (0, y_c)`, `x₊ < r`, `Ψ_S(x₊) = R`. -/
theorem exists_xplus {r : ℝ} (hr0 : 0 < r) (hra : r < a) (hsep : RS k S < PsiS k S r) :
    ∃ xp, 0 < xp ∧ xp < yc k a S ∧ xp < r ∧ PsiS k S xp = RS k S := by
  have hR := RS_pos hSm ha hSa hS2 hk
  have hycpos := yc_pos hSm ha hSa hS2 hk
  set r0 := min r (yc k a S) with hr0def
  have hr0pos : 0 < r0 := lt_min hr0 hycpos
  have hr0a : r0 < a := lt_of_le_of_lt (min_le_left _ _) hra
  have hΨr0 : RS k S < PsiS k S r0 := by
    rcases le_total r (yc k a S) with h | h
    · rw [hr0def, min_eq_left h]; exact hsep
    · rw [hr0def, min_eq_right h]
      rcases h.lt_or_eq with h' | h'
      · have := PsiS_strictAntiOn hSm ha hSa hS2 hk ⟨le_rfl, lt_trans h' hra⟩ ⟨h'.le, hra⟩ h'
        linarith
      · rw [h']; exact hsep
  have hcont : ContinuousOn (PsiS k S) (Icc 0 r0) := fun y hy =>
    (PsiS_continuousAt hSm ha hSa hS2 (by linarith [hy.2])).continuousWithinAt
  obtain ⟨xp, hxp, hΨ⟩ := intermediate_value_Icc hr0pos.le hcont
    ⟨by rw [PsiS_zero]; exact hR.le, hΨr0.le⟩
  have hxp0 : 0 < xp := by
    rcases hxp.1.lt_or_eq with h | h
    · exact h
    · rw [← h, PsiS_zero] at hΨ; linarith
  have hxpr0 : xp < r0 := by
    rcases hxp.2.lt_or_eq with h | h
    · exact h
    · rw [h] at hΨ; linarith
  exact ⟨xp, hxp0, lt_of_lt_of_le hxpr0 (min_le_right _ _), lt_of_lt_of_le hxpr0 (min_le_left _ _),
    hΨ⟩

/-- **Lemma 10.6**, strictly separated case. -/
theorem main_component_sep {r : ℝ} (hr0 : 0 < r) (hra : r < a) (hsep : RS k S < PsiS k S r) :
    ∃ xm xp, xm < 0 ∧ 0 < xp ∧ xp < yc k a S ∧ xp < r ∧
      WS k S xm = 0 ∧ WS k S xp = 0 ∧
      (∀ y, xm < y → y < xp → y ≠ 0 → WS k S y < 0) ∧
      GS k S xm < 0 ∧ 0 < GS k S xp := by
  obtain ⟨xm, hxm, hΨm⟩ := exists_xminus hSm ha hSa hS2 hk
  obtain ⟨xp, hxp0, hxpyc, hxpr, hΨp⟩ := exists_xplus hSm ha hSa hS2 hk hr0 hra hsep
  have hR := RS_pos hSm ha hSa hS2 hk
  have hmono := PsiS_strictMonoOn hSm ha hSa hS2 hk
  have hycpos := yc_pos hSm ha hSa hS2 hk
  refine ⟨xm, xp, hxm, hxp0, hxpyc, hxpr, ?_, ?_, ?_, ?_, ?_⟩
  · exact WS_zero_of_abs hSm ha hSa hS2 hk (by linarith) hxm.ne (by rw [hΨm, abs_neg, abs_of_pos hR])
  · exact WS_zero_of_abs hSm ha hSa hS2 hk (by linarith) hxp0.ne' (by rw [hΨp, abs_of_pos hR])
  · intro y h1 h2 hy0
    have hya : y < a := by linarith
    rw [WS_neg_iff hSm ha hSa hS2 hk hya hy0, abs_lt]
    have hyyc : y < yc k a S := by linarith
    have a1 : PsiS k S xm < PsiS k S y := hmono (by simp only [mem_Iio]; linarith) hyyc h1
    have a2 : PsiS k S y < PsiS k S xp := hmono hyyc hxpyc h2
    constructor <;> linarith
  · unfold GS
    have hJ := JS_pos hSm ha hSa hS2 (show xm < a by linarith)
    have : 1 / xm < 0 := one_div_neg.mpr hxm
    have : 0 < (1 / k) * JS S xm := mul_pos (by positivity) hJ
    linarith
  · exact GS_pos_of_lt_yc hSm ha hSa hS2 hk hxp0 hxpyc

/-- **Lemma 10.6**, contact case (`x₊ = y_c`). -/
theorem main_component_contact (hyc : yc k a S < a) (hcon : RS k S = PsiS k S (yc k a S)) :
    ∃ xm, xm < 0 ∧ WS k S xm = 0 ∧ WS k S (yc k a S) = 0 ∧
      ∀ y, xm < y → y < yc k a S → y ≠ 0 → WS k S y < 0 := by
  obtain ⟨xm, hxm, hΨm⟩ := exists_xminus hSm ha hSa hS2 hk
  have hR := RS_pos hSm ha hSa hS2 hk
  have hmono := PsiS_strictMonoOn_Iic hSm ha hSa hS2 hk hyc
  have hycpos := yc_pos hSm ha hSa hS2 hk
  refine ⟨xm, hxm, ?_, ?_, ?_⟩
  · exact WS_zero_of_abs hSm ha hSa hS2 hk (by linarith) hxm.ne (by rw [hΨm, abs_neg, abs_of_pos hR])
  · exact WS_zero_of_abs hSm ha hSa hS2 hk hyc hycpos.ne' (by
      rw [← hcon, abs_of_pos hR])
  · intro y h1 h2 hy0
    have hya : y < a := by linarith
    rw [WS_neg_iff hSm ha hSa hS2 hk hya hy0, abs_lt]
    have a1 : PsiS k S xm < PsiS k S y := hmono (by simp only [mem_Iic]; linarith)
      (by simp only [mem_Iic]; linarith) h1
    have a2 : PsiS k S y < PsiS k S (yc k a S) := hmono (by simp only [mem_Iic]; linarith)
      (Set.mem_Iic.mpr le_rfl) h2
    constructor <;> linarith

end comp

end EP1038.Stage10
