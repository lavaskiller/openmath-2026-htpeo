import LeanProject.COVLogTwo
import LeanProject.COVLogBounds08
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_960 : RB (Real.log ((17757729 : ℝ) / 25000000)) ((-34205497 : ℝ) / 100000000) ((-4275687 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((17757729 : ℝ) / 25000000)) (t := ((-7242271 : ℝ) / 42757729))
    (lo := ((-34205497 : ℝ) / 100000000)) (hi := ((-4275687 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_961 : RB (Real.log ((41545909 : ℝ) / 100000000)) ((-43918557 : ℝ) / 50000000) ((-10979639 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((41545909 : ℝ) / 50000000)) (t := ((-8454091 : ℝ) / 91545909))
    (lo := ((-3704479 : ℝ) / 20000000)) (hi := ((-9261197 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41545909 : ℝ) / 100000000) = Real.log ((41545909 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41545909 : ℝ) / 100000000) = ((41545909 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_962 : RB (Real.log ((108284303 : ℝ) / 25000000)) ((146588437 : ℝ) / 100000000) ((3664711 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((108284303 : ℝ) / 100000000)) (t := ((8284303 : ℝ) / 208284303))
    (lo := ((7959001 : ℝ) / 100000000)) (hi := ((3979501 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((108284303 : ℝ) / 25000000) = Real.log ((108284303 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((108284303 : ℝ) / 25000000) = ((108284303 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_963 : RB (Real.log ((108285227 : ℝ) / 25000000)) ((146589291 : ℝ) / 100000000) ((73294647 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((108285227 : ℝ) / 100000000)) (t := ((8285227 : ℝ) / 208285227))
    (lo := ((1591971 : ℝ) / 20000000)) (hi := ((497491 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((108285227 : ℝ) / 25000000) = Real.log ((108285227 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((108285227 : ℝ) / 25000000) = ((108285227 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_964 : RB (Real.log ((65004847 : ℝ) / 50000000)) ((26243883 : ℝ) / 100000000) ((6560971 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((65004847 : ℝ) / 50000000)) (t := ((15004847 : ℝ) / 115004847))
    (lo := ((26243883 : ℝ) / 100000000)) (hi := ((6560971 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_965 : RB (Real.log ((429395771 : ℝ) / 100000000)) ((36430221 : ℝ) / 25000000) ((145720887 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((429395771 : ℝ) / 400000000)) (t := ((29395771 : ℝ) / 829395771))
    (lo := ((886431 : ℝ) / 12500000)) (hi := ((7091449 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((429395771 : ℝ) / 100000000) = Real.log ((429395771 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((429395771 : ℝ) / 100000000) = ((429395771 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_966 : RB (Real.log ((214699713 : ℝ) / 50000000)) ((18215217 : ℝ) / 12500000) ((145721739 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((214699713 : ℝ) / 200000000)) (t := ((14699713 : ℝ) / 414699713))
    (lo := ((70923 : ℝ) / 1000000)) (hi := ((7092301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((214699713 : ℝ) / 50000000) = Real.log ((214699713 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((214699713 : ℝ) / 50000000) = ((214699713 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_967 : RB (Real.log ((130350559 : ℝ) / 100000000)) ((6626431 : ℝ) / 25000000) ((1060229 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((130350559 : ℝ) / 100000000)) (t := ((30350559 : ℝ) / 230350559))
    (lo := ((6626431 : ℝ) / 25000000)) (hi := ((1060229 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_968 : RB (Real.log ((8555183 : ℝ) / 100000000)) ((-61465823 : ℝ) / 25000000) ((-30732911 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((8555183 : ℝ) / 12500000)) (t := ((-3944817 : ℝ) / 21055183))
    (lo := ((-7583827 : ℝ) / 20000000)) (hi := ((-18959567 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8555183 : ℝ) / 100000000) = Real.log ((8555183 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8555183 : ℝ) / 100000000) = ((8555183 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_969 : RB (Real.log ((10617949 : ℝ) / 100000000)) ((-44852487 : ℝ) / 20000000) ((-224262431 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10617949 : ℝ) / 12500000)) (t := ((-1882051 : ℝ) / 23117949))
    (lo := ((-8159139 : ℝ) / 50000000)) (hi := ((-16318277 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10617949 : ℝ) / 100000000) = Real.log ((10617949 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((10617949 : ℝ) / 100000000) = ((10617949 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_970 : RB (Real.log ((1544071 : ℝ) / 50000000)) ((-173880031 : ℝ) / 50000000) ((-43470007 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((1544071 : ℝ) / 1562500)) (t := ((-18429 : ℝ) / 3106571))
    (lo := ((-1186467 : ℝ) / 100000000)) (hi := ((-593233 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1544071 : ℝ) / 50000000) = Real.log ((1544071 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1544071 : ℝ) / 50000000) = ((1544071 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_971 : RB (Real.log ((394603 : ℝ) / 12500000)) ((-172780189 : ℝ) / 50000000) ((-86390093 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((394603 : ℝ) / 390625)) (t := ((1989 : ℝ) / 392614))
    (lo := ((1013217 : ℝ) / 100000000)) (hi := ((506609 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((394603 : ℝ) / 12500000) = Real.log ((394603 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((394603 : ℝ) / 12500000) = ((394603 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_972 : RB (Real.log ((68600137 : ℝ) / 100000000)) ((-18843783 : ℝ) / 50000000) ((-7537513 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((68600137 : ℝ) / 100000000)) (t := ((-31399863 : ℝ) / 168600137))
    (lo := ((-18843783 : ℝ) / 50000000)) (hi := ((-7537513 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_973 : RB (Real.log ((68602051 : ℝ) / 100000000)) ((-4710597 : ℝ) / 12500000) ((-1507391 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((68602051 : ℝ) / 100000000)) (t := ((-31397949 : ℝ) / 168602051))
    (lo := ((-4710597 : ℝ) / 12500000)) (hi := ((-1507391 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_974 : RB (Real.log ((20352241 : ℝ) / 50000000)) ((-89883199 : ℝ) / 100000000) ((-89883197 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20352241 : ℝ) / 25000000)) (t := ((-4647759 : ℝ) / 45352241))
    (lo := ((-128553 : ℝ) / 625000)) (hi := ((-20568479 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20352241 : ℝ) / 50000000) = Real.log ((20352241 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20352241 : ℝ) / 50000000) = ((20352241 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_975 : RB (Real.log ((48377041 : ℝ) / 25000000)) ((66014951 : ℝ) / 100000000) ((66014953 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((48377041 : ℝ) / 50000000)) (t := ((-1622959 : ℝ) / 98377041))
    (lo := ((-3299767 : ℝ) / 100000000)) (hi := ((-1649883 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48377041 : ℝ) / 25000000) = Real.log ((48377041 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48377041 : ℝ) / 25000000) = ((48377041 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_976 : RB (Real.log ((96819617 : ℝ) / 50000000)) ((33041331 : ℝ) / 50000000) ((8260333 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((96819617 : ℝ) / 100000000)) (t := ((-3180383 : ℝ) / 196819617))
    (lo := ((-404007 : ℝ) / 12500000)) (hi := ((-646411 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((96819617 : ℝ) / 50000000) = Real.log ((96819617 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((96819617 : ℝ) / 50000000) = ((96819617 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_977 : RB (Real.log ((35376347 : ℝ) / 50000000)) ((-17298979 : ℝ) / 50000000) ((-34597957 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35376347 : ℝ) / 50000000)) (t := ((-14623653 : ℝ) / 85376347))
    (lo := ((-17298979 : ℝ) / 50000000)) (hi := ((-34597957 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_978 : RB (Real.log ((8844329 : ℝ) / 12500000)) ((-34595219 : ℝ) / 100000000) ((-17297609 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8844329 : ℝ) / 12500000)) (t := ((-3655671 : ℝ) / 21344329))
    (lo := ((-34595219 : ℝ) / 100000000)) (hi := ((-17297609 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_979 : RB (Real.log ((20725989 : ℝ) / 50000000)) ((-4403173 : ℝ) / 5000000) ((-44031729 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((20725989 : ℝ) / 25000000)) (t := ((-4274011 : ℝ) / 45725989))
    (lo := ((-18748741 : ℝ) / 100000000)) (hi := ((-937437 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20725989 : ℝ) / 50000000) = Real.log ((20725989 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20725989 : ℝ) / 50000000) = ((20725989 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_980 : RB (Real.log ((215935317 : ℝ) / 50000000)) ((146295589 : ℝ) / 100000000) ((18286949 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((215935317 : ℝ) / 200000000)) (t := ((15935317 : ℝ) / 415935317))
    (lo := ((7666153 : ℝ) / 100000000)) (hi := ((3833077 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((215935317 : ℝ) / 50000000) = Real.log ((215935317 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((215935317 : ℝ) / 50000000) = ((215935317 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_981 : RB (Real.log ((539843 : ℝ) / 125000)) ((146296461 : ℝ) / 100000000) ((9143529 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((539843 : ℝ) / 500000)) (t := ((39843 : ℝ) / 1039843))
    (lo := ((306681 : ℝ) / 4000000)) (hi := ((3833513 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((539843 : ℝ) / 125000) = Real.log ((539843 : ℝ) / 500000) + 2 * Real.log 2 := by
    rw [show ((539843 : ℝ) / 125000) = ((539843 : ℝ) / 500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_982 : RB (Real.log ((32530971 : ℝ) / 25000000)) ((6582919 : ℝ) / 25000000) ((26331677 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32530971 : ℝ) / 25000000)) (t := ((7530971 : ℝ) / 57530971))
    (lo := ((6582919 : ℝ) / 25000000)) (hi := ((26331677 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_983 : RB (Real.log ((428175777 : ℝ) / 100000000)) ((145436361 : ℝ) / 100000000) ((36359091 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((428175777 : ℝ) / 400000000)) (t := ((28175777 : ℝ) / 828175777))
    (lo := ((272277 : ℝ) / 4000000)) (hi := ((3403463 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((428175777 : ℝ) / 100000000) = Real.log ((428175777 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((428175777 : ℝ) / 100000000) = ((428175777 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_984 : RB (Real.log ((428179501 : ℝ) / 100000000)) ((145437231 : ℝ) / 100000000) ((72718617 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((428179501 : ℝ) / 400000000)) (t := ((28179501 : ℝ) / 828179501))
    (lo := ((1361559 : ℝ) / 20000000)) (hi := ((1701949 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((428179501 : ℝ) / 100000000) = Real.log ((428179501 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((428179501 : ℝ) / 100000000) = ((428179501 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_985 : RB (Real.log ((65231521 : ℝ) / 50000000)) ((26591979 : ℝ) / 100000000) ((1329599 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((65231521 : ℝ) / 50000000)) (t := ((15231521 : ℝ) / 115231521))
    (lo := ((26591979 : ℝ) / 100000000)) (hi := ((1329599 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_986 : RB (Real.log ((868963 : ℝ) / 10000000)) ((-122151993 : ℝ) / 50000000) ((-122151991 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((868963 : ℝ) / 1250000)) (t := ((-381037 : ℝ) / 2118963))
    (lo := ((-36359829 : ℝ) / 100000000)) (hi := ((-9089957 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((868963 : ℝ) / 10000000) = Real.log ((868963 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((868963 : ℝ) / 10000000) = ((868963 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_987 : RB (Real.log ((670081 : ℝ) / 6250000)) ((-111646909 : ℝ) / 50000000) ((-111646907 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((670081 : ℝ) / 781250)) (t := ((-111169 : ℝ) / 1451331))
    (lo := ((-15349661 : ℝ) / 100000000)) (hi := ((-767483 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((670081 : ℝ) / 6250000) = Real.log ((670081 : ℝ) / 781250) - 3 * Real.log 2 := by
    rw [show ((670081 : ℝ) / 6250000) = ((670081 : ℝ) / 781250) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_988 : RB (Real.log ((3152549 : ℝ) / 100000000)) ((-345695891 : ℝ) / 100000000) ((-69139177 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3152549 : ℝ) / 3125000)) (t := ((27549 : ℝ) / 6277549))
    (lo := ((109713 : ℝ) / 12500000)) (hi := ((175541 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3152549 : ℝ) / 100000000) = Real.log ((3152549 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3152549 : ℝ) / 100000000) = ((3152549 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_989 : RB (Real.log ((3221323 : ℝ) / 100000000)) ((-343537809 : ℝ) / 100000000) ((-343537803 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3221323 : ℝ) / 3125000)) (t := ((96323 : ℝ) / 6346323))
    (lo := ((1517893 : ℝ) / 50000000)) (hi := ((3035787 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3221323 : ℝ) / 100000000) = Real.log ((3221323 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3221323 : ℝ) / 100000000) = ((3221323 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_990 : RB (Real.log ((34187397 : ℝ) / 50000000)) ((-19008297 : ℝ) / 50000000) ((-38016593 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((34187397 : ℝ) / 50000000)) (t := ((-15812603 : ℝ) / 84187397))
    (lo := ((-19008297 : ℝ) / 50000000)) (hi := ((-38016593 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_991 : RB (Real.log ((68376747 : ℝ) / 100000000)) ((-19006869 : ℝ) / 50000000) ((-38013737 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68376747 : ℝ) / 100000000)) (t := ((-31623253 : ℝ) / 168376747))
    (lo := ((-19006869 : ℝ) / 50000000)) (hi := ((-38013737 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_992 : RB (Real.log ((10156453 : ℝ) / 25000000)) ((-90076657 : ℝ) / 100000000) ((-18015331 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((10156453 : ℝ) / 12500000)) (t := ((-2343547 : ℝ) / 22656453))
    (lo := ((-10380969 : ℝ) / 50000000)) (hi := ((-20761937 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10156453 : ℝ) / 25000000) = Real.log ((10156453 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10156453 : ℝ) / 25000000) = ((10156453 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_993 : RB (Real.log ((38675411 : ℝ) / 20000000)) ((32973587 : ℝ) / 50000000) ((8243397 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((38675411 : ℝ) / 40000000)) (t := ((-1324589 : ℝ) / 78675411))
    (lo := ((-420943 : ℝ) / 12500000)) (hi := ((-3367543 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38675411 : ℝ) / 20000000) = Real.log ((38675411 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38675411 : ℝ) / 20000000) = ((38675411 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_994 : RB (Real.log ((19350817 : ℝ) / 10000000)) ((33007477 : ℝ) / 50000000) ((16503739 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((19350817 : ℝ) / 20000000)) (t := ((-649183 : ℝ) / 39350817))
    (lo := ((-824941 : ℝ) / 25000000)) (hi := ((-3299763 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19350817 : ℝ) / 10000000) = Real.log ((19350817 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((19350817 : ℝ) / 10000000) = ((19350817 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_995 : RB (Real.log ((17620729 : ℝ) / 25000000)) ((-2186249 : ℝ) / 6250000) ((-34979983 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17620729 : ℝ) / 25000000)) (t := ((-7379271 : ℝ) / 42620729))
    (lo := ((-2186249 : ℝ) / 6250000)) (hi := ((-34979983 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_996 : RB (Real.log ((35242447 : ℝ) / 50000000)) ((-34977177 : ℝ) / 100000000) ((-4372147 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((35242447 : ℝ) / 50000000)) (t := ((-14757553 : ℝ) / 85242447))
    (lo := ((-34977177 : ℝ) / 100000000)) (hi := ((-4372147 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_997 : RB (Real.log ((41360009 : ℝ) / 100000000)) ((-3531423 : ℝ) / 4000000) ((-88285573 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41360009 : ℝ) / 50000000)) (t := ((-8639991 : ℝ) / 91360009))
    (lo := ((-2371357 : ℝ) / 12500000)) (hi := ((-3794171 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41360009 : ℝ) / 100000000) = Real.log ((41360009 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41360009 : ℝ) / 100000000) = ((41360009 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_998 : RB (Real.log ((215309919 : ℝ) / 50000000)) ((73002773 : ℝ) / 50000000) ((146005549 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((215309919 : ℝ) / 200000000)) (t := ((15309919 : ℝ) / 415309919))
    (lo := ((737611 : ℝ) / 10000000)) (hi := ((7376111 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((215309919 : ℝ) / 50000000) = Real.log ((215309919 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((215309919 : ℝ) / 50000000) = ((215309919 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_999 : RB (Real.log ((53827959 : ℝ) / 12500000)) ((146006437 : ℝ) / 100000000) ((3650161 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((53827959 : ℝ) / 50000000)) (t := ((3827959 : ℝ) / 103827959))
    (lo := ((7377001 : ℝ) / 100000000)) (hi := ((3688501 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53827959 : ℝ) / 12500000) = Real.log ((53827959 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((53827959 : ℝ) / 12500000) = ((53827959 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1000 : RB (Real.log ((65118749 : ℝ) / 50000000)) ((528379 : ℝ) / 2000000) ((26418951 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65118749 : ℝ) / 50000000)) (t := ((15118749 : ℝ) / 115118749))
    (lo := ((528379 : ℝ) / 2000000)) (hi := ((26418951 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1001 : RB (Real.log ((213485301 : ℝ) / 50000000)) ((145154497 : ℝ) / 100000000) ((290309 : ℝ) / 200000) := by
  have hm := log_bounds_of_series (x := ((213485301 : ℝ) / 200000000)) (t := ((13485301 : ℝ) / 413485301))
    (lo := ((6525061 : ℝ) / 100000000)) (hi := ((3262531 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((213485301 : ℝ) / 50000000) = Real.log ((213485301 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((213485301 : ℝ) / 50000000) = ((213485301 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1002 : RB (Real.log ((213487197 : ℝ) / 50000000)) ((29031077 : ℝ) / 20000000) ((36288847 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((213487197 : ℝ) / 200000000)) (t := ((13487197 : ℝ) / 413487197))
    (lo := ((6525949 : ℝ) / 100000000)) (hi := ((130519 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((213487197 : ℝ) / 50000000) = Real.log ((213487197 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((213487197 : ℝ) / 50000000) = ((213487197 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1003 : RB (Real.log ((130574971 : ℝ) / 100000000)) ((3334717 : ℝ) / 12500000) ((26677737 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((130574971 : ℝ) / 100000000)) (t := ((30574971 : ℝ) / 230574971))
    (lo := ((3334717 : ℝ) / 12500000)) (hi := ((26677737 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1004 : RB (Real.log ((4412299 : ℝ) / 50000000)) ((-242762717 : ℝ) / 100000000) ((-242762713 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4412299 : ℝ) / 6250000)) (t := ((-1837701 : ℝ) / 10662299))
    (lo := ((-27202 : ℝ) / 78125)) (hi := ((-34818559 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4412299 : ℝ) / 50000000) = Real.log ((4412299 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4412299 : ℝ) / 50000000) = ((4412299 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1005 : RB (Real.log ((5413437 : ℝ) / 50000000)) ((-55578471 : ℝ) / 25000000) ((-5557847 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((5413437 : ℝ) / 6250000)) (t := ((-836563 : ℝ) / 11663437))
    (lo := ((-14369727 : ℝ) / 100000000)) (hi := ((-7184863 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5413437 : ℝ) / 50000000) = Real.log ((5413437 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5413437 : ℝ) / 50000000) = ((5413437 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1006 : RB (Real.log ((1608479 : ℝ) / 50000000)) ((-68734681 : ℝ) / 20000000) ((-343673399 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1608479 : ℝ) / 1562500)) (t := ((45979 : ℝ) / 3170979))
    (lo := ((290019 : ℝ) / 10000000)) (hi := ((2900191 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1608479 : ℝ) / 50000000) = Real.log ((1608479 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1608479 : ℝ) / 50000000) = ((1608479 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1007 : RB (Real.log ((3285821 : ℝ) / 100000000)) ((-341555369 : ℝ) / 100000000) ((-341555363 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3285821 : ℝ) / 3125000)) (t := ((160821 : ℝ) / 6410821))
    (lo := ((2509113 : ℝ) / 50000000)) (hi := ((5018227 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3285821 : ℝ) / 100000000) = Real.log ((3285821 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3285821 : ℝ) / 100000000) = ((3285821 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1008 : RB (Real.log ((68153191 : ℝ) / 100000000)) ((-38341221 : ℝ) / 100000000) ((-1917061 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((68153191 : ℝ) / 100000000)) (t := ((-31846809 : ℝ) / 168153191))
    (lo := ((-38341221 : ℝ) / 100000000)) (hi := ((-1917061 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1009 : RB (Real.log ((13631037 : ℝ) / 20000000)) ((-7667659 : ℝ) / 20000000) ((-19169147 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((13631037 : ℝ) / 20000000)) (t := ((-6368963 : ℝ) / 33631037))
    (lo := ((-7667659 : ℝ) / 20000000)) (hi := ((-19169147 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1010 : RB (Real.log ((40548269 : ℝ) / 100000000)) ((-90267711 : ℝ) / 100000000) ((-90267709 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40548269 : ℝ) / 50000000)) (t := ((-9451731 : ℝ) / 90548269))
    (lo := ((-654781 : ℝ) / 3125000)) (hi := ((-20952991 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40548269 : ℝ) / 100000000) = Real.log ((40548269 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40548269 : ℝ) / 100000000) = ((40548269 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1011 : RB (Real.log ((193245897 : ℝ) / 100000000)) ((32939663 : ℝ) / 50000000) ((2058729 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((193245897 : ℝ) / 200000000)) (t := ((-6754103 : ℝ) / 393245897))
    (lo := ((-26839 : ℝ) / 781250)) (hi := ((-3435391 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((193245897 : ℝ) / 100000000) = Real.log ((193245897 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((193245897 : ℝ) / 100000000) = ((193245897 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1012 : RB (Real.log ((193377059 : ℝ) / 100000000)) ((8243397 : ℝ) / 12500000) ((32973589 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((193377059 : ℝ) / 200000000)) (t := ((-6622941 : ℝ) / 393377059))
    (lo := ((-1683771 : ℝ) / 50000000)) (hi := ((-3367541 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((193377059 : ℝ) / 100000000) = Real.log ((193377059 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((193377059 : ℝ) / 100000000) = ((193377059 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1013 : RB (Real.log ((70219313 : ℝ) / 100000000)) ((-883867 : ℝ) / 2500000) ((-35354679 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70219313 : ℝ) / 100000000)) (t := ((-29780687 : ℝ) / 170219313))
    (lo := ((-883867 : ℝ) / 2500000)) (hi := ((-35354679 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1014 : RB (Real.log ((70221331 : ℝ) / 100000000)) ((-35351807 : ℝ) / 100000000) ((-17675903 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((70221331 : ℝ) / 100000000)) (t := ((-29778669 : ℝ) / 170221331))
    (lo := ((-35351807 : ℝ) / 100000000)) (hi := ((-17675903 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1015 : RB (Real.log ((20634947 : ℝ) / 50000000)) ((-88503693 : ℝ) / 100000000) ((-88503691 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20634947 : ℝ) / 25000000)) (t := ((-4365053 : ℝ) / 45634947))
    (lo := ((-9594487 : ℝ) / 50000000)) (hi := ((-19188973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20634947 : ℝ) / 50000000) = Real.log ((20634947 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20634947 : ℝ) / 50000000) = ((20634947 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1016 : RB (Real.log ((85876899 : ℝ) / 20000000)) ((72859129 : ℝ) / 50000000) ((145718261 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((85876899 : ℝ) / 80000000)) (t := ((5876899 : ℝ) / 165876899))
    (lo := ((3544411 : ℝ) / 50000000)) (hi := ((7088823 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85876899 : ℝ) / 20000000) = Real.log ((85876899 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((85876899 : ℝ) / 20000000) = ((85876899 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1017 : RB (Real.log ((429388401 : ℝ) / 100000000)) ((1138431 : ℝ) / 781250) ((145719171 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((429388401 : ℝ) / 400000000)) (t := ((29388401 : ℝ) / 829388401))
    (lo := ((1772433 : ℝ) / 25000000)) (hi := ((7089733 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((429388401 : ℝ) / 100000000) = Real.log ((429388401 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((429388401 : ℝ) / 100000000) = ((429388401 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1018 : RB (Real.log ((130350543 : ℝ) / 100000000)) ((1656607 : ℝ) / 6250000) ((26505713 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((130350543 : ℝ) / 100000000)) (t := ((30350543 : ℝ) / 230350543))
    (lo := ((1656607 : ℝ) / 6250000)) (hi := ((26505713 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1019 : RB (Real.log ((425779941 : ℝ) / 100000000)) ((28975049 : ℝ) / 20000000) ((9054703 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((425779941 : ℝ) / 400000000)) (t := ((25779941 : ℝ) / 825779941))
    (lo := ((6245809 : ℝ) / 100000000)) (hi := ((624581 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425779941 : ℝ) / 100000000) = Real.log ((425779941 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((425779941 : ℝ) / 100000000) = ((425779941 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1020 : RB (Real.log ((106445951 : ℝ) / 25000000)) ((18109519 : ℝ) / 12500000) ((28975231 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((106445951 : ℝ) / 100000000)) (t := ((6445951 : ℝ) / 206445951))
    (lo := ((1561679 : ℝ) / 25000000)) (hi := ((6246717 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((106445951 : ℝ) / 25000000) = Real.log ((106445951 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((106445951 : ℝ) / 25000000) = ((106445951 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1021 : RB (Real.log ((130686353 : ℝ) / 100000000)) ((26763001 : ℝ) / 100000000) ((13381501 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((130686353 : ℝ) / 100000000)) (t := ((30686353 : ℝ) / 230686353))
    (lo := ((26763001 : ℝ) / 100000000)) (hi := ((13381501 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1022 : RB (Real.log ((1791993 : ℝ) / 20000000)) ((-24124039 : ℝ) / 10000000) ((-120620193 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1791993 : ℝ) / 2500000)) (t := ((-708007 : ℝ) / 4291993))
    (lo := ((-33296233 : ℝ) / 100000000)) (hi := ((-4162029 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1791993 : ℝ) / 20000000) = Real.log ((1791993 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((1791993 : ℝ) / 20000000) = ((1791993 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1023 : RB (Real.log ((10934469 : ℝ) / 100000000)) ((-221325013 : ℝ) / 100000000) ((-221325009 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10934469 : ℝ) / 12500000)) (t := ((-1565531 : ℝ) / 23434469))
    (lo := ((-1672607 : ℝ) / 12500000)) (hi := ((-2676171 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10934469 : ℝ) / 100000000) = Real.log ((10934469 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((10934469 : ℝ) / 100000000) = ((10934469 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1024 : RB (Real.log ((656273 : ℝ) / 20000000)) ((-170845537 : ℝ) / 50000000) ((-85422767 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((656273 : ℝ) / 625000)) (t := ((31273 : ℝ) / 1281273))
    (lo := ((4882521 : ℝ) / 100000000)) (hi := ((2441261 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((656273 : ℝ) / 20000000) = Real.log ((656273 : ℝ) / 625000) - 5 * Real.log 2 := by
    rw [show ((656273 : ℝ) / 20000000) = ((656273 : ℝ) / 625000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1025 : RB (Real.log ((41879 : ℝ) / 1250000)) ((-339611437 : ℝ) / 100000000) ((-339611431 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83758 : ℝ) / 78125)) (t := ((5633 : ℝ) / 161883))
    (lo := ((3481079 : ℝ) / 50000000)) (hi := ((6962159 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41879 : ℝ) / 1250000) = Real.log ((83758 : ℝ) / 78125) - 5 * Real.log 2 := by
    rw [show ((41879 : ℝ) / 1250000) = ((83758 : ℝ) / 78125) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1026 : RB (Real.log ((8491891 : ℝ) / 12500000)) ((-19330847 : ℝ) / 50000000) ((-38661693 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8491891 : ℝ) / 12500000)) (t := ((-4008109 : ℝ) / 20991891))
    (lo := ((-19330847 : ℝ) / 50000000)) (hi := ((-38661693 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1027 : RB (Real.log ((67937161 : ℝ) / 100000000)) ((-19329351 : ℝ) / 50000000) ((-38658701 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((67937161 : ℝ) / 100000000)) (t := ((-32062839 : ℝ) / 167937161))
    (lo := ((-19329351 : ℝ) / 50000000)) (hi := ((-38658701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1028 : RB (Real.log ((40471791 : ℝ) / 100000000)) ((-90456499 : ℝ) / 100000000) ((-90456497 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40471791 : ℝ) / 50000000)) (t := ((-9528209 : ℝ) / 90471791))
    (lo := ((-1057089 : ℝ) / 5000000)) (hi := ((-21141779 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40471791 : ℝ) / 100000000) = Real.log ((40471791 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40471791 : ℝ) / 100000000) = ((40471791 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1029 : RB (Real.log ((24139337 : ℝ) / 12500000)) ((6581141 : ℝ) / 10000000) ((16452853 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((24139337 : ℝ) / 25000000)) (t := ((-860663 : ℝ) / 49139337))
    (lo := ((-875827 : ℝ) / 25000000)) (hi := ((-3503307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24139337 : ℝ) / 12500000) = Real.log ((24139337 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((24139337 : ℝ) / 12500000) = ((24139337 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1030 : RB (Real.log ((193245903 : ℝ) / 100000000)) ((6587933 : ℝ) / 10000000) ((16469833 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((193245903 : ℝ) / 200000000)) (t := ((-6754097 : ℝ) / 393245903))
    (lo := ((-858847 : ℝ) / 25000000)) (hi := ((-3435387 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((193245903 : ℝ) / 100000000) = Real.log ((193245903 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((193245903 : ℝ) / 100000000) = ((193245903 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1031 : RB (Real.log ((69961531 : ℝ) / 100000000)) ((-17861233 : ℝ) / 50000000) ((-7144493 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((69961531 : ℝ) / 100000000)) (t := ((-30038469 : ℝ) / 169961531))
    (lo := ((-17861233 : ℝ) / 50000000)) (hi := ((-7144493 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1032 : RB (Real.log ((69963589 : ℝ) / 100000000)) ((-8929881 : ℝ) / 25000000) ((-35719523 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((69963589 : ℝ) / 100000000)) (t := ((-30036411 : ℝ) / 169963589))
    (lo := ((-8929881 : ℝ) / 25000000)) (hi := ((-35719523 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1033 : RB (Real.log ((41181529 : ℝ) / 100000000)) ((-88718037 : ℝ) / 100000000) ((-17743607 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((41181529 : ℝ) / 50000000)) (t := ((-8818471 : ℝ) / 91181529))
    (lo := ((-9701659 : ℝ) / 50000000)) (hi := ((-19403317 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41181529 : ℝ) / 100000000) = Real.log ((41181529 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41181529 : ℝ) / 100000000) = ((41181529 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1034 : RB (Real.log ((214082141 : ℝ) / 50000000)) ((145433677 : ℝ) / 100000000) ((1817921 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((214082141 : ℝ) / 200000000)) (t := ((14082141 : ℝ) / 414082141))
    (lo := ((6804241 : ℝ) / 100000000)) (hi := ((3402121 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((214082141 : ℝ) / 50000000) = Real.log ((214082141 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((214082141 : ℝ) / 50000000) = ((214082141 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1035 : RB (Real.log ((85633651 : ℝ) / 20000000)) ((29086921 : ℝ) / 20000000) ((9089663 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((85633651 : ℝ) / 80000000)) (t := ((5633651 : ℝ) / 165633651))
    (lo := ((6805169 : ℝ) / 100000000)) (hi := ((680517 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85633651 : ℝ) / 20000000) = Real.log ((85633651 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((85633651 : ℝ) / 20000000) = ((85633651 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1036 : RB (Real.log ((130463027 : ℝ) / 100000000)) ((830999 : ℝ) / 3125000) ((26591969 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((130463027 : ℝ) / 100000000)) (t := ((30463027 : ℝ) / 230463027))
    (lo := ((830999 : ℝ) / 3125000)) (hi := ((26591969 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1037 : RB (Real.log ((424603503 : ℝ) / 100000000)) ((144598561 : ℝ) / 100000000) ((36149641 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((424603503 : ℝ) / 400000000)) (t := ((24603503 : ℝ) / 824603503))
    (lo := ((47753 : ℝ) / 800000)) (hi := ((2984563 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((424603503 : ℝ) / 100000000) = Real.log ((424603503 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((424603503 : ℝ) / 100000000) = ((424603503 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1038 : RB (Real.log ((424607433 : ℝ) / 100000000)) ((72299743 : ℝ) / 50000000) ((144599489 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((424607433 : ℝ) / 400000000)) (t := ((24607433 : ℝ) / 824607433))
    (lo := ((119401 : ℝ) / 2000000)) (hi := ((5970051 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((424607433 : ℝ) / 100000000) = Real.log ((424607433 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((424607433 : ℝ) / 100000000) = ((424607433 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1039 : RB (Real.log ((26159439 : ℝ) / 20000000)) ((1342389 : ℝ) / 5000000) ((26847781 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((26159439 : ℝ) / 20000000)) (t := ((6159439 : ℝ) / 46159439))
    (lo := ((1342389 : ℝ) / 5000000)) (hi := ((26847781 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
