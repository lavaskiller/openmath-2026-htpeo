import LeanProject.Corollaries

/-!
# EP-1038, fixed degree 3: an integer certificate checker and its soundness (m₃ = 2)

Certificate data are integers at scale `S = 2^16`. A box is `[l_i/S, u_i/S]`, `i = 0,1,2`.
Leaves:
* `inf`  — the box misses `D = {r₀ ≤ r₁ ≤ r₂, r₀ + r₂ ≥ 0}`;
* `sig`  — the spread `max u - min l < S`; then `(μ-1, μ+1) ⊆ S(r)` by AM–GM (`spread_lemma`);
* `leaf` — ordered intervals `[a/S, b/S]` with `P(B, J) < 1` (Lemma 1.4) and total length `≥ 2`.
`check_sound`: if `check t bx = true` then every sorted `r` in the box with `r₀ + r₂ ≥ 0` has
`|S(r)| ≥ 2`.
-/

open Real MeasureTheory

namespace EP1038.N3

/-- The scale. -/
def S : ℤ := 65536

theorem S_pos : (0 : ℝ) < (S : ℝ) := by norm_num [S]

/-- Certificate trees. -/
inductive C3 where
  | split : Fin 3 → C3 → C3 → C3
  | inf : C3
  | sig : C3
  | leaf : List (ℤ × ℤ) → C3

/-- Integer boxes. -/
structure Box where
  l : Fin 3 → ℤ
  u : Fin 3 → ℤ

def Box.setU (b : Box) (d : Fin 3) (m : ℤ) : Box := ⟨b.l, fun i => if i = d then m else b.u i⟩
def Box.setL (b : Box) (d : Fin 3) (m : ℤ) : Box := ⟨fun i => if i = d then m else b.l i, b.u⟩

def pmax (a b l u : ℤ) : ℤ := max (max |a - l| |a - u|) (max |b - l| |b - u|)

def pval (bx : Box) (a b : ℤ) : ℤ :=
  pmax a b (bx.l 0) (bx.u 0) * pmax a b (bx.l 1) (bx.u 1) * pmax a b (bx.l 2) (bx.u 2)

def listOK (bx : Box) : ℤ → List (ℤ × ℤ) → Bool
  | _, [] => true
  | p, (a, b) :: rest =>
      decide (p ≤ a) && decide (a < b) && decide (pval bx a b < S ^ 3) && listOK bx b rest

def sumLen : List (ℤ × ℤ) → ℤ
  | [] => 0
  | (a, b) :: rest => (b - a) + sumLen rest

def check : C3 → Box → Bool
  | .split d t₁ t₂, bx =>
      check t₁ (bx.setU d ((bx.l d + bx.u d) / 2)) && check t₂ (bx.setL d ((bx.l d + bx.u d) / 2))
  | .inf, bx =>
      decide (bx.u 1 < bx.l 0) || decide (bx.u 2 < bx.l 0) || decide (bx.u 2 < bx.l 1) ||
        decide (bx.u 0 + bx.u 2 < 0)
  | .sig, bx =>
      decide (max (max (bx.u 0) (bx.u 1)) (bx.u 2) - min (min (bx.l 0) (bx.l 1)) (bx.l 2) < S)
  | .leaf ivs, bx => listOK bx (-2 * S) ivs && decide (2 * S ≤ sumLen ivs)

/-- `r` lies in the real box of `bx`. -/
def InBox (bx : Box) (r : Fin 3 → ℝ) : Prop :=
  ∀ i, ((bx.l i : ℤ) : ℝ) / S ≤ r i ∧ r i ≤ ((bx.u i : ℤ) : ℝ) / S

/-! ## The `sig` leaf: spread < 1 gives `|S(r)| ≥ 2` -/

theorem prod3_le {d₀ d₁ d₂ : ℝ} (h₀ : 0 ≤ d₀) (h₁ : 0 ≤ d₁) (h₂ : 0 ≤ d₂) :
    d₀ * d₁ * d₂ ≤ ((d₀ + d₁ + d₂) / 3) ^ 3 := by
  have := amgm_prod_le (n := 3) (by norm_num) ![d₀, d₁, d₂]
    (by intro i; fin_cases i <;> simp [h₀, h₁, h₂])
  simpa [Fin.prod_univ_three, Fin.sum_univ_three] using this

/-- If `r₀ ≤ r₁ ≤ r₂` and `r₂ - r₀ < 1`, then `(μ - 1, μ + 1) ⊆ S(r)`, hence `|S(r)| ≥ 2`. -/
theorem spread_lemma (r : Fin 3 → ℝ) (h01 : r 0 ≤ r 1) (h12 : r 1 ≤ r 2) (hw : r 2 - r 0 < 1) :
    ENNReal.ofReal 2 ≤ volume (sublevel r) := by
  set μ := (r 0 + r 1 + r 2) / 3 with hμ
  have hsub : Set.Ioo (μ - 1) (μ + 1) ⊆ sublevel r := by
    intro x hx
    obtain ⟨hx1, hx2⟩ := hx
    simp only [sublevel, Set.mem_setOf_eq, Fin.prod_univ_three]
    rcases le_or_gt (r 2) x with hr | hr
    · -- right of all roots
      have hp := prod3_le (sub_nonneg.mpr (by linarith : r 0 ≤ x)) (sub_nonneg.mpr (by linarith : r 1 ≤ x))
        (sub_nonneg.mpr hr)
      have hm : ((x - r 0) + (x - r 1) + (x - r 2)) / 3 = x - μ := by rw [hμ]; ring
      rw [hm] at hp
      have hxm : 0 ≤ x - μ := by rw [hμ]; linarith
      have hxm1 : x - μ < 1 := by linarith
      have hcube : (x - μ) ^ 3 < 1 := by
        calc (x - μ) ^ 3 ≤ (x - μ) ^ 1 := pow_le_pow_of_le_one hxm hxm1.le (by norm_num)
          _ < 1 := by simpa using hxm1
      rw [abs_of_nonneg (mul_nonneg (mul_nonneg (by linarith) (by linarith)) (by linarith))]
      linarith
    rcases le_or_gt x (r 0) with hl | hl
    · -- left of all roots
      have hp := prod3_le (sub_nonneg.mpr hl) (sub_nonneg.mpr (by linarith : x ≤ r 1))
        (sub_nonneg.mpr (by linarith : x ≤ r 2))
      have hm : ((r 0 - x) + (r 1 - x) + (r 2 - x)) / 3 = μ - x := by rw [hμ]; ring
      rw [hm] at hp
      have hxm : 0 ≤ μ - x := by rw [hμ]; linarith
      have hxm1 : μ - x < 1 := by linarith
      have hcube : (μ - x) ^ 3 < 1 := by
        calc (μ - x) ^ 3 ≤ (μ - x) ^ 1 := pow_le_pow_of_le_one hxm hxm1.le (by norm_num)
          _ < 1 := by simpa using hxm1
      have heq : |(x - r 0) * (x - r 1) * (x - r 2)| = (r 0 - x) * (r 1 - x) * (r 2 - x) := by
        rw [abs_of_nonpos (by
          have h1 : x - r 0 ≤ 0 := by linarith
          have h2 : 0 ≤ (x - r 1) * (x - r 2) := mul_nonneg_of_nonpos_of_nonpos (by linarith) (by linarith)
          nlinarith)]
        ring
      rw [heq]; linarith
    · -- between the extreme roots: the three distances sum to at most 2 (r₂ - r₀) < 2
      have hd : |x - r 0| + |x - r 1| + |x - r 2| ≤ 2 * (r 2 - r 0) := by
        rw [abs_of_pos (by linarith : 0 < x - r 0), abs_of_neg (by linarith : x - r 2 < 0)]
        rcases le_total (r 1) x with h | h
        · rw [abs_of_nonneg (by linarith : 0 ≤ x - r 1)]; linarith
        · rw [abs_of_nonpos (by linarith : x - r 1 ≤ 0)]; linarith
      have hp := prod3_le (abs_nonneg (x - r 0)) (abs_nonneg (x - r 1)) (abs_nonneg (x - r 2))
      have hsum : (|x - r 0| + |x - r 1| + |x - r 2|) / 3 < 2 / 3 := by linarith
      have hnn : 0 ≤ (|x - r 0| + |x - r 1| + |x - r 2|) / 3 := by positivity
      have hc : ((|x - r 0| + |x - r 1| + |x - r 2|) / 3) ^ 3 < 1 := by
        calc ((|x - r 0| + |x - r 1| + |x - r 2|) / 3) ^ 3 ≤ (2 / 3) ^ 3 := by gcongr
          _ < 1 := by norm_num
      rw [abs_mul, abs_mul]
      linarith
  calc ENNReal.ofReal 2 = volume (Set.Ioo (μ - 1) (μ + 1)) := by
        rw [Real.volume_Ioo]; congr 1; ring
    _ ≤ volume (sublevel r) := measure_mono hsub

/-! ## The `leaf` case -/

theorem pmax_real (a b l u : ℤ) :
    ((pmax a b l u : ℤ) : ℝ) / S =
      max (max |(a : ℝ) / S - (l : ℝ) / S| |(a : ℝ) / S - (u : ℝ) / S|)
        (max |(b : ℝ) / S - (l : ℝ) / S| |(b : ℝ) / S - (u : ℝ) / S|) := by
  have hS := S_pos
  have key : ∀ p q : ℤ, |(p : ℝ) / S - (q : ℝ) / S| = ((|p - q| : ℤ) : ℝ) / S := by
    intro p q
    rw [← sub_div, abs_div, abs_of_pos hS]; push_cast; rfl
  rw [key, key, key, key]
  unfold pmax
  push_cast
  rw [max_div_div_right hS.le, max_div_div_right hS.le, max_div_div_right hS.le]

theorem leaf_interval (bx : Box) (r : Fin 3 → ℝ) (hr : InBox bx r) (a b : ℤ)
    (hP : pval bx a b < S ^ 3) :
    Set.Ioo ((a : ℝ) / S) ((b : ℝ) / S) ⊆ sublevel r := by
  intro x hx
  have hS := S_pos
  have hb := rect_prod_le (fun i => ((bx.l i : ℤ) : ℝ) / S) (fun i => ((bx.u i : ℤ) : ℝ) / S) r
    (fun i => hr i) (Set.Ioo_subset_Icc_self hx)
  have hP' : ((pval bx a b : ℤ) : ℝ) / (S : ℝ) ^ 3 < 1 := by
    rw [div_lt_one (by positivity)]; exact_mod_cast hP
  have hval : ((pval bx a b : ℤ) : ℝ) / (S : ℝ) ^ 3 =
      ∏ i : Fin 3, max (max |(a : ℝ) / S - ((bx.l i : ℤ) : ℝ) / S| |(a : ℝ) / S - ((bx.u i : ℤ) : ℝ) / S|)
        (max |(b : ℝ) / S - ((bx.l i : ℤ) : ℝ) / S| |(b : ℝ) / S - ((bx.u i : ℤ) : ℝ) / S|) := by
    rw [Fin.prod_univ_three, ← pmax_real, ← pmax_real, ← pmax_real]
    unfold pval; push_cast; ring
  simp only [sublevel, Set.mem_setOf_eq]
  linarith [hval ▸ hP']

theorem listOK_sound (bx : Box) (r : Fin 3 → ℝ) (hr : InBox bx r) :
    ∀ (ivs : List (ℤ × ℤ)) (p : ℤ), listOK bx p ivs = true →
      ENNReal.ofReal ((sumLen ivs : ℝ) / S) ≤ volume (sublevel r ∩ Set.Ici ((p : ℝ) / S)) := by
  have hS := S_pos
  intro ivs
  induction ivs with
  | nil => intro p _; simp [sumLen]
  | cons ab rest ih =>
    intro p h
    obtain ⟨a, b⟩ := ab
    simp only [listOK, Bool.and_eq_true, decide_eq_true_eq] at h
    obtain ⟨⟨⟨hpa, hab⟩, hP⟩, hrest⟩ := h
    have hI : Set.Ioo ((a : ℝ) / S) ((b : ℝ) / S) ⊆ sublevel r ∩ Set.Ici ((p : ℝ) / S) := by
      intro x hx
      refine ⟨leaf_interval bx r hr a b hP hx, ?_⟩
      have : (p : ℝ) / S ≤ (a : ℝ) / S := by
        apply div_le_div_of_nonneg_right _ hS.le; exact_mod_cast hpa
      exact le_trans this hx.1.le
    have hR : sublevel r ∩ Set.Ici ((b : ℝ) / S) ⊆ sublevel r ∩ Set.Ici ((p : ℝ) / S) := by
      intro x ⟨hx1, hx2⟩
      refine ⟨hx1, ?_⟩
      have : (p : ℝ) / S ≤ (b : ℝ) / S := by
        apply div_le_div_of_nonneg_right _ hS.le; exact_mod_cast (le_of_lt (lt_of_le_of_lt hpa hab))
      exact le_trans this hx2
    have hdisj : Disjoint (Set.Ioo ((a : ℝ) / S) ((b : ℝ) / S)) (sublevel r ∩ Set.Ici ((b : ℝ) / S)) := by
      rw [Set.disjoint_left]
      rintro x ⟨_, hx⟩ ⟨_, hx'⟩
      exact absurd (lt_of_lt_of_le hx (Set.mem_Ici.mp hx')) (lt_irrefl _)
    calc ENNReal.ofReal ((sumLen ((a, b) :: rest) : ℝ) / S)
        = ENNReal.ofReal (((b : ℝ) / S - (a : ℝ) / S) + (sumLen rest : ℝ) / S) := by
          congr 1; simp only [sumLen]; push_cast; ring
      _ ≤ ENNReal.ofReal ((b : ℝ) / S - (a : ℝ) / S) + ENNReal.ofReal ((sumLen rest : ℝ) / S) :=
          ENNReal.ofReal_add_le
      _ ≤ volume (Set.Ioo ((a : ℝ) / S) ((b : ℝ) / S)) + volume (sublevel r ∩ Set.Ici ((b : ℝ) / S)) := by
          gcongr
          · rw [Real.volume_Ioo]
          · exact ih b hrest
      _ = volume (Set.Ioo ((a : ℝ) / S) ((b : ℝ) / S) ∪ (sublevel r ∩ Set.Ici ((b : ℝ) / S))) :=
          (measure_union' hdisj measurableSet_Ioo).symm
      _ ≤ volume (sublevel r ∩ Set.Ici ((p : ℝ) / S)) := measure_mono (Set.union_subset hI hR)

/-! ## Soundness of the checker -/

theorem div_S_lt {p q : ℤ} (h : p < q) : (p : ℝ) / S < (q : ℝ) / S :=
  div_lt_div_of_pos_right (by exact_mod_cast h) S_pos

theorem check_sound : ∀ (t : C3) (bx : Box), check t bx = true → ∀ r : Fin 3 → ℝ, InBox bx r →
    r 0 ≤ r 1 → r 1 ≤ r 2 → 0 ≤ r 0 + r 2 → ENNReal.ofReal 2 ≤ volume (sublevel r) := by
  have hS := S_pos
  intro t
  induction t with
  | split d t₁ t₂ ih₁ ih₂ =>
    intro bx h r hr h01 h12 hsum
    simp only [check, Bool.and_eq_true] at h
    rcases le_total (r d) ((((bx.l d + bx.u d) / 2 : ℤ) : ℝ) / S) with hd | hd
    · apply ih₁ _ h.1 r _ h01 h12 hsum
      intro i
      simp only [Box.setU]
      split_ifs with hi
      · subst hi; exact ⟨(hr _).1, hd⟩
      · exact hr i
    · apply ih₂ _ h.2 r _ h01 h12 hsum
      intro i
      simp only [Box.setL]
      split_ifs with hi
      · subst hi; exact ⟨hd, (hr _).2⟩
      · exact hr i
  | inf =>
    intro bx h r hr h01 h12 hsum
    simp only [check, Bool.or_eq_true, decide_eq_true_eq] at h
    exfalso
    rcases h with ((h | h) | h) | h
    · have := div_S_lt h; linarith [(hr 0).1, (hr 1).2]
    · have := div_S_lt h; linarith [(hr 0).1, (hr 2).2]
    · have := div_S_lt h; linarith [(hr 1).1, (hr 2).2]
    · have h' : ((bx.u 0 : ℤ) : ℝ) / S + ((bx.u 2 : ℤ) : ℝ) / S < 0 := by
        rw [← add_div]; apply div_neg_of_neg_of_pos _ hS; exact_mod_cast h
      linarith [(hr 0).2, (hr 2).2]
  | sig =>
    intro bx h r hr h01 h12 hsum
    simp only [check, decide_eq_true_eq] at h
    apply spread_lemma r h01 h12
    have hu : ((bx.u 2 : ℤ) : ℝ) ≤ ((max (max (bx.u 0) (bx.u 1)) (bx.u 2) : ℤ) : ℝ) := by
      exact_mod_cast le_max_right _ _
    have hl : ((min (min (bx.l 0) (bx.l 1)) (bx.l 2) : ℤ) : ℝ) ≤ ((bx.l 0 : ℤ) : ℝ) := by
      exact_mod_cast le_trans (min_le_left _ _) (min_le_left _ _)
    have hW : ((max (max (bx.u 0) (bx.u 1)) (bx.u 2) : ℤ) : ℝ) -
        ((min (min (bx.l 0) (bx.l 1)) (bx.l 2) : ℤ) : ℝ) < (S : ℝ) := by exact_mod_cast h
    have h2 : r 2 - r 0 ≤ (((bx.u 2 : ℤ) : ℝ) - ((bx.l 0 : ℤ) : ℝ)) / S := by
      rw [sub_div]; linarith [(hr 0).1, (hr 2).2]
    have h3 : (((bx.u 2 : ℤ) : ℝ) - ((bx.l 0 : ℤ) : ℝ)) / S < 1 := by
      rw [div_lt_one hS]; linarith
    linarith
  | leaf ivs =>
    intro bx h r hr h01 h12 hsum
    simp only [check, Bool.and_eq_true, decide_eq_true_eq] at h
    have hv := listOK_sound bx r hr ivs (-2 * S) h.1
    have h2 : (2 : ℝ) ≤ (sumLen ivs : ℝ) / S := by
      rw [le_div_iff₀ hS]; exact_mod_cast h.2
    calc ENNReal.ofReal 2 ≤ ENNReal.ofReal ((sumLen ivs : ℝ) / S) := ENNReal.ofReal_le_ofReal h2
      _ ≤ volume (sublevel r ∩ Set.Ici ((((-2 * S : ℤ)) : ℝ) / S)) := hv
      _ ≤ volume (sublevel r) := measure_mono Set.inter_subset_left

/-- The initial box `[-1,1]^3`. -/
def box0 : Box := ⟨fun _ => -S, fun _ => S⟩

theorem inBox0 (r : Fin 3 → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) : InBox box0 r := by
  intro i
  have hS := S_pos
  simp only [box0]
  push_cast
  rw [neg_div, div_self hS.ne']
  exact hr i

end EP1038.N3