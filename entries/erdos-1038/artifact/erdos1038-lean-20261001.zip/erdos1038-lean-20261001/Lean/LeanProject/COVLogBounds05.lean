import LeanProject.COVLogTwo
import LeanProject.COVLogBounds01
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_400 : RB (Real.log ((196120853 : ℝ) / 100000000)) ((67356087 : ℝ) / 100000000) ((67356089 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((196120853 : ℝ) / 200000000)) (t := ((-3879147 : ℝ) / 396120853))
    (lo := ((-1958631 : ℝ) / 100000000)) (hi := ((-195863 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((196120853 : ℝ) / 100000000) = Real.log ((196120853 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((196120853 : ℝ) / 100000000) = ((196120853 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_401 : RB (Real.log ((76641467 : ℝ) / 100000000)) ((-3325399 : ℝ) / 12500000) ((-26603191 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76641467 : ℝ) / 100000000)) (t := ((-23358533 : ℝ) / 176641467))
    (lo := ((-3325399 : ℝ) / 12500000)) (hi := ((-26603191 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_402 : RB (Real.log ((76642057 : ℝ) / 100000000)) ((-13301211 : ℝ) / 50000000) ((-26602421 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76642057 : ℝ) / 100000000)) (t := ((-23357943 : ℝ) / 176642057))
    (lo := ((-13301211 : ℝ) / 50000000)) (hi := ((-26602421 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_403 : RB (Real.log ((43393823 : ℝ) / 100000000)) ((-8348531 : ℝ) / 10000000) ((-20871327 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((43393823 : ℝ) / 50000000)) (t := ((-6606177 : ℝ) / 93393823))
    (lo := ((-14170591 : ℝ) / 100000000)) (hi := ((-1417059 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43393823 : ℝ) / 100000000) = Real.log ((43393823 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43393823 : ℝ) / 100000000) = ((43393823 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_404 : RB (Real.log ((458269689 : ℝ) / 100000000)) ((76114383 : ℝ) / 50000000) ((152228769 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((458269689 : ℝ) / 400000000)) (t := ((58269689 : ℝ) / 858269689))
    (lo := ((1359933 : ℝ) / 10000000)) (hi := ((13599331 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458269689 : ℝ) / 100000000) = Real.log ((458269689 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((458269689 : ℝ) / 100000000) = ((458269689 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_405 : RB (Real.log ((458270883 : ℝ) / 100000000)) ((76114513 : ℝ) / 50000000) ((152229029 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((458270883 : ℝ) / 400000000)) (t := ((58270883 : ℝ) / 858270883))
    (lo := ((1359959 : ℝ) / 10000000)) (hi := ((13599591 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458270883 : ℝ) / 100000000) = Real.log ((458270883 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((458270883 : ℝ) / 100000000) = ((458270883 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_406 : RB (Real.log ((63954569 : ℝ) / 50000000)) ((6153749 : ℝ) / 25000000) ((24614997 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63954569 : ℝ) / 50000000)) (t := ((13954569 : ℝ) / 113954569))
    (lo := ((6153749 : ℝ) / 25000000)) (hi := ((24614997 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_407 : RB (Real.log ((45587077 : ℝ) / 10000000)) ((75851959 : ℝ) / 50000000) ((151703921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45587077 : ℝ) / 40000000)) (t := ((5587077 : ℝ) / 85587077))
    (lo := ((6537241 : ℝ) / 50000000)) (hi := ((13074483 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45587077 : ℝ) / 10000000) = Real.log ((45587077 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((45587077 : ℝ) / 10000000) = ((45587077 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_408 : RB (Real.log ((113967989 : ℝ) / 25000000)) ((75852089 : ℝ) / 50000000) ((151704181 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((113967989 : ℝ) / 100000000)) (t := ((13967989 : ℝ) / 213967989))
    (lo := ((6537371 : ℝ) / 50000000)) (hi := ((13074743 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((113967989 : ℝ) / 25000000) = Real.log ((113967989 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((113967989 : ℝ) / 25000000) = ((113967989 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_409 : RB (Real.log ((128097273 : ℝ) / 100000000)) ((24761973 : ℝ) / 100000000) ((12380987 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((128097273 : ℝ) / 100000000)) (t := ((28097273 : ℝ) / 228097273))
    (lo := ((24761973 : ℝ) / 100000000)) (hi := ((12380987 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_410 : RB (Real.log ((7322421 : ℝ) / 100000000)) ((-130711461 : ℝ) / 50000000) ((-261422917 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7322421 : ℝ) / 6250000)) (t := ((1072421 : ℝ) / 13572421))
    (lo := ((7917977 : ℝ) / 50000000)) (hi := ((3167191 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7322421 : ℝ) / 100000000) = Real.log ((7322421 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7322421 : ℝ) / 100000000) = ((7322421 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_411 : RB (Real.log ((4259147 : ℝ) / 50000000)) ((-246295413 : ℝ) / 100000000) ((-246295409 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4259147 : ℝ) / 6250000)) (t := ((-1990853 : ℝ) / 10509147))
    (lo := ((-4793907 : ℝ) / 12500000)) (hi := ((-7670251 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4259147 : ℝ) / 50000000) = Real.log ((4259147 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4259147 : ℝ) / 50000000) = ((4259147 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_412 : RB (Real.log ((385887 : ℝ) / 20000000)) ((-394794303 : ℝ) / 100000000) ((-49349287 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((385887 : ℝ) / 312500)) (t := ((73387 : ℝ) / 698387))
    (lo := ((21094011 : ℝ) / 100000000)) (hi := ((5273503 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((385887 : ℝ) / 20000000) = Real.log ((385887 : ℝ) / 312500) - 6 * Real.log 2 := by
    rw [show ((385887 : ℝ) / 20000000) = ((385887 : ℝ) / 312500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_413 : RB (Real.log ((981479 : ℝ) / 50000000)) ((-393071773 : ℝ) / 100000000) ((-196535883 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((981479 : ℝ) / 781250)) (t := ((200229 : ℝ) / 1762729))
    (lo := ((22816541 : ℝ) / 100000000)) (hi := ((11408271 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((981479 : ℝ) / 50000000) = Real.log ((981479 : ℝ) / 781250) - 6 * Real.log 2 := by
    rw [show ((981479 : ℝ) / 50000000) = ((981479 : ℝ) / 781250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_414 : RB (Real.log ((75032667 : ℝ) / 100000000)) ((-28724661 : ℝ) / 100000000) ((-1436233 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((75032667 : ℝ) / 100000000)) (t := ((-24967333 : ℝ) / 175032667))
    (lo := ((-28724661 : ℝ) / 100000000)) (hi := ((-1436233 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_415 : RB (Real.log ((75033263 : ℝ) / 100000000)) ((-28723867 : ℝ) / 100000000) ((-14361933 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((75033263 : ℝ) / 100000000)) (t := ((-24966737 : ℝ) / 175033263))
    (lo := ((-28723867 : ℝ) / 100000000)) (hi := ((-14361933 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_416 : RB (Real.log ((1714949 : ℝ) / 4000000)) ((-84691103 : ℝ) / 100000000) ((-84691101 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1714949 : ℝ) / 2000000)) (t := ((-285051 : ℝ) / 3714949))
    (lo := ((-60064 : ℝ) / 390625)) (hi := ((-15376383 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1714949 : ℝ) / 4000000) = Real.log ((1714949 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((1714949 : ℝ) / 4000000) = ((1714949 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_417 : RB (Real.log ((48997659 : ℝ) / 25000000)) ((67289669 : ℝ) / 100000000) ((67289671 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((48997659 : ℝ) / 50000000)) (t := ((-1002341 : ℝ) / 98997659))
    (lo := ((-2025049 : ℝ) / 100000000)) (hi := ((-253131 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48997659 : ℝ) / 25000000) = Real.log ((48997659 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48997659 : ℝ) / 25000000) = ((48997659 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_418 : RB (Real.log ((24506969 : ℝ) / 12500000)) ((8415361 : ℝ) / 12500000) ((6732289 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((24506969 : ℝ) / 25000000)) (t := ((-493031 : ℝ) / 49506969))
    (lo := ((-199183 : ℝ) / 10000000)) (hi := ((-1991829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24506969 : ℝ) / 12500000) = Real.log ((24506969 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((24506969 : ℝ) / 12500000) = ((24506969 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_419 : RB (Real.log ((38206721 : ℝ) / 50000000)) ((-26901157 : ℝ) / 100000000) ((-6725289 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((38206721 : ℝ) / 50000000)) (t := ((-11793279 : ℝ) / 88206721))
    (lo := ((-26901157 : ℝ) / 100000000)) (hi := ((-6725289 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_420 : RB (Real.log ((38207021 : ℝ) / 50000000)) ((-6725093 : ℝ) / 25000000) ((-26900371 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38207021 : ℝ) / 50000000)) (t := ((-11792979 : ℝ) / 88207021))
    (lo := ((-6725093 : ℝ) / 25000000)) (hi := ((-26900371 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_421 : RB (Real.log ((2707553 : ℝ) / 6250000)) ((-4182681 : ℝ) / 5000000) ((-41826809 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2707553 : ℝ) / 3125000)) (t := ((-417447 : ℝ) / 5832553))
    (lo := ((-14338901 : ℝ) / 100000000)) (hi := ((-143389 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2707553 : ℝ) / 6250000) = Real.log ((2707553 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((2707553 : ℝ) / 6250000) = ((2707553 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_422 : RB (Real.log ((91492587 : ℝ) / 20000000)) ((152052567 : ℝ) / 100000000) ((15205257 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((91492587 : ℝ) / 80000000)) (t := ((11492587 : ℝ) / 171492587))
    (lo := ((13423131 : ℝ) / 100000000)) (hi := ((3355783 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91492587 : ℝ) / 20000000) = Real.log ((91492587 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((91492587 : ℝ) / 20000000) = ((91492587 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_423 : RB (Real.log ((457464151 : ℝ) / 100000000)) ((152052833 : ℝ) / 100000000) ((38013209 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((457464151 : ℝ) / 400000000)) (t := ((57464151 : ℝ) / 857464151))
    (lo := ((13423397 : ℝ) / 100000000)) (hi := ((6711699 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((457464151 : ℝ) / 100000000) = Real.log ((457464151 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((457464151 : ℝ) / 100000000) = ((457464151 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_424 : RB (Real.log ((127972031 : ℝ) / 100000000)) ((12332077 : ℝ) / 50000000) ((4932831 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((127972031 : ℝ) / 100000000)) (t := ((27972031 : ℝ) / 227972031))
    (lo := ((12332077 : ℝ) / 50000000)) (hi := ((4932831 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_425 : RB (Real.log ((455081623 : ℝ) / 100000000)) ((7576533 : ℝ) / 5000000) ((151530663 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((455081623 : ℝ) / 400000000)) (t := ((55081623 : ℝ) / 855081623))
    (lo := ((1612653 : ℝ) / 12500000)) (hi := ((516049 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((455081623 : ℝ) / 100000000) = Real.log ((455081623 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((455081623 : ℝ) / 100000000) = ((455081623 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_426 : RB (Real.log ((28442677 : ℝ) / 6250000)) ((75765463 : ℝ) / 50000000) ((151530929 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((28442677 : ℝ) / 25000000)) (t := ((3442677 : ℝ) / 53442677))
    (lo := ((1290149 : ℝ) / 10000000)) (hi := ((12901491 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28442677 : ℝ) / 6250000) = Real.log ((28442677 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((28442677 : ℝ) / 6250000) = ((28442677 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_427 : RB (Real.log ((64079811 : ℝ) / 50000000)) ((12405317 : ℝ) / 50000000) ((4962127 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((64079811 : ℝ) / 50000000)) (t := ((14079811 : ℝ) / 114079811))
    (lo := ((12405317 : ℝ) / 50000000)) (hi := ((4962127 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_428 : RB (Real.log ((3677401 : ℝ) / 50000000)) ((-3262271 : ℝ) / 1250000) ((-10439267 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((3677401 : ℝ) / 3125000)) (t := ((552401 : ℝ) / 6802401))
    (lo := ((4069299 : ℝ) / 25000000)) (hi := ((16277197 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3677401 : ℝ) / 50000000) = Real.log ((3677401 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((3677401 : ℝ) / 50000000) = ((3677401 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_429 : RB (Real.log ((4267383 : ℝ) / 50000000)) ((-61525557 : ℝ) / 25000000) ((-15381389 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((4267383 : ℝ) / 6250000)) (t := ((-1982617 : ℝ) / 10517383))
    (lo := ((-38158071 : ℝ) / 100000000)) (hi := ((-3815807 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4267383 : ℝ) / 50000000) = Real.log ((4267383 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4267383 : ℝ) / 50000000) = ((4267383 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_430 : RB (Real.log ((39233 : ℝ) / 2000000)) ((-393138429 : ℝ) / 100000000) ((-196569211 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39233 : ℝ) / 31250)) (t := ((7983 : ℝ) / 70483))
    (lo := ((4549977 : ℝ) / 20000000)) (hi := ((11374943 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39233 : ℝ) / 2000000) = Real.log ((39233 : ℝ) / 31250) - 6 * Real.log 2 := by
    rw [show ((39233 : ℝ) / 2000000) = ((39233 : ℝ) / 31250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_431 : RB (Real.log ((399039 : ℝ) / 20000000)) ((-195721423 : ℝ) / 50000000) ((-391442839 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((399039 : ℝ) / 312500)) (t := ((86539 : ℝ) / 711539))
    (lo := ((6111367 : ℝ) / 25000000)) (hi := ((24445469 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((399039 : ℝ) / 20000000) = Real.log ((399039 : ℝ) / 312500) - 6 * Real.log 2 := by
    rw [show ((399039 : ℝ) / 20000000) = ((399039 : ℝ) / 312500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_432 : RB (Real.log ((37416653 : ℝ) / 50000000)) ((-14495357 : ℝ) / 50000000) ((-28990713 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37416653 : ℝ) / 50000000)) (t := ((-12583347 : ℝ) / 87416653))
    (lo := ((-14495357 : ℝ) / 50000000)) (hi := ((-28990713 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_433 : RB (Real.log ((7483391 : ℝ) / 10000000)) ((-28989907 : ℝ) / 100000000) ((-14494953 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((7483391 : ℝ) / 10000000)) (t := ((-2516609 : ℝ) / 17483391))
    (lo := ((-28989907 : ℝ) / 100000000)) (hi := ((-14494953 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_434 : RB (Real.log ((42808781 : ℝ) / 100000000)) ((-10605337 : ℝ) / 12500000) ((-42421347 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42808781 : ℝ) / 50000000)) (t := ((-7191219 : ℝ) / 92808781))
    (lo := ((-15527977 : ℝ) / 100000000)) (hi := ((-1940997 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42808781 : ℝ) / 100000000) = Real.log ((42808781 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42808781 : ℝ) / 100000000) = ((42808781 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_435 : RB (Real.log ((39185103 : ℝ) / 20000000)) ((67256437 : ℝ) / 100000000) ((67256439 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39185103 : ℝ) / 40000000)) (t := ((-814897 : ℝ) / 79185103))
    (lo := ((-2058281 : ℝ) / 100000000)) (hi := ((-51457 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39185103 : ℝ) / 20000000) = Real.log ((39185103 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39185103 : ℝ) / 20000000) = ((39185103 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_436 : RB (Real.log ((195990643 : ℝ) / 100000000)) ((67289673 : ℝ) / 100000000) ((2691587 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((195990643 : ℝ) / 200000000)) (t := ((-4009357 : ℝ) / 395990643))
    (lo := ((-405009 : ℝ) / 20000000)) (hi := ((-506261 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195990643 : ℝ) / 100000000) = Real.log ((195990643 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195990643 : ℝ) / 100000000) = ((195990643 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_437 : RB (Real.log ((19047391 : ℝ) / 25000000)) ((-27194569 : ℝ) / 100000000) ((-3399321 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((19047391 : ℝ) / 25000000)) (t := ((-5952609 : ℝ) / 44047391))
    (lo := ((-27194569 : ℝ) / 100000000)) (hi := ((-3399321 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_438 : RB (Real.log ((76190173 : ℝ) / 100000000)) ((-2719377 : ℝ) / 10000000) ((-27193769 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((76190173 : ℝ) / 100000000)) (t := ((-23809827 : ℝ) / 176190173))
    (lo := ((-2719377 : ℝ) / 10000000)) (hi := ((-27193769 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_439 : RB (Real.log ((43249023 : ℝ) / 100000000)) ((-20954889 : ℝ) / 25000000) ((-41909777 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((43249023 : ℝ) / 50000000)) (t := ((-6750977 : ℝ) / 93249023))
    (lo := ((-14504837 : ℝ) / 100000000)) (hi := ((-3626209 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43249023 : ℝ) / 100000000) = Real.log ((43249023 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43249023 : ℝ) / 100000000) = ((43249023 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_440 : RB (Real.log ((45666211 : ℝ) / 10000000)) ((37969339 : ℝ) / 25000000) ((151877359 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45666211 : ℝ) / 40000000)) (t := ((5666211 : ℝ) / 85666211))
    (lo := ((165599 : ℝ) / 1250000)) (hi := ((13247921 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45666211 : ℝ) / 10000000) = Real.log ((45666211 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((45666211 : ℝ) / 10000000) = ((45666211 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_441 : RB (Real.log ((228331671 : ℝ) / 50000000)) ((75938813 : ℝ) / 50000000) ((151877629 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((228331671 : ℝ) / 200000000)) (t := ((28331671 : ℝ) / 428331671))
    (lo := ((1324819 : ℝ) / 10000000)) (hi := ((13248191 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((228331671 : ℝ) / 50000000) = Real.log ((228331671 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((228331671 : ℝ) / 50000000) = ((228331671 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_442 : RB (Real.log ((128034741 : ℝ) / 100000000)) ((4942629 : ℝ) / 20000000) ((12356573 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((128034741 : ℝ) / 100000000)) (t := ((28034741 : ℝ) / 228034741))
    (lo := ((4942629 : ℝ) / 20000000)) (hi := ((12356573 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_443 : RB (Real.log ((28393637 : ℝ) / 6250000)) ((3783959 : ℝ) / 2500000) ((151358363 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((28393637 : ℝ) / 25000000)) (t := ((3393637 : ℝ) / 53393637))
    (lo := ((3182231 : ℝ) / 25000000)) (hi := ((509157 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28393637 : ℝ) / 6250000) = Real.log ((28393637 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((28393637 : ℝ) / 6250000) = ((28393637 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_444 : RB (Real.log ((56787427 : ℝ) / 12500000)) ((15135863 : ℝ) / 10000000) ((151358633 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((56787427 : ℝ) / 50000000)) (t := ((6787427 : ℝ) / 106787427))
    (lo := ((6364597 : ℝ) / 50000000)) (hi := ((2545839 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((56787427 : ℝ) / 12500000) = Real.log ((56787427 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((56787427 : ℝ) / 12500000) = ((56787427 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_445 : RB (Real.log ((4006931 : ℝ) / 3125000)) ((6214783 : ℝ) / 25000000) ((24859133 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4006931 : ℝ) / 3125000)) (t := ((881931 : ℝ) / 7131931))
    (lo := ((6214783 : ℝ) / 25000000)) (hi := ((24859133 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_446 : RB (Real.log ((1847173 : ℝ) / 25000000)) ((-260521951 : ℝ) / 100000000) ((-130260973 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1847173 : ℝ) / 1562500)) (t := ((284673 : ℝ) / 3409673))
    (lo := ((669477 : ℝ) / 4000000)) (hi := ((8368463 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1847173 : ℝ) / 25000000) = Real.log ((1847173 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1847173 : ℝ) / 25000000) = ((1847173 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_447 : RB (Real.log ((4276549 : ℝ) / 50000000)) ((-122943833 : ℝ) / 50000000) ((-122943831 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4276549 : ℝ) / 6250000)) (t := ((-1973451 : ℝ) / 10526549))
    (lo := ((-37943509 : ℝ) / 100000000)) (hi := ((-9485877 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4276549 : ℝ) / 50000000) = Real.log ((4276549 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4276549 : ℝ) / 50000000) = ((4276549 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_448 : RB (Real.log ((1993867 : ℝ) / 100000000)) ((-97877357 : ℝ) / 25000000) ((-391509421 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1993867 : ℝ) / 1562500)) (t := ((431367 : ℝ) / 3556367))
    (lo := ((12189443 : ℝ) / 50000000)) (hi := ((24378887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1993867 : ℝ) / 100000000) = Real.log ((1993867 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1993867 : ℝ) / 100000000) = ((1993867 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_449 : RB (Real.log ((1013717 : ℝ) / 50000000)) ((-389839929 : ℝ) / 100000000) ((-194919961 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1013717 : ℝ) / 781250)) (t := ((232467 : ℝ) / 1794967))
    (lo := ((5209677 : ℝ) / 20000000)) (hi := ((13024193 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1013717 : ℝ) / 50000000) = Real.log ((1013717 : ℝ) / 781250) - 6 * Real.log 2 := by
    rw [show ((1013717 : ℝ) / 50000000) = ((1013717 : ℝ) / 781250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_450 : RB (Real.log ((37318673 : ℝ) / 50000000)) ((-29252919 : ℝ) / 100000000) ((-14626459 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((37318673 : ℝ) / 50000000)) (t := ((-12681327 : ℝ) / 87318673))
    (lo := ((-29252919 : ℝ) / 100000000)) (hi := ((-14626459 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_451 : RB (Real.log ((37318981 : ℝ) / 50000000)) ((-14626047 : ℝ) / 50000000) ((-29252093 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37318981 : ℝ) / 50000000)) (t := ((-12681019 : ℝ) / 87318981))
    (lo := ((-14626047 : ℝ) / 50000000)) (hi := ((-29252093 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_452 : RB (Real.log ((5343101 : ℝ) / 12500000)) ((-42496123 : ℝ) / 50000000) ((-21248061 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5343101 : ℝ) / 6250000)) (t := ((-906899 : ℝ) / 11593101))
    (lo := ((-15677527 : ℝ) / 100000000)) (hi := ((-7838763 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5343101 : ℝ) / 12500000) = Real.log ((5343101 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5343101 : ℝ) / 12500000) = ((5343101 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_453 : RB (Real.log ((195860383 : ℝ) / 100000000)) ((16805797 : ℝ) / 25000000) ((6722319 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((195860383 : ℝ) / 200000000)) (t := ((-4139617 : ℝ) / 395860383))
    (lo := ((-209153 : ℝ) / 10000000)) (hi := ((-2091529 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195860383 : ℝ) / 100000000) = Real.log ((195860383 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195860383 : ℝ) / 100000000) = ((195860383 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_454 : RB (Real.log ((97962761 : ℝ) / 50000000)) ((67256441 : ℝ) / 100000000) ((67256443 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((97962761 : ℝ) / 100000000)) (t := ((-2037239 : ℝ) / 197962761))
    (lo := ((-2058277 : ℝ) / 100000000)) (hi := ((-514569 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97962761 : ℝ) / 50000000) = Real.log ((97962761 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97962761 : ℝ) / 50000000) = ((97962761 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_455 : RB (Real.log ((75969723 : ℝ) / 100000000)) ((-27483531 : ℝ) / 100000000) ((-2748353 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((75969723 : ℝ) / 100000000)) (t := ((-24030277 : ℝ) / 175969723))
    (lo := ((-27483531 : ℝ) / 100000000)) (hi := ((-2748353 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_456 : RB (Real.log ((9496293 : ℝ) / 12500000)) ((-13741357 : ℝ) / 50000000) ((-27482713 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9496293 : ℝ) / 12500000)) (t := ((-3003707 : ℝ) / 21996293))
    (lo := ((-13741357 : ℝ) / 50000000)) (hi := ((-27482713 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_457 : RB (Real.log ((43178323 : ℝ) / 100000000)) ((-83983161 : ℝ) / 100000000) ((-83983159 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43178323 : ℝ) / 50000000)) (t := ((-6821677 : ℝ) / 93178323))
    (lo := ((-7334221 : ℝ) / 50000000)) (hi := ((-14668441 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43178323 : ℝ) / 100000000) = Real.log ((43178323 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((43178323 : ℝ) / 100000000) = ((43178323 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_458 : RB (Real.log ((56983391 : ℝ) / 12500000)) ((151703119 : ℝ) / 100000000) ((75851561 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((56983391 : ℝ) / 50000000)) (t := ((6983391 : ℝ) / 106983391))
    (lo := ((13073683 : ℝ) / 100000000)) (hi := ((3268421 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((56983391 : ℝ) / 12500000) = Real.log ((56983391 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((56983391 : ℝ) / 12500000) = ((56983391 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_459 : RB (Real.log ((227934191 : ℝ) / 50000000)) ((75851697 : ℝ) / 50000000) ((151703397 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((227934191 : ℝ) / 200000000)) (t := ((27934191 : ℝ) / 427934191))
    (lo := ((6536979 : ℝ) / 50000000)) (hi := ((13073959 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((227934191 : ℝ) / 50000000) = Real.log ((227934191 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((227934191 : ℝ) / 50000000) = ((227934191 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_460 : RB (Real.log ((12809727 : ℝ) / 10000000)) ((24761971 : ℝ) / 100000000) ((6190493 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((12809727 : ℝ) / 10000000)) (t := ((2809727 : ℝ) / 22809727))
    (lo := ((24761971 : ℝ) / 100000000)) (hi := ((6190493 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_461 : RB (Real.log ((90704081 : ℝ) / 20000000)) ((151187007 : ℝ) / 100000000) ((15118701 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((90704081 : ℝ) / 80000000)) (t := ((10704081 : ℝ) / 170704081))
    (lo := ((12557571 : ℝ) / 100000000)) (hi := ((3139393 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((90704081 : ℝ) / 20000000) = Real.log ((90704081 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((90704081 : ℝ) / 20000000) = ((90704081 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_462 : RB (Real.log ((453521651 : ℝ) / 100000000)) ((75593641 : ℝ) / 50000000) ((30237457 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((453521651 : ℝ) / 400000000)) (t := ((53521651 : ℝ) / 853521651))
    (lo := ((6278923 : ℝ) / 50000000)) (hi := ((12557847 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((453521651 : ℝ) / 100000000) = Real.log ((453521651 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((453521651 : ℝ) / 100000000) = ((453521651 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_463 : RB (Real.log ((16035473 : ℝ) / 12500000)) ((6226867 : ℝ) / 25000000) ((24907469 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16035473 : ℝ) / 12500000)) (t := ((3535473 : ℝ) / 28535473))
    (lo := ((6226867 : ℝ) / 25000000)) (hi := ((24907469 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_464 : RB (Real.log ((928003 : ℝ) / 12500000)) ((-2600449 : ℝ) / 1000000) ((-52008979 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((928003 : ℝ) / 781250)) (t := ((146753 : ℝ) / 1709253))
    (lo := ((2151747 : ℝ) / 12500000)) (hi := ((17213977 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((928003 : ℝ) / 12500000) = Real.log ((928003 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((928003 : ℝ) / 12500000) = ((928003 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_465 : RB (Real.log ((4286623 : ℝ) / 50000000)) ((-12282619 : ℝ) / 5000000) ((-30706547 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4286623 : ℝ) / 6250000)) (t := ((-1963377 : ℝ) / 10536623))
    (lo := ((-37708223 : ℝ) / 100000000)) (hi := ((-18854111 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4286623 : ℝ) / 50000000) = Real.log ((4286623 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4286623 : ℝ) / 50000000) = ((4286623 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_466 : RB (Real.log ((2026081 : ℝ) / 100000000)) ((-194953343 : ℝ) / 50000000) ((-389906679 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2026081 : ℝ) / 1562500)) (t := ((463581 : ℝ) / 3588581))
    (lo := ((6495407 : ℝ) / 25000000)) (hi := ((25981629 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2026081 : ℝ) / 100000000) = Real.log ((2026081 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((2026081 : ℝ) / 100000000) = ((2026081 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_467 : RB (Real.log ((2059671 : ℝ) / 100000000)) ((-388262399 : ℝ) / 100000000) ((-48532799 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((2059671 : ℝ) / 1562500)) (t := ((497171 : ℝ) / 3622171))
    (lo := ((5525183 : ℝ) / 20000000)) (hi := ((6906479 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2059671 : ℝ) / 100000000) = Real.log ((2059671 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((2059671 : ℝ) / 100000000) = ((2059671 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_468 : RB (Real.log ((74444703 : ℝ) / 100000000)) ((-14755679 : ℝ) / 50000000) ((-29511357 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74444703 : ℝ) / 100000000)) (t := ((-25555297 : ℝ) / 174444703))
    (lo := ((-14755679 : ℝ) / 50000000)) (hi := ((-29511357 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_469 : RB (Real.log ((74445327 : ℝ) / 100000000)) ((-737763 : ℝ) / 2500000) ((-29510519 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74445327 : ℝ) / 100000000)) (t := ((-25554673 : ℝ) / 174445327))
    (lo := ((-737763 : ℝ) / 2500000)) (hi := ((-29510519 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_470 : RB (Real.log ((5335223 : ℝ) / 12500000)) ((-42569899 : ℝ) / 50000000) ((-21284949 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5335223 : ℝ) / 6250000)) (t := ((-914777 : ℝ) / 11585223))
    (lo := ((-15825079 : ℝ) / 100000000)) (hi := ((-7912539 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5335223 : ℝ) / 12500000) = Real.log ((5335223 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5335223 : ℝ) / 12500000) = ((5335223 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_471 : RB (Real.log ((195795241 : ℝ) / 100000000)) ((67189923 : ℝ) / 100000000) ((2687597 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((195795241 : ℝ) / 200000000)) (t := ((-4204759 : ℝ) / 395795241))
    (lo := ((-424959 : ℝ) / 20000000)) (hi := ((-1062397 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195795241 : ℝ) / 100000000) = Real.log ((195795241 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195795241 : ℝ) / 100000000) = ((195795241 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_472 : RB (Real.log ((195860389 : ℝ) / 100000000)) ((67223191 : ℝ) / 100000000) ((67223193 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((195860389 : ℝ) / 200000000)) (t := ((-4139611 : ℝ) / 395860389))
    (lo := ((-2091527 : ℝ) / 100000000)) (hi := ((-1045763 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195860389 : ℝ) / 100000000) = Real.log ((195860389 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195860389 : ℝ) / 100000000) = ((195860389 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_473 : RB (Real.log ((3030153 : ℝ) / 4000000)) ((-44429 : ℝ) / 160000) ((-6942031 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((3030153 : ℝ) / 4000000)) (t := ((-969847 : ℝ) / 7030153))
    (lo := ((-44429 : ℝ) / 160000)) (hi := ((-6942031 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_474 : RB (Real.log ((75754453 : ℝ) / 100000000)) ((-108466 : ℝ) / 390625) ((-5553459 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((75754453 : ℝ) / 100000000)) (t := ((-24245547 : ℝ) / 175754453))
    (lo := ((-108466 : ℝ) / 390625)) (hi := ((-5553459 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_475 : RB (Real.log ((1724349 : ℝ) / 4000000)) ((-84144479 : ℝ) / 100000000) ((-84144477 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1724349 : ℝ) / 2000000)) (t := ((-275651 : ℝ) / 3724349))
    (lo := ((-46343 : ℝ) / 312500)) (hi := ((-14829759 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1724349 : ℝ) / 4000000) = Real.log ((1724349 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((1724349 : ℝ) / 4000000) = ((1724349 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_476 : RB (Real.log ((455077929 : ℝ) / 100000000)) ((18941231 : ℝ) / 12500000) ((151529851 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((455077929 : ℝ) / 400000000)) (t := ((55077929 : ℝ) / 855077929))
    (lo := ((3225103 : ℝ) / 25000000)) (hi := ((12900413 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((455077929 : ℝ) / 100000000) = Real.log ((455077929 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((455077929 : ℝ) / 100000000) = ((455077929 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_477 : RB (Real.log ((455079197 : ℝ) / 100000000)) ((151530127 : ℝ) / 100000000) ((15153013 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((455079197 : ℝ) / 400000000)) (t := ((55079197 : ℝ) / 855079197))
    (lo := ((12900691 : ℝ) / 100000000)) (hi := ((3225173 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((455079197 : ℝ) / 100000000) = Real.log ((455079197 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((455079197 : ℝ) / 100000000) = ((455079197 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_478 : RB (Real.log ((128159619 : ℝ) / 100000000)) ((3101329 : ℝ) / 12500000) ((24810633 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((128159619 : ℝ) / 100000000)) (t := ((28159619 : ℝ) / 228159619))
    (lo := ((3101329 : ℝ) / 12500000)) (hi := ((24810633 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_479 : RB (Real.log ((226374103 : ℝ) / 50000000)) ((75508297 : ℝ) / 50000000) ((151016597 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((226374103 : ℝ) / 200000000)) (t := ((26374103 : ℝ) / 426374103))
    (lo := ((6193579 : ℝ) / 50000000)) (hi := ((12387159 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((226374103 : ℝ) / 50000000) = Real.log ((226374103 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((226374103 : ℝ) / 50000000) = ((226374103 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
