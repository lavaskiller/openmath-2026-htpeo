import LeanProject.Supremum

/-!
# EP-1038: simultaneous component atomization and a universal lower bound (roadmap 15d, part 1)

* `conn`, `cls`, `cmean`: roots are connected when the segment between them lies in `S`; each root
  is replaced by the mean of its class (proof.md Lemma 7.2).
* `atom_ineq`, `sublevel_cmean_subset`: Jensen per class and double counting give
  `S(atomized) ⊆ S` (Lemma 7.2).
* `cmean_mem_Icc`, `sum_cmean`, `cmean_eq_of_uIcc`: roots stay in `[-1, 1]`, the mean is preserved,
  and each component of the new sublevel set carries one root value (Lemma 7.2).
* `sqrt2_clustered`: for a clustered configuration with mean `≤ 0`: the first point `r0 ∉ S` right
  of the minimal root `c0` satisfies `|f(r0)| = 1` and `r0 ≥ c0 + 1`; AM–GM at `r0` and the mean
  condition give `2a ≥ n` (`a` = multiplicity of `c0`, Lemma 7.4(iii)); the window
  `(c0 - (√2 - 1), c0 + 1) ⊆ S` (Lemma 7.6, and Lemma 7.3 after translation).
* `sqrt2_le`, `sqrt2_le_volume_le`: **every `p ∈ 𝒫` has `√2 ≤ |S_p| ≤ 2√2`**.
-/
open Real MeasureTheory Finset

namespace EP1038.Atom

variable {n : ℕ} (r : Fin n → ℝ)

theorem root_mem (i : Fin n) : r i ∈ sublevel r := by
  change |∏ j, (r i - r j)| < 1
  rw [Finset.prod_eq_zero (Finset.mem_univ i) (sub_self _), abs_zero]
  exact zero_lt_one

/-- Two roots are connected if the segment between them lies in `S`. -/
def conn (i j : Fin n) : Prop := Set.uIcc (r i) (r j) ⊆ sublevel r

theorem conn_refl (i : Fin n) : conn r i i := by
  intro x hx
  rw [Set.uIcc_self, Set.mem_singleton_iff] at hx
  rw [hx]; exact root_mem r i

theorem conn_symm {i j : Fin n} (h : conn r i j) : conn r j i := by
  intro x hx; rw [Set.uIcc_comm] at hx; exact h hx

theorem conn_trans {i j k : Fin n} (h1 : conn r i j) (h2 : conn r j k) : conn r i k :=
  (Set.uIcc_subset_uIcc_union_uIcc).trans (Set.union_subset h1 h2)

open Classical in
/-- The class of `i`. -/
noncomputable def cls (i : Fin n) : Finset (Fin n) := univ.filter (fun j => conn r i j)

theorem mem_cls {i j : Fin n} : j ∈ cls r i ↔ conn r i j := by
  classical
  simp [cls]

theorem self_mem_cls (i : Fin n) : i ∈ cls r i := (mem_cls r).mpr (conn_refl r i)

theorem cls_nonempty (i : Fin n) : (cls r i).Nonempty := ⟨i, self_mem_cls r i⟩

theorem cls_eq {i j : Fin n} (h : conn r i j) : cls r i = cls r j := by
  ext k
  rw [mem_cls, mem_cls]
  exact ⟨fun hk => conn_trans r (conn_symm r h) hk, fun hk => conn_trans r h hk⟩

/-- The class mean. -/
noncomputable def cmean (i : Fin n) : ℝ := (∑ j ∈ cls r i, r j) / (cls r i).card

theorem card_cls_pos (i : Fin n) : (0 : ℝ) < (cls r i).card := by
  exact_mod_cast (cls_nonempty r i).card_pos

/-- All roots of a class lie on one side of any point outside `S`. -/
theorem cls_side {i : Fin n} {x : ℝ} (hx : x ∉ sublevel r) :
    (∀ j ∈ cls r i, r j < x) ∨ (∀ j ∈ cls r i, x < r j) := by
  by_contra hc
  simp only [not_or, not_forall, not_lt, exists_prop] at hc
  obtain ⟨⟨j, hj, hj'⟩, ⟨k, hk, hk'⟩⟩ := hc
  have hjk : conn r j k := conn_trans r (conn_symm r ((mem_cls r).mp hj)) ((mem_cls r).mp hk)
  apply hx
  exact hjk (Set.mem_uIcc.mpr (Or.inr ⟨hk', hj'⟩))

/-- The class mean lies between two roots of the class, hence in `S`. -/
theorem cmean_mem (i : Fin n) : cmean r i ∈ sublevel r := by
  classical
  obtain ⟨jmin, hjmin, hmin⟩ := (cls r i).exists_min_image r (cls_nonempty r i)
  obtain ⟨jmax, hjmax, hmax⟩ := (cls r i).exists_max_image r (cls_nonempty r i)
  have hpos := card_cls_pos r i
  have h1 : r jmin ≤ cmean r i := by
    rw [cmean, le_div_iff₀ hpos]
    calc r jmin * (cls r i).card = ∑ _j ∈ cls r i, r jmin := by rw [sum_const, nsmul_eq_mul]; ring
      _ ≤ ∑ j ∈ cls r i, r j := sum_le_sum fun j hj => hmin j hj
  have h2 : cmean r i ≤ r jmax := by
    rw [cmean, div_le_iff₀ hpos]
    calc ∑ j ∈ cls r i, r j ≤ ∑ _j ∈ cls r i, r jmax := sum_le_sum fun j hj => hmax j hj
      _ = r jmax * (cls r i).card := by rw [sum_const, nsmul_eq_mul]; ring
  have hc : conn r jmin jmax :=
    conn_trans r (conn_symm r ((mem_cls r).mp hjmin)) ((mem_cls r).mp hjmax)
  exact hc (Set.mem_uIcc.mpr (Or.inl ⟨h1, h2⟩))

/-- Jensen on one class: `(1/|C|) ∑_{j ∈ C} log|x - r_j| ≤ log|x - mean_C|` for `x ∉ S`. -/
theorem log_jensen_cls (i : Fin n) {x : ℝ} (hx : x ∉ sublevel r) :
    ∑ j ∈ cls r i, (1 / ((cls r i).card : ℝ)) * Real.log |x - r j| ≤ Real.log |x - cmean r i| := by
  have hpos := card_cls_pos r i
  have hw0 : ∀ j ∈ cls r i, (0 : ℝ) ≤ 1 / ((cls r i).card : ℝ) := fun _ _ => by positivity
  have hw1 : ∑ _j ∈ cls r i, (1 / ((cls r i).card : ℝ)) = 1 := by
    rw [sum_const, nsmul_eq_mul]; field_simp
  have hcc := strictConcaveOn_log_Ioi.concaveOn
  rcases cls_side r (i := i) hx with hR | hL
  · -- all roots of the class are left of x
    have hmem : ∀ j ∈ cls r i, x - r j ∈ Set.Ioi (0 : ℝ) := fun j hj => sub_pos.mpr (hR j hj)
    have hj := hcc.le_map_sum hw0 hw1 hmem
    simp only [smul_eq_mul] at hj
    have e : ∑ j ∈ cls r i, 1 / ((cls r i).card : ℝ) * (x - r j) = x - cmean r i := by
      rw [← mul_sum, sum_sub_distrib, sum_const, nsmul_eq_mul, cmean]; field_simp
    rw [e] at hj
    have e2 : ∀ j ∈ cls r i, Real.log |x - r j| = Real.log (x - r j) := fun j hj' => by
      rw [abs_of_pos (sub_pos.mpr (hR j hj'))]
    have hcm : cmean r i < x := by
      have : x - cmean r i > 0 := by
        rw [← e]; apply sum_pos (fun j hj' => mul_pos (by positivity) (sub_pos.mpr (hR j hj')))
          (cls_nonempty r i)
      linarith
    rw [abs_of_pos (sub_pos.mpr hcm), sum_congr rfl fun j hj' => by rw [e2 j hj']]
    exact hj
  · -- all roots of the class are right of x
    have hmem : ∀ j ∈ cls r i, r j - x ∈ Set.Ioi (0 : ℝ) := fun j hj => sub_pos.mpr (hL j hj)
    have hj := hcc.le_map_sum hw0 hw1 hmem
    simp only [smul_eq_mul] at hj
    have e : ∑ j ∈ cls r i, 1 / ((cls r i).card : ℝ) * (r j - x) = cmean r i - x := by
      rw [← mul_sum, sum_sub_distrib, sum_const, nsmul_eq_mul, cmean]; field_simp
    rw [e] at hj
    have e2 : ∀ j ∈ cls r i, Real.log |x - r j| = Real.log (r j - x) := fun j hj' => by
      rw [abs_sub_comm, abs_of_pos (sub_pos.mpr (hL j hj'))]
    have hcm : x < cmean r i := by
      have : cmean r i - x > 0 := by
        rw [← e]; apply sum_pos (fun j hj' => mul_pos (by positivity) (sub_pos.mpr (hL j hj')))
          (cls_nonempty r i)
      linarith
    rw [abs_sub_comm, abs_of_pos (sub_pos.mpr hcm), sum_congr rfl fun j hj' => by rw [e2 j hj']]
    exact hj

/-- Double counting: `∑_i (1/|cls i|) ∑_{j ∈ cls i} g j = ∑_j g j`. -/
theorem double_count (g : Fin n → ℝ) :
    ∑ i, ∑ j ∈ cls r i, (1 / ((cls r i).card : ℝ)) * g j = ∑ j, g j := by
  classical
  have h1 : ∀ i, ∑ j ∈ cls r i, (1 / ((cls r i).card : ℝ)) * g j =
      ∑ j, if j ∈ cls r i then (1 / ((cls r i).card : ℝ)) * g j else 0 := fun i => by
    rw [Finset.sum_ite_mem, Finset.univ_inter]
  rw [Finset.sum_congr rfl (fun i _ => h1 i), Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  have hswap : ∀ i, (if j ∈ cls r i then (1 / ((cls r i).card : ℝ)) * g j else 0) =
      if i ∈ cls r j then (1 / ((cls r j).card : ℝ)) * g j else 0 := by
    intro i
    by_cases h : conn r i j
    · rw [if_pos ((mem_cls r).mpr h), if_pos ((mem_cls r).mpr (conn_symm r h)), cls_eq r h]
    · rw [if_neg (fun h' => h ((mem_cls r).mp h')),
        if_neg (fun h' => h (conn_symm r ((mem_cls r).mp h')))]
  rw [Finset.sum_congr rfl (fun i _ => hswap i), Finset.sum_ite_mem, Finset.univ_inter,
    Finset.sum_const, nsmul_eq_mul]
  have hpos := card_cls_pos r j
  field_simp

/-- **Atomization inequality** (Lemma 7.2): for `x ∉ S`,
`∑_j log|x - r_j| ≤ ∑_i log|x - mean(cls i)|`. -/
theorem atom_ineq {x : ℝ} (hx : x ∉ sublevel r) :
    ∑ j, Real.log |x - r j| ≤ ∑ i, Real.log |x - cmean r i| := by
  rw [← double_count r (fun j => Real.log |x - r j|)]
  exact Finset.sum_le_sum fun i _ => log_jensen_cls r i hx

/-- **Simultaneous component atomization** (Lemma 7.2): `S(cmean r) ⊆ S(r)`. -/
theorem sublevel_cmean_subset : sublevel (cmean r) ⊆ sublevel r := by
  intro x hx
  by_contra hxr
  have hne : ∀ j, x - r j ≠ 0 := fun j h => hxr (by rw [show x = r j by linarith]; exact root_mem r j)
  have hne' : ∀ i, x - cmean r i ≠ 0 := fun i h =>
    hxr (by rw [show x = cmean r i by linarith]; exact cmean_mem r i)
  have h1 : (1 : ℝ) ≤ |∏ j, (x - r j)| := not_lt.mp hxr
  have h2 : 0 ≤ ∑ j, Real.log |x - r j| := by
    rw [← Real.log_prod (fun j _ => abs_ne_zero.mpr (hne j)), ← Finset.abs_prod]
    exact Real.log_nonneg h1
  have h3 := (atom_ineq r hxr)
  have h4 : 0 ≤ Real.log |∏ i, (x - cmean r i)| := by
    rw [Finset.abs_prod, Real.log_prod (fun i _ => abs_ne_zero.mpr (hne' i))]; linarith
  have h5 : 1 ≤ |∏ i, (x - cmean r i)| := by
    by_contra h6
    push Not at h6
    have hp : 0 < |∏ i, (x - cmean r i)| := by
      rw [Finset.abs_prod]; exact Finset.prod_pos fun i _ => abs_pos.mpr (hne' i)
    have := Real.log_neg hp h6
    linarith
  exact absurd hx (not_lt.mpr h5)

/-- (P1) the class means stay in `[-1, 1]`. -/
theorem cmean_mem_Icc (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) (i : Fin n) :
    cmean r i ∈ Set.Icc (-1 : ℝ) 1 := by
  have hpos := card_cls_pos r i
  constructor
  · rw [cmean, le_div_iff₀ hpos]
    calc (-1 : ℝ) * (cls r i).card = ∑ _j ∈ cls r i, (-1 : ℝ) := by rw [sum_const, nsmul_eq_mul]; ring
      _ ≤ ∑ j ∈ cls r i, r j := sum_le_sum fun j _ => (hr j).1
  · rw [cmean, div_le_iff₀ hpos]
    calc ∑ j ∈ cls r i, r j ≤ ∑ _j ∈ cls r i, (1 : ℝ) := sum_le_sum fun j _ => (hr j).2
      _ = 1 * (cls r i).card := by rw [sum_const, nsmul_eq_mul]; ring

/-- (P2) the sum of the roots (hence the mean) is preserved. -/
theorem sum_cmean : ∑ i, cmean r i = ∑ i, r i := by
  rw [← double_count r r]
  apply Finset.sum_congr rfl
  intro i _
  rw [cmean, ← Finset.mul_sum]
  ring

/-- Every root of the class of `i` is connected to `cmean r i` inside `S(r)`. -/
theorem uIcc_root_cmean (i : Fin n) : Set.uIcc (r i) (cmean r i) ⊆ sublevel r := by
  classical
  obtain ⟨jmin, hjmin, hmin⟩ := (cls r i).exists_min_image r (cls_nonempty r i)
  obtain ⟨jmax, hjmax, hmax⟩ := (cls r i).exists_max_image r (cls_nonempty r i)
  have hpos := card_cls_pos r i
  have h1 : r jmin ≤ cmean r i := by
    rw [cmean, le_div_iff₀ hpos]
    calc r jmin * (cls r i).card = ∑ _j ∈ cls r i, r jmin := by rw [sum_const, nsmul_eq_mul]; ring
      _ ≤ ∑ j ∈ cls r i, r j := sum_le_sum fun j hj => hmin j hj
  have h2 : cmean r i ≤ r jmax := by
    rw [cmean, div_le_iff₀ hpos]
    calc ∑ j ∈ cls r i, r j ≤ ∑ _j ∈ cls r i, r jmax := sum_le_sum fun j hj => hmax j hj
      _ = r jmax * (cls r i).card := by rw [sum_const, nsmul_eq_mul]; ring
  have hc : conn r jmin jmax :=
    conn_trans r (conn_symm r ((mem_cls r).mp hjmin)) ((mem_cls r).mp hjmax)
  have hi1 : r jmin ≤ r i := hmin i (self_mem_cls r i)
  have hi2 : r i ≤ r jmax := hmax i (self_mem_cls r i)
  intro x hx
  apply hc
  rw [Set.mem_uIcc] at hx ⊢
  left
  rcases hx with ⟨a, b⟩ | ⟨a, b⟩ <;> constructor <;> linarith

/-- (P3) **one cluster per component**: if the segment between two class means lies in
`S(cmean r)`, the two means coincide. -/
theorem cmean_eq_of_uIcc {i j : Fin n}
    (h : Set.uIcc (cmean r i) (cmean r j) ⊆ sublevel (cmean r)) : cmean r i = cmean r j := by
  have h' : Set.uIcc (cmean r i) (cmean r j) ⊆ sublevel r := h.trans (sublevel_cmean_subset r)
  have hij : conn r i j := by
    have a1 := uIcc_root_cmean r i
    have a2 := uIcc_root_cmean r j
    rw [Set.uIcc_comm] at a2
    exact (Set.uIcc_subset_uIcc_union_uIcc).trans (Set.union_subset a1
      ((Set.uIcc_subset_uIcc_union_uIcc).trans (Set.union_subset h' a2)))
  rw [cmean, cmean, cls_eq r hij]

/-- Translation: `x ∈ S(s - c)` iff `x + c ∈ S(s)`. -/
theorem mem_sublevel_shift {n : ℕ} (s : Fin n → ℝ) (c x : ℝ) :
    x ∈ sublevel (fun i => s i - c) ↔ x + c ∈ sublevel s := by
  change |∏ i, (x - (s i - c))| < 1 ↔ |∏ i, (x + c - s i)| < 1
  have : ∏ i, (x - (s i - c)) = ∏ i, (x + c - s i) := by
    apply Finset.prod_congr rfl; intro i _; ring
  rw [this]

/-- **Lemma 7.4 + 7.6 for a clustered configuration**: if `s ∈ [-1,1]ⁿ`, `∑ s ≤ 0`, and every
component of `S(s)` contains one root value, then `|S(s)| ≥ √2`. -/
theorem sqrt2_clustered {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ)
    (hs : ∀ i, s i ∈ Set.Icc (-1 : ℝ) 1) (hsum : ∑ i, s i ≤ 0)
    (hcl : ∀ i j, Set.uIcc (s i) (s j) ⊆ sublevel s → s i = s j) :
    ENNReal.ofReal √2 ≤ volume (sublevel s) := by
  classical
  have hne : (univ : Finset (Fin n)).Nonempty := ⟨⟨0, hn⟩, mem_univ _⟩
  obtain ⟨i0, -, hmin⟩ := (univ : Finset (Fin n)).exists_min_image s hne
  set c0 := s i0 with hc0
  have hc0l : -1 ≤ c0 := (hs i0).1
  have hcle : ∀ i, c0 ≤ s i := fun i => hmin i (mem_univ i)
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hc0n : (n : ℝ) * c0 ≤ 0 := by
    calc (n : ℝ) * c0 = ∑ _i : Fin n, c0 := by simp
      _ ≤ ∑ i, s i := sum_le_sum fun i _ => hcle i
      _ ≤ 0 := hsum
  have hc00 : c0 ≤ 0 := by nlinarith
  -- orientation after translation: (c0, c0 + 1) ⊆ S
  have hIoo : Set.Ioo c0 (c0 + 1) ⊆ sublevel s := by
    have ht : ∀ i, (fun i => s i - (c0 + 1)) i ∈ Set.Icc (-1 : ℝ) 1 := fun i =>
      ⟨by linarith [hcle i], by linarith [(hs i).2]⟩
    have htsum : ∑ i, (fun i => s i - (c0 + 1)) i ≤ 0 := by
      simp only [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
        nsmul_eq_mul]
      nlinarith
    have h := Ioo_subset_sublevel hn _ ht htsum
    intro x hx
    have hx' : x - (c0 + 1) ∈ Set.Ioo (-1 : ℝ) 0 := ⟨by linarith [hx.1], by linarith [hx.2]⟩
    have := (mem_sublevel_shift s (c0 + 1) (x - (c0 + 1))).mp (h hx')
    rwa [sub_add_cancel] at this
  -- r0 = first point to the right of c0 outside S
  set T := (sublevel s)ᶜ ∩ Set.Ici c0 with hT
  have hTne : T.Nonempty := by
    refine ⟨2, ?_, by simp only [Set.mem_Ici]; linarith⟩
    intro h2
    have := sublevel_subset_Ioo s hs h2
    exact (lt_irrefl _ this.2)
  have hTbdd : BddBelow T := ⟨c0, fun y hy => hy.2⟩
  have hopenS : IsOpen (sublevel s) := isOpen_lt (continuous_absProd s) continuous_const
  have hTclosed : IsClosed T := hopenS.isClosed_compl.inter isClosed_Ici
  set r0 := sInf T with hr0
  have hr0T : r0 ∈ T := hTclosed.csInf_mem hTne hTbdd
  have hr0S : r0 ∉ sublevel s := hr0T.1
  have hbelow : ∀ y, c0 ≤ y → y < r0 → y ∈ sublevel s := by
    intro y hy1 hy2
    by_contra hy
    have := csInf_le hTbdd ⟨hy, hy1⟩
    linarith
  have hr0ge : c0 + 1 ≤ r0 := by
    by_contra hc
    push Not at hc
    have hr0c : c0 ≤ r0 := hr0T.2
    rcases hr0c.lt_or_eq with h | h
    · exact hr0S (hIoo ⟨h, hc⟩)
    · rw [← h] at hr0S; exact hr0S (root_mem s i0)
  -- |f(r0)| = 1
  have hf1 : |∏ i, (r0 - s i)| = 1 := by
    apply le_antisymm _ (not_lt.mp hr0S)
    by_contra hgt
    push Not at hgt
    have hopen : IsOpen {x : ℝ | 1 < |∏ i, (x - s i)|} :=
      isOpen_lt continuous_const (continuous_absProd s)
    obtain ⟨ε, hε, hball⟩ := Metric.isOpen_iff.mp hopen r0 hgt
    set y := r0 - min (ε / 2) (1 / 2) with hy
    have hy1 : c0 ≤ y := by
      have : min (ε / 2) (1 / 2) ≤ 1 / 2 := min_le_right _ _
      linarith
    have hy2 : y < r0 := by
      have : 0 < min (ε / 2) (1 / 2) := lt_min (by linarith) (by norm_num)
      linarith
    have hyball : y ∈ Metric.ball r0 ε := by
      rw [Metric.mem_ball, Real.dist_eq, abs_of_neg (by linarith)]
      have : min (ε / 2) (1 / 2) ≤ ε / 2 := min_le_left _ _
      linarith
    have h1 : 1 < |∏ i, (y - s i)| := hball hyball
    have h2 : |∏ i, (y - s i)| < 1 := hbelow y hy1 hy2
    linarith
  -- the other roots lie to the right of r0
  have hother : ∀ i, s i ≠ c0 → r0 < s i := by
    intro i hi
    by_contra hle
    push Not at hle
    rcases hle.lt_or_eq with h | h
    · apply hi
      symm
      apply hcl i0 i
      intro x hx
      rw [Set.uIcc_of_le (hcle i)] at hx
      exact hbelow x hx.1 (lt_of_le_of_lt hx.2 h)
    · rw [← h] at hr0S; exact hr0S (root_mem s i)
  -- counting: a roots at c0, m others; AM–GM at r0 gives 2a ≥ n
  set A := univ.filter (fun i => s i = c0) with hA
  set O := univ.filter (fun i => s i ≠ c0) with hO
  have hsplitAO : ∀ g : Fin n → ℝ, ∑ i, g i = ∑ i ∈ A, g i + ∑ i ∈ O, g i := fun g =>
    (Finset.sum_filter_add_sum_filter_not univ (fun i => s i = c0) g).symm
  have hz : ∀ i, |r0 - s i| = if s i = c0 then r0 - c0 else s i - r0 := by
    intro i
    split_ifs with h
    · rw [h, abs_of_nonneg (by linarith)]
    · rw [abs_sub_comm, abs_of_pos (by linarith [hother i h])]
  have hamgm := amgm_prod_le hn (fun i => |r0 - s i|) (fun i => abs_nonneg _)
  rw [← Finset.abs_prod, hf1] at hamgm
  have hsumz : (n : ℝ) ≤ ∑ i, |r0 - s i| := by
    by_contra hc
    push Not at hc
    have hmean : (∑ i, |r0 - s i|) / n < 1 := by rw [div_lt_one hnR]; exact hc
    have hmean0 : 0 ≤ (∑ i, |r0 - s i|) / n := by positivity
    have := pow_lt_one₀ hmean0 hmean (Nat.pos_iff_ne_zero.mp hn)
    linarith
  have hcardAO : (A.card : ℝ) + O.card = n := by
    have := Finset.card_filter_add_card_filter_not (s := univ) (fun i => s i = c0)
    rw [Finset.card_univ, Fintype.card_fin] at this
    exact_mod_cast this
  have hzA : ∑ i ∈ A, |r0 - s i| = A.card * (r0 - c0) := by
    rw [Finset.sum_congr rfl (fun i hi => by rw [hz i, if_pos (Finset.mem_filter.mp hi).2]),
      sum_const, nsmul_eq_mul]
  have hzO : ∑ i ∈ O, |r0 - s i| = ∑ i ∈ O, s i - O.card * r0 := by
    rw [Finset.sum_congr rfl (fun i hi => by rw [hz i, if_neg (Finset.mem_filter.mp hi).2]),
      sum_sub_distrib, sum_const, nsmul_eq_mul]
  have hsA : ∑ i ∈ A, s i = A.card * c0 := by
    rw [Finset.sum_congr rfl (fun i hi => (Finset.mem_filter.mp hi).2), sum_const, nsmul_eq_mul]
  have hs_split := hsplitAO s
  have hz_split := hsplitAO (fun i => |r0 - s i|)
  have hr0nn : 0 ≤ r0 := by linarith
  have hAO : (O.card : ℝ) ≤ A.card := by
    by_contra hc
    push Not at hc
    nlinarith
  -- the window to the left of c0
  have hwin : Set.Ioo (c0 - (√2 - 1)) c0 ⊆ sublevel s := by
    intro x ⟨hx1, hx2⟩
    set u := c0 - x with hu
    have hu0 : 0 < u := by linarith
    have hs1 : √2 * √2 = 2 := Real.mul_self_sqrt (by norm_num)
    have hs2 : 0 < √2 := by positivity
    have hs3 : √2 < 3 / 2 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
    have hu1 : u < √2 - 1 := by linarith
    have huu : u * (2 + u) < 1 := by nlinarith
    have hfac : ∀ i, |x - s i| = if s i = c0 then u else s i - x := by
      intro i
      split_ifs with h
      · rw [h, hu, abs_of_neg (by linarith)]; ring
      · rw [abs_sub_comm, abs_of_pos (by linarith [hother i h, hcle i])]
    change |∏ i, (x - s i)| < 1
    rw [Finset.abs_prod]
    have hprod : ∏ i, |x - s i| = (∏ i ∈ A, |x - s i|) * ∏ i ∈ O, |x - s i| :=
      (Finset.prod_filter_mul_prod_filter_not univ (fun i => s i = c0) _).symm
    have hPA : ∏ i ∈ A, |x - s i| = u ^ A.card := by
      rw [Finset.prod_congr rfl (fun i hi => by rw [hfac i, if_pos (Finset.mem_filter.mp hi).2]),
        prod_const]
    have hPO : ∏ i ∈ O, |x - s i| ≤ (2 + u) ^ O.card := by
      rw [← prod_const]
      gcongr with i hi
      rw [hfac i, if_neg (Finset.mem_filter.mp hi).2]
      linarith [(hs i).2]
    rw [hprod, hPA]
    have hAO' : O.card ≤ A.card := by exact_mod_cast hAO
    have hupow : u ^ A.card ≤ u ^ O.card := pow_le_pow_of_le_one hu0.le (by linarith) hAO'
    rcases Nat.eq_zero_or_pos O.card with h0 | hpos
    · rw [h0, pow_zero] at hPO
      have hAn : A.card = n := by
        have : (A.card : ℝ) = n := by rw [← hcardAO, h0]; simp
        exact_mod_cast this
      calc u ^ A.card * ∏ i ∈ O, |x - s i| ≤ u ^ A.card * 1 :=
            mul_le_mul_of_nonneg_left hPO (by positivity)
        _ < 1 := by rw [mul_one, hAn]; exact pow_lt_one₀ hu0.le (by linarith) (Nat.pos_iff_ne_zero.mp hn)
    · calc u ^ A.card * ∏ i ∈ O, |x - s i| ≤ u ^ O.card * (2 + u) ^ O.card :=
            mul_le_mul hupow hPO (Finset.prod_nonneg fun i _ => abs_nonneg _) (by positivity)
        _ = (u * (2 + u)) ^ O.card := by rw [mul_pow]
        _ < 1 := pow_lt_one₀ (by positivity) huu (Nat.pos_iff_ne_zero.mp hpos)
  -- assemble: (c0 - (√2 - 1), c0 + 1) ⊆ S
  have hbig : Set.Ioo (c0 - (√2 - 1)) (c0 + 1) ⊆ sublevel s := by
    intro x hx
    rcases lt_trichotomy x c0 with h | h | h
    · exact hwin ⟨hx.1, h⟩
    · rw [h]; exact root_mem s i0
    · exact hIoo ⟨h, hx.2⟩
  calc ENNReal.ofReal √2 = volume (Set.Ioo (c0 - (√2 - 1)) (c0 + 1)) := by
        rw [Real.volume_Ioo]; congr 1; ring
    _ ≤ volume (sublevel s) := measure_mono hbig

/-- **A universal lower bound, fully formal**: every root vector in `[-1, 1]ⁿ`, `n ≥ 1`, has
`|S| ≥ √2` (proof.md Lemmas 7.2–7.4 and 7.6, in the simplified form of this file). -/
theorem sqrt2_le {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    ENNReal.ofReal √2 ≤ volume (sublevel r) := by
  have main : ∀ r' : Fin n → ℝ, (∀ i, r' i ∈ Set.Icc (-1 : ℝ) 1) → ∑ i, r' i ≤ 0 →
      ENNReal.ofReal √2 ≤ volume (sublevel r') := by
    intro r' hr' hs
    have h := sqrt2_clustered hn (cmean r') (cmean_mem_Icc r' hr')
      (by rw [sum_cmean]; exact hs) (fun i j h => cmean_eq_of_uIcc r' h)
    exact h.trans (measure_mono (sublevel_cmean_subset r'))
  rcases le_total (∑ i, r i) 0 with h | h
  · exact main r hr h
  · rw [← volume_sublevel_neg]
    exact main _ (fun i => ⟨by linarith [(hr i).2], by linarith [(hr i).1]⟩)
      (by simp only [Finset.sum_neg_distrib]; linarith)

end EP1038.Atom

namespace EP1038

open Polynomial in
/-- **Every `p ∈ 𝒫` satisfies `√2 ≤ |S_p| ≤ 2√2`** (monic, degree `≥ 1`, all roots real in `[-1, 1]`). -/
theorem sqrt2_le_volume_le (p : ℝ[X]) (hm : p.Monic) (hdeg : 1 ≤ p.natDegree)
    (hsplit : Multiset.card p.roots = p.natDegree)
    (hroots : ∀ r ∈ p.roots, r ∈ Set.Icc (-1 : ℝ) 1) :
    ENNReal.ofReal √2 ≤ volume {x : ℝ | |p.eval x| < 1} ∧
      volume {x : ℝ | |p.eval x| < 1} ≤ ENNReal.ofReal (2 * √2) := by
  refine ⟨?_, (sup_theorem p hm hdeg hsplit hroots).1⟩
  set l := p.roots.toList with hl
  set r : Fin l.length → ℝ := fun i => l[i.1] with hrdef
  have hlen : l.length = p.natDegree := by rw [hl, Multiset.length_toList, hsplit]
  have hn : 0 < l.length := by omega
  have hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1 := by
    intro i
    apply hroots
    rw [← Multiset.mem_toList]
    exact List.getElem_mem _
  have hset : {x : ℝ | |p.eval x| < 1} = sublevel r := by
    ext x
    simp only [Set.mem_ofPred_eq, sublevel]
    rw [eval_eq_prod p hm hsplit x]
  rw [hset]
  exact Atom.sqrt2_le hn r hr

end EP1038
