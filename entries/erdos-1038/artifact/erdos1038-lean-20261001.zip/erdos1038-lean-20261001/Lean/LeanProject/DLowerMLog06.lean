import LeanProject.DLowerMTools
import LeanProject.DLowerMLog03
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_240 : RB (Real.log ((25664062499999999 : ℝ) / 1000000000000000000)) ((-915665902995760843 : ℝ) / 250000000000000000) ((-366266361198304337 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((25664062499999999 : ℝ) / 31250000000000000)) (t := ((-5585937500000001 : ℝ) / 56914062499999999))
    (lo := ((-24615963647914603 : ℝ) / 125000000000000000)) (hi := ((-196927709183316823 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25664062499999999 : ℝ) / 1000000000000000000) = Real.log ((25664062499999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25664062499999999 : ℝ) / 1000000000000000000) = ((25664062499999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_241 : RB (Real.log ((657 : ℝ) / 25600)) ((-3662663611983043333 : ℝ) / 1000000000000000000) ((-3662663611983043331 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((657 : ℝ) / 800)) (t := ((-143 : ℝ) / 1457))
    (lo := ((-39385541836663357 : ℝ) / 200000000000000000)) (hi := ((-12307981823957299 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((657 : ℝ) / 25600) = Real.log ((657 : ℝ) / 800) - 5 * Real.log 2 := by
    rw [show ((657 : ℝ) / 25600) = ((657 : ℝ) / 800) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_242 : RB (Real.log ((1025664062499999999 : ℝ) / 1000000000000000000)) ((12670134334773397 : ℝ) / 500000000000000000) ((5068053733909359 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025664062499999999 : ℝ) / 1000000000000000000)) (t := ((25664062499999999 : ℝ) / 2025664062499999999))
    (lo := ((12670134334773397 : ℝ) / 500000000000000000)) (hi := ((5068053733909359 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_243 : RB (Real.log ((26257 : ℝ) / 25600)) ((5068053733909359 : ℝ) / 200000000000000000) ((6335067167386699 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((26257 : ℝ) / 25600)) (t := ((657 : ℝ) / 51857))
    (lo := ((5068053733909359 : ℝ) / 200000000000000000)) (hi := ((6335067167386699 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_244 : RB (Real.log ((25624999999999999 : ℝ) / 1000000000000000000)) ((-1832093420761782421 : ℝ) / 500000000000000000) ((-91604671038089121 : ℝ) / 25000000000000000) := by
  have hm := log_bounds_of_series (x := ((25624999999999999 : ℝ) / 31250000000000000)) (t := ((-5625000000000001 : ℝ) / 56874999999999999))
    (lo := ((-99225469361919147 : ℝ) / 500000000000000000)) (hi := ((-198450938723838293 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25624999999999999 : ℝ) / 1000000000000000000) = Real.log ((25624999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25624999999999999 : ℝ) / 1000000000000000000) = ((25624999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_245 : RB (Real.log ((329 : ℝ) / 12800)) ((-3661142699142336643 : ℝ) / 1000000000000000000) ((-3661142699142336641 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((329 : ℝ) / 400)) (t := ((-71 : ℝ) / 729))
    (lo := ((-39081359268522019 : ℝ) / 200000000000000000)) (hi := ((-97703398171305047 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((329 : ℝ) / 12800) = Real.log ((329 : ℝ) / 400) - 5 * Real.log 2 := by
    rw [show ((329 : ℝ) / 12800) = ((329 : ℝ) / 400) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_246 : RB (Real.log ((1025624999999999999 : ℝ) / 1000000000000000000)) ((2530218286221829 : ℝ) / 100000000000000000) ((25302182862218291 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025624999999999999 : ℝ) / 1000000000000000000)) (t := ((25624999999999999 : ℝ) / 2025624999999999999))
    (lo := ((2530218286221829 : ℝ) / 100000000000000000)) (hi := ((25302182862218291 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_247 : RB (Real.log ((13129 : ℝ) / 12800)) ((12689176513200911 : ℝ) / 500000000000000000) ((25378353026401823 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((13129 : ℝ) / 12800)) (t := ((329 : ℝ) / 25929))
    (lo := ((12689176513200911 : ℝ) / 500000000000000000)) (hi := ((25378353026401823 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_248 : RB (Real.log ((458762886953619093 : ℝ) / 1000000000000000000)) ((-155844357711176751 : ℝ) / 200000000000000000) ((-779221788555883753 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458762886953619093 : ℝ) / 500000000000000000)) (t := ((-41237113046380907 : ℝ) / 958762886953619093))
    (lo := ((-17214921599187689 : ℝ) / 200000000000000000)) (hi := ((-21518651998984611 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458762886953619093 : ℝ) / 1000000000000000000) = Real.log ((458762886953619093 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458762886953619093 : ℝ) / 1000000000000000000) = ((458762886953619093 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_249 : RB (Real.log ((229381443476811047 : ℝ) / 500000000000000000)) ((-779221788555877213 : ℝ) / 1000000000000000000) ((-779221788555877211 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229381443476811047 : ℝ) / 250000000000000000)) (t := ((-20618556523188953 : ℝ) / 479381443476811047))
    (lo := ((-86074607995931903 : ℝ) / 1000000000000000000)) (hi := ((-43037303997965951 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229381443476811047 : ℝ) / 500000000000000000) = Real.log ((229381443476811047 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229381443476811047 : ℝ) / 500000000000000000) = ((229381443476811047 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_250 : RB (Real.log ((270289234471187 : ℝ) / 500000000000000)) ((-24604618960338739 : ℝ) / 40000000000000000) ((-615115474008468473 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((270289234471187 : ℝ) / 250000000000000)) (t := ((20289234471187 : ℝ) / 520289234471187))
    (lo := ((15606341310295367 : ℝ) / 200000000000000000)) (hi := ((19507926637869209 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270289234471187 : ℝ) / 500000000000000) = Real.log ((270289234471187 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((270289234471187 : ℝ) / 500000000000000) = ((270289234471187 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_251 : RB (Real.log ((540578468942377 : ℝ) / 1000000000000000)) ((-24604618960338517 : ℝ) / 40000000000000000) ((-615115474008462923 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((540578468942377 : ℝ) / 500000000000000)) (t := ((40578468942377 : ℝ) / 1040578468942377))
    (lo := ((15606341310296477 : ℝ) / 200000000000000000)) (hi := ((39015853275741193 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540578468942377 : ℝ) / 1000000000000000) = Real.log ((540578468942377 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((540578468942377 : ℝ) / 1000000000000000) = ((540578468942377 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_252 : RB (Real.log ((459421531057623 : ℝ) / 1000000000000000)) ((-388893561023253589 : ℝ) / 500000000000000000) ((-97223390255813397 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((459421531057623 : ℝ) / 500000000000000)) (t := ((-40578468942377 : ℝ) / 959421531057623))
    (lo := ((-21159985371640467 : ℝ) / 250000000000000000)) (hi := ((-84639941486561867 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459421531057623 : ℝ) / 1000000000000000) = Real.log ((459421531057623 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((459421531057623 : ℝ) / 1000000000000000) = ((459421531057623 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_253 : RB (Real.log ((229710765528813 : ℝ) / 500000000000000)) ((-97223390255812581 : ℝ) / 125000000000000000) ((-388893561023250323 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((229710765528813 : ℝ) / 250000000000000)) (t := ((-20289234471187 : ℝ) / 479710765528813))
    (lo := ((-42319970743277669 : ℝ) / 500000000000000000)) (hi := ((-84639941486555337 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229710765528813 : ℝ) / 500000000000000) = Real.log ((229710765528813 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((229710765528813 : ℝ) / 500000000000000) = ((229710765528813 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_254 : RB (Real.log ((229381443476809547 : ℝ) / 500000000000000000)) ((-779221788555883753 : ℝ) / 1000000000000000000) ((-779221788555883751 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229381443476809547 : ℝ) / 250000000000000000)) (t := ((-20618556523190453 : ℝ) / 479381443476809547))
    (lo := ((-86074607995938443 : ℝ) / 1000000000000000000)) (hi := ((-43037303997969221 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229381443476809547 : ℝ) / 500000000000000000) = Real.log ((229381443476809547 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229381443476809547 : ℝ) / 500000000000000000) = ((229381443476809547 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_255 : RB (Real.log ((458762886953622093 : ℝ) / 1000000000000000000)) ((-155844357711175443 : ℝ) / 200000000000000000) ((-779221788555877213 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458762886953622093 : ℝ) / 500000000000000000)) (t := ((-41237113046377907 : ℝ) / 958762886953622093))
    (lo := ((-17214921599186381 : ℝ) / 200000000000000000)) (hi := ((-336228937484109 : ℝ) / 3906250000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458762886953622093 : ℝ) / 1000000000000000000) = Real.log ((458762886953622093 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458762886953622093 : ℝ) / 1000000000000000000) = ((458762886953622093 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_256 : RB (Real.log ((1424632753657640093 : ℝ) / 1000000000000000000)) ((88478515943617399 : ℝ) / 250000000000000000) ((176957031887234799 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424632753657640093 : ℝ) / 2000000000000000000)) (t := ((-575367246342359907 : ℝ) / 3424632753657640093))
    (lo := ((-339233116785475713 : ℝ) / 1000000000000000000)) (hi := ((-2650258724886529 : ℝ) / 7812500000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424632753657640093 : ℝ) / 1000000000000000000) = Real.log ((1424632753657640093 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424632753657640093 : ℝ) / 1000000000000000000) = ((1424632753657640093 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_257 : RB (Real.log ((712316376828821547 : ℝ) / 500000000000000000)) ((353914063774471703 : ℝ) / 1000000000000000000) ((70782812754894341 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((712316376828821547 : ℝ) / 1000000000000000000)) (t := ((-287683623171178453 : ℝ) / 1712316376828821547))
    (lo := ((-169616558392736803 : ℝ) / 500000000000000000)) (hi := ((-67846623357094721 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712316376828821547 : ℝ) / 500000000000000000) = Real.log ((712316376828821547 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712316376828821547 : ℝ) / 500000000000000000) = ((712316376828821547 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_258 : RB (Real.log ((106322849440411 : ℝ) / 250000000000000)) ((-427490351605282159 : ℝ) / 500000000000000000) ((-213745175802641079 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((106322849440411 : ℝ) / 125000000000000)) (t := ((-18677150559589 : ℝ) / 231322849440411))
    (lo := ((-1264324395707961 : ℝ) / 7812500000000000)) (hi := ((-161833522650619007 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((106322849440411 : ℝ) / 250000000000000) = Real.log ((106322849440411 : ℝ) / 125000000000000) - 1 * Real.log 2 := by
    rw [show ((106322849440411 : ℝ) / 250000000000000) = ((106322849440411 : ℝ) / 125000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_259 : RB (Real.log ((425291397761647 : ℝ) / 1000000000000000)) ((-53436293950659829 : ℝ) / 62500000000000000) ((-427490351605278631 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((425291397761647 : ℝ) / 500000000000000)) (t := ((-74708602238353 : ℝ) / 925291397761647))
    (lo := ((-80916761325305977 : ℝ) / 500000000000000000)) (hi := ((-161833522650611953 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425291397761647 : ℝ) / 1000000000000000) = Real.log ((425291397761647 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425291397761647 : ℝ) / 1000000000000000) = ((425291397761647 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_260 : RB (Real.log ((356322849440411 : ℝ) / 250000000000000)) ((35437628247274779 : ℝ) / 100000000000000000) ((22148517654546737 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((356322849440411 : ℝ) / 500000000000000)) (t := ((-143677150559589 : ℝ) / 856322849440411))
    (lo := ((-338770898087197519 : ℝ) / 1000000000000000000)) (hi := ((-169385449043598759 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356322849440411 : ℝ) / 250000000000000) = Real.log ((356322849440411 : ℝ) / 500000000000000) + 1 * Real.log 2 := by
    rw [show ((356322849440411 : ℝ) / 250000000000000) = ((356322849440411 : ℝ) / 500000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_261 : RB (Real.log ((1425291397761647 : ℝ) / 1000000000000000)) ((70875256494549979 : ℝ) / 200000000000000000) ((354376282472749897 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425291397761647 : ℝ) / 2000000000000000)) (t := ((-574708602238353 : ℝ) / 3425291397761647))
    (lo := ((-169385449043597707 : ℝ) / 500000000000000000)) (hi := ((-338770898087195413 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425291397761647 : ℝ) / 1000000000000000) = Real.log ((1425291397761647 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425291397761647 : ℝ) / 1000000000000000) = ((1425291397761647 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_262 : RB (Real.log ((712316376828820047 : ℝ) / 500000000000000000)) ((353914063774469597 : ℝ) / 1000000000000000000) ((353914063774469599 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712316376828820047 : ℝ) / 1000000000000000000)) (t := ((-287683623171179953 : ℝ) / 1712316376828820047))
    (lo := ((-2650258724886529 : ℝ) / 7812500000000000)) (hi := ((-339233116785475711 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712316376828820047 : ℝ) / 500000000000000000) = Real.log ((712316376828820047 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712316376828820047 : ℝ) / 500000000000000000) = ((712316376828820047 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_263 : RB (Real.log ((1424632753657643093 : ℝ) / 1000000000000000000)) ((176957031887235851 : ℝ) / 500000000000000000) ((44239257971808963 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424632753657643093 : ℝ) / 2000000000000000000)) (t := ((-575367246342356907 : ℝ) / 3424632753657643093))
    (lo := ((-339233116785473607 : ℝ) / 1000000000000000000)) (hi := ((-169616558392736803 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424632753657643093 : ℝ) / 1000000000000000000) = Real.log ((1424632753657643093 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424632753657643093 : ℝ) / 1000000000000000000) = ((1424632753657643093 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_264 : RB (Real.log ((458672415341279073 : ℝ) / 1000000000000000000)) ((-779419015787944653 : ℝ) / 1000000000000000000) ((-779419015787944651 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458672415341279073 : ℝ) / 500000000000000000)) (t := ((-41327584658720927 : ℝ) / 958672415341279073))
    (lo := ((-86271835227999343 : ℝ) / 1000000000000000000)) (hi := ((-43135917613999671 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458672415341279073 : ℝ) / 1000000000000000000) = Real.log ((458672415341279073 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458672415341279073 : ℝ) / 1000000000000000000) = ((458672415341279073 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_265 : RB (Real.log ((18354134220568147 : ℝ) / 40000000000000000)) ((-779024606865563191 : ℝ) / 1000000000000000000) ((-779024606865563189 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((18354134220568147 : ℝ) / 20000000000000000)) (t := ((-1645865779431853 : ℝ) / 38354134220568147))
    (lo := ((-85877426305617881 : ℝ) / 1000000000000000000)) (hi := ((-2146935657640447 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((18354134220568147 : ℝ) / 40000000000000000) = Real.log ((18354134220568147 : ℝ) / 20000000000000000) - 1 * Real.log 2 := by
    rw [show ((18354134220568147 : ℝ) / 40000000000000000) = ((18354134220568147 : ℝ) / 20000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_266 : RB (Real.log ((270245001930398163 : ℝ) / 500000000000000000)) ((-615279136318489877 : ℝ) / 1000000000000000000) ((-4922233090547919 : ℝ) / 8000000000000000) := by
  have hm := log_bounds_of_series (x := ((270245001930398163 : ℝ) / 250000000000000000)) (t := ((20245001930398163 : ℝ) / 520245001930398163))
    (lo := ((77868044241455433 : ℝ) / 1000000000000000000)) (hi := ((38934022120727717 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270245001930398163 : ℝ) / 500000000000000000) = Real.log ((270245001930398163 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((270245001930398163 : ℝ) / 500000000000000000) = ((270245001930398163 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_267 : RB (Real.log ((270333467011977651 : ℝ) / 500000000000000000)) ((-614951838479409109 : ℝ) / 1000000000000000000) ((-614951838479409107 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((270333467011977651 : ℝ) / 250000000000000000)) (t := ((20333467011977651 : ℝ) / 520333467011977651))
    (lo := ((78195342080536201 : ℝ) / 1000000000000000000)) (hi := ((39097671040268101 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270333467011977651 : ℝ) / 500000000000000000) = Real.log ((270333467011977651 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((270333467011977651 : ℝ) / 500000000000000000) = ((270333467011977651 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_268 : RB (Real.log ((229666532988022349 : ℝ) / 500000000000000000)) ((-777979698131867343 : ℝ) / 1000000000000000000) ((-777979698131867341 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229666532988022349 : ℝ) / 250000000000000000)) (t := ((-20333467011977651 : ℝ) / 479666532988022349))
    (lo := ((-84832517571922033 : ℝ) / 1000000000000000000)) (hi := ((-5302032348245127 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229666532988022349 : ℝ) / 500000000000000000) = Real.log ((229666532988022349 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229666532988022349 : ℝ) / 500000000000000000) = ((229666532988022349 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_269 : RB (Real.log ((229754998069601837 : ℝ) / 500000000000000000)) ((-777594583039550203 : ℝ) / 1000000000000000000) ((-777594583039550201 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229754998069601837 : ℝ) / 250000000000000000)) (t := ((-20245001930398163 : ℝ) / 479754998069601837))
    (lo := ((-84447402479604893 : ℝ) / 1000000000000000000)) (hi := ((-21111850619901223 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229754998069601837 : ℝ) / 500000000000000000) = Real.log ((229754998069601837 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229754998069601837 : ℝ) / 500000000000000000) = ((229754998069601837 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_270 : RB (Real.log ((458674421872040791 : ℝ) / 1000000000000000000)) ((-194853660287161807 : ℝ) / 250000000000000000) ((-389707320574323613 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((458674421872040791 : ℝ) / 500000000000000000)) (t := ((-41325578127959209 : ℝ) / 958674421872040791))
    (lo := ((-43133730294350959 : ℝ) / 500000000000000000)) (hi := ((-86267460588701917 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458674421872040791 : ℝ) / 1000000000000000000) = Real.log ((458674421872040791 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458674421872040791 : ℝ) / 1000000000000000000) = ((458674421872040791 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_271 : RB (Real.log ((57334302734005099 : ℝ) / 125000000000000000)) ((-31176585645945889 : ℝ) / 40000000000000000) ((-779414641148647223 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((57334302734005099 : ℝ) / 62500000000000000)) (t := ((-5165697265994901 : ℝ) / 119834302734005099))
    (lo := ((-17253492117740383 : ℝ) / 200000000000000000)) (hi := ((-43133730294350957 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57334302734005099 : ℝ) / 125000000000000000) = Real.log ((57334302734005099 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57334302734005099 : ℝ) / 125000000000000000) = ((57334302734005099 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_272 : RB (Real.log ((458676425351044699 : ℝ) / 1000000000000000000)) ((-779410273181887343 : ℝ) / 1000000000000000000) ((-779410273181887341 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458676425351044699 : ℝ) / 500000000000000000)) (t := ((-41323574648955301 : ℝ) / 958676425351044699))
    (lo := ((-86263092621942033 : ℝ) / 1000000000000000000)) (hi := ((-5391443288871377 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458676425351044699 : ℝ) / 1000000000000000000) = Real.log ((458676425351044699 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458676425351044699 : ℝ) / 1000000000000000000) = ((458676425351044699 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_273 : RB (Real.log ((458851352035199767 : ℝ) / 1000000000000000000)) ((-779028973148066549 : ℝ) / 1000000000000000000) ((-779028973148066547 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458851352035199767 : ℝ) / 500000000000000000)) (t := ((-41148647964800233 : ℝ) / 958851352035199767))
    (lo := ((-85881792588121239 : ℝ) / 1000000000000000000)) (hi := ((-42940896294060619 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458851352035199767 : ℝ) / 1000000000000000000) = Real.log ((458851352035199767 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458851352035199767 : ℝ) / 1000000000000000000) = ((458851352035199767 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_274 : RB (Real.log ((57356419004399971 : ℝ) / 125000000000000000)) ((-779028973148066547 : ℝ) / 1000000000000000000) ((-155805794629613309 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((57356419004399971 : ℝ) / 62500000000000000)) (t := ((-5143580995600029 : ℝ) / 119856419004399971))
    (lo := ((-85881792588121237 : ℝ) / 1000000000000000000)) (hi := ((-21470448147030309 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57356419004399971 : ℝ) / 125000000000000000) = Real.log ((57356419004399971 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57356419004399971 : ℝ) / 125000000000000000) = ((57356419004399971 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_275 : RB (Real.log ((458849345504438049 : ℝ) / 1000000000000000000)) ((-155806669220105439 : ℝ) / 200000000000000000) ((-779033346100527193 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458849345504438049 : ℝ) / 500000000000000000)) (t := ((-41150654495561951 : ℝ) / 958849345504438049))
    (lo := ((-17177233108116377 : ℝ) / 200000000000000000)) (hi := ((-21471541385145471 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458849345504438049 : ℝ) / 1000000000000000000) = Real.log ((458849345504438049 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458849345504438049 : ℝ) / 1000000000000000000) = ((458849345504438049 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_276 : RB (Real.log ((17807793172421703 : ℝ) / 12500000000000000)) ((88476883962632403 : ℝ) / 250000000000000000) ((176953767925264807 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((17807793172421703 : ℝ) / 25000000000000000)) (t := ((-7192206827578297 : ℝ) / 42807793172421703))
    (lo := ((-339239644709415697 : ℝ) / 1000000000000000000)) (hi := ((-21202477794338481 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17807793172421703 : ℝ) / 12500000000000000) = Real.log ((17807793172421703 : ℝ) / 25000000000000000) + 1 * Real.log 2 := by
    rw [show ((17807793172421703 : ℝ) / 12500000000000000) = ((17807793172421703 : ℝ) / 25000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_277 : RB (Real.log ((356160512617447311 : ℝ) / 250000000000000000)) ((353920589513675739 : ℝ) / 1000000000000000000) ((353920589513675741 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((356160512617447311 : ℝ) / 500000000000000000)) (t := ((-143839487382552689 : ℝ) / 856160512617447311))
    (lo := ((-33922659104626957 : ℝ) / 100000000000000000)) (hi := ((-339226591046269569 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356160512617447311 : ℝ) / 250000000000000000) = Real.log ((356160512617447311 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356160512617447311 : ℝ) / 250000000000000000) = ((356160512617447311 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_278 : RB (Real.log ((85056820885700373 : ℝ) / 200000000000000000)) ((-854997852383385623 : ℝ) / 1000000000000000000) ((-854997852383385621 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((85056820885700373 : ℝ) / 100000000000000000)) (t := ((-14943179114299627 : ℝ) / 185056820885700373))
    (lo := ((-161850671823440313 : ℝ) / 1000000000000000000)) (hi := ((-20231333977930039 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85056820885700373 : ℝ) / 200000000000000000) = Real.log ((85056820885700373 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((85056820885700373 : ℝ) / 200000000000000000) = ((85056820885700373 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_279 : RB (Real.log ((425298691094789243 : ℝ) / 1000000000000000000)) ((-854963554331824789 : ℝ) / 1000000000000000000) ((-854963554331824787 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((425298691094789243 : ℝ) / 500000000000000000)) (t := ((-74701308905210757 : ℝ) / 925298691094789243))
    (lo := ((-161816373771879479 : ℝ) / 1000000000000000000)) (hi := ((-80908186885939739 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425298691094789243 : ℝ) / 1000000000000000000) = Real.log ((425298691094789243 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425298691094789243 : ℝ) / 1000000000000000000) = ((425298691094789243 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
