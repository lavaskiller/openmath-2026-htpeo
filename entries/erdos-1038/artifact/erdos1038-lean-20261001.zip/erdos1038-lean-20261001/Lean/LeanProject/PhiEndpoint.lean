import LeanProject.TwoAtomWitness
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Complex.ExponentialBounds

/-!
# EP-1038: the scalar inequality of Lemma 6.4 at `a = 3/4` (i.e. `φ(U) > 0`), proved in Lean

With `B = 2√2` and `a = 3/4` (so `u = U = 7/4 - √2`), the hypothesis `hphi` of `witness_of_phi`
reads `log(3/4)·log(2√2 - 11/4) < log(11/4)·log(2√2 - 3/4)`. By proof.md Remark 6.4′ this single
value implies `φ > 0` on all of `(0, U]`; that implication (the power-series monotonicity) is not
formalised here. Ingredients: `√2 ∈ (1.41421, 1.41422)`, the log-series remainder bound
(`Real.abs_log_sub_add_sum_range_le`) at `3/11`, `49/1299`, `1/4`, `12736/62736`, and Mathlib's
bounds for `log 2`. Margin: left side `≤ 0.73238`, right side `≥ 0.74006` (Lean RED L-67).
-/

open Real Finset

namespace EP1038

theorem log_11_8_ge : 0.31845 ≤ Real.log (11 / 8) := by
  have h := Real.abs_log_sub_add_sum_range_le (x := 3 / 11)
    (by rw [abs_of_pos (by norm_num)]; norm_num) 10
  have e1 : Real.log (1 - 3 / 11) = -Real.log (11 / 8) := by
    rw [show (1 : ℝ) - 3 / 11 = (11 / 8)⁻¹ by norm_num, Real.log_inv]
  rw [e1] at h
  simp only [Finset.sum_range_succ, Finset.sum_range_zero] at h
  rw [abs_of_pos (by norm_num : (0 : ℝ) < 3 / 11), abs_le] at h
  obtain ⟨h1, h2⟩ := h
  norm_num at h1 h2 ⊢
  linarith

theorem log_1299_ge : 0.03845 ≤ Real.log (1299 / 1250) := by
  have h := Real.abs_log_sub_add_sum_range_le (x := 49 / 1299)
    (by rw [abs_of_pos (by norm_num)]; norm_num) 4
  have e1 : Real.log (1 - 49 / 1299) = -Real.log (1299 / 1250) := by
    rw [show (1 : ℝ) - 49 / 1299 = (1299 / 1250)⁻¹ by norm_num, Real.log_inv]
  rw [e1] at h
  simp only [Finset.sum_range_succ, Finset.sum_range_zero] at h
  rw [abs_of_pos (by norm_num : (0 : ℝ) < 49 / 1299), abs_le] at h
  obtain ⟨h1, h2⟩ := h
  norm_num at h1 h2 ⊢
  linarith

theorem log_4_3_le : Real.log (4 / 3) ≤ 0.28769 := by
  have h := Real.abs_log_sub_add_sum_range_le (x := 1 / 4)
    (by rw [abs_of_pos (by norm_num)]; norm_num) 10
  have e1 : Real.log (1 - 1 / 4) = -Real.log (4 / 3) := by
    rw [show (1 : ℝ) - 1 / 4 = (4 / 3)⁻¹ by norm_num, Real.log_inv]
  rw [e1] at h
  simp only [Finset.sum_range_succ, Finset.sum_range_zero] at h
  rw [abs_of_pos (by norm_num : (0 : ℝ) < 1 / 4), abs_le] at h
  obtain ⟨h1, h2⟩ := h
  norm_num at h1 h2 ⊢
  linarith

theorem log_62736_ge : 0.22690 ≤ Real.log (62736 / 50000) := by
  have h := Real.abs_log_sub_add_sum_range_le (x := 12736 / 62736)
    (by rw [abs_of_pos (by norm_num)]; norm_num) 10
  have e1 : Real.log (1 - 12736 / 62736) = -Real.log (62736 / 50000) := by
    rw [show (1 : ℝ) - 12736 / 62736 = (62736 / 50000)⁻¹ by norm_num, Real.log_inv]
  rw [e1] at h
  simp only [Finset.sum_range_succ, Finset.sum_range_zero] at h
  rw [abs_of_pos (by norm_num : (0 : ℝ) < 12736 / 62736), abs_le] at h
  obtain ⟨h1, h2⟩ := h
  norm_num at h1 h2 ⊢
  linarith

/-- **`φ(U) > 0`**: the scalar inequality of Lemma 6.4 at `a = 3/4`, `B = 2√2`. -/
theorem phi_three_quarters :
    Real.log (3 / 4) * Real.log (2 * √2 - 3 / 4 - 2) <
      Real.log (3 / 4 + 2) * Real.log (2 * √2 - 3 / 4) := by
  have hs1 : (1.41421 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have hs2 : √2 < 1.41422 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  have l2lo := Real.log_two_gt_d9
  have l2hi := Real.log_two_lt_d9
  have b1 := log_11_8_ge
  have b2 := log_1299_ge
  have b3 := log_4_3_le
  have b4 := log_62736_ge
  -- log(B - a) ≥ log 2 + log(1299/1250)
  have A : Real.log 2 + Real.log (1299 / 1250) ≤ Real.log (2 * √2 - 3 / 4) := by
    rw [← Real.log_mul (by norm_num) (by norm_num)]
    exact Real.log_le_log (by norm_num) (by linarith)
  -- log(B - a - 2) ≥ log(62736/50000) - 4 log 2
  have Bv : Real.log (3921 / 50000) ≤ Real.log (2 * √2 - 3 / 4 - 2) :=
    Real.log_le_log (by norm_num) (by linarith)
  have e2 : Real.log (3921 / 50000) = Real.log (62736 / 50000) - 4 * Real.log 2 := by
    rw [show (3921 / 50000 : ℝ) = (62736 / 50000) / 2 ^ 4 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    push_cast; ring
  have e3 : Real.log (3 / 4 + 2) = Real.log 2 + Real.log (11 / 8) := by
    rw [← Real.log_mul (by norm_num) (by norm_num)]; norm_num
  have e4 : Real.log (3 / 4) = -Real.log (4 / 3) := by
    rw [show (3 / 4 : ℝ) = (4 / 3)⁻¹ by norm_num, Real.log_inv]
  have hY : -Real.log (2 * √2 - 3 / 4 - 2) ≤ 2.5457 := by linarith
  have hY0 : 0 ≤ -Real.log (2 * √2 - 3 / 4 - 2) := by
    have : Real.log (2 * √2 - 3 / 4 - 2) < 0 := Real.log_neg (by linarith) (by linarith)
    linarith
  have hL : Real.log (4 / 3) * (-Real.log (2 * √2 - 3 / 4 - 2)) ≤ 0.28769 * 2.5457 :=
    mul_le_mul b3 hY hY0 (by norm_num)
  have hR : 1.01159 * 0.73159 ≤ (Real.log 2 + Real.log (11 / 8)) * Real.log (2 * √2 - 3 / 4) :=
    mul_le_mul (by linarith) (by linarith) (by norm_num) (by linarith)
  rw [e3, e4]
  nlinarith

/-- The two-atom branch at `M = 7/4` (`a = 3/4`), with `B = 2√2`: formal, given the setting of
Lemma 6.3 (roots of the shifted polynomial in `[3/4, 11/4]`, `∏ q_j = 1`, and a point `y ∈ K` with
`|K ∩ [0, y]| ≥ 2√2`). -/
theorem two_atom_three_quarters {n : ℕ} (hn : 0 < n) (q : Fin n → ℝ) {y : ℝ}
    (hq : ∀ j, q j ∈ Set.Icc (3 / 4 : ℝ) (3 / 4 + 2)) (h0 : ∏ j, q j = 1)
    (hy : |∏ j, (y - q j)| ≤ 1)
    (hvol : ENNReal.ofReal (2 * √2) ≤
      MeasureTheory.volume (Set.Icc 0 y ∩ {x | |∏ j, (x - q j)| ≤ 1})) : False := by
  have hs1 : (1.41421 : ℝ) < √2 := by rw [Real.lt_sqrt (by norm_num)]; norm_num
  have hs2 : √2 < 1.41422 := by rw [Real.sqrt_lt' (by norm_num)]; norm_num
  exact two_atom_of_phi hn q (by norm_num) (by norm_num) (by linarith) (by linarith) (by linarith)
    phi_three_quarters hq h0 hy hvol

end EP1038
