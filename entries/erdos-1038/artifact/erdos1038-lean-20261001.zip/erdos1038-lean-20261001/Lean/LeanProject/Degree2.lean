import LeanProject.SupAttained

/-!
# EP-1038: the fixed-degree case n = 2 (proof.md Lemma 2.2), fully formalised

For roots `r₁, r₂ ∈ [-1,1]`, put `c = (r₁ + r₂)/2`, `d = |r₂ - r₁|/2 ∈ [0,1]`. Then
`|{x : |(x - r₁)(x - r₂)| < 1}| = 2 √(1 + d²) ≥ 2`, with equality iff `r₁ = r₂`. Hence `m₂ = 2`.
-/

open Real MeasureTheory

namespace EP1038

theorem volume_quad (c d : ℝ) (hd0 : 0 ≤ d) (hd1 : d ≤ 1) :
    volume {x : ℝ | |(x - c) ^ 2 - d ^ 2| < 1} = ENNReal.ofReal (2 * √(1 + d ^ 2)) := by
  set R := √(1 + d ^ 2) with hR
  have hR2 : R ^ 2 = 1 + d ^ 2 := Real.sq_sqrt (by positivity)
  have hR0 : 0 ≤ R := Real.sqrt_nonneg _
  set S := {x : ℝ | |(x - c) ^ 2 - d ^ 2| < 1}
  have hsub : S ⊆ Set.Ioo (c - R) (c + R) := by
    intro x hx
    simp only [S, Set.mem_setOf_eq, abs_lt] at hx
    have hy : (x - c) ^ 2 < R ^ 2 := by rw [hR2]; linarith
    have := abs_lt_of_sq_lt_sq hy hR0
    rw [abs_lt] at this
    exact ⟨by linarith [this.1], by linarith [this.2]⟩
  have hsup : Set.Ioo (c - R) (c + R) \ {c} ⊆ S := by
    rintro x ⟨⟨h1, h2⟩, hxc⟩
    have hne : x - c ≠ 0 := sub_ne_zero.mpr hxc
    have hpos : 0 < (x - c) ^ 2 := by positivity
    have hlt : (x - c) ^ 2 < R ^ 2 := by
      have : |x - c| < R := by rw [abs_lt]; constructor <;> linarith
      have h0 : 0 ≤ |x - c| := abs_nonneg _
      calc (x - c) ^ 2 = |x - c| ^ 2 := (sq_abs _).symm
        _ < R ^ 2 := by gcongr
    simp only [S, Set.mem_setOf_eq, abs_lt]
    constructor <;> nlinarith
  have hvolI : volume (Set.Ioo (c - R) (c + R)) = ENNReal.ofReal (2 * R) := by
    rw [Real.volume_Ioo]; congr 1; ring
  apply le_antisymm
  · rw [← hvolI]; exact measure_mono hsub
  · rw [← hvolI, ← measure_diff_null (s := Set.Ioo (c - R) (c + R)) (measure_singleton c)]
    exact measure_mono hsup

/-- Lemma 2.2: for a monic quadratic with roots in `[-1,1]`, the sublevel set has measure
`2 √(1 + d²)` with `d = |r₂ - r₁|/2`. -/
theorem volume_deg2 (r₁ r₂ : ℝ) (h1 : r₁ ∈ Set.Icc (-1 : ℝ) 1) (h2 : r₂ ∈ Set.Icc (-1 : ℝ) 1) :
    volume {x : ℝ | |(x - r₁) * (x - r₂)| < 1} =
      ENNReal.ofReal (2 * √(1 + (|r₂ - r₁| / 2) ^ 2)) := by
  obtain ⟨a1, b1⟩ := h1
  obtain ⟨a2, b2⟩ := h2
  have hd0 : 0 ≤ |r₂ - r₁| / 2 := by positivity
  have hd1 : |r₂ - r₁| / 2 ≤ 1 := by
    rw [div_le_one (by norm_num), abs_le]; constructor <;> linarith
  rw [← volume_quad ((r₁ + r₂) / 2) (|r₂ - r₁| / 2) hd0 hd1]
  congr 1
  ext x
  simp only [Set.mem_setOf_eq]
  have : (x - r₁) * (x - r₂) = (x - (r₁ + r₂) / 2) ^ 2 - (|r₂ - r₁| / 2) ^ 2 := by
    rw [div_pow, sq_abs]; ring
  rw [this]

/-- `m₂ = 2`: the measure is at least `2`, with equality iff the two roots coincide. -/
theorem deg2_ge_two (r₁ r₂ : ℝ) (h1 : r₁ ∈ Set.Icc (-1 : ℝ) 1) (h2 : r₂ ∈ Set.Icc (-1 : ℝ) 1) :
    ENNReal.ofReal 2 ≤ volume {x : ℝ | |(x - r₁) * (x - r₂)| < 1} ∧
      (volume {x : ℝ | |(x - r₁) * (x - r₂)| < 1} = ENNReal.ofReal 2 ↔ r₁ = r₂) := by
  rw [volume_deg2 r₁ r₂ h1 h2]
  have hsq : 1 ≤ √(1 + (|r₂ - r₁| / 2) ^ 2) := by
    have := Real.sqrt_le_sqrt (le_add_of_nonneg_right (sq_nonneg (|r₂ - r₁| / 2)) :
      (1 : ℝ) ≤ 1 + (|r₂ - r₁| / 2) ^ 2)
    simpa using this
  constructor
  · exact ENNReal.ofReal_le_ofReal (by linarith)
  · constructor
    · intro h
      have h' := (ENNReal.ofReal_eq_ofReal_iff (p := 2 * √(1 + (|r₂ - r₁| / 2) ^ 2)) (q := 2)
        (by positivity) (by norm_num)).mp h
      have hs1 : √(1 + (|r₂ - r₁| / 2) ^ 2) = 1 := by linarith
      have : 1 + (|r₂ - r₁| / 2) ^ 2 = 1 := by
        have := Real.sq_sqrt (show (0:ℝ) ≤ 1 + (|r₂ - r₁| / 2) ^ 2 by positivity)
        rw [hs1] at this; linarith
      have habs : |r₂ - r₁| = 0 := by nlinarith [abs_nonneg (r₂ - r₁)]
      have := abs_eq_zero.mp habs
      linarith
    · rintro rfl
      simp

end EP1038
