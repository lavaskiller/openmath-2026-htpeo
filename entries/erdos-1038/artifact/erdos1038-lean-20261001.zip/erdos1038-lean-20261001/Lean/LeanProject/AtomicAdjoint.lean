import LeanProject.AdjointJump

/-!
# Finite positive jumps and the endpoint correction

The integration domain is stated explicitly. Linearity of the adjoint is proved
through the integrable joint kernel, so no exchange of two principal values is used.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset

namespace EP1038.Stage11
open EP1038.Arc

structure AdjointIntegrable (ρ1 ρ2 : ℝ) (B f : ℝ → ℝ) : Prop where
  poisson1 : IntervalIntegrable (fun θ => f θ * Pq ρ1 θ) volume 0 π
  poisson2 : IntervalIntegrable (fun θ => f θ * Pq ρ2 θ) volume 0 π
  kernel : Integrable (weightedDQ B f) (angleMeasure.prod angleMeasure)

theorem weightedDQ_add (B f g : ℝ → ℝ) :
    weightedDQ B (f + g) = weightedDQ B f + weightedDQ B g := by
  funext p
  simp only [weightedDQ, Pi.add_apply, div_eq_mul_inv]
  ring

theorem weightedDQ_smul (B f : ℝ → ℝ) (c : ℝ) :
    weightedDQ B (c • f) = c • weightedDQ B f := by
  funext p
  simp only [weightedDQ, Pi.smul_apply, smul_eq_mul, div_eq_mul_inv]
  ring

theorem AdjointIntegrable.zero (ρ1 ρ2 : ℝ) (B : ℝ → ℝ) :
    AdjointIntegrable ρ1 ρ2 B 0 := by
  constructor
  · simpa only [Pi.zero_apply, zero_mul] using
      (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => (0 : ℝ)) volume 0 π)
  · simpa only [Pi.zero_apply, zero_mul] using
      (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => (0 : ℝ)) volume 0 π)
  · have hz : weightedDQ B (0 : ℝ → ℝ) = 0 := by funext p; simp [weightedDQ]
    rw [hz]
    exact integrable_zero (ℝ × ℝ) ℝ (angleMeasure.prod angleMeasure)

theorem AdjointIntegrable.add {ρ1 ρ2 : ℝ} {B f g : ℝ → ℝ}
    (hf : AdjointIntegrable ρ1 ρ2 B f) (hg : AdjointIntegrable ρ1 ρ2 B g) :
    AdjointIntegrable ρ1 ρ2 B (f + g) := by
  refine ⟨?_, ?_, ?_⟩
  · simpa only [Pi.add_apply, add_mul] using hf.poisson1.add hg.poisson1
  · simpa only [Pi.add_apply, add_mul] using hf.poisson2.add hg.poisson2
  · rw [weightedDQ_add]
    exact hf.kernel.add hg.kernel

theorem AdjointIntegrable.smul {ρ1 ρ2 : ℝ} {B f : ℝ → ℝ}
    (hf : AdjointIntegrable ρ1 ρ2 B f) (c : ℝ) :
    AdjointIntegrable ρ1 ρ2 B (c • f) := by
  refine ⟨?_, ?_, ?_⟩
  · simpa only [Pi.smul_apply, smul_eq_mul, mul_assoc] using hf.poisson1.const_mul c
  · simpa only [Pi.smul_apply, smul_eq_mul, mul_assoc] using hf.poisson2.const_mul c
  · rw [weightedDQ_smul]
    exact hf.kernel.smul c

theorem int_HT_add {B f g : ℝ → ℝ}
    (hf : Integrable (weightedDQ B f) (angleMeasure.prod angleMeasure))
    (hg : Integrable (weightedDQ B g) (angleMeasure.prod angleMeasure)) :
    (∫ θ in (0 : ℝ)..π, HT (f + g) θ * B θ) =
      (∫ θ in (0 : ℝ)..π, HT f θ * B θ) + (∫ θ in (0 : ℝ)..π, HT g θ * B θ) := by
  have hfg : Integrable (weightedDQ B (f + g)) (angleMeasure.prod angleMeasure) := by
    rw [weightedDQ_add]; exact hf.add hg
  have h : (∫ p, weightedDQ B (f + g) p ∂angleMeasure.prod angleMeasure) =
      (∫ p, weightedDQ B f p ∂angleMeasure.prod angleMeasure) +
      (∫ p, weightedDQ B g p ∂angleMeasure.prod angleMeasure) := by
    rw [weightedDQ_add]; exact MeasureTheory.integral_add hf hg
  rw [integral_weightedDQ hfg, integral_weightedDQ hf, integral_weightedDQ hg] at h
  nlinarith [Real.pi_pos]

theorem int_HT_smul {B f : ℝ → ℝ}
    (hf : Integrable (weightedDQ B f) (angleMeasure.prod angleMeasure)) (c : ℝ) :
    (∫ θ in (0 : ℝ)..π, HT (c • f) θ * B θ) =
      c * ∫ θ in (0 : ℝ)..π, HT f θ * B θ := by
  have hcf : Integrable (weightedDQ B (c • f)) (angleMeasure.prod angleMeasure) := by
    rw [weightedDQ_smul]; exact hf.smul c
  have h : (∫ p, weightedDQ B (c • f) p ∂angleMeasure.prod angleMeasure) =
      c * ∫ p, weightedDQ B f p ∂angleMeasure.prod angleMeasure := by
    rw [weightedDQ_smul]; exact MeasureTheory.integral_smul c _
  rw [integral_weightedDQ hcf, integral_weightedDQ hf] at h
  nlinarith [Real.pi_pos]

theorem Lfun_add {r ρ1 ρ2 σ1 σ2 : ℝ} {f g : ℝ → ℝ}
    (hf : AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) f)
    (hg : AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) g) :
    Lfun r ρ1 ρ2 σ1 σ2 (f + g) = Lfun r ρ1 ρ2 σ1 σ2 f + Lfun r ρ1 ρ2 σ1 σ2 g := by
  have h1 : (∫ θ in (0 : ℝ)..π, (f + g) θ * Pq ρ1 θ) =
      (∫ θ in (0 : ℝ)..π, f θ * Pq ρ1 θ) + (∫ θ in (0 : ℝ)..π, g θ * Pq ρ1 θ) := by
    simpa only [Pi.add_apply, add_mul] using
      intervalIntegral.integral_add hf.poisson1 hg.poisson1
  have h2 : (∫ θ in (0 : ℝ)..π, (f + g) θ * Pq ρ2 θ) =
      (∫ θ in (0 : ℝ)..π, f θ * Pq ρ2 θ) + (∫ θ in (0 : ℝ)..π, g θ * Pq ρ2 θ) := by
    simpa only [Pi.add_apply, add_mul] using
      intervalIntegral.integral_add hf.poisson2 hg.poisson2
  unfold Lfun
  rw [h1, h2, int_HT_add hf.kernel hg.kernel]
  simp only [Pi.add_apply]
  ring

theorem Lfun_smul {r ρ1 ρ2 σ1 σ2 : ℝ} {f : ℝ → ℝ}
    (hf : AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) f) (c : ℝ) :
    Lfun r ρ1 ρ2 σ1 σ2 (c • f) = c * Lfun r ρ1 ρ2 σ1 σ2 f := by
  have h1 : (∫ θ in (0 : ℝ)..π, (c • f) θ * Pq ρ1 θ) =
      c * ∫ θ in (0 : ℝ)..π, f θ * Pq ρ1 θ := by
    simpa only [Pi.smul_apply, smul_eq_mul, mul_assoc] using
      intervalIntegral.integral_const_mul c (fun θ => f θ * Pq ρ1 θ)
  have h2 : (∫ θ in (0 : ℝ)..π, (c • f) θ * Pq ρ2 θ) =
      c * ∫ θ in (0 : ℝ)..π, f θ * Pq ρ2 θ := by
    simpa only [Pi.smul_apply, smul_eq_mul, mul_assoc] using
      intervalIntegral.integral_const_mul c (fun θ => f θ * Pq ρ2 θ)
  unfold Lfun
  rw [h1, h2, int_HT_smul hf.kernel]
  simp only [Pi.smul_apply, smul_eq_mul]
  ring

theorem jump_poisson_integrable {ρ : ℝ} (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (z : ℝ) :
    IntervalIntegrable (fun θ => jump z θ * Pq ρ θ) volume 0 π := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le]
  apply (integrableOn_const (C := (1 + ρ) / (1 - ρ)) measure_Ioc_lt_top.ne).mono'
    ((measurable_jump z).mul (Pq_cont hρ0 hρ1).measurable).aestronglyMeasurable
  apply Eventually.of_forall
  intro θ
  rw [Real.norm_eq_abs, Pi.mul_apply, abs_mul, abs_of_nonneg (Pq_nonneg hρ0 hρ1 θ)]
  have hj : |jump z θ| ≤ 1 := by simp only [jump]; split_ifs <;> norm_num
  exact (mul_le_of_le_one_left (Pq_nonneg hρ0 hρ1 θ) hj).trans (Pq_le hρ0 hρ1 θ)

theorem XLip.adjointIntegrable {ρ1 ρ2 σ1 σ2 M : ℝ} {f : ℝ → ℝ}
    (hf : XLip M f) (hM : 0 ≤ M) (h10 : 0 ≤ ρ1) (h11 : ρ1 < 1)
    (h20 : 0 ≤ ρ2) (h21 : ρ2 < 1) (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) :
    AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) f := by
  refine ⟨(hf.continuous.mul (Pq_cont h10 h11)).intervalIntegrable _ _,
    (hf.continuous.mul (Pq_cont h20 h21)).intervalIntegrable _ _, ?_⟩
  have hb : ∀ θ, |Bxi ρ1 ρ2 σ1 σ2 θ| ≤ σ1 * Pq ρ1 0 + σ2 * Pq ρ2 0 := by
    intro θ
    obtain ⟨hn, hl⟩ := Bxi_bounds h10 h11 h20 h21 hs1 hs2 θ
    rwa [abs_of_nonneg hn]
  exact weightedDQ_integrable hf hM (Bxi_cont h10 h11 h20 h21).measurable hb

/-- A cosine-Lipschitz remainder plus finitely many nonnegative atomic jumps. -/
theorem finite_jump_adjoint {ι : Type*} {r ρ1 ρ2 σ1 σ2 M : ℝ} {fc : ℝ → ℝ}
    (hr : 0 < r) (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (hM : 0 ≤ M) (hfc : XLip M fc)
    (s : Finset ι) (Δ z : ι → ℝ) (hΔ : ∀ i ∈ s, 0 ≤ Δ i) (hz : ∀ i ∈ s, -1 < z i) :
    AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (fc + ∑ i ∈ s, Δ i • jump (z i)) ∧
      0 ≤ Lfun r ρ1 ρ2 σ1 σ2 (fc + ∑ i ∈ s, Δ i • jump (z i)) := by
  classical
  have hj : ∀ i ∈ s, AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (jump (z i)) ∧
      0 ≤ Lfun r ρ1 ρ2 σ1 σ2 (jump (z i)) := by
    intro i hi
    obtain ⟨hki, hL⟩ := L_jump_nonneg hr h10 h11 h20 h21 hs1 hs2 (hz i hi)
    exact ⟨⟨jump_poisson_integrable h10.le h11 _, jump_poisson_integrable h20.le h21 _, hki⟩, hL⟩
  have hsum : AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (∑ i ∈ s, Δ i • jump (z i)) ∧
      0 ≤ Lfun r ρ1 ρ2 σ1 σ2 (∑ i ∈ s, Δ i • jump (z i)) := by
    induction s using Finset.induction_on with
    | empty =>
      simp only [Finset.sum_empty]
      exact ⟨AdjointIntegrable.zero _ _ _, by simp [Lfun, HT]⟩
    | @insert i s hi ih =>
      have hj' := hj i (mem_insert_self i s)
      obtain ⟨hsi, hsL⟩ := ih (fun j hj => hΔ j (mem_insert_of_mem hj))
        (fun j hmem => hz j (mem_insert_of_mem hmem))
        (fun j hmem => hj j (mem_insert_of_mem hmem))
      rw [Finset.sum_insert hi]
      refine ⟨(hj'.1.smul (Δ i)).add hsi, ?_⟩
      rw [Lfun_add (hj'.1.smul (Δ i)) hsi, Lfun_smul hj'.1]
      exact add_nonneg (mul_nonneg (hΔ i (mem_insert_self i s)) hj'.2) hsL
  have hfci := hfc.adjointIntegrable hM h10.le h11 h20.le h21 hs1 hs2
  refine ⟨hfci.add hsum.1, ?_⟩
  rw [Lfun_add hfci hsum.1, L_XLip hr h10 h11 h20 h21 hM hfc, zero_add]
  exact hsum.2

noncomputable def widthVariation (r ρ1 ρ2 σ1 σ2 : ℝ) (f : ℝ → ℝ) : ℝ :=
  -poissonPair r ρ1 ρ2 σ1 σ2 f

noncomputable def adjointIntegral (r ρ1 ρ2 σ1 σ2 : ℝ) (f : ℝ → ℝ) : ℝ :=
  1 / (π * r) * ∫ θ in (0 : ℝ)..π, HT f θ * Bxi ρ1 ρ2 σ1 σ2 θ

theorem endpoint_corrected_inequality {r ρ1 ρ2 σ1 σ2 : ℝ} {f : ℝ → ℝ}
    (hL : 0 ≤ Lfun r ρ1 ρ2 σ1 σ2 f) :
    -Gam r ρ1 ρ2 σ1 σ2 * f π ≤
      widthVariation r ρ1 ρ2 σ1 σ2 f - adjointIntegral r ρ1 ρ2 σ1 σ2 f := by
  dsimp [Lfun, widthVariation, poissonPair, adjointIntegral] at *
  linarith

theorem Gam_nonneg {r ρ1 ρ2 σ1 σ2 : ℝ} (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) : 0 ≤ Gam r ρ1 ρ2 σ1 σ2 := by
  have hk1 : 0 < Kr r ρ1 := div_pos (mul_pos hr (by nlinarith)) (by positivity)
  have hk2 : 0 < Kr r ρ2 := div_pos (mul_pos hr (by nlinarith)) (by positivity)
  exact add_nonneg (div_nonneg hs1 hk1.le) (div_nonneg hs2 hk2.le)

/-- The endpoint value is nonpositive, so the correction improves the lower bound. -/
theorem finite_jump_endpoint_bound {ι : Type*} {r ρ1 ρ2 σ1 σ2 M : ℝ} {fc : ℝ → ℝ}
    (hr : 0 < r) (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (hM : 0 ≤ M) (hfc : XLip M fc)
    (s : Finset ι) (Δ z : ι → ℝ) (hΔ : ∀ i ∈ s, 0 ≤ Δ i) (hz : ∀ i ∈ s, -1 < z i)
    (hend : (fc + ∑ i ∈ s, Δ i • jump (z i)) π ≤ 0) :
    adjointIntegral r ρ1 ρ2 σ1 σ2 (fc + ∑ i ∈ s, Δ i • jump (z i)) ≤
      widthVariation r ρ1 ρ2 σ1 σ2 (fc + ∑ i ∈ s, Δ i • jump (z i)) := by
  have hL := (finite_jump_adjoint hr h10 h11 h20 h21 hs1 hs2 hM hfc s Δ z hΔ hz).2
  have hcorr := endpoint_corrected_inequality hL
  have hn := mul_nonneg_of_nonpos_of_nonpos
    (neg_nonpos.mpr (Gam_nonneg hr h10 h11 h20 h21 hs1 hs2)) hend
  linarith

end EP1038.Stage11
