import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk11
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_40 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((510539078986510094776890630235749 : ℝ) / 5192296858534827628530496329220096) ((522487852132213366841193764225023 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((98326249999 : ℝ) / 1000000000000) ((40251 : ℝ) / 400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1098326249999 : ℝ) / 1000000000000) ((440251 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((93787430099 : ℝ) / 1000000000000) ((95880471703 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_559.1 dlower_log_560.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((93787430099 : ℝ) / 500000000000) ((95880471703 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((501386237153 : ℝ) / 1000000000000) ((252786160181 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1159732123907 : ℝ) / 500000000000) ((-229632969883 : ℝ) / 100000000000) := rb_log hqr (by norm_num) dlower_log_561.1 dlower_log_562.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((229632969883 : ℝ) / 100000000000) ((1159732123907 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((216164675797 : ℝ) / 1000000000000) ((110082694271 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((389917305729 : ℝ) / 500000000000) ((783835324203 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((4834025719 : ℝ) / 500000000000) ((10125893757 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((315420646717 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((954046103 : ℝ) / 3125000000) ((305752595279 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((315420646717 : ℝ) / 1000000000000) ((315420646717 : ℝ) / 1000000000000) ((315420646717 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((684579353283 : ℝ) / 1000000000000))
  have h11 : RB z11 ((696811917 : ℝ) / 1562500000) ((446628420523 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((684579353283 : ℝ) / 1000000000000) ((684579353283 : ℝ) / 1000000000000) ((684579353283 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-807526853751 : ℝ) / 1000000000000) ((-161205660813 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_563.1 dlower_log_564.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-632968073213 : ℝ) / 1000000000000) ((-157142192331 : ℝ) / 250000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((315420646717 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1153848144589 : ℝ) / 1000000000000) ((-1153848144587 : ℝ) / 1000000000000) := rb_log (show RB ((315420646717 : ℝ) / 1000000000000) ((315420646717 : ℝ) / 1000000000000) ((315420646717 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_565.1 dlower_log_565.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((260440035687 : ℝ) / 500000000000) ((105055875053 : ℝ) / 200000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((3826937753 : ℝ) / 250000000000) ((373330283 : ℝ) / 15625000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((4834025719 : ℝ) / 500000000000) ((10125893757 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((182525902991 : ℝ) / 125000000000)) - (z17)
  have h18 : RB z18 ((1450081330171 : ℝ) / 1000000000000) ((145053917249 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((182525902991 : ℝ) / 125000000000) ((182525902991 : ℝ) / 125000000000) ((182525902991 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((57525902991 : ℝ) / 125000000000))
  have h19 : RB z19 ((157546563241 : ℝ) / 50000000000) ((1575963063019 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((57525902991 : ℝ) / 125000000000) ((57525902991 : ℝ) / 125000000000) ((57525902991 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1147698048769 : ℝ) / 1000000000000) ((1148013734551 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_566.1 dlower_log_567.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((223753665483 : ℝ) / 250000000000) ((224963429453 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((182525902991 : ℝ) / 125000000000))
  have h22 : RB z22 ((94644589961 : ℝ) / 250000000000) ((189289179923 : ℝ) / 500000000000) := rb_log (show RB ((182525902991 : ℝ) / 125000000000) ((182525902991 : ℝ) / 125000000000) ((182525902991 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_568.1 dlower_log_568.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((258218151043 : ℝ) / 500000000000) ((32579709873 : ℝ) / 62500000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2715995431 : ℝ) / 250000000000) ((3977824163 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1098326249999 : ℝ) / 1000000000000) ((440251 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((301580137859 : ℝ) / 250000000000) ((1211380893757 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((6604033497 : ℝ) / 4000000000) ((41448352961 : ℝ) / 25000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1144786577211 : ℝ) / 1000000000000))
  have h28 : RB z28 ((236256528213 : ℝ) / 125000000000) ((1897980724691 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1144786577211 : ℝ) / 1000000000000) ((1144786577211 : ℝ) / 1000000000000) ((1144786577211 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((4834025719 : ℝ) / 500000000000) ((10125893757 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((57572438364025624630547 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((262388233 : ℝ) / 12500000000) ((21985115719 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((57572438364025624630547 : ℝ) / 125000000000000000000000) ((57572438364025624630547 : ℝ) / 125000000000000000000000) ((57572438364025624630547 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((978014884281 : ℝ) / 1000000000000) ((12237611767 : ℝ) / 12500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((924249604403 : ℝ) / 500000000000) ((929070050001 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((315420646717 : ℝ) / 1000000000000)) ((3826937753 : ℝ) / 250000000000) ((373330283 : ℝ) / 15625000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((182525902991 : ℝ) / 125000000000)) ((2715995431 : ℝ) / 250000000000) ((3977824163 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((315420646717 : ℝ) / 1000000000000)) (wl := ((182525902991 : ℝ) / 125000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((924249604403 : ℝ) / 500000000000) ≤ D0q (q) * (((182525902991 : ℝ) / 125000000000) - ((315420646717 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((182525902991 : ℝ) / 125000000000) * ((315420646717 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_41 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((522487852132213366841193764225023 : ℝ) / 5192296858534827628530496329220096) ((534436625277916638905496898214297 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((100627499999 : ℝ) / 1000000000000) ((82343 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1100627499999 : ℝ) / 1000000000000) ((882343 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((95880471701 : ℝ) / 1000000000000) ((97969141631 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_569.1 dlower_log_570.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((95880471701 : ℝ) / 500000000000) ((97969141631 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((497208897297 : ℝ) / 1000000000000) ((250693118579 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1148164849421 : ℝ) / 500000000000) ((-568429569423 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_571.1 dlower_log_572.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((568429569423 : ℝ) / 250000000000) ((1148164849421 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((54130826417 : ℝ) / 250000000000) ((44102758207 : ℝ) / 200000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((155897241793 : ℝ) / 200000000000) ((195869173583 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2531473439 : ℝ) / 250000000000) ((10594327577 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((155623295383 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((300652263189 : ℝ) / 1000000000000) ((30112069701 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((155623295383 : ℝ) / 500000000000) ((155623295383 : ℝ) / 500000000000) ((155623295383 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((344376704617 : ℝ) / 500000000000))
  have h11 : RB z11 ((218258275863 : ℝ) / 500000000000) ((437196670061 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((344376704617 : ℝ) / 500000000000) ((344376704617 : ℝ) / 500000000000) ((344376704617 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-828928985233 : ℝ) / 1000000000000) ((-827372139219 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_573.1 dlower_log_574.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-649446541187 : ℝ) / 1000000000000) ((-644925172203 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((155623295383 : ℝ) / 500000000000))
  have h14 : RB z14 ((-583584892313 : ℝ) / 500000000000) ((-72948111539 : ℝ) / 62500000000) := rb_log (show RB ((155623295383 : ℝ) / 500000000000) ((155623295383 : ℝ) / 500000000000) ((155623295383 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_575.1 dlower_log_575.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((517723243437 : ℝ) / 1000000000000) ((522244612423 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((16337006279 : ℝ) / 1000000000000) ((12517857563 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2531473439 : ℝ) / 250000000000) ((10594327577 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((365534404407 : ℝ) / 250000000000)) - (z17)
  have h18 : RB z18 ((1451543290051 : ℝ) / 1000000000000) ((45375366371 : ℝ) / 31250000000) := rb_widen (rb_sub (show RB ((365534404407 : ℝ) / 250000000000) ((365534404407 : ℝ) / 250000000000) ((365534404407 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((115534404407 : ℝ) / 250000000000))
  have h19 : RB z19 ((3140932991997 : ℝ) / 1000000000000) ((1570973308043 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((115534404407 : ℝ) / 250000000000) ((115534404407 : ℝ) / 250000000000) ((115534404407 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1144519886993 : ℝ) / 1000000000000) ((228968509853 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_576.1 dlower_log_577.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((892137467797 : ℝ) / 1000000000000) ((896957456029 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((365534404407 : ℝ) / 250000000000))
  have h22 : RB z22 ((379899486601 : ℝ) / 1000000000000) ((379899486603 : ℝ) / 1000000000000) := rb_log (show RB ((365534404407 : ℝ) / 250000000000) ((365534404407 : ℝ) / 250000000000) ((365534404407 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_578.1 dlower_log_578.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((256118990597 : ℝ) / 500000000000) ((129264492357 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2712936009 : ℝ) / 250000000000) ((19849072131 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1100627499999 : ℝ) / 1000000000000) ((882343 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((605690446877 : ℝ) / 500000000000) ((1216451827577 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1644125936317 : ℝ) / 1000000000000) ((330201674851 : ℝ) / 200000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((575445513431 : ℝ) / 500000000000))
  have h28 : RB z28 ((946104893569 : ℝ) / 500000000000) ((380026144641 : ℝ) / 200000000000) := rb_widen (rb_mul h27 (show RB ((575445513431 : ℝ) / 500000000000) ((575445513431 : ℝ) / 500000000000) ((575445513431 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2531473439 : ℝ) / 250000000000) ((10594327577 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((56885668589679537952881 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((5562634451 : ℝ) / 250000000000) ((4655973921 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((56885668589679537952881 : ℝ) / 125000000000000000000000) ((56885668589679537952881 : ℝ) / 125000000000000000000000) ((56885668589679537952881 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((195344026079 : ℝ) / 200000000000) ((244437365549 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((462039847507 : ℝ) / 250000000000) ((464462948179 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((155623295383 : ℝ) / 500000000000)) ((16337006279 : ℝ) / 1000000000000) ((12517857563 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((365534404407 : ℝ) / 250000000000)) ((2712936009 : ℝ) / 250000000000) ((19849072131 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((155623295383 : ℝ) / 500000000000)) (wl := ((365534404407 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((462039847507 : ℝ) / 250000000000) ≤ D0q (q) * (((365534404407 : ℝ) / 250000000000) - ((155623295383 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((365534404407 : ℝ) / 250000000000) * ((155623295383 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_42 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((534436625277916638905496898214297 : ℝ) / 5192296858534827628530496329220096) ((546385398423619910969800032203571 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((102928749999 : ℝ) / 1000000000000) ((10523 : ℝ) / 100000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1102928749999 : ℝ) / 1000000000000) ((110523 : ℝ) / 100000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((97969141629 : ℝ) / 1000000000000) ((100053458107 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_579.1 dlower_log_580.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((97969141629 : ℝ) / 500000000000) ((100053458107 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((98608052869 : ℝ) / 200000000000) ((248604448651 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2273718277703 : ℝ) / 1000000000000) ((-562901712057 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_581.1 dlower_log_582.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((562901712057 : ℝ) / 250000000000) ((2273718277703 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((27105395443 : ℝ) / 125000000000) ((220824029601 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779175970399 : ℝ) / 1000000000000) ((97894604557 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1324290947 : ℝ) / 125000000000) ((110733529 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((153865229823 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((148328553373 : ℝ) / 500000000000) ((29713613207 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((153865229823 : ℝ) / 500000000000) ((153865229823 : ℝ) / 500000000000) ((153865229823 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((346134770177 : ℝ) / 500000000000))
  have h11 : RB z11 ((107132081311 : ℝ) / 250000000000) ((214610144423 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((346134770177 : ℝ) / 500000000000) ((346134770177 : ℝ) / 500000000000) ((346134770177 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-211849609969 : ℝ) / 250000000000) ((-52861562377 : ℝ) / 62500000000) := rb_log h11 (by norm_num) dlower_log_583.1 dlower_log_584.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-41477867587 : ℝ) / 62500000000) ((-65901534659 : ℝ) / 100000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((153865229823 : ℝ) / 500000000000))
  have h14 : RB z14 ((-1178531010179 : ℝ) / 1000000000000) ((-1178531010177 : ℝ) / 1000000000000) := rb_log (show RB ((153865229823 : ℝ) / 500000000000) ((153865229823 : ℝ) / 500000000000) ((153865229823 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_585.1 dlower_log_585.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((102977025757 : ℝ) / 200000000000) ((519515663589 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((17676231483 : ℝ) / 1000000000000) ((6618849811 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1324290947 : ℝ) / 125000000000) ((110733529 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((732046547159 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((726509870709 : ℝ) / 500000000000) ((726749383371 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((732046547159 : ℝ) / 500000000000) ((732046547159 : ℝ) / 500000000000) ((732046547159 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((232046547159 : ℝ) / 500000000000))
  have h19 : RB z19 ((782719975371 : ℝ) / 250000000000) ((3131912076559 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((232046547159 : ℝ) / 500000000000) ((232046547159 : ℝ) / 500000000000) ((232046547159 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1141314083729 : ℝ) / 1000000000000) ((1141643705117 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_586.1 dlower_log_587.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((889284508719 : ℝ) / 1000000000000) ((44704303623 : ℝ) / 50000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((732046547159 : ℝ) / 500000000000))
  have h22 : RB z22 ((381236002531 : ℝ) / 1000000000000) ((381236002533 : ℝ) / 1000000000000) := rb_log (show RB ((732046547159 : ℝ) / 500000000000) ((732046547159 : ℝ) / 500000000000) ((732046547159 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_588.1 dlower_log_588.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((254024253093 : ℝ) / 500000000000) ((512850069929 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2709902221 : ℝ) / 250000000000) ((1238112849 : ℝ) / 62500000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1102928749999 : ℝ) / 1000000000000) ((110523 : ℝ) / 100000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((608225913787 : ℝ) / 500000000000) ((12215333529 : ℝ) / 10000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1637286444329 : ℝ) / 1000000000000) ((822062968161 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((72272664667 : ℝ) / 62500000000))
  have h28 : RB z28 ((1893296866477 : ℝ) / 1000000000000) ((950602899729 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((72272664667 : ℝ) / 62500000000) ((72272664667 : ℝ) / 62500000000) ((72272664667 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1324290947 : ℝ) / 125000000000) ((110733529 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((112636510219753142722857 : ℝ) / 250000000000000000000000))
  have h30 : RB z30 ((11757208603 : ℝ) / 500000000000) ((12288813901 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((112636510219753142722857 : ℝ) / 250000000000000000000000) ((112636510219753142722857 : ℝ) / 250000000000000000000000) ((112636510219753142722857 : ℝ) / 250000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((487711186099 : ℝ) / 500000000000) ((488242791397 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((923382060387 : ℝ) / 500000000000) ((232062506637 : ℝ) / 125000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((153865229823 : ℝ) / 500000000000)) ((17676231483 : ℝ) / 1000000000000) ((6618849811 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((732046547159 : ℝ) / 500000000000)) ((2709902221 : ℝ) / 250000000000) ((1238112849 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((153865229823 : ℝ) / 500000000000)) (wl := ((732046547159 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((923382060387 : ℝ) / 500000000000) ≤ D0q (q) * (((732046547159 : ℝ) / 500000000000) - ((153865229823 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((732046547159 : ℝ) / 500000000000) * ((153865229823 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_43 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((546385398423619910969800032203571 : ℝ) / 5192296858534827628530496329220096) ((139583542892330795758525791548211 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((105229999999 : ℝ) / 1000000000000) ((3441 : ℝ) / 32000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1105229999999 : ℝ) / 1000000000000) ((35441 : ℝ) / 32000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((50026729053 : ℝ) / 500000000000) ((25533359811 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_589.1 dlower_log_590.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((50026729053 : ℝ) / 250000000000) ((25533359811 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((488880302071 : ℝ) / 1000000000000) ((123260066087 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-28145085603 : ℝ) / 12500000000) ((-2229973775983 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_591.1 dlower_log_592.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2229973775983 : ℝ) / 1000000000000) ((28145085603 : ℝ) / 12500000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((108562536673 : ℝ) / 500000000000) ((27637111121 : ℝ) / 125000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((97362888879 : ℝ) / 125000000000) ((391437463327 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((11073352899 : ℝ) / 1000000000000) ((11562969727 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((38153777129 : ℝ) / 125000000000)) - (z9)
  have h10 : RB z10 ((58733449461 : ℝ) / 200000000000) ((294156864133 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((38153777129 : ℝ) / 125000000000) ((38153777129 : ℝ) / 125000000000) ((38153777129 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((86846222871 : ℝ) / 125000000000))
  have h11 : RB z11 ((84536562903 : ℝ) / 200000000000) ((105846883149 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((86846222871 : ℝ) / 125000000000) ((86846222871 : ℝ) / 125000000000) ((86846222871 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-172226645739 : ℝ) / 200000000000) ((-859467366637 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_593.1 dlower_log_594.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-337079806627 : ℝ) / 500000000000) ((-83680225713 : ℝ) / 125000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((38153777129 : ℝ) / 125000000000))
  have h14 : RB z14 ((-29667224429 : ℝ) / 25000000000) ((-593344488579 : ℝ) / 500000000000) := rb_log (show RB ((38153777129 : ℝ) / 125000000000) ((38153777129 : ℝ) / 125000000000) ((38153777129 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_595.1 dlower_log_595.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((8008271311 : ℝ) / 15625000000) ((4040993527 : ℝ) / 7812500000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((4872274889 : ℝ) / 250000000000) ((5673373877 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((11073352899 : ℝ) / 1000000000000) ((11562969727 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1466073255403 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((363627571419 : ℝ) / 250000000000) ((181874987813 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((1466073255403 : ℝ) / 1000000000000) ((1466073255403 : ℝ) / 1000000000000) ((1466073255403 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((466073255403 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3120776120093 : ℝ) / 1000000000000) ((3121826634841 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((466073255403 : ℝ) / 1000000000000) ((466073255403 : ℝ) / 1000000000000) ((466073255403 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((45523269093 : ℝ) / 40000000000) ((142302286299 : ℝ) / 125000000000) := rb_log h19 (by norm_num) dlower_log_596.1 dlower_log_597.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((443227699011 : ℝ) / 500000000000) ((891239135593 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1466073255403 : ℝ) / 1000000000000))
  have h22 : RB z22 ((191293785897 : ℝ) / 500000000000) ((95646892949 : ℝ) / 250000000000) := rb_log (show RB ((1466073255403 : ℝ) / 1000000000000) ((1466073255403 : ℝ) / 1000000000000) ((1466073255403 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_598.1 dlower_log_598.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((251933913113 : ℝ) / 500000000000) ((508651563799 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5413780939 : ℝ) / 500000000000) ((617851929 : ℝ) / 31250000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1105229999999 : ℝ) / 1000000000000) ((35441 : ℝ) / 32000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1221533352897 : ℝ) / 1000000000000) ((1226625469727 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((815244770861 : ℝ) / 500000000000) ((818643222167 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1160843038371 : ℝ) / 1000000000000))
  have h28 : RB z28 ((473185608411 : ℝ) / 250000000000) ((76025302829 : ℝ) / 40000000000) := rb_widen (rb_mul h27 (show RB ((1160843038371 : ℝ) / 1000000000000) ((1160843038371 : ℝ) / 1000000000000) ((1160843038371 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((11073352899 : ℝ) / 1000000000000) ((11562969727 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((55936232241433557077987 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((24745483507 : ℝ) / 1000000000000) ((12919812061 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((55936232241433557077987 : ℝ) / 125000000000000000000000) ((55936232241433557077987 : ℝ) / 125000000000000000000000) ((55936232241433557077987 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((487080187939 : ℝ) / 500000000000) ((975254516493 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((921917340299 : ℝ) / 500000000000) ((926800249397 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((38153777129 : ℝ) / 125000000000)) ((4872274889 : ℝ) / 250000000000) ((5673373877 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1466073255403 : ℝ) / 1000000000000)) ((5413780939 : ℝ) / 500000000000) ((617851929 : ℝ) / 31250000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((38153777129 : ℝ) / 125000000000)) (wl := ((1466073255403 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((921917340299 : ℝ) / 500000000000) ≤ D0q (q) * (((1466073255403 : ℝ) / 1000000000000) - ((38153777129 : ℝ) / 125000000000)) * (1 - (q) ^ 2 / (((1466073255403 : ℝ) / 1000000000000) * ((38153777129 : ℝ) / 125000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
