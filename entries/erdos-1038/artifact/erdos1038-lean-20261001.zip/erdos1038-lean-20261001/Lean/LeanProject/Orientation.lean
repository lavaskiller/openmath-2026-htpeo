import LeanProject.Elementary
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.BigOperators

/-!
# EP-1038: orientation and localisation (Stage 15, second batch)

* `abs_sub_lt_exp` — for `-1 < x < 0` and `r ∈ [-1,1]`, `|x - r| < exp (-(x r))`.
* `orientation_prod_lt_one` — Lemma 7.3 in product form: if all roots lie in `[-1,1]`, their sum is
  `≤ 0` and there is at least one root, then `∏ |x - r| < 1` for every `x ∈ (-1, 0)`.
* `localisation_one_le_prod` — Lemma 1.1(a), pointwise core: if `|x - r| ≥ 1` for all roots then
  `∏ |x - r| ≥ 1` (the set form is `lemma11a` in Bridge.lean).
* `abs_eval_prod` — `|p(x)| = ∏ |x - r|` for `p = ∏ (X - C r)`, linking the product form to polynomials.
* `orientation_poly` — Lemma 7.3 for polynomials.
-/

open Real Polynomial

namespace EP1038

/-- Pointwise strict bound: `|x - r| < exp (-(x * r))` for `-1 < x < 0`, `r ∈ [-1,1]`. -/
theorem abs_sub_lt_exp {x r : ℝ} (hx1 : -1 < x) (hx0 : x < 0) (hr : r ∈ Set.Icc (-1 : ℝ) 1) :
    |x - r| < exp (-(x * r)) := by
  obtain ⟨hr1, hr2⟩ := hr
  have h1 : |x - r| ≤ 1 - x * r := orientation_abs_le hx1 hx0 hr1 hr2
  rcases eq_or_ne r 0 with rfl | hr0
  · simp only [sub_zero, mul_zero, neg_zero, exp_zero]
    rw [abs_of_neg hx0]; linarith
  · have hne : -(x * r) ≠ 0 := by
      intro h; apply hr0; nlinarith [mul_eq_zero.mp (neg_eq_zero.mp h)]
    have h2 : -(x * r) + 1 < exp (-(x * r)) := add_one_lt_exp hne
    linarith

/-- Strict comparison of finite products: `0 ≤ a_i < b_i` termwise and `s ≠ 0` give
`∏ a_i < ∏ b_i`. -/
theorem prod_lt_prod_of_lt {ι : Type*} (s : Multiset ι) (a b : ι → ℝ) (hs : s ≠ 0)
    (ha : ∀ i ∈ s, 0 ≤ a i) (hab : ∀ i ∈ s, a i < b i) :
    (s.map a).prod < (s.map b).prod := by
  induction s using Multiset.induction_on with
  | empty => exact absurd rfl hs
  | cons i s ih =>
    simp only [Multiset.map_cons, Multiset.prod_cons]
    have hai : 0 ≤ a i := ha i (Multiset.mem_cons_self i s)
    have habi : a i < b i := hab i (Multiset.mem_cons_self i s)
    have hA : 0 ≤ (s.map a).prod :=
      Multiset.prod_nonneg (fun y hy => by
        obtain ⟨j, hj, rfl⟩ := Multiset.mem_map.mp hy
        exact ha j (Multiset.mem_cons_of_mem hj))
    have hB : 0 < (s.map b).prod :=
      Multiset.prod_pos (fun y hy => by
        obtain ⟨j, hj, rfl⟩ := Multiset.mem_map.mp hy
        exact lt_of_le_of_lt (ha j (Multiset.mem_cons_of_mem hj)) (hab j (Multiset.mem_cons_of_mem hj)))
    have hAB : (s.map a).prod ≤ (s.map b).prod := by
      rcases eq_or_ne s 0 with rfl | hs'
      · simp
      · exact le_of_lt (ih hs' (fun j hj => ha j (Multiset.mem_cons_of_mem hj))
          (fun j hj => hab j (Multiset.mem_cons_of_mem hj)))
    calc a i * (s.map a).prod ≤ a i * (s.map b).prod := mul_le_mul_of_nonneg_left hAB hai
      _ < b i * (s.map b).prod := mul_lt_mul_of_pos_right habi hB

/-- Lemma 7.3 (product form). -/
theorem orientation_prod_lt_one (s : Multiset ℝ) (hs : ∀ r ∈ s, r ∈ Set.Icc (-1 : ℝ) 1)
    (hne : s ≠ 0) (hsum : s.sum ≤ 0) {x : ℝ} (hx1 : -1 < x) (hx0 : x < 0) :
    (s.map fun r => |x - r|).prod < 1 := by
  have hlt := prod_lt_prod_of_lt s (fun r => |x - r|) (fun r => exp (-(x * r))) hne
    (fun r _ => abs_nonneg _) (fun r hr => abs_sub_lt_exp hx1 hx0 (hs r hr))
  have hexp : ∀ t : Multiset ℝ, (t.map fun r => exp (-(x * r))).prod = exp (-(x * t.sum)) := by
    intro t
    induction t using Multiset.induction_on with
    | empty => simp
    | cons a t iht =>
      rw [Multiset.map_cons, Multiset.prod_cons, iht, Multiset.sum_cons, ← Real.exp_add]
      congr 1; ring
  have hle : exp (-(x * s.sum)) ≤ 1 := by
    calc exp (-(x * s.sum)) ≤ exp 0 := Real.exp_le_exp.mpr (by nlinarith)
      _ = 1 := Real.exp_zero
  rw [hexp s] at hlt
  linarith

/-- Lemma 1.1(a): if every root is at distance `≥ 1` from `x` then `∏ |x - r| ≥ 1`. -/
theorem localisation_one_le_prod (s : Multiset ℝ) {x : ℝ} (h : ∀ r ∈ s, 1 ≤ |x - r|) :
    1 ≤ (s.map fun r => |x - r|).prod :=
  one_le_prod _ (fun y hy => by
    obtain ⟨r, hr, rfl⟩ := Multiset.mem_map.mp hy
    exact h r hr)

/-- `|p(x)| = ∏ |x - r|` for `p = ∏ (X - C r)`. -/
theorem abs_eval_prod (s : Multiset ℝ) (x : ℝ) :
    |((s.map fun r => X - C r).prod).eval x| = (s.map fun r => |x - r|).prod := by
  induction s using Multiset.induction_on with
  | empty => simp
  | cons a s ih =>
    simp only [Multiset.map_cons, Multiset.prod_cons, eval_mul, eval_sub, eval_X, eval_C, abs_mul]
    rw [ih]

/-- Lemma 7.3 for polynomials: a monic polynomial whose (nonempty multiset of) roots lie in
`[-1,1]` with nonpositive sum satisfies `|p(x)| < 1` on `(-1, 0)`. -/
theorem orientation_poly (s : Multiset ℝ) (hs : ∀ r ∈ s, r ∈ Set.Icc (-1 : ℝ) 1)
    (hne : s ≠ 0) (hsum : s.sum ≤ 0) {x : ℝ} (hx1 : -1 < x) (hx0 : x < 0) :
    |((s.map fun r => X - C r).prod).eval x| < 1 := by
  rw [abs_eval_prod]; exact orientation_prod_lt_one s hs hne hsum hx1 hx0

end EP1038
