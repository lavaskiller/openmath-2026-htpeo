import LeanProject.MaterialDictionary
import LeanProject.BlockRed

/-!
# Actual residual blocks, retaining multiplicities

Blocks are indexed by the distinct original residual roots. The angular sets are
fibers of the actual residual quantile; they partition the reference interval.
-/

open Real Set MeasureTheory Finset Filter Topology intervalIntegral
open scoped ENNReal

namespace EP1038.AtomicQuantile

theorem step_mem_range {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) (u : ℝ) :
    step hn d u ∈ Set.range d := by
  by_cases h0 : u ≤ 0
  · exact ⟨⟨0, hn⟩, by simp [step, h0]⟩
  by_cases h1 : 1 < u
  · exact ⟨⟨n - 1, by omega⟩, by simp [step, h0, h1]⟩
  obtain ⟨j, hj⟩ := cell_cover hn ⟨lt_of_not_ge h0, le_of_not_gt h1⟩
  exact ⟨j, (step_on_cell hn d hj).symm⟩

end EP1038.AtomicQuantile

namespace EP1038.NormalForm
open NormalData

namespace NormalData

noncomputable def residualValues {n : ℕ} (a : NormalData n) : Finset ℝ :=
  a.residualIndices.image a.roots

noncomputable def multiplicity {n : ℕ} (a : NormalData n) (v : ℝ) : ℕ :=
  (univ.filter (fun i => a.roots i = v)).card

end NormalData

theorem residual_value_ne_main {n : ℕ} (a : NormalData n) {v : ℝ}
    (hv : v ∈ a.residualValues) : v ≠ a.roots a.main := by
  classical
  obtain ⟨i, hi, rfl⟩ := mem_image.mp hv
  exact (mem_filter.mp hi).2

theorem multiplicity_pos {n : ℕ} (a : NormalData n) {v : ℝ}
    (hv : v ∈ a.residualValues) : 0 < a.multiplicity v := by
  classical
  obtain ⟨i, hi, rfl⟩ := mem_image.mp hv
  exact card_pos.mpr ⟨i, by simp⟩

theorem ordered_atom_original {n : ℕ} (a : NormalData n)
    (j : Fin a.sortedLocations.length) :
    ∃ v ∈ a.residualValues, a.orderedAtoms j = v - a.roots a.main := by
  classical
  have hm : a.orderedAtoms j ∈ a.residualIndices.val.map a.locations := by
    apply (Multiset.mem_sort (r := (· ≤ ·))).mp
    exact List.getElem_mem j.isLt
  obtain ⟨i, hi, heq⟩ := Multiset.mem_map.mp hm
  exact ⟨a.roots i, mem_image.mpr ⟨i, hi, rfl⟩, heq.symm⟩

theorem residualQuantile_original {n : ℕ} (a : NormalData n)
    (hres : 0 < a.residualCount) (u : ℝ) :
    ∃ v ∈ a.residualValues, a.residualQuantile hres u = v - a.roots a.main := by
  obtain ⟨j, hj⟩ := AtomicQuantile.step_mem_range (sorted_length_pos a hres) a.orderedAtoms u
  obtain ⟨v, hv, heq⟩ := ordered_atom_original a j
  exact ⟨v, hv, hj.symm.trans heq⟩

theorem ordered_atom_exists {n : ℕ} (a : NormalData n) {v : ℝ}
    (hv : v ∈ a.residualValues) :
    ∃ j : Fin a.sortedLocations.length, a.orderedAtoms j = v - a.roots a.main := by
  classical
  obtain ⟨i, hi, rfl⟩ := mem_image.mp hv
  have hm : a.locations i ∈ a.sortedLocations := by
    apply (Multiset.mem_sort (r := (· ≤ ·))).mpr
    exact Multiset.mem_map.mpr ⟨i, hi, rfl⟩
  obtain ⟨j, hj, heq⟩ := List.mem_iff_getElem.mp hm
  exact ⟨⟨j, hj⟩, heq⟩

end EP1038.NormalForm

namespace EP1038.Stage12
open EP1038.Arc EP1038.Stage11 EP1038.NormalForm NormalData AngleReference

noncomputable def blockSet {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : Set ℝ :=
  Icc 0 π ∩ {θ | A.angularTarget (a.residualQuantile hres) θ = v - a.roots a.main}

theorem blockSet_measurable {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : MeasurableSet (blockSet A a hres v) := by
  apply measurableSet_Icc.inter
  exact (measurable_residualQuantile a hres |>.comp
    (A.cdf_continuous.measurable.comp
      (Real.continuous_arccos.comp Real.continuous_cos).measurable)).stronglyMeasurable.measurableSet_eq_fun
        stronglyMeasurable_const

theorem blockSet_disjoint {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v w : ℝ} (hvw : v ≠ w) :
    Disjoint (blockSet A a hres v) (blockSet A a hres w) := by
  apply Set.disjoint_left.mpr
  intro θ hv hw
  change θ ∈ Icc 0 π ∩ _ at hv hw
  have h1 : A.angularTarget (a.residualQuantile hres) θ = v - a.roots a.main := hv.2
  have h2 : A.angularTarget (a.residualQuantile hres) θ = w - a.roots a.main := hw.2
  exact hvw (by linarith)

theorem blockSet_cover {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {θ : ℝ} (hθ : θ ∈ Icc (0 : ℝ) π) :
    ∃ v ∈ a.residualValues, θ ∈ blockSet A a hres v := by
  obtain ⟨v, hv, heq⟩ := residualQuantile_original a hres (A.cdf (foldedAngle θ))
  exact ⟨v, hv, hθ, heq⟩

theorem blockSet_orderConvex {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : OrdConnected (blockSet A a hres v) := by
  refine ⟨?_⟩
  intro x hx y hy z hz
  change x ∈ Icc 0 π ∩ _ at hx
  change y ∈ Icc 0 π ∩ _ at hy
  have hzc : z ∈ Icc (0 : ℝ) π := ⟨hx.1.1.trans hz.1, hz.2.trans hy.1.2⟩
  have hm := (monotone_residualQuantile a hres).comp_monotoneOn
    A.cdf_strictMonoOn.monotoneOn
  refine ⟨hzc, ?_⟩
  have h1 := hm hx.1 hzc hz.1
  have h2 := hm hzc hy.1 hz.2
  have hxv := hx.2
  have hyv := hy.2
  change A.angularTarget (a.residualQuantile hres) x = v - a.roots a.main at hxv
  change A.angularTarget (a.residualQuantile hres) y = v - a.roots a.main at hyv
  simp only [angularTarget, foldedAngle_eq hx.1] at hxv
  simp only [angularTarget, foldedAngle_eq hy.1] at hyv
  change A.angularTarget (a.residualQuantile hres) z = v - a.roots a.main
  simp only [angularTarget, foldedAngle_eq hzc]
  exact le_antisymm (hyv ▸ h2) (hxv ▸ h1)

theorem sum_block_indicator {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (g : ℝ → ℝ) {θ : ℝ} (hθ : θ ∈ Icc (0 : ℝ) π) :
    ∑ v ∈ a.residualValues, (blockSet A a hres v).indicator g θ = g θ := by
  classical
  obtain ⟨v, hv, hmem⟩ := blockSet_cover A a hres hθ
  rw [sum_eq_single v]
  · exact indicator_of_mem hmem g
  · intro w hw hwv
    exact indicator_of_notMem (fun hwθ =>
      Set.disjoint_left.mp (blockSet_disjoint A a hres hwv) hwθ hmem) g
  · exact fun h => (h hv).elim

theorem interval_integrable_indicator {g : ℝ → ℝ} {s : Set ℝ}
    (hg : IntervalIntegrable g volume 0 π) (hs : MeasurableSet s) :
    IntervalIntegrable (s.indicator g) volume 0 π := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le] at hg ⊢
  exact hg.indicator hs

theorem sum_block_integral {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {g : ℝ → ℝ}
    (hg : IntervalIntegrable g volume 0 π) :
    ∑ v ∈ a.residualValues, (∫ θ in (0 : ℝ)..π, (blockSet A a hres v).indicator g θ) =
      ∫ θ in (0 : ℝ)..π, g θ := by
  classical
  rw [← intervalIntegral.integral_finsetSum (fun v _ =>
    interval_integrable_indicator hg (blockSet_measurable A a hres v))]
  exact intervalIntegral.integral_congr fun θ hθ =>
    sum_block_indicator A a hres g (by simpa only [uIcc_of_le Real.pi_pos.le] using hθ)

noncomputable def blockMass {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ :=
  1 / π * ∫ θ in (0 : ℝ)..π,
    (blockSet A a hres v).indicator (alpha A.k A.ρ) θ

theorem blockMass_eq_multiplicity {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) :
    blockMass A a hres v = a.multiplicity v / a.residualCount := by
  classical
  have hc := A.integral_cdf (fun u => if a.residualQuantile hres u = v - a.roots a.main then
    (1 : ℝ) else 0)
  have heq : (∫ u in (0 : ℝ)..1,
      if a.residualQuantile hres u = v - a.roots a.main then (1 : ℝ) else 0) =
      blockMass A a hres v := by
    rw [hc]
    congr 1
    apply intervalIntegral.integral_congr
    intro θ hθ
    rw [uIcc_of_le Real.pi_pos.le] at hθ
    change _ = (Icc 0 π ∩ {θ | A.angularTarget (a.residualQuantile hres) θ =
      v - a.roots a.main}).indicator (alpha A.k A.ρ) θ
    simp only [Set.indicator, mem_inter_iff, mem_setOf_eq, hθ, true_and,
      angularTarget, foldedAngle_eq hθ]
    split_ifs <;> simp
  rw [← heq]
  have hi := integral_residualQuantile a hres (fun t =>
    if t = v - a.roots a.main then (1 : ℝ) else 0)
  rw [hi]
  have hne := residual_value_ne_main a hv
  have hset : a.residualIndices.filter (fun i => a.roots i = v) =
      univ.filter (fun i => a.roots i = v) := by
    ext i
    simp only [residualIndices, Finset.mem_filter, Finset.mem_univ, true_and]
    constructor
    · exact And.right
    · intro h; exact ⟨by simpa only [h] using hne, h⟩
  have hsum : (∑ i ∈ a.residualIndices,
      if a.locations i = v - a.roots a.main then (1 : ℝ) else 0) = a.multiplicity v := by
    simp only [locations, sub_left_inj]
    rw [← sum_filter, sum_const, nsmul_eq_mul, mul_one, hset]
    rfl
  rw [hsum]

theorem blockMass_pos {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) :
    0 < blockMass A a hres v := by
  rw [blockMass_eq_multiplicity A a hres hv]
  exact div_pos (by exact_mod_cast multiplicity_pos a hv) (by exact_mod_cast hres)

theorem sum_blockMass {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) : ∑ v ∈ a.residualValues, blockMass A a hres v = 1 := by
  classical
  simp only [blockMass]
  rw [← mul_sum, sum_block_integral A a hres
    ((alpha_cont A.k A.ρ A.rho_pos.le A.rho_lt_one).intervalIntegrable _ _)]
  exact A.cdf_pi

noncomputable def refB (R : SeparatedReference) : ℝ → ℝ :=
  Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus

theorem refB_eq (R : SeparatedReference) :
    refB R = Bf R.sigmaPlus R.sigmaMinus R.rhoPlus R.rhoMinus := by
  funext θ
  dsimp [refB, Bxi, Bf]
  ring

theorem refB_continuous (R : SeparatedReference) : Continuous (refB R) :=
  Bxi_cont R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1

theorem refB_nonneg (R : SeparatedReference) (θ : ℝ) : 0 ≤ refB R θ :=
  (Bxi_bounds R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1 R.sigmaPlus_pos.le R.sigmaMinus_pos.le θ).1

theorem refB_pos (R : SeparatedReference) {θ : ℝ} (hθ : θ ∈ Ioc (0 : ℝ) π) :
    0 < refB R θ := by
  rw [refB_eq]
  exact Bf_pos R.sigmaPlus_pos R.sigmaMinus_pos.le R.rhoPlus_spec.1 R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1 hθ.1 hθ.2

theorem block_weight_pos {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues)
    {h : ℝ → ℝ} (hc : Continuous h) (hnn : ∀ θ, 0 ≤ h θ)
    (hp : ∀ θ ∈ Ioc (0 : ℝ) π, 0 < h θ) :
    0 < ∫ θ in (0 : ℝ)..π, (blockSet A a hres v).indicator h θ := by
  have hsm := blockSet_measurable A a hres v
  have hαi := interval_integrable_indicator
    ((alpha_cont A.k A.ρ A.rho_pos.le A.rho_lt_one).intervalIntegrable 0 π) hsm
  have hhi := interval_integrable_indicator (hc.intervalIntegrable 0 π) hsm
  have hαnn : 0 ≤ᵐ[volume] (blockSet A a hres v).indicator (alpha A.k A.ρ) :=
    Eventually.of_forall fun θ => indicator_nonneg (fun _ _ =>
      (alpha_bounds A.k_pos.le A.rho_pos.le A.rho_lt_one A.density_zero_nonneg _).1) θ
  have hhnn : 0 ≤ᵐ[volume] (blockSet A a hres v).indicator h :=
    Eventually.of_forall fun θ => indicator_nonneg (fun t _ => hnn t) θ
  have hαpos : 0 < ∫ θ in (0 : ℝ)..π,
      (blockSet A a hres v).indicator (alpha A.k A.ρ) θ := by
    have hq := blockMass_pos A a hres hv
    dsimp [blockMass] at hq
    exact pos_of_mul_pos_right hq (one_div_pos.mpr Real.pi_pos).le
  have hs := (intervalIntegral.integral_pos_iff_support_of_nonneg_ae hαnn hαi).mp hαpos
  apply (intervalIntegral.integral_pos_iff_support_of_nonneg_ae hhnn hhi).mpr
  refine ⟨Real.pi_pos, hs.2.trans_le (measure_mono ?_)⟩
  intro θ hθ
  have hb : θ ∈ blockSet A a hres v := by
    by_contra h
    exact hθ.1 (indicator_of_notMem h _)
  refine ⟨?_, hθ.2⟩
  rw [Function.mem_support, indicator_of_mem hb]
  exact (hp θ hθ.2).ne'

noncomputable def blockXi {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ :=
  1 / π * ∫ θ in (0 : ℝ)..π, (blockSet R.angles a hres v).indicator (refB R) θ

noncomputable def totalXi (R : SeparatedReference) : ℝ :=
  1 / π * ∫ θ in (0 : ℝ)..π, refB R θ

theorem blockXi_pos {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) :
    0 < blockXi R a hres v :=
  mul_pos (one_div_pos.mpr Real.pi_pos) (block_weight_pos R.angles a hres hv
    (refB_continuous R) (refB_nonneg R) (fun _ hθ => refB_pos R hθ))

theorem sum_blockXi {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) : ∑ v ∈ a.residualValues, blockXi R a hres v = totalXi R := by
  classical
  simp only [blockXi, totalXi]
  rw [← mul_sum, sum_block_integral R.angles a hres ((refB_continuous R).intervalIntegrable _ _)]

theorem totalXi_formula (R : SeparatedReference) :
    totalXi R = R.sigmaPlus * (2 * R.rhoPlus / (1 - R.rhoPlus)) +
      R.sigmaMinus * (2 * R.rhoMinus / (1 - R.rhoMinus)) := by
  rw [totalXi, refB_eq]
  exact int_Bf R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1

theorem totalXi_pos (R : SeparatedReference) : 0 < totalXi R := by
  rw [totalXi_formula]
  exact add_pos (mul_pos R.sigmaPlus_pos (div_pos (mul_pos (by norm_num) R.rhoPlus_spec.1)
    (by linarith [R.rhoPlus_spec.2.1])))
    (mul_pos R.sigmaMinus_pos (div_pos (mul_pos (by norm_num) R.rhoMinus_spec.1)
      (by linarith [R.rhoMinus_spec.2.1])))

theorem blockRadius_pos {n : ℕ} (a : NormalData n) (v : ℝ) : 0 < Stage7.Rv a.roots v :=
  Real.exp_pos _

theorem block_radius_identity {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) :
    -blockMass A a hres v * Real.log (Stage7.Rv a.roots v) =
      Stage10.WS a.k (a.residualQuantile hres) (v - a.roots a.main) := by
  classical
  rw [blockMass_eq_multiplicity A a hres hv, potential_eq_log_sum, Stage7.Rv, Real.log_exp]
  have hm : (a.multiplicity v : ℝ) ≠ 0 := by exact_mod_cast (multiplicity_pos a hv).ne'
  have heq : (∑ j ∈ univ.filter (fun j => a.roots j ≠ v), Real.log |v - a.roots j|) =
      ∑ j, Real.log |v - a.roots j| := by
    apply Finset.sum_subset (filter_subset _ _)
    intro i hi hnot
    have hi' : a.roots i = v := by simpa only [Finset.mem_filter, hi, true_and, not_not] using hnot
    simp [hi']
  have heq2 : ∀ i, (v - a.roots a.main) - a.locations i = v - a.roots i := by
    intro i; dsimp [locations]; ring
  simp_rw [heq2]
  rw [heq]
  change -((a.multiplicity v : ℝ) / a.residualCount) *
    (-(∑ j, Real.log |v - a.roots j|) / a.multiplicity v) = _
  field_simp

noncomputable def blockMaterialIntegral {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ) : ℝ :=
  1 / π * ∫ θ in (0 : ℝ)..π, (blockSet R.angles a hres v).indicator
    (fun θ => materialAngular R.angles.k R.angles.ρ R.c R.r
      (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ * refB R θ) θ

theorem material_weight_integrable {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    IntervalIntegrable (fun θ => materialAngular R.angles.k R.angles.ρ R.c R.r
      (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ * refB R θ) volume 0 π := by
  have h := R.residual_adjoint_le_Mdot a hres
  have heq := R.angles.material_eq_HT_ae R.radius_pos R.rhoPlus_spec.1 R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1 R.sigmaPlus_pos R.sigmaMinus_pos.le hzero h.1.kernel
  have hi := integrable_HT_weight h.1.kernel
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le] at hi ⊢
  apply (hi.div_const R.r).congr
  filter_upwards [heq] with θ hθ
  rw [hθ]
  dsimp [refB]
  ring

theorem sum_blockMaterialIntegral {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    ∑ v ∈ a.residualValues, blockMaterialIntegral R a hres v =
      ∫ d, R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d
        ∂spatialAdjointMeasure R.c R.r (refB R) := by
  classical
  simp only [blockMaterialIntegral]
  rw [← mul_sum, sum_block_integral R.angles a hres (material_weight_integrable R a hres hzero)]
  unfold spatialMaterial
  rw [integral_spatialAdjoint R.radius_pos (refB_continuous R).measurable (refB_nonneg R)
    (materialAngular_measurable (R.angles.angularDrift_measurable R.c R.r
      (measurable_residualQuantile a hres)) R.angles.rho_pos.le R.angles.rho_lt_one)]

theorem normal_form_block_supporting {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (hk : R.angles.k = a.k)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    (volume (Stage10.correctedNegSet a.k R.quantile ∩ Iio R.separator)).toReal +
      ∑ v ∈ a.residualValues, blockMaterialIntegral R a hres v ≤
        Resid.rhoR a.roots (a.roots a.main) - Resid.ellL a.roots (a.roots a.main) := by
  rw [sum_blockMaterialIntegral R a hres hzero]
  exact normal_form_material_supporting a hres R hk hzero

theorem weighted_angular_target_integrable {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (g : ℝ → ℝ) :
    IntervalIntegrable (fun θ => g (A.angularTarget (a.residualQuantile hres) θ) *
      alpha A.k A.ρ θ) volume 0 π := by
  classical
  have hs : ∀ v ∈ a.residualValues, IntervalIntegrable
      ((blockSet A a hres v).indicator (fun θ => g (v - a.roots a.main) * alpha A.k A.ρ θ))
        volume 0 π := fun v _ => interval_integrable_indicator
          (((alpha_cont A.k A.ρ A.rho_pos.le A.rho_lt_one).intervalIntegrable _ _).const_mul _)
            (blockSet_measurable A a hres v)
  apply (IntervalIntegrable.sum a.residualValues hs).congr
  intro θ hθ
  simp only [Finset.sum_apply]
  rw [Set.uIoc_of_le Real.pi_pos.le] at hθ
  obtain ⟨v, hv, hmem⟩ := blockSet_cover A a hres ⟨hθ.1.le, hθ.2⟩
  rw [Finset.sum_eq_single v]
  · rw [indicator_of_mem hmem]
    have heq : A.angularTarget (a.residualQuantile hres) θ = v - a.roots a.main := hmem.2
    rw [heq]
  · intro w hw hwv
    exact indicator_of_notMem (fun hwθ =>
      Set.disjoint_left.mp (blockSet_disjoint A a hres hwv) hwθ hmem) _
  · exact fun h => (h hv).elim

theorem weighted_angular_target_integral {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (g : ℝ → ℝ) :
    1 / π * (∫ θ in (0 : ℝ)..π,
      g (A.angularTarget (a.residualQuantile hres) θ) * alpha A.k A.ρ θ) =
        ∫ u in (0 : ℝ)..1, g (a.residualQuantile hres u) := by
  rw [A.integral_cdf]
  congr 1
  exact intervalIntegral.integral_congr fun θ hθ => by
    rw [Set.uIcc_of_le Real.pi_pos.le] at hθ
    simp only [angularTarget, foldedAngle_eq hθ]

end EP1038.Stage12
