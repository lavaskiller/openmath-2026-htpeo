import LeanProject.TerminalTail
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
namespace TailCert
theorem cov_log_0 : RB (Real.log ((88660377 : ℝ) / 100000000)) ((-12035711 : ℝ) / 100000000) ((-1203571 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((88660377 : ℝ) / 100000000)) (t := ((-11339623 : ℝ) / 188660377))
    (lo := ((-12035711 : ℝ) / 100000000)) (hi := ((-1203571 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1 : RB (Real.log ((44339623 : ℝ) / 50000000)) ((-12014431 : ℝ) / 100000000) ((-1201443 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((44339623 : ℝ) / 50000000)) (t := ((-5660377 : ℝ) / 94339623))
    (lo := ((-12014431 : ℝ) / 100000000)) (hi := ((-1201443 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2 : RB (Real.log ((47 : ℝ) / 100)) ((-3775113 : ℝ) / 5000000) ((-37751129 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((47 : ℝ) / 50)) (t := ((-3 : ℝ) / 97))
    (lo := ((-6187541 : ℝ) / 100000000)) (hi := ((-309377 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47 : ℝ) / 100) = Real.log ((47 : ℝ) / 50) - 1 * Real.log 2 := by
    rw [show ((47 : ℝ) / 100) = ((47 : ℝ) / 50) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_3 : RB (Real.log ((49 : ℝ) / 25)) ((67294447 : ℝ) / 100000000) ((67294449 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((49 : ℝ) / 50)) (t := ((-1 : ℝ) / 99))
    (lo := ((-2020271 : ℝ) / 100000000)) (hi := ((-202027 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((49 : ℝ) / 25) = Real.log ((49 : ℝ) / 50) + 1 * Real.log 2 := by
    rw [show ((49 : ℝ) / 25) = ((49 : ℝ) / 50) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_4 : RB (Real.log (2 : ℝ)) ((34657359 : ℝ) / 50000000) ((69314719 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := (1 : ℝ)) (t := (0 : ℝ))
    (lo := (0 : ℝ)) (hi := (0 : ℝ)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log (2 : ℝ) = Real.log (1 : ℝ) + 1 * Real.log 2 := by
    rw [show (2 : ℝ) = (1 : ℝ) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_5 : RB (Real.log ((1733 : ℝ) / 1600)) ((3992519 : ℝ) / 50000000) ((7985039 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1733 : ℝ) / 1600)) (t := ((133 : ℝ) / 3333))
    (lo := ((3992519 : ℝ) / 50000000)) (hi := ((7985039 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_6 : RB (Real.log ((54166667 : ℝ) / 50000000)) ((8004271 : ℝ) / 100000000) ((500267 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((54166667 : ℝ) / 50000000)) (t := ((4166667 : ℝ) / 104166667))
    (lo := ((8004271 : ℝ) / 100000000)) (hi := ((500267 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_7 : RB (Real.log ((13 : ℝ) / 25)) ((-8174081 : ℝ) / 12500000) ((-32696323 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((26 : ℝ) / 25)) (t := ((1 : ℝ) / 51))
    (lo := ((3922071 : ℝ) / 100000000)) (hi := ((490259 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13 : ℝ) / 25) = Real.log ((26 : ℝ) / 25) - 1 * Real.log 2 := by
    rw [show ((13 : ℝ) / 25) = ((26 : ℝ) / 25) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_8 : RB (Real.log ((71276923 : ℝ) / 20000000)) ((127084033 : ℝ) / 100000000) ((31771009 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((71276923 : ℝ) / 80000000)) (t := ((-8723077 : ℝ) / 151276923))
    (lo := ((-11545403 : ℝ) / 100000000)) (hi := ((-5772701 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71276923 : ℝ) / 20000000) = Real.log ((71276923 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((71276923 : ℝ) / 20000000) = ((71276923 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_9 : RB (Real.log ((356410257 : ℝ) / 100000000)) ((31772807 : ℝ) / 25000000) ((127091231 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((356410257 : ℝ) / 400000000)) (t := ((-43589743 : ℝ) / 756410257))
    (lo := ((-360569 : ℝ) / 3125000)) (hi := ((-11538207 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356410257 : ℝ) / 100000000) = Real.log ((356410257 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((356410257 : ℝ) / 100000000) = ((356410257 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_10 : RB (Real.log ((139 : ℝ) / 100)) ((16465187 : ℝ) / 50000000) ((4116297 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((139 : ℝ) / 200)) (t := ((-61 : ℝ) / 339))
    (lo := ((-4548043 : ℝ) / 12500000)) (hi := ((-36384343 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((139 : ℝ) / 100) = Real.log ((139 : ℝ) / 200) + 1 * Real.log 2 := by
    rw [show ((139 : ℝ) / 100) = ((139 : ℝ) / 200) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_11 : RB (Real.log ((292288461 : ℝ) / 100000000)) ((1072571 : ℝ) / 1000000) ((107257103 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((292288461 : ℝ) / 400000000)) (t := ((-107711539 : ℝ) / 692288461))
    (lo := ((-1960771 : ℝ) / 6250000)) (hi := ((-6274467 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((292288461 : ℝ) / 100000000) = Real.log ((292288461 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((292288461 : ℝ) / 100000000) = ((292288461 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_12 : RB (Real.log ((292307693 : ℝ) / 100000000)) ((335199 : ℝ) / 312500) ((107263683 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((292307693 : ℝ) / 400000000)) (t := ((-107692307 : ℝ) / 692307693))
    (lo := ((-7841439 : ℝ) / 25000000)) (hi := ((-6273151 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((292307693 : ℝ) / 100000000) = Real.log ((292307693 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((292307693 : ℝ) / 100000000) = ((292307693 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_13 : RB (Real.log ((38 : ℝ) / 25)) ((41871033 : ℝ) / 100000000) ((8374207 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((19 : ℝ) / 25)) (t := ((-3 : ℝ) / 22))
    (lo := ((-5488737 : ℝ) / 20000000)) (hi := ((-6860921 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38 : ℝ) / 25) = Real.log ((19 : ℝ) / 25) + 1 * Real.log 2 := by
    rw [show ((38 : ℝ) / 25) = ((19 : ℝ) / 25) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
theorem cov_signs_0 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((849 : ℝ) / 1000) (1 : ℝ))
    (hq : RB (qa a) (0 : ℝ) ((1 : ℝ) / 100))
    (hd : RB (D0a a) ((49 : ℝ) / 25) (2 : ℝ))
    : certE k a ((47 : ℝ) / 100) < 0 ∧ 0 < certE k a ((13 : ℝ) / 25) ∧ 0 < certE k a ((139 : ℝ) / 100) ∧ certE k a ((38 : ℝ) / 25) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 (0 : ℝ) ((1 : ℝ) / 10000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((47 : ℝ) / 100)) - (z1)
  have h2 : RB z2 ((4699 : ℝ) / 10000) ((47 : ℝ) / 100) := rb_widen (rb_sub (show RB ((47 : ℝ) / 100) ((47 : ℝ) / 100) ((47 : ℝ) / 100) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((53 : ℝ) / 100))
  have h3 : RB z3 ((88660377 : ℝ) / 100000000) ((44339623 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((53 : ℝ) / 100) ((53 : ℝ) / 100) ((53 : ℝ) / 100) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-12035711 : ℝ) / 100000000) ((-1201443 : ℝ) / 10000000) := rb_log h3 (by norm_num) cov_log_0.1 cov_log_1.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-12035711 : ℝ) / 100000000) ((-10200251 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((47 : ℝ) / 100))
  have h6 : RB z6 ((-3775113 : ℝ) / 5000000) ((-37751129 : ℝ) / 50000000) := rb_log (show RB ((47 : ℝ) / 100) ((47 : ℝ) / 100) ((47 : ℝ) / 100) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2.1 cov_log_2.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63466547 : ℝ) / 100000000) ((65302009 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((67294447 : ℝ) / 100000000) ((69314719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-1462043 : ℝ) / 25000000) ((-996219 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 (0 : ℝ) ((1 : ℝ) / 10000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((13 : ℝ) / 25)) - (z10)
  have h11 : RB z11 ((5199 : ℝ) / 10000) ((13 : ℝ) / 25) := rb_widen (rb_sub (show RB ((13 : ℝ) / 25) ((13 : ℝ) / 25) ((13 : ℝ) / 25) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((12 : ℝ) / 25))
  have h12 : RB z12 ((1733 : ℝ) / 1600) ((54166667 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((12 : ℝ) / 25) ((12 : ℝ) / 25) ((12 : ℝ) / 25) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((3992519 : ℝ) / 50000000) ((500267 : ℝ) / 6250000) := rb_log h12 (by norm_num) cov_log_5.1 cov_log_6.2
  let z14 : ℝ := (k / (k + 1)) * (z13)
  have h14 : RB z14 ((6779297 : ℝ) / 100000000) ((500267 : ℝ) / 6250000) := rb_widen (rb_mul hA h13 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((13 : ℝ) / 25))
  have h15 : RB z15 ((-8174081 : ℝ) / 12500000) ((-32696323 : ℝ) / 50000000) := rb_log (show RB ((13 : ℝ) / 25) ((13 : ℝ) / 25) ((13 : ℝ) / 25) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_7.1 cov_log_7.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((72171943 : ℝ) / 100000000) ((1834923 : ℝ) / 2500000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((67294447 : ℝ) / 100000000) ((69314719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((357153 : ℝ) / 12500000) ((6102473 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 (0 : ℝ) ((1 : ℝ) / 10000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((139 : ℝ) / 100)) - (z19)
  have h20 : RB z20 ((13899 : ℝ) / 10000) ((139 : ℝ) / 100) := rb_widen (rb_sub (show RB ((139 : ℝ) / 100) ((139 : ℝ) / 100) ((139 : ℝ) / 100) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((39 : ℝ) / 100))
  have h21 : RB z21 ((71276923 : ℝ) / 20000000) ((356410257 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((39 : ℝ) / 100) ((39 : ℝ) / 100) ((39 : ℝ) / 100) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((127084033 : ℝ) / 100000000) ((127091231 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_8.1 cov_log_9.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((13486793 : ℝ) / 12500000) ((127091231 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((139 : ℝ) / 100))
  have h24 : RB z24 ((16465187 : ℝ) / 50000000) ((4116297 : ℝ) / 12500000) := rb_log (show RB ((139 : ℝ) / 100) ((139 : ℝ) / 100) ((139 : ℝ) / 100) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_10.1 cov_log_10.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((292828 : ℝ) / 390625) ((94160857 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((67294447 : ℝ) / 100000000) ((69314719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((5649249 : ℝ) / 100000000) ((2686641 : ℝ) / 10000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 (0 : ℝ) ((1 : ℝ) / 10000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((38 : ℝ) / 25)) - (z28)
  have h29 : RB z29 ((15199 : ℝ) / 10000) ((38 : ℝ) / 25) := rb_widen (rb_sub (show RB ((38 : ℝ) / 25) ((38 : ℝ) / 25) ((38 : ℝ) / 25) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((13 : ℝ) / 25))
  have h30 : RB z30 ((292288461 : ℝ) / 100000000) ((292307693 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((13 : ℝ) / 25) ((13 : ℝ) / 25) ((13 : ℝ) / 25) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((1072571 : ℝ) / 1000000) ((107263683 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_11.1 cov_log_12.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((91061277 : ℝ) / 100000000) ((107263683 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((38 : ℝ) / 25))
  have h33 : RB z33 ((41871033 : ℝ) / 100000000) ((8374207 : ℝ) / 20000000) := rb_log (show RB ((38 : ℝ) / 25) ((38 : ℝ) / 25) ((38 : ℝ) / 25) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_13.1 cov_log_13.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((24595121 : ℝ) / 50000000) ((1307853 : ℝ) / 2000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((67294447 : ℝ) / 100000000) ((69314719 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_3.1 cov_log_4.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-20124477 : ℝ) / 100000000) ((-1901797 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((47 : ℝ) / 100)) ((-1462043 : ℝ) / 25000000) ((-996219 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((13 : ℝ) / 25)) ((357153 : ℝ) / 12500000) ((6102473 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((139 : ℝ) / 100)) ((5649249 : ℝ) / 100000000) ((2686641 : ℝ) / 10000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((38 : ℝ) / 25)) ((-20124477 : ℝ) / 100000000) ((-1901797 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem tail_weights {A q vp vm : ℝ}
    (hA : RB A ((849 : ℝ) / 1000) (1 : ℝ))
    (hq : RB q (0 : ℝ) ((1 : ℝ) / 100))
    (hp : RB vp ((47 : ℝ) / 100) ((13 : ℝ) / 25))
    (hm : RB vm ((139 : ℝ) / 100) ((38 : ℝ) / 25))
    : RB (formWp A q vp + formWm A q vm) ((120326029 : ℝ) / 100000000) (21 / 10) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 (0 : ℝ) ((1 : ℝ) / 10000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((9999 : ℝ) / 10000) (1 : ℝ) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((8489151 : ℝ) / 10000000) (1 : ℝ) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 (0 : ℝ) ((21277 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99978723 : ℝ) / 100000000) (1 : ℝ) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((12 : ℝ) / 25) ((53 : ℝ) / 100) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((47989787 : ℝ) / 100000000) ((53 : ℝ) / 100) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((8008633 : ℝ) / 5000000) ((208377671 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3008633 : ℝ) / 5000000) ((108377671 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) / (z9)
  have h10 : RB z10 ((11533741 : ℝ) / 12500000) ((10386777 : ℝ) / 6250000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := ((1 : ℝ)) - (z1)
  have h11 : RB z11 ((9999 : ℝ) / 10000) (1 : ℝ) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z12 : ℝ := (A) * (z11)
  have h12 : RB z12 ((8489151 : ℝ) / 10000000) (1 : ℝ) := rb_widen (rb_mul hA h11 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z13 : ℝ := (z1) / (vm)
  have h13 : RB z13 (0 : ℝ) ((1439 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := ((1 : ℝ)) - (z13)
  have h14 : RB z14 ((19998561 : ℝ) / 20000000) (1 : ℝ) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h13) (by norm_num) (by norm_num)
  let z15 : ℝ := (vm) - ((1 : ℝ))
  have h15 : RB z15 ((39 : ℝ) / 100) ((13 : ℝ) / 25) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z14) * (z15)
  have h16 : RB z16 ((38997193 : ℝ) / 100000000) ((13 : ℝ) / 25) := rb_widen (rb_mul h14 h15 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z17 : ℝ := (z12) / (z16)
  have h17 : RB z17 ((163252903 : ℝ) / 100000000) ((256428713 : ℝ) / 100000000) := rb_div_signed h12 h16 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := (z17) + ((1 : ℝ))
  have h18 : RB z18 ((263252903 : ℝ) / 100000000) ((356428713 : ℝ) / 100000000) := rb_widen (rb_add h17 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z18)
  have h19 : RB z19 ((28056101 : ℝ) / 100000000) ((18993143 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z10) + (z19)
  have h20 : RB z20 ((120326029 : ℝ) / 100000000) ((102087359 : ℝ) / 50000000) := rb_widen (rb_add h10 h19) (by norm_num) (by norm_num)
  have hh := rb_widen h20 (show ((120326029 : ℝ) / 100000000) ≤ ((120326029 : ℝ) / 100000000) by norm_num) (show ((102087359 : ℝ) / 50000000) ≤ (21 / 10 : ℝ) by norm_num)
  convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, formWp, formWm, formDp, formDm] <;> ring
theorem tail_scalar {k A q vp vm : ℝ}
    (hk : 0 < k) (hk1 : (33 : ℝ) / 5 ≤ k + 1)
    (hA : RB A ((849 : ℝ) / 1000) (1 : ℝ)) (hq : RB q (0 : ℝ) ((1 : ℝ) / 100))
    (hp : RB vp ((47 : ℝ) / 100) ((13 : ℝ) / 25)) (hm : RB vm ((139 : ℝ) / 100) ((38 : ℝ) / 25))
    (hapi : formApi k q ≤ 77 / 50) : FormulaPositiveZero k A q vp vm := by
  have hw := tail_weights hA hq hp hm
  have hwp : 0 < formWp A q vp + formWm A q vm := by linarith [hw.1]
  have hapi1 : 1 ≤ formApi k q := by
    unfold formApi
    have hp : 0 ≤ 2 * k * q / (1 + q) := div_nonneg (by nlinarith [hq.1]) (by linarith [hq.1])
    linarith
  have hap : 0 < formApi k q := by linarith
  have hprod : 2 * formApi k q * (formWp A q vp + formWm A q vm) < k + 1 := by
    have hh := mul_le_mul hapi hw.2 hwp.le (show (0 : ℝ) ≤ 77 / 50 by norm_num)
    nlinarith
  have hc : 0 < formC0 k A q vp vm := by
    unfold formC0
    apply Real.log_pos
    apply (one_lt_div (mul_pos (mul_pos (by norm_num) hap) hwp)).mpr
    exact hprod
  have hr : q / vp ≤ 1 := by
    apply (div_le_one (by linarith [hp.1])).mpr
    linarith [hq.2, hp.1]
  intro Q V hQ hV
  have hQπ : Q ≤ π := hQ.2.trans ((div_le_self Real.pi_pos.le hapi1).trans le_rfl)
  have hVπ : V ≤ π := by
    have hh := mul_le_mul_of_nonneg_left (show (1 + q / vp) / 2 ≤ 1 by linarith) Real.pi_pos.le
    simpa using hV.2.trans hh
  have hs : 0 ≤ ∑' n : ℕ, (xs n Q - xs n V) ^ 2 / ((n : ℝ) + 1) :=
    tsum_nonneg fun n => div_nonneg (sq_nonneg _) (by positivity)
  have hhQ := hfun_nonneg hQ.1 hQπ
  have hhV := hfun_nonneg hV.1 hVπ
  unfold rhs
  simp only [mul_zero, zero_div, sub_zero]
  linarith

 theorem terminal_tail_certified {q : ℝ} (hq : q ∈ terminalDomain)
    (hqc : q ≤ terminalTailCut) : RatioCertified (terminalK q) := by
  obtain ⟨hk1, hA, hapi⟩ := tail_parameter_bounds hq hqc
  have hq0 : RB q 0 (1 / 100) := ⟨hq.1.le, hqc⟩
  have hqr : RB (qa (terminalA q)) 0 (1 / 100) := by rwa [terminal_qa hq]
  have hd : RB (D0a (terminalA q)) (49 / 25) 2 := by
    rw [terminal_D0 hq]; exact tail_D_bounds hq.1 hqc
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_0 hA hqr hd
  apply terminal_ratio_certified_of_box hq (pl := 47 / 100) (ph := 13 / 25) (ml := 139 / 100) (mh := 38 / 25)
  · linarith [hq0.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · intro vp hp vm hm
    exact tail_scalar (terminalK_pos hq) hk1 hA hq0 ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩ hapi

end TailCert
end EP1038.ReferenceCert
