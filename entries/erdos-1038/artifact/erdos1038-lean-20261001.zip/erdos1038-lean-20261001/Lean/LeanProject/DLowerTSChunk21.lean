import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk18
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_68 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((641042085687238019354201421774847 : ℝ) / 5192296858534827628530496329220096) ((320614392633819816490103079121715 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((123460214843 : ℝ) / 1000000000000) ((1580751 : ℝ) / 12800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1123460214843 : ℝ) / 1000000000000) ((14380751 : ℝ) / 12800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((14551675027 : ℝ) / 125000000000) ((116445405317 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_839.1 dlower_log_840.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((14551675027 : ℝ) / 62500000000) ((116445405317 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((18410254797 : ℝ) / 40000000000) ((14385011879 : ℝ) / 31250000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-522959080459 : ℝ) / 250000000000) ((-2091545120357 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_841.1 dlower_log_842.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2091545120357 : ℝ) / 1000000000000) ((522959080459 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((220025039779 : ℝ) / 1000000000000) ((8803451107 : ℝ) / 40000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((31196548893 : ℝ) / 40000000000) ((779974960221 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15242424649 : ℝ) / 1000000000000) ((3812826117 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((13917837623 : ℝ) / 62500000000)) - (z9)
  have h10 : RB z10 ((82973639 : ℝ) / 400000000) ((207442977319 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((13917837623 : ℝ) / 62500000000) ((13917837623 : ℝ) / 62500000000) ((13917837623 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((48582162377 : ℝ) / 62500000000))
  have h11 : RB z11 ((266859902059 : ℝ) / 1000000000000) ((266871325773 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((48582162377 : ℝ) / 62500000000) ((48582162377 : ℝ) / 62500000000) ((48582162377 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1321031469681 : ℝ) / 1000000000000) ((-41280895709 : ℝ) / 31250000000) := rb_log h11 (by norm_num) dlower_log_843.1 dlower_log_844.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-64398216751 : ℝ) / 62500000000) ((-515128592533 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((13917837623 : ℝ) / 62500000000))
  have h14 : RB z14 ((-1501995257079 : ℝ) / 1000000000000) ((-1501995257077 : ℝ) / 1000000000000) := rb_log (show RB ((13917837623 : ℝ) / 62500000000) ((13917837623 : ℝ) / 62500000000) ((13917837623 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_845.1 dlower_log_845.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((471623789061 : ℝ) / 1000000000000) ((471738072013 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((11303408933 : ℝ) / 1000000000000) ((1435212761 : ℝ) / 125000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15242424649 : ℝ) / 1000000000000) ((3812826117 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1490043740537 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1474792436069 : ℝ) / 1000000000000) ((92175082243 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB ((1490043740537 : ℝ) / 1000000000000) ((1490043740537 : ℝ) / 1000000000000) ((1490043740537 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((490043740537 : ℝ) / 1000000000000))
  have h19 : RB z19 ((75237795837 : ℝ) / 25000000000) ((3009529953943 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((490043740537 : ℝ) / 1000000000000) ((490043740537 : ℝ) / 1000000000000) ((490043740537 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((550888942019 : ℝ) / 500000000000) ((550891952543 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_846.1 dlower_log_847.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((171858338143 : ℝ) / 200000000000) ((429681928771 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1490043740537 : ℝ) / 1000000000000))
  have h22 : RB z22 ((39880547559 : ℝ) / 100000000000) ((49850684449 : ℝ) / 125000000000) := rb_log (show RB ((1490043740537 : ℝ) / 1000000000000) ((1490043740537 : ℝ) / 1000000000000) ((1490043740537 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_848.1 dlower_log_848.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((460486215123 : ℝ) / 1000000000000) ((3598112359 : ℝ) / 7812500000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((33166999 : ℝ) / 200000000000) ((302012027 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1123460214843 : ℝ) / 1000000000000) ((14380751 : ℝ) / 12800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((252432570867 : ℝ) / 200000000000) ((631121824109 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1584480145987 : ℝ) / 1000000000000) ((792290786063 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1267358338569 : ℝ) / 1000000000000))
  have h28 : RB z28 ((2008104125313 : ℝ) / 1000000000000) ((2008232668577 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1267358338569 : ℝ) / 1000000000000) ((1267358338569 : ℝ) / 1000000000000) ((1267358338569 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15242424649 : ℝ) / 1000000000000) ((3812826117 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((20738186831961508823551 : ℝ) / 62500000000000000000000))
  have h30 : RB z30 ((22968535009 : ℝ) / 500000000000) ((22981915849 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((20738186831961508823551 : ℝ) / 62500000000000000000000) ((20738186831961508823551 : ℝ) / 62500000000000000000000) ((20738186831961508823551 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((477018084151 : ℝ) / 500000000000) ((477031464991 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((383160793053 : ℝ) / 200000000000) ((1915980343869 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((13917837623 : ℝ) / 62500000000)) ((11303408933 : ℝ) / 1000000000000) ((1435212761 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1490043740537 : ℝ) / 1000000000000)) ((33166999 : ℝ) / 200000000000) ((302012027 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((13917837623 : ℝ) / 62500000000)) (wl := ((1490043740537 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((383160793053 : ℝ) / 200000000000) ≤ D0q (q) * (((1490043740537 : ℝ) / 1000000000000) - ((13917837623 : ℝ) / 62500000000)) * (1 - (q) ^ 2 / (((1490043740537 : ℝ) / 1000000000000) * ((13917837623 : ℝ) / 62500000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_69 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((320614392633819816490103079121715 : ℝ) / 2596148429267413814265248164610048) ((160353871212010311651552723678003 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((61748085937 : ℝ) / 500000000000) ((123532128907 : ℝ) / 1000000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((561748085937 : ℝ) / 500000000000) ((1123532128907 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((23289081063 : ℝ) / 200000000000) ((116477409393 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_849.1 dlower_log_850.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((23289081063 : ℝ) / 100000000000) ((116477409393 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460192361773 : ℝ) / 1000000000000) ((46025636993 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2091545120367 : ℝ) / 1000000000000) ((-1045627001827 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_851.1 dlower_log_852.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1045627001827 : ℝ) / 500000000000) ((2091545120367 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((110012535061 : ℝ) / 500000000000) ((4401726133 : ℝ) / 20000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((15598273867 : ℝ) / 20000000000) ((389987464939 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15251304467 : ℝ) / 1000000000000) ((15260186873 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((253394412399 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((119067112763 : ℝ) / 500000000000) ((59535776983 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((253394412399 : ℝ) / 1000000000000) ((253394412399 : ℝ) / 1000000000000) ((253394412399 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((746605587601 : ℝ) / 1000000000000))
  have h11 : RB z11 ((159477928829 : ℝ) / 500000000000) ((39870969339 : ℝ) / 125000000000) := rb_div_signed h10 (show RB ((746605587601 : ℝ) / 1000000000000) ((746605587601 : ℝ) / 1000000000000) ((746605587601 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1142702563021 : ℝ) / 1000000000000) ((-1142665263713 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_853.1 dlower_log_854.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-111409918933 : ℝ) / 125000000000) ((-178236057217 : ℝ) / 200000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((253394412399 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-42900251933 : ℝ) / 31250000000) ((-686404030927 : ℝ) / 500000000000) := rb_log (show RB ((253394412399 : ℝ) / 1000000000000) ((253394412399 : ℝ) / 1000000000000) ((253394412399 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_855.1 dlower_log_855.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((48152871039 : ℝ) / 100000000000) ((481627775771 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1063617023 : ℝ) / 50000000000) ((10717706999 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15251304467 : ℝ) / 1000000000000) ((15260186873 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((46564935453 : ℝ) / 31250000000)) - (z17)
  have h18 : RB z18 ((1474817747623 : ℝ) / 1000000000000) ((1474826630029 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((46564935453 : ℝ) / 31250000000) ((46564935453 : ℝ) / 31250000000) ((46564935453 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((15314935453 : ℝ) / 31250000000))
  have h19 : RB z19 ((752338375089 : ℝ) / 250000000000) ((3009371624833 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((15314935453 : ℝ) / 31250000000) ((15314935453 : ℝ) / 31250000000) ((15314935453 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((220345054351 : ℝ) / 200000000000) ((550865647227 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_856.1 dlower_log_857.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((859250625751 : ℝ) / 1000000000000) ((859322789137 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((46564935453 : ℝ) / 31250000000))
  have h22 : RB z22 ((398828423619 : ℝ) / 1000000000000) ((398828423621 : ℝ) / 1000000000000) := rb_log (show RB ((46564935453 : ℝ) / 31250000000) ((46564935453 : ℝ) / 31250000000) ((46564935453 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_858.1 dlower_log_858.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((46042220213 : ℝ) / 100000000000) ((230247182759 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((829161 : ℝ) / 5000000000) ((60400749 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((561748085937 : ℝ) / 500000000000) ((1123532128907 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((252448729643 : ℝ) / 200000000000) ((1262324444687 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1584378729587 : ℝ) / 1000000000000) ((198060018249 : ℝ) / 125000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1236683522097 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1959375067641 : ℝ) / 1000000000000) ((1959500487639 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1236683522097 : ℝ) / 1000000000000) ((1236683522097 : ℝ) / 1000000000000) ((1236683522097 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15251304467 : ℝ) / 1000000000000) ((15260186873 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((11799294457510297881747 : ℝ) / 31250000000000000000000))
  have h30 : RB z30 ((10098130577 : ℝ) / 250000000000) ((10104011759 : ℝ) / 250000000000) := rb_div_signed h29 (show RB ((11799294457510297881747 : ℝ) / 31250000000000000000000) ((11799294457510297881747 : ℝ) / 31250000000000000000000) ((11799294457510297881747 : ℝ) / 31250000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((239895988241 : ℝ) / 250000000000) ((239901869423 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((940092436373 : ℝ) / 500000000000) ((11752195753 : ℝ) / 6250000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((253394412399 : ℝ) / 1000000000000)) ((1063617023 : ℝ) / 50000000000) ((10717706999 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((46564935453 : ℝ) / 31250000000)) ((829161 : ℝ) / 5000000000) ((60400749 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((253394412399 : ℝ) / 1000000000000)) (wl := ((46564935453 : ℝ) / 31250000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((940092436373 : ℝ) / 500000000000) ≤ D0q (q) * (((46564935453 : ℝ) / 31250000000) - ((253394412399 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((46564935453 : ℝ) / 31250000000) * ((253394412399 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_70 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((160353871212010311651552723678003 : ℝ) / 1298074214633706907132624082305024) ((641508834638242053419213262946303 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((61766064453 : ℝ) / 500000000000) ((61775053711 : ℝ) / 500000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((561766064453 : ℝ) / 500000000000) ((561775053711 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((116477409391 : ℝ) / 1000000000000) ((58246705523 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_859.1 dlower_log_860.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((116477409391 : ℝ) / 500000000000) ((58246705523 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460160358467 : ℝ) / 1000000000000) ((230096180889 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-130703375229 : ℝ) / 62500000000) ((-418221695417 : ℝ) / 200000000000) := rb_log hqr (by norm_num) dlower_log_861.1 dlower_log_862.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((418221695417 : ℝ) / 200000000000) ((130703375229 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((44008079139 : ℝ) / 200000000000) ((220071013447 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779928986553 : ℝ) / 1000000000000) ((155991920861 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1907523359 : ℝ) / 125000000000) ((3816157261 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((102595104329 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((94962789807 : ℝ) / 500000000000) ((94965010893 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((102595104329 : ℝ) / 500000000000) ((102595104329 : ℝ) / 500000000000) ((102595104329 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((397404895671 : ℝ) / 500000000000))
  have h11 : RB z11 ((47791454429 : ℝ) / 200000000000) ((238962861121 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((397404895671 : ℝ) / 500000000000) ((397404895671 : ℝ) / 500000000000) ((397404895671 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-143147052067 : ℝ) / 100000000000) ((-1431447131923 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_863.1 dlower_log_864.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-1116489180877 : ℝ) / 1000000000000) ((-139553388863 : ℝ) / 125000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((102595104329 : ℝ) / 500000000000))
  have h14 : RB z14 ((-395954470729 : ℝ) / 250000000000) ((-791908941457 : ℝ) / 500000000000) := rb_log (show RB ((102595104329 : ℝ) / 500000000000) ((102595104329 : ℝ) / 500000000000) ((102595104329 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_865.1 dlower_log_865.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((467328702037 : ℝ) / 1000000000000) ((116847693003 : ℝ) / 250000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((7136340259 : ℝ) / 1000000000000) ((1446082709 : ℝ) / 200000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1907523359 : ℝ) / 125000000000) ((3816157261 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1490171056789 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((294981285549 : ℝ) / 200000000000) ((1474910869917 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1490171056789 : ℝ) / 1000000000000) ((1490171056789 : ℝ) / 1000000000000) ((1490171056789 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((490171056789 : ℝ) / 1000000000000))
  have h19 : RB z19 ((188060168909 : ℝ) / 62500000000) ((3008971765039 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((490171056789 : ℝ) / 1000000000000) ((490171056789 : ℝ) / 1000000000000) ((490171056789 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((110159540227 : ℝ) / 100000000000) ((1101598414101 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_866.1 dlower_log_867.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((859166185683 : ℝ) / 1000000000000) ((429601131583 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1490171056789 : ℝ) / 1000000000000))
  have h22 : RB z22 ((398890916581 : ℝ) / 1000000000000) ((398890916583 : ℝ) / 1000000000000) := rb_log (show RB ((1490171056789 : ℝ) / 1000000000000) ((1490171056789 : ℝ) / 1000000000000) ((1490171056789 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_868.1 dlower_log_868.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((4602752691 : ℝ) / 10000000000) ((92062269317 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((41453661 : ℝ) / 500000000000) ((75494059 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((561766064453 : ℝ) / 500000000000) ((561775053711 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((315581111171 : ℝ) / 250000000000) ((78897802743 : ℝ) / 62500000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((792164012521 : ℝ) / 500000000000) ((1584378729591 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1284980848131 : ℝ) / 1000000000000))
  have h28 : RB z28 ((254478896167 : ℝ) / 125000000000) ((2035896323711 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1284980848131 : ℝ) / 1000000000000) ((1284980848131 : ℝ) / 1000000000000) ((1284980848131 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1907523359 : ℝ) / 125000000000) ((3816157261 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((152884255039323638739581 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((49907647023 : ℝ) / 1000000000000) ((49922174917 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((152884255039323638739581 : ℝ) / 500000000000000000000000) ((152884255039323638739581 : ℝ) / 500000000000000000000000) ((152884255039323638739581 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((950077825083 : ℝ) / 1000000000000) ((950092352977 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((967099024799 : ℝ) / 500000000000) ((483572382153 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((102595104329 : ℝ) / 500000000000)) ((7136340259 : ℝ) / 1000000000000) ((1446082709 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1490171056789 : ℝ) / 1000000000000)) ((41453661 : ℝ) / 500000000000) ((75494059 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((102595104329 : ℝ) / 500000000000)) (wl := ((1490171056789 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((967099024799 : ℝ) / 500000000000) ≤ D0q (q) * (((1490171056789 : ℝ) / 1000000000000) - ((102595104329 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((1490171056789 : ℝ) / 1000000000000) * ((102595104329 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_71 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((641508834638242053419213262946303 : ℝ) / 5192296858534827628530496329220096) ((641602184428442860232215631180595 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((123550107421 : ℝ) / 1000000000000) ((61784042969 : ℝ) / 500000000000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1123550107421 : ℝ) / 1000000000000) ((561784042969 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((29123352761 : ℝ) / 250000000000) ((29127353111 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_869.1 dlower_log_870.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((29123352761 : ℝ) / 125000000000) ((29127353111 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460128355671 : ℝ) / 1000000000000) ((57520044809 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-418221695419 : ℝ) / 200000000000) ((-2090962971683 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_871.1 dlower_log_872.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2090962971683 : ℝ) / 1000000000000) ((418221695419 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((220040404747 : ℝ) / 1000000000000) ((110035511079 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((389964488921 : ℝ) / 500000000000) ((779959595253 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15264629043 : ℝ) / 1000000000000) ((15269071863 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((112690472829 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((42022374759 : ℝ) / 200000000000) ((42023263323 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((112690472829 : ℝ) / 500000000000) ((112690472829 : ℝ) / 500000000000) ((112690472829 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((387309527171 : ℝ) / 500000000000))
  have h11 : RB z11 ((5424908479 : ℝ) / 20000000000) ((271251159441 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((387309527171 : ℝ) / 500000000000) ((387309527171 : ℝ) / 500000000000) ((387309527171 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1304731244501 : ℝ) / 1000000000000) ((-652355049849 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_873.1 dlower_log_874.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-8141101227 : ℝ) / 8000000000) ((-1017581214437 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((112690472829 : ℝ) / 500000000000))
  have h14 : RB z14 ((-1489963216629 : ℝ) / 1000000000000) ((-1489963216627 : ℝ) / 1000000000000) := rb_log (show RB ((112690472829 : ℝ) / 500000000000) ((112690472829 : ℝ) / 500000000000) ((112690472829 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_875.1 dlower_log_875.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((118081390813 : ℝ) / 250000000000) ((29523875137 : ℝ) / 62500000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((608260239 : ℝ) / 50000000000) ((12253646521 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15264629043 : ℝ) / 1000000000000) ((15269071863 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((46568379979 : ℝ) / 31250000000)) - (z17)
  have h18 : RB z18 ((294983817493 : ℝ) / 200000000000) ((294984706057 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((46568379979 : ℝ) / 31250000000) ((46568379979 : ℝ) / 31250000000) ((46568379979 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((15318379979 : ℝ) / 31250000000))
  have h19 : RB z19 ((1504441773427 : ℝ) / 500000000000) ((1504446305177 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((15318379979 : ℝ) / 31250000000) ((15318379979 : ℝ) / 31250000000) ((15318379979 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1101569095287 : ℝ) / 1000000000000) ((1101572107531 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_876.1 dlower_log_877.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((859145658509 : ℝ) / 1000000000000) ((214795433783 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((46568379979 : ℝ) / 31250000000))
  have h22 : RB z22 ((398902393411 : ℝ) / 1000000000000) ((398902393413 : ℝ) / 1000000000000) := rb_log (show RB ((46568379979 : ℝ) / 31250000000) ((46568379979 : ℝ) / 31250000000) ((46568379979 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_878.1 dlower_log_878.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((57530408137 : ℝ) / 125000000000) ((460279341721 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((161927 : ℝ) / 1953125000) ((3019721 : ℝ) / 20000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1123550107421 : ℝ) / 1000000000000) ((561784042969 : ℝ) / 500000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((252472968777 : ℝ) / 200000000000) ((1262405243739 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1584277322927 : ℝ) / 1000000000000) ((1584328025047 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((126480721367 : ℝ) / 100000000000))
  have h28 : RB z28 ((2003805386491 : ℝ) / 1000000000000) ((2003869514899 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((126480721367 : ℝ) / 100000000000) ((126480721367 : ℝ) / 100000000000) ((126480721367 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15264629043 : ℝ) / 1000000000000) ((15269071863 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((5247812758714047090591 : ℝ) / 15625000000000000000000))
  have h30 : RB z30 ((45449378581 : ℝ) / 1000000000000) ((11365651693 : ℝ) / 250000000000) := rb_div_signed h29 (show RB ((5247812758714047090591 : ℝ) / 15625000000000000000000) ((5247812758714047090591 : ℝ) / 15625000000000000000000) ((5247812758714047090591 : ℝ) / 15625000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((238634348307 : ℝ) / 250000000000) ((954550621419 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1912707170157 : ℝ) / 1000000000000) ((191279489069 : ℝ) / 100000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((112690472829 : ℝ) / 500000000000)) ((608260239 : ℝ) / 50000000000) ((12253646521 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((46568379979 : ℝ) / 31250000000)) ((161927 : ℝ) / 1953125000) ((3019721 : ℝ) / 20000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((112690472829 : ℝ) / 500000000000)) (wl := ((46568379979 : ℝ) / 31250000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1912707170157 : ℝ) / 1000000000000) ≤ D0q (q) * (((46568379979 : ℝ) / 31250000000) - ((112690472829 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((46568379979 : ℝ) / 31250000000) * ((112690472829 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
