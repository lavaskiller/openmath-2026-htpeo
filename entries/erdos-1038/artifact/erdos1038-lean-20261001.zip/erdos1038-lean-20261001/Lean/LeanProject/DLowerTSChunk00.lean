import LeanProject.DLowerLogs
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_T_0 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r (0 : ℝ) ((3912727356259487 : ℝ) / 72057594037927936)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((1004487 : ℝ) / 100000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((3912727356259487 : ℝ) / 72057594037927936) ≤ ((-1151012736283 : ℝ) / 62500000000) by norm_num).trans dlower_log_0.1)
  have hql : (0 : ℝ) ≤ tailQ r := (tailQ_pos hr0).le
  have hqr : RB (tailQ r) (0 : ℝ) ((1004487 : ℝ) / 100000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 (1 : ℝ) ((200000002009 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 (0 : ℝ) ((2009 : ℝ) / 200000000000) := rb_log h1 (by norm_num) dlower_log_1.1 dlower_log_2.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 (0 : ℝ) ((2009 : ℝ) / 100000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((693147160469 : ℝ) / 1000000000000) ((8664339757 : ℝ) / 12500000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 (0 : ℝ) ((7527578381 : ℝ) / 200000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((192472421619 : ℝ) / 200000000000) (1 : ℝ) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 (0 : ℝ) ((1 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((250000008147 : ℝ) / 500000000000)) - (z7)
  have h8 : RB z8 ((500000016293 : ℝ) / 1000000000000) ((250000008147 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((250000008147 : ℝ) / 500000000000) ((250000008147 : ℝ) / 500000000000) ((250000008147 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((249999991853 : ℝ) / 500000000000))
  have h9 : RB z9 ((500000032587 : ℝ) / 500000000000) ((1000000065177 : ℝ) / 1000000000000) := rb_div_signed h8 (show RB ((249999991853 : ℝ) / 500000000000) ((249999991853 : ℝ) / 500000000000) ((249999991853 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((65173 : ℝ) / 1000000000000) ((65177 : ℝ) / 1000000000000) := rb_log h9 (by norm_num) dlower_log_3.1 dlower_log_4.2
  let z11 : ℝ := (z6) * (z10)
  have h11 : RB z11 ((49 : ℝ) / 781250000) ((65177 : ℝ) / 1000000000000) := rb_widen (rb_mul h6 h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((250000008147 : ℝ) / 500000000000))
  have h12 : RB z12 ((-693147147973 : ℝ) / 1000000000000) ((-693147147971 : ℝ) / 1000000000000) := rb_log (show RB ((250000008147 : ℝ) / 500000000000) ((250000008147 : ℝ) / 500000000000) ((250000008147 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_5.1 dlower_log_5.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((693147210691 : ℝ) / 1000000000000) ((13862944263 : ℝ) / 20000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((30131 : ℝ) / 1000000000000) ((52681 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 (0 : ℝ) ((1 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((289483375211 : ℝ) / 200000000000)) - (z15)
  have h16 : RB z16 ((723708438027 : ℝ) / 500000000000) ((289483375211 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((289483375211 : ℝ) / 200000000000) ((289483375211 : ℝ) / 200000000000) ((289483375211 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((89483375211 : ℝ) / 200000000000))
  have h17 : RB z17 ((3235052036517 : ℝ) / 1000000000000) ((80876300913 : ℝ) / 25000000000) := rb_div_signed h16 (show RB ((89483375211 : ℝ) / 200000000000) ((89483375211 : ℝ) / 200000000000) ((89483375211 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((1174045013299 : ℝ) / 1000000000000) ((587022506651 : ℝ) / 500000000000) := rb_log h17 (by norm_num) dlower_log_6.1 dlower_log_7.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((282464108499 : ℝ) / 250000000000) ((587022506651 : ℝ) / 500000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((289483375211 : ℝ) / 200000000000))
  have h20 : RB z20 ((184890251473 : ℝ) / 500000000000) ((92445125737 : ℝ) / 250000000000) := rb_log (show RB ((289483375211 : ℝ) / 200000000000) ((289483375211 : ℝ) / 200000000000) ((289483375211 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_8.1 dlower_log_8.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((95009491381 : ℝ) / 125000000000) ((201066127589 : ℝ) / 250000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((8366093811 : ℝ) / 125000000000) ((111117349887 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 (1 : ℝ) ((200000002009 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 (1 : ℝ) ((1000000020091 : ℝ) / 1000000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((999999979909 : ℝ) / 500000000000) (2 : ℝ) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((947416859761 : ℝ) / 1000000000000))
  have h26 : RB z26 ((473708420363 : ℝ) / 250000000000) ((947416859761 : ℝ) / 500000000000) := rb_widen (rb_mul h25 (show RB ((947416859761 : ℝ) / 1000000000000) ((947416859761 : ℝ) / 1000000000000) ((947416859761 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 (0 : ℝ) ((1 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((72370846161171057844017 : ℝ) / 100000000000000000000000))
  have h28 : RB z28 (0 : ℝ) ((1 : ℝ) / 500000000000) := rb_div_signed h27 (show RB ((72370846161171057844017 : ℝ) / 100000000000000000000000) ((72370846161171057844017 : ℝ) / 100000000000000000000000) ((72370846161171057844017 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((499999999999 : ℝ) / 500000000000) (1 : ℝ) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((236854210181 : ℝ) / 125000000000) ((947416859761 : ℝ) / 500000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((250000008147 : ℝ) / 500000000000)) ((30131 : ℝ) / 1000000000000) ((52681 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((289483375211 : ℝ) / 200000000000)) ((8366093811 : ℝ) / 125000000000) ((111117349887 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((250000008147 : ℝ) / 500000000000)) (wl := ((289483375211 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((236854210181 : ℝ) / 125000000000) ≤ D0q (tailQ r) * (((289483375211 : ℝ) / 200000000000) - ((250000008147 : ℝ) / 500000000000)) * (1 - (tailQ r) ^ 2 / (((289483375211 : ℝ) / 200000000000) * ((250000008147 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_1 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((3912727356259487 : ℝ) / 72057594037927936) ((3912727356259487 : ℝ) / 36028797018963968)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((501119873 : ℝ) / 5000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((3912727356259487 : ℝ) / 36028797018963968) ≤ ((-920810313047 : ℝ) / 100000000000) by norm_num).trans dlower_log_9.1)
  have hql : ((502241 : ℝ) / 50000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_10.2.trans (show ((-92081043791 : ℝ) / 5000000000) ≤ -1 / ((3912727356259487 : ℝ) / 72057594037927936) by norm_num))
  have hqr : RB (tailQ r) ((502241 : ℝ) / 50000000000000) ((501119873 : ℝ) / 5000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((250000002511 : ℝ) / 250000000000) ((40004008959 : ℝ) / 40000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((10043 : ℝ) / 1000000000000) ((100218953 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_11.1 dlower_log_12.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((10043 : ℝ) / 500000000000) ((100218953 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((692946742653 : ℝ) / 1000000000000) ((346573580237 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((18813504063 : ℝ) / 500000000000) ((18818945407 : ℝ) / 250000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((231181054593 : ℝ) / 250000000000) ((481186495937 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 (0 : ℝ) ((2009 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((125044250453 : ℝ) / 250000000000)) - (z7)
  have h8 : RB z8 ((500176991767 : ℝ) / 1000000000000) ((125044250453 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((125044250453 : ℝ) / 250000000000) ((125044250453 : ℝ) / 250000000000) ((125044250453 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((124955749547 : ℝ) / 250000000000))
  have h9 : RB z9 ((250177059469 : ℝ) / 250000000000) ((500354128987 : ℝ) / 500000000000) := rb_div_signed h8 (show RB ((124955749547 : ℝ) / 250000000000) ((124955749547 : ℝ) / 250000000000) ((124955749547 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((707987193 : ℝ) / 1000000000000) ((354003639 : ℝ) / 500000000000) := rb_log h9 (by norm_num) dlower_log_13.1 dlower_log_14.2
  let z11 : ℝ := (z6) * (z10)
  have h11 : RB z11 ((654692903 : ℝ) / 1000000000000) ((681367083 : ℝ) / 1000000000000) := rb_widen (rb_mul h6 h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((125044250453 : ℝ) / 250000000000))
  have h12 : RB z12 ((-692793239581 : ℝ) / 1000000000000) ((-692793239579 : ℝ) / 1000000000000) := rb_log (show RB ((125044250453 : ℝ) / 250000000000) ((125044250453 : ℝ) / 250000000000) ((125044250453 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_15.1 dlower_log_15.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((346723966241 : ℝ) / 500000000000) ((86684325833 : ℝ) / 125000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((37596501 : ℝ) / 125000000000) ((527864011 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 (0 : ℝ) ((2009 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((285219472921 : ℝ) / 200000000000)) - (z15)
  have h16 : RB z16 ((4456554233 : ℝ) / 3125000000) ((285219472921 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((285219472921 : ℝ) / 200000000000) ((285219472921 : ℝ) / 200000000000) ((285219472921 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((85219472921 : ℝ) / 200000000000))
  have h17 : RB z17 ((3346881424347 : ℝ) / 1000000000000) ((3346881447923 : ℝ) / 1000000000000) := rb_div_signed h16 (show RB ((85219472921 : ℝ) / 200000000000) ((85219472921 : ℝ) / 200000000000) ((85219472921 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((1208028994157 : ℝ) / 1000000000000) ((1208029001203 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_16.1 dlower_log_17.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((17454588553 : ℝ) / 15625000000) ((1162574484159 : ℝ) / 1000000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((285219472921 : ℝ) / 200000000000))
  have h20 : RB z20 ((44367699723 : ℝ) / 125000000000) ((177470798893 : ℝ) / 500000000000) := rb_log (show RB ((285219472921 : ℝ) / 200000000000) ((285219472921 : ℝ) / 200000000000) ((285219472921 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_18.1 dlower_log_18.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((381076034803 : ℝ) / 500000000000) ((6461063091 : ℝ) / 8000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((17251227283 : ℝ) / 250000000000) ((57343071861 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((250000002511 : ℝ) / 250000000000) ((40004008959 : ℝ) / 40000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((125000002511 : ℝ) / 125000000000) ((200040091599 : ℝ) / 200000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((49989979109 : ℝ) / 25000000000) ((79999998393 : ℝ) / 40000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((925920362793 : ℝ) / 1000000000000))
  have h26 : RB z26 ((231433697963 : ℝ) / 125000000000) ((462960172097 : ℝ) / 250000000000) := rb_widen (rb_mul h25 (show RB ((925920362793 : ℝ) / 1000000000000) ((925920362793 : ℝ) / 1000000000000) ((925920362793 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 (0 : ℝ) ((2009 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((35665055206006175483213 : ℝ) / 50000000000000000000000))
  have h28 : RB z28 (0 : ℝ) ((14083 : ℝ) / 1000000000000) := rb_div_signed h27 (show RB ((35665055206006175483213 : ℝ) / 50000000000000000000000) ((35665055206006175483213 : ℝ) / 50000000000000000000000) ((35665055206006175483213 : ℝ) / 50000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((999999985917 : ℝ) / 1000000000000) (1 : ℝ) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1851469557629 : ℝ) / 1000000000000) ((462960172097 : ℝ) / 250000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((125044250453 : ℝ) / 250000000000)) ((37596501 : ℝ) / 125000000000) ((527864011 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((285219472921 : ℝ) / 200000000000)) ((17251227283 : ℝ) / 250000000000) ((57343071861 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((125044250453 : ℝ) / 250000000000)) (wl := ((285219472921 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1851469557629 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((285219472921 : ℝ) / 200000000000) - ((125044250453 : ℝ) / 250000000000)) * (1 - (tailQ r) ^ 2 / (((285219472921 : ℝ) / 200000000000) * ((125044250453 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_2 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((3912727356259487 : ℝ) / 36028797018963968) ((19563636781297435 : ℝ) / 144115188075855872)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((1975273871 : ℝ) / 3125000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((19563636781297435 : ℝ) / 144115188075855872) ≤ ((-7366482504571 : ℝ) / 1000000000000) by norm_num).trans dlower_log_19.1)
  have hql : ((2004479491 : ℝ) / 20000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_20.2.trans (show ((-4604051565483 : ℝ) / 500000000000) ≤ -1 / ((3912727356259487 : ℝ) / 36028797018963968) by norm_num))
  have hqr : RB (tailQ r) ((2004479491 : ℝ) / 20000000000000) ((1975273871 : ℝ) / 3125000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((500050111987 : ℝ) / 500000000000) ((1000632087639 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((100218951 : ℝ) / 1000000000000) ((157971989 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_21.1 dlower_log_22.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((100218951 : ℝ) / 500000000000) ((157971989 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((691883404647 : ℝ) / 1000000000000) ((346473371329 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((4696158609 : ℝ) / 62500000000) ((23516880079 : ℝ) / 250000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((226483119921 : ℝ) / 250000000000) ((57803841391 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((2511 : ℝ) / 250000000000) ((79907 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((100174959107 : ℝ) / 200000000000)) - (z7)
  have h8 : RB z8 ((125218599 : ℝ) / 250000000) ((500874785491 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((100174959107 : ℝ) / 200000000000) ((100174959107 : ℝ) / 200000000000) ((100174959107 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((99825040893 : ℝ) / 200000000000))
  have h9 : RB z9 ((1003504514537 : ℝ) / 1000000000000) ((200701058977 : ℝ) / 200000000000) := rb_div_signed h8 (show RB ((99825040893 : ℝ) / 200000000000) ((99825040893 : ℝ) / 200000000000) ((99825040893 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((699677607 : ℝ) / 200000000000) ((1749582829 : ℝ) / 500000000000) := rb_log h9 (by norm_num) dlower_log_23.1 dlower_log_24.2
  let z11 : ℝ := (z6) * (z10)
  have h11 : RB z11 ((3169303347 : ℝ) / 1000000000000) ((809060867 : ℝ) / 250000000000) := rb_widen (rb_mul h6 h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((100174959107 : ℝ) / 200000000000))
  have h12 : RB z12 ((-345699559121 : ℝ) / 500000000000) ((-4321244489 : ℝ) / 6250000000) := rb_log (show RB ((100174959107 : ℝ) / 200000000000) ((100174959107 : ℝ) / 200000000000) ((100174959107 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_25.1 dlower_log_25.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((694568421587 : ℝ) / 1000000000000) ((69463536171 : ℝ) / 100000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((1621678929 : ℝ) / 1000000000000) ((2751957063 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((2511 : ℝ) / 250000000000) ((79907 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((715783239701 : ℝ) / 500000000000)) - (z15)
  have h16 : RB z16 ((1431566079867 : ℝ) / 1000000000000) ((715783234679 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((715783239701 : ℝ) / 500000000000) ((715783239701 : ℝ) / 500000000000) ((715783239701 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((215783239701 : ℝ) / 500000000000))
  have h17 : RB z17 ((663427837051 : ℝ) / 200000000000) ((3317140087761 : ℝ) / 1000000000000) := rb_div_signed h16 (show RB ((215783239701 : ℝ) / 500000000000) ((215783239701 : ℝ) / 500000000000) ((215783239701 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((1199102720269 : ℝ) / 1000000000000) ((239820598469 : ℝ) / 200000000000) := rb_log h17 (by norm_num) dlower_log_26.1 dlower_log_27.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1086306100769 : ℝ) / 1000000000000) ((69312759181 : ℝ) / 62500000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((715783239701 : ℝ) / 500000000000))
  have h20 : RB z20 ((71753856971 : ℝ) / 200000000000) ((358769284857 : ℝ) / 1000000000000) := rb_log (show RB ((715783239701 : ℝ) / 500000000000) ((715783239701 : ℝ) / 500000000000) ((715783239701 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_28.1 dlower_log_28.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((90942101989 : ℝ) / 125000000000) ((750234862041 : ℝ) / 1000000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((17295036627 : ℝ) / 500000000000) ((29175728697 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((500050111987 : ℝ) / 500000000000) ((1000632087639 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((125025057249 : ℝ) / 125000000000) ((1001264574813 : ℝ) / 1000000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((1997474044633 : ℝ) / 1000000000000) ((1999599164367 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((930691683867 : ℝ) / 1000000000000))
  have h26 : RB z26 ((11618953013 : ℝ) / 6250000000) ((14539143073 : ℝ) / 7812500000) := rb_widen (rb_mul h25 (show RB ((930691683867 : ℝ) / 1000000000000) ((930691683867 : ℝ) / 1000000000000) ((930691683867 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((2511 : ℝ) / 250000000000) ((79907 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((71703556766523653907007 : ℝ) / 100000000000000000000000))
  have h28 : RB z28 ((14007 : ℝ) / 1000000000000) ((139301 : ℝ) / 250000000000) := rb_div_signed h27 (show RB ((71703556766523653907007 : ℝ) / 100000000000000000000000) ((71703556766523653907007 : ℝ) / 100000000000000000000000) ((71703556766523653907007 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((249999860699 : ℝ) / 250000000000) ((999999985993 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1859031446219 : ℝ) / 1000000000000) ((1861010287277 : ℝ) / 1000000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((100174959107 : ℝ) / 200000000000)) ((1621678929 : ℝ) / 1000000000000) ((2751957063 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((715783239701 : ℝ) / 500000000000)) ((17295036627 : ℝ) / 500000000000) ((29175728697 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((100174959107 : ℝ) / 200000000000)) (wl := ((715783239701 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1859031446219 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((715783239701 : ℝ) / 500000000000) - ((100174959107 : ℝ) / 200000000000)) * (1 - (tailQ r) ^ 2 / (((715783239701 : ℝ) / 500000000000) * ((100174959107 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_3 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((19563636781297435 : ℝ) / 144115188075855872) ((43040000918854357 : ℝ) / 288230376151711744)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((123485431813 : ℝ) / 100000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((43040000918854357 : ℝ) / 288230376151711744) ≤ ((-669680227689 : ℝ) / 100000000000) by norm_num).trans dlower_log_29.1)
  have hql : ((63208763867 : ℝ) / 100000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_30.2.trans (show ((-920810313081 : ℝ) / 125000000000) ≤ -1 / ((19563636781297435 : ℝ) / 144115188075855872) by norm_num))
  have hqr : RB (tailQ r) ((63208763867 : ℝ) / 100000000000000) ((123485431813 : ℝ) / 100000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((500316043819 : ℝ) / 500000000000) ((1001234854319 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((315943977 : ℝ) / 500000000000) ((617046257 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_31.1 dlower_log_32.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((315943977 : ℝ) / 250000000000) ((617046257 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((690678995531 : ℝ) / 1000000000000) ((172970851163 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((93759673643 : ℝ) / 1000000000000) ((516577447 : ℝ) / 5000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((4483422553 : ℝ) / 5000000000) ((906240326357 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((199767 : ℝ) / 500000000000) ((762433 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((500394347999 : ℝ) / 1000000000000)) - (z7)
  have h8 : RB z8 ((500392823133 : ℝ) / 1000000000000) ((100078789693 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((500394347999 : ℝ) / 1000000000000) ((500394347999 : ℝ) / 1000000000000) ((500394347999 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((499605652001 : ℝ) / 1000000000000))
  have h9 : RB z9 ((1001575584921 : ℝ) / 1000000000000) ((1001577837363 : ℝ) / 1000000000000) := rb_div_signed h8 (show RB ((499605652001 : ℝ) / 1000000000000) ((499605652001 : ℝ) / 1000000000000) ((499605652001 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((1574344989 : ℝ) / 1000000000000) ((788296943 : ℝ) / 500000000000) := rb_log h9 (by norm_num) dlower_log_33.1 dlower_log_34.2
  let z11 : ℝ := (z6) * (z10)
  have h11 : RB z11 ((282338153 : ℝ) / 200000000000) ((714386479 : ℝ) / 500000000000) := rb_widen (rb_mul h6 h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((500394347999 : ℝ) / 1000000000000))
  have h12 : RB z12 ((-34617939771 : ℝ) / 50000000000) ((-346179397709 : ℝ) / 500000000000) := rb_log (show RB ((500394347999 : ℝ) / 1000000000000) ((500394347999 : ℝ) / 1000000000000) ((500394347999 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_35.1 dlower_log_35.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((693770486183 : ℝ) / 1000000000000) ((346893784189 : ℝ) / 500000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((1887081531 : ℝ) / 1000000000000) ((3108572847 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((199767 : ℝ) / 500000000000) ((762433 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((1434842542449 : ℝ) / 1000000000000)) - (z15)
  have h16 : RB z16 ((1434841017583 : ℝ) / 1000000000000) ((286968428583 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((1434842542449 : ℝ) / 1000000000000) ((1434842542449 : ℝ) / 1000000000000) ((1434842542449 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((434842542449 : ℝ) / 1000000000000))
  have h17 : RB z17 ((1649839743717 : ℝ) / 500000000000) ((1649841037671 : ℝ) / 500000000000) := rb_div_signed h16 (show RB ((434842542449 : ℝ) / 1000000000000) ((434842542449 : ℝ) / 1000000000000) ((434842542449 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((596912669367 : ℝ) / 500000000000) ((1193826123027 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_36.1 dlower_log_37.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((267621172401 : ℝ) / 250000000000) ((540946687673 : ℝ) / 500000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((1434842542449 : ℝ) / 1000000000000))
  have h20 : RB z20 ((361055116673 : ℝ) / 1000000000000) ((14442204667 : ℝ) / 40000000000) := rb_log (show RB ((1434842542449 : ℝ) / 1000000000000) ((1434842542449 : ℝ) / 1000000000000) ((1434842542449 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_38.1 dlower_log_38.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((709429572929 : ℝ) / 1000000000000) ((720838258673 : ℝ) / 1000000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((17546168277 : ℝ) / 1000000000000) ((15079631571 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((500316043819 : ℝ) / 500000000000) ((1001234854319 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((100126457481 : ℝ) / 100000000000) ((31327226047 : ℝ) / 31250000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((249383714609 : ℝ) / 125000000000) ((12484212779 : ℝ) / 6250000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((18688963889 : ℝ) / 20000000000))
  have h26 : RB z26 ((466072323683 : ℝ) / 250000000000) ((74661440579 : ℝ) / 40000000000) := rb_widen (rb_mul h25 (show RB ((18688963889 : ℝ) / 20000000000) ((18688963889 : ℝ) / 20000000000) ((18688963889 : ℝ) / 20000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((199767 : ℝ) / 500000000000) ((762433 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((717987098509994835709551 : ℝ) / 1000000000000000000000000))
  have h28 : RB z28 ((34779 : ℝ) / 62500000000) ((2123807 : ℝ) / 1000000000000) := rb_div_signed h27 (show RB ((717987098509994835709551 : ℝ) / 1000000000000000000000000) ((717987098509994835709551 : ℝ) / 1000000000000000000000000) ((717987098509994835709551 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((999997876193 : ℝ) / 1000000000000) ((62499965221 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1864285335341 : ℝ) / 1000000000000) ((373306995163 : ℝ) / 200000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((500394347999 : ℝ) / 1000000000000)) ((1887081531 : ℝ) / 1000000000000) ((3108572847 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((1434842542449 : ℝ) / 1000000000000)) ((17546168277 : ℝ) / 1000000000000) ((15079631571 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((500394347999 : ℝ) / 1000000000000)) (wl := ((1434842542449 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1864285335341 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((1434842542449 : ℝ) / 1000000000000) - ((500394347999 : ℝ) / 1000000000000)) * (1 - (tailQ r) ^ 2 / (((1434842542449 : ℝ) / 1000000000000) * ((500394347999 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
