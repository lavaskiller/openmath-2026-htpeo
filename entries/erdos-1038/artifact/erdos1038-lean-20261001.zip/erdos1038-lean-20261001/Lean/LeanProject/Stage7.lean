import LeanProject.RefBridge
import LeanProject.Residual
import LeanProject.Bridge

/-!
# EP-1038, Stage 7 (reductions for the infimum), in the root-vector language

A polynomial `f ∈ 𝒫` of degree `n` is `∏ (x - s i)` with `s : Fin n → [-1, 1]`, and
`S_f = sublevel s = {x : |∏ (x - s i)| < 1}`.

* `lemma71` (**Lemma 7.1**): every point of `S` is joined inside `S` to a root, i.e. every
  component of `S` contains a root (concavity of `log|f|` on root-free intervals);
  `lemma71_union`: `S = ⋃ᵢ (ℓ(sᵢ), ρ(sᵢ))`, a finite union of bounded open intervals.
* `lemma74` (**Lemma 7.4**, (i)–(iv)), `lemma75` (**Lemma 7.5**, (a), (b) and `|S| ≥ 𝒥`),
  `lemma76` (**Lemma 7.6**: `ρ(k)`, `ρ(1) = √2 - 1`, monotonicity, `M_k ≥ 1 + ρ(k)`);
  Corollary 7.7 is `EP1038.sqrt2_le_volume_le` (Atomize.lean).
* `lemma72` (**Lemma 7.2**): simultaneous atomization (`Atom.cmean`): roots stay in `[-1, 1]`,
  the root sum is unchanged, `S(cmean) ⊆ S`, and every component of `S(cmean)` carries at most one
  root value (segment form; `seg_iff_comp` is [M-181]); at least one by `lemma71`.
* `lemma73` (**Lemma 7.3**): root sum `≤ 0` ⇒ `(-1, 0) ⊆ S`.
-/

open Real MeasureTheory Set Finset Polynomial

namespace EP1038.Stage7

open Resid Atom

/-- Concavity of `y ↦ log|y - t|` along a segment `[l, ρ]` not containing `t`. -/
theorem log_abs_concave {t l ρ x : ℝ} (hlρ : l < ρ) (hx : x ∈ Icc l ρ)
    (ht : t < l ∨ ρ < t) :
    (1 - (x - l) / (ρ - l)) * Real.log |l - t| + (x - l) / (ρ - l) * Real.log |ρ - t| ≤
      Real.log |x - t| := by
  have hd : 0 < ρ - l := by linarith
  set w := (x - l) / (ρ - l) with hw
  have hw0 : 0 ≤ w := div_nonneg (by linarith [hx.1]) hd.le
  have hw1 : w ≤ 1 := by rw [hw, div_le_one hd]; linarith [hx.2]
  have hxw : x = (1 - w) * l + w * ρ := by rw [hw]; field_simp; ring
  rcases ht with ht | ht
  · have ha : l - t ∈ Ioi (0 : ℝ) := by simp only [Set.mem_Ioi]; linarith
    have hb : ρ - t ∈ Ioi (0 : ℝ) := by simp only [Set.mem_Ioi]; linarith
    have h := strictConcaveOn_log_Ioi.concaveOn.2 ha hb (show (0 : ℝ) ≤ 1 - w by linarith) hw0
      (show (1 - w) + w = 1 by ring)
    simp only [smul_eq_mul] at h
    rw [abs_of_pos (show (0 : ℝ) < l - t by linarith), abs_of_pos (show (0 : ℝ) < ρ - t by linarith),
      abs_of_pos (show (0 : ℝ) < x - t by rw [hxw]; nlinarith)]
    calc (1 - w) * Real.log (l - t) + w * Real.log (ρ - t)
        ≤ Real.log ((1 - w) * (l - t) + w * (ρ - t)) := h
      _ = Real.log (x - t) := by rw [hxw]; ring_nf
  · have ha : t - l ∈ Ioi (0 : ℝ) := by simp only [Set.mem_Ioi]; linarith
    have hb : t - ρ ∈ Ioi (0 : ℝ) := by simp only [Set.mem_Ioi]; linarith
    have h := strictConcaveOn_log_Ioi.concaveOn.2 ha hb (show (0 : ℝ) ≤ 1 - w by linarith) hw0
      (show (1 - w) + w = 1 by ring)
    simp only [smul_eq_mul] at h
    rw [abs_of_neg (show l - t < 0 by linarith), abs_of_neg (show ρ - t < 0 by linarith),
      abs_of_neg (show x - t < 0 by rw [hxw]; nlinarith)]
    calc (1 - w) * Real.log (-(l - t)) + w * Real.log (-(ρ - t))
        = (1 - w) * Real.log (t - l) + w * Real.log (t - ρ) := by ring_nf
      _ ≤ Real.log ((1 - w) * (t - l) + w * (t - ρ)) := h
      _ = Real.log (-(x - t)) := by rw [hxw]; ring_nf

/-- **Lemma 7.1**: every component of `S` contains a root. -/
theorem lemma71 {n : ℕ} (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1) {x : ℝ}
    (hx : x ∈ sublevel s) : ∃ i, uIcc x (s i) ⊆ sublevel s := by
  classical
  have hx2 := sublevel_subset_Ioo s hs hx
  obtain ⟨hL1, hL2, hL3⟩ := ellL_props hs x (by linarith [hx2.1])
  obtain ⟨hR1, hR2, hR3⟩ := rhoR_props hs x (by linarith [hx2.2])
  set l := ellL s x with hl
  set ρ := rhoR s x with hρ
  have hlx : l < x := lt_of_le_of_ne hL2 (fun h => hL1 (h ▸ hx))
  have hxρ : x < ρ := lt_of_le_of_ne hR2 (fun h => hR1 (h.symm ▸ hx))
  have hIoo : Ioo l ρ ⊆ sublevel s := fun y hy =>
    (le_or_gt y x).elim (fun h => hL3 y hy.1 h) (fun h => hR3 y h.le hy.2)
  by_cases hroot : ∃ i, s i ∈ Ioo l ρ
  · obtain ⟨i, hi⟩ := hroot
    exact ⟨i, (ordConnected_Ioo.uIcc_subset ⟨hlx, hxρ⟩ hi).trans hIoo⟩
  · exfalso
    push Not at hroot
    -- every root lies strictly outside `[l, ρ]`
    have hout : ∀ i, s i < l ∨ ρ < s i := by
      intro i
      have hsi : s i ∈ sublevel s := root_mem s i
      rcases lt_or_ge (s i) l with h | h
      · exact Or.inl h
      · have h' : l < s i := lt_of_le_of_ne h (fun e => hL1 (e ▸ hsi))
        have hge : ρ ≤ s i := by
          by_contra hc
          push Not at hc
          exact hroot i ⟨h', hc⟩
        exact Or.inr (lt_of_le_of_ne hge (fun e => hR1 (e.symm ▸ hsi)))
    -- `|f| = 1` at both ends
    have hfl : |∏ i, (l - s i)| = 1 := by
      apply abs_eq_one_of_boundary hL1
      intro ε hε
      refine ⟨l + min (ε / 2) ((x - l) / 2), ?_, hIoo ⟨?_, ?_⟩⟩
      · have h0 : 0 < min (ε / 2) ((x - l) / 2) := lt_min (by linarith) (by linarith)
        rw [abs_of_pos (by linarith)]
        linarith [min_le_left (ε / 2) ((x - l) / 2)]
      · linarith [lt_min (show 0 < ε / 2 by linarith) (show 0 < (x - l) / 2 by linarith)]
      · linarith [min_le_right (ε / 2) ((x - l) / 2)]
    have hfρ : |∏ i, (ρ - s i)| = 1 := by
      apply abs_eq_one_of_boundary hR1
      intro ε hε
      refine ⟨ρ - min (ε / 2) ((ρ - x) / 2), ?_, hIoo ⟨?_, ?_⟩⟩
      · have h0 : 0 < min (ε / 2) ((ρ - x) / 2) := lt_min (by linarith) (by linarith)
        rw [abs_of_neg (by linarith)]
        linarith [min_le_left (ε / 2) ((ρ - x) / 2)]
      · linarith [min_le_right (ε / 2) ((ρ - x) / 2)]
      · linarith [lt_min (show 0 < ε / 2 by linarith) (show 0 < (ρ - x) / 2 by linarith)]
    -- log|f| is a sum of logs (no factor vanishes on `[l, ρ]`)
    have hne : ∀ y ∈ Icc l ρ, ∀ i, y - s i ≠ 0 := by
      intro y hy i h
      rcases hout i with h' | h' <;> linarith [hy.1, hy.2]
    have hlog : ∀ y ∈ Icc l ρ, Real.log |∏ i, (y - s i)| = ∑ i, Real.log |y - s i| := by
      intro y hy
      rw [Finset.abs_prod, Real.log_prod]
      intro i _
      exact abs_ne_zero.mpr (hne y hy i)
    have hlρ : l < ρ := hlx.trans hxρ
    have hxI : x ∈ Icc l ρ := ⟨hlx.le, hxρ.le⟩
    have hsum : ∑ i, ((1 - (x - l) / (ρ - l)) * Real.log |l - s i| +
        (x - l) / (ρ - l) * Real.log |ρ - s i|) ≤ ∑ i, Real.log |x - s i| :=
      Finset.sum_le_sum fun i _ => log_abs_concave hlρ hxI (hout i)
    rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum,
      ← hlog l ⟨le_rfl, hlρ.le⟩, ← hlog ρ ⟨hlρ.le, le_rfl⟩, ← hlog x hxI, hfl, hfρ,
      Real.log_one] at hsum
    simp only [mul_zero, add_zero] at hsum
    have hpos : 0 < |∏ i, (x - s i)| := by
      rw [Finset.abs_prod]
      exact Finset.prod_pos fun i _ => abs_pos.mpr (hne x hxI i)
    have hlt : Real.log |∏ i, (x - s i)| < 0 := Real.log_neg hpos hx
    linarith

/-- **Lemma 7.1**, first part: `S` is the finite union of the bounded open intervals
`(ℓ(s i), ρ(s i))`, the components of the roots. -/
theorem lemma71_union {n : ℕ} (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1) :
    sublevel s = ⋃ i, Ioo (ellL s (s i)) (rhoR s (s i)) := by
  apply Set.Subset.antisymm
  · intro x hx
    obtain ⟨i, hi⟩ := lemma71 s hs hx
    obtain ⟨hL1, hL2, -⟩ := ellL_props hs (s i) (by linarith [(hs i).1])
    obtain ⟨hR1, hR2, -⟩ := rhoR_props hs (s i) (by linarith [(hs i).2])
    refine Set.mem_iUnion.mpr ⟨i, ?_, ?_⟩
    · by_contra hc
      push Not at hc
      have hmem : ellL s (s i) ∈ uIcc x (s i) := by
        rw [Set.mem_uIcc]; left; exact ⟨hc, hL2⟩
      exact hL1 (hi hmem)
    · by_contra hc
      push Not at hc
      have hmem : rhoR s (s i) ∈ uIcc x (s i) := by
        rw [Set.mem_uIcc]; right; exact ⟨hR2, hc⟩
      exact hR1 (hi hmem)
  · exact Set.iUnion_subset fun i => (comp_props hs i).2.2.1

/-- **Lemma 7.2** (simultaneous atomization), segment form. -/
theorem lemma72 {n : ℕ} (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Icc (-1 : ℝ) 1) :
    (∀ i, cmean r i ∈ Icc (-1 : ℝ) 1) ∧ ∑ i, cmean r i = ∑ i, r i ∧
      sublevel (cmean r) ⊆ sublevel r ∧
      ∀ i j, uIcc (cmean r i) (cmean r j) ⊆ sublevel (cmean r) → cmean r i = cmean r j :=
  ⟨cmean_mem_Icc r hr, sum_cmean r, sublevel_cmean_subset r, fun _ _ h => cmean_eq_of_uIcc r h⟩

/-- **Lemma 7.3** (orientation): root sum `≤ 0` ⇒ `(-1, 0) ⊆ S`. -/
theorem lemma73 {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, r i ≤ 0) : Ioo (-1 : ℝ) 0 ⊆ sublevel r :=
  Ioo_subset_sublevel hn r hr hsum

/-! ### Lemma 7.4 (endpoint normalization) -/

theorem sublevel_const {n : ℕ} (hn : 0 < n) (c : ℝ) :
    sublevel (fun _ : Fin n => c) = Ioo (c - 1) (c + 1) := by
  ext x
  simp only [sublevel, Set.mem_ofPred_eq, Finset.prod_const, Finset.card_univ, Fintype.card_fin,
    abs_pow, Set.mem_Ioo]
  rw [pow_lt_one_iff_of_nonneg (abs_nonneg _) hn.ne', abs_sub_lt_iff]
  constructor
  · intro h; constructor <;> linarith [h.1, h.2]
  · intro h; constructor <;> linarith [h.1, h.2]

/-- `(c₀, c₀ + 1) ⊆ S` when `c₀` is the least root and the root sum is `≤ 0` (Lemma 7.3 after
translation by `-c₀ - 1`). -/
theorem Ioo_min_root {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, s i ≤ 0) {c0 : ℝ} (hc0l : -1 ≤ c0) (hcle : ∀ i, c0 ≤ s i) :
    Ioo c0 (c0 + 1) ⊆ sublevel s := by
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have ht : ∀ i, (fun i => s i - (c0 + 1)) i ∈ Icc (-1 : ℝ) 1 := fun i =>
    ⟨by linarith [hcle i], by linarith [(hs i).2]⟩
  have htsum : ∑ i, (fun i => s i - (c0 + 1)) i ≤ 0 := by
    simp only [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul]
    nlinarith
  have h := Ioo_subset_sublevel hn _ ht htsum
  intro x hx
  have hx' : x - (c0 + 1) ∈ Ioo (-1 : ℝ) 0 := ⟨by linarith [hx.1], by linarith [hx.2]⟩
  have := (mem_sublevel_shift s (c0 + 1) (x - (c0 + 1))).mp (h hx')
  rwa [sub_add_cancel] at this

/-- **Lemma 7.4** (endpoint normalization), for an atomized configuration with root sum `≤ 0`:
`c₀ = s i0` is the least root and `r0` the right end of the main component.
* (i) `c₀ ≤ s i` for all `i`, and `-1 ≤ c₀ ≤ m ≤ 0` (`m` the mean);
* (ii) after translating by `-c₀ - 1`: roots in `[-1, 1]`, the main root is `-1`, root sum `≤ 0`,
  and `|S|` unchanged;
* (iii) `β = r0 - c₀ - 1 ≥ 0` is the right end of the main component (translated), the other roots
  lie in `(β, 1]` (translated), and the main multiplicity is at least half (`#others ≤ #main`);
* (iv) if all roots equal `c₀` (`A = 1`), then `|S| = 2`. -/
theorem lemma74 {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, s i ≤ 0) (hcl : ∀ i j, uIcc (s i) (s j) ⊆ sublevel s → s i = s j) :
    ∃ i0 : Fin n, ∃ r0 : ℝ,
      ((∀ i, s i0 ≤ s i) ∧ -1 ≤ s i0 ∧ s i0 ≤ (∑ i, s i) / n ∧ (∑ i, s i) / n ≤ 0) ∧
      ((∀ i, s i - s i0 - 1 ∈ Icc (-1 : ℝ) 1) ∧ s i0 - s i0 - 1 = -1 ∧
        ∑ i, (s i - s i0 - 1) ≤ 0 ∧
        volume (sublevel (fun i => s i - s i0 - 1)) = volume (sublevel s)) ∧
      (0 ≤ r0 - s i0 - 1 ∧ r0 ∉ sublevel s ∧ |∏ i, (r0 - s i)| = 1 ∧
        (∀ y, s i0 ≤ y → y < r0 → y ∈ sublevel s) ∧
        (∀ i, s i ≠ s i0 → r0 - s i0 - 1 < s i - s i0 - 1 ∧ s i - s i0 - 1 ≤ 1) ∧
        (univ.filter (fun i => s i ≠ s i0)).card ≤ (univ.filter (fun i => s i = s i0)).card) ∧
      ((∀ i, s i = s i0) → volume (sublevel s) = ENNReal.ofReal 2) := by
  obtain ⟨i0, r0, hc0l, hc00, hcle, hr0ge, hR1, hf1, hother, hbelow, hab⟩ := setup hn s hs hsum hcl
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  refine ⟨i0, r0, ⟨hcle, hc0l, ?_, div_nonpos_of_nonpos_of_nonneg hsum hnR.le⟩, ⟨?_, by ring, ?_, ?_⟩,
    ⟨by linarith, hR1, hf1, hbelow, ?_, hab⟩, ?_⟩
  · rw [le_div_iff₀ hnR]
    calc s i0 * n = ∑ _i : Fin n, s i0 := by simp [mul_comm]
      _ ≤ ∑ i, s i := Finset.sum_le_sum fun i _ => hcle i
  · intro i
    exact ⟨by linarith [hcle i], by linarith [(hs i).2]⟩
  · simp only [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul]
    nlinarith
  · have e : (fun i => s i - s i0 - 1) = fun i => s i + -(s i0 + 1) := by funext i; ring
    rw [e, volume_sublevel_translate]
  · intro i hi
    exact ⟨by linarith [hother i hi], by linarith [(hs i).2]⟩
  · intro hall
    have e : s = fun _ => s i0 := funext hall
    rw [e, sublevel_const hn, Real.volume_Ioo]
    congr 1
    ring

/-! ### Lemma 7.5 (residual radius; `|S| ≥ 𝒥_k`) -/

/-- `R_v = exp(-(1/m_v) ∑_{t ≠ v} log|v - t|)` (Lemma 7.5 in root form; it equals the normalized
`R_i`, cf. the proof of Corollary 8.2). -/
noncomputable def Rv {n : ℕ} (s : Fin n → ℝ) (v : ℝ) : ℝ :=
  Real.exp (-(∑ j ∈ univ.filter (fun j => s j ≠ v), Real.log |v - s j|) /
    ((univ.filter (fun j => s j = v)).card : ℝ))

/-- The ends of two disjoint components around `c₀ < v` are ordered. -/
theorem comp_order {n : ℕ} {s : Fin n → ℝ} (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (hcl : ∀ i j, uIcc (s i) (s j) ⊆ sublevel s → s i = s j) {i j : Fin n} (hlt : s i < s j) :
    rhoR s (s i) ≤ ellL s (s j) := by
  obtain ⟨hl1, hr1, -⟩ := comp_props hs i
  obtain ⟨hl2, hr2, -⟩ := comp_props hs j
  have hd := comp_disjoint hs hcl i j hlt.ne
  by_contra h
  push Not at h
  set z := max (s i) (ellL s (s j))
  set z' := min (rhoR s (s i)) (s j)
  have hzz : z < z' := lt_min (max_lt hr1 h) (max_lt hlt hl2)
  have hm1 : (z + z') / 2 ∈ Ioo (ellL s (s i)) (rhoR s (s i)) := by
    constructor
    · linarith [le_max_left (s i) (ellL s (s j)), hl1]
    · linarith [min_le_left (rhoR s (s i)) (s j)]
  have hm2 : (z + z') / 2 ∈ Ioo (ellL s (s j)) (rhoR s (s j)) := by
    constructor
    · linarith [le_max_right (s i) (ellL s (s j))]
    · linarith [min_le_right (rhoR s (s i)) (s j)]
  exact Set.disjoint_left.mp hd hm1 hm2

/-- **Lemma 7.5**: with `c₀ = s i0` the least root,
* (a) `(c₀, c₀ + 1)` lies in the main component `(ℓ(c₀), ρ(c₀))`, and every residual component
  `(ℓ(v), ρ(v))` has `ℓ(v) ≥ c₀ + 1`;
* (b) `ρ(v) - ℓ(v) ≥ 2R_v`;
* hence `|S| ≥ 𝒥 := (ρ(c₀) - ℓ(c₀)) + 2 ∑_{v ≠ c₀} R_v` (sum over the distinct residual values). -/
theorem lemma75 {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, s i ≤ 0) (hcl : ∀ i j, uIcc (s i) (s j) ⊆ sublevel s → s i = s j) :
    ∃ i0 : Fin n, (∀ i, s i0 ≤ s i) ∧
      Ioo (s i0) (s i0 + 1) ⊆ Ioo (ellL s (s i0)) (rhoR s (s i0)) ∧
      (∀ i, s i ≠ s i0 → s i0 + 1 ≤ ellL s (s i)) ∧
      (∀ i, 2 * Rv s (s i) ≤ rhoR s (s i) - ellL s (s i)) ∧
      ENNReal.ofReal ((rhoR s (s i0) - ellL s (s i0)) +
        2 * ∑ v ∈ (univ.filter (fun i => s i ≠ s i0)).image s, Rv s v) ≤ volume (sublevel s) := by
  classical
  have hne : (univ : Finset (Fin n)).Nonempty := ⟨⟨0, hn⟩, mem_univ _⟩
  obtain ⟨i0, -, hmin⟩ := (univ : Finset (Fin n)).exists_min_image s hne
  set c0 := s i0 with hc0
  have hcle : ∀ i, c0 ≤ s i := fun i => hmin i (mem_univ i)
  have hc0l : -1 ≤ c0 := (hs i0).1
  have hIoo := Ioo_min_root hn s hs hsum hc0l hcle
  obtain ⟨hl0, hr0, hmain, -, -⟩ := comp_props hs i0
  obtain ⟨hR1, hR2, -⟩ := rhoR_props hs c0 (by linarith [(hs i0).2])
  have hrge : c0 + 1 ≤ rhoR s c0 := by
    by_contra hc
    push Not at hc
    rcases hR2.lt_or_eq with h | h
    · exact hR1 (hIoo ⟨h, hc⟩)
    · rw [← h] at hR1; exact hR1 (root_mem s i0)
  have ha : Ioo c0 (c0 + 1) ⊆ Ioo (ellL s c0) (rhoR s c0) := fun x hx =>
    ⟨by linarith [hx.1], by linarith [hx.2]⟩
  have hres : ∀ i, s i ≠ c0 → c0 + 1 ≤ ellL s (s i) := by
    intro i hi
    have hlt : c0 < s i := lt_of_le_of_ne (hcle i) (Ne.symm hi)
    exact hrge.trans (comp_order hs hcl hlt)
  have hwidth : ∀ i, 2 * Rv s (s i) ≤ rhoR s (s i) - ellL s (s i) := fun i => comp_width hs hcl i
  refine ⟨i0, hcle, ha, hres, hwidth, ?_⟩
  -- the volume of the disjoint union
  set V := (univ.filter (fun i => s i ≠ c0)).image s with hV
  have hVmem : ∀ v ∈ V, ∃ i, s i = v ∧ s i ≠ c0 := by
    intro v hv
    obtain ⟨i, hi, h⟩ := Finset.mem_image.mp hv
    exact ⟨i, h, (Finset.mem_filter.mp hi).2⟩
  set W : ℝ → Set ℝ := fun v => Ioo (ellL s v) (rhoR s v) with hW
  have hWsub : ∀ v ∈ V, W v ⊆ sublevel s := by
    intro v hv
    obtain ⟨i, rfl, -⟩ := hVmem v hv
    exact (comp_props hs i).2.2.1
  have hWdisj : (↑V : Set ℝ).PairwiseDisjoint W := by
    intro v hv w hw hvw
    obtain ⟨i, rfl, -⟩ := hVmem v hv
    obtain ⟨j, rfl, -⟩ := hVmem w hw
    exact comp_disjoint hs hcl i j hvw
  have hmdisj : Disjoint (Ioo (ellL s c0) (rhoR s c0)) (⋃ v ∈ V, W v) := by
    rw [Set.disjoint_iUnion₂_right]
    intro v hv
    obtain ⟨i, rfl, hi⟩ := hVmem v hv
    exact comp_disjoint hs hcl i0 i (Ne.symm hi)
  have hwpos : ∀ v ∈ V, 0 ≤ rhoR s v - ellL s v := by
    intro v hv
    obtain ⟨i, rfl, -⟩ := hVmem v hv
    exact le_trans (by unfold Rv; positivity) (hwidth i)
  have hsubU : Ioo (ellL s c0) (rhoR s c0) ∪ ⋃ v ∈ V, W v ⊆ sublevel s :=
    Set.union_subset hmain (Set.iUnion₂_subset hWsub)
  have hvolU : volume (Ioo (ellL s c0) (rhoR s c0) ∪ ⋃ v ∈ V, W v) =
      ENNReal.ofReal (rhoR s c0 - ellL s c0) + ∑ v ∈ V, ENNReal.ofReal (rhoR s v - ellL s v) := by
    rw [measure_union hmdisj (Finset.measurableSet_biUnion V fun v _ => measurableSet_Ioo),
      Real.volume_Ioo, measure_biUnion_finset hWdisj (fun v _ => measurableSet_Ioo)]
    congr 1
    exact Finset.sum_congr rfl fun v _ => Real.volume_Ioo
  have hsumR : 2 * ∑ v ∈ V, Rv s v ≤ ∑ v ∈ V, (rhoR s v - ellL s v) := by
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun v hv => ?_
    obtain ⟨i, rfl, -⟩ := hVmem v hv
    exact hwidth i
  have hm0 : 0 ≤ rhoR s c0 - ellL s c0 := by linarith
  calc ENNReal.ofReal ((rhoR s c0 - ellL s c0) + 2 * ∑ v ∈ V, Rv s v)
      ≤ ENNReal.ofReal ((rhoR s c0 - ellL s c0) + ∑ v ∈ V, (rhoR s v - ellL s v)) :=
        ENNReal.ofReal_le_ofReal (by linarith)
    _ = volume (Ioo (ellL s c0) (rhoR s c0) ∪ ⋃ v ∈ V, W v) := by
        rw [hvolU, ENNReal.ofReal_add hm0 (Finset.sum_nonneg hwpos),
          ENNReal.ofReal_sum_of_nonneg hwpos]
    _ ≤ volume (sublevel s) := measure_mono hsubU

/-! ### Lemma 7.6 (endpoint window) -/

/-- `g_k(r) = r^k (2 + r)`. -/
noncomputable def gk (k r : ℝ) : ℝ := r ^ k * (2 + r)

theorem gk_strictMonoOn {k : ℝ} (hk : 0 < k) : StrictMonoOn (gk k) (Ici 0) := by
  intro x hx y hy hxy
  have hx' : (0 : ℝ) ≤ x := hx
  have hy' : (0 : ℝ) ≤ y := hy
  unfold gk
  have h1 : x ^ k < y ^ k := Real.rpow_lt_rpow hx' hxy hk
  have hx0 : 0 ≤ x ^ k := Real.rpow_nonneg hx' k
  nlinarith

theorem gk_cont {k : ℝ} (hk : 0 < k) : Continuous (gk k) :=
  (Real.continuous_rpow_const hk.le).mul (continuous_const.add continuous_id)

theorem exists_rho {k : ℝ} (hk : 0 < k) : ∃ r ∈ Ioo (0 : ℝ) 1, gk k r = 1 := by
  have h0 : gk k 0 = 0 := by unfold gk; rw [Real.zero_rpow hk.ne', zero_mul]
  have h1 : gk k 1 = 3 := by unfold gk; rw [Real.one_rpow]; norm_num
  have hI : (1 : ℝ) ∈ Icc (gk k 0) (gk k 1) := by rw [h0, h1]; constructor <;> norm_num
  obtain ⟨r, hr, hr1⟩ := intermediate_value_Icc zero_le_one (gk_cont hk).continuousOn hI
  refine ⟨r, ⟨?_, ?_⟩, hr1⟩
  · rcases hr.1.eq_or_lt with h | h
    · rw [← h, h0] at hr1; norm_num at hr1
    · exact h
  · rcases hr.2.eq_or_lt with h | h
    · rw [h, h1] at hr1; norm_num at hr1
    · exact h

/-- `ρ(k) ∈ (0, 1)`, the solution of `ρ^k (2 + ρ) = 1`. -/
noncomputable def rhoK (k : ℝ) : ℝ := if hk : 0 < k then Classical.choose (exists_rho hk) else 0

theorem rhoK_spec {k : ℝ} (hk : 0 < k) : rhoK k ∈ Ioo (0 : ℝ) 1 ∧ gk k (rhoK k) = 1 := by
  unfold rhoK
  simp only [hk, ↓reduceDIte]
  exact Classical.choose_spec (exists_rho hk)

theorem rhoK_unique {k r : ℝ} (hk : 0 < k) (hr0 : 0 ≤ r) (h : gk k r = 1) : r = rhoK k :=
  (gk_strictMonoOn hk).injOn hr0 (show (0 : ℝ) ≤ rhoK k from (rhoK_spec hk).1.1.le)
    (h.trans (rhoK_spec hk).2.symm)

theorem gk_lt_one {k r : ℝ} (hk : 0 < k) (hr0 : 0 ≤ r) (hr : r < rhoK k) : gk k r < 1 := by
  rw [← (rhoK_spec hk).2]
  exact gk_strictMonoOn hk hr0 (show (0 : ℝ) ≤ rhoK k from (rhoK_spec hk).1.1.le) hr

/-- `ρ(1) = √2 - 1`. -/
theorem rhoK_one : rhoK 1 = √2 - 1 := by
  have h2 : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have h1 : (1 : ℝ) ≤ √2 := by
    rw [show (1 : ℝ) = √1 by simp]; exact Real.sqrt_le_sqrt (by norm_num)
  refine (rhoK_unique one_pos (by linarith) ?_).symm
  unfold gk
  rw [Real.rpow_one]
  linear_combination h2

/-- `ρ` is nondecreasing in `k`. -/
theorem rhoK_mono {k1 k2 : ℝ} (hk1 : 0 < k1) (h12 : k1 ≤ k2) : rhoK k1 ≤ rhoK k2 := by
  have hk2 : 0 < k2 := hk1.trans_le h12
  obtain ⟨⟨h10, h11⟩, hg1⟩ := rhoK_spec hk1
  obtain ⟨⟨h20, -⟩, hg2⟩ := rhoK_spec hk2
  by_contra h
  push Not at h
  have hle : gk k2 (rhoK k1) ≤ gk k1 (rhoK k1) := by
    unfold gk
    exact mul_le_mul_of_nonneg_right (Real.rpow_le_rpow_of_exponent_ge h10 h11.le h12)
      (by linarith)
  have hlt : gk k2 (rhoK k2) < gk k2 (rhoK k1) :=
    gk_strictMonoOn hk2 (show (0 : ℝ) ≤ rhoK k2 from h20.le) (show (0 : ℝ) ≤ rhoK k1 from h10.le) h
  linarith

/-- **Lemma 7.6**: for a configuration with root sum `≤ 0`, least root `c₀` of multiplicity `a`
and `b ≥ 1` other roots, and `k = a/b` (no atomization needed): `(c₀ - ρ(k), c₀ + 1) ⊆ S`, so the
main component `(ℓ(c₀), rhoR(c₀))` has width `M_k ≥ 1 + ρ(k)`. -/
theorem lemma76 {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, s i ≤ 0) {c0 : ℝ} (hc0l : -1 ≤ c0) (hcle : ∀ i, c0 ≤ s i)
    (hb : 1 ≤ (univ.filter (fun i => s i ≠ c0)).card)
    (ha : 1 ≤ (univ.filter (fun i => s i = c0)).card) {k : ℝ}
    (hk : k = ((univ.filter (fun i => s i = c0)).card : ℝ) / (univ.filter (fun i => s i ≠ c0)).card) :
    Ioo (c0 - rhoK k) (c0 + 1) ⊆ sublevel s ∧ 1 + rhoK k ≤ rhoR s c0 - ellL s c0 := by
  classical
  set a := (univ.filter (fun i => s i = c0)).card with haa
  set b := (univ.filter (fun i => s i ≠ c0)).card with hbb
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  have haR : (0 : ℝ) < a := by exact_mod_cast ha
  have hk0 : 0 < k := by rw [hk]; exact div_pos haR hbR
  have hIoo := Ioo_min_root hn s hs hsum hc0l hcle
  have hρ := (rhoK_spec hk0).1
  obtain ⟨i1, hi1⟩ : ∃ i, s i = c0 := by
    obtain ⟨i, hi⟩ := Finset.card_pos.mp (by omega : 0 < a)
    exact ⟨i, (Finset.mem_filter.mp hi).2⟩
  have hsub : Ioo (c0 - rhoK k) (c0 + 1) ⊆ sublevel s := by
    intro x hx
    rcases lt_or_ge x c0 with hlt | hge
    · set u := (c0 - x + rhoK k) / 2 with hu
      have hu0 : 0 < u := by rw [hu]; linarith [hx.1, hlt]
      have hur : u < rhoK k := by rw [hu]; linarith [hx.1]
      have hg := gk_lt_one hk0 hu0.le hur
      have hw : u ^ a * (2 + u) ^ b < 1 := by
        have hpow : (gk k u) ^ b < 1 := pow_lt_one₀ (by unfold gk; positivity) hg (by omega)
        have e : (gk k u) ^ b = u ^ a * (2 + u) ^ b := by
          unfold gk
          rw [mul_pow, ← Real.rpow_mul_natCast hu0.le, hk, div_mul_cancel₀ _ hbR.ne',
            Real.rpow_natCast]
        rwa [e] at hpow
      exact Resid.window s hs hc0l hcle hu0 hw ⟨by linarith [hx.1], hlt⟩
    · rcases hge.lt_or_eq with h | h
      · exact hIoo ⟨h, hx.2⟩
      · rw [← h, ← hi1]
        exact root_mem s i1
  refine ⟨hsub, ?_⟩
  have hL : ellL s c0 ≤ c0 - rhoK k := by
    unfold ellL
    refine csSup_le (compl_left_nonempty hs c0 (by linarith)) fun y hy => ?_
    by_contra hc
    push Not at hc
    exact hy.1 (hsub ⟨hc, by linarith [Set.mem_Iic.mp hy.2]⟩)
  have hR : c0 + 1 ≤ rhoR s c0 := by
    unfold rhoR
    refine le_csInf (compl_right_nonempty hs c0 (by linarith [(hs i1).2, hi1])) fun y hy => ?_
    by_contra hc
    push Not at hc
    have hy2 : c0 ≤ y := hy.2
    exact hy.1 (hsub ⟨by linarith [hρ.1], hc⟩)
  linarith

/-! ### Supplements (Lean RED Review 27) -/

/-- If the segment from `x` to the root `s i` lies in `S`, then `x` is in the component of `s i`. -/
theorem mem_comp_of_uIcc {n : ℕ} (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1) (i : Fin n)
    {x : ℝ} (h : uIcc x (s i) ⊆ sublevel s) : x ∈ Ioo (ellL s (s i)) (rhoR s (s i)) := by
  obtain ⟨hL1, hL2, -⟩ := ellL_props hs (s i) (by linarith [(hs i).1])
  obtain ⟨hR1, hR2, -⟩ := rhoR_props hs (s i) (by linarith [(hs i).2])
  constructor
  · by_contra hc
    push Not at hc
    exact hL1 (h (Set.mem_uIcc.mpr (Or.inl ⟨hc, hL2⟩)))
  · by_contra hc
    push Not at hc
    exact hR1 (h (Set.mem_uIcc.mpr (Or.inr ⟨hR2, hc⟩)))

/-- [M-181]: segment classes = component classes. -/
theorem seg_iff_comp {n : ℕ} (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1) (i j : Fin n) :
    uIcc (s i) (s j) ⊆ sublevel s ↔ s j ∈ Ioo (ellL s (s i)) (rhoR s (s i)) := by
  obtain ⟨hl, hr, hsub, -, -⟩ := comp_props hs i
  constructor
  · intro h
    exact mem_comp_of_uIcc s hs i (by rwa [Set.uIcc_comm])
  · intro h
    exact (ordConnected_Ioo.uIcc_subset ⟨hl, hr⟩ h).trans hsub

/-- **Lemma 7.1**, disjointness: two root components are equal or disjoint. -/
theorem comp_eq_or_disjoint {n : ℕ} (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (i j : Fin n) :
    Ioo (ellL s (s i)) (rhoR s (s i)) = Ioo (ellL s (s j)) (rhoR s (s j)) ∨
      Disjoint (Ioo (ellL s (s i)) (rhoR s (s i))) (Ioo (ellL s (s j)) (rhoR s (s j))) := by
  classical
  by_cases h : uIcc (s i) (s j) ⊆ sublevel s
  · left
    obtain ⟨hli, hri, hsi, -, -⟩ := comp_props hs i
    obtain ⟨hlj, hrj, hsj, -, -⟩ := comp_props hs j
    obtain ⟨hL1i, -, -⟩ := ellL_props hs (s i) (by linarith [(hs i).1])
    obtain ⟨hR1i, -, -⟩ := rhoR_props hs (s i) (by linarith [(hs i).2])
    obtain ⟨hL1j, -, -⟩ := ellL_props hs (s j) (by linarith [(hs j).1])
    obtain ⟨hR1j, -, -⟩ := rhoR_props hs (s j) (by linarith [(hs j).2])
    have hj := (seg_iff_comp s hs i j).mp h
    have hi := (seg_iff_comp s hs j i).mp (by rwa [Set.uIcc_comm])
    have e1 : ellL s (s i) = ellL s (s j) := by
      rcases lt_trichotomy (ellL s (s i)) (ellL s (s j)) with c | c | c
      · exact absurd (hsi ⟨c, by linarith [hj.2, hlj]⟩) hL1j
      · exact c
      · exact absurd (hsj ⟨c, by linarith [hi.2, hli]⟩) hL1i
    have e2 : rhoR s (s i) = rhoR s (s j) := by
      rcases lt_trichotomy (rhoR s (s i)) (rhoR s (s j)) with c | c | c
      · exact absurd (hsj ⟨by linarith [hi.1, hri], c⟩) hR1i
      · exact c
      · exact absurd (hsi ⟨by linarith [hj.1, hrj], c⟩) hR1j
    rw [e1, e2]
  · right
    rw [Set.disjoint_left]
    intro x hxi hxj
    apply h
    obtain ⟨hli, hri, hsi, -, -⟩ := comp_props hs i
    obtain ⟨hlj, hrj, hsj, -, -⟩ := comp_props hs j
    intro y hy
    rw [Set.mem_uIcc] at hy
    rcases hy with ⟨a, b⟩ | ⟨a, b⟩
    · rcases le_total y x with c | c
      · exact hsi ⟨by linarith [hxi.1], by linarith [hxi.2]⟩
      · exact hsj ⟨by linarith [hxj.1], by linarith [hxj.2]⟩
    · rcases le_total y x with c | c
      · exact hsj ⟨by linarith [hxj.1], by linarith [hxj.2]⟩
      · exact hsi ⟨by linarith [hxi.1], by linarith [hxi.2]⟩

/-- Lemma 7.4, the identification of `c`: for root sum `≤ 0`, the least root `c₀ = s i0` is the root
of the component `I₀` containing `(-1, 0)`. -/
theorem main_comp {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1)
    (hsum : ∑ i, s i ≤ 0) {i0 : Fin n} (hmin : ∀ i, s i0 ≤ s i) :
    Ioo (-1 : ℝ) 0 ⊆ Ioo (ellL s (s i0)) (rhoR s (s i0)) := by
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hc0 : s i0 ≤ 0 := by
    have : (n : ℝ) * s i0 ≤ ∑ i, s i := by
      calc (n : ℝ) * s i0 = ∑ _i : Fin n, s i0 := by simp
        _ ≤ ∑ i, s i := Finset.sum_le_sum fun i _ => hmin i
    nlinarith
  have hc1 := (hs i0).1
  have hO := lemma73 hn s hs hsum
  intro x hx
  apply mem_comp_of_uIcc s hs i0
  intro y hy
  by_cases hyc : y = s i0
  · rw [hyc]; exact root_mem s i0
  · apply hO
    rw [Set.mem_uIcc] at hy
    rcases hy with ⟨a, b⟩ | ⟨a, b⟩
    · refine ⟨by linarith [hx.1], lt_of_le_of_ne (by linarith) ?_⟩
      intro e
      exact hyc (le_antisymm (e ▸ b) (by linarith))
    · refine ⟨lt_of_le_of_ne (by linarith) ?_, by linarith [hx.2]⟩
      intro e
      exact hyc (le_antisymm (by linarith) (e ▸ a))

/-- **Lemma 7.6**: `ρ` is strictly increasing. -/
theorem rhoK_strictMono {k1 k2 : ℝ} (hk1 : 0 < k1) (h12 : k1 < k2) : rhoK k1 < rhoK k2 := by
  have hk2 : 0 < k2 := hk1.trans h12
  obtain ⟨⟨h10, h11⟩, -⟩ := rhoK_spec hk1
  obtain ⟨⟨h20, -⟩, -⟩ := rhoK_spec hk2
  have hg1 := (rhoK_spec hk1).2
  have hg2 := (rhoK_spec hk2).2
  by_contra h
  push Not at h
  have hlt : gk k2 (rhoK k1) < gk k1 (rhoK k1) := by
    unfold gk
    exact mul_lt_mul_of_pos_right (Real.rpow_lt_rpow_of_exponent_gt h10 h11 h12) (by linarith)
  have hle : gk k2 (rhoK k2) ≤ gk k2 (rhoK k1) :=
    (gk_strictMonoOn hk2).monotoneOn (show (0 : ℝ) ≤ rhoK k2 from h20.le)
      (show (0 : ℝ) ≤ rhoK k1 from h10.le) h
  linarith

/-- The polynomial–root-vector bridge: every root vector in `[-1, 1]ⁿ` (`n ≥ 1`) gives `f ∈ 𝒫` with
`S_f = sublevel s` (the converse direction is `Polynomial.eval_eq_prod`). -/
theorem bridge_vec {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Icc (-1 : ℝ) 1) :
    let p := polyOf (univ.val.map s)
    p.Monic ∧ 1 ≤ p.natDegree ∧ Multiset.card p.roots = p.natDegree ∧
      (∀ r ∈ p.roots, r ∈ Icc (-1 : ℝ) 1) ∧ {x : ℝ | |p.eval x| < 1} = sublevel s := by
  intro p
  refine ⟨polyOf_monic _, ?_, ?_, ?_, ?_⟩
  · rw [polyOf_natDegree]; simp; omega
  · rw [polyOf_roots, polyOf_natDegree]
  · intro r hr
    rw [polyOf_roots] at hr
    obtain ⟨i, -, rfl⟩ := Multiset.mem_map.mp hr
    exact hs i
  · ext x
    simp only [Set.mem_ofPred_eq, sublevel, p, polyOf]
    rw [abs_eval_prod, abs_prod_eq_multiset, Multiset.map_map]

end EP1038.Stage7
