import LeanProject.DLowerMLogs
import LeanProject.DLowerMNumeric10
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_param_13_point {q : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80)) :
    RB (delta (q)) ((123903846862902537 : ℝ) / 200000000000000000) ((61951923431451269 : ℝ) / 100000000000000000) ∧
    RB (delta1 (q)) ((-963855421686746989 : ℝ) / 500000000000000000) ((-77108433734939759 : ℝ) / 40000000000000000) ∧
    RB (delta2 (q)) ((1858034547829873711 : ℝ) / 1000000000000000000) ((1858034547829873717 : ℝ) / 1000000000000000000) ∧
    RB (aval (q)) ((811318594295554181 : ℝ) / 1000000000000000000) ((162263718859110837 : ℝ) / 200000000000000000) ∧
    RB (aval1 (q)) ((-472647217449235873 : ℝ) / 500000000000000000) ((-945294434898471653 : ℝ) / 1000000000000000000) ∧
    RB (aval2 (q)) ((24943457536423823123 : ℝ) / 1000000000000000000) ((12471728768211918467 : ℝ) / 500000000000000000) ∧
    RB (D0q (q)) ((1858034547829873711 : ℝ) / 1000000000000000000) ((1858034547829873717 : ℝ) / 1000000000000000000) ∧
    RB (d01 (q)) ((-3581753345214214401 : ℝ) / 1000000000000000000) ((-223859584075888399 : ℝ) / 62500000000000000) ∧
    RB (d02 (q)) ((2071375428557617957 : ℝ) / 200000000000000000) ((1294609642848511231 : ℝ) / 125000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1037499999999999999 : ℝ) / 1000000000000000000) ((83 : ℝ) / 80) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-3283414346005771949 : ℝ) / 1000000000000000000) ((-41042679325072149 : ℝ) / 12500000000000000) := rb_log hq (by norm_num) dlower_m_log_624.1 dlower_m_log_625.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((3681397312271631 : ℝ) / 100000000000000000) ((4601746640339539 : ℝ) / 125000000000000000) := rb_log h1 (by norm_num) dlower_m_log_626.1 dlower_m_log_627.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((3681397312271631 : ℝ) / 50000000000000000) ((4601746640339539 : ℝ) / 62500000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((123903846862902537 : ℝ) / 200000000000000000) ((61951923431451269 : ℝ) / 100000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((123903846862902537 : ℝ) / 200000000000000000) ((61951923431451269 : ℝ) / 100000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-963855421686746989 : ℝ) / 500000000000000000) ((-77108433734939759 : ℝ) / 40000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-963855421686746989 : ℝ) / 500000000000000000) ((-77108433734939759 : ℝ) / 40000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((1076406249999999997 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 6400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((1858034547829873711 : ℝ) / 1000000000000000000) ((1858034547829873717 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((1858034547829873711 : ℝ) / 1000000000000000000) ((1858034547829873717 : ℝ) / 1000000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-61951923431451269 : ℝ) / 100000000000000000) ((-123903846862902537 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((41042679325072149 : ℝ) / 12500000000000000) ((3283414346005771949 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-188681405704445819 : ℝ) / 1000000000000000000) ((-37736281140889163 : ℝ) / 200000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((811318594295554181 : ℝ) / 1000000000000000000) ((162263718859110837 : ℝ) / 200000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((811318594295554181 : ℝ) / 1000000000000000000) ((162263718859110837 : ℝ) / 200000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((77108433734939759 : ℝ) / 40000000000000000) ((963855421686746989 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((41042679325072149 : ℝ) / 12500000000000000) ((3283414346005771949 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((587105567629174643 : ℝ) / 1000000000000000000) ((11742111352583493 : ℝ) / 20000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((41042679325072149 : ℝ) / 12500000000000000) ((3283414346005771949 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((431232390702260437 : ℝ) / 40000000000000000) ((10780809767556511117 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((101070091570842287 : ℝ) / 250000000000000000) ((404280366283369167 : ℝ) / 1000000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((1532400002527646303 : ℝ) / 1000000000000000000) ((1532400002527646389 : ℝ) / 1000000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-472647217449235873 : ℝ) / 500000000000000000) ((-945294434898471653 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-472647217449235873 : ℝ) / 500000000000000000) ((-945294434898471653 : ℝ) / 1000000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-1858034547829873717 : ℝ) / 1000000000000000000) ((-1858034547829873711 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((41042679325072149 : ℝ) / 12500000000000000) ((3283414346005771949 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-113176976892371017 : ℝ) / 200000000000000000) ((-565884884461855077 : ℝ) / 1000000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-963855421686746989 : ℝ) / 250000000000000000) ((-77108433734939759 : ℝ) / 20000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((41042679325072149 : ℝ) / 12500000000000000) ((3283414346005771949 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((431232390702260437 : ℝ) / 40000000000000000) ((10780809767556511117 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((101070091570842287 : ℝ) / 250000000000000000) ((404280366283369167 : ℝ) / 1000000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-1192063110246564847 : ℝ) / 125000000000000000) ((-1192063110246564789 : ℝ) / 125000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((8970619997510663227 : ℝ) / 1000000000000000000) ((8970619997510663699 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-1283414346005771949 : ℝ) / 1000000000000000000) ((-16042679325072149 : ℝ) / 12500000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-24846871029554903 : ℝ) / 31250000000000000) ((-795099872945756871 : ℝ) / 1000000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((41042679325072149 : ℝ) / 12500000000000000) ((3283414346005771949 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((431232390702260437 : ℝ) / 40000000000000000) ((10780809767556511117 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((3790128433906583 : ℝ) / 250000000000000000) ((1895064216953293 : ℝ) / 125000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-9955649658474619 : ℝ) / 200000000000000000) ((-9955649658474611 : ℝ) / 200000000000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((795099872945756871 : ℝ) / 1000000000000000000) ((24846871029554903 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((9955649658474611 : ℝ) / 200000000000000000) ((9955649658474619 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((1996604692364144987 : ℝ) / 125000000000000000) ((3194567507782634647 : ℝ) / 200000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((24943457536423823123 : ℝ) / 1000000000000000000) ((12471728768211918467 : ℝ) / 500000000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((24943457536423823123 : ℝ) / 1000000000000000000) ((12471728768211918467 : ℝ) / 500000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((1076406249999999997 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 6400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((1858034547829873711 : ℝ) / 1000000000000000000) ((1858034547829873717 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((1858034547829873711 : ℝ) / 1000000000000000000) ((1858034547829873717 : ℝ) / 1000000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((1076406249999999997 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 6400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((223354296874999999 : ℝ) / 200000000000000000) ((571787 : ℝ) / 512000) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-3581753345214214401 : ℝ) / 1000000000000000000) ((-223859584075888399 : ℝ) / 62500000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-3581753345214214401 : ℝ) / 1000000000000000000) ((-223859584075888399 : ℝ) / 62500000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((1076406249999999997 : ℝ) / 1000000000000000000) ((6889 : ℝ) / 6400) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((1158650415039062493 : ℝ) / 1000000000000000000) ((47458321 : ℝ) / 40960000) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((2071375428557617957 : ℝ) / 200000000000000000) ((1294609642848511231 : ℝ) / 125000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((2071375428557617957 : ℝ) / 200000000000000000) ((1294609642848511231 : ℝ) / 125000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_param_13_slab {q : ℝ} (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25)) :
    RB (delta (q)) ((122941150850676543 : ℝ) / 200000000000000000) ((15608608178132013 : ℝ) / 25000000000000000) ∧
    RB (delta1 (q)) ((-1932367149758454109 : ℝ) / 1000000000000000000) ((-480769230769230769 : ℝ) / 250000000000000000) ∧
    RB (delta2 (q)) ((924556213017751479 : ℝ) / 500000000000000000) ((933510700366402953 : ℝ) / 500000000000000000) ∧
    RB (aval (q)) ((806036529181474479 : ℝ) / 1000000000000000000) ((408318752112530767 : ℝ) / 500000000000000000) ∧
    RB (aval1 (q)) ((-574010269350148571 : ℝ) / 500000000000000000) ((-383535327056802703 : ℝ) / 500000000000000000) ∧
    RB (aval2 (q)) ((4080927445429571299 : ℝ) / 200000000000000000) ((480826293776854091 : ℝ) / 15625000000000000) ∧
    RB (D0q (q)) ((924556213017751479 : ℝ) / 500000000000000000) ((933510700366402953 : ℝ) / 500000000000000000) ∧
    RB (d01 (q)) ((-450971352834011089 : ℝ) / 125000000000000000) ((-711197086936731907 : ℝ) / 200000000000000000) ∧
    RB (d02 (q)) ((10257650292356710199 : ℝ) / 1000000000000000000) ((1307163341547858231 : ℝ) / 125000000000000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1034999999999999999 : ℝ) / 1000000000000000000) ((26 : ℝ) / 25) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (q)
  have h2 : RB z2 ((-1676203608746361701 : ℝ) / 500000000000000000) ((-3218875824868200749 : ℝ) / 1000000000000000000) := rb_log hq (by norm_num) dlower_m_log_628.1 dlower_m_log_629.2
  let z3 : ℝ := Real.log (z1)
  have h3 : RB z3 ((6880285343466479 : ℝ) / 200000000000000000) ((39220713153281297 : ℝ) / 1000000000000000000) := rb_log h1 (by norm_num) dlower_m_log_630.1 dlower_m_log_631.2
  let z4 : ℝ := ((2 : ℝ)) * (z3)
  have h4 : RB z4 ((6880285343466479 : ℝ) / 100000000000000000) ((39220713153281297 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (Real.log 2) - (z4)
  have h5 : RB z5 ((122941150850676543 : ℝ) / 200000000000000000) ((15608608178132013 : ℝ) / 25000000000000000) := rb_widen (rb_sub witness_log_two h4) (by norm_num) (by norm_num)
  have bound_dl_5 : RB (delta (q)) ((122941150850676543 : ℝ) / 200000000000000000) ((15608608178132013 : ℝ) / 25000000000000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, delta] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z6 : ℝ := ((-2 : ℝ)) / (z1)
  have h6 : RB z6 ((-1932367149758454109 : ℝ) / 1000000000000000000) ((-480769230769230769 : ℝ) / 250000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl1_6 : RB (delta1 (q)) ((-1932367149758454109 : ℝ) / 1000000000000000000) ((-480769230769230769 : ℝ) / 250000000000000000) := by
    have hh := h6
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, delta1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z7 : ℝ := (z1) ^ 2
  have h7 : RB z7 ((1071224999999999997 : ℝ) / 1000000000000000000) ((676 : ℝ) / 625) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) / (z7)
  have h8 : RB z8 ((924556213017751479 : ℝ) / 500000000000000000) ((933510700366402953 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_dl2_8 : RB (delta2 (q)) ((924556213017751479 : ℝ) / 500000000000000000) ((933510700366402953 : ℝ) / 500000000000000000) := by
    have hh := h8
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, delta2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z9 : ℝ := ((0 : ℝ)) - (delta (q))
  have h9 : RB z9 ((-15608608178132013 : ℝ) / 25000000000000000) ((-122941150850676543 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl_5) (by norm_num) (by norm_num)
  let z10 : ℝ := ((0 : ℝ)) - (z2)
  have h10 : RB z10 ((3218875824868200749 : ℝ) / 1000000000000000000) ((1676203608746361701 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z11 : ℝ := (z9) / (z10)
  have h11 : RB z11 ((-193963470818525521 : ℝ) / 1000000000000000000) ((-91681247887469233 : ℝ) / 500000000000000000) := rb_div_signed h9 h10 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((1 : ℝ)) + (z11)
  have h12 : RB z12 ((806036529181474479 : ℝ) / 1000000000000000000) ((408318752112530767 : ℝ) / 500000000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h11) (by norm_num) (by norm_num)
  have bound_A_12 : RB (aval (q)) ((806036529181474479 : ℝ) / 1000000000000000000) ((408318752112530767 : ℝ) / 500000000000000000) := by
    have hh := h12
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, aval] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z13 : ℝ := ((0 : ℝ)) - (delta1 (q))
  have h13 : RB z13 ((480769230769230769 : ℝ) / 250000000000000000) ((1932367149758454109 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6) (by norm_num) (by norm_num)
  let z14 : ℝ := ((0 : ℝ)) - (z2)
  have h14 : RB z14 ((3218875824868200749 : ℝ) / 1000000000000000000) ((1676203608746361701 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) / (z14)
  have h15 : RB z15 ((143410152639153333 : ℝ) / 250000000000000000) ((30016180413507817 : ℝ) / 50000000000000000) := rb_div_signed h13 h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := ((0 : ℝ)) - (z2)
  have h16 : RB z16 ((3218875824868200749 : ℝ) / 1000000000000000000) ((1676203608746361701 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) ^ 2
  have h17 : RB z17 ((10361161575920939779 : ℝ) / 1000000000000000000) ((11238634151897304067 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h16 (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (q) * (z17)
  have h18 : RB z18 ((362640655157232881 : ℝ) / 1000000000000000000) ((449545366075892163 : ℝ) / 1000000000000000000) := rb_mul_four hq h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (delta (q)) / (z18)
  have h19 : RB z19 ((683697131191880873 : ℝ) / 500000000000000000) ((860830574628455237 : ℝ) / 500000000000000000) := rb_div_signed bound_dl_5 h18 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := (z15) - (z19)
  have h20 : RB z20 ((-574010269350148571 : ℝ) / 500000000000000000) ((-383535327056802703 : ℝ) / 500000000000000000) := rb_widen (rb_sub h15 h19) (by norm_num) (by norm_num)
  have bound_A1_20 : RB (aval1 (q)) ((-574010269350148571 : ℝ) / 500000000000000000) ((-383535327056802703 : ℝ) / 500000000000000000) := by
    have hh := h20
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, aval1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z21 : ℝ := ((0 : ℝ)) - (delta2 (q))
  have h21 : RB z21 ((-933510700366402953 : ℝ) / 500000000000000000) ((-924556213017751479 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl2_8) (by norm_num) (by norm_num)
  let z22 : ℝ := ((0 : ℝ)) - (z2)
  have h22 : RB z22 ((3218875824868200749 : ℝ) / 1000000000000000000) ((1676203608746361701 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((-580022809922856369 : ℝ) / 1000000000000000000) ((-275788755075294871 : ℝ) / 500000000000000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((2 : ℝ)) * (delta1 (q))
  have h24 : RB z24 ((-1932367149758454109 : ℝ) / 500000000000000000) ((-480769230769230769 : ℝ) / 125000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_dl1_6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := ((0 : ℝ)) - (z2)
  have h25 : RB z25 ((3218875824868200749 : ℝ) / 1000000000000000000) ((1676203608746361701 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((10361161575920939779 : ℝ) / 1000000000000000000) ((11238634151897304067 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (q) * (z26)
  have h27 : RB z27 ((362640655157232881 : ℝ) / 1000000000000000000) ((449545366075892163 : ℝ) / 1000000000000000000) := rb_mul_four hq h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z24) / (z27)
  have h28 : RB z28 ((-5328600426558966237 : ℝ) / 500000000000000000) ((-8555652302073867207 : ℝ) / 1000000000000000000) := rb_div_signed h24 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z23) - (z28)
  have h29 : RB z29 ((3987814746075505419 : ℝ) / 500000000000000000) ((2526405835741835683 : ℝ) / 250000000000000000) := rb_widen (rb_sub h23 h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z2) + ((2 : ℝ))
  have h30 : RB z30 ((-676203608746361701 : ℝ) / 500000000000000000) ((-1218875824868200749 : ℝ) / 1000000000000000000) := rb_widen (rb_add h2 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z31 : ℝ := (delta (q)) * (z30)
  have h31 : RB z31 ((-8443677742048673 : ℝ) / 10000000000000000) ((-749249983266821357 : ℝ) / 1000000000000000000) := rb_mul_four bound_dl_5 h30 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z32 : ℝ := (q) ^ 2
  have h32 : RB z32 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := ((0 : ℝ)) - (z2)
  have h33 : RB z33 ((3218875824868200749 : ℝ) / 1000000000000000000) ((1676203608746361701 : ℝ) / 500000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z34 : ℝ := (z33) ^ 2
  have h34 : RB z34 ((10361161575920939779 : ℝ) / 1000000000000000000) ((11238634151897304067 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h33 (by norm_num)) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) * (z34)
  have h35 : RB z35 ((634621146525157 : ℝ) / 50000000000000000) ((17981814643035687 : ℝ) / 1000000000000000000) := rb_mul_four h32 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := (z35) * (z2)
  have h36 : RB z36 ((-60282365192929177 : ℝ) / 1000000000000000000) ((-15959114582031 : ℝ) / 390625000000000) := rb_mul_four h35 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - (z31)
  have h37 : RB z37 ((749249983266821357 : ℝ) / 1000000000000000000) ((8443677742048673 : ℝ) / 10000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h31) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z36)
  have h38 : RB z38 ((15959114582031 : ℝ) / 390625000000000) ((60282365192929177 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h36) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((12429007734996845657 : ℝ) / 1000000000000000000) ((5166814864687829773 : ℝ) / 250000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z29) + (z39)
  have h40 : RB z40 ((4080927445429571299 : ℝ) / 200000000000000000) ((480826293776854091 : ℝ) / 15625000000000000) := rb_widen (rb_add h29 h39) (by norm_num) (by norm_num)
  have bound_A2_40 : RB (aval2 (q)) ((4080927445429571299 : ℝ) / 200000000000000000) ((480826293776854091 : ℝ) / 15625000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, aval2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (z1) ^ 2
  have h41 : RB z41 ((1071224999999999997 : ℝ) / 1000000000000000000) ((676 : ℝ) / 625) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) / (z41)
  have h42 : RB z42 ((924556213017751479 : ℝ) / 500000000000000000) ((933510700366402953 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h41 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D0_42 : RB (D0q (q)) ((924556213017751479 : ℝ) / 500000000000000000) ((933510700366402953 : ℝ) / 500000000000000000) := by
    have hh := h42
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, D0q] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z43 : ℝ := (z1) ^ 2
  have h43 : RB z43 ((1071224999999999997 : ℝ) / 1000000000000000000) ((676 : ℝ) / 625) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) * (z1)
  have h44 : RB z44 ((221743574999999999 : ℝ) / 200000000000000000) ((17576 : ℝ) / 15625) := rb_mul_four h43 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := ((-4 : ℝ)) / (z44)
  have h45 : RB z45 ((-450971352834011089 : ℝ) / 125000000000000000) ((-711197086936731907 : ℝ) / 200000000000000000) := rb_div_signed (show RB (-4 : ℝ) (-4 : ℝ) (-4 : ℝ) from ⟨le_rfl, le_rfl⟩) h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D01_45 : RB (d01 (q)) ((-450971352834011089 : ℝ) / 125000000000000000) ((-711197086936731907 : ℝ) / 200000000000000000) := by
    have hh := h45
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, d01] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z46 : ℝ := (z1) ^ 2
  have h46 : RB z46 ((1071224999999999997 : ℝ) / 1000000000000000000) ((676 : ℝ) / 625) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z46) ^ 2
  have h47 : RB z47 ((1147523000624999993 : ℝ) / 1000000000000000000) ((456976 : ℝ) / 390625) := rb_widen (rb_sq h46 (by norm_num)) (by norm_num) (by norm_num)
  let z48 : ℝ := ((12 : ℝ)) / (z47)
  have h48 : RB z48 ((10257650292356710199 : ℝ) / 1000000000000000000) ((1307163341547858231 : ℝ) / 125000000000000000) := rb_div_signed (show RB (12 : ℝ) (12 : ℝ) (12 : ℝ) from ⟨le_rfl, le_rfl⟩) h47 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_D02_48 : RB (d02 (q)) ((10257650292356710199 : ℝ) / 1000000000000000000) ((1307163341547858231 : ℝ) / 125000000000000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, d02] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_dl_5, bound_dl1_6, bound_dl2_8, bound_A_12, bound_A1_20, bound_A2_40, bound_D0_42, bound_D01_45, bound_D02_48⟩

theorem dlower_m_13_point_plus_branch {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((436858947545871 : ℝ) / 1000000000000000) ((218429473772937 : ℝ) / 500000000000000)) :
    RB (phi q (v)) ((220038974972235453 : ℝ) / 500000000000000000) ((440077949944473931 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((-226876392566740743 : ℝ) / 125000000000000000) ((-1815011140533841291 : ℝ) / 1000000000000000000) ∧
    RB (psi2 q (v)) ((-1975681397296401111 : ℝ) / 200000000000000000) ((-2469601746619624077 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((435452697545871 : ℝ) / 1000000000000000) ((435452697545874001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((281570526227063 : ℝ) / 500000000000000) ((563141052454129 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-83136910501616239 : ℝ) / 100000000000000000) ((-831369105016155497 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_632.1 dlower_m_log_633.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-28711257250147919 : ℝ) / 50000000000000000) ((-574225145002953051 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_634.1 dlower_m_log_635.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-257143960013209339 : ℝ) / 1000000000000000000) ((-257143960013197117 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-52156419042377299 : ℝ) / 250000000000000000) ((-104312838084749639 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-414072455242010203 : ℝ) / 500000000000000000) ((-828144910484013537 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_636.1 dlower_m_log_637.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((619519234314504341 : ℝ) / 1000000000000000000) ((77439904289315141 : ℝ) / 125000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-8349 : ℝ) / 1000000000000000000) ((8443 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-8349 : ℝ) / 1000000000000000000) ((8443 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((6076918859205759 : ℝ) / 25000000000000000) ((121538377184120969 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-86117275679638463 : ℝ) / 500000000000000000) ((-86117275679637867 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-139737094097933987 : ℝ) / 1000000000000000000) ((-139737094097933019 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((103339660270296373 : ℝ) / 1000000000000000000) ((103339660270308919 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((507762625910947587 : ℝ) / 250000000000000000) ((2031050503643802897 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((507762625910947587 : ℝ) / 250000000000000000) ((2031050503643802897 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((2296460684790343181 : ℝ) / 1000000000000000000) ((71764396399698719 : ℝ) / 31250000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((1775754041801908259 : ℝ) / 1000000000000000000) ((44393851045047943 : ℝ) / 25000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((50902684082403143 : ℝ) / 12500000000000000) ((509026840824034591 : ℝ) / 125000000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((3303863527648479937 : ℝ) / 1000000000000000000) ((3303863527648500471 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((2289068372337712683 : ℝ) / 1000000000000000000) ((572267093084432101 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((1014795155310751533 : ℝ) / 1000000000000000000) ((253698788827696947 : ℝ) / 250000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((1014795155310751533 : ℝ) / 1000000000000000000) ((253698788827696947 : ℝ) / 250000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((31712784495914069 : ℝ) / 100000000000000000) ((31712784495914407 : ℝ) / 100000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((3153302416975813343 : ℝ) / 1000000000000000000) ((3153302416975846953 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((189619051799975807 : ℝ) / 1000000000000000000) ((94809525899989211 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((65921645959846649 : ℝ) / 12500000000000000) ((105474633535756093 : ℝ) / 20000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-2120429259811991307 : ℝ) / 1000000000000000000) ((-2120429259811884967 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-860171843186913617 : ℝ) / 500000000000000000) ((-1720343686373740949 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((190845740050886069 : ℝ) / 1000000000000000000) ((190845740050888691 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((1309958503309206307 : ℝ) / 250000000000000000) ((2619917006618448609 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((1759745163431498997 : ℝ) / 500000000000000000) ((3519490326863156269 : ℝ) / 1000000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((1759745163431498997 : ℝ) / 500000000000000000) ((3519490326863156269 : ℝ) / 1000000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((2296460684790343181 : ℝ) / 1000000000000000000) ((71764396399698719 : ℝ) / 31250000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((1775754041801908259 : ℝ) / 1000000000000000000) ((44393851045047943 : ℝ) / 25000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((50902684082403143 : ℝ) / 12500000000000000) ((509026840824034591 : ℝ) / 125000000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-1924720959379640427 : ℝ) / 500000000000000000) ((-384944191875925657 : ℝ) / 100000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((37499999999999999 : ℝ) / 500000000000000000) ((3 : ℝ) / 40) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((189619051799975807 : ℝ) / 1000000000000000000) ((94809525899989211 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((395529875759079883 : ℝ) / 1000000000000000000) ((395529875759085349 : ℝ) / 1000000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((320900742802751881 : ℝ) / 1000000000000000000) ((320900742802756319 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-3528541175956528973 : ℝ) / 1000000000000000000) ((-3528541175956500251 : ℝ) / 1000000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-3528541175956528973 : ℝ) / 1000000000000000000) ((-3528541175956500251 : ℝ) / 1000000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-1282811889467471251 : ℝ) / 200000000000000000) ((-6414059447337047843 : ℝ) / 1000000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-472647217449235873 : ℝ) / 250000000000000000) ((-945294434898471653 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-86117275679638463 : ℝ) / 500000000000000000) ((-86117275679637867 : ℝ) / 500000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((65124945158863339 : ℝ) / 200000000000000000) ((325624725794318981 : ℝ) / 1000000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-152210868038575989 : ℝ) / 25000000000000000) ((-3044217360771364431 : ℝ) / 500000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-71764396399698719 : ℝ) / 15625000000000000) ((-2296460684790343181 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((1406249999999999 : ℝ) / 250000000000000000) ((9 : ℝ) / 1600) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((189619051799975807 : ℝ) / 1000000000000000000) ((94809525899989211 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((2966474068193097 : ℝ) / 100000000000000000) ((14832370340965701 : ℝ) / 500000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-2311293055131324709 : ℝ) / 500000000000000000) ((-1155646527565654333 : ℝ) / 250000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-3750390064988446367 : ℝ) / 1000000000000000000) ((-937597516247105079 : ℝ) / 250000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-9838824786531485927 : ℝ) / 1000000000000000000) ((-4919412393265574589 : ℝ) / 500000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-2924214833590339911 : ℝ) / 250000000000000000) ((-11696859334361022889 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-2924214833590339911 : ℝ) / 250000000000000000) ((-11696859334361022889 : ℝ) / 1000000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-2031050503643802897 : ℝ) / 1000000000000000000) ((-507762625910947587 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-2001438904211020489 : ℝ) / 1000000000000000000) ((-1000719452105468309 : ℝ) / 500000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-2001438904211020489 : ℝ) / 1000000000000000000) ((-1000719452105468309 : ℝ) / 500000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((1000719452105468309 : ℝ) / 500000000000000000) ((2001438904211020489 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((4005757687289074723 : ℝ) / 1000000000000000000) ((4005757687289410449 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((14098225432170992501 : ℝ) / 1000000000000000000) ((7049112716086404049 : ℝ) / 500000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-3528541175956528973 : ℝ) / 500000000000000000) ((-3528541175956500251 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((1765539896167386889 : ℝ) / 125000000000000000) ((882769948083737623 : ℝ) / 62500000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((28222544601510087613 : ℝ) / 1000000000000000000) ((14111272300756305033 : ℝ) / 500000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((16525685267148727969 : ℝ) / 1000000000000000000) ((16525685267151587177 : ℝ) / 1000000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-16525685267151587177 : ℝ) / 1000000000000000000) ((-16525685267148727969 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-8142374931860546867 : ℝ) / 500000000000000000) ((-3256949972743538883 : ℝ) / 200000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-8142374931860546867 : ℝ) / 500000000000000000) ((-3256949972743538883 : ℝ) / 200000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((1609501199299953 : ℝ) / 500000000000000000) ((3219002398599931 : ℝ) / 1000000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((220038974972235453 : ℝ) / 500000000000000000) ((440077949944473931 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((220038974972235453 : ℝ) / 500000000000000000) ((440077949944473931 : ℝ) / 1000000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((190845740050886069 : ℝ) / 1000000000000000000) ((190845740050888691 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((184212914527857 : ℝ) / 25000000000000000) ((7368516581114387 : ℝ) / 1000000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((992631483418885613 : ℝ) / 1000000000000000000) ((24815787085472143 : ℝ) / 25000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-198669126845925439 : ℝ) / 100000000000000000) ((-993345634229585461 : ℝ) / 500000000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((37499999999999999 : ℝ) / 500000000000000000) ((3 : ℝ) / 40) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((85840063962664223 : ℝ) / 500000000000000000) ((171680127925329631 : ℝ) / 1000000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-226876392566740743 : ℝ) / 125000000000000000) ((-1815011140533841291 : ℝ) / 1000000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-226876392566740743 : ℝ) / 125000000000000000) ((-1815011140533841291 : ℝ) / 1000000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((1406249999999999 : ℝ) / 500000000000000000) ((9 : ℝ) / 3200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((190845740050886069 : ℝ) / 1000000000000000000) ((190845740050888691 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((83372669142242969 : ℝ) / 1000000000000000000) ((5210791821390293 : ℝ) / 62500000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((1349363060549977 : ℝ) / 40000000000000000) ((16867038256875073 : ℝ) / 500000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((1000719452105468309 : ℝ) / 500000000000000000) ((2001438904211020489 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((4005757687289074723 : ℝ) / 1000000000000000000) ((4005757687289410449 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((135130536318549589 : ℝ) / 1000000000000000000) ((135130536318563803 : ℝ) / 1000000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((37499999999999999 : ℝ) / 250000000000000000) ((3 : ℝ) / 20) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((190845740050886069 : ℝ) / 1000000000000000000) ((190845740050888691 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((785975101985523763 : ℝ) / 1000000000000000000) ((785975101985534583 : ℝ) / 1000000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-1573081146855073411 : ℝ) / 1000000000000000000) ((-1573081146854985833 : ℝ) / 1000000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((854105841586767711 : ℝ) / 500000000000000000) ((854105841586818607 : ℝ) / 500000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((4578136744675425367 : ℝ) / 1000000000000000000) ((4578136744675456807 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((6286348427848960789 : ℝ) / 1000000000000000000) ((6286348427849094021 : ℝ) / 1000000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((190845740050886069 : ℝ) / 1000000000000000000) ((190845740050888691 : ℝ) / 1000000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((184212914527857 : ℝ) / 25000000000000000) ((7368516581114387 : ℝ) / 1000000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((992631483418885613 : ℝ) / 1000000000000000000) ((24815787085472143 : ℝ) / 25000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-2020594426791370793 : ℝ) / 125000000000000000) ((-16164755414327590329 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-1975681397296401111 : ℝ) / 200000000000000000) ((-2469601746619624077 : ℝ) / 250000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-1975681397296401111 : ℝ) / 200000000000000000) ((-2469601746619624077 : ℝ) / 250000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_13_point_plus_lo_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((436858947545871 : ℝ) / 1000000000000000) ((436858947545871 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-741 : ℝ) / 500000000000000000) ((-367 : ℝ) / 250000000000000000) ∧
    RB (Eq q (v)) ((406210100728760379 : ℝ) / 200000000000000000) ((406210100728760387 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((435452697545871 : ℝ) / 1000000000000000) ((435452697545871001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((563141052454129 : ℝ) / 1000000000000000) ((563141052454129 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-83136910501616239 : ℝ) / 100000000000000000) ((-415684552508081193 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_632.1 dlower_m_log_638.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-574225145002953053 : ℝ) / 1000000000000000000) ((-574225145002953051 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_635.1 dlower_m_log_635.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-257143960013209339 : ℝ) / 1000000000000000000) ((-257143960013209333 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-52156419042377299 : ℝ) / 250000000000000000) ((-208625676169509189 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-414072455242010203 : ℝ) / 500000000000000000) ((-207036227621005101 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_636.1 dlower_m_log_636.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((77439904289313901 : ℝ) / 125000000000000000) ((619519234314511217 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-741 : ℝ) / 500000000000000000) ((-367 : ℝ) / 250000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-741 : ℝ) / 500000000000000000) ((-367 : ℝ) / 250000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((243076754368241907 : ℝ) / 1000000000000000000) ((121538377184120969 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-86117275679638463 : ℝ) / 500000000000000000) ((-4305863783981923 : ℝ) / 25000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-139737094097933987 : ℝ) / 1000000000000000000) ((-139737094097933981 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((1291745753378849 : ℝ) / 12500000000000000) ((103339660270307957 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((406210100728760379 : ℝ) / 200000000000000000) ((406210100728760387 : ℝ) / 200000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((406210100728760379 : ℝ) / 200000000000000000) ((406210100728760387 : ℝ) / 200000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_13_point_plus_hi_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((218429473772937 : ℝ) / 500000000000000) ((218429473772937 : ℝ) / 500000000000000)) :
    RB (E q (v)) ((781 : ℝ) / 500000000000000000) ((197 : ℝ) / 125000000000000000) ∧
    RB (Eq q (v)) ((2031050503643791311 : ℝ) / 1000000000000000000) ((2031050503643791349 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((217726348772937 : ℝ) / 500000000000000) ((435452697545874001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((281570526227063 : ℝ) / 500000000000000) ((281570526227063 : ℝ) / 500000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-831369105016155501 : ℝ) / 1000000000000000000) ((-831369105016155497 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_639.1 dlower_m_log_633.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-28711257250147919 : ℝ) / 50000000000000000) ((-287112572501479189 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_634.1 dlower_m_log_634.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-257143960013197123 : ℝ) / 1000000000000000000) ((-257143960013197117 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-41725135233899857 : ℝ) / 200000000000000000) ((-104312838084749639 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-828144910484013539 : ℝ) / 1000000000000000000) ((-828144910484013537 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_637.1 dlower_m_log_637.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((154879808578628563 : ℝ) / 250000000000000000) ((619519234314514261 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((781 : ℝ) / 500000000000000000) ((197 : ℝ) / 125000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((781 : ℝ) / 500000000000000000) ((197 : ℝ) / 125000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((6076918859205759 : ℝ) / 25000000000000000) ((24307675436823039 : ℝ) / 100000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-172234551359275739 : ℝ) / 1000000000000000000) ((-86117275679637867 : ℝ) / 500000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-4366784190560407 : ℝ) / 31250000000000000) ((-139737094097933019 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((12917457533787167 : ℝ) / 125000000000000000) ((103339660270297371 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2031050503643791311 : ℝ) / 1000000000000000000) ((2031050503643791349 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2031050503643791311 : ℝ) / 1000000000000000000) ((2031050503643791349 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_13_point_minus_branch {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((142847873306067 : ℝ) / 100000000000000) ((1428478733060673 : ℝ) / 1000000000000000)) :
    RB (phi q (v)) ((714731585968907583 : ℝ) / 500000000000000000) ((142946317193781817 : ℝ) / 100000000000000000) ∧
    RB (psi1 q (v)) ((210753232739481083 : ℝ) / 500000000000000000) ((421506465478969537 : ℝ) / 1000000000000000000) ∧
    RB (psi2 q (v)) ((15629683025237328903 : ℝ) / 1000000000000000000) ((15629683025237600237 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((142707248306067 : ℝ) / 100000000000000) ((1427072483060673001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-428478733060673 : ℝ) / 1000000000000000) ((-42847873306067 : ℝ) / 100000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((44453141402576687 : ℝ) / 125000000000000000) ((355625131220615601 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_640.1 dlower_m_log_641.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((42847873306067 : ℝ) / 100000000000000) ((428478733060673 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-211878543326564897 : ℝ) / 250000000000000000) ((-169502834661250517 : ℝ) / 200000000000000000) := rb_log h5 (by norm_num) dlower_m_log_642.1 dlower_m_log_643.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1203139304526866081 : ℝ) / 1000000000000000000) ((1203139304526875189 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((39045171571618707 : ℝ) / 40000000000000000) ((976129289290475071 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((356610054975958169 : ℝ) / 1000000000000000000) ((356610054975960271 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_644.1 dlower_m_log_645.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((154879808578626851 : ℝ) / 250000000000000000) ((309759617157258451 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-2643 : ℝ) / 500000000000000000) ((4217 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-2643 : ℝ) / 500000000000000000) ((4217 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-142165111122109099 : ℝ) / 125000000000000000) ((-1137320888976864069 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-26277572054064853 : ℝ) / 500000000000000000) ((-52555144108129593 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-4263896564080807 : ℝ) / 100000000000000000) ((-42638965640807977 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-589979927308840431 : ℝ) / 500000000000000000) ((-589979927308836023 : ℝ) / 500000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((747750988755813113 : ℝ) / 1000000000000000000) ((186937747188955483 : ℝ) / 250000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((747750988755813113 : ℝ) / 1000000000000000000) ((186937747188955483 : ℝ) / 250000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((700735254775061267 : ℝ) / 1000000000000000000) ((700735254775062741 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((42847873306067 : ℝ) / 100000000000000) ((428478733060673 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-2333838118071559089 : ℝ) / 1000000000000000000) ((-2333838118071542747 : ℝ) / 1000000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-816551431648248911 : ℝ) / 500000000000000000) ((-816551431648240003 : ℝ) / 500000000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-331241679847439801 : ℝ) / 250000000000000000) ((-662483359694872371 : ℝ) / 500000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((700045423747674473 : ℝ) / 1000000000000000000) ((87505677968459493 : ℝ) / 125000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-506253035784358787 : ℝ) / 250000000000000000) ((-405002428627483843 : ℝ) / 200000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-506253035784358787 : ℝ) / 250000000000000000) ((-405002428627483843 : ℝ) / 200000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((42847873306067 : ℝ) / 100000000000000) ((428478733060673 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((91797012342638449 : ℝ) / 500000000000000000) ((18359402468527947 : ℝ) / 100000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((5446800361363720287 : ℝ) / 1000000000000000000) ((5446800361363796593 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((254566983988618283 : ℝ) / 125000000000000000) ((203653587190895483 : ℝ) / 100000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((61378737160583753 : ℝ) / 125000000000000000) ((49102989728467209 : ℝ) / 100000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((4955770464079048197 : ℝ) / 1000000000000000000) ((4955770464079126569 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((251294295410502473 : ℝ) / 62500000000000000) ((2010354363284051587 : ℝ) / 500000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((1020275745403308449 : ℝ) / 500000000000000000) ((204055149080662547 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((98012719062012223 : ℝ) / 200000000000000000) ((19602543812402527 : ℝ) / 40000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((4510772321878100683 : ℝ) / 1000000000000000000) ((4510772321878166349 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((4510772321878100683 : ℝ) / 1000000000000000000) ((4510772321878166349 : ℝ) / 1000000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((700735254775061267 : ℝ) / 1000000000000000000) ((700735254775062741 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((42847873306067 : ℝ) / 100000000000000) ((428478733060673 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-2333838118071559089 : ℝ) / 1000000000000000000) ((-2333838118071542747 : ℝ) / 1000000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-816551431648248911 : ℝ) / 500000000000000000) ((-816551431648240003 : ℝ) / 500000000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((154376304829092207 : ℝ) / 100000000000000000) ((192970381036367383 : ℝ) / 125000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((37499999999999999 : ℝ) / 500000000000000000) ((3 : ℝ) / 40) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((254566983988618283 : ℝ) / 125000000000000000) ((203653587190895483 : ℝ) / 100000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((147308969185401 : ℝ) / 4000000000000000) ((36827242296350407 : ℝ) / 1000000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((29878626451656661 : ℝ) / 1000000000000000000) ((2987862645165679 : ℝ) / 100000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((1573641674742578731 : ℝ) / 1000000000000000000) ((786820837371297927 : ℝ) / 500000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((1573641674742578731 : ℝ) / 1000000000000000000) ((786820837371297927 : ℝ) / 500000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((750261353821709373 : ℝ) / 25000000000000000) ((15005227076434309361 : ℝ) / 500000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-472647217449235873 : ℝ) / 250000000000000000) ((-945294434898471653 : ℝ) / 500000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-26277572054064853 : ℝ) / 500000000000000000) ((-52555144108129593 : ℝ) / 1000000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((99360170501404211 : ℝ) / 1000000000000000000) ((19872034100280887 : ℝ) / 200000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((30109814323369779131 : ℝ) / 1000000000000000000) ((30109814323370023157 : ℝ) / 1000000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-700735254775062741 : ℝ) / 500000000000000000) ((-700735254775061267 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((1406249999999999 : ℝ) / 250000000000000000) ((9 : ℝ) / 1600) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((254566983988618283 : ℝ) / 125000000000000000) ((203653587190895483 : ℝ) / 100000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((1381021586113133 : ℝ) / 500000000000000000) ((2762043172226281 : ℝ) / 1000000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-1404232552722351763 : ℝ) / 1000000000000000000) ((-219411336362867 : ℝ) / 156250000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-1139279980738756113 : ℝ) / 1000000000000000000) ((-569639990369376851 : ℝ) / 500000000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((14485267171315511509 : ℝ) / 500000000000000000) ((5794106868526253891 : ℝ) / 200000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((27112499794801149301 : ℝ) / 1000000000000000000) ((847265618587543617 : ℝ) / 31250000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((27112499794801149301 : ℝ) / 1000000000000000000) ((847265618587543617 : ℝ) / 31250000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-186937747188955483 : ℝ) / 250000000000000000) ((-747750988755813113 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((747750988755813113 : ℝ) / 1000000000000000000) ((186937747188955483 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((405002428627483843 : ℝ) / 200000000000000000) ((506253035784358787 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((46157191654990001 : ℝ) / 125000000000000000) ((369257533239927269 : ℝ) / 1000000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((46157191654990001 : ℝ) / 125000000000000000) ((369257533239927269 : ℝ) / 1000000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((136351125854430629 : ℝ) / 1000000000000000000) ((17043890731804499 : ℝ) / 125000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((615048884561083173 : ℝ) / 1000000000000000000) ((615048884561116319 : ℝ) / 1000000000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((1573641674742578731 : ℝ) / 500000000000000000) ((786820837371297927 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((116215808603796231 : ℝ) / 100000000000000000) ((1162158086037997809 : ℝ) / 1000000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((1777206970599045483 : ℝ) / 1000000000000000000) ((111075435662444633 : ℝ) / 62500000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((902803336418756087 : ℝ) / 31250000000000000) ((1805606672837531867 : ℝ) / 62500000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-1805606672837531867 : ℝ) / 62500000000000000) ((-902803336418756087 : ℝ) / 31250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((902803336418756087 : ℝ) / 31250000000000000) ((1805606672837531867 : ℝ) / 62500000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((405002428627483843 : ℝ) / 200000000000000000) ((506253035784358787 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((1783304538648356947 : ℝ) / 125000000000000000) ((570657452367484937 : ℝ) / 40000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((1783304538648356947 : ℝ) / 125000000000000000) ((570657452367484937 : ℝ) / 40000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((492219438572583 : ℝ) / 500000000000000000) ((98443887714517 : ℝ) / 100000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((714731585968907583 : ℝ) / 500000000000000000) ((142946317193781817 : ℝ) / 100000000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((714731585968907583 : ℝ) / 500000000000000000) ((142946317193781817 : ℝ) / 100000000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((1020275745403308449 : ℝ) / 500000000000000000) ((204055149080662547 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((172287982726193 : ℝ) / 250000000000000000) ((689151930904777 : ℝ) / 1000000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((999310848069095223 : ℝ) / 1000000000000000000) ((249827712017273807 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((184501529348943291 : ℝ) / 500000000000000000) ((369003058697893841 : ℝ) / 1000000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((37499999999999999 : ℝ) / 500000000000000000) ((3 : ℝ) / 40) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((410182865477153 : ℝ) / 7812500000000000) ((3281462923817231 : ℝ) / 62500000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((210753232739481083 : ℝ) / 500000000000000000) ((421506465478969537 : ℝ) / 1000000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((210753232739481083 : ℝ) / 500000000000000000) ((421506465478969537 : ℝ) / 1000000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((1406249999999999 : ℝ) / 500000000000000000) ((9 : ℝ) / 3200) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((1020275745403308449 : ℝ) / 500000000000000000) ((204055149080662547 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((2914884408332497513 : ℝ) / 1000000000000000000) ((72872110208312897 : ℝ) / 25000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((964875310993519 : ℝ) / 1000000000000000000) ((964875310993527 : ℝ) / 1000000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((136351125854430629 : ℝ) / 1000000000000000000) ((17043890731804499 : ℝ) / 125000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((13156183496311 : ℝ) / 100000000000000000) ((131561834963117 : ℝ) / 1000000000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((37499999999999999 : ℝ) / 250000000000000000) ((3 : ℝ) / 20) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((1020275745403308449 : ℝ) / 500000000000000000) ((204055149080662547 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((14701907859301833 : ℝ) / 200000000000000000) ((73509539296509477 : ℝ) / 1000000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((27143951150231939 : ℝ) / 1000000000000000000) ((6785987787558147 : ℝ) / 250000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-13506194657634739 : ℝ) / 500000000000000000) ((-13506194657634411 : ℝ) / 500000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((1400090847495348947 : ℝ) / 1000000000000000000) ((87505677968459493 : ℝ) / 62500000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((1373078458180079469 : ℝ) / 1000000000000000000) ((686539229090041533 : ℝ) / 500000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((1020275745403308449 : ℝ) / 500000000000000000) ((204055149080662547 : ℝ) / 100000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((172287982726193 : ℝ) / 250000000000000000) ((689151930904777 : ℝ) / 1000000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((999310848069095223 : ℝ) / 1000000000000000000) ((249827712017273807 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((7128302283528624717 : ℝ) / 500000000000000000) ((14256604567057517171 : ℝ) / 1000000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((15629683025237328903 : ℝ) / 1000000000000000000) ((15629683025237600237 : ℝ) / 1000000000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((15629683025237328903 : ℝ) / 1000000000000000000) ((15629683025237600237 : ℝ) / 1000000000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_13_point_minus_lo_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((142847873306067 : ℝ) / 100000000000000) ((142847873306067 : ℝ) / 100000000000000)) :
    RB (E q (v)) ((1247 : ℝ) / 500000000000000000) ((2511 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((7477509887558151 : ℝ) / 10000000000000000) ((93468873594476903 : ℝ) / 125000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((142707248306067 : ℝ) / 100000000000000) ((1427072483060670001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-42847873306067 : ℝ) / 100000000000000) ((-42847873306067 : ℝ) / 100000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((44453141402576687 : ℝ) / 125000000000000000) ((355625131220613499 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_640.1 dlower_m_log_646.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((42847873306067 : ℝ) / 100000000000000) ((42847873306067 : ℝ) / 100000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-211878543326564897 : ℝ) / 250000000000000000) ((-423757086653129793 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_642.1 dlower_m_log_642.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((601569652263436541 : ℝ) / 500000000000000000) ((1203139304526873087 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((195225857858094671 : ℝ) / 200000000000000000) ((195225857858094673 : ℝ) / 200000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((356610054975958169 : ℝ) / 1000000000000000000) ((356610054975958171 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_644.1 dlower_m_log_644.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((38719952144657199 : ℝ) / 62500000000000000) ((154879808578628799 : ℝ) / 250000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((1247 : ℝ) / 500000000000000000) ((2511 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((1247 : ℝ) / 500000000000000000) ((2511 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-227464177795374161 : ℝ) / 200000000000000000) ((-1137320888976870687 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-26277572054064853 : ℝ) / 500000000000000000) ((-6569393013516213 : ℝ) / 125000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-4263896564080807 : ℝ) / 100000000000000000) ((-42638965640808067 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-9439678836941431 : ℝ) / 8000000000000000) ((-589979927308839377 : ℝ) / 500000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((7477509887558151 : ℝ) / 10000000000000000) ((93468873594476903 : ℝ) / 125000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((7477509887558151 : ℝ) / 10000000000000000) ((93468873594476903 : ℝ) / 125000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_13_point_minus_hi_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((1428478733060673 : ℝ) / 1000000000000000) ((1428478733060673 : ℝ) / 1000000000000000)) :
    RB (E q (v)) ((-179 : ℝ) / 50000000000000000) ((-3563 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((37387549437790991 : ℝ) / 50000000000000000) ((149550197751163989 : ℝ) / 200000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((1427072483060673 : ℝ) / 1000000000000000) ((1427072483060673001 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-428478733060673 : ℝ) / 1000000000000000) ((-428478733060673 : ℝ) / 1000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((177812565610307799 : ℝ) / 500000000000000000) ((355625131220615601 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_647.1 dlower_m_log_641.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((428478733060673 : ℝ) / 1000000000000000) ((428478733060673 : ℝ) / 1000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-847514173306252587 : ℝ) / 1000000000000000000) ((-169502834661250517 : ℝ) / 200000000000000000) := rb_log h5 (by norm_num) dlower_m_log_643.1 dlower_m_log_643.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1203139304526868183 : ℝ) / 1000000000000000000) ((300784826131717047 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((976129289290469381 : ℝ) / 1000000000000000000) ((976129289290469391 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((356610054975960269 : ℝ) / 1000000000000000000) ((356610054975960271 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_645.1 dlower_m_log_645.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((61951923431450911 : ℝ) / 100000000000000000) ((309759617157254561 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-179 : ℝ) / 50000000000000000) ((-3563 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-179 : ℝ) / 50000000000000000) ((-3563 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-568660444488433087 : ℝ) / 500000000000000000) ((-142165111122108257 : ℝ) / 125000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-13138786027032399 : ℝ) / 250000000000000000) ((-52555144108129593 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-42638965640807981 : ℝ) / 1000000000000000000) ((-42638965640807977 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-235991970923534831 : ℝ) / 200000000000000000) ((-1179959854617674033 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((37387549437790991 : ℝ) / 50000000000000000) ((149550197751163989 : ℝ) / 200000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((37387549437790991 : ℝ) / 50000000000000000) ((149550197751163989 : ℝ) / 200000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_13_slab_plus_branch {q v : ℝ} (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25))
    (hv : RB v ((53825556371276643 : ℝ) / 125000000000000000) ((110778361030382941 : ℝ) / 250000000000000000)) :
    RB (phi q (v)) ((86673796009134089 : ℝ) / 200000000000000000) ((446829151184928281 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((-2149102231321726413 : ℝ) / 1000000000000000000) ((-1549156928247689369 : ℝ) / 1000000000000000000) ∧
    RB (psi2 q (v)) ((-444750975048912939 : ℝ) / 15625000000000000) ((23224455222103069 : ℝ) / 10000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((53625556371276643 : ℝ) / 125000000000000000) ((88377688824306353 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((139221638969617059 : ℝ) / 250000000000000000) ((71174443628723357 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-105785998110750033 : ℝ) / 125000000000000000) ((-51043613601573839 : ℝ) / 62500000000000000) := rb_log h2 (by norm_num) dlower_m_log_648.1 dlower_m_log_649.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-585393729675455823 : ℝ) / 1000000000000000000) ((-281589960558395453 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_650.1 dlower_m_log_651.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-141554031884604679 : ℝ) / 500000000000000000) ((-231304087949725601 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-115598331311238349 : ℝ) / 500000000000000000) ((-93219772118241669 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-842565357435039291 : ℝ) / 1000000000000000000) ((-203482365045458871 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_652.1 dlower_m_log_653.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((291366398779679393 : ℝ) / 500000000000000000) ((656125813198555953 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-20805764782960867 : ℝ) / 500000000000000000) ((20710029472586619 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-20805764782960867 : ℝ) / 500000000000000000) ((20710029472586619 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((17742657804274693 : ℝ) / 100000000000000000) ((325013871878725803 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-93239125863468723 : ℝ) / 500000000000000000) ((-39602755475513197 : ℝ) / 250000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-152285134082538967 : ℝ) / 1000000000000000000) ((-31921267569505291 : ℝ) / 250000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((25141443960207963 : ℝ) / 1000000000000000000) ((197328801600704639 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((1948218367037131039 : ℝ) / 1000000000000000000) ((532423987839789687 : ℝ) / 250000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((1948218367037131039 : ℝ) / 1000000000000000000) ((532423987839789687 : ℝ) / 250000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z17 : ℝ := ((1 : ℝ)) / (z2)
  have h17 : RB z17 ((2263014598600754179 : ℝ) / 1000000000000000000) ((2330978146586718073 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z3)
  have h18 : RB z18 ((175624836144914593 : ℝ) / 100000000000000000) ((1795697866008879427 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := (z17) + (z18)
  have h19 : RB z19 ((4019262960049900109 : ℝ) / 1000000000000000000) ((1650670405038239 : ℝ) / 400000000000000) := rb_widen (rb_add h17 h18) (by norm_num) (by norm_num)
  let z20 : ℝ := (aval q) * (z19)
  have h20 : RB z20 ((1619836383093140401 : ℝ) / 500000000000000000) ((1684999199835748669 : ℝ) / 500000000000000000) := rb_mul_four hp_A h19 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z21 : ℝ := ((1 : ℝ)) / (v)
  have h21 : RB z21 ((2256758428944738059 : ℝ) / 1000000000000000000) ((2322316914622822883 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z20) - (z21)
  have h22 : RB z22 ((917355851563457919 : ℝ) / 1000000000000000000) ((1113239970726759279 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h20 h21) (by norm_num) (by norm_num)
  have bound_Ev_22 : RB (Ev q (v)) ((917355851563457919 : ℝ) / 1000000000000000000) ((1113239970726759279 : ℝ) / 1000000000000000000) := by
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, Ev] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z23 : ℝ := (z3) ^ 2
  have h23 : RB z23 ((12404905444727293 : ℝ) / 40000000000000000) ((40526411406866551 : ℝ) / 125000000000000000) := rb_widen (rb_sq h3 (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (z23)
  have h24 : RB z24 ((1542204153546404963 : ℝ) / 500000000000000000) ((3224530825988843491 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z2) ^ 2
  have h25 : RB z25 ((184044818952254013 : ℝ) / 1000000000000000000) ((97632698524074051 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z26 : ℝ := ((1 : ℝ)) / (z25)
  have h26 : RB z26 ((640154384185016567 : ℝ) / 125000000000000000) ((679182389983106417 : ℝ) / 125000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h25 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z27 : ℝ := (z24) - (z26)
  have h27 : RB z27 ((-234905081277204141 : ℝ) / 100000000000000000) ((-379340849498257809 : ℝ) / 200000000000000000) := rb_widen (rb_sub h24 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (aval q) * (z27)
  have h28 : RB z28 ((-959161496520006099 : ℝ) / 500000000000000000) ((-764406454265819497 : ℝ) / 500000000000000000) := rb_mul_four hp_A h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (v) ^ 2
  have h29 : RB z29 ((37084038639071739 : ℝ) / 200000000000000000) ((98174762180622927 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((1018591721322624463 : ℝ) / 200000000000000000) ((134828896298581691 : ℝ) / 25000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) + (z30)
  have h31 : RB z31 ((3174635613573110117 : ℝ) / 1000000000000000000) ((1932171471705814323 : ℝ) / 500000000000000000) := rb_widen (rb_add h28 h30) (by norm_num) (by norm_num)
  have bound_Evv_31 : RB (Evv q (v)) ((3174635613573110117 : ℝ) / 1000000000000000000) ((1932171471705814323 : ℝ) / 500000000000000000) := by
    have hh := h31
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, Evv] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z32 : ℝ := ((1 : ℝ)) / (z2)
  have h32 : RB z32 ((2263014598600754179 : ℝ) / 1000000000000000000) ((2330978146586718073 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := ((1 : ℝ)) / (z3)
  have h33 : RB z33 ((175624836144914593 : ℝ) / 100000000000000000) ((1795697866008879427 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) + (z33)
  have h34 : RB z34 ((4019262960049900109 : ℝ) / 1000000000000000000) ((1650670405038239 : ℝ) / 400000000000000) := rb_widen (rb_add h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := (aval1 q) * (z34)
  have h35 : RB z35 ((-1184377204755398009 : ℝ) / 250000000000000000) ((-3083058667820062749 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h34 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((2 : ℝ)) * (q)
  have h36 : RB z36 ((34999999999999999 : ℝ) / 500000000000000000) ((2 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := (z2) ^ 2
  have h37 : RB z37 ((184044818952254013 : ℝ) / 1000000000000000000) ((97632698524074051 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (z36) / (z37)
  have h38 : RB z38 ((358486455143609267 : ℝ) / 1000000000000000000) ((434676729589188107 : ℝ) / 1000000000000000000) := rb_div_signed h36 h37 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := (aval q) * (z38)
  have h39 : RB z39 ((9029786814453911 : ℝ) / 31250000000000000) ((354973319596426533 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z35) + (z39)
  have h40 : RB z40 ((-1112138910239766721 : ℝ) / 250000000000000000) ((-341010668527954527 : ℝ) / 125000000000000000) := rb_widen (rb_add h35 h39) (by norm_num) (by norm_num)
  have bound_Evq_40 : RB (Evq q (v)) ((-1112138910239766721 : ℝ) / 250000000000000000) ((-341010668527954527 : ℝ) / 125000000000000000) := by
    have hh := h40
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, Evq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z41 : ℝ := (aval2 q) * (z6)
  have h41 : RB z41 ((-2178012816647843211 : ℝ) / 250000000000000000) ((-2359838001885226457 : ℝ) / 500000000000000000) := rb_mul_four hp_A2 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h42 : RB z42 ((-574010269350148571 : ℝ) / 250000000000000000) ((-383535327056802703 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := ((-2 : ℝ)) * (q)
  have h43 : RB z43 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z44 : ℝ := (z43) / (z2)
  have h44 : RB z44 ((-93239125863468723 : ℝ) / 500000000000000000) ((-39602755475513197 : ℝ) / 250000000000000000) := rb_div_signed h43 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (z42) * (z44)
  have h45 : RB z45 ((7594527886825769 : ℝ) / 31250000000000000) ((214080863003448343 : ℝ) / 500000000000000000) := rb_mul_four h42 h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((-2117256593553237059 : ℝ) / 250000000000000000) ((-1072878569440889057 : ℝ) / 250000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  let z47 : ℝ := ((-2 : ℝ)) / (z2)
  have h47 : RB z47 ((-932391258634687229 : ℝ) / 200000000000000000) ((-4526029197201508359 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := (q) ^ 2
  have h48 : RB z48 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z49 : ℝ := ((4 : ℝ)) * (z48)
  have h49 : RB z49 ((1224999999999999 : ℝ) / 250000000000000000) ((4 : ℝ) / 625) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h48 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z2) ^ 2
  have h50 : RB z50 ((184044818952254013 : ℝ) / 1000000000000000000) ((97632698524074051 : ℝ) / 500000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z51 : ℝ := (z49) / (z50)
  have h51 : RB z51 ((6273512965013157 : ℝ) / 250000000000000000) ((34774138367135049 : ℝ) / 1000000000000000000) := rb_div_signed h49 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) - (z51)
  have h52 : RB z52 ((-2348365215770285597 : ℝ) / 500000000000000000) ((-4551123249061560987 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := (aval q) * (z52)
  have h53 : RB z53 ((-3835526217631188291 : ℝ) / 1000000000000000000) ((-733674317510139169 : ℝ) / 200000000000000000) := rb_mul_four hp_A h52 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (z46) + (z53)
  have h54 : RB z54 ((-12304552591844136527 : ℝ) / 1000000000000000000) ((-7959885865314252073 : ℝ) / 1000000000000000000) := rb_widen (rb_add h46 h53) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) - (delta2 q)
  have h55 : RB z55 ((-14171573992576942433 : ℝ) / 1000000000000000000) ((-9808998291349755031 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h54 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_55 : RB (Eqq q (v)) ((-14171573992576942433 : ℝ) / 1000000000000000000) ((-9808998291349755031 : ℝ) / 1000000000000000000) := by
    have hh := h55
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, Eqq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z56 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h56 : RB z56 ((-532423987839789687 : ℝ) / 250000000000000000) ((-1948218367037131039 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_16) (by norm_num) (by norm_num)
  let z57 : ℝ := (z56) / (Ev q (v))
  have h57 : RB z57 ((-464311847519040419 : ℝ) / 200000000000000000) ((-350008698621424937 : ℝ) / 200000000000000000) := rb_div_signed h56 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_57 : RB (rootSlope q (v)) ((-464311847519040419 : ℝ) / 200000000000000000) ((-350008698621424937 : ℝ) / 200000000000000000) := by
    have hh := h57
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, rootSlope] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z58 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h58 : RB z58 ((350008698621424937 : ℝ) / 200000000000000000) ((464311847519040419 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z59 : ℝ := (z58) ^ 2
  have h59 : RB z59 ((765663056941646691 : ℝ) / 250000000000000000) ((5389637293663616013 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h58 (by norm_num)) (by norm_num) (by norm_num)
  let z60 : ℝ := (Evv q (v)) * (z59)
  have h60 : RB z60 ((9722804834256830769 : ℝ) / 1000000000000000000) ((10413703421658571129 : ℝ) / 500000000000000000) := rb_mul_four bound_Evv_31 h59 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z61 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h61 : RB z61 ((-1112138910239766721 : ℝ) / 125000000000000000) ((-341010668527954527 : ℝ) / 62500000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z62 : ℝ := (z61) * (rootSlope q (v))
  have h62 : RB z62 ((596783501537457369 : ℝ) / 62500000000000000) ((10327585442224766901 : ℝ) / 500000000000000000) := rb_mul_four h61 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z63 : ℝ := (z60) + (z62)
  have h63 : RB z63 ((19271340858856148673 : ℝ) / 1000000000000000000) ((2074128886388333803 : ℝ) / 50000000000000000) := rb_widen (rb_add h60 h62) (by norm_num) (by norm_num)
  let z64 : ℝ := (z63) + (Eqq q (v))
  have h64 : RB z64 ((31873542914245039 : ℝ) / 6250000000000000) ((31673579436416921029 : ℝ) / 1000000000000000000) := rb_widen (rb_add h63 bound_Eqq_55) (by norm_num) (by norm_num)
  let z65 : ℝ := ((0 : ℝ)) - (z64)
  have h65 : RB z65 ((-31673579436416921029 : ℝ) / 1000000000000000000) ((-31873542914245039 : ℝ) / 6250000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h64) (by norm_num) (by norm_num)
  let z66 : ℝ := (z65) / (Ev q (v))
  have h66 : RB z66 ((-17263518503989128973 : ℝ) / 500000000000000000) ((-91620261585647387 : ℝ) / 20000000000000000) := rb_div_signed h65 bound_Ev_22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_66 : RB (rootCurvature q (v)) ((-17263518503989128973 : ℝ) / 500000000000000000) ((-91620261585647387 : ℝ) / 20000000000000000) := by
    have hh := h66
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, rootCurvature] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z67 : ℝ := (q) ^ 2
  have h67 : RB z67 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z68 : ℝ := (z67) / (v)
  have h68 : RB z68 ((2764529075457301 : ℝ) / 1000000000000000000) ((3715707063396517 : ℝ) / 1000000000000000000) := rb_div_signed h67 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (v) + (z68)
  have h69 : RB z69 ((86673796009134089 : ℝ) / 200000000000000000) ((446829151184928281 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h68) (by norm_num) (by norm_num)
  have bound_p_69 : RB (phi q (v)) ((86673796009134089 : ℝ) / 200000000000000000) ((446829151184928281 : ℝ) / 1000000000000000000) := by
    have hh := h69
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, phi] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z70 : ℝ := (q) ^ 2
  have h70 : RB z70 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z71 : ℝ := (v) ^ 2
  have h71 : RB z71 ((37084038639071739 : ℝ) / 200000000000000000) ((98174762180622927 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z72 : ℝ := (z70) / (z71)
  have h72 : RB z72 ((6238874293101069 : ℝ) / 1000000000000000000) ((8629049363109229 : ℝ) / 1000000000000000000) := rb_div_signed h70 h71 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z73 : ℝ := ((1 : ℝ)) - (z72)
  have h73 : RB z73 ((991370950636890771 : ℝ) / 1000000000000000000) ((993761125706898931 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := (z73) * (rootSlope q (v))
  have h74 : RB z74 ((-288384415168482259 : ℝ) / 125000000000000000) ((-1084338925885947 : ℝ) / 625000000000000) := rb_mul_four h73 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z75 : ℝ := ((2 : ℝ)) * (q)
  have h75 : RB z75 ((34999999999999999 : ℝ) / 500000000000000000) ((2 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z76 : ℝ := (z75) / (v)
  have h76 : RB z76 ((157973090026131659 : ℝ) / 1000000000000000000) ((185785353169825831 : ℝ) / 1000000000000000000) := rb_div_signed h75 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z77 : ℝ := (z74) + (z76)
  have h77 : RB z77 ((-2149102231321726413 : ℝ) / 1000000000000000000) ((-1549156928247689369 : ℝ) / 1000000000000000000) := rb_widen (rb_add h74 h76) (by norm_num) (by norm_num)
  have bound_p1_77 : RB (psi1 q (v)) ((-2149102231321726413 : ℝ) / 1000000000000000000) ((-1549156928247689369 : ℝ) / 1000000000000000000) := by
    have hh := h77
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, psi1] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z78 : ℝ := (q) ^ 2
  have h78 : RB z78 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z79 : ℝ := ((2 : ℝ)) * (z78)
  have h79 : RB z79 ((1224999999999999 : ℝ) / 500000000000000000) ((2 : ℝ) / 625) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h78 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((37084038639071739 : ℝ) / 200000000000000000) ((98174762180622927 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z80) * (v)
  have h81 : RB z81 ((39921380244839141 : ℝ) / 500000000000000000) ((17401022798267251 : ℝ) / 200000000000000000) := rb_mul_four h80 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := (z79) / (z81)
  have h82 : RB z82 ((14079632148082483 : ℝ) / 500000000000000000) ((10019693646531929 : ℝ) / 250000000000000000) := rb_div_signed h79 h81 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z83 : ℝ := ((0 : ℝ)) - (rootSlope q (v))
  have h83 : RB z83 ((350008698621424937 : ℝ) / 200000000000000000) ((464311847519040419 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_r1_57) (by norm_num) (by norm_num)
  let z84 : ℝ := (z83) ^ 2
  have h84 : RB z84 ((765663056941646691 : ℝ) / 250000000000000000) ((5389637293663616013 : ℝ) / 1000000000000000000) := rb_widen (rb_sq h83 (by norm_num)) (by norm_num) (by norm_num)
  let z85 : ℝ := (z82) * (z84)
  have h85 : RB z85 ((86242033528917739 : ℝ) / 1000000000000000000) ((27001257274216437 : ℝ) / 125000000000000000) := rb_mul_four h82 h84 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := ((4 : ℝ)) * (q)
  have h86 : RB z86 ((34999999999999999 : ℝ) / 250000000000000000) ((4 : ℝ) / 25) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z87 : ℝ := (v) ^ 2
  have h87 : RB z87 ((37084038639071739 : ℝ) / 200000000000000000) ((98174762180622927 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := (z86) / (z87)
  have h88 : RB z88 ((713014204925837103 : ℝ) / 1000000000000000000) ((862904936310922823 : ℝ) / 1000000000000000000) := rb_div_signed h86 h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (z88) * (rootSlope q (v))
  have h89 : RB z89 ((-200328492605912241 : ℝ) / 100000000000000000) ((-1247805869823411191 : ℝ) / 1000000000000000000) := rb_mul_four h88 bound_r1_57 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z90 : ℝ := (z85) - (z89)
  have h90 : RB z90 ((133404790335232893 : ℝ) / 100000000000000000) ((1109647492126426953 : ℝ) / 500000000000000000) := rb_widen (rb_sub h85 h89) (by norm_num) (by norm_num)
  let z91 : ℝ := ((2 : ℝ)) / (v)
  have h91 : RB z91 ((2256758428944738059 : ℝ) / 500000000000000000) ((2322316914622822883 : ℝ) / 500000000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (z90) + (z91)
  have h92 : RB z92 ((730945595155225631 : ℝ) / 125000000000000000) ((857991101687312459 : ℝ) / 125000000000000000) := rb_widen (rb_add h90 h91) (by norm_num) (by norm_num)
  let z93 : ℝ := (q) ^ 2
  have h93 : RB z93 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z94 : ℝ := (v) ^ 2
  have h94 : RB z94 ((37084038639071739 : ℝ) / 200000000000000000) ((98174762180622927 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z95 : ℝ := (z93) / (z94)
  have h95 : RB z95 ((6238874293101069 : ℝ) / 1000000000000000000) ((8629049363109229 : ℝ) / 1000000000000000000) := rb_div_signed h93 h94 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z96 : ℝ := ((1 : ℝ)) - (z95)
  have h96 : RB z96 ((991370950636890771 : ℝ) / 1000000000000000000) ((993761125706898931 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h95) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootCurvature q (v))
  have h97 : RB z97 ((-4288953395546529143 : ℝ) / 125000000000000000) ((-1135370822822048193 : ℝ) / 250000000000000000) := rb_mul_four h96 bound_r2_66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z92) + (z97)
  have h98 : RB z98 ((-444750975048912939 : ℝ) / 15625000000000000) ((23224455222103069 : ℝ) / 10000000000000000) := rb_widen (rb_add h92 h97) (by norm_num) (by norm_num)
  have bound_p2_98 : RB (psi2 q (v)) ((-444750975048912939 : ℝ) / 15625000000000000) ((23224455222103069 : ℝ) / 10000000000000000) := by
    have hh := h98
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, psi2] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_69, bound_p1_77, bound_p2_98⟩

theorem dlower_m_13_slab_plus_lo_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((53825556371276643 : ℝ) / 125000000000000000) ((53825556371276643 : ℝ) / 125000000000000000)) :
    RB (E q (v)) ((-6278382530948213 : ℝ) / 1000000000000000000) ((-3139191265474099 : ℝ) / 500000000000000000) ∧
    RB (Eq q (v)) ((2053131081612603893 : ℝ) / 1000000000000000000) ((64160346300393873 : ℝ) / 31250000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((53649775121276643 : ℝ) / 125000000000000000) ((85839640194042629 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((71174443628723357 : ℝ) / 125000000000000000) ((71174443628723357 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-845836459822884567 : ℝ) / 1000000000000000000) ((-422918229911442281 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_654.1 dlower_m_log_655.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-140794980279197727 : ℝ) / 250000000000000000) ((-281589960558395453 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_651.1 dlower_m_log_651.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-282656538706093661 : ℝ) / 1000000000000000000) ((-141328269353046827 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-57331126412868703 : ℝ) / 250000000000000000) ((-57331126412868701 : ℝ) / 250000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-842565357435039291 : ℝ) / 1000000000000000000) ((-842565357435039289 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_652.1 dlower_m_log_652.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((613240851783564477 : ℝ) / 1000000000000000000) ((613240851783564487 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-6278382530948213 : ℝ) / 1000000000000000000) ((-3139191265474099 : ℝ) / 500000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-6278382530948213 : ℝ) / 1000000000000000000) ((-3139191265474099 : ℝ) / 500000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((13359682651326739 : ℝ) / 50000000000000000) ((133596826513267407 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-174744441683261127 : ℝ) / 1000000000000000000) ((-174744441683261121 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-70886707393712431 : ℝ) / 500000000000000000) ((-17721676848428107 : ℝ) / 125000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((62710119119554959 : ℝ) / 500000000000000000) ((62710119119554979 : ℝ) / 500000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((2053131081612603893 : ℝ) / 1000000000000000000) ((64160346300393873 : ℝ) / 31250000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((2053131081612603893 : ℝ) / 1000000000000000000) ((64160346300393873 : ℝ) / 31250000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_13_slab_plus_lo_slope {q v : ℝ} (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25))
    (hv : RB v ((53825556371276643 : ℝ) / 125000000000000000) ((53825556371276643 : ℝ) / 125000000000000000)) :
    RB (E q (v)) ((-12975632312717929 : ℝ) / 1000000000000000000) ((46053049309109 : ℝ) / 125000000000000000) ∧
    RB (Eq q (v)) ((1987285460186390449 : ℝ) / 1000000000000000000) ((212597613741365113 : ℝ) / 100000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((53625556371276643 : ℝ) / 125000000000000000) ((85875890194042629 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((71174443628723357 : ℝ) / 125000000000000000) ((71174443628723357 : ℝ) / 125000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-105785998110750033 : ℝ) / 125000000000000000) ((-845414249898638681 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_648.1 dlower_m_log_656.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-140794980279197727 : ℝ) / 250000000000000000) ((-281589960558395453 : ℝ) / 500000000000000000) := rb_log h3 (by norm_num) dlower_m_log_651.1 dlower_m_log_651.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-141554031884604679 : ℝ) / 500000000000000000) ((-282234328781847773 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-115598331311238349 : ℝ) / 500000000000000000) ((-28436397348397963 : ℝ) / 125000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-842565357435039291 : ℝ) / 1000000000000000000) ((-842565357435039289 : ℝ) / 1000000000000000000) := rb_log hv (by norm_num) dlower_m_log_652.1 dlower_m_log_652.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((611368694812562591 : ℝ) / 1000000000000000000) ((615074178647855587 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((-12975632312717929 : ℝ) / 1000000000000000000) ((46053049309109 : ℝ) / 125000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((-12975632312717929 : ℝ) / 1000000000000000000) ((46053049309109 : ℝ) / 125000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((10824683559600317 : ℝ) / 50000000000000000) ((325013871878725803 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-93239125863468723 : ℝ) / 500000000000000000) ((-163025966524085077 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-152285134082538967 : ℝ) / 1000000000000000000) ((-65702442111764391 : ℝ) / 500000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((64208537109467373 : ℝ) / 1000000000000000000) ((193608987655197021 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((1987285460186390449 : ℝ) / 1000000000000000000) ((212597613741365113 : ℝ) / 100000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((1987285460186390449 : ℝ) / 1000000000000000000) ((212597613741365113 : ℝ) / 100000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_13_slab_plus_hi_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((110778361030382941 : ℝ) / 250000000000000000) ((110778361030382941 : ℝ) / 250000000000000000)) :
    RB (E q (v)) ((802008803711877 : ℝ) / 125000000000000000) ((641607042969503 : ℝ) / 100000000000000000) ∧
    RB (Eq q (v)) ((80359627258484307 : ℝ) / 40000000000000000) ((2008990681462107713 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((110426798530382941 : ℝ) / 250000000000000000) ((88341438824306353 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((139221638969617059 : ℝ) / 250000000000000000) ((139221638969617059 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-817108073164474431 : ℝ) / 1000000000000000000) ((-817108073164474427 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_657.1 dlower_m_log_658.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-585393729675455823 : ℝ) / 1000000000000000000) ((-585393729675455821 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_650.1 dlower_m_log_650.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-23171434348901861 : ℝ) / 100000000000000000) ((-57928585872254651 : ℝ) / 250000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-93997077718813889 : ℝ) / 500000000000000000) ((-187994155437627771 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-406964730090917743 : ℝ) / 500000000000000000) ((-203482365045458871 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_653.1 dlower_m_log_653.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((312967652372103853 : ℝ) / 500000000000000000) ((125187060948841543 : ℝ) / 200000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((802008803711877 : ℝ) / 125000000000000000) ((641607042969503 : ℝ) / 100000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((802008803711877 : ℝ) / 125000000000000000) ((641607042969503 : ℝ) / 100000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((43807655877264439 : ℝ) / 200000000000000000) ((219038279386322223 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-169795740250869503 : ℝ) / 1000000000000000000) ((-169795740250869497 : ℝ) / 1000000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-27551688259541699 : ℝ) / 200000000000000000) ((-17219805162213561 : ℝ) / 125000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((812798380886137 : ℝ) / 10000000000000000) ((16255967617722747 : ℝ) / 200000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((80359627258484307 : ℝ) / 40000000000000000) ((2008990681462107713 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((80359627258484307 : ℝ) / 40000000000000000) ((2008990681462107713 : ℝ) / 1000000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_13_slab_plus_hi_slope {q v : ℝ} (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25))
    (hv : RB v ((110778361030382941 : ℝ) / 250000000000000000) ((110778361030382941 : ℝ) / 250000000000000000)) :
    RB (E q (v)) ((4445133223 : ℝ) / 20000000000000000) ((12784161691969433 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((195253292127018801 : ℝ) / 100000000000000000) ((517799645491908991 : ℝ) / 250000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_slab hq
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((110378361030382941 : ℝ) / 250000000000000000) ((88377688824306353 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((139221638969617059 : ℝ) / 250000000000000000) ((139221638969617059 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((-817546808390348011 : ℝ) / 1000000000000000000) ((-51043613601573839 : ℝ) / 62500000000000000) := rb_log h2 (by norm_num) dlower_m_log_659.1 dlower_m_log_649.2
  let z5 : ℝ := Real.log (z3)
  have h5 : RB z5 ((-585393729675455823 : ℝ) / 1000000000000000000) ((-585393729675455821 : ℝ) / 1000000000000000000) := rb_log h3 (by norm_num) dlower_m_log_650.1 dlower_m_log_650.2
  let z6 : ℝ := (z4) - (z5)
  have h6 : RB z6 ((-23215307871489219 : ℝ) / 100000000000000000) ((-231304087949725601 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (aval q) * (z6)
  have h7 : RB z7 ((-94792455399946907 : ℝ) / 500000000000000000) ((-93219772118241669 : ℝ) / 500000000000000000) := rb_mul_four hp_A h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (v)
  have h8 : RB z8 ((-406964730090917743 : ℝ) / 500000000000000000) ((-203482365045458871 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_653.1 dlower_m_log_653.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((62434454938194167 : ℝ) / 100000000000000000) ((156872478986338037 : ℝ) / 250000000000000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) - (delta q)
  have h10 : RB z10 ((4445133223 : ℝ) / 20000000000000000) ((12784161691969433 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h9 hp_dl) (by norm_num) (by norm_num)
  have bound_E_10 : RB (E q (v)) ((4445133223 : ℝ) / 20000000000000000) ((12784161691969433 : ℝ) / 1000000000000000000) := by
    have hh := h10
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, E] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z11 : ℝ := (aval1 q) * (z6)
  have h11 : RB z11 ((17742657804274693 : ℝ) / 100000000000000000) ((266516502487203019 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := ((-2 : ℝ)) * (q)
  have h12 : RB z12 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z12) / (z2)
  have h13 : RB z13 ((-181194935432088587 : ℝ) / 1000000000000000000) ((-39602755475513197 : ℝ) / 250000000000000000) := rb_div_signed h12 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (aval q) * (z13)
  have h14 : RB z14 ((-36992644962370499 : ℝ) / 250000000000000000) ((-31921267569505291 : ℝ) / 250000000000000000) := rb_mul_four hp_A h13 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (z11) + (z14)
  have h15 : RB z15 ((14727999096632467 : ℝ) / 500000000000000000) ((27766286441836371 : ℝ) / 200000000000000000) := rb_widen (rb_add h11 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (delta1 q)
  have h16 : RB z16 ((195253292127018801 : ℝ) / 100000000000000000) ((517799645491908991 : ℝ) / 250000000000000000) := rb_widen (rb_sub h15 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_16 : RB (Eq q (v)) ((195253292127018801 : ℝ) / 100000000000000000) ((517799645491908991 : ℝ) / 250000000000000000) := by
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, Eq] <;> try simp only [Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_10, bound_Eq_16⟩

theorem dlower_m_13_slab_minus_branch {q v : ℝ} (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25))
    (hv : RB v ((285234174695584343 : ℝ) / 200000000000000000) ((357696648160855189 : ℝ) / 250000000000000000)) :
    RB (phi q (v)) ((713513522942136963 : ℝ) / 500000000000000000) ((1431908477846487743 : ℝ) / 1000000000000000000) ∧
    RB (psi1 q (v)) ((28712952585021981 : ℝ) / 100000000000000000) ((271260078480756943 : ℝ) / 500000000000000000) ∧
    RB (psi2 q (v)) ((3064910024497421063 : ℝ) / 250000000000000000) ((20012611602582074307 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((284914174695584343 : ℝ) / 200000000000000000) ((1429561592643420757 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-107696648160855189 : ℝ) / 250000000000000000) ((-85234174695584343 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353870626949429247 : ℝ) / 1000000000000000000) ((35736781869596401 : ℝ) / 100000000000000000) := rb_log h2 (by norm_num) dlower_m_log_660.1 dlower_m_log_661.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((85234174695584343 : ℝ) / 200000000000000000) ((107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-213228725421484713 : ℝ) / 250000000000000000) ((-421071228090916763 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_662.1 dlower_m_log_663.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1196013083131262773 : ℝ) / 1000000000000000000) ((605141360190951431 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((241007558595689337 : ℝ) / 250000000000000000) ((494181130089697583 : ℝ) / 500000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35499314193677517 : ℝ) / 100000000000000000) ((179112178913622853 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_664.1 dlower_m_log_665.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((302902938277755821 : ℝ) / 500000000000000000) ((158342279560654999 : ℝ) / 250000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-9269225284884439 : ℝ) / 500000000000000000) ((18663363989237281 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-9269225284884439 : ℝ) / 500000000000000000) ((18663363989237281 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-69471471031624661 : ℝ) / 50000000000000000) ((-183485307601185531 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-28078631077402783 : ℝ) / 500000000000000000) ((-24483030448013819 : ℝ) / 500000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-45860126410212919 : ℝ) / 1000000000000000000) ((-39468433772322837 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1435289547042706139 : ℝ) / 1000000000000000000) ((-239223742944562623 : ℝ) / 250000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((487787376034216937 : ℝ) / 1000000000000000000) ((975472177980203617 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((487787376034216937 : ℝ) / 1000000000000000000) ((975472177980203617 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z18 : ℝ := ((1 : ℝ)) / (z2)
  have h18 : RB z18 ((699515155657537719 : ℝ) / 1000000000000000000) ((175491444233767391 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h19 : RB z19 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z20 : ℝ := ((0 : ℝ)) - (z3)
  have h20 : RB z20 ((85234174695584343 : ℝ) / 200000000000000000) ((107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z21 : ℝ := (z19) / (z20)
  have h21 : RB z21 ((-1173238320863105841 : ℝ) / 500000000000000000) ((-23213350115279467 : ℝ) / 10000000000000000) := rb_div_signed h19 h20 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := (z18) + (z21)
  have h22 : RB z22 ((-1646961486068673963 : ℝ) / 1000000000000000000) ((-101210577162054821 : ℝ) / 62500000000000000) := rb_widen (rb_add h18 h21) (by norm_num) (by norm_num)
  let z23 : ℝ := (aval q) * (z22)
  have h23 : RB z23 ((-1344970517537920357 : ℝ) / 1000000000000000000) ((-652635378657251801 : ℝ) / 500000000000000000) := rb_mul_four hp_A h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) / (v)
  have h24 : RB z24 ((698916250083438563 : ℝ) / 1000000000000000000) ((5477955093100521 : ℝ) / 7812500000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((-409229753890957409 : ℝ) / 200000000000000000) ((-400837401479588433 : ℝ) / 200000000000000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  have bound_Ev_25 : RB (Ev q (v)) ((-409229753890957409 : ℝ) / 200000000000000000) ((-400837401479588433 : ℝ) / 200000000000000000) := by
    have hh := h25
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, Ev] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z26 : ℝ := ((0 : ℝ)) - (z3)
  have h26 : RB z26 ((85234174695584343 : ℝ) / 200000000000000000) ((107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z27 : ℝ := (z26) ^ 2
  have h27 : RB z27 ((90810806700467379 : ℝ) / 500000000000000000) ((92788544200664267 : ℝ) / 500000000000000000) := rb_widen (rb_sq h26 (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := ((1 : ℝ)) / (z27)
  have h28 : RB z28 ((1347149058936363109 : ℝ) / 250000000000000000) ((2752976315083360191 : ℝ) / 500000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := (z2) ^ 2
  have h29 : RB z29 ((1014701086780824419 : ℝ) / 500000000000000000) ((510911586790298417 : ℝ) / 250000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := ((1 : ℝ)) / (z29)
  have h30 : RB z30 ((61165181624323653 : ℝ) / 125000000000000000) ((492755951988055841 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h29 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := (z28) - (z30)
  have h31 : RB z31 ((979168056751479319 : ℝ) / 200000000000000000) ((2508315588586065579 : ℝ) / 500000000000000000) := rb_widen (rb_sub h28 h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (aval q) * (z31)
  have h32 : RB z32 ((1973113054873328547 : ℝ) / 500000000000000000) ((1024192291035870419 : ℝ) / 250000000000000000) := rb_mul_four hp_A h31 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z33 : ℝ := (v) ^ 2
  have h33 : RB z33 ((508490840089194547 : ℝ) / 250000000000000000) ((1023575136844085023 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z34 : ℝ := ((1 : ℝ)) / (z33)
  have h34 : RB z34 ((97696784926139127 : ℝ) / 200000000000000000) ((491650940961192963 : ℝ) / 1000000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (z32) + (z34)
  have h35 : RB z35 ((4434710034377352729 : ℝ) / 1000000000000000000) ((4588420105104674639 : ℝ) / 1000000000000000000) := rb_widen (rb_add h32 h34) (by norm_num) (by norm_num)
  have bound_Evv_35 : RB (Evv q (v)) ((4434710034377352729 : ℝ) / 1000000000000000000) ((4588420105104674639 : ℝ) / 1000000000000000000) := by
    have hh := h35
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, Evv] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z36 : ℝ := ((1 : ℝ)) / (z2)
  have h36 : RB z36 ((699515155657537719 : ℝ) / 1000000000000000000) ((175491444233767391 : ℝ) / 250000000000000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z37 : ℝ := ((0 : ℝ)) - ((1 : ℝ))
  have h37 : RB z37 (-1 : ℝ) (-1 : ℝ) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z38 : ℝ := ((0 : ℝ)) - (z3)
  have h38 : RB z38 ((85234174695584343 : ℝ) / 200000000000000000) ((107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h3) (by norm_num) (by norm_num)
  let z39 : ℝ := (z37) / (z38)
  have h39 : RB z39 ((-1173238320863105841 : ℝ) / 500000000000000000) ((-23213350115279467 : ℝ) / 10000000000000000) := rb_div_signed h37 h38 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z40 : ℝ := (z36) + (z39)
  have h40 : RB z40 ((-1646961486068673963 : ℝ) / 1000000000000000000) ((-101210577162054821 : ℝ) / 62500000000000000) := rb_widen (rb_add h36 h39) (by norm_num) (by norm_num)
  let z41 : ℝ := (aval1 q) * (z40)
  have h41 : RB z41 ((1242170618030606787 : ℝ) / 1000000000000000000) ((189074561245520101 : ℝ) / 100000000000000000) := rb_mul_four hp_A1 h40 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z42 : ℝ := ((2 : ℝ)) * (q)
  have h42 : RB z42 ((34999999999999999 : ℝ) / 500000000000000000) ((2 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z43 : ℝ := (z2) ^ 2
  have h43 : RB z43 ((1014701086780824419 : ℝ) / 500000000000000000) ((510911586790298417 : ℝ) / 250000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z44 : ℝ := (z42) / (z43)
  have h44 : RB z44 ((8563125427405311 : ℝ) / 250000000000000000) ((9855119039761117 : ℝ) / 250000000000000000) := rb_div_signed h42 h43 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z45 : ℝ := (aval q) * (z44)
  have h45 : RB z45 ((6902191898451407 : ℝ) / 250000000000000000) ((6438447853177123 : ℝ) / 200000000000000000) := rb_mul_four hp_A h44 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z46 : ℝ := (z41) + (z45)
  have h46 : RB z46 ((253955877124882483 : ℝ) / 200000000000000000) ((15383502813768693 : ℝ) / 8000000000000000) := rb_widen (rb_add h41 h45) (by norm_num) (by norm_num)
  have bound_Evq_46 : RB (Evq q (v)) ((253955877124882483 : ℝ) / 200000000000000000) ((15383502813768693 : ℝ) / 8000000000000000) := by
    have hh := h46
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, Evq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z47 : ℝ := (aval2 q) * (z7)
  have h47 : RB z47 ((24404213080216048407 : ℝ) / 1000000000000000000) ((18621944155628767361 : ℝ) / 500000000000000000) := rb_mul_four hp_A2 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := ((2 : ℝ)) * (aval1 q)
  have h48 : RB z48 ((-574010269350148571 : ℝ) / 250000000000000000) ((-383535327056802703 : ℝ) / 250000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_A1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z49 : ℝ := ((-2 : ℝ)) * (q)
  have h49 : RB z49 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z50 : ℝ := (z49) / (z2)
  have h50 : RB z50 ((-28078631077402783 : ℝ) / 500000000000000000) ((-24483030448013819 : ℝ) / 500000000000000000) := rb_div_signed h49 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z51 : ℝ := (z48) * (z50)
  have h51 : RB z51 ((75120856721765111 : ℝ) / 1000000000000000000) ((128939380701787391 : ℝ) / 1000000000000000000) := rb_mul_four h48 h50 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z52 : ℝ := (z47) + (z51)
  have h52 : RB z52 ((12239666968468906759 : ℝ) / 500000000000000000) ((37372827691959322113 : ℝ) / 1000000000000000000) := rb_widen (rb_add h47 h51) (by norm_num) (by norm_num)
  let z53 : ℝ := ((-2 : ℝ)) / (z2)
  have h53 : RB z53 ((-1403931553870139127 : ℝ) / 1000000000000000000) ((-699515155657537719 : ℝ) / 500000000000000000) := rb_div_signed (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z54 : ℝ := (q) ^ 2
  have h54 : RB z54 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z55 : ℝ := ((4 : ℝ)) * (z54)
  have h55 : RB z55 ((1224999999999999 : ℝ) / 250000000000000000) ((4 : ℝ) / 625) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) h54 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z2) ^ 2
  have h56 : RB z56 ((1014701086780824419 : ℝ) / 500000000000000000) ((510911586790298417 : ℝ) / 250000000000000000) := rb_widen (rb_sq h2 (by norm_num)) (by norm_num) (by norm_num)
  let z57 : ℝ := (z55) / (z56)
  have h57 : RB z57 ((479535023934697 : ℝ) / 200000000000000000) ((1576819046361779 : ℝ) / 500000000000000000) := rb_div_signed h55 h56 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z58 : ℝ := (z53) - (z57)
  have h58 : RB z58 ((-281417038392572537 : ℝ) / 200000000000000000) ((-1401427986434748923 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h53 h57) (by norm_num) (by norm_num)
  let z59 : ℝ := (aval q) * (z58)
  have h59 : RB z59 ((-287269634849148449 : ℝ) / 250000000000000000) ((-7060013438022797 : ℝ) / 6250000000000000) := rb_mul_four hp_A h58 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z60 : ℝ := (z52) + (z59)
  have h60 : RB z60 ((11665127698770609861 : ℝ) / 500000000000000000) ((36243225541875674593 : ℝ) / 1000000000000000000) := rb_widen (rb_add h52 h59) (by norm_num) (by norm_num)
  let z61 : ℝ := (z60) - (delta2 q)
  have h61 : RB z61 ((2682904249601051727 : ℝ) / 125000000000000000) ((6878822623168034327 : ℝ) / 200000000000000000) := rb_widen (rb_sub h60 hp_dl2) (by norm_num) (by norm_num)
  have bound_Eqq_61 : RB (Eqq q (v)) ((2682904249601051727 : ℝ) / 125000000000000000) ((6878822623168034327 : ℝ) / 200000000000000000) := by
    have hh := h61
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, Eqq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z62 : ℝ := ((0 : ℝ)) - (Eq q (v))
  have h62 : RB z62 ((-975472177980203617 : ℝ) / 1000000000000000000) ((-487787376034216937 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Eq_17) (by norm_num) (by norm_num)
  let z63 : ℝ := ((0 : ℝ)) - (z62)
  have h63 : RB z63 ((487787376034216937 : ℝ) / 1000000000000000000) ((975472177980203617 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h62) (by norm_num) (by norm_num)
  let z64 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h64 : RB z64 ((400837401479588433 : ℝ) / 200000000000000000) ((409229753890957409 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z65 : ℝ := (z63) / (z64)
  have h65 : RB z65 ((238392918108389471 : ℝ) / 1000000000000000000) ((97343428969402389 : ℝ) / 200000000000000000) := rb_div_signed h63 h64 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r1_65 : RB (rootSlope q (v)) ((238392918108389471 : ℝ) / 1000000000000000000) ((97343428969402389 : ℝ) / 200000000000000000) := by
    have hh := h65
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, rootSlope] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z66 : ℝ := (rootSlope q (v)) ^ 2
  have h66 : RB z66 ((7103897925529161 : ℝ) / 125000000000000000) ((236893579088027207 : ℝ) / 1000000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z67 : ℝ := (Evv q (v)) * (z66)
  have h67 : RB z67 ((126014909654146521 : ℝ) / 500000000000000000) ((16983863454026693 : ℝ) / 15625000000000000) := rb_mul_four bound_Evv_35 h66 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z68 : ℝ := ((2 : ℝ)) * (Evq q (v))
  have h68 : RB z68 ((253955877124882483 : ℝ) / 100000000000000000) ((15383502813768693 : ℝ) / 4000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Evq_46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z69 : ℝ := (z68) * (rootSlope q (v))
  have h69 : RB z69 ((605412826185763287 : ℝ) / 1000000000000000000) ((935926820907934097 : ℝ) / 500000000000000000) := rb_mul_four h68 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z70 : ℝ := (z67) + (z69)
  have h70 : RB z70 ((857442645494056329 : ℝ) / 1000000000000000000) ((1479410451436788273 : ℝ) / 500000000000000000) := rb_widen (rb_add h67 h69) (by norm_num) (by norm_num)
  let z71 : ℝ := (z70) + (Eqq q (v))
  have h71 : RB z71 ((4464135328460494029 : ℝ) / 200000000000000000) ((37352934018713748181 : ℝ) / 1000000000000000000) := rb_widen (rb_add h70 bound_Eqq_61) (by norm_num) (by norm_num)
  let z72 : ℝ := ((0 : ℝ)) - (z71)
  have h72 : RB z72 ((-37352934018713748181 : ℝ) / 1000000000000000000) ((-4464135328460494029 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h71) (by norm_num) (by norm_num)
  let z73 : ℝ := ((0 : ℝ)) - (z72)
  have h73 : RB z73 ((4464135328460494029 : ℝ) / 200000000000000000) ((37352934018713748181 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h72) (by norm_num) (by norm_num)
  let z74 : ℝ := ((0 : ℝ)) - (Ev q (v))
  have h74 : RB z74 ((400837401479588433 : ℝ) / 200000000000000000) ((409229753890957409 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) bound_Ev_25) (by norm_num) (by norm_num)
  let z75 : ℝ := (z73) / (z74)
  have h75 : RB z75 ((10908628431866171533 : ℝ) / 1000000000000000000) ((9318724720007408271 : ℝ) / 500000000000000000) := rb_div_signed h73 h74 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have bound_r2_75 : RB (rootCurvature q (v)) ((10908628431866171533 : ℝ) / 1000000000000000000) ((9318724720007408271 : ℝ) / 500000000000000000) := by
    have hh := h75
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, rootCurvature] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z76 : ℝ := (q) ^ 2
  have h76 : RB z76 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z77 : ℝ := (z76) / (v)
  have h77 : RB z77 ((856172406352211 : ℝ) / 1000000000000000000) ((1121885203066987 : ℝ) / 1000000000000000000) := rb_div_signed h76 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z78 : ℝ := (v) + (z77)
  have h78 : RB z78 ((713513522942136963 : ℝ) / 500000000000000000) ((1431908477846487743 : ℝ) / 1000000000000000000) := rb_widen (rb_add hv h77) (by norm_num) (by norm_num)
  have bound_p_78 : RB (phi q (v)) ((713513522942136963 : ℝ) / 500000000000000000) ((1431908477846487743 : ℝ) / 1000000000000000000) := by
    have hh := h78
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, phi] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z79 : ℝ := (q) ^ 2
  have h79 : RB z79 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z80 : ℝ := (v) ^ 2
  have h80 : RB z80 ((508490840089194547 : ℝ) / 250000000000000000) ((1023575136844085023 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z81 : ℝ := (z79) / (z80)
  have h81 : RB z81 ((598392807672601 : ℝ) / 1000000000000000000) ((786641505537909 : ℝ) / 1000000000000000000) := rb_div_signed h79 h80 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z82 : ℝ := ((1 : ℝ)) - (z81)
  have h82 : RB z82 ((999213358494462091 : ℝ) / 1000000000000000000) ((999401607192327399 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h81) (by norm_num) (by norm_num)
  let z83 : ℝ := (z82) * (rootSlope q (v))
  have h83 : RB z83 ((29775673543047389 : ℝ) / 125000000000000000) ((9728517936163291 : ℝ) / 20000000000000000) := rb_mul_four h82 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z84 : ℝ := ((2 : ℝ)) * (q)
  have h84 : RB z84 ((34999999999999999 : ℝ) / 500000000000000000) ((2 : ℝ) / 25) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z85 : ℝ := (z84) / (v)
  have h85 : RB z85 ((24462068752920349 : ℝ) / 500000000000000000) ((7011782519168667 : ℝ) / 125000000000000000) := rb_div_signed h84 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z86 : ℝ := (z83) + (z85)
  have h86 : RB z86 ((28712952585021981 : ℝ) / 100000000000000000) ((271260078480756943 : ℝ) / 500000000000000000) := rb_widen (rb_add h83 h85) (by norm_num) (by norm_num)
  have bound_p1_86 : RB (psi1 q (v)) ((28712952585021981 : ℝ) / 100000000000000000) ((271260078480756943 : ℝ) / 500000000000000000) := by
    have hh := h86
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, psi1] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z87 : ℝ := (q) ^ 2
  have h87 : RB z87 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z88 : ℝ := ((2 : ℝ)) * (z87)
  have h88 : RB z88 ((1224999999999999 : ℝ) / 500000000000000000) ((2 : ℝ) / 625) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h87 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z89 : ℝ := (v) ^ 2
  have h89 : RB z89 ((508490840089194547 : ℝ) / 250000000000000000) ((1023575136844085023 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z90 : ℝ := (z89) * (v)
  have h90 : RB z90 ((2900779302262115197 : ℝ) / 1000000000000000000) ((732258791179835767 : ℝ) / 250000000000000000) := rb_mul_four h89 hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z91 : ℝ := (z88) / (z90)
  have h91 : RB z91 ((83645291443087 : ℝ) / 100000000000000000) ((1103151831476647 : ℝ) / 1000000000000000000) := rb_div_signed h88 h90 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z92 : ℝ := (rootSlope q (v)) ^ 2
  have h92 : RB z92 ((7103897925529161 : ℝ) / 125000000000000000) ((236893579088027207 : ℝ) / 1000000000000000000) := rb_widen (rb_sq bound_r1_65 (by norm_num)) (by norm_num) (by norm_num)
  let z93 : ℝ := (z91) * (z92)
  have h93 : RB z93 ((23768304494513 : ℝ) / 500000000000000000) ((16333099102251 : ℝ) / 62500000000000000) := rb_mul_four h91 h92 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z94 : ℝ := ((4 : ℝ)) * (q)
  have h94 : RB z94 ((34999999999999999 : ℝ) / 250000000000000000) ((4 : ℝ) / 25) := rb_mul_four (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z95 : ℝ := (v) ^ 2
  have h95 : RB z95 ((508490840089194547 : ℝ) / 250000000000000000) ((1023575136844085023 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z96 : ℝ := (z94) / (z95)
  have h96 : RB z96 ((68387749448297387 : ℝ) / 1000000000000000000) ((629313204430327 : ℝ) / 8000000000000000) := rb_div_signed h94 h95 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z97 : ℝ := (z96) * (rootSlope q (v))
  have h97 : RB z97 ((2037894394230627 : ℝ) / 125000000000000000) ((38287190759356589 : ℝ) / 1000000000000000000) := rb_mul_four h96 bound_r1_65 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z98 : ℝ := (z93) - (z97)
  have h98 : RB z98 ((-38239654150367563 : ℝ) / 1000000000000000000) ((-16041825568209 : ℝ) / 1000000000000000) := rb_widen (rb_sub h93 h97) (by norm_num) (by norm_num)
  let z99 : ℝ := ((2 : ℝ)) / (v)
  have h99 : RB z99 ((1397832500166877127 : ℝ) / 1000000000000000000) ((5477955093100521 : ℝ) / 3906250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hv (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z100 : ℝ := (z98) + (z99)
  have h100 : RB z100 ((339898211504127391 : ℝ) / 250000000000000000) ((173289334783190547 : ℝ) / 125000000000000000) := rb_widen (rb_add h98 h99) (by norm_num) (by norm_num)
  let z101 : ℝ := (q) ^ 2
  have h101 : RB z101 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z102 : ℝ := (v) ^ 2
  have h102 : RB z102 ((508490840089194547 : ℝ) / 250000000000000000) ((1023575136844085023 : ℝ) / 500000000000000000) := rb_widen (rb_sq hv (by norm_num)) (by norm_num) (by norm_num)
  let z103 : ℝ := (z101) / (z102)
  have h103 : RB z103 ((598392807672601 : ℝ) / 1000000000000000000) ((786641505537909 : ℝ) / 1000000000000000000) := rb_div_signed h101 h102 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z104 : ℝ := ((1 : ℝ)) - (z103)
  have h104 : RB z104 ((999213358494462091 : ℝ) / 1000000000000000000) ((999401607192327399 : ℝ) / 1000000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h103) (by norm_num) (by norm_num)
  let z105 : ℝ := (z104) * (rootCurvature q (v))
  have h105 : RB z105 ((340626476624161709 : ℝ) / 31250000000000000) ((18626296924316549931 : ℝ) / 1000000000000000000) := rb_mul_four h104 bound_r2_75 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z106 : ℝ := (z100) + (z105)
  have h106 : RB z106 ((3064910024497421063 : ℝ) / 250000000000000000) ((20012611602582074307 : ℝ) / 1000000000000000000) := rb_widen (rb_add h100 h105) (by norm_num) (by norm_num)
  have bound_p2_106 : RB (psi2 q (v)) ((3064910024497421063 : ℝ) / 250000000000000000) ((20012611602582074307 : ℝ) / 1000000000000000000) := by
    have hh := h106
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, z57, z58, z59, z60, z61, z62, z63, z64, z65, z66, z67, z68, z69, z70, z71, z72, z73, z74, z75, z76, z77, z78, z79, z80, z81, z82, z83, z84, z85, z86, z87, z88, z89, z90, z91, z92, z93, z94, z95, z96, z97, z98, z99, z100, z101, z102, z103, z104, z105, z106, psi2] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_p_78, bound_p1_86, bound_p2_106⟩

theorem dlower_m_13_slab_minus_lo_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((285234174695584343 : ℝ) / 200000000000000000) ((285234174695584343 : ℝ) / 200000000000000000)) :
    RB (E q (v)) ((1171374761253921 : ℝ) / 250000000000000000) ((4685499045015701 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((93013326147291741 : ℝ) / 125000000000000000) ((744106609178334051 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((284952924695584343 : ℝ) / 200000000000000000) ((356191155869480429 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-85234174695584343 : ℝ) / 200000000000000000) ((-85234174695584343 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((177003311785375343 : ℝ) / 500000000000000000) ((354006623570750689 : ℝ) / 1000000000000000000) := rb_log h2 (by norm_num) dlower_m_log_666.1 dlower_m_log_667.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((85234174695584343 : ℝ) / 200000000000000000) ((85234174695584343 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-213228725421484713 : ℝ) / 250000000000000000) ((-17058298033718777 : ℝ) / 20000000000000000) := rb_log h5 (by norm_num) dlower_m_log_662.1 dlower_m_log_662.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((9429074416067887 : ℝ) / 7812500000000000) ((1206921525256689541 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((489598937648151773 : ℝ) / 500000000000000000) ((244799468824075889 : ℝ) / 250000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35499314193677517 : ℝ) / 100000000000000000) ((88748285484193793 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_664.1 dlower_m_log_664.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((312102366679764187 : ℝ) / 500000000000000000) ((312102366679764193 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((1171374761253921 : ℝ) / 250000000000000000) ((4685499045015701 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((1171374761253921 : ℝ) / 250000000000000000) ((4685499045015701 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-228179240236864787 : ℝ) / 200000000000000000) ((-1140896201184323817 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-13160068470980359 : ℝ) / 250000000000000000) ((-26320136941960717 : ℝ) / 500000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-2669252063177257 : ℝ) / 62500000000000000) ((-4270803301083611 : ℝ) / 100000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1183604234195160047 : ℝ) / 1000000000000000000) ((-1183604234195159927 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((93013326147291741 : ℝ) / 125000000000000000) ((744106609178334051 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((93013326147291741 : ℝ) / 125000000000000000) ((744106609178334051 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_13_slab_minus_lo_slope {q v : ℝ} (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25))
    (hv : RB v ((285234174695584343 : ℝ) / 200000000000000000) ((285234174695584343 : ℝ) / 200000000000000000)) :
    RB (E q (v)) ((-662425009437271 : ℝ) / 100000000000000000) ((80111835515513 : ℝ) / 5000000000000000) ∧
    RB (Eq q (v)) ((122875015520467359 : ℝ) / 250000000000000000) ((483540552027460611 : ℝ) / 500000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((284914174695584343 : ℝ) / 200000000000000000) ((356236468369480429 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-85234174695584343 : ℝ) / 200000000000000000) ((-85234174695584343 : ℝ) / 200000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((353870626949429247 : ℝ) / 1000000000000000000) ((177066914737478031 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_660.1 dlower_m_log_668.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((85234174695584343 : ℝ) / 200000000000000000) ((85234174695584343 : ℝ) / 200000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-213228725421484713 : ℝ) / 250000000000000000) ((-17058298033718777 : ℝ) / 20000000000000000) := rb_log h5 (by norm_num) dlower_m_log_662.1 dlower_m_log_662.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((1206785528635368097 : ℝ) / 1000000000000000000) ((603524365580447457 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((486356609483841491 : ℝ) / 500000000000000000) ((197144252658652097 : ℝ) / 200000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((35499314193677517 : ℝ) / 100000000000000000) ((88748285484193793 : ℝ) / 250000000000000000) := rb_log hv (by norm_num) dlower_m_log_664.1 dlower_m_log_664.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((61772007703090781 : ℝ) / 100000000000000000) ((126145624271297063 : ℝ) / 200000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-662425009437271 : ℝ) / 100000000000000000) ((80111835515513 : ℝ) / 5000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-662425009437271 : ℝ) / 100000000000000000) ((80111835515513 : ℝ) / 5000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-1385716734584840721 : ℝ) / 1000000000000000000) ((-925689764825164893 : ℝ) / 1000000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-28078631077402783 : ℝ) / 500000000000000000) ((-24562336472875363 : ℝ) / 500000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-45860126410212919 : ℝ) / 1000000000000000000) ((-19798140439183997 : ℝ) / 500000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-35789421524876341 : ℝ) / 25000000000000000) ((-965286045703532887 : ℝ) / 1000000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((122875015520467359 : ℝ) / 250000000000000000) ((483540552027460611 : ℝ) / 500000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((122875015520467359 : ℝ) / 250000000000000000) ((483540552027460611 : ℝ) / 500000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_13_slab_minus_hi_center {q v : ℝ} (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hv : RB v ((357696648160855189 : ℝ) / 250000000000000000) ((357696648160855189 : ℝ) / 250000000000000000)) :
    RB (E q (v)) ((-932294671181931 : ℝ) / 200000000000000000) ((-4661473355909639 : ℝ) / 1000000000000000000) ∧
    RB (Eq q (v)) ((751370193385818711 : ℝ) / 1000000000000000000) ((751370193385818833 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1406249999999999 : ℝ) / 1000000000000000000) ((9 : ℝ) / 6400) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((357345085660855189 : ℝ) / 250000000000000000) ((1429380342643420757 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-107696648160855189 : ℝ) / 250000000000000000) ((-107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((714482047071669 : ℝ) / 2000000000000000) ((178620511767917251 : ℝ) / 500000000000000000) := rb_log h2 (by norm_num) dlower_m_log_669.1 dlower_m_log_670.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((107696648160855189 : ℝ) / 250000000000000000) ((107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-105267807022729191 : ℝ) / 125000000000000000) ((-421071228090916763 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_663.1 dlower_m_log_663.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((599691739858834013 : ℝ) / 500000000000000000) ((119938347971766803 : ℝ) / 100000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((973082118785848741 : ℝ) / 1000000000000000000) ((778465695028679 : ℝ) / 800000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((44778044728405713 : ℝ) / 125000000000000000) ((179112178913622853 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_665.1 dlower_m_log_665.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((122971552191720607 : ℝ) / 200000000000000000) ((307428880479301523 : ℝ) / 500000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-932294671181931 : ℝ) / 200000000000000000) ((-4661473355909639 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-932294671181931 : ℝ) / 200000000000000000) ((-4661473355909639 : ℝ) / 1000000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-22675410573725513 : ℝ) / 20000000000000000) ((-566885264343137767 : ℝ) / 500000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-3 : ℝ) / 40) ((-37499999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-2098811569251021 : ℝ) / 40000000000000000) ((-52470289231275523 : ℝ) / 1000000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-21285060650699807 : ℝ) / 500000000000000000) ((-42570121301399611 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-9190161328028713 : ℝ) / 7812500000000000) ((-235268129997535029 : ℝ) / 200000000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((751370193385818711 : ℝ) / 1000000000000000000) ((751370193385818833 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((751370193385818711 : ℝ) / 1000000000000000000) ((751370193385818833 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_13_slab_minus_hi_slope {q v : ℝ} (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25))
    (hv : RB v ((357696648160855189 : ℝ) / 250000000000000000) ((357696648160855189 : ℝ) / 250000000000000000)) :
    RB (E q (v)) ((-7965526023723817 : ℝ) / 500000000000000000) ((663496508789369 : ℝ) / 100000000000000000) ∧
    RB (Eq q (v)) ((500302475171484433 : ℝ) / 1000000000000000000) ((972990827796133357 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_slab hq
  have hlog : Real.log (1-v) = Real.log (v-1) := by
    rw [show 1-v = -(v-1) by ring, Real.log_neg_eq_log]
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1224999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (v) - (z1)
  have h2 : RB z2 ((357296648160855189 : ℝ) / 250000000000000000) ((1429561592643420757 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hv h1) (by norm_num) (by norm_num)
  let z3 : ℝ := ((1 : ℝ)) - (v)
  have h3 : RB z3 ((-107696648160855189 : ℝ) / 250000000000000000) ((-107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hv) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z2)
  have h4 : RB z4 ((178552733050579903 : ℝ) / 500000000000000000) ((35736781869596401 : ℝ) / 100000000000000000) := rb_log h2 (by norm_num) dlower_m_log_671.1 dlower_m_log_661.2
  let z5 : ℝ := (v) - ((1 : ℝ))
  have h5 : RB z5 ((107696648160855189 : ℝ) / 250000000000000000) ((107696648160855189 : ℝ) / 250000000000000000) := rb_widen (rb_sub hv (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z5)
  have h6 : RB z6 ((-105267807022729191 : ℝ) / 125000000000000000) ((-421071228090916763 : ℝ) / 500000000000000000) := rb_log h5 (by norm_num) dlower_m_log_663.1 dlower_m_log_663.2
  let z7 : ℝ := (z4) - (z6)
  have h7 : RB z7 ((299811980570748333 : ℝ) / 250000000000000000) ((599755137438898769 : ℝ) / 500000000000000000) := rb_widen (rb_sub h4 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (aval q) * (z7)
  have h8 : RB z8 ((15103713014141853 : ℝ) / 15625000000000000) ((979565077168522109 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := Real.log (v)
  have h9 : RB z9 ((44778044728405713 : ℝ) / 125000000000000000) ((179112178913622853 : ℝ) / 500000000000000000) := rb_log hv (by norm_num) dlower_m_log_665.1 dlower_m_log_665.2
  let z10 : ℝ := (z8) - (z9)
  have h10 : RB z10 ((304206637538916443 : ℝ) / 500000000000000000) ((124268143868255281 : ℝ) / 200000000000000000) := rb_widen (rb_sub h8 h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) - (delta q)
  have h11 : RB z11 ((-7965526023723817 : ℝ) / 500000000000000000) ((663496508789369 : ℝ) / 100000000000000000) := rb_widen (rb_sub h10 hp_dl) (by norm_num) (by norm_num)
  have bound_E_11 : RB (E q (v)) ((-7965526023723817 : ℝ) / 500000000000000000) ((663496508789369 : ℝ) / 100000000000000000) := by
    have hh := h11
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, E] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  let z12 : ℝ := (aval1 q) * (z7)
  have h12 : RB z12 ((-172132803992718829 : ℝ) / 125000000000000000) ((-183981577637999583 : ℝ) / 200000000000000000) := rb_mul_four hp_A1 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((-2 : ℝ)) * (q)
  have h13 : RB z13 ((-2 : ℝ) / 25) ((-34999999999999999 : ℝ) / 500000000000000000) := rb_mul_four (show RB (-2 : ℝ) (-2 : ℝ) (-2 : ℝ) from ⟨le_rfl, le_rfl⟩) hq (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) / (z2)
  have h14 : RB z14 ((-27987947973970339 : ℝ) / 500000000000000000) ((-24483030448013819 : ℝ) / 500000000000000000) := rb_div_signed h13 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := (aval q) * (z14)
  have h15 : RB z15 ((-45712015963688011 : ℝ) / 1000000000000000000) ((-39468433772322837 : ℝ) / 1000000000000000000) := rb_mul_four hp_A h14 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z16 : ℝ := (z12) + (z15)
  have h16 : RB z16 ((-1422774447905438643 : ℝ) / 1000000000000000000) ((-59961020122645047 : ℝ) / 62500000000000000) := rb_widen (rb_add h12 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) - (delta1 q)
  have h17 : RB z17 ((500302475171484433 : ℝ) / 1000000000000000000) ((972990827796133357 : ℝ) / 1000000000000000000) := rb_widen (rb_sub h16 hp_dl1) (by norm_num) (by norm_num)
  have bound_Eq_17 : RB (Eq q (v)) ((500302475171484433 : ℝ) / 1000000000000000000) ((972990827796133357 : ℝ) / 1000000000000000000) := by
    have hh := h17
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, Eq] <;> try simp only [hlog, Real.log_abs, div_pow, one_pow, zero_sub, neg_div, div_neg, neg_neg, neg_sq, neg_mul, mul_neg, ←pow_mul, ←pow_succ, Nat.reduceMul, Nat.reduceAdd] <;> ring_nf
  exact ⟨bound_E_11, bound_Eq_17⟩

theorem dlower_m_13_point_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((37499999999999999 : ℝ) / 1000000000000000000) ((3 : ℝ) / 80))
    (hplus : RB (vPlus q) ((436858947545871 : ℝ) / 1000000000000000) ((218429473772937 : ℝ) / 500000000000000))
    (hminus : RB (vMinus q) ((142847873306067 : ℝ) / 100000000000000) ((1428478733060673 : ℝ) / 1000000000000000)) :
RB (Lam q) ((459577980893989251 : ℝ) / 250000000000000000) ((1838311923575968213 : ℝ) / 1000000000000000000) ∧
    RB (lam1 q) ((305896575110685609 : ℝ) / 500000000000000000) ((611793150221563829 : ℝ) / 1000000000000000000) ∧
    RB (lam2 q) ((20810272424031468821 : ℝ) / 500000000000000000) ((41620544848070684043 : ℝ) / 1000000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_point hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_13_point_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_13_point_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((197877044398668247 : ℝ) / 200000000000000000) ((15459144093646051 : ℝ) / 15625000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((2236517606012803457 : ℝ) / 1000000000000000000) ((2236517606012895481 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((25508090011715825211 : ℝ) / 1000000000000000000) ((797127812866237681 : ℝ) / 31250000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((459577980893989251 : ℝ) / 250000000000000000) ((1838311923575968213 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-1771866914290089847 : ℝ) / 500000000000000000) ((-1771866914290079041 : ℝ) / 500000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((64930109043774233 : ℝ) / 15625000000000000) ((4155526978801721911 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((305896575110685609 : ℝ) / 500000000000000000) ((611793150221563829 : ℝ) / 1000000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((10246941191075155899 : ℝ) / 1000000000000000000) ((2561735297768804601 : ℝ) / 250000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-3581753345214214401 : ℝ) / 500000000000000000) ((-223859584075888399 : ℝ) / 31250000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-4005327208483587391 : ℝ) / 250000000000000000) ((-500665901060427821 : ℝ) / 31250000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-1154873528571838733 : ℝ) / 200000000000000000) ((-1443591910714617967 : ℝ) / 250000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((47394912490922131307 : ℝ) / 1000000000000000000) ((47394912490929155911 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((20810272424031468821 : ℝ) / 500000000000000000) ((41620544848070684043 : ℝ) / 1000000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((459577980893989251 : ℝ) / 250000000000000000) ((1838311923575968213 : ℝ) / 1000000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((305896575110685609 : ℝ) / 500000000000000000) ((611793150221563829 : ℝ) / 1000000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((20810272424031468821 : ℝ) / 500000000000000000) ((41620544848070684043 : ℝ) / 1000000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

theorem dlower_m_13_slab_width {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((34999999999999999 : ℝ) / 1000000000000000000) ((1 : ℝ) / 25))
    (hplus : RB (vPlus q) ((53825556371276643 : ℝ) / 125000000000000000) ((110778361030382941 : ℝ) / 250000000000000000))
    (hminus : RB (vMinus q) ((285234174695584343 : ℝ) / 200000000000000000) ((357696648160855189 : ℝ) / 250000000000000000)) :
RB (Lam q) ((181249610706239949 : ℝ) / 100000000000000000) ((74571784474844579 : ℝ) / 40000000000000000) ∧
    RB (lam1 q) ((-207001565418312857 : ℝ) / 1000000000000000000) ((384936791239473781 : ℝ) / 250000000000000000) ∧
    RB (lam2 q) ((9008003754937943697 : ℝ) / 1000000000000000000) ((4394470292427875553 : ℝ) / 50000000000000000) := by
  obtain ⟨hp_dl, hp_dl1, hp_dl2, hp_A, hp_A1, hp_A2, hp_D0, hp_D01, hp_D02⟩ := dlower_m_param_13_slab hq
  obtain ⟨hp_plus0, hp_plus1, hp_plus2⟩ := dlower_m_13_slab_plus_branch hq hplus
  obtain ⟨hp_minus0, hp_minus1, hp_minus2⟩ := dlower_m_13_slab_minus_branch hq hminus
  let z1 : ℝ := (phi q (vMinus q)) - (phi q (vPlus q))
  have h1 : RB z1 ((196039578939869129 : ℝ) / 200000000000000000) ((499269748900408649 : ℝ) / 500000000000000000) := rb_widen (rb_sub hp_minus0 hp_plus0) (by norm_num) (by norm_num)
  let z2 : ℝ := (psi1 q (vMinus q)) - (psi1 q (vPlus q))
  have h2 : RB z2 ((1836286454097909179 : ℝ) / 1000000000000000000) ((2691622388283240299 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus1 hp_plus1) (by norm_num) (by norm_num)
  let z3 : ℝ := (psi2 q (vMinus q)) - (psi2 q (vPlus q))
  have h3 : RB z3 ((1242149321972422169 : ℝ) / 125000000000000000) ((48476674005712502403 : ℝ) / 1000000000000000000) := rb_widen (rb_sub hp_minus2 hp_plus2) (by norm_num) (by norm_num)
  let z4 : ℝ := (D0q q) * (z1)
  have h4 : RB z4 ((181249610706239949 : ℝ) / 100000000000000000) ((74571784474844579 : ℝ) / 40000000000000000) := rb_mul_four hp_D0 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (d01 q) * (z1)
  have h5 : RB z5 ((-3602501665451428941 : ℝ) / 1000000000000000000) ((-3485569436658460559 : ℝ) / 1000000000000000000) := rb_mul_four hp_D01 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := (D0q q) * (z2)
  have h6 : RB z6 ((848875025008279021 : ℝ) / 250000000000000000) ((5025316601616355683 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) + (z6)
  have h7 : RB z7 ((-207001565418312857 : ℝ) / 1000000000000000000) ((384936791239473781 : ℝ) / 250000000000000000) := rb_widen (rb_add h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := (d02 q) * (z1)
  have h8 : RB z8 ((10054527221130174693 : ℝ) / 1000000000000000000) ((5221016906451346299 : ℝ) / 500000000000000000) := rb_mul_four hp_D02 h1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := ((2 : ℝ)) * (d01 q)
  have h9 : RB z9 ((-450971352834011089 : ℝ) / 62500000000000000) ((-711197086936731907 : ℝ) / 100000000000000000) := rb_mul_four (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hp_D01 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) * (z2)
  have h10 : RB z10 ((-19421513436198476093 : ℝ) / 1000000000000000000) ((-13059615769358138787 : ℝ) / 1000000000000000000) := rb_mul_four h9 h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z11 : ℝ := (z8) + (z10)
  have h11 : RB z11 ((-46834931075341507 : ℝ) / 5000000000000000) ((-2617581956455446189 : ℝ) / 1000000000000000000) := rb_widen (rb_add h8 h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (D0q q) * (z3)
  have h12 : RB z12 ((18374989970006245097 : ℝ) / 1000000000000000000) ((90506987805012957249 : ℝ) / 1000000000000000000) := rb_mul_four hp_D0 h3 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := (z11) + (z12)
  have h13 : RB z13 ((9008003754937943697 : ℝ) / 1000000000000000000) ((4394470292427875553 : ℝ) / 50000000000000000) := rb_widen (rb_add h11 h12) (by norm_num) (by norm_num)
  have hf0 : RB (Lam q) ((181249610706239949 : ℝ) / 100000000000000000) ((74571784474844579 : ℝ) / 40000000000000000) := by
    rw [Lam_eq_actual_roots hqa]
    have hh := h4
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf1 : RB (lam1 q) ((-207001565418312857 : ℝ) / 1000000000000000000) ((384936791239473781 : ℝ) / 250000000000000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  have hf2 : RB (lam2 q) ((9008003754937943697 : ℝ) / 1000000000000000000) ((4394470292427875553 : ℝ) / 50000000000000000) := by
    have hh := h13
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, lam1, lam2] <;> ring
  exact ⟨hf0, hf1, hf2⟩

end EP1038.DLowerCert
