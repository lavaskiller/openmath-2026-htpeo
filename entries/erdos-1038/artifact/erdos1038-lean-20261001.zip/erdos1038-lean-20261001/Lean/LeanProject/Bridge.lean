import LeanProject.Quantile
import Mathlib.Algebra.Polynomial.Roots

/-!
# EP-1038: bridge from root multisets to polynomials of the class 𝒫 (Stage 15, seventh batch)

The class 𝒫 of problem.md is encoded as: `p : ℝ[X]` monic, `1 ≤ natDegree p`, splitting over ℝ
(`card p.roots = natDegree p`), all roots in `[-1,1]`. These lemmas (taken from the Lean RED Review 2
scratch file, findings L-06/L-07) restate the product-form results for every such `p`.

* `polyOf_monic`, `polyOf_roots`, `polyOf_natDegree`, `polyOf_of_split` — `polyOf s` is exactly the
  monic polynomial with root multiset `s`, and every split monic `p` is `polyOf p.roots`.
* `mean_nonpos_iff` — mean `≤ 0` iff sum `≤ 0` for a nonempty multiset.
* `lemma73` — Lemma 7.3: root mean `≤ 0` implies `(-1, 0) ⊆ {|p| < 1}`.
* `lemma11a_core`, `lemma11a` — Lemma 1.1(a): `{|p| < 1} ⊆ (min r - 1, max r + 1) ⊆ (-2, 2)`.
* `thm67_alg` — Theorem 6.7, algebraic part: `|p(±√2)| = 1` forces `p = (X^2-1)^m`, `m ≥ 1`.
-/

open Real Polynomial

namespace EP1038

theorem polyOf_monic (s : Multiset ℝ) : (polyOf s).Monic := by
  unfold polyOf
  exact monic_multiset_prod_of_monic _ _ (fun r _ => monic_X_sub_C r)

theorem polyOf_roots (s : Multiset ℝ) : (polyOf s).roots = s := by
  unfold polyOf; exact roots_multiset_prod_X_sub_C s

theorem polyOf_natDegree (s : Multiset ℝ) : (polyOf s).natDegree = Multiset.card s := by
  unfold polyOf; exact natDegree_multiset_prod_X_sub_C_eq_card s

/-- Every monic real polynomial that splits over ℝ is `polyOf` of its root multiset. -/
theorem polyOf_of_split (p : ℝ[X]) (hm : p.Monic)
    (hsplit : Multiset.card p.roots = p.natDegree) : polyOf p.roots = p := by
  unfold polyOf; exact prod_multiset_X_sub_C_of_monic_of_roots_card_eq hm hsplit

theorem mean_nonpos_iff (s : Multiset ℝ) (hne : s ≠ 0) :
    s.sum / (Multiset.card s : ℝ) ≤ 0 ↔ s.sum ≤ 0 := by
  have hc : (0 : ℝ) < Multiset.card s := by exact_mod_cast Multiset.card_pos.mpr hne
  rw [div_le_iff₀ hc, zero_mul]

/-- Lemma 7.3 for every `p ∈ 𝒫` (mean form, set inclusion). -/
theorem lemma73 (p : ℝ[X]) (hm : p.Monic) (hdeg : 1 ≤ p.natDegree)
    (hsplit : Multiset.card p.roots = p.natDegree)
    (hroots : ∀ r ∈ p.roots, r ∈ Set.Icc (-1 : ℝ) 1)
    (hmean : p.roots.sum / (Multiset.card p.roots : ℝ) ≤ 0) :
    Set.Ioo (-1 : ℝ) 0 ⊆ {x | |p.eval x| < 1} := by
  intro x hx
  have hne : p.roots ≠ 0 := by
    intro h; rw [h] at hsplit; simp at hsplit; omega
  have hsum : p.roots.sum ≤ 0 := (mean_nonpos_iff _ hne).mp hmean
  have h := orientation_poly p.roots hroots hne hsum hx.1 hx.2
  have hp := polyOf_of_split p hm hsplit
  unfold polyOf at hp
  rw [hp] at h
  exact h

/-- Lemma 1.1(a), core: a point of `{|polyOf s| < 1}` is within distance `< 1` of some root on
each side. -/
theorem lemma11a_core (s : Multiset ℝ) (x : ℝ) (hx : |(polyOf s).eval x| < 1) :
    (∃ r ∈ s, x < r + 1) ∧ (∃ r ∈ s, r - 1 < x) := by
  unfold polyOf at hx; rw [abs_eval_prod] at hx
  constructor
  · by_contra h; push_neg at h
    have := localisation_one_le_prod s (x := x) (fun r hr => by
      have := h r hr; rw [abs_of_nonneg (by linarith)]; linarith)
    linarith
  · by_contra h; push_neg at h
    have := localisation_one_le_prod s (x := x) (fun r hr => by
      have := h r hr; rw [abs_of_nonpos (by linarith)]; linarith)
    linarith

/-- Lemma 1.1(a): for roots in `[-1,1]`, `{|polyOf s| < 1} ⊆ (-2, 2)`. -/
theorem lemma11a (s : Multiset ℝ) (hs : ∀ r ∈ s, r ∈ Set.Icc (-1 : ℝ) 1) :
    {x | |(polyOf s).eval x| < 1} ⊆ Set.Ioo (-2) 2 := by
  intro x hx
  obtain ⟨⟨r, hr, h1⟩, ⟨r', hr', h2⟩⟩ := lemma11a_core s x hx
  exact ⟨by linarith [(hs r' hr').1], by linarith [(hs r hr).2]⟩

/-- Theorem 6.7, algebraic part, for every `p ∈ 𝒫`: `|p(±√2)| = 1` forces `p = (X^2-1)^m`, `m ≥ 1`. -/
theorem thm67_alg (p : ℝ[X]) (hm : p.Monic) (hdeg : 1 ≤ p.natDegree)
    (hsplit : Multiset.card p.roots = p.natDegree)
    (hroots : ∀ r ∈ p.roots, r ∈ Set.Icc (-1 : ℝ) 1)
    (h1 : |p.eval √2| = 1) (h2 : |p.eval (-√2)| = 1) :
    ∃ m : ℕ, 1 ≤ m ∧ p = (X ^ 2 - 1) ^ m := by
  have hp := polyOf_of_split p hm hsplit
  rw [← hp] at h1 h2
  obtain ⟨m, hm'⟩ := eq_case_poly p.roots hroots h1 h2
  rw [hp] at hm'
  refine ⟨m, ?_, hm'⟩
  rcases Nat.eq_zero_or_pos m with rfl | hpos
  · rw [hm'] at hdeg; simp at hdeg
  · exact hpos

end EP1038
