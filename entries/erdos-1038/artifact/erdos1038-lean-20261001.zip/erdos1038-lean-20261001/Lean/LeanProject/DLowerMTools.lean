import LeanProject.DLowerProgress
import Mathlib.Analysis.Calculus.Taylor

open Real Set Filter Topology
open scoped ContDiff
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert

theorem rb_mul_four {x y l u a b lo hi : ℝ} (hx : RB x l u) (hy : RB y a b)
    (h1 : lo ≤ l*a) (h2 : lo ≤ l*b) (h3 : lo ≤ u*a) (h4 : lo ≤ u*b)
    (h5 : l*a ≤ hi) (h6 : l*b ≤ hi) (h7 : u*a ≤ hi) (h8 : u*b ≤ hi) :
    RB (x*y) lo hi := by
  by_cases hy0 : 0 ≤ y
  · constructor
    · have h := mul_le_mul_of_nonneg_right hx.1 hy0
      by_cases hl : 0 ≤ l
      · exact h1.trans ((mul_le_mul_of_nonneg_left hy.1 hl).trans h)
      · exact h2.trans ((mul_le_mul_of_nonpos_left hy.2 (le_of_not_ge hl)).trans h)
    · have h := mul_le_mul_of_nonneg_right hx.2 hy0
      by_cases hu : 0 ≤ u
      · exact (h.trans (mul_le_mul_of_nonneg_left hy.2 hu)).trans h8
      · exact (h.trans (mul_le_mul_of_nonpos_left hy.1 (le_of_not_ge hu))).trans h7
  · have hy0' : y ≤ 0 := le_of_not_ge hy0
    constructor
    · have h := mul_le_mul_of_nonpos_right hx.2 hy0'
      by_cases hu : 0 ≤ u
      · exact h3.trans ((mul_le_mul_of_nonneg_left hy.1 hu).trans h)
      · exact h4.trans ((mul_le_mul_of_nonpos_left hy.2 (le_of_not_ge hu)).trans h)
    · have h := mul_le_mul_of_nonpos_right hx.1 hy0'
      by_cases hl : 0 ≤ l
      · exact (h.trans (mul_le_mul_of_nonneg_left hy.2 hl)).trans h6
      · exact (h.trans (mul_le_mul_of_nonpos_left hy.1 (le_of_not_ge hl))).trans h5

theorem rb_sq_cross {x l u hi : ℝ} (hx : RB x l u) (hl : l ≤ 0) (hu : 0 ≤ u)
    (h1 : l^2 ≤ hi) (h2 : u^2 ≤ hi) : RB (x^2) 0 hi := by
  constructor
  · positivity
  · by_cases h : 0 ≤ x
    · nlinarith [mul_nonneg h (sub_nonneg.mpr hx.2)]
    · have h' : x ≤ 0 := le_of_not_ge h
      nlinarith [mul_nonneg (neg_nonneg.mpr h') (sub_nonneg.mpr hx.1)]

theorem plus_sign_neg {q v : ℝ} (hq : q ∈ Qadm) (hvq : q < v) (hv1 : v < 1) :
    E q v < 0 ↔ v < vPlus q := by
  have hv0 := hq.1.trans hvq
  have hp0 := hq.1.trans (pPlus_spec hq).1
  have hqp : q < q / v := (lt_div_iff₀ hv0).mpr (by
    nlinarith [mul_pos hq.1 (sub_pos.mpr hv1)])
  have hp1 : q / v < 1 := (div_lt_one hv0).mpr hvq
  rw [E_eq_GA hq.1 hq.2.1 hvq hv1.ne, (pPlus_spec hq).2.2.2.2 _ hqp hp1]
  rw [lt_div_iff₀ hv0, vPlus, lt_div_iff₀ hp0]
  constructor <;> intro h <;> nlinarith

theorem minus_sign_neg {q v : ℝ} (hq : q ∈ Qadm) (hv1 : 1 < v) :
    E q v < 0 ↔ vMinus q < v := by
  have hv0 := zero_lt_one.trans hv1
  have hp := pMinus_spec hq
  have hpq : q / v < q := (div_lt_iff₀ hv0).mpr (by nlinarith)
  rw [E_eq_GA hq.1 hq.2.1 (hq.2.1.trans hv1) hv1.ne',
    hp.2.2.2.2 _ (div_pos hq.1 hv0) hpq, vMinus,
    div_lt_iff₀ hp.1, div_lt_iff₀ hv0]
  constructor <;> intro h <;> nlinarith

theorem roots_box_of_signs {q pl pu ml mu : ℝ} (hq : q ∈ Qadm)
    (hpl : q < pl) (hpu : pu < 1) (hpo : pl ≤ pu) (hml : 1 < ml) (hmo : ml ≤ mu)
    (hepl : E q pl < 0) (hepu : 0 < E q pu)
    (heml : 0 < E q ml) (hemu : E q mu < 0) :
    RB (vPlus q) pl pu ∧ RB (vMinus q) ml mu := by
  exact ⟨⟨((plus_sign_neg hq hpl (hpo.trans_lt hpu)).mp hepl).le,
    ((plus_sign_pos hq (hpl.trans_le hpo) hpu).mp hepu).le⟩,
    ⟨((minus_sign_pos hq hml).mp heml).le,
    ((minus_sign_neg hq (hml.trans_le hmo)).mp hemu).le⟩⟩

theorem hasDerivAt_E_fixed {q v : ℝ} (hq : q ∈ Qadm)
    (hx : v-q^2 ≠ 0) (hy : 1-v ≠ 0) (hv : v ≠ 0) :
    HasDerivAt (fun x => E x v) (Eq q v) q := by
  simpa using hasDerivAt_E_along hq (hasDerivAt_const q v) hx hy hv

/-- A signed mean-value enclosure, also valid when the evaluation point is left of the center. -/
theorem E_mean_value {a b m q v : ℝ} (hab : a ≤ b) (hm : m ∈ Icc a b)
    (hq : q ∈ Icc a b) (hadm : ∀ x ∈ Icc a b, x ∈ Qadm)
    (hx : ∀ x ∈ Icc a b, v-x^2 ≠ 0) (hy : 1-v ≠ 0) (hv : v ≠ 0) :
    ∃ c ∈ Icc a b, E q v = E m v + Eq c v * (q-m) := by
  have hd : ∀ x ∈ Icc a b, HasDerivAt (fun x => E x v) (Eq x v) x :=
    fun x h => hasDerivAt_E_fixed (hadm x h) (hx x h) hy hv
  have hc : ContinuousOn (fun x => E x v) (Icc a b) := fun x h => (hd x h).continuousAt.continuousWithinAt
  rcases lt_trichotomy m q with h | h | h
  · have hs : Icc m q ⊆ Icc a b := Icc_subset_Icc hm.1 hq.2
    obtain ⟨c, hcm, he⟩ := exists_hasDerivAt_eq_slope (fun x => E x v) (fun x => Eq x v) h
      (hc.mono hs) (fun x hx => hd x (hs (Ioo_subset_Icc_self hx)))
    refine ⟨c, hs (Ioo_subset_Icc_self hcm), ?_⟩
    have := (eq_div_iff (sub_ne_zero.mpr h.ne')).mp he
    linarith
  · subst q; exact ⟨m, hm, by ring⟩
  · have hs : Icc q m ⊆ Icc a b := Icc_subset_Icc hq.1 hm.2
    obtain ⟨c, hcm, he⟩ := exists_hasDerivAt_eq_slope (fun x => E x v) (fun x => Eq x v) h
      (hc.mono hs) (fun x hx => hd x (hs (Ioo_subset_Icc_self hx)))
    refine ⟨c, hs (Ioo_subset_Icc_self hcm), ?_⟩
    have := (eq_div_iff (sub_ne_zero.mpr h.ne')).mp he
    nlinarith

/-- The true second-order Taylor inequality, with a certified curvature lower bound. -/
theorem Lam_taylor_lower {a b m q M : ℝ} (hm : m ∈ Icc a b) (hq : q ∈ Icc a b)
    (hadm : ∀ x ∈ Icc a b, x ∈ Qadm) (hM : ∀ x ∈ Icc a b, M ≤ lam2 x) :
    Lam m + lam1 m * (q-m) + M * (q-m)^2 / 2 ≤ Lam q := by
  by_cases heq : m = q
  · subst q; simp
  have hs : uIcc m q ⊆ Icc a b := by
    intro x hx; rcases le_total m q with h | h
    · simp only [uIcc_of_le h, mem_Icc] at hx; exact ⟨hm.1.trans hx.1, hx.2.trans hq.2⟩
    · simp only [uIcc_of_ge h, mem_Icc] at hx; exact ⟨hq.1.trans hx.1, hx.2.trans hm.2⟩
  have hc : ContDiffOn ℝ 2 Lam (uIcc m q) := fun x hx =>
    ((Lam_contDiffAt (hadm x (hs hx))).of_le (by norm_cast)).contDiffWithinAt
  obtain ⟨c, hcm, ht⟩ := taylor_mean_remainder_lagrange_iteratedDeriv (n := 1) heq hc
  have htay : taylorWithinEval Lam 1 (uIcc m q) m q = Lam m + lam1 m * (q-m) := by
    rw [show (1 : ℕ) = 0+1 by rfl, taylorWithinEval_succ, taylor_within_zero_eval,
      iteratedDerivWithin_one, (Lam_hasDerivAt (hadm m hm)).hasDerivWithinAt.derivWithin
        ((uniqueDiffOn_uIcc heq) m (left_mem_uIcc))]
    norm_num; ring
  have hdc : iteratedDeriv 2 Lam c = lam2 c := by
    rw [show (2 : ℕ) = 1+1 by rfl, iteratedDeriv_succ, iteratedDeriv_one]
    exact (Lam_hasSecondDerivAt (hadm c (hs (Ioo_subset_Icc_self hcm)))).deriv
  rw [htay, hdc] at ht
  norm_num at ht
  have hm2 := hM c (hs (Ioo_subset_Icc_self hcm))
  nlinarith [mul_nonneg (sub_nonneg.mpr hm2) (sq_nonneg (q-m))]

/-- Minimum of the Taylor quadratic when the curvature is positive. -/
theorem taylor_vertex_bound {f g h M G : ℝ} (hM : 0 < M) (hg : -G ≤ g ∧ g ≤ G)
    (hG : 0 ≤ G) : f - G^2/(2*M) ≤ f + g*h + M*h^2/2 := by
  have hsq : g^2 ≤ G^2 := by nlinarith
  have hsquare := sq_nonneg (M*h+g)
  have hh : -g*h-M*h^2/2 ≤ G^2/(2*M) := by
    apply (le_div_iff₀ (by positivity : 0 < 2*M)).mpr
    nlinarith
  linarith

/-- Endpoint minimum; covers negative curvature and a vertex beyond the slab. -/
theorem taylor_endpoint_bound {f g h M G w : ℝ} (hw : 0 ≤ w)
    (hh : -w ≤ h ∧ h ≤ w) (hg : -G ≤ g ∧ g ≤ G) (hG : 0 ≤ G)
    (hcase : M*w ≤ G) : f-G*w+M*w^2/2 ≤ f+g*h+M*h^2/2 := by
  have habs : |h| ≤ w := abs_le.mpr hh
  have hgh : -G*|h| ≤ g*h := by
    rcases le_or_gt 0 h with hp | hn
    · rw [abs_of_nonneg hp]; nlinarith [mul_nonneg hp (sub_nonneg.mpr hg.1)]
    · rw [abs_of_neg hn]; nlinarith [mul_nonneg (neg_nonneg.mpr hn.le) (sub_nonneg.mpr hg.2)]
  have h1 := mul_nonneg (sub_nonneg.mpr habs) (sub_nonneg.mpr hcase)
  have h2 := mul_nonneg (sub_nonneg.mpr habs) (abs_nonneg h)
  have he : |h|^2 = h^2 := sq_abs h
  by_cases hm : 0 ≤ M
  · nlinarith [mul_nonneg hm (sq_nonneg (w-|h|))]
  · have h3 := mul_nonneg (neg_nonneg.mpr (le_of_not_ge hm))
      (show 0 ≤ w^2-h^2 by nlinarith [sq_nonneg (w-|h|)])
    nlinarith

end EP1038.DLowerCert
