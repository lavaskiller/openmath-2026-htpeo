import LeanProject.DActualRoots
import LeanProject.CertificateArithmetic

/-! Transfer rational T/S leaf calculations to the true exponential/logarithm. -/
open Real Set
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert

noncomputable def lowerTarget : ℝ := 18344304757 / 10000000000

theorem log_tailQ {r : ℝ} (hr : 0 < r) : Real.log (tailQ r) = -1 / r := by
  rw [tailQ, if_neg hr.ne', Real.log_exp]

theorem aval_tailQ {r : ℝ} (hr : 0 < r) :
    aval (tailQ r) = 1 - r * delta (tailQ r) := by
  rw [aval, log_tailQ hr]
  field_simp
  <;> ring

theorem tail_q_upper {r rb qu : ℝ} (hr : 0 < r) (hrb : r ≤ rb)
    (hqu : 0 < qu) (hlog : -1 / rb ≤ Real.log qu) : tailQ r ≤ qu := by
  have hb : 0 < rb := hr.trans_le hrb
  have hm := div_le_div_of_nonneg_left (zero_le_one' ℝ) hr hrb
  have he : -1 / r ≤ Real.log qu := by
    simp only [neg_div] at hlog ⊢
    linarith
  rw [tailQ, if_neg hr.ne']
  exact (Real.exp_le_exp.mpr he).trans_eq (Real.exp_log hqu)

theorem tail_q_lower {r ra ql : ℝ} (hr : 0 < r) (hra : ra ≤ r)
    (hra0 : 0 < ra) (hql : 0 < ql) (hlog : Real.log ql ≤ -1 / ra) : ql ≤ tailQ r := by
  have hm := div_le_div_of_nonneg_left (zero_le_one' ℝ) hra0 hra
  have he : Real.log ql ≤ -1 / r := by
    simp only [neg_div] at hlog ⊢
    linarith
  rw [tailQ, if_neg hr.ne']
  exact (Real.exp_log hql).symm.le.trans (Real.exp_le_exp.mpr he)

theorem E_eq_log_ratio {q v : ℝ} (hx : 0 < v - q ^ 2) (hv1 : v ≠ 1) :
    E q v = aval q * Real.log ((v - q ^ 2) / |1 - v|) - Real.log v - delta q := by
  rw [E, Real.log_div hx.ne' (abs_pos.mpr (sub_ne_zero.mpr hv1.symm)).ne', Real.log_abs]

end EP1038.DLowerCert
