import LeanProject.DLowerMTools
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_80 : RB (Real.log ((234101664053954681 : ℝ) / 500000000000000000)) ((-151770523129328119 : ℝ) / 200000000000000000) ((-758852615646640593 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((234101664053954681 : ℝ) / 250000000000000000)) (t := ((-15898335946045319 : ℝ) / 484101664053954681))
    (lo := ((-13141087017339057 : ℝ) / 200000000000000000)) (hi := ((-16426358771673821 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((234101664053954681 : ℝ) / 500000000000000000) = Real.log ((234101664053954681 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((234101664053954681 : ℝ) / 500000000000000000) = ((234101664053954681 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_81 : RB (Real.log ((478616431614347497 : ℝ) / 1000000000000000000)) ((-147371154286076213 : ℝ) / 200000000000000000) ((-736855771430381063 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((478616431614347497 : ℝ) / 500000000000000000)) (t := ((-21383568385652503 : ℝ) / 978616431614347497))
    (lo := ((-8741718174087151 : ℝ) / 200000000000000000)) (hi := ((-21854295435217877 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((478616431614347497 : ℝ) / 1000000000000000000) = Real.log ((478616431614347497 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((478616431614347497 : ℝ) / 1000000000000000000) = ((478616431614347497 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_82 : RB (Real.log ((239308215807173749 : ℝ) / 500000000000000000)) ((-736855771430381063 : ℝ) / 1000000000000000000) ((-736855771430381061 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((239308215807173749 : ℝ) / 250000000000000000)) (t := ((-10691784192826251 : ℝ) / 489308215807173749))
    (lo := ((-43708590870435753 : ℝ) / 1000000000000000000)) (hi := ((-5463573858804469 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((239308215807173749 : ℝ) / 500000000000000000) = Real.log ((239308215807173749 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((239308215807173749 : ℝ) / 500000000000000000) = ((239308215807173749 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_83 : RB (Real.log ((478522681614347497 : ℝ) / 1000000000000000000)) ((-184262916929913533 : ℝ) / 250000000000000000) ((-73705166771965413 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((478522681614347497 : ℝ) / 500000000000000000)) (t := ((-21477318385652503 : ℝ) / 978522681614347497))
    (lo := ((-21952243579854411 : ℝ) / 500000000000000000)) (hi := ((-43904487159708821 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((478522681614347497 : ℝ) / 1000000000000000000) = Real.log ((478522681614347497 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((478522681614347497 : ℝ) / 1000000000000000000) = ((478522681614347497 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_84 : RB (Real.log ((711586224292540793 : ℝ) / 500000000000000000)) ((35288849840265111 : ℝ) / 100000000000000000) ((44111062300331389 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((711586224292540793 : ℝ) / 1000000000000000000)) (t := ((-288413775707459207 : ℝ) / 1711586224292540793))
    (lo := ((-340258682157294199 : ℝ) / 1000000000000000000)) (hi := ((-170129341078647099 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((711586224292540793 : ℝ) / 500000000000000000) = Real.log ((711586224292540793 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((711586224292540793 : ℝ) / 500000000000000000) = ((711586224292540793 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_85 : RB (Real.log ((713160964717619541 : ℝ) / 500000000000000000)) ((8877476337001077 : ℝ) / 25000000000000000) ((177549526740021541 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((713160964717619541 : ℝ) / 1000000000000000000)) (t := ((-286839035282380459 : ℝ) / 1713160964717619541))
    (lo := ((-338048127079902229 : ℝ) / 1000000000000000000)) (hi := ((-84512031769975557 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((713160964717619541 : ℝ) / 500000000000000000) = Real.log ((713160964717619541 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((713160964717619541 : ℝ) / 500000000000000000) = ((713160964717619541 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_86 : RB (Real.log ((211786224292540793 : ℝ) / 500000000000000000)) ((-859030708481855901 : ℝ) / 1000000000000000000) ((-859030708481855899 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((211786224292540793 : ℝ) / 250000000000000000)) (t := ((-38213775707459207 : ℝ) / 461786224292540793))
    (lo := ((-165883527921910591 : ℝ) / 1000000000000000000)) (hi := ((-16588352792191059 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((211786224292540793 : ℝ) / 500000000000000000) = Real.log ((211786224292540793 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((211786224292540793 : ℝ) / 500000000000000000) = ((211786224292540793 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_87 : RB (Real.log ((426546929435239081 : ℝ) / 1000000000000000000)) ((-4260164421289351 : ℝ) / 5000000000000000) ((-426016442128935099 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((426546929435239081 : ℝ) / 500000000000000000)) (t := ((-73453070564760919 : ℝ) / 926546929435239081))
    (lo := ((-15888570369792489 : ℝ) / 100000000000000000)) (hi := ((-158885703697924889 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((426546929435239081 : ℝ) / 1000000000000000000) = Real.log ((426546929435239081 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((426546929435239081 : ℝ) / 1000000000000000000) = ((426546929435239081 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_88 : RB (Real.log ((711786224292540793 : ℝ) / 500000000000000000)) ((70633904225311187 : ℝ) / 200000000000000000) ((353169521126555937 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((711786224292540793 : ℝ) / 1000000000000000000)) (t := ((-288213775707459207 : ℝ) / 1711786224292540793))
    (lo := ((-169988829716694687 : ℝ) / 500000000000000000)) (hi := ((-339977659433389373 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((711786224292540793 : ℝ) / 500000000000000000) = Real.log ((711786224292540793 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((711786224292540793 : ℝ) / 500000000000000000) = ((711786224292540793 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_89 : RB (Real.log ((1426546929435239081 : ℝ) / 1000000000000000000)) ((355256789437493009 : ℝ) / 1000000000000000000) ((355256789437493011 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426546929435239081 : ℝ) / 2000000000000000000)) (t := ((-573453070564760919 : ℝ) / 3426546929435239081))
    (lo := ((-3378903911224523 : ℝ) / 10000000000000000)) (hi := ((-337890391122452299 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426546929435239081 : ℝ) / 1000000000000000000) = Real.log ((1426546929435239081 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426546929435239081 : ℝ) / 1000000000000000000) = ((1426546929435239081 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_90 : RB (Real.log ((711633099292540793 : ℝ) / 500000000000000000)) ((352954370189578331 : ℝ) / 1000000000000000000) ((352954370189578333 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((711633099292540793 : ℝ) / 1000000000000000000)) (t := ((-288366900707459207 : ℝ) / 1711633099292540793))
    (lo := ((-170096405185183489 : ℝ) / 500000000000000000)) (hi := ((-340192810370366977 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((711633099292540793 : ℝ) / 500000000000000000) = Real.log ((711633099292540793 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((711633099292540793 : ℝ) / 500000000000000000) = ((711633099292540793 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_91 : RB (Real.log ((1423266198585081587 : ℝ) / 1000000000000000000)) ((352954370189578331 : ℝ) / 1000000000000000000) ((352954370189578333 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1423266198585081587 : ℝ) / 2000000000000000000)) (t := ((-576733801414918413 : ℝ) / 3423266198585081587))
    (lo := ((-170096405185183489 : ℝ) / 500000000000000000)) (hi := ((-340192810370366977 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1423266198585081587 : ℝ) / 1000000000000000000) = Real.log ((1423266198585081587 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1423266198585081587 : ℝ) / 1000000000000000000) = ((1423266198585081587 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_92 : RB (Real.log ((1423347448585081587 : ℝ) / 1000000000000000000)) ((176505727780974499 : ℝ) / 500000000000000000) ((353011455561949 : ℝ) / 1000000000000000) := by
  have hm := log_bounds_of_series (x := ((1423347448585081587 : ℝ) / 2000000000000000000)) (t := ((-576652551414918413 : ℝ) / 3423347448585081587))
    (lo := ((-340135724997996311 : ℝ) / 1000000000000000000)) (hi := ((-34013572499799631 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1423347448585081587 : ℝ) / 1000000000000000000) = Real.log ((1423347448585081587 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1423347448585081587 : ℝ) / 1000000000000000000) = ((1423347448585081587 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_93 : RB (Real.log ((1426240679435239081 : ℝ) / 1000000000000000000)) ((177521043579031729 : ℝ) / 500000000000000000) ((17752104357903173 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426240679435239081 : ℝ) / 2000000000000000000)) (t := ((-573759320564760919 : ℝ) / 3426240679435239081))
    (lo := ((-338105093401881851 : ℝ) / 1000000000000000000)) (hi := ((-6762101868037637 : ℝ) / 20000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426240679435239081 : ℝ) / 1000000000000000000) = Real.log ((1426240679435239081 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426240679435239081 : ℝ) / 1000000000000000000) = ((1426240679435239081 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_94 : RB (Real.log ((713120339717619541 : ℝ) / 500000000000000000)) ((355042087158063459 : ℝ) / 1000000000000000000) ((355042087158063461 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((713120339717619541 : ℝ) / 1000000000000000000)) (t := ((-286879660282380459 : ℝ) / 1713120339717619541))
    (lo := ((-6762101868037637 : ℝ) / 20000000000000000)) (hi := ((-338105093401881849 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((713120339717619541 : ℝ) / 500000000000000000) = Real.log ((713120339717619541 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((713120339717619541 : ℝ) / 500000000000000000) = ((713120339717619541 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_95 : RB (Real.log ((1426146929435239081 : ℝ) / 1000000000000000000)) ((70995270550769119 : ℝ) / 200000000000000000) ((354976352753845597 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426146929435239081 : ℝ) / 2000000000000000000)) (t := ((-573853070564760919 : ℝ) / 3426146929435239081))
    (lo := ((-169085413903049857 : ℝ) / 500000000000000000)) (hi := ((-338170827806099713 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426146929435239081 : ℝ) / 1000000000000000000) = Real.log ((1426146929435239081 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426146929435239081 : ℝ) / 1000000000000000000) = ((1426146929435239081 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_96 : RB (Real.log ((21249999999999999 : ℝ) / 1000000000000000000)) ((-770279676722342253 : ℝ) / 200000000000000000) ((-3851398383611711263 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((21249999999999999 : ℝ) / 31250000000000000)) (t := ((-10000000000000001 : ℝ) / 52499999999999999))
    (lo := ((-385662480811984717 : ℝ) / 1000000000000000000)) (hi := ((-96415620202996179 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21249999999999999 : ℝ) / 1000000000000000000) = Real.log ((21249999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((21249999999999999 : ℝ) / 1000000000000000000) = ((21249999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_97 : RB (Real.log ((17 : ℝ) / 800)) ((-3851398383611711217 : ℝ) / 1000000000000000000) ((-770279676722342243 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((17 : ℝ) / 25)) (t := ((-4 : ℝ) / 21))
    (lo := ((-385662480811984669 : ℝ) / 1000000000000000000)) (hi := ((-96415620202996167 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17 : ℝ) / 800) = Real.log ((17 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((17 : ℝ) / 800) = ((17 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_98 : RB (Real.log ((1021249999999999999 : ℝ) / 1000000000000000000)) ((10513683596037793 : ℝ) / 500000000000000000) ((21027367192075587 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1021249999999999999 : ℝ) / 1000000000000000000)) (t := ((21249999999999999 : ℝ) / 2021249999999999999))
    (lo := ((10513683596037793 : ℝ) / 500000000000000000)) (hi := ((21027367192075587 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_99 : RB (Real.log ((817 : ℝ) / 800)) ((21027367192075587 : ℝ) / 1000000000000000000) ((5256841798018897 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((817 : ℝ) / 800)) (t := ((17 : ℝ) / 1617))
    (lo := ((21027367192075587 : ℝ) / 1000000000000000000)) (hi := ((5256841798018897 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_100 : RB (Real.log ((19999999999999999 : ℝ) / 1000000000000000000)) ((-391202300542814611 : ℝ) / 100000000000000000) ((-978005751357036527 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((19999999999999999 : ℝ) / 15625000000000000)) (t := ((4374999999999999 : ℝ) / 35624999999999999))
    (lo := ((246860077931525747 : ℝ) / 1000000000000000000)) (hi := ((61715019482881437 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19999999999999999 : ℝ) / 1000000000000000000) = Real.log ((19999999999999999 : ℝ) / 15625000000000000) - 6 * Real.log 2 := by
    rw [show ((19999999999999999 : ℝ) / 1000000000000000000) = ((19999999999999999 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_101 : RB (Real.log ((9 : ℝ) / 400)) ((-758847993954352521 : ℝ) / 200000000000000000) ((-3794239969771762603 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((18 : ℝ) / 25)) (t := ((-7 : ℝ) / 43))
    (lo := ((-328504066972036057 : ℝ) / 1000000000000000000)) (hi := ((-41063008371504507 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9 : ℝ) / 400) = Real.log ((18 : ℝ) / 25) - 5 * Real.log 2 := by
    rw [show ((9 : ℝ) / 400) = ((18 : ℝ) / 25) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_102 : RB (Real.log ((1019999999999999999 : ℝ) / 1000000000000000000)) ((38677006437851 : ℝ) / 1953125000000000) ((19802627296179713 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1019999999999999999 : ℝ) / 1000000000000000000)) (t := ((19999999999999999 : ℝ) / 2019999999999999999))
    (lo := ((38677006437851 : ℝ) / 1953125000000000)) (hi := ((19802627296179713 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_103 : RB (Real.log ((409 : ℝ) / 400)) ((11125304467409879 : ℝ) / 500000000000000000) ((22250608934819759 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((409 : ℝ) / 400)) (t := ((9 : ℝ) / 809))
    (lo := ((11125304467409879 : ℝ) / 500000000000000000)) (hi := ((22250608934819759 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_104 : RB (Real.log ((466811033794107 : ℝ) / 1000000000000000)) ((-380915370879013679 : ℝ) / 500000000000000000) ((-190457685439506839 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((466811033794107 : ℝ) / 500000000000000)) (t := ((-33188966205893 : ℝ) / 966811033794107))
    (lo := ((-33536895116251 : ℝ) / 488281250000000)) (hi := ((-68683561198082047 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((466811033794107 : ℝ) / 1000000000000000) = Real.log ((466811033794107 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((466811033794107 : ℝ) / 1000000000000000) = ((466811033794107 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_105 : RB (Real.log ((466811033794110001 : ℝ) / 1000000000000000000)) ((-761830741758020929 : ℝ) / 1000000000000000000) ((-761830741758020927 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((466811033794110001 : ℝ) / 500000000000000000)) (t := ((-33188966205889999 : ℝ) / 966811033794110001))
    (lo := ((-68683561198075619 : ℝ) / 1000000000000000000)) (hi := ((-34341780599037809 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((466811033794110001 : ℝ) / 1000000000000000000) = Real.log ((466811033794110001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((466811033794110001 : ℝ) / 1000000000000000000) = ((466811033794110001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_106 : RB (Real.log ((53273740370589 : ℝ) / 100000000000000)) ((-62972665219491721 : ℝ) / 100000000000000000) ((-78715831524364651 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((53273740370589 : ℝ) / 50000000000000)) (t := ((3273740370589 : ℝ) / 103273740370589))
    (lo := ((634205283650281 : ℝ) / 10000000000000000)) (hi := ((63420528365028101 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53273740370589 : ℝ) / 100000000000000) = Real.log ((53273740370589 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((53273740370589 : ℝ) / 100000000000000) = ((53273740370589 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_107 : RB (Real.log ((532737403705893 : ℝ) / 1000000000000000)) ((-314863326097455789 : ℝ) / 500000000000000000) ((-78715831524363947 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((532737403705893 : ℝ) / 500000000000000)) (t := ((32737403705893 : ℝ) / 1032737403705893))
    (lo := ((15855132091258433 : ℝ) / 250000000000000000)) (hi := ((63420528365033733 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((532737403705893 : ℝ) / 1000000000000000) = Real.log ((532737403705893 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((532737403705893 : ℝ) / 1000000000000000) = ((532737403705893 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_108 : RB (Real.log ((467262596294107 : ℝ) / 1000000000000000)) ((-47553992165561579 : ℝ) / 62500000000000000) ((-380431937324492631 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((467262596294107 : ℝ) / 500000000000000)) (t := ((-32737403705893 : ℝ) / 967262596294107))
    (lo := ((-33858347044519977 : ℝ) / 500000000000000000)) (hi := ((-67716694089039953 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((467262596294107 : ℝ) / 1000000000000000) = Real.log ((467262596294107 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((467262596294107 : ℝ) / 1000000000000000) = ((467262596294107 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_109 : RB (Real.log ((46726259629411 : ℝ) / 100000000000000)) ((-190215968662244711 : ℝ) / 250000000000000000) ((-380431937324489421 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((46726259629411 : ℝ) / 50000000000000)) (t := ((-3273740370589 : ℝ) / 96726259629411))
    (lo := ((-33858347044516767 : ℝ) / 500000000000000000)) (hi := ((-67716694089033533 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((46726259629411 : ℝ) / 100000000000000) = Real.log ((46726259629411 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((46726259629411 : ℝ) / 100000000000000) = ((46726259629411 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_110 : RB (Real.log ((466811033794107001 : ℝ) / 1000000000000000000)) ((-152366148351605471 : ℝ) / 200000000000000000) ((-761830741758027353 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((466811033794107001 : ℝ) / 500000000000000000)) (t := ((-33188966205892999 : ℝ) / 966811033794107001))
    (lo := ((-13736712239616409 : ℝ) / 200000000000000000)) (hi := ((-17170890299520511 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((466811033794107001 : ℝ) / 1000000000000000000) = Real.log ((466811033794107001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((466811033794107001 : ℝ) / 1000000000000000000) = ((466811033794107001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_111 : RB (Real.log ((46681103379411 : ℝ) / 100000000000000)) ((-761830741758020931 : ℝ) / 1000000000000000000) ((-761830741758020929 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((46681103379411 : ℝ) / 50000000000000)) (t := ((-3318896620589 : ℝ) / 96681103379411))
    (lo := ((-68683561198075621 : ℝ) / 1000000000000000000)) (hi := ((-3434178059903781 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((46681103379411 : ℝ) / 100000000000000) = Real.log ((46681103379411 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((46681103379411 : ℝ) / 100000000000000) = ((46681103379411 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_112 : RB (Real.log ((712221888758889 : ℝ) / 500000000000000)) ((353781405954947097 : ℝ) / 1000000000000000000) ((353781405954947099 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712221888758889 : ℝ) / 1000000000000000)) (t := ((-287778111241111 : ℝ) / 1712221888758889))
    (lo := ((-84841443651249553 : ℝ) / 250000000000000000)) (hi := ((-339365774604998211 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712221888758889 : ℝ) / 500000000000000) = Real.log ((712221888758889 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712221888758889 : ℝ) / 500000000000000) = ((712221888758889 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_113 : RB (Real.log ((1424443777517781001 : ℝ) / 1000000000000000000)) ((88445351488737301 : ℝ) / 250000000000000000) ((176890702977474603 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424443777517781001 : ℝ) / 2000000000000000000)) (t := ((-575556222482218999 : ℝ) / 3424443777517781001))
    (lo := ((-67873154920999221 : ℝ) / 200000000000000000)) (hi := ((-42420721825624513 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424443777517781001 : ℝ) / 1000000000000000000) = Real.log ((1424443777517781001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424443777517781001 : ℝ) / 1000000000000000000) = ((1424443777517781001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_114 : RB (Real.log ((212447670008889 : ℝ) / 500000000000000)) ((-427956199583045869 : ℝ) / 500000000000000000) ((-106989049895761467 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((212447670008889 : ℝ) / 250000000000000)) (t := ((-37552329991111 : ℝ) / 462447670008889))
    (lo := ((-40691304651536607 : ℝ) / 250000000000000000)) (hi := ((-162765218606146427 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212447670008889 : ℝ) / 500000000000000) = Real.log ((212447670008889 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212447670008889 : ℝ) / 500000000000000) = ((212447670008889 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_115 : RB (Real.log ((424895340017781 : ℝ) / 1000000000000000)) ((-855912399166084677 : ℝ) / 1000000000000000000) ((-34236495966643387 : ℝ) / 40000000000000000) := by
  have hm := log_bounds_of_series (x := ((424895340017781 : ℝ) / 500000000000000)) (t := ((-75104659982219 : ℝ) / 924895340017781))
    (lo := ((-162765218606139367 : ℝ) / 1000000000000000000)) (hi := ((-81382609303069683 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((424895340017781 : ℝ) / 1000000000000000) = Real.log ((424895340017781 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((424895340017781 : ℝ) / 1000000000000000) = ((424895340017781 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_116 : RB (Real.log ((712447670008889 : ℝ) / 500000000000000)) ((177049182710897143 : ℝ) / 500000000000000000) ((22131147838862143 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((712447670008889 : ℝ) / 1000000000000000)) (t := ((-287552329991111 : ℝ) / 1712447670008889))
    (lo := ((-339048815138151023 : ℝ) / 1000000000000000000)) (hi := ((-169524407569075511 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712447670008889 : ℝ) / 500000000000000) = Real.log ((712447670008889 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712447670008889 : ℝ) / 500000000000000) = ((712447670008889 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_117 : RB (Real.log ((1424895340017781 : ℝ) / 1000000000000000)) ((44262295677724549 : ℝ) / 125000000000000000) ((177049182710898197 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424895340017781 : ℝ) / 2000000000000000)) (t := ((-575104659982219 : ℝ) / 3424895340017781))
    (lo := ((-339048815138148917 : ℝ) / 1000000000000000000)) (hi := ((-84762203784537229 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424895340017781 : ℝ) / 1000000000000000) = Real.log ((1424895340017781 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424895340017781 : ℝ) / 1000000000000000) = ((1424895340017781 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_118 : RB (Real.log ((1424443777517778001 : ℝ) / 1000000000000000000)) ((176890702977473549 : ℝ) / 500000000000000000) ((3537814059549471 : ℝ) / 10000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424443777517778001 : ℝ) / 2000000000000000000)) (t := ((-575556222482221999 : ℝ) / 3424443777517778001))
    (lo := ((-339365774604998211 : ℝ) / 1000000000000000000)) (hi := ((-33936577460499821 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424443777517778001 : ℝ) / 1000000000000000000) = Real.log ((1424443777517778001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424443777517778001 : ℝ) / 1000000000000000000) = ((1424443777517778001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_119 : RB (Real.log ((1424443777517781 : ℝ) / 1000000000000000)) ((353781405954949203 : ℝ) / 1000000000000000000) ((70756281190989841 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424443777517781 : ℝ) / 2000000000000000)) (t := ((-575556222482219 : ℝ) / 3424443777517781))
    (lo := ((-169682887302498053 : ℝ) / 500000000000000000)) (hi := ((-67873154920999221 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424443777517781 : ℝ) / 1000000000000000) = Real.log ((1424443777517781 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424443777517781 : ℝ) / 1000000000000000) = ((1424443777517781 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
