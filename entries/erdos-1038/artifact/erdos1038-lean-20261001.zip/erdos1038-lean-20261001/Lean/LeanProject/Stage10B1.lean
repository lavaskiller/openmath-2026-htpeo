import LeanProject.Stage9D4

/-!
# EP-1038, Stage 10 Part (b): `Ψ_S`, `E_S`, `R(S)` on the real axis; (10.1), (10.2); Lemma 10.4

Setting (proof.md §10.0): `S : ℝ → ℝ` measurable with `a ≤ S u ≤ 2` for all `u` (`a > 0` plays the role
of a lower bound for `a_S = ess inf S`; the quantile function is used on `(0, 1)` only), `k > 0`.
On the real axis `y < a` all quantities are real:
* `LS S y = ∫_0^1 log(S(u) - y) du`, `JS S y = ∫_0^1 du/(S(u) - y)`;
* `RS k S = exp(-(1/k) ∫ log S)`, `ES k S y = exp(-(1/k) ∫ log(S - y))`,
  `PsiS k S y = y exp((1/k) ∫ log(1 - y/S))` (`PsiS_def'`);
* `WS k S x = k log|x| + ∫ log|x - S(u)| du`.
Results: (10.1) `PsiS_eq`, (10.2) `WS_eq`, the derivative `hasDerivAt_LS`, `hasDerivAt_PsiS`
(`Ψ' = G Ψ` with `G(y) = 1/y - (1/k) J(y)`), and Lemma 10.4(1)–(3).
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

/-- `L_S(y) = ∫_0^1 log(S(u) - y) du`. -/
noncomputable def LS (S : ℝ → ℝ) (y : ℝ) : ℝ := ∫ u in (0 : ℝ)..1, Real.log (S u - y)

/-- `J_S(y) = ∫_0^1 du/(S(u) - y)`. -/
noncomputable def JS (S : ℝ → ℝ) (y : ℝ) : ℝ := ∫ u in (0 : ℝ)..1, 1 / (S u - y)

/-- `R(S) = exp(-(1/k) ∫ log S)`. -/
noncomputable def RS (k : ℝ) (S : ℝ → ℝ) : ℝ := Real.exp (-(1 / k) * LS S 0)

/-- `E_S(y) = exp(-(1/k) ∫ log(S - y))`. -/
noncomputable def ES (k : ℝ) (S : ℝ → ℝ) (y : ℝ) : ℝ := Real.exp (-(1 / k) * LS S y)

/-- `Ψ_S(y) = y exp((1/k) ∫ log(1 - y/S))`, written with `∫ log(1 - y/S) = L_S(y) - L_S(0)`. -/
noncomputable def PsiS (k : ℝ) (S : ℝ → ℝ) (y : ℝ) : ℝ :=
  y * Real.exp ((1 / k) * (LS S y - LS S 0))

/-- `G_S(y) = 1/y - (1/k) ∫ du/(S - y)`. -/
noncomputable def GS (k : ℝ) (S : ℝ → ℝ) (y : ℝ) : ℝ := 1 / y - (1 / k) * JS S y

/-- `W_S(x) = k log|x| + ∫_0^1 log|x - S(u)| du`. -/
noncomputable def WS (k : ℝ) (S : ℝ → ℝ) (x : ℝ) : ℝ :=
  k * Real.log |x| + ∫ u in (0 : ℝ)..1, Real.log |x - S u|

section real

variable {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
  (hS2 : ∀ u, S u ≤ 2)
include hSm ha hSa hS2

theorem ii_log {y : ℝ} (hy : y < a) :
    IntervalIntegrable (fun u => Real.log (S u - y)) volume 0 1 := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le zero_le_one]
  refine Measure.integrableOn_of_bounded (M := max |Real.log (a - y)| |Real.log (2 - y)|)
    measure_Ioc_lt_top.ne ((Real.measurable_log.comp (hSm.sub_const y)).aestronglyMeasurable) ?_
  refine Eventually.of_forall fun u => ?_
  have h1 : Real.log (a - y) ≤ Real.log (S u - y) :=
    Real.log_le_log (by linarith) (by linarith [hSa u])
  have h2 : Real.log (S u - y) ≤ Real.log (2 - y) :=
    Real.log_le_log (by linarith [hSa u]) (by linarith [hS2 u])
  rw [Real.norm_eq_abs, abs_le]
  constructor
  · linarith [neg_abs_le (Real.log (a - y)), le_max_left |Real.log (a - y)| |Real.log (2 - y)|]
  · linarith [le_abs_self (Real.log (2 - y)), le_max_right |Real.log (a - y)| |Real.log (2 - y)|]

theorem ii_inv {y : ℝ} (hy : y < a) :
    IntervalIntegrable (fun u => 1 / (S u - y)) volume 0 1 := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le zero_le_one]
  refine Measure.integrableOn_of_bounded (M := 1 / (a - y)) measure_Ioc_lt_top.ne
    ((measurable_const.div (hSm.sub_const y)).aestronglyMeasurable) ?_
  refine Eventually.of_forall fun u => ?_
  have hpos : 0 < S u - y := by linarith [hSa u]
  rw [Real.norm_eq_abs, abs_of_pos (by positivity)]
  exact one_div_le_one_div_of_le (by linarith) (by linarith [hSa u])

/-- `∫ log(1 - y/S) = L_S(y) - L_S(0)`, so `PsiS` is the paper's `Ψ_S` on the real axis. -/
theorem PsiS_def' {y : ℝ} (hy : y < a) :
    PsiS k S y = y * Real.exp ((1 / k) * ∫ u in (0 : ℝ)..1, Real.log (1 - y / S u)) := by
  unfold PsiS LS
  congr 3
  rw [← intervalIntegral.integral_sub (ii_log hSm ha hSa hS2 hy) (ii_log hSm ha hSa hS2 ha)]
  refine intervalIntegral.integral_congr fun u _ => ?_
  have hS : 0 < S u := by linarith [hSa u]
  simp only [sub_zero]
  rw [← Real.log_div (by linarith [hSa u]) hS.ne']
  congr 1
  field_simp

omit hSm ha hSa hS2 in
/-- **(10.1)**: `Ψ_S(y) = R(S) y / E_S(y)`. -/
theorem PsiS_eq (y : ℝ) : PsiS k S y = RS k S * y / ES k S y := by
  unfold PsiS RS ES
  rw [eq_div_iff (Real.exp_pos _).ne', mul_comm (Real.exp _) y, mul_assoc, ← Real.exp_add]
  congr 2
  ring

/-- **(10.2)**: `W_S(y) = k log(|Ψ_S(y)|/R(S))` for real `y < a`, `y ≠ 0`. -/
theorem WS_eq (hk : 0 < k) {y : ℝ} (hy : y < a) (hy0 : y ≠ 0) :
    WS k S y = k * Real.log (|PsiS k S y| / RS k S) := by
  have hL : ∫ u in (0 : ℝ)..1, Real.log |y - S u| = LS S y := by
    unfold LS
    refine intervalIntegral.integral_congr fun u _ => ?_
    rw [abs_sub_comm, Real.log_abs]
  unfold WS
  rw [hL]
  unfold PsiS RS
  rw [abs_mul, abs_of_pos (Real.exp_pos _), Real.log_div (by positivity) (Real.exp_pos _).ne',
    Real.log_mul (abs_ne_zero.mpr hy0) (Real.exp_pos _).ne', Real.log_exp, Real.log_exp]
  field_simp
  ring

/-- The derivative of `L_S`: `L_S'(y) = -J_S(y)` for `y < a`. -/
theorem hasDerivAt_LS {y : ℝ} (hy : y < a) : HasDerivAt (LS S) (-JS S y) y := by
  set ε := (a - y) / 2 with hε
  have hε0 : 0 < ε := by linarith
  have hball : Metric.ball y ε ∈ 𝓝 y := Metric.ball_mem_nhds y hε0
  have hlt : ∀ x ∈ Metric.ball y ε, x < a - ε := fun x hx => by
    rw [Metric.mem_ball, Real.dist_eq, abs_lt] at hx; linarith [hx.2]
  have key := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (F := fun x u => Real.log (S u - x)) (F' := fun x u => -(1 / (S u - x)))
    (bound := fun _ => 1 / ε) (a := 0) (b := 1) (μ := volume) hball
    (Eventually.of_forall fun x => (Real.measurable_log.comp (hSm.sub_const x)).aestronglyMeasurable)
    (ii_log hSm ha hSa hS2 hy)
    ((measurable_const.div (hSm.sub_const y)).neg.aestronglyMeasurable)
    (Eventually.of_forall fun u _ x hx => by
      have hpos : ε < S u - x := by linarith [hSa u, hlt x hx]
      rw [norm_neg, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr (by linarith))]
      exact one_div_le_one_div_of_le hε0 hpos.le)
    intervalIntegrable_const
    (Eventually.of_forall fun u _ x hx => by
      have hpos : 0 < S u - x := by linarith [hSa u, hlt x hx]
      exact (((hasDerivAt_id' x).const_sub (S u)).log hpos.ne').congr_deriv (by ring))
  have e : (∫ u in (0 : ℝ)..1, -(1 / (S u - y))) = -JS S y := by
    unfold JS; exact intervalIntegral.integral_neg
  rw [e] at key
  exact key.2

/-- `Ψ_S' = G_S Ψ_S` on `(-∞, a) \ {0}`, in the form `Ψ_S'(y) = e(y)(1 - (y/k) J_S(y))`. -/
theorem hasDerivAt_PsiS {y : ℝ} (hy : y < a) :
    HasDerivAt (PsiS k S)
      (Real.exp ((1 / k) * (LS S y - LS S 0)) * (1 - y * ((1 / k) * JS S y))) y := by
  have hL := hasDerivAt_LS hSm ha hSa hS2 hy
  have he := (((hL.sub_const (LS S 0)).const_mul (1 / k)).exp)
  have := (hasDerivAt_id' y).mul he
  exact this.congr_deriv (by ring)

omit hSm ha hSa hS2 in
theorem PsiS_deriv_eq_G {y : ℝ} (hy0 : y ≠ 0) :
    Real.exp ((1 / k) * (LS S y - LS S 0)) * (1 - y * ((1 / k) * JS S y)) =
      GS k S y * PsiS k S y := by
  unfold GS PsiS
  field_simp

end real

end EP1038.Stage10
