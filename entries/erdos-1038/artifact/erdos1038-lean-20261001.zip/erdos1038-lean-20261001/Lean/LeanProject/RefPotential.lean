import LeanProject.PoissonLog

/-!
# EP-1038, Stage 10, Lemma 10.2(ii) and Proposition 10.3(4), in the angle variable

Parametrize the interval `I = [a, 2]` by `d(θ) = c - ϱ cos θ = D₀ (1 - 2q cos θ + q²)` (identity (K)
of Stage 10), with `D₀ > 0`, `0 ≤ q < 1`, so `c = D₀(1 + q²)`, `ϱ = 2D₀q` and `H = ϱ/2 = D₀q`.
The measures `e_I` and `ω_{0,I}` are the images of `dθ/π` and `P_q(θ) dθ/π` on `[0, π]`; since all
integrands are even in `θ`, we integrate over `[-π, π]` against `dθ/(2π)`.

* `normSq_one_sub`, `Kl_eq_half_log`: `log|1 - q e^{iφ}| = ½ log(1 - 2q cos φ + q²)`; `Kl_even`.
* `int_Pq`: `∫_{-π}^{π} P_q = 2π`.
* `log_dist_eq`: `log|d(φ) - d(θ)| = log(D₀q) + K(θ + φ) + K(θ - φ)` for a.e. `θ`.
* `U_omega` (**Lemma 10.2(ii)**, balayage):
  `(1/2π) ∫ log|d(φ) - d(θ)| P_q(θ) dθ = log H + log d(φ) - log D₀`.
* `U_e` (**Lemma 10.2(ii)**, equilibrium): `(1/2π) ∫ log|d(φ) - d(θ)| dθ = log H`.
* `platform` (**Proposition 10.3(4)**): for every real `k` and `x = d(φ) ∈ I`,
  `k log x + (1/2π) ∫ log|x - d(θ)| ((k+1) - k P_q(θ)) dθ = log H + k log D₀`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- `d(θ) = D₀ (1 - 2q cos θ + q²)`. -/
noncomputable def dth (D0 q θ : ℝ) : ℝ := D0 * (1 - 2 * q * Real.cos θ + q ^ 2)

theorem normSq_one_sub (q φ : ℝ) :
    Complex.normSq (1 - (q : ℂ) * Complex.exp ((φ : ℂ) * Complex.I)) =
      1 - 2 * q * Real.cos φ + q ^ 2 := by
  rw [Complex.normSq_apply, Complex.sub_re, Complex.sub_im, Complex.one_re, Complex.one_im,
    Complex.re_ofReal_mul, Complex.im_ofReal_mul, Complex.exp_ofReal_mul_I_re,
    Complex.exp_ofReal_mul_I_im]
  linear_combination q ^ 2 * Real.sin_sq_add_cos_sq φ

theorem Kl_eq_half_log (q φ : ℝ) : Kl q φ = Real.log (1 - 2 * q * Real.cos φ + q ^ 2) / 2 := by
  unfold Kl
  rw [← normSq_one_sub, Complex.normSq_eq_norm_sq, Real.log_pow]
  push_cast
  ring

theorem Kl_even (q φ : ℝ) : Kl q (-φ) = Kl q φ := by
  rw [Kl_eq_half_log, Kl_eq_half_log, Real.cos_neg]

theorem int_Pq {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) : ∫ θ in (-π)..π, Pq q θ = 2 * π := by
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence (μ := volume)
    (a := -π) (b := π)
    (F := fun (m : ℕ) (θ : ℝ) => 2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ)))
    (f := fun θ => Pq q θ - 1) (fun m _ => 2 * q ^ (m + 1))
    (fun m => (Continuous.aestronglyMeasurable (by fun_prop)))
    (fun m => Filter.Eventually.of_forall fun θ _ => by
      rw [Real.norm_eq_abs, abs_mul, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2),
        abs_of_nonneg (pow_nonneg hq0 _)]
      have := Real.abs_cos_le_one ((m + 1) * θ)
      have := pow_nonneg hq0 (m + 1)
      nlinarith)
    (Filter.Eventually.of_forall fun θ _ => (summable_pow_succ hq0 hq1).mul_left 2)
    intervalIntegrable_const
    (Filter.Eventually.of_forall fun θ _ => Pq_hasSum hq0 hq1 θ)
  have hterm : ∀ m : ℕ, (∫ θ in (-π)..π, 2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ))) = 0 := by
    intro m
    have h0 := orth0 m 0
    simp only [add_zero] at h0
    rw [intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul, h0]
    ring
  rw [show (fun m : ℕ => ∫ θ in (-π)..π, 2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ))) =
      fun _ => (0 : ℝ) from funext hterm] at h
  have h' := h.unique hasSum_zero
  rw [intervalIntegral.integral_sub ((Pq_cont hq0 hq1).intervalIntegrable _ _)
    intervalIntegrable_const, intervalIntegral.integral_const, smul_eq_mul] at h'
  linarith

theorem Kl1_shift_ii (φ a b : ℝ) : IntervalIntegrable (fun θ => Kl 1 (θ + φ)) volume a b := by
  have := (Kl1_ii (a + φ) (b + φ)).comp_add_right φ
  simpa using this

/-- `log|d(φ) - d(θ)| = log(D₀q) + K(θ + φ) + K(θ - φ)` for a.e. `θ`. -/
theorem log_dist_eq {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) (φ : ℝ) :
    ∀ᵐ θ ∂(volume : Measure ℝ), Real.log |dth D0 q φ - dth D0 q θ| =
      Real.log (D0 * q) + Kl 1 (θ + φ) + Kl 1 (θ + -φ) := by
  filter_upwards [Circ.ae_sin_ne (-φ), Circ.ae_sin_ne φ] with θ h1 h2
  have s1 : Real.sin ((θ + φ) / 2) ≠ 0 := by
    rwa [show (-φ - θ) / 2 = -((θ + φ) / 2) by ring, Real.sin_neg, neg_ne_zero] at h1
  have s2 : Real.sin ((θ + -φ) / 2) ≠ 0 := by
    rwa [show (φ - θ) / 2 = -((θ + -φ) / 2) by ring, Real.sin_neg, neg_ne_zero] at h2
  have e : dth D0 q φ - dth D0 q θ =
      -(4 * (D0 * q)) * (Real.sin ((θ + φ) / 2) * Real.sin ((θ + -φ) / 2)) := by
    unfold dth
    have hc := Real.cos_sub_cos θ φ
    rw [show θ + -φ = θ - φ by ring]
    linear_combination (2 * D0 * q) * hc
  have h4 : (0 : ℝ) < 4 * (D0 * q) := by positivity
  rw [e, abs_mul, abs_neg, abs_of_pos h4, abs_mul, Kl1_eq, Kl1_eq]
  have hD0q : 0 < D0 * q := mul_pos hD hq
  have ha1 : 0 < |Real.sin ((θ + φ) / 2)| := abs_pos.mpr s1
  have ha2 : 0 < |Real.sin ((θ + -φ) / 2)| := abs_pos.mpr s2
  rw [show 4 * (D0 * q) * (|Real.sin ((θ + φ) / 2)| * |Real.sin ((θ + -φ) / 2)|) =
      (D0 * q) * ((2 * |Real.sin ((θ + φ) / 2)|) * (2 * |Real.sin ((θ + -φ) / 2)|)) by ring,
    Real.log_mul hD0q.ne' (by positivity),
    Real.log_mul (show (2 * |Real.sin ((θ + φ) / 2)|) ≠ 0 by positivity)
      (show (2 * |Real.sin ((θ + -φ) / 2)|) ≠ 0 by positivity)]
  ring

theorem dth_pos {D0 q : ℝ} (hD : 0 < D0) (hq0 : 0 ≤ q) (hq1 : q < 1) (φ : ℝ) :
    0 < dth D0 q φ := mul_pos hD (Pq_den_pos hq0 hq1 φ)

/-- The key computation: `∫ log|d(φ) - d(θ)| w(θ) dθ` for `w = P_q` and `w = 1`. -/
theorem int_log_dist {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) (φ : ℝ)
    {p : ℝ} (hp0 : 0 ≤ p) (hp1 : p < 1) :
    ∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ| * Pq p θ =
      Real.log (D0 * q) * (2 * π) + 2 * π * (2 * Kl p φ) := by
  have hPc := Pq_cont hp0 hp1
  have hc : ContinuousOn (Pq p) (uIcc (-π) π) := hPc.continuousOn
  have hA : IntervalIntegrable (fun θ => Real.log (D0 * q) * Pq p θ) volume (-π) π :=
    (continuous_const.mul hPc).intervalIntegrable _ _
  have hB : IntervalIntegrable (fun θ => Kl 1 (θ + φ) * Pq p θ) volume (-π) π :=
    (Kl1_shift_ii φ _ _).mul_continuousOn hc
  have hC : IntervalIntegrable (fun θ => Kl 1 (θ + -φ) * Pq p θ) volume (-π) π :=
    (Kl1_shift_ii (-φ) _ _).mul_continuousOn hc
  have e : ∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ| * Pq p θ =
      ∫ θ in (-π)..π, ((Real.log (D0 * q) * Pq p θ + Kl 1 (θ + φ) * Pq p θ) +
        Kl 1 (θ + -φ) * Pq p θ) := by
    refine intervalIntegral.integral_congr_ae ?_
    filter_upwards [log_dist_eq hD hq φ] with θ hθ _
    rw [hθ]
    ring
  rw [e, intervalIntegral.integral_add (hA.add hB) hC, intervalIntegral.integral_add hA hB,
    intervalIntegral.integral_const_mul, int_Pq hp0 hp1, poisson_log hp0 hp1,
    poisson_log hp0 hp1, Kl_even]
  ring

/-- **Lemma 10.2(ii)**, balayage potential:
`(1/2π) ∫ log|d(φ) - d(θ)| P_q(θ) dθ = log H + log d(φ) - log D₀` with `H = D₀q`. -/
theorem U_omega {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) (hq1 : q < 1) (φ : ℝ) :
    1 / (2 * π) * ∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ| * Pq q θ =
      Real.log (D0 * q) + Real.log (dth D0 q φ) - Real.log D0 := by
  rw [int_log_dist hD hq φ hq.le hq1, Kl_eq_half_log]
  have hden := Pq_den_pos hq.le hq1 φ
  have hlog : Real.log (dth D0 q φ) = Real.log D0 + Real.log (1 - 2 * q * Real.cos φ + q ^ 2) := by
    unfold dth
    rw [Real.log_mul hD.ne' hden.ne']
  rw [hlog]
  have hπ := Real.pi_pos.ne'
  field_simp
  ring

/-- `P_0 ≡ 1`. -/
theorem Pq_zero (θ : ℝ) : Pq 0 θ = 1 := by
  unfold Pq
  norm_num

/-- **Lemma 10.2(ii)**, equilibrium potential: `(1/2π) ∫ log|d(φ) - d(θ)| dθ = log H`. -/
theorem U_e {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) (φ : ℝ) :
    1 / (2 * π) * ∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ| = Real.log (D0 * q) := by
  have h := int_log_dist hD hq φ (le_refl 0) zero_lt_one
  simp only [Pq_zero, mul_one] at h
  rw [h, Kl_eq_half_log]
  simp only [mul_zero, zero_mul, sub_zero, zero_pow two_ne_zero, add_zero, Real.log_one,
    zero_div]
  have hπ := Real.pi_pos.ne'
  field_simp

/-- `θ ↦ log|d(φ) - d(θ)|` is integrable on `[-π, π]`. -/
theorem log_dist_ii {D0 q : ℝ} (hD : 0 < D0) (hq : 0 < q) (φ : ℝ) :
    IntervalIntegrable (fun θ => Real.log |dth D0 q φ - dth D0 q θ|) volume (-π) π := by
  have hs : IntervalIntegrable (fun θ => Real.log (D0 * q) + Kl 1 (θ + φ) + Kl 1 (θ + -φ))
      volume (-π) π :=
    (intervalIntegrable_const.add (Kl1_shift_ii φ _ _)).add (Kl1_shift_ii (-φ) _ _)
  refine (intervalIntegrable_congr_ae ?_).mp hs
  exact (ae_restrict_of_ae (log_dist_eq hD hq φ)).mono fun θ h => h.symm

/-- **Proposition 10.3(4)** (platform identity), for `x = d(φ) ∈ I`:
`k log x + (1/2π) ∫ log|x - d(θ)| ((k+1) - k P_q(θ)) dθ = log H + k log D₀`. -/
theorem platform {D0 q k : ℝ} (hD : 0 < D0) (hq : 0 < q) (hq1 : q < 1) (φ : ℝ) :
    k * Real.log (dth D0 q φ) + 1 / (2 * π) *
        ∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ| * ((k + 1) - k * Pq q θ) =
      Real.log (D0 * q) + k * Real.log D0 := by
  have hPc := Pq_cont hq.le hq1
  -- integrability of `log|d(φ) - d(θ)|` and of its product with `P_q`
  have hL : IntervalIntegrable (fun θ => Real.log |dth D0 q φ - dth D0 q θ|) volume (-π) π := by
    have hs : IntervalIntegrable (fun θ => Real.log (D0 * q) + Kl 1 (θ + φ) + Kl 1 (θ + -φ))
        volume (-π) π :=
      (intervalIntegrable_const.add (Kl1_shift_ii φ _ _)).add (Kl1_shift_ii (-φ) _ _)
    refine (intervalIntegrable_congr_ae ?_).mp hs
    exact (ae_restrict_of_ae (log_dist_eq hD hq φ)).mono fun θ h => h.symm
  have hLP : IntervalIntegrable (fun θ => Real.log |dth D0 q φ - dth D0 q θ| * Pq q θ)
      volume (-π) π := hL.mul_continuousOn hPc.continuousOn
  have e : ∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ| * ((k + 1) - k * Pq q θ) =
      (k + 1) * (∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ|) -
        k * ∫ θ in (-π)..π, Real.log |dth D0 q φ - dth D0 q θ| * Pq q θ := by
    rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_const_mul,
      ← intervalIntegral.integral_sub (hL.const_mul _) (hLP.const_mul _)]
    refine intervalIntegral.integral_congr (fun θ _ => ?_)
    ring
  have hU := U_omega hD hq hq1 φ
  have hE := U_e hD hq φ
  rw [e, mul_sub, ← mul_assoc, mul_comm (1 / (2 * π)) (k + 1), mul_assoc, ← mul_assoc _ k,
    mul_comm (1 / (2 * π)) k, mul_assoc, hU, hE]
  ring

end EP1038.Arc
