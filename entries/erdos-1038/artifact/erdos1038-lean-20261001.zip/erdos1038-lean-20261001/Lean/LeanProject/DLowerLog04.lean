import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog01
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_240 : RB (Real.log ((3376569 : ℝ) / 3200000)) ((2685464769 : ℝ) / 50000000000) ((53709295381 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3376569 : ℝ) / 3200000)) (t := ((176569 : ℝ) / 6576569))
    (lo := ((2685464769 : ℝ) / 50000000000)) (hi := ((53709295381 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_241 : RB (Real.log ((54602499999 : ℝ) / 1000000000000)) ((-2907675609753 : ℝ) / 1000000000000) ((-2907675609751 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((54602499999 : ℝ) / 62500000000)) (t := ((-7897500001 : ℝ) / 117102499999))
    (lo := ((-135086887513 : ℝ) / 1000000000000)) (hi := ((-16885860939 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((54602499999 : ℝ) / 1000000000000) = Real.log ((54602499999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((54602499999 : ℝ) / 1000000000000) = ((54602499999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_242 : RB (Real.log ((176569 : ℝ) / 3200000)) ((-1448597176983 : ℝ) / 500000000000) ((-724298588491 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((176569 : ℝ) / 200000)) (t := ((-23431 : ℝ) / 376569))
    (lo := ((-62302815863 : ℝ) / 500000000000)) (hi := ((-4984225269 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((176569 : ℝ) / 3200000) = Real.log ((176569 : ℝ) / 200000) - 4 * Real.log 2 := by
    rw [show ((176569 : ℝ) / 3200000) = ((176569 : ℝ) / 200000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_243 : RB (Real.log ((134080692259 : ℝ) / 200000000000)) ((-399875566801 : ℝ) / 1000000000000) ((-79975113359 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((134080692259 : ℝ) / 200000000000)) (t := ((-65919307741 : ℝ) / 334080692259))
    (lo := ((-399875566801 : ℝ) / 1000000000000)) (hi := ((-79975113359 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_244 : RB (Real.log ((1676273207 : ℝ) / 2500000000)) ((-79943546353 : ℝ) / 200000000000) ((-4996471647 : ℝ) / 12500000000) := by
  have hm := log_bounds_of_series (x := ((1676273207 : ℝ) / 2500000000)) (t := ((-823726793 : ℝ) / 4176273207))
    (lo := ((-79943546353 : ℝ) / 200000000000)) (hi := ((-4996471647 : ℝ) / 12500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_245 : RB (Real.log ((403164904703 : ℝ) / 1000000000000)) ((-908409607921 : ℝ) / 1000000000000) ((-908409607919 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((403164904703 : ℝ) / 500000000000)) (t := ((-96835095297 : ℝ) / 903164904703))
    (lo := ((-215262427361 : ℝ) / 1000000000000)) (hi := ((-1345390171 : ℝ) / 6250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((403164904703 : ℝ) / 1000000000000) = Real.log ((403164904703 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((403164904703 : ℝ) / 1000000000000) = ((403164904703 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_246 : RB (Real.log ((1646760397609 : ℝ) / 500000000000)) ((238391428619 : ℝ) / 200000000000) ((1191957143097 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1646760397609 : ℝ) / 2000000000000)) (t := ((-353239602391 : ℝ) / 3646760397609))
    (lo := ((-24292152253 : ℝ) / 125000000000)) (hi := ((-194337218023 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1646760397609 : ℝ) / 500000000000) = Real.log ((1646760397609 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1646760397609 : ℝ) / 500000000000) = ((1646760397609 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_247 : RB (Real.log ((102927065367 : ℝ) / 31250000000)) ((1192001257989 : ℝ) / 1000000000000) ((1192001257991 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((102927065367 : ℝ) / 125000000000)) (t := ((-22072934633 : ℝ) / 227927065367))
    (lo := ((-19429310313 : ℝ) / 100000000000)) (hi := ((-194293103129 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((102927065367 : ℝ) / 31250000000) = Real.log ((102927065367 : ℝ) / 125000000000) + 2 * Real.log 2 := by
    rw [show ((102927065367 : ℝ) / 31250000000) = ((102927065367 : ℝ) / 125000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_248 : RB (Real.log ((358670849103 : ℝ) / 250000000000)) ((36094419519 : ℝ) / 100000000000) ((45118024399 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((358670849103 : ℝ) / 500000000000)) (t := ((-141329150897 : ℝ) / 858670849103))
    (lo := ((-332202985369 : ℝ) / 1000000000000)) (hi := ((-41525373171 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((358670849103 : ℝ) / 250000000000) = Real.log ((358670849103 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((358670849103 : ℝ) / 250000000000) = ((358670849103 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_249 : RB (Real.log ((1055177812499 : ℝ) / 1000000000000)) ((53709295379 : ℝ) / 1000000000000) ((2685464769 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((1055177812499 : ℝ) / 1000000000000)) (t := ((55177812499 : ℝ) / 2055177812499))
    (lo := ((53709295379 : ℝ) / 1000000000000)) (hi := ((2685464769 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_250 : RB (Real.log ((337841 : ℝ) / 320000)) ((6781796851 : ℝ) / 125000000000) ((54254374809 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((337841 : ℝ) / 320000)) (t := ((17841 : ℝ) / 657841))
    (lo := ((6781796851 : ℝ) / 125000000000)) (hi := ((54254374809 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_251 : RB (Real.log ((55177812499 : ℝ) / 1000000000000)) ((-45268661781 : ℝ) / 15625000000) ((-1448597176991 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((55177812499 : ℝ) / 62500000000)) (t := ((-7322187501 : ℝ) / 117677812499))
    (lo := ((-486740749 : ℝ) / 3906250000)) (hi := ((-124605631743 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((55177812499 : ℝ) / 1000000000000) = Real.log ((55177812499 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((55177812499 : ℝ) / 1000000000000) = ((55177812499 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_252 : RB (Real.log ((17841 : ℝ) / 320000)) ((-1443410908201 : ℝ) / 500000000000) ((-7217054541 : ℝ) / 2500000000) := by
  have hm := log_bounds_of_series (x := ((17841 : ℝ) / 20000)) (t := ((-2159 : ℝ) / 37841))
    (lo := ((-57116547081 : ℝ) / 500000000000)) (hi := ((-114233094161 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17841 : ℝ) / 320000) = Real.log ((17841 : ℝ) / 20000) - 4 * Real.log 2 := by
    rw [show ((17841 : ℝ) / 320000) = ((17841 : ℝ) / 20000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_253 : RB (Real.log ((333343747589 : ℝ) / 500000000000)) ((-50679233229 : ℝ) / 125000000000) ((-202716932913 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((333343747589 : ℝ) / 500000000000)) (t := ((-166656252411 : ℝ) / 833343747589))
    (lo := ((-50679233229 : ℝ) / 125000000000)) (hi := ((-202716932913 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_254 : RB (Real.log ((41674637173 : ℝ) / 62500000000)) ((-405273834253 : ℝ) / 1000000000000) ((-405273834247 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((41674637173 : ℝ) / 62500000000)) (t := ((-20825362827 : ℝ) / 104174637173))
    (lo := ((-405273834253 : ℝ) / 1000000000000)) (hi := ((-405273834247 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_255 : RB (Real.log ((50234065179 : ℝ) / 125000000000)) ((-5697627197 : ℝ) / 6250000000) ((-455810175759 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((50234065179 : ℝ) / 62500000000)) (t := ((-12265934821 : ℝ) / 112734065179))
    (lo := ((-2730914637 : ℝ) / 12500000000)) (hi := ((-218473170959 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((50234065179 : ℝ) / 125000000000) = Real.log ((50234065179 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((50234065179 : ℝ) / 125000000000) = ((50234065179 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_256 : RB (Real.log ((822916342969 : ℝ) / 250000000000)) ((1191393628763 : ℝ) / 1000000000000) ((238278725753 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((822916342969 : ℝ) / 1000000000000)) (t := ((-177083657031 : ℝ) / 1822916342969))
    (lo := ((-48725183089 : ℝ) / 250000000000)) (hi := ((-38980146471 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((822916342969 : ℝ) / 250000000000) = Real.log ((822916342969 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((822916342969 : ℝ) / 250000000000) = ((822916342969 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_257 : RB (Real.log ((658362416379 : ℝ) / 200000000000)) ((7446488737 : ℝ) / 6250000000) ((595719098961 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((658362416379 : ℝ) / 800000000000)) (t := ((-141637583621 : ℝ) / 1458362416379))
    (lo := ((-194856163199 : ℝ) / 1000000000000)) (hi := ((-97428081599 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((658362416379 : ℝ) / 200000000000) = Real.log ((658362416379 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((658362416379 : ℝ) / 200000000000) = ((658362416379 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_258 : RB (Real.log ((717503742319 : ℝ) / 500000000000)) ((90292516243 : ℝ) / 250000000000) ((180585032487 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((717503742319 : ℝ) / 1000000000000)) (t := ((-282496257681 : ℝ) / 1717503742319))
    (lo := ((-331977115587 : ℝ) / 1000000000000)) (hi := ((-165988557793 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((717503742319 : ℝ) / 500000000000) = Real.log ((717503742319 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((717503742319 : ℝ) / 500000000000) = ((717503742319 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_259 : RB (Real.log ((1055753124999 : ℝ) / 1000000000000)) ((54254374807 : ℝ) / 1000000000000) ((6781796851 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((1055753124999 : ℝ) / 1000000000000)) (t := ((55753124999 : ℝ) / 2055753124999))
    (lo := ((54254374807 : ℝ) / 1000000000000)) (hi := ((6781796851 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_260 : RB (Real.log ((3380251 : ℝ) / 3200000)) ((54799157287 : ℝ) / 1000000000000) ((6849894661 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((3380251 : ℝ) / 3200000)) (t := ((180251 : ℝ) / 6580251))
    (lo := ((54799157287 : ℝ) / 1000000000000)) (hi := ((6849894661 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_261 : RB (Real.log ((55753124999 : ℝ) / 1000000000000)) ((-144341090821 : ℝ) / 50000000000) ((-1443410908209 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((55753124999 : ℝ) / 62500000000)) (t := ((-6746875001 : ℝ) / 118253124999))
    (lo := ((-5711654709 : ℝ) / 50000000000)) (hi := ((-114233094179 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((55753124999 : ℝ) / 1000000000000) = Real.log ((55753124999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((55753124999 : ℝ) / 1000000000000) = ((55753124999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_262 : RB (Real.log ((180251 : ℝ) / 3200000)) ((-2876555764789 : ℝ) / 1000000000000) ((-2876555764787 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((180251 : ℝ) / 200000)) (t := ((-19749 : ℝ) / 380251))
    (lo := ((-103967042549 : ℝ) / 1000000000000)) (hi := ((-25991760637 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((180251 : ℝ) / 3200000) = Real.log ((180251 : ℝ) / 200000) - 4 * Real.log 2 := by
    rw [show ((180251 : ℝ) / 3200000) = ((180251 : ℝ) / 200000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_263 : RB (Real.log ((662970659437 : ℝ) / 1000000000000)) ((-411024544019 : ℝ) / 1000000000000) ((-411024544017 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((662970659437 : ℝ) / 500000000000)) (t := ((162970659437 : ℝ) / 1162970659437))
    (lo := ((282122636541 : ℝ) / 1000000000000)) (hi := ((141061318271 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((662970659437 : ℝ) / 1000000000000) = Real.log ((662970659437 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((662970659437 : ℝ) / 1000000000000) = ((662970659437 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_264 : RB (Real.log ((132615646461 : ℝ) / 200000000000)) ((-82172459663 : ℝ) / 200000000000) ((-410862298313 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((132615646461 : ℝ) / 100000000000)) (t := ((32615646461 : ℝ) / 232615646461))
    (lo := ((56456976449 : ℝ) / 200000000000)) (hi := ((141142441123 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((132615646461 : ℝ) / 200000000000) = Real.log ((132615646461 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((132615646461 : ℝ) / 200000000000) = ((132615646461 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_265 : RB (Real.log ((400574447017 : ℝ) / 1000000000000)) ((-914855644563 : ℝ) / 1000000000000) ((-914855644561 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((400574447017 : ℝ) / 500000000000)) (t := ((-99425552983 : ℝ) / 900574447017))
    (lo := ((-221708464003 : ℝ) / 1000000000000)) (hi := ((-110854232001 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((400574447017 : ℝ) / 1000000000000) = Real.log ((400574447017 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((400574447017 : ℝ) / 1000000000000) = ((400574447017 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_266 : RB (Real.log ((1644898142003 : ℝ) / 500000000000)) ((37213301347 : ℝ) / 31250000000) ((595412821553 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1644898142003 : ℝ) / 2000000000000)) (t := ((-355101857997 : ℝ) / 3644898142003))
    (lo := ((-39093743603 : ℝ) / 200000000000)) (hi := ((-97734359007 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1644898142003 : ℝ) / 500000000000) = Real.log ((1644898142003 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1644898142003 : ℝ) / 500000000000) = ((1644898142003 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_267 : RB (Real.log ((3289944404449 : ℝ) / 1000000000000)) ((1190870666289 : ℝ) / 1000000000000) ((1190870666291 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3289944404449 : ℝ) / 4000000000000)) (t := ((-710055595551 : ℝ) / 7289944404449))
    (lo := ((-19542369483 : ℝ) / 100000000000)) (hi := ((-195423694829 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3289944404449 : ℝ) / 1000000000000) = Real.log ((3289944404449 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3289944404449 : ℝ) / 1000000000000) = ((3289944404449 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_268 : RB (Real.log ((71766720343 : ℝ) / 50000000000)) ((361397858201 : ℝ) / 1000000000000) ((361397858203 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((71766720343 : ℝ) / 100000000000)) (t := ((-28233279657 : ℝ) / 171766720343))
    (lo := ((-165874661179 : ℝ) / 500000000000)) (hi := ((-331749322357 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71766720343 : ℝ) / 50000000000) = Real.log ((71766720343 : ℝ) / 100000000000) + 1 * Real.log 2 := by
    rw [show ((71766720343 : ℝ) / 50000000000) = ((71766720343 : ℝ) / 100000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_269 : RB (Real.log ((1056328437499 : ℝ) / 1000000000000)) ((27399578643 : ℝ) / 500000000000) ((54799157287 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1056328437499 : ℝ) / 1000000000000)) (t := ((56328437499 : ℝ) / 2056328437499))
    (lo := ((27399578643 : ℝ) / 500000000000)) (hi := ((54799157287 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_270 : RB (Real.log ((845523 : ℝ) / 800000)) ((55343643139 : ℝ) / 1000000000000) ((2767182157 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((845523 : ℝ) / 800000)) (t := ((45523 : ℝ) / 1645523))
    (lo := ((55343643139 : ℝ) / 1000000000000)) (hi := ((2767182157 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_271 : RB (Real.log ((56328437499 : ℝ) / 1000000000000)) ((-1438277882403 : ℝ) / 500000000000) ((-719138941201 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((56328437499 : ℝ) / 62500000000)) (t := ((-6171562501 : ℝ) / 118828437499))
    (lo := ((-51983521283 : ℝ) / 500000000000)) (hi := ((-20793408513 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((56328437499 : ℝ) / 1000000000000) = Real.log ((56328437499 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((56328437499 : ℝ) / 1000000000000) = ((56328437499 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_272 : RB (Real.log ((45523 : ℝ) / 800000)) ((-1433197017463 : ℝ) / 500000000000) ((-716598508731 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((45523 : ℝ) / 50000)) (t := ((-4477 : ℝ) / 95523))
    (lo := ((-46902656343 : ℝ) / 500000000000)) (hi := ((-18761062537 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45523 : ℝ) / 800000) = Real.log ((45523 : ℝ) / 50000) - 4 * Real.log 2 := by
    rw [show ((45523 : ℝ) / 800000) = ((45523 : ℝ) / 50000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_273 : RB (Real.log ((164813247387 : ℝ) / 250000000000)) ((-104161979747 : ℝ) / 250000000000) ((-208323959493 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((164813247387 : ℝ) / 125000000000)) (t := ((39813247387 : ℝ) / 289813247387))
    (lo := ((69124815393 : ℝ) / 250000000000)) (hi := ((276499261573 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((164813247387 : ℝ) / 250000000000) = Real.log ((164813247387 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((164813247387 : ℝ) / 250000000000) = ((164813247387 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_274 : RB (Real.log ((659361430887 : ℝ) / 1000000000000)) ((-650755377 : ℝ) / 1562500000) ((-208241720639 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((659361430887 : ℝ) / 500000000000)) (t := ((159361430887 : ℝ) / 1159361430887))
    (lo := ((3458296741 : ℝ) / 12500000000)) (hi := ((276663739281 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((659361430887 : ℝ) / 1000000000000) = Real.log ((659361430887 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((659361430887 : ℝ) / 1000000000000) = ((659361430887 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_275 : RB (Real.log ((79854130803 : ℝ) / 200000000000)) ((-918115761191 : ℝ) / 1000000000000) ((-918115761189 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((79854130803 : ℝ) / 100000000000)) (t := ((-20145869197 : ℝ) / 179854130803))
    (lo := ((-224968580631 : ℝ) / 1000000000000)) (hi := ((-22496858063 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((79854130803 : ℝ) / 200000000000) = Real.log ((79854130803 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((79854130803 : ℝ) / 200000000000) = ((79854130803 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_276 : RB (Real.log ((3287913775007 : ℝ) / 1000000000000)) ((595126626351 : ℝ) / 500000000000) ((37195414147 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((3287913775007 : ℝ) / 4000000000000)) (t := ((-712086224993 : ℝ) / 7287913775007))
    (lo := ((-196041108417 : ℝ) / 1000000000000)) (hi := ((-3063142319 : ℝ) / 15625000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3287913775007 : ℝ) / 1000000000000) = Real.log ((3287913775007 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3287913775007 : ℝ) / 1000000000000) = ((3287913775007 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_277 : RB (Real.log ((822015825699 : ℝ) / 250000000000)) ((595149364841 : ℝ) / 500000000000) ((297574682421 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((822015825699 : ℝ) / 1000000000000)) (t := ((-177984174301 : ℝ) / 1822015825699))
    (lo := ((-195995631437 : ℝ) / 1000000000000)) (hi := ((-48998907859 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((822015825699 : ℝ) / 250000000000) = Real.log ((822015825699 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((822015825699 : ℝ) / 250000000000) = ((822015825699 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_278 : RB (Real.log ((1435664129533 : ℝ) / 1000000000000)) ((45203443773 : ℝ) / 125000000000) ((361627550187 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1435664129533 : ℝ) / 2000000000000)) (t := ((-564335870467 : ℝ) / 3435664129533))
    (lo := ((-2652157043 : ℝ) / 8000000000)) (hi := ((-331519630373 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1435664129533 : ℝ) / 1000000000000) = Real.log ((1435664129533 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1435664129533 : ℝ) / 1000000000000) = ((1435664129533 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_279 : RB (Real.log ((1056903749999 : ℝ) / 1000000000000)) ((27671821569 : ℝ) / 500000000000) ((55343643139 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1056903749999 : ℝ) / 1000000000000)) (t := ((56903749999 : ℝ) / 2056903749999))
    (lo := ((27671821569 : ℝ) / 500000000000)) (hi := ((55343643139 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_280 : RB (Real.log ((1692887 : ℝ) / 1600000)) ((11286345251 : ℝ) / 200000000000) ((3526982891 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((1692887 : ℝ) / 1600000)) (t := ((92887 : ℝ) / 3292887))
    (lo := ((11286345251 : ℝ) / 200000000000)) (hi := ((3526982891 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_281 : RB (Real.log ((56903749999 : ℝ) / 1000000000000)) ((-2866394034943 : ℝ) / 1000000000000) ((-2866394034941 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((56903749999 : ℝ) / 62500000000)) (t := ((-5596250001 : ℝ) / 119403749999))
    (lo := ((-93805312703 : ℝ) / 1000000000000)) (hi := ((-46902656351 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((56903749999 : ℝ) / 1000000000000) = Real.log ((56903749999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((56903749999 : ℝ) / 1000000000000) = ((56903749999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_282 : RB (Real.log ((92887 : ℝ) / 1600000)) ((-569275041523 : ℝ) / 200000000000) ((-2846375207613 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((92887 : ℝ) / 100000)) (t := ((-7113 : ℝ) / 192887))
    (lo := ((-590291883 : ℝ) / 8000000000)) (hi := ((-36893242687 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92887 : ℝ) / 1600000) = Real.log ((92887 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((92887 : ℝ) / 1600000) = ((92887 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_283 : RB (Real.log ((332105192371 : ℝ) / 500000000000)) ((-511445419 : ℝ) / 1250000000) ((-204578167599 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((332105192371 : ℝ) / 250000000000)) (t := ((82105192371 : ℝ) / 582105192371))
    (lo := ((3549885567 : ℝ) / 12500000000)) (hi := ((283990845361 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((332105192371 : ℝ) / 500000000000) = Real.log ((332105192371 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((332105192371 : ℝ) / 500000000000) = ((332105192371 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_284 : RB (Real.log ((664431260417 : ℝ) / 1000000000000)) ((-408823851753 : ℝ) / 1000000000000) ((-408823851751 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((664431260417 : ℝ) / 500000000000)) (t := ((164431260417 : ℝ) / 1164431260417))
    (lo := ((284323328807 : ℝ) / 1000000000000)) (hi := ((35540416101 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((664431260417 : ℝ) / 1000000000000) = Real.log ((664431260417 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((664431260417 : ℝ) / 1000000000000) = ((664431260417 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_285 : RB (Real.log ((80227920859 : ℝ) / 200000000000)) ((-228361442969 : ℝ) / 250000000000) ((-456722885937 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((80227920859 : ℝ) / 100000000000)) (t := ((-19772079141 : ℝ) / 180227920859))
    (lo := ((-55074647829 : ℝ) / 250000000000)) (hi := ((-44059718263 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((80227920859 : ℝ) / 200000000000) = Real.log ((80227920859 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((80227920859 : ℝ) / 200000000000) = ((80227920859 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_286 : RB (Real.log ((329565457471 : ℝ) / 100000000000)) ((149075600649 : ℝ) / 125000000000) ((596302402597 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((329565457471 : ℝ) / 400000000000)) (t := ((-70434542529 : ℝ) / 729565457471))
    (lo := ((-193689555927 : ℝ) / 1000000000000)) (hi := ((-96844777963 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((329565457471 : ℝ) / 100000000000) = Real.log ((329565457471 : ℝ) / 400000000000) + 2 * Real.log 2 := by
    rw [show ((329565457471 : ℝ) / 100000000000) = ((329565457471 : ℝ) / 400000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_287 : RB (Real.log ((1647979628147 : ℝ) / 500000000000)) ((149087156301 : ℝ) / 125000000000) ((119269725041 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((1647979628147 : ℝ) / 2000000000000)) (t := ((-352020371853 : ℝ) / 3647979628147))
    (lo := ((-193597110711 : ℝ) / 1000000000000)) (hi := ((-19359711071 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1647979628147 : ℝ) / 500000000000) = Real.log ((1647979628147 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1647979628147 : ℝ) / 500000000000) = ((1647979628147 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_288 : RB (Real.log ((1434137478923 : ℝ) / 1000000000000)) ((360563608517 : ℝ) / 1000000000000) ((360563608519 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1434137478923 : ℝ) / 2000000000000)) (t := ((-565862521077 : ℝ) / 3434137478923))
    (lo := ((-166291786021 : ℝ) / 500000000000)) (hi := ((-332583572041 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1434137478923 : ℝ) / 1000000000000) = Real.log ((1434137478923 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1434137478923 : ℝ) / 1000000000000) = ((1434137478923 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_289 : RB (Real.log ((1058054374999 : ℝ) / 1000000000000)) ((28215863127 : ℝ) / 500000000000) ((11286345251 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1058054374999 : ℝ) / 1000000000000)) (t := ((58054374999 : ℝ) / 2058054374999))
    (lo := ((28215863127 : ℝ) / 500000000000)) (hi := ((11286345251 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_290 : RB (Real.log ((211841 : ℝ) / 200000)) ((57518626733 : ℝ) / 1000000000000) ((28759313367 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((211841 : ℝ) / 200000)) (t := ((11841 : ℝ) / 411841))
    (lo := ((57518626733 : ℝ) / 1000000000000)) (hi := ((28759313367 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_291 : RB (Real.log ((58054374999 : ℝ) / 1000000000000)) ((-177898450477 : ℝ) / 62500000000) ((-284637520763 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((58054374999 : ℝ) / 62500000000)) (t := ((-4445625001 : ℝ) / 120554374999))
    (lo := ((-4611655337 : ℝ) / 62500000000)) (hi := ((-73786485391 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((58054374999 : ℝ) / 1000000000000) = Real.log ((58054374999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((58054374999 : ℝ) / 1000000000000) = ((58054374999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_292 : RB (Real.log ((11841 : ℝ) / 200000)) ((-7066873203 : ℝ) / 2500000000) ((-1413374640599 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((11841 : ℝ) / 12500)) (t := ((-659 : ℝ) / 24341))
    (lo := ((-677006987 : ℝ) / 12500000000)) (hi := ((-54160558959 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11841 : ℝ) / 200000) = Real.log ((11841 : ℝ) / 12500) - 4 * Real.log 2 := by
    rw [show ((11841 : ℝ) / 200000) = ((11841 : ℝ) / 12500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_293 : RB (Real.log ((656885313971 : ℝ) / 1000000000000)) ((-420245835901 : ℝ) / 1000000000000) ((-420245835899 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((656885313971 : ℝ) / 500000000000)) (t := ((156885313971 : ℝ) / 1156885313971))
    (lo := ((272901344659 : ℝ) / 1000000000000)) (hi := ((13645067233 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((656885313971 : ℝ) / 1000000000000) = Real.log ((656885313971 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((656885313971 : ℝ) / 1000000000000) = ((656885313971 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_294 : RB (Real.log ((657109649887 : ℝ) / 1000000000000)) ((-209952189809 : ℝ) / 500000000000) ((-13122011863 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((657109649887 : ℝ) / 500000000000)) (t := ((157109649887 : ℝ) / 1157109649887))
    (lo := ((136621400471 : ℝ) / 500000000000)) (hi := ((273242800943 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((657109649887 : ℝ) / 1000000000000) = Real.log ((657109649887 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((657109649887 : ℝ) / 1000000000000) = ((657109649887 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_295 : RB (Real.log ((398573480269 : ℝ) / 1000000000000)) ((-114982925701 : ℝ) / 125000000000) ((-459931702803 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((398573480269 : ℝ) / 500000000000)) (t := ((-101426519731 : ℝ) / 898573480269))
    (lo := ((-28339528131 : ℝ) / 125000000000)) (hi := ((-226716225047 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((398573480269 : ℝ) / 1000000000000) = Real.log ((398573480269 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((398573480269 : ℝ) / 1000000000000) = ((398573480269 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_296 : RB (Real.log ((3291781131239 : ℝ) / 1000000000000)) ((29785719889 : ℝ) / 25000000000) ((595714397781 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3291781131239 : ℝ) / 4000000000000)) (t := ((-708218868761 : ℝ) / 7291781131239))
    (lo := ((-194865565559 : ℝ) / 1000000000000)) (hi := ((-97432782779 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3291781131239 : ℝ) / 1000000000000) = Real.log ((3291781131239 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3291781131239 : ℝ) / 1000000000000) = ((3291781131239 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_297 : RB (Real.log ((1646045714807 : ℝ) / 500000000000)) ((1191523055701 : ℝ) / 1000000000000) ((1191523055703 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1646045714807 : ℝ) / 2000000000000)) (t := ((-353954285193 : ℝ) / 3646045714807))
    (lo := ((-97385652709 : ℝ) / 500000000000)) (hi := ((-194771305417 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1646045714807 : ℝ) / 500000000000) = Real.log ((1646045714807 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1646045714807 : ℝ) / 500000000000) = ((1646045714807 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_298 : RB (Real.log ((717406181243 : ℝ) / 500000000000)) ((361034082811 : ℝ) / 1000000000000) ((361034082813 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((717406181243 : ℝ) / 1000000000000)) (t := ((-282593818757 : ℝ) / 1717406181243))
    (lo := ((-83028274437 : ℝ) / 250000000000)) (hi := ((-332113097747 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((717406181243 : ℝ) / 500000000000) = Real.log ((717406181243 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((717406181243 : ℝ) / 500000000000) = ((717406181243 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_299 : RB (Real.log ((1059204999999 : ℝ) / 1000000000000)) ((14379656683 : ℝ) / 250000000000) ((57518626733 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1059204999999 : ℝ) / 1000000000000)) (t := ((59204999999 : ℝ) / 2059204999999))
    (lo := ((14379656683 : ℝ) / 250000000000)) (hi := ((57518626733 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
