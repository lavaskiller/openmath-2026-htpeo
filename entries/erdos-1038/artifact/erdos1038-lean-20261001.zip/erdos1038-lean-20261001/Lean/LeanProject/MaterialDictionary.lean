import LeanProject.SupportingAdjoint
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

/-!
# The material difference quotient and the spatial adjoint integral

The material expression is defined independently of `HT`. Its platform term
cancels by an explicitly computed density transform. The spatial adjoint measure
is a push-forward of its angular density, with integrability proved separately.
This does not yet differentiate the moving logarithmic potential at block points.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Polynomial
open scoped ENNReal

namespace EP1038.Stage11
open EP1038.Arc AngleReference

theorem int_Pq_half {ρ : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ < 1) :
    (∫ φ in (0 : ℝ)..π, Pq ρ φ) = π := by
  simpa using int_Pq_cos_half h0 h1 0

theorem HT_alpha {k ρ θ : ℝ} (h0 : 0 < ρ) (h1 : ρ < 1) (hθ : θ ∈ Icc (0 : ℝ) π) :
    HT (alpha k ρ) θ = 2 * k * ρ / (1 - ρ ^ 2) * Pq ρ θ := by
  have hN : 1 - ρ ^ 2 ≠ 0 := by nlinarith
  have heq : ∀ᵐ φ ∂volume, φ ∈ uIoc (0 : ℝ) π →
      (alpha k ρ φ - alpha k ρ θ) / (cos θ - cos φ) =
        (2 * k * ρ / (1 - ρ ^ 2) * Pq ρ θ) * Pq ρ φ := by
    filter_upwards [EP1038.Stage9.ae_ne_real θ] with φ hφ hmem
    rw [uIoc_of_le Real.pi_pos.le] at hmem
    have hc : cos θ - cos φ ≠ 0 := by
      intro hh
      exact hφ (Real.injOn_cos ⟨hmem.1.le, hmem.2⟩ hθ (by linarith))
    have hDθ := (Pq_den_pos h0.le h1 θ).ne'
    have hDφ := (Pq_den_pos h0.le h1 φ).ne'
    let D := fun t => 1 - 2 * ρ * cos t + ρ ^ 2
    change D θ ≠ 0 at hDθ
    change D φ ≠ 0 at hDφ
    change ((k + 1 - k * ((1 - ρ ^ 2) / D φ)) -
      (k + 1 - k * ((1 - ρ ^ 2) / D θ))) / (cos θ - cos φ) =
        (2 * k * ρ / (1 - ρ ^ 2) * ((1 - ρ ^ 2) / D θ)) * ((1 - ρ ^ 2) / D φ)
    field_simp [hDθ, hDφ, hN, hc]
    dsimp [D]
    ring
  rw [HT, intervalIntegral.integral_congr_ae heq, intervalIntegral.integral_const_mul,
    int_Pq_half h0.le h1]
  field_simp

theorem platform_density_transform {k ρ c r θ : ℝ} (hr : 0 < r)
    (h0 : 0 < ρ) (h1 : ρ < 1) (hzero : (0 : ℝ) = c - r / 2 * (ρ + 1 / ρ))
    (hθ : θ ∈ Icc (0 : ℝ) π) : HT (alpha k ρ) θ / r = k / position c r θ := by
  rw [HT_alpha h0 h1 hθ, poisson_exterior hr h0 h1 hzero θ, sub_zero]
  have hN : 1 - ρ ^ 2 ≠ 0 := by nlinarith
  dsimp [Kr]
  field_simp

theorem XLip.dq_integrable {M : ℝ} {f : ℝ → ℝ} (hf : XLip M f) (hM : 0 ≤ M) (θ : ℝ) :
    IntervalIntegrable (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le]
  exact Measure.integrableOn_of_bounded measure_Ioc_lt_top.ne
    (dq_meas hf.continuous θ).aestronglyMeasurable
    (Eventually.of_forall fun φ => by rw [Real.norm_eq_abs]; exact dq_bound hf hM θ φ)

noncomputable def materialKernel (k ρ c r : ℝ) (v : ℝ → ℝ) (p : ℝ × ℝ) : ℝ :=
  (v p.2 - v p.1) / (position c r p.2 - position c r p.1) * alpha k ρ p.2

noncomputable def materialAngular (k ρ c r : ℝ) (v : ℝ → ℝ) (θ : ℝ) : ℝ :=
  k * v θ / position c r θ + 1 / π * ∫ φ in (0 : ℝ)..π, materialKernel k ρ c r v (θ, φ)

theorem materialAngular_measurable {k ρ c r : ℝ} {v : ℝ → ℝ}
    (hv : Measurable v) (h0 : 0 ≤ ρ) (h1 : ρ < 1) : Measurable (materialAngular k ρ c r v) := by
  have hp : Continuous (position c r) := by unfold position; fun_prop
  have hk : Measurable (materialKernel k ρ c r v) :=
    ((hv.comp measurable_snd).sub (hv.comp measurable_fst)).div
      ((hp.measurable.comp measurable_snd).sub (hp.measurable.comp measurable_fst)) |>.mul
        ((alpha_cont k ρ h0 h1).measurable.comp measurable_snd)
  have hi := hk.stronglyMeasurable.integral_prod_right' (ν := angleMeasure)
  unfold materialAngular
  simp_rw [intervalIntegral.integral_of_le Real.pi_pos.le]
  exact ((measurable_const.mul hv).div hp.measurable).add (measurable_const.mul hi.measurable)

/-- Independent algebraic identification of the material formula, at each point
where the difference quotient of the weighted velocity is integrable. -/
theorem materialAngular_eq_HT {k ρ c r θ : ℝ} {v : ℝ → ℝ}
    (hr : 0 < r) (hk : 0 ≤ k) (h0 : 0 < ρ) (h1 : ρ < 1)
    (hzero : (0 : ℝ) = c - r / 2 * (ρ + 1 / ρ)) (hθ : θ ∈ Icc (0 : ℝ) π)
    (hF : IntervalIntegrable (fun φ =>
      (alpha k ρ φ * v φ - alpha k ρ θ * v θ) / (cos θ - cos φ)) volume 0 π) :
    materialAngular k ρ c r v θ = HT (fun φ => alpha k ρ φ * v φ) θ / r := by
  have hα := (alpha_XLip hk h0.le h1).dq_integrable
    (mul_nonneg hk (poissonLip_nonneg h0.le h1)) θ
  have heq : (fun φ => materialKernel k ρ c r v (θ, φ)) =
      (fun φ => 1 / r * ((alpha k ρ φ * v φ - alpha k ρ θ * v θ) / (cos θ - cos φ)) -
        (v θ / r) * ((alpha k ρ φ - alpha k ρ θ) / (cos θ - cos φ))) := by
    funext φ
    dsimp [materialKernel, position]
    rw [show (c - r * cos φ) - (c - r * cos θ) = r * (cos θ - cos φ) by ring]
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  have hplat := platform_density_transform (k := k) hr h0 h1 hzero hθ
  dsimp [materialAngular]
  rw [heq, intervalIntegral.integral_sub (hF.const_mul _) (hα.const_mul _),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul]
  dsimp [HT] at hplat ⊢
  linear_combination -(v θ) * hplat

/-- Positivity of the adjoint weight makes the joint integrability sufficient
for integrability of the unweighted fiber almost everywhere. -/
theorem ae_dq_integrable {B f : ℝ → ℝ}
    (hf : Integrable (weightedDQ B f) (angleMeasure.prod angleMeasure))
    (hB : ∀ᵐ θ ∂angleMeasure, B θ ≠ 0) :
    ∀ᵐ θ ∂angleMeasure, IntervalIntegrable
      (fun φ => (f φ - f θ) / (cos θ - cos φ)) volume 0 π := by
  filter_upwards [hf.prod_right_ae, hB] with θ hθ hBθ
  have h := hθ.div_const (B θ)
  have heq : (fun φ => weightedDQ B f (θ, φ) / B θ) =
      (fun φ => (f φ - f θ) / (cos θ - cos φ)) := by
    funext φ
    dsimp [weightedDQ]
    rw [mul_div_cancel_right₀ _ hBθ]
  rw [heq] at h
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le]
  exact h

theorem Bxi_ne_zero_ae {ρ1 ρ2 σ1 σ2 : ℝ}
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 ≤ ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 < σ1) (hs2 : 0 ≤ σ2) : ∀ᵐ θ ∂angleMeasure, Bxi ρ1 ρ2 σ1 σ2 θ ≠ 0 := by
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with θ hθ
  have heq : Bxi ρ1 ρ2 σ1 σ2 θ = Bf σ1 σ2 ρ1 ρ2 θ := by dsimp [Bxi, Bf]; ring
  rw [heq]
  exact (Bf_pos hs1 hs2 h10 h11 h20 h21 hθ.1 hθ.2).ne'

noncomputable def angularAdjointMeasure (B : ℝ → ℝ) : Measure ℝ :=
  angleMeasure.withDensity (fun θ => ENNReal.ofReal (B θ / π))

noncomputable def spatialAdjointMeasure (c r : ℝ) (B : ℝ → ℝ) : Measure ℝ :=
  Measure.map (position c r) (angularAdjointMeasure B)

noncomputable def physicalAngle (c r d : ℝ) : ℝ := arccos ((c - d) / r)

theorem physicalAngle_position {c r θ : ℝ} (hr : 0 < r) (hθ : θ ∈ Icc (0 : ℝ) π) :
    physicalAngle c r (position c r θ) = θ := by
  dsimp [physicalAngle, position]
  rw [show c - (c - r * cos θ) = r * cos θ by ring, mul_div_cancel_left₀ _ hr.ne']
  exact Real.arccos_cos hθ.1 hθ.2

/-- Genuine change of variables for the spatial measure `dξ = B(θ) dθ/π`. -/
theorem integral_spatialAdjoint {c r : ℝ} {B g : ℝ → ℝ} (hr : 0 < r)
    (hB : Measurable B) (hBn : ∀ θ, 0 ≤ B θ) (hg : Measurable g) :
    (∫ d, g (physicalAngle c r d) ∂spatialAdjointMeasure c r B) =
      1 / π * ∫ θ in (0 : ℝ)..π, g θ * B θ := by
  have hden : Measurable (fun θ => ENNReal.ofReal (B θ / π)) :=
    ENNReal.measurable_ofReal.comp (hB.div_const π)
  change (∫ d, (g ∘ physicalAngle c r) d
    ∂Measure.map (position c r) (angularAdjointMeasure B)) = _
  rw [MeasureTheory.integral_map_of_stronglyMeasurable (by
    unfold position; fun_prop) (hg.comp (by unfold physicalAngle; fun_prop)).stronglyMeasurable,
    angularAdjointMeasure, integral_withDensity_eq_integral_toReal_smul hden
      (Eventually.of_forall fun θ => ENNReal.ofReal_lt_top)]
  have heq : (fun θ => (ENNReal.ofReal (B θ / π)).toReal • g (physicalAngle c r (position c r θ)))
      =ᵐ[angleMeasure] (fun θ => 1 / π * (g θ * B θ)) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with θ hθ
    rw [ENNReal.toReal_ofReal (div_nonneg (hBn θ) Real.pi_pos.le), smul_eq_mul,
      physicalAngle_position hr ⟨hθ.1.le, hθ.2⟩]
    ring
  simp only [Function.comp_apply]
  rw [MeasureTheory.integral_congr_ae heq, MeasureTheory.integral_const_mul,
    intervalIntegral.integral_of_le Real.pi_pos.le]
  rfl

theorem integrable_spatialAdjoint {c r : ℝ} {B g : ℝ → ℝ} (hr : 0 < r)
    (hB : Measurable B) (hBn : ∀ θ, 0 ≤ B θ) (hg : Measurable g)
    (hgi : Integrable (fun θ => g θ * B θ) angleMeasure) :
    Integrable (fun d => g (physicalAngle c r d)) (spatialAdjointMeasure c r B) := by
  have hden : Measurable (fun θ => ENNReal.ofReal (B θ / π)) :=
    ENNReal.measurable_ofReal.comp (hB.div_const π)
  have hp : Measurable (position c r) := by unfold position; fun_prop
  have hg' : Measurable (fun d => g (physicalAngle c r d)) := hg.comp (by unfold physicalAngle; fun_prop)
  rw [spatialAdjointMeasure]
  apply (integrable_map_measure hg'.aestronglyMeasurable hp.aemeasurable).mpr
  rw [angularAdjointMeasure, integrable_withDensity_iff hden
    (Eventually.of_forall fun θ => ENNReal.ofReal_lt_top)]
  apply (hgi.const_mul (1 / π)).congr
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with θ hθ
  rw [ENNReal.toReal_ofReal (div_nonneg (hBn θ) Real.pi_pos.le)]
  change 1 / π * (g θ * B θ) = g (physicalAngle c r (position c r θ)) * (B θ / π)
  rw [physicalAngle_position hr ⟨hθ.1.le, hθ.2⟩]
  ring

namespace AngleReference

noncomputable def angularDrift (A : AngleReference) (c r : ℝ) (T : ℝ → ℝ) (θ : ℝ) : ℝ :=
  A.angularTarget T θ - position c r θ

noncomputable def spatialMaterial (A : AngleReference) (c r : ℝ) (T : ℝ → ℝ) (d : ℝ) : ℝ :=
  materialAngular A.k A.ρ c r (A.angularDrift c r T) (physicalAngle c r d)

theorem angularDrift_measurable (A : AngleReference) (c r : ℝ) {T : ℝ → ℝ} (hT : Measurable T) :
    Measurable (A.angularDrift c r T) := by
  unfold angularDrift angularTarget
  exact (hT.comp (A.cdf_continuous.measurable.comp
    (Real.continuous_arccos.comp Real.continuous_cos).measurable)).sub (by unfold position; fun_prop)

/-- The independently defined material expression is the Hilbert expression almost everywhere. -/
theorem material_eq_HT_ae (A : AngleReference) {c r ρ1 ρ2 σ1 σ2 : ℝ} {T : ℝ → ℝ}
    (hr : 0 < r) (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 ≤ ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 < σ1) (hs2 : 0 ≤ σ2)
    (hzero : (0 : ℝ) = c - r / 2 * (A.ρ + 1 / A.ρ))
    (hFi : Integrable (weightedDQ (Bxi ρ1 ρ2 σ1 σ2) (A.angularVelocity c r T))
      (angleMeasure.prod angleMeasure)) :
    (fun θ => materialAngular A.k A.ρ c r (A.angularDrift c r T) θ) =ᵐ[angleMeasure]
      (fun θ => HT (A.angularVelocity c r T) θ / r) := by
  have hFib := ae_dq_integrable hFi (Bxi_ne_zero_ae h10 h11 h20 h21 hs1 hs2)
  filter_upwards [hFib, ae_restrict_mem measurableSet_Ioc] with θ hFθ hθ
  exact materialAngular_eq_HT hr A.k_pos.le A.rho_pos A.rho_lt_one hzero
    ⟨hθ.1.le, hθ.2⟩ hFθ

/-- The material expression is integrable against the spatial adjoint measure,
and its integral is exactly the previously proved adjoint term. -/
theorem material_integral_dictionary (A : AngleReference) {c r ρ1 ρ2 σ1 σ2 : ℝ} {T : ℝ → ℝ}
    (hT : Measurable T) (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 < σ1) (hs2 : 0 ≤ σ2)
    (hzero : (0 : ℝ) = c - r / 2 * (A.ρ + 1 / A.ρ))
    (hFi : Integrable (weightedDQ (Bxi ρ1 ρ2 σ1 σ2) (A.angularVelocity c r T))
      (angleMeasure.prod angleMeasure)) :
    Integrable (A.spatialMaterial c r T) (spatialAdjointMeasure c r (Bxi ρ1 ρ2 σ1 σ2)) ∧
      (∫ d, A.spatialMaterial c r T d ∂spatialAdjointMeasure c r (Bxi ρ1 ρ2 σ1 σ2)) =
        adjointIntegral r ρ1 ρ2 σ1 σ2 (A.angularVelocity c r T) := by
  let B := Bxi ρ1 ρ2 σ1 σ2
  let g := materialAngular A.k A.ρ c r (A.angularDrift c r T)
  have hB : Measurable B := (Bxi_cont h10.le h11 h20.le h21).measurable
  have hBn : ∀ θ, 0 ≤ B θ := fun θ => (Bxi_bounds h10.le h11 h20.le h21 hs1.le hs2 θ).1
  have hg : Measurable g := materialAngular_measurable (A.angularDrift_measurable c r hT)
    A.rho_pos.le A.rho_lt_one
  have heq := A.material_eq_HT_ae hr h10 h11 h20.le h21 hs1 hs2 hzero hFi
  have hht := integrable_HT_weight hFi
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le] at hht
  have hgb : Integrable (fun θ => g θ * B θ) angleMeasure := by
    apply (hht.div_const r).congr
    filter_upwards [heq] with θ hθ
    change (HT (A.angularVelocity c r T) θ * B θ) / r = g θ * B θ
    rw [show g θ = HT (A.angularVelocity c r T) θ / r from hθ]
    ring
  refine ⟨integrable_spatialAdjoint hr hB hBn hg hgb, ?_⟩
  change (∫ d, g (physicalAngle c r d) ∂spatialAdjointMeasure c r B) = _
  rw [integral_spatialAdjoint hr hB hBn hg]
  unfold adjointIntegral
  simp_rw [intervalIntegral.integral_of_le Real.pi_pos.le]
  change 1 / π * (∫ θ, g θ * B θ ∂angleMeasure) =
    1 / (π * r) * ∫ θ, HT (A.angularVelocity c r T) θ * B θ ∂angleMeasure
  have hgeq : (fun θ => g θ * B θ) =ᵐ[angleMeasure]
      (fun θ => 1 / r * (HT (A.angularVelocity c r T) θ * B θ)) := by
    filter_upwards [heq] with θ hθ
    rw [show g θ = HT (A.angularVelocity c r T) θ / r from hθ]
    ring
  rw [MeasureTheory.integral_congr_ae hgeq, MeasureTheory.integral_const_mul]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

end AngleReference

/-- The physical reference interval automatically supplies the platform compatibility. -/
theorem interval_zero_exterior {a : ℝ} (ha : 0 < a) (ha2 : a < 2) :
    (0 : ℝ) = (a + 2) / 2 - ((2 - a) / 2) / 2 * (qa a + 1 / qa a) := by
  have hq := (qa_pos ha ha2).ne'
  rw [show ((2 - a) / 2) / 2 = (2 - a) / 4 by ring,
    ← D0a_mul_one_add ha, ← D0a_mul_qa ha]
  field_simp
  ring

noncomputable def intervalReference (k a : ℝ) (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (t : ℝ) (ht0 : 0 < t) (hta : t < a)
    (hsep : Stage10.RS k ((AngleReference.ofInterval k a hk ha ha2 hH1).quantile
        ((a + 2) / 2) ((2 - a) / 2)) <
      Stage10.PsiS k ((AngleReference.ofInterval k a hk ha ha2 hH1).quantile
        ((a + 2) / 2) ((2 - a) / 2)) t) : SeparatedReference where
  angles := AngleReference.ofInterval k a hk ha ha2 hH1
  c := (a + 2) / 2
  r := (2 - a) / 2
  radius_pos := by linarith
  left_pos := by linarith
  end_eq_two := by ring
  separator := t
  separator_pos := ht0
  separator_lt_left := by linarith
  separation := hsep

theorem intervalReference_platform (k a : ℝ) (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (t : ℝ) (ht0 : 0 < t) (hta : t < a) (hsep) :
    let R := intervalReference k a hk ha ha2 hH1 t ht0 hta hsep
    (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) :=
  interval_zero_exterior ha ha2

namespace SeparatedReference

theorem residual_material_dictionary {n : ℕ} (R : SeparatedReference)
    (a : EP1038.NormalForm.NormalData n) (hres : 0 < a.residualCount)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    Integrable (R.angles.spatialMaterial R.c R.r (a.residualQuantile hres))
      (spatialAdjointMeasure R.c R.r (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)) ∧
      (∫ d, R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d
        ∂spatialAdjointMeasure R.c R.r (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)) =
          adjointIntegral R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
            (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) :=
  R.angles.material_integral_dictionary (EP1038.NormalForm.measurable_residualQuantile a hres)
    R.radius_pos R.rhoPlus_spec.1 R.rhoPlus_spec.2.1 R.rhoMinus_spec.1 R.rhoMinus_spec.2.1
    R.sigmaPlus_pos R.sigmaMinus_pos.le hzero (R.residual_adjoint_le_Mdot a hres).1.kernel

end SeparatedReference

theorem normal_form_material_supporting {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (R : SeparatedReference) (hk : R.angles.k = a.k)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    (volume (Stage10.correctedNegSet a.k R.quantile ∩ Iio R.separator)).toReal +
      (∫ d, R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d
        ∂spatialAdjointMeasure R.c R.r (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)) ≤
          Resid.rhoR a.roots (a.roots a.main) - Resid.ellL a.roots (a.roots a.main) := by
  rw [(R.residual_material_dictionary a hres hzero).2]
  exact normal_form_adjoint_supporting a hres R hk

/-- The arbitrary polynomial now supplies the actual target of the spatial material integral. -/
theorem polynomial_material_reduction {p : ℝ[X]} (hp : EP1038.Admissible p) :
    ENNReal.ofReal 2 ≤ EP1038.sublevelMeasure p ∨
      ∃ n : ℕ, ∃ a : EP1038.NormalForm.NormalData n, ∃ hres : 0 < a.residualCount,
        1 ≤ a.k ∧ a.J ≤ (EP1038.sublevelMeasure p).toReal ∧
          ∀ R : SeparatedReference, R.angles.k = a.k →
            (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) →
            (volume (Stage10.correctedNegSet a.k R.quantile ∩ Iio R.separator)).toReal +
              (∫ d, R.angles.spatialMaterial R.c R.r (a.residualQuantile hres) d
                ∂spatialAdjointMeasure R.c R.r (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)) +
                  2 * ∑ v ∈ a.residualIndices.image a.roots, Stage7.Rv a.roots v ≤
                    (EP1038.sublevelMeasure p).toReal := by
  rcases polynomial_adjoint_reduction hp with hbig | ⟨n, a, hres, hk, hJ, hs⟩
  · exact Or.inl hbig
  refine Or.inr ⟨n, a, hres, hk, hJ, ?_⟩
  intro R hR hzero
  rw [(R.residual_material_dictionary a hres hzero).2]
  exact hs R hR

end EP1038.Stage11
