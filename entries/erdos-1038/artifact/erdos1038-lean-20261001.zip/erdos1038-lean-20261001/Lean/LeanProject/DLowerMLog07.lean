import LeanProject.DLowerMTools
import LeanProject.DLowerMLog04
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_280 : RB (Real.log ((285056820885700373 : ℝ) / 200000000000000000)) ((70874233075505011 : ℝ) / 200000000000000000) ((354371165377525057 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((285056820885700373 : ℝ) / 400000000000000000)) (t := ((-114943179114299627 : ℝ) / 685056820885700373))
    (lo := ((-169388007591210127 : ℝ) / 500000000000000000)) (hi := ((-338776015182420253 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285056820885700373 : ℝ) / 200000000000000000) = Real.log ((285056820885700373 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((285056820885700373 : ℝ) / 200000000000000000) = ((285056820885700373 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_281 : RB (Real.log ((1425298691094789243 : ℝ) / 1000000000000000000)) ((22148837471361761 : ℝ) / 62500000000000000) ((177190699770894089 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425298691094789243 : ℝ) / 2000000000000000000)) (t := ((-574701308905210757 : ℝ) / 3425298691094789243))
    (lo := ((-338765781018157133 : ℝ) / 1000000000000000000)) (hi := ((-84691445254539283 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425298691094789243 : ℝ) / 1000000000000000000) = Real.log ((1425298691094789243 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425298691094789243 : ℝ) / 1000000000000000000) = ((1425298691094789243 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_282 : RB (Real.log ((712312730162248979 : ℝ) / 500000000000000000)) ((70781788862695401 : ℝ) / 200000000000000000) ((353908944313477007 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712312730162248979 : ℝ) / 1000000000000000000)) (t := ((-287687269837751021 : ℝ) / 1712312730162248979))
    (lo := ((-21202389765404269 : ℝ) / 62500000000000000)) (hi := ((-339238236246468303 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712312730162248979 : ℝ) / 500000000000000000) = Real.log ((712312730162248979 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712312730162248979 : ℝ) / 500000000000000000) = ((712312730162248979 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_283 : RB (Real.log ((1424625460324497959 : ℝ) / 1000000000000000000)) ((176954472156738503 : ℝ) / 500000000000000000) ((22119309019592313 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((1424625460324497959 : ℝ) / 2000000000000000000)) (t := ((-575374539675502041 : ℝ) / 3424625460324497959))
    (lo := ((-339238236246468303 : ℝ) / 1000000000000000000)) (hi := ((-169619118123234151 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424625460324497959 : ℝ) / 1000000000000000000) = Real.log ((1424625460324497959 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424625460324497959 : ℝ) / 1000000000000000000) = ((1424625460324497959 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_284 : RB (Real.log ((712313731901750933 : ℝ) / 500000000000000000)) ((353910350632296189 : ℝ) / 1000000000000000000) ((353910350632296191 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712313731901750933 : ℝ) / 1000000000000000000)) (t := ((-287686268098249067 : ℝ) / 1712313731901750933))
    (lo := ((-2120230187047807 : ℝ) / 6250000000000000)) (hi := ((-339236829927649119 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712313731901750933 : ℝ) / 500000000000000000) = Real.log ((712313731901750933 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712313731901750933 : ℝ) / 500000000000000000) = ((712313731901750933 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_285 : RB (Real.log ((178080005873848167 : ℝ) / 125000000000000000)) ((353919183209255623 : ℝ) / 1000000000000000000) ((566270693134809 : ℝ) / 1600000000000000) := by
  have hm := log_bounds_of_series (x := ((178080005873848167 : ℝ) / 250000000000000000)) (t := ((-71919994126151833 : ℝ) / 428080005873848167))
    (lo := ((-169613998675344843 : ℝ) / 500000000000000000)) (hi := ((-67845599470137937 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178080005873848167 : ℝ) / 125000000000000000) = Real.log ((178080005873848167 : ℝ) / 250000000000000000) + 1 * Real.log 2 := by
    rw [show ((178080005873848167 : ℝ) / 125000000000000000) = ((178080005873848167 : ℝ) / 250000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_286 : RB (Real.log ((1424640046990785337 : ℝ) / 1000000000000000000)) ((353919183209255623 : ℝ) / 1000000000000000000) ((566270693134809 : ℝ) / 1600000000000000) := by
  have hm := log_bounds_of_series (x := ((1424640046990785337 : ℝ) / 2000000000000000000)) (t := ((-575359953009214663 : ℝ) / 3424640046990785337))
    (lo := ((-169613998675344843 : ℝ) / 500000000000000000)) (hi := ((-67845599470137937 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424640046990785337 : ℝ) / 1000000000000000000) = Real.log ((1424640046990785337 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424640046990785337 : ℝ) / 1000000000000000000) = ((1424640046990785337 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_287 : RB (Real.log ((712319020230011809 : ℝ) / 500000000000000000)) ((353917774760729271 : ℝ) / 1000000000000000000) ((353917774760729273 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712319020230011809 : ℝ) / 1000000000000000000)) (t := ((-287680979769988191 : ℝ) / 1712319020230011809))
    (lo := ((-169614702899608019 : ℝ) / 500000000000000000)) (hi := ((-339229405799216037 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712319020230011809 : ℝ) / 500000000000000000) = Real.log ((712319020230011809 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712319020230011809 : ℝ) / 500000000000000000) = ((712319020230011809 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_288 : RB (Real.log ((25722656249999999 : ℝ) / 1000000000000000000)) ((-457547888660539769 : ℝ) / 125000000000000000) ((-73207662185686363 : ℝ) / 20000000000000000) := by
  have hm := log_bounds_of_series (x := ((25722656249999999 : ℝ) / 31250000000000000)) (t := ((-5527343750000001 : ℝ) / 56972656249999999))
    (lo := ((-48661801621147901 : ℝ) / 250000000000000000)) (hi := ((-194647206484591603 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25722656249999999 : ℝ) / 1000000000000000000) = Real.log ((25722656249999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25722656249999999 : ℝ) / 1000000000000000000) = ((25722656249999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_289 : RB (Real.log ((1317 : ℝ) / 51200)) ((-3660383109284318113 : ℝ) / 1000000000000000000) ((-3660383109284318111 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1317 : ℝ) / 1600)) (t := ((-283 : ℝ) / 2917))
    (lo := ((-38929441296918313 : ℝ) / 200000000000000000)) (hi := ((-48661801621147891 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1317 : ℝ) / 51200) = Real.log ((1317 : ℝ) / 1600) - 5 * Real.log 2 := by
    rw [show ((1317 : ℝ) / 51200) = ((1317 : ℝ) / 1600) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_290 : RB (Real.log ((1025722656249999999 : ℝ) / 1000000000000000000)) ((5079478932187261 : ℝ) / 200000000000000000) ((12698697330468153 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025722656249999999 : ℝ) / 1000000000000000000)) (t := ((25722656249999999 : ℝ) / 2025722656249999999))
    (lo := ((5079478932187261 : ℝ) / 200000000000000000)) (hi := ((12698697330468153 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_291 : RB (Real.log ((52517 : ℝ) / 51200)) ((12698697330468153 : ℝ) / 500000000000000000) ((25397394660936307 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((52517 : ℝ) / 51200)) (t := ((1317 : ℝ) / 103717))
    (lo := ((12698697330468153 : ℝ) / 500000000000000000)) (hi := ((25397394660936307 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_292 : RB (Real.log ((25703124999999999 : ℝ) / 1000000000000000000)) ((-1830571349571168341 : ℝ) / 500000000000000000) ((-91528567478558417 : ℝ) / 25000000000000000) := by
  have hm := log_bounds_of_series (x := ((25703124999999999 : ℝ) / 31250000000000000)) (t := ((-5546875000000001 : ℝ) / 56953124999999999))
    (lo := ((-97703398171305067 : ℝ) / 500000000000000000)) (hi := ((-195406796342610133 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25703124999999999 : ℝ) / 1000000000000000000) = Real.log ((25703124999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25703124999999999 : ℝ) / 1000000000000000000) = ((25703124999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_293 : RB (Real.log ((659 : ℝ) / 25600)) ((-1829812047982573313 : ℝ) / 500000000000000000) ((-7147703312431927 : ℝ) / 1953125000000000) := by
  have hm := log_bounds_of_series (x := ((659 : ℝ) / 800)) (t := ((-141 : ℝ) / 1459))
    (lo := ((-96944096582710039 : ℝ) / 500000000000000000)) (hi := ((-193888193165420077 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((659 : ℝ) / 25600) = Real.log ((659 : ℝ) / 800) - 5 * Real.log 2 := by
    rw [show ((659 : ℝ) / 25600) = ((659 : ℝ) / 800) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_294 : RB (Real.log ((1025703124999999999 : ℝ) / 1000000000000000000)) ((25378353026401821 : ℝ) / 1000000000000000000) ((12689176513200911 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025703124999999999 : ℝ) / 1000000000000000000)) (t := ((25703124999999999 : ℝ) / 2025703124999999999))
    (lo := ((25378353026401821 : ℝ) / 1000000000000000000)) (hi := ((12689176513200911 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_295 : RB (Real.log ((26259 : ℝ) / 25600)) ((3177054491611731 : ℝ) / 125000000000000000) ((25416435932893849 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((26259 : ℝ) / 25600)) (t := ((659 : ℝ) / 51859))
    (lo := ((3177054491611731 : ℝ) / 125000000000000000)) (hi := ((25416435932893849 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_296 : RB (Real.log ((91730738101465467 : ℝ) / 200000000000000000)) ((-155891968120445631 : ℝ) / 200000000000000000) ((-779459840602228153 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((91730738101465467 : ℝ) / 100000000000000000)) (t := ((-8269261898534533 : ℝ) / 191730738101465467))
    (lo := ((-17262532008456569 : ℝ) / 200000000000000000)) (hi := ((-21578165010570711 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91730738101465467 : ℝ) / 200000000000000000) = Real.log ((91730738101465467 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((91730738101465467 : ℝ) / 200000000000000000) = ((91730738101465467 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_297 : RB (Real.log ((14332927828354073 : ℝ) / 31250000000000000)) ((-194864960150555403 : ℝ) / 250000000000000000) ((-77945984060222161 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((14332927828354073 : ℝ) / 15625000000000000)) (t := ((-1292072171645927 : ℝ) / 29957927828354073))
    (lo := ((-43156330021138151 : ℝ) / 500000000000000000)) (hi := ((-86312660042276301 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14332927828354073 : ℝ) / 31250000000000000) = Real.log ((14332927828354073 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((14332927828354073 : ℝ) / 31250000000000000) = ((14332927828354073 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_298 : RB (Real.log ((270342327224057 : ℝ) / 500000000000000)) ((-38432441493471701 : ℝ) / 62500000000000000) ((-307459531947773607 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((270342327224057 : ℝ) / 250000000000000)) (t := ((20342327224057 : ℝ) / 520342327224057))
    (lo := ((39114058332199047 : ℝ) / 500000000000000000)) (hi := ((15645623332879619 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270342327224057 : ℝ) / 500000000000000) = Real.log ((270342327224057 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((270342327224057 : ℝ) / 500000000000000) = ((270342327224057 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_299 : RB (Real.log ((540684654448117 : ℝ) / 1000000000000000)) ((-153729765973885417 : ℝ) / 250000000000000000) ((-307459531947770833 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((540684654448117 : ℝ) / 500000000000000)) (t := ((40684654448117 : ℝ) / 1040684654448117))
    (lo := ((39114058332201821 : ℝ) / 500000000000000000)) (hi := ((78228116664403643 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540684654448117 : ℝ) / 1000000000000000) = Real.log ((540684654448117 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((540684654448117 : ℝ) / 1000000000000000) = ((540684654448117 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_300 : RB (Real.log ((459315345551883 : ℝ) / 1000000000000000)) ((-77801827747069061 : ℝ) / 100000000000000000) ((-48626142341918163 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((459315345551883 : ℝ) / 500000000000000)) (t := ((-40684654448117 : ℝ) / 959315345551883))
    (lo := ((-848710969107453 : ℝ) / 10000000000000000)) (hi := ((-84871096910745299 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459315345551883 : ℝ) / 1000000000000000) = Real.log ((459315345551883 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((459315345551883 : ℝ) / 1000000000000000) = ((459315345551883 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_301 : RB (Real.log ((229657672775943 : ℝ) / 500000000000000)) ((-778018277470684079 : ℝ) / 1000000000000000000) ((-778018277470684077 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229657672775943 : ℝ) / 250000000000000)) (t := ((-20342327224057 : ℝ) / 479657672775943))
    (lo := ((-84871096910738769 : ℝ) / 1000000000000000000)) (hi := ((-5304443556921173 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229657672775943 : ℝ) / 500000000000000) = Real.log ((229657672775943 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((229657672775943 : ℝ) / 500000000000000) = ((229657672775943 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_302 : RB (Real.log ((57331711313415917 : ℝ) / 125000000000000000)) ((-779459840602228153 : ℝ) / 1000000000000000000) ((-779459840602228151 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((57331711313415917 : ℝ) / 62500000000000000)) (t := ((-5168288686584083 : ℝ) / 119831711313415917))
    (lo := ((-86312660042282843 : ℝ) / 1000000000000000000)) (hi := ((-43156330021141421 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57331711313415917 : ℝ) / 125000000000000000) = Real.log ((57331711313415917 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57331711313415917 : ℝ) / 125000000000000000) = ((57331711313415917 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_303 : RB (Real.log ((91730738101466067 : ℝ) / 200000000000000000)) ((-389729920301110807 : ℝ) / 500000000000000000) ((-194864960150555403 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((91730738101466067 : ℝ) / 100000000000000000)) (t := ((-8269261898533933 : ℝ) / 191730738101466067))
    (lo := ((-5394541252642269 : ℝ) / 62500000000000000)) (hi := ((-86312660042276303 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91730738101466067 : ℝ) / 200000000000000000) = Real.log ((91730738101466067 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((91730738101466067 : ℝ) / 200000000000000000) = ((91730738101466067 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_304 : RB (Real.log ((284927707388596467 : ℝ) / 200000000000000000)) ((353918123258283109 : ℝ) / 1000000000000000000) ((353918123258283111 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((284927707388596467 : ℝ) / 400000000000000000)) (t := ((-115072292611403533 : ℝ) / 684927707388596467))
    (lo := ((-1696145286508311 : ℝ) / 5000000000000000)) (hi := ((-339229057301662199 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284927707388596467 : ℝ) / 200000000000000000) = Real.log ((284927707388596467 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284927707388596467 : ℝ) / 200000000000000000) = ((284927707388596467 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_305 : RB (Real.log ((178079817117873167 : ℝ) / 125000000000000000)) ((11059941351821413 : ℝ) / 31250000000000000) ((176959061629142609 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((178079817117873167 : ℝ) / 250000000000000000)) (t := ((-71920182882126833 : ℝ) / 428079817117873167))
    (lo := ((-339229057301660093 : ℝ) / 1000000000000000000)) (hi := ((-84807264325415023 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178079817117873167 : ℝ) / 125000000000000000) = Real.log ((178079817117873167 : ℝ) / 250000000000000000) + 1 * Real.log 2 := by
    rw [show ((178079817117873167 : ℝ) / 125000000000000000) = ((178079817117873167 : ℝ) / 250000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_306 : RB (Real.log ((212650095993769 : ℝ) / 500000000000000)) ((-854960025305914669 : ℝ) / 1000000000000000000) ((-854960025305914667 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((212650095993769 : ℝ) / 250000000000000)) (t := ((-37349904006231 : ℝ) / 462650095993769))
    (lo := ((-161812844745969359 : ℝ) / 1000000000000000000)) (hi := ((-80906422372984679 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212650095993769 : ℝ) / 500000000000000) = Real.log ((212650095993769 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212650095993769 : ℝ) / 500000000000000) = ((212650095993769 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_307 : RB (Real.log ((425300191987541 : ℝ) / 1000000000000000)) ((-170992005061181523 : ℝ) / 200000000000000000) ((-854960025305907613 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((425300191987541 : ℝ) / 500000000000000)) (t := ((-74699808012459 : ℝ) / 925300191987541))
    (lo := ((-32362568949192461 : ℝ) / 200000000000000000)) (hi := ((-2528325699155661 : ℝ) / 15625000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425300191987541 : ℝ) / 1000000000000000) = Real.log ((425300191987541 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((425300191987541 : ℝ) / 1000000000000000) = ((425300191987541 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_308 : RB (Real.log ((712650095993769 : ℝ) / 500000000000000)) ((354382452578578209 : ℝ) / 1000000000000000000) ((354382452578578211 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712650095993769 : ℝ) / 1000000000000000)) (t := ((-287349904006231 : ℝ) / 1712650095993769))
    (lo := ((-3387647279813671 : ℝ) / 10000000000000000)) (hi := ((-338764727981367099 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712650095993769 : ℝ) / 500000000000000) = Real.log ((712650095993769 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712650095993769 : ℝ) / 500000000000000) = ((712650095993769 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_309 : RB (Real.log ((1425300191987541 : ℝ) / 1000000000000000)) ((177191226289290157 : ℝ) / 500000000000000000) ((88595613144645079 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425300191987541 : ℝ) / 2000000000000000)) (t := ((-574699808012459 : ℝ) / 3425300191987541))
    (lo := ((-67752945596272999 : ℝ) / 200000000000000000)) (hi := ((-169382363990682497 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425300191987541 : ℝ) / 1000000000000000) = Real.log ((1425300191987541 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425300191987541 : ℝ) / 1000000000000000) = ((1425300191987541 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_310 : RB (Real.log ((22259977139734099 : ℝ) / 15625000000000000)) ((35391812325828311 : ℝ) / 100000000000000000) ((44239765407285389 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((22259977139734099 : ℝ) / 31250000000000000)) (t := ((-8990022860265901 : ℝ) / 53509977139734099))
    (lo := ((-339229057301662199 : ℝ) / 1000000000000000000)) (hi := ((-169614528650831099 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22259977139734099 : ℝ) / 15625000000000000) = Real.log ((22259977139734099 : ℝ) / 31250000000000000) + 1 * Real.log 2 := by
    rw [show ((22259977139734099 : ℝ) / 15625000000000000) = ((22259977139734099 : ℝ) / 31250000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_311 : RB (Real.log ((284927707388597067 : ℝ) / 200000000000000000)) ((70783624651657043 : ℝ) / 200000000000000000) ((353918123258285217 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((284927707388597067 : ℝ) / 400000000000000000)) (t := ((-115072292611402933 : ℝ) / 684927707388597067))
    (lo := ((-169614528650830047 : ℝ) / 500000000000000000)) (hi := ((-339229057301660093 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284927707388597067 : ℝ) / 200000000000000000) = Real.log ((284927707388597067 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284927707388597067 : ℝ) / 200000000000000000) = ((284927707388597067 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_312 : RB (Real.log ((458608429954348079 : ℝ) / 1000000000000000000)) ((-779558526794552783 : ℝ) / 1000000000000000000) ((-779558526794552781 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458608429954348079 : ℝ) / 500000000000000000)) (t := ((-41391570045651921 : ℝ) / 958608429954348079))
    (lo := ((-86411346234607473 : ℝ) / 1000000000000000000)) (hi := ((-5400709139662967 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458608429954348079 : ℝ) / 1000000000000000000) = Real.log ((458608429954348079 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458608429954348079 : ℝ) / 1000000000000000000) = ((458608429954348079 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_313 : RB (Real.log ((3583585549198201 : ℝ) / 7812500000000000)) ((-779361165811169801 : ℝ) / 1000000000000000000) ((-779361165811169799 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((3583585549198201 : ℝ) / 3906250000000000)) (t := ((-322664450801799 : ℝ) / 7489835549198201))
    (lo := ((-86213985251224491 : ℝ) / 1000000000000000000)) (hi := ((-8621398525122449 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3583585549198201 : ℝ) / 7812500000000000) = Real.log ((3583585549198201 : ℝ) / 3906250000000000) - 1 * Real.log 2 := by
    rw [show ((3583585549198201 : ℝ) / 7812500000000000) = ((3583585549198201 : ℝ) / 3906250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_314 : RB (Real.log ((67580049883483081 : ℝ) / 125000000000000000)) ((-307500458938348887 : ℝ) / 500000000000000000) ((-153750229469174443 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((67580049883483081 : ℝ) / 62500000000000000)) (t := ((5080049883483081 : ℝ) / 130080049883483081))
    (lo := ((4884141417702971 : ℝ) / 62500000000000000)) (hi := ((78146262683247537 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((67580049883483081 : ℝ) / 125000000000000000) = Real.log ((67580049883483081 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((67580049883483081 : ℝ) / 125000000000000000) = ((67580049883483081 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_315 : RB (Real.log ((135182227457091691 : ℝ) / 250000000000000000)) ((-614837216613916199 : ℝ) / 1000000000000000000) ((-614837216613916197 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((135182227457091691 : ℝ) / 125000000000000000)) (t := ((10182227457091691 : ℝ) / 260182227457091691))
    (lo := ((78309963946029111 : ℝ) / 1000000000000000000)) (hi := ((9788745493253639 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((135182227457091691 : ℝ) / 250000000000000000) = Real.log ((135182227457091691 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((135182227457091691 : ℝ) / 250000000000000000) = ((135182227457091691 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_316 : RB (Real.log ((114817772542908309 : ℝ) / 250000000000000000)) ((-77811463286755459 : ℝ) / 100000000000000000) ((-194528658216888647 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((114817772542908309 : ℝ) / 125000000000000000)) (t := ((-10182227457091691 : ℝ) / 239817772542908309))
    (lo := ((-265523288461279 : ℝ) / 3125000000000000)) (hi := ((-84967452307609279 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114817772542908309 : ℝ) / 250000000000000000) = Real.log ((114817772542908309 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((114817772542908309 : ℝ) / 250000000000000000) = ((114817772542908309 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_317 : RB (Real.log ((57419950116516919 : ℝ) / 125000000000000000)) ((-194480482839322249 : ℝ) / 250000000000000000) ((-388960965678644497 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((57419950116516919 : ℝ) / 62500000000000000)) (t := ((-5080049883483081 : ℝ) / 119919950116516919))
    (lo := ((-42387375398671843 : ℝ) / 500000000000000000)) (hi := ((-16954950159468737 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57419950116516919 : ℝ) / 125000000000000000) = Real.log ((57419950116516919 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57419950116516919 : ℝ) / 125000000000000000) = ((57419950116516919 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_318 : RB (Real.log ((458609435127077571 : ℝ) / 1000000000000000000)) ((-389778167504176443 : ℝ) / 500000000000000000) ((-194889083752088221 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((458609435127077571 : ℝ) / 500000000000000000)) (t := ((-41390564872922429 : ℝ) / 958609435127077571))
    (lo := ((-10801144306050947 : ℝ) / 125000000000000000)) (hi := ((-3456366177936303 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458609435127077571 : ℝ) / 1000000000000000000) = Real.log ((458609435127077571 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458609435127077571 : ℝ) / 1000000000000000000) = ((458609435127077571 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_319 : RB (Real.log ((114652358781769393 : ℝ) / 250000000000000000)) ((-194889083752088221 : ℝ) / 250000000000000000) ((-389778167504176441 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((114652358781769393 : ℝ) / 125000000000000000)) (t := ((-10347641218230607 : ℝ) / 239652358781769393))
    (lo := ((-43204577224203787 : ℝ) / 500000000000000000)) (hi := ((-86409154448407573 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114652358781769393 : ℝ) / 250000000000000000) = Real.log ((114652358781769393 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((114652358781769393 : ℝ) / 250000000000000000) = ((114652358781769393 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
