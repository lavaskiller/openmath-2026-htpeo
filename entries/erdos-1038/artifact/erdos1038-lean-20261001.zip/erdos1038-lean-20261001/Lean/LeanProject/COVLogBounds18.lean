import LeanProject.COVLogTwo
import LeanProject.COVLogBounds14
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1440 : RB (Real.log ((1283549 : ℝ) / 2000000)) ((-4435183 : ℝ) / 10000000) ((-11087957 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1283549 : ℝ) / 1000000)) (t := ((283549 : ℝ) / 2283549))
    (lo := ((24962889 : ℝ) / 100000000)) (hi := ((2496289 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1283549 : ℝ) / 2000000) = Real.log ((1283549 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((1283549 : ℝ) / 2000000) = ((1283549 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1441 : RB (Real.log ((64178923 : ℝ) / 100000000)) ((-8869907 : ℝ) / 20000000) ((-44349533 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64178923 : ℝ) / 50000000)) (t := ((14178923 : ℝ) / 114178923))
    (lo := ((390081 : ℝ) / 1562500)) (hi := ((4993037 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64178923 : ℝ) / 100000000) = Real.log ((64178923 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64178923 : ℝ) / 100000000) = ((64178923 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1442 : RB (Real.log ((19564513 : ℝ) / 50000000)) ((-46915283 : ℝ) / 50000000) ((-23457641 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((19564513 : ℝ) / 25000000)) (t := ((-5435487 : ℝ) / 44564513))
    (lo := ((-24515847 : ℝ) / 100000000)) (hi := ((-12257923 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19564513 : ℝ) / 50000000) = Real.log ((19564513 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19564513 : ℝ) / 50000000) = ((19564513 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1443 : RB (Real.log ((190282519 : ℝ) / 100000000)) ((16083493 : ℝ) / 25000000) ((32166987 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((190282519 : ℝ) / 200000000)) (t := ((-9717481 : ℝ) / 390282519))
    (lo := ((-2490373 : ℝ) / 50000000)) (hi := ((-996149 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((190282519 : ℝ) / 100000000) = Real.log ((190282519 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((190282519 : ℝ) / 100000000) = ((190282519 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1444 : RB (Real.log ((190348639 : ℝ) / 100000000)) ((32184357 : ℝ) / 50000000) ((16092179 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((190348639 : ℝ) / 200000000)) (t := ((-9651361 : ℝ) / 390348639))
    (lo := ((-1236501 : ℝ) / 25000000)) (hi := ((-4946003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((190348639 : ℝ) / 100000000) = Real.log ((190348639 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((190348639 : ℝ) / 100000000) = ((190348639 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1445 : RB (Real.log ((64937663 : ℝ) / 100000000)) ((-21587121 : ℝ) / 50000000) ((-269839 : ℝ) / 625000) := by
  have hm := log_bounds_of_series (x := ((64937663 : ℝ) / 50000000)) (t := ((14937663 : ℝ) / 114937663))
    (lo := ((26140477 : ℝ) / 100000000)) (hi := ((13070239 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64937663 : ℝ) / 100000000) = Real.log ((64937663 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64937663 : ℝ) / 100000000) = ((64937663 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1446 : RB (Real.log ((64939143 : ℝ) / 100000000)) ((-43171963 : ℝ) / 100000000) ((-43171961 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64939143 : ℝ) / 50000000)) (t := ((14939143 : ℝ) / 114939143))
    (lo := ((6535689 : ℝ) / 25000000)) (hi := ((26142757 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64939143 : ℝ) / 100000000) = Real.log ((64939143 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64939143 : ℝ) / 100000000) = ((64939143 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1447 : RB (Real.log ((19704793 : ℝ) / 50000000)) ((-93116111 : ℝ) / 100000000) ((-93116109 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19704793 : ℝ) / 25000000)) (t := ((-5295207 : ℝ) / 44704793))
    (lo := ((-1487587 : ℝ) / 6250000)) (hi := ((-23801391 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19704793 : ℝ) / 50000000) = Real.log ((19704793 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19704793 : ℝ) / 50000000) = ((19704793 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1448 : RB (Real.log ((404132463 : ℝ) / 100000000)) ((139657251 : ℝ) / 100000000) ((69828627 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((404132463 : ℝ) / 400000000)) (t := ((4132463 : ℝ) / 804132463))
    (lo := ((205563 : ℝ) / 20000000)) (hi := ((128477 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((404132463 : ℝ) / 100000000) = Real.log ((404132463 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((404132463 : ℝ) / 100000000) = ((404132463 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1449 : RB (Real.log ((404135191 : ℝ) / 100000000)) ((69828963 : ℝ) / 50000000) ((139657929 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((404135191 : ℝ) / 400000000)) (t := ((4135191 : ℝ) / 804135191))
    (lo := ((102849 : ℝ) / 10000000)) (hi := ((1028491 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((404135191 : ℝ) / 100000000) = Real.log ((404135191 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((404135191 : ℝ) / 100000000) = ((404135191 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1450 : RB (Real.log ((66429751 : ℝ) / 50000000)) ((142061 : ℝ) / 500000) ((28412201 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66429751 : ℝ) / 50000000)) (t := ((16429751 : ℝ) / 116429751))
    (lo := ((142061 : ℝ) / 500000)) (hi := ((28412201 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1451 : RB (Real.log ((50342003 : ℝ) / 12500000)) ((139311113 : ℝ) / 100000000) ((34827779 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((50342003 : ℝ) / 50000000)) (t := ((342003 : ℝ) / 100342003))
    (lo := ((681677 : ℝ) / 100000000)) (hi := ((340839 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((50342003 : ℝ) / 12500000) = Real.log ((50342003 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((50342003 : ℝ) / 12500000) = ((50342003 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1452 : RB (Real.log ((402738739 : ℝ) / 100000000)) ((139311787 : ℝ) / 100000000) ((13931179 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((402738739 : ℝ) / 400000000)) (t := ((2738739 : ℝ) / 802738739))
    (lo := ((682351 : ℝ) / 100000000)) (hi := ((42647 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((402738739 : ℝ) / 100000000) = Real.log ((402738739 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((402738739 : ℝ) / 100000000) = ((402738739 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1453 : RB (Real.log ((66505537 : ℝ) / 50000000)) ((1426311 : ℝ) / 5000000) ((28526221 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((66505537 : ℝ) / 50000000)) (t := ((16505537 : ℝ) / 116505537))
    (lo := ((1426311 : ℝ) / 5000000)) (hi := ((28526221 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1454 : RB (Real.log ((3092789 : ℝ) / 25000000)) ((-208980259 : ℝ) / 100000000) ((-41796051 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3092789 : ℝ) / 3125000)) (t := ((-32211 : ℝ) / 6217789))
    (lo := ((-518051 : ℝ) / 50000000)) (hi := ((-1036101 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3092789 : ℝ) / 25000000) = Real.log ((3092789 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((3092789 : ℝ) / 25000000) = ((3092789 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1455 : RB (Real.log ((6590671 : ℝ) / 50000000)) ((-202636787 : ℝ) / 100000000) ((-202636783 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6590671 : ℝ) / 6250000)) (t := ((340671 : ℝ) / 12840671))
    (lo := ((530737 : ℝ) / 10000000)) (hi := ((5307371 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6590671 : ℝ) / 50000000) = Real.log ((6590671 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((6590671 : ℝ) / 50000000) = ((6590671 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1456 : RB (Real.log ((2382179 : ℝ) / 50000000)) ((-304400743 : ℝ) / 100000000) ((-152200369 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2382179 : ℝ) / 3125000)) (t := ((-742821 : ℝ) / 5507179))
    (lo := ((-27141867 : ℝ) / 100000000)) (hi := ((-13570933 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2382179 : ℝ) / 50000000) = Real.log ((2382179 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2382179 : ℝ) / 50000000) = ((2382179 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1457 : RB (Real.log ((599989 : ℝ) / 12500000)) ((-18978579 : ℝ) / 6250000) ((-303657259 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((599989 : ℝ) / 781250)) (t := ((-181261 : ℝ) / 1381239))
    (lo := ((-6599597 : ℝ) / 25000000)) (hi := ((-26398387 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((599989 : ℝ) / 12500000) = Real.log ((599989 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((599989 : ℝ) / 12500000) = ((599989 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1458 : RB (Real.log ((64090261 : ℝ) / 100000000)) ((-22243889 : ℝ) / 50000000) ((-1390243 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((64090261 : ℝ) / 50000000)) (t := ((14090261 : ℝ) / 114090261))
    (lo := ((24826941 : ℝ) / 100000000)) (hi := ((12413471 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64090261 : ℝ) / 100000000) = Real.log ((64090261 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64090261 : ℝ) / 100000000) = ((64090261 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1459 : RB (Real.log ((2002867 : ℝ) / 3125000)) ((-5560683 : ℝ) / 12500000) ((-22242731 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2002867 : ℝ) / 1562500)) (t := ((440367 : ℝ) / 3565367))
    (lo := ((4965851 : ℝ) / 20000000)) (hi := ((3103657 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2002867 : ℝ) / 3125000) = Real.log ((2002867 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((2002867 : ℝ) / 3125000) = ((2002867 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1460 : RB (Real.log ((2443577 : ℝ) / 6250000)) ((-93911853 : ℝ) / 100000000) ((-93911851 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2443577 : ℝ) / 3125000)) (t := ((-681423 : ℝ) / 5568577))
    (lo := ((-12298567 : ℝ) / 50000000)) (hi := ((-24597133 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2443577 : ℝ) / 6250000) = Real.log ((2443577 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((2443577 : ℝ) / 6250000) = ((2443577 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1461 : RB (Real.log ((23777049 : ℝ) / 12500000)) ((32149607 : ℝ) / 50000000) ((4018701 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((23777049 : ℝ) / 25000000)) (t := ((-1222951 : ℝ) / 48777049))
    (lo := ((-313469 : ℝ) / 6250000)) (hi := ((-5015503 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23777049 : ℝ) / 12500000) = Real.log ((23777049 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((23777049 : ℝ) / 12500000) = ((23777049 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1462 : RB (Real.log ((7611301 : ℝ) / 4000000)) ((2573359 : ℝ) / 4000000) ((64333977 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7611301 : ℝ) / 8000000)) (t := ((-388699 : ℝ) / 15611301))
    (lo := ((-4980743 : ℝ) / 100000000)) (hi := ((-2490371 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7611301 : ℝ) / 4000000) = Real.log ((7611301 : ℝ) / 8000000) + 1 * Real.log 2 := by
    rw [show ((7611301 : ℝ) / 4000000) = ((7611301 : ℝ) / 8000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1463 : RB (Real.log ((64847151 : ℝ) / 100000000)) ((-21656861 : ℝ) / 50000000) ((-1082843 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((64847151 : ℝ) / 50000000)) (t := ((14847151 : ℝ) / 114847151))
    (lo := ((26000997 : ℝ) / 100000000)) (hi := ((13000499 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64847151 : ℝ) / 100000000) = Real.log ((64847151 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64847151 : ℝ) / 100000000) = ((64847151 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1464 : RB (Real.log ((64848641 : ℝ) / 100000000)) ((-1732457 : ℝ) / 4000000) ((-43311423 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64848641 : ℝ) / 50000000)) (t := ((14848641 : ℝ) / 114848641))
    (lo := ((13001647 : ℝ) / 50000000)) (hi := ((5200659 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64848641 : ℝ) / 100000000) = Real.log ((64848641 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64848641 : ℝ) / 100000000) = ((64848641 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1465 : RB (Real.log ((7875373 : ℝ) / 20000000)) ((-46599587 : ℝ) / 50000000) ((-23299793 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((7875373 : ℝ) / 10000000)) (t := ((-2124627 : ℝ) / 17875373))
    (lo := ((-4776891 : ℝ) / 20000000)) (hi := ((-11942227 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7875373 : ℝ) / 20000000) = Real.log ((7875373 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((7875373 : ℝ) / 20000000) = ((7875373 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1466 : RB (Real.log ((403661863 : ℝ) / 100000000)) ((545081 : ℝ) / 390625) ((139540739 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((403661863 : ℝ) / 400000000)) (t := ((3661863 : ℝ) / 803661863))
    (lo := ((9113 : ℝ) / 1000000)) (hi := ((911301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((403661863 : ℝ) / 100000000) = Real.log ((403661863 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((403661863 : ℝ) / 100000000) = ((403661863 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1467 : RB (Real.log ((12614519 : ℝ) / 3125000)) ((17442677 : ℝ) / 12500000) ((139541419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12614519 : ℝ) / 12500000)) (t := ((114519 : ℝ) / 25114519))
    (lo := ((45599 : ℝ) / 5000000)) (hi := ((911981 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12614519 : ℝ) / 3125000) = Real.log ((12614519 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((12614519 : ℝ) / 3125000) = ((12614519 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1468 : RB (Real.log ((132910129 : ℝ) / 100000000)) ((28450299 : ℝ) / 100000000) ((284503 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((132910129 : ℝ) / 100000000)) (t := ((32910129 : ℝ) / 232910129))
    (lo := ((28450299 : ℝ) / 100000000)) (hi := ((284503 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1469 : RB (Real.log ((12571017 : ℝ) / 3125000)) ((34798991 : ℝ) / 25000000) ((139195967 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12571017 : ℝ) / 12500000)) (t := ((71017 : ℝ) / 25071017))
    (lo := ((2213 : ℝ) / 390625)) (hi := ((566529 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12571017 : ℝ) / 3125000) = Real.log ((12571017 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((12571017 : ℝ) / 3125000) = ((12571017 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1470 : RB (Real.log ((402275277 : ℝ) / 100000000)) ((139196643 : ℝ) / 100000000) ((69598323 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((402275277 : ℝ) / 400000000)) (t := ((2275277 : ℝ) / 802275277))
    (lo := ((567207 : ℝ) / 100000000)) (hi := ((70901 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((402275277 : ℝ) / 100000000) = Real.log ((402275277 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((402275277 : ℝ) / 100000000) = ((402275277 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1471 : RB (Real.log ((8316337 : ℝ) / 6250000)) ((14282021 : ℝ) / 50000000) ((28564043 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8316337 : ℝ) / 6250000)) (t := ((2066337 : ℝ) / 14566337))
    (lo := ((14282021 : ℝ) / 50000000)) (hi := ((28564043 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1472 : RB (Real.log ((310807 : ℝ) / 2500000)) ((-20848739 : ℝ) / 10000000) ((-104243693 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((310807 : ℝ) / 312500)) (t := ((-1693 : ℝ) / 623307))
    (lo := ((-543233 : ℝ) / 100000000)) (hi := ((-2122 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((310807 : ℝ) / 2500000) = Real.log ((310807 : ℝ) / 312500) - 3 * Real.log 2 := by
    rw [show ((310807 : ℝ) / 2500000) = ((310807 : ℝ) / 312500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1473 : RB (Real.log ((662021 : ℝ) / 5000000)) ((-40437919 : ℝ) / 20000000) ((-202189591 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((662021 : ℝ) / 625000)) (t := ((37021 : ℝ) / 1287021))
    (lo := ((2877281 : ℝ) / 50000000)) (hi := ((5754563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((662021 : ℝ) / 5000000) = Real.log ((662021 : ℝ) / 625000) - 3 * Real.log 2 := by
    rw [show ((662021 : ℝ) / 5000000) = ((662021 : ℝ) / 625000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1474 : RB (Real.log ((1199143 : ℝ) / 25000000)) ((-303726873 : ℝ) / 100000000) ((-75931717 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1199143 : ℝ) / 1562500)) (t := ((-363357 : ℝ) / 2761643))
    (lo := ((-26467997 : ℝ) / 100000000)) (hi := ((-6616999 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1199143 : ℝ) / 25000000) = Real.log ((1199143 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1199143 : ℝ) / 25000000) = ((1199143 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1475 : RB (Real.log ((4832149 : ℝ) / 100000000)) ((-302987893 : ℝ) / 100000000) ((-18936743 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((4832149 : ℝ) / 6250000)) (t := ((-1417851 : ℝ) / 11082149))
    (lo := ((-25729017 : ℝ) / 100000000)) (hi := ((-3216127 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4832149 : ℝ) / 100000000) = Real.log ((4832149 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4832149 : ℝ) / 100000000) = ((4832149 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1476 : RB (Real.log ((64003409 : ℝ) / 100000000)) ((-8924677 : ℝ) / 20000000) ((-44623383 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64003409 : ℝ) / 50000000)) (t := ((14003409 : ℝ) / 114003409))
    (lo := ((12345667 : ℝ) / 50000000)) (hi := ((4938267 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64003409 : ℝ) / 100000000) = Real.log ((64003409 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64003409 : ℝ) / 100000000) = ((64003409 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1477 : RB (Real.log ((8000613 : ℝ) / 12500000)) ((-892421 : ℝ) / 2000000) ((-5577631 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((8000613 : ℝ) / 6250000)) (t := ((1750613 : ℝ) / 14250613))
    (lo := ((24693669 : ℝ) / 100000000)) (hi := ((2469367 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8000613 : ℝ) / 12500000) = Real.log ((8000613 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((8000613 : ℝ) / 12500000) = ((8000613 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1478 : RB (Real.log ((19532767 : ℝ) / 50000000)) ((-93992961 : ℝ) / 100000000) ((-93992959 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19532767 : ℝ) / 25000000)) (t := ((-5467233 : ℝ) / 44532767))
    (lo := ((-12339121 : ℝ) / 50000000)) (hi := ((-24678241 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19532767 : ℝ) / 50000000) = Real.log ((19532767 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19532767 : ℝ) / 50000000) = ((19532767 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1479 : RB (Real.log ((38030051 : ℝ) / 20000000)) ((32132219 : ℝ) / 50000000) ((1606611 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((38030051 : ℝ) / 40000000)) (t := ((-1969949 : ℝ) / 78030051))
    (lo := ((-126257 : ℝ) / 2500000)) (hi := ((-5050279 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38030051 : ℝ) / 20000000) = Real.log ((38030051 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38030051 : ℝ) / 20000000) = ((38030051 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1480 : RB (Real.log ((190216399 : ℝ) / 100000000)) ((64299217 : ℝ) / 100000000) ((64299219 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((190216399 : ℝ) / 200000000)) (t := ((-9783601 : ℝ) / 390216399))
    (lo := ((-5015501 : ℝ) / 100000000)) (hi := ((-10031 : ℝ) / 200000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((190216399 : ℝ) / 100000000) = Real.log ((190216399 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((190216399 : ℝ) / 100000000) = ((190216399 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1481 : RB (Real.log ((64757043 : ℝ) / 100000000)) ((-43452773 : ℝ) / 100000000) ((-43452771 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64757043 : ℝ) / 50000000)) (t := ((14757043 : ℝ) / 114757043))
    (lo := ((12930973 : ℝ) / 50000000)) (hi := ((25861947 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64757043 : ℝ) / 100000000) = Real.log ((64757043 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64757043 : ℝ) / 100000000) = ((64757043 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1482 : RB (Real.log ((4047409 : ℝ) / 6250000)) ((-8690091 : ℝ) / 20000000) ((-43450453 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4047409 : ℝ) / 3125000)) (t := ((922409 : ℝ) / 7172409))
    (lo := ((3233033 : ℝ) / 12500000)) (hi := ((5172853 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4047409 : ℝ) / 6250000) = Real.log ((4047409 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((4047409 : ℝ) / 6250000) = ((4047409 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1483 : RB (Real.log ((39344261 : ℝ) / 100000000)) ((-11660251 : ℝ) / 12500000) ((-46641003 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39344261 : ℝ) / 50000000)) (t := ((-10655739 : ℝ) / 89344261))
    (lo := ((-23967289 : ℝ) / 100000000)) (hi := ((-2995911 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39344261 : ℝ) / 100000000) = Real.log ((39344261 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39344261 : ℝ) / 100000000) = ((39344261 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1484 : RB (Real.log ((100798411 : ℝ) / 25000000)) ((34856169 : ℝ) / 25000000) ((139424679 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((100798411 : ℝ) / 100000000)) (t := ((798411 : ℝ) / 200798411))
    (lo := ((19881 : ℝ) / 2500000)) (hi := ((795241 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((100798411 : ℝ) / 25000000) = Real.log ((100798411 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((100798411 : ℝ) / 25000000) = ((100798411 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1485 : RB (Real.log ((201598203 : ℝ) / 50000000)) ((139425361 : ℝ) / 100000000) ((34856341 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((201598203 : ℝ) / 200000000)) (t := ((1598203 : ℝ) / 401598203))
    (lo := ((31837 : ℝ) / 4000000)) (hi := ((397963 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((201598203 : ℝ) / 50000000) = Real.log ((201598203 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((201598203 : ℝ) / 50000000) = ((201598203 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1486 : RB (Real.log ((33240163 : ℝ) / 25000000)) ((1780519 : ℝ) / 6250000) ((5697661 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((33240163 : ℝ) / 25000000)) (t := ((8240163 : ℝ) / 58240163))
    (lo := ((1780519 : ℝ) / 6250000)) (hi := ((5697661 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1487 : RB (Real.log ((200905691 : ℝ) / 50000000)) ((139081259 : ℝ) / 100000000) ((69540631 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((200905691 : ℝ) / 200000000)) (t := ((905691 : ℝ) / 400905691))
    (lo := ((451823 : ℝ) / 100000000)) (hi := ((28239 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((200905691 : ℝ) / 50000000) = Real.log ((200905691 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((200905691 : ℝ) / 50000000) = ((200905691 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1488 : RB (Real.log ((100453533 : ℝ) / 25000000)) ((139081943 : ℝ) / 100000000) ((69540973 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((100453533 : ℝ) / 100000000)) (t := ((453533 : ℝ) / 200453533))
    (lo := ((452507 : ℝ) / 100000000)) (hi := ((113127 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((100453533 : ℝ) / 25000000) = Real.log ((100453533 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((100453533 : ℝ) / 25000000) = ((100453533 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1489 : RB (Real.log ((16638951 : ℝ) / 12500000)) ((14300887 : ℝ) / 50000000) ((1144071 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((16638951 : ℝ) / 12500000)) (t := ((4138951 : ℝ) / 29138951))
    (lo := ((14300887 : ℝ) / 50000000)) (hi := ((1144071 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1490 : RB (Real.log ((1561649 : ℝ) / 12500000)) ((-51999659 : ℝ) / 25000000) ((-25999829 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((1561649 : ℝ) / 1562500)) (t := ((-851 : ℝ) / 3124149))
    (lo := ((-54479 : ℝ) / 100000000)) (hi := ((-27239 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1561649 : ℝ) / 12500000) = Real.log ((1561649 : ℝ) / 1562500) - 3 * Real.log 2 := by
    rw [show ((1561649 : ℝ) / 12500000) = ((1561649 : ℝ) / 1562500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1491 : RB (Real.log ((13299329 : ℝ) / 100000000)) ((-788069 : ℝ) / 390625) ((-10087283 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((13299329 : ℝ) / 12500000)) (t := ((799329 : ℝ) / 25799329))
    (lo := ((6198493 : ℝ) / 100000000)) (hi := ((3099247 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13299329 : ℝ) / 100000000) = Real.log ((13299329 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13299329 : ℝ) / 100000000) = ((13299329 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1492 : RB (Real.log ((4828787 : ℝ) / 100000000)) ((-303057493 : ℝ) / 100000000) ((-18941093 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((4828787 : ℝ) / 6250000)) (t := ((-1421213 : ℝ) / 11078787))
    (lo := ((-25798617 : ℝ) / 100000000)) (hi := ((-3224827 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4828787 : ℝ) / 100000000) = Real.log ((4828787 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4828787 : ℝ) / 100000000) = ((4828787 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1493 : RB (Real.log ((4864389 : ℝ) / 100000000)) ((-302322911 : ℝ) / 100000000) ((-151161453 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4864389 : ℝ) / 6250000)) (t := ((-1385611 : ℝ) / 11114389))
    (lo := ((-5012807 : ℝ) / 20000000)) (hi := ((-12532017 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4864389 : ℝ) / 100000000) = Real.log ((4864389 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4864389 : ℝ) / 100000000) = ((4864389 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1494 : RB (Real.log ((15979221 : ℝ) / 25000000)) ((-8951733 : ℝ) / 20000000) ((-44758663 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((15979221 : ℝ) / 12500000)) (t := ((3479221 : ℝ) / 28479221))
    (lo := ((12278027 : ℝ) / 50000000)) (hi := ((4911211 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15979221 : ℝ) / 25000000) = Real.log ((15979221 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((15979221 : ℝ) / 25000000) = ((15979221 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1495 : RB (Real.log ((63918389 : ℝ) / 100000000)) ((-4475631 : ℝ) / 10000000) ((-11189077 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((63918389 : ℝ) / 50000000)) (t := ((13918389 : ℝ) / 113918389))
    (lo := ((24558409 : ℝ) / 100000000)) (hi := ((2455841 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63918389 : ℝ) / 100000000) = Real.log ((63918389 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63918389 : ℝ) / 100000000) = ((63918389 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1496 : RB (Real.log ((4879241 : ℝ) / 12500000)) ((-47036949 : ℝ) / 50000000) ((-11759237 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4879241 : ℝ) / 6250000)) (t := ((-1370759 : ℝ) / 11129241))
    (lo := ((-24759179 : ℝ) / 100000000)) (hi := ((-12379589 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4879241 : ℝ) / 12500000) = Real.log ((4879241 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((4879241 : ℝ) / 12500000) = ((4879241 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1497 : RB (Real.log ((23760513 : ℝ) / 12500000)) ((16057411 : ℝ) / 25000000) ((32114823 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((23760513 : ℝ) / 25000000)) (t := ((-1239487 : ℝ) / 48760513))
    (lo := ((-2542537 : ℝ) / 50000000)) (hi := ((-5085073 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23760513 : ℝ) / 12500000) = Real.log ((23760513 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((23760513 : ℝ) / 12500000) = ((23760513 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1498 : RB (Real.log ((95075129 : ℝ) / 50000000)) ((1606611 : ℝ) / 2500000) ((32132221 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((95075129 : ℝ) / 100000000)) (t := ((-4924871 : ℝ) / 195075129))
    (lo := ((-2525139 : ℝ) / 50000000)) (hi := ((-5050277 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95075129 : ℝ) / 50000000) = Real.log ((95075129 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95075129 : ℝ) / 50000000) = ((95075129 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1499 : RB (Real.log ((32333663 : ℝ) / 50000000)) ((-43591413 : ℝ) / 100000000) ((-43591411 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32333663 : ℝ) / 25000000)) (t := ((7333663 : ℝ) / 57333663))
    (lo := ((12861653 : ℝ) / 50000000)) (hi := ((25723307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32333663 : ℝ) / 50000000) = Real.log ((32333663 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32333663 : ℝ) / 50000000) = ((32333663 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1500 : RB (Real.log ((32334419 : ℝ) / 50000000)) ((-1743563 : ℝ) / 4000000) ((-43589073 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32334419 : ℝ) / 25000000)) (t := ((7334419 : ℝ) / 57334419))
    (lo := ((6431411 : ℝ) / 25000000)) (hi := ((5145129 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32334419 : ℝ) / 50000000) = Real.log ((32334419 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32334419 : ℝ) / 50000000) = ((32334419 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1501 : RB (Real.log ((3931177 : ℝ) / 10000000)) ((-5835289 : ℝ) / 6250000) ((-46682311 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3931177 : ℝ) / 5000000)) (t := ((-1068823 : ℝ) / 8931177))
    (lo := ((-4809981 : ℝ) / 20000000)) (hi := ((-1503119 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3931177 : ℝ) / 10000000) = Real.log ((3931177 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((3931177 : ℝ) / 10000000) = ((3931177 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1502 : RB (Real.log ((402727781 : ℝ) / 100000000)) ((69654533 : ℝ) / 50000000) ((139309069 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((402727781 : ℝ) / 400000000)) (t := ((2727781 : ℝ) / 802727781))
    (lo := ((67963 : ℝ) / 10000000)) (hi := ((679631 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((402727781 : ℝ) / 100000000) = Real.log ((402727781 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((402727781 : ℝ) / 100000000) = ((402727781 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1503 : RB (Real.log ((1258533 : ℝ) / 312500)) ((34827439 : ℝ) / 25000000) ((139309759 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1258533 : ℝ) / 1250000)) (t := ((8533 : ℝ) / 2508533))
    (lo := ((1063 : ℝ) / 156250)) (hi := ((680321 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1258533 : ℝ) / 312500) = Real.log ((1258533 : ℝ) / 1250000) + 2 * Real.log 2 := by
    rw [show ((1258533 : ℝ) / 312500) = ((1258533 : ℝ) / 1250000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1504 : RB (Real.log ((1039149 : ℝ) / 781250)) ((14263109 : ℝ) / 50000000) ((28526219 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1039149 : ℝ) / 781250)) (t := ((257899 : ℝ) / 1820399))
    (lo := ((14263109 : ℝ) / 50000000)) (hi := ((28526219 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1505 : RB (Real.log ((401352523 : ℝ) / 100000000)) ((34741749 : ℝ) / 25000000) ((138966999 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((401352523 : ℝ) / 400000000)) (t := ((1352523 : ℝ) / 801352523))
    (lo := ((8439 : ℝ) / 2500000)) (hi := ((337561 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((401352523 : ℝ) / 100000000) = Real.log ((401352523 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((401352523 : ℝ) / 100000000) = ((401352523 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1506 : RB (Real.log ((401355289 : ℝ) / 100000000)) ((27793537 : ℝ) / 20000000) ((17370961 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((401355289 : ℝ) / 400000000)) (t := ((1355289 : ℝ) / 801355289))
    (lo := ((338249 : ℝ) / 100000000)) (hi := ((1353 : ℝ) / 400000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((401355289 : ℝ) / 100000000) = Real.log ((401355289 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((401355289 : ℝ) / 100000000) = ((401355289 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1507 : RB (Real.log ((66580861 : ℝ) / 50000000)) ((5727883 : ℝ) / 20000000) ((3579927 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((66580861 : ℝ) / 50000000)) (t := ((16580861 : ℝ) / 116580861))
    (lo := ((5727883 : ℝ) / 20000000)) (hi := ((3579927 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1508 : RB (Real.log ((3138471 : ℝ) / 25000000)) ((-51878503 : ℝ) / 25000000) ((-25939251 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((3138471 : ℝ) / 3125000)) (t := ((13471 : ℝ) / 6263471))
    (lo := ((86029 : ℝ) / 20000000)) (hi := ((215073 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3138471 : ℝ) / 25000000) = Real.log ((3138471 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((3138471 : ℝ) / 25000000) = ((3138471 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1509 : RB (Real.log ((13358063 : ℝ) / 100000000)) ((-40261001 : ℝ) / 20000000) ((-201305001 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13358063 : ℝ) / 12500000)) (t := ((858063 : ℝ) / 25858063))
    (lo := ((414947 : ℝ) / 6250000)) (hi := ((6639153 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13358063 : ℝ) / 100000000) = Real.log ((13358063 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((13358063 : ℝ) / 100000000) = ((13358063 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1510 : RB (Real.log ((4861001 : ℝ) / 100000000)) ((-37799073 : ℝ) / 12500000) ((-302392579 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4861001 : ℝ) / 6250000)) (t := ((-1388999 : ℝ) / 11111001))
    (lo := ((-6283427 : ℝ) / 25000000)) (hi := ((-25133707 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4861001 : ℝ) / 100000000) = Real.log ((4861001 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4861001 : ℝ) / 100000000) = ((4861001 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1511 : RB (Real.log ((2448313 : ℝ) / 50000000)) ((-301662383 : ℝ) / 100000000) ((-150831189 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2448313 : ℝ) / 3125000)) (t := ((-676687 : ℝ) / 5573313))
    (lo := ((-24403507 : ℝ) / 100000000)) (hi := ((-12201753 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2448313 : ℝ) / 50000000) = Real.log ((2448313 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2448313 : ℝ) / 50000000) = ((2448313 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1512 : RB (Real.log ((63830679 : ℝ) / 100000000)) ((-22446813 : ℝ) / 50000000) ((-5611703 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((63830679 : ℝ) / 50000000)) (t := ((13830679 : ℝ) / 113830679))
    (lo := ((24421093 : ℝ) / 100000000)) (hi := ((12210547 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63830679 : ℝ) / 100000000) = Real.log ((63830679 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63830679 : ℝ) / 100000000) = ((63830679 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1513 : RB (Real.log ((12766439 : ℝ) / 20000000)) ((-44891251 : ℝ) / 100000000) ((-44891249 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12766439 : ℝ) / 10000000)) (t := ((2766439 : ℝ) / 22766439))
    (lo := ((6105867 : ℝ) / 25000000)) (hi := ((24423469 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12766439 : ℝ) / 20000000) = Real.log ((12766439 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((12766439 : ℝ) / 20000000) = ((12766439 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1514 : RB (Real.log ((9750603 : ℝ) / 25000000)) ((-94154671 : ℝ) / 100000000) ((-94154669 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9750603 : ℝ) / 12500000)) (t := ((-2749397 : ℝ) / 22250603))
    (lo := ((-1552497 : ℝ) / 6250000)) (hi := ((-24839951 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9750603 : ℝ) / 25000000) = Real.log ((9750603 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9750603 : ℝ) / 25000000) = ((9750603 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1515 : RB (Real.log ((9500897 : ℝ) / 5000000)) ((6419483 : ℝ) / 10000000) ((4012177 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((9500897 : ℝ) / 10000000)) (t := ((-499103 : ℝ) / 19500897))
    (lo := ((-319993 : ℝ) / 6250000)) (hi := ((-5119887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9500897 : ℝ) / 5000000) = Real.log ((9500897 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((9500897 : ℝ) / 5000000) = ((9500897 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1516 : RB (Real.log ((47521027 : ℝ) / 25000000)) ((32114823 : ℝ) / 50000000) ((4014353 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((47521027 : ℝ) / 50000000)) (t := ((-2478973 : ℝ) / 97521027))
    (lo := ((-317817 : ℝ) / 6250000)) (hi := ((-5085071 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47521027 : ℝ) / 25000000) = Real.log ((47521027 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((47521027 : ℝ) / 25000000) = ((47521027 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1517 : RB (Real.log ((64577993 : ℝ) / 100000000)) ((-43729651 : ℝ) / 100000000) ((-43729649 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64577993 : ℝ) / 50000000)) (t := ((14577993 : ℝ) / 114577993))
    (lo := ((6396267 : ℝ) / 25000000)) (hi := ((25585069 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64577993 : ℝ) / 100000000) = Real.log ((64577993 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((64577993 : ℝ) / 100000000) = ((64577993 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1518 : RB (Real.log ((12915903 : ℝ) / 20000000)) ((-8745459 : ℝ) / 20000000) ((-43727293 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12915903 : ℝ) / 10000000)) (t := ((2915903 : ℝ) / 22915903))
    (lo := ((799607 : ℝ) / 3125000)) (hi := ((1023497 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12915903 : ℝ) / 20000000) = Real.log ((12915903 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((12915903 : ℝ) / 20000000) = ((12915903 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1519 : RB (Real.log ((39279389 : ℝ) / 100000000)) ((-93447027 : ℝ) / 100000000) ((-3737881 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((39279389 : ℝ) / 50000000)) (t := ((-10720611 : ℝ) / 89279389))
    (lo := ((-6033077 : ℝ) / 25000000)) (hi := ((-24132307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39279389 : ℝ) / 100000000) = Real.log ((39279389 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39279389 : ℝ) / 100000000) = ((39279389 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
