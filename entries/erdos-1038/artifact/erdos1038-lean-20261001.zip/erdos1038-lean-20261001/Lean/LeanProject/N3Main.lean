import LeanProject.N3Cert

/-!
# EP-1038: the fixed-degree infimum for n = 3 is 2 (proof.md Theorem 2.4), fully formalised

`cert_ok` checks the generated certificate (N3Cert.lean) by kernel evaluation (`decide`).
`m3_lower`: every cubic with roots in `[-1,1]` has `|S| ≥ 2`; `m3_attained`: `(x - c)^3` has `|S| = 2`.
-/

open Real MeasureTheory

namespace EP1038.N3

theorem cert_ok : check certTree box0 = true := by decide

theorem m3_lower_sorted (r : Fin 3 → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1)
    (h01 : r 0 ≤ r 1) (h12 : r 1 ≤ r 2) (hsum : 0 ≤ r 0 + r 2) :
    ENNReal.ofReal 2 ≤ volume (sublevel r) :=
  check_sound certTree box0 cert_ok r (inBox0 r hr) h01 h12 hsum

theorem sublevel_eq_of_prod (r r' : Fin 3 → ℝ) (h : ∀ x, ∏ i, (x - r' i) = ∏ i, (x - r i)) :
    sublevel r' = sublevel r := by
  ext x; simp only [sublevel, Set.mem_setOf_eq, h]

/-- A sorted rearrangement `p ≤ q ≤ s` of the roots gives the bound (with reflection if needed). -/
theorem sorted_case (r : Fin 3 → ℝ) (p q s : ℝ) (hp : p ∈ Set.Icc (-1 : ℝ) 1)
    (hq : q ∈ Set.Icc (-1 : ℝ) 1) (hs : s ∈ Set.Icc (-1 : ℝ) 1) (hpq : p ≤ q) (hqs : q ≤ s)
    (hprod : ∀ x, (x - p) * (x - q) * (x - s) = ∏ i, (x - r i)) :
    ENNReal.ofReal 2 ≤ volume (sublevel r) := by
  have hr' : sublevel ![p, q, s] = sublevel r :=
    sublevel_eq_of_prod r ![p, q, s] (fun x => by rw [Fin.prod_univ_three]; exact hprod x)
  rw [← hr']
  have hb : ∀ i, (![p, q, s] : Fin 3 → ℝ) i ∈ Set.Icc (-1 : ℝ) 1 := by
    intro i; fin_cases i <;> simp [hp, hq, hs]
  rcases le_total 0 (p + s) with h | h
  · exact m3_lower_sorted _ hb (by simpa using hpq) (by simpa using hqs) (by simpa using h)
  · -- reflect: (-s, -q, -p) is sorted with nonnegative extreme sum
    have hneg : sublevel ![-s, -q, -p] = sublevel (fun i => -(![p, q, s] : Fin 3 → ℝ) i) :=
      sublevel_eq_of_prod _ _ (fun x => by simp [Fin.prod_univ_three]; ring)
    rw [← volume_sublevel_neg, ← hneg]
    have hb' : ∀ i, (![-s, -q, -p] : Fin 3 → ℝ) i ∈ Set.Icc (-1 : ℝ) 1 := by
      intro i
      fin_cases i <;> simp <;> constructor <;> linarith [hp.1, hp.2, hq.1, hq.2, hs.1, hs.2]
    exact m3_lower_sorted _ hb' (by simp; linarith) (by simp; linarith) (by simp; linarith)

/-- Theorem 2.4, lower bound: every monic cubic with roots in `[-1,1]` has `|S| ≥ 2`. -/
theorem m3_lower (r : Fin 3 → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    ENNReal.ofReal 2 ≤ volume (sublevel r) := by
  have h0 := hr 0
  have h1 := hr 1
  have h2 := hr 2
  have e : ∀ x, ∏ i, (x - r i) = (x - r 0) * (x - r 1) * (x - r 2) := fun x => Fin.prod_univ_three _
  rcases le_total (r 0) (r 1) with hab | hab <;> rcases le_total (r 1) (r 2) with hbc | hbc <;>
    rcases le_total (r 0) (r 2) with hac | hac
  all_goals first
    | exact sorted_case r (r 0) (r 1) (r 2) h0 h1 h2 (by linarith) (by linarith)
        (fun x => by rw [e] <;> ring)
    | exact sorted_case r (r 0) (r 2) (r 1) h0 h2 h1 (by linarith) (by linarith)
        (fun x => by rw [e] <;> ring)
    | exact sorted_case r (r 1) (r 0) (r 2) h1 h0 h2 (by linarith) (by linarith)
        (fun x => by rw [e] <;> ring)
    | exact sorted_case r (r 1) (r 2) (r 0) h1 h2 h0 (by linarith) (by linarith)
        (fun x => by rw [e] <;> ring)
    | exact sorted_case r (r 2) (r 0) (r 1) h2 h0 h1 (by linarith) (by linarith)
        (fun x => by rw [e] <;> ring)
    | exact sorted_case r (r 2) (r 1) (r 0) h2 h1 h0 (by linarith) (by linarith)
        (fun x => by rw [e] <;> ring)

/-- Theorem 2.4, attainment: the triple root `(x - c)^3` has `|S| = 2`. -/
theorem m3_attained (c : ℝ) : volume (sublevel (fun _ : Fin 3 => c)) = ENNReal.ofReal 2 := by
  have : sublevel (fun _ : Fin 3 => c) = Set.Ioo (c - 1) (c + 1) := by
    ext x
    simp only [sublevel, Set.mem_setOf_eq, Fin.prod_univ_three, Set.mem_Ioo]
    rw [show (x - c) * (x - c) * (x - c) = (x - c) ^ 3 by ring, abs_pow,
      pow_lt_one_iff_of_nonneg (abs_nonneg _) (by norm_num), abs_lt]
    constructor <;> rintro ⟨h1, h2⟩ <;> constructor <;> linarith
  rw [this, Real.volume_Ioo]; congr 1; ring

/-- `m₃ = 2`: the minimum of `|S|` over monic cubics with all roots in `[-1,1]` is `2`. -/
theorem m3_eq_two :
    (∀ r : Fin 3 → ℝ, (∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) → ENNReal.ofReal 2 ≤ volume (sublevel r)) ∧
      volume (sublevel (fun _ : Fin 3 => (0 : ℝ))) = ENNReal.ofReal 2 :=
  ⟨m3_lower, m3_attained 0⟩

end EP1038.N3
