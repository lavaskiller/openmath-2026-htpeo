import LeanProject.COVLogTwo
import LeanProject.COVLogBounds24
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2240 : RB (Real.log ((4387829 : ℝ) / 3125000)) ((8485007 : ℝ) / 25000000) ((3394003 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((4387829 : ℝ) / 6250000)) (t := ((-1862171 : ℝ) / 10637829))
    (lo := ((-3537469 : ℝ) / 10000000)) (hi := ((-35374689 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4387829 : ℝ) / 3125000) = Real.log ((4387829 : ℝ) / 6250000) + 1 * Real.log 2 := by
    rw [show ((4387829 : ℝ) / 3125000) = ((4387829 : ℝ) / 6250000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2241 : RB (Real.log ((13828859 : ℝ) / 4000000)) ((124046327 : ℝ) / 100000000) ((12404633 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((13828859 : ℝ) / 16000000)) (t := ((-2171141 : ℝ) / 29828859))
    (lo := ((-14583109 : ℝ) / 100000000)) (hi := ((-3645777 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13828859 : ℝ) / 4000000) = Real.log ((13828859 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((13828859 : ℝ) / 4000000) = ((13828859 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2242 : RB (Real.log ((172860739 : ℝ) / 50000000)) ((15505791 : ℝ) / 12500000) ((124046331 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((172860739 : ℝ) / 200000000)) (t := ((-27139261 : ℝ) / 372860739))
    (lo := ((-3645777 : ℝ) / 25000000)) (hi := ((-14583107 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((172860739 : ℝ) / 50000000) = Real.log ((172860739 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((172860739 : ℝ) / 50000000) = ((172860739 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2243 : RB (Real.log ((140668261 : ℝ) / 100000000)) ((34123417 : ℝ) / 100000000) ((34123419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((140668261 : ℝ) / 200000000)) (t := ((-59331739 : ℝ) / 340668261))
    (lo := ((-35191301 : ℝ) / 100000000)) (hi := ((-351913 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((140668261 : ℝ) / 100000000) = Real.log ((140668261 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((140668261 : ℝ) / 100000000) = ((140668261 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2244 : RB (Real.log ((1189989 : ℝ) / 1562500)) ((-106384 : ℝ) / 390625) ((-27234303 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1189989 : ℝ) / 1562500)) (t := ((-372511 : ℝ) / 2752489))
    (lo := ((-106384 : ℝ) / 390625)) (hi := ((-27234303 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2245 : RB (Real.log ((77591619 : ℝ) / 100000000)) ((-25371077 : ℝ) / 100000000) ((-6342769 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((77591619 : ℝ) / 100000000)) (t := ((-22408381 : ℝ) / 177591619))
    (lo := ((-25371077 : ℝ) / 100000000)) (hi := ((-6342769 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2246 : RB (Real.log ((10306053 : ℝ) / 12500000)) ((-9649863 : ℝ) / 50000000) ((-771989 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((10306053 : ℝ) / 12500000)) (t := ((-2193947 : ℝ) / 22806053))
    (lo := ((-9649863 : ℝ) / 50000000)) (hi := ((-771989 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2247 : RB (Real.log ((82448427 : ℝ) / 100000000)) ((-9649861 : ℝ) / 50000000) ((-19299721 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((82448427 : ℝ) / 100000000)) (t := ((-17551573 : ℝ) / 182448427))
    (lo := ((-9649861 : ℝ) / 50000000)) (hi := ((-19299721 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2248 : RB (Real.log ((11307 : ℝ) / 25000)) ((-9918173 : ℝ) / 12500000) ((-39672691 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((11307 : ℝ) / 12500)) (t := ((-1193 : ℝ) / 23807))
    (lo := ((-2006133 : ℝ) / 20000000)) (hi := ((-1253833 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11307 : ℝ) / 25000) = Real.log ((11307 : ℝ) / 12500) - 1 * Real.log 2 := by
    rw [show ((11307 : ℝ) / 25000) = ((11307 : ℝ) / 12500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2249 : RB (Real.log ((41362921 : ℝ) / 50000000)) ((-2370477 : ℝ) / 12500000) ((-3792763 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((41362921 : ℝ) / 50000000)) (t := ((-8637079 : ℝ) / 91362921))
    (lo := ((-2370477 : ℝ) / 12500000)) (hi := ((-3792763 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2250 : RB (Real.log ((16545169 : ℝ) / 20000000)) ((-4740953 : ℝ) / 25000000) ((-18963811 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16545169 : ℝ) / 20000000)) (t := ((-3454831 : ℝ) / 36545169))
    (lo := ((-4740953 : ℝ) / 25000000)) (hi := ((-18963811 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2251 : RB (Real.log ((11327789 : ℝ) / 25000000)) ((-79161693 : ℝ) / 100000000) ((-79161691 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11327789 : ℝ) / 12500000)) (t := ((-1172211 : ℝ) / 23827789))
    (lo := ((-4923487 : ℝ) / 50000000)) (hi := ((-9846973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11327789 : ℝ) / 25000000) = Real.log ((11327789 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11327789 : ℝ) / 25000000) = ((11327789 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2252 : RB (Real.log ((34675669 : ℝ) / 10000000)) ((31086329 : ℝ) / 25000000) ((124345319 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((34675669 : ℝ) / 40000000)) (t := ((-5324331 : ℝ) / 74675669))
    (lo := ((-357103 : ℝ) / 2500000)) (hi := ((-14284119 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34675669 : ℝ) / 10000000) = Real.log ((34675669 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((34675669 : ℝ) / 10000000) = ((34675669 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2253 : RB (Real.log ((346756693 : ℝ) / 100000000)) ((124345317 : ℝ) / 100000000) ((3108633 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((346756693 : ℝ) / 400000000)) (t := ((-53243307 : ℝ) / 746756693))
    (lo := ((-14284119 : ℝ) / 100000000)) (hi := ((-7142059 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((346756693 : ℝ) / 100000000) = Real.log ((346756693 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((346756693 : ℝ) / 100000000) = ((346756693 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2254 : RB (Real.log ((70248823 : ℝ) / 50000000)) ((17001027 : ℝ) / 50000000) ((4250257 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((70248823 : ℝ) / 100000000)) (t := ((-29751177 : ℝ) / 170248823))
    (lo := ((-4414083 : ℝ) / 12500000)) (hi := ((-35312663 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70248823 : ℝ) / 50000000) = Real.log ((70248823 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70248823 : ℝ) / 50000000) = ((70248823 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2255 : RB (Real.log ((34521803 : ℝ) / 10000000)) ((619503 : ℝ) / 500000) ((123900603 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((34521803 : ℝ) / 40000000)) (t := ((-5478197 : ℝ) / 74521803))
    (lo := ((-3682209 : ℝ) / 25000000)) (hi := ((-2945767 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34521803 : ℝ) / 10000000) = Real.log ((34521803 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((34521803 : ℝ) / 10000000) = ((34521803 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2256 : RB (Real.log ((345218033 : ℝ) / 100000000)) ((123900601 : ℝ) / 100000000) ((30975151 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((345218033 : ℝ) / 400000000)) (t := ((-54781967 : ℝ) / 745218033))
    (lo := ((-2945767 : ℝ) / 20000000)) (hi := ((-7364417 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((345218033 : ℝ) / 100000000) = Real.log ((345218033 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((345218033 : ℝ) / 100000000) = ((345218033 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2257 : RB (Real.log ((28150351 : ℝ) / 20000000)) ((17091377 : ℝ) / 50000000) ((8545689 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((28150351 : ℝ) / 40000000)) (t := ((-11849649 : ℝ) / 68150351))
    (lo := ((-8782991 : ℝ) / 25000000)) (hi := ((-35131963 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28150351 : ℝ) / 20000000) = Real.log ((28150351 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((28150351 : ℝ) / 20000000) = ((28150351 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2258 : RB (Real.log ((77092303 : ℝ) / 100000000)) ((-1040667 : ℝ) / 4000000) ((-13008337 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((77092303 : ℝ) / 100000000)) (t := ((-22907697 : ℝ) / 177092303))
    (lo := ((-1040667 : ℝ) / 4000000)) (hi := ((-13008337 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2259 : RB (Real.log ((39258961 : ℝ) / 50000000)) ((-24184329 : ℝ) / 100000000) ((-3023041 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((39258961 : ℝ) / 50000000)) (t := ((-10741039 : ℝ) / 89258961))
    (lo := ((-24184329 : ℝ) / 100000000)) (hi := ((-3023041 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2260 : RB (Real.log ((41271599 : ℝ) / 50000000)) ((-9592421 : ℝ) / 50000000) ((-19184841 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41271599 : ℝ) / 50000000)) (t := ((-8728401 : ℝ) / 91271599))
    (lo := ((-9592421 : ℝ) / 50000000)) (hi := ((-19184841 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2261 : RB (Real.log ((82543201 : ℝ) / 100000000)) ((-19184839 : ℝ) / 100000000) ((-9592419 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((82543201 : ℝ) / 100000000)) (t := ((-17456799 : ℝ) / 182543201))
    (lo := ((-19184839 : ℝ) / 100000000)) (hi := ((-9592419 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2262 : RB (Real.log ((45256437 : ℝ) / 100000000)) ((-79282529 : ℝ) / 100000000) ((-79282527 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45256437 : ℝ) / 50000000)) (t := ((-4743563 : ℝ) / 95256437))
    (lo := ((-996781 : ℝ) / 10000000)) (hi := ((-9967809 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45256437 : ℝ) / 100000000) = Real.log ((45256437 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45256437 : ℝ) / 100000000) = ((45256437 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2263 : RB (Real.log ((82813697 : ℝ) / 100000000)) ((-2357209 : ℝ) / 12500000) ((-18857671 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((82813697 : ℝ) / 100000000)) (t := ((-17186303 : ℝ) / 182813697))
    (lo := ((-2357209 : ℝ) / 12500000)) (hi := ((-18857671 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2264 : RB (Real.log ((828137 : ℝ) / 1000000)) ((-4714417 : ℝ) / 25000000) ((-18857667 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((828137 : ℝ) / 1000000)) (t := ((-171863 : ℝ) / 1828137))
    (lo := ((-4714417 : ℝ) / 25000000)) (hi := ((-18857667 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2265 : RB (Real.log ((22668719 : ℝ) / 50000000)) ((-39551853 : ℝ) / 50000000) ((-9887963 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((22668719 : ℝ) / 25000000)) (t := ((-2331281 : ℝ) / 47668719))
    (lo := ((-9788987 : ℝ) / 100000000)) (hi := ((-4894493 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22668719 : ℝ) / 50000000) = Real.log ((22668719 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22668719 : ℝ) / 50000000) = ((22668719 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2266 : RB (Real.log ((86558621 : ℝ) / 25000000)) ((24838921 : ℝ) / 20000000) ((7762163 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((86558621 : ℝ) / 100000000)) (t := ((-13441379 : ℝ) / 186558621))
    (lo := ((-14434831 : ℝ) / 100000000)) (hi := ((-1443483 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86558621 : ℝ) / 25000000) = Real.log ((86558621 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((86558621 : ℝ) / 25000000) = ((86558621 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2267 : RB (Real.log ((43279311 : ℝ) / 12500000)) ((62097303 : ℝ) / 50000000) ((124194609 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43279311 : ℝ) / 50000000)) (t := ((-6720689 : ℝ) / 93279311))
    (lo := ((-1443483 : ℝ) / 10000000)) (hi := ((-14434829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43279311 : ℝ) / 12500000) = Real.log ((43279311 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((43279311 : ℝ) / 12500000) = ((43279311 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2268 : RB (Real.log ((35145883 : ℝ) / 25000000)) ((6812633 : ℝ) / 20000000) ((34063167 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35145883 : ℝ) / 50000000)) (t := ((-14854117 : ℝ) / 85145883))
    (lo := ((-35251553 : ℝ) / 100000000)) (hi := ((-1101611 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((35145883 : ℝ) / 25000000) = Real.log ((35145883 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((35145883 : ℝ) / 25000000) = ((35145883 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2269 : RB (Real.log ((86180893 : ℝ) / 25000000)) ((61878633 : ℝ) / 50000000) ((123757269 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((86180893 : ℝ) / 100000000)) (t := ((-13819107 : ℝ) / 186180893))
    (lo := ((-1487217 : ℝ) / 10000000)) (hi := ((-14872169 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86180893 : ℝ) / 25000000) = Real.log ((86180893 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((86180893 : ℝ) / 25000000) = ((86180893 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2270 : RB (Real.log ((13788943 : ℝ) / 4000000)) ((123757267 : ℝ) / 100000000) ((12375727 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((13788943 : ℝ) / 16000000)) (t := ((-2211057 : ℝ) / 29788943))
    (lo := ((-14872169 : ℝ) / 100000000)) (hi := ((-1859021 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13788943 : ℝ) / 4000000) = Real.log ((13788943 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((13788943 : ℝ) / 4000000) = ((13788943 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2271 : RB (Real.log ((140834093 : ℝ) / 100000000)) ((8560309 : ℝ) / 25000000) ((17120619 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((140834093 : ℝ) / 200000000)) (t := ((-59165907 : ℝ) / 340834093))
    (lo := ((-17536741 : ℝ) / 50000000)) (hi := ((-35073481 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((140834093 : ℝ) / 100000000) = Real.log ((140834093 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((140834093 : ℝ) / 100000000) = ((140834093 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2272 : RB (Real.log ((78020669 : ℝ) / 100000000)) ((-24819641 : ℝ) / 100000000) ((-620491 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((78020669 : ℝ) / 100000000)) (t := ((-21979331 : ℝ) / 178020669))
    (lo := ((-24819641 : ℝ) / 100000000)) (hi := ((-620491 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2273 : RB (Real.log ((79439783 : ℝ) / 100000000)) ((-2301709 : ℝ) / 10000000) ((-23017089 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((79439783 : ℝ) / 100000000)) (t := ((-20560217 : ℝ) / 179439783))
    (lo := ((-2301709 : ℝ) / 10000000)) (hi := ((-23017089 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2274 : RB (Real.log ((41317789 : ℝ) / 50000000)) ((-4768247 : ℝ) / 25000000) ((-19072987 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41317789 : ℝ) / 50000000)) (t := ((-8682211 : ℝ) / 91317789))
    (lo := ((-4768247 : ℝ) / 25000000)) (hi := ((-19072987 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2275 : RB (Real.log ((4131779 : ℝ) / 5000000)) ((-3814597 : ℝ) / 20000000) ((-2384123 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4131779 : ℝ) / 5000000)) (t := ((-868221 : ℝ) / 9131779))
    (lo := ((-3814597 : ℝ) / 20000000)) (hi := ((-2384123 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2276 : RB (Real.log ((45284127 : ℝ) / 100000000)) ((-79221363 : ℝ) / 100000000) ((-79221361 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45284127 : ℝ) / 50000000)) (t := ((-4715873 : ℝ) / 95284127))
    (lo := ((-2476661 : ℝ) / 25000000)) (hi := ((-9906643 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45284127 : ℝ) / 100000000) = Real.log ((45284127 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45284127 : ℝ) / 100000000) = ((45284127 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2277 : RB (Real.log ((3315977 : ℝ) / 4000000)) ((-9377103 : ℝ) / 50000000) ((-3750841 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3315977 : ℝ) / 4000000)) (t := ((-684023 : ℝ) / 7315977))
    (lo := ((-9377103 : ℝ) / 50000000)) (hi := ((-3750841 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2278 : RB (Real.log ((82899427 : ℝ) / 100000000)) ((-4688551 : ℝ) / 25000000) ((-18754203 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((82899427 : ℝ) / 100000000)) (t := ((-17100573 : ℝ) / 182899427))
    (lo := ((-4688551 : ℝ) / 25000000)) (hi := ((-18754203 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2279 : RB (Real.log ((45363059 : ℝ) / 100000000)) ((-79047211 : ℝ) / 100000000) ((-79047209 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((45363059 : ℝ) / 50000000)) (t := ((-4636941 : ℝ) / 95363059))
    (lo := ((-2433123 : ℝ) / 25000000)) (hi := ((-9732491 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45363059 : ℝ) / 100000000) = Real.log ((45363059 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45363059 : ℝ) / 100000000) = ((45363059 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2280 : RB (Real.log ((345721783 : ℝ) / 100000000)) ((7752901 : ℝ) / 6250000) ((124046419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((345721783 : ℝ) / 400000000)) (t := ((-54278217 : ℝ) / 745721783))
    (lo := ((-729151 : ℝ) / 5000000)) (hi := ((-14583019 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((345721783 : ℝ) / 100000000) = Real.log ((345721783 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((345721783 : ℝ) / 100000000) = ((345721783 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2281 : RB (Real.log ((345721787 : ℝ) / 100000000)) ((62023209 : ℝ) / 50000000) ((124046421 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((345721787 : ℝ) / 400000000)) (t := ((-54278213 : ℝ) / 745721787))
    (lo := ((-7291509 : ℝ) / 50000000)) (hi := ((-14583017 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((345721787 : ℝ) / 100000000) = Real.log ((345721787 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((345721787 : ℝ) / 100000000) = ((345721787 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2282 : RB (Real.log ((14066821 : ℝ) / 10000000)) ((34123381 : ℝ) / 100000000) ((34123383 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((14066821 : ℝ) / 20000000)) (t := ((-5933179 : ℝ) / 34066821))
    (lo := ((-35191337 : ℝ) / 100000000)) (hi := ((-4398917 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14066821 : ℝ) / 10000000) = Real.log ((14066821 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((14066821 : ℝ) / 10000000) = ((14066821 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2283 : RB (Real.log ((21514867 : ℝ) / 6250000)) ((123616271 : ℝ) / 100000000) ((61808137 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((21514867 : ℝ) / 25000000)) (t := ((-3485133 : ℝ) / 46514867))
    (lo := ((-3002633 : ℝ) / 20000000)) (hi := ((-3753291 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21514867 : ℝ) / 6250000) = Real.log ((21514867 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((21514867 : ℝ) / 6250000) = ((21514867 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2284 : RB (Real.log ((86059469 : ℝ) / 25000000)) ((123616273 : ℝ) / 100000000) ((30904069 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((86059469 : ℝ) / 100000000)) (t := ((-13940531 : ℝ) / 186059469))
    (lo := ((-15013163 : ℝ) / 100000000)) (hi := ((-7506581 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86059469 : ℝ) / 25000000) = Real.log ((86059469 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((86059469 : ℝ) / 25000000) = ((86059469 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2285 : RB (Real.log ((140915297 : ℝ) / 100000000)) ((34298879 : ℝ) / 100000000) ((34298881 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((140915297 : ℝ) / 200000000)) (t := ((-59084703 : ℝ) / 340915297))
    (lo := ((-35015839 : ℝ) / 100000000)) (hi := ((-17507919 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((140915297 : ℝ) / 100000000) = Real.log ((140915297 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((140915297 : ℝ) / 100000000) = ((140915297 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2286 : RB (Real.log ((15788893 : ℝ) / 20000000)) ((-5910639 : ℝ) / 25000000) ((-4728511 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((15788893 : ℝ) / 20000000)) (t := ((-4211107 : ℝ) / 35788893))
    (lo := ((-5910639 : ℝ) / 25000000)) (hi := ((-4728511 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2287 : RB (Real.log ((40178647 : ℝ) / 50000000)) ((-21868733 : ℝ) / 100000000) ((-5467183 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((40178647 : ℝ) / 50000000)) (t := ((-9821353 : ℝ) / 90178647))
    (lo := ((-21868733 : ℝ) / 100000000)) (hi := ((-5467183 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2288 : RB (Real.log ((41362829 : ℝ) / 50000000)) ((-9482019 : ℝ) / 50000000) ((-18964037 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41362829 : ℝ) / 50000000)) (t := ((-8637171 : ℝ) / 91362829))
    (lo := ((-9482019 : ℝ) / 50000000)) (hi := ((-18964037 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2289 : RB (Real.log ((82725661 : ℝ) / 100000000)) ((-3792807 : ℝ) / 20000000) ((-9482017 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((82725661 : ℝ) / 100000000)) (t := ((-17274339 : ℝ) / 182725661))
    (lo := ((-3792807 : ℝ) / 20000000)) (hi := ((-9482017 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2290 : RB (Real.log ((45311101 : ℝ) / 100000000)) ((-39580907 : ℝ) / 50000000) ((-19790453 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((45311101 : ℝ) / 50000000)) (t := ((-4688899 : ℝ) / 95311101))
    (lo := ((-1969419 : ℝ) / 20000000)) (hi := ((-4923547 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45311101 : ℝ) / 100000000) = Real.log ((45311101 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45311101 : ℝ) / 100000000) = ((45311101 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2291 : RB (Real.log ((16596619 : ℝ) / 20000000)) ((-1165833 : ℝ) / 6250000) ((-18653327 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16596619 : ℝ) / 20000000)) (t := ((-3403381 : ℝ) / 36596619))
    (lo := ((-1165833 : ℝ) / 6250000)) (hi := ((-18653327 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2292 : RB (Real.log ((82983097 : ℝ) / 100000000)) ((-746133 : ℝ) / 4000000) ((-4663331 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((82983097 : ℝ) / 100000000)) (t := ((-17016903 : ℝ) / 182983097))
    (lo := ((-746133 : ℝ) / 4000000)) (hi := ((-4663331 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2293 : RB (Real.log ((22694021 : ℝ) / 50000000)) ((-9874019 : ℝ) / 12500000) ((-1579843 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((22694021 : ℝ) / 25000000)) (t := ((-2305979 : ℝ) / 47694021))
    (lo := ((-9677433 : ℝ) / 100000000)) (hi := ((-1209679 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22694021 : ℝ) / 50000000) = Real.log ((22694021 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22694021 : ℝ) / 50000000) = ((22694021 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2294 : RB (Real.log ((13808733 : ℝ) / 4000000)) ((24780137 : ℝ) / 20000000) ((7743793 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((13808733 : ℝ) / 16000000)) (t := ((-2191267 : ℝ) / 29808733))
    (lo := ((-14728751 : ℝ) / 100000000)) (hi := ((-11783 : ℝ) / 80000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13808733 : ℝ) / 4000000) = Real.log ((13808733 : ℝ) / 16000000) + 2 * Real.log 2 := by
    rw [show ((13808733 : ℝ) / 4000000) = ((13808733 : ℝ) / 16000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2295 : RB (Real.log ((43152291 : ℝ) / 12500000)) ((61950343 : ℝ) / 50000000) ((123900689 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43152291 : ℝ) / 50000000)) (t := ((-6847709 : ℝ) / 93152291))
    (lo := ((-11783 : ℝ) / 80000)) (hi := ((-14728749 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43152291 : ℝ) / 12500000) = Real.log ((43152291 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((43152291 : ℝ) / 12500000) = ((43152291 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2296 : RB (Real.log ((70375853 : ℝ) / 50000000)) ((106821 : ℝ) / 312500) ((17091361 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((70375853 : ℝ) / 100000000)) (t := ((-29624147 : ℝ) / 170375853))
    (lo := ((-17565999 : ℝ) / 50000000)) (hi := ((-35131997 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70375853 : ℝ) / 50000000) = Real.log ((70375853 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70375853 : ℝ) / 50000000) = ((70375853 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2297 : RB (Real.log ((343760697 : ℝ) / 100000000)) ((123477557 : ℝ) / 100000000) ((3086939 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((343760697 : ℝ) / 400000000)) (t := ((-56239303 : ℝ) / 743760697))
    (lo := ((-15151879 : ℝ) / 100000000)) (hi := ((-7575939 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((343760697 : ℝ) / 100000000) = Real.log ((343760697 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((343760697 : ℝ) / 100000000) = ((343760697 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2298 : RB (Real.log ((3437607 : ℝ) / 1000000)) ((61738779 : ℝ) / 50000000) ((123477561 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3437607 : ℝ) / 4000000)) (t := ((-562393 : ℝ) / 7437607))
    (lo := ((-7575939 : ℝ) / 50000000)) (hi := ((-15151877 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3437607 : ℝ) / 1000000) = Real.log ((3437607 : ℝ) / 4000000) + 2 * Real.log 2 := by
    rw [show ((3437607 : ℝ) / 1000000) = ((3437607 : ℝ) / 4000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2299 : RB (Real.log ((140995391 : ℝ) / 100000000)) ((34355701 : ℝ) / 100000000) ((34355703 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((140995391 : ℝ) / 200000000)) (t := ((-59004609 : ℝ) / 340995391))
    (lo := ((-34959017 : ℝ) / 100000000)) (hi := ((-4369877 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((140995391 : ℝ) / 100000000) = Real.log ((140995391 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((140995391 : ℝ) / 100000000) = ((140995391 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2300 : RB (Real.log ((4991487 : ℝ) / 6250000)) ((-22484761 : ℝ) / 100000000) ((-562119 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((4991487 : ℝ) / 6250000)) (t := ((-1258513 : ℝ) / 11241487))
    (lo := ((-22484761 : ℝ) / 100000000)) (hi := ((-562119 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2301 : RB (Real.log ((40635257 : ℝ) / 50000000)) ((-5184673 : ℝ) / 25000000) ((-20738691 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40635257 : ℝ) / 50000000)) (t := ((-9364743 : ℝ) / 90635257))
    (lo := ((-5184673 : ℝ) / 25000000)) (hi := ((-20738691 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2302 : RB (Real.log ((20703381 : ℝ) / 25000000)) ((-18857881 : ℝ) / 100000000) ((-471447 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((20703381 : ℝ) / 25000000)) (t := ((-4296619 : ℝ) / 45703381))
    (lo := ((-18857881 : ℝ) / 100000000)) (hi := ((-471447 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2303 : RB (Real.log ((41406763 : ℝ) / 50000000)) ((-18857879 : ℝ) / 100000000) ((-9428939 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((41406763 : ℝ) / 50000000)) (t := ((-8593237 : ℝ) / 91406763))
    (lo := ((-18857879 : ℝ) / 100000000)) (hi := ((-9428939 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2304 : RB (Real.log ((22668693 : ℝ) / 50000000)) ((-79103821 : ℝ) / 100000000) ((-79103819 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22668693 : ℝ) / 25000000)) (t := ((-2331307 : ℝ) / 47668693))
    (lo := ((-4894551 : ℝ) / 50000000)) (hi := ((-9789101 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22668693 : ℝ) / 50000000) = Real.log ((22668693 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22668693 : ℝ) / 50000000) = ((22668693 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2305 : RB (Real.log ((16612957 : ℝ) / 20000000)) ((-3710987 : ℝ) / 20000000) ((-9277467 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16612957 : ℝ) / 20000000)) (t := ((-3387043 : ℝ) / 36612957))
    (lo := ((-3710987 : ℝ) / 20000000)) (hi := ((-9277467 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2306 : RB (Real.log ((20766197 : ℝ) / 25000000)) ((-18554931 : ℝ) / 100000000) ((-1855493 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((20766197 : ℝ) / 25000000)) (t := ((-4233803 : ℝ) / 45766197))
    (lo := ((-18554931 : ℝ) / 100000000)) (hi := ((-1855493 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2307 : RB (Real.log ((11353103 : ℝ) / 25000000)) ((-39469237 : ℝ) / 50000000) ((-9867309 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((11353103 : ℝ) / 12500000)) (t := ((-1146897 : ℝ) / 23853103))
    (lo := ((-1924751 : ℝ) / 20000000)) (hi := ((-4811877 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11353103 : ℝ) / 25000000) = Real.log ((11353103 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11353103 : ℝ) / 25000000) = ((11353103 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2308 : RB (Real.log ((344723859 : ℝ) / 100000000)) ((2475147 : ℝ) / 2000000) ((123757353 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((344723859 : ℝ) / 400000000)) (t := ((-55276141 : ℝ) / 744723859))
    (lo := ((-7436043 : ℝ) / 50000000)) (hi := ((-2974417 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((344723859 : ℝ) / 100000000) = Real.log ((344723859 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((344723859 : ℝ) / 100000000) = ((344723859 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2309 : RB (Real.log ((344723863 : ℝ) / 100000000)) ((123757351 : ℝ) / 100000000) ((61878677 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((344723863 : ℝ) / 400000000)) (t := ((-55276137 : ℝ) / 744723863))
    (lo := ((-2974417 : ℝ) / 20000000)) (hi := ((-3718021 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((344723863 : ℝ) / 100000000) = Real.log ((344723863 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((344723863 : ℝ) / 100000000) = ((344723863 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2310 : RB (Real.log ((28166809 : ℝ) / 20000000)) ((17120601 : ℝ) / 50000000) ((8560301 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((28166809 : ℝ) / 40000000)) (t := ((-11833191 : ℝ) / 68166809))
    (lo := ((-8768379 : ℝ) / 25000000)) (hi := ((-7014703 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28166809 : ℝ) / 20000000) = Real.log ((28166809 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((28166809 : ℝ) / 20000000) = ((28166809 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2311 : RB (Real.log ((343291821 : ℝ) / 100000000)) ((30835267 : ℝ) / 25000000) ((123341071 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((343291821 : ℝ) / 400000000)) (t := ((-56708179 : ℝ) / 743291821))
    (lo := ((-955523 : ℝ) / 6250000)) (hi := ((-15288367 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((343291821 : ℝ) / 100000000) = Real.log ((343291821 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((343291821 : ℝ) / 100000000) = ((343291821 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2312 : RB (Real.log ((21455739 : ℝ) / 6250000)) ((123341069 : ℝ) / 100000000) ((7708817 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((21455739 : ℝ) / 25000000)) (t := ((-3544261 : ℝ) / 46455739))
    (lo := ((-15288367 : ℝ) / 100000000)) (hi := ((-7644183 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21455739 : ℝ) / 6250000) = Real.log ((21455739 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((21455739 : ℝ) / 6250000) = ((21455739 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2313 : RB (Real.log ((70537199 : ℝ) / 50000000)) ((34411721 : ℝ) / 100000000) ((34411723 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70537199 : ℝ) / 100000000)) (t := ((-29462801 : ℝ) / 170537199))
    (lo := ((-34902997 : ℝ) / 100000000)) (hi := ((-8725749 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70537199 : ℝ) / 50000000) = Real.log ((70537199 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((70537199 : ℝ) / 50000000) = ((70537199 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2314 : RB (Real.log ((40389361 : ℝ) / 50000000)) ((-1067283 : ℝ) / 5000000) ((-21345659 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40389361 : ℝ) / 50000000)) (t := ((-9610639 : ℝ) / 90389361))
    (lo := ((-1067283 : ℝ) / 5000000)) (hi := ((-21345659 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2315 : RB (Real.log ((256811 : ℝ) / 312500)) ((-19626407 : ℝ) / 100000000) ((-9813203 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((256811 : ℝ) / 312500)) (t := ((-55689 : ℝ) / 569311))
    (lo := ((-19626407 : ℝ) / 100000000)) (hi := ((-9813203 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2316 : RB (Real.log ((41449627 : ℝ) / 50000000)) ((-18754413 : ℝ) / 100000000) ((-4688603 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((41449627 : ℝ) / 50000000)) (t := ((-8550373 : ℝ) / 91449627))
    (lo := ((-18754413 : ℝ) / 100000000)) (hi := ((-4688603 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2317 : RB (Real.log ((82899257 : ℝ) / 100000000)) ((-18754409 : ℝ) / 100000000) ((-2344301 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((82899257 : ℝ) / 100000000)) (t := ((-17100743 : ℝ) / 182899257))
    (lo := ((-18754409 : ℝ) / 100000000)) (hi := ((-2344301 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2318 : RB (Real.log ((708797 : ℝ) / 1562500)) ((-79047323 : ℝ) / 100000000) ((-79047321 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((708797 : ℝ) / 781250)) (t := ((-72453 : ℝ) / 1490047))
    (lo := ((-2433151 : ℝ) / 25000000)) (hi := ((-9732603 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((708797 : ℝ) / 1562500) = Real.log ((708797 : ℝ) / 781250) - 1 * Real.log 2 := by
    rw [show ((708797 : ℝ) / 1562500) = ((708797 : ℝ) / 781250) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2319 : RB (Real.log ((83144569 : ℝ) / 100000000)) ((-1845893 : ℝ) / 10000000) ((-18458929 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83144569 : ℝ) / 100000000)) (t := ((-16855431 : ℝ) / 183144569))
    (lo := ((-1845893 : ℝ) / 10000000)) (hi := ((-18458929 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
