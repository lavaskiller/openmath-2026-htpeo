import LeanProject.AngleCDF
import LeanProject.ResidualQuantile

/-!
# Actual finite quantiles in the reference angle coordinate

Every occurrence of a residual root keeps its own mass cell. Repeated roots give
zero jumps, so no distinctness assumption is needed. The choice at a mass-cell
boundary is the same as in `AtomicQuantile.step`.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset

namespace EP1038.AtomicQuantile

theorem cut_strictMono {n : ℕ} (hn : 0 < n) : StrictMono (cut n) := by
  intro i j hij
  exact div_lt_div_of_pos_right (by exact_mod_cast hij) (by exact_mod_cast hn)

noncomputable def entry {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) (j : ℕ) : ℝ :=
  if hj : j < n then d ⟨j, hj⟩ else d ⟨n - 1, by omega⟩

theorem entry_eq {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) {j : ℕ} (hj : j < n) :
    entry hn d j = d ⟨j, hj⟩ := by rw [entry, dif_pos hj]

theorem threshold_on_cell {n : ℕ} (hn : 0 < n) {j : Fin n} {u : ℝ}
    (hu : u ∈ cell n j) (i : ℕ) : cut n (i + 1) < u ↔ i < j.1 := by
  constructor
  · intro h
    by_contra hi
    have hc := cut_mono hn (show j.1 + 1 ≤ i + 1 by omega)
    linarith [hu.2]
  · intro hi
    exact lt_of_le_of_lt (cut_mono hn (show i + 1 ≤ j.1 by omega)) hu.1

/-- Telescoping representation of the actual left-continuous empirical quantile. -/
theorem step_expansion {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) {u : ℝ}
    (hu : u ∈ Icc (0 : ℝ) 1) :
    step hn d u = entry hn d 0 + ∑ i ∈ range (n - 1),
      (entry hn d (i + 1) - entry hn d i) * (if cut n (i + 1) < u then 1 else 0) := by
  by_cases hu0 : u = 0
  · subst u
    have hcut : ∀ i, ¬cut n (i + 1) < 0 := by
      intro i
      have h := cut_mono hn (Nat.zero_le (i + 1))
      rw [cut_zero] at h
      exact not_lt_of_ge h
    simp [step, entry_eq hn d hn, hcut]
  obtain ⟨j, hj⟩ := cell_cover hn ⟨lt_of_le_of_ne hu.1 (Ne.symm hu0), hu.2⟩
  rw [step_on_cell hn d hj]
  have hterm : ∀ i, (entry hn d (i + 1) - entry hn d i) *
      (if cut n (i + 1) < u then 1 else 0) =
        if i < j.1 then entry hn d (i + 1) - entry hn d i else 0 := by
    intro i
    simp only [threshold_on_cell hn hj]
    split_ifs <;> simp
  simp_rw [hterm]
  have hsum : (∑ i ∈ range (n - 1),
      if i < j.1 then entry hn d (i + 1) - entry hn d i else 0) =
        ∑ i ∈ range j.1, (entry hn d (i + 1) - entry hn d i) := by
    calc
      _ = ∑ i ∈ range j.1, if i < j.1 then entry hn d (i + 1) - entry hn d i else 0 := by
        symm
        apply sum_subset (range_mono (show j.1 ≤ n - 1 by omega))
        intro i _ hi
        simp only [Finset.mem_range, not_lt] at hi
        simp only [if_neg (not_lt.mpr hi)]
      _ = _ := by
        apply sum_congr rfl
        intro i hi
        simp only [if_pos (mem_range.mp hi)]
  rw [hsum, Finset.sum_range_sub, entry_eq hn d j.isLt]
  ring

theorem sum_jumps {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) :
    entry hn d 0 + (∑ i ∈ range (n - 1), (entry hn d (i + 1) - entry hn d i)) =
      d ⟨n - 1, by omega⟩ := by
  rw [Finset.sum_range_sub, entry_eq hn d (show n - 1 < n by omega)]
  ring

theorem jump_nonneg {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) (hd : Monotone d)
    {i : ℕ} (hi : i ∈ range (n - 1)) : 0 ≤ entry hn d (i + 1) - entry hn d i := by
  have hi' := mem_range.mp hi
  rw [entry_eq hn d (show i + 1 < n by omega), entry_eq hn d (show i < n by omega)]
  exact sub_nonneg.mpr (hd (by change i ≤ i + 1; omega))

end EP1038.AtomicQuantile

namespace EP1038.Stage11
open EP1038.Arc EP1038.AtomicQuantile

noncomputable def foldedAngle (θ : ℝ) : ℝ := arccos (cos θ)

theorem foldedAngle_mem (θ : ℝ) : foldedAngle θ ∈ Icc (0 : ℝ) π :=
  ⟨Real.arccos_nonneg _, Real.arccos_le_pi _⟩

theorem cos_foldedAngle (θ : ℝ) : cos (foldedAngle θ) = cos θ :=
  Real.cos_arccos (Real.neg_one_le_cos θ) (Real.cos_le_one θ)

theorem foldedAngle_eq {θ : ℝ} (hθ : θ ∈ Icc (0 : ℝ) π) : foldedAngle θ = θ :=
  Real.arccos_cos hθ.1 hθ.2

namespace AngleReference

noncomputable def angularTarget (A : AngleReference) (T : ℝ → ℝ) (θ : ℝ) : ℝ :=
  T (A.cdf (foldedAngle θ))

noncomputable def angularVelocity (A : AngleReference) (c r : ℝ) (T : ℝ → ℝ) (θ : ℝ) : ℝ :=
  alpha A.k A.ρ θ * (A.angularTarget T θ - position c r θ)

noncomputable def threshold (A : AngleReference) (n i : ℕ) : ℝ :=
  cos (A.inverse (cut n (i + 1)))

theorem cut_interior {n : ℕ} (hn : 0 < n) {i : ℕ} (hi : i ∈ range (n - 1)) :
    cut n (i + 1) ∈ Ioo (0 : ℝ) 1 := by
  have hi' := mem_range.mp hi
  have h0 := cut_strictMono hn (show 0 < i + 1 by omega)
  have h1 := cut_strictMono hn (show i + 1 < n by omega)
  constructor
  · simpa only [cut_zero] using h0
  · simpa only [cut_end hn] using h1

theorem threshold_interior (A : AngleReference) {n : ℕ} (hn : 0 < n) {i : ℕ}
    (hi : i ∈ range (n - 1)) : A.threshold n i ∈ Ioo (-1 : ℝ) 1 := by
  have ht := A.inverse_interior (cut_interior hn hi)
  change -1 < cos (A.inverse (cut n (i + 1))) ∧ cos (A.inverse (cut n (i + 1))) < 1
  constructor
  · simpa only [Real.cos_pi] using
      Real.cos_lt_cos_of_nonneg_of_le_pi ht.1.le le_rfl ht.2
  · simpa only [Real.cos_zero] using
      Real.cos_lt_cos_of_nonneg_of_le_pi le_rfl ht.2.le ht.1

theorem cdf_lt_iff_cos (A : AngleReference) {u θ : ℝ} (hu : u ∈ Icc (0 : ℝ) 1)
    (hθ : θ ∈ Icc (0 : ℝ) π) : u < A.cdf θ ↔ cos θ < cos (A.inverse u) := by
  have hi := A.inverse_mem u
  have hcu := A.cdf_inverse hu
  constructor
  · intro h
    have ht : A.inverse u < θ := by
      by_contra hh
      have hh' := A.cdf_strictMonoOn.monotoneOn hθ hi (le_of_not_gt hh)
      rw [hcu] at hh'
      linarith
    exact Real.cos_lt_cos_of_nonneg_of_le_pi hi.1 hθ.2 ht
  · intro h
    have ht : A.inverse u < θ := by
      by_contra hh
      have hh' := Real.cos_le_cos_of_nonneg_of_le_pi hθ.1 hi.2 (le_of_not_gt hh)
      linarith
    simpa only [hcu] using A.cdf_strictMonoOn hi hθ ht

/-- The angular target is the already constructed quantile, with all repeated atoms retained. -/
theorem angularTarget_step (A : AngleReference) {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ) :
    A.angularTarget (step hn d) = stepPosition (range (n - 1)) (entry hn d 0)
      (fun i => entry hn d (i + 1) - entry hn d i) (A.threshold n) := by
  funext θ
  rw [angularTarget, step_expansion hn d (A.cdf_mem (foldedAngle_mem θ))]
  dsimp [stepPosition]
  congr 1
  apply Finset.sum_congr rfl
  intro i hi
  have hu := cut_interior hn hi
  simp only [A.cdf_lt_iff_cos ⟨hu.1.le, hu.2.le⟩ (foldedAngle_mem θ), cos_foldedAngle,
    jump, threshold]
  rfl

theorem angularVelocity_step (A : AngleReference) {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ)
    (c r : ℝ) : A.angularVelocity c r (step hn d) =
      atomicVelocity (range (n - 1)) A.k A.ρ c r (entry hn d 0)
        (fun i => entry hn d (i + 1) - entry hn d i) (A.threshold n) := by
  funext θ
  simp only [angularVelocity, A.angularTarget_step hn d, atomicVelocity, position]

/-- The adjoint bound now applies to a genuine empirical quantile. -/
theorem step_adjoint_bound (A : AngleReference) {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ)
    (hd : Monotone d) {c r ρ1 ρ2 σ1 σ2 : ℝ} (hr : 0 < r)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) (hend : d ⟨n - 1, by omega⟩ ≤ c + r) :
    AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (A.angularVelocity c r (step hn d)) ∧
      adjointIntegral r ρ1 ρ2 σ1 σ2 (A.angularVelocity c r (step hn d)) ≤
        widthVariation r ρ1 ρ2 σ1 σ2 (A.angularVelocity c r (step hn d)) := by
  rw [A.angularVelocity_step hn d c r]
  have hΔ := fun i hi => jump_nonneg hn d hd (i := i) hi
  have hz := fun i hi => A.threshold_interior hn (i := i) hi
  have he : entry hn d 0 + ∑ i ∈ range (n - 1), (entry hn d (i + 1) - entry hn d i) ≤ c + r := by
    rwa [sum_jumps hn d]
  have h := atomicVelocity_adjoint (range (n - 1))
    (fun i => entry hn d (i + 1) - entry hn d i) (A.threshold n) A.k_pos.le A.rho_pos.le
    A.rho_lt_one A.density_zero_nonneg hr h10 h11 h20 h21 hs1 hs2 hΔ hz he
  refine ⟨h.1, ?_⟩
  linarith [h.2.2.1, h.2.2.2]

end AngleReference

/-- The preceding angle construction is instantiated with the actual sorted residual roots. -/
theorem residual_quantile_adjoint {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (A : AngleReference) {c r ρ1 ρ2 σ1 σ2 : ℝ}
    (hr : 0 < r) (hpos : c + r = 2)
    (h10 : 0 < ρ1) (h11 : ρ1 < 1) (h20 : 0 < ρ2) (h21 : ρ2 < 1)
    (hs1 : 0 ≤ σ1) (hs2 : 0 ≤ σ2) :
    AdjointIntegrable ρ1 ρ2 (Bxi ρ1 ρ2 σ1 σ2) (A.angularVelocity c r (a.residualQuantile hres)) ∧
      adjointIntegral r ρ1 ρ2 σ1 σ2 (A.angularVelocity c r (a.residualQuantile hres)) ≤
        widthVariation r ρ1 ρ2 σ1 σ2 (A.angularVelocity c r (a.residualQuantile hres)) := by
  apply A.step_adjoint_bound (EP1038.NormalForm.sorted_length_pos a hres) a.orderedAtoms
    (EP1038.NormalForm.orderedAtoms_monotone a) hr h10 h11 h20 h21 hs1 hs2
  rw [hpos]
  exact (EP1038.NormalForm.orderedAtoms_bounds a _).2

end EP1038.Stage11
