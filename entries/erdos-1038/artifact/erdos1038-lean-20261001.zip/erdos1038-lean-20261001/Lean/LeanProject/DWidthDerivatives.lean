import LeanProject.DImplicitDerivatives

/-! The C² volume width and its actual first/second derivatives equal the replay formulas. -/
open Real Set Filter Topology
open scoped ContDiff
namespace EP1038.DLowerCert
open EP1038.Stage9

noncomputable def psi1 (q v : ℝ) : ℝ :=
  (1 - q ^ 2 / v ^ 2) * rootSlope q v + 2 * q / v
noncomputable def psi2 (q v : ℝ) : ℝ :=
  2 * q ^ 2 / v ^ 3 * (rootSlope q v) ^ 2 - 4 * q / v ^ 2 * rootSlope q v +
    2 / v + (1 - q ^ 2 / v ^ 2) * rootCurvature q v
noncomputable def d01 (q : ℝ) : ℝ := -4 / (1 + q) ^ 3
noncomputable def d02 (q : ℝ) : ℝ := 12 / (1 + q) ^ 4
noncomputable def lam1 (q : ℝ) : ℝ :=
  d01 q * (phi q (vMinus q) - phi q (vPlus q)) +
    D0q q * (psi1 q (vMinus q) - psi1 q (vPlus q))
noncomputable def lam2 (q : ℝ) : ℝ :=
  d02 q * (phi q (vMinus q) - phi q (vPlus q)) +
    2 * d01 q * (psi1 q (vMinus q) - psi1 q (vPlus q)) +
    D0q q * (psi2 q (vMinus q) - psi2 q (vPlus q))

theorem hasDerivAt_D0q {q : ℝ} (hq : 0 < q) : HasDerivAt D0q (d01 q) q := by
  have hn : 1 + q ≠ 0 := by linarith
  have h := (hasDerivAt_const q (2 : ℝ)).div (((hasDerivAt_id q).const_add 1).pow 2)
    (pow_ne_zero 2 hn)
  convert h using 1
  · rfl
  · unfold d01
    simp only [id_eq, Pi.pow_apply, Nat.cast_ofNat, Nat.reduceSub, pow_one]
    field_simp [hn]
    <;> ring

theorem hasDerivAt_d01 {q : ℝ} (hq : 0 < q) : HasDerivAt d01 (d02 q) q := by
  have hn : 1 + q ≠ 0 := by linarith
  have h := (hasDerivAt_const q (-4 : ℝ)).div (((hasDerivAt_id q).const_add 1).pow 3)
    (pow_ne_zero 3 hn)
  convert h using 1
  · rfl
  · unfold d02
    simp only [id_eq, Pi.pow_apply, Nat.cast_ofNat, Nat.reduceSub]
    field_simp [hn]
    <;> ring

theorem hasDerivAt_phi_along {q t : ℝ} {r : ℝ → ℝ}
    (hr : HasDerivAt r t q) (hv : r q ≠ 0) :
    HasDerivAt (fun x => phi x (r x)) ((1 - q ^ 2 / (r q) ^ 2) * t + 2 * q / r q) q := by
  have h := hr.add (((hasDerivAt_id q).pow 2).div hr hv)
  convert h using 1
  · rfl
  · simp only [id_eq, Pi.pow_apply, Nat.cast_ofNat, Nat.reduceSub, pow_one, one_mul]
    field_simp [hv]
    <;> ring

theorem hasDerivAt_phi_slope {q t t2 : ℝ} {r : ℝ → ℝ}
    (hr : HasDerivAt r t q) (hr2 : HasDerivAt (deriv r) t2 q) (hv : r q ≠ 0) :
    HasDerivAt (fun x => (1 - x ^ 2 / (r x) ^ 2) * deriv r x + 2 * x / r x)
      (2 * q ^ 2 / (r q) ^ 3 * t ^ 2 - 4 * q / (r q) ^ 2 * t +
        2 / r q + (1 - q ^ 2 / (r q) ^ 2) * t2) q := by
  have h := ((((hasDerivAt_id q).pow 2).div (hr.pow 2) (pow_ne_zero 2 hv)).const_sub 1).mul hr2 |>.add
    (((hasDerivAt_id q).const_mul 2).div hr hv)
  convert h using 1
  · rfl
  · simp only [id_eq, Pi.mul_apply, Pi.div_apply, Pi.pow_apply, Nat.cast_ofNat,
      Nat.reduceSub, pow_one, hr.deriv]
    field_simp [hv]
    <;> ring

theorem actual_phi_hasSecondDerivAt {q : ℝ} {r : ℝ → ℝ} (hq : q ∈ Qadm)
    (hr : ∀ x ∈ Qadm, HasDerivAt r (rootSlope x (r x)) x)
    (hr2 : HasDerivAt (deriv r) (rootCurvature q (r q)) q)
    (hv : ∀ x ∈ Qadm, r x ≠ 0) :
    HasDerivAt (deriv (fun x => phi x (r x))) (psi2 q (r q)) q := by
  have h := hasDerivAt_phi_slope (hr q hq) hr2 (hv q hq)
  have he : deriv (fun x => phi x (r x)) =ᶠ[𝓝 q]
      fun x => (1 - x ^ 2 / (r x) ^ 2) * deriv r x + 2 * x / r x := by
    filter_upwards [Qadm_mem_nhds hq] with x hxa
    rw [(hasDerivAt_phi_along (hr x hxa) (hv x hxa)).deriv, (hr x hxa).deriv]
  exact h.congr_of_eventuallyEq he

theorem phiPlus_hasDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt (fun x => phi x (vPlus x)) (psi1 q (vPlus q)) q :=
  hasDerivAt_phi_along (vPlus_hasDerivAt hq) (vPlus_denominators hq).2.2

theorem phiMinus_hasDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt (fun x => phi x (vMinus x)) (psi1 q (vMinus q)) q :=
  hasDerivAt_phi_along (vMinus_hasDerivAt hq) (vMinus_denominators hq).2.2

theorem phiPlus_hasSecondDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt (deriv (fun x => phi x (vPlus x))) (psi2 q (vPlus q)) q :=
  actual_phi_hasSecondDerivAt hq (fun _ hx => vPlus_hasDerivAt hx)
    (vPlus_hasSecondDerivAt hq) (fun _ hx => (vPlus_denominators hx).2.2)

theorem phiMinus_hasSecondDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt (deriv (fun x => phi x (vMinus x))) (psi2 q (vMinus q)) q :=
  actual_phi_hasSecondDerivAt hq (fun _ hx => vMinus_hasDerivAt hx)
    (vMinus_hasSecondDerivAt hq) (fun _ hx => (vMinus_denominators hx).2.2)

theorem Lam_contDiffAt {q : ℝ} (hq : q ∈ Qadm) : ContDiffAt ℝ ∞ Lam q := by
  have hp := vPlus_contDiffAt hq
  have hm := vMinus_contDiffAt hq
  have hpn := (vPlus_denominators hq).2.2
  have hmn := (vMinus_denominators hq).2.2
  have h1 : 1 + q ≠ 0 := by linarith [hq.1]
  have hw : ContDiffAt ℝ ∞ (fun x => D0q x * (phi x (vMinus x) - phi x (vPlus x))) q := by
    unfold D0q phi
    fun_prop (disch := first | assumption | exact pow_ne_zero 2 h1)
  apply hw.congr_of_eventuallyEq
  filter_upwards [Qadm_mem_nhds hq] with x hx
  exact Lam_eq_actual_roots hx

theorem Lam_hasDerivAt {q : ℝ} (hq : q ∈ Qadm) : HasDerivAt Lam (lam1 q) q := by
  have hw := (hasDerivAt_D0q hq.1).mul ((phiMinus_hasDerivAt hq).sub (phiPlus_hasDerivAt hq))
  apply hw.congr_of_eventuallyEq
  filter_upwards [Qadm_mem_nhds hq] with x hx
  exact Lam_eq_actual_roots hx

theorem Lam_hasSecondDerivAt {q : ℝ} (hq : q ∈ Qadm) :
    HasDerivAt (deriv Lam) (lam2 q) q := by
  have h0 := (phiMinus_hasDerivAt hq).sub (phiPlus_hasDerivAt hq)
  have h1 := (phiMinus_hasSecondDerivAt hq).sub (phiPlus_hasSecondDerivAt hq)
  have h := ((hasDerivAt_d01 hq.1).mul h0).add ((hasDerivAt_D0q hq.1).mul h1)
  have he : deriv Lam =ᶠ[𝓝 q] fun x =>
      d01 x * (phi x (vMinus x) - phi x (vPlus x)) +
        D0q x * (deriv (fun y => phi y (vMinus y)) x - deriv (fun y => phi y (vPlus y)) x) := by
    filter_upwards [Qadm_mem_nhds hq] with x hx
    rw [(Lam_hasDerivAt hx).deriv, (phiMinus_hasDerivAt hx).deriv, (phiPlus_hasDerivAt hx).deriv]
    rfl
  convert h.congr_of_eventuallyEq he using 1
  unfold lam2
  simp only [Pi.sub_apply, (phiMinus_hasDerivAt hq).deriv, (phiPlus_hasDerivAt hq).deriv]
  ring

/-- Numbered obligation 3: actual C² roots/width, nonzero denominators, both derivative formulas. -/
theorem actual_central_root_calculus {q : ℝ} (hq : q ∈ MRegion) :
    ContDiffAt ℝ 2 vPlus q ∧ ContDiffAt ℝ 2 vMinus q ∧ ContDiffAt ℝ 2 Lam q ∧
    Ev q (vPlus q) ≠ 0 ∧ Ev q (vMinus q) ≠ 0 ∧
    deriv vPlus q = rootSlope q (vPlus q) ∧ deriv vMinus q = rootSlope q (vMinus q) ∧
    deriv (deriv vPlus) q = rootCurvature q (vPlus q) ∧
    deriv (deriv vMinus) q = rootCurvature q (vMinus q) ∧
    deriv Lam q = lam1 q ∧ deriv (deriv Lam) q = lam2 q := by
  have ha := MRegion_admissible hq
  exact ⟨(vPlus_contDiffAt ha).of_le (by simp), (vMinus_contDiffAt ha).of_le (by simp),
    (Lam_contDiffAt ha).of_le (by simp), (Ev_vPlus_pos ha).ne', (Ev_vMinus_neg ha).ne,
    (vPlus_hasDerivAt ha).deriv, (vMinus_hasDerivAt ha).deriv,
    (vPlus_hasSecondDerivAt ha).deriv, (vMinus_hasSecondDerivAt ha).deriv,
    (Lam_hasDerivAt ha).deriv, (Lam_hasSecondDerivAt ha).deriv⟩

end EP1038.DLowerCert
