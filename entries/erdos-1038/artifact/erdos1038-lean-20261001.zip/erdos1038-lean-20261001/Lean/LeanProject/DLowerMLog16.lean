import LeanProject.DLowerMTools
import LeanProject.DLowerMLog13
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_640 : RB (Real.log ((142707248306067 : ℝ) / 100000000000000)) ((44453141402576687 : ℝ) / 125000000000000000) ((177812565610306749 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((142707248306067 : ℝ) / 200000000000000)) (t := ((-57292751693933 : ℝ) / 342707248306067))
    (lo := ((-337522049339331813 : ℝ) / 1000000000000000000)) (hi := ((-84380512334832953 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142707248306067 : ℝ) / 100000000000000) = Real.log ((142707248306067 : ℝ) / 200000000000000) + 1 * Real.log 2 := by
    rw [show ((142707248306067 : ℝ) / 100000000000000) = ((142707248306067 : ℝ) / 200000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_641 : RB (Real.log ((1427072483060673001 : ℝ) / 1000000000000000000)) ((355625131220615599 : ℝ) / 1000000000000000000) ((355625131220615601 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1427072483060673001 : ℝ) / 2000000000000000000)) (t := ((-572927516939326999 : ℝ) / 3427072483060673001))
    (lo := ((-33752204933932971 : ℝ) / 100000000000000000)) (hi := ((-337522049339329709 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1427072483060673001 : ℝ) / 1000000000000000000) = Real.log ((1427072483060673001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1427072483060673001 : ℝ) / 1000000000000000000) = ((1427072483060673001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_642 : RB (Real.log ((42847873306067 : ℝ) / 100000000000000)) ((-211878543326564897 : ℝ) / 250000000000000000) ((-423757086653129793 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((42847873306067 : ℝ) / 50000000000000)) (t := ((-7152126693933 : ℝ) / 92847873306067))
    (lo := ((-77183496373157139 : ℝ) / 500000000000000000)) (hi := ((-154366992746314277 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42847873306067 : ℝ) / 100000000000000) = Real.log ((42847873306067 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((42847873306067 : ℝ) / 100000000000000) = ((42847873306067 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_643 : RB (Real.log ((428478733060673 : ℝ) / 1000000000000000)) ((-847514173306252587 : ℝ) / 1000000000000000000) ((-169502834661250517 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((428478733060673 : ℝ) / 500000000000000)) (t := ((-71521266939327 : ℝ) / 928478733060673))
    (lo := ((-154366992746307277 : ℝ) / 1000000000000000000)) (hi := ((-38591748186576819 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((428478733060673 : ℝ) / 1000000000000000) = Real.log ((428478733060673 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((428478733060673 : ℝ) / 1000000000000000) = ((428478733060673 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_644 : RB (Real.log ((142847873306067 : ℝ) / 100000000000000)) ((356610054975958169 : ℝ) / 1000000000000000000) ((356610054975958171 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((142847873306067 : ℝ) / 200000000000000)) (t := ((-57152126693933 : ℝ) / 342847873306067))
    (lo := ((-16826856279199357 : ℝ) / 50000000000000000)) (hi := ((-336537125583987139 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((142847873306067 : ℝ) / 100000000000000) = Real.log ((142847873306067 : ℝ) / 200000000000000) + 1 * Real.log 2 := by
    rw [show ((142847873306067 : ℝ) / 100000000000000) = ((142847873306067 : ℝ) / 200000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_645 : RB (Real.log ((1428478733060673 : ℝ) / 1000000000000000)) ((356610054975960269 : ℝ) / 1000000000000000000) ((356610054975960271 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1428478733060673 : ℝ) / 2000000000000000)) (t := ((-571521266939327 : ℝ) / 3428478733060673))
    (lo := ((-4206714069799813 : ℝ) / 12500000000000000)) (hi := ((-336537125583985039 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1428478733060673 : ℝ) / 1000000000000000) = Real.log ((1428478733060673 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1428478733060673 : ℝ) / 1000000000000000) = ((1428478733060673 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_646 : RB (Real.log ((1427072483060670001 : ℝ) / 1000000000000000000)) ((355625131220613497 : ℝ) / 1000000000000000000) ((355625131220613499 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1427072483060670001 : ℝ) / 2000000000000000000)) (t := ((-572927516939329999 : ℝ) / 3427072483060670001))
    (lo := ((-84380512334832953 : ℝ) / 250000000000000000)) (hi := ((-337522049339331811 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1427072483060670001 : ℝ) / 1000000000000000000) = Real.log ((1427072483060670001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1427072483060670001 : ℝ) / 1000000000000000000) = ((1427072483060670001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_647 : RB (Real.log ((1427072483060673 : ℝ) / 1000000000000000)) ((177812565610307799 : ℝ) / 500000000000000000) ((889062828051539 : ℝ) / 2500000000000000) := by
  have hm := log_bounds_of_series (x := ((1427072483060673 : ℝ) / 2000000000000000)) (t := ((-572927516939327 : ℝ) / 3427072483060673))
    (lo := ((-337522049339329711 : ℝ) / 1000000000000000000)) (hi := ((-33752204933932971 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1427072483060673 : ℝ) / 1000000000000000) = Real.log ((1427072483060673 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1427072483060673 : ℝ) / 1000000000000000) = ((1427072483060673 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_648 : RB (Real.log ((53625556371276643 : ℝ) / 125000000000000000)) ((-105785998110750033 : ℝ) / 125000000000000000) ((-423143992443000131 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((53625556371276643 : ℝ) / 62500000000000000)) (t := ((-8874443628723357 : ℝ) / 116125556371276643))
    (lo := ((-76570402163027477 : ℝ) / 500000000000000000)) (hi := ((-153140804326054953 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53625556371276643 : ℝ) / 125000000000000000) = Real.log ((53625556371276643 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((53625556371276643 : ℝ) / 125000000000000000) = ((53625556371276643 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_649 : RB (Real.log ((88377688824306353 : ℝ) / 200000000000000000)) ((-408348908812590713 : ℝ) / 500000000000000000) ((-51043613601573839 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((88377688824306353 : ℝ) / 100000000000000000)) (t := ((-11622311175693647 : ℝ) / 188377688824306353))
    (lo := ((-30887659266309029 : ℝ) / 250000000000000000)) (hi := ((-24710127413047223 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((88377688824306353 : ℝ) / 200000000000000000) = Real.log ((88377688824306353 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((88377688824306353 : ℝ) / 200000000000000000) = ((88377688824306353 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_650 : RB (Real.log ((139221638969617059 : ℝ) / 250000000000000000)) ((-585393729675455823 : ℝ) / 1000000000000000000) ((-585393729675455821 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((139221638969617059 : ℝ) / 125000000000000000)) (t := ((14221638969617059 : ℝ) / 264221638969617059))
    (lo := ((107753450884489487 : ℝ) / 1000000000000000000)) (hi := ((6734590680280593 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((139221638969617059 : ℝ) / 250000000000000000) = Real.log ((139221638969617059 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((139221638969617059 : ℝ) / 250000000000000000) = ((139221638969617059 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_651 : RB (Real.log ((71174443628723357 : ℝ) / 125000000000000000)) ((-140794980279197727 : ℝ) / 250000000000000000) ((-281589960558395453 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((71174443628723357 : ℝ) / 62500000000000000)) (t := ((8674443628723357 : ℝ) / 133674443628723357))
    (lo := ((64983629721577201 : ℝ) / 500000000000000000)) (hi := ((129967259443154403 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71174443628723357 : ℝ) / 125000000000000000) = Real.log ((71174443628723357 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((71174443628723357 : ℝ) / 125000000000000000) = ((71174443628723357 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_652 : RB (Real.log ((53825556371276643 : ℝ) / 125000000000000000)) ((-842565357435039291 : ℝ) / 1000000000000000000) ((-842565357435039289 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((53825556371276643 : ℝ) / 62500000000000000)) (t := ((-8674443628723357 : ℝ) / 116325556371276643))
    (lo := ((-149418176875093981 : ℝ) / 1000000000000000000)) (hi := ((-7470908843754699 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53825556371276643 : ℝ) / 125000000000000000) = Real.log ((53825556371276643 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((53825556371276643 : ℝ) / 125000000000000000) = ((53825556371276643 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_653 : RB (Real.log ((110778361030382941 : ℝ) / 250000000000000000)) ((-406964730090917743 : ℝ) / 500000000000000000) ((-203482365045458871 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((110778361030382941 : ℝ) / 125000000000000000)) (t := ((-14221638969617059 : ℝ) / 235778361030382941))
    (lo := ((-943611559546017 : ℝ) / 7812500000000000)) (hi := ((-4831291184875607 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((110778361030382941 : ℝ) / 250000000000000000) = Real.log ((110778361030382941 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((110778361030382941 : ℝ) / 250000000000000000) = ((110778361030382941 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_654 : RB (Real.log ((53649775121276643 : ℝ) / 125000000000000000)) ((-845836459822884567 : ℝ) / 1000000000000000000) ((-169167291964576913 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((53649775121276643 : ℝ) / 62500000000000000)) (t := ((-8850224878723357 : ℝ) / 116149775121276643))
    (lo := ((-152689279262939257 : ℝ) / 1000000000000000000)) (hi := ((-19086159907867407 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53649775121276643 : ℝ) / 125000000000000000) = Real.log ((53649775121276643 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((53649775121276643 : ℝ) / 125000000000000000) = ((53649775121276643 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_655 : RB (Real.log ((85839640194042629 : ℝ) / 200000000000000000)) ((-211459114955721141 : ℝ) / 250000000000000000) ((-422918229911442281 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((85839640194042629 : ℝ) / 100000000000000000)) (t := ((-14160359805957371 : ℝ) / 185839640194042629))
    (lo := ((-76344639631469627 : ℝ) / 500000000000000000)) (hi := ((-152689279262939253 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85839640194042629 : ℝ) / 200000000000000000) = Real.log ((85839640194042629 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((85839640194042629 : ℝ) / 200000000000000000) = ((85839640194042629 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_656 : RB (Real.log ((85875890194042629 : ℝ) / 200000000000000000)) ((-845414249898638683 : ℝ) / 1000000000000000000) ((-845414249898638681 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((85875890194042629 : ℝ) / 100000000000000000)) (t := ((-14124109805957371 : ℝ) / 185875890194042629))
    (lo := ((-152267069338693373 : ℝ) / 1000000000000000000)) (hi := ((-38066767334673343 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85875890194042629 : ℝ) / 200000000000000000) = Real.log ((85875890194042629 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((85875890194042629 : ℝ) / 200000000000000000) = ((85875890194042629 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_657 : RB (Real.log ((110426798530382941 : ℝ) / 250000000000000000)) ((-817108073164474431 : ℝ) / 1000000000000000000) ((-817108073164474429 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((110426798530382941 : ℝ) / 125000000000000000)) (t := ((-14573201469617059 : ℝ) / 235426798530382941))
    (lo := ((-123960892604529121 : ℝ) / 1000000000000000000)) (hi := ((-774755578778307 : ℝ) / 6250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((110426798530382941 : ℝ) / 250000000000000000) = Real.log ((110426798530382941 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((110426798530382941 : ℝ) / 250000000000000000) = ((110426798530382941 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_658 : RB (Real.log ((88341438824306353 : ℝ) / 200000000000000000)) ((-817108073164474429 : ℝ) / 1000000000000000000) ((-817108073164474427 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((88341438824306353 : ℝ) / 100000000000000000)) (t := ((-11658561175693647 : ℝ) / 188341438824306353))
    (lo := ((-123960892604529119 : ℝ) / 1000000000000000000)) (hi := ((-61980446302264559 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((88341438824306353 : ℝ) / 200000000000000000) = Real.log ((88341438824306353 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((88341438824306353 : ℝ) / 200000000000000000) = ((88341438824306353 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_659 : RB (Real.log ((110378361030382941 : ℝ) / 250000000000000000)) ((-817546808390348011 : ℝ) / 1000000000000000000) ((-817546808390348009 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((110378361030382941 : ℝ) / 125000000000000000)) (t := ((-14621638969617059 : ℝ) / 235378361030382941))
    (lo := ((-124399627830402701 : ℝ) / 1000000000000000000)) (hi := ((-1243996278304027 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((110378361030382941 : ℝ) / 250000000000000000) = Real.log ((110378361030382941 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((110378361030382941 : ℝ) / 250000000000000000) = ((110378361030382941 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_660 : RB (Real.log ((284914174695584343 : ℝ) / 200000000000000000)) ((353870626949429247 : ℝ) / 1000000000000000000) ((353870626949429249 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((284914174695584343 : ℝ) / 400000000000000000)) (t := ((-115085825304415657 : ℝ) / 684914174695584343))
    (lo := ((-169638276805258031 : ℝ) / 500000000000000000)) (hi := ((-339276553610516061 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284914174695584343 : ℝ) / 200000000000000000) = Real.log ((284914174695584343 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284914174695584343 : ℝ) / 200000000000000000) = ((284914174695584343 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_661 : RB (Real.log ((1429561592643420757 : ℝ) / 1000000000000000000)) ((44670977336995501 : ℝ) / 125000000000000000) ((35736781869596401 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1429561592643420757 : ℝ) / 2000000000000000000)) (t := ((-570438407356579243 : ℝ) / 3429561592643420757))
    (lo := ((-335779361863981301 : ℝ) / 1000000000000000000)) (hi := ((-3357793618639813 : ℝ) / 10000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1429561592643420757 : ℝ) / 1000000000000000000) = Real.log ((1429561592643420757 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1429561592643420757 : ℝ) / 1000000000000000000) = ((1429561592643420757 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_662 : RB (Real.log ((85234174695584343 : ℝ) / 200000000000000000)) ((-213228725421484713 : ℝ) / 250000000000000000) ((-17058298033718777 : ℝ) / 20000000000000000) := by
  have hm := log_bounds_of_series (x := ((85234174695584343 : ℝ) / 100000000000000000)) (t := ((-14765825304415657 : ℝ) / 185234174695584343))
    (lo := ((-79883860562996771 : ℝ) / 500000000000000000)) (hi := ((-159767721125993541 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85234174695584343 : ℝ) / 200000000000000000) = Real.log ((85234174695584343 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((85234174695584343 : ℝ) / 200000000000000000) = ((85234174695584343 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_663 : RB (Real.log ((107696648160855189 : ℝ) / 250000000000000000)) ((-105267807022729191 : ℝ) / 125000000000000000) ((-421071228090916763 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((107696648160855189 : ℝ) / 125000000000000000)) (t := ((-17303351839144811 : ℝ) / 232696648160855189))
    (lo := ((-74497637810944109 : ℝ) / 500000000000000000)) (hi := ((-148995275621888217 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((107696648160855189 : ℝ) / 250000000000000000) = Real.log ((107696648160855189 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((107696648160855189 : ℝ) / 250000000000000000) = ((107696648160855189 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_664 : RB (Real.log ((285234174695584343 : ℝ) / 200000000000000000)) ((35499314193677517 : ℝ) / 100000000000000000) ((88748285484193793 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((285234174695584343 : ℝ) / 400000000000000000)) (t := ((-114765825304415657 : ℝ) / 685234174695584343))
    (lo := ((-338154038623170139 : ℝ) / 1000000000000000000)) (hi := ((-169077019311585069 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285234174695584343 : ℝ) / 200000000000000000) = Real.log ((285234174695584343 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((285234174695584343 : ℝ) / 200000000000000000) = ((285234174695584343 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_665 : RB (Real.log ((357696648160855189 : ℝ) / 250000000000000000)) ((44778044728405713 : ℝ) / 125000000000000000) ((179112178913622853 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((357696648160855189 : ℝ) / 500000000000000000)) (t := ((-142303351839144811 : ℝ) / 857696648160855189))
    (lo := ((-66984564546539921 : ℝ) / 200000000000000000)) (hi := ((-83730705683174901 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((357696648160855189 : ℝ) / 250000000000000000) = Real.log ((357696648160855189 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((357696648160855189 : ℝ) / 250000000000000000) = ((357696648160855189 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_666 : RB (Real.log ((284952924695584343 : ℝ) / 200000000000000000)) ((177003311785375343 : ℝ) / 500000000000000000) ((11062706986585959 : ℝ) / 31250000000000000) := by
  have hm := log_bounds_of_series (x := ((284952924695584343 : ℝ) / 400000000000000000)) (t := ((-115047075304415657 : ℝ) / 684952924695584343))
    (lo := ((-339140556989194623 : ℝ) / 1000000000000000000)) (hi := ((-169570278494597311 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284952924695584343 : ℝ) / 200000000000000000) = Real.log ((284952924695584343 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284952924695584343 : ℝ) / 200000000000000000) = ((284952924695584343 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_667 : RB (Real.log ((356191155869480429 : ℝ) / 250000000000000000)) ((354006623570750687 : ℝ) / 1000000000000000000) ((354006623570750689 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((356191155869480429 : ℝ) / 500000000000000000)) (t := ((-143808844130519571 : ℝ) / 856191155869480429))
    (lo := ((-169570278494597311 : ℝ) / 500000000000000000)) (hi := ((-339140556989194621 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356191155869480429 : ℝ) / 250000000000000000) = Real.log ((356191155869480429 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356191155869480429 : ℝ) / 250000000000000000) = ((356191155869480429 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_668 : RB (Real.log ((356236468369480429 : ℝ) / 250000000000000000)) ((17706691473747803 : ℝ) / 50000000000000000) ((177066914737478031 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((356236468369480429 : ℝ) / 500000000000000000)) (t := ((-143763531630519571 : ℝ) / 856236468369480429))
    (lo := ((-339013351084989249 : ℝ) / 1000000000000000000)) (hi := ((-5297083610702957 : ℝ) / 15625000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356236468369480429 : ℝ) / 250000000000000000) = Real.log ((356236468369480429 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356236468369480429 : ℝ) / 250000000000000000) = ((356236468369480429 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_669 : RB (Real.log ((357345085660855189 : ℝ) / 250000000000000000)) ((714482047071669 : ℝ) / 2000000000000000) ((178620511767917251 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((357345085660855189 : ℝ) / 500000000000000000)) (t := ((-142654914339144811 : ℝ) / 857345085660855189))
    (lo := ((-335906157024110809 : ℝ) / 1000000000000000000)) (hi := ((-41988269628013851 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((357345085660855189 : ℝ) / 250000000000000000) = Real.log ((357345085660855189 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((357345085660855189 : ℝ) / 250000000000000000) = ((357345085660855189 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_670 : RB (Real.log ((1429380342643420757 : ℝ) / 1000000000000000000)) ((714482047071669 : ℝ) / 2000000000000000) ((178620511767917251 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1429380342643420757 : ℝ) / 2000000000000000000)) (t := ((-570619657356579243 : ℝ) / 3429380342643420757))
    (lo := ((-335906157024110809 : ℝ) / 1000000000000000000)) (hi := ((-41988269628013851 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1429380342643420757 : ℝ) / 1000000000000000000) = Real.log ((1429380342643420757 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1429380342643420757 : ℝ) / 1000000000000000000) = ((1429380342643420757 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_671 : RB (Real.log ((357296648160855189 : ℝ) / 250000000000000000)) ((178552733050579903 : ℝ) / 500000000000000000) ((2789886453915311 : ℝ) / 7812500000000000) := by
  have hm := log_bounds_of_series (x := ((357296648160855189 : ℝ) / 500000000000000000)) (t := ((-142703351839144811 : ℝ) / 857296648160855189))
    (lo := ((-336041714458785503 : ℝ) / 1000000000000000000)) (hi := ((-168020857229392751 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((357296648160855189 : ℝ) / 250000000000000000) = Real.log ((357296648160855189 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((357296648160855189 : ℝ) / 250000000000000000) = ((357296648160855189 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_672 : RB (Real.log ((44999999999999999 : ℝ) / 1000000000000000000)) ((-1550546394605908659 : ℝ) / 500000000000000000) ((-775273197302954329 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((44999999999999999 : ℝ) / 62500000000000000)) (t := ((-17500000000000001 : ℝ) / 107499999999999999))
    (lo := ((-4106300837150451 : ℝ) / 12500000000000000)) (hi := ((-328504066972036079 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44999999999999999 : ℝ) / 1000000000000000000) = Real.log ((44999999999999999 : ℝ) / 62500000000000000) - 4 * Real.log 2 := by
    rw [show ((44999999999999999 : ℝ) / 1000000000000000000) = ((44999999999999999 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_673 : RB (Real.log ((9 : ℝ) / 200)) ((-620218557842363459 : ℝ) / 200000000000000000) ((-3101092789211817293 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((18 : ℝ) / 25)) (t := ((-7 : ℝ) / 43))
    (lo := ((-328504066972036057 : ℝ) / 1000000000000000000)) (hi := ((-41063008371504507 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9 : ℝ) / 200) = Real.log ((18 : ℝ) / 25) - 4 * Real.log 2 := by
    rw [show ((9 : ℝ) / 200) = ((18 : ℝ) / 25) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_674 : RB (Real.log ((1044999999999999999 : ℝ) / 1000000000000000000)) ((1760675416670973 : ℝ) / 40000000000000000) ((22008442708387163 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1044999999999999999 : ℝ) / 1000000000000000000)) (t := ((44999999999999999 : ℝ) / 2044999999999999999))
    (lo := ((1760675416670973 : ℝ) / 40000000000000000)) (hi := ((22008442708387163 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_675 : RB (Real.log ((209 : ℝ) / 200)) ((22008442708387163 : ℝ) / 500000000000000000) ((44016885416774327 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((209 : ℝ) / 200)) (t := ((9 : ℝ) / 409))
    (lo := ((22008442708387163 : ℝ) / 500000000000000000)) (hi := ((44016885416774327 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_676 : RB (Real.log ((39999999999999999 : ℝ) / 1000000000000000000)) ((-402359478108525097 : ℝ) / 125000000000000000) ((-1609437912434100387 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((39999999999999999 : ℝ) / 31250000000000000)) (t := ((8749999999999999 : ℝ) / 71249999999999999))
    (lo := ((61715019482881443 : ℝ) / 250000000000000000)) (hi := ((246860077931525773 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39999999999999999 : ℝ) / 1000000000000000000) = Real.log ((39999999999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((39999999999999999 : ℝ) / 1000000000000000000) = ((39999999999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_677 : RB (Real.log ((50000000000000001 : ℝ) / 1000000000000000000)) ((-1497866136776995487 : ℝ) / 500000000000000000) ((-748933068388497743 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((50000000000000001 : ℝ) / 62500000000000000)) (t := ((-12499999999999999 : ℝ) / 112500000000000001))
    (lo := ((-27892943914276217 : ℝ) / 125000000000000000)) (hi := ((-44628710262841947 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((50000000000000001 : ℝ) / 1000000000000000000) = Real.log ((50000000000000001 : ℝ) / 62500000000000000) - 4 * Real.log 2 := by
    rw [show ((50000000000000001 : ℝ) / 1000000000000000000) = ((50000000000000001 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_678 : RB (Real.log ((1039999999999999999 : ℝ) / 1000000000000000000)) ((7844142630656259 : ℝ) / 200000000000000000) ((2451294572080081 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((1039999999999999999 : ℝ) / 1000000000000000000)) (t := ((39999999999999999 : ℝ) / 2039999999999999999))
    (lo := ((7844142630656259 : ℝ) / 200000000000000000)) (hi := ((2451294572080081 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_679 : RB (Real.log ((1050000000000000001 : ℝ) / 1000000000000000000)) ((12197541042358001 : ℝ) / 250000000000000000) ((9758032833886401 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1050000000000000001 : ℝ) / 1000000000000000000)) (t := ((50000000000000001 : ℝ) / 2050000000000000001))
    (lo := ((12197541042358001 : ℝ) / 250000000000000000)) (hi := ((9758032833886401 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
