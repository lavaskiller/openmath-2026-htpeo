import LeanProject.COVLogTwo
import LeanProject.COVLogBounds07
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_880 : RB (Real.log ((553221 : ℝ) / 20000000)) ((-89693251 : ℝ) / 25000000) ((-179386499 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((553221 : ℝ) / 625000)) (t := ((-71779 : ℝ) / 1178221))
    (lo := ((-12199409 : ℝ) / 100000000)) (hi := ((-762463 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((553221 : ℝ) / 20000000) = Real.log ((553221 : ℝ) / 625000) - 5 * Real.log 2 := by
    rw [show ((553221 : ℝ) / 20000000) = ((553221 : ℝ) / 625000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_881 : RB (Real.log ((2834331 : ℝ) / 100000000)) ((-356336431 : ℝ) / 100000000) ((-14253457 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((2834331 : ℝ) / 3125000)) (t := ((-290669 : ℝ) / 5959331))
    (lo := ((-2440709 : ℝ) / 25000000)) (hi := ((-1952567 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2834331 : ℝ) / 100000000) = Real.log ((2834331 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2834331 : ℝ) / 100000000) = ((2834331 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_882 : RB (Real.log ((69790841 : ℝ) / 100000000)) ((-35966741 : ℝ) / 100000000) ((-1798337 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((69790841 : ℝ) / 100000000)) (t := ((-30209159 : ℝ) / 169790841))
    (lo := ((-35966741 : ℝ) / 100000000)) (hi := ((-1798337 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_883 : RB (Real.log ((69792557 : ℝ) / 100000000)) ((-17982141 : ℝ) / 50000000) ((-35964281 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((69792557 : ℝ) / 100000000)) (t := ((-30207443 : ℝ) / 169792557))
    (lo := ((-17982141 : ℝ) / 50000000)) (hi := ((-35964281 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_884 : RB (Real.log ((41117119 : ℝ) / 100000000)) ((-22218641 : ℝ) / 25000000) ((-44437281 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((41117119 : ℝ) / 50000000)) (t := ((-8882881 : ℝ) / 91117119))
    (lo := ((-3911969 : ℝ) / 20000000)) (hi := ((-4889961 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41117119 : ℝ) / 100000000) = Real.log ((41117119 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41117119 : ℝ) / 100000000) = ((41117119 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_885 : RB (Real.log ((194163027 : ℝ) / 100000000)) ((16588199 : ℝ) / 25000000) ((33176399 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((194163027 : ℝ) / 200000000)) (t := ((-5836973 : ℝ) / 394163027))
    (lo := ((-1480961 : ℝ) / 50000000)) (hi := ((-2961921 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194163027 : ℝ) / 100000000) = Real.log ((194163027 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194163027 : ℝ) / 100000000) = ((194163027 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_886 : RB (Real.log ((48573467 : ℝ) / 25000000)) ((207563 : ℝ) / 312500) ((33210081 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((48573467 : ℝ) / 50000000)) (t := ((-1426533 : ℝ) / 98573467))
    (lo := ((-1447279 : ℝ) / 50000000)) (hi := ((-2894557 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48573467 : ℝ) / 25000000) = Real.log ((48573467 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48573467 : ℝ) / 25000000) = ((48573467 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_887 : RB (Real.log ((72208091 : ℝ) / 100000000)) ((-32561809 : ℝ) / 100000000) ((-2035113 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((72208091 : ℝ) / 100000000)) (t := ((-27791909 : ℝ) / 172208091))
    (lo := ((-32561809 : ℝ) / 100000000)) (hi := ((-2035113 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_888 : RB (Real.log ((72209831 : ℝ) / 100000000)) ((-32559399 : ℝ) / 100000000) ((-16279699 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((72209831 : ℝ) / 100000000)) (t := ((-27790169 : ℝ) / 172209831))
    (lo := ((-32559399 : ℝ) / 100000000)) (hi := ((-16279699 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_889 : RB (Real.log ((20971823 : ℝ) / 50000000)) ((-3475373 : ℝ) / 4000000) ((-86884323 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20971823 : ℝ) / 25000000)) (t := ((-4028177 : ℝ) / 45971823))
    (lo := ((-8784803 : ℝ) / 50000000)) (hi := ((-3513921 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20971823 : ℝ) / 50000000) = Real.log ((20971823 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20971823 : ℝ) / 50000000) = ((20971823 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_890 : RB (Real.log ((109592069 : ℝ) / 25000000)) ((73894459 : ℝ) / 50000000) ((147788921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((109592069 : ℝ) / 100000000)) (t := ((9592069 : ℝ) / 209592069))
    (lo := ((4579741 : ℝ) / 50000000)) (hi := ((9159483 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((109592069 : ℝ) / 25000000) = Real.log ((109592069 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((109592069 : ℝ) / 25000000) = ((109592069 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_891 : RB (Real.log ((87674339 : ℝ) / 20000000)) ((73894849 : ℝ) / 50000000) ((147789701 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((87674339 : ℝ) / 80000000)) (t := ((7674339 : ℝ) / 167674339))
    (lo := ((4580131 : ℝ) / 50000000)) (hi := ((9160263 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((87674339 : ℝ) / 20000000) = Real.log ((87674339 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((87674339 : ℝ) / 20000000) = ((87674339 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_892 : RB (Real.log ((129547019 : ℝ) / 100000000)) ((25887371 : ℝ) / 100000000) ((6471843 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((129547019 : ℝ) / 100000000)) (t := ((29547019 : ℝ) / 229547019))
    (lo := ((25887371 : ℝ) / 100000000)) (hi := ((6471843 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_893 : RB (Real.log ((434430349 : ℝ) / 100000000)) ((9180409 : ℝ) / 6250000) ((146886547 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((434430349 : ℝ) / 400000000)) (t := ((34430349 : ℝ) / 834430349))
    (lo := ((2064277 : ℝ) / 25000000)) (hi := ((8257109 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((434430349 : ℝ) / 100000000) = Real.log ((434430349 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((434430349 : ℝ) / 100000000) = ((434430349 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_894 : RB (Real.log ((434433729 : ℝ) / 100000000)) ((73443661 : ℝ) / 50000000) ((5875493 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((434433729 : ℝ) / 400000000)) (t := ((34433729 : ℝ) / 834433729))
    (lo := ((4128943 : ℝ) / 50000000)) (hi := ((8257887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((434433729 : ℝ) / 100000000) = Real.log ((434433729 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((434433729 : ℝ) / 100000000) = ((434433729 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_895 : RB (Real.log ((16236867 : ℝ) / 12500000)) ((1046223 : ℝ) / 4000000) ((3269447 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((16236867 : ℝ) / 12500000)) (t := ((3736867 : ℝ) / 28736867))
    (lo := ((1046223 : ℝ) / 4000000)) (hi := ((3269447 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_896 : RB (Real.log ((8025239 : ℝ) / 100000000)) ((-126128939 : ℝ) / 50000000) ((-252257873 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8025239 : ℝ) / 6250000)) (t := ((1775239 : ℝ) / 14275239))
    (lo := ((12500499 : ℝ) / 50000000)) (hi := ((25000999 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8025239 : ℝ) / 100000000) = Real.log ((8025239 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8025239 : ℝ) / 100000000) = ((8025239 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_897 : RB (Real.log ((5115851 : ℝ) / 50000000)) ((-28495991 : ℝ) / 12500000) ((-56991981 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5115851 : ℝ) / 6250000)) (t := ((-1134149 : ℝ) / 11365851))
    (lo := ((-20023771 : ℝ) / 100000000)) (hi := ((-2002377 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5115851 : ℝ) / 50000000) = Real.log ((5115851 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5115851 : ℝ) / 50000000) = ((5115851 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_898 : RB (Real.log ((176907 : ℝ) / 6250000)) ((-178235631 : ℝ) / 50000000) ((-44558907 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((353814 : ℝ) / 390625)) (t := ((-36811 : ℝ) / 744439))
    (lo := ((-9897667 : ℝ) / 100000000)) (hi := ((-4948833 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((176907 : ℝ) / 6250000) = Real.log ((353814 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((176907 : ℝ) / 6250000) = ((353814 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_899 : RB (Real.log ((724707 : ℝ) / 25000000)) ((-88521593 : ℝ) / 25000000) ((-177043183 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((724707 : ℝ) / 781250)) (t := ((-56543 : ℝ) / 1505957))
    (lo := ((-7512777 : ℝ) / 100000000)) (hi := ((-939097 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((724707 : ℝ) / 25000000) = Real.log ((724707 : ℝ) / 781250) - 5 * Real.log 2 := by
    rw [show ((724707 : ℝ) / 25000000) = ((724707 : ℝ) / 781250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_900 : RB (Real.log ((13908667 : ℝ) / 20000000)) ((-36322011 : ℝ) / 100000000) ((-3632201 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((13908667 : ℝ) / 20000000)) (t := ((-6091333 : ℝ) / 33908667))
    (lo := ((-36322011 : ℝ) / 100000000)) (hi := ((-3632201 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_901 : RB (Real.log ((6954509 : ℝ) / 10000000)) ((-36319487 : ℝ) / 100000000) ((-18159743 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6954509 : ℝ) / 10000000)) (t := ((-3045491 : ℝ) / 16954509))
    (lo := ((-36319487 : ℝ) / 100000000)) (hi := ((-18159743 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_902 : RB (Real.log ((41031769 : ℝ) / 100000000)) ((-44541179 : ℝ) / 50000000) ((-22270589 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((41031769 : ℝ) / 50000000)) (t := ((-8968231 : ℝ) / 91031769))
    (lo := ((-19767639 : ℝ) / 100000000)) (hi := ((-9883819 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41031769 : ℝ) / 100000000) = Real.log ((41031769 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41031769 : ℝ) / 100000000) = ((41031769 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_903 : RB (Real.log ((38806429 : ℝ) / 20000000)) ((13257073 : ℝ) / 20000000) ((66285367 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38806429 : ℝ) / 40000000)) (t := ((-1193571 : ℝ) / 78806429))
    (lo := ((-3029353 : ℝ) / 100000000)) (hi := ((-378669 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38806429 : ℝ) / 20000000) = Real.log ((38806429 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38806429 : ℝ) / 20000000) = ((38806429 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_904 : RB (Real.log ((194163031 : ℝ) / 100000000)) ((33176399 : ℝ) / 50000000) ((82941 : ℝ) / 125000) := by
  have hm := log_bounds_of_series (x := ((194163031 : ℝ) / 200000000)) (t := ((-5836969 : ℝ) / 394163031))
    (lo := ((-2314 : ℝ) / 78125)) (hi := ((-2961919 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194163031 : ℝ) / 100000000) = Real.log ((194163031 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194163031 : ℝ) / 100000000) = ((194163031 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_905 : RB (Real.log ((14380271 : ℝ) / 20000000)) ((-8246877 : ℝ) / 25000000) ((-32987507 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((14380271 : ℝ) / 20000000)) (t := ((-5619729 : ℝ) / 34380271))
    (lo := ((-8246877 : ℝ) / 25000000)) (hi := ((-32987507 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_906 : RB (Real.log ((35951567 : ℝ) / 50000000)) ((-16492517 : ℝ) / 50000000) ((-32985033 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35951567 : ℝ) / 50000000)) (t := ((-14048433 : ℝ) / 85951567))
    (lo := ((-16492517 : ℝ) / 50000000)) (hi := ((-32985033 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_907 : RB (Real.log ((41840653 : ℝ) / 100000000)) ((-87130177 : ℝ) / 100000000) ((-3485207 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((41840653 : ℝ) / 50000000)) (t := ((-8159347 : ℝ) / 91840653))
    (lo := ((-8907729 : ℝ) / 50000000)) (hi := ((-17815457 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41840653 : ℝ) / 100000000) = Real.log ((41840653 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41840653 : ℝ) / 100000000) = ((41840653 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_908 : RB (Real.log ((87407017 : ℝ) / 20000000)) ((147484329 : ℝ) / 100000000) ((36871083 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((87407017 : ℝ) / 80000000)) (t := ((7407017 : ℝ) / 167407017))
    (lo := ((8854893 : ℝ) / 100000000)) (hi := ((4427447 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((87407017 : ℝ) / 20000000) = Real.log ((87407017 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((87407017 : ℝ) / 20000000) = ((87407017 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_909 : RB (Real.log ((109259643 : ℝ) / 25000000)) ((73742563 : ℝ) / 50000000) ((147485129 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((109259643 : ℝ) / 100000000)) (t := ((9259643 : ℝ) / 209259643))
    (lo := ((885569 : ℝ) / 10000000)) (hi := ((8855691 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((109259643 : ℝ) / 25000000) = Real.log ((109259643 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((109259643 : ℝ) / 25000000) = ((109259643 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_910 : RB (Real.log ((12966359 : ℝ) / 10000000)) ((12988657 : ℝ) / 50000000) ((5195463 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((12966359 : ℝ) / 10000000)) (t := ((2966359 : ℝ) / 22966359))
    (lo := ((12988657 : ℝ) / 50000000)) (hi := ((5195463 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_911 : RB (Real.log ((433147857 : ℝ) / 100000000)) ((29318179 : ℝ) / 20000000) ((73295449 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((433147857 : ℝ) / 400000000)) (t := ((33147857 : ℝ) / 833147857))
    (lo := ((7961459 : ℝ) / 100000000)) (hi := ((398073 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((433147857 : ℝ) / 100000000) = Real.log ((433147857 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((433147857 : ℝ) / 100000000) = ((433147857 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_912 : RB (Real.log ((54143913 : ℝ) / 12500000)) ((146591691 : ℝ) / 100000000) ((73295847 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((54143913 : ℝ) / 50000000)) (t := ((4143913 : ℝ) / 104143913))
    (lo := ((1592451 : ℝ) / 20000000)) (hi := ((497641 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((54143913 : ℝ) / 12500000) = Real.log ((54143913 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((54143913 : ℝ) / 12500000) = ((54143913 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_913 : RB (Real.log ((13000971 : ℝ) / 10000000)) ((5248779 : ℝ) / 20000000) ((3280487 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((13000971 : ℝ) / 10000000)) (t := ((3000971 : ℝ) / 23000971))
    (lo := ((5248779 : ℝ) / 20000000)) (hi := ((3280487 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_914 : RB (Real.log ((8156259 : ℝ) / 100000000)) ((-125319231 : ℝ) / 50000000) ((-250638457 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8156259 : ℝ) / 6250000)) (t := ((1906259 : ℝ) / 14406259))
    (lo := ((13310207 : ℝ) / 50000000)) (hi := ((5324083 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8156259 : ℝ) / 100000000) = Real.log ((8156259 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8156259 : ℝ) / 100000000) = ((8156259 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_915 : RB (Real.log ((1032367 : ℝ) / 10000000)) ((-22707309 : ℝ) / 10000000) ((-113536543 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1032367 : ℝ) / 1250000)) (t := ((-217633 : ℝ) / 2282367))
    (lo := ((-19128933 : ℝ) / 100000000)) (hi := ((-4782233 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1032367 : ℝ) / 10000000) = Real.log ((1032367 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((1032367 : ℝ) / 10000000) = ((1032367 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_916 : RB (Real.log ((72373 : ℝ) / 2500000)) ((-88555319 : ℝ) / 25000000) ((-35422127 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((72373 : ℝ) / 78125)) (t := ((-2876 : ℝ) / 75249))
    (lo := ((-7647681 : ℝ) / 100000000)) (hi := ((-23899 : ℝ) / 312500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((72373 : ℝ) / 2500000) = Real.log ((72373 : ℝ) / 78125) - 5 * Real.log 2 := by
    rw [show ((72373 : ℝ) / 2500000) = ((72373 : ℝ) / 78125) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_917 : RB (Real.log ((23151 : ℝ) / 781250)) ((-10996429 : ℝ) / 3125000) ((-175942861 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((370416 : ℝ) / 390625)) (t := ((-20209 : ℝ) / 761041))
    (lo := ((-5312133 : ℝ) / 100000000)) (hi := ((-1328033 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23151 : ℝ) / 781250) = Real.log ((370416 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((23151 : ℝ) / 781250) = ((370416 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_918 : RB (Real.log ((34650391 : ℝ) / 50000000)) ((-183357 : ℝ) / 500000) ((-36671399 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((34650391 : ℝ) / 50000000)) (t := ((-15349609 : ℝ) / 84650391))
    (lo := ((-183357 : ℝ) / 500000)) (hi := ((-36671399 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_919 : RB (Real.log ((69302577 : ℝ) / 100000000)) ((-3666881 : ℝ) / 10000000) ((-36668809 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((69302577 : ℝ) / 100000000)) (t := ((-30697423 : ℝ) / 169302577))
    (lo := ((-3666881 : ℝ) / 10000000)) (hi := ((-36668809 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_920 : RB (Real.log ((40947911 : ℝ) / 100000000)) ((-4464347 : ℝ) / 5000000) ((-44643469 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((40947911 : ℝ) / 50000000)) (t := ((-9052089 : ℝ) / 90947911))
    (lo := ((-19972221 : ℝ) / 100000000)) (hi := ((-998611 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40947911 : ℝ) / 100000000) = Real.log ((40947911 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40947911 : ℝ) / 100000000) = ((40947911 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_921 : RB (Real.log ((193901219 : ℝ) / 100000000)) ((33108933 : ℝ) / 50000000) ((16554467 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((193901219 : ℝ) / 200000000)) (t := ((-6098781 : ℝ) / 393901219))
    (lo := ((-774213 : ℝ) / 25000000)) (hi := ((-3096851 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((193901219 : ℝ) / 100000000) = Real.log ((193901219 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((193901219 : ℝ) / 100000000) = ((193901219 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_922 : RB (Real.log ((24254019 : ℝ) / 12500000)) ((66285369 : ℝ) / 100000000) ((66285371 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((24254019 : ℝ) / 25000000)) (t := ((-745981 : ℝ) / 49254019))
    (lo := ((-3029349 : ℝ) / 100000000)) (hi := ((-757337 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24254019 : ℝ) / 12500000) = Real.log ((24254019 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((24254019 : ℝ) / 12500000) = ((24254019 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_923 : RB (Real.log ((14320583 : ℝ) / 20000000)) ((-33403441 : ℝ) / 100000000) ((-417543 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((14320583 : ℝ) / 20000000)) (t := ((-5679417 : ℝ) / 34320583))
    (lo := ((-33403441 : ℝ) / 100000000)) (hi := ((-417543 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_924 : RB (Real.log ((71604733 : ℝ) / 100000000)) ((-16700451 : ℝ) / 50000000) ((-33400901 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((71604733 : ℝ) / 100000000)) (t := ((-28395267 : ℝ) / 171604733))
    (lo := ((-16700451 : ℝ) / 50000000)) (hi := ((-33400901 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_925 : RB (Real.log ((20870061 : ℝ) / 50000000)) ((-43685369 : ℝ) / 50000000) ((-5460671 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((20870061 : ℝ) / 25000000)) (t := ((-4129939 : ℝ) / 45870061))
    (lo := ((-18056019 : ℝ) / 100000000)) (hi := ((-9028009 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20870061 : ℝ) / 50000000) = Real.log ((20870061 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20870061 : ℝ) / 50000000) = ((20870061 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_926 : RB (Real.log ((217859547 : ℝ) / 50000000)) ((36795689 : ℝ) / 25000000) ((147182759 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((217859547 : ℝ) / 200000000)) (t := ((17859547 : ℝ) / 417859547))
    (lo := ((213833 : ℝ) / 2500000)) (hi := ((8553321 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((217859547 : ℝ) / 50000000) = Real.log ((217859547 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((217859547 : ℝ) / 50000000) = ((217859547 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_927 : RB (Real.log ((435722651 : ℝ) / 100000000)) ((147183573 : ℝ) / 100000000) ((18397947 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((435722651 : ℝ) / 400000000)) (t := ((35722651 : ℝ) / 835722651))
    (lo := ((8554137 : ℝ) / 100000000)) (hi := ((4277069 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((435722651 : ℝ) / 100000000) = Real.log ((435722651 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((435722651 : ℝ) / 100000000) = ((435722651 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_928 : RB (Real.log ((64889777 : ℝ) / 50000000)) ((6516677 : ℝ) / 25000000) ((26066709 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64889777 : ℝ) / 50000000)) (t := ((14889777 : ℝ) / 114889777))
    (lo := ((6516677 : ℝ) / 25000000)) (hi := ((26066709 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_929 : RB (Real.log ((107970373 : ℝ) / 25000000)) ((146298103 : ℝ) / 100000000) ((73149053 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((107970373 : ℝ) / 100000000)) (t := ((7970373 : ℝ) / 207970373))
    (lo := ((7668667 : ℝ) / 100000000)) (hi := ((1917167 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((107970373 : ℝ) / 25000000) = Real.log ((107970373 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((107970373 : ℝ) / 25000000) = ((107970373 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_930 : RB (Real.log ((431885009 : ℝ) / 100000000)) ((73149459 : ℝ) / 50000000) ((146298921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((431885009 : ℝ) / 400000000)) (t := ((31885009 : ℝ) / 831885009))
    (lo := ((3834741 : ℝ) / 50000000)) (hi := ((7669483 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((431885009 : ℝ) / 100000000) = Real.log ((431885009 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((431885009 : ℝ) / 100000000) = ((431885009 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_931 : RB (Real.log ((1301239 : ℝ) / 1000000)) ((3291461 : ℝ) / 12500000) ((26331689 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1301239 : ℝ) / 1000000)) (t := ((301239 : ℝ) / 2301239))
    (lo := ((3291461 : ℝ) / 12500000)) (hi := ((26331689 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_932 : RB (Real.log ((8288357 : ℝ) / 100000000)) ((-249031847 : ℝ) / 100000000) ((-124515921 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8288357 : ℝ) / 6250000)) (t := ((2038357 : ℝ) / 14538357))
    (lo := ((28227029 : ℝ) / 100000000)) (hi := ((2822703 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8288357 : ℝ) / 100000000) = Real.log ((8288357 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8288357 : ℝ) / 100000000) = ((8288357 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_933 : RB (Real.log ((2604721 : ℝ) / 25000000)) ((-226155029 : ℝ) / 100000000) ((-9046201 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((2604721 : ℝ) / 3125000)) (t := ((-520279 : ℝ) / 5729721))
    (lo := ((-2276359 : ℝ) / 12500000)) (hi := ((-18210871 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2604721 : ℝ) / 25000000) = Real.log ((2604721 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((2604721 : ℝ) / 25000000) = ((2604721 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_934 : RB (Real.log ((92479 : ℝ) / 3125000)) ((-176010401 : ℝ) / 50000000) ((-88005199 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((369916 : ℝ) / 390625)) (t := ((-20709 : ℝ) / 760541))
    (lo := ((-5447207 : ℝ) / 100000000)) (hi := ((-2723603 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((92479 : ℝ) / 3125000) = Real.log ((369916 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((92479 : ℝ) / 3125000) = ((369916 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_935 : RB (Real.log ((756957 : ℝ) / 25000000)) ((-349732471 : ℝ) / 100000000) ((-69946493 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((756957 : ℝ) / 781250)) (t := ((-24293 : ℝ) / 1538207))
    (lo := ((-789719 : ℝ) / 25000000)) (hi := ((-25271 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((756957 : ℝ) / 25000000) = Real.log ((756957 : ℝ) / 781250) - 5 * Real.log 2 := by
    rw [show ((756957 : ℝ) / 25000000) = ((756957 : ℝ) / 781250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_936 : RB (Real.log ((69062899 : ℝ) / 100000000)) ((-9253813 : ℝ) / 25000000) ((-37015251 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((69062899 : ℝ) / 100000000)) (t := ((-30937101 : ℝ) / 169062899))
    (lo := ((-9253813 : ℝ) / 25000000)) (hi := ((-37015251 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_937 : RB (Real.log ((69064733 : ℝ) / 100000000)) ((-37012597 : ℝ) / 100000000) ((-9253149 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((69064733 : ℝ) / 100000000)) (t := ((-30935267 : ℝ) / 169064733))
    (lo := ((-37012597 : ℝ) / 100000000)) (hi := ((-9253149 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_938 : RB (Real.log ((40865461 : ℝ) / 100000000)) ((-89488497 : ℝ) / 100000000) ((-17897699 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((40865461 : ℝ) / 50000000)) (t := ((-9134539 : ℝ) / 90865461))
    (lo := ((-10086889 : ℝ) / 50000000)) (hi := ((-20173777 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40865461 : ℝ) / 100000000) = Real.log ((40865461 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40865461 : ℝ) / 100000000) = ((40865461 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_939 : RB (Real.log ((193770247 : ℝ) / 100000000)) ((66150297 : ℝ) / 100000000) ((66150299 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((193770247 : ℝ) / 200000000)) (t := ((-6229753 : ℝ) / 393770247))
    (lo := ((-3164421 : ℝ) / 100000000)) (hi := ((-158221 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((193770247 : ℝ) / 100000000) = Real.log ((193770247 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((193770247 : ℝ) / 100000000) = ((193770247 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_940 : RB (Real.log ((7756049 : ℝ) / 4000000)) ((66217869 : ℝ) / 100000000) ((66217871 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7756049 : ℝ) / 8000000)) (t := ((-243951 : ℝ) / 15756049))
    (lo := ((-3096849 : ℝ) / 100000000)) (hi := ((-193553 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7756049 : ℝ) / 4000000) = Real.log ((7756049 : ℝ) / 8000000) + 1 * Real.log 2 := by
    rw [show ((7756049 : ℝ) / 4000000) = ((7756049 : ℝ) / 8000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_941 : RB (Real.log ((14262457 : ℝ) / 20000000)) ((-16905079 : ℝ) / 50000000) ((-33810157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((14262457 : ℝ) / 20000000)) (t := ((-5737543 : ℝ) / 34262457))
    (lo := ((-16905079 : ℝ) / 50000000)) (hi := ((-33810157 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_942 : RB (Real.log ((2228567 : ℝ) / 3125000)) ((-33807551 : ℝ) / 100000000) ((-676151 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((2228567 : ℝ) / 3125000)) (t := ((-896433 : ℝ) / 5353567))
    (lo := ((-33807551 : ℝ) / 100000000)) (hi := ((-676151 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_943 : RB (Real.log ((41641917 : ℝ) / 100000000)) ((-21901573 : ℝ) / 25000000) ((-8760629 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((41641917 : ℝ) / 50000000)) (t := ((-8358083 : ℝ) / 91641917))
    (lo := ((-18291573 : ℝ) / 100000000)) (hi := ((-4572893 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41641917 : ℝ) / 100000000) = Real.log ((41641917 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41641917 : ℝ) / 100000000) = ((41641917 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_944 : RB (Real.log ((217209957 : ℝ) / 50000000)) ((73442071 : ℝ) / 50000000) ((29376829 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((217209957 : ℝ) / 200000000)) (t := ((17209957 : ℝ) / 417209957))
    (lo := ((4127353 : ℝ) / 50000000)) (hi := ((8254707 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((217209957 : ℝ) / 50000000) = Real.log ((217209957 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((217209957 : ℝ) / 50000000) = ((217209957 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_945 : RB (Real.log ((434423541 : ℝ) / 100000000)) ((146884977 : ℝ) / 100000000) ((7344249 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((434423541 : ℝ) / 400000000)) (t := ((34423541 : ℝ) / 834423541))
    (lo := ((8255541 : ℝ) / 100000000)) (hi := ((4127771 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((434423541 : ℝ) / 100000000) = Real.log ((434423541 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((434423541 : ℝ) / 100000000) = ((434423541 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_946 : RB (Real.log ((3247373 : ℝ) / 2500000)) ((13077781 : ℝ) / 50000000) ((26155563 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3247373 : ℝ) / 2500000)) (t := ((747373 : ℝ) / 5747373))
    (lo := ((13077781 : ℝ) / 50000000)) (hi := ((26155563 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_947 : RB (Real.log ((53828863 : ℝ) / 12500000)) ((36502029 : ℝ) / 25000000) ((146008119 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((53828863 : ℝ) / 50000000)) (t := ((3828863 : ℝ) / 103828863))
    (lo := ((184467 : ℝ) / 2500000)) (hi := ((7378681 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53828863 : ℝ) / 12500000) = Real.log ((53828863 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((53828863 : ℝ) / 12500000) = ((53828863 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_948 : RB (Real.log ((43063449 : ℝ) / 10000000)) ((146008949 : ℝ) / 100000000) ((18251119 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((43063449 : ℝ) / 40000000)) (t := ((3063449 : ℝ) / 83063449))
    (lo := ((7379513 : ℝ) / 100000000)) (hi := ((3689757 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43063449 : ℝ) / 10000000) = Real.log ((43063449 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((43063449 : ℝ) / 10000000) = ((43063449 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_949 : RB (Real.log ((65118757 : ℝ) / 50000000)) ((13209481 : ℝ) / 50000000) ((26418963 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65118757 : ℝ) / 50000000)) (t := ((15118757 : ℝ) / 115118757))
    (lo := ((13209481 : ℝ) / 50000000)) (hi := ((26418963 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_950 : RB (Real.log ((421069 : ℝ) / 5000000)) ((-247439651 : ℝ) / 100000000) ((-247439647 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((421069 : ℝ) / 625000)) (t := ((-203931 : ℝ) / 1046069))
    (lo := ((-19747747 : ℝ) / 50000000)) (hi := ((-39495493 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((421069 : ℝ) / 5000000) = Real.log ((421069 : ℝ) / 625000) - 3 * Real.log 2 := by
    rw [show ((421069 : ℝ) / 5000000) = ((421069 : ℝ) / 625000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_951 : RB (Real.log ((5258531 : ℝ) / 50000000)) ((-225217133 : ℝ) / 100000000) ((-225217129 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5258531 : ℝ) / 6250000)) (t := ((-991469 : ℝ) / 11508531))
    (lo := ((-1079561 : ℝ) / 6250000)) (hi := ((-690919 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5258531 : ℝ) / 50000000) = Real.log ((5258531 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5258531 : ℝ) / 50000000) = ((5258531 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_952 : RB (Real.log ((377967 : ℝ) / 12500000)) ((-349867709 : ℝ) / 100000000) ((-349867703 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((377967 : ℝ) / 390625)) (t := ((-6329 : ℝ) / 384296))
    (lo := ((-1647057 : ℝ) / 50000000)) (hi := ((-3294113 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((377967 : ℝ) / 12500000) = Real.log ((377967 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((377967 : ℝ) / 12500000) = ((377967 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_953 : RB (Real.log ((1546163 : ℝ) / 50000000)) ((-86906167 : ℝ) / 25000000) ((-173812331 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1546163 : ℝ) / 1562500)) (t := ((-16337 : ℝ) / 3108663))
    (lo := ((-1051073 : ℝ) / 100000000)) (hi := ((-16423 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1546163 : ℝ) / 50000000) = Real.log ((1546163 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1546163 : ℝ) / 50000000) = ((1546163 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_954 : RB (Real.log ((6882943 : ℝ) / 10000000)) ((-18676939 : ℝ) / 50000000) ((-37353877 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((6882943 : ℝ) / 10000000)) (t := ((-3117057 : ℝ) / 16882943))
    (lo := ((-18676939 : ℝ) / 50000000)) (hi := ((-37353877 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_955 : RB (Real.log ((8603913 : ℝ) / 12500000)) ((-7470231 : ℝ) / 20000000) ((-18675577 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8603913 : ℝ) / 12500000)) (t := ((-3896087 : ℝ) / 21103913))
    (lo := ((-7470231 : ℝ) / 20000000)) (hi := ((-18675577 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_956 : RB (Real.log ((20392171 : ℝ) / 50000000)) ((-89687197 : ℝ) / 100000000) ((-17937439 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((20392171 : ℝ) / 25000000)) (t := ((-4607829 : ℝ) / 45392171))
    (lo := ((-10186239 : ℝ) / 50000000)) (hi := ((-20372477 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20392171 : ℝ) / 50000000) = Real.log ((20392171 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20392171 : ℝ) / 50000000) = ((20392171 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_957 : RB (Real.log ((48409807 : ℝ) / 25000000)) ((66082659 : ℝ) / 100000000) ((66082661 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((48409807 : ℝ) / 50000000)) (t := ((-1590193 : ℝ) / 98409807))
    (lo := ((-3232059 : ℝ) / 100000000)) (hi := ((-1616029 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48409807 : ℝ) / 25000000) = Real.log ((48409807 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48409807 : ℝ) / 25000000) = ((48409807 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_958 : RB (Real.log ((193770251 : ℝ) / 100000000)) ((66150299 : ℝ) / 100000000) ((66150301 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((193770251 : ℝ) / 200000000)) (t := ((-6229749 : ℝ) / 393770251))
    (lo := ((-3164419 : ℝ) / 100000000)) (hi := ((-1582209 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((193770251 : ℝ) / 100000000) = Real.log ((193770251 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((193770251 : ℝ) / 100000000) = ((193770251 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_959 : RB (Real.log ((35514509 : ℝ) / 50000000)) ((-34208169 : ℝ) / 100000000) ((-4276021 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((35514509 : ℝ) / 50000000)) (t := ((-14485491 : ℝ) / 85514509))
    (lo := ((-34208169 : ℝ) / 100000000)) (hi := ((-4276021 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
