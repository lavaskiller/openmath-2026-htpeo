import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk09
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_32 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((51868611727610489782808194790195 : ℝ) / 649037107316853453566312041152512) ((213448833483293595163384346155417 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((79916249999 : ℝ) / 1000000000000) ((32887 : ℝ) / 400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1079916249999 : ℝ) / 1000000000000) ((432887 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((9610436479 : ℝ) / 125000000000) ((3950608843 : ℝ) / 50000000000) := rb_log h1 (by norm_num) dlower_log_479.1 dlower_log_480.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((9610436479 : ℝ) / 62500000000) ((3950608843 : ℝ) / 25000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((535122826839 : ℝ) / 1000000000000) ((16855631153 : ℝ) / 31250000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1263388033839 : ℝ) / 500000000000) ((-2498387104201 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_481.1 dlower_log_482.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2498387104201 : ℝ) / 1000000000000) ((1263388033839 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((105890433601 : ℝ) / 500000000000) ((53972840717 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((196027159283 : ℝ) / 250000000000) ((394109566399 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((6386607013 : ℝ) / 1000000000000) ((6759717307 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((178261245181 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((69952554611 : ℝ) / 200000000000) ((350135883349 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((178261245181 : ℝ) / 500000000000) ((178261245181 : ℝ) / 500000000000) ((178261245181 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((321738754819 : ℝ) / 500000000000))
  have h11 : RB z11 ((271775444997 : ℝ) / 500000000000) ((544130724237 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((321738754819 : ℝ) / 500000000000) ((321738754819 : ℝ) / 500000000000) ((321738754819 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-609631942961 : ℝ) / 1000000000000) ((-304282879543 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_483.1 dlower_log_484.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-480523561407 : ℝ) / 1000000000000) ((-238590833981 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((178261245181 : ℝ) / 500000000000))
  have h14 : RB z14 ((-1031357954549 : ℝ) / 1000000000000) ((-1031357954547 : ℝ) / 1000000000000) := rb_log (show RB ((178261245181 : ℝ) / 500000000000) ((178261245181 : ℝ) / 500000000000) ((178261245181 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_485.1 dlower_log_485.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((27541719657 : ℝ) / 50000000000) ((554176286587 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2863549061 : ℝ) / 250000000000) ((4763364937 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((6386607013 : ℝ) / 1000000000000) ((6759717307 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((722862117553 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1438964517799 : ℝ) / 1000000000000) ((1439337628093 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((722862117553 : ℝ) / 500000000000) ((722862117553 : ℝ) / 500000000000) ((722862117553 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((222862117553 : ℝ) / 500000000000))
  have h19 : RB z19 ((3228373968619 : ℝ) / 1000000000000) ((3229211056363 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((222862117553 : ℝ) / 500000000000) ((222862117553 : ℝ) / 500000000000) ((222862117553 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1171978595189 : ℝ) / 1000000000000) ((293059463101 : ℝ) / 250000000000) := rb_log h19 (by norm_num) dlower_log_486.1 dlower_log_487.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((918958539021 : ℝ) / 1000000000000) ((184796060691 : ℝ) / 200000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((722862117553 : ℝ) / 500000000000))
  have h22 : RB z22 ((368610396769 : ℝ) / 1000000000000) ((368610396771 : ℝ) / 1000000000000) := rb_log (show RB ((722862117553 : ℝ) / 500000000000) ((722862117553 : ℝ) / 500000000000) ((722862117553 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_488.1 dlower_log_488.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((2201392569 : ℝ) / 4000000000) ((277684953343 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5483972677 : ℝ) / 500000000000) ((20247079847 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1079916249999 : ℝ) / 1000000000000) ((432887 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1166219107011 : ℝ) / 1000000000000) ((1171194717307 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((213457246951 : ℝ) / 125000000000) ((857471802673 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((136150218093 : ℝ) / 125000000000))
  have h28 : RB z28 ((929992023229 : ℝ) / 500000000000) ((1867919567081 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((136150218093 : ℝ) / 125000000000) ((136150218093 : ℝ) / 125000000000) ((136150218093 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((6386607013 : ℝ) / 1000000000000) ((6759717307 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((128858301169172176762093 : ℝ) / 250000000000000000000000))
  have h30 : RB z30 ((6195377941 : ℝ) / 500000000000) ((1639329123 : ℝ) / 125000000000) := rb_div_signed h29 (show RB ((128858301169172176762093 : ℝ) / 250000000000000000000000) ((128858301169172176762093 : ℝ) / 250000000000000000000000) ((128858301169172176762093 : ℝ) / 250000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((123360670877 : ℝ) / 125000000000) ((493804622059 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((458897759583 : ℝ) / 250000000000) ((1844774631719 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((178261245181 : ℝ) / 500000000000)) ((2863549061 : ℝ) / 250000000000) ((4763364937 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((722862117553 : ℝ) / 500000000000)) ((5483972677 : ℝ) / 500000000000) ((20247079847 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((178261245181 : ℝ) / 500000000000)) (wl := ((722862117553 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((458897759583 : ℝ) / 250000000000) ≤ D0q (q) * (((722862117553 : ℝ) / 500000000000) - ((178261245181 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((722862117553 : ℝ) / 500000000000) * ((178261245181 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_33 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((213448833483293595163384346155417 : ℝ) / 2596148429267413814265248164610048) ((109711610028072615597767956575027 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((82217499999 : ℝ) / 1000000000000) ((13523 : ℝ) / 160000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1082217499999 : ℝ) / 1000000000000) ((173523 : ℝ) / 160000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((39506088429 : ℝ) / 500000000000) ((81136340209 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_489.1 dlower_log_490.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((39506088429 : ℝ) / 250000000000) ((81136340209 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((530874500141 : ℝ) / 1000000000000) ((133780706711 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-499677420843 : ℝ) / 200000000000) ((-123539093787 : ℝ) / 50000000000) := rb_log hqr (by norm_num) dlower_log_491.1 dlower_log_492.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((123539093787 : ℝ) / 50000000000) ((499677420843 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((106243443869 : ℝ) / 500000000000) ((5414508987 : ℝ) / 25000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((19585491013 : ℝ) / 25000000000) ((393756556131 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3379858653 : ℝ) / 500000000000) ((3571709551 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((351185644833 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((344042225731 : ℝ) / 1000000000000) ((344425927527 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((351185644833 : ℝ) / 1000000000000) ((351185644833 : ℝ) / 1000000000000) ((351185644833 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((648814355167 : ℝ) / 1000000000000))
  have h11 : RB z11 ((530262968121 : ℝ) / 1000000000000) ((530854357313 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((648814355167 : ℝ) / 1000000000000) ((648814355167 : ℝ) / 1000000000000) ((648814355167 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-31719111461 : ℝ) / 50000000000) ((-316633787687 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_493.1 dlower_log_494.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-499584323697 : ℝ) / 1000000000000) ((-124028564063 : ℝ) / 250000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((351185644833 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1046440292679 : ℝ) / 1000000000000) ((-261610073169 : ℝ) / 250000000000) := rb_log (show RB ((351185644833 : ℝ) / 1000000000000) ((351185644833 : ℝ) / 1000000000000) ((351185644833 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_495.1 dlower_log_495.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((546855968979 : ℝ) / 1000000000000) ((550326036427 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2346628427 : ℝ) / 200000000000) ((9725768143 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3379858653 : ℝ) / 500000000000) ((3571709551 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((723718052633 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((360073171541 : ℝ) / 250000000000) ((36016909699 : ℝ) / 25000000000) := rb_widen (rb_sub (show RB ((723718052633 : ℝ) / 500000000000) ((723718052633 : ℝ) / 500000000000) ((723718052633 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((223718052633 : ℝ) / 500000000000))
  have h19 : RB z19 ((1609495377343 : ℝ) / 500000000000) ((3219848311311 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((223718052633 : ℝ) / 500000000000) ((223718052633 : ℝ) / 500000000000) ((223718052633 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((292266970051 : ℝ) / 250000000000) ((1169334250159 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_496.1 dlower_log_497.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((228967684613 : ℝ) / 250000000000) ((460433027309 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((723718052633 : ℝ) / 500000000000))
  have h22 : RB z22 ((7395875761 : ℝ) / 20000000000) ((92448447013 : ℝ) / 250000000000) := rb_log (show RB ((723718052633 : ℝ) / 500000000000) ((723718052633 : ℝ) / 500000000000) ((723718052633 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_498.1 dlower_log_498.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((170649047 : ℝ) / 312500000) ((68884033321 : ℝ) / 125000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2738530889 : ℝ) / 250000000000) ((20197766427 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1082217499999 : ℝ) / 1000000000000) ((173523 : ℝ) / 160000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((146399339663 : ℝ) / 125000000000) ((588090459551 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1700418674983 : ℝ) / 1000000000000) ((853828987807 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1096250460433 : ℝ) / 1000000000000))
  have h28 : RB z28 ((932042377689 : ℝ) / 500000000000) ((1872020842029 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1096250460433 : ℝ) / 1000000000000) ((1096250460433 : ℝ) / 1000000000000) ((1096250460433 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3379858653 : ℝ) / 500000000000) ((3571709551 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((254159390991203138495289 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((2659637041 : ℝ) / 200000000000) ((14053030019 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((254159390991203138495289 : ℝ) / 500000000000000000000000) ((254159390991203138495289 : ℝ) / 500000000000000000000000) ((254159390991203138495289 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((985946969981 : ℝ) / 1000000000000) ((197340362959 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((28717011193 : ℝ) / 15625000000) ((369425272433 : ℝ) / 200000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((351185644833 : ℝ) / 1000000000000)) ((2346628427 : ℝ) / 200000000000) ((9725768143 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((723718052633 : ℝ) / 500000000000)) ((2738530889 : ℝ) / 250000000000) ((20197766427 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((351185644833 : ℝ) / 1000000000000)) (wl := ((723718052633 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((28717011193 : ℝ) / 15625000000) ≤ D0q (q) * (((723718052633 : ℝ) / 500000000000) - ((351185644833 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((723718052633 : ℝ) / 500000000000) * ((351185644833 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_34 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((109711610028072615597767956575027 : ℝ) / 1298074214633706907132624082305024) ((225397606628996867227687480144691 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((84518749999 : ℝ) / 1000000000000) ((4341 : ℝ) / 50000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1084518749999 : ℝ) / 1000000000000) ((54341 : ℝ) / 50000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((81136340207 : ℝ) / 1000000000000) ((83256001051 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_499.1 dlower_log_500.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((81136340207 : ℝ) / 500000000000) ((83256001051 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((526635178457 : ℝ) / 1000000000000) ((265437250073 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2470781875757 : ℝ) / 1000000000000) ((-2443918269109 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_501.1 dlower_log_502.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2443918269109 : ℝ) / 1000000000000) ((2470781875757 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((42629030399 : ℝ) / 200000000000) ((217222689833 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((782777310167 : ℝ) / 1000000000000) ((157370969601 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7143419101 : ℝ) / 1000000000000) ((18844281 : ℝ) / 2500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((172921968717 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((169153112517 : ℝ) / 500000000000) ((338700518333 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((172921968717 : ℝ) / 500000000000) ((172921968717 : ℝ) / 500000000000) ((172921968717 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((327078031283 : ℝ) / 500000000000))
  have h11 : RB z11 ((64645549509 : ℝ) / 125000000000) ((64720893399 : ℝ) / 125000000000) := rb_div_signed h10 (show RB ((327078031283 : ℝ) / 500000000000) ((327078031283 : ℝ) / 500000000000) ((327078031283 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-659394474223 : ℝ) / 1000000000000) ((-329114830291 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_503.1 dlower_log_504.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-518847738791 : ℝ) / 1000000000000) ((-257623621591 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((172921968717 : ℝ) / 500000000000))
  have h14 : RB z14 ((-1061767653557 : ℝ) / 1000000000000) ((-530883826777 : ℝ) / 500000000000) := rb_log (show RB ((172921968717 : ℝ) / 500000000000) ((172921968717 : ℝ) / 500000000000) ((172921968717 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_505.1 dlower_log_505.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((542919914763 : ℝ) / 1000000000000) ((4372163283 : ℝ) / 8000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((12045414617 : ℝ) / 1000000000000) ((9942615959 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7143419101 : ℝ) / 1000000000000) ((18844281 : ℝ) / 2500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((144917735953 : ℝ) / 100000000000)) - (z17)
  have h18 : RB z18 ((144163964713 : ℝ) / 100000000000) ((1442033940429 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((144917735953 : ℝ) / 100000000000) ((144917735953 : ℝ) / 100000000000) ((144917735953 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((44917735953 : ℝ) / 100000000000))
  have h19 : RB z19 ((3209510934919 : ℝ) / 1000000000000) ((3210388746971 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((44917735953 : ℝ) / 100000000000) ((44917735953 : ℝ) / 100000000000) ((44917735953 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((116611856881 : ℝ) / 100000000000) ((233278406957 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_506.1 dlower_log_507.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((228202789157 : ℝ) / 250000000000) ((183556245449 : ℝ) / 200000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((144917735953 : ℝ) / 100000000000))
  have h22 : RB z22 ((370996057179 : ℝ) / 1000000000000) ((370996057181 : ℝ) / 1000000000000) := rb_log (show RB ((144917735953 : ℝ) / 100000000000) ((144917735953 : ℝ) / 100000000000) ((144917735953 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_508.1 dlower_log_508.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((541815099447 : ℝ) / 1000000000000) ((273392585033 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((10940599301 : ℝ) / 1000000000000) ((20149991609 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1084518749999 : ℝ) / 1000000000000) ((54341 : ℝ) / 50000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1176180919099 : ℝ) / 1000000000000) ((2952944281 : ℝ) / 2500000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1693225311487 : ℝ) / 1000000000000) ((425104668747 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((68958338881 : ℝ) / 62500000000))
  have h28 : RB z28 ((934096038651 : ℝ) / 500000000000) ((1876128755671 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((68958338881 : ℝ) / 62500000000) ((68958338881 : ℝ) / 62500000000) ((68958338881 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7143419101 : ℝ) / 1000000000000) ((18844281 : ℝ) / 2500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((25059460203003132182301 : ℝ) / 50000000000000000000000))
  have h30 : RB z30 ((890808681 : ℝ) / 62500000000) ((3759913591 : ℝ) / 250000000000) := rb_div_signed h29 (show RB ((25059460203003132182301 : ℝ) / 50000000000000000000000) ((25059460203003132182301 : ℝ) / 50000000000000000000000) ((25059460203003132182301 : ℝ) / 50000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((246240086409 : ℝ) / 250000000000) ((61609191319 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1840095114173 : ℝ) / 1000000000000) ((462347101789 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((172921968717 : ℝ) / 500000000000)) ((12045414617 : ℝ) / 1000000000000) ((9942615959 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((144917735953 : ℝ) / 100000000000)) ((10940599301 : ℝ) / 1000000000000) ((20149991609 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((172921968717 : ℝ) / 500000000000)) (wl := ((144917735953 : ℝ) / 100000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1840095114173 : ℝ) / 1000000000000) ≤ D0q (q) * (((144917735953 : ℝ) / 100000000000) - ((172921968717 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((144917735953 : ℝ) / 100000000000) * ((172921968717 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_35 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((225397606628996867227687480144691 : ℝ) / 2596148429267413814265248164610048) ((462743986403697006519678094278655 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((86819999999 : ℝ) / 1000000000000) ((71297 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1086819999999 : ℝ) / 1000000000000) ((871297 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((83256001049 : ℝ) / 1000000000000) ((85371178433 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_509.1 dlower_log_510.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((83256001049 : ℝ) / 500000000000) ((85371178433 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((522404823693 : ℝ) / 1000000000000) ((263317589231 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2443918269123 : ℝ) / 1000000000000) ((-604439369217 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_511.1 dlower_log_512.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((604439369217 : ℝ) / 250000000000) ((2443918269123 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((42751415241 : ℝ) / 200000000000) ((108909843833 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((391090156167 : ℝ) / 500000000000) ((157248584759 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7537712399 : ℝ) / 1000000000000) ((3971298601 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((85129131991 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((166286965381 : ℝ) / 500000000000) ((66595763113 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((85129131991 : ℝ) / 250000000000) ((85129131991 : ℝ) / 250000000000) ((85129131991 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((164870868009 : ℝ) / 250000000000))
  have h11 : RB z11 ((252147282581 : ℝ) / 500000000000) ((126227126867 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((164870868009 : ℝ) / 250000000000) ((164870868009 : ℝ) / 250000000000) ((164870868009 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-85574340869 : ℝ) / 125000000000) ((-13667560789 : ℝ) / 20000000000) := rb_log h11 (by norm_num) dlower_log_513.1 dlower_log_514.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-269128879867 : ℝ) / 500000000000) ((-534524848339 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((85129131991 : ℝ) / 250000000000))
  have h14 : RB z14 ((-134661451787 : ℝ) / 125000000000) ((-269322903573 : ℝ) / 250000000000) := rb_log (show RB ((85129131991 : ℝ) / 250000000000) ((85129131991 : ℝ) / 250000000000) ((85129131991 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_515.1 dlower_log_515.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((269516927279 : ℝ) / 500000000000) ((542766765957 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((96864657 : ℝ) / 7812500000) ((2545242783 : ℝ) / 125000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7537712399 : ℝ) / 1000000000000) ((3971298601 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((725473661937 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((90187795417 : ℝ) / 62500000000) ((57736384459 : ℝ) / 40000000000) := rb_widen (rb_sub (show RB ((725473661937 : ℝ) / 500000000000) ((725473661937 : ℝ) / 500000000000) ((725473661937 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((225473661937 : ℝ) / 500000000000))
  have h19 : RB z19 ((639988153949 : ℝ) / 200000000000) ((3200838623623 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((225473661937 : ℝ) / 500000000000) ((225473661937 : ℝ) / 500000000000) ((225473661937 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((581566150089 : ℝ) / 500000000000) ((581706422677 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_516.1 dlower_log_517.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((454889592919 : ℝ) / 500000000000) ((114340639639 : ℝ) / 125000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((725473661937 : ℝ) / 500000000000))
  have h22 : RB z22 ((93054167479 : ℝ) / 250000000000) ((186108334959 : ℝ) / 500000000000) := rb_log (show RB ((725473661937 : ℝ) / 500000000000) ((725473661937 : ℝ) / 500000000000) ((725473661937 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_518.1 dlower_log_518.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((6719531449 : ℝ) / 12500000000) ((135627111799 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5463668729 : ℝ) / 500000000000) ((20103623503 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1086819999999 : ℝ) / 1000000000000) ((871297 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1181177712397 : ℝ) / 1000000000000) ((593092548601 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1686077497279 : ℝ) / 1000000000000) ((423306327873 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((111043079591 : ℝ) / 100000000000))
  have h28 : RB z28 ((1872272377269 : ℝ) / 1000000000000) ((235026191287 : ℝ) / 125000000000) := rb_widen (rb_mul h27 (show RB ((111043079591 : ℝ) / 100000000000) ((111043079591 : ℝ) / 100000000000) ((111043079591 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7537712399 : ℝ) / 1000000000000) ((3971298601 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((61758943123028985726567 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((7628158791 : ℝ) / 500000000000) ((16075803763 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((61758943123028985726567 : ℝ) / 125000000000000000000000) ((61758943123028985726567 : ℝ) / 125000000000000000000000) ((61758943123028985726567 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((983924196237 : ℝ) / 1000000000000) ((492371841209 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1842174093941 : ℝ) / 1000000000000) ((925762228291 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((85129131991 : ℝ) / 250000000000)) ((96864657 : ℝ) / 7812500000) ((2545242783 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((725473661937 : ℝ) / 500000000000)) ((5463668729 : ℝ) / 500000000000) ((20103623503 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((85129131991 : ℝ) / 250000000000)) (wl := ((725473661937 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1842174093941 : ℝ) / 1000000000000) ≤ D0q (q) * (((725473661937 : ℝ) / 500000000000) - ((85129131991 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((725473661937 : ℝ) / 500000000000) * ((85129131991 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
