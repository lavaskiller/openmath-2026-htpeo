import LeanProject.Symmetry

/-!
# EP-1038: corollaries requested by Lean RED Review 3 (L-14, L-16)

* `side_of_not_mem`, `atomize_of_not_mem` — the hypothesis of `atomize_abs` follows from
  `x ∉ I_j` for an order-connected `I_j` containing the roots (proof.md Lemma 7.2).
* `lemma11a_P` — Lemma 1.1(a) stated directly for `p ∈ 𝒫`.
-/

open Real Polynomial

namespace EP1038

theorem side_of_not_mem {n : ℕ} (I : Set ℝ) (hI : I.OrdConnected) (r : Fin n → ℝ)
    (hr : ∀ i, r i ∈ I) {x : ℝ} (hx : x ∉ I) : (∀ i, r i ≤ x) ∨ (∀ i, x ≤ r i) := by
  by_contra h
  simp only [not_or, not_forall, not_le] at h
  obtain ⟨⟨i, hi⟩, ⟨j, hj⟩⟩ := h
  exact hx (hI.out (hr j) (hr i) ⟨hj.le, hi.le⟩)

/-- Lemma 7.2, per-component Jensen step, in the form proof.md uses it. -/
theorem atomize_of_not_mem {n : ℕ} (hn : 0 < n) (I : Set ℝ) (hI : I.OrdConnected)
    (r : Fin n → ℝ) (hr : ∀ i, r i ∈ I) {x : ℝ} (hx : x ∉ I) :
    ∏ i, |x - r i| ≤ |x - (∑ i, r i) / n| ^ n :=
  atomize_abs hn r (side_of_not_mem I hI r hr hx)

/-- Lemma 1.1(a) for every `p ∈ 𝒫`. -/
theorem lemma11a_P (p : ℝ[X]) (hm : p.Monic) (hsplit : Multiset.card p.roots = p.natDegree)
    (hroots : ∀ r ∈ p.roots, r ∈ Set.Icc (-1 : ℝ) 1) :
    {x | |p.eval x| < 1} ⊆ Set.Ioo (-2) 2 := by
  have h := lemma11a p.roots hroots
  rwa [polyOf_of_split p hm hsplit] at h

end EP1038