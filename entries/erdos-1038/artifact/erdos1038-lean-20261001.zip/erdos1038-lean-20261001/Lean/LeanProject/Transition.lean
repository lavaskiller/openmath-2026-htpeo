import LeanProject.UpperMain

/-!
# EP-1038: the fixed-degree minima drop below 2 exactly at n = 4 (Phase I), fully formalised

* `fixed_degree_transition`: `m₁ = m₂ = m₃ = 2` (lower bounds, with minimisers) and `m₄ < 2`,
  witnessed by the quartic `(x + 1)(x - 1)^3`.
* `inf_lt_two`: some monic polynomial with all roots in `[-1, 1]` has `|S_f| < 2`
  (the Erdős–Herzog–Piranian observation `inf < 2`).
* `corner_upper_bounds`: `|S((x + 1)(x - 1)^m)| ≤ 1.9843136, 1.9032177, 1.8762680, 1.8716770`
  for `m = 3, …, 6`; since `corner m ∈ [-1, 1]^(m+1)` (`corner_mem`), these are upper bounds
  for `m₄, …, m₇` (Lean RED L-51).

Here `sublevel r = {x : |∏ (x - r_i)| < 1}` (Symmetry.lean), and `m_n` is the infimum of its
measure over `r : Fin n → [-1, 1]`.
-/

open Real MeasureTheory

namespace EP1038

theorem sublevel_fin2 (r : Fin 2 → ℝ) :
    sublevel r = {x : ℝ | |(x - r 0) * (x - r 1)| < 1} := by
  ext x; simp only [sublevel, Set.mem_ofPred_eq, Fin.prod_univ_two]

theorem corner3_lt_two : volume (sublevel (corner 3)) < ENNReal.ofReal 2 :=
  lt_of_le_of_lt Upper.upper3 ((ENNReal.ofReal_lt_ofReal_iff (by norm_num)).mpr (by norm_num))

/-- **`m₁ = m₂ = m₃ = 2 > m₄`.** -/
theorem fixed_degree_transition :
    (∀ r : Fin 1 → ℝ, volume (sublevel r) = ENNReal.ofReal 2) ∧
    (∀ r : Fin 2 → ℝ, (∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) →
      ENNReal.ofReal 2 ≤ volume (sublevel r) ∧
        (volume (sublevel r) = ENNReal.ofReal 2 ↔ r 0 = r 1)) ∧
    ((∀ r : Fin 3 → ℝ, (∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) → ENNReal.ofReal 2 ≤ volume (sublevel r)) ∧
      volume (sublevel (fun _ : Fin 3 => (0 : ℝ))) = ENNReal.ofReal 2) ∧
    ∃ r : Fin 4 → ℝ, (∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) ∧ volume (sublevel r) < ENNReal.ofReal 2 := by
  refine ⟨fun r => ?_, fun r hr => ?_, N3.m3_eq_two, corner 3, corner_mem 3, corner3_lt_two⟩
  · have : r = fun _ => r 0 := funext fun i => by rw [Subsingleton.elim i 0]
    rw [this]; exact volume_deg1 (r 0)
  · rw [sublevel_fin2]; exact deg2_ge_two (r 0) (r 1) (hr 0) (hr 1)

/-- `inf < 2` over all degrees. -/
theorem inf_lt_two :
    ∃ (n : ℕ) (r : Fin n → ℝ), (∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) ∧
      volume (sublevel r) < ENNReal.ofReal 2 :=
  ⟨4, corner 3, corner_mem 3, corner3_lt_two⟩

/-- `|S|` of the corner polynomials `(x + 1)(x - 1)^m`, `m = 3, …, 6`; as `corner m` has all
roots in `[-1, 1]`, these bound `m₄, …, m₇` from above. -/
theorem corner_upper_bounds :
    volume (sublevel (corner 3)) ≤ ENNReal.ofReal (19843136 / 10000000) ∧
    volume (sublevel (corner 4)) ≤ ENNReal.ofReal (19032177 / 10000000) ∧
    volume (sublevel (corner 5)) ≤ ENNReal.ofReal (18762680 / 10000000) ∧
    volume (sublevel (corner 6)) ≤ ENNReal.ofReal (18716770 / 10000000) :=
  ⟨Upper.upper3, Upper.upper4, Upper.upper5, Upper.upper6⟩

end EP1038
