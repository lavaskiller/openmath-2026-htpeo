import LeanProject.DerivativeDictionary
import LeanProject.NormalFormComponent

/-!
# From an arbitrary polynomial to the actual adjoint supporting bound

The separated reference remains an explicit input. All endpoint Poisson parameters,
their positive coefficients, the residual angular target, and the connection to
the already proved series derivative are constructed.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral Finset Polynomial
open scoped ENNReal

namespace EP1038.Stage11
open EP1038.Arc AngleReference

structure SeparatedReference where
  angles : AngleReference
  c : ℝ
  r : ℝ
  radius_pos : 0 < r
  left_pos : 0 < c - r
  end_eq_two : c + r = 2
  separator : ℝ
  separator_pos : 0 < separator
  separator_lt_left : separator < c - r
  separation : Stage10.RS angles.k (angles.quantile c r) <
    Stage10.PsiS angles.k (angles.quantile c r) separator

namespace SeparatedReference

noncomputable def quantile (R : SeparatedReference) : ℝ → ℝ := R.angles.quantile R.c R.r

theorem quantile_measurable (R : SeparatedReference) : Measurable R.quantile :=
  R.angles.quantile_measurable R.radius_pos.le

theorem quantile_lower (R : SeparatedReference) (u : ℝ) : R.c - R.r ≤ R.quantile u :=
  (R.angles.quantile_bounds R.radius_pos.le u).1

theorem quantile_upper (R : SeparatedReference) (u : ℝ) : R.quantile u ≤ 2 := by
  simpa only [quantile, R.end_eq_two] using
    (R.angles.quantile_bounds (c := R.c) R.radius_pos.le u).2

theorem xp_exterior (R : SeparatedReference) : Stage10.xpS R.angles.k R.quantile < R.c - R.r :=
  (Stage10.xp_lt_r R.quantile_measurable R.left_pos R.quantile_lower R.quantile_upper
    R.angles.k_pos R.separator_pos R.separator_lt_left R.separation).trans R.separator_lt_left

theorem xm_neg (R : SeparatedReference) : Stage10.xmS R.angles.k R.quantile < 0 :=
  (Stage10.sep_series R.quantile_measurable R.left_pos R.quantile_lower R.quantile_upper
    R.angles.k_pos R.separator_pos R.separator_lt_left R.separation).2.2.2.1

theorem xm_exterior (R : SeparatedReference) : Stage10.xmS R.angles.k R.quantile < R.c - R.r :=
  R.xm_neg.trans R.left_pos

theorem slope_plus_pos (R : SeparatedReference) :
    0 < R.angles.k * Stage10.GS R.angles.k R.quantile (Stage10.xpS R.angles.k R.quantile) := by
  obtain ⟨hp, hyc, _, _, _⟩ := Stage10.sep_series R.quantile_measurable R.left_pos
    R.quantile_lower R.quantile_upper R.angles.k_pos R.separator_pos R.separator_lt_left R.separation
  exact mul_pos R.angles.k_pos (Stage10.GS_pos_of_lt_yc R.quantile_measurable R.left_pos
    R.quantile_lower R.quantile_upper R.angles.k_pos hp hyc)

theorem slope_minus_neg (R : SeparatedReference) :
    R.angles.k * Stage10.GS R.angles.k R.quantile (Stage10.xmS R.angles.k R.quantile) < 0 := by
  have hJ := Stage10.JS_pos R.quantile_measurable R.left_pos R.quantile_lower R.quantile_upper R.xm_exterior
  have hneg : 1 / Stage10.xmS R.angles.k R.quantile < 0 := one_div_neg.mpr R.xm_neg
  have hpos : 0 < (1 / R.angles.k) * Stage10.JS R.quantile (Stage10.xmS R.angles.k R.quantile) :=
    mul_pos (one_div_pos.mpr R.angles.k_pos) hJ
  apply mul_neg_of_pos_of_neg R.angles.k_pos
  dsimp [Stage10.GS]
  linarith

noncomputable def rhoPlus (R : SeparatedReference) : ℝ :=
  exteriorParameter R.c R.r (Stage10.xpS R.angles.k R.quantile) R.radius_pos R.xp_exterior

noncomputable def rhoMinus (R : SeparatedReference) : ℝ :=
  exteriorParameter R.c R.r (Stage10.xmS R.angles.k R.quantile) R.radius_pos R.xm_exterior

noncomputable def sigmaPlus (R : SeparatedReference) : ℝ :=
  1 / (R.angles.k * Stage10.GS R.angles.k R.quantile (Stage10.xpS R.angles.k R.quantile))

noncomputable def sigmaMinus (R : SeparatedReference) : ℝ :=
  -(1 / (R.angles.k * Stage10.GS R.angles.k R.quantile (Stage10.xmS R.angles.k R.quantile)))

theorem rhoPlus_spec (R : SeparatedReference) : 0 < R.rhoPlus ∧ R.rhoPlus < 1 ∧
    Stage10.xpS R.angles.k R.quantile = R.c - R.r / 2 * (R.rhoPlus + 1 / R.rhoPlus) :=
  exteriorParameter_spec R.radius_pos R.xp_exterior

theorem rhoMinus_spec (R : SeparatedReference) : 0 < R.rhoMinus ∧ R.rhoMinus < 1 ∧
    Stage10.xmS R.angles.k R.quantile = R.c - R.r / 2 * (R.rhoMinus + 1 / R.rhoMinus) :=
  exteriorParameter_spec R.radius_pos R.xm_exterior

theorem sigmaPlus_pos (R : SeparatedReference) : 0 < R.sigmaPlus := one_div_pos.mpr R.slope_plus_pos

theorem sigmaMinus_pos (R : SeparatedReference) : 0 < R.sigmaMinus := neg_pos.mpr (one_div_neg.mpr R.slope_minus_neg)

/-- The derived adjoint coefficients are the actual endpoint coefficients of `Mdot`. -/
theorem Mdot_eq (R : SeparatedReference) (T : ℝ → ℝ) :
    Stage10.Mdot R.angles.k R.quantile T =
      widthVariation R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
        (R.angles.angularVelocity R.c R.r T) :=
  R.angles.Mdot_eq_widthVariation T R.radius_pos R.rhoPlus_spec.1 R.rhoPlus_spec.2.1
    R.rhoMinus_spec.1 R.rhoMinus_spec.2.1 R.rhoPlus_spec.2.2 R.rhoMinus_spec.2.2

/-- The new adjoint integral is bounded by the existing formal derivative for the actual target. -/
theorem residual_adjoint_le_Mdot {n : ℕ} (R : SeparatedReference)
    (a : EP1038.NormalForm.NormalData n) (hres : 0 < a.residualCount) :
    AdjointIntegrable R.rhoPlus R.rhoMinus (Bxi R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus)
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) ∧
      adjointIntegral R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
        (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) ≤
          Stage10.Mdot R.angles.k R.quantile (a.residualQuantile hres) := by
  rw [R.Mdot_eq]
  exact residual_quantile_adjoint a hres R.angles R.radius_pos R.end_eq_two
    R.rhoPlus_spec.1 R.rhoPlus_spec.2.1 R.rhoMinus_spec.1 R.rhoMinus_spec.2.1
    R.sigmaPlus_pos.le R.sigmaMinus_pos.le

end SeparatedReference

/-- All target and adjoint hypotheses are discharged. Only the separated reference is input. -/
theorem normal_form_adjoint_supporting {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (R : SeparatedReference) (hk : R.angles.k = a.k) :
    (volume (Stage10.correctedNegSet a.k R.quantile ∩ Iio R.separator)).toReal +
      adjointIntegral R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
        (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) ≤
          Resid.rhoR a.roots (a.roots a.main) - Resid.ellL a.roots (a.roots a.main) := by
  have hsep : Stage10.RS a.k R.quantile < Stage10.PsiS a.k R.quantile R.separator := by
    rw [← hk]; exact R.separation
  have hs := EP1038.NormalForm.supporting_inequality_normal_form a hres R.quantile_measurable
    R.left_pos R.quantile_lower R.quantile_upper R.separator_pos R.separator_lt_left hsep
  have hi := (R.residual_adjoint_le_Mdot a hres).2
  rw [hk] at hi
  linarith

/-- Arbitrary-polynomial supporting reduction with the actual adjoint integral.
No angular target, Poisson endpoint parameter, or derivative equality is assumed. -/
theorem polynomial_adjoint_reduction {p : ℝ[X]} (hp : EP1038.Admissible p) :
    ENNReal.ofReal 2 ≤ EP1038.sublevelMeasure p ∨
      ∃ n : ℕ, ∃ a : EP1038.NormalForm.NormalData n, ∃ hres : 0 < a.residualCount,
        1 ≤ a.k ∧ a.J ≤ (EP1038.sublevelMeasure p).toReal ∧
          ∀ R : SeparatedReference, R.angles.k = a.k →
            (volume (Stage10.correctedNegSet a.k R.quantile ∩ Iio R.separator)).toReal +
              adjointIntegral R.r R.rhoPlus R.rhoMinus R.sigmaPlus R.sigmaMinus
                (R.angles.angularVelocity R.c R.r (a.residualQuantile hres)) +
                  2 * ∑ v ∈ a.residualIndices.image a.roots, Stage7.Rv a.roots v ≤
                    (EP1038.sublevelMeasure p).toReal := by
  classical
  rcases EP1038.NormalForm.polynomial_supporting_reduction hp with hbig |
    ⟨n, a, hres, hk, hJ, hs⟩
  · exact Or.inl hbig
  refine Or.inr ⟨n, a, hres, hk, hJ, ?_⟩
  intro R hR
  have hsep : Stage10.RS a.k R.quantile < Stage10.PsiS a.k R.quantile R.separator := by
    rw [← hR]; exact R.separation
  have h := hs R.quantile (R.c - R.r) R.separator R.quantile_measurable R.left_pos
    R.quantile_lower R.quantile_upper R.separator_pos R.separator_lt_left hsep
  have hi := (R.residual_adjoint_le_Mdot a hres).2
  rw [hR] at hi
  linarith

end EP1038.Stage11
