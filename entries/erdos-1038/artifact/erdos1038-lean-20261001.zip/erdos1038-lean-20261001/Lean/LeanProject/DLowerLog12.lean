import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog09
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_720 : RB (Real.log ((897071 : ℝ) / 800000)) ((114523283989 : ℝ) / 1000000000000) ((11452328399 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((897071 : ℝ) / 800000)) (t := ((97071 : ℝ) / 1697071))
    (lo := ((114523283989 : ℝ) / 1000000000000)) (hi := ((11452328399 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_721 : RB (Real.log ((120763437499 : ℝ) / 1000000000000)) ((-1056960854503 : ℝ) / 500000000000) ((-528480427251 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((120763437499 : ℝ) / 125000000000)) (t := ((-4236562501 : ℝ) / 245763437499))
    (lo := ((-17240083663 : ℝ) / 500000000000)) (hi := ((-1379206693 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((120763437499 : ℝ) / 1000000000000) = Real.log ((120763437499 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((120763437499 : ℝ) / 1000000000000) = ((120763437499 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_722 : RB (Real.log ((97071 : ℝ) / 800000)) ((-2109169058153 : ℝ) / 1000000000000) ((-2109169058151 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((97071 : ℝ) / 100000)) (t := ((-2929 : ℝ) / 197071))
    (lo := ((-29727516473 : ℝ) / 1000000000000)) (hi := ((-3715939559 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97071 : ℝ) / 800000) = Real.log ((97071 : ℝ) / 100000) - 3 * Real.log 2 := by
    rw [show ((97071 : ℝ) / 800000) = ((97071 : ℝ) / 100000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_723 : RB (Real.log ((65154390923 : ℝ) / 200000000000)) ((-1121557668119 : ℝ) / 1000000000000) ((-1121557668117 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((65154390923 : ℝ) / 50000000000)) (t := ((15154390923 : ℝ) / 115154390923))
    (lo := ((264736693001 : ℝ) / 1000000000000)) (hi := ((132368346501 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65154390923 : ℝ) / 200000000000) = Real.log ((65154390923 : ℝ) / 50000000000) - 2 * Real.log 2 := by
    rw [show ((65154390923 : ℝ) / 200000000000) = ((65154390923 : ℝ) / 50000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_724 : RB (Real.log ((81489843343 : ℝ) / 250000000000)) ((-56049126347 : ℝ) / 50000000000) ((-560491263469 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((81489843343 : ℝ) / 62500000000)) (t := ((18989843343 : ℝ) / 143989843343))
    (lo := ((13265591709 : ℝ) / 50000000000)) (hi := ((265311834181 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((81489843343 : ℝ) / 250000000000) = Real.log ((81489843343 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((81489843343 : ℝ) / 250000000000) = ((81489843343 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_725 : RB (Real.log ((256827764143 : ℝ) / 1000000000000)) ((-1359349597189 : ℝ) / 1000000000000) ((-1359349597187 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((256827764143 : ℝ) / 250000000000)) (t := ((6827764143 : ℝ) / 506827764143))
    (lo := ((26944763931 : ℝ) / 1000000000000)) (hi := ((6736190983 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((256827764143 : ℝ) / 1000000000000) = Real.log ((256827764143 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((256827764143 : ℝ) / 1000000000000) = ((256827764143 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_726 : RB (Real.log ((3028449203481 : ℝ) / 1000000000000)) ((554025337233 : ℝ) / 500000000000) ((277012668617 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3028449203481 : ℝ) / 4000000000000)) (t := ((-971550796519 : ℝ) / 7028449203481))
    (lo := ((-278243686653 : ℝ) / 1000000000000)) (hi := ((-69560921663 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3028449203481 : ℝ) / 1000000000000) = Real.log ((3028449203481 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3028449203481 : ℝ) / 1000000000000) = ((3028449203481 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_727 : RB (Real.log ((151436797837 : ℝ) / 50000000000)) ((277036339121 : ℝ) / 250000000000) ((554072678243 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((151436797837 : ℝ) / 200000000000)) (t := ((-48563202163 : ℝ) / 351436797837))
    (lo := ((-55629800927 : ℝ) / 200000000000)) (hi := ((-139074502317 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((151436797837 : ℝ) / 50000000000) = Real.log ((151436797837 : ℝ) / 200000000000) + 2 * Real.log 2 := by
    rw [show ((151436797837 : ℝ) / 50000000000) = ((151436797837 : ℝ) / 200000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_728 : RB (Real.log ((1485729150159 : ℝ) / 1000000000000)) ((79181132391 : ℝ) / 200000000000) ((395905661957 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1485729150159 : ℝ) / 2000000000000)) (t := ((-514270849841 : ℝ) / 3485729150159))
    (lo := ((-74310379651 : ℝ) / 250000000000)) (hi := ((-297241518603 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1485729150159 : ℝ) / 1000000000000) = Real.log ((1485729150159 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1485729150159 : ℝ) / 1000000000000) = ((1485729150159 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_729 : RB (Real.log ((1121338749999 : ℝ) / 1000000000000)) ((28630820997 : ℝ) / 250000000000) ((114523283989 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1121338749999 : ℝ) / 1000000000000)) (t := ((121338749999 : ℝ) / 2121338749999))
    (lo := ((28630820997 : ℝ) / 250000000000)) (hi := ((114523283989 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_730 : RB (Real.log ((28721 : ℝ) / 25600)) ((115036211029 : ℝ) / 1000000000000) ((11503621103 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((28721 : ℝ) / 25600)) (t := ((3121 : ℝ) / 54321))
    (lo := ((115036211029 : ℝ) / 1000000000000)) (hi := ((11503621103 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_731 : RB (Real.log ((121338749999 : ℝ) / 1000000000000)) ((-1054584529081 : ℝ) / 500000000000) ((-26364613227 : ℝ) / 12500000000) := by
  have hm := log_bounds_of_series (x := ((121338749999 : ℝ) / 125000000000)) (t := ((-3661250001 : ℝ) / 246338749999))
    (lo := ((-14863758241 : ℝ) / 500000000000)) (hi := ((-29727516481 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((121338749999 : ℝ) / 1000000000000) = Real.log ((121338749999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((121338749999 : ℝ) / 1000000000000) = ((121338749999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_732 : RB (Real.log ((3121 : ℝ) / 25600)) ((-1052219444099 : ℝ) / 500000000000) ((-526109722049 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3121 : ℝ) / 3200)) (t := ((-79 : ℝ) / 6321))
    (lo := ((-12498673259 : ℝ) / 500000000000)) (hi := ((-24997346517 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3121 : ℝ) / 25600) = Real.log ((3121 : ℝ) / 3200) - 3 * Real.log 2 := by
    rw [show ((3121 : ℝ) / 25600) = ((3121 : ℝ) / 3200) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_733 : RB (Real.log ((91951636939 : ℝ) / 250000000000)) ((-48837801 : ℝ) / 48828125) ((-500099082239 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((91951636939 : ℝ) / 125000000000)) (t := ((-33048363061 : ℝ) / 216951636939))
    (lo := ((-3838137299 : ℝ) / 12500000000)) (hi := ((-307050983919 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91951636939 : ℝ) / 250000000000) = Real.log ((91951636939 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((91951636939 : ℝ) / 250000000000) = ((91951636939 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_734 : RB (Real.log ((18400042767 : ℝ) / 50000000000)) ((-999670016523 : ℝ) / 1000000000000) ((-999670016521 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((18400042767 : ℝ) / 25000000000)) (t := ((-6599957233 : ℝ) / 43400042767))
    (lo := ((-306522835963 : ℝ) / 1000000000000)) (hi := ((-153261417981 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((18400042767 : ℝ) / 50000000000) = Real.log ((18400042767 : ℝ) / 25000000000) - 1 * Real.log 2 := by
    rw [show ((18400042767 : ℝ) / 50000000000) = ((18400042767 : ℝ) / 25000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_735 : RB (Real.log ((69942198153 : ℝ) / 250000000000)) ((-1273791757597 : ℝ) / 1000000000000) ((-254758351519 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((69942198153 : ℝ) / 62500000000)) (t := ((7442198153 : ℝ) / 132442198153))
    (lo := ((112502603523 : ℝ) / 1000000000000)) (hi := ((28125650881 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((69942198153 : ℝ) / 250000000000) = Real.log ((69942198153 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((69942198153 : ℝ) / 250000000000) = ((69942198153 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_736 : RB (Real.log ((3025906983757 : ℝ) / 1000000000000)) ((1107210875883 : ℝ) / 1000000000000) ((221442175177 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3025906983757 : ℝ) / 4000000000000)) (t := ((-974093016243 : ℝ) / 7025906983757))
    (lo := ((-69770871309 : ℝ) / 250000000000)) (hi := ((-55816697047 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3025906983757 : ℝ) / 1000000000000) = Real.log ((3025906983757 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3025906983757 : ℝ) / 1000000000000) = ((3025906983757 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_737 : RB (Real.log ((1513097389819 : ℝ) / 500000000000)) ((1107305981977 : ℝ) / 1000000000000) ((1107305981979 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1513097389819 : ℝ) / 2000000000000)) (t := ((-486902610181 : ℝ) / 3513097389819))
    (lo := ((-139494189571 : ℝ) / 500000000000)) (hi := ((-278988379141 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1513097389819 : ℝ) / 500000000000) = Real.log ((1513097389819 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1513097389819 : ℝ) / 500000000000) = ((1513097389819 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_738 : RB (Real.log ((743134795739 : ℝ) / 500000000000)) ((396269350753 : ℝ) / 1000000000000) ((79253870151 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((743134795739 : ℝ) / 1000000000000)) (t := ((-256865204261 : ℝ) / 1743134795739))
    (lo := ((-148438914903 : ℝ) / 500000000000)) (hi := ((-59375565961 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((743134795739 : ℝ) / 500000000000) = Real.log ((743134795739 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((743134795739 : ℝ) / 500000000000) = ((743134795739 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_739 : RB (Real.log ((1121914062499 : ℝ) / 1000000000000)) ((28759052757 : ℝ) / 250000000000) ((115036211029 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1121914062499 : ℝ) / 1000000000000)) (t := ((121914062499 : ℝ) / 2121914062499))
    (lo := ((28759052757 : ℝ) / 250000000000)) (hi := ((115036211029 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_740 : RB (Real.log ((7182091 : ℝ) / 6400000)) ((115292575923 : ℝ) / 1000000000000) ((28823143981 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((7182091 : ℝ) / 6400000)) (t := ((782091 : ℝ) / 13582091))
    (lo := ((115292575923 : ℝ) / 1000000000000)) (hi := ((28823143981 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_741 : RB (Real.log ((121914062499 : ℝ) / 1000000000000)) ((-1052219444103 : ℝ) / 500000000000) ((-526109722051 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((121914062499 : ℝ) / 125000000000)) (t := ((-3085937501 : ℝ) / 246914062499))
    (lo := ((-12498673263 : ℝ) / 500000000000)) (hi := ((-999893861 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((121914062499 : ℝ) / 1000000000000) = Real.log ((121914062499 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((121914062499 : ℝ) / 1000000000000) = ((121914062499 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_742 : RB (Real.log ((782091 : ℝ) / 6400000)) ((-2102082167287 : ℝ) / 1000000000000) ((-420416433457 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((782091 : ℝ) / 800000)) (t := ((-17909 : ℝ) / 1582091))
    (lo := ((-22640625607 : ℝ) / 1000000000000)) (hi := ((-11320312803 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((782091 : ℝ) / 6400000) = Real.log ((782091 : ℝ) / 800000) - 3 * Real.log 2 := by
    rw [show ((782091 : ℝ) / 6400000) = ((782091 : ℝ) / 800000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_743 : RB (Real.log ((137745808011 : ℝ) / 500000000000)) ((-257839616543 : ℝ) / 200000000000) ((-1289198082713 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((137745808011 : ℝ) / 125000000000)) (t := ((12745808011 : ℝ) / 262745808011))
    (lo := ((19419255681 : ℝ) / 200000000000)) (hi := ((48548139203 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((137745808011 : ℝ) / 500000000000) = Real.log ((137745808011 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((137745808011 : ℝ) / 500000000000) = ((137745808011 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_744 : RB (Real.log ((275582540671 : ℝ) / 1000000000000)) ((-12888680921 : ℝ) / 10000000000) ((-644434046049 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((275582540671 : ℝ) / 250000000000)) (t := ((25582540671 : ℝ) / 525582540671))
    (lo := ((4871313451 : ℝ) / 50000000000)) (hi := ((97426269021 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((275582540671 : ℝ) / 1000000000000) = Real.log ((275582540671 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((275582540671 : ℝ) / 1000000000000) = ((275582540671 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_745 : RB (Real.log ((113848210541 : ℝ) / 500000000000)) ((-1479742023727 : ℝ) / 1000000000000) ((-59189680949 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((113848210541 : ℝ) / 125000000000)) (t := ((-11151789459 : ℝ) / 238848210541))
    (lo := ((-93447662607 : ℝ) / 1000000000000)) (hi := ((-46723831303 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((113848210541 : ℝ) / 500000000000) = Real.log ((113848210541 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((113848210541 : ℝ) / 500000000000) = ((113848210541 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_746 : RB (Real.log ((603919259107 : ℝ) / 200000000000)) ((44204925819 : ℝ) / 40000000000) ((1105123145477 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((603919259107 : ℝ) / 800000000000)) (t := ((-196080740893 : ℝ) / 1403919259107))
    (lo := ((-70292803911 : ℝ) / 250000000000)) (hi := ((-281171215643 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((603919259107 : ℝ) / 200000000000) = Real.log ((603919259107 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((603919259107 : ℝ) / 200000000000) = ((603919259107 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_747 : RB (Real.log ((3019740264403 : ℝ) / 1000000000000)) ((552585411261 : ℝ) / 500000000000) ((276292705631 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3019740264403 : ℝ) / 4000000000000)) (t := ((-980259735597 : ℝ) / 7019740264403))
    (lo := ((-281123538597 : ℝ) / 1000000000000)) (hi := ((-70280884649 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3019740264403 : ℝ) / 1000000000000) = Real.log ((3019740264403 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3019740264403 : ℝ) / 1000000000000) = ((3019740264403 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_748 : RB (Real.log ((1487754281443 : ℝ) / 1000000000000)) ((79453557867 : ℝ) / 200000000000) ((397267789337 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1487754281443 : ℝ) / 2000000000000)) (t := ((-512245718557 : ℝ) / 3487754281443))
    (lo := ((-36984923903 : ℝ) / 125000000000)) (hi := ((-295879391223 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1487754281443 : ℝ) / 1000000000000) = Real.log ((1487754281443 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1487754281443 : ℝ) / 1000000000000) = ((1487754281443 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_749 : RB (Real.log ((1122201718749 : ℝ) / 1000000000000)) ((57646287961 : ℝ) / 500000000000) ((115292575923 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1122201718749 : ℝ) / 1000000000000)) (t := ((122201718749 : ℝ) / 2122201718749))
    (lo := ((57646287961 : ℝ) / 500000000000)) (hi := ((115292575923 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_750 : RB (Real.log ((1795983 : ℝ) / 1600000)) ((11554887511 : ℝ) / 100000000000) ((115548875111 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1795983 : ℝ) / 1600000)) (t := ((195983 : ℝ) / 3395983))
    (lo := ((11554887511 : ℝ) / 100000000000)) (hi := ((115548875111 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_751 : RB (Real.log ((122201718749 : ℝ) / 1000000000000)) ((-420416433459 : ℝ) / 200000000000) ((-2102082167293 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((122201718749 : ℝ) / 125000000000)) (t := ((-2798281251 : ℝ) / 247201718749))
    (lo := ((-4528125123 : ℝ) / 200000000000)) (hi := ((-11320312807 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((122201718749 : ℝ) / 1000000000000) = Real.log ((122201718749 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((122201718749 : ℝ) / 1000000000000) = ((122201718749 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_752 : RB (Real.log ((195983 : ℝ) / 1600000)) ((-1049865493727 : ℝ) / 500000000000) ((-524932746863 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((195983 : ℝ) / 200000)) (t := ((-4017 : ℝ) / 395983))
    (lo := ((-10144722887 : ℝ) / 500000000000)) (hi := ((-20289445773 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195983 : ℝ) / 1600000) = Real.log ((195983 : ℝ) / 200000) - 3 * Real.log 2 := by
    rw [show ((195983 : ℝ) / 1600000) = ((195983 : ℝ) / 200000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_753 : RB (Real.log ((149265348197 : ℝ) / 500000000000)) ((-1208882515947 : ℝ) / 1000000000000) ((-241776503189 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((149265348197 : ℝ) / 125000000000)) (t := ((24265348197 : ℝ) / 274265348197))
    (lo := ((177411845173 : ℝ) / 1000000000000)) (hi := ((88705922587 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((149265348197 : ℝ) / 500000000000) = Real.log ((149265348197 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((149265348197 : ℝ) / 500000000000) = ((149265348197 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_754 : RB (Real.log ((298623488191 : ℝ) / 1000000000000)) ((-302142933979 : ℝ) / 250000000000) ((-604285867957 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((298623488191 : ℝ) / 250000000000)) (t := ((48623488191 : ℝ) / 548623488191))
    (lo := ((44430656301 : ℝ) / 250000000000)) (hi := ((35544525041 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((298623488191 : ℝ) / 1000000000000) = Real.log ((298623488191 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((298623488191 : ℝ) / 1000000000000) = ((298623488191 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_755 : RB (Real.log ((60363290651 : ℝ) / 250000000000)) ((-88817485523 : ℝ) / 62500000000) ((-710539884183 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((60363290651 : ℝ) / 62500000000)) (t := ((-2136709349 : ℝ) / 122863290651))
    (lo := ((-2174087953 : ℝ) / 62500000000)) (hi := ((-34785407247 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((60363290651 : ℝ) / 250000000000) = Real.log ((60363290651 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((60363290651 : ℝ) / 250000000000) = ((60363290651 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_756 : RB (Real.log ((603665579569 : ℝ) / 200000000000)) ((13808787523 : ℝ) / 12500000000) ((552351500921 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((603665579569 : ℝ) / 800000000000)) (t := ((-196334420431 : ℝ) / 1403665579569))
    (lo := ((-281591359279 : ℝ) / 1000000000000)) (hi := ((-140795679639 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((603665579569 : ℝ) / 200000000000) = Real.log ((603665579569 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((603665579569 : ℝ) / 200000000000) = ((603665579569 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_757 : RB (Real.log ((37730901571 : ℝ) / 12500000000)) ((276187696179 : ℝ) / 250000000000) ((552375392359 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((37730901571 : ℝ) / 50000000000)) (t := ((-12269098429 : ℝ) / 87730901571))
    (lo := ((-281543576403 : ℝ) / 1000000000000)) (hi := ((-140771788201 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((37730901571 : ℝ) / 12500000000) = Real.log ((37730901571 : ℝ) / 50000000000) + 2 * Real.log 2 := by
    rw [show ((37730901571 : ℝ) / 12500000000) = ((37730901571 : ℝ) / 50000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_758 : RB (Real.log ((744012965897 : ℝ) / 500000000000)) ((397450363539 : ℝ) / 1000000000000) ((397450363541 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((744012965897 : ℝ) / 1000000000000)) (t := ((-255987034103 : ℝ) / 1744012965897))
    (lo := ((-14784840851 : ℝ) / 50000000000)) (hi := ((-295696817019 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((744012965897 : ℝ) / 500000000000) = Real.log ((744012965897 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((744012965897 : ℝ) / 500000000000) = ((744012965897 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_759 : RB (Real.log ((1122489374999 : ℝ) / 1000000000000)) ((115548875109 : ℝ) / 1000000000000) ((11554887511 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((1122489374999 : ℝ) / 1000000000000)) (t := ((122489374999 : ℝ) / 2122489374999))
    (lo := ((115548875109 : ℝ) / 1000000000000)) (hi := ((11554887511 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_760 : RB (Real.log ((7185773 : ℝ) / 6400000)) ((926440869 : ℝ) / 8000000000) ((57902554313 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((7185773 : ℝ) / 6400000)) (t := ((785773 : ℝ) / 13585773))
    (lo := ((926440869 : ℝ) / 8000000000)) (hi := ((57902554313 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_761 : RB (Real.log ((122489374999 : ℝ) / 1000000000000)) ((-1049865493731 : ℝ) / 500000000000) ((-104986549373 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((122489374999 : ℝ) / 125000000000)) (t := ((-2510625001 : ℝ) / 247489374999))
    (lo := ((-10144722891 : ℝ) / 500000000000)) (hi := ((-20289445781 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((122489374999 : ℝ) / 1000000000000) = Real.log ((122489374999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((122489374999 : ℝ) / 1000000000000) = ((122489374999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_762 : RB (Real.log ((785773 : ℝ) / 6400000)) ((-1048692661351 : ℝ) / 500000000000) ((-20973853227 : ℝ) / 10000000000) := by
  have hm := log_bounds_of_series (x := ((785773 : ℝ) / 800000)) (t := ((-14227 : ℝ) / 1585773))
    (lo := ((-8971890511 : ℝ) / 500000000000)) (hi := ((-17943781021 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((785773 : ℝ) / 6400000) = Real.log ((785773 : ℝ) / 800000) - 3 * Real.log 2 := by
    rw [show ((785773 : ℝ) / 6400000) = ((785773 : ℝ) / 800000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_763 : RB (Real.log ((85506561449 : ℝ) / 250000000000)) ((-268216950693 : ℝ) / 250000000000) ((-67054237673 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((85506561449 : ℝ) / 125000000000)) (t := ((-39493438551 : ℝ) / 210506561449))
    (lo := ((-94930155553 : ℝ) / 250000000000)) (hi := ((-379720622209 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85506561449 : ℝ) / 250000000000) = Real.log ((85506561449 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((85506561449 : ℝ) / 250000000000) = ((85506561449 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_764 : RB (Real.log ((342122378109 : ℝ) / 1000000000000)) ((-1072586775199 : ℝ) / 1000000000000) ((-214517355039 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((342122378109 : ℝ) / 500000000000)) (t := ((-157877621891 : ℝ) / 842122378109))
    (lo := ((-379439594639 : ℝ) / 1000000000000)) (hi := ((-94859898659 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342122378109 : ℝ) / 1000000000000) = Real.log ((342122378109 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((342122378109 : ℝ) / 1000000000000) = ((342122378109 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_765 : RB (Real.log ((266090507781 : ℝ) / 1000000000000)) ((-1323918773259 : ℝ) / 1000000000000) ((-1323918773257 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((266090507781 : ℝ) / 250000000000)) (t := ((16090507781 : ℝ) / 516090507781))
    (lo := ((62375587861 : ℝ) / 1000000000000)) (hi := ((31187793931 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((266090507781 : ℝ) / 1000000000000) = Real.log ((266090507781 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((266090507781 : ℝ) / 1000000000000) = ((266090507781 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_766 : RB (Real.log ((1508529564617 : ℝ) / 500000000000)) ((1104282558669 : ℝ) / 1000000000000) ((1104282558671 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1508529564617 : ℝ) / 2000000000000)) (t := ((-491470435383 : ℝ) / 3508529564617))
    (lo := ((-5640236049 : ℝ) / 20000000000)) (hi := ((-282011802449 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1508529564617 : ℝ) / 500000000000) = Real.log ((1508529564617 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1508529564617 : ℝ) / 500000000000) = ((1508529564617 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_767 : RB (Real.log ((3017203615647 : ℝ) / 1000000000000)) ((55216522367 : ℝ) / 50000000000) ((552165223671 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3017203615647 : ℝ) / 4000000000000)) (t := ((-982796384353 : ℝ) / 7017203615647))
    (lo := ((-281963913779 : ℝ) / 1000000000000)) (hi := ((-140981956889 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3017203615647 : ℝ) / 1000000000000) = Real.log ((3017203615647 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3017203615647 : ℝ) / 1000000000000) = ((3017203615647 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_768 : RB (Real.log ((1488297931539 : ℝ) / 1000000000000)) ((49704142397 : ℝ) / 125000000000) ((198816569589 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1488297931539 : ℝ) / 2000000000000)) (t := ((-511702068461 : ℝ) / 3488297931539))
    (lo := ((-295514041383 : ℝ) / 1000000000000)) (hi := ((-147757020691 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1488297931539 : ℝ) / 1000000000000) = Real.log ((1488297931539 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1488297931539 : ℝ) / 1000000000000) = ((1488297931539 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_769 : RB (Real.log ((1122777031249 : ℝ) / 1000000000000)) ((7237819289 : ℝ) / 62500000000) ((926440869 : ℝ) / 8000000000) := by
  have hm := log_bounds_of_series (x := ((1122777031249 : ℝ) / 1000000000000)) (t := ((122777031249 : ℝ) / 2122777031249))
    (lo := ((7237819289 : ℝ) / 62500000000)) (hi := ((926440869 : ℝ) / 8000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_770 : RB (Real.log ((14373387 : ℝ) / 12800000)) ((57966600383 : ℝ) / 500000000000) ((115933200767 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((14373387 : ℝ) / 12800000)) (t := ((1573387 : ℝ) / 27173387))
    (lo := ((57966600383 : ℝ) / 500000000000)) (hi := ((115933200767 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_771 : RB (Real.log ((122777031249 : ℝ) / 1000000000000)) ((-2097385322711 : ℝ) / 1000000000000) ((-2097385322709 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((122777031249 : ℝ) / 125000000000)) (t := ((-2222968751 : ℝ) / 247777031249))
    (lo := ((-17943781031 : ℝ) / 1000000000000)) (hi := ((-1794378103 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((122777031249 : ℝ) / 1000000000000) = Real.log ((122777031249 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((122777031249 : ℝ) / 1000000000000) = ((122777031249 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_772 : RB (Real.log ((1573387 : ℝ) / 12800000)) ((-2096214550409 : ℝ) / 1000000000000) ((-2096214550407 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1573387 : ℝ) / 1600000)) (t := ((-26613 : ℝ) / 3173387))
    (lo := ((-16773008729 : ℝ) / 1000000000000)) (hi := ((-2096626091 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1573387 : ℝ) / 12800000) = Real.log ((1573387 : ℝ) / 1600000) - 3 * Real.log 2 := by
    rw [show ((1573387 : ℝ) / 12800000) = ((1573387 : ℝ) / 1600000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_773 : RB (Real.log ((64217159727 : ℝ) / 250000000000)) ((-679595228707 : ℝ) / 500000000000) ((-339797614353 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((64217159727 : ℝ) / 62500000000)) (t := ((1717159727 : ℝ) / 126717159727))
    (lo := ((13551951853 : ℝ) / 500000000000)) (hi := ((27103903707 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64217159727 : ℝ) / 250000000000) = Real.log ((64217159727 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((64217159727 : ℝ) / 250000000000) = ((64217159727 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_774 : RB (Real.log ((32114216983 : ℝ) / 125000000000)) ((-27180298171 : ℝ) / 20000000000) ((-339753727137 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((32114216983 : ℝ) / 31250000000)) (t := ((864216983 : ℝ) / 63364216983))
    (lo := ((2727945257 : ℝ) / 100000000000)) (hi := ((27279452571 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32114216983 : ℝ) / 125000000000) = Real.log ((32114216983 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((32114216983 : ℝ) / 125000000000) = ((32114216983 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_775 : RB (Real.log ((216393478331 : ℝ) / 1000000000000)) ((-1530656869567 : ℝ) / 1000000000000) ((-306131373913 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((216393478331 : ℝ) / 250000000000)) (t := ((-33606521669 : ℝ) / 466393478331))
    (lo := ((-144362508447 : ℝ) / 1000000000000)) (hi := ((-72181254223 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((216393478331 : ℝ) / 1000000000000) = Real.log ((216393478331 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((216393478331 : ℝ) / 1000000000000) = ((216393478331 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_776 : RB (Real.log ((1506959630413 : ℝ) / 500000000000)) ((1103241311797 : ℝ) / 1000000000000) ((1103241311799 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1506959630413 : ℝ) / 2000000000000)) (t := ((-493040369587 : ℝ) / 3506959630413))
    (lo := ((-141526524661 : ℝ) / 500000000000)) (hi := ((-283053049321 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1506959630413 : ℝ) / 500000000000) = Real.log ((1506959630413 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1506959630413 : ℝ) / 500000000000) = ((1506959630413 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_777 : RB (Real.log ((376748940133 : ℝ) / 125000000000)) ((220653057403 : ℝ) / 200000000000) ((1103265287017 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((376748940133 : ℝ) / 500000000000)) (t := ((-123251059867 : ℝ) / 876748940133))
    (lo := ((-35378634263 : ℝ) / 125000000000)) (hi := ((-283029074103 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((376748940133 : ℝ) / 125000000000) = Real.log ((376748940133 : ℝ) / 500000000000) + 2 * Real.log 2 := by
    rw [show ((376748940133 : ℝ) / 125000000000) = ((376748940133 : ℝ) / 500000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_778 : RB (Real.log ((1489041681803 : ℝ) / 1000000000000)) ((19906637323 : ℝ) / 50000000000) ((199066373231 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1489041681803 : ℝ) / 2000000000000)) (t := ((-510958318197 : ℝ) / 3489041681803))
    (lo := ((-295014434099 : ℝ) / 1000000000000)) (hi := ((-147507217049 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1489041681803 : ℝ) / 1000000000000) = Real.log ((1489041681803 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1489041681803 : ℝ) / 1000000000000) = ((1489041681803 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_779 : RB (Real.log ((561460429687 : ℝ) / 500000000000)) ((23186640153 : ℝ) / 200000000000) ((57966600383 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((561460429687 : ℝ) / 500000000000)) (t := ((61460429687 : ℝ) / 1061460429687))
    (lo := ((23186640153 : ℝ) / 200000000000)) (hi := ((57966600383 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
