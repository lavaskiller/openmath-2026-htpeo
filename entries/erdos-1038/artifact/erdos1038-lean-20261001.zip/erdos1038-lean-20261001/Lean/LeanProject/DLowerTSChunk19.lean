import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk16
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_60 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((636001197016394451452073537123123 : ℝ) / 5192296858534827628530496329220096) ((318747396829803680230055714435891 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((122489374999 : ℝ) / 1000000000000) ((785773 : ℝ) / 6400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1122489374999 : ℝ) / 1000000000000) ((7185773 : ℝ) / 6400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((115548875109 : ℝ) / 1000000000000) ((57902554313 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_759.1 dlower_log_760.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((115548875109 : ℝ) / 500000000000) ((57902554313 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((461536963307 : ℝ) / 1000000000000) ((231024715171 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1049865493731 : ℝ) / 500000000000) ((-20973853227 : ℝ) / 10000000000) := rb_log hqr (by norm_num) dlower_log_761.1 dlower_log_762.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((20973853227 : ℝ) / 10000000000) ((1049865493731 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((54951915991 : ℝ) / 250000000000) ((220297827653 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779702172347 : ℝ) / 1000000000000) ((195048084009 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15003646987 : ℝ) / 1000000000000) ((15074199403 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((266090507781 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((125508154189 : ℝ) / 500000000000) ((125543430397 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((266090507781 : ℝ) / 1000000000000) ((266090507781 : ℝ) / 1000000000000) ((266090507781 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((733909492219 : ℝ) / 1000000000000))
  have h11 : RB z11 ((85506561449 : ℝ) / 250000000000) ((342122378109 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((733909492219 : ℝ) / 1000000000000) ((733909492219 : ℝ) / 1000000000000) ((733909492219 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-268216950693 : ℝ) / 250000000000) ((-214517355039 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_763.1 dlower_log_764.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-837043237303 : ℝ) / 1000000000000) ((-16725964773 : ℝ) / 20000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((266090507781 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1323918773259 : ℝ) / 1000000000000) ((-1323918773257 : ℝ) / 1000000000000) := rb_log (show RB ((266090507781 : ℝ) / 1000000000000) ((266090507781 : ℝ) / 1000000000000) ((266090507781 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_765.1 dlower_log_765.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((243437767977 : ℝ) / 500000000000) ((487620534609 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((6206526403 : ℝ) / 250000000000) ((13041785651 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15003646987 : ℝ) / 1000000000000) ((15074199403 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1488297931539 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((184152966517 : ℝ) / 125000000000) ((184161785569 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((1488297931539 : ℝ) / 1000000000000) ((1488297931539 : ℝ) / 1000000000000) ((1488297931539 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((488297931539 : ℝ) / 1000000000000))
  have h19 : RB z19 ((1508529564617 : ℝ) / 500000000000) ((3017203615647 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((488297931539 : ℝ) / 1000000000000) ((488297931539 : ℝ) / 1000000000000) ((488297931539 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1104282558669 : ℝ) / 1000000000000) ((552165223671 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_766.1 dlower_log_767.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((861011509879 : ℝ) / 1000000000000) ((215397537867 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1488297931539 : ℝ) / 1000000000000))
  have h22 : RB z22 ((49704142397 : ℝ) / 125000000000) ((198816569589 : ℝ) / 500000000000) := rb_log (show RB ((1488297931539 : ℝ) / 1000000000000) ((1488297931539 : ℝ) / 1000000000000) ((1488297931539 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_768.1 dlower_log_768.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((463378370701 : ℝ) / 1000000000000) ((115989253073 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1328940359 : ℝ) / 1000000000000) ((484009797 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1122489374999 : ℝ) / 1000000000000) ((7185773 : ℝ) / 6400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((251996479397 : ℝ) / 200000000000) ((1260628261903 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((79325526027 : ℝ) / 50000000000) ((793661881621 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((611103711879 : ℝ) / 500000000000))
  have h28 : RB z28 ((969522468037 : ℝ) / 500000000000) ((970019443671 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((611103711879 : ℝ) / 500000000000) ((611103711879 : ℝ) / 500000000000) ((611103711879 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15003646987 : ℝ) / 1000000000000) ((15074199403 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((396021952332624484804959 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((3788589723 : ℝ) / 100000000000) ((38064050021 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((396021952332624484804959 : ℝ) / 1000000000000000000000000) ((396021952332624484804959 : ℝ) / 1000000000000000000000000) ((396021952332624484804959 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((961935949979 : ℝ) / 1000000000000) ((96211410277 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((932618516317 : ℝ) / 500000000000) ((933269386717 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((266090507781 : ℝ) / 1000000000000)) ((6206526403 : ℝ) / 250000000000) ((13041785651 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1488297931539 : ℝ) / 1000000000000)) ((1328940359 : ℝ) / 1000000000000) ((484009797 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((266090507781 : ℝ) / 1000000000000)) (wl := ((1488297931539 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((932618516317 : ℝ) / 500000000000) ≤ D0q (q) * (((1488297931539 : ℝ) / 1000000000000) - ((266090507781 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1488297931539 : ℝ) / 1000000000000) * ((266090507781 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_61 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((318747396829803680230055714435891 : ℝ) / 2596148429267413814265248164610048) ((638241591981213814964130374746111 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((122777031249 : ℝ) / 1000000000000) ((1573387 : ℝ) / 12800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1122777031249 : ℝ) / 1000000000000) ((14373387 : ℝ) / 12800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((7237819289 : ℝ) / 62500000000) ((115933200767 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_769.1 dlower_log_770.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((7237819289 : ℝ) / 31250000000) ((115933200767 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((18451231161 : ℝ) / 40000000000) ((28846060207 : ℝ) / 62500000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2097385322711 : ℝ) / 1000000000000) ((-2096214550407 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_771.1 dlower_log_772.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2096214550407 : ℝ) / 1000000000000) ((2097385322711 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((43986269383 : ℝ) / 200000000000) ((110088197609 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((389911802391 : ℝ) / 500000000000) ((156013730617 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((7537099701 : ℝ) / 500000000000) ((1510953767 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((216393478331 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((201283940661 : ℝ) / 1000000000000) ((201319278929 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((216393478331 : ℝ) / 1000000000000) ((216393478331 : ℝ) / 1000000000000) ((216393478331 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((783606521669 : ℝ) / 1000000000000))
  have h11 : RB z11 ((64217159727 : ℝ) / 250000000000) ((32114216983 : ℝ) / 125000000000) := rb_div_signed h10 (show RB ((783606521669 : ℝ) / 1000000000000) ((783606521669 : ℝ) / 1000000000000) ((783606521669 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-679595228707 : ℝ) / 500000000000) ((-339753727137 : ℝ) / 250000000000) := rb_log h11 (by norm_num) dlower_log_773.1 dlower_log_774.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-1060261869401 : ℝ) / 1000000000000) ((-132473988117 : ℝ) / 125000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((216393478331 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1530656869567 : ℝ) / 1000000000000) ((-306131373913 : ℝ) / 200000000000) := rb_log (show RB ((216393478331 : ℝ) / 1000000000000) ((216393478331 : ℝ) / 1000000000000) ((216393478331 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_775.1 dlower_log_775.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((117598750041 : ℝ) / 250000000000) ((470864964631 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2214509213 : ℝ) / 250000000000) ((4792092803 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((7537099701 : ℝ) / 500000000000) ((1510953767 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1489041681803 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1473932144133 : ℝ) / 1000000000000) ((1473967482401 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1489041681803 : ℝ) / 1000000000000) ((1489041681803 : ℝ) / 1000000000000) ((1489041681803 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((489041681803 : ℝ) / 1000000000000))
  have h19 : RB z19 ((1506959630413 : ℝ) / 500000000000) ((376748940133 : ℝ) / 125000000000) := rb_div_signed h18 (show RB ((489041681803 : ℝ) / 1000000000000) ((489041681803 : ℝ) / 1000000000000) ((489041681803 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1103241311797 : ℝ) / 1000000000000) ((1103265287017 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_776.1 dlower_log_777.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((860333616709 : ℝ) / 1000000000000) ((860622666439 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1489041681803 : ℝ) / 1000000000000))
  have h22 : RB z22 ((19906637323 : ℝ) / 50000000000) ((199066373231 : ℝ) / 500000000000) := rb_log (show RB ((1489041681803 : ℝ) / 1000000000000) ((1489041681803 : ℝ) / 1000000000000) ((1489041681803 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_778.1 dlower_log_778.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((462200870247 : ℝ) / 1000000000000) ((462489919979 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((132781387 : ℝ) / 200000000000) ((604570477 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1122777031249 : ℝ) / 1000000000000) ((14373387 : ℝ) / 12800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((12606282619 : ℝ) / 10000000000) ((63047562821 : ℝ) / 50000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1586104133539 : ℝ) / 1000000000000) ((317302104109 : ℝ) / 200000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((79540512717 : ℝ) / 62500000000))
  have h28 : RB z28 ((2018552576067 : ℝ) / 1000000000000) ((1009534881881 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((79540512717 : ℝ) / 62500000000) ((79540512717 : ℝ) / 62500000000) ((79540512717 : ℝ) / 62500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((7537099701 : ℝ) / 500000000000) ((1510953767 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((322218908905193277510793 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((23391239597 : ℝ) / 500000000000) ((4689215081 : ℝ) / 100000000000) := rb_div_signed h29 (show RB ((322218908905193277510793 : ℝ) / 1000000000000000000000000) ((322218908905193277510793 : ℝ) / 1000000000000000000000000) ((322218908905193277510793 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((95310784919 : ℝ) / 100000000000) ((476608760403 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((480974576063 : ℝ) / 250000000000) ((481153168637 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((216393478331 : ℝ) / 1000000000000)) ((2214509213 : ℝ) / 250000000000) ((4792092803 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1489041681803 : ℝ) / 1000000000000)) ((132781387 : ℝ) / 200000000000) ((604570477 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((216393478331 : ℝ) / 1000000000000)) (wl := ((1489041681803 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((480974576063 : ℝ) / 250000000000) ≤ D0q (q) * (((1489041681803 : ℝ) / 1000000000000) - ((216393478331 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1489041681803 : ℝ) / 1000000000000) * ((216393478331 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_62 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((638241591981213814964130374746111 : ℝ) / 5192296858534827628530496329220096) ((638988390302820269468149320620441 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((61460429687 : ℝ) / 500000000000) ((393807 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((561460429687 : ℝ) / 500000000000) ((3593807 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((23186640153 : ℝ) / 200000000000) ((58030638251 : ℝ) / 500000000000) := rb_log h1 (by norm_num) dlower_log_779.1 dlower_log_780.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((23186640153 : ℝ) / 100000000000) ((58030638251 : ℝ) / 250000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((92204925511 : ℝ) / 200000000000) ((46128077903 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2096214550417 : ℝ) / 1000000000000) ((-2095045147219 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_781.1 dlower_log_782.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2095045147219 : ℝ) / 1000000000000) ((2096214550417 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((54982996309 : ℝ) / 250000000000) ((220177011289 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779822988711 : ℝ) / 1000000000000) ((195017003691 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15109537669 : ℝ) / 1000000000000) ((1514491731 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((57817213461 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((108061968267 : ℝ) / 500000000000) ((8646372647 : ℝ) / 40000000000) := rb_widen (rb_sub (show RB ((57817213461 : ℝ) / 250000000000) ((57817213461 : ℝ) / 250000000000) ((57817213461 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((192182786539 : ℝ) / 250000000000))
  have h11 : RB z11 ((281143723153 : ℝ) / 1000000000000) ((14059487329 : ℝ) / 50000000000) := rb_div_signed h10 (show RB ((192182786539 : ℝ) / 250000000000) ((192182786539 : ℝ) / 250000000000) ((192182786539 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-126888927011 : ℝ) / 100000000000) ((-317181395699 : ℝ) / 250000000000) := rb_log h11 (by norm_num) dlower_log_783.1 dlower_log_784.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-989819933891 : ℝ) / 1000000000000) ((-98938137583 : ℝ) / 100000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((57817213461 : ℝ) / 250000000000))
  have h14 : RB z14 ((-1464174375777 : ℝ) / 1000000000000) ((-58566975031 : ℝ) / 40000000000) := rb_log (show RB ((57817213461 : ℝ) / 250000000000) ((57817213461 : ℝ) / 250000000000) ((57817213461 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_785.1 dlower_log_785.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((118588610471 : ℝ) / 250000000000) ((474792999947 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((6536831427 : ℝ) / 500000000000) ((1721046549 : ℝ) / 125000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15109537669 : ℝ) / 1000000000000) ((1514491731 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((297835607649 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((294806624187 : ℝ) / 200000000000) ((46064640643 : ℝ) / 31250000000) := rb_widen (rb_sub (show RB ((297835607649 : ℝ) / 200000000000) ((297835607649 : ℝ) / 200000000000) ((297835607649 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((97835607649 : ℝ) / 200000000000))
  have h19 : RB z19 ((3013285564133 : ℝ) / 1000000000000) ((1506678944403 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((97835607649 : ℝ) / 200000000000) ((97835607649 : ℝ) / 200000000000) ((97835607649 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((551515516499 : ℝ) / 500000000000) ((1103055034643 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_786.1 dlower_log_787.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((860168956793 : ℝ) / 1000000000000) ((17209159021 : ℝ) / 20000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((297835607649 : ℝ) / 200000000000))
  have h22 : RB z22 ((79644863111 : ℝ) / 200000000000) ((398224315557 : ℝ) / 1000000000000) := rb_log (show RB ((297835607649 : ℝ) / 200000000000) ((297835607649 : ℝ) / 200000000000) ((297835607649 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_788.1 dlower_log_788.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((115486160309 : ℝ) / 250000000000) ((92446727099 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((331931103 : ℝ) / 500000000000) ((60450397 : ℝ) / 50000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((561460429687 : ℝ) / 500000000000) ((3593807 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1260951256417 : ℝ) / 1000000000000) ((126127429231 : ℝ) / 100000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((198212237833 : ℝ) / 125000000000) ((198263016693 : ℝ) / 125000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1257909184401 : ℝ) / 1000000000000))
  have h28 : RB z28 ((997331977723 : ℝ) / 500000000000) ((997587478501 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((1257909184401 : ℝ) / 1000000000000) ((1257909184401 : ℝ) / 1000000000000) ((1257909184401 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15109537669 : ℝ) / 1000000000000) ((1514491731 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((17220024903728877363189 : ℝ) / 50000000000000000000000))
  have h30 : RB z30 ((43871997147 : ℝ) / 1000000000000) ((43974725341 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((17220024903728877363189 : ℝ) / 50000000000000000000000) ((17220024903728877363189 : ℝ) / 50000000000000000000000) ((17220024903728877363189 : ℝ) / 50000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((956025274659 : ℝ) / 1000000000000) ((956128002853 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1906949155857 : ℝ) / 1000000000000) ((1907642646981 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((57817213461 : ℝ) / 250000000000)) ((6536831427 : ℝ) / 500000000000) ((1721046549 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((297835607649 : ℝ) / 200000000000)) ((331931103 : ℝ) / 500000000000) ((60450397 : ℝ) / 50000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((57817213461 : ℝ) / 250000000000)) (wl := ((297835607649 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1906949155857 : ℝ) / 1000000000000) ≤ D0q (q) * (((297835607649 : ℝ) / 200000000000) - ((57817213461 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((297835607649 : ℝ) / 200000000000) * ((57817213461 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_63 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((638988390302820269468149320620441 : ℝ) / 5192296858534827628530496329220096) ((319867594312213361986084133247385 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((123064687499 : ℝ) / 1000000000000) ((1577069 : ℝ) / 12800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1123064687499 : ℝ) / 1000000000000) ((14377069 : ℝ) / 12800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((232122553 : ℝ) / 2000000000) ((29047333959 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_789.1 dlower_log_790.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((232122553 : ℝ) / 1000000000) ((29047333959 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((460768508887 : ℝ) / 1000000000000) ((11525615689 : ℝ) / 25000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2095045147229 : ℝ) / 1000000000000) ((-2093877109937 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_791.1 dlower_log_792.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2093877109937 : ℝ) / 1000000000000) ((2095045147229 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((109966248101 : ℝ) / 500000000000) ((22017750009 : ℝ) / 100000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((77982249991 : ℝ) / 100000000000) ((390033751899 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((15144917309 : ℝ) / 1000000000000) ((15180338323 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((3217242619 : ℝ) / 12500000000)) - (z9)
  have h10 : RB z10 ((242199071197 : ℝ) / 1000000000000) ((242234492211 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((3217242619 : ℝ) / 12500000000) ((3217242619 : ℝ) / 12500000000) ((3217242619 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((9282757381 : ℝ) / 12500000000))
  have h11 : RB z11 ((40767633281 : ℝ) / 125000000000) ((326188763571 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((9282757381 : ℝ) / 12500000000) ((9282757381 : ℝ) / 12500000000) ((9282757381 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-56021263633 : ℝ) / 50000000000) ((-280069758957 : ℝ) / 250000000000) := rb_log h11 (by norm_num) dlower_log_793.1 dlower_log_794.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-874007345637 : ℝ) / 1000000000000) ((-218404699579 : ℝ) / 250000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((3217242619 : ℝ) / 12500000000))
  have h14 : RB z14 ((-271440796223 : ℝ) / 200000000000) ((-1357203981113 : ℝ) / 1000000000000) := rb_log (show RB ((3217242619 : ℝ) / 12500000000) ((3217242619 : ℝ) / 12500000000) ((3217242619 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_795.1 dlower_log_795.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((120799158869 : ℝ) / 250000000000) ((483585182799 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((5543001979 : ℝ) / 250000000000) ((2852084239 : ℝ) / 125000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((15144917309 : ℝ) / 1000000000000) ((15180338323 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((297862896359 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((92133383967 : ℝ) / 62500000000) ((737084782243 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((297862896359 : ℝ) / 200000000000) ((297862896359 : ℝ) / 200000000000) ((297862896359 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((97862896359 : ℝ) / 200000000000))
  have h19 : RB z19 ((3012651777777 : ℝ) / 1000000000000) ((602544833367 : ℝ) / 200000000000) := rb_div_signed h18 (show RB ((97862896359 : ℝ) / 200000000000) ((97862896359 : ℝ) / 200000000000) ((97862896359 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1102820680211 : ℝ) / 1000000000000) ((275711177069 : ℝ) / 250000000000) := rb_log h19 (by norm_num) dlower_log_796.1 dlower_log_797.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((430002189897 : ℝ) / 500000000000) ((430146659331 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((297862896359 : ℝ) / 200000000000))
  have h22 : RB z22 ((79663186951 : ℝ) / 200000000000) ((398315934757 : ℝ) / 1000000000000) := rb_log (show RB ((297862896359 : ℝ) / 200000000000) ((297862896359 : ℝ) / 200000000000) ((297862896359 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_798.1 dlower_log_798.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((461688445037 : ℝ) / 1000000000000) ((461977383907 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((663817477 : ℝ) / 1000000000000) ((60443751 : ℝ) / 50000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1123064687499 : ℝ) / 1000000000000) ((14377069 : ℝ) / 12800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1261274292307 : ℝ) / 1000000000000) ((1261597369573 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1585291827833 : ℝ) / 1000000000000) ((396424475667 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((49277402891 : ℝ) / 40000000000))
  have h28 : RB z28 ((976488301249 : ℝ) / 500000000000) ((195347686033 : ℝ) / 100000000000) := rb_widen (rb_mul h27 (show RB ((49277402891 : ℝ) / 40000000000) ((49277402891 : ℝ) / 40000000000) ((49277402891 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((15144917309 : ℝ) / 1000000000000) ((15180338323 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((958297204784954724221 : ℝ) / 2500000000000000000000))
  have h30 : RB z30 ((9877492359 : ℝ) / 250000000000) ((19801187783 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((958297204784954724221 : ℝ) / 2500000000000000000000) ((958297204784954724221 : ℝ) / 2500000000000000000000) ((958297204784954724221 : ℝ) / 2500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((480198812217 : ℝ) / 500000000000) ((240122507641 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((937817044807 : ℝ) / 500000000000) ((375259009857 : ℝ) / 200000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((3217242619 : ℝ) / 12500000000)) ((5543001979 : ℝ) / 250000000000) ((2852084239 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((297862896359 : ℝ) / 200000000000)) ((663817477 : ℝ) / 1000000000000) ((60443751 : ℝ) / 50000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((3217242619 : ℝ) / 12500000000)) (wl := ((297862896359 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((937817044807 : ℝ) / 500000000000) ≤ D0q (q) * (((297862896359 : ℝ) / 200000000000) - ((3217242619 : ℝ) / 12500000000)) * (1 - (q) ^ 2 / (((297862896359 : ℝ) / 200000000000) * ((3217242619 : ℝ) / 12500000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
