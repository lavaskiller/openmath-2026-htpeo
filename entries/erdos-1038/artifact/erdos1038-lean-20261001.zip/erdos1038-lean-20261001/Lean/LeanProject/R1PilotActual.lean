import LeanProject.R1PilotData

/-! Transfer rational formula certificates to the actual separated reference. -/
open Real Set
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

noncomputable def pilotVp {k : ℝ} (hk : k ∈ pilotSlab) : ℝ :=
  (pilot_positive_root_box hk).choose
noncomputable def pilotVm {k : ℝ} (hk : k ∈ pilotSlab) : ℝ :=
  (pilot_negative_root_box hk).choose

theorem pilotVp_spec {k : ℝ} (hk : k ∈ pilotSlab) :
    pilotVp hk ∈ Ioo (2027 / 5000) (4057 / 10000) ∧
      certE k (r1A k) (pilotVp hk) = 0 :=
  ⟨(pilot_positive_root_box hk).choose_spec.1,
    (pilot_positive_root_box hk).choose_spec.2.1⟩
theorem pilotVm_spec {k : ℝ} (hk : k ∈ pilotSlab) :
    pilotVm hk ∈ Ioo (131 / 100) (6551 / 5000) ∧
      certE k (r1A k) (pilotVm hk) = 0 :=
  ⟨(pilot_negative_root_box hk).choose_spec.1,
    (pilot_negative_root_box hk).choose_spec.2.1⟩

theorem pilot_reference_dictionary {k : ℝ} (hk : k ∈ pilotSlab) :
    let R := pilotReference hk
    R.rhoPlus = qa (r1A k) / pilotVp hk ∧
    R.rhoMinus = qa (r1A k) / pilotVm hk ∧
    R.sigmaPlus = certSp k (pilotVp hk) ∧
    R.sigmaMinus = certSm k (pilotVm hk) ∧
    bpi R = certBp k (pilotVp hk) (pilotVm hk) ∧
    totalXi R = certXi k (pilotVp hk) (pilotVm hk) ∧
    api R.angles = certApi k ∧
    referenceWidth R = certWidth k (pilotVp hk) (pilotVm hk) ∧
    refD0 R = D0a (r1A k) := by
  let R := pilotReference hk
  have hp := pilotVp_spec hk
  have hm := pilotVm_spec hk
  have hk0 := r1_k_pos (pilot_slab_subset hk)
  have ha := r1_a_pos (pilot_slab_subset hk)
  have ha2 := (r1_a_mem (pilot_slab_subset hk)).2
  have hH := r1_H1 (pilot_slab_subset hk)
  have hv0 : qa (r1A k) < (9 : ℝ) / 25 := by linarith [pilot_q_bound hk]
  have hv01 : (9 : ℝ) / 25 < 1 := by norm_num
  have hE0 := pilot_negative_certificate hk
  have hp0 : (9 : ℝ) / 25 < pilotVp hk := by linarith [hp.1.1]
  have hp1 : pilotVp hk < 1 := by linarith [hp.1.2]
  have hm1 : 1 < pilotVm hk := by linarith [hm.1.1]
  have hrp : R.rhoPlus = qa (r1A k) / pilotVp hk :=
    certificate_rho_plus hk0 ha ha2 hH hv0 hv01 hE0 hp0 hp1 hp.2
  have hrm : R.rhoMinus = qa (r1A k) / pilotVm hk :=
    certificate_rho_minus hk0 ha ha2 hH hv0 hv01 hE0 hm1 hm.2
  have hsp : R.sigmaPlus = certSp k (pilotVp hk) :=
    certificate_sigma_plus hk0 ha ha2 hH hv0 hv01 hE0 hp0 hp1 hp.2
  have hsm : R.sigmaMinus = certSm k (pilotVm hk) := by
    have hh : R.sigmaMinus = -(D0a (r1A k) * (1 - (qa (r1A k)) ^ 2 / (pilotVm hk) ^ 2) /
        ((k + 1) * certEprime k (r1A k) (pilotVm hk))) :=
      certificate_sigma_minus hk0 ha ha2 hH hv0 hv01 hE0 hm1 hm.2
    rw [hh]
    unfold certSm certEprime
    have he : 1 / (1 - pilotVm hk) = -(1 / (pilotVm hk - 1)) := by
      rw [show 1 - pilotVm hk = -(pilotVm hk - 1) by ring, div_neg]
    rw [he]
    have he' : (k / (k + 1) * (1 / (pilotVm hk - (qa (r1A k)) ^ 2) +
        -(1 / (pilotVm hk - 1))) - 1 / pilotVm hk) =
      -(k / (k + 1) * (1 / (pilotVm hk - 1) -
        1 / (pilotVm hk - (qa (r1A k)) ^ 2)) + 1 / pilotVm hk) := by ring
    rw [he', mul_neg, div_neg, neg_neg]
  have hbp : bpi R = certBp k (pilotVp hk) (pilotVm hk) := by
    rw [bpi, refB_eq, bpi_eq R.rhoPlus_spec.1.le R.rhoPlus_spec.2.1
      R.rhoMinus_spec.1.le R.rhoMinus_spec.2.1, hrp, hrm, hsp, hsm]
    rfl
  have hxi : totalXi R = certXi k (pilotVp hk) (pilotVm hk) := by
    rw [totalXi_formula, hrp, hrm, hsp, hsm]
    rfl
  have hapi : api R.angles = certApi k := by
    rw [api, api_eq R.angles.rho_pos.le]
    rfl
  have hw : referenceWidth R = certWidth k (pilotVp hk) (pilotVm hk) := by
    have hh : referenceWidth R = certPoint (r1A k) (pilotVp hk) - certPoint (r1A k) (pilotVm hk) :=
      certificate_width hk0 ha ha2 hH hv0 hv01 hE0 hp0 hp1 hp.2 hm1 hm.2
    rw [hh]
    unfold certPoint certWidth
    have hpz : pilotVp hk ≠ 0 := by linarith [hp.1.1]
    have hmz : pilotVm hk ≠ 0 := by linarith [hm.1.1]
    field_simp
    <;> ring
  have hd : refD0 R = D0a (r1A k) := by
    change ((2 - r1A k) / 2) / (2 * qa (r1A k)) = D0a (r1A k)
    apply (div_eq_iff (mul_pos (by norm_num) (qa_pos ha ha2)).ne').mpr
    linear_combination -2 * D0a_mul_qa ha
  exact ⟨hrp, hrm, hsp, hsm, hbp, hxi, hapi, hw, hd⟩

theorem pilot_actual_bounds {k : ℝ} (hk : k ∈ pilotSlab) :
    let R := pilotReference hk
    RB R.sigmaPlus (3366 / 1000) (3428 / 1000) ∧
    RB R.sigmaMinus (2932 / 10000) (2936 / 10000) ∧
    RB (bpi R) (6379 / 10000) (6501 / 10000) ∧
    RB (totalXi R) (3333 / 10000) (3398 / 10000) ∧
    RB (api R.angles) (1066 / 1000) (106605 / 100000) ∧
    RB (referenceWidth R) (17417 / 10000) (17428 / 10000) ∧
    RB R.rhoPlus (4603 / 100000) (461 / 10000) ∧
    RB R.rhoMinus (1425 / 100000) (1427 / 100000) := by
  obtain ⟨hrp, hrm, hsp, hsm, hbp, hxi, hapi, hw, _⟩ := pilot_reference_dictionary hk
  have hp := pilotVp_spec hk
  have hm := pilotVm_spec hk
  have h := pilot_rational_bounds hk ⟨hp.1.1.le, hp.1.2.le⟩ ⟨hm.1.1.le, hm.1.2.le⟩
  norm_num only at h ⊢
  simpa only [hrp, hrm, hsp, hsm, hbp, hxi, hapi, hw] using h

end EP1038.ReferenceCert
