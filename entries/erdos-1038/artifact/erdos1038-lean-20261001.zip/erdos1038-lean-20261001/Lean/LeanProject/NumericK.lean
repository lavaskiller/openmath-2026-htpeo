import LeanProject.Normalization
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Complex.ExponentialBounds

/-!
# EP-1038: the numeric facts of Proposition 8.1 for K = 29/20, proved in Lean

`eps_pos` and `num_pos` discharge the two numeric hypotheses of `prop81` for `K = 29/20`, so
`prop81_full` is Proposition 8.1 with no numeric assumptions.
Ingredients: the log-series remainder bound (`Real.abs_log_sub_add_sum_range_le`) for
`log (29/20) = -log (1 - 9/29)`, the Taylor remainder bound for `exp` (`Real.exp_bound`), and the
Mathlib constants `log 2 < 0.6931471808`, `log 3 > 1.0986122885`, `e > 2.7182818283`.
-/

open Real Finset

namespace EP1038

theorem logK_bounds : 0.3714 ≤ Real.log (29 / 20) ∧ Real.log (29 / 20) ≤ 0.3716 := by
  have h := Real.abs_log_sub_add_sum_range_le (x := 9 / 29) (by rw [abs_of_pos (by norm_num)]; norm_num) 10
  have e1 : Real.log (1 - 9 / 29) = -Real.log (29 / 20) := by
    rw [show (1 : ℝ) - 9 / 29 = (29 / 20)⁻¹ by norm_num, Real.log_inv]
  rw [e1] at h
  simp only [Finset.sum_range_succ, Finset.sum_range_zero] at h
  rw [abs_of_pos (by norm_num : (0 : ℝ) < 9 / 29)] at h
  rw [abs_le] at h
  obtain ⟨h1, h2⟩ := h
  constructor <;> norm_num at h1 h2 ⊢ <;> linarith

/-- `K^(-K/(K+1)) = exp(-(29/49) log(29/20))` for `K = 29/20`. -/
theorem rpowK : (29 / 20 : ℝ) ^ (-(29 / 20 : ℝ) / (29 / 20 + 1)) =
    Real.exp (-(29 / 49 * Real.log (29 / 20))) := by
  rw [Real.rpow_def_of_pos (by norm_num)]
  congr 1
  ring

/-- Taylor bounds for `exp(-c)`, `0 ≤ c ≤ 1`. -/
theorem exp_neg_bounds {c : ℝ} (h0 : 0 ≤ c) (h1 : c ≤ 1) :
    1 - c + c ^ 2 / 2 - c ^ 3 / 6 - c ^ 4 * (5 / 96) ≤ Real.exp (-c) ∧
      Real.exp (-c) ≤ 1 - c + c ^ 2 / 2 + c ^ 3 * (2 / 9) := by
  have hc : |(-c)| ≤ 1 := by rw [abs_neg, abs_of_nonneg h0]; exact h1
  have b4 := Real.exp_bound hc (n := 4) (by norm_num)
  have b3 := Real.exp_bound hc (n := 3) (by norm_num)
  simp only [Finset.sum_range_succ, Finset.sum_range_zero, Nat.factorial, Nat.cast_one,
    Nat.cast_ofNat, Nat.succ_eq_add_one, abs_neg, abs_of_nonneg h0] at b4 b3
  rw [abs_le] at b4 b3
  constructor
  · norm_num at b4; nlinarith [b4.1]
  · norm_num at b3; nlinarith [b3.2]

theorem eps_pos : 0 < 2 - (29 / 20 + 1) * (29 / 20 : ℝ) ^ (-(29 / 20 : ℝ) / (29 / 20 + 1)) := by
  rw [rpowK]
  obtain ⟨hl, hu⟩ := logK_bounds
  set c := 29 / 49 * Real.log (29 / 20) with hcdef
  have hc0 : 0.2198 ≤ c := by rw [hcdef]; nlinarith
  have hc1 : c ≤ 0.2200 := by rw [hcdef]; nlinarith
  have hb := (exp_neg_bounds (c := c) (by linarith) (by linarith)).2
  have hc2 : c ^ 2 ≤ 0.0484 := by nlinarith
  have hc3 : c ^ 3 ≤ 0.010648 := by nlinarith
  nlinarith

theorem num_pos : 0 < Real.log 3 - 29 / 20 * Real.log 2 -
    6 * (2 - (29 / 20 + 1) * (29 / 20 : ℝ) ^ (-(29 / 20 : ℝ) / (29 / 20 + 1))) / Real.exp 1 := by
  rw [rpowK]
  obtain ⟨hl, hu⟩ := logK_bounds
  set c := 29 / 49 * Real.log (29 / 20) with hcdef
  have hc0 : 0.2198 ≤ c := by rw [hcdef]; nlinarith
  have hc1 : c ≤ 0.2200 := by rw [hcdef]; nlinarith
  have hexp := (exp_neg_bounds (c := c) (by linarith) (by linarith)).1
  have hc2 : 0.04831204 ≤ c ^ 2 := by nlinarith
  have hc3 : c ^ 3 ≤ 0.010648 := by nlinarith
  have hc4 : c ^ 4 ≤ 0.00234256 := by nlinarith
  have hε : 2 - (29 / 20 + 1) * Real.exp (-c) ≤ 0.035 := by nlinarith
  have h3 := Real.log_three_gt_d9
  have h2 := Real.log_two_lt_d9
  have he := Real.exp_one_gt_d9
  have hepos : 0 < Real.exp 1 := Real.exp_pos 1
  have hq : 6 * (2 - (29 / 20 + 1) * Real.exp (-c)) / Real.exp 1 ≤ 6 * 0.035 / 2.7182818283 := by
    rcases le_or_gt 0 (2 - (29 / 20 + 1) * Real.exp (-c)) with hnn | hneg
    · calc 6 * (2 - (29 / 20 + 1) * Real.exp (-c)) / Real.exp 1
          ≤ 6 * 0.035 / Real.exp 1 := by gcongr
        _ ≤ 6 * 0.035 / 2.7182818283 := by gcongr
    · have : 6 * (2 - (29 / 20 + 1) * Real.exp (-c)) / Real.exp 1 < 0 :=
        div_neg_of_neg_of_pos (by linarith) hepos
      have : (0 : ℝ) ≤ 6 * 0.035 / 2.7182818283 := by norm_num
      linarith
  norm_num at h3 h2 hq ⊢
  linarith

/-- Proposition 8.1 for `K = 29/20`, with no numeric hypotheses. -/
theorem prop81_full {N : ℕ} (q d : Fin N → ℝ) (k b : ℝ)
    (hq : ∀ i, 0 < q i) (hq1 : ∑ i, q i = 1)
    (hd1 : ∀ i, 1 ≤ d i) (hd2 : ∀ i, d i ≤ 2) (hdist : ∀ i j, i ≠ j → d i ≠ d j)
    (hk1 : 1 ≤ k) (hkK : k ≤ 29 / 20) (hb0 : 0 < b) (hbd : ∀ i, b < d i)
    (hsep : 0 ≤ k * Real.log b + ∑ i, q i * Real.log (d i - b)) :
    1 / 3 < ∑ i, Real.exp (-(k * Real.log (d i) +
      ∑ j, (if i = j then 0 else q j * Real.log |d i - d j|)) / q i) :=
  prop81 q d k (29 / 20) b _ hq hq1 hd1 hd2 hdist hk1 hkK hb0 hbd hsep rfl eps_pos num_pos

end EP1038
