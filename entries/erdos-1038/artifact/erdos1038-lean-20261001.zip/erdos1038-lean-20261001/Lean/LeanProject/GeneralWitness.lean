import LeanProject.Arcsine

/-!
# EP-1038: Lemma 6.3 for a general witness measure (roadmap 15c part 2)

Setting after the shift: roots `q_j ∈ [a, a+2]`, `∏ q_j = 1`, `K = {|g| ≤ 1}`, `|K ∩ [0, Y]| ≥ B`.

* `H y = |[0, y] ∩ K| + min y 0` (extended by `y` for `y < 0`): monotone, 1-Lipschitz, continuous,
  `H y ≤ y`.
* `φ s = inf {y : s ≤ H y}` (proof.md Lemma 6.2): `H (φ s) = s` (`φ_eq`), minimality (`φ_min`),
  `φ s ∈ K` for `s > 0` (`φ_in_K`, Lemma 6.2(ii), since `K` is closed), `φ 0 = 0` (`φ_zero`).
* `measure_witness_contradiction` (Lemma 6.3): for a measure `μ` supported in `[0, B]` with no atoms
  in `[a, min(B, a+2)]`, if `x ↦ ∫ log|x - s| dμ(s)` is integrable and positive on `[a, min(B, a+2)]`, the
  setting is contradictory. Proof: `∑ log|x_j - s| ≤ ∑ log|q_j - φ s| ≤ 0` for `μ`-a.e. `s`
  (`quantile_expansive`, `φ s ∈ K`; the exceptional `s` are finitely many positive points), then
  integrate the left side only.
-/
open Real MeasureTheory

namespace EP1038.General

variable {n : ℕ} (q : Fin n → ℝ)

/-- `K = {x : |g(x)| ≤ 1}` for `g = ∏ (x - q_j)`. -/
def K : Set ℝ := {x | |∏ j, (x - q j)| ≤ 1}

theorem K_closed : IsClosed (K q) := isClosed_le (continuous_absProd q) continuous_const

/-- `V y = |[0, y] ∩ K|` as a real number. -/
noncomputable def V (y : ℝ) : ℝ := (volume (Set.Icc 0 y ∩ K q)).toReal

/-- `H y = |[0, y] ∩ K| + min y 0` (extended by `y` for `y < 0`, Lean RED L-13). -/
noncomputable def H (y : ℝ) : ℝ := V q y + min y 0

theorem vol_ne_top (y : ℝ) : volume (Set.Icc 0 y ∩ K q) ≠ ⊤ :=
  ne_top_of_le_ne_top (by simp [Real.volume_Icc]) (measure_mono Set.inter_subset_left)

theorem V_nonneg (y : ℝ) : 0 ≤ V q y := ENNReal.toReal_nonneg

theorem V_of_nonpos {y : ℝ} (hy : y ≤ 0) : V q y = 0 := by
  have h : volume (Set.Icc 0 y ∩ K q) = 0 := by
    apply measure_mono_null Set.inter_subset_left
    rcases hy.lt_or_eq with h | h
    · rw [Set.Icc_eq_empty (by linarith), measure_empty]
    · rw [h, Set.Icc_self, Real.volume_singleton]
  rw [V, h, ENNReal.toReal_zero]

theorem V_le {y : ℝ} (hy : 0 ≤ y) : V q y ≤ y := by
  apply ENNReal.toReal_le_of_le_ofReal hy
  calc volume (Set.Icc 0 y ∩ K q) ≤ volume (Set.Icc 0 y) := measure_mono Set.inter_subset_left
    _ = ENNReal.ofReal y := by rw [Real.volume_Icc, sub_zero]

theorem V_mono {x y : ℝ} (hxy : x ≤ y) : V q x ≤ V q y :=
  ENNReal.toReal_mono (vol_ne_top q y)
    (measure_mono (Set.inter_subset_inter_left _ (Set.Icc_subset_Icc_right hxy)))

theorem V_diff {x y : ℝ} (hxy : x ≤ y) : V q y ≤ V q x + (y - x) := by
  have hsub : Set.Icc 0 y ∩ K q ⊆ (Set.Icc 0 x ∩ K q) ∪ Set.Icc x y := by
    rintro t ⟨⟨ht0, hty⟩, htK⟩
    rcases le_total t x with h | h
    · exact Or.inl ⟨⟨ht0, h⟩, htK⟩
    · exact Or.inr ⟨h, hty⟩
  have h1 : volume (Set.Icc 0 y ∩ K q) ≤ volume (Set.Icc 0 x ∩ K q) + ENNReal.ofReal (y - x) :=
    calc volume (Set.Icc 0 y ∩ K q) ≤ volume ((Set.Icc 0 x ∩ K q) ∪ Set.Icc x y) :=
          measure_mono hsub
      _ ≤ volume (Set.Icc 0 x ∩ K q) + volume (Set.Icc x y) := measure_union_le _ _
      _ = _ := by rw [Real.volume_Icc]
  have h2 := ENNReal.toReal_mono (by
    exact ENNReal.add_ne_top.mpr ⟨vol_ne_top q x, ENNReal.ofReal_ne_top⟩) h1
  rw [ENNReal.toReal_add (vol_ne_top q x) ENNReal.ofReal_ne_top,
    ENNReal.toReal_ofReal (by linarith)] at h2
  exact h2

theorem H_le_self (y : ℝ) : H q y ≤ y := by
  rcases le_total y 0 with hy | hy
  · rw [H, V_of_nonpos q hy, min_eq_left hy, zero_add]
  · rw [H, min_eq_right hy, add_zero]; exact V_le q hy

theorem H_mono : Monotone (H q) := fun _ _ hxy =>
  add_le_add (V_mono q hxy) (min_le_min_right 0 hxy)

theorem H_lip {x y : ℝ} (hxy : x ≤ y) : H q y - H q x ≤ y - x := by
  rcases le_total y 0 with hy | hy
  · rw [H, H, V_of_nonpos q hy, V_of_nonpos q (hxy.trans hy), min_eq_left hy,
      min_eq_left (hxy.trans hy)]; linarith
  · rcases le_total x 0 with hx | hx
    · rw [H, H, V_of_nonpos q hx, min_eq_left hx, min_eq_right hy]
      linarith [V_le q hy]
    · rw [H, H, min_eq_right hy, min_eq_right hx]
      linarith [V_diff q hxy]

theorem H_continuous : Continuous (H q) := by
  apply continuous_iff_continuousAt.mpr
  intro x
  rw [Metric.continuousAt_iff]
  intro ε hε
  refine ⟨ε, hε, fun y hy => ?_⟩
  rw [Real.dist_eq] at hy ⊢
  rcases le_total x y with h | h
  · have := H_lip q h; have := H_mono q h
    rw [abs_of_nonneg (by linarith)]; rw [abs_of_nonneg (by linarith)] at hy; linarith
  · have := H_lip q h; have := H_mono q h
    rw [abs_of_nonpos (by linarith)]; rw [abs_of_nonpos (by linarith)] at hy; linarith

/-- The quantile map `φ(s) = inf {y : s ≤ H y}`. -/
noncomputable def φ (s : ℝ) : ℝ := sInf {y | s ≤ H q y}

section quantile

variable {q} {Y s : ℝ} (hY : s ≤ H q Y)

include hY

theorem φ_set_nonempty : {y | s ≤ H q y}.Nonempty := ⟨Y, hY⟩

omit hY in
theorem φ_set_bdd : BddBelow {y | s ≤ H q y} :=
  ⟨s, fun y hy => le_trans hy (H_le_self q y)⟩

theorem φ_mem : s ≤ H q (φ q s) :=
  (isClosed_le continuous_const (H_continuous q)).csInf_mem (φ_set_nonempty hY) φ_set_bdd

theorem φ_min (y : ℝ) (hy : s ≤ H q y) : φ q s ≤ y := csInf_le φ_set_bdd hy

theorem φ_eq : H q (φ q s) = s := by
  apply le_antisymm _ (φ_mem hY)
  by_contra hc
  push Not at hc
  set δ := (H q (φ q s) - s) / 2 with hδ
  have hδpos : 0 < δ := by rw [hδ]; linarith
  have hl := H_lip q (show φ q s - δ ≤ φ q s by linarith)
  have hy : s ≤ H q (φ q s - δ) := by linarith
  have := φ_min hY _ hy
  linarith

end quantile

theorem K_zero (h0 : ∏ j, q j = 1) : (0 : ℝ) ∈ K q := by
  change |∏ j, (0 - q j)| ≤ 1
  have : ∏ j, (0 - q j) = (-1) ^ n * ∏ j, q j := by
    rw [show ((-1 : ℝ) ^ n) = ∏ _j : Fin n, (-1 : ℝ) by simp, ← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl; intro j _; ring
  rw [this, h0, mul_one, abs_pow, abs_neg, abs_one, one_pow]

/-- Lemma 6.2(ii): `φ(s) ∈ K` for `0 < s ≤ H Y`. -/
theorem φ_in_K {Y s : ℝ} (hY : s ≤ H q Y) (hs : 0 < s) : φ q s ∈ K q := by
  have hφs : H q (φ q s) = s := φ_eq hY
  have hpos : 0 < φ q s := by
    have := H_le_self q (φ q s); rw [hφs] at this; linarith
  by_contra hnot
  have hopen : IsOpen (K q)ᶜ := (K_closed q).isOpen_compl
  obtain ⟨ε, hε, hball⟩ := Metric.isOpen_iff.mp hopen (φ q s) hnot
  set δ := min (ε / 2) (φ q s / 2) with hδ
  have hδpos : 0 < δ := lt_min (by linarith) (by linarith)
  have hδε : δ < ε := lt_of_le_of_lt (min_le_left _ _) (by linarith)
  have hδφ : δ < φ q s := lt_of_le_of_lt (min_le_right _ _) (by linarith)
  set y := φ q s - δ with hy
  have hy0 : 0 ≤ y := by rw [hy]; linarith
  have hsub : Set.Icc 0 (φ q s) ∩ K q ⊆ Set.Icc 0 y ∩ K q := by
    rintro t ⟨⟨ht0, htφ⟩, htK⟩
    refine ⟨⟨ht0, ?_⟩, htK⟩
    by_contra hty
    push Not at hty
    have : t ∈ Metric.ball (φ q s) ε := by
      rw [Metric.mem_ball, Real.dist_eq, abs_of_nonpos (by linarith)]; linarith
    exact hball this htK
  have hV : V q (φ q s) ≤ V q y :=
    ENNReal.toReal_mono (vol_ne_top q y) (measure_mono hsub)
  have hH : H q (φ q s) ≤ H q y := by
    rw [H, H, min_eq_right hpos.le, min_eq_right hy0]; linarith
  have := φ_min hY y (by linarith)
  linarith

/-- `φ 0 = 0` when `0 ≤ H Y`. -/
theorem φ_zero {Y : ℝ} (hY : 0 ≤ H q Y) : φ q 0 = 0 := by
  apply le_antisymm
  · apply φ_min hY 0
    rw [H, V_of_nonpos q le_rfl, min_self, add_zero]
  · have := φ_mem hY
    by_contra hc
    push Not at hc
    have hH : H q (φ q 0) = φ q 0 := by
      rw [H, V_of_nonpos q hc.le, min_eq_left hc.le, zero_add]
    linarith


/-- **Lemma 6.3 for a general witness measure `μ`** (no atoms in `[a, min(B, a+2)]`, supported in`[0, B]`):
with the shifted roots `q_j ∈ [a, a+2]`, `∏ q_j = 1`, and `|K ∩ [0, Y]| ≥ B`, a witness with
`∫ log|x - s| dμ(s) > 0` for all `x ∈ [a, min(B, a+2)]` is contradictory. -/
theorem measure_witness_contradiction {n : ℕ} (hn : 0 < n) (q : Fin n → ℝ) {a B Y : ℝ}
    (ha : 0 < a) (haB : a ≤ B) (hq : ∀ j, q j ∈ Set.Icc a (a + 2)) (h0 : ∏ j, q j = 1)
    (hvol : ENNReal.ofReal B ≤ volume (Set.Icc 0 Y ∩ K q))
    (μ : Measure ℝ) (hsupp : μ (Set.Icc 0 B)ᶜ = 0)
    (hatom : ∀ s ∈ Set.Icc a (min B (a + 2)), μ {s} = 0)
    (hint : ∀ x ∈ Set.Icc a (min B (a + 2)), Integrable (fun s => Real.log |x - s|) μ)
    (hW : ∀ x ∈ Set.Icc a (min B (a + 2)), 0 < ∫ s, Real.log |x - s| ∂μ) : False := by
  have hB0 : 0 < B := lt_of_lt_of_le ha haB
  have hqpos : ∀ j, 0 < q j := fun j => lt_of_lt_of_le ha (hq j).1
  -- H Y ≥ B
  have hVY : B ≤ V q Y := (ENNReal.ofReal_le_iff_le_toReal (vol_ne_top q Y)).mp hvol
  have hY0 : 0 ≤ Y := by
    by_contra hc; push Not at hc
    rw [V_of_nonpos q hc.le] at hVY; linarith
  have hHY : B ≤ H q Y := by rw [H, min_eq_right hY0, add_zero]; exact hVY
  -- [0, a] ⊆ K, hence H y ≥ a for y ≥ a
  have hsubK : Set.Icc 0 a ⊆ K q := by
    intro x hx
    obtain ⟨hx0, hxa⟩ := hx
    change |∏ j, (x - q j)| ≤ 1
    rw [Finset.abs_prod, ← h0]
    gcongr with j
    rw [abs_of_nonpos (by linarith [(hq j).1])]; linarith
  have hHa : ∀ y, a ≤ y → a ≤ H q y := by
    intro y hy
    have hy0 : 0 ≤ y := by linarith
    rw [H, min_eq_right hy0, add_zero, V]
    apply (ENNReal.ofReal_le_iff_le_toReal (vol_ne_top q y)).mp
    calc ENNReal.ofReal a = volume (Set.Icc 0 a) := by rw [Real.volume_Icc, sub_zero]
      _ ≤ volume (Set.Icc 0 y ∩ K q) :=
          measure_mono (fun t ht => ⟨⟨ht.1, ht.2.trans hy⟩, hsubK ht⟩)
  -- the points x_j = min (H q_j) B
  set x : Fin n → ℝ := fun j => min (H q (q j)) B with hxdef
  have hHq : ∀ j, a ≤ H q (q j) := fun j => hHa _ (hq j).1
  have hx : ∀ j, x j ∈ Set.Icc a (min B (a + 2)) := by
    intro j
    refine ⟨le_min (hHq j) haB, le_min (min_le_right _ _) ?_⟩
    calc x j ≤ H q (q j) := min_le_left _ _
      _ ≤ q j := H_le_self q _
      _ ≤ a + 2 := (hq j).2
  -- almost every s is good
  have hae_supp : ∀ᵐ s ∂μ, s ∈ Set.Icc 0 B := by
    filter_upwards [measure_eq_zero_iff_ae_notMem.mp hsupp] with s hs
    simpa using hs
  have hae_pts : ∀ᵐ s ∂μ, ∀ j, s ≠ H q (q j) ∧ s ≠ x j := by
    rw [ae_all_iff]
    intro j
    have h2 : μ {x j} = 0 := hatom _ (hx j)
    rcases le_or_gt (H q (q j)) B with hle | hgt
    · have h1 : μ {H q (q j)} = 0 := by
        apply hatom
        refine ⟨hHq j, le_min hle ?_⟩
        exact (H_le_self q _).trans (hq j).2
      filter_upwards [measure_eq_zero_iff_ae_notMem.mp h1,
        measure_eq_zero_iff_ae_notMem.mp h2] with s hs1 hs2
      exact ⟨hs1, hs2⟩
    · filter_upwards [hae_supp, measure_eq_zero_iff_ae_notMem.mp h2] with s hs hs2
      exact ⟨fun h => by rw [h] at hs; linarith [hs.2], hs2⟩
  -- the pointwise chain
  have hchain : ∀ᵐ s ∂μ, ∑ j, Real.log |x j - s| ≤ 0 := by
    filter_upwards [hae_supp, hae_pts] with s hs hpts
    obtain ⟨hs0, hsB⟩ := hs
    have hYs : s ≤ H q Y := hsB.trans hHY
    have hφeq : H q (φ q s) = s := φ_eq hYs
    have hle : ∀ j, Real.log |x j - s| ≤ Real.log |q j - φ q s| := by
      intro j
      have hexp := quantile_expansive (H_mono q) (fun x y h => H_lip q h) hφeq
        (φ_min hYs) (q := q j) hsB
      have hposx : 0 < |x j - s| := abs_pos.mpr (sub_ne_zero.mpr (hpts j).2.symm)
      exact Real.log_le_log hposx hexp
    have hne : ∀ j, q j - φ q s ≠ 0 := by
      intro j h
      have : φ q s = q j := by linarith
      exact (hpts j).1 (by rw [← hφeq, this])
    have hK : φ q s ∈ K q := by
      rcases hs0.lt_or_eq with hs' | hs'
      · exact φ_in_K q hYs hs'
      · rw [← hs', φ_zero q (hs' ▸ hYs)]; exact K_zero q h0
    have hsum : ∑ j, Real.log |q j - φ q s| ≤ 0 := by
      rw [← Real.log_prod (fun j _ => abs_ne_zero.mpr (hne j))]
      apply Real.log_nonpos (Finset.prod_nonneg fun j _ => abs_nonneg _)
      have : ∏ j, |q j - φ q s| = |∏ j, (φ q s - q j)| := by
        rw [Finset.abs_prod]; apply Finset.prod_congr rfl; intro j _; exact abs_sub_comm _ _
      rw [this]; exact hK
    exact (Finset.sum_le_sum fun j _ => hle j).trans hsum
  have hint_sum : ∫ s, ∑ j, Real.log |x j - s| ∂μ = ∑ j, ∫ s, Real.log |x j - s| ∂μ :=
    integral_finset_sum _ (fun j _ => hint (x j) (hx j))
  have hnonpos : ∫ s, ∑ j, Real.log |x j - s| ∂μ ≤ 0 := integral_nonpos_of_ae hchain
  have hposs : 0 < ∑ j, ∫ s, Real.log |x j - s| ∂μ := by
    have : Nonempty (Fin n) := ⟨⟨0, hn⟩⟩
    exact Finset.sum_pos (fun j _ => hW (x j) (hx j)) Finset.univ_nonempty
  linarith

end EP1038.General