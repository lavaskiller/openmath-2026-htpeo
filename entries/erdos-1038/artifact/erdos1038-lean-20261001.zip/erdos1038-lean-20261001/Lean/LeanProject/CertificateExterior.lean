import LeanProject.R1Reference

/-!
# Exterior certificate dictionary on both branches

These formulas concern the actual reference quantile and its physical potential.
The point `v = 1` is excluded: it represents the logarithmic atom at zero.
-/

open Real Set Filter Topology

namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11

noncomputable def certEprime (k a v : ℝ) : ℝ :=
  k / (k + 1) * (1 / (v - (qa a) ^ 2) + 1 / (1 - v)) - 1 / v

theorem exterior_parameter_bounds {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) :
    0 < v ∧ (qa a) ^ 2 < v ∧ 0 < qa a / v ∧ qa a / v < 1 := by
  have hq := qa_pos ha ha2
  have hq1 := qa_lt_one ha
  have hv := hq.trans hvq
  exact ⟨hv, by nlinarith, div_pos hq hv, (div_lt_one hv).mpr hvq⟩

theorem certPoint_lt_left {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) : certPoint a v < a := by
  obtain ⟨hv, _, hp, hp1⟩ := exterior_parameter_bounds ha ha2 hvq
  rw [certPoint_eq_xoff ha ha2 hv]
  simpa only [interval_left_identity ha] using
    Stage9.xoff_lt (D0a_pos ha) (qa_pos ha ha2) hp hp1

theorem certPoint_neg {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hv : 1 < v) : certPoint a v < 0 := by
  obtain ⟨hv0, hq2, _, _⟩ := exterior_parameter_bounds ha ha2 ((qa_lt_one ha).trans hv)
  rw [certPoint_factor ha hv0.ne']
  exact div_neg_of_neg_of_pos
    (mul_neg_of_pos_of_neg (mul_pos (D0a_pos ha) (sub_pos.mpr hq2)) (by linarith)) hv0

theorem certPoint_ne_zero {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v ≠ 1) : certPoint a v ≠ 0 := by
  rcases lt_or_gt_of_ne hv1 with h | h
  · exact (certPoint_bounds ha ha2 hvq h).1.ne'
  · exact (certPoint_neg ha ha2 h).ne

theorem certPoint_abs_log {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v ≠ 1) :
    Real.log |certPoint a v| = Real.log (D0a a) + Real.log (v - (qa a) ^ 2) +
      Real.log |1 - v| - Real.log v := by
  obtain ⟨hv, hq2, _, _⟩ := exterior_parameter_bounds ha ha2 hvq
  have h1 : 1 - v ≠ 0 := sub_ne_zero.mpr (Ne.symm hv1)
  have hD := D0a_pos ha
  have hd := sub_pos.mpr hq2
  have habs := abs_pos.mpr h1
  rw [certPoint_factor ha hv.ne', abs_div, abs_mul, abs_mul,
    abs_of_pos (D0a_pos ha), abs_of_pos (sub_pos.mpr hq2), abs_of_pos hv,
    Real.log_div (by positivity) hv.ne',
    Real.log_mul (by positivity) (abs_ne_zero.mpr h1),
    Real.log_mul (D0a_pos ha).ne' (sub_pos.mpr hq2).ne']

theorem certE_eq_logs {k a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v ≠ 1) :
    certE k a v = k / (k + 1) *
      (Real.log (v - (qa a) ^ 2) - Real.log (1 - v)) - Real.log v - Real.log (D0a a) := by
  obtain ⟨_, hq2, _, _⟩ := exterior_parameter_bounds ha ha2 hvq
  unfold certE
  rw [Real.log_div (sub_pos.mpr hq2).ne'
    (abs_ne_zero.mpr (sub_ne_zero.mpr (Ne.symm hv1))), Real.log_abs]

theorem certificate_potential_eq_exterior {k a v : ℝ} (hk : 0 < k) (ha : 0 < a)
    (ha2 : a < 2) (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a)
    (hvq : qa a < v) (hv1 : v ≠ 1) :
    Stage10.WS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) =
      -(k + 1) * certE k a v := by
  obtain ⟨hv, hq2, hp, hp1⟩ := exterior_parameter_bounds ha ha2 hvq
  have hq := qa_pos ha ha2
  have hD := D0a_pos ha
  have hmul : 1 - qa a * (qa a / v) = (v - (qa a) ^ 2) / v := by field_simp
  have hlogs := Real.log_div hq.ne' hv.ne'
  have hlogm : Real.log (1 - qa a * (qa a / v)) =
      Real.log (v - (qa a) ^ 2) - Real.log v := by
    rw [hmul, Real.log_div (sub_pos.mpr hq2).ne' hv.ne']
  rw [certPoint_eq_xoff ha ha2 hv, intervalQuantile_potential_off hk ha ha2 hH1 hp hp1,
    ← certPoint_eq_xoff ha ha2 hv, certPoint_abs_log ha ha2 hvq hv1,
    hlogs, hlogm, Real.log_mul hD.ne' hq.ne', certE_eq_logs ha ha2 hvq hv1, Real.log_abs]
  have hk1 : k + 1 ≠ 0 := by positivity
  field_simp
  <;> ring

theorem hasDerivAt_certPoint {a v : ℝ} (hv : v ≠ 0) :
    HasDerivAt (certPoint a) (-(D0a a * (1 - (qa a) ^ 2 / v ^ 2))) v := by
  have h := ((hasDerivAt_const v ((a + 2) / 2)).sub
    ((hasDerivAt_id v).const_mul (D0a a))).sub
    ((hasDerivAt_const v (D0a a * (qa a) ^ 2)).div (hasDerivAt_id v) hv)
  change HasDerivAt (certPoint a) _ v at h
  exact h.congr_deriv (by dsimp; ring)

theorem certPoint_derivative_neg {a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) : -(D0a a * (1 - (qa a) ^ 2 / v ^ 2)) < 0 := by
  have hq := qa_pos ha ha2
  have hv := hq.trans hvq
  have hsq : (qa a) ^ 2 < v ^ 2 := by nlinarith
  have hrat : (qa a) ^ 2 / v ^ 2 < 1 := (div_lt_one (sq_pos_of_pos hv)).mpr hsq
  exact neg_neg_of_pos (mul_pos (D0a_pos ha) (by linarith))

theorem certPoint_strictAntiOn {a : ℝ} (ha : 0 < a) (ha2 : a < 2) :
    StrictAntiOn (certPoint a) (Ioi (qa a)) := by
  refine strictAntiOn_of_deriv_neg (convex_Ioi _) ?_ ?_
  · intro v hv
    exact (hasDerivAt_certPoint ((qa_pos ha ha2).trans hv).ne').continuousAt.continuousWithinAt
  · intro v hv
    rw [interior_Ioi] at hv
    rw [(hasDerivAt_certPoint ((qa_pos ha ha2).trans hv).ne').deriv]
    exact certPoint_derivative_neg ha ha2 hv

theorem hasDerivAt_certE {k a v : ℝ} (ha : 0 < a) (ha2 : a < 2)
    (hvq : qa a < v) (hv1 : v ≠ 1) : HasDerivAt (certE k a) (certEprime k a v) v := by
  obtain ⟨hv, hq2, _, _⟩ := exterior_parameter_bounds ha ha2 hvq
  have h := (((((hasDerivAt_id v).sub_const ((qa a) ^ 2)).log (sub_pos.mpr hq2).ne').sub
    (((hasDerivAt_id v).const_sub 1).log (sub_ne_zero.mpr (Ne.symm hv1)))).const_mul
      (k / (k + 1))).sub (Real.hasDerivAt_log hv.ne')
  have h' := h.sub_const (Real.log (D0a a))
  refine (h'.congr_of_eventuallyEq ?_).congr_deriv ?_
  · filter_upwards [Ioi_mem_nhds hvq, eventually_ne_nhds hv1] with w hw hw1
    exact certE_eq_logs ha ha2 hw hw1
  · dsimp [certEprime]
    simp only [one_mul, inv_eq_one_div]
    ring

theorem certificate_slope_eq {k a v : ℝ} (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2)
    (hH1 : 2 * (k / (k + 1)) ^ 2 ≤ a) (hvq : qa a < v) (hv1 : v ≠ 1) :
    k * Stage10.GS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a v) =
      (k + 1) * certEprime k a v / (D0a a * (1 - (qa a) ^ 2 / v ^ 2)) := by
  have hv := (qa_pos ha ha2).trans hvq
  have hm := intervalQuantile_measurable hk ha ha2 hH1
  have hl := fun u => (intervalQuantile_bounds hk ha ha2 hH1 u).1
  have hu := fun u => (intervalQuantile_bounds hk ha ha2 hH1 u).2
  have hW := Stage10.hasDerivAt_WS hm ha hl hu hk (certPoint_lt_left ha ha2 hvq)
    (certPoint_ne_zero ha ha2 hvq hv1)
  have hcomp := hW.comp v (hasDerivAt_certPoint hv.ne')
  have hE := (hasDerivAt_certE (k := k) ha ha2 hvq hv1).const_mul (-(k + 1))
  have heq : (fun w => Stage10.WS k (intervalQuantile k a hk ha ha2 hH1) (certPoint a w)) =ᶠ[𝓝 v]
      (fun w => -(k + 1) * certE k a w) := by
    filter_upwards [Ioi_mem_nhds hvq, eventually_ne_nhds hv1] with w hw hw1
    exact certificate_potential_eq_exterior hk ha ha2 hH1 hw hw1
  have hder := (hE.congr_of_eventuallyEq heq).unique hcomp
  have hden : D0a a * (1 - (qa a) ^ 2 / v ^ 2) ≠ 0 :=
    (neg_neg_iff_pos.mp (certPoint_derivative_neg ha ha2 hvq)).ne'
  apply (eq_div_iff hden).mpr
  nlinarith [hder]

end EP1038.ReferenceCert
