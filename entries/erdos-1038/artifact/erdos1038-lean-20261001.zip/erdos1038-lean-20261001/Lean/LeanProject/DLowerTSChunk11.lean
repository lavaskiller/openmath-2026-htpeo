import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk08
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_28 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((391051347529477374133859290343013 : ℝ) / 5192296858534827628530496329220096) ((198512867051164505083005428668825 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((75313749999 : ℝ) / 1000000000000) ((122343 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1075313749999 : ℝ) / 1000000000000) ((1722343 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((3630623973 : ℝ) / 50000000000) ((73681943917 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_439.1 dlower_log_440.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((3630623973 : ℝ) / 25000000000) ((73681943917 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((21831331709 : ℝ) / 40000000000) ((13698055541 : ℝ) / 25000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2586092557939 : ℝ) / 1000000000000) ((-321366291611 : ℝ) / 125000000000) := rb_log hqr (by norm_num) dlower_log_441.1 dlower_log_442.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((321366291611 : ℝ) / 125000000000) ((2586092557939 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((211045537039 : ℝ) / 1000000000000) ((133201349 : ℝ) / 625000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((491798651 : ℝ) / 625000000) ((788954462961 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2836080469 : ℝ) / 500000000000) ((1169360129 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((35749904373 : ℝ) / 100000000000)) - (z9)
  have h10 : RB z10 ((70330448617 : ℝ) / 200000000000) ((43978360349 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((35749904373 : ℝ) / 100000000000) ((35749904373 : ℝ) / 100000000000) ((35749904373 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((64250095627 : ℝ) / 100000000000))
  have h11 : RB z11 ((21892714067 : ℝ) / 40000000000) ((109517932809 : ℝ) / 200000000000) := rb_div_signed h10 (show RB ((64250095627 : ℝ) / 100000000000) ((64250095627 : ℝ) / 100000000000) ((64250095627 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-602725563651 : ℝ) / 1000000000000) ((-301114530377 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_443.1 dlower_log_444.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-59440377923 : ℝ) / 125000000000) ((-236940351737 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((35749904373 : ℝ) / 100000000000))
  have h14 : RB z14 ((-1028622591733 : ℝ) / 1000000000000) ((-1028622591731 : ℝ) / 1000000000000) := rb_log (show RB ((35749904373 : ℝ) / 100000000000) ((35749904373 : ℝ) / 100000000000) ((35749904373 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_445.1 dlower_log_445.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((553099568347 : ℝ) / 1000000000000) ((554741888259 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((5177346707 : ℝ) / 1000000000000) ((4479297767 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2836080469 : ℝ) / 500000000000) ((1169360129 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1446092742511 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((720122970933 : ℝ) / 500000000000) ((1440420581573 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1446092742511 : ℝ) / 1000000000000) ((1446092742511 : ℝ) / 1000000000000) ((1446092742511 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((446092742511 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3228579630681 : ℝ) / 1000000000000) ((5166353789 : ℝ) / 1600000000) := rb_div_signed h18 (show RB ((446092742511 : ℝ) / 1000000000000) ((446092742511 : ℝ) / 1000000000000) ((446092742511 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((234408459539 : ℝ) / 200000000000) ((1172163547211 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_446.1 dlower_log_447.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((461127056737 : ℝ) / 500000000000) ((924783661893 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1446092742511 : ℝ) / 1000000000000))
  have h22 : RB z22 ((368865258961 : ℝ) / 1000000000000) ((368865258963 : ℝ) / 1000000000000) := rb_log (show RB ((1446092742511 : ℝ) / 1000000000000) ((1446092742511 : ℝ) / 1000000000000) ((1446092742511 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_448.1 dlower_log_448.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((553388854511 : ℝ) / 1000000000000) ((138979600733 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5466632871 : ℝ) / 1000000000000) ((10135110207 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1075313749999 : ℝ) / 1000000000000) ((1722343 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((144537457617 : ℝ) / 125000000000) ((231755110129 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((86297989239 : ℝ) / 50000000000) ((1729655441031 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1088593698781 : ℝ) / 1000000000000))
  have h28 : RB z28 ((93943447303 : ℝ) / 50000000000) ((1882892014169 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1088593698781 : ℝ) / 1000000000000) ((1088593698781 : ℝ) / 1000000000000) ((1088593698781 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2836080469 : ℝ) / 500000000000) ((1169360129 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((51697677259257561900603 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((2194358137 : ℝ) / 200000000000) ((11309600267 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((51697677259257561900603 : ℝ) / 100000000000000000000000) ((51697677259257561900603 : ℝ) / 100000000000000000000000) ((51697677259257561900603 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((988690399733 : ℝ) / 1000000000000) ((197805641863 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((74304787573 : ℝ) / 40000000000) ((465558329277 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((35749904373 : ℝ) / 100000000000)) ((5177346707 : ℝ) / 1000000000000) ((4479297767 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1446092742511 : ℝ) / 1000000000000)) ((5466632871 : ℝ) / 1000000000000) ((10135110207 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((35749904373 : ℝ) / 100000000000)) (wl := ((1446092742511 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((74304787573 : ℝ) / 40000000000) ≤ D0q (q) * (((1446092742511 : ℝ) / 1000000000000) - ((35749904373 : ℝ) / 100000000000)) * (1 - (q) ^ 2 / (((1446092742511 : ℝ) / 1000000000000) * ((35749904373 : ℝ) / 100000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_29 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((198512867051164505083005428668825 : ℝ) / 2596148429267413814265248164610048) ((403000120675180646198162424332287 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((76464374999 : ℝ) / 1000000000000) ((15523 : ℝ) / 200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1076464374999 : ℝ) / 1000000000000) ((215523 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((14736388783 : ℝ) / 200000000000) ((74750265839 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_449.1 dlower_log_450.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((14736388783 : ℝ) / 100000000000) ((74750265839 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((543646648881 : ℝ) / 1000000000000) ((54578329273 : ℝ) / 100000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2570930332903 : ℝ) / 1000000000000) ((-1277997285751 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_451.1 dlower_log_452.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1277997285751 : ℝ) / 500000000000) ((2570930332903 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((52864778357 : ℝ) / 250000000000) ((8541227729 : ℝ) / 40000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((31458772271 : ℝ) / 40000000000) ((197135221643 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((5846800643 : ℝ) / 1000000000000) ((240963529 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((354583837397 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((87139937293 : ℝ) / 250000000000) ((174368518377 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((354583837397 : ℝ) / 1000000000000) ((354583837397 : ℝ) / 1000000000000) ((354583837397 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((645416162603 : ℝ) / 1000000000000))
  have h11 : RB z11 ((540054261681 : ℝ) / 1000000000000) ((540328948919 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((645416162603 : ℝ) / 1000000000000) ((645416162603 : ℝ) / 1000000000000) ((645416162603 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-308042829939 : ℝ) / 500000000000) ((-615577160223 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_453.1 dlower_log_454.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-97161746489 : ℝ) / 200000000000) ((-484132542467 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((354583837397 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-518405233099 : ℝ) / 500000000000) ((-259202616549 : ℝ) / 250000000000) := rb_log (show RB ((354583837397 : ℝ) / 1000000000000) ((354583837397 : ℝ) / 1000000000000) ((354583837397 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_455.1 dlower_log_455.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((551001733751 : ℝ) / 1000000000000) ((552677923731 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((5218441021 : ℝ) / 1000000000000) ((180625497 : ℝ) / 20000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((5846800643 : ℝ) / 1000000000000) ((240963529 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1446914540181 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((360222612989 : ℝ) / 250000000000) ((720533869769 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((1446914540181 : ℝ) / 1000000000000) ((1446914540181 : ℝ) / 1000000000000) ((1446914540181 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((446914540181 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3224084970187 : ℝ) / 1000000000000) ((644896332509 : ℝ) / 200000000000) := rb_div_signed h18 (show RB ((446914540181 : ℝ) / 1000000000000) ((446914540181 : ℝ) / 1000000000000) ((446914540181 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1170649179813 : ℝ) / 1000000000000) ((585386106269 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_456.1 dlower_log_457.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((230169912231 : ℝ) / 250000000000) ((923201758449 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1446914540181 : ℝ) / 1000000000000))
  have h22 : RB z22 ((23089586619 : ℝ) / 62500000000) ((369433385907 : ℝ) / 1000000000000) := rb_log (show RB ((1446914540181 : ℝ) / 1000000000000) ((1446914540181 : ℝ) / 1000000000000) ((1446914540181 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_458.1 dlower_log_458.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((551246263017 : ℝ) / 1000000000000) ((110753674509 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5462970287 : ℝ) / 1000000000000) ((632607729 : ℝ) / 62500000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1076464374999 : ℝ) / 1000000000000) ((215523 : ℝ) / 200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1158775550641 : ℝ) / 1000000000000) ((46450163529 : ℝ) / 40000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1722275960343 : ℝ) / 1000000000000) ((1725959784787 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((17067667231 : ℝ) / 15625000000))
  have h28 : RB z28 ((1881294910149 : ℝ) / 1000000000000) ((942659432347 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((17067667231 : ℝ) / 15625000000) ((17067667231 : ℝ) / 15625000000) ((17067667231 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((5846800643 : ℝ) / 1000000000000) ((240963529 : ℝ) / 40000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((513052510042894726948857 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((11396105717 : ℝ) / 1000000000000) ((733853761 : ℝ) / 62500000000) := rb_div_signed h29 (show RB ((513052510042894726948857 : ℝ) / 1000000000000000000000000) ((513052510042894726948857 : ℝ) / 1000000000000000000000000) ((513052510042894726948857 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((61766146239 : ℝ) / 62500000000) ((988603894283 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1859205384623 : ℝ) / 1000000000000) ((931916785801 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((354583837397 : ℝ) / 1000000000000)) ((5218441021 : ℝ) / 1000000000000) ((180625497 : ℝ) / 20000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1446914540181 : ℝ) / 1000000000000)) ((5462970287 : ℝ) / 1000000000000) ((632607729 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((354583837397 : ℝ) / 1000000000000)) (wl := ((1446914540181 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1859205384623 : ℝ) / 1000000000000) ≤ D0q (q) * (((1446914540181 : ℝ) / 1000000000000) - ((354583837397 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1446914540181 : ℝ) / 1000000000000) * ((354583837397 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_30 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((403000120675180646198162424332287 : ℝ) / 5192296858534827628530496329220096) ((408974507248032282230313991326923 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((77614999999 : ℝ) / 1000000000000) ((5041 : ℝ) / 64000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1077614999999 : ℝ) / 1000000000000) ((69041 : ℝ) / 64000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((37375132919 : ℝ) / 500000000000) ((18954361917 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_459.1 dlower_log_460.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((37375132919 : ℝ) / 250000000000) ((18954361917 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((541512285223 : ℝ) / 1000000000000) ((135911662221 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2555994571517 : ℝ) / 1000000000000) ((-1270639304129 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_461.1 dlower_log_462.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1270639304129 : ℝ) / 500000000000) ((2555994571517 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((21185971647 : ℝ) / 100000000000) ((53481606377 : ℝ) / 250000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((196518393623 : ℝ) / 250000000000) ((78814028353 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((188252757 : ℝ) / 31250000000) ((3102011841 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((43955771137 : ℝ) / 125000000000)) - (z9)
  have h10 : RB z10 ((172721072707 : ℝ) / 500000000000) ((43202760109 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((43955771137 : ℝ) / 125000000000) ((43955771137 : ℝ) / 125000000000) ((43955771137 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((81044228863 : ℝ) / 125000000000))
  have h11 : RB z11 ((266399401799 : ℝ) / 500000000000) ((106615266047 : ℝ) / 200000000000) := rb_div_signed h10 (show RB ((81044228863 : ℝ) / 125000000000) ((81044228863 : ℝ) / 125000000000) ((81044228863 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-314805702629 : ℝ) / 500000000000) ((-157272664093 : ℝ) / 250000000000) := rb_log h11 (by norm_num) dlower_log_463.1 dlower_log_464.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-248111055727 : ℝ) / 500000000000) ((-494511540933 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((43955771137 : ℝ) / 125000000000))
  have h14 : RB z14 ((-104512981037 : ℝ) / 100000000000) ((-16330153287 : ℝ) / 15625000000) := rb_log (show RB ((43955771137 : ℝ) / 125000000000) ((43955771137 : ℝ) / 125000000000) ((43955771137 : ℝ) / 125000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_465.1 dlower_log_465.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((274453849457 : ℝ) / 500000000000) ((550618269437 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((526105003 : ℝ) / 100000000000) ((4552992107 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((188252757 : ℝ) / 31250000000) ((3102011841 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1447744306677 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((288308056599 : ℝ) / 200000000000) ((1441720218453 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1447744306677 : ℝ) / 1000000000000) ((1447744306677 : ℝ) / 1000000000000) ((1447744306677 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((447744306677 : ℝ) / 1000000000000))
  have h19 : RB z19 ((804890347849 : ℝ) / 250000000000) ((321996326241 : ℝ) / 100000000000) := rb_div_signed h18 (show RB ((447744306677 : ℝ) / 1000000000000) ((447744306677 : ℝ) / 1000000000000) ((447744306677 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((46769805457 : ℝ) / 40000000000) ((584684975151 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_466.1 dlower_log_467.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((459556351923 : ℝ) / 500000000000) ((921627564183 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1447744306677 : ℝ) / 1000000000000))
  have h22 : RB z22 ((370006694583 : ℝ) / 1000000000000) ((74001338917 : ℝ) / 200000000000) := rb_log (show RB ((1447744306677 : ℝ) / 1000000000000) ((1447744306677 : ℝ) / 1000000000000) ((1447744306677 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_468.1 dlower_log_468.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((549106009261 : ℝ) / 1000000000000) ((689526087 : ℝ) / 1250000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((5459360377 : ℝ) / 1000000000000) ((10108584377 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1077614999999 : ℝ) / 1000000000000) ((69041 : ℝ) / 64000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((580627044111 : ℝ) / 500000000000) ((581867636841 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((214825489657 : ℝ) / 125000000000) ((430568990087 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1096098137581 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1883758552943 : ℝ) / 1000000000000) ((943891736269 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((1096098137581 : ℝ) / 1000000000000) ((1096098137581 : ℝ) / 1000000000000) ((1096098137581 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((188252757 : ℝ) / 31250000000) ((3102011841 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((63636717409188952981749 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((11832964657 : ℝ) / 1000000000000) ((6093203671 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((63636717409188952981749 : ℝ) / 125000000000000000000000) ((63636717409188952981749 : ℝ) / 125000000000000000000000) ((63636717409188952981749 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((493906796329 : ℝ) / 500000000000) ((988167035343 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((930401151941 : ℝ) / 500000000000) ((466361349357 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((43955771137 : ℝ) / 125000000000)) ((526105003 : ℝ) / 100000000000) ((4552992107 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1447744306677 : ℝ) / 1000000000000)) ((5459360377 : ℝ) / 1000000000000) ((10108584377 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((43955771137 : ℝ) / 125000000000)) (wl := ((1447744306677 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((930401151941 : ℝ) / 500000000000) ≤ D0q (q) * (((1447744306677 : ℝ) / 1000000000000) - ((43955771137 : ℝ) / 125000000000)) * (1 - (q) ^ 2 / (((1447744306677 : ℝ) / 1000000000000) * ((43955771137 : ℝ) / 125000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_31 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((408974507248032282230313991326923 : ℝ) / 5192296858534827628530496329220096) ((51868611727610489782808194790195 : ℝ) / 649037107316853453566312041152512)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((78765624999 : ℝ) / 1000000000000) ((63933 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1078765624999 : ℝ) / 1000000000000) ((863933 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((37908723833 : ℝ) / 500000000000) ((76883491833 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_469.1 dlower_log_470.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((37908723833 : ℝ) / 250000000000) ((76883491833 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((539380196893 : ℝ) / 1000000000000) ((135378071307 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2541278608273 : ℝ) / 1000000000000) ((-2526776067663 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_471.1 dlower_log_472.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2526776067663 : ℝ) / 1000000000000) ((2541278608273 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((106123782559 : ℝ) / 500000000000) ((1674293493 : ℝ) / 7812500000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((6138206507 : ℝ) / 7812500000) ((393876217441 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((6204023681 : ℝ) / 1000000000000) ((1277321403 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((174343034433 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((342299461851 : ℝ) / 1000000000000) ((68496409037 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((174343034433 : ℝ) / 500000000000) ((174343034433 : ℝ) / 500000000000) ((174343034433 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((325656965567 : ℝ) / 500000000000))
  have h11 : RB z11 ((131388047103 : ℝ) / 250000000000) ((26291625959 : ℝ) / 50000000000) := rb_div_signed h10 (show RB ((325656965567 : ℝ) / 500000000000) ((325656965567 : ℝ) / 500000000000) ((325656965567 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-643305781681 : ℝ) / 1000000000000) ((-128554504309 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_473.1 dlower_log_474.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-506765695893 : ℝ) / 1000000000000) ((-252510110353 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((174343034433 : ℝ) / 500000000000))
  have h14 : RB z14 ((-1053583277731 : ℝ) / 1000000000000) ((-1053583277729 : ℝ) / 1000000000000) := rb_log (show RB ((174343034433 : ℝ) / 500000000000) ((174343034433 : ℝ) / 500000000000) ((174343034433 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_475.1 dlower_log_475.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((136704395459 : ℝ) / 250000000000) ((21942522281 : ℝ) / 40000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((165790519 : ℝ) / 31250000000) ((2295715033 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((6204023681 : ℝ) / 1000000000000) ((1277321403 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((724290966401 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1442195325787 : ℝ) / 1000000000000) ((1442377909121 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((724290966401 : ℝ) / 500000000000) ((724290966401 : ℝ) / 500000000000) ((724290966401 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((224290966401 : ℝ) / 500000000000))
  have h19 : RB z19 ((200938114691 : ℝ) / 62500000000) ((803854214609 : ℝ) / 250000000000) := rb_div_signed h18 (show RB ((224290966401 : ℝ) / 500000000000) ((224290966401 : ℝ) / 500000000000) ((224290966401 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1167830416799 : ℝ) / 1000000000000) ((1167957009763 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_476.1 dlower_log_477.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((917553185723 : ℝ) / 1000000000000) ((920060978279 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((724290966401 : ℝ) / 500000000000))
  have h22 : RB z22 ((370585100521 : ℝ) / 1000000000000) ((370585100523 : ℝ) / 1000000000000) := rb_log (show RB ((724290966401 : ℝ) / 500000000000) ((724290966401 : ℝ) / 500000000000) ((724290966401 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_478.1 dlower_log_478.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((1367420213 : ℝ) / 2500000000) ((274737938879 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1363949993 : ℝ) / 250000000000) ((2019136173 : ℝ) / 200000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1078765624999 : ℝ) / 1000000000000) ((863933 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1163735273679 : ℝ) / 1000000000000) ((233243821403 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1714943605339 : ℝ) / 1000000000000) ((859301958631 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((8592936437 : ℝ) / 7812500000))
  have h28 : RB z28 ((377251875679 : ℝ) / 200000000000) ((1890285340341 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((8592936437 : ℝ) / 7812500000) ((8592936437 : ℝ) / 7812500000) ((8592936437 : ℝ) / 7812500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((6204023681 : ℝ) / 1000000000000) ((1277321403 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((126275084894760389085633 : ℝ) / 250000000000000000000000))
  have h30 : RB z30 ((12282754919 : ℝ) / 1000000000000) ((6322117127 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((126275084894760389085633 : ℝ) / 250000000000000000000000) ((126275084894760389085633 : ℝ) / 250000000000000000000000) ((126275084894760389085633 : ℝ) / 250000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((493677882873 : ℝ) / 500000000000) ((987717245081 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((37248181459 : ℝ) / 20000000000) ((1867067428779 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((174343034433 : ℝ) / 500000000000)) ((165790519 : ℝ) / 31250000000) ((2295715033 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((724290966401 : ℝ) / 500000000000)) ((1363949993 : ℝ) / 250000000000) ((2019136173 : ℝ) / 200000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((174343034433 : ℝ) / 500000000000)) (wl := ((724290966401 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((37248181459 : ℝ) / 20000000000) ≤ D0q (q) * (((724290966401 : ℝ) / 500000000000) - ((174343034433 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((724290966401 : ℝ) / 500000000000) * ((174343034433 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
