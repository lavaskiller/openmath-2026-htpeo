import LeanProject.Stage8Prop

/-!
# EP-1038: cores of Lemma 7.4 (half-mass bound) and Lemma 7.6 (endpoint window)

* `half_mass` — Lemma 7.4(iii): at the right end `β > 0` of the main component, the distances
  `z_i = |β - root_i|` satisfy `∏ z_i = 1` (because `|f(β)| = 1`) and
  `∑ z_i ≤ a (1 + β) + m (1 - β)` (`a` main roots at distance `1 + β`, `m` residual roots at distance
  `≤ 1 - β`). Then `a ≥ m`, i.e. the main mass `A = a/(a+m) ≥ 1/2`.
* `window` — Lemma 7.6: if `r^k (2 + r) < 1` then `k log r + ∑ q_i log (d_i + r) < 0` for weights
  `q_i ≥ 0`, `∑ q_i = 1`, `d_i ≤ 2`.
-/

open Real Finset

namespace EP1038

theorem half_mass {n a m : ℕ} (hn : n = a + m) (hpos : 0 < n) (z : Fin n → ℝ)
    (hz : ∀ i, 0 ≤ z i) (hprod : ∏ i, z i = 1) {β : ℝ} (hβ : 0 < β)
    (hsum : ∑ i, z i ≤ a * (1 + β) + m * (1 - β)) : m ≤ a := by
  have hamgm := amgm_prod_le hpos z hz
  rw [hprod] at hamgm
  have hn' : (0 : ℝ) < n := by exact_mod_cast hpos
  -- the arithmetic mean is ≥ 1
  have hmean : 1 ≤ (∑ i, z i) / n := by
    by_contra h
    push_neg at h
    have h0 : 0 ≤ (∑ i, z i) / n := div_nonneg (sum_nonneg fun i _ => hz i) hn'.le
    have : ((∑ i, z i) / n) ^ n < 1 := pow_lt_one₀ h0 h hpos.ne'
    linarith
  rw [le_div_iff₀ hn', one_mul] at hmean
  have hcast : (n : ℝ) = a + m := by exact_mod_cast hn
  by_contra hlt
  push_neg at hlt
  have hlt' : (a : ℝ) < m := by exact_mod_cast hlt
  nlinarith

theorem window {N : ℕ} (q d : Fin N → ℝ) (hq : ∀ i, 0 ≤ q i) (hq1 : ∑ i, q i = 1)
    (hd : ∀ i, d i ≤ 2) (hd0 : ∀ i, 0 < d i) {k r : ℝ} (hr : 0 < r)
    (hwin : r ^ k * (2 + r) < 1) :
    k * Real.log r + ∑ i, q i * Real.log (d i + r) < 0 := by
  have h1 : ∑ i, q i * Real.log (d i + r) ≤ Real.log (2 + r) := by
    calc ∑ i, q i * Real.log (d i + r) ≤ ∑ i, q i * Real.log (2 + r) :=
          sum_le_sum fun i _ => mul_le_mul_of_nonneg_left
            (Real.log_le_log (by linarith [hd0 i]) (by linarith [hd i])) (hq i)
      _ = Real.log (2 + r) := by rw [← sum_mul, hq1, one_mul]
  have h2 : k * Real.log r + Real.log (2 + r) = Real.log (r ^ k * (2 + r)) := by
    rw [Real.log_mul (by positivity) (by positivity), Real.log_rpow hr]
  have h3 : Real.log (r ^ k * (2 + r)) < 0 := Real.log_neg (by positivity) hwin
  linarith

end EP1038
