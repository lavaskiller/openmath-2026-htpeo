import LeanProject.COVLogTwo
import LeanProject.COVLogBounds04
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_640 : RB (Real.log ((25742569 : ℝ) / 20000000)) ((6310343 : ℝ) / 25000000) ((25241373 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((25742569 : ℝ) / 20000000)) (t := ((5742569 : ℝ) / 45742569))
    (lo := ((6310343 : ℝ) / 25000000)) (hi := ((25241373 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_641 : RB (Real.log ((111509733 : ℝ) / 25000000)) ((29904721 : ℝ) / 20000000) ((18690451 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((111509733 : ℝ) / 100000000)) (t := ((11509733 : ℝ) / 211509733))
    (lo := ((10894169 : ℝ) / 100000000)) (hi := ((1089417 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111509733 : ℝ) / 25000000) = Real.log ((111509733 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((111509733 : ℝ) / 25000000) = ((111509733 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_642 : RB (Real.log ((111510089 : ℝ) / 25000000)) ((37380981 : ℝ) / 25000000) ((149523927 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((111510089 : ℝ) / 100000000)) (t := ((11510089 : ℝ) / 211510089))
    (lo := ((1361811 : ℝ) / 12500000)) (hi := ((10894489 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111510089 : ℝ) / 25000000) = Real.log ((111510089 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((111510089 : ℝ) / 25000000) = ((111510089 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_643 : RB (Real.log ((64447091 : ℝ) / 50000000)) ((12691079 : ℝ) / 50000000) ((25382159 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64447091 : ℝ) / 50000000)) (t := ((14447091 : ℝ) / 114447091))
    (lo := ((12691079 : ℝ) / 50000000)) (hi := ((25382159 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_644 : RB (Real.log ((7847627 : ℝ) / 100000000)) ((-7952997 : ℝ) / 3125000) ((-254495899 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7847627 : ℝ) / 6250000)) (t := ((1597627 : ℝ) / 14097627))
    (lo := ((5690743 : ℝ) / 25000000)) (hi := ((22762973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7847627 : ℝ) / 100000000) = Real.log ((7847627 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7847627 : ℝ) / 100000000) = ((7847627 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_645 : RB (Real.log ((8863869 : ℝ) / 100000000)) ((-242318687 : ℝ) / 100000000) ((-242318683 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8863869 : ℝ) / 12500000)) (t := ((-3636131 : ℝ) / 21363869))
    (lo := ((-3437453 : ℝ) / 10000000)) (hi := ((-34374529 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8863869 : ℝ) / 100000000) = Real.log ((8863869 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((8863869 : ℝ) / 100000000) = ((8863869 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_646 : RB (Real.log ((587059 : ℝ) / 25000000)) ((-375150583 : ℝ) / 100000000) ((-375150577 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((587059 : ℝ) / 781250)) (t := ((-194191 : ℝ) / 1368309))
    (lo := ((-7144247 : ℝ) / 25000000)) (hi := ((-28576987 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((587059 : ℝ) / 25000000) = Real.log ((587059 : ℝ) / 781250) - 5 * Real.log 2 := by
    rw [show ((587059 : ℝ) / 25000000) = ((587059 : ℝ) / 781250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_647 : RB (Real.log ((2382047 : ℝ) / 100000000)) ((-93430251 : ℝ) / 25000000) ((-186860499 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2382047 : ℝ) / 3125000)) (t := ((-742953 : ℝ) / 5507047))
    (lo := ((-27147409 : ℝ) / 100000000)) (hi := ((-1696713 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2382047 : ℝ) / 100000000) = Real.log ((2382047 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2382047 : ℝ) / 100000000) = ((2382047 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_648 : RB (Real.log ((2907261 : ℝ) / 4000000)) ((-31908297 : ℝ) / 100000000) ((-3988537 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((2907261 : ℝ) / 4000000)) (t := ((-1092739 : ℝ) / 6907261))
    (lo := ((-31908297 : ℝ) / 100000000)) (hi := ((-3988537 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_649 : RB (Real.log ((36341123 : ℝ) / 50000000)) ((-6381461 : ℝ) / 20000000) ((-3988413 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((36341123 : ℝ) / 50000000)) (t := ((-13658877 : ℝ) / 86341123))
    (lo := ((-6381461 : ℝ) / 20000000)) (hi := ((-3988413 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_650 : RB (Real.log ((1315587 : ℝ) / 3125000)) ((-43257567 : ℝ) / 50000000) ((-21628783 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1315587 : ℝ) / 1562500)) (t := ((-246913 : ℝ) / 2878087))
    (lo := ((-3440083 : ℝ) / 20000000)) (hi := ((-8600207 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1315587 : ℝ) / 3125000) = Real.log ((1315587 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((1315587 : ℝ) / 3125000) = ((1315587 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_651 : RB (Real.log ((97571597 : ℝ) / 50000000)) ((66856343 : ℝ) / 100000000) ((13371269 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((97571597 : ℝ) / 100000000)) (t := ((-2428403 : ℝ) / 197571597))
    (lo := ((-19667 : ℝ) / 800000)) (hi := ((-1229187 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97571597 : ℝ) / 50000000) = Real.log ((97571597 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97571597 : ℝ) / 50000000) = ((97571597 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_652 : RB (Real.log ((97604227 : ℝ) / 50000000)) ((66889779 : ℝ) / 100000000) ((66889781 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((97604227 : ℝ) / 100000000)) (t := ((-2395773 : ℝ) / 197604227))
    (lo := ((-2424939 : ℝ) / 100000000)) (hi := ((-1212469 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97604227 : ℝ) / 50000000) = Real.log ((97604227 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97604227 : ℝ) / 50000000) = ((97604227 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_653 : RB (Real.log ((36895027 : ℝ) / 50000000)) ((-118729 : ℝ) / 390625) ((-30394623 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36895027 : ℝ) / 50000000)) (t := ((-13104973 : ℝ) / 86895027))
    (lo := ((-118729 : ℝ) / 390625)) (hi := ((-30394623 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_654 : RB (Real.log ((3689539 : ℝ) / 5000000)) ((-759841 : ℝ) / 2500000) ((-30393639 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3689539 : ℝ) / 5000000)) (t := ((-1310461 : ℝ) / 8689539))
    (lo := ((-759841 : ℝ) / 2500000)) (hi := ((-30393639 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_655 : RB (Real.log ((4246811 : ℝ) / 10000000)) ((-21410419 : ℝ) / 25000000) ((-42820837 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4246811 : ℝ) / 5000000)) (t := ((-753189 : ℝ) / 9246811))
    (lo := ((-16326957 : ℝ) / 100000000)) (hi := ((-4081739 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4246811 : ℝ) / 10000000) = Real.log ((4246811 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((4246811 : ℝ) / 10000000) = ((4246811 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_656 : RB (Real.log ((111872341 : ℝ) / 25000000)) ((74924129 : ℝ) / 50000000) ((149848261 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((111872341 : ℝ) / 100000000)) (t := ((11872341 : ℝ) / 211872341))
    (lo := ((5609411 : ℝ) / 50000000)) (hi := ((11218823 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111872341 : ℝ) / 25000000) = Real.log ((111872341 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((111872341 : ℝ) / 25000000) = ((111872341 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_657 : RB (Real.log ((89498163 : ℝ) / 20000000)) ((74924291 : ℝ) / 50000000) ((29969717 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((89498163 : ℝ) / 80000000)) (t := ((9498163 : ℝ) / 169498163))
    (lo := ((5609573 : ℝ) / 50000000)) (hi := ((11219147 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89498163 : ℝ) / 20000000) = Real.log ((89498163 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((89498163 : ℝ) / 20000000) = ((89498163 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_658 : RB (Real.log ((128773457 : ℝ) / 100000000)) ((6322113 : ℝ) / 25000000) ((25288453 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((128773457 : ℝ) / 100000000)) (t := ((28773457 : ℝ) / 228773457))
    (lo := ((6322113 : ℝ) / 25000000)) (hi := ((25288453 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_659 : RB (Real.log ((13916221 : ℝ) / 3125000)) ((29872417 : ℝ) / 20000000) ((18670261 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((13916221 : ℝ) / 12500000)) (t := ((1416221 : ℝ) / 26416221))
    (lo := ((10732649 : ℝ) / 100000000)) (hi := ((214653 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13916221 : ℝ) / 3125000) = Real.log ((13916221 : ℝ) / 12500000) + 2 * Real.log 2 := by
    rw [show ((13916221 : ℝ) / 3125000) = ((13916221 : ℝ) / 12500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_660 : RB (Real.log ((445320513 : ℝ) / 100000000)) ((18670301 : ℝ) / 12500000) ((149362411 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((445320513 : ℝ) / 400000000)) (t := ((45320513 : ℝ) / 845320513))
    (lo := ((2683243 : ℝ) / 25000000)) (hi := ((10732973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((445320513 : ℝ) / 100000000) = Real.log ((445320513 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((445320513 : ℝ) / 100000000) = ((445320513 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_661 : RB (Real.log ((25790859 : ℝ) / 20000000)) ((5085757 : ℝ) / 20000000) ((12714393 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((25790859 : ℝ) / 20000000)) (t := ((5790859 : ℝ) / 45790859))
    (lo := ((5085757 : ℝ) / 20000000)) (hi := ((12714393 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_662 : RB (Real.log ((98701 : ℝ) / 1250000)) ((-253880379 : ℝ) / 100000000) ((-126940187 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((98701 : ℝ) / 78125)) (t := ((10288 : ℝ) / 88413))
    (lo := ((23378497 : ℝ) / 100000000)) (hi := ((11689249 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98701 : ℝ) / 1250000) = Real.log ((98701 : ℝ) / 78125) - 4 * Real.log 2 := by
    rw [show ((98701 : ℝ) / 1250000) = ((98701 : ℝ) / 78125) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_663 : RB (Real.log ((4450407 : ℝ) / 50000000)) ((-241902749 : ℝ) / 100000000) ((-48380549 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((4450407 : ℝ) / 6250000)) (t := ((-1799593 : ℝ) / 10700407))
    (lo := ((-530603 : ℝ) / 1562500)) (hi := ((-33958591 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4450407 : ℝ) / 50000000) = Real.log ((4450407 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4450407 : ℝ) / 50000000) = ((4450407 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_664 : RB (Real.log ((595113 : ℝ) / 25000000)) ((-74757597 : ℝ) / 20000000) ((-373787979 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((595113 : ℝ) / 781250)) (t := ((-186137 : ℝ) / 1376363))
    (lo := ((-2721439 : ℝ) / 10000000)) (hi := ((-27214389 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((595113 : ℝ) / 25000000) = Real.log ((595113 : ℝ) / 781250) - 5 * Real.log 2 := by
    rw [show ((595113 : ℝ) / 25000000) = ((595113 : ℝ) / 781250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_665 : RB (Real.log ((1207143 : ℝ) / 50000000)) ((-74475333 : ℝ) / 20000000) ((-372376659 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1207143 : ℝ) / 1562500)) (t := ((-355357 : ℝ) / 2769643))
    (lo := ((-2580307 : ℝ) / 10000000)) (hi := ((-25803069 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1207143 : ℝ) / 50000000) = Real.log ((1207143 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1207143 : ℝ) / 50000000) = ((1207143 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_666 : RB (Real.log ((72336483 : ℝ) / 100000000)) ((-16192079 : ℝ) / 50000000) ((-32384157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((72336483 : ℝ) / 100000000)) (t := ((-27663517 : ℝ) / 172336483))
    (lo := ((-16192079 : ℝ) / 50000000)) (hi := ((-32384157 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_667 : RB (Real.log ((18084303 : ℝ) / 25000000)) ((-32383151 : ℝ) / 100000000) ((-647663 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((18084303 : ℝ) / 25000000)) (t := ((-6915697 : ℝ) / 43084303))
    (lo := ((-32383151 : ℝ) / 100000000)) (hi := ((-647663 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_668 : RB (Real.log ((20991551 : ℝ) / 50000000)) ((-867903 : ℝ) / 1000000) ((-43395149 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((20991551 : ℝ) / 25000000)) (t := ((-4008449 : ℝ) / 45991551))
    (lo := ((-17475581 : ℝ) / 100000000)) (hi := ((-873779 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20991551 : ℝ) / 50000000) = Real.log ((20991551 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20991551 : ℝ) / 50000000) = ((20991551 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_669 : RB (Real.log ((195077929 : ℝ) / 100000000)) ((16705723 : ℝ) / 25000000) ((33411447 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((195077929 : ℝ) / 200000000)) (t := ((-4922071 : ℝ) / 395077929))
    (lo := ((-1245913 : ℝ) / 50000000)) (hi := ((-99673 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195077929 : ℝ) / 100000000) = Real.log ((195077929 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195077929 : ℝ) / 100000000) = ((195077929 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_670 : RB (Real.log ((195143201 : ℝ) / 100000000)) ((33428173 : ℝ) / 50000000) ((16714087 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((195143201 : ℝ) / 200000000)) (t := ((-4856799 : ℝ) / 395143201))
    (lo := ((-614593 : ℝ) / 25000000)) (hi := ((-2458371 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195143201 : ℝ) / 100000000) = Real.log ((195143201 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195143201 : ℝ) / 100000000) = ((195143201 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_671 : RB (Real.log ((73797183 : ℝ) / 100000000)) ((-30384963 : ℝ) / 100000000) ((-15192481 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((73797183 : ℝ) / 100000000)) (t := ((-26202817 : ℝ) / 173797183))
    (lo := ((-30384963 : ℝ) / 100000000)) (hi := ((-15192481 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_672 : RB (Real.log ((73797917 : ℝ) / 100000000)) ((-949499 : ℝ) / 3125000) ((-30383967 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((73797917 : ℝ) / 100000000)) (t := ((-26202083 : ℝ) / 173797917))
    (lo := ((-949499 : ℝ) / 3125000)) (hi := ((-30383967 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_673 : RB (Real.log ((5308839 : ℝ) / 12500000)) ((-85635549 : ℝ) / 100000000) ((-85635547 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5308839 : ℝ) / 6250000)) (t := ((-941161 : ℝ) / 11558839))
    (lo := ((-1632083 : ℝ) / 10000000)) (hi := ((-16320829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5308839 : ℝ) / 12500000) = Real.log ((5308839 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5308839 : ℝ) / 12500000) = ((5308839 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_674 : RB (Real.log ((446759469 : ℝ) / 100000000)) ((18710627 : ℝ) / 12500000) ((149685019 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((446759469 : ℝ) / 400000000)) (t := ((46759469 : ℝ) / 846759469))
    (lo := ((552779 : ℝ) / 5000000)) (hi := ((11055581 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((446759469 : ℝ) / 100000000) = Real.log ((446759469 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((446759469 : ℝ) / 100000000) = ((446759469 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_675 : RB (Real.log ((446760933 : ℝ) / 100000000)) ((149685343 : ℝ) / 100000000) ((74842673 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((446760933 : ℝ) / 400000000)) (t := ((46760933 : ℝ) / 846760933))
    (lo := ((11055907 : ℝ) / 100000000)) (hi := ((2763977 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((446760933 : ℝ) / 100000000) = Real.log ((446760933 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((446760933 : ℝ) / 100000000) = ((446760933 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_676 : RB (Real.log ((128833901 : ℝ) / 100000000)) ((25335379 : ℝ) / 100000000) ((1266769 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((128833901 : ℝ) / 100000000)) (t := ((28833901 : ℝ) / 228833901))
    (lo := ((25335379 : ℝ) / 100000000)) (hi := ((1266769 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_677 : RB (Real.log ((222302069 : ℝ) / 50000000)) ((37300353 : ℝ) / 25000000) ((29840283 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((222302069 : ℝ) / 200000000)) (t := ((22302069 : ℝ) / 422302069))
    (lo := ((1321497 : ℝ) / 12500000)) (hi := ((10571977 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((222302069 : ℝ) / 50000000) = Real.log ((222302069 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((222302069 : ℝ) / 50000000) = ((222302069 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_678 : RB (Real.log ((444605593 : ℝ) / 100000000)) ((149201739 : ℝ) / 100000000) ((74600871 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((444605593 : ℝ) / 400000000)) (t := ((44605593 : ℝ) / 844605593))
    (lo := ((10572303 : ℝ) / 100000000)) (hi := ((660769 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((444605593 : ℝ) / 100000000) = Real.log ((444605593 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((444605593 : ℝ) / 100000000) = ((444605593 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_679 : RB (Real.log ((129014243 : ℝ) / 100000000)) ((12737631 : ℝ) / 50000000) ((25475263 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129014243 : ℝ) / 100000000)) (t := ((29014243 : ℝ) / 229014243))
    (lo := ((12737631 : ℝ) / 50000000)) (hi := ((25475263 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_680 : RB (Real.log ((7809119 : ℝ) / 100000000)) ((-7968369 : ℝ) / 3125000) ((-254987803 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7809119 : ℝ) / 6250000)) (t := ((1559119 : ℝ) / 14059119))
    (lo := ((5567767 : ℝ) / 25000000)) (hi := ((22271069 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7809119 : ℝ) / 100000000) = Real.log ((7809119 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7809119 : ℝ) / 100000000) = ((7809119 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_681 : RB (Real.log ((9077159 : ℝ) / 100000000)) ((-7498153 : ℝ) / 3125000) ((-59985223 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((9077159 : ℝ) / 12500000)) (t := ((-3422841 : ℝ) / 21577159))
    (lo := ((-31996739 : ℝ) / 100000000)) (hi := ((-15998369 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9077159 : ℝ) / 100000000) = Real.log ((9077159 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9077159 : ℝ) / 100000000) = ((9077159 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_682 : RB (Real.log ((2412667 : ℝ) / 100000000)) ((-186221873 : ℝ) / 50000000) ((-18622187 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((2412667 : ℝ) / 3125000)) (t := ((-712333 : ℝ) / 5537667))
    (lo := ((-25870151 : ℝ) / 100000000)) (hi := ((-517403 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2412667 : ℝ) / 100000000) = Real.log ((2412667 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2412667 : ℝ) / 100000000) = ((2412667 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_683 : RB (Real.log ((611631 : ℝ) / 25000000)) ((-1855251 : ℝ) / 500000) ((-185525097 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((611631 : ℝ) / 781250)) (t := ((-169619 : ℝ) / 1392881))
    (lo := ((-4895321 : ℝ) / 20000000)) (hi := ((-6119151 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((611631 : ℝ) / 25000000) = Real.log ((611631 : ℝ) / 781250) - 5 * Real.log 2 := by
    rw [show ((611631 : ℝ) / 25000000) = ((611631 : ℝ) / 781250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_684 : RB (Real.log ((72179849 : ℝ) / 100000000)) ((-1018779 : ℝ) / 3125000) ((-32600927 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((72179849 : ℝ) / 100000000)) (t := ((-27820151 : ℝ) / 172179849))
    (lo := ((-1018779 : ℝ) / 3125000)) (hi := ((-32600927 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_685 : RB (Real.log ((72180589 : ℝ) / 100000000)) ((-32599903 : ℝ) / 100000000) ((-16299951 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((72180589 : ℝ) / 100000000)) (t := ((-27819411 : ℝ) / 172180589))
    (lo := ((-32599903 : ℝ) / 100000000)) (hi := ((-16299951 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_686 : RB (Real.log ((10482643 : ℝ) / 25000000)) ((-173831 : ℝ) / 200000) ((-43457749 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((10482643 : ℝ) / 12500000)) (t := ((-2017357 : ℝ) / 22982643))
    (lo := ((-17600781 : ℝ) / 100000000)) (hi := ((-880039 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10482643 : ℝ) / 25000000) = Real.log ((10482643 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10482643 : ℝ) / 25000000) = ((10482643 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_687 : RB (Real.log ((195012653 : ℝ) / 100000000)) ((2671577 : ℝ) / 4000000) ((66789427 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((195012653 : ℝ) / 200000000)) (t := ((-4987347 : ℝ) / 395012653))
    (lo := ((-2525293 : ℝ) / 100000000)) (hi := ((-631323 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195012653 : ℝ) / 100000000) = Real.log ((195012653 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195012653 : ℝ) / 100000000) = ((195012653 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_688 : RB (Real.log ((12192371 : ℝ) / 6250000)) ((4176431 : ℝ) / 6250000) ((33411449 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((12192371 : ℝ) / 12500000)) (t := ((-307629 : ℝ) / 24692371))
    (lo := ((-1245911 : ℝ) / 50000000)) (hi := ((-2491821 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12192371 : ℝ) / 6250000) = Real.log ((12192371 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((12192371 : ℝ) / 6250000) = ((12192371 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_689 : RB (Real.log ((14723657 : ℝ) / 20000000)) ((-7656919 : ℝ) / 25000000) ((-1225107 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((14723657 : ℝ) / 20000000)) (t := ((-5276343 : ℝ) / 34723657))
    (lo := ((-7656919 : ℝ) / 25000000)) (hi := ((-1225107 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_690 : RB (Real.log ((73619031 : ℝ) / 100000000)) ((-30626663 : ℝ) / 100000000) ((-15313331 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((73619031 : ℝ) / 100000000)) (t := ((-26380969 : ℝ) / 173619031))
    (lo := ((-30626663 : ℝ) / 100000000)) (hi := ((-15313331 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_691 : RB (Real.log ((265073 : ℝ) / 625000)) ((-1072183 : ℝ) / 1250000) ((-42887319 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((265073 : ℝ) / 312500)) (t := ((-47427 : ℝ) / 577573))
    (lo := ((-16459921 : ℝ) / 100000000)) (hi := ((-205749 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((265073 : ℝ) / 625000) = Real.log ((265073 : ℝ) / 312500) - 1 * Real.log 2 := by
    rw [show ((265073 : ℝ) / 625000) = ((265073 : ℝ) / 312500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_692 : RB (Real.log ((44603459 : ℝ) / 10000000)) ((149522631 : ℝ) / 100000000) ((74761317 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((44603459 : ℝ) / 40000000)) (t := ((4603459 : ℝ) / 84603459))
    (lo := ((2178639 : ℝ) / 20000000)) (hi := ((2723299 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44603459 : ℝ) / 10000000) = Real.log ((44603459 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((44603459 : ℝ) / 10000000) = ((44603459 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_693 : RB (Real.log ((111509019 : ℝ) / 25000000)) ((37380741 : ℝ) / 25000000) ((149522967 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((111509019 : ℝ) / 100000000)) (t := ((11509019 : ℝ) / 211509019))
    (lo := ((1361691 : ℝ) / 12500000)) (hi := ((10893529 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111509019 : ℝ) / 25000000) = Real.log ((111509019 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((111509019 : ℝ) / 25000000) = ((111509019 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_694 : RB (Real.log ((128894179 : ℝ) / 100000000)) ((6345539 : ℝ) / 25000000) ((25382157 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((128894179 : ℝ) / 100000000)) (t := ((28894179 : ℝ) / 228894179))
    (lo := ((6345539 : ℝ) / 25000000)) (hi := ((25382157 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_695 : RB (Real.log ((443894043 : ℝ) / 100000000)) ((14904157 : ℝ) / 10000000) ((149041573 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((443894043 : ℝ) / 400000000)) (t := ((43894043 : ℝ) / 843894043))
    (lo := ((5206067 : ℝ) / 50000000)) (hi := ((2082427 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((443894043 : ℝ) / 100000000) = Real.log ((443894043 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((443894043 : ℝ) / 100000000) = ((443894043 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_696 : RB (Real.log ((2774347 : ℝ) / 625000)) ((149041903 : ℝ) / 100000000) ((74520953 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2774347 : ℝ) / 2500000)) (t := ((274347 : ℝ) / 5274347))
    (lo := ((10412467 : ℝ) / 100000000)) (hi := ((2603117 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2774347 : ℝ) / 625000) = Real.log ((2774347 : ℝ) / 2500000) + 2 * Real.log 2 := by
    rw [show ((2774347 : ℝ) / 625000) = ((2774347 : ℝ) / 2500000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_697 : RB (Real.log ((129074029 : ℝ) / 100000000)) ((3190199 : ℝ) / 12500000) ((25521593 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129074029 : ℝ) / 100000000)) (t := ((29074029 : ℝ) / 229074029))
    (lo := ((3190199 : ℝ) / 12500000)) (hi := ((25521593 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_698 : RB (Real.log ((786117 : ℝ) / 10000000)) ((-127161739 : ℝ) / 50000000) ((-254323473 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((786117 : ℝ) / 625000)) (t := ((161117 : ℝ) / 1411117))
    (lo := ((11467699 : ℝ) / 50000000)) (hi := ((22935399 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((786117 : ℝ) / 10000000) = Real.log ((786117 : ℝ) / 625000) - 4 * Real.log 2 := by
    rw [show ((786117 : ℝ) / 10000000) = ((786117 : ℝ) / 625000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_699 : RB (Real.log ((911477 : ℝ) / 10000000)) ((-59881851 : ℝ) / 25000000) ((-1197637 : ℝ) / 500000) := by
  have hm := log_bounds_of_series (x := ((911477 : ℝ) / 1250000)) (t := ((-338523 : ℝ) / 2161477))
    (lo := ((-31583247 : ℝ) / 100000000)) (hi := ((-15791623 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((911477 : ℝ) / 10000000) = Real.log ((911477 : ℝ) / 1250000) - 3 * Real.log 2 := by
    rw [show ((911477 : ℝ) / 10000000) = ((911477 : ℝ) / 1250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_700 : RB (Real.log ((2444883 : ℝ) / 100000000)) ((-371117297 : ℝ) / 100000000) ((-371117291 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2444883 : ℝ) / 3125000)) (t := ((-680117 : ℝ) / 5569883))
    (lo := ((-12271851 : ℝ) / 50000000)) (hi := ((-24543701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2444883 : ℝ) / 100000000) = Real.log ((2444883 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2444883 : ℝ) / 100000000) = ((2444883 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_701 : RB (Real.log ((61969 : ℝ) / 2500000)) ((-18487059 : ℝ) / 5000000) ((-184870587 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((61969 : ℝ) / 78125)) (t := ((-8078 : ℝ) / 70047))
    (lo := ((-4633517 : ℝ) / 20000000)) (hi := ((-723987 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61969 : ℝ) / 2500000) = Real.log ((61969 : ℝ) / 78125) - 5 * Real.log 2 := by
    rw [show ((61969 : ℝ) / 2500000) = ((61969 : ℝ) / 78125) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_702 : RB (Real.log ((72025421 : ℝ) / 100000000)) ((-16407553 : ℝ) / 50000000) ((-6563021 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((72025421 : ℝ) / 100000000)) (t := ((-27974579 : ℝ) / 172025421))
    (lo := ((-16407553 : ℝ) / 50000000)) (hi := ((-6563021 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_703 : RB (Real.log ((72026171 : ℝ) / 100000000)) ((-6562813 : ℝ) / 20000000) ((-2050879 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((72026171 : ℝ) / 100000000)) (t := ((-27973829 : ℝ) / 172026171))
    (lo := ((-6562813 : ℝ) / 20000000)) (hi := ((-2050879 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_704 : RB (Real.log ((8375739 : ℝ) / 20000000)) ((-43519649 : ℝ) / 50000000) ((-1359989 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((8375739 : ℝ) / 10000000)) (t := ((-1624261 : ℝ) / 18375739))
    (lo := ((-17724579 : ℝ) / 100000000)) (hi := ((-8862289 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8375739 : ℝ) / 20000000) = Real.log ((8375739 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8375739 : ℝ) / 20000000) = ((8375739 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_705 : RB (Real.log ((38989473 : ℝ) / 20000000)) ((66755941 : ℝ) / 100000000) ((66755943 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38989473 : ℝ) / 40000000)) (t := ((-1010527 : ℝ) / 78989473))
    (lo := ((-2558777 : ℝ) / 100000000)) (hi := ((-319847 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38989473 : ℝ) / 20000000) = Real.log ((38989473 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38989473 : ℝ) / 20000000) = ((38989473 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_706 : RB (Real.log ((195012659 : ℝ) / 100000000)) ((16697357 : ℝ) / 25000000) ((6678943 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((195012659 : ℝ) / 200000000)) (t := ((-4987341 : ℝ) / 395012659))
    (lo := ((-252529 : ℝ) / 10000000)) (hi := ((-2525289 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195012659 : ℝ) / 100000000) = Real.log ((195012659 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195012659 : ℝ) / 100000000) = ((195012659 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_707 : RB (Real.log ((36721113 : ℝ) / 50000000)) ((-30867113 : ℝ) / 100000000) ((-3858389 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((36721113 : ℝ) / 50000000)) (t := ((-13278887 : ℝ) / 86721113))
    (lo := ((-30867113 : ℝ) / 100000000)) (hi := ((-3858389 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_708 : RB (Real.log ((36721491 : ℝ) / 50000000)) ((-7716521 : ℝ) / 25000000) ((-30866083 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36721491 : ℝ) / 50000000)) (t := ((-13278509 : ℝ) / 86721491))
    (lo := ((-7716521 : ℝ) / 25000000)) (hi := ((-30866083 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_709 : RB (Real.log ((42353473 : ℝ) / 100000000)) ((-42955989 : ℝ) / 50000000) ((-10738997 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((42353473 : ℝ) / 50000000)) (t := ((-7646527 : ℝ) / 92353473))
    (lo := ((-16597259 : ℝ) / 100000000)) (hi := ((-8298629 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42353473 : ℝ) / 100000000) = Real.log ((42353473 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42353473 : ℝ) / 100000000) = ((42353473 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_710 : RB (Real.log ((445314677 : ℝ) / 100000000)) ((74680549 : ℝ) / 50000000) ((149361101 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((445314677 : ℝ) / 400000000)) (t := ((45314677 : ℝ) / 845314677))
    (lo := ((5365831 : ℝ) / 50000000)) (hi := ((10731663 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((445314677 : ℝ) / 100000000) = Real.log ((445314677 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((445314677 : ℝ) / 100000000) = ((445314677 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_711 : RB (Real.log ((22265809 : ℝ) / 5000000)) ((29872287 : ℝ) / 20000000) ((74680719 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((22265809 : ℝ) / 20000000)) (t := ((2265809 : ℝ) / 42265809))
    (lo := ((10731999 : ℝ) / 100000000)) (hi := ((2683 : ℝ) / 25000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22265809 : ℝ) / 5000000) = Real.log ((22265809 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((22265809 : ℝ) / 5000000) = ((22265809 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_712 : RB (Real.log ((32238573 : ℝ) / 25000000)) ((25428783 : ℝ) / 100000000) ((1589299 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((32238573 : ℝ) / 25000000)) (t := ((7238573 : ℝ) / 57238573))
    (lo := ((25428783 : ℝ) / 100000000)) (hi := ((1589299 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_713 : RB (Real.log ((443188763 : ℝ) / 100000000)) ((148882559 : ℝ) / 100000000) ((74441281 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((443188763 : ℝ) / 400000000)) (t := ((43188763 : ℝ) / 843188763))
    (lo := ((10253123 : ℝ) / 100000000)) (hi := ((2563281 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((443188763 : ℝ) / 100000000) = Real.log ((443188763 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((443188763 : ℝ) / 100000000) = ((443188763 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_714 : RB (Real.log ((443190257 : ℝ) / 100000000)) ((9305181 : ℝ) / 6250000) ((148882899 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((443190257 : ℝ) / 400000000)) (t := ((43190257 : ℝ) / 843190257))
    (lo := ((512673 : ℝ) / 5000000)) (hi := ((10253461 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((443190257 : ℝ) / 100000000) = Real.log ((443190257 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((443190257 : ℝ) / 100000000) = ((443190257 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_715 : RB (Real.log ((32283413 : ℝ) / 25000000)) ((12783887 : ℝ) / 50000000) ((1022711 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((32283413 : ℝ) / 25000000)) (t := ((7283413 : ℝ) / 57283413))
    (lo := ((12783887 : ℝ) / 50000000)) (hi := ((1022711 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_716 : RB (Real.log ((123657 : ℝ) / 1562500)) ((-126826541 : ℝ) / 50000000) ((-253653077 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((494628 : ℝ) / 390625)) (t := ((104003 : ℝ) / 885253))
    (lo := ((11802897 : ℝ) / 50000000)) (hi := ((4721159 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123657 : ℝ) / 1562500) = Real.log ((494628 : ℝ) / 390625) - 4 * Real.log 2 := by
    rw [show ((123657 : ℝ) / 1562500) = ((494628 : ℝ) / 390625) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_717 : RB (Real.log ((9153593 : ℝ) / 100000000)) ((-119551187 : ℝ) / 50000000) ((-23910237 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((9153593 : ℝ) / 12500000)) (t := ((-3346407 : ℝ) / 21653593))
    (lo := ((-31158217 : ℝ) / 100000000)) (hi := ((-3894777 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9153593 : ℝ) / 100000000) = Real.log ((9153593 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9153593 : ℝ) / 100000000) = ((9153593 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_718 : RB (Real.log ((1238549 : ℝ) / 50000000)) ((-92452063 : ℝ) / 25000000) ((-184904123 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1238549 : ℝ) / 1562500)) (t := ((-323951 : ℝ) / 2801049))
    (lo := ((-23234657 : ℝ) / 100000000)) (hi := ((-726083 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1238549 : ℝ) / 50000000) = Real.log ((1238549 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1238549 : ℝ) / 50000000) = ((1238549 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_719 : RB (Real.log ((2510999 : ℝ) / 100000000)) ((-92112239 : ℝ) / 25000000) ((-7368979 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((2510999 : ℝ) / 3125000)) (t := ((-614001 : ℝ) / 5635999))
    (lo := ((-21875361 : ℝ) / 100000000)) (hi := ((-136721 : ℝ) / 625000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2510999 : ℝ) / 100000000) = Real.log ((2510999 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2510999 : ℝ) / 100000000) = ((2510999 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
