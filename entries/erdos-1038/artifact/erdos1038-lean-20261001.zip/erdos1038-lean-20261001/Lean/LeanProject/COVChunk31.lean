import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk27
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_155 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((40304587 : ℝ) / 50000000) ((40511233 : ℝ) / 50000000))
    (hq : RB (qa a) ((1 : ℝ) / 25) ((21 : ℝ) / 500))
    (hd : RB (D0a a) ((184202091 : ℝ) / 100000000) ((184911243 : ℝ) / 100000000))
    : certE k a ((42356843 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((43592217 : ℝ) / 100000000) ∧ 0 < certE k a ((3567903 : ℝ) / 2500000) ∧ certE k a ((71628073 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1 : ℝ) / 625) ((441 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42356843 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((42180443 : ℝ) / 100000000) ((42196843 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((42356843 : ℝ) / 100000000) ((42356843 : ℝ) / 100000000) ((42356843 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57643157 : ℝ) / 100000000))
  have h3 : RB z3 ((73175109 : ℝ) / 100000000) ((1830089 : ℝ) / 2500000) := rb_div_signed h2 (show RB ((57643157 : ℝ) / 100000000) ((57643157 : ℝ) / 100000000) ((57643157 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-31231487 : ℝ) / 100000000) ((-31192613 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2595.1 cov_log_2596.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-25304521 : ℝ) / 100000000) ((-25144107 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42356843 : ℝ) / 100000000))
  have h6 : RB z6 ((-85904021 : ℝ) / 100000000) ((-85904019 : ℝ) / 100000000) := rb_log (show RB ((42356843 : ℝ) / 100000000) ((42356843 : ℝ) / 100000000) ((42356843 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2597.1 cov_log_2597.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((30299749 : ℝ) / 50000000) ((30379957 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((7635791 : ℝ) / 12500000) ((61470577 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2598.1 cov_log_2599.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-871079 : ℝ) / 100000000) ((-163207 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1 : ℝ) / 625) ((441 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43592217 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((43415817 : ℝ) / 100000000) ((43432217 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43592217 : ℝ) / 100000000) ((43592217 : ℝ) / 100000000) ((43592217 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56407783 : ℝ) / 100000000))
  have h12 : RB z12 ((76967777 : ℝ) / 100000000) ((19249213 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((56407783 : ℝ) / 100000000) ((56407783 : ℝ) / 100000000) ((56407783 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-13089167 : ℝ) / 50000000) ((-6535141 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_2600.1 cov_log_2601.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-5302583 : ℝ) / 25000000) ((-5267923 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43592217 : ℝ) / 100000000))
  have h15 : RB z15 ((-41514579 : ℝ) / 50000000) ((-20757289 : ℝ) / 25000000) := rb_log (show RB ((43592217 : ℝ) / 100000000) ((43592217 : ℝ) / 100000000) ((43592217 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2602.1 cov_log_2602.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((7727353 : ℝ) / 12500000) ((30978733 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((7635791 : ℝ) / 12500000) ((61470577 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2598.1 cov_log_2599.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((348247 : ℝ) / 100000000) ((435569 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1 : ℝ) / 625) ((441 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((3567903 : ℝ) / 2500000)) - (z19)
  have h20 : RB z20 ((3563493 : ℝ) / 2500000) ((3563903 : ℝ) / 2500000) := rb_widen (rb_sub (show RB ((3567903 : ℝ) / 2500000) ((3567903 : ℝ) / 2500000) ((3567903 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1067903 : ℝ) / 2500000))
  have h21 : RB z21 ((3336907 : ℝ) / 1000000) ((166864547 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((1067903 : ℝ) / 2500000) ((1067903 : ℝ) / 2500000) ((1067903 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((7531527 : ℝ) / 6250000) ((120515941 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2603.1 cov_log_2604.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((97137627 : ℝ) / 100000000) ((24411247 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((3567903 : ℝ) / 2500000))
  have h24 : RB z24 ((35568729 : ℝ) / 100000000) ((35568731 : ℝ) / 100000000) := rb_log (show RB ((3567903 : ℝ) / 2500000) ((3567903 : ℝ) / 2500000) ((3567903 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2605.1 cov_log_2605.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((481007 : ℝ) / 781250) ((62076259 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((7635791 : ℝ) / 12500000) ((61470577 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2598.1 cov_log_2599.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((98319 : ℝ) / 100000000) ((989931 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1 : ℝ) / 625) ((441 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((71628073 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((71539873 : ℝ) / 50000000) ((71548073 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((71628073 : ℝ) / 50000000) ((71628073 : ℝ) / 50000000) ((71628073 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((21628073 : ℝ) / 50000000))
  have h30 : RB z30 ((330773217 : ℝ) / 100000000) ((82702783 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((21628073 : ℝ) / 50000000) ((21628073 : ℝ) / 50000000) ((21628073 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((2990657 : ℝ) / 2500000) ((23927549 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_2606.1 cov_log_2607.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((24107439 : ℝ) / 25000000) ((24233363 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((71628073 : ℝ) / 50000000))
  have h33 : RB z33 ((35946407 : ℝ) / 100000000) ((35946409 : ℝ) / 100000000) := rb_log (show RB ((71628073 : ℝ) / 50000000) ((71628073 : ℝ) / 50000000) ((71628073 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2608.1 cov_log_2608.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((60483347 : ℝ) / 100000000) ((12197409 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((7635791 : ℝ) / 12500000) ((61470577 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2598.1 cov_log_2599.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-98723 : ℝ) / 10000000) ((-99283 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42356843 : ℝ) / 100000000)) ((-871079 : ℝ) / 100000000) ((-163207 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43592217 : ℝ) / 100000000)) ((348247 : ℝ) / 100000000) ((435569 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((3567903 : ℝ) / 2500000)) ((98319 : ℝ) / 100000000) ((989931 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((71628073 : ℝ) / 50000000)) ((-98723 : ℝ) / 10000000) ((-99283 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_155 {k A q d vp vm : ℝ}
    (hk : RB k ((415707807 : ℝ) / 100000000) ((10673471 : ℝ) / 2500000))
    (hA : RB A ((40304587 : ℝ) / 50000000) ((40511233 : ℝ) / 50000000))
    (hq : RB q ((1 : ℝ) / 25) ((21 : ℝ) / 500))
    (hd : RB d ((184202091 : ℝ) / 100000000) ((184911243 : ℝ) / 100000000))
    (hp : RB vp ((42356843 : ℝ) / 100000000) ((43592217 : ℝ) / 100000000))
    (hm : RB vm ((3567903 : ℝ) / 2500000) ((71628073 : ℝ) / 50000000))
    : FormulaPositiveZero k A q vp vm := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1 : ℝ) / 625) ((441 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((249559 : ℝ) / 250000) ((624 : ℝ) / 625) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((80466979 : ℝ) / 100000000) ((80892831 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((367037 : ℝ) / 100000000) ((208231 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49791769 : ℝ) / 50000000) ((99632963 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56407783 : ℝ) / 100000000) ((57643157 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((28086433 : ℝ) / 50000000) ((28715793 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((5604371 : ℝ) / 4000000) ((2880139 : ℝ) / 2000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1604371 : ℝ) / 4000000) ((880139 : ℝ) / 2000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((249559 : ℝ) / 250000) ((624 : ℝ) / 625) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((80466979 : ℝ) / 100000000) ((80892831 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((13961 : ℝ) / 12500000) ((123603 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99876397 : ℝ) / 100000000) ((12486039 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1067903 : ℝ) / 2500000) ((21628073 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((42663321 : ℝ) / 100000000) ((8641567 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((93116189 : ℝ) / 50000000) ((189607441 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((143116189 : ℝ) / 50000000) ((289607441 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((113618417 : ℝ) / 50000000) ((62329723 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((34529499 : ℝ) / 100000000) ((34936649 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((415707807 : ℝ) / 50000000) ((10673471 : ℝ) / 1250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2078539 : ℝ) / 6250000) ((35862863 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((26 : ℝ) / 25) ((521 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((6383229 : ℝ) / 20000000) ((34483523 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((26383229 : ℝ) / 20000000) ((134483523 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((99123903 : ℝ) / 100000000) ((100899303 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((91294151 : ℝ) / 50000000) ((46643539 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((30225021 : ℝ) / 50000000) ((62448531 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((25621 : ℝ) / 10000000) ((72953 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24927047 : ℝ) / 25000000) ((9974379 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((182055487 : ℝ) / 100000000) ((37219227 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((184202091 : ℝ) / 50000000) ((184911243 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((14736167 : ℝ) / 100000000) ((3106509 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((515707807 : ℝ) / 100000000) ((13173471 : ℝ) / 2500000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2796561 : ℝ) / 100000000) ((3011889 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((9175949 : ℝ) / 100000000) ((4957877 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((109175949 : ℝ) / 100000000) ((54957877 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((248087969 : ℝ) / 100000000) ((274040741 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((2792201 : ℝ) / 100000000) ((1471453 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((102792201 : ℝ) / 100000000) ((51471453 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((138647 : ℝ) / 390625) ((17982401 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((283581601 : ℝ) / 100000000) ((310005543 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((1982633 : ℝ) / 25000000) ((9337023 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((515707807 : ℝ) / 100000000) ((13173471 : ℝ) / 2500000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((26383229 : ℝ) / 10000000) ((134483523 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((261766333 : ℝ) / 100000000) ((284255541 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((69062411 : ℝ) / 10000000) ((191138433 : ℝ) / 25000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((67452133 : ℝ) / 100000000) ((15259787 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-39375199 : ℝ) / 100000000) ((-338139 : ℝ) / 1250000) := rb_log h47 (by norm_num) cov_log_2609.1 cov_log_2610.2
  have hap : RB (formApi k q) ((26383229 : ℝ) / 20000000) ((134483523 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-39375199 : ℝ) / 100000000) ((-338139 : ℝ) / 1250000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((239 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((9175949 : ℝ) / 100000000) ((4957877 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((173 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((54957877 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((239 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((173 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((995079 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((239 : ℝ) / 100) + hfun ((173 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_70, cov_h_68]
  have hP : (0 : ℝ) ≤ -(π * 0 / formApi k q) := by simp
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := 0) (hi := ((239 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_tparams_155 {q : ℝ} (hq : RB q ((1 : ℝ) / 25) ((21 : ℝ) / 500)) :
    RB (terminalK q) ((415707807 : ℝ) / 100000000) ((10673471 : ℝ) / 2500000) ∧
    RB (terminalK q / (terminalK q + 1)) ((40304587 : ℝ) / 50000000) ((40511233 : ℝ) / 50000000) ∧
    RB (D0q q) ((184202091 : ℝ) / 100000000) ((184911243 : ℝ) / 100000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((26 : ℝ) / 25) ((521 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := (z1) ^ 2
  have h2 : RB z2 ((676 : ℝ) / 625) ((271441 : ℝ) / 250000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z3 : ℝ := ((2 : ℝ)) / (z2)
  have h3 : RB z3 ((184202091 : ℝ) / 100000000) ((184911243 : ℝ) / 100000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (q)
  have h4 : RB z4 ((-80471897 : ℝ) / 25000000) ((-63401713 : ℝ) / 20000000) := rb_log hq (by norm_num) cov_log_2594.1 cov_log_2611.2
  let z5 : ℝ := ((0 : ℝ)) - (z4)
  have h5 : RB z5 ((63401713 : ℝ) / 20000000) ((80471897 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z3)
  have h6 : RB z6 ((7635791 : ℝ) / 12500000) ((61470577 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2598.1 cov_log_2599.2
  let z7 : ℝ := (z5) / (z6)
  have h7 : RB z7 ((515707807 : ℝ) / 100000000) ((13173471 : ℝ) / 2500000) := rb_div_signed h5 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) - ((1 : ℝ))
  have h8 : RB z8 ((415707807 : ℝ) / 100000000) ((10673471 : ℝ) / 2500000) := rb_widen (rb_sub h7 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z9 : ℝ := (z6) / (z5)
  have h9 : RB z9 ((9488767 : ℝ) / 50000000) ((9695413 : ℝ) / 50000000) := rb_div_signed h6 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z9)
  have h10 : RB z10 ((40304587 : ℝ) / 50000000) ((40511233 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  have hd : RB (D0q q) ((184202091 : ℝ) / 100000000) ((184911243 : ℝ) / 100000000) := by
    have hh := h3
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q] using hh
  have hk : RB (terminalK q) ((415707807 : ℝ) / 100000000) ((10673471 : ℝ) / 2500000) := by
    have hh := h8
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, terminalK, D0q, zero_sub] using hh
  have he : terminalK q / (terminalK q + 1) = 1 - Real.log (D0q q) / (-Real.log q) := by
    rw [terminal_mass_ratio hqd]
    unfold Aq
    rw [log_H_eq hqd.1]
    change (Real.log (D0q q) + Real.log q) / Real.log q = _
    field_simp [(log_q_neg hqd.1 (terminal_admissible hqd).2.1).ne] <;> ring
  have hA : RB (terminalK q / (terminalK q + 1)) ((40304587 : ℝ) / 50000000) ((40511233 : ℝ) / 50000000) := by
    rw [he]
    have hh := h10
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q, zero_sub] using hh
  exact ⟨hk, hA, hd⟩
theorem cov_terminal_155 {q : ℝ} (hq : RB q ((1 : ℝ) / 25) ((21 : ℝ) / 500)) : RatioCertified (terminalK q) := by
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  obtain ⟨hk, hA, hd0⟩ := cov_tparams_155 hq
  have hq0 : RB (qa (terminalA q)) ((1 : ℝ) / 25) ((21 : ℝ) / 500) := by rwa [terminal_qa hqd]
  have hd : RB (D0a (terminalA q)) ((184202091 : ℝ) / 100000000) ((184911243 : ℝ) / 100000000) := by rwa [terminal_D0 hqd]
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_155 hA hq0 hd
  apply terminal_ratio_certified_of_box hqd (pl := ((42356843 : ℝ) / 100000000)) (ph := ((43592217 : ℝ) / 100000000)) (ml := ((3567903 : ℝ) / 2500000)) (mh := ((71628073 : ℝ) / 50000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · intro vp hp vm hm
    exact cov_numeric_155 hk hA hq hd0 ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
