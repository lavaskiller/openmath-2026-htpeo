import LeanProject.COVLogTwo
import LeanProject.COVLogBounds06
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_800 : RB (Real.log ((441787723 : ℝ) / 100000000)) ((148565931 : ℝ) / 100000000) ((74282967 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((441787723 : ℝ) / 400000000)) (t := ((41787723 : ℝ) / 841787723))
    (lo := ((1987299 : ℝ) / 20000000)) (hi := ((621031 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((441787723 : ℝ) / 100000000) = Real.log ((441787723 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((441787723 : ℝ) / 100000000) = ((441787723 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_801 : RB (Real.log ((220894657 : ℝ) / 50000000)) ((148566291 : ℝ) / 100000000) ((74283147 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((220894657 : ℝ) / 200000000)) (t := ((20894657 : ℝ) / 420894657))
    (lo := ((1987371 : ℝ) / 20000000)) (hi := ((1242107 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((220894657 : ℝ) / 50000000) = Real.log ((220894657 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((220894657 : ℝ) / 50000000) = ((220894657 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_802 : RB (Real.log ((64626207 : ℝ) / 50000000)) ((256597 : ℝ) / 1000000) ((25659701 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64626207 : ℝ) / 50000000)) (t := ((14626207 : ℝ) / 114626207))
    (lo := ((256597 : ℝ) / 1000000)) (hi := ((25659701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_803 : RB (Real.log ((439732517 : ℝ) / 100000000)) ((148099643 : ℝ) / 100000000) ((74049823 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((439732517 : ℝ) / 400000000)) (t := ((39732517 : ℝ) / 839732517))
    (lo := ((9470207 : ℝ) / 100000000)) (hi := ((36993 : ℝ) / 390625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((439732517 : ℝ) / 100000000) = Real.log ((439732517 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((439732517 : ℝ) / 100000000) = ((439732517 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_804 : RB (Real.log ((219867049 : ℝ) / 50000000)) ((148100003 : ℝ) / 100000000) ((74050003 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((219867049 : ℝ) / 200000000)) (t := ((19867049 : ℝ) / 419867049))
    (lo := ((9470567 : ℝ) / 100000000)) (hi := ((1183821 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((219867049 : ℝ) / 50000000) = Real.log ((219867049 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((219867049 : ℝ) / 50000000) = ((219867049 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_805 : RB (Real.log ((1011167 : ℝ) / 781250)) ((12898259 : ℝ) / 50000000) ((25796519 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1011167 : ℝ) / 781250)) (t := ((229917 : ℝ) / 1792417))
    (lo := ((12898259 : ℝ) / 50000000)) (hi := ((25796519 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_806 : RB (Real.log ((8189619 : ℝ) / 100000000)) ((-50046057 : ℝ) / 20000000) ((-6255757 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((8189619 : ℝ) / 6250000)) (t := ((1939619 : ℝ) / 14439619))
    (lo := ((27028591 : ℝ) / 100000000)) (hi := ((1689287 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8189619 : ℝ) / 100000000) = Real.log ((8189619 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((8189619 : ℝ) / 100000000) = ((8189619 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_807 : RB (Real.log ((585277 : ℝ) / 6250000)) ((-118412577 : ℝ) / 50000000) ((-4736503 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((585277 : ℝ) / 781250)) (t := ((-195973 : ℝ) / 1366527))
    (lo := ((-28880997 : ℝ) / 100000000)) (hi := ((-7220249 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((585277 : ℝ) / 6250000) = Real.log ((585277 : ℝ) / 781250) - 3 * Real.log 2 := by
    rw [show ((585277 : ℝ) / 6250000) = ((585277 : ℝ) / 781250) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_808 : RB (Real.log ((105527 : ℝ) / 4000000)) ((-72701657 : ℝ) / 20000000) ((-363508279 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((105527 : ℝ) / 125000)) (t := ((-19473 : ℝ) / 230527))
    (lo := ((-1693469 : ℝ) / 10000000)) (hi := ((-16934689 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((105527 : ℝ) / 4000000) = Real.log ((105527 : ℝ) / 125000) - 5 * Real.log 2 := by
    rw [show ((105527 : ℝ) / 4000000) = ((105527 : ℝ) / 125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_809 : RB (Real.log ((668047 : ℝ) / 25000000)) ((-362227263 : ℝ) / 100000000) ((-362227257 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((668047 : ℝ) / 781250)) (t := ((-113203 : ℝ) / 1449297))
    (lo := ((-3913417 : ℝ) / 25000000)) (hi := ((-15653667 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((668047 : ℝ) / 25000000) = Real.log ((668047 : ℝ) / 781250) - 5 * Real.log 2 := by
    rw [show ((668047 : ℝ) / 25000000) = ((668047 : ℝ) / 781250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_810 : RB (Real.log ((71141661 : ℝ) / 100000000)) ((-8512427 : ℝ) / 25000000) ((-34049707 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((71141661 : ℝ) / 100000000)) (t := ((-28858339 : ℝ) / 171141661))
    (lo := ((-8512427 : ℝ) / 25000000)) (hi := ((-34049707 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_811 : RB (Real.log ((17785617 : ℝ) / 25000000)) ((-34048573 : ℝ) / 100000000) ((-8512143 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((17785617 : ℝ) / 25000000)) (t := ((-7214383 : ℝ) / 42785617))
    (lo := ((-34048573 : ℝ) / 100000000)) (hi := ((-8512143 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_812 : RB (Real.log ((41580157 : ℝ) / 100000000)) ((-43877357 : ℝ) / 50000000) ((-10969339 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((41580157 : ℝ) / 50000000)) (t := ((-8419843 : ℝ) / 91580157))
    (lo := ((-3687999 : ℝ) / 20000000)) (hi := ((-9219997 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41580157 : ℝ) / 100000000) = Real.log ((41580157 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41580157 : ℝ) / 100000000) = ((41580157 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_813 : RB (Real.log ((194555399 : ℝ) / 100000000)) ((16638669 : ℝ) / 25000000) ((33277339 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((194555399 : ℝ) / 200000000)) (t := ((-5444601 : ℝ) / 394555399))
    (lo := ((-1380021 : ℝ) / 50000000)) (hi := ((-2760041 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194555399 : ℝ) / 100000000) = Real.log ((194555399 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194555399 : ℝ) / 100000000) = ((194555399 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_814 : RB (Real.log ((194620759 : ℝ) / 100000000)) ((13317653 : ℝ) / 20000000) ((66588267 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((194620759 : ℝ) / 200000000)) (t := ((-5379241 : ℝ) / 394620759))
    (lo := ((-2726453 : ℝ) / 100000000)) (hi := ((-681613 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194620759 : ℝ) / 100000000) = Real.log ((194620759 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194620759 : ℝ) / 100000000) = ((194620759 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_815 : RB (Real.log ((18110279 : ℝ) / 25000000)) ((-6447923 : ℝ) / 20000000) ((-16119807 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18110279 : ℝ) / 25000000)) (t := ((-6889721 : ℝ) / 43110279))
    (lo := ((-6447923 : ℝ) / 20000000)) (hi := ((-16119807 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_816 : RB (Real.log ((72441929 : ℝ) / 100000000)) ((-32238493 : ℝ) / 100000000) ((-8059623 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((72441929 : ℝ) / 100000000)) (t := ((-27558071 : ℝ) / 172441929))
    (lo := ((-32238493 : ℝ) / 100000000)) (hi := ((-8059623 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_817 : RB (Real.log ((10505097 : ℝ) / 25000000)) ((-86701527 : ℝ) / 100000000) ((-3468061 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((10505097 : ℝ) / 12500000)) (t := ((-1994903 : ℝ) / 23005097))
    (lo := ((-2173351 : ℝ) / 12500000)) (hi := ((-17386807 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10505097 : ℝ) / 25000000) = Real.log ((10505097 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10505097 : ℝ) / 25000000) = ((10505097 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_818 : RB (Real.log ((441096471 : ℝ) / 100000000)) ((148409341 : ℝ) / 100000000) ((579724 : ℝ) / 390625) := by
  have hm := log_bounds_of_series (x := ((441096471 : ℝ) / 400000000)) (t := ((41096471 : ℝ) / 841096471))
    (lo := ((1955981 : ℝ) / 20000000)) (hi := ((4889953 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((441096471 : ℝ) / 100000000) = Real.log ((441096471 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((441096471 : ℝ) / 100000000) = ((441096471 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_819 : RB (Real.log ((441098079 : ℝ) / 100000000)) ((74204853 : ℝ) / 50000000) ((148409709 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((441098079 : ℝ) / 400000000)) (t := ((41098079 : ℝ) / 841098079))
    (lo := ((978027 : ℝ) / 10000000)) (hi := ((9780271 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((441098079 : ℝ) / 100000000) = Real.log ((441098079 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((441098079 : ℝ) / 100000000) = ((441098079 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_820 : RB (Real.log ((64655779 : ℝ) / 50000000)) ((3213181 : ℝ) / 12500000) ((25705449 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((64655779 : ℝ) / 50000000)) (t := ((14655779 : ℝ) / 114655779))
    (lo := ((3213181 : ℝ) / 12500000)) (hi := ((25705449 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_821 : RB (Real.log ((8781099 : ℝ) / 2000000)) ((73972719 : ℝ) / 50000000) ((147945441 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8781099 : ℝ) / 8000000)) (t := ((781099 : ℝ) / 16781099))
    (lo := ((4658001 : ℝ) / 50000000)) (hi := ((9316003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8781099 : ℝ) / 2000000) = Real.log ((8781099 : ℝ) / 8000000) + 2 * Real.log 2 := by
    rw [show ((8781099 : ℝ) / 2000000) = ((8781099 : ℝ) / 8000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_822 : RB (Real.log ((109764137 : ℝ) / 25000000)) ((73972901 : ℝ) / 50000000) ((29589161 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((109764137 : ℝ) / 100000000)) (t := ((9764137 : ℝ) / 209764137))
    (lo := ((4658183 : ℝ) / 50000000)) (hi := ((9316367 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((109764137 : ℝ) / 25000000) = Real.log ((109764137 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((109764137 : ℝ) / 25000000) = ((109764137 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_823 : RB (Real.log ((129488049 : ℝ) / 100000000)) ((323023 : ℝ) / 1250000) ((25841841 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129488049 : ℝ) / 100000000)) (t := ((29488049 : ℝ) / 229488049))
    (lo := ((323023 : ℝ) / 1250000)) (hi := ((25841841 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_824 : RB (Real.log ((4123371 : ℝ) / 50000000)) ((-124767601 : ℝ) / 50000000) ((-249535197 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4123371 : ℝ) / 3125000)) (t := ((998371 : ℝ) / 7248371))
    (lo := ((13861837 : ℝ) / 50000000)) (hi := ((1108947 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4123371 : ℝ) / 50000000) = Real.log ((4123371 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((4123371 : ℝ) / 50000000) = ((4123371 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_825 : RB (Real.log ((9409659 : ℝ) / 100000000)) ((-4726867 : ℝ) / 2000000) ((-118171673 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9409659 : ℝ) / 12500000)) (t := ((-3090341 : ℝ) / 21909659))
    (lo := ((-28399193 : ℝ) / 100000000)) (hi := ((-3549899 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9409659 : ℝ) / 100000000) = Real.log ((9409659 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9409659 : ℝ) / 100000000) = ((9409659 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_826 : RB (Real.log ((2670391 : ℝ) / 100000000)) ((-362294533 : ℝ) / 100000000) ((-362294527 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2670391 : ℝ) / 3125000)) (t := ((-454609 : ℝ) / 5795391))
    (lo := ((-7860469 : ℝ) / 50000000)) (hi := ((-15720937 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2670391 : ℝ) / 100000000) = Real.log ((2670391 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2670391 : ℝ) / 100000000) = ((2670391 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_827 : RB (Real.log ((108177 : ℝ) / 4000000)) ((-90257023 : ℝ) / 25000000) ((-180514043 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((108177 : ℝ) / 125000)) (t := ((-16823 : ℝ) / 233177))
    (lo := ((-14454497 : ℝ) / 100000000)) (hi := ((-451703 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((108177 : ℝ) / 4000000) = Real.log ((108177 : ℝ) / 125000) - 5 * Real.log 2 := by
    rw [show ((108177 : ℝ) / 4000000) = ((108177 : ℝ) / 125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_828 : RB (Real.log ((35500483 : ℝ) / 50000000)) ((-34247671 : ℝ) / 100000000) ((-3424767 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((35500483 : ℝ) / 50000000)) (t := ((-14499517 : ℝ) / 85500483))
    (lo := ((-34247671 : ℝ) / 100000000)) (hi := ((-3424767 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_829 : RB (Real.log ((71001783 : ℝ) / 100000000)) ((-856163 : ℝ) / 2500000) ((-34246519 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((71001783 : ℝ) / 100000000)) (t := ((-28998217 : ℝ) / 171001783))
    (lo := ((-856163 : ℝ) / 2500000)) (hi := ((-34246519 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_830 : RB (Real.log ((41532369 : ℝ) / 100000000)) ((-8786971 : ℝ) / 10000000) ((-21967427 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((41532369 : ℝ) / 50000000)) (t := ((-8467631 : ℝ) / 91532369))
    (lo := ((-18554991 : ℝ) / 100000000)) (hi := ((-1855499 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41532369 : ℝ) / 100000000) = Real.log ((41532369 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41532369 : ℝ) / 100000000) = ((41532369 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_831 : RB (Real.log ((194490031 : ℝ) / 100000000)) ((4157567 : ℝ) / 6250000) ((33260537 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((194490031 : ℝ) / 200000000)) (t := ((-5509969 : ℝ) / 394490031))
    (lo := ((-1396823 : ℝ) / 50000000)) (hi := ((-558729 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194490031 : ℝ) / 100000000) = Real.log ((194490031 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194490031 : ℝ) / 100000000) = ((194490031 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_832 : RB (Real.log ((38911081 : ℝ) / 20000000)) ((66554679 : ℝ) / 100000000) ((66554681 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38911081 : ℝ) / 40000000)) (t := ((-1088919 : ℝ) / 78911081))
    (lo := ((-2760039 : ℝ) / 100000000)) (hi := ((-1380019 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38911081 : ℝ) / 20000000) = Real.log ((38911081 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38911081 : ℝ) / 20000000) = ((38911081 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_833 : RB (Real.log ((14456557 : ℝ) / 20000000)) ((-1622921 : ℝ) / 5000000) ((-32458419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((14456557 : ℝ) / 20000000)) (t := ((-5543443 : ℝ) / 34456557))
    (lo := ((-1622921 : ℝ) / 5000000)) (hi := ((-32458419 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_834 : RB (Real.log ((9035451 : ℝ) / 12500000)) ((-32457281 : ℝ) / 100000000) ((-101429 : ℝ) / 312500) := by
  have hm := log_bounds_of_series (x := ((9035451 : ℝ) / 12500000)) (t := ((-3464549 : ℝ) / 21535451))
    (lo := ((-32457281 : ℝ) / 100000000)) (hi := ((-101429 : ℝ) / 312500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_835 : RB (Real.log ((2098369 : ℝ) / 5000000)) ((-17365551 : ℝ) / 20000000) ((-86827753 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2098369 : ℝ) / 2500000)) (t := ((-401631 : ℝ) / 4598369))
    (lo := ((-4378259 : ℝ) / 25000000)) (hi := ((-3502607 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2098369 : ℝ) / 5000000) = Real.log ((2098369 : ℝ) / 2500000) - 1 * Real.log 2 := by
    rw [show ((2098369 : ℝ) / 5000000) = ((2098369 : ℝ) / 2500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_836 : RB (Real.log ((440409813 : ℝ) / 100000000)) ((148253549 : ℝ) / 100000000) ((9265847 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((440409813 : ℝ) / 400000000)) (t := ((40409813 : ℝ) / 840409813))
    (lo := ((9624113 : ℝ) / 100000000)) (hi := ((4812057 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((440409813 : ℝ) / 100000000) = Real.log ((440409813 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((440409813 : ℝ) / 100000000) = ((440409813 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_837 : RB (Real.log ((220205719 : ℝ) / 50000000)) ((74126959 : ℝ) / 50000000) ((148253921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((220205719 : ℝ) / 200000000)) (t := ((20205719 : ℝ) / 420205719))
    (lo := ((4812241 : ℝ) / 50000000)) (hi := ((9624483 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((220205719 : ℝ) / 50000000) = Real.log ((220205719 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((220205719 : ℝ) / 50000000) = ((220205719 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_838 : RB (Real.log ((8085659 : ℝ) / 6250000)) ((25751053 : ℝ) / 100000000) ((12875527 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8085659 : ℝ) / 6250000)) (t := ((1835659 : ℝ) / 14335659))
    (lo := ((25751053 : ℝ) / 100000000)) (hi := ((12875527 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_839 : RB (Real.log ((219190909 : ℝ) / 50000000)) ((147792007 : ℝ) / 100000000) ((14779201 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((219190909 : ℝ) / 200000000)) (t := ((19190909 : ℝ) / 419190909))
    (lo := ((9162571 : ℝ) / 100000000)) (hi := ((2290643 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((219190909 : ℝ) / 50000000) = Real.log ((219190909 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((219190909 : ℝ) / 50000000) = ((219190909 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_840 : RB (Real.log ((438383433 : ℝ) / 100000000)) ((1182339 : ℝ) / 800000) ((73896189 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((438383433 : ℝ) / 400000000)) (t := ((38383433 : ℝ) / 838383433))
    (lo := ((9162939 : ℝ) / 100000000)) (hi := ((458147 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((438383433 : ℝ) / 100000000) = Real.log ((438383433 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((438383433 : ℝ) / 100000000) = ((438383433 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_841 : RB (Real.log ((16193321 : ℝ) / 12500000)) ((12943511 : ℝ) / 50000000) ((25887023 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16193321 : ℝ) / 12500000)) (t := ((3693321 : ℝ) / 28693321))
    (lo := ((12943511 : ℝ) / 50000000)) (hi := ((25887023 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_842 : RB (Real.log ((4152233 : ℝ) / 50000000)) ((-248837679 : ℝ) / 100000000) ((-124418837 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4152233 : ℝ) / 3125000)) (t := ((1027233 : ℝ) / 7277233))
    (lo := ((28421197 : ℝ) / 100000000)) (hi := ((14210599 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4152233 : ℝ) / 50000000) = Real.log ((4152233 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((4152233 : ℝ) / 50000000) = ((4152233 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_843 : RB (Real.log ((9455813 : ℝ) / 100000000)) ((-235854053 : ℝ) / 100000000) ((-235854049 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9455813 : ℝ) / 12500000)) (t := ((-3044187 : ℝ) / 21955813))
    (lo := ((-3488737 : ℝ) / 12500000)) (hi := ((-5581979 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9455813 : ℝ) / 100000000) = Real.log ((9455813 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9455813 : ℝ) / 100000000) = ((9455813 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_844 : RB (Real.log ((1351303 : ℝ) / 50000000)) ((-2888763 : ℝ) / 800000) ((-361095369 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1351303 : ℝ) / 1562500)) (t := ((-211197 : ℝ) / 2913803))
    (lo := ((-726089 : ℝ) / 5000000)) (hi := ((-14521779 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1351303 : ℝ) / 50000000) = Real.log ((1351303 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1351303 : ℝ) / 50000000) = ((1351303 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_845 : RB (Real.log ((342083 : ℝ) / 12500000)) ((-179921529 : ℝ) / 50000000) ((-89960763 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((342083 : ℝ) / 390625)) (t := ((-24271 : ℝ) / 366354))
    (lo := ((-13269463 : ℝ) / 100000000)) (hi := ((-6634731 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((342083 : ℝ) / 12500000) = Real.log ((342083 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((342083 : ℝ) / 12500000) = ((342083 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_846 : RB (Real.log ((7086201 : ℝ) / 10000000)) ((-34443573 : ℝ) / 100000000) ((-8610893 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((7086201 : ℝ) / 10000000)) (t := ((-2913799 : ℝ) / 17086201))
    (lo := ((-34443573 : ℝ) / 100000000)) (hi := ((-8610893 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_847 : RB (Real.log ((35431419 : ℝ) / 50000000)) ((-8610601 : ℝ) / 25000000) ((-34442403 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35431419 : ℝ) / 50000000)) (t := ((-14568581 : ℝ) / 85431419))
    (lo := ((-8610601 : ℝ) / 25000000)) (hi := ((-34442403 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_848 : RB (Real.log ((20742551 : ℝ) / 50000000)) ((-87983583 : ℝ) / 100000000) ((-87983581 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20742551 : ℝ) / 25000000)) (t := ((-4257449 : ℝ) / 45742551))
    (lo := ((-291701 : ℝ) / 1562500)) (hi := ((-18668863 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20742551 : ℝ) / 50000000) = Real.log ((20742551 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20742551 : ℝ) / 50000000) = ((20742551 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_849 : RB (Real.log ((194424653 : ℝ) / 100000000)) ((66487451 : ℝ) / 100000000) ((66487453 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((194424653 : ℝ) / 200000000)) (t := ((-5575347 : ℝ) / 394424653))
    (lo := ((-2827267 : ℝ) / 100000000)) (hi := ((-1413633 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194424653 : ℝ) / 100000000) = Real.log ((194424653 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194424653 : ℝ) / 100000000) = ((194424653 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_850 : RB (Real.log ((97245019 : ℝ) / 50000000)) ((2660843 : ℝ) / 4000000) ((66521077 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((97245019 : ℝ) / 100000000)) (t := ((-2754981 : ℝ) / 197245019))
    (lo := ((-2793643 : ℝ) / 100000000)) (hi := ((-1396821 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97245019 : ℝ) / 50000000) = Real.log ((97245019 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97245019 : ℝ) / 50000000) = ((97245019 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_851 : RB (Real.log ((36063349 : ℝ) / 50000000)) ((-1021081 : ℝ) / 3125000) ((-32674591 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36063349 : ℝ) / 50000000)) (t := ((-13936651 : ℝ) / 86063349))
    (lo := ((-1021081 : ℝ) / 3125000)) (hi := ((-32674591 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_852 : RB (Real.log ((72127533 : ℝ) / 100000000)) ((-6534687 : ℝ) / 20000000) ((-16336717 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((72127533 : ℝ) / 100000000)) (t := ((-27872467 : ℝ) / 172127533))
    (lo := ((-6534687 : ℝ) / 20000000)) (hi := ((-16336717 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_853 : RB (Real.log ((10478759 : ℝ) / 25000000)) ((-43476279 : ℝ) / 50000000) ((-21738139 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((10478759 : ℝ) / 12500000)) (t := ((-2021241 : ℝ) / 22978759))
    (lo := ((-17637839 : ℝ) / 100000000)) (hi := ((-8818919 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10478759 : ℝ) / 25000000) = Real.log ((10478759 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10478759 : ℝ) / 25000000) = ((10478759 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_854 : RB (Real.log ((27482981 : ℝ) / 6250000)) ((148098547 : ℝ) / 100000000) ((2961971 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((27482981 : ℝ) / 25000000)) (t := ((2482981 : ℝ) / 52482981))
    (lo := ((9469111 : ℝ) / 100000000)) (hi := ((1183639 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((27482981 : ℝ) / 6250000) = Real.log ((27482981 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((27482981 : ℝ) / 6250000) = ((27482981 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_855 : RB (Real.log ((219864671 : ℝ) / 50000000)) ((148098921 : ℝ) / 100000000) ((37024731 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((219864671 : ℝ) / 200000000)) (t := ((19864671 : ℝ) / 419864671))
    (lo := ((1893897 : ℝ) / 20000000)) (hi := ((4734743 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((219864671 : ℝ) / 50000000) = Real.log ((219864671 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((219864671 : ℝ) / 50000000) = ((219864671 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_856 : RB (Real.log ((129429373 : ℝ) / 100000000)) ((6449129 : ℝ) / 25000000) ((25796517 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129429373 : ℝ) / 100000000)) (t := ((29429373 : ℝ) / 229429373))
    (lo := ((6449129 : ℝ) / 25000000)) (hi := ((25796517 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_857 : RB (Real.log ((437713079 : ℝ) / 100000000)) ((147639343 : ℝ) / 100000000) ((73819673 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((437713079 : ℝ) / 400000000)) (t := ((37713079 : ℝ) / 837713079))
    (lo := ((9009907 : ℝ) / 100000000)) (hi := ((2252477 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((437713079 : ℝ) / 100000000) = Real.log ((437713079 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((437713079 : ℝ) / 100000000) = ((437713079 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_858 : RB (Real.log ((87542943 : ℝ) / 20000000)) ((147639717 : ℝ) / 100000000) ((3690993 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((87542943 : ℝ) / 80000000)) (t := ((7542943 : ℝ) / 167542943))
    (lo := ((9010281 : ℝ) / 100000000)) (hi := ((4505141 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((87542943 : ℝ) / 20000000) = Real.log ((87542943 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((87542943 : ℝ) / 20000000) = ((87542943 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_859 : RB (Real.log ((129604933 : ℝ) / 100000000)) ((12966033 : ℝ) / 50000000) ((25932067 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((129604933 : ℝ) / 100000000)) (t := ((29604933 : ℝ) / 229604933))
    (lo := ((12966033 : ℝ) / 50000000)) (hi := ((25932067 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_860 : RB (Real.log ((209069 : ℝ) / 2500000)) ((-24813817 : ℝ) / 10000000) ((-124069083 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((209069 : ℝ) / 312500)) (t := ((-103431 : ℝ) / 521569))
    (lo := ((-40194013 : ℝ) / 100000000)) (hi := ((-10048503 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((209069 : ℝ) / 2500000) = Real.log ((209069 : ℝ) / 312500) - 3 * Real.log 2 := by
    rw [show ((209069 : ℝ) / 2500000) = ((209069 : ℝ) / 312500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_861 : RB (Real.log ((4751433 : ℝ) / 50000000)) ((-117678839 : ℝ) / 50000000) ((-117678837 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4751433 : ℝ) / 6250000)) (t := ((-1498567 : ℝ) / 11001433))
    (lo := ((-27413521 : ℝ) / 100000000)) (hi := ((-342669 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4751433 : ℝ) / 50000000) = Real.log ((4751433 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4751433 : ℝ) / 50000000) = ((4751433 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_862 : RB (Real.log ((2734821 : ℝ) / 100000000)) ((-14396417 : ℝ) / 4000000) ((-359910419 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2734821 : ℝ) / 3125000)) (t := ((-390179 : ℝ) / 5859821))
    (lo := ((-1333683 : ℝ) / 10000000)) (hi := ((-13336829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2734821 : ℝ) / 100000000) = Real.log ((2734821 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2734821 : ℝ) / 100000000) = ((2734821 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_863 : RB (Real.log ((2768901 : ℝ) / 100000000)) ((-14346879 : ℝ) / 4000000) ((-358671969 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2768901 : ℝ) / 3125000)) (t := ((-356099 : ℝ) / 5893901))
    (lo := ((-604919 : ℝ) / 5000000)) (hi := ((-12098379 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2768901 : ℝ) / 100000000) = Real.log ((2768901 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2768901 : ℝ) / 100000000) = ((2768901 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_864 : RB (Real.log ((1094431 : ℝ) / 1562500)) ((-35605251 : ℝ) / 100000000) ((-142421 : ℝ) / 400000) := by
  have hm := log_bounds_of_series (x := ((1094431 : ℝ) / 1562500)) (t := ((-468069 : ℝ) / 2656931))
    (lo := ((-35605251 : ℝ) / 100000000)) (hi := ((-142421 : ℝ) / 400000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_865 : RB (Real.log ((70045259 : ℝ) / 100000000)) ((-1780143 : ℝ) / 5000000) ((-35602859 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((70045259 : ℝ) / 100000000)) (t := ((-29954741 : ℝ) / 170045259))
    (lo := ((-1780143 : ℝ) / 5000000)) (hi := ((-35602859 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_866 : RB (Real.log ((20602023 : ℝ) / 50000000)) ((-709307 : ℝ) / 800000) ((-88663373 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20602023 : ℝ) / 25000000)) (t := ((-4397977 : ℝ) / 45602023))
    (lo := ((-1209291 : ℝ) / 6250000)) (hi := ((-3869731 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20602023 : ℝ) / 50000000) = Real.log ((20602023 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20602023 : ℝ) / 50000000) = ((20602023 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_867 : RB (Real.log ((24286733 : ℝ) / 12500000)) ((33210079 : ℝ) / 50000000) ((207563 : ℝ) / 312500) := by
  have hm := log_bounds_of_series (x := ((24286733 : ℝ) / 25000000)) (t := ((-713267 : ℝ) / 49286733))
    (lo := ((-18091 : ℝ) / 625000)) (hi := ((-2894559 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24286733 : ℝ) / 12500000) = Real.log ((24286733 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((24286733 : ℝ) / 12500000) = ((24286733 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_868 : RB (Real.log ((194424659 : ℝ) / 100000000)) ((33243727 : ℝ) / 50000000) ((2077733 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((194424659 : ℝ) / 200000000)) (t := ((-5575341 : ℝ) / 394424659))
    (lo := ((-11044 : ℝ) / 390625)) (hi := ((-2827263 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194424659 : ℝ) / 100000000) = Real.log ((194424659 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((194424659 : ℝ) / 100000000) = ((194424659 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_869 : RB (Real.log ((72523621 : ℝ) / 100000000)) ((-8031447 : ℝ) / 25000000) ((-32125787 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((72523621 : ℝ) / 100000000)) (t := ((-27476379 : ℝ) / 172523621))
    (lo := ((-8031447 : ℝ) / 25000000)) (hi := ((-32125787 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_870 : RB (Real.log ((1813133 : ℝ) / 2500000)) ((-6424689 : ℝ) / 20000000) ((-8030861 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1813133 : ℝ) / 2500000)) (t := ((-686867 : ℝ) / 4313133))
    (lo := ((-6424689 : ℝ) / 20000000)) (hi := ((-8030861 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_871 : RB (Real.log ((42049241 : ℝ) / 100000000)) ((-43316443 : ℝ) / 50000000) ((-21658221 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((42049241 : ℝ) / 50000000)) (t := ((-7950759 : ℝ) / 92049241))
    (lo := ((-17318167 : ℝ) / 100000000)) (hi := ((-8659083 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42049241 : ℝ) / 100000000) = Real.log ((42049241 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42049241 : ℝ) / 100000000) = ((42049241 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_872 : RB (Real.log ((219859523 : ℝ) / 50000000)) ((7404829 : ℝ) / 5000000) ((148096583 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((219859523 : ℝ) / 200000000)) (t := ((19859523 : ℝ) / 419859523))
    (lo := ((1183393 : ℝ) / 12500000)) (hi := ((1893429 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((219859523 : ℝ) / 50000000) = Real.log ((219859523 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((219859523 : ℝ) / 50000000) = ((219859523 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_873 : RB (Real.log ((43972239 : ℝ) / 10000000)) ((7404867 : ℝ) / 5000000) ((148097343 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((43972239 : ℝ) / 40000000)) (t := ((3972239 : ℝ) / 83972239))
    (lo := ((36984 : ℝ) / 390625)) (hi := ((1893581 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43972239 : ℝ) / 10000000) = Real.log ((43972239 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((43972239 : ℝ) / 10000000) = ((43972239 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_874 : RB (Real.log ((129429833 : ℝ) / 100000000)) ((25796871 : ℝ) / 100000000) ((3224609 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((129429833 : ℝ) / 100000000)) (t := ((29429833 : ℝ) / 229429833))
    (lo := ((25796871 : ℝ) / 100000000)) (hi := ((3224609 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_875 : RB (Real.log ((435729309 : ℝ) / 100000000)) ((147185101 : ℝ) / 100000000) ((9199069 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((435729309 : ℝ) / 400000000)) (t := ((35729309 : ℝ) / 835729309))
    (lo := ((1711133 : ℝ) / 20000000)) (hi := ((4277833 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((435729309 : ℝ) / 100000000) = Real.log ((435729309 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((435729309 : ℝ) / 100000000) = ((435729309 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_876 : RB (Real.log ((217866307 : ℝ) / 50000000)) ((147185859 : ℝ) / 100000000) ((73592931 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((217866307 : ℝ) / 200000000)) (t := ((17866307 : ℝ) / 417866307))
    (lo := ((8556423 : ℝ) / 100000000)) (hi := ((1069553 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((217866307 : ℝ) / 50000000) = Real.log ((217866307 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((217866307 : ℝ) / 50000000) = ((217866307 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_877 : RB (Real.log ((129779571 : ℝ) / 100000000)) ((26066721 : ℝ) / 100000000) ((13033361 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((129779571 : ℝ) / 100000000)) (t := ((29779571 : ℝ) / 229779571))
    (lo := ((26066721 : ℝ) / 100000000)) (hi := ((13033361 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_878 : RB (Real.log ((7895463 : ℝ) / 100000000)) ((-126944097 : ℝ) / 50000000) ((-253888189 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7895463 : ℝ) / 6250000)) (t := ((1645463 : ℝ) / 14145463))
    (lo := ((11685341 : ℝ) / 50000000)) (hi := ((23370683 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7895463 : ℝ) / 100000000) = Real.log ((7895463 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7895463 : ℝ) / 100000000) = ((7895463 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_879 : RB (Real.log ((10143251 : ℝ) / 100000000)) ((-114418083 : ℝ) / 50000000) ((-114418081 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((10143251 : ℝ) / 12500000)) (t := ((-2356749 : ℝ) / 22643251))
    (lo := ((-20892009 : ℝ) / 100000000)) (hi := ((-2611501 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10143251 : ℝ) / 100000000) = Real.log ((10143251 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((10143251 : ℝ) / 100000000) = ((10143251 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
