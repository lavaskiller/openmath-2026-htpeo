import LeanProject.DLowerMTools
import LeanProject.DLowerMLog02
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_200 : RB (Real.log ((22970838502423 : ℝ) / 50000000000000)) ((-777797485152088021 : ℝ) / 1000000000000000000) ((-777797485152088019 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((22970838502423 : ℝ) / 25000000000000)) (t := ((-2029161497577 : ℝ) / 47970838502423))
    (lo := ((-84650304592142711 : ℝ) / 1000000000000000000)) (hi := ((-8465030459214271 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22970838502423 : ℝ) / 50000000000000) = Real.log ((22970838502423 : ℝ) / 25000000000000) - 1 * Real.log 2 := by
    rw [show ((22970838502423 : ℝ) / 50000000000000) = ((22970838502423 : ℝ) / 25000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_201 : RB (Real.log ((459416770048463001 : ℝ) / 1000000000000000000)) ((-777797485152081489 : ℝ) / 1000000000000000000) ((-777797485152081487 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((459416770048463001 : ℝ) / 500000000000000000)) (t := ((-40583229951536999 : ℝ) / 959416770048463001))
    (lo := ((-84650304592136179 : ℝ) / 1000000000000000000)) (hi := ((-42325152296068089 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459416770048463001 : ℝ) / 1000000000000000000) = Real.log ((459416770048463001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((459416770048463001 : ℝ) / 1000000000000000000) = ((459416770048463001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_202 : RB (Real.log ((539942507295287 : ℝ) / 1000000000000000)) ((-616292613063624543 : ℝ) / 1000000000000000000) ((-616292613063624541 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((539942507295287 : ℝ) / 500000000000000)) (t := ((39942507295287 : ℝ) / 1039942507295287))
    (lo := ((76854567496320767 : ℝ) / 1000000000000000000)) (hi := ((300213154282503 : ℝ) / 3906250000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((539942507295287 : ℝ) / 1000000000000000) = Real.log ((539942507295287 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((539942507295287 : ℝ) / 1000000000000000) = ((539942507295287 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_203 : RB (Real.log ((53994250729529 : ℝ) / 100000000000000)) ((-616292613063618987 : ℝ) / 1000000000000000000) ((-123258522612723797 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((53994250729529 : ℝ) / 50000000000000)) (t := ((3994250729529 : ℝ) / 103994250729529))
    (lo := ((76854567496326323 : ℝ) / 1000000000000000000)) (hi := ((19213641874081581 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53994250729529 : ℝ) / 100000000000000) = Real.log ((53994250729529 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((53994250729529 : ℝ) / 100000000000000) = ((53994250729529 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_204 : RB (Real.log ((46005749270471 : ℝ) / 100000000000000)) ((-776403813168189433 : ℝ) / 1000000000000000000) ((-776403813168189431 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((46005749270471 : ℝ) / 50000000000000)) (t := ((-3994250729529 : ℝ) / 96005749270471))
    (lo := ((-83256632608244123 : ℝ) / 1000000000000000000)) (hi := ((-41628316304122061 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((46005749270471 : ℝ) / 100000000000000) = Real.log ((46005749270471 : ℝ) / 50000000000000) - 1 * Real.log 2 := by
    rw [show ((46005749270471 : ℝ) / 100000000000000) = ((46005749270471 : ℝ) / 50000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_205 : RB (Real.log ((460057492704713 : ℝ) / 1000000000000000)) ((-6065654790376429 : ℝ) / 7812500000000000) ((-77640381316818291 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((460057492704713 : ℝ) / 500000000000000)) (t := ((-39942507295287 : ℝ) / 960057492704713))
    (lo := ((-41628316304118801 : ℝ) / 500000000000000000)) (hi := ((-83256632608237601 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((460057492704713 : ℝ) / 1000000000000000) = Real.log ((460057492704713 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((460057492704713 : ℝ) / 1000000000000000) = ((460057492704713 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_206 : RB (Real.log ((459416770048460001 : ℝ) / 1000000000000000000)) ((-777797485152088019 : ℝ) / 1000000000000000000) ((-777797485152088017 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((459416770048460001 : ℝ) / 500000000000000000)) (t := ((-40583229951539999 : ℝ) / 959416770048460001))
    (lo := ((-84650304592142709 : ℝ) / 1000000000000000000)) (hi := ((-21162576148035677 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459416770048460001 : ℝ) / 1000000000000000000) = Real.log ((459416770048460001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((459416770048460001 : ℝ) / 1000000000000000000) = ((459416770048460001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_207 : RB (Real.log ((459416770048463 : ℝ) / 1000000000000000)) ((-777797485152081491 : ℝ) / 1000000000000000000) ((-777797485152081489 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((459416770048463 : ℝ) / 500000000000000)) (t := ((-40583229951537 : ℝ) / 959416770048463))
    (lo := ((-84650304592136181 : ℝ) / 1000000000000000000)) (hi := ((-4232515229606809 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459416770048463 : ℝ) / 1000000000000000) = Real.log ((459416770048463 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((459416770048463 : ℝ) / 1000000000000000) = ((459416770048463 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_208 : RB (Real.log ((284919939099329 : ℝ) / 200000000000000)) ((44236357351941199 : ℝ) / 125000000000000000) ((176945429407764797 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((284919939099329 : ℝ) / 400000000000000)) (t := ((-115080060900671 : ℝ) / 684919939099329))
    (lo := ((-339256321744415717 : ℝ) / 1000000000000000000)) (hi := ((-84814080436103929 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284919939099329 : ℝ) / 200000000000000) = Real.log ((284919939099329 : ℝ) / 400000000000000) + 1 * Real.log 2 := by
    rw [show ((284919939099329 : ℝ) / 200000000000000) = ((284919939099329 : ℝ) / 400000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_209 : RB (Real.log ((1424599695496648001 : ℝ) / 1000000000000000000)) ((353890858815531699 : ℝ) / 1000000000000000000) ((353890858815531701 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424599695496648001 : ℝ) / 2000000000000000000)) (t := ((-575400304503351999 : ℝ) / 3424599695496648001))
    (lo := ((-33925632174441361 : ℝ) / 100000000000000000)) (hi := ((-339256321744413609 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424599695496648001 : ℝ) / 1000000000000000000) = Real.log ((1424599695496648001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424599695496648001 : ℝ) / 1000000000000000000) = ((1424599695496648001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_210 : RB (Real.log ((85048083630579 : ℝ) / 200000000000000)) ((-213775145057086449 : ℝ) / 250000000000000000) ((-427550290114172897 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((85048083630579 : ℝ) / 100000000000000)) (t := ((-14951916369421 : ℝ) / 185048083630579))
    (lo := ((-80976699834200243 : ℝ) / 500000000000000000)) (hi := ((-32390679933680097 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85048083630579 : ℝ) / 200000000000000) = Real.log ((85048083630579 : ℝ) / 100000000000000) - 1 * Real.log 2 := by
    rw [show ((85048083630579 : ℝ) / 200000000000000) = ((85048083630579 : ℝ) / 100000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_211 : RB (Real.log ((212620209076449 : ℝ) / 500000000000000)) ((-855100580228338741 : ℝ) / 1000000000000000000) ((-855100580228338739 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((212620209076449 : ℝ) / 250000000000000)) (t := ((-37379790923551 : ℝ) / 462620209076449))
    (lo := ((-161953399668393431 : ℝ) / 1000000000000000000)) (hi := ((-16195339966839343 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((212620209076449 : ℝ) / 500000000000000) = Real.log ((212620209076449 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((212620209076449 : ℝ) / 500000000000000) = ((212620209076449 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_212 : RB (Real.log ((285048083630579 : ℝ) / 200000000000000)) ((88585128495795993 : ℝ) / 250000000000000000) ((177170256991591987 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((285048083630579 : ℝ) / 400000000000000)) (t := ((-114951916369421 : ℝ) / 685048083630579))
    (lo := ((-338806666576761337 : ℝ) / 1000000000000000000)) (hi := ((-42350833322095167 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285048083630579 : ℝ) / 200000000000000) = Real.log ((285048083630579 : ℝ) / 400000000000000) + 1 * Real.log 2 := by
    rw [show ((285048083630579 : ℝ) / 200000000000000) = ((285048083630579 : ℝ) / 400000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_213 : RB (Real.log ((712620209076449 : ℝ) / 500000000000000)) ((354340513983186077 : ℝ) / 1000000000000000000) ((354340513983186079 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((712620209076449 : ℝ) / 1000000000000000)) (t := ((-287379790923551 : ℝ) / 1712620209076449))
    (lo := ((-5293854165261863 : ℝ) / 15625000000000000)) (hi := ((-338806666576759231 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712620209076449 : ℝ) / 500000000000000) = Real.log ((712620209076449 : ℝ) / 1000000000000000) + 1 * Real.log 2 := by
    rw [show ((712620209076449 : ℝ) / 500000000000000) = ((712620209076449 : ℝ) / 1000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_214 : RB (Real.log ((1424599695496645001 : ℝ) / 1000000000000000000)) ((353890858815529593 : ℝ) / 1000000000000000000) ((70778171763105919 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424599695496645001 : ℝ) / 2000000000000000000)) (t := ((-575400304503354999 : ℝ) / 3424599695496645001))
    (lo := ((-84814080436103929 : ℝ) / 250000000000000000)) (hi := ((-67851264348883143 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424599695496645001 : ℝ) / 1000000000000000000) = Real.log ((1424599695496645001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424599695496645001 : ℝ) / 1000000000000000000) = ((1424599695496645001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_215 : RB (Real.log ((178074961937081 : ℝ) / 125000000000000)) ((176945429407765849 : ℝ) / 500000000000000000) ((3538908588155317 : ℝ) / 10000000000000000) := by
  have hm := log_bounds_of_series (x := ((178074961937081 : ℝ) / 250000000000000)) (t := ((-71925038062919 : ℝ) / 428074961937081))
    (lo := ((-339256321744413611 : ℝ) / 1000000000000000000)) (hi := ((-33925632174441361 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178074961937081 : ℝ) / 125000000000000) = Real.log ((178074961937081 : ℝ) / 250000000000000) + 1 * Real.log 2 := by
    rw [show ((178074961937081 : ℝ) / 125000000000000) = ((178074961937081 : ℝ) / 250000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_216 : RB (Real.log ((458695324883334469 : ℝ) / 1000000000000000000)) ((-194842267382953211 : ℝ) / 250000000000000000) ((-389684534765906421 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((458695324883334469 : ℝ) / 500000000000000000)) (t := ((-41304675116665531 : ℝ) / 958695324883334469))
    (lo := ((-43110944485933767 : ℝ) / 500000000000000000)) (hi := ((-86221888971867533 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458695324883334469 : ℝ) / 1000000000000000000) = Real.log ((458695324883334469 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458695324883334469 : ℝ) / 1000000000000000000) = ((458695324883334469 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_217 : RB (Real.log ((57517252487635951 : ℝ) / 125000000000000000)) ((-194057197809935119 : ℝ) / 250000000000000000) ((-388114395619870237 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((57517252487635951 : ℝ) / 62500000000000000)) (t := ((-4982747512364049 : ℝ) / 120017252487635951))
    (lo := ((-41540805339897583 : ℝ) / 500000000000000000)) (hi := ((-16616322135959033 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57517252487635951 : ℝ) / 125000000000000000) = Real.log ((57517252487635951 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57517252487635951 : ℝ) / 125000000000000000) = ((57517252487635951 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_218 : RB (Real.log ((539236980098912393 : ℝ) / 1000000000000000000)) ((-617600138466268399 : ℝ) / 1000000000000000000) ((-617600138466268397 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((539236980098912393 : ℝ) / 500000000000000000)) (t := ((39236980098912393 : ℝ) / 1039236980098912393))
    (lo := ((75547042093676911 : ℝ) / 1000000000000000000)) (hi := ((4721690130854807 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((539236980098912393 : ℝ) / 1000000000000000000) = Real.log ((539236980098912393 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((539236980098912393 : ℝ) / 1000000000000000000) = ((539236980098912393 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_219 : RB (Real.log ((540648034491665531 : ℝ) / 1000000000000000000)) ((-307493397525719257 : ℝ) / 500000000000000000) ((-38436674690714907 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((540648034491665531 : ℝ) / 500000000000000000)) (t := ((40648034491665531 : ℝ) / 1040648034491665531))
    (lo := ((19540096377126699 : ℝ) / 250000000000000000)) (hi := ((78160385508506797 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540648034491665531 : ℝ) / 1000000000000000000) = Real.log ((540648034491665531 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((540648034491665531 : ℝ) / 1000000000000000000) = ((540648034491665531 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_220 : RB (Real.log ((459351965508334469 : ℝ) / 1000000000000000000)) ((-97242319172919049 : ℝ) / 125000000000000000) ((-77793855338335239 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((459351965508334469 : ℝ) / 500000000000000000)) (t := ((-40648034491665531 : ℝ) / 959351965508334469))
    (lo := ((-42395686411703541 : ℝ) / 500000000000000000)) (hi := ((-84791372823407081 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459351965508334469 : ℝ) / 1000000000000000000) = Real.log ((459351965508334469 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((459351965508334469 : ℝ) / 1000000000000000000) = ((459351965508334469 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_221 : RB (Real.log ((460763019901087607 : ℝ) / 1000000000000000000)) ((-774871424771580407 : ℝ) / 1000000000000000000) ((-154974284954316081 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((460763019901087607 : ℝ) / 500000000000000000)) (t := ((-39236980098912393 : ℝ) / 960763019901087607))
    (lo := ((-81724244211635097 : ℝ) / 1000000000000000000)) (hi := ((-10215530526454387 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((460763019901087607 : ℝ) / 1000000000000000000) = Real.log ((460763019901087607 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((460763019901087607 : ℝ) / 1000000000000000000) = ((460763019901087607 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_222 : RB (Real.log ((458711242852084469 : ℝ) / 1000000000000000000)) ((-779334367428489363 : ℝ) / 1000000000000000000) ((-779334367428489361 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458711242852084469 : ℝ) / 500000000000000000)) (t := ((-41288757147915531 : ℝ) / 958711242852084469))
    (lo := ((-86187186868544053 : ℝ) / 1000000000000000000)) (hi := ((-21546796717136013 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458711242852084469 : ℝ) / 1000000000000000000) = Real.log ((458711242852084469 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458711242852084469 : ℝ) / 1000000000000000000) = ((458711242852084469 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_223 : RB (Real.log ((45871124285208447 : ℝ) / 100000000000000000)) ((-779334367428489361 : ℝ) / 1000000000000000000) ((-779334367428489359 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((45871124285208447 : ℝ) / 50000000000000000)) (t := ((-4128875714791553 : ℝ) / 95871124285208447))
    (lo := ((-86187186868544051 : ℝ) / 1000000000000000000)) (hi := ((-1723743737370881 : ℝ) / 20000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45871124285208447 : ℝ) / 100000000000000000) = Real.log ((45871124285208447 : ℝ) / 50000000000000000) - 1 * Real.log 2 := by
    rw [show ((45871124285208447 : ℝ) / 100000000000000000) = ((45871124285208447 : ℝ) / 50000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_224 : RB (Real.log ((45872696550833447 : ℝ) / 100000000000000000)) ((-779300092299966781 : ℝ) / 1000000000000000000) ((-779300092299966779 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((45872696550833447 : ℝ) / 50000000000000000)) (t := ((-4127303449166553 : ℝ) / 95872696550833447))
    (lo := ((-86152911740021471 : ℝ) / 1000000000000000000)) (hi := ((-8615291174002147 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45872696550833447 : ℝ) / 100000000000000000) = Real.log ((45872696550833447 : ℝ) / 50000000000000000) - 1 * Real.log 2 := by
    rw [show ((45872696550833447 : ℝ) / 100000000000000000) = ((45872696550833447 : ℝ) / 50000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_225 : RB (Real.log ((460122297244837607 : ℝ) / 1000000000000000000)) ((-77626296125872009 : ℝ) / 100000000000000000) ((-97032870157340011 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((460122297244837607 : ℝ) / 500000000000000000)) (t := ((-39877702755162393 : ℝ) / 960122297244837607))
    (lo := ((-4155789034938739 : ℝ) / 50000000000000000)) (hi := ((-83115780698774779 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((460122297244837607 : ℝ) / 1000000000000000000) = Real.log ((460122297244837607 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((460122297244837607 : ℝ) / 1000000000000000000) = ((460122297244837607 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_226 : RB (Real.log ((57515287155604701 : ℝ) / 125000000000000000)) ((-776262961258720087 : ℝ) / 1000000000000000000) ((-155252592251744017 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((57515287155604701 : ℝ) / 62500000000000000)) (t := ((-4984712844395299 : ℝ) / 120015287155604701))
    (lo := ((-83115780698774777 : ℝ) / 1000000000000000000)) (hi := ((-10389472587346847 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57515287155604701 : ℝ) / 125000000000000000) = Real.log ((57515287155604701 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57515287155604701 : ℝ) / 125000000000000000) = ((57515287155604701 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_227 : RB (Real.log ((460106379276087607 : ℝ) / 1000000000000000000)) ((-48518597308716423 : ℝ) / 62500000000000000) ((-388148778469731383 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((460106379276087607 : ℝ) / 500000000000000000)) (t := ((-39893620723912393 : ℝ) / 960106379276087607))
    (lo := ((-41575188189758729 : ℝ) / 500000000000000000)) (hi := ((-83150376379517457 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((460106379276087607 : ℝ) / 1000000000000000000) = Real.log ((460106379276087607 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((460106379276087607 : ℝ) / 1000000000000000000) = ((460106379276087607 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_228 : RB (Real.log ((284905769593226783 : ℝ) / 200000000000000000)) ((353841126043248577 : ℝ) / 1000000000000000000) ((353841126043248579 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((284905769593226783 : ℝ) / 400000000000000000)) (t := ((-115094230406773217 : ℝ) / 684905769593226783))
    (lo := ((-84826513629174183 : ℝ) / 250000000000000000)) (hi := ((-339306054516696731 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284905769593226783 : ℝ) / 200000000000000000) = Real.log ((284905769593226783 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284905769593226783 : ℝ) / 200000000000000000) = ((284905769593226783 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_229 : RB (Real.log ((356167586928664667 : ℝ) / 250000000000000000)) ((176970226010739121 : ℝ) / 500000000000000000) ((88485113005369561 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((356167586928664667 : ℝ) / 500000000000000000)) (t := ((-143832413071335333 : ℝ) / 856167586928664667))
    (lo := ((-339206728538467067 : ℝ) / 1000000000000000000)) (hi := ((-169603364269233533 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356167586928664667 : ℝ) / 250000000000000000) = Real.log ((356167586928664667 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356167586928664667 : ℝ) / 250000000000000000) = ((356167586928664667 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_230 : RB (Real.log ((85037097718226783 : ℝ) / 200000000000000000)) ((-855229761527743831 : ℝ) / 1000000000000000000) ((-855229761527743829 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((85037097718226783 : ℝ) / 100000000000000000)) (t := ((-14962902281773217 : ℝ) / 185037097718226783))
    (lo := ((-162082580967798521 : ℝ) / 1000000000000000000)) (hi := ((-4052064524194963 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85037097718226783 : ℝ) / 200000000000000000) = Real.log ((85037097718226783 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((85037097718226783 : ℝ) / 200000000000000000) = ((85037097718226783 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_231 : RB (Real.log ((425295347714658667 : ℝ) / 1000000000000000000)) ((-854971415614594353 : ℝ) / 1000000000000000000) ((-854971415614594351 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((425295347714658667 : ℝ) / 500000000000000000)) (t := ((-74704652285341333 : ℝ) / 925295347714658667))
    (lo := ((-161824235054649043 : ℝ) / 1000000000000000000)) (hi := ((-80912117527324521 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425295347714658667 : ℝ) / 1000000000000000000) = Real.log ((425295347714658667 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425295347714658667 : ℝ) / 1000000000000000000) = ((425295347714658667 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_232 : RB (Real.log ((285037097718226783 : ℝ) / 200000000000000000)) ((177150986340971697 : ℝ) / 500000000000000000) ((88575493170485849 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((285037097718226783 : ℝ) / 400000000000000000)) (t := ((-114962902281773217 : ℝ) / 685037097718226783))
    (lo := ((-67769041575600383 : ℝ) / 200000000000000000)) (hi := ((-169422603939000957 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285037097718226783 : ℝ) / 200000000000000000) = Real.log ((285037097718226783 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((285037097718226783 : ℝ) / 200000000000000000) = ((285037097718226783 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_233 : RB (Real.log ((1425295347714658667 : ℝ) / 1000000000000000000)) ((88594763449762927 : ℝ) / 250000000000000000) ((35437905379905171 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425295347714658667 : ℝ) / 2000000000000000000)) (t := ((-574704652285341333 : ℝ) / 3425295347714658667))
    (lo := ((-338768126760893601 : ℝ) / 1000000000000000000)) (hi := ((-423460158451117 : ℝ) / 1250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425295347714658667 : ℝ) / 1000000000000000000) = Real.log ((1425295347714658667 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425295347714658667 : ℝ) / 1000000000000000000) = ((1425295347714658667 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_234 : RB (Real.log ((284908953186976783 : ℝ) / 200000000000000000)) ((70770460035952527 : ℝ) / 200000000000000000) ((353852300179762637 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((284908953186976783 : ℝ) / 400000000000000000)) (t := ((-115091046813023217 : ℝ) / 684908953186976783))
    (lo := ((-169647440190091337 : ℝ) / 500000000000000000)) (hi := ((-339294880380182673 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284908953186976783 : ℝ) / 200000000000000000) = Real.log ((284908953186976783 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284908953186976783 : ℝ) / 200000000000000000) = ((284908953186976783 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_235 : RB (Real.log ((356136191483720979 : ℝ) / 250000000000000000)) ((88463075044940659 : ℝ) / 250000000000000000) ((176926150089881319 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((356136191483720979 : ℝ) / 500000000000000000)) (t := ((-143863808516279021 : ℝ) / 856136191483720979))
    (lo := ((-339294880380182673 : ℝ) / 1000000000000000000)) (hi := ((-21205930023761417 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356136191483720979 : ℝ) / 250000000000000000) = Real.log ((356136191483720979 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356136191483720979 : ℝ) / 250000000000000000) = ((356136191483720979 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_236 : RB (Real.log ((356140122147783479 : ℝ) / 250000000000000000)) ((35386333708773589 : ℝ) / 100000000000000000) ((88465834271933973 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((356140122147783479 : ℝ) / 500000000000000000)) (t := ((-143859877852216521 : ℝ) / 856140122147783479))
    (lo := ((-339283843472209419 : ℝ) / 1000000000000000000)) (hi := ((-169641921736104709 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356140122147783479 : ℝ) / 250000000000000000) = Real.log ((356140122147783479 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356140122147783479 : ℝ) / 250000000000000000) = ((356140122147783479 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_237 : RB (Real.log ((1424654625058408667 : ℝ) / 1000000000000000000)) ((70785883192917459 : ℝ) / 200000000000000000) ((353929415964587297 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424654625058408667 : ℝ) / 2000000000000000000)) (t := ((-575345374941591333 : ℝ) / 3424654625058408667))
    (lo := ((-169608882297679007 : ℝ) / 500000000000000000)) (hi := ((-339217764595358013 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424654625058408667 : ℝ) / 1000000000000000000) = Real.log ((1424654625058408667 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424654625058408667 : ℝ) / 1000000000000000000) = ((1424654625058408667 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_238 : RB (Real.log ((356163656264602167 : ℝ) / 250000000000000000)) ((70785883192917459 : ℝ) / 200000000000000000) ((353929415964587297 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((356163656264602167 : ℝ) / 500000000000000000)) (t := ((-143836343735397833 : ℝ) / 856163656264602167))
    (lo := ((-169608882297679007 : ℝ) / 500000000000000000)) (hi := ((-339217764595358013 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356163656264602167 : ℝ) / 250000000000000000) = Real.log ((356163656264602167 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356163656264602167 : ℝ) / 250000000000000000) = ((356163656264602167 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_239 : RB (Real.log ((1424638707089658667 : ℝ) / 1000000000000000000)) ((353918242689747133 : ℝ) / 1000000000000000000) ((70783648537949427 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424638707089658667 : ℝ) / 2000000000000000000)) (t := ((-575361292910341333 : ℝ) / 3424638707089658667))
    (lo := ((-10600904308443693 : ℝ) / 31250000000000000)) (hi := ((-13569157514807927 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424638707089658667 : ℝ) / 1000000000000000000) = Real.log ((1424638707089658667 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424638707089658667 : ℝ) / 1000000000000000000) = ((1424638707089658667 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
