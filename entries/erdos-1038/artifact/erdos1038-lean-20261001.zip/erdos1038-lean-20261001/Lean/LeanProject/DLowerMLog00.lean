import LeanProject.DLowerMTools
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_0 : RB (Real.log ((12499999999999999 : ℝ) / 1000000000000000000)) ((-4382026634673881693 : ℝ) / 1000000000000000000) ((-4382026634673881691 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((12499999999999999 : ℝ) / 15625000000000000)) (t := ((-3125000000000001 : ℝ) / 28124999999999999))
    (lo := ((-55785887828552459 : ℝ) / 250000000000000000)) (hi := ((-44628710262841967 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12499999999999999 : ℝ) / 1000000000000000000) = Real.log ((12499999999999999 : ℝ) / 15625000000000000) - 6 * Real.log 2 := by
    rw [show ((12499999999999999 : ℝ) / 1000000000000000000) = ((12499999999999999 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_1 : RB (Real.log ((1 : ℝ) / 80)) ((-4382026634673881613 : ℝ) / 1000000000000000000) ((-4382026634673881611 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((4 : ℝ) / 5)) (t := ((-1 : ℝ) / 9))
    (lo := ((-55785887828552439 : ℝ) / 250000000000000000)) (hi := ((-44628710262841951 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 80) = Real.log ((4 : ℝ) / 5) - 6 * Real.log 2 := by
    rw [show ((1 : ℝ) / 80) = ((4 : ℝ) / 5) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_2 : RB (Real.log ((1012499999999999999 : ℝ) / 1000000000000000000)) ((388203749954911 : ℝ) / 31250000000000000) ((12422519998557153 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1012499999999999999 : ℝ) / 1000000000000000000)) (t := ((12499999999999999 : ℝ) / 2012499999999999999))
    (lo := ((388203749954911 : ℝ) / 31250000000000000)) (hi := ((12422519998557153 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_3 : RB (Real.log ((81 : ℝ) / 80)) ((12422519998557153 : ℝ) / 1000000000000000000) ((6211259999278577 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((81 : ℝ) / 80)) (t := ((1 : ℝ) / 161))
    (lo := ((12422519998557153 : ℝ) / 1000000000000000000)) (hi := ((6211259999278577 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_4 : RB (Real.log ((9999999999999999 : ℝ) / 1000000000000000000)) ((-4605170185988091469 : ℝ) / 1000000000000000000) ((-4605170185988091467 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((9999999999999999 : ℝ) / 7812500000000000)) (t := ((2187499999999999 : ℝ) / 17812499999999999))
    (lo := ((246860077931525697 : ℝ) / 1000000000000000000)) (hi := ((123430038965762849 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9999999999999999 : ℝ) / 1000000000000000000) = Real.log ((9999999999999999 : ℝ) / 7812500000000000) - 7 * Real.log 2 := by
    rw [show ((9999999999999999 : ℝ) / 1000000000000000000) = ((9999999999999999 : ℝ) / 7812500000000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_5 : RB (Real.log ((3 : ℝ) / 200)) ((-4199705077879926987 : ℝ) / 1000000000000000000) ((-839941015575985397 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((24 : ℝ) / 25)) (t := ((-1 : ℝ) / 49))
    (lo := ((-4082199452025513 : ℝ) / 100000000000000000)) (hi := ((-40821994520255129 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3 : ℝ) / 200) = Real.log ((24 : ℝ) / 25) - 6 * Real.log 2 := by
    rw [show ((3 : ℝ) / 200) = ((24 : ℝ) / 25) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_6 : RB (Real.log ((1009999999999999999 : ℝ) / 1000000000000000000)) ((9950330853168081 : ℝ) / 1000000000000000000) ((4975165426584041 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1009999999999999999 : ℝ) / 1000000000000000000)) (t := ((9999999999999999 : ℝ) / 2009999999999999999))
    (lo := ((9950330853168081 : ℝ) / 1000000000000000000)) (hi := ((4975165426584041 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_7 : RB (Real.log ((203 : ℝ) / 200)) ((7444306246875327 : ℝ) / 500000000000000000) ((2977722498750131 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((203 : ℝ) / 200)) (t := ((3 : ℝ) / 403))
    (lo := ((7444306246875327 : ℝ) / 500000000000000000)) (hi := ((2977722498750131 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_8 : RB (Real.log ((481700886171037 : ℝ) / 1000000000000000)) ((-146086385134701267 : ℝ) / 200000000000000000) ((-730431925673506333 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((481700886171037 : ℝ) / 500000000000000)) (t := ((-18299113828963 : ℝ) / 981700886171037))
    (lo := ((-1491389804542441 : ℝ) / 40000000000000000)) (hi := ((-582574142399391 : ℝ) / 15625000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((481700886171037 : ℝ) / 1000000000000000) = Real.log ((481700886171037 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((481700886171037 : ℝ) / 1000000000000000) = ((481700886171037 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_9 : RB (Real.log ((481700886171040001 : ℝ) / 1000000000000000000)) ((-146086385134700021 : ℝ) / 200000000000000000) ((-730431925673500103 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((481700886171040001 : ℝ) / 500000000000000000)) (t := ((-18299113828959999 : ℝ) / 981700886171040001))
    (lo := ((-7456949022710959 : ℝ) / 200000000000000000)) (hi := ((-18642372556777397 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((481700886171040001 : ℝ) / 1000000000000000000) = Real.log ((481700886171040001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((481700886171040001 : ℝ) / 1000000000000000000) = ((481700886171040001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_10 : RB (Real.log ((3238392898931 : ℝ) / 6250000000000)) ((-657504275850572339 : ℝ) / 1000000000000000000) ((-657504275850572337 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((3238392898931 : ℝ) / 3125000000000)) (t := ((113392898931 : ℝ) / 6363392898931))
    (lo := ((35642904709372971 : ℝ) / 1000000000000000000)) (hi := ((8910726177343243 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3238392898931 : ℝ) / 6250000000000) = Real.log ((3238392898931 : ℝ) / 3125000000000) - 1 * Real.log 2 := by
    rw [show ((3238392898931 : ℝ) / 6250000000000) = ((3238392898931 : ℝ) / 3125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_11 : RB (Real.log ((518142863828963 : ℝ) / 1000000000000000)) ((-657504275850566549 : ℝ) / 1000000000000000000) ((-657504275850566547 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((518142863828963 : ℝ) / 500000000000000)) (t := ((18142863828963 : ℝ) / 1018142863828963))
    (lo := ((35642904709378761 : ℝ) / 1000000000000000000)) (hi := ((17821452354689381 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((518142863828963 : ℝ) / 1000000000000000) = Real.log ((518142863828963 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((518142863828963 : ℝ) / 1000000000000000) = ((518142863828963 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_12 : RB (Real.log ((481857136171037 : ℝ) / 1000000000000000)) ((-730107606851501663 : ℝ) / 1000000000000000000) ((-730107606851501661 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((481857136171037 : ℝ) / 500000000000000)) (t := ((-18142863828963 : ℝ) / 981857136171037))
    (lo := ((-36960426291556353 : ℝ) / 1000000000000000000)) (hi := ((-9023541575087 : ℝ) / 244140625000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((481857136171037 : ℝ) / 1000000000000000) = Real.log ((481857136171037 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((481857136171037 : ℝ) / 1000000000000000) = ((481857136171037 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_13 : RB (Real.log ((3011607101069 : ℝ) / 6250000000000)) ((-730107606851495437 : ℝ) / 1000000000000000000) ((-146021521370299087 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((3011607101069 : ℝ) / 3125000000000)) (t := ((-113392898931 : ℝ) / 6136607101069))
    (lo := ((-36960426291550127 : ℝ) / 1000000000000000000)) (hi := ((-18480213145775063 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3011607101069 : ℝ) / 6250000000000) = Real.log ((3011607101069 : ℝ) / 3125000000000) - 1 * Real.log 2 := by
    rw [show ((3011607101069 : ℝ) / 6250000000000) = ((3011607101069 : ℝ) / 3125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_14 : RB (Real.log ((481700886171037001 : ℝ) / 1000000000000000000)) ((-730431925673506333 : ℝ) / 1000000000000000000) ((-730431925673506331 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((481700886171037001 : ℝ) / 500000000000000000)) (t := ((-18299113828962999 : ℝ) / 981700886171037001))
    (lo := ((-37284745113561023 : ℝ) / 1000000000000000000)) (hi := ((-18642372556780511 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((481700886171037001 : ℝ) / 1000000000000000000) = Real.log ((481700886171037001 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((481700886171037001 : ℝ) / 1000000000000000000) = ((481700886171037001 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_15 : RB (Real.log ((3010630538569 : ℝ) / 6250000000000)) ((-730431925673500107 : ℝ) / 1000000000000000000) ((-146086385134700021 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((3010630538569 : ℝ) / 3125000000000)) (t := ((-114369461431 : ℝ) / 6135630538569))
    (lo := ((-37284745113554797 : ℝ) / 1000000000000000000)) (hi := ((-9321186278388699 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3010630538569 : ℝ) / 6250000000000) = Real.log ((3010630538569 : ℝ) / 3125000000000) - 1 * Real.log 2 := by
    rw [show ((3010630538569 : ℝ) / 6250000000000) = ((3010630538569 : ℝ) / 3125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_16 : RB (Real.log ((7130793960907 : ℝ) / 5000000000000)) ((70996934151703771 : ℝ) / 200000000000000000) ((354984670758518857 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((7130793960907 : ℝ) / 10000000000000)) (t := ((-2869206039093 : ℝ) / 17130793960907))
    (lo := ((-169081254900713227 : ℝ) / 500000000000000000)) (hi := ((-338162509801426453 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7130793960907 : ℝ) / 5000000000000) = Real.log ((7130793960907 : ℝ) / 10000000000000) + 1 * Real.log 2 := by
    rw [show ((7130793960907 : ℝ) / 5000000000000) = ((7130793960907 : ℝ) / 10000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_17 : RB (Real.log ((1426158792181403001 : ℝ) / 1000000000000000000)) ((554663548060189 : ℝ) / 1562500000000000) ((177492335379260481 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426158792181403001 : ℝ) / 2000000000000000000)) (t := ((-573841207818596999 : ℝ) / 3426158792181403001))
    (lo := ((-338162509801424349 : ℝ) / 1000000000000000000)) (hi := ((-84540627450356087 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426158792181403001 : ℝ) / 1000000000000000000) = Real.log ((1426158792181403001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426158792181403001 : ℝ) / 1000000000000000000) = ((1426158792181403001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_18 : RB (Real.log ((2131575210907 : ℝ) / 5000000000000)) ((-170515334079482177 : ℝ) / 200000000000000000) ((-852576670397410883 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((2131575210907 : ℝ) / 2500000000000)) (t := ((-368424789093 : ℝ) / 4631575210907))
    (lo := ((-6377179593498623 : ℝ) / 40000000000000000)) (hi := ((-79714744918732787 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2131575210907 : ℝ) / 5000000000000) = Real.log ((2131575210907 : ℝ) / 2500000000000) - 1 * Real.log 2 := by
    rw [show ((2131575210907 : ℝ) / 5000000000000) = ((2131575210907 : ℝ) / 2500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_19 : RB (Real.log ((426315042181403 : ℝ) / 1000000000000000)) ((-106572083799675481 : ℝ) / 125000000000000000) ((-426288335198701923 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((426315042181403 : ℝ) / 500000000000000)) (t := ((-73684957818597 : ℝ) / 926315042181403))
    (lo := ((-79714744918729269 : ℝ) / 500000000000000000)) (hi := ((-159429489837458537 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((426315042181403 : ℝ) / 1000000000000000) = Real.log ((426315042181403 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((426315042181403 : ℝ) / 1000000000000000) = ((426315042181403 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_20 : RB (Real.log ((7131575210907 : ℝ) / 5000000000000)) ((88773556196804431 : ℝ) / 250000000000000000) ((177547112393608863 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((7131575210907 : ℝ) / 10000000000000)) (t := ((-2868424789093 : ℝ) / 17131575210907))
    (lo := ((-67610591154545517 : ℝ) / 200000000000000000)) (hi := ((-10564154867897737 : ℝ) / 31250000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7131575210907 : ℝ) / 5000000000000) = Real.log ((7131575210907 : ℝ) / 10000000000000) + 1 * Real.log 2 := by
    rw [show ((7131575210907 : ℝ) / 5000000000000) = ((7131575210907 : ℝ) / 10000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_21 : RB (Real.log ((1426315042181403 : ℝ) / 1000000000000000)) ((88773556196804957 : ℝ) / 250000000000000000) ((35509422478721983 : ℝ) / 100000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426315042181403 : ℝ) / 2000000000000000)) (t := ((-573684957818597 : ℝ) / 3426315042181403))
    (lo := ((-338052955772725481 : ℝ) / 1000000000000000000)) (hi := ((-8451323894318137 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426315042181403 : ℝ) / 1000000000000000) = Real.log ((1426315042181403 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426315042181403 : ℝ) / 1000000000000000) = ((1426315042181403 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_22 : RB (Real.log ((1426158792181400001 : ℝ) / 1000000000000000000)) ((44373083844814857 : ℝ) / 125000000000000000) ((177492335379259429 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426158792181400001 : ℝ) / 2000000000000000000)) (t := ((-573841207818599999 : ℝ) / 3426158792181400001))
    (lo := ((-338162509801426453 : ℝ) / 1000000000000000000)) (hi := ((-84540627450356613 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426158792181400001 : ℝ) / 1000000000000000000) = Real.log ((1426158792181400001 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426158792181400001 : ℝ) / 1000000000000000000) = ((1426158792181400001 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_23 : RB (Real.log ((1426158792181403 : ℝ) / 1000000000000000)) ((354984670758520959 : ℝ) / 1000000000000000000) ((354984670758520961 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1426158792181403 : ℝ) / 2000000000000000)) (t := ((-573841207818597 : ℝ) / 3426158792181403))
    (lo := ((-6763250196028487 : ℝ) / 20000000000000000)) (hi := ((-338162509801424349 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426158792181403 : ℝ) / 1000000000000000) = Real.log ((1426158792181403 : ℝ) / 2000000000000000) + 1 * Real.log 2 := by
    rw [show ((1426158792181403 : ℝ) / 1000000000000000) = ((1426158792181403 : ℝ) / 2000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_24 : RB (Real.log ((476655846934861613 : ℝ) / 1000000000000000000)) ((-370480271695983297 : ℝ) / 500000000000000000) ((-5788754245249739 : ℝ) / 7812500000000000) := by
  have hm := log_bounds_of_series (x := ((476655846934861613 : ℝ) / 500000000000000000)) (t := ((-23344153065138387 : ℝ) / 976655846934861613))
    (lo := ((-11953340708005321 : ℝ) / 250000000000000000)) (hi := ((-47813362832021283 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((476655846934861613 : ℝ) / 1000000000000000000) = Real.log ((476655846934861613 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((476655846934861613 : ℝ) / 1000000000000000000) = ((476655846934861613 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_25 : RB (Real.log ((243366712703608161 : ℝ) / 500000000000000000)) ((-720038686861282297 : ℝ) / 1000000000000000000) ((-144007737372256459 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((243366712703608161 : ℝ) / 250000000000000000)) (t := ((-6633287296391839 : ℝ) / 493366712703608161))
    (lo := ((-26891506301336987 : ℝ) / 1000000000000000000)) (hi := ((-13445753150668493 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((243366712703608161 : ℝ) / 500000000000000000) = Real.log ((243366712703608161 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((243366712703608161 : ℝ) / 500000000000000000) = ((243366712703608161 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_26 : RB (Real.log ((513166574592783679 : ℝ) / 1000000000000000000)) ((-41697173731791819 : ℝ) / 62500000000000000) ((-333577389854334551 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((513166574592783679 : ℝ) / 500000000000000000)) (t := ((13166574592783679 : ℝ) / 1013166574592783679))
    (lo := ((12996200425638103 : ℝ) / 500000000000000000)) (hi := ((25992400851276207 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((513166574592783679 : ℝ) / 1000000000000000000) = Real.log ((513166574592783679 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((513166574592783679 : ℝ) / 1000000000000000000) = ((513166574592783679 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_27 : RB (Real.log ((523119153065138387 : ℝ) / 1000000000000000000)) ((-647946014737273781 : ℝ) / 1000000000000000000) ((-647946014737273779 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((523119153065138387 : ℝ) / 500000000000000000)) (t := ((23119153065138387 : ℝ) / 1023119153065138387))
    (lo := ((45201165822671529 : ℝ) / 1000000000000000000)) (hi := ((4520116582267153 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((523119153065138387 : ℝ) / 1000000000000000000) = Real.log ((523119153065138387 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((523119153065138387 : ℝ) / 1000000000000000000) = ((523119153065138387 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_28 : RB (Real.log ((476880846934861613 : ℝ) / 1000000000000000000)) ((-185122154020117359 : ℝ) / 250000000000000000) ((-370244308040234717 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((476880846934861613 : ℝ) / 500000000000000000)) (t := ((-23119153065138387 : ℝ) / 976880846934861613))
    (lo := ((-23670717760262063 : ℝ) / 500000000000000000)) (hi := ((-378731484164193 : ℝ) / 8000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((476880846934861613 : ℝ) / 1000000000000000000) = Real.log ((476880846934861613 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((476880846934861613 : ℝ) / 1000000000000000000) = ((476880846934861613 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_29 : RB (Real.log ((486833425407216321 : ℝ) / 1000000000000000000)) ((-719833256694328637 : ℝ) / 1000000000000000000) ((-143966651338865727 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((486833425407216321 : ℝ) / 500000000000000000)) (t := ((-13166574592783679 : ℝ) / 986833425407216321))
    (lo := ((-26686076134383327 : ℝ) / 1000000000000000000)) (hi := ((-13343038067191663 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((486833425407216321 : ℝ) / 1000000000000000000) = Real.log ((486833425407216321 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((486833425407216321 : ℝ) / 1000000000000000000) = ((486833425407216321 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_30 : RB (Real.log ((476724596934861613 : ℝ) / 1000000000000000000)) ((-740816319749534583 : ℝ) / 1000000000000000000) ((-740816319749534581 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((476724596934861613 : ℝ) / 500000000000000000)) (t := ((-23275403065138387 : ℝ) / 976724596934861613))
    (lo := ((-47669139189589273 : ℝ) / 1000000000000000000)) (hi := ((-5958642398698659 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((476724596934861613 : ℝ) / 1000000000000000000) = Real.log ((476724596934861613 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((476724596934861613 : ℝ) / 1000000000000000000) = ((476724596934861613 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_31 : RB (Real.log ((238362298467430807 : ℝ) / 500000000000000000)) ((-740816319749534581 : ℝ) / 1000000000000000000) ((-740816319749534579 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((238362298467430807 : ℝ) / 250000000000000000)) (t := ((-11637701532569193 : ℝ) / 488362298467430807))
    (lo := ((-47669139189589271 : ℝ) / 1000000000000000000)) (hi := ((-4766913918958927 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((238362298467430807 : ℝ) / 500000000000000000) = Real.log ((238362298467430807 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((238362298467430807 : ℝ) / 500000000000000000) = ((238362298467430807 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_32 : RB (Real.log ((238390423467430807 : ℝ) / 500000000000000000)) ((-370349167028499977 : ℝ) / 500000000000000000) ((-46293645878562497 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((238390423467430807 : ℝ) / 250000000000000000)) (t := ((-11609576532569193 : ℝ) / 488390423467430807))
    (lo := ((-11887788374263661 : ℝ) / 250000000000000000)) (hi := ((-47551153497054643 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((238390423467430807 : ℝ) / 500000000000000000) = Real.log ((238390423467430807 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((238390423467430807 : ℝ) / 500000000000000000) = ((238390423467430807 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_33 : RB (Real.log ((486677175407216321 : ℝ) / 1000000000000000000)) ((-720154259878497333 : ℝ) / 1000000000000000000) ((-720154259878497331 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((486677175407216321 : ℝ) / 500000000000000000)) (t := ((-13322824592783679 : ℝ) / 986677175407216321))
    (lo := ((-27007079318552023 : ℝ) / 1000000000000000000)) (hi := ((-13503539659276011 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((486677175407216321 : ℝ) / 1000000000000000000) = Real.log ((486677175407216321 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((486677175407216321 : ℝ) / 1000000000000000000) = ((486677175407216321 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_34 : RB (Real.log ((243338587703608161 : ℝ) / 500000000000000000)) ((-720154259878497331 : ℝ) / 1000000000000000000) ((-720154259878497329 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((243338587703608161 : ℝ) / 250000000000000000)) (t := ((-6661412296391839 : ℝ) / 493338587703608161))
    (lo := ((-27007079318552021 : ℝ) / 1000000000000000000)) (hi := ((-1350353965927601 : ℝ) / 50000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((243338587703608161 : ℝ) / 500000000000000000) = Real.log ((243338587703608161 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((243338587703608161 : ℝ) / 500000000000000000) = ((243338587703608161 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_35 : RB (Real.log ((486608425407216321 : ℝ) / 1000000000000000000)) ((-360147766965068031 : ℝ) / 500000000000000000) ((-36014776696506803 : ℝ) / 50000000000000000) := by
  have hm := log_bounds_of_series (x := ((486608425407216321 : ℝ) / 500000000000000000)) (t := ((-13391574592783679 : ℝ) / 986608425407216321))
    (lo := ((-848386042818461 : ℝ) / 31250000000000000)) (hi := ((-27148353370190751 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((486608425407216321 : ℝ) / 1000000000000000000) = Real.log ((486608425407216321 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((486608425407216321 : ℝ) / 1000000000000000000) = ((486608425407216321 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_36 : RB (Real.log ((710486914709594343 : ℝ) / 500000000000000000)) ((351342431928611519 : ℝ) / 1000000000000000000) ((351342431928611521 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((710486914709594343 : ℝ) / 1000000000000000000)) (t := ((-289513085290405657 : ℝ) / 1710486914709594343))
    (lo := ((-34180474863133379 : ℝ) / 100000000000000000)) (hi := ((-341804748631333789 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((710486914709594343 : ℝ) / 500000000000000000) = Real.log ((710486914709594343 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((710486914709594343 : ℝ) / 500000000000000000) = ((710486914709594343 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_37 : RB (Real.log ((1431331254943613651 : ℝ) / 1000000000000000000)) ((358604958721948157 : ℝ) / 1000000000000000000) ((358604958721948159 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1431331254943613651 : ℝ) / 2000000000000000000)) (t := ((-568668745056386349 : ℝ) / 3431331254943613651))
    (lo := ((-10454444432437411 : ℝ) / 31250000000000000)) (hi := ((-334542221837997151 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1431331254943613651 : ℝ) / 1000000000000000000) = Real.log ((1431331254943613651 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1431331254943613651 : ℝ) / 1000000000000000000) = ((1431331254943613651 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_38 : RB (Real.log ((210599414709594343 : ℝ) / 500000000000000000)) ((-432325138941450249 : ℝ) / 500000000000000000) ((-54040642367681281 : ℝ) / 62500000000000000) := by
  have hm := log_bounds_of_series (x := ((210599414709594343 : ℝ) / 250000000000000000)) (t := ((-39400585290405657 : ℝ) / 460599414709594343))
    (lo := ((-42875774330738797 : ℝ) / 250000000000000000)) (hi := ((-171503097322955187 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((210599414709594343 : ℝ) / 500000000000000000) = Real.log ((210599414709594343 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((210599414709594343 : ℝ) / 500000000000000000) = ((210599414709594343 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_39 : RB (Real.log ((8628625098872273 : ℝ) / 20000000000000000)) ((-21016177440497523 : ℝ) / 25000000000000000) ((-420323548809950459 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((8628625098872273 : ℝ) / 10000000000000000)) (t := ((-1371374901127727 : ℝ) / 18628625098872273))
    (lo := ((-14749991705995561 : ℝ) / 100000000000000000)) (hi := ((-147499917059955609 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8628625098872273 : ℝ) / 20000000000000000) = Real.log ((8628625098872273 : ℝ) / 10000000000000000) - 1 * Real.log 2 := by
    rw [show ((8628625098872273 : ℝ) / 20000000000000000) = ((8628625098872273 : ℝ) / 10000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
