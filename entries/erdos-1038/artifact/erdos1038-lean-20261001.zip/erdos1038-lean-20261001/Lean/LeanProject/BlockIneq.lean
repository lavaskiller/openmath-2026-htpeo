import LeanProject.ScalarRed

/-!
# EP-1038, Stage 12, Theorem 12.8 steps 3–8: from the energy identity (12.7) to (12.5)

`block_ineq`: if `f, g` are measurable, `2π`-periodic, `[0, 1]`-valued with masses `2Q, 2R > 0`
(`Q, R ≤ π` is not needed here), `q = a_π Q/π`, `r = b_π R/π`, and the energy satisfies the
identity (12.7) `𝓔/(qr) = log H + (1/(2QR)) ∬ f g K`, then
`𝓔/(qr) - log(qr/2) - C_eff/q ≥ rhs(log(2H/(a_π b_π)), C_eff, a_π, Q, R)`, i.e. (12.5).
`block_pos` (step 8): positivity of `rhs` gives `𝓔 - qr log(qr/2) - C_eff r > 0`.
Step 2 of Theorem 12.8, the derivation of (12.7) from the reference objects, is not formalised here.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- **Theorem 12.8**, steps 3–7: (12.7) implies (12.5). -/
theorem block_ineq {f g : ℝ → ℝ} (hfm : Measurable f) (hgm : Measurable g)
    (hfp : Function.Periodic f (2 * π)) (hgp : Function.Periodic g (2 * π))
    (hf0 : ∀ x, 0 ≤ f x) (hf1 : ∀ x, f x ≤ 1) (hg0 : ∀ x, 0 ≤ g x) (hg1 : ∀ x, g x ≤ 1)
    {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R)
    (hfmass : ∫ θ in (-π)..π, f θ = 2 * Q) (hgmass : ∫ θ in (-π)..π, g θ = 2 * R)
    {H api bpi E q r Ceff : ℝ} (hH : 0 < H) (ha : 0 < api) (hb : 0 < bpi)
    (hq : q = api * Q / π) (hr : r = bpi * R / π)
    (hE : E / (q * r) = Real.log H + 1 / (2 * Q * R) * Circ.IK (Kl 1) f g) :
    rhs (Real.log (2 * H / (api * bpi))) Ceff api Q R ≤
      E / (q * r) - Real.log (q * r / 2) - Ceff / q := by
  have hπ := Real.pi_pos
  -- step 3
  have h3 := circle_block_K hfm hgm hfp hgp hf0 hf1 hg0 hg1 hQ hR hfmass hgmass
  -- step 4: 𝓔/(qr) ≥ log H + 2 𝒜(Q, R)
  have h4 : Real.log H + 2 * AE Q R ≤ E / (q * r) := by
    rw [hE]
    have hpos : 0 < 1 / (2 * Q * R) := by positivity
    have := mul_le_mul_of_nonneg_left h3 hpos.le
    have e : 1 / (2 * Q * R) * (4 * Q * R * AE Q R) = 2 * AE Q R := by
      have := hQ.ne'
      have := hR.ne'
      field_simp
      ring
    linarith
  -- step 5: 2𝒜(Q, R) = 𝒜(Q, Q) + 𝒜(R, R) + Σ, and 𝒜(X, X) = h(X) + log(X/π)
  have h5 := AE_combo hQ hR
  have hhQ : AE Q Q = hfun Q + (Real.log Q - Real.log π) := by
    unfold hfun; rw [Real.log_div hQ.ne' hπ.ne']; ring
  have hhR : AE R R = hfun R + (Real.log R - Real.log π) := by
    unfold hfun; rw [Real.log_div hR.ne' hπ.ne']; ring
  -- step 6: the logarithms
  have hq0 : 0 < q := by rw [hq]; positivity
  have hr0 : 0 < r := by rw [hr]; positivity
  have hlq : Real.log q = Real.log api + Real.log Q - Real.log π := by
    rw [hq, Real.log_div (by positivity) hπ.ne', Real.log_mul ha.ne' hQ.ne']
  have hlr : Real.log r = Real.log bpi + Real.log R - Real.log π := by
    rw [hr, Real.log_div (by positivity) hπ.ne', Real.log_mul hb.ne' hR.ne']
  have hlqr : Real.log (q * r / 2) = Real.log q + Real.log r - Real.log 2 := by
    rw [Real.log_div (by positivity) two_ne_zero, Real.log_mul hq0.ne' hr0.ne']
  have hl0 : Real.log (2 * H / (api * bpi)) =
      Real.log 2 + Real.log H - (Real.log api + Real.log bpi) := by
    rw [Real.log_div (by positivity) (by positivity), Real.log_mul two_ne_zero hH.ne',
      Real.log_mul ha.ne' hb.ne']
  -- step 7: C_eff/q = π C_eff/(a_π Q)
  have h7 : Ceff / q = π * Ceff / (api * Q) := by
    rw [hq]
    have := ha.ne'
    have := hQ.ne'
    have := hπ.ne'
    field_simp
  unfold rhs
  rw [h7, hl0, hlqr, hlq, hlr]
  linarith

/-- **Theorem 12.8**, step 8: if the right side of (12.5) is positive, then
`𝓔 - qr log(qr/2) - C_eff r > 0`, i.e. (12.4) holds strictly for this block. -/
theorem block_pos {f g : ℝ → ℝ} (hfm : Measurable f) (hgm : Measurable g)
    (hfp : Function.Periodic f (2 * π)) (hgp : Function.Periodic g (2 * π))
    (hf0 : ∀ x, 0 ≤ f x) (hf1 : ∀ x, f x ≤ 1) (hg0 : ∀ x, 0 ≤ g x) (hg1 : ∀ x, g x ≤ 1)
    {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R)
    (hfmass : ∫ θ in (-π)..π, f θ = 2 * Q) (hgmass : ∫ θ in (-π)..π, g θ = 2 * R)
    {H api bpi E q r Ceff : ℝ} (hH : 0 < H) (ha : 0 < api) (hb : 0 < bpi)
    (hq : q = api * Q / π) (hr : r = bpi * R / π)
    (hE : E / (q * r) = Real.log H + 1 / (2 * Q * R) * Circ.IK (Kl 1) f g)
    (hpos : 0 < rhs (Real.log (2 * H / (api * bpi))) Ceff api Q R) :
    0 < E - q * r * Real.log (q * r / 2) - Ceff * r := by
  have h := block_ineq (Ceff := Ceff) hfm hgm hfp hgp hf0 hf1 hg0 hg1 hQ hR hfmass hgmass hH ha hb hq hr hE
  have hq0 : 0 < q := by rw [hq]; positivity
  have hr0 : 0 < r := by rw [hr]; positivity
  have hqr : 0 < q * r := mul_pos hq0 hr0
  have key : 0 < E / (q * r) - Real.log (q * r / 2) - Ceff / q := lt_of_lt_of_le hpos h
  have e : E - q * r * Real.log (q * r / 2) - Ceff * r =
      q * r * (E / (q * r) - Real.log (q * r / 2) - Ceff / q) := by
    have := hq0.ne'
    have := hr0.ne'
    field_simp
  rw [e]
  exact mul_pos hqr key

end EP1038.Arc
