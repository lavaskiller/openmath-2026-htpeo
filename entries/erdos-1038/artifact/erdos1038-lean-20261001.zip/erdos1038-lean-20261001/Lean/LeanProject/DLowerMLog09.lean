import LeanProject.DLowerMTools
import LeanProject.DLowerMLog06
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option maxHeartbeats 8000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_m_log_360 : RB (Real.log ((229267790653302339 : ℝ) / 500000000000000000)) ((-31188695462979319 : ℝ) / 40000000000000000) ((-779717386574482973 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229267790653302339 : ℝ) / 250000000000000000)) (t := ((-20732209346697661 : ℝ) / 479267790653302339))
    (lo := ((-17314041202907533 : ℝ) / 200000000000000000)) (hi := ((-1352659468977151 : ℝ) / 15625000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229267790653302339 : ℝ) / 500000000000000000) = Real.log ((229267790653302339 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229267790653302339 : ℝ) / 500000000000000000) = ((229267790653302339 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_361 : RB (Real.log ((458626135151297259 : ℝ) / 1000000000000000000)) ((-31180796847643603 : ℝ) / 40000000000000000) ((-779519921191090073 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((458626135151297259 : ℝ) / 500000000000000000)) (t := ((-41373864848702741 : ℝ) / 958626135151297259))
    (lo := ((-17274548126228953 : ℝ) / 200000000000000000)) (hi := ((-21593185157786191 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458626135151297259 : ℝ) / 1000000000000000000) = Real.log ((458626135151297259 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458626135151297259 : ℝ) / 1000000000000000000) = ((458626135151297259 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_362 : RB (Real.log ((108142240926283517 : ℝ) / 200000000000000000)) ((-614869960353886683 : ℝ) / 1000000000000000000) ((-614869960353886681 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((108142240926283517 : ℝ) / 100000000000000000)) (t := ((8142240926283517 : ℝ) / 208142240926283517))
    (lo := ((78277220206058627 : ℝ) / 1000000000000000000)) (hi := ((19569305051514657 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((108142240926283517 : ℝ) / 200000000000000000) = Real.log ((108142240926283517 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((108142240926283517 : ℝ) / 200000000000000000) = ((108142240926283517 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_363 : RB (Real.log ((270399872920916411 : ℝ) / 500000000000000000)) ((-30735311211025913 : ℝ) / 50000000000000000) ((-307353112110259129 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((270399872920916411 : ℝ) / 250000000000000000)) (t := ((20399872920916411 : ℝ) / 520399872920916411))
    (lo := ((1568819126788541 : ℝ) / 20000000000000000)) (hi := ((78440956339427051 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270399872920916411 : ℝ) / 500000000000000000) = Real.log ((270399872920916411 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((270399872920916411 : ℝ) / 500000000000000000) = ((270399872920916411 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_364 : RB (Real.log ((229600127079083589 : ℝ) / 500000000000000000)) ((-38913444024830217 : ℝ) / 50000000000000000) ((-389134440248302169 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((229600127079083589 : ℝ) / 250000000000000000)) (t := ((-20399872920916411 : ℝ) / 479600127079083589))
    (lo := ((-8512169993665903 : ℝ) / 100000000000000000)) (hi := ((-85121699936659029 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229600127079083589 : ℝ) / 500000000000000000) = Real.log ((229600127079083589 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229600127079083589 : ℝ) / 500000000000000000) = ((229600127079083589 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_365 : RB (Real.log ((91857759073716483 : ℝ) / 200000000000000000)) ((-389038041482595469 : ℝ) / 500000000000000000) ((-97259510370648867 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((91857759073716483 : ℝ) / 100000000000000000)) (t := ((-8142240926283517 : ℝ) / 191857759073716483))
    (lo := ((-21232225601311407 : ℝ) / 250000000000000000)) (hi := ((-84928902405245627 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91857759073716483 : ℝ) / 200000000000000000) = Real.log ((91857759073716483 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((91857759073716483 : ℝ) / 200000000000000000) = ((91857759073716483 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_366 : RB (Real.log ((114634147001303269 : ℝ) / 250000000000000000)) ((-389857595556177253 : ℝ) / 500000000000000000) ((-97464398889044313 : ℝ) / 125000000000000000) := by
  have hm := log_bounds_of_series (x := ((114634147001303269 : ℝ) / 125000000000000000)) (t := ((-10365852998696731 : ℝ) / 239634147001303269))
    (lo := ((-21642002638102299 : ℝ) / 250000000000000000)) (hi := ((-17313602110481839 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((114634147001303269 : ℝ) / 250000000000000000) = Real.log ((114634147001303269 : ℝ) / 125000000000000000) - 1 * Real.log 2 := by
    rw [show ((114634147001303269 : ℝ) / 250000000000000000) = ((114634147001303269 : ℝ) / 125000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_367 : RB (Real.log ((458536588005213077 : ℝ) / 1000000000000000000)) ((-97464398889044313 : ℝ) / 125000000000000000) ((-389857595556177251 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((458536588005213077 : ℝ) / 500000000000000000)) (t := ((-41463411994786923 : ℝ) / 958536588005213077))
    (lo := ((-43284005276204597 : ℝ) / 500000000000000000)) (hi := ((-86568010552409193 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458536588005213077 : ℝ) / 1000000000000000000) = Real.log ((458536588005213077 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458536588005213077 : ℝ) / 1000000000000000000) = ((458536588005213077 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_368 : RB (Real.log ((229268796970441011 : ℝ) / 500000000000000000)) ((-155942599463779947 : ℝ) / 200000000000000000) ((-779712997318899733 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229268796970441011 : ℝ) / 250000000000000000)) (t := ((-20731203029558989 : ℝ) / 479268796970441011))
    (lo := ((-3462632670358177 : ℝ) / 40000000000000000)) (hi := ((-10820727094869303 : ℝ) / 125000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229268796970441011 : ℝ) / 500000000000000000) = Real.log ((229268796970441011 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229268796970441011 : ℝ) / 500000000000000000) = ((229268796970441011 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_369 : RB (Real.log ((458625129215628313 : ℝ) / 1000000000000000000)) ((-194880528640254031 : ℝ) / 250000000000000000) ((-389761057280508061 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((458625129215628313 : ℝ) / 500000000000000000)) (t := ((-41374870784371687 : ℝ) / 958625129215628313))
    (lo := ((-43187467000535407 : ℝ) / 500000000000000000)) (hi := ((-86374934001070813 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((458625129215628313 : ℝ) / 1000000000000000000) = Real.log ((458625129215628313 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((458625129215628313 : ℝ) / 1000000000000000000) = ((458625129215628313 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_370 : RB (Real.log ((229312564607814157 : ℝ) / 500000000000000000)) ((-389761057280508061 : ℝ) / 500000000000000000) ((-19488052864025403 : ℝ) / 25000000000000000) := by
  have hm := log_bounds_of_series (x := ((229312564607814157 : ℝ) / 250000000000000000)) (t := ((-20687435392185843 : ℝ) / 479312564607814157))
    (lo := ((-21593733500267703 : ℝ) / 250000000000000000)) (hi := ((-86374934001070811 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229312564607814157 : ℝ) / 500000000000000000) = Real.log ((229312564607814157 : ℝ) / 250000000000000000) - 1 * Real.log 2 := by
    rw [show ((229312564607814157 : ℝ) / 500000000000000000) = ((229312564607814157 : ℝ) / 250000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_371 : RB (Real.log ((91724824503403983 : ℝ) / 200000000000000000)) ((-779524309599292791 : ℝ) / 1000000000000000000) ((-779524309599292789 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((91724824503403983 : ℝ) / 100000000000000000)) (t := ((-8275175496596017 : ℝ) / 191724824503403983))
    (lo := ((-86377129039347481 : ℝ) / 1000000000000000000)) (hi := ((-2159428225983687 : ℝ) / 25000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91724824503403983 : ℝ) / 200000000000000000) = Real.log ((91724824503403983 : ℝ) / 100000000000000000) - 1 * Real.log 2 := by
    rw [show ((91724824503403983 : ℝ) / 200000000000000000) = ((91724824503403983 : ℝ) / 100000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_372 : RB (Real.log ((1424637723568253167 : ℝ) / 1000000000000000000)) ((353917552324014333 : ℝ) / 1000000000000000000) ((70783510464802867 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424637723568253167 : ℝ) / 2000000000000000000)) (t := ((-575362276431746833 : ℝ) / 3424637723568253167))
    (lo := ((-10600925882372843 : ℝ) / 31250000000000000)) (hi := ((-13569185129437239 : ℝ) / 40000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424637723568253167 : ℝ) / 1000000000000000000) = Real.log ((1424637723568253167 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424637723568253167 : ℝ) / 1000000000000000000) = ((1424637723568253167 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_373 : RB (Real.log ((71232357331520067 : ℝ) / 50000000000000000)) ((353924166658893071 : ℝ) / 1000000000000000000) ((353924166658893073 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((71232357331520067 : ℝ) / 100000000000000000)) (t := ((-28767642668479933 : ℝ) / 171232357331520067))
    (lo := ((-169611506950526119 : ℝ) / 500000000000000000)) (hi := ((-339223013901052237 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71232357331520067 : ℝ) / 50000000000000000) = Real.log ((71232357331520067 : ℝ) / 100000000000000000) + 1 * Real.log 2 := by
    rw [show ((71232357331520067 : ℝ) / 50000000000000000) = ((71232357331520067 : ℝ) / 100000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_374 : RB (Real.log ((425302396419815667 : ℝ) / 1000000000000000000)) ((-427477421040484347 : ℝ) / 500000000000000000) ((-213738710520242173 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((425302396419815667 : ℝ) / 500000000000000000)) (t := ((-74697603580184333 : ℝ) / 925302396419815667))
    (lo := ((-20225957690127923 : ℝ) / 125000000000000000)) (hi := ((-161807661521023383 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((425302396419815667 : ℝ) / 1000000000000000000) = Real.log ((425302396419815667 : ℝ) / 500000000000000000) - 1 * Real.log 2 := by
    rw [show ((425302396419815667 : ℝ) / 1000000000000000000) = ((425302396419815667 : ℝ) / 500000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_375 : RB (Real.log ((13290931463990203 : ℝ) / 31250000000000000)) ((-170987483665872711 : ℝ) / 200000000000000000) ((-854937418329363553 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((13290931463990203 : ℝ) / 15625000000000000)) (t := ((-2334068536009797 : ℝ) / 28915931463990203))
    (lo := ((-32358047553883649 : ℝ) / 200000000000000000)) (hi := ((-40447559442354561 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13290931463990203 : ℝ) / 31250000000000000) = Real.log ((13290931463990203 : ℝ) / 15625000000000000) - 1 * Real.log 2 := by
    rw [show ((13290931463990203 : ℝ) / 31250000000000000) = ((13290931463990203 : ℝ) / 15625000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_376 : RB (Real.log ((1425302396419815667 : ℝ) / 1000000000000000000)) ((35438399922158389 : ℝ) / 100000000000000000) ((88595999805395973 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((1425302396419815667 : ℝ) / 2000000000000000000)) (t := ((-574697603580184333 : ℝ) / 3425302396419815667))
    (lo := ((-338763181338361419 : ℝ) / 1000000000000000000)) (hi := ((-169381590669180709 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1425302396419815667 : ℝ) / 1000000000000000000) = Real.log ((1425302396419815667 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1425302396419815667 : ℝ) / 1000000000000000000) = ((1425302396419815667 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_377 : RB (Real.log ((44540931463990203 : ℝ) / 31250000000000000)) ((70877839681003417 : ℝ) / 200000000000000000) ((354389198405017087 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((44540931463990203 : ℝ) / 62500000000000000)) (t := ((-17959068536009797 : ℝ) / 107040931463990203))
    (lo := ((-10586186942341507 : ℝ) / 31250000000000000)) (hi := ((-338757982154928223 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44540931463990203 : ℝ) / 31250000000000000) = Real.log ((44540931463990203 : ℝ) / 62500000000000000) + 1 * Real.log 2 := by
    rw [show ((44540931463990203 : ℝ) / 31250000000000000) = ((44540931463990203 : ℝ) / 62500000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_378 : RB (Real.log ((284927746053372313 : ℝ) / 200000000000000000)) ((353918258958575569 : ℝ) / 1000000000000000000) ((353918258958575571 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((284927746053372313 : ℝ) / 400000000000000000)) (t := ((-115072253946627687 : ℝ) / 684927746053372313))
    (lo := ((-16961446080068487 : ℝ) / 50000000000000000)) (hi := ((-339228921601369739 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284927746053372313 : ℝ) / 200000000000000000) = Real.log ((284927746053372313 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284927746053372313 : ℝ) / 200000000000000000) = ((284927746053372313 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_379 : RB (Real.log ((712319365133430783 : ℝ) / 500000000000000000)) ((35391825895857557 : ℝ) / 100000000000000000) ((88479564739643893 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((712319365133430783 : ℝ) / 1000000000000000000)) (t := ((-287680634866569217 : ℝ) / 1712319365133430783))
    (lo := ((-339228921601369739 : ℝ) / 1000000000000000000)) (hi := ((-169614460800684869 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712319365133430783 : ℝ) / 500000000000000000) = Real.log ((712319365133430783 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712319365133430783 : ℝ) / 500000000000000000) = ((712319365133430783 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_380 : RB (Real.log ((1424639736202530511 : ℝ) / 1000000000000000000)) ((14156758602284239 : ℝ) / 40000000000000000) ((353918965057105977 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1424639736202530511 : ℝ) / 2000000000000000000)) (t := ((-575360263797469489 : ℝ) / 3424639736202530511))
    (lo := ((-169614107751419667 : ℝ) / 500000000000000000)) (hi := ((-339228215502839333 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1424639736202530511 : ℝ) / 1000000000000000000) = Real.log ((1424639736202530511 : ℝ) / 2000000000000000000) + 1 * Real.log 2 := by
    rw [show ((1424639736202530511 : ℝ) / 1000000000000000000) = ((1424639736202530511 : ℝ) / 2000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_381 : RB (Real.log ((712323070347366197 : ℝ) / 500000000000000000)) ((707846921128071 : ℝ) / 2000000000000000) ((176961730282017751 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((712323070347366197 : ℝ) / 1000000000000000000)) (t := ((-287676929652633803 : ℝ) / 1712323070347366197))
    (lo := ((-339223719995909809 : ℝ) / 1000000000000000000)) (hi := ((-21201482499744363 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712323070347366197 : ℝ) / 500000000000000000) = Real.log ((712323070347366197 : ℝ) / 1000000000000000000) + 1 * Real.log 2 := by
    rw [show ((712323070347366197 : ℝ) / 500000000000000000) = ((712323070347366197 : ℝ) / 1000000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_382 : RB (Real.log ((284929228138946479 : ℝ) / 200000000000000000)) ((707846921128071 : ℝ) / 2000000000000000) ((176961730282017751 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((284929228138946479 : ℝ) / 400000000000000000)) (t := ((-115070771861053521 : ℝ) / 684929228138946479))
    (lo := ((-339223719995909809 : ℝ) / 1000000000000000000)) (hi := ((-21201482499744363 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((284929228138946479 : ℝ) / 200000000000000000) = Real.log ((284929228138946479 : ℝ) / 400000000000000000) + 1 * Real.log 2 := by
    rw [show ((284929228138946479 : ℝ) / 200000000000000000) = ((284929228138946479 : ℝ) / 400000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_383 : RB (Real.log ((356161283499030999 : ℝ) / 250000000000000000)) ((35392275393314989 : ℝ) / 100000000000000000) ((88480688483287473 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((356161283499030999 : ℝ) / 500000000000000000)) (t := ((-143838716500969001 : ℝ) / 856161283499030999))
    (lo := ((-339224426626795419 : ℝ) / 1000000000000000000)) (hi := ((-169612213313397709 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356161283499030999 : ℝ) / 250000000000000000) = Real.log ((356161283499030999 : ℝ) / 500000000000000000) + 1 * Real.log 2 := by
    rw [show ((356161283499030999 : ℝ) / 250000000000000000) = ((356161283499030999 : ℝ) / 500000000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_384 : RB (Real.log ((25859374999999999 : ℝ) / 1000000000000000000)) ((-3655082074530645673 : ℝ) / 1000000000000000000) ((-3655082074530645671 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((25859374999999999 : ℝ) / 31250000000000000)) (t := ((-5390625000000001 : ℝ) / 57109374999999999))
    (lo := ((-1514769373847353 : ℝ) / 8000000000000000)) (hi := ((-47336542932729781 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25859374999999999 : ℝ) / 1000000000000000000) = Real.log ((25859374999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25859374999999999 : ℝ) / 1000000000000000000) = ((25859374999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_385 : RB (Real.log ((331 : ℝ) / 12800)) ((-731016414906129127 : ℝ) / 200000000000000000) ((-3655082074530645633 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((331 : ℝ) / 400)) (t := ((-69 : ℝ) / 731))
    (lo := ((-189346171730919087 : ℝ) / 1000000000000000000)) (hi := ((-94673085865459543 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((331 : ℝ) / 12800) = Real.log ((331 : ℝ) / 400) - 5 * Real.log 2 := by
    rw [show ((331 : ℝ) / 12800) = ((331 : ℝ) / 400) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_386 : RB (Real.log ((1025859374999999999 : ℝ) / 1000000000000000000)) ((25530675951296493 : ℝ) / 1000000000000000000) ((12765337975648247 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025859374999999999 : ℝ) / 1000000000000000000)) (t := ((25859374999999999 : ℝ) / 2025859374999999999))
    (lo := ((25530675951296493 : ℝ) / 1000000000000000000)) (hi := ((12765337975648247 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_387 : RB (Real.log ((13131 : ℝ) / 12800)) ((12765337975648247 : ℝ) / 500000000000000000) ((5106135190259299 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((13131 : ℝ) / 12800)) (t := ((331 : ℝ) / 25931))
    (lo := ((12765337975648247 : ℝ) / 500000000000000000)) (hi := ((5106135190259299 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_388 : RB (Real.log ((25781249999999999 : ℝ) / 1000000000000000000)) ((-731621559089436531 : ℝ) / 200000000000000000) ((-3658107795447182653 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((25781249999999999 : ℝ) / 31250000000000000)) (t := ((-5468750000000001 : ℝ) / 57031249999999999))
    (lo := ((-192371892647456107 : ℝ) / 1000000000000000000)) (hi := ((-96185946323728053 : ℝ) / 500000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25781249999999999 : ℝ) / 1000000000000000000) = Real.log ((25781249999999999 : ℝ) / 31250000000000000) - 5 * Real.log 2 := by
    rw [show ((25781249999999999 : ℝ) / 1000000000000000000) = ((25781249999999999 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_389 : RB (Real.log ((83 : ℝ) / 3200)) ((-3652065480991219993 : ℝ) / 1000000000000000000) ((-3652065480991219991 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((83 : ℝ) / 100)) (t := ((-17 : ℝ) / 183))
    (lo := ((-37265915638298689 : ℝ) / 200000000000000000)) (hi := ((-46582394547873361 : ℝ) / 250000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((83 : ℝ) / 3200) = Real.log ((83 : ℝ) / 100) - 5 * Real.log 2 := by
    rw [show ((83 : ℝ) / 3200) = ((83 : ℝ) / 100) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_390 : RB (Real.log ((1025781249999999999 : ℝ) / 1000000000000000000)) ((3181814673641667 : ℝ) / 125000000000000000) ((25454517389133337 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((1025781249999999999 : ℝ) / 1000000000000000000)) (t := ((25781249999999999 : ℝ) / 2025781249999999999))
    (lo := ((3181814673641667 : ℝ) / 125000000000000000)) (hi := ((25454517389133337 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_391 : RB (Real.log ((3283 : ℝ) / 3200)) ((12803414356887377 : ℝ) / 500000000000000000) ((5121365742754951 : ℝ) / 200000000000000000) := by
  have hm := log_bounds_of_series (x := ((3283 : ℝ) / 3200)) (t := ((83 : ℝ) / 6483))
    (lo := ((12803414356887377 : ℝ) / 500000000000000000)) (hi := ((5121365742754951 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_m_log_392 : RB (Real.log ((3667189271595267 : ℝ) / 8000000000000000)) ((-3046937652691103 : ℝ) / 3906250000000000) ((-390008019544461183 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((3667189271595267 : ℝ) / 4000000000000000)) (t := ((-332810728404733 : ℝ) / 7667189271595267))
    (lo := ((-43434429264488529 : ℝ) / 500000000000000000)) (hi := ((-86868858528977057 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3667189271595267 : ℝ) / 8000000000000000) = Real.log ((3667189271595267 : ℝ) / 4000000000000000) - 1 * Real.log 2 := by
    rw [show ((3667189271595267 : ℝ) / 8000000000000000) = ((3667189271595267 : ℝ) / 4000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_393 : RB (Real.log ((28649916184338211 : ℝ) / 62500000000000000)) ((-780016039088915821 : ℝ) / 1000000000000000000) ((-780016039088915819 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((28649916184338211 : ℝ) / 31250000000000000)) (t := ((-2600083815661789 : ℝ) / 59899916184338211))
    (lo := ((-86868858528970511 : ℝ) / 1000000000000000000)) (hi := ((-8686885852897051 : ℝ) / 100000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((28649916184338211 : ℝ) / 62500000000000000) = Real.log ((28649916184338211 : ℝ) / 31250000000000000) - 1 * Real.log 2 := by
    rw [show ((28649916184338211 : ℝ) / 62500000000000000) = ((28649916184338211 : ℝ) / 31250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_394 : RB (Real.log ((270466316887599 : ℝ) / 500000000000000)) ((-38403783097599047 : ℝ) / 62500000000000000) ((-2457842118246339 : ℝ) / 4000000000000000) := by
  have hm := log_bounds_of_series (x := ((270466316887599 : ℝ) / 250000000000000)) (t := ((20466316887599 : ℝ) / 520466316887599))
    (lo := ((39343325499180279 : ℝ) / 500000000000000000)) (hi := ((78686650998360559 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((270466316887599 : ℝ) / 500000000000000) = Real.log ((270466316887599 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((270466316887599 : ℝ) / 500000000000000) = ((270466316887599 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_395 : RB (Real.log ((540932633775201 : ℝ) / 1000000000000000)) ((-307230264780789603 : ℝ) / 500000000000000000) ((-153615132390394801 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((540932633775201 : ℝ) / 500000000000000)) (t := ((40932633775201 : ℝ) / 1040932633775201))
    (lo := ((9835831374795763 : ℝ) / 125000000000000000)) (hi := ((15737330199673221 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((540932633775201 : ℝ) / 1000000000000000) = Real.log ((540932633775201 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((540932633775201 : ℝ) / 1000000000000000) = ((540932633775201 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_396 : RB (Real.log ((459067366224799 : ℝ) / 1000000000000000)) ((-77855831231657951 : ℝ) / 100000000000000000) ((-194639578079144877 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((459067366224799 : ℝ) / 500000000000000)) (t := ((-40932633775201 : ℝ) / 959067366224799))
    (lo := ((-427055658783171 : ℝ) / 5000000000000000)) (hi := ((-85411131756634199 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((459067366224799 : ℝ) / 1000000000000000) = Real.log ((459067366224799 : ℝ) / 500000000000000) - 1 * Real.log 2 := by
    rw [show ((459067366224799 : ℝ) / 1000000000000000) = ((459067366224799 : ℝ) / 500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_397 : RB (Real.log ((229533683112401 : ℝ) / 500000000000000)) ((-31142332492662919 : ℝ) / 40000000000000000) ((-778558312316572973 : ℝ) / 1000000000000000000) := by
  have hm := log_bounds_of_series (x := ((229533683112401 : ℝ) / 250000000000000)) (t := ((-20466316887599 : ℝ) / 479533683112401))
    (lo := ((-17082226351325533 : ℝ) / 200000000000000000)) (hi := ((-5338195734789229 : ℝ) / 62500000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((229533683112401 : ℝ) / 500000000000000) = Real.log ((229533683112401 : ℝ) / 250000000000000) - 1 * Real.log 2 := by
    rw [show ((229533683112401 : ℝ) / 500000000000000) = ((229533683112401 : ℝ) / 250000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_398 : RB (Real.log ((57299832368676047 : ℝ) / 125000000000000000)) ((-390008019544461183 : ℝ) / 500000000000000000) ((-195004009772230591 : ℝ) / 250000000000000000) := by
  have hm := log_bounds_of_series (x := ((57299832368676047 : ℝ) / 62500000000000000)) (t := ((-5200167631323953 : ℝ) / 119799832368676047))
    (lo := ((-2714651829030533 : ℝ) / 31250000000000000)) (hi := ((-17373771705795411 : ℝ) / 200000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57299832368676047 : ℝ) / 125000000000000000) = Real.log ((57299832368676047 : ℝ) / 62500000000000000) - 1 * Real.log 2 := by
    rw [show ((57299832368676047 : ℝ) / 125000000000000000) = ((57299832368676047 : ℝ) / 62500000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_m_log_399 : RB (Real.log ((3667189271595291 : ℝ) / 8000000000000000)) ((-48751002443057239 : ℝ) / 62500000000000000) ((-390008019544457911 : ℝ) / 500000000000000000) := by
  have hm := log_bounds_of_series (x := ((3667189271595291 : ℝ) / 4000000000000000)) (t := ((-332810728404709 : ℝ) / 7667189271595291))
    (lo := ((-43434429264485257 : ℝ) / 500000000000000000)) (hi := ((-86868858528970513 : ℝ) / 1000000000000000000)) (by norm_num) (by norm_num) 14
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3667189271595291 : ℝ) / 8000000000000000) = Real.log ((3667189271595291 : ℝ) / 4000000000000000) - 1 * Real.log 2 := by
    rw [show ((3667189271595291 : ℝ) / 8000000000000000) = ((3667189271595291 : ℝ) / 4000000000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
