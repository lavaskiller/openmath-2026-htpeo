import LeanProject.COVLogTwo
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_0 : RB (Real.log ((10046177 : ℝ) / 12500000)) ((-21853649 : ℝ) / 100000000) ((-1365853 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((10046177 : ℝ) / 12500000)) (t := ((-2453823 : ℝ) / 22546177))
    (lo := ((-21853649 : ℝ) / 100000000)) (hi := ((-1365853 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1 : RB (Real.log ((642957 : ℝ) / 800000)) ((-5463347 : ℝ) / 25000000) ((-21853387 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((642957 : ℝ) / 800000)) (t := ((-157043 : ℝ) / 1442957))
    (lo := ((-5463347 : ℝ) / 25000000)) (hi := ((-21853387 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2 : RB (Real.log ((5570111 : ℝ) / 12500000)) ((-10103921 : ℝ) / 12500000) ((-40415683 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5570111 : ℝ) / 6250000)) (t := ((-679889 : ℝ) / 11820111))
    (lo := ((-11516649 : ℝ) / 100000000)) (hi := ((-1439581 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5570111 : ℝ) / 12500000) = Real.log ((5570111 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5570111 : ℝ) / 12500000) = ((5570111 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_3 : RB (Real.log ((197258311 : ℝ) / 100000000)) ((6793439 : ℝ) / 10000000) ((8491799 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((197258311 : ℝ) / 200000000)) (t := ((-2741689 : ℝ) / 397258311))
    (lo := ((-172541 : ℝ) / 12500000)) (hi := ((-1380327 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197258311 : ℝ) / 100000000) = Real.log ((197258311 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((197258311 : ℝ) / 100000000) = ((197258311 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_4 : RB (Real.log ((39458153 : ℝ) / 20000000)) ((67950841 : ℝ) / 100000000) ((67950843 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39458153 : ℝ) / 40000000)) (t := ((-541847 : ℝ) / 79458153))
    (lo := ((-1363877 : ℝ) / 100000000)) (hi := ((-340969 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39458153 : ℝ) / 20000000) = Real.log ((39458153 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39458153 : ℝ) / 20000000) = ((39458153 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_5 : RB (Real.log ((80950753 : ℝ) / 100000000)) ((-21132921 : ℝ) / 100000000) ((-528323 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((80950753 : ℝ) / 100000000)) (t := ((-19049247 : ℝ) / 180950753))
    (lo := ((-21132921 : ℝ) / 100000000)) (hi := ((-528323 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_6 : RB (Real.log ((40475481 : ℝ) / 50000000)) ((-21132663 : ℝ) / 100000000) ((-10566331 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((40475481 : ℝ) / 50000000)) (t := ((-9524519 : ℝ) / 90475481))
    (lo := ((-21132663 : ℝ) / 100000000)) (hi := ((-10566331 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_7 : RB (Real.log ((11184749 : ℝ) / 25000000)) ((-80432469 : ℝ) / 100000000) ((-80432467 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11184749 : ℝ) / 12500000)) (t := ((-1315251 : ℝ) / 23684749))
    (lo := ((-44471 : ℝ) / 400000)) (hi := ((-11117749 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11184749 : ℝ) / 25000000) = Real.log ((11184749 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11184749 : ℝ) / 25000000) = ((11184749 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_8 : RB (Real.log ((118357639 : ℝ) / 25000000)) ((31096701 : ℝ) / 20000000) ((38870877 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((118357639 : ℝ) / 100000000)) (t := ((18357639 : ℝ) / 218357639))
    (lo := ((16854069 : ℝ) / 100000000)) (hi := ((1685407 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((118357639 : ℝ) / 25000000) = Real.log ((118357639 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((118357639 : ℝ) / 25000000) = ((118357639 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_9 : RB (Real.log ((473430987 : ℝ) / 100000000)) ((38870899 : ℝ) / 25000000) ((155483599 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((473430987 : ℝ) / 400000000)) (t := ((73430987 : ℝ) / 873430987))
    (lo := ((210677 : ℝ) / 1250000)) (hi := ((16854161 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((473430987 : ℝ) / 100000000) = Real.log ((473430987 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((473430987 : ℝ) / 100000000) = ((473430987 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_10 : RB (Real.log ((7923591 : ℝ) / 6250000)) ((741447 : ℝ) / 3125000) ((4745261 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((7923591 : ℝ) / 6250000)) (t := ((1673591 : ℝ) / 14173591))
    (lo := ((741447 : ℝ) / 3125000)) (hi := ((4745261 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_11 : RB (Real.log ((472049867 : ℝ) / 100000000)) ((38797861 : ℝ) / 25000000) ((155191447 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((472049867 : ℝ) / 400000000)) (t := ((72049867 : ℝ) / 872049867))
    (lo := ((2070251 : ℝ) / 12500000)) (hi := ((16562009 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((472049867 : ℝ) / 100000000) = Real.log ((472049867 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((472049867 : ℝ) / 100000000) = ((472049867 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_12 : RB (Real.log ((59006287 : ℝ) / 12500000)) ((31038307 : ℝ) / 20000000) ((77595769 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((59006287 : ℝ) / 50000000)) (t := ((9006287 : ℝ) / 109006287))
    (lo := ((16562099 : ℝ) / 100000000)) (hi := ((165621 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((59006287 : ℝ) / 12500000) = Real.log ((59006287 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((59006287 : ℝ) / 12500000) = ((59006287 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_13 : RB (Real.log ((31719207 : ℝ) / 25000000)) ((23804657 : ℝ) / 100000000) ((11902329 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((31719207 : ℝ) / 25000000)) (t := ((6719207 : ℝ) / 56719207))
    (lo := ((23804657 : ℝ) / 100000000)) (hi := ((11902329 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_14 : RB (Real.log ((1514637 : ℝ) / 20000000)) ((-258055651 : ℝ) / 100000000) ((-129027823 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1514637 : ℝ) / 1250000)) (t := ((264637 : ℝ) / 2764637))
    (lo := ((768129 : ℝ) / 4000000)) (hi := ((9601613 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1514637 : ℝ) / 20000000) = Real.log ((1514637 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1514637 : ℝ) / 20000000) = ((1514637 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_15 : RB (Real.log ((806861 : ℝ) / 10000000)) ((-2517189 : ℝ) / 1000000) ((-50343779 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((806861 : ℝ) / 625000)) (t := ((181861 : ℝ) / 1431861))
    (lo := ((3192497 : ℝ) / 12500000)) (hi := ((25539977 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((806861 : ℝ) / 10000000) = Real.log ((806861 : ℝ) / 625000) - 4 * Real.log 2 := by
    rw [show ((806861 : ℝ) / 10000000) = ((806861 : ℝ) / 625000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_16 : RB (Real.log ((1349777 : ℝ) / 100000000)) ((-86104617 : ℝ) / 20000000) ((-215261539 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1349777 : ℝ) / 1562500)) (t := ((-212723 : ℝ) / 2912277))
    (lo := ((-14634771 : ℝ) / 100000000)) (hi := ((-1463477 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1349777 : ℝ) / 100000000) = Real.log ((1349777 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1349777 : ℝ) / 100000000) = ((1349777 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_17 : RB (Real.log ((68317 : ℝ) / 5000000)) ((-214651731 : ℝ) / 50000000) ((-85860691 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((68317 : ℝ) / 78125)) (t := ((-4904 : ℝ) / 73221))
    (lo := ((-3353787 : ℝ) / 25000000)) (hi := ((-13415147 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((68317 : ℝ) / 5000000) = Real.log ((68317 : ℝ) / 78125) - 6 * Real.log 2 := by
    rw [show ((68317 : ℝ) / 5000000) = ((68317 : ℝ) / 78125) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_18 : RB (Real.log ((16027037 : ℝ) / 20000000)) ((-22145517 : ℝ) / 100000000) ((-5536379 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((16027037 : ℝ) / 20000000)) (t := ((-3972963 : ℝ) / 36027037))
    (lo := ((-22145517 : ℝ) / 100000000)) (hi := ((-5536379 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_19 : RB (Real.log ((16027079 : ℝ) / 20000000)) ((-4429051 : ℝ) / 20000000) ((-11072627 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16027079 : ℝ) / 20000000)) (t := ((-3972921 : ℝ) / 36027079))
    (lo := ((-4429051 : ℝ) / 20000000)) (hi := ((-11072627 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_20 : RB (Real.log ((1390277 : ℝ) / 3125000)) ((-80993129 : ℝ) / 100000000) ((-80993127 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1390277 : ℝ) / 1562500)) (t := ((-172223 : ℝ) / 2952777))
    (lo := ((-1167841 : ℝ) / 10000000)) (hi := ((-11678409 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1390277 : ℝ) / 3125000) = Real.log ((1390277 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((1390277 : ℝ) / 3125000) = ((1390277 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_21 : RB (Real.log ((197225857 : ℝ) / 100000000)) ((4244871 : ℝ) / 6250000) ((33958969 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((197225857 : ℝ) / 200000000)) (t := ((-2774143 : ℝ) / 397225857))
    (lo := ((-698391 : ℝ) / 50000000)) (hi := ((-1396781 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197225857 : ℝ) / 100000000) = Real.log ((197225857 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((197225857 : ℝ) / 100000000) = ((197225857 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_22 : RB (Real.log ((39451663 : ℝ) / 20000000)) ((8491799 : ℝ) / 12500000) ((33967197 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39451663 : ℝ) / 40000000)) (t := ((-548337 : ℝ) / 79451663))
    (lo := ((-690163 : ℝ) / 50000000)) (hi := ((-55213 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39451663 : ℝ) / 20000000) = Real.log ((39451663 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39451663 : ℝ) / 20000000) = ((39451663 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_23 : RB (Real.log ((2527521 : ℝ) / 3125000)) ((-21219531 : ℝ) / 100000000) ((-2121953 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((2527521 : ℝ) / 3125000)) (t := ((-597479 : ℝ) / 5652521))
    (lo := ((-21219531 : ℝ) / 100000000)) (hi := ((-2121953 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_24 : RB (Real.log ((40440441 : ℝ) / 50000000)) ((-21219271 : ℝ) / 100000000) ((-2121927 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((40440441 : ℝ) / 50000000)) (t := ((-9559559 : ℝ) / 90440441))
    (lo := ((-21219271 : ℝ) / 100000000)) (hi := ((-2121927 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_25 : RB (Real.log ((44717649 : ℝ) / 100000000)) ((-40240097 : ℝ) / 50000000) ((-1257503 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((44717649 : ℝ) / 50000000)) (t := ((-5282351 : ℝ) / 94717649))
    (lo := ((-446619 : ℝ) / 4000000)) (hi := ((-5582737 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44717649 : ℝ) / 100000000) = Real.log ((44717649 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44717649 : ℝ) / 100000000) = ((44717649 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_26 : RB (Real.log ((472968051 : ℝ) / 100000000)) ((31077153 : ℝ) / 20000000) ((19423221 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((472968051 : ℝ) / 400000000)) (t := ((72968051 : ℝ) / 872968051))
    (lo := ((16756329 : ℝ) / 100000000)) (hi := ((1675633 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((472968051 : ℝ) / 100000000) = Real.log ((472968051 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((472968051 : ℝ) / 100000000) = ((472968051 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_27 : RB (Real.log ((94593697 : ℝ) / 20000000)) ((155385857 : ℝ) / 100000000) ((7769293 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((94593697 : ℝ) / 80000000)) (t := ((14593697 : ℝ) / 174593697))
    (lo := ((16756421 : ℝ) / 100000000)) (hi := ((8378211 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94593697 : ℝ) / 20000000) = Real.log ((94593697 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((94593697 : ℝ) / 20000000) = ((94593697 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_28 : RB (Real.log ((126810631 : ℝ) / 100000000)) ((23752469 : ℝ) / 100000000) ((2375247 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((126810631 : ℝ) / 100000000)) (t := ((26810631 : ℝ) / 226810631))
    (lo := ((23752469 : ℝ) / 100000000)) (hi := ((2375247 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_29 : RB (Real.log ((29474557 : ℝ) / 6250000)) ((31018919 : ℝ) / 20000000) ((77547299 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((29474557 : ℝ) / 25000000)) (t := ((4474557 : ℝ) / 54474557))
    (lo := ((16465159 : ℝ) / 100000000)) (hi := ((411629 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((29474557 : ℝ) / 6250000) = Real.log ((29474557 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((29474557 : ℝ) / 6250000) = ((29474557 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_30 : RB (Real.log ((3684323 : ℝ) / 781250)) ((77547343 : ℝ) / 50000000) ((155094689 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3684323 : ℝ) / 3125000)) (t := ((559323 : ℝ) / 6809323))
    (lo := ((65861 : ℝ) / 400000)) (hi := ((16465251 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3684323 : ℝ) / 781250) = Real.log ((3684323 : ℝ) / 3125000) + 2 * Real.log 2 := by
    rw [show ((3684323 : ℝ) / 781250) = ((3684323 : ℝ) / 3125000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_31 : RB (Real.log ((15863731 : ℝ) / 12500000)) ((23830679 : ℝ) / 100000000) ((595767 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((15863731 : ℝ) / 12500000)) (t := ((3363731 : ℝ) / 28363731))
    (lo := ((23830679 : ℝ) / 100000000)) (hi := ((595767 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_32 : RB (Real.log ((7510043 : ℝ) / 100000000)) ((-32361613 : ℝ) / 12500000) ((-258892899 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((7510043 : ℝ) / 6250000)) (t := ((1260043 : ℝ) / 13760043))
    (lo := ((4591493 : ℝ) / 25000000)) (hi := ((18365973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7510043 : ℝ) / 100000000) = Real.log ((7510043 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((7510043 : ℝ) / 100000000) = ((7510043 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_33 : RB (Real.log ((1623483 : ℝ) / 20000000)) ((-31389481 : ℝ) / 12500000) ((-251115843 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1623483 : ℝ) / 1250000)) (t := ((373483 : ℝ) / 2873483))
    (lo := ((6535757 : ℝ) / 25000000)) (hi := ((26143029 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1623483 : ℝ) / 20000000) = Real.log ((1623483 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1623483 : ℝ) / 20000000) = ((1623483 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_34 : RB (Real.log ((1365887 : ℝ) / 100000000)) ((-429336621 : ℝ) / 100000000) ((-214668307 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1365887 : ℝ) / 1562500)) (t := ((-196613 : ℝ) / 2928387))
    (lo := ((-13448307 : ℝ) / 100000000)) (hi := ((-6724153 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1365887 : ℝ) / 100000000) = Real.log ((1365887 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1365887 : ℝ) / 100000000) = ((1365887 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_35 : RB (Real.log ((172807 : ℝ) / 12500000)) ((-214065431 : ℝ) / 50000000) ((-85626171 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((345614 : ℝ) / 390625)) (t := ((-45011 : ℝ) / 736239))
    (lo := ((-3060637 : ℝ) / 25000000)) (hi := ((-12242547 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((172807 : ℝ) / 12500000) = Real.log ((345614 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((172807 : ℝ) / 12500000) = ((345614 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_36 : RB (Real.log ((39993863 : ℝ) / 50000000)) ((-22329699 : ℝ) / 100000000) ((-11164849 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39993863 : ℝ) / 50000000)) (t := ((-10006137 : ℝ) / 89993863))
    (lo := ((-22329699 : ℝ) / 100000000)) (hi := ((-11164849 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_37 : RB (Real.log ((79987939 : ℝ) / 100000000)) ((-22329433 : ℝ) / 100000000) ((-2791179 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((79987939 : ℝ) / 100000000)) (t := ((-20012061 : ℝ) / 179987939))
    (lo := ((-22329433 : ℝ) / 100000000)) (hi := ((-2791179 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_38 : RB (Real.log ((888869 : ℝ) / 2000000)) ((-81095261 : ℝ) / 100000000) ((-81095259 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((888869 : ℝ) / 1000000)) (t := ((-111131 : ℝ) / 1888869))
    (lo := ((-5890271 : ℝ) / 50000000)) (hi := ((-11780541 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((888869 : ℝ) / 2000000) = Real.log ((888869 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((888869 : ℝ) / 2000000) = ((888869 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_39 : RB (Real.log ((197193401 : ℝ) / 100000000)) ((67901479 : ℝ) / 100000000) ((67901481 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((197193401 : ℝ) / 200000000)) (t := ((-2806599 : ℝ) / 397193401))
    (lo := ((-1413239 : ℝ) / 100000000)) (hi := ((-706619 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((197193401 : ℝ) / 100000000) = Real.log ((197193401 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((197193401 : ℝ) / 100000000) = ((197193401 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_40 : RB (Real.log ((24653233 : ℝ) / 12500000)) ((3395897 : ℝ) / 5000000) ((33958971 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((24653233 : ℝ) / 25000000)) (t := ((-346767 : ℝ) / 49653233))
    (lo := ((-698389 : ℝ) / 50000000)) (hi := ((-1396777 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24653233 : ℝ) / 12500000) = Real.log ((24653233 : ℝ) / 25000000) + 1 * Real.log 2 := by
    rw [show ((24653233 : ℝ) / 12500000) = ((24653233 : ℝ) / 25000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_41 : RB (Real.log ((10090761 : ℝ) / 12500000)) ((-535271 : ℝ) / 2500000) ((-21410839 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10090761 : ℝ) / 12500000)) (t := ((-2409239 : ℝ) / 22590761))
    (lo := ((-535271 : ℝ) / 2500000)) (hi := ((-21410839 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_42 : RB (Real.log ((40363151 : ℝ) / 50000000)) ((-856423 : ℝ) / 4000000) ((-10705287 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((40363151 : ℝ) / 50000000)) (t := ((-9636849 : ℝ) / 90363151))
    (lo := ((-856423 : ℝ) / 4000000)) (hi := ((-10705287 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_43 : RB (Real.log ((11167607 : ℝ) / 25000000)) ((-10073231 : ℝ) / 12500000) ((-40292923 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((11167607 : ℝ) / 12500000)) (t := ((-1332393 : ℝ) / 23667607))
    (lo := ((-11271129 : ℝ) / 100000000)) (hi := ((-1408891 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11167607 : ℝ) / 25000000) = Real.log ((11167607 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11167607 : ℝ) / 25000000) = ((11167607 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_44 : RB (Real.log ((472507403 : ℝ) / 100000000)) ((77644161 : ℝ) / 50000000) ((6211533 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((472507403 : ℝ) / 400000000)) (t := ((72507403 : ℝ) / 872507403))
    (lo := ((8329443 : ℝ) / 50000000)) (hi := ((16658887 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((472507403 : ℝ) / 100000000) = Real.log ((472507403 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((472507403 : ℝ) / 100000000) = ((472507403 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_45 : RB (Real.log ((472507843 : ℝ) / 100000000)) ((31057683 : ℝ) / 20000000) ((77644209 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((472507843 : ℝ) / 400000000)) (t := ((72507843 : ℝ) / 872507843))
    (lo := ((16658979 : ℝ) / 100000000)) (hi := ((832949 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((472507843 : ℝ) / 100000000) = Real.log ((472507843 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((472507843 : ℝ) / 100000000) = ((472507843 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_46 : RB (Real.log ((63421877 : ℝ) / 50000000)) ((4755717 : ℝ) / 20000000) ((11889293 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((63421877 : ℝ) / 50000000)) (t := ((13421877 : ℝ) / 113421877))
    (lo := ((4755717 : ℝ) / 20000000)) (hi := ((11889293 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_47 : RB (Real.log ((471137759 : ℝ) / 100000000)) ((77499017 : ℝ) / 50000000) ((154998037 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((471137759 : ℝ) / 400000000)) (t := ((71137759 : ℝ) / 871137759))
    (lo := ((8184299 : ℝ) / 50000000)) (hi := ((16368599 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((471137759 : ℝ) / 100000000) = Real.log ((471137759 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((471137759 : ℝ) / 100000000) = ((471137759 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_48 : RB (Real.log ((235569099 : ℝ) / 50000000)) ((154998127 : ℝ) / 100000000) ((15499813 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((235569099 : ℝ) / 200000000)) (t := ((35569099 : ℝ) / 435569099))
    (lo := ((16368691 : ℝ) / 100000000)) (hi := ((4092173 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((235569099 : ℝ) / 50000000) = Real.log ((235569099 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((235569099 : ℝ) / 50000000) = ((235569099 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_49 : RB (Real.log ((63471409 : ℝ) / 50000000)) ((11928327 : ℝ) / 50000000) ((4771331 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((63471409 : ℝ) / 50000000)) (t := ((13471409 : ℝ) / 113471409))
    (lo := ((11928327 : ℝ) / 50000000)) (hi := ((4771331 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_50 : RB (Real.log ((375271 : ℝ) / 5000000)) ((-3236931 : ℝ) / 1250000) ((-10358179 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((375271 : ℝ) / 312500)) (t := ((62771 : ℝ) / 687771))
    (lo := ((4576099 : ℝ) / 25000000)) (hi := ((18304397 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((375271 : ℝ) / 5000000) = Real.log ((375271 : ℝ) / 312500) - 4 * Real.log 2 := by
    rw [show ((375271 : ℝ) / 5000000) = ((375271 : ℝ) / 312500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_51 : RB (Real.log ((1621711 : ℝ) / 20000000)) ((-50245011 : ℝ) / 20000000) ((-5024501 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((1621711 : ℝ) / 1250000)) (t := ((371711 : ℝ) / 2871711))
    (lo := ((26033821 : ℝ) / 100000000)) (hi := ((13016911 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1621711 : ℝ) / 20000000) = Real.log ((1621711 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1621711 : ℝ) / 20000000) = ((1621711 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_52 : RB (Real.log ((690999 : ℝ) / 50000000)) ((-428163997 : ℝ) / 100000000) ((-42816399 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((690999 : ℝ) / 781250)) (t := ((-90251 : ℝ) / 1472249))
    (lo := ((-12275683 : ℝ) / 100000000)) (hi := ((-6137841 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((690999 : ℝ) / 50000000) = Real.log ((690999 : ℝ) / 781250) - 6 * Real.log 2 := by
    rw [show ((690999 : ℝ) / 50000000) = ((690999 : ℝ) / 781250) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_53 : RB (Real.log ((349643 : ℝ) / 25000000)) ((-426971853 : ℝ) / 100000000) ((-213485923 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((349643 : ℝ) / 390625)) (t := ((-20491 : ℝ) / 370134))
    (lo := ((-11083539 : ℝ) / 100000000)) (hi := ((-5541769 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((349643 : ℝ) / 25000000) = Real.log ((349643 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((349643 : ℝ) / 25000000) = ((349643 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_54 : RB (Real.log ((19960419 : ℝ) / 25000000)) ((-22512457 : ℝ) / 100000000) ((-2814057 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((19960419 : ℝ) / 25000000)) (t := ((-5039581 : ℝ) / 44960419))
    (lo := ((-22512457 : ℝ) / 100000000)) (hi := ((-2814057 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_55 : RB (Real.log ((79841891 : ℝ) / 100000000)) ((-22512187 : ℝ) / 100000000) ((-11256093 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((79841891 : ℝ) / 100000000)) (t := ((-20158109 : ℝ) / 179841891))
    (lo := ((-22512187 : ℝ) / 100000000)) (hi := ((-11256093 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_56 : RB (Real.log ((22199199 : ℝ) / 50000000)) ((-81196681 : ℝ) / 100000000) ((-81196679 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22199199 : ℝ) / 25000000)) (t := ((-2800801 : ℝ) / 47199199))
    (lo := ((-5940981 : ℝ) / 50000000)) (hi := ((-11881961 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22199199 : ℝ) / 50000000) = Real.log ((22199199 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22199199 : ℝ) / 50000000) = ((22199199 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_57 : RB (Real.log ((12322559 : ℝ) / 6250000)) ((33942509 : ℝ) / 50000000) ((3394251 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((12322559 : ℝ) / 12500000)) (t := ((-177441 : ℝ) / 24822559))
    (lo := ((-14297 : ℝ) / 1000000)) (hi := ((-1429699 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12322559 : ℝ) / 6250000) = Real.log ((12322559 : ℝ) / 12500000) + 1 * Real.log 2 := by
    rw [show ((12322559 : ℝ) / 6250000) = ((12322559 : ℝ) / 12500000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_58 : RB (Real.log ((3081147 : ℝ) / 1562500)) ((33950741 : ℝ) / 50000000) ((16975371 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((3081147 : ℝ) / 3125000)) (t := ((-43853 : ℝ) / 6206147))
    (lo := ((-353309 : ℝ) / 25000000)) (hi := ((-282647 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3081147 : ℝ) / 1562500) = Real.log ((3081147 : ℝ) / 3125000) + 1 * Real.log 2 := by
    rw [show ((3081147 : ℝ) / 1562500) = ((3081147 : ℝ) / 3125000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_59 : RB (Real.log ((40286489 : ℝ) / 50000000)) ((-10800343 : ℝ) / 50000000) ((-4320137 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((40286489 : ℝ) / 50000000)) (t := ((-9713511 : ℝ) / 90286489))
    (lo := ((-10800343 : ℝ) / 50000000)) (hi := ((-4320137 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_60 : RB (Real.log ((40286597 : ℝ) / 50000000)) ((-10800209 : ℝ) / 50000000) ((-21600417 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40286597 : ℝ) / 50000000)) (t := ((-9713403 : ℝ) / 90286597))
    (lo := ((-10800209 : ℝ) / 50000000)) (hi := ((-21600417 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_61 : RB (Real.log ((44623579 : ℝ) / 100000000)) ((-4034539 : ℝ) / 5000000) ((-40345389 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((44623579 : ℝ) / 50000000)) (t := ((-5376421 : ℝ) / 94623579))
    (lo := ((-11376061 : ℝ) / 100000000)) (hi := ((-568803 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44623579 : ℝ) / 100000000) = Real.log ((44623579 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44623579 : ℝ) / 100000000) = ((44623579 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_62 : RB (Real.log ((472048593 : ℝ) / 100000000)) ((77595587 : ℝ) / 50000000) ((155191177 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((472048593 : ℝ) / 400000000)) (t := ((72048593 : ℝ) / 872048593))
    (lo := ((8280869 : ℝ) / 50000000)) (hi := ((16561739 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((472048593 : ℝ) / 100000000) = Real.log ((472048593 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((472048593 : ℝ) / 100000000) = ((472048593 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_63 : RB (Real.log ((118012259 : ℝ) / 25000000)) ((38797817 : ℝ) / 25000000) ((155191271 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((118012259 : ℝ) / 100000000)) (t := ((18012259 : ℝ) / 218012259))
    (lo := ((2070229 : ℝ) / 12500000)) (hi := ((16561833 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((118012259 : ℝ) / 25000000) = Real.log ((118012259 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((118012259 : ℝ) / 25000000) = ((118012259 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_64 : RB (Real.log ((63438413 : ℝ) / 50000000)) ((4760931 : ℝ) / 20000000) ((1487791 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((63438413 : ℝ) / 50000000)) (t := ((13438413 : ℝ) / 113438413))
    (lo := ((4760931 : ℝ) / 20000000)) (hi := ((1487791 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_65 : RB (Real.log ((94136883 : ℝ) / 20000000)) ((30980353 : ℝ) / 20000000) ((19362721 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((94136883 : ℝ) / 80000000)) (t := ((14136883 : ℝ) / 174136883))
    (lo := ((16272329 : ℝ) / 100000000)) (hi := ((1627233 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((94136883 : ℝ) / 20000000) = Real.log ((94136883 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((94136883 : ℝ) / 20000000) = ((94136883 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_66 : RB (Real.log ((470684857 : ℝ) / 100000000)) ((77450929 : ℝ) / 50000000) ((154901861 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((470684857 : ℝ) / 400000000)) (t := ((70684857 : ℝ) / 870684857))
    (lo := ((8136211 : ℝ) / 50000000)) (hi := ((16272423 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((470684857 : ℝ) / 100000000) = Real.log ((470684857 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((470684857 : ℝ) / 100000000) = ((470684857 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_67 : RB (Real.log ((126975737 : ℝ) / 100000000)) ((23882583 : ℝ) / 100000000) ((2985323 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((126975737 : ℝ) / 100000000)) (t := ((26975737 : ℝ) / 226975737))
    (lo := ((23882583 : ℝ) / 100000000)) (hi := ((2985323 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_68 : RB (Real.log ((1500281 : ℝ) / 20000000)) ((-259007989 : ℝ) / 100000000) ((-16187999 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((1500281 : ℝ) / 1250000)) (t := ((250281 : ℝ) / 2750281))
    (lo := ((18250887 : ℝ) / 100000000)) (hi := ((2281361 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1500281 : ℝ) / 20000000) = Real.log ((1500281 : ℝ) / 1250000) - 4 * Real.log 2 := by
    rw [show ((1500281 : ℝ) / 20000000) = ((1500281 : ℝ) / 1250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_69 : RB (Real.log ((50627 : ℝ) / 625000)) ((-125663333 : ℝ) / 50000000) ((-251326661 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((101254 : ℝ) / 78125)) (t := ((23129 : ℝ) / 179379))
    (lo := ((2593221 : ℝ) / 10000000)) (hi := ((25932211 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((50627 : ℝ) / 625000) = Real.log ((101254 : ℝ) / 78125) - 4 * Real.log 2 := by
    rw [show ((50627 : ℝ) / 625000) = ((101254 : ℝ) / 78125) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_70 : RB (Real.log ((1398107 : ℝ) / 100000000)) ((-427005107 : ℝ) / 100000000) ((-4270051 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((1398107 : ℝ) / 1562500)) (t := ((-164393 : ℝ) / 2960607))
    (lo := ((-11116793 : ℝ) / 100000000)) (hi := ((-1389599 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1398107 : ℝ) / 100000000) = Real.log ((1398107 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((1398107 : ℝ) / 100000000) = ((1398107 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_71 : RB (Real.log ((44209 : ℝ) / 3125000)) ((-106456531 : ℝ) / 25000000) ((-425826117 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((353672 : ℝ) / 390625)) (t := ((-36953 : ℝ) / 744297))
    (lo := ((-993781 : ℝ) / 10000000)) (hi := ((-9937809 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44209 : ℝ) / 3125000) = Real.log ((353672 : ℝ) / 390625) - 6 * Real.log 2 := by
    rw [show ((44209 : ℝ) / 3125000) = ((353672 : ℝ) / 390625) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_72 : RB (Real.log ((15939403 : ℝ) / 20000000)) ((-11346903 : ℝ) / 50000000) ((-4538761 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((15939403 : ℝ) / 20000000)) (t := ((-4060597 : ℝ) / 35939403))
    (lo := ((-11346903 : ℝ) / 50000000)) (hi := ((-4538761 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_73 : RB (Real.log ((79697233 : ℝ) / 100000000)) ((-5673383 : ℝ) / 25000000) ((-22693531 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((79697233 : ℝ) / 100000000)) (t := ((-20302767 : ℝ) / 179697233))
    (lo := ((-5673383 : ℝ) / 25000000)) (hi := ((-22693531 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_74 : RB (Real.log ((5544213 : ℝ) / 12500000)) ((-40648699 : ℝ) / 50000000) ((-20324349 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((5544213 : ℝ) / 6250000)) (t := ((-705787 : ℝ) / 11794213))
    (lo := ((-11982679 : ℝ) / 100000000)) (hi := ((-5991339 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5544213 : ℝ) / 12500000) = Real.log ((5544213 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5544213 : ℝ) / 12500000) = ((5544213 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_75 : RB (Real.log ((98564241 : ℝ) / 50000000)) ((8483569 : ℝ) / 12500000) ((33934277 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((98564241 : ℝ) / 100000000)) (t := ((-1435759 : ℝ) / 198564241))
    (lo := ((-723083 : ℝ) / 50000000)) (hi := ((-289233 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98564241 : ℝ) / 50000000) = Real.log ((98564241 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((98564241 : ℝ) / 50000000) = ((98564241 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_76 : RB (Real.log ((49290237 : ℝ) / 25000000)) ((3394251 : ℝ) / 5000000) ((33942511 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((49290237 : ℝ) / 50000000)) (t := ((-709763 : ℝ) / 99290237))
    (lo := ((-714849 : ℝ) / 50000000)) (hi := ((-1429697 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((49290237 : ℝ) / 25000000) = Real.log ((49290237 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((49290237 : ℝ) / 25000000) = ((49290237 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_77 : RB (Real.log ((40210663 : ℝ) / 50000000)) ((-544727 : ℝ) / 2500000) ((-21789079 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40210663 : ℝ) / 50000000)) (t := ((-9789337 : ℝ) / 90210663))
    (lo := ((-544727 : ℝ) / 2500000)) (hi := ((-21789079 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_78 : RB (Real.log ((16084309 : ℝ) / 20000000)) ((-2723601 : ℝ) / 12500000) ((-21788807 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16084309 : ℝ) / 20000000)) (t := ((-3915691 : ℝ) / 36084309))
    (lo := ((-2723601 : ℝ) / 12500000)) (hi := ((-21788807 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_79 : RB (Real.log ((44577099 : ℝ) / 100000000)) ((-16158999 : ℝ) / 20000000) ((-80794993 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((44577099 : ℝ) / 50000000)) (t := ((-5422901 : ℝ) / 94577099))
    (lo := ((-2870069 : ℝ) / 25000000)) (hi := ((-459211 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44577099 : ℝ) / 100000000) = Real.log ((44577099 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44577099 : ℝ) / 100000000) = ((44577099 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
