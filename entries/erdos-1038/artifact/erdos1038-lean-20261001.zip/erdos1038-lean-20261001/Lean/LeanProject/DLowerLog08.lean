import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog05
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_480 : RB (Real.log ((432887 : ℝ) / 400000)) ((79012176859 : ℝ) / 1000000000000) ((3950608843 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((432887 : ℝ) / 400000)) (t := ((32887 : ℝ) / 832887))
    (lo := ((79012176859 : ℝ) / 1000000000000)) (hi := ((3950608843 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_481 : RB (Real.log ((79916249999 : ℝ) / 1000000000000)) ((-1263388033839 : ℝ) / 500000000000) ((-631694016919 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((79916249999 : ℝ) / 62500000000)) (t := ((17416249999 : ℝ) / 142416249999))
    (lo := ((122906327281 : ℝ) / 500000000000)) (hi := ((245812654563 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((79916249999 : ℝ) / 1000000000000) = Real.log ((79916249999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((79916249999 : ℝ) / 1000000000000) = ((79916249999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_482 : RB (Real.log ((32887 : ℝ) / 400000)) ((-2498387104203 : ℝ) / 1000000000000) ((-2498387104201 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((32887 : ℝ) / 25000)) (t := ((7887 : ℝ) / 57887))
    (lo := ((274201618037 : ℝ) / 1000000000000)) (hi := ((137100809019 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32887 : ℝ) / 400000) = Real.log ((32887 : ℝ) / 25000) - 4 * Real.log 2 := by
    rw [show ((32887 : ℝ) / 400000) = ((32887 : ℝ) / 25000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_483 : RB (Real.log ((271775444997 : ℝ) / 500000000000)) ((-609631942961 : ℝ) / 1000000000000) ((-609631942959 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((271775444997 : ℝ) / 250000000000)) (t := ((21775444997 : ℝ) / 521775444997))
    (lo := ((83515237599 : ℝ) / 1000000000000)) (hi := ((104394047 : ℝ) / 1250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((271775444997 : ℝ) / 500000000000) = Real.log ((271775444997 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((271775444997 : ℝ) / 500000000000) = ((271775444997 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_484 : RB (Real.log ((544130724237 : ℝ) / 1000000000000)) ((-38035359943 : ℝ) / 62500000000) ((-304282879543 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((544130724237 : ℝ) / 500000000000)) (t := ((44130724237 : ℝ) / 1044130724237))
    (lo := ((2643169421 : ℝ) / 31250000000)) (hi := ((84581421473 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((544130724237 : ℝ) / 1000000000000) = Real.log ((544130724237 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((544130724237 : ℝ) / 1000000000000) = ((544130724237 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_485 : RB (Real.log ((178261245181 : ℝ) / 500000000000)) ((-1031357954549 : ℝ) / 1000000000000) ((-1031357954547 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((178261245181 : ℝ) / 250000000000)) (t := ((-71738754819 : ℝ) / 428261245181))
    (lo := ((-338210773989 : ℝ) / 1000000000000)) (hi := ((-84552693497 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((178261245181 : ℝ) / 500000000000) = Real.log ((178261245181 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((178261245181 : ℝ) / 500000000000) = ((178261245181 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_486 : RB (Real.log ((3228373968619 : ℝ) / 1000000000000)) ((1171978595189 : ℝ) / 1000000000000) ((1171978595191 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3228373968619 : ℝ) / 4000000000000)) (t := ((-771626031381 : ℝ) / 7228373968619))
    (lo := ((-21431576593 : ℝ) / 100000000000)) (hi := ((-214315765929 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3228373968619 : ℝ) / 1000000000000) = Real.log ((3228373968619 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3228373968619 : ℝ) / 1000000000000) = ((3228373968619 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_487 : RB (Real.log ((3229211056363 : ℝ) / 1000000000000)) ((586118926201 : ℝ) / 500000000000) ((293059463101 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3229211056363 : ℝ) / 4000000000000)) (t := ((-770788943637 : ℝ) / 7229211056363))
    (lo := ((-214056508717 : ℝ) / 1000000000000)) (hi := ((-53514127179 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3229211056363 : ℝ) / 1000000000000) = Real.log ((3229211056363 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3229211056363 : ℝ) / 1000000000000) = ((3229211056363 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_488 : RB (Real.log ((722862117553 : ℝ) / 500000000000)) ((368610396769 : ℝ) / 1000000000000) ((368610396771 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((722862117553 : ℝ) / 1000000000000)) (t := ((-277137882447 : ℝ) / 1722862117553))
    (lo := ((-32453678379 : ℝ) / 100000000000)) (hi := ((-324536783789 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((722862117553 : ℝ) / 500000000000) = Real.log ((722862117553 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((722862117553 : ℝ) / 500000000000) = ((722862117553 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_489 : RB (Real.log ((1082217499999 : ℝ) / 1000000000000)) ((39506088429 : ℝ) / 500000000000) ((79012176859 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1082217499999 : ℝ) / 1000000000000)) (t := ((82217499999 : ℝ) / 2082217499999))
    (lo := ((39506088429 : ℝ) / 500000000000)) (hi := ((79012176859 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_490 : RB (Real.log ((173523 : ℝ) / 160000)) ((5071021263 : ℝ) / 62500000000) ((81136340209 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((173523 : ℝ) / 160000)) (t := ((13523 : ℝ) / 333523))
    (lo := ((5071021263 : ℝ) / 62500000000)) (hi := ((81136340209 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_491 : RB (Real.log ((82217499999 : ℝ) / 1000000000000)) ((-499677420843 : ℝ) / 200000000000) ((-2498387104213 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((82217499999 : ℝ) / 62500000000)) (t := ((19717499999 : ℝ) / 144717499999))
    (lo := ((10968064721 : ℝ) / 40000000000)) (hi := ((137100809013 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((82217499999 : ℝ) / 1000000000000) = Real.log ((82217499999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((82217499999 : ℝ) / 1000000000000) = ((82217499999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_492 : RB (Real.log ((13523 : ℝ) / 160000)) ((-494156375149 : ℝ) / 200000000000) ((-123539093787 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((13523 : ℝ) / 20000)) (t := ((-6477 : ℝ) / 33523))
    (lo := ((-78268066813 : ℝ) / 200000000000)) (hi := ((-391340334061 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13523 : ℝ) / 160000) = Real.log ((13523 : ℝ) / 20000) - 3 * Real.log 2 := by
    rw [show ((13523 : ℝ) / 160000) = ((13523 : ℝ) / 20000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_493 : RB (Real.log ((530262968121 : ℝ) / 1000000000000)) ((-31719111461 : ℝ) / 50000000000) ((-317191114609 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((530262968121 : ℝ) / 500000000000)) (t := ((30262968121 : ℝ) / 1030262968121))
    (lo := ((2938247567 : ℝ) / 50000000000)) (hi := ((58764951341 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((530262968121 : ℝ) / 1000000000000) = Real.log ((530262968121 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((530262968121 : ℝ) / 1000000000000) = ((530262968121 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_494 : RB (Real.log ((530854357313 : ℝ) / 1000000000000)) ((-39579223461 : ℝ) / 62500000000) ((-316633787687 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((530854357313 : ℝ) / 500000000000)) (t := ((30854357313 : ℝ) / 1030854357313))
    (lo := ((935618831 : ℝ) / 15625000000)) (hi := ((11975921037 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((530854357313 : ℝ) / 1000000000000) = Real.log ((530854357313 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((530854357313 : ℝ) / 1000000000000) = ((530854357313 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_495 : RB (Real.log ((351185644833 : ℝ) / 1000000000000)) ((-1046440292679 : ℝ) / 1000000000000) ((-261610073169 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((351185644833 : ℝ) / 500000000000)) (t := ((-148814355167 : ℝ) / 851185644833))
    (lo := ((-353293112119 : ℝ) / 1000000000000)) (hi := ((-353293112117 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((351185644833 : ℝ) / 1000000000000) = Real.log ((351185644833 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((351185644833 : ℝ) / 1000000000000) = ((351185644833 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_496 : RB (Real.log ((1609495377343 : ℝ) / 500000000000)) ((292266970051 : ℝ) / 250000000000) ((584533940103 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1609495377343 : ℝ) / 2000000000000)) (t := ((-390504622657 : ℝ) / 3609495377343))
    (lo := ((-43445296183 : ℝ) / 200000000000)) (hi := ((-108613240457 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1609495377343 : ℝ) / 500000000000) = Real.log ((1609495377343 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1609495377343 : ℝ) / 500000000000) = ((1609495377343 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_497 : RB (Real.log ((3219848311311 : ℝ) / 1000000000000)) ((1169334250157 : ℝ) / 1000000000000) ((1169334250159 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3219848311311 : ℝ) / 4000000000000)) (t := ((-780151688689 : ℝ) / 7219848311311))
    (lo := ((-108480055481 : ℝ) / 500000000000)) (hi := ((-216960110961 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3219848311311 : ℝ) / 1000000000000) = Real.log ((3219848311311 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3219848311311 : ℝ) / 1000000000000) = ((3219848311311 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_498 : RB (Real.log ((723718052633 : ℝ) / 500000000000)) ((7395875761 : ℝ) / 20000000000) ((92448447013 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((723718052633 : ℝ) / 1000000000000)) (t := ((-276281947367 : ℝ) / 1723718052633))
    (lo := ((-323353392509 : ℝ) / 1000000000000)) (hi := ((-80838348127 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((723718052633 : ℝ) / 500000000000) = Real.log ((723718052633 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((723718052633 : ℝ) / 500000000000) = ((723718052633 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_499 : RB (Real.log ((1084518749999 : ℝ) / 1000000000000)) ((81136340207 : ℝ) / 1000000000000) ((5071021263 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((1084518749999 : ℝ) / 1000000000000)) (t := ((84518749999 : ℝ) / 2084518749999))
    (lo := ((81136340207 : ℝ) / 1000000000000)) (hi := ((5071021263 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_500 : RB (Real.log ((54341 : ℝ) / 50000)) ((1665120021 : ℝ) / 20000000000) ((83256001051 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((54341 : ℝ) / 50000)) (t := ((4341 : ℝ) / 104341))
    (lo := ((1665120021 : ℝ) / 20000000000)) (hi := ((83256001051 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_501 : RB (Real.log ((84518749999 : ℝ) / 1000000000000)) ((-2470781875757 : ℝ) / 1000000000000) ((-2470781875751 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((84518749999 : ℝ) / 125000000000)) (t := ((-40481250001 : ℝ) / 209518749999))
    (lo := ((-391340334077 : ℝ) / 1000000000000)) (hi := ((-48917541759 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((84518749999 : ℝ) / 1000000000000) = Real.log ((84518749999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((84518749999 : ℝ) / 1000000000000) = ((84518749999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_502 : RB (Real.log ((4341 : ℝ) / 50000)) ((-305489783639 : ℝ) / 125000000000) ((-2443918269109 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((4341 : ℝ) / 6250)) (t := ((-1909 : ℝ) / 10591))
    (lo := ((-45559590929 : ℝ) / 125000000000)) (hi := ((-36447672743 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4341 : ℝ) / 50000) = Real.log ((4341 : ℝ) / 6250) - 3 * Real.log 2 := by
    rw [show ((4341 : ℝ) / 50000) = ((4341 : ℝ) / 6250) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_503 : RB (Real.log ((64645549509 : ℝ) / 125000000000)) ((-659394474223 : ℝ) / 1000000000000) ((-659394474221 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((64645549509 : ℝ) / 62500000000)) (t := ((2145549509 : ℝ) / 127145549509))
    (lo := ((33752706337 : ℝ) / 1000000000000)) (hi := ((16876353169 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64645549509 : ℝ) / 125000000000) = Real.log ((64645549509 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((64645549509 : ℝ) / 125000000000) = ((64645549509 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_504 : RB (Real.log ((64720893399 : ℝ) / 125000000000)) ((-82278707573 : ℝ) / 125000000000) ((-329114830291 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((64720893399 : ℝ) / 62500000000)) (t := ((2220893399 : ℝ) / 127220893399))
    (lo := ((4364689997 : ℝ) / 125000000000)) (hi := ((34917519977 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((64720893399 : ℝ) / 125000000000) = Real.log ((64720893399 : ℝ) / 62500000000) - 1 * Real.log 2 := by
    rw [show ((64720893399 : ℝ) / 125000000000) = ((64720893399 : ℝ) / 62500000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_505 : RB (Real.log ((172921968717 : ℝ) / 500000000000)) ((-1061767653557 : ℝ) / 1000000000000) ((-530883826777 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((172921968717 : ℝ) / 250000000000)) (t := ((-77078031283 : ℝ) / 422921968717))
    (lo := ((-368620472997 : ℝ) / 1000000000000)) (hi := ((-73724094599 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((172921968717 : ℝ) / 500000000000) = Real.log ((172921968717 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((172921968717 : ℝ) / 500000000000) = ((172921968717 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_506 : RB (Real.log ((3209510934919 : ℝ) / 1000000000000)) ((116611856881 : ℝ) / 100000000000) ((291529642203 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3209510934919 : ℝ) / 4000000000000)) (t := ((-790489065081 : ℝ) / 7209510934919))
    (lo := ((-220175792309 : ℝ) / 1000000000000)) (hi := ((-55043948077 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3209510934919 : ℝ) / 1000000000000) = Real.log ((3209510934919 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3209510934919 : ℝ) / 1000000000000) = ((3209510934919 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_507 : RB (Real.log ((3210388746971 : ℝ) / 1000000000000)) ((1166392034783 : ℝ) / 1000000000000) ((233278406957 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3210388746971 : ℝ) / 4000000000000)) (t := ((-789611253029 : ℝ) / 7210388746971))
    (lo := ((-3435973849 : ℝ) / 15625000000)) (hi := ((-43980465267 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3210388746971 : ℝ) / 1000000000000) = Real.log ((3210388746971 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3210388746971 : ℝ) / 1000000000000) = ((3210388746971 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_508 : RB (Real.log ((144917735953 : ℝ) / 100000000000)) ((370996057179 : ℝ) / 1000000000000) ((370996057181 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((144917735953 : ℝ) / 200000000000)) (t := ((-55082264047 : ℝ) / 344917735953))
    (lo := ((-16107556169 : ℝ) / 50000000000)) (hi := ((-322151123379 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((144917735953 : ℝ) / 100000000000) = Real.log ((144917735953 : ℝ) / 200000000000) + 1 * Real.log 2 := by
    rw [show ((144917735953 : ℝ) / 100000000000) = ((144917735953 : ℝ) / 200000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_509 : RB (Real.log ((1086819999999 : ℝ) / 1000000000000)) ((83256001049 : ℝ) / 1000000000000) ((1665120021 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((1086819999999 : ℝ) / 1000000000000)) (t := ((86819999999 : ℝ) / 2086819999999))
    (lo := ((83256001049 : ℝ) / 1000000000000)) (hi := ((1665120021 : ℝ) / 20000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_510 : RB (Real.log ((871297 : ℝ) / 800000)) ((1333924663 : ℝ) / 15625000000) ((85371178433 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((871297 : ℝ) / 800000)) (t := ((71297 : ℝ) / 1671297))
    (lo := ((1333924663 : ℝ) / 15625000000)) (hi := ((85371178433 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_511 : RB (Real.log ((86819999999 : ℝ) / 1000000000000)) ((-2443918269123 : ℝ) / 1000000000000) ((-7637244591 : ℝ) / 3125000000) := by
  have hm := log_bounds_of_series (x := ((86819999999 : ℝ) / 125000000000)) (t := ((-38180000001 : ℝ) / 211819999999))
    (lo := ((-364476727443 : ℝ) / 1000000000000)) (hi := ((-364476727441 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((86819999999 : ℝ) / 1000000000000) = Real.log ((86819999999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((86819999999 : ℝ) / 1000000000000) = ((86819999999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_512 : RB (Real.log ((71297 : ℝ) / 800000)) ((-241775747687 : ℝ) / 100000000000) ((-604439369217 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((71297 : ℝ) / 100000)) (t := ((-28703 : ℝ) / 171297))
    (lo := ((-33831593519 : ℝ) / 100000000000)) (hi := ((-338315935189 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((71297 : ℝ) / 800000) = Real.log ((71297 : ℝ) / 100000) - 3 * Real.log 2 := by
    rw [show ((71297 : ℝ) / 800000) = ((71297 : ℝ) / 100000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_513 : RB (Real.log ((252147282581 : ℝ) / 500000000000)) ((-85574340869 : ℝ) / 125000000000) ((-13691894539 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((252147282581 : ℝ) / 250000000000)) (t := ((2147282581 : ℝ) / 502147282581))
    (lo := ((1069056701 : ℝ) / 125000000000)) (hi := ((8552453609 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((252147282581 : ℝ) / 500000000000) = Real.log ((252147282581 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((252147282581 : ℝ) / 500000000000) = ((252147282581 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_514 : RB (Real.log ((126227126867 : ℝ) / 250000000000)) ((-170844509863 : ℝ) / 250000000000) ((-13667560789 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((126227126867 : ℝ) / 125000000000)) (t := ((1227126867 : ℝ) / 251227126867))
    (lo := ((2442285277 : ℝ) / 250000000000)) (hi := ((9769141109 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((126227126867 : ℝ) / 250000000000) = Real.log ((126227126867 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((126227126867 : ℝ) / 250000000000) = ((126227126867 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_515 : RB (Real.log ((85129131991 : ℝ) / 250000000000)) ((-134661451787 : ℝ) / 125000000000) ((-269322903573 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((85129131991 : ℝ) / 125000000000)) (t := ((-39870868009 : ℝ) / 210129131991))
    (lo := ((-48018054217 : ℝ) / 125000000000)) (hi := ((-384144433733 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85129131991 : ℝ) / 250000000000) = Real.log ((85129131991 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((85129131991 : ℝ) / 250000000000) = ((85129131991 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_516 : RB (Real.log ((639988153949 : ℝ) / 200000000000)) ((581566150089 : ℝ) / 500000000000) ((58156615009 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((639988153949 : ℝ) / 800000000000)) (t := ((-160011846051 : ℝ) / 1439988153949))
    (lo := ((-223162060941 : ℝ) / 1000000000000)) (hi := ((-11158103047 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((639988153949 : ℝ) / 200000000000) = Real.log ((639988153949 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((639988153949 : ℝ) / 200000000000) = ((639988153949 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_517 : RB (Real.log ((3200838623623 : ℝ) / 1000000000000)) ((145426605669 : ℝ) / 125000000000) ((581706422677 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3200838623623 : ℝ) / 4000000000000)) (t := ((-799161376377 : ℝ) / 7200838623623))
    (lo := ((-222881515767 : ℝ) / 1000000000000)) (hi := ((-111440757883 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3200838623623 : ℝ) / 1000000000000) = Real.log ((3200838623623 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3200838623623 : ℝ) / 1000000000000) = ((3200838623623 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_518 : RB (Real.log ((725473661937 : ℝ) / 500000000000)) ((93054167479 : ℝ) / 250000000000) ((186108334959 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((725473661937 : ℝ) / 1000000000000)) (t := ((-274526338063 : ℝ) / 1725473661937))
    (lo := ((-320930510643 : ℝ) / 1000000000000)) (hi := ((-160465255321 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((725473661937 : ℝ) / 500000000000) = Real.log ((725473661937 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((725473661937 : ℝ) / 500000000000) = ((725473661937 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_519 : RB (Real.log ((1089121249999 : ℝ) / 1000000000000)) ((85371178431 : ℝ) / 1000000000000) ((1333924663 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((1089121249999 : ℝ) / 1000000000000)) (t := ((89121249999 : ℝ) / 2089121249999))
    (lo := ((85371178431 : ℝ) / 1000000000000)) (hi := ((1333924663 : ℝ) / 15625000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_520 : RB (Real.log ((436569 : ℝ) / 400000)) ((1093523641 : ℝ) / 12500000000) ((87481891281 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((436569 : ℝ) / 400000)) (t := ((36569 : ℝ) / 836569))
    (lo := ((1093523641 : ℝ) / 12500000000)) (hi := ((87481891281 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_521 : RB (Real.log ((89121249999 : ℝ) / 1000000000000)) ((-2417757476881 : ℝ) / 1000000000000) ((-2417757476879 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((89121249999 : ℝ) / 125000000000)) (t := ((-35878750001 : ℝ) / 214121249999))
    (lo := ((-338315935201 : ℝ) / 1000000000000)) (hi := ((-422894919 : ℝ) / 1250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89121249999 : ℝ) / 1000000000000) = Real.log ((89121249999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((89121249999 : ℝ) / 1000000000000) = ((89121249999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_522 : RB (Real.log ((36569 : ℝ) / 400000)) ((-2392263660139 : ℝ) / 1000000000000) ((-2392263660137 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((36569 : ℝ) / 50000)) (t := ((-13431 : ℝ) / 86569))
    (lo := ((-312822118459 : ℝ) / 1000000000000)) (hi := ((-156411059229 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((36569 : ℝ) / 400000) = Real.log ((36569 : ℝ) / 50000) - 3 * Real.log 2 := by
    rw [show ((36569 : ℝ) / 400000) = ((36569 : ℝ) / 50000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_523 : RB (Real.log ((491704814693 : ℝ) / 1000000000000)) ((-709876712681 : ℝ) / 1000000000000) ((-709876712679 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((491704814693 : ℝ) / 500000000000)) (t := ((-8295185307 : ℝ) / 991704814693))
    (lo := ((-16729532121 : ℝ) / 1000000000000)) (hi := ((-418238303 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((491704814693 : ℝ) / 1000000000000) = Real.log ((491704814693 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((491704814693 : ℝ) / 1000000000000) = ((491704814693 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_524 : RB (Real.log ((492329806427 : ℝ) / 1000000000000)) ((-885758061 : ℝ) / 1250000000) ((-354303224399 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((492329806427 : ℝ) / 500000000000)) (t := ((-7670193573 : ℝ) / 992329806427))
    (lo := ((-193240853 : ℝ) / 12500000000)) (hi := ((-15459268239 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((492329806427 : ℝ) / 1000000000000) = Real.log ((492329806427 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((492329806427 : ℝ) / 1000000000000) = ((492329806427 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_525 : RB (Real.log ((20951819827 : ℝ) / 62500000000)) ((-1092941048899 : ℝ) / 1000000000000) ((-273235262223 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((20951819827 : ℝ) / 31250000000)) (t := ((-10298180173 : ℝ) / 52201819827))
    (lo := ((-399793868339 : ℝ) / 1000000000000)) (hi := ((-399793868333 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20951819827 : ℝ) / 62500000000) = Real.log ((20951819827 : ℝ) / 31250000000) - 1 * Real.log 2 := by
    rw [show ((20951819827 : ℝ) / 62500000000) = ((20951819827 : ℝ) / 31250000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_526 : RB (Real.log ((778878461 : ℝ) / 244140625)) ((1160110623197 : ℝ) / 1000000000000) ((1160110623199 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((778878461 : ℝ) / 976562500)) (t := ((-197684039 : ℝ) / 1755440961))
    (lo := ((-113091868961 : ℝ) / 500000000000)) (hi := ((-226183737921 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((778878461 : ℝ) / 244140625) = Real.log ((778878461 : ℝ) / 976562500) + 2 * Real.log 2 := by
    rw [show ((778878461 : ℝ) / 244140625) = ((778878461 : ℝ) / 976562500) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_527 : RB (Real.log ((3191203858321 : ℝ) / 1000000000000)) ((1160398230657 : ℝ) / 1000000000000) ((1160398230659 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3191203858321 : ℝ) / 4000000000000)) (t := ((-808796141679 : ℝ) / 7191203858321))
    (lo := ((-112948065231 : ℝ) / 500000000000)) (hi := ((-225896130461 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3191203858321 : ℝ) / 1000000000000) = Real.log ((3191203858321 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3191203858321 : ℝ) / 1000000000000) = ((3191203858321 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_528 : RB (Real.log ((363186342639 : ℝ) / 250000000000)) ((37345512529 : ℝ) / 100000000000) ((93363781323 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((363186342639 : ℝ) / 500000000000)) (t := ((-136813657361 : ℝ) / 863186342639))
    (lo := ((-319692055269 : ℝ) / 1000000000000)) (hi := ((-79923013817 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((363186342639 : ℝ) / 250000000000) = Real.log ((363186342639 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((363186342639 : ℝ) / 250000000000) = ((363186342639 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_529 : RB (Real.log ((1091422499999 : ℝ) / 1000000000000)) ((87481891279 : ℝ) / 1000000000000) ((1093523641 : ℝ) / 12500000000) := by
  have hm := log_bounds_of_series (x := ((1091422499999 : ℝ) / 1000000000000)) (t := ((91422499999 : ℝ) / 2091422499999))
    (lo := ((87481891279 : ℝ) / 1000000000000)) (hi := ((1093523641 : ℝ) / 12500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_530 : RB (Real.log ((874979 : ℝ) / 800000)) ((89588158401 : ℝ) / 1000000000000) ((44794079201 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((874979 : ℝ) / 800000)) (t := ((74979 : ℝ) / 1674979))
    (lo := ((89588158401 : ℝ) / 1000000000000)) (hi := ((44794079201 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_531 : RB (Real.log ((91422499999 : ℝ) / 1000000000000)) ((-47845273203 : ℝ) / 20000000000) ((-598065915037 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((91422499999 : ℝ) / 125000000000)) (t := ((-33577500001 : ℝ) / 216422499999))
    (lo := ((-31282211847 : ℝ) / 100000000000)) (hi := ((-312822118469 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((91422499999 : ℝ) / 1000000000000) = Real.log ((91422499999 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((91422499999 : ℝ) / 1000000000000) = ((91422499999 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_532 : RB (Real.log ((74979 : ℝ) / 800000)) ((-118370182667 : ℝ) / 50000000000) ((-1183701826669 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((74979 : ℝ) / 100000)) (t := ((-25021 : ℝ) / 174979))
    (lo := ((-14398105583 : ℝ) / 50000000000)) (hi := ((-287962111659 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((74979 : ℝ) / 800000) = Real.log ((74979 : ℝ) / 100000) - 3 * Real.log 2 := by
    rw [show ((74979 : ℝ) / 800000) = ((74979 : ℝ) / 100000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_533 : RB (Real.log ((239731708273 : ℝ) / 500000000000)) ((-735087682573 : ℝ) / 1000000000000) ((-735087682571 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((239731708273 : ℝ) / 250000000000)) (t := ((-10268291727 : ℝ) / 489731708273))
    (lo := ((-41940502013 : ℝ) / 1000000000000)) (hi := ((-10485125503 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((239731708273 : ℝ) / 500000000000) = Real.log ((239731708273 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((239731708273 : ℝ) / 500000000000) = ((239731708273 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_534 : RB (Real.log ((120024838613 : ℝ) / 250000000000)) ((-366881104029 : ℝ) / 500000000000) ((-91720276007 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((120024838613 : ℝ) / 125000000000)) (t := ((-4975161387 : ℝ) / 245024838613))
    (lo := ((-20307513749 : ℝ) / 500000000000)) (hi := ((-40615027497 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((120024838613 : ℝ) / 250000000000) = Real.log ((120024838613 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((120024838613 : ℝ) / 250000000000) = ((120024838613 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_535 : RB (Real.log ((330016648199 : ℝ) / 1000000000000)) ((-1108612176707 : ℝ) / 1000000000000) ((-221722435341 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((330016648199 : ℝ) / 250000000000)) (t := ((80016648199 : ℝ) / 580016648199))
    (lo := ((277682184413 : ℝ) / 1000000000000)) (hi := ((138841092207 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((330016648199 : ℝ) / 1000000000000) = Real.log ((330016648199 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((330016648199 : ℝ) / 1000000000000) = ((330016648199 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_536 : RB (Real.log ((3180552754943 : ℝ) / 1000000000000)) ((578527501997 : ℝ) / 500000000000) ((289263750999 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3180552754943 : ℝ) / 4000000000000)) (t := ((-819447245057 : ℝ) / 7180552754943))
    (lo := ((-1833914857 : ℝ) / 8000000000)) (hi := ((-57309839281 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3180552754943 : ℝ) / 1000000000000) = Real.log ((3180552754943 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3180552754943 : ℝ) / 1000000000000) = ((3180552754943 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_537 : RB (Real.log ((25451920413 : ℝ) / 8000000000)) ((57867482837 : ℝ) / 50000000000) ((578674828371 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((25451920413 : ℝ) / 32000000000)) (t := ((-6548079587 : ℝ) / 57451920413))
    (lo := ((-228944704379 : ℝ) / 1000000000000)) (hi := ((-114472352189 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((25451920413 : ℝ) / 8000000000) = Real.log ((25451920413 : ℝ) / 32000000000) + 2 * Real.log 2 := by
    rw [show ((25451920413 : ℝ) / 8000000000) = ((25451920413 : ℝ) / 32000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_538 : RB (Real.log ((1454570913929 : ℝ) / 1000000000000)) ((374710952613 : ℝ) / 1000000000000) ((74942190523 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1454570913929 : ℝ) / 2000000000000)) (t := ((-545429086071 : ℝ) / 3454570913929))
    (lo := ((-159218113973 : ℝ) / 500000000000)) (hi := ((-63687245589 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1454570913929 : ℝ) / 1000000000000) = Real.log ((1454570913929 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1454570913929 : ℝ) / 1000000000000) = ((1454570913929 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_539 : RB (Real.log ((1093723749999 : ℝ) / 1000000000000)) ((55992599 : ℝ) / 625000000) ((89588158401 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1093723749999 : ℝ) / 1000000000000)) (t := ((93723749999 : ℝ) / 2093723749999))
    (lo := ((55992599 : ℝ) / 625000000)) (hi := ((89588158401 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
