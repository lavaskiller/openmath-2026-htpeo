import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk02
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_4 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((135781808036222326745413975225139 : ℝ) / 2596148429267413814265248164610048) ((68637702339717617876725933486899 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((52301249999 : ℝ) / 1000000000000) ((33841 : ℝ) / 640000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1052301249999 : ℝ) / 1000000000000) ((673841 : ℝ) / 640000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((50979432637 : ℝ) / 1000000000000) ((10305200337 : ℝ) / 200000000000) := rb_log h1 (by norm_num) dlower_log_199.1 dlower_log_200.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((50979432637 : ℝ) / 500000000000) ((10305200337 : ℝ) / 100000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((590095177189 : ℝ) / 1000000000000) ((295594157643 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2950735007643 : ℝ) / 1000000000000) ((-367474386403 : ℝ) / 125000000000) := rb_log hqr (by norm_num) dlower_log_201.1 dlower_log_202.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((367474386403 : ℝ) / 125000000000) ((2950735007643 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((199982436803 : ℝ) / 1000000000000) ((40219695383 : ℝ) / 200000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((159780304617 : ℝ) / 200000000000) ((800017563197 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2735420751 : ℝ) / 1000000000000) ((1397965431 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((408278053349 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((405482122487 : ℝ) / 1000000000000) ((202771316299 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((408278053349 : ℝ) / 1000000000000) ((408278053349 : ℝ) / 1000000000000) ((408278053349 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((591721946651 : ℝ) / 1000000000000))
  have h11 : RB z11 ((34262893643 : ℝ) / 50000000000) ((685360133917 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((591721946651 : ℝ) / 1000000000000) ((591721946651 : ℝ) / 1000000000000) ((591721946651 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-377960054833 : ℝ) / 1000000000000) ((-47226354491 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_203.1 dlower_log_204.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-151187341027 : ℝ) / 500000000000) ((-15091682613 : ℝ) / 50000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((408278053349 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-89580683339 : ℝ) / 100000000000) ((-223951708347 : ℝ) / 250000000000) := rb_log (show RB ((408278053349 : ℝ) / 1000000000000) ((408278053349 : ℝ) / 1000000000000) ((408278053349 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_205.1 dlower_log_205.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((296716075667 : ℝ) / 500000000000) ((59397318113 : ℝ) / 100000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((140239753 : ℝ) / 62500000000) ((3878003941 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2735420751 : ℝ) / 1000000000000) ((1397965431 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((14334160879 : ℝ) / 10000000000)) - (z17)
  have h18 : RB z18 ((715310078519 : ℝ) / 500000000000) ((1430680667149 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((14334160879 : ℝ) / 10000000000) ((14334160879 : ℝ) / 10000000000) ((14334160879 : ℝ) / 10000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((4334160879 : ℝ) / 10000000000))
  have h19 : RB z19 ((3300800770847 : ℝ) / 1000000000000) ((412617547863 : ℝ) / 125000000000) := rb_div_signed h18 (show RB ((4334160879 : ℝ) / 10000000000) ((4334160879 : ℝ) / 10000000000) ((4334160879 : ℝ) / 10000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1194165096867 : ℝ) / 1000000000000) ((238841478479 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_206.1 dlower_log_207.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((954020314701 : ℝ) / 1000000000000) ((59711680501 : ℝ) / 62500000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((14334160879 : ℝ) / 10000000000))
  have h22 : RB z22 ((360060468107 : ℝ) / 1000000000000) ((36006046811 : ℝ) / 100000000000) := rb_log (show RB ((14334160879 : ℝ) / 10000000000) ((14334160879 : ℝ) / 10000000000) ((14334160879 : ℝ) / 10000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_208.1 dlower_log_208.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((593959846591 : ℝ) / 1000000000000) ((595326419909 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((554306261 : ℝ) / 200000000000) ((32695267 : ℝ) / 6250000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1052301249999 : ℝ) / 1000000000000) ((673841 : ℝ) / 640000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1107337920749 : ℝ) / 1000000000000) ((554274527931 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((45104003053 : ℝ) / 25000000000) ((1806133396613 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1025138034551 : ℝ) / 1000000000000))
  have h28 : RB z28 ((369902632321 : ℝ) / 200000000000) ((1851536040341 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1025138034551 : ℝ) / 1000000000000) ((1025138034551 : ℝ) / 1000000000000) ((1025138034551 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2735420751 : ℝ) / 1000000000000) ((1397965431 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((5852323300069510733771 : ℝ) / 10000000000000000000000))
  have h30 : RB z30 ((233703831 : ℝ) / 50000000000) ((955494329 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((5852323300069510733771 : ℝ) / 10000000000000000000000) ((5852323300069510733771 : ℝ) / 10000000000000000000000) ((5852323300069510733771 : ℝ) / 10000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((199044505671 : ℝ) / 200000000000) ((49766296169 : ℝ) / 50000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((920338582459 : ℝ) / 500000000000) ((115180113689 : ℝ) / 62500000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((408278053349 : ℝ) / 1000000000000)) ((140239753 : ℝ) / 62500000000) ((3878003941 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((14334160879 : ℝ) / 10000000000)) ((554306261 : ℝ) / 200000000000) ((32695267 : ℝ) / 6250000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((408278053349 : ℝ) / 1000000000000)) (wl := ((14334160879 : ℝ) / 10000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((920338582459 : ℝ) / 500000000000) ≤ D0q (q) * (((14334160879 : ℝ) / 10000000000) - ((408278053349 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((14334160879 : ℝ) / 10000000000) * ((408278053349 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_5 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((68637702339717617876725933486899 : ℝ) / 1298074214633706907132624082305024) ((277538002645296289522979517444915 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((52876562499 : ℝ) / 1000000000000) ((85523 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1052876562499 : ℝ) / 1000000000000) ((1685523 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((51526001683 : ℝ) / 1000000000000) ((13018068039 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_209.1 dlower_log_210.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((51526001683 : ℝ) / 500000000000) ((13018068039 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((589002636247 : ℝ) / 1000000000000) ((295047588597 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-587959018249 : ℝ) / 200000000000) ((-732243390653 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_211.1 dlower_log_212.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((732243390653 : ℝ) / 250000000000) ((587959018249 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((4007099937 : ℝ) / 20000000000) ((10073412487 : ℝ) / 50000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((39926587513 : ℝ) / 50000000000) ((15992900063 : ℝ) / 20000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2795930861 : ℝ) / 1000000000000) ((1428551471 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((407008172697 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((80830213951 : ℝ) / 200000000000) ((101053060459 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((407008172697 : ℝ) / 1000000000000) ((407008172697 : ℝ) / 1000000000000) ((407008172697 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((592991827303 : ℝ) / 1000000000000))
  have h11 : RB z11 ((85193220873 : ℝ) / 125000000000) ((681648925373 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((592991827303 : ℝ) / 1000000000000) ((592991827303 : ℝ) / 1000000000000) ((592991827303 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-95847968463 : ℝ) / 250000000000) ((-191620262929 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_213.1 dlower_log_214.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-12263095847 : ℝ) / 40000000000) ((-306029727883 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((407008172697 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-179784402681 : ℝ) / 200000000000) ((-898922013403 : ℝ) / 1000000000000) := rb_log (show RB ((407008172697 : ℝ) / 1000000000000) ((407008172697 : ℝ) / 1000000000000) ((407008172697 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_215.1 dlower_log_215.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((148086154307 : ℝ) / 250000000000) ((296446142761 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((1124720017 : ℝ) / 500000000000) ((155585971 : ℝ) / 40000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2795930861 : ℝ) / 1000000000000) ((1428551471 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((716864242711 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((17885892281 : ℝ) / 12500000000) ((1430932554561 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((716864242711 : ℝ) / 500000000000) ((716864242711 : ℝ) / 500000000000) ((716864242711 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((216864242711 : ℝ) / 500000000000))
  have h19 : RB z19 ((3299002557067 : ℝ) / 1000000000000) ((1649571797399 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((216864242711 : ℝ) / 500000000000) ((216864242711 : ℝ) / 500000000000) ((216864242711 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((298405041837 : ℝ) / 250000000000) ((238732583613 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_216.1 dlower_log_217.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((476571800689 : ℝ) / 500000000000) ((954506587877 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((716864242711 : ℝ) / 500000000000))
  have h22 : RB z22 ((360278383539 : ℝ) / 1000000000000) ((360278383541 : ℝ) / 1000000000000) := rb_log (show RB ((716864242711 : ℝ) / 500000000000) ((716864242711 : ℝ) / 500000000000) ((716864242711 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_218.1 dlower_log_218.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((592865217837 : ℝ) / 1000000000000) ((297114102169 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2770040643 : ℝ) / 1000000000000) ((5225568091 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1052876562499 : ℝ) / 1000000000000) ((1685523 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1108549055859 : ℝ) / 1000000000000) ((554880426471 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1802190079689 : ℝ) / 1000000000000) ((14433280977 : ℝ) / 8000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((41068812509 : ℝ) / 40000000000))
  have h28 : RB z28 ((57823286319 : ℝ) / 31250000000) ((370473568959 : ℝ) / 200000000000) := rb_widen (rb_mul h27 (show RB ((41068812509 : ℝ) / 40000000000) ((41068812509 : ℝ) / 40000000000) ((41068812509 : ℝ) / 40000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2795930861 : ℝ) / 1000000000000) ((1428551471 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((291769605497622811461567 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((74864583 : ℝ) / 15625000000) ((244808137 : ℝ) / 50000000000) := rb_div_signed h29 (show RB ((291769605497622811461567 : ℝ) / 500000000000000000000000) ((291769605497622811461567 : ℝ) / 500000000000000000000000) ((291769605497622811461567 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((49755191863 : ℝ) / 50000000000) ((15550135417 : ℝ) / 15625000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((57540174099 : ℝ) / 31250000000) ((368698506607 : ℝ) / 200000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((407008172697 : ℝ) / 1000000000000)) ((1124720017 : ℝ) / 500000000000) ((155585971 : ℝ) / 40000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((716864242711 : ℝ) / 500000000000)) ((2770040643 : ℝ) / 1000000000000) ((5225568091 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((407008172697 : ℝ) / 1000000000000)) (wl := ((716864242711 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((57540174099 : ℝ) / 31250000000) ≤ D0q (q) * (((716864242711 : ℝ) / 500000000000) - ((407008172697 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((716864242711 : ℝ) / 500000000000) * ((407008172697 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_6 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((277538002645296289522979517444915 : ℝ) / 5192296858534827628530496329220096) ((280525195931722107539055300942233 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((53451874999 : ℝ) / 1000000000000) ((172887 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1053451874999 : ℝ) / 1000000000000) ((3372887 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((26036136077 : ℝ) / 500000000000) ((52618244379 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_219.1 dlower_log_220.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((26036136077 : ℝ) / 250000000000) ((52618244379 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((587910691801 : ℝ) / 1000000000000) ((147250659063 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-366121695329 : ℝ) / 125000000000) ((-1459133943447 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_221.1 dlower_log_222.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1459133943447 : ℝ) / 500000000000) ((366121695329 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((50180607577 : ℝ) / 250000000000) ((6307279899 : ℝ) / 31250000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((24942720101 : ℝ) / 31250000000) ((199819392423 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((142855147 : ℝ) / 50000000000) ((291893699 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((405732704451 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((402813767461 : ℝ) / 1000000000000) ((402875601511 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((405732704451 : ℝ) / 1000000000000) ((405732704451 : ℝ) / 1000000000000) ((405732704451 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((594267295549 : ℝ) / 1000000000000))
  have h11 : RB z11 ((677832636051 : ℝ) / 1000000000000) ((677936686957 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((594267295549 : ℝ) / 1000000000000) ((594267295549 : ℝ) / 1000000000000) ((594267295549 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-194427435499 : ℝ) / 500000000000) ((-38870137747 : ℝ) / 100000000000) := rb_log h11 (by norm_num) dlower_log_223.1 dlower_log_224.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-62160595251 : ℝ) / 200000000000) ((-62049725831 : ℝ) / 200000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((405732704451 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-902060699619 : ℝ) / 1000000000000) ((-902060699617 : ℝ) / 1000000000000) := rb_log (show RB ((405732704451 : ℝ) / 1000000000000) ((405732704451 : ℝ) / 1000000000000) ((405732704451 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_225.1 dlower_log_225.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((295628861681 : ℝ) / 500000000000) ((9247063601 : ℝ) / 15625000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((225508711 : ℝ) / 100000000000) ((3901378663 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((142855147 : ℝ) / 50000000000) ((291893699 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1434043860847 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1431124923857 : ℝ) / 1000000000000) ((1431186757907 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1434043860847 : ℝ) / 1000000000000) ((1434043860847 : ℝ) / 1000000000000) ((1434043860847 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((434043860847 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3297189645913 : ℝ) / 1000000000000) ((1648666053143 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((434043860847 : ℝ) / 1000000000000) ((434043860847 : ℝ) / 1000000000000) ((434043860847 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((74566905199 : ℝ) / 62500000000) ((596556844429 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_226.1 dlower_log_227.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((95226953993 : ℝ) / 100000000000) ((953629009597 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1434043860847 : ℝ) / 1000000000000))
  have h22 : RB z22 ((360498328073 : ℝ) / 1000000000000) ((14419933123 : ℝ) / 40000000000) := rb_log (show RB ((1434043860847 : ℝ) / 1000000000000) ((1434043860847 : ℝ) / 1000000000000) ((1434043860847 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_228.1 dlower_log_228.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((118354242371 : ℝ) / 200000000000) ((148282670381 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2768575603 : ℝ) / 1000000000000) ((5219989723 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1053451874999 : ℝ) / 1000000000000) ((3372887 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((554880426469 : ℝ) / 500000000000) ((111097331199 : ℝ) / 100000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((360044652453 : ℝ) / 200000000000) ((1802190079697 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((257077789099 : ℝ) / 250000000000))
  have h28 : RB z28 ((185118966459 : ℝ) / 100000000000) ((1853212164899 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((257077789099 : ℝ) / 250000000000) ((257077789099 : ℝ) / 250000000000) ((257077789099 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((142855147 : ℝ) / 50000000000) ((291893699 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((581838493962806821529997 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((2455237123 : ℝ) / 500000000000) ((501674781 : ℝ) / 100000000000) := rb_div_signed h29 (show RB ((581838493962806821529997 : ℝ) / 1000000000000000000000000) ((581838493962806821529997 : ℝ) / 1000000000000000000000000) ((581838493962806821529997 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((99498325219 : ℝ) / 100000000000) ((497544762877 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((920951356447 : ℝ) / 500000000000) ((1844112014291 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((405732704451 : ℝ) / 1000000000000)) ((225508711 : ℝ) / 100000000000) ((3901378663 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1434043860847 : ℝ) / 1000000000000)) ((2768575603 : ℝ) / 1000000000000) ((5219989723 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((405732704451 : ℝ) / 1000000000000)) (wl := ((1434043860847 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((920951356447 : ℝ) / 500000000000) ≤ D0q (q) * (((1434043860847 : ℝ) / 1000000000000) - ((405732704451 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1434043860847 : ℝ) / 1000000000000) * ((405732704451 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_7 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((280525195931722107539055300942233 : ℝ) / 5192296858534827628530496329220096) ((31476198227647681 : ℝ) / 576460752303423488)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((54027187499 : ℝ) / 1000000000000) ((21841 : ℝ) / 400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1054027187499 : ℝ) / 1000000000000) ((421841 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((52618244377 : ℝ) / 1000000000000) ((53163918679 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_229.1 dlower_log_230.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((52618244377 : ℝ) / 500000000000) ((53163918679 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((586819343201 : ℝ) / 1000000000000) ((293955345903 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1459133943457 : ℝ) / 500000000000) ((-726918902433 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_231.1 dlower_log_232.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((726918902433 : ℝ) / 250000000000) ((1459133943457 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((201084809873 : ℝ) / 1000000000000) ((202192668893 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((797807331107 : ℝ) / 1000000000000) ((798915190127 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2918936989 : ℝ) / 1000000000000) ((2981433007 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((80890324729 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((200735095319 : ℝ) / 500000000000) ((6273948229 : ℝ) / 15625000000) := rb_widen (rb_sub (show RB ((80890324729 : ℝ) / 200000000000) ((80890324729 : ℝ) / 200000000000) ((80890324729 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((119109675271 : ℝ) / 200000000000))
  have h11 : RB z11 ((26964740839 : ℝ) / 40000000000) ((134844691917 : ℝ) / 200000000000) := rb_div_signed h10 (show RB ((119109675271 : ℝ) / 200000000000) ((119109675271 : ℝ) / 200000000000) ((119109675271 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-394349336387 : ℝ) / 1000000000000) ((-78838736121 : ℝ) / 200000000000) := rb_log h11 (by norm_num) dlower_log_233.1 dlower_log_234.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-315051675057 : ℝ) / 1000000000000) ((-157245304131 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((80890324729 : ℝ) / 200000000000))
  have h14 : RB z14 ((-36208925803 : ℝ) / 40000000000) ((-905223145073 : ℝ) / 1000000000000) := rb_log (show RB ((80890324729 : ℝ) / 200000000000) ((80890324729 : ℝ) / 200000000000) ((80890324729 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_235.1 dlower_log_235.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((9221429219 : ℝ) / 15625000000) ((590732536813 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((226077821 : ℝ) / 100000000000) ((978298403 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2918936989 : ℝ) / 1000000000000) ((2981433007 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((286872435333 : ℝ) / 200000000000)) - (z17)
  have h18 : RB z18 ((715690371829 : ℝ) / 500000000000) ((357860809919 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB ((286872435333 : ℝ) / 200000000000) ((286872435333 : ℝ) / 200000000000) ((286872435333 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((86872435333 : ℝ) / 200000000000))
  have h19 : RB z19 ((411920288113 : ℝ) / 125000000000) ((3295506184877 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((86872435333 : ℝ) / 200000000000) ((86872435333 : ℝ) / 200000000000) ((86872435333 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1192516117873 : ℝ) / 1000000000000) ((596279889137 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_236.1 dlower_log_237.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((475699050651 : ℝ) / 500000000000) ((476377060999 : ℝ) / 500000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((286872435333 : ℝ) / 200000000000))
  have h22 : RB z22 ((36072027421 : ℝ) / 100000000000) ((90180068553 : ℝ) / 250000000000) := rb_log (show RB ((286872435333 : ℝ) / 200000000000) ((286872435333 : ℝ) / 200000000000) ((286872435333 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_238.1 dlower_log_238.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((59067782709 : ℝ) / 100000000000) ((148008461947 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((691783821 : ℝ) / 250000000000) ((5214504587 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1054027187499 : ℝ) / 1000000000000) ((421841 : ℝ) / 400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1110973311987 : ℝ) / 1000000000000) ((1112186433007 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1798259662809 : ℝ) / 1000000000000) ((180022326227 : ℝ) / 100000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((51495527651 : ℝ) / 50000000000))
  have h28 : RB z28 ((1852046603797 : ℝ) / 1000000000000) ((463517233901 : ℝ) / 250000000000) := rb_widen (rb_mul h27 (show RB ((51495527651 : ℝ) / 50000000000) ((51495527651 : ℝ) / 50000000000) ((51495527651 : ℝ) / 50000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2918936989 : ℝ) / 1000000000000) ((2981433007 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((23205204449885423249757 : ℝ) / 40000000000000000000000))
  have h30 : RB z30 ((5031521261 : ℝ) / 1000000000000) ((102784977 : ℝ) / 20000000000) := rb_div_signed h29 (show RB ((23205204449885423249757 : ℝ) / 40000000000000000000000) ((23205204449885423249757 : ℝ) / 40000000000000000000000) ((23205204449885423249757 : ℝ) / 40000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((19897215023 : ℝ) / 20000000000) ((994968478739 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((921264237709 : ℝ) / 500000000000) ((115296259271 : ℝ) / 62500000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((80890324729 : ℝ) / 200000000000)) ((226077821 : ℝ) / 100000000000) ((978298403 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((286872435333 : ℝ) / 200000000000)) ((691783821 : ℝ) / 250000000000) ((5214504587 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((80890324729 : ℝ) / 200000000000)) (wl := ((286872435333 : ℝ) / 200000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((921264237709 : ℝ) / 500000000000) ≤ D0q (q) * (((286872435333 : ℝ) / 200000000000) - ((80890324729 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((286872435333 : ℝ) / 200000000000) * ((80890324729 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
