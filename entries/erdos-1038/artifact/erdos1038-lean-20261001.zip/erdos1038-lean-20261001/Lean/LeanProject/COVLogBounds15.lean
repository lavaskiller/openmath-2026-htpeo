import LeanProject.COVLogTwo
import LeanProject.COVLogBounds11
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1200 : RB (Real.log ((103653821 : ℝ) / 25000000)) ((142218087 : ℝ) / 100000000) ((14221809 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((103653821 : ℝ) / 100000000)) (t := ((3653821 : ℝ) / 203653821))
    (lo := ((3588651 : ℝ) / 100000000)) (hi := ((897163 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((103653821 : ℝ) / 25000000) = Real.log ((103653821 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((103653821 : ℝ) / 25000000) = ((103653821 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1201 : RB (Real.log ((32942889 : ℝ) / 25000000)) ((689749 : ℝ) / 2500000) ((27589961 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32942889 : ℝ) / 25000000)) (t := ((7942889 : ℝ) / 57942889))
    (lo := ((689749 : ℝ) / 2500000)) (hi := ((27589961 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1202 : RB (Real.log ((10314509 : ℝ) / 100000000)) ((-227161867 : ℝ) / 100000000) ((-227161863 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10314509 : ℝ) / 12500000)) (t := ((-2185491 : ℝ) / 22814509))
    (lo := ((-1921771 : ℝ) / 10000000)) (hi := ((-19217709 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10314509 : ℝ) / 100000000) = Real.log ((10314509 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((10314509 : ℝ) / 100000000) = ((10314509 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1203 : RB (Real.log ((12081607 : ℝ) / 100000000)) ((-211348601 : ℝ) / 100000000) ((-211348597 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12081607 : ℝ) / 12500000)) (t := ((-418393 : ℝ) / 24581607))
    (lo := ((-851111 : ℝ) / 25000000)) (hi := ((-3404443 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12081607 : ℝ) / 100000000) = Real.log ((12081607 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12081607 : ℝ) / 100000000) = ((12081607 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1204 : RB (Real.log ((3925431 : ℝ) / 100000000)) ((-5058897 : ℝ) / 1562500) ((-161884701 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3925431 : ℝ) / 3125000)) (t := ((800431 : ℝ) / 7050431))
    (lo := ((22804187 : ℝ) / 100000000)) (hi := ((5701047 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3925431 : ℝ) / 100000000) = Real.log ((3925431 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3925431 : ℝ) / 100000000) = ((3925431 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1205 : RB (Real.log ((3995319 : ℝ) / 100000000)) ((-322004681 : ℝ) / 100000000) ((-12880187 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((3995319 : ℝ) / 3125000)) (t := ((870319 : ℝ) / 7120319))
    (lo := ((12284457 : ℝ) / 50000000)) (hi := ((4913783 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3995319 : ℝ) / 100000000) = Real.log ((3995319 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3995319 : ℝ) / 100000000) = ((3995319 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1206 : RB (Real.log ((2059809 : ℝ) / 3125000)) ((-5210263 : ℝ) / 12500000) ((-20841051 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2059809 : ℝ) / 1562500)) (t := ((497309 : ℝ) / 3622309))
    (lo := ((5526523 : ℝ) / 20000000)) (hi := ((3454077 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2059809 : ℝ) / 3125000) = Real.log ((2059809 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((2059809 : ℝ) / 3125000) = ((2059809 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1207 : RB (Real.log ((65916331 : ℝ) / 100000000)) ((-41678397 : ℝ) / 100000000) ((-8335679 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((65916331 : ℝ) / 50000000)) (t := ((15916331 : ℝ) / 115916331))
    (lo := ((13818161 : ℝ) / 50000000)) (hi := ((27636323 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65916331 : ℝ) / 100000000) = Real.log ((65916331 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65916331 : ℝ) / 100000000) = ((65916331 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1208 : RB (Real.log ((19877369 : ℝ) / 50000000)) ((-92244117 : ℝ) / 100000000) ((-18448823 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((19877369 : ℝ) / 25000000)) (t := ((-5122631 : ℝ) / 44877369))
    (lo := ((-11464699 : ℝ) / 50000000)) (hi := ((-22929397 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19877369 : ℝ) / 50000000) = Real.log ((19877369 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((19877369 : ℝ) / 50000000) = ((19877369 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1209 : RB (Real.log ((191800119 : ℝ) / 100000000)) ((65128359 : ℝ) / 100000000) ((65128361 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((191800119 : ℝ) / 200000000)) (t := ((-8199881 : ℝ) / 391800119))
    (lo := ((-4186359 : ℝ) / 100000000)) (hi := ((-2093179 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((191800119 : ℝ) / 100000000) = Real.log ((191800119 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((191800119 : ℝ) / 100000000) = ((191800119 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1210 : RB (Real.log ((191931793 : ℝ) / 100000000)) ((65196987 : ℝ) / 100000000) ((65196989 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((191931793 : ℝ) / 200000000)) (t := ((-8068207 : ℝ) / 391931793))
    (lo := ((-4117731 : ℝ) / 100000000)) (hi := ((-411773 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((191931793 : ℝ) / 100000000) = Real.log ((191931793 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((191931793 : ℝ) / 100000000) = ((191931793 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1211 : RB (Real.log ((13528233 : ℝ) / 20000000)) ((-2443459 : ℝ) / 6250000) ((-39095343 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13528233 : ℝ) / 20000000)) (t := ((-6471767 : ℝ) / 33528233))
    (lo := ((-2443459 : ℝ) / 6250000)) (hi := ((-39095343 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1212 : RB (Real.log ((67643633 : ℝ) / 100000000)) ((-2443231 : ℝ) / 6250000) ((-7818339 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((67643633 : ℝ) / 100000000)) (t := ((-32356367 : ℝ) / 167643633))
    (lo := ((-2443231 : ℝ) / 6250000)) (hi := ((-7818339 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1213 : RB (Real.log ((4037547 : ℝ) / 10000000)) ((-45347389 : ℝ) / 50000000) ((-11336847 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((4037547 : ℝ) / 5000000)) (t := ((-962453 : ℝ) / 9037547))
    (lo := ((-21380059 : ℝ) / 100000000)) (hi := ((-10690029 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4037547 : ℝ) / 10000000) = Real.log ((4037547 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((4037547 : ℝ) / 10000000) = ((4037547 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1214 : RB (Real.log ((208364991 : ℝ) / 50000000)) ((142726829 : ℝ) / 100000000) ((8920427 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((208364991 : ℝ) / 200000000)) (t := ((8364991 : ℝ) / 408364991))
    (lo := ((4097393 : ℝ) / 100000000)) (hi := ((2048697 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((208364991 : ℝ) / 50000000) = Real.log ((208364991 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((208364991 : ℝ) / 50000000) = ((208364991 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1215 : RB (Real.log ((83346929 : ℝ) / 20000000)) ((35681987 : ℝ) / 25000000) ((142727951 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((83346929 : ℝ) / 80000000)) (t := ((3346929 : ℝ) / 163346929))
    (lo := ((256157 : ℝ) / 6250000)) (hi := ((4098513 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((83346929 : ℝ) / 20000000) = Real.log ((83346929 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((83346929 : ℝ) / 20000000) = ((83346929 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1216 : RB (Real.log ((32889627 : ℝ) / 25000000)) ((27428149 : ℝ) / 100000000) ((548563 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((32889627 : ℝ) / 25000000)) (t := ((7889627 : ℝ) / 57889627))
    (lo := ((27428149 : ℝ) / 100000000)) (hi := ((548563 : ℝ) / 2000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1217 : RB (Real.log ((413561943 : ℝ) / 100000000)) ((141963711 : ℝ) / 100000000) ((70981857 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((413561943 : ℝ) / 400000000)) (t := ((13561943 : ℝ) / 813561943))
    (lo := ((133371 : ℝ) / 4000000)) (hi := ((833569 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((413561943 : ℝ) / 100000000) = Real.log ((413561943 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((413561943 : ℝ) / 100000000) = ((413561943 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1218 : RB (Real.log ((413566559 : ℝ) / 100000000)) ((141964827 : ℝ) / 100000000) ((14196483 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((413566559 : ℝ) / 400000000)) (t := ((13566559 : ℝ) / 813566559))
    (lo := ((3335391 : ℝ) / 100000000)) (hi := ((104231 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((413566559 : ℝ) / 100000000) = Real.log ((413566559 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((413566559 : ℝ) / 100000000) = ((413566559 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1219 : RB (Real.log ((32969339 : ℝ) / 25000000)) ((13835109 : ℝ) / 50000000) ((27670219 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32969339 : ℝ) / 25000000)) (t := ((7969339 : ℝ) / 57969339))
    (lo := ((13835109 : ℝ) / 50000000)) (hi := ((27670219 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1220 : RB (Real.log ((5224173 : ℝ) / 50000000)) ((-225872653 : ℝ) / 100000000) ((-225872649 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5224173 : ℝ) / 6250000)) (t := ((-1025827 : ℝ) / 11474173))
    (lo := ((-1120531 : ℝ) / 6250000)) (hi := ((-3585699 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5224173 : ℝ) / 50000000) = Real.log ((5224173 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5224173 : ℝ) / 50000000) = ((5224173 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1221 : RB (Real.log ((12200219 : ℝ) / 100000000)) ((-13148227 : ℝ) / 6250000) ((-52592907 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((12200219 : ℝ) / 12500000)) (t := ((-299781 : ℝ) / 24700219))
    (lo := ((-97099 : ℝ) / 4000000)) (hi := ((-1213737 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12200219 : ℝ) / 100000000) = Real.log ((12200219 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12200219 : ℝ) / 100000000) = ((12200219 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1222 : RB (Real.log ((3989837 : ℝ) / 100000000)) ((-161070993 : ℝ) / 50000000) ((-16107099 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((3989837 : ℝ) / 3125000)) (t := ((864837 : ℝ) / 7114837))
    (lo := ((24431609 : ℝ) / 100000000)) (hi := ((2443161 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3989837 : ℝ) / 100000000) = Real.log ((3989837 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3989837 : ℝ) / 100000000) = ((3989837 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1223 : RB (Real.log ((4059819 : ℝ) / 100000000)) ((-64080637 : ℝ) / 20000000) ((-320403179 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4059819 : ℝ) / 3125000)) (t := ((934819 : ℝ) / 7184819))
    (lo := ((2617041 : ℝ) / 10000000)) (hi := ((26170411 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4059819 : ℝ) / 100000000) = Real.log ((4059819 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((4059819 : ℝ) / 100000000) = ((4059819 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1224 : RB (Real.log ((65724813 : ℝ) / 100000000)) ((-5246171 : ℝ) / 12500000) ((-20984683 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((65724813 : ℝ) / 50000000)) (t := ((15724813 : ℝ) / 115724813))
    (lo := ((27345351 : ℝ) / 100000000)) (hi := ((3418169 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65724813 : ℝ) / 100000000) = Real.log ((65724813 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65724813 : ℝ) / 100000000) = ((65724813 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1225 : RB (Real.log ((1026989 : ℝ) / 1562500)) ((-4196559 : ℝ) / 10000000) ((-10491397 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1026989 : ℝ) / 781250)) (t := ((245739 : ℝ) / 1808239))
    (lo := ((27349129 : ℝ) / 100000000)) (hi := ((2734913 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1026989 : ℝ) / 1562500) = Real.log ((1026989 : ℝ) / 781250) - 1 * Real.log 2 := by
    rw [show ((1026989 : ℝ) / 1562500) = ((1026989 : ℝ) / 781250) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1226 : RB (Real.log ((39686907 : ℝ) / 100000000)) ((-92414887 : ℝ) / 100000000) ((-18482977 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((39686907 : ℝ) / 50000000)) (t := ((-10313093 : ℝ) / 89686907))
    (lo := ((-2887521 : ℝ) / 12500000)) (hi := ((-23100167 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39686907 : ℝ) / 100000000) = Real.log ((39686907 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39686907 : ℝ) / 100000000) = ((39686907 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1227 : RB (Real.log ((38333681 : ℝ) / 20000000)) ((65059663 : ℝ) / 100000000) ((13011933 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((38333681 : ℝ) / 40000000)) (t := ((-1666319 : ℝ) / 78333681))
    (lo := ((-851011 : ℝ) / 20000000)) (hi := ((-2127527 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38333681 : ℝ) / 20000000) = Real.log ((38333681 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((38333681 : ℝ) / 20000000) = ((38333681 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1228 : RB (Real.log ((1534401 : ℝ) / 800000)) ((32564181 : ℝ) / 50000000) ((16282091 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1534401 : ℝ) / 1600000)) (t := ((-65599 : ℝ) / 3134401))
    (lo := ((-1046589 : ℝ) / 25000000)) (hi := ((-837271 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1534401 : ℝ) / 800000) = Real.log ((1534401 : ℝ) / 1600000) + 1 * Real.log 2 := by
    rw [show ((1534401 : ℝ) / 800000) = ((1534401 : ℝ) / 1600000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1229 : RB (Real.log ((16857443 : ℝ) / 25000000)) ((-7881671 : ℝ) / 20000000) ((-19704177 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((16857443 : ℝ) / 25000000)) (t := ((-8142557 : ℝ) / 41857443))
    (lo := ((-7881671 : ℝ) / 20000000)) (hi := ((-19704177 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1230 : RB (Real.log ((67432281 : ℝ) / 100000000)) ((-19702317 : ℝ) / 50000000) ((-39404633 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((67432281 : ℝ) / 100000000)) (t := ((-32567719 : ℝ) / 167432281))
    (lo := ((-19702317 : ℝ) / 50000000)) (hi := ((-39404633 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1231 : RB (Real.log ((40301083 : ℝ) / 100000000)) ((-45439593 : ℝ) / 50000000) ((-5679949 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((40301083 : ℝ) / 50000000)) (t := ((-9698917 : ℝ) / 90301083))
    (lo := ((-21564467 : ℝ) / 100000000)) (hi := ((-10782233 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40301083 : ℝ) / 100000000) = Real.log ((40301083 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40301083 : ℝ) / 100000000) = ((40301083 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1232 : RB (Real.log ((415657417 : ℝ) / 100000000)) ((142469121 : ℝ) / 100000000) ((35617281 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((415657417 : ℝ) / 400000000)) (t := ((15657417 : ℝ) / 815657417))
    (lo := ((767937 : ℝ) / 20000000)) (hi := ((1919843 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((415657417 : ℝ) / 100000000) = Real.log ((415657417 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((415657417 : ℝ) / 100000000) = ((415657417 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1233 : RB (Real.log ((207831073 : ℝ) / 50000000)) ((142470259 : ℝ) / 100000000) ((71235131 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((207831073 : ℝ) / 200000000)) (t := ((7831073 : ℝ) / 407831073))
    (lo := ((3840823 : ℝ) / 100000000)) (hi := ((480103 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((207831073 : ℝ) / 50000000) = Real.log ((207831073 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((207831073 : ℝ) / 50000000) = ((207831073 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1234 : RB (Real.log ((65832633 : ℝ) / 50000000)) ((5501853 : ℝ) / 20000000) ((13754633 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((65832633 : ℝ) / 50000000)) (t := ((15832633 : ℝ) / 115832633))
    (lo := ((5501853 : ℝ) / 20000000)) (hi := ((13754633 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1235 : RB (Real.log ((206262299 : ℝ) / 50000000)) ((35428141 : ℝ) / 25000000) ((141712567 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((206262299 : ℝ) / 200000000)) (t := ((6262299 : ℝ) / 406262299))
    (lo := ((385391 : ℝ) / 12500000)) (hi := ((3083129 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((206262299 : ℝ) / 50000000) = Real.log ((206262299 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((206262299 : ℝ) / 50000000) = ((206262299 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1236 : RB (Real.log ((644577 : ℝ) / 156250)) ((141713699 : ℝ) / 100000000) ((70856851 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((644577 : ℝ) / 625000)) (t := ((19577 : ℝ) / 1269577))
    (lo := ((3084263 : ℝ) / 100000000)) (hi := ((385533 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((644577 : ℝ) / 156250) = Real.log ((644577 : ℝ) / 625000) + 2 * Real.log 2 := by
    rw [show ((644577 : ℝ) / 156250) = ((644577 : ℝ) / 625000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1237 : RB (Real.log ((65991343 : ℝ) / 50000000)) ((3468757 : ℝ) / 12500000) ((27750057 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65991343 : ℝ) / 50000000)) (t := ((15991343 : ℝ) / 115991343))
    (lo := ((3468757 : ℝ) / 12500000)) (hi := ((27750057 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1238 : RB (Real.log ((5290823 : ℝ) / 50000000)) ((-224604923 : ℝ) / 100000000) ((-224604919 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5290823 : ℝ) / 6250000)) (t := ((-959177 : ℝ) / 11540823))
    (lo := ((-8330383 : ℝ) / 50000000)) (hi := ((-3332153 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5290823 : ℝ) / 50000000) = Real.log ((5290823 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5290823 : ℝ) / 50000000) = ((5290823 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1239 : RB (Real.log ((615953 : ℝ) / 5000000)) ((-13087641 : ℝ) / 6250000) ((-52350563 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((615953 : ℝ) / 625000)) (t := ((-9047 : ℝ) / 1240953))
    (lo := ((-1458099 : ℝ) / 100000000)) (hi := ((-729049 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((615953 : ℝ) / 5000000) = Real.log ((615953 : ℝ) / 625000) - 3 * Real.log 2 := by
    rw [show ((615953 : ℝ) / 5000000) = ((615953 : ℝ) / 625000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1240 : RB (Real.log ((2027121 : ℝ) / 50000000)) ((-6410813 : ℝ) / 2000000) ((-80135161 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2027121 : ℝ) / 1562500)) (t := ((464621 : ℝ) / 3589621))
    (lo := ((5206589 : ℝ) / 20000000)) (hi := ((13016473 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2027121 : ℝ) / 50000000) = Real.log ((2027121 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((2027121 : ℝ) / 50000000) = ((2027121 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1241 : RB (Real.log ((4124319 : ℝ) / 100000000)) ((-79706733 : ℝ) / 25000000) ((-159413463 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4124319 : ℝ) / 3125000)) (t := ((999319 : ℝ) / 7249319))
    (lo := ((27746663 : ℝ) / 100000000)) (hi := ((3468333 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4124319 : ℝ) / 100000000) = Real.log ((4124319 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((4124319 : ℝ) / 100000000) = ((4124319 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1242 : RB (Real.log ((32768843 : ℝ) / 50000000)) ((-21127243 : ℝ) / 50000000) ((-10563621 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((32768843 : ℝ) / 25000000)) (t := ((7768843 : ℝ) / 57768843))
    (lo := ((27060233 : ℝ) / 100000000)) (hi := ((13530117 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32768843 : ℝ) / 50000000) = Real.log ((32768843 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32768843 : ℝ) / 50000000) = ((32768843 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1243 : RB (Real.log ((65540211 : ℝ) / 100000000)) ((-21125317 : ℝ) / 50000000) ((-5281329 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((65540211 : ℝ) / 50000000)) (t := ((15540211 : ℝ) / 115540211))
    (lo := ((5412817 : ℝ) / 20000000)) (hi := ((13532043 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65540211 : ℝ) / 100000000) = Real.log ((65540211 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65540211 : ℝ) / 100000000) = ((65540211 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1244 : RB (Real.log ((619057 : ℝ) / 1562500)) ((-11573063 : ℝ) / 12500000) ((-46292251 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((619057 : ℝ) / 781250)) (t := ((-162193 : ℝ) / 1400307))
    (lo := ((-4653957 : ℝ) / 20000000)) (hi := ((-2908723 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((619057 : ℝ) / 1562500) = Real.log ((619057 : ℝ) / 781250) - 1 * Real.log 2 := by
    rw [show ((619057 : ℝ) / 1562500) = ((619057 : ℝ) / 781250) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1245 : RB (Real.log ((95768321 : ℝ) / 50000000)) ((32495447 : ℝ) / 50000000) ((4061931 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((95768321 : ℝ) / 100000000)) (t := ((-4231679 : ℝ) / 195768321))
    (lo := ((-270239 : ℝ) / 6250000)) (hi := ((-4323823 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95768321 : ℝ) / 50000000) = Real.log ((95768321 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95768321 : ℝ) / 50000000) = ((95768321 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1246 : RB (Real.log ((191668409 : ℝ) / 100000000)) ((13011933 : ℝ) / 20000000) ((65059667 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((191668409 : ℝ) / 200000000)) (t := ((-8331591 : ℝ) / 391668409))
    (lo := ((-4255053 : ℝ) / 100000000)) (hi := ((-1063763 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((191668409 : ℝ) / 100000000) = Real.log ((191668409 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((191668409 : ℝ) / 100000000) = ((191668409 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1247 : RB (Real.log ((67221381 : ℝ) / 100000000)) ((-19858941 : ℝ) / 50000000) ((-39717881 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((67221381 : ℝ) / 100000000)) (t := ((-32778619 : ℝ) / 167221381))
    (lo := ((-19858941 : ℝ) / 50000000)) (hi := ((-39717881 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1248 : RB (Real.log ((16805983 : ℝ) / 25000000)) ((-4964261 : ℝ) / 12500000) ((-39714087 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16805983 : ℝ) / 25000000)) (t := ((-8194017 : ℝ) / 41805983))
    (lo := ((-4964261 : ℝ) / 12500000)) (hi := ((-39714087 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1249 : RB (Real.log ((40227597 : ℝ) / 100000000)) ((-18212339 : ℝ) / 20000000) ((-91061693 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40227597 : ℝ) / 50000000)) (t := ((-9772403 : ℝ) / 90227597))
    (lo := ((-679593 : ℝ) / 3125000)) (hi := ((-869879 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40227597 : ℝ) / 100000000) = Real.log ((40227597 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40227597 : ℝ) / 100000000) = ((40227597 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1250 : RB (Real.log ((207298369 : ℝ) / 50000000)) ((71106807 : ℝ) / 50000000) ((142213617 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((207298369 : ℝ) / 200000000)) (t := ((7298369 : ℝ) / 407298369))
    (lo := ((1792089 : ℝ) / 50000000)) (hi := ((3584179 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((207298369 : ℝ) / 50000000) = Real.log ((207298369 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((207298369 : ℝ) / 50000000) = ((207298369 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1251 : RB (Real.log ((6478149 : ℝ) / 1562500)) ((142214771 : ℝ) / 100000000) ((71107387 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((6478149 : ℝ) / 6250000)) (t := ((228149 : ℝ) / 12728149))
    (lo := ((717067 : ℝ) / 20000000)) (hi := ((448167 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6478149 : ℝ) / 1562500) = Real.log ((6478149 : ℝ) / 6250000) + 2 * Real.log 2 := by
    rw [show ((6478149 : ℝ) / 1562500) = ((6478149 : ℝ) / 6250000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1252 : RB (Real.log ((131771543 : ℝ) / 100000000)) ((551799 : ℝ) / 2000000) ((27589951 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((131771543 : ℝ) / 100000000)) (t := ((31771543 : ℝ) / 231771543))
    (lo := ((551799 : ℝ) / 2000000)) (hi := ((27589951 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1253 : RB (Real.log ((411498483 : ℝ) / 100000000)) ((70731757 : ℝ) / 50000000) ((141463517 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((411498483 : ℝ) / 400000000)) (t := ((11498483 : ℝ) / 811498483))
    (lo := ((1417039 : ℝ) / 50000000)) (hi := ((2834079 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((411498483 : ℝ) / 100000000) = Real.log ((411498483 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((411498483 : ℝ) / 100000000) = ((411498483 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1254 : RB (Real.log ((205751617 : ℝ) / 50000000)) ((141464669 : ℝ) / 100000000) ((4420771 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((205751617 : ℝ) / 200000000)) (t := ((5751617 : ℝ) / 405751617))
    (lo := ((2835233 : ℝ) / 100000000)) (hi := ((1417617 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((205751617 : ℝ) / 50000000) = Real.log ((205751617 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((205751617 : ℝ) / 50000000) = ((205751617 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1255 : RB (Real.log ((515967 : ℝ) / 390625)) ((13914739 : ℝ) / 50000000) ((27829479 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((515967 : ℝ) / 390625)) (t := ((62671 : ℝ) / 453296))
    (lo := ((13914739 : ℝ) / 50000000)) (hi := ((27829479 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1256 : RB (Real.log ((5357179 : ℝ) / 50000000)) ((-223358551 : ℝ) / 100000000) ((-223358547 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5357179 : ℝ) / 6250000)) (t := ((-892821 : ℝ) / 11607179))
    (lo := ((-7707197 : ℝ) / 50000000)) (hi := ((-15414393 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5357179 : ℝ) / 50000000) = Real.log ((5357179 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5357179 : ℝ) / 50000000) = ((5357179 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1257 : RB (Real.log ((3109511 : ℝ) / 25000000)) ((-104220519 : ℝ) / 50000000) ((-104220517 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3109511 : ℝ) / 3125000)) (t := ((-15489 : ℝ) / 6234511))
    (lo := ((-496881 : ℝ) / 100000000)) (hi := ((-6211 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3109511 : ℝ) / 25000000) = Real.log ((3109511 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((3109511 : ℝ) / 25000000) = ((3109511 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1258 : RB (Real.log ((514831 : ℝ) / 12500000)) ((-19935283 : ℝ) / 6250000) ((-159482261 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((514831 : ℝ) / 390625)) (t := ((62103 : ℝ) / 452728))
    (lo := ((27609067 : ℝ) / 100000000)) (hi := ((6902267 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((514831 : ℝ) / 12500000) = Real.log ((514831 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((514831 : ℝ) / 12500000) = ((514831 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1259 : RB (Real.log ((209441 : ℝ) / 5000000)) ((-79318779 : ℝ) / 25000000) ((-317275111 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((209441 : ℝ) / 312500)) (t := ((-103059 : ℝ) / 521941))
    (lo := ((-500203 : ℝ) / 1250000)) (hi := ((-40016239 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((209441 : ℝ) / 5000000) = Real.log ((209441 : ℝ) / 312500) - 4 * Real.log 2 := by
    rw [show ((209441 : ℝ) / 5000000) = ((209441 : ℝ) / 312500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1260 : RB (Real.log ((32676207 : ℝ) / 50000000)) ((-21268791 : ℝ) / 50000000) ((-2126879 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((32676207 : ℝ) / 25000000)) (t := ((7676207 : ℝ) / 57676207))
    (lo := ((26777137 : ℝ) / 100000000)) (hi := ((13388569 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((32676207 : ℝ) / 50000000) = Real.log ((32676207 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((32676207 : ℝ) / 50000000) = ((32676207 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1261 : RB (Real.log ((65354981 : ℝ) / 100000000)) ((-21266827 : ℝ) / 50000000) ((-10633413 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((65354981 : ℝ) / 50000000)) (t := ((15354981 : ℝ) / 115354981))
    (lo := ((5356213 : ℝ) / 20000000)) (hi := ((13390533 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65354981 : ℝ) / 100000000) = Real.log ((65354981 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65354981 : ℝ) / 100000000) = ((65354981 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1262 : RB (Real.log ((39552931 : ℝ) / 100000000)) ((-1159413 : ℝ) / 1250000) ((-46376519 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39552931 : ℝ) / 50000000)) (t := ((-10447069 : ℝ) / 89552931))
    (lo := ((-23438321 : ℝ) / 100000000)) (hi := ((-292979 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39552931 : ℝ) / 100000000) = Real.log ((39552931 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((39552931 : ℝ) / 100000000) = ((39552931 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1263 : RB (Real.log ((191404831 : ℝ) / 100000000)) ((64922053 : ℝ) / 100000000) ((12984411 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((191404831 : ℝ) / 200000000)) (t := ((-8595169 : ℝ) / 391404831))
    (lo := ((-878533 : ℝ) / 20000000)) (hi := ((-549083 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((191404831 : ℝ) / 100000000) = Real.log ((191404831 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((191404831 : ℝ) / 100000000) = ((191404831 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1264 : RB (Real.log ((95768323 : ℝ) / 50000000)) ((4061931 : ℝ) / 6250000) ((32495449 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((95768323 : ℝ) / 100000000)) (t := ((-4231677 : ℝ) / 195768323))
    (lo := ((-2161911 : ℝ) / 50000000)) (hi := ((-4323821 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95768323 : ℝ) / 50000000) = Real.log ((95768323 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95768323 : ℝ) / 50000000) = ((95768323 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1265 : RB (Real.log ((33507921 : ℝ) / 50000000)) ((-8004823 : ℝ) / 20000000) ((-20012057 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((33507921 : ℝ) / 50000000)) (t := ((-16492079 : ℝ) / 83507921))
    (lo := ((-8004823 : ℝ) / 20000000)) (hi := ((-20012057 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1266 : RB (Real.log ((13403687 : ℝ) / 20000000)) ((-20010123 : ℝ) / 50000000) ((-8004049 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((13403687 : ℝ) / 20000000)) (t := ((-6596313 : ℝ) / 33403687))
    (lo := ((-20010123 : ℝ) / 50000000)) (hi := ((-8004049 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1267 : RB (Real.log ((20077483 : ℝ) / 50000000)) ((-11405301 : ℝ) / 12500000) ((-45621203 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((20077483 : ℝ) / 25000000)) (t := ((-4922517 : ℝ) / 45077483))
    (lo := ((-21927689 : ℝ) / 100000000)) (hi := ((-2740961 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20077483 : ℝ) / 50000000) = Real.log ((20077483 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20077483 : ℝ) / 50000000) = ((20077483 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1268 : RB (Real.log ((206773869 : ℝ) / 50000000)) ((35490069 : ℝ) / 25000000) ((141960279 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((206773869 : ℝ) / 200000000)) (t := ((6773869 : ℝ) / 406773869))
    (lo := ((83271 : ℝ) / 2500000)) (hi := ((3330841 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((206773869 : ℝ) / 50000000) = Real.log ((206773869 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((206773869 : ℝ) / 50000000) = ((206773869 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1269 : RB (Real.log ((103388151 : ℝ) / 25000000)) ((141961453 : ℝ) / 100000000) ((8872591 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((103388151 : ℝ) / 100000000)) (t := ((3388151 : ℝ) / 203388151))
    (lo := ((3332017 : ℝ) / 100000000)) (hi := ((1666009 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((103388151 : ℝ) / 25000000) = Real.log ((103388151 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((103388151 : ℝ) / 25000000) = ((103388151 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1270 : RB (Real.log ((131877343 : ℝ) / 100000000)) ((432347 : ℝ) / 1562500) ((27670209 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((131877343 : ℝ) / 100000000)) (t := ((31877343 : ℝ) / 231877343))
    (lo := ((432347 : ℝ) / 1562500)) (hi := ((27670209 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1271 : RB (Real.log ((410483397 : ℝ) / 100000000)) ((141216529 : ℝ) / 100000000) ((35304133 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((410483397 : ℝ) / 400000000)) (t := ((10483397 : ℝ) / 810483397))
    (lo := ((2587093 : ℝ) / 100000000)) (hi := ((1293547 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((410483397 : ℝ) / 100000000) = Real.log ((410483397 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((410483397 : ℝ) / 100000000) = ((410483397 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1272 : RB (Real.log ((51311027 : ℝ) / 12500000)) ((141217703 : ℝ) / 100000000) ((70608853 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((51311027 : ℝ) / 50000000)) (t := ((1311027 : ℝ) / 101311027))
    (lo := ((2588267 : ℝ) / 100000000)) (hi := ((647067 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51311027 : ℝ) / 12500000) = Real.log ((51311027 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((51311027 : ℝ) / 12500000) = ((51311027 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1273 : RB (Real.log ((132191959 : ℝ) / 100000000)) ((27908491 : ℝ) / 100000000) ((6977123 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((132191959 : ℝ) / 100000000)) (t := ((32191959 : ℝ) / 232191959))
    (lo := ((27908491 : ℝ) / 100000000)) (hi := ((6977123 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1274 : RB (Real.log ((10846431 : ℝ) / 100000000)) ((-222133413 : ℝ) / 100000000) ((-222133409 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10846431 : ℝ) / 12500000)) (t := ((-1653569 : ℝ) / 23346431))
    (lo := ((-1773657 : ℝ) / 12500000)) (hi := ((-2837851 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10846431 : ℝ) / 100000000) = Real.log ((10846431 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((10846431 : ℝ) / 100000000) = ((10846431 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1275 : RB (Real.log ((12557079 : ℝ) / 100000000)) ((-41497713 : ℝ) / 20000000) ((-207488561 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((12557079 : ℝ) / 12500000)) (t := ((57079 : ℝ) / 25057079))
    (lo := ((56949 : ℝ) / 12500000)) (hi := ((455593 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12557079 : ℝ) / 100000000) = Real.log ((12557079 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((12557079 : ℝ) / 100000000) = ((12557079 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1276 : RB (Real.log ((2091527 : ℝ) / 50000000)) ((-317412863 : ℝ) / 100000000) ((-158706429 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2091527 : ℝ) / 3125000)) (t := ((-1033473 : ℝ) / 5216527))
    (lo := ((-40153987 : ℝ) / 100000000)) (hi := ((-20076993 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2091527 : ℝ) / 50000000) = Real.log ((2091527 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2091527 : ℝ) / 50000000) = ((2091527 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1277 : RB (Real.log ((4253319 : ℝ) / 100000000)) ((-315747061 : ℝ) / 100000000) ((-19734191 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((4253319 : ℝ) / 6250000)) (t := ((-1996681 : ℝ) / 10503319))
    (lo := ((-7697637 : ℝ) / 20000000)) (hi := ((-4811023 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4253319 : ℝ) / 100000000) = Real.log ((4253319 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((4253319 : ℝ) / 100000000) = ((4253319 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1278 : RB (Real.log ((65168919 : ℝ) / 100000000)) ((-8563751 : ℝ) / 20000000) ((-42818753 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65168919 : ℝ) / 50000000)) (t := ((15168919 : ℝ) / 115168919))
    (lo := ((6623991 : ℝ) / 25000000)) (hi := ((5299193 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((65168919 : ℝ) / 100000000) = Real.log ((65168919 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((65168919 : ℝ) / 100000000) = ((65168919 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1279 : RB (Real.log ((8146441 : ℝ) / 12500000)) ((-42814751 : ℝ) / 100000000) ((-42814749 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8146441 : ℝ) / 6250000)) (t := ((1896441 : ℝ) / 14396441))
    (lo := ((207031 : ℝ) / 781250)) (hi := ((26499969 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8146441 : ℝ) / 12500000) = Real.log ((8146441 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((8146441 : ℝ) / 12500000) = ((8146441 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
