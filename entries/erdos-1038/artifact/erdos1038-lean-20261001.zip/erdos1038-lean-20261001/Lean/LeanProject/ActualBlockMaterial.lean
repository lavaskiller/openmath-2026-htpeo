import LeanProject.ActualBlockEnergy

/-! The static material expression on each actual residual block. -/

open Real Set MeasureTheory Finset Filter Topology intervalIntegral
open scoped ENNReal

namespace EP1038.Stage12
open EP1038.Arc EP1038.Stage11 EP1038.NormalForm NormalData AngleReference

noncomputable def refConstant (R : SeparatedReference) : ℝ :=
  Real.log (R.r / 2) + R.angles.k * Real.log (refD0 R)

theorem reference_platform (R : SeparatedReference)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) (θ : ℝ) :
    R.angles.k * Real.log (position R.c R.r θ) + 1 / π *
      (∫ φ in (0 : ℝ)..π, Real.log |position R.c R.r θ - position R.c R.r φ| *
        alpha R.angles.k R.angles.ρ φ) = refConstant R := by
  have h := platform (k := R.angles.k) (refD0_pos R) R.angles.rho_pos R.angles.rho_lt_one θ
  have hi := (log_dist_ii (refD0_pos R) R.angles.rho_pos θ).mul_continuousOn
    (alpha_cont R.angles.k R.angles.ρ R.angles.rho_pos.le R.angles.rho_lt_one).continuousOn
  change IntervalIntegrable (fun φ => Real.log |dth (refD0 R) R.angles.ρ θ -
    dth (refD0 R) R.angles.ρ φ| * ((R.angles.k + 1) - R.angles.k * Pq R.angles.ρ φ))
      volume (-π) π at hi
  rw [int_split hi] at h
  have he (φ : ℝ) : dth (refD0 R) R.angles.ρ (-φ) = dth (refD0 R) R.angles.ρ φ := by
    simp [dth, Real.cos_neg]
  simp_rw [he, EP1038.Arc.Pq_even] at h
  simp_rw [← refPosition_eq_dth R hzero] at h
  rw [refH_eq] at h
  unfold refConstant
  dsimp [alpha]
  linear_combination h

noncomputable def blockLogPotential {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v θ : ℝ) : ℝ :=
  1 / π * ∫ φ in (0 : ℝ)..π, (blockSet R.angles a hres v).indicator
    (fun φ => Real.log |position R.c R.r θ - position R.c R.r φ| *
      alpha R.angles.k R.angles.ρ φ) φ

theorem position_strictMonoOn {c r : ℝ} (hr : 0 < r) :
    StrictMonoOn (position c r) (Icc (0 : ℝ) π) := by
  intro θ hθ φ hφ hlt
  have hc := Real.cos_lt_cos_of_nonneg_of_le_pi hθ.1 hφ.2 hlt
  dsimp [position]
  nlinarith

theorem angularTarget_monoOn {n : ℕ} (A : AngleReference) (a : NormalData n)
    (hres : 0 < a.residualCount) :
    MonotoneOn (A.angularTarget (a.residualQuantile hres)) (Icc (0 : ℝ) π) := by
  intro θ hθ φ hφ hle
  simp only [angularTarget, foldedAngle_eq hθ, foldedAngle_eq hφ]
  exact monotone_residualQuantile a hres (A.cdf_strictMonoOn.monotoneOn hθ hφ hle)

theorem log_ratio_bound {X Y : ℝ} (hX : X ≠ 0) (hY : Y ≠ 0) (hpos : 0 < Y / X) :
    Real.log |Y| - Real.log |X| ≤ Y / X - 1 := by
  have heq : Real.log (Y / X) = Real.log |Y| - Real.log |X| := by
    rw [← Real.log_abs, abs_div, Real.log_div (abs_ne_zero.mpr hY) (abs_ne_zero.mpr hX)]
  simpa only [heq] using Real.log_le_sub_one_of_pos hpos

theorem material_kernel_block_bound {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v θ φ : ℝ} (hθ : θ ∈ blockSet R.angles a hres v)
    (hφ : φ ∈ Icc (0 : ℝ) π) (hne : φ ≠ θ) :
    (Real.log |(v - a.roots a.main) - R.angles.angularTarget (a.residualQuantile hres) φ| -
      Real.log |position R.c R.r θ - position R.c R.r φ| +
      (blockSet R.angles a hres v).indicator
        (fun φ => Real.log |position R.c R.r θ - position R.c R.r φ|) φ -
      (blockSet R.angles a hres v).indicator (fun _ => (1 : ℝ)) φ) *
        alpha R.angles.k R.angles.ρ φ ≤
          materialKernel R.angles.k R.angles.ρ R.c R.r
            (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) (θ, φ) := by
  have hθc : θ ∈ Icc (0 : ℝ) π := hθ.1
  have hTv : R.angles.angularTarget (a.residualQuantile hres) θ = v - a.roots a.main := hθ.2
  have hX : position R.c R.r φ - position R.c R.r θ ≠ 0 :=
    sub_ne_zero.mpr (fun heq => hne ((position_strictMonoOn R.radius_pos).injOn hφ hθc heq))
  have hα := (alpha_bounds R.angles.k_pos.le R.angles.rho_pos.le R.angles.rho_lt_one
    R.angles.density_zero_nonneg φ).1
  have he : materialKernel R.angles.k R.angles.ρ R.c R.r
      (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) (θ, φ) =
      ((R.angles.angularTarget (a.residualQuantile hres) φ - (v - a.roots a.main)) /
        (position R.c R.r φ - position R.c R.r θ) - 1) * alpha R.angles.k R.angles.ρ φ := by
    dsimp [materialKernel, angularDrift]
    rw [hTv]
    field_simp
    ring
  rw [he]
  by_cases hmem : φ ∈ blockSet R.angles a hres v
  · have ht : R.angles.angularTarget (a.residualQuantile hres) φ = v - a.roots a.main := hmem.2
    rw [indicator_of_mem hmem, indicator_of_mem hmem, ht]
    simp
  · have hY : R.angles.angularTarget (a.residualQuantile hres) φ - (v - a.roots a.main) ≠ 0 := by
      intro hh
      apply hmem
      refine ⟨hφ, ?_⟩
      change R.angles.angularTarget (a.residualQuantile hres) φ = v - a.roots a.main
      linarith
    have hpos : 0 < (R.angles.angularTarget (a.residualQuantile hres) φ -
        (v - a.roots a.main)) / (position R.c R.r φ - position R.c R.r θ) := by
      rcases lt_or_gt_of_ne hne with hlt | hlt
      · have hm := angularTarget_monoOn R.angles a hres hφ hθc hlt.le
        rw [hTv] at hm
        exact div_pos_of_neg_of_neg (lt_of_le_of_ne (sub_nonpos.mpr hm) hY)
          (sub_neg.mpr (position_strictMonoOn R.radius_pos hφ hθc hlt))
      · have hm := angularTarget_monoOn R.angles a hres hθc hφ hlt.le
        rw [hTv] at hm
        exact div_pos (lt_of_le_of_ne (sub_nonneg.mpr hm) hY.symm)
          (sub_pos.mpr (position_strictMonoOn R.radius_pos hθc hφ hlt))
    rw [indicator_of_notMem hmem, indicator_of_notMem hmem, add_zero, sub_zero]
    apply mul_le_mul_of_nonneg_right _ hα
    simpa only [abs_sub_comm] using log_ratio_bound hX hY hpos

theorem material_kernel_integrable {k ρ c r θ : ℝ} {v : ℝ → ℝ}
    (hr : 0 < r) (hk : 0 ≤ k) (h0 : 0 ≤ ρ) (h1 : ρ < 1)
    (hF : IntervalIntegrable (fun φ =>
      (alpha k ρ φ * v φ - alpha k ρ θ * v θ) / (cos θ - cos φ)) volume 0 π) :
    IntervalIntegrable (fun φ => materialKernel k ρ c r v (θ, φ)) volume 0 π := by
  have hα := (alpha_XLip hk h0 h1).dq_integrable (mul_nonneg hk (poissonLip_nonneg h0 h1)) θ
  have heq : (fun φ => materialKernel k ρ c r v (θ, φ)) =
      (fun φ => 1 / r * ((alpha k ρ φ * v φ - alpha k ρ θ * v θ) / (cos θ - cos φ)) -
        (v θ / r) * ((alpha k ρ φ - alpha k ρ θ) / (cos θ - cos φ))) := by
    funext φ
    dsimp [materialKernel, position]
    rw [show (c - r * cos φ) - (c - r * cos θ) = r * (cos θ - cos φ) by ring]
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  rw [heq]
  exact (hF.const_mul _).sub (hα.const_mul _)

theorem block_log_potential_integrable {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v θ : ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    IntervalIntegrable ((blockSet R.angles a hres v).indicator
      (fun φ => Real.log |position R.c R.r θ - position R.c R.r φ| *
        alpha R.angles.k R.angles.ρ φ)) volume 0 π := by
  apply interval_integrable_indicator _ (blockSet_measurable R.angles a hres v)
  rw [refPosition_eq_dth R hzero]
  exact (log_distance_half_integrable (refD0_pos R) R.angles.rho_pos θ).mul_continuousOn
    (alpha_cont R.angles.k R.angles.ρ R.angles.rho_pos.le R.angles.rho_lt_one).continuousOn

theorem material_block_pointwise {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v θ : ℝ} (hv : v ∈ a.residualValues)
    (hθ : θ ∈ blockSet R.angles a hres v) (hk : R.angles.k = a.k)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ))
    (hF : IntervalIntegrable (fun φ =>
      (R.angles.angularVelocity R.c R.r (a.residualQuantile hres) φ -
        R.angles.angularVelocity R.c R.r (a.residualQuantile hres) θ) /
          (cos θ - cos φ)) volume 0 π) :
    -blockMass R.angles a hres v * Real.log (Stage7.Rv a.roots v) - refConstant R -
      blockMass R.angles a hres v + blockLogPotential R a hres v θ ≤
        materialAngular R.angles.k R.angles.ρ R.c R.r
          (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) θ := by
  let d := position R.c R.r
  let T := R.angles.angularTarget (a.residualQuantile hres)
  let α := alpha R.angles.k R.angles.ρ
  let S := blockSet R.angles a hres v
  let x := v - a.roots a.main
  have hTx : T θ = x := hθ.2
  have hx : 0 < x := by
    obtain ⟨i, hi, heq⟩ := Finset.mem_image.mp hv
    have hb := residual_location_bounds a hi
    dsimp [locations] at hb
    dsimp [x]
    rw [← heq]
    linarith [separator_ge_one a]
  have hd : 0 < d θ := lt_of_lt_of_le R.left_pos (position_bounds R.radius_pos.le).1
  have hiT := weighted_angular_target_integrable R.angles a hres (fun t => Real.log |x - t|)
  have hiD : IntervalIntegrable (fun φ => Real.log |d θ - d φ| * α φ) volume 0 π := by
    change IntervalIntegrable (fun φ => Real.log |position R.c R.r θ - position R.c R.r φ| *
      alpha R.angles.k R.angles.ρ φ) volume 0 π
    rw [refPosition_eq_dth R hzero]
    exact (log_distance_half_integrable (refD0_pos R) R.angles.rho_pos θ).mul_continuousOn
      (alpha_cont R.angles.k R.angles.ρ R.angles.rho_pos.le R.angles.rho_lt_one).continuousOn
  have hiL := block_log_potential_integrable R a hres v θ hzero
  have hiQ := interval_integrable_indicator
    ((alpha_cont R.angles.k R.angles.ρ R.angles.rho_pos.le R.angles.rho_lt_one).intervalIntegrable 0 π)
      (blockSet_measurable R.angles a hres v)
  have hiK := material_kernel_integrable (c := R.c) R.radius_pos R.angles.k_pos.le R.angles.rho_pos.le
    R.angles.rho_lt_one hF
  let low := fun φ => Real.log |x - T φ| * α φ - Real.log |d θ - d φ| * α φ +
    S.indicator (fun φ => Real.log |d θ - d φ| * α φ) φ - S.indicator α φ
  have hilow : IntervalIntegrable low volume 0 π := ((hiT.sub hiD).add hiL).sub hiQ
  have hibound : (∫ φ in (0 : ℝ)..π, low φ) ≤
      ∫ φ in (0 : ℝ)..π, materialKernel R.angles.k R.angles.ρ R.c R.r
        (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) (θ, φ) := by
    apply intervalIntegral.integral_mono_ae_restrict Real.pi_pos.le hilow hiK
    filter_upwards [ae_restrict_of_ae (EP1038.Stage9.ae_ne_real θ),
      ae_restrict_mem measurableSet_Icc] with φ hne hφ
    have h := material_kernel_block_bound R a hres hθ hφ hne
    have heq : low φ = (Real.log |x - T φ| - Real.log |d θ - d φ| +
      S.indicator (fun φ => Real.log |d θ - d φ|) φ - S.indicator (fun _ => (1 : ℝ)) φ) * α φ := by
      by_cases hmem : φ ∈ S <;> simp [low, hmem] <;> ring
    rw [heq]
    exact h
  have hlog : R.angles.k * (Real.log x - Real.log (d θ)) ≤
      R.angles.k * (x - d θ) / d θ := by
    have h := log_ratio_bound hd.ne' hx.ne' (div_pos hx hd)
    rw [abs_of_pos hx, abs_of_pos hd] at h
    have he : (x - d θ) / d θ = x / d θ - 1 := by field_simp
    rw [mul_div_assoc, he]
    exact mul_le_mul_of_nonneg_left h R.angles.k_pos.le
  have hIlow : (∫ φ in (0 : ℝ)..π, low φ) =
      (∫ φ in (0 : ℝ)..π, Real.log |x - T φ| * α φ) -
        (∫ φ in (0 : ℝ)..π, Real.log |d θ - d φ| * α φ) +
          (∫ φ in (0 : ℝ)..π, S.indicator (fun φ => Real.log |d θ - d φ| * α φ) φ) -
            ∫ φ in (0 : ℝ)..π, S.indicator α φ := by
    dsimp [low]
    rw [intervalIntegral.integral_sub ((hiT.sub hiD).add hiL) hiQ,
      intervalIntegral.integral_add (hiT.sub hiD) hiL, intervalIntegral.integral_sub hiT hiD]
  have hpot : R.angles.k * Real.log x + 1 / π *
      (∫ φ in (0 : ℝ)..π, Real.log |x - T φ| * α φ) =
        -blockMass R.angles a hres v * Real.log (Stage7.Rv a.roots v) := by
    dsimp only [T, α]
    rw [weighted_angular_target_integral R.angles a hres (fun t => Real.log |x - t|),
      block_radius_identity R.angles a hres hv]
    rw [Stage10.WS]
    dsimp [x]
    rw [hk, abs_of_pos hx]
  have hplat := reference_platform R hzero θ
  have hbound := mul_le_mul_of_nonneg_left hibound (one_div_pos.mpr Real.pi_pos).le
  rw [hIlow] at hbound
  dsimp only [materialAngular, angularDrift]
  dsimp only [T] at hTx
  rw [hTx]
  change -blockMass R.angles a hres v * Real.log (Stage7.Rv a.roots v) - refConstant R -
    blockMass R.angles a hres v + blockLogPotential R a hres v θ ≤
      R.angles.k * (x - d θ) / d θ + 1 / π * ∫ φ in (0 : ℝ)..π,
        materialKernel R.angles.k R.angles.ρ R.c R.r
          (R.angles.angularDrift R.c R.r (a.residualQuantile hres)) (θ, φ)
  dsimp [blockMass, blockLogPotential, S, α, d] at hbound hpot hlog ⊢
  linarith

theorem block_log_potential_weight_integrable {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    IntervalIntegrable (fun θ => blockLogPotential R a hres v θ *
      (blockSet R.angles a hres v).indicator (refB R) θ) volume 0 π := by
  have h := (block_log_joint_integrable R a hres v hzero).integral_prod_right
  have he (θ : ℝ) : (∫ φ, (blockSet R.angles a hres v).indicator
      (alpha R.angles.k R.angles.ρ) φ *
        (Real.log |position R.c R.r φ - position R.c R.r θ| *
          (blockSet R.angles a hres v).indicator (refB R) θ) ∂angleMeasure) =
      π * (blockLogPotential R a hres v θ *
        (blockSet R.angles a hres v).indicator (refB R) θ) := by
    have hfun : (fun φ => (blockSet R.angles a hres v).indicator
        (alpha R.angles.k R.angles.ρ) φ *
          (Real.log |position R.c R.r φ - position R.c R.r θ| *
            (blockSet R.angles a hres v).indicator (refB R) θ)) =
        fun φ => (blockSet R.angles a hres v).indicator
          (fun φ => Real.log |position R.c R.r θ - position R.c R.r φ| *
            alpha R.angles.k R.angles.ρ φ) φ *
              (blockSet R.angles a hres v).indicator (refB R) θ := by
      funext φ
      rw [abs_sub_comm (position R.c R.r φ) (position R.c R.r θ)]
      by_cases hm : φ ∈ blockSet R.angles a hres v <;> simp [hm] <;> ring
    rw [hfun, MeasureTheory.integral_mul_const]
    unfold blockLogPotential
    rw [intervalIntegral.integral_of_le Real.pi_pos.le]
    field_simp
    dsimp [angleMeasure]
    ring
  simp_rw [he] at h
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le Real.pi_pos.le]
  have h' := h.div_const π
  apply h'.congr
  exact Eventually.of_forall fun θ => by field_simp

theorem block_log_potential_energy {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) (v : ℝ)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    1 / π * (∫ θ in (0 : ℝ)..π, blockLogPotential R a hres v θ *
      (blockSet R.angles a hres v).indicator (refB R) θ) = blockEnergy R a hres v := by
  rw [blockEnergy_raw_swap R a hres v hzero]
  have he (θ : ℝ) : (∫ φ in (0 : ℝ)..π, (blockSet R.angles a hres v).indicator
      (fun φ => Real.log |position R.c R.r θ - position R.c R.r φ| *
        alpha R.angles.k R.angles.ρ φ) φ) =
      ∫ φ in (0 : ℝ)..π, Real.log |position R.c R.r θ - position R.c R.r φ| *
        (blockSet R.angles a hres v).indicator (alpha R.angles.k R.angles.ρ) φ := by
    apply intervalIntegral.integral_congr
    intro φ _
    by_cases hm : φ ∈ blockSet R.angles a hres v <;> simp [hm]
  unfold blockLogPotential
  simp_rw [he]
  simp_rw [show ∀ θ, 1 / π * (∫ φ in (0 : ℝ)..π,
      Real.log |position R.c R.r θ - position R.c R.r φ| *
        (blockSet R.angles a hres v).indicator (alpha R.angles.k R.angles.ρ) φ) *
          (blockSet R.angles a hres v).indicator (refB R) θ =
      1 / π * ((blockSet R.angles a hres v).indicator (refB R) θ *
        ∫ φ in (0 : ℝ)..π, Real.log |position R.c R.r θ - position R.c R.r φ| *
          (blockSet R.angles a hres v).indicator (alpha R.angles.k R.angles.ρ) φ) by intros; ring]
  rw [intervalIntegral.integral_const_mul]
  ring

theorem blockMaterial_lower_bound {n : ℕ} (R : SeparatedReference) (a : NormalData n)
    (hres : 0 < a.residualCount) {v : ℝ} (hv : v ∈ a.residualValues) (hk : R.angles.k = a.k)
    (hzero : (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ)) :
    blockXi R a hres v * (-blockMass R.angles a hres v * Real.log (Stage7.Rv a.roots v) -
      refConstant R - blockMass R.angles a hres v) + blockEnergy R a hres v ≤
        blockMaterialIntegral R a hres v := by
  let S := blockSet R.angles a hres v
  let C := -blockMass R.angles a hres v * Real.log (Stage7.Rv a.roots v) -
    refConstant R - blockMass R.angles a hres v
  let g := materialAngular R.angles.k R.angles.ρ R.c R.r
    (R.angles.angularDrift R.c R.r (a.residualQuantile hres))
  have hB := interval_integrable_indicator ((refB_continuous R).intervalIntegrable 0 π)
    (blockSet_measurable R.angles a hres v)
  have hE := block_log_potential_weight_integrable R a hres v hzero
  have hg := interval_integrable_indicator (material_weight_integrable R a hres hzero)
    (blockSet_measurable R.angles a hres v)
  have hF := ae_dq_integrable (R.residual_adjoint_le_Mdot a hres).1.kernel
    (Bxi_ne_zero_ae R.rhoPlus_spec.1 R.rhoPlus_spec.2.1 R.rhoMinus_spec.1.le
      R.rhoMinus_spec.2.1 R.sigmaPlus_pos R.sigmaMinus_pos.le)
  have hle : (∫ θ in (0 : ℝ)..π, C * S.indicator (refB R) θ +
      blockLogPotential R a hres v θ * S.indicator (refB R) θ) ≤
        ∫ θ in (0 : ℝ)..π, S.indicator (fun θ => g θ * refB R θ) θ := by
    apply intervalIntegral.integral_mono_ae_restrict Real.pi_pos.le ((hB.const_mul C).add hE) hg
    have hF' : ∀ᵐ θ ∂(volume.restrict (Icc (0 : ℝ) π)), IntervalIntegrable
        (fun φ => (R.angles.angularVelocity R.c R.r (a.residualQuantile hres) φ -
          R.angles.angularVelocity R.c R.r (a.residualQuantile hres) θ) / (cos θ - cos φ)) volume 0 π := by
      have he : volume.restrict (Ioc (0 : ℝ) π) = volume.restrict (Icc (0 : ℝ) π) :=
        Measure.restrict_congr_set Ioc_ae_eq_Icc
      rw [← he]
      exact hF
    filter_upwards [hF'] with θ hθF
    by_cases hm : θ ∈ S
    · rw [indicator_of_mem hm, indicator_of_mem hm]
      have h := material_block_pointwise R a hres hv hm hk hzero hθF
      have h' := mul_le_mul_of_nonneg_right h (refB_nonneg R θ)
      dsimp [C, g]
      nlinarith
    · change C * S.indicator (refB R) θ + blockLogPotential R a hres v θ *
        S.indicator (refB R) θ ≤ S.indicator (fun θ => g θ * refB R θ) θ
      rw [Set.indicator_of_notMem hm, Set.indicator_of_notMem hm]
      simp
  have hle' := mul_le_mul_of_nonneg_left hle (one_div_pos.mpr Real.pi_pos).le
  rw [intervalIntegral.integral_add (hB.const_mul C) hE, intervalIntegral.integral_const_mul] at hle'
  have he := block_log_potential_energy R a hres v hzero
  dsimp [blockXi, blockMaterialIntegral]
  dsimp [S, C, g] at hle'
  linarith [he]

end EP1038.Stage12
