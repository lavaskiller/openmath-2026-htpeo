import LeanProject.COVLogTwo
import LeanProject.COVLogBounds10
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1120 : RB (Real.log ((192589431 : ℝ) / 100000000)) ((65539043 : ℝ) / 100000000) ((13107809 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((192589431 : ℝ) / 200000000)) (t := ((-7410569 : ℝ) / 392589431))
    (lo := ((-151027 : ℝ) / 4000000)) (hi := ((-1887837 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192589431 : ℝ) / 100000000) = Real.log ((192589431 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((192589431 : ℝ) / 100000000) = ((192589431 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1121 : RB (Real.log ((68749197 : ℝ) / 100000000)) ((-37470513 : ℝ) / 100000000) ((-2341907 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((68749197 : ℝ) / 100000000)) (t := ((-31250803 : ℝ) / 168749197))
    (lo := ((-37470513 : ℝ) / 100000000)) (hi := ((-2341907 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1122 : RB (Real.log ((68751459 : ℝ) / 100000000)) ((-37467223 : ℝ) / 100000000) ((-18733611 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((68751459 : ℝ) / 100000000)) (t := ((-31248541 : ℝ) / 168751459))
    (lo := ((-37467223 : ℝ) / 100000000)) (hi := ((-18733611 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1123 : RB (Real.log ((1630511 : ℝ) / 4000000)) ((-89740091 : ℝ) / 100000000) ((-89740089 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1630511 : ℝ) / 2000000)) (t := ((-369489 : ℝ) / 3630511))
    (lo := ((-5106343 : ℝ) / 25000000)) (hi := ((-20425371 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1630511 : ℝ) / 4000000) = Real.log ((1630511 : ℝ) / 2000000) - 1 * Real.log 2 := by
    rw [show ((1630511 : ℝ) / 4000000) = ((1630511 : ℝ) / 2000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1124 : RB (Real.log ((211139813 : ℝ) / 50000000)) ((18006219 : ℝ) / 12500000) ((28809951 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((211139813 : ℝ) / 200000000)) (t := ((11139813 : ℝ) / 411139813))
    (lo := ((1355079 : ℝ) / 25000000)) (hi := ((5420317 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((211139813 : ℝ) / 50000000) = Real.log ((211139813 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((211139813 : ℝ) / 50000000) = ((211139813 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1125 : RB (Real.log ((52785493 : ℝ) / 12500000)) ((5762031 : ℝ) / 4000000) ((72025389 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((52785493 : ℝ) / 50000000)) (t := ((2785493 : ℝ) / 102785493))
    (lo := ((5421339 : ℝ) / 100000000)) (hi := ((271067 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52785493 : ℝ) / 12500000) = Real.log ((52785493 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((52785493 : ℝ) / 12500000) = ((52785493 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1126 : RB (Real.log ((13101727 : ℝ) / 10000000)) ((3376987 : ℝ) / 12500000) ((27015897 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13101727 : ℝ) / 10000000)) (t := ((3101727 : ℝ) / 23101727))
    (lo := ((3376987 : ℝ) / 12500000)) (hi := ((27015897 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1127 : RB (Real.log ((418924913 : ℝ) / 100000000)) ((143252151 : ℝ) / 100000000) ((71626077 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((418924913 : ℝ) / 400000000)) (t := ((18924913 : ℝ) / 818924913))
    (lo := ((924543 : ℝ) / 20000000)) (hi := ((1155679 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((418924913 : ℝ) / 100000000) = Real.log ((418924913 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((418924913 : ℝ) / 100000000) = ((418924913 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1128 : RB (Real.log ((209464593 : ℝ) / 50000000)) ((143253171 : ℝ) / 100000000) ((71626587 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((209464593 : ℝ) / 200000000)) (t := ((9464593 : ℝ) / 409464593))
    (lo := ((924747 : ℝ) / 20000000)) (hi := ((577967 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((209464593 : ℝ) / 50000000) = Real.log ((209464593 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((209464593 : ℝ) / 50000000) = ((209464593 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1129 : RB (Real.log ((26268707 : ℝ) / 20000000)) ((2726461 : ℝ) / 10000000) ((27264611 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((26268707 : ℝ) / 20000000)) (t := ((6268707 : ℝ) / 46268707))
    (lo := ((2726461 : ℝ) / 10000000)) (hi := ((27264611 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1130 : RB (Real.log ((9774843 : ℝ) / 100000000)) ((-232535817 : ℝ) / 100000000) ((-232535813 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9774843 : ℝ) / 12500000)) (t := ((-2725157 : ℝ) / 22274843))
    (lo := ((-1229583 : ℝ) / 5000000)) (hi := ((-24591659 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9774843 : ℝ) / 100000000) = Real.log ((9774843 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((9774843 : ℝ) / 100000000) = ((9774843 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1131 : RB (Real.log ((2322329 : ℝ) / 20000000)) ((-8612647 : ℝ) / 4000000) ((-215316171 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2322329 : ℝ) / 2500000)) (t := ((-177671 : ℝ) / 4822329))
    (lo := ((-3686009 : ℝ) / 50000000)) (hi := ((-7372017 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2322329 : ℝ) / 20000000) = Real.log ((2322329 : ℝ) / 2500000) - 3 * Real.log 2 := by
    rw [show ((2322329 : ℝ) / 20000000) = ((2322329 : ℝ) / 2500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1132 : RB (Real.log ((1833903 : ℝ) / 50000000)) ((-165278829 : ℝ) / 50000000) ((-82639413 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1833903 : ℝ) / 1562500)) (t := ((271403 : ℝ) / 3396403))
    (lo := ((16015937 : ℝ) / 100000000)) (hi := ((8007969 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1833903 : ℝ) / 50000000) = Real.log ((1833903 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1833903 : ℝ) / 50000000) = ((1833903 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1133 : RB (Real.log ((1868659 : ℝ) / 50000000)) ((-1643401 : ℝ) / 500000) ((-164340097 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1868659 : ℝ) / 1562500)) (t := ((306159 : ℝ) / 3431159))
    (lo := ((3578679 : ℝ) / 20000000)) (hi := ((4473349 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1868659 : ℝ) / 50000000) = Real.log ((1868659 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1868659 : ℝ) / 50000000) = ((1868659 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1134 : RB (Real.log ((66691569 : ℝ) / 100000000)) ((-8101833 : ℝ) / 20000000) ((-10127291 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((66691569 : ℝ) / 100000000)) (t := ((-33308431 : ℝ) / 166691569))
    (lo := ((-8101833 : ℝ) / 20000000)) (hi := ((-10127291 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1135 : RB (Real.log ((8336731 : ℝ) / 12500000)) ((-10126437 : ℝ) / 25000000) ((-40505747 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8336731 : ℝ) / 12500000)) (t := ((-4163269 : ℝ) / 20836731))
    (lo := ((-10126437 : ℝ) / 25000000)) (hi := ((-40505747 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1136 : RB (Real.log ((20016187 : ℝ) / 50000000)) ((-22887043 : ℝ) / 25000000) ((-9154817 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((20016187 : ℝ) / 25000000)) (t := ((-4983813 : ℝ) / 45016187))
    (lo := ((-22233453 : ℝ) / 100000000)) (hi := ((-5558363 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20016187 : ℝ) / 50000000) = Real.log ((20016187 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((20016187 : ℝ) / 50000000) = ((20016187 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1137 : RB (Real.log ((19232651 : ℝ) / 10000000)) ((65402431 : ℝ) / 100000000) ((65402433 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19232651 : ℝ) / 20000000)) (t := ((-767349 : ℝ) / 39232651))
    (lo := ((-3912287 : ℝ) / 100000000)) (hi := ((-1956143 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19232651 : ℝ) / 10000000) = Real.log ((19232651 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((19232651 : ℝ) / 10000000) = ((19232651 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1138 : RB (Real.log ((48114499 : ℝ) / 25000000)) ((32735387 : ℝ) / 50000000) ((8183847 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((48114499 : ℝ) / 50000000)) (t := ((-1885501 : ℝ) / 98114499))
    (lo := ((-480493 : ℝ) / 12500000)) (hi := ((-3843943 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48114499 : ℝ) / 25000000) = Real.log ((48114499 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48114499 : ℝ) / 25000000) = ((48114499 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1139 : RB (Real.log ((34260077 : ℝ) / 50000000)) ((-37804227 : ℝ) / 100000000) ((-18902113 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((34260077 : ℝ) / 50000000)) (t := ((-15739923 : ℝ) / 84260077))
    (lo := ((-37804227 : ℝ) / 100000000)) (hi := ((-18902113 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1140 : RB (Real.log ((34261229 : ℝ) / 50000000)) ((-7560173 : ℝ) / 20000000) ((-1181277 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((34261229 : ℝ) / 50000000)) (t := ((-15738771 : ℝ) / 84261229))
    (lo := ((-7560173 : ℝ) / 20000000)) (hi := ((-1181277 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1141 : RB (Real.log ((40683073 : ℝ) / 100000000)) ((-89935809 : ℝ) / 100000000) ((-89935807 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40683073 : ℝ) / 50000000)) (t := ((-9316927 : ℝ) / 90683073))
    (lo := ((-2062109 : ℝ) / 10000000)) (hi := ((-20621089 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40683073 : ℝ) / 100000000) = Real.log ((40683073 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40683073 : ℝ) / 100000000) = ((40683073 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1142 : RB (Real.log ((210571979 : ℝ) / 50000000)) ((143780453 : ℝ) / 100000000) ((17972557 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((210571979 : ℝ) / 200000000)) (t := ((10571979 : ℝ) / 410571979))
    (lo := ((5151017 : ℝ) / 100000000)) (hi := ((2575509 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((210571979 : ℝ) / 50000000) = Real.log ((210571979 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((210571979 : ℝ) / 50000000) = ((210571979 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1143 : RB (Real.log ((105287087 : ℝ) / 25000000)) ((28756299 : ℝ) / 20000000) ((71890749 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((105287087 : ℝ) / 100000000)) (t := ((5287087 : ℝ) / 205287087))
    (lo := ((5152059 : ℝ) / 100000000)) (hi := ((257603 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((105287087 : ℝ) / 25000000) = Real.log ((105287087 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((105287087 : ℝ) / 25000000) = ((105287087 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1144 : RB (Real.log ((32781633 : ℝ) / 25000000)) ((3387407 : ℝ) / 12500000) ((27099257 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32781633 : ℝ) / 25000000)) (t := ((7781633 : ℝ) / 57781633))
    (lo := ((3387407 : ℝ) / 12500000)) (hi := ((27099257 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1145 : RB (Real.log ((417828059 : ℝ) / 100000000)) ((142989981 : ℝ) / 100000000) ((4468437 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((417828059 : ℝ) / 400000000)) (t := ((17828059 : ℝ) / 817828059))
    (lo := ((872109 : ℝ) / 20000000)) (hi := ((2180273 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((417828059 : ℝ) / 100000000) = Real.log ((417828059 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((417828059 : ℝ) / 100000000) = ((417828059 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1146 : RB (Real.log ((417832403 : ℝ) / 100000000)) ((142991021 : ℝ) / 100000000) ((8936939 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((417832403 : ℝ) / 400000000)) (t := ((17832403 : ℝ) / 817832403))
    (lo := ((872317 : ℝ) / 20000000)) (hi := ((2180793 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((417832403 : ℝ) / 100000000) = Real.log ((417832403 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((417832403 : ℝ) / 100000000) = ((417832403 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1147 : RB (Real.log ((5258051 : ℝ) / 4000000)) ((13673303 : ℝ) / 50000000) ((27346607 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5258051 : ℝ) / 4000000)) (t := ((1258051 : ℝ) / 9258051))
    (lo := ((13673303 : ℝ) / 50000000)) (hi := ((27346607 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1148 : RB (Real.log ((247757 : ℝ) / 2500000)) ((-115579881 : ℝ) / 50000000) ((-115579879 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((247757 : ℝ) / 312500)) (t := ((-64743 : ℝ) / 560257))
    (lo := ((-4643121 : ℝ) / 20000000)) (hi := ((-5803901 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((247757 : ℝ) / 2500000) = Real.log ((247757 : ℝ) / 312500) - 3 * Real.log 2 := by
    rw [show ((247757 : ℝ) / 2500000) = ((247757 : ℝ) / 312500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1149 : RB (Real.log ((11728237 : ℝ) / 100000000)) ((-214317087 : ℝ) / 100000000) ((-214317083 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((11728237 : ℝ) / 12500000)) (t := ((-771763 : ℝ) / 24228237))
    (lo := ((-637293 : ℝ) / 10000000)) (hi := ((-6372929 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11728237 : ℝ) / 100000000) = Real.log ((11728237 : ℝ) / 12500000) - 3 * Real.log 2 := by
    rw [show ((11728237 : ℝ) / 100000000) = ((11728237 : ℝ) / 12500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1150 : RB (Real.log ((3732213 : ℝ) / 100000000)) ((-41102111 : ℝ) / 12500000) ((-164408441 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((3732213 : ℝ) / 3125000)) (t := ((607213 : ℝ) / 6857213))
    (lo := ((17756707 : ℝ) / 100000000)) (hi := ((4439177 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3732213 : ℝ) / 100000000) = Real.log ((3732213 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3732213 : ℝ) / 100000000) = ((3732213 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1151 : RB (Real.log ((1900909 : ℝ) / 50000000)) ((-163484543 : ℝ) / 50000000) ((-8174227 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((1900909 : ℝ) / 1562500)) (t := ((338409 : ℝ) / 3463409))
    (lo := ((19604509 : ℝ) / 100000000)) (hi := ((1960451 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1900909 : ℝ) / 50000000) = Real.log ((1900909 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1900909 : ℝ) / 50000000) = ((1900909 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1152 : RB (Real.log ((16623433 : ℝ) / 25000000)) ((-40806251 : ℝ) / 100000000) ((-40806249 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((16623433 : ℝ) / 12500000)) (t := ((4123433 : ℝ) / 29123433))
    (lo := ((7127117 : ℝ) / 25000000)) (hi := ((28508469 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16623433 : ℝ) / 25000000) = Real.log ((16623433 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((16623433 : ℝ) / 25000000) = ((16623433 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1153 : RB (Real.log ((1329921 : ℝ) / 2000000)) ((-8160553 : ℝ) / 20000000) ((-40802763 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1329921 : ℝ) / 1000000)) (t := ((329921 : ℝ) / 2329921))
    (lo := ((14255977 : ℝ) / 50000000)) (hi := ((5702391 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1329921 : ℝ) / 2000000) = Real.log ((1329921 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((1329921 : ℝ) / 2000000) = ((1329921 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1154 : RB (Real.log ((1248811 : ℝ) / 3125000)) ((-1146553 : ℝ) / 1250000) ((-45862119 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1248811 : ℝ) / 1562500)) (t := ((-313689 : ℝ) / 2811311))
    (lo := ((-22409521 : ℝ) / 100000000)) (hi := ((-280119 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1248811 : ℝ) / 3125000) = Real.log ((1248811 : ℝ) / 1562500) - 1 * Real.log 2 := by
    rw [show ((1248811 : ℝ) / 3125000) = ((1248811 : ℝ) / 1562500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1155 : RB (Real.log ((96097491 : ℝ) / 50000000)) ((3266701 : ℝ) / 5000000) ((32667011 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((96097491 : ℝ) / 100000000)) (t := ((-3902509 : ℝ) / 196097491))
    (lo := ((-1990349 : ℝ) / 50000000)) (hi := ((-3980697 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((96097491 : ℝ) / 50000000) = Real.log ((96097491 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((96097491 : ℝ) / 50000000) = ((96097491 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1156 : RB (Real.log ((192326517 : ℝ) / 100000000)) ((13080487 : ℝ) / 20000000) ((65402437 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((192326517 : ℝ) / 200000000)) (t := ((-7673483 : ℝ) / 392326517))
    (lo := ((-3912283 : ℝ) / 100000000)) (hi := ((-1956141 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192326517 : ℝ) / 100000000) = Real.log ((192326517 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((192326517 : ℝ) / 100000000) = ((192326517 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1157 : RB (Real.log ((68295029 : ℝ) / 100000000)) ((-38133321 : ℝ) / 100000000) ((-953333 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((68295029 : ℝ) / 100000000)) (t := ((-31704971 : ℝ) / 168295029))
    (lo := ((-38133321 : ℝ) / 100000000)) (hi := ((-953333 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1158 : RB (Real.log ((17074343 : ℝ) / 25000000)) ((-3812989 : ℝ) / 10000000) ((-38129889 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17074343 : ℝ) / 25000000)) (t := ((-7925657 : ℝ) / 42074343))
    (lo := ((-3812989 : ℝ) / 10000000)) (hi := ((-38129889 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1159 : RB (Real.log ((5075569 : ℝ) / 12500000)) ((-45064501 : ℝ) / 50000000) ((-90129 : ℝ) / 100000) := by
  have hm := log_bounds_of_series (x := ((5075569 : ℝ) / 6250000)) (t := ((-1174431 : ℝ) / 11325569))
    (lo := ((-20814283 : ℝ) / 100000000)) (hi := ((-10407141 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5075569 : ℝ) / 12500000) = Real.log ((5075569 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((5075569 : ℝ) / 12500000) = ((5075569 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1160 : RB (Real.log ((420021421 : ℝ) / 100000000)) ((8969597 : ℝ) / 6250000) ((28702711 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((420021421 : ℝ) / 400000000)) (t := ((20021421 : ℝ) / 820021421))
    (lo := ((1221029 : ℝ) / 25000000)) (hi := ((4884117 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((420021421 : ℝ) / 100000000) = Real.log ((420021421 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((420021421 : ℝ) / 100000000) = ((420021421 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1161 : RB (Real.log ((3360207 : ℝ) / 800000)) ((35878653 : ℝ) / 25000000) ((28702923 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((3360207 : ℝ) / 3200000)) (t := ((160207 : ℝ) / 6560207))
    (lo := ((610647 : ℝ) / 12500000)) (hi := ((4885177 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3360207 : ℝ) / 800000) = Real.log ((3360207 : ℝ) / 3200000) + 2 * Real.log 2 := by
    rw [show ((3360207 : ℝ) / 800000) = ((3360207 : ℝ) / 3200000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1162 : RB (Real.log ((1640441 : ℝ) / 1250000)) ((5436431 : ℝ) / 20000000) ((6795539 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1640441 : ℝ) / 1250000)) (t := ((390441 : ℝ) / 2890441))
    (lo := ((5436431 : ℝ) / 20000000)) (hi := ((6795539 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1163 : RB (Real.log ((208371781 : ℝ) / 50000000)) ((17841261 : ℝ) / 12500000) ((142730091 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((208371781 : ℝ) / 200000000)) (t := ((8371781 : ℝ) / 408371781))
    (lo := ((1025163 : ℝ) / 25000000)) (hi := ((4100653 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((208371781 : ℝ) / 50000000) = Real.log ((208371781 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((208371781 : ℝ) / 50000000) = ((208371781 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1164 : RB (Real.log ((416747971 : ℝ) / 100000000)) ((71365573 : ℝ) / 50000000) ((142731149 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((416747971 : ℝ) / 400000000)) (t := ((16747971 : ℝ) / 816747971))
    (lo := ((410171 : ℝ) / 10000000)) (hi := ((4101711 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((416747971 : ℝ) / 100000000) = Real.log ((416747971 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((416747971 : ℝ) / 100000000) = ((416747971 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1165 : RB (Real.log ((65779261 : ℝ) / 50000000)) ((85713 : ℝ) / 312500) ((27428161 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65779261 : ℝ) / 50000000)) (t := ((15779261 : ℝ) / 115779261))
    (lo := ((85713 : ℝ) / 312500)) (hi := ((27428161 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1166 : RB (Real.log ((1255677 : ℝ) / 12500000)) ((-229805381 : ℝ) / 100000000) ((-229805377 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((1255677 : ℝ) / 1562500)) (t := ((-306823 : ℝ) / 2818177))
    (lo := ((-2732653 : ℝ) / 12500000)) (hi := ((-21861223 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1255677 : ℝ) / 12500000) = Real.log ((1255677 : ℝ) / 1562500) - 3 * Real.log 2 := by
    rw [show ((1255677 : ℝ) / 12500000) = ((1255677 : ℝ) / 1562500) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1167 : RB (Real.log ((5922753 : ℝ) / 50000000)) ((-106661083 : ℝ) / 50000000) ((-106661081 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5922753 : ℝ) / 6250000)) (t := ((-327247 : ℝ) / 12172753))
    (lo := ((-5378009 : ℝ) / 100000000)) (hi := ((-672251 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5922753 : ℝ) / 50000000) = Real.log ((5922753 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5922753 : ℝ) / 50000000) = ((5922753 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1168 : RB (Real.log ((3796617 : ℝ) / 100000000)) ((-327105983 : ℝ) / 100000000) ((-327105977 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3796617 : ℝ) / 3125000)) (t := ((671617 : ℝ) / 6921617))
    (lo := ((4866903 : ℝ) / 25000000)) (hi := ((19467613 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3796617 : ℝ) / 100000000) = Real.log ((3796617 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3796617 : ℝ) / 100000000) = ((3796617 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1169 : RB (Real.log ((3866317 : ℝ) / 100000000)) ((-162643393 : ℝ) / 50000000) ((-16264339 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((3866317 : ℝ) / 3125000)) (t := ((741317 : ℝ) / 6991317))
    (lo := ((21286809 : ℝ) / 100000000)) (hi := ((2128681 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3866317 : ℝ) / 100000000) = Real.log ((3866317 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3866317 : ℝ) / 100000000) = ((3866317 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1170 : RB (Real.log ((13259649 : ℝ) / 20000000)) ((-41100677 : ℝ) / 100000000) ((-1644027 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((13259649 : ℝ) / 10000000)) (t := ((3259649 : ℝ) / 23259649))
    (lo := ((14107021 : ℝ) / 50000000)) (hi := ((28214043 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13259649 : ℝ) / 20000000) = Real.log ((13259649 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((13259649 : ℝ) / 20000000) = ((13259649 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1171 : RB (Real.log ((13260121 : ℝ) / 20000000)) ((-20548559 : ℝ) / 50000000) ((-10274279 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((13260121 : ℝ) / 10000000)) (t := ((3260121 : ℝ) / 23260121))
    (lo := ((28217601 : ℝ) / 100000000)) (hi := ((14108801 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13260121 : ℝ) / 20000000) = Real.log ((13260121 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((13260121 : ℝ) / 20000000) = ((13260121 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1172 : RB (Real.log ((9973057 : ℝ) / 25000000)) ((-22974717 : ℝ) / 25000000) ((-45949433 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((9973057 : ℝ) / 12500000)) (t := ((-2526943 : ℝ) / 22473057))
    (lo := ((-22584149 : ℝ) / 100000000)) (hi := ((-5646037 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((9973057 : ℝ) / 25000000) = Real.log ((9973057 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((9973057 : ℝ) / 25000000) = ((9973057 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1173 : RB (Real.log ((19206341 : ℝ) / 10000000)) ((65265539 : ℝ) / 100000000) ((65265541 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19206341 : ℝ) / 20000000)) (t := ((-793659 : ℝ) / 39206341))
    (lo := ((-4049179 : ℝ) / 100000000)) (hi := ((-2024589 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19206341 : ℝ) / 10000000) = Real.log ((19206341 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((19206341 : ℝ) / 10000000) = ((19206341 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1174 : RB (Real.log ((192194989 : ℝ) / 100000000)) ((65334023 : ℝ) / 100000000) ((2613361 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((192194989 : ℝ) / 200000000)) (t := ((-7805011 : ℝ) / 392194989))
    (lo := ((-796139 : ℝ) / 20000000)) (hi := ((-1990347 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((192194989 : ℝ) / 100000000) = Real.log ((192194989 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((192194989 : ℝ) / 100000000) = ((192194989 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1175 : RB (Real.log ((68073619 : ℝ) / 100000000)) ((-9614511 : ℝ) / 25000000) ((-38458043 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((68073619 : ℝ) / 100000000)) (t := ((-31926381 : ℝ) / 168073619))
    (lo := ((-9614511 : ℝ) / 25000000)) (hi := ((-38458043 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1176 : RB (Real.log ((17019001 : ℝ) / 25000000)) ((-1922727 : ℝ) / 5000000) ((-38454539 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((17019001 : ℝ) / 25000000)) (t := ((-7980999 : ℝ) / 42019001))
    (lo := ((-1922727 : ℝ) / 5000000)) (hi := ((-38454539 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1177 : RB (Real.log ((40527151 : ℝ) / 100000000)) ((-45159903 : ℝ) / 50000000) ((-22579951 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((40527151 : ℝ) / 50000000)) (t := ((-9472849 : ℝ) / 90527151))
    (lo := ((-21005087 : ℝ) / 100000000)) (hi := ((-10502543 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40527151 : ℝ) / 100000000) = Real.log ((40527151 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40527151 : ℝ) / 100000000) = ((40527151 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1178 : RB (Real.log ((83782349 : ℝ) / 20000000)) ((143249007 : ℝ) / 100000000) ((14324901 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((83782349 : ℝ) / 80000000)) (t := ((3782349 : ℝ) / 163782349))
    (lo := ((4619571 : ℝ) / 100000000)) (hi := ((1154893 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((83782349 : ℝ) / 20000000) = Real.log ((83782349 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((83782349 : ℝ) / 20000000) = ((83782349 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1179 : RB (Real.log ((41891627 : ℝ) / 10000000)) ((143250087 : ℝ) / 100000000) ((14325009 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((41891627 : ℝ) / 40000000)) (t := ((1891627 : ℝ) / 81891627))
    (lo := ((4620651 : ℝ) / 100000000)) (hi := ((1155163 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41891627 : ℝ) / 10000000) = Real.log ((41891627 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((41891627 : ℝ) / 10000000) = ((41891627 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1180 : RB (Real.log ((131343521 : ℝ) / 100000000)) ((136323 : ℝ) / 500000) ((27264601 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((131343521 : ℝ) / 100000000)) (t := ((31343521 : ℝ) / 231343521))
    (lo := ((136323 : ℝ) / 500000)) (hi := ((27264601 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1181 : RB (Real.log ((207835601 : ℝ) / 50000000)) ((71236219 : ℝ) / 50000000) ((142472441 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((207835601 : ℝ) / 200000000)) (t := ((7835601 : ℝ) / 407835601))
    (lo := ((1921501 : ℝ) / 50000000)) (hi := ((3843003 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((207835601 : ℝ) / 50000000) = Real.log ((207835601 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((207835601 : ℝ) / 50000000) = ((207835601 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1182 : RB (Real.log ((415675681 : ℝ) / 100000000)) ((28494703 : ℝ) / 20000000) ((71236759 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((415675681 : ℝ) / 400000000)) (t := ((15675681 : ℝ) / 815675681))
    (lo := ((3844079 : ℝ) / 100000000)) (hi := ((48051 : ℝ) / 1250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((415675681 : ℝ) / 100000000) = Real.log ((415675681 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((415675681 : ℝ) / 100000000) = ((415675681 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1183 : RB (Real.log ((205727 : ℝ) / 156250)) ((1100371 : ℝ) / 4000000) ((6877319 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((205727 : ℝ) / 156250)) (t := ((49477 : ℝ) / 361977))
    (lo := ((1100371 : ℝ) / 4000000)) (hi := ((6877319 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1184 : RB (Real.log ((407207 : ℝ) / 4000000)) ((-114236401 : ℝ) / 50000000) ((-114236399 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((407207 : ℝ) / 500000)) (t := ((-92793 : ℝ) / 907207))
    (lo := ((-4105729 : ℝ) / 20000000)) (hi := ((-5132161 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((407207 : ℝ) / 4000000) = Real.log ((407207 : ℝ) / 500000) - 3 * Real.log 2 := by
    rw [show ((407207 : ℝ) / 4000000) = ((407207 : ℝ) / 500000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1185 : RB (Real.log ((5981669 : ℝ) / 50000000)) ((-212332341 : ℝ) / 100000000) ((-212332337 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5981669 : ℝ) / 6250000)) (t := ((-268331 : ℝ) / 12231669))
    (lo := ((-548523 : ℝ) / 12500000)) (hi := ((-4388183 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5981669 : ℝ) / 50000000) = Real.log ((5981669 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((5981669 : ℝ) / 50000000) = ((5981669 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1186 : RB (Real.log ((154441 : ℝ) / 4000000)) ((-65084751 : ℝ) / 20000000) ((-325423749 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((154441 : ℝ) / 125000)) (t := ((29441 : ℝ) / 279441))
    (lo := ((264373 : ℝ) / 1250000)) (hi := ((21149841 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((154441 : ℝ) / 4000000) = Real.log ((154441 : ℝ) / 125000) - 5 * Real.log 2 := by
    rw [show ((154441 : ℝ) / 4000000) = ((154441 : ℝ) / 125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1187 : RB (Real.log ((3930817 : ℝ) / 100000000)) ((-64726459 : ℝ) / 20000000) ((-323632289 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3930817 : ℝ) / 3125000)) (t := ((805817 : ℝ) / 7055817))
    (lo := ((229413 : ℝ) / 1000000)) (hi := ((22941301 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3930817 : ℝ) / 100000000) = Real.log ((3930817 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((3930817 : ℝ) / 100000000) = ((3930817 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1188 : RB (Real.log ((13221 : ℝ) / 20000)) ((-41392581 : ℝ) / 100000000) ((-41392579 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13221 : ℝ) / 10000)) (t := ((3221 : ℝ) / 23221))
    (lo := ((13961069 : ℝ) / 50000000)) (hi := ((27922139 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13221 : ℝ) / 20000) = Real.log ((13221 : ℝ) / 10000) - 1 * Real.log 2 := by
    rw [show ((13221 : ℝ) / 20000) = ((13221 : ℝ) / 10000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1189 : RB (Real.log ((330537 : ℝ) / 500000)) ((-41388951 : ℝ) / 100000000) ((-41388949 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((330537 : ℝ) / 250000)) (t := ((80537 : ℝ) / 580537))
    (lo := ((3490721 : ℝ) / 12500000)) (hi := ((27925769 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((330537 : ℝ) / 500000) = Real.log ((330537 : ℝ) / 250000) - 1 * Real.log 2 := by
    rw [show ((330537 : ℝ) / 500000) = ((330537 : ℝ) / 250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1190 : RB (Real.log ((622237 : ℝ) / 1562500)) ((-18414427 : ℝ) / 20000000) ((-92072133 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((622237 : ℝ) / 781250)) (t := ((-159013 : ℝ) / 1403487))
    (lo := ((-2844677 : ℝ) / 12500000)) (hi := ((-4551483 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((622237 : ℝ) / 1562500) = Real.log ((622237 : ℝ) / 781250) - 1 * Real.log 2 := by
    rw [show ((622237 : ℝ) / 1562500) = ((622237 : ℝ) / 781250) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1191 : RB (Real.log ((95965893 : ℝ) / 50000000)) ((8149623 : ℝ) / 12500000) ((32598493 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((95965893 : ℝ) / 100000000)) (t := ((-4034107 : ℝ) / 195965893))
    (lo := ((-2058867 : ℝ) / 50000000)) (hi := ((-4117733 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((95965893 : ℝ) / 50000000) = Real.log ((95965893 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((95965893 : ℝ) / 50000000) = ((95965893 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1192 : RB (Real.log ((96031707 : ℝ) / 50000000)) ((65265541 : ℝ) / 100000000) ((65265543 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((96031707 : ℝ) / 100000000)) (t := ((-3968293 : ℝ) / 196031707))
    (lo := ((-4049177 : ℝ) / 100000000)) (hi := ((-506147 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((96031707 : ℝ) / 50000000) = Real.log ((96031707 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((96031707 : ℝ) / 50000000) = ((96031707 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1193 : RB (Real.log ((33927863 : ℝ) / 50000000)) ((-19389321 : ℝ) / 50000000) ((-38778641 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33927863 : ℝ) / 50000000)) (t := ((-16072137 : ℝ) / 83927863))
    (lo := ((-19389321 : ℝ) / 50000000)) (hi := ((-38778641 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1194 : RB (Real.log ((8482269 : ℝ) / 12500000)) ((-19387533 : ℝ) / 50000000) ((-7755013 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((8482269 : ℝ) / 12500000)) (t := ((-4017731 : ℝ) / 20982269))
    (lo := ((-19387533 : ℝ) / 50000000)) (hi := ((-7755013 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1195 : RB (Real.log ((40450809 : ℝ) / 100000000)) ((-22627089 : ℝ) / 25000000) ((-45254177 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((40450809 : ℝ) / 50000000)) (t := ((-9549191 : ℝ) / 90450809))
    (lo := ((-21193637 : ℝ) / 100000000)) (hi := ((-5298409 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40450809 : ℝ) / 100000000) = Real.log ((40450809 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40450809 : ℝ) / 100000000) = ((40450809 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1196 : RB (Real.log ((417814677 : ℝ) / 100000000)) ((142986779 : ℝ) / 100000000) ((71493391 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((417814677 : ℝ) / 400000000)) (t := ((17814677 : ℝ) / 817814677))
    (lo := ((4357343 : ℝ) / 100000000)) (hi := ((136167 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((417814677 : ℝ) / 100000000) = Real.log ((417814677 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((417814677 : ℝ) / 100000000) = ((417814677 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1197 : RB (Real.log ((41781927 : ℝ) / 10000000)) ((71493939 : ℝ) / 50000000) ((142987881 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41781927 : ℝ) / 40000000)) (t := ((1781927 : ℝ) / 81781927))
    (lo := ((2179221 : ℝ) / 50000000)) (hi := ((4358443 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41781927 : ℝ) / 10000000) = Real.log ((41781927 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((41781927 : ℝ) / 10000000) = ((41781927 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1198 : RB (Real.log ((65725631 : ℝ) / 50000000)) ((6836649 : ℝ) / 25000000) ((27346597 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((65725631 : ℝ) / 50000000)) (t := ((15725631 : ℝ) / 115725631))
    (lo := ((6836649 : ℝ) / 25000000)) (hi := ((27346597 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1199 : RB (Real.log ((207305369 : ℝ) / 50000000)) ((142216991 : ℝ) / 100000000) ((71108497 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((207305369 : ℝ) / 200000000)) (t := ((7305369 : ℝ) / 407305369))
    (lo := ((717511 : ℝ) / 20000000)) (hi := ((896889 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((207305369 : ℝ) / 50000000) = Real.log ((207305369 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((207305369 : ℝ) / 50000000) = ((207305369 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
