import LeanProject.COVLogTwo
import LeanProject.COVLogBounds22
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_2080 : RB (Real.log ((11082333 : ℝ) / 25000000)) ((-40676181 : ℝ) / 50000000) ((-2033809 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((11082333 : ℝ) / 12500000)) (t := ((-1417667 : ℝ) / 23582333))
    (lo := ((-12037643 : ℝ) / 100000000)) (hi := ((-6018821 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((11082333 : ℝ) / 25000000) = Real.log ((11082333 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((11082333 : ℝ) / 25000000) = ((11082333 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2081 : RB (Real.log ((40263401 : ℝ) / 50000000)) ((-5414503 : ℝ) / 25000000) ((-21658011 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40263401 : ℝ) / 50000000)) (t := ((-9736599 : ℝ) / 90263401))
    (lo := ((-5414503 : ℝ) / 25000000)) (hi := ((-21658011 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2082 : RB (Real.log ((20131701 : ℝ) / 25000000)) ((-21658009 : ℝ) / 100000000) ((-2707251 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((20131701 : ℝ) / 25000000)) (t := ((-4868299 : ℝ) / 45131701))
    (lo := ((-21658009 : ℝ) / 100000000)) (hi := ((-2707251 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2083 : RB (Real.log ((22322489 : ℝ) / 50000000)) ((-80642837 : ℝ) / 100000000) ((-16128567 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((22322489 : ℝ) / 25000000)) (t := ((-2677511 : ℝ) / 47322489))
    (lo := ((-5664059 : ℝ) / 50000000)) (hi := ((-11328117 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22322489 : ℝ) / 50000000) = Real.log ((22322489 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22322489 : ℝ) / 50000000) = ((22322489 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2084 : RB (Real.log ((180640119 : ℝ) / 50000000)) ((1027587 : ℝ) / 800000) ((64224189 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((180640119 : ℝ) / 200000000)) (t := ((-19359881 : ℝ) / 380640119))
    (lo := ((-10181061 : ℝ) / 100000000)) (hi := ((-509053 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((180640119 : ℝ) / 50000000) = Real.log ((180640119 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((180640119 : ℝ) / 50000000) = ((180640119 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2085 : RB (Real.log ((180640121 : ℝ) / 50000000)) ((16056047 : ℝ) / 12500000) ((128448379 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((180640121 : ℝ) / 200000000)) (t := ((-19359879 : ℝ) / 380640121))
    (lo := ((-509053 : ℝ) / 5000000)) (hi := ((-10181059 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((180640121 : ℝ) / 50000000) = Real.log ((180640121 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((180640121 : ℝ) / 50000000) = ((180640121 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2086 : RB (Real.log ((6912327 : ℝ) / 5000000)) ((16193421 : ℝ) / 50000000) ((8096711 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((6912327 : ℝ) / 10000000)) (t := ((-3087673 : ℝ) / 16912327))
    (lo := ((-9231969 : ℝ) / 25000000)) (hi := ((-295423 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6912327 : ℝ) / 5000000) = Real.log ((6912327 : ℝ) / 10000000) + 1 * Real.log 2 := by
    rw [show ((6912327 : ℝ) / 5000000) = ((6912327 : ℝ) / 10000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2087 : RB (Real.log ((89154789 : ℝ) / 25000000)) ((127149823 : ℝ) / 100000000) ((63574913 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((89154789 : ℝ) / 100000000)) (t := ((-10845211 : ℝ) / 189154789))
    (lo := ((-11479613 : ℝ) / 100000000)) (hi := ((-2869903 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89154789 : ℝ) / 25000000) = Real.log ((89154789 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((89154789 : ℝ) / 25000000) = ((89154789 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2088 : RB (Real.log ((8915479 : ℝ) / 2500000)) ((496679 : ℝ) / 390625) ((127149827 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8915479 : ℝ) / 10000000)) (t := ((-1084521 : ℝ) / 18915479))
    (lo := ((-2869903 : ℝ) / 25000000)) (hi := ((-11479611 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8915479 : ℝ) / 2500000) = Real.log ((8915479 : ℝ) / 10000000) + 2 * Real.log 2 := by
    rw [show ((8915479 : ℝ) / 2500000) = ((8915479 : ℝ) / 10000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2089 : RB (Real.log ((34735307 : ℝ) / 25000000)) ((32888083 : ℝ) / 100000000) ((6577617 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((34735307 : ℝ) / 50000000)) (t := ((-15264693 : ℝ) / 84735307))
    (lo := ((-7285327 : ℝ) / 20000000)) (hi := ((-18213317 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34735307 : ℝ) / 25000000) = Real.log ((34735307 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((34735307 : ℝ) / 25000000) = ((34735307 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2090 : RB (Real.log ((700677 : ℝ) / 1250000)) ((-57885183 : ℝ) / 100000000) ((-57885181 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((700677 : ℝ) / 625000)) (t := ((75677 : ℝ) / 1325677))
    (lo := ((357173 : ℝ) / 3125000)) (hi := ((11429537 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((700677 : ℝ) / 1250000) = Real.log ((700677 : ℝ) / 625000) - 1 * Real.log 2 := by
    rw [show ((700677 : ℝ) / 1250000) = ((700677 : ℝ) / 625000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2091 : RB (Real.log ((463387 : ℝ) / 781250)) ((-26116633 : ℝ) / 50000000) ((-3264579 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((463387 : ℝ) / 390625)) (t := ((36381 : ℝ) / 427006))
    (lo := ((17081453 : ℝ) / 100000000)) (hi := ((8540727 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((463387 : ℝ) / 781250) = Real.log ((463387 : ℝ) / 390625) - 1 * Real.log 2 := by
    rw [show ((463387 : ℝ) / 781250) = ((463387 : ℝ) / 390625) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2092 : RB (Real.log ((15973443 : ℝ) / 20000000)) ((-899219 : ℝ) / 4000000) ((-11240237 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((15973443 : ℝ) / 20000000)) (t := ((-4026557 : ℝ) / 35973443))
    (lo := ((-899219 : ℝ) / 4000000)) (hi := ((-11240237 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2093 : RB (Real.log ((39933609 : ℝ) / 50000000)) ((-22480471 : ℝ) / 100000000) ((-2248047 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((39933609 : ℝ) / 50000000)) (t := ((-10066391 : ℝ) / 89933609))
    (lo := ((-22480471 : ℝ) / 100000000)) (hi := ((-2248047 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2094 : RB (Real.log ((44441987 : ℝ) / 100000000)) ((-10137319 : ℝ) / 12500000) ((-1621971 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((44441987 : ℝ) / 50000000)) (t := ((-5558013 : ℝ) / 94441987))
    (lo := ((-11783833 : ℝ) / 100000000)) (hi := ((-1472979 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44441987 : ℝ) / 100000000) = Real.log ((44441987 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44441987 : ℝ) / 100000000) = ((44441987 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2095 : RB (Real.log ((80821889 : ℝ) / 100000000)) ((-5323059 : ℝ) / 25000000) ((-4258447 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((80821889 : ℝ) / 100000000)) (t := ((-19178111 : ℝ) / 180821889))
    (lo := ((-5323059 : ℝ) / 25000000)) (hi := ((-4258447 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2096 : RB (Real.log ((80821891 : ℝ) / 100000000)) ((-21292233 : ℝ) / 100000000) ((-2661529 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((80821891 : ℝ) / 100000000)) (t := ((-19178109 : ℝ) / 180821891))
    (lo := ((-21292233 : ℝ) / 100000000)) (hi := ((-2661529 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2097 : RB (Real.log ((44735313 : ℝ) / 100000000)) ((-80440701 : ℝ) / 100000000) ((-80440699 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((44735313 : ℝ) / 50000000)) (t := ((-5264687 : ℝ) / 94735313))
    (lo := ((-5562991 : ℝ) / 50000000)) (hi := ((-11125981 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44735313 : ℝ) / 100000000) = Real.log ((44735313 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((44735313 : ℝ) / 100000000) = ((44735313 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2098 : RB (Real.log ((179828757 : ℝ) / 50000000)) ((31999551 : ℝ) / 25000000) ((127998207 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((179828757 : ℝ) / 200000000)) (t := ((-20171243 : ℝ) / 379828757))
    (lo := ((-166113 : ℝ) / 1562500)) (hi := ((-10631231 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((179828757 : ℝ) / 50000000) = Real.log ((179828757 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((179828757 : ℝ) / 50000000) = ((179828757 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2099 : RB (Real.log ((359657517 : ℝ) / 100000000)) ((31999551 : ℝ) / 25000000) ((127998207 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((359657517 : ℝ) / 400000000)) (t := ((-40342483 : ℝ) / 759657517))
    (lo := ((-166113 : ℝ) / 1562500)) (hi := ((-10631231 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((359657517 : ℝ) / 100000000) = Real.log ((359657517 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((359657517 : ℝ) / 100000000) = ((359657517 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2100 : RB (Real.log ((138485561 : ℝ) / 100000000)) ((8139897 : ℝ) / 25000000) ((3255959 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((138485561 : ℝ) / 200000000)) (t := ((-61514439 : ℝ) / 338485561))
    (lo := ((-3675513 : ℝ) / 10000000)) (hi := ((-36755129 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((138485561 : ℝ) / 100000000) = Real.log ((138485561 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((138485561 : ℝ) / 100000000) = ((138485561 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2101 : RB (Real.log ((177599689 : ℝ) / 50000000)) ((126750907 : ℝ) / 100000000) ((12675091 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((177599689 : ℝ) / 200000000)) (t := ((-22400311 : ℝ) / 377599689))
    (lo := ((-11878529 : ℝ) / 100000000)) (hi := ((-92801 : ℝ) / 781250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((177599689 : ℝ) / 50000000) = Real.log ((177599689 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((177599689 : ℝ) / 50000000) = ((177599689 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2102 : RB (Real.log ((355199381 : ℝ) / 100000000)) ((31687727 : ℝ) / 25000000) ((126750911 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((355199381 : ℝ) / 400000000)) (t := ((-44800619 : ℝ) / 755199381))
    (lo := ((-92801 : ℝ) / 781250)) (hi := ((-11878527 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((355199381 : ℝ) / 100000000) = Real.log ((355199381 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((355199381 : ℝ) / 100000000) = ((355199381 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2103 : RB (Real.log ((69578937 : ℝ) / 50000000)) ((2065243 : ℝ) / 6250000) ((3304389 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((69578937 : ℝ) / 100000000)) (t := ((-30421063 : ℝ) / 169578937))
    (lo := ((-3627083 : ℝ) / 10000000)) (hi := ((-36270829 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((69578937 : ℝ) / 50000000) = Real.log ((69578937 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((69578937 : ℝ) / 50000000) = ((69578937 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2104 : RB (Real.log ((58160669 : ℝ) / 100000000)) ((-27098043 : ℝ) / 50000000) ((-13549021 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((58160669 : ℝ) / 50000000)) (t := ((8160669 : ℝ) / 108160669))
    (lo := ((15118633 : ℝ) / 100000000)) (hi := ((7559317 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((58160669 : ℝ) / 100000000) = Real.log ((58160669 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((58160669 : ℝ) / 100000000) = ((58160669 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2105 : RB (Real.log ((15340647 : ℝ) / 25000000)) ((-48836987 : ℝ) / 100000000) ((-9767397 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((15340647 : ℝ) / 12500000)) (t := ((2840647 : ℝ) / 27840647))
    (lo := ((5119433 : ℝ) / 25000000)) (hi := ((20477733 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15340647 : ℝ) / 25000000) = Real.log ((15340647 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((15340647 : ℝ) / 25000000) = ((15340647 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2106 : RB (Real.log ((40102967 : ℝ) / 50000000)) ((-22057269 : ℝ) / 100000000) ((-5514317 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((40102967 : ℝ) / 50000000)) (t := ((-9897033 : ℝ) / 90102967))
    (lo := ((-22057269 : ℝ) / 100000000)) (hi := ((-5514317 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2107 : RB (Real.log ((80205937 : ℝ) / 100000000)) ((-4411453 : ℝ) / 20000000) ((-1378579 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((80205937 : ℝ) / 100000000)) (t := ((-19794063 : ℝ) / 180205937))
    (lo := ((-4411453 : ℝ) / 20000000)) (hi := ((-1378579 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2108 : RB (Real.log ((8909283 : ℝ) / 20000000)) ((-20215963 : ℝ) / 25000000) ((-1617277 : ℝ) / 2000000) := by
  have hm := log_bounds_of_series (x := ((8909283 : ℝ) / 10000000)) (t := ((-1090717 : ℝ) / 18909283))
    (lo := ((-11549133 : ℝ) / 100000000)) (hi := ((-2887283 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8909283 : ℝ) / 20000000) = Real.log ((8909283 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8909283 : ℝ) / 20000000) = ((8909283 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2109 : RB (Real.log ((1267167 : ℝ) / 1562500)) ((-20950341 : ℝ) / 100000000) ((-1047517 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((1267167 : ℝ) / 1562500)) (t := ((-295333 : ℝ) / 2829667))
    (lo := ((-20950341 : ℝ) / 100000000)) (hi := ((-1047517 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2110 : RB (Real.log ((81098691 : ℝ) / 100000000)) ((-20950337 : ℝ) / 100000000) ((-327349 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((81098691 : ℝ) / 100000000)) (t := ((-18901309 : ℝ) / 181098691))
    (lo := ((-20950337 : ℝ) / 100000000)) (hi := ((-327349 : ℝ) / 1562500)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2111 : RB (Real.log ((22409891 : ℝ) / 50000000)) ((-4012603 : ℝ) / 5000000) ((-40126029 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((22409891 : ℝ) / 25000000)) (t := ((-2590109 : ℝ) / 47409891))
    (lo := ((-10937341 : ℝ) / 100000000)) (hi := ((-546867 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22409891 : ℝ) / 50000000) = Real.log ((22409891 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22409891 : ℝ) / 50000000) = ((22409891 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2112 : RB (Real.log ((358106903 : ℝ) / 100000000)) ((15945767 : ℝ) / 12500000) ((127566139 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((358106903 : ℝ) / 400000000)) (t := ((-41893097 : ℝ) / 758106903))
    (lo := ((-110633 : ℝ) / 1000000)) (hi := ((-11063299 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((358106903 : ℝ) / 100000000) = Real.log ((358106903 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((358106903 : ℝ) / 100000000) = ((358106903 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2113 : RB (Real.log ((358106907 : ℝ) / 100000000)) ((127566137 : ℝ) / 100000000) ((6378307 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((358106907 : ℝ) / 400000000)) (t := ((-41893093 : ℝ) / 758106907))
    (lo := ((-11063299 : ℝ) / 100000000)) (hi := ((-5531649 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((358106907 : ℝ) / 100000000) = Real.log ((358106907 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((358106907 : ℝ) / 100000000) = ((358106907 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2114 : RB (Real.log ((4334899 : ℝ) / 3125000)) ((16363201 : ℝ) / 50000000) ((8181601 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4334899 : ℝ) / 6250000)) (t := ((-1915101 : ℝ) / 10584899))
    (lo := ((-9147079 : ℝ) / 25000000)) (hi := ((-7317663 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4334899 : ℝ) / 3125000) = Real.log ((4334899 : ℝ) / 6250000) + 1 * Real.log 2 := by
    rw [show ((4334899 : ℝ) / 3125000) = ((4334899 : ℝ) / 6250000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2115 : RB (Real.log ((88459683 : ℝ) / 25000000)) ((63183553 : ℝ) / 50000000) ((126367109 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((88459683 : ℝ) / 100000000)) (t := ((-11540317 : ℝ) / 188459683))
    (lo := ((-1226233 : ℝ) / 10000000)) (hi := ((-12262329 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((88459683 : ℝ) / 25000000) = Real.log ((88459683 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((88459683 : ℝ) / 25000000) = ((88459683 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2116 : RB (Real.log ((22114921 : ℝ) / 6250000)) ((126367107 : ℝ) / 100000000) ((12636711 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((22114921 : ℝ) / 25000000)) (t := ((-2885079 : ℝ) / 47114921))
    (lo := ((-12262329 : ℝ) / 100000000)) (hi := ((-1532791 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22114921 : ℝ) / 6250000) = Real.log ((22114921 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((22114921 : ℝ) / 6250000) = ((22114921 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2117 : RB (Real.log ((139367771 : ℝ) / 100000000)) ((2074663 : ℝ) / 6250000) ((3319461 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((139367771 : ℝ) / 200000000)) (t := ((-60632229 : ℝ) / 339367771))
    (lo := ((-3612011 : ℝ) / 10000000)) (hi := ((-36120109 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((139367771 : ℝ) / 100000000) = Real.log ((139367771 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((139367771 : ℝ) / 100000000) = ((139367771 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2118 : RB (Real.log ((7529483 : ℝ) / 12500000)) ((-12672557 : ℝ) / 25000000) ((-25345113 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((7529483 : ℝ) / 6250000)) (t := ((1279483 : ℝ) / 13779483))
    (lo := ((18624491 : ℝ) / 100000000)) (hi := ((4656123 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7529483 : ℝ) / 12500000) = Real.log ((7529483 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((7529483 : ℝ) / 12500000) = ((7529483 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2119 : RB (Real.log ((63385619 : ℝ) / 100000000)) ((-45593319 : ℝ) / 100000000) ((-45593317 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((63385619 : ℝ) / 50000000)) (t := ((13385619 : ℝ) / 113385619))
    (lo := ((118607 : ℝ) / 500000)) (hi := ((23721401 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((63385619 : ℝ) / 100000000) = Real.log ((63385619 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((63385619 : ℝ) / 100000000) = ((63385619 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2120 : RB (Real.log ((80522027 : ℝ) / 100000000)) ((-10831971 : ℝ) / 50000000) ((-21663941 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((80522027 : ℝ) / 100000000)) (t := ((-19477973 : ℝ) / 180522027))
    (lo := ((-10831971 : ℝ) / 50000000)) (hi := ((-21663941 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2121 : RB (Real.log ((8052203 : ℝ) / 10000000)) ((-10831969 : ℝ) / 50000000) ((-21663937 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((8052203 : ℝ) / 10000000)) (t := ((-1947797 : ℝ) / 18052203))
    (lo := ((-10831969 : ℝ) / 50000000)) (hi := ((-21663937 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2122 : RB (Real.log ((22321757 : ℝ) / 50000000)) ((-80646117 : ℝ) / 100000000) ((-16129223 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((22321757 : ℝ) / 25000000)) (t := ((-2678243 : ℝ) / 47321757))
    (lo := ((-5665699 : ℝ) / 50000000)) (hi := ((-11331397 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22321757 : ℝ) / 50000000) = Real.log ((22321757 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22321757 : ℝ) / 50000000) = ((22321757 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2123 : RB (Real.log ((40679443 : ℝ) / 50000000)) ((-20630013 : ℝ) / 100000000) ((-5157503 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((40679443 : ℝ) / 50000000)) (t := ((-9320557 : ℝ) / 90679443))
    (lo := ((-20630013 : ℝ) / 100000000)) (hi := ((-5157503 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2124 : RB (Real.log ((81358889 : ℝ) / 100000000)) ((-20630009 : ℝ) / 100000000) ((-2578751 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((81358889 : ℝ) / 100000000)) (t := ((-18641111 : ℝ) / 181358889))
    (lo := ((-20630009 : ℝ) / 100000000)) (hi := ((-2578751 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2125 : RB (Real.log ((897979 : ℝ) / 2000000)) ((-80075579 : ℝ) / 100000000) ((-80075577 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((897979 : ℝ) / 1000000)) (t := ((-102021 : ℝ) / 1897979))
    (lo := ((-538043 : ℝ) / 5000000)) (hi := ((-10760859 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((897979 : ℝ) / 2000000) = Real.log ((897979 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((897979 : ℝ) / 2000000) = ((897979 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2126 : RB (Real.log ((356623697 : ℝ) / 100000000)) ((15893887 : ℝ) / 12500000) ((127151099 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((356623697 : ℝ) / 400000000)) (t := ((-43376303 : ℝ) / 756623697))
    (lo := ((-573917 : ℝ) / 5000000)) (hi := ((-11478339 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356623697 : ℝ) / 100000000) = Real.log ((356623697 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((356623697 : ℝ) / 100000000) = ((356623697 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2127 : RB (Real.log ((356623701 : ℝ) / 100000000)) ((127151097 : ℝ) / 100000000) ((1271511 : ℝ) / 1000000) := by
  have hm := log_bounds_of_series (x := ((356623701 : ℝ) / 400000000)) (t := ((-43376299 : ℝ) / 756623701))
    (lo := ((-11478339 : ℝ) / 100000000)) (hi := ((-5739169 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356623701 : ℝ) / 100000000) = Real.log ((356623701 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((356623701 : ℝ) / 100000000) = ((356623701 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2128 : RB (Real.log ((138940539 : ℝ) / 100000000)) ((32887587 : ℝ) / 100000000) ((32887589 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((138940539 : ℝ) / 200000000)) (t := ((-61059461 : ℝ) / 338940539))
    (lo := ((-36427131 : ℝ) / 100000000)) (hi := ((-3642713 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((138940539 : ℝ) / 100000000) = Real.log ((138940539 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((138940539 : ℝ) / 100000000) = ((138940539 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2129 : RB (Real.log ((176266799 : ℝ) / 50000000)) ((62998787 : ℝ) / 50000000) ((125997577 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((176266799 : ℝ) / 200000000)) (t := ((-23733201 : ℝ) / 376266799))
    (lo := ((-6315931 : ℝ) / 50000000)) (hi := ((-12631861 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((176266799 : ℝ) / 50000000) = Real.log ((176266799 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((176266799 : ℝ) / 50000000) = ((176266799 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2130 : RB (Real.log ((352533601 : ℝ) / 100000000)) ((5039903 : ℝ) / 4000000) ((62998789 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((352533601 : ℝ) / 400000000)) (t := ((-47466399 : ℝ) / 752533601))
    (lo := ((-12631861 : ℝ) / 100000000)) (hi := ((-631593 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((352533601 : ℝ) / 100000000) = Real.log ((352533601 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((352533601 : ℝ) / 100000000) = ((352533601 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2131 : RB (Real.log ((13957123 : ℝ) / 10000000)) ((33340489 : ℝ) / 100000000) ((33340491 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13957123 : ℝ) / 20000000)) (t := ((-6042877 : ℝ) / 33957123))
    (lo := ((-35974229 : ℝ) / 100000000)) (hi := ((-8993557 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13957123 : ℝ) / 10000000) = Real.log ((13957123 : ℝ) / 20000000) + 1 * Real.log 2 := by
    rw [show ((13957123 : ℝ) / 10000000) = ((13957123 : ℝ) / 20000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2132 : RB (Real.log ((31140919 : ℝ) / 50000000)) ((-23675017 : ℝ) / 50000000) ((-2959377 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((31140919 : ℝ) / 25000000)) (t := ((6140919 : ℝ) / 56140919))
    (lo := ((4392937 : ℝ) / 20000000)) (hi := ((10982343 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31140919 : ℝ) / 50000000) = Real.log ((31140919 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((31140919 : ℝ) / 50000000) = ((31140919 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2133 : RB (Real.log ((13076803 : ℝ) / 20000000)) ((-42489239 : ℝ) / 100000000) ((-42489237 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13076803 : ℝ) / 10000000)) (t := ((3076803 : ℝ) / 23076803))
    (lo := ((670637 : ℝ) / 2500000)) (hi := ((26825481 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((13076803 : ℝ) / 20000000) = Real.log ((13076803 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((13076803 : ℝ) / 20000000) = ((13076803 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2134 : RB (Real.log ((20204439 : ℝ) / 25000000)) ((-425947 : ℝ) / 2000000) ((-21297349 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((20204439 : ℝ) / 25000000)) (t := ((-4795561 : ℝ) / 45204439))
    (lo := ((-425947 : ℝ) / 2000000)) (hi := ((-21297349 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2135 : RB (Real.log ((80817759 : ℝ) / 100000000)) ((-10648673 : ℝ) / 50000000) ((-4259469 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((80817759 : ℝ) / 100000000)) (t := ((-19182241 : ℝ) / 180817759))
    (lo := ((-10648673 : ℝ) / 50000000)) (hi := ((-4259469 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2136 : RB (Real.log ((894681 : ℝ) / 2000000)) ((-20110881 : ℝ) / 25000000) ((-40221761 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((894681 : ℝ) / 1000000)) (t := ((-105319 : ℝ) / 1894681))
    (lo := ((-2225761 : ℝ) / 20000000)) (hi := ((-2782201 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((894681 : ℝ) / 2000000) = Real.log ((894681 : ℝ) / 1000000) - 1 * Real.log 2 := by
    rw [show ((894681 : ℝ) / 2000000) = ((894681 : ℝ) / 1000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2137 : RB (Real.log ((81603971 : ℝ) / 100000000)) ((-20329227 : ℝ) / 100000000) ((-10164613 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((81603971 : ℝ) / 100000000)) (t := ((-18396029 : ℝ) / 181603971))
    (lo := ((-20329227 : ℝ) / 100000000)) (hi := ((-10164613 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2138 : RB (Real.log ((40801987 : ℝ) / 50000000)) ((-20329223 : ℝ) / 100000000) ((-10164611 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((40801987 : ℝ) / 50000000)) (t := ((-9198013 : ℝ) / 90801987))
    (lo := ((-20329223 : ℝ) / 100000000)) (hi := ((-10164611 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2139 : RB (Real.log ((175677 : ℝ) / 390625)) ((-15982019 : ℝ) / 20000000) ((-79910093 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((351354 : ℝ) / 390625)) (t := ((-39271 : ℝ) / 741979))
    (lo := ((-662211 : ℝ) / 6250000)) (hi := ((-84763 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((175677 : ℝ) / 390625) = Real.log ((351354 : ℝ) / 390625) - 1 * Real.log 2 := by
    rw [show ((175677 : ℝ) / 390625) = ((351354 : ℝ) / 390625) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2140 : RB (Real.log ((88800897 : ℝ) / 25000000)) ((31688023 : ℝ) / 25000000) ((25350419 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((88800897 : ℝ) / 100000000)) (t := ((-11199103 : ℝ) / 188800897))
    (lo := ((-371167 : ℝ) / 3125000)) (hi := ((-11877343 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((88800897 : ℝ) / 25000000) = Real.log ((88800897 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((88800897 : ℝ) / 25000000) = ((88800897 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2141 : RB (Real.log ((44400449 : ℝ) / 12500000)) ((126752093 : ℝ) / 100000000) ((3961003 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((44400449 : ℝ) / 50000000)) (t := ((-5599551 : ℝ) / 94400449))
    (lo := ((-11877343 : ℝ) / 100000000)) (hi := ((-5938671 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((44400449 : ℝ) / 12500000) = Real.log ((44400449 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((44400449 : ℝ) / 12500000) = ((44400449 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2142 : RB (Real.log ((34789307 : ℝ) / 25000000)) ((1032607 : ℝ) / 3125000) ((16521713 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((34789307 : ℝ) / 50000000)) (t := ((-15210693 : ℝ) / 84789307))
    (lo := ((-18135647 : ℝ) / 50000000)) (hi := ((-36271293 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34789307 : ℝ) / 25000000) = Real.log ((34789307 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((34789307 : ℝ) / 25000000) = ((34789307 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2143 : RB (Real.log ((351280637 : ℝ) / 100000000)) ((5025661 : ℝ) / 4000000) ((15705191 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((351280637 : ℝ) / 400000000)) (t := ((-48719363 : ℝ) / 751280637))
    (lo := ((-12987911 : ℝ) / 100000000)) (hi := ((-1298791 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((351280637 : ℝ) / 100000000) = Real.log ((351280637 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((351280637 : ℝ) / 100000000) = ((351280637 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2144 : RB (Real.log ((351280641 : ℝ) / 100000000)) ((62820763 : ℝ) / 50000000) ((125641529 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((351280641 : ℝ) / 400000000)) (t := ((-48719359 : ℝ) / 751280641))
    (lo := ((-1298791 : ℝ) / 10000000)) (hi := ((-12987909 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((351280641 : ℝ) / 100000000) = Real.log ((351280641 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((351280641 : ℝ) / 100000000) = ((351280641 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2145 : RB (Real.log ((4367767 : ℝ) / 3125000)) ((33481761 : ℝ) / 100000000) ((33481763 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((4367767 : ℝ) / 6250000)) (t := ((-1882233 : ℝ) / 10617767))
    (lo := ((-35832957 : ℝ) / 100000000)) (hi := ((-8958239 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4367767 : ℝ) / 3125000) = Real.log ((4367767 : ℝ) / 6250000) + 1 * Real.log 2 := by
    rw [show ((4367767 : ℝ) / 3125000) = ((4367767 : ℝ) / 6250000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2146 : RB (Real.log ((8037553 : ℝ) / 12500000)) ((-22080199 : ℝ) / 50000000) ((-11040099 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((8037553 : ℝ) / 6250000)) (t := ((1787553 : ℝ) / 14287553))
    (lo := ((25154321 : ℝ) / 100000000)) (hi := ((12577161 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8037553 : ℝ) / 12500000) = Real.log ((8037553 : ℝ) / 6250000) - 1 * Real.log 2 := by
    rw [show ((8037553 : ℝ) / 12500000) = ((8037553 : ℝ) / 6250000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2147 : RB (Real.log ((67359019 : ℝ) / 100000000)) ((-19756669 : ℝ) / 50000000) ((-39513337 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((67359019 : ℝ) / 100000000)) (t := ((-32640981 : ℝ) / 167359019))
    (lo := ((-19756669 : ℝ) / 50000000)) (hi := ((-39513337 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2148 : RB (Real.log ((81095091 : ℝ) / 100000000)) ((-2619347 : ℝ) / 12500000) ((-838191 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((81095091 : ℝ) / 100000000)) (t := ((-18904909 : ℝ) / 181095091))
    (lo := ((-2619347 : ℝ) / 12500000)) (hi := ((-838191 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2149 : RB (Real.log ((40547547 : ℝ) / 50000000)) ((-5238693 : ℝ) / 25000000) ((-20954771 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40547547 : ℝ) / 50000000)) (t := ((-9452453 : ℝ) / 90547547))
    (lo := ((-5238693 : ℝ) / 25000000)) (hi := ((-20954771 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2150 : RB (Real.log ((22409343 : ℝ) / 50000000)) ((-16050901 : ℝ) / 20000000) ((-80254503 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((22409343 : ℝ) / 25000000)) (t := ((-2590657 : ℝ) / 47409343))
    (lo := ((-5469893 : ℝ) / 50000000)) (hi := ((-2187957 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22409343 : ℝ) / 50000000) = Real.log ((22409343 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((22409343 : ℝ) / 50000000) = ((22409343 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2151 : RB (Real.log ((10229407 : ℝ) / 12500000)) ((-5011551 : ℝ) / 25000000) ((-20046203 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((10229407 : ℝ) / 12500000)) (t := ((-2270593 : ℝ) / 22729407))
    (lo := ((-5011551 : ℝ) / 25000000)) (hi := ((-20046203 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2152 : RB (Real.log ((81835259 : ℝ) / 100000000)) ((-100231 : ℝ) / 500000) ((-20046199 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((81835259 : ℝ) / 100000000)) (t := ((-18164741 : ℝ) / 181835259))
    (lo := ((-100231 : ℝ) / 500000)) (hi := ((-20046199 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_2153 : RB (Real.log ((45043303 : ℝ) / 100000000)) ((-19938647 : ℝ) / 25000000) ((-39877293 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((45043303 : ℝ) / 50000000)) (t := ((-4956697 : ℝ) / 95043303))
    (lo := ((-10439869 : ℝ) / 100000000)) (hi := ((-2609967 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45043303 : ℝ) / 100000000) = Real.log ((45043303 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((45043303 : ℝ) / 100000000) = ((45043303 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2154 : RB (Real.log ((176921323 : ℝ) / 50000000)) ((31592053 : ℝ) / 25000000) ((25273643 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((176921323 : ℝ) / 200000000)) (t := ((-23078677 : ℝ) / 376921323))
    (lo := ((-1532653 : ℝ) / 12500000)) (hi := ((-12261223 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((176921323 : ℝ) / 50000000) = Real.log ((176921323 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((176921323 : ℝ) / 50000000) = ((176921323 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2155 : RB (Real.log ((7076853 : ℝ) / 2000000)) ((126368213 : ℝ) / 100000000) ((15796027 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((7076853 : ℝ) / 8000000)) (t := ((-923147 : ℝ) / 15076853))
    (lo := ((-12261223 : ℝ) / 100000000)) (hi := ((-6130611 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7076853 : ℝ) / 2000000) = Real.log ((7076853 : ℝ) / 8000000) + 2 * Real.log 2 := by
    rw [show ((7076853 : ℝ) / 2000000) = ((7076853 : ℝ) / 8000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2156 : RB (Real.log ((34841791 : ℝ) / 25000000)) ((33194173 : ℝ) / 100000000) ((1327767 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((34841791 : ℝ) / 50000000)) (t := ((-15158209 : ℝ) / 84841791))
    (lo := ((-7224109 : ℝ) / 20000000)) (hi := ((-1128767 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((34841791 : ℝ) / 25000000) = Real.log ((34841791 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((34841791 : ℝ) / 25000000) = ((34841791 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2157 : RB (Real.log ((350076791 : ℝ) / 100000000)) ((62649117 : ℝ) / 50000000) ((125298237 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((350076791 : ℝ) / 400000000)) (t := ((-49923209 : ℝ) / 750076791))
    (lo := ((-6665601 : ℝ) / 50000000)) (hi := ((-13331201 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((350076791 : ℝ) / 100000000) = Real.log ((350076791 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((350076791 : ℝ) / 100000000) = ((350076791 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2158 : RB (Real.log ((70015359 : ℝ) / 20000000)) ((25059647 : ℝ) / 20000000) ((62649119 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((70015359 : ℝ) / 80000000)) (t := ((-9984641 : ℝ) / 150015359))
    (lo := ((-13331201 : ℝ) / 100000000)) (hi := ((-2083 : ℝ) / 15625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((70015359 : ℝ) / 20000000) = Real.log ((70015359 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((70015359 : ℝ) / 20000000) = ((70015359 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_2159 : RB (Real.log ((69979993 : ℝ) / 50000000)) ((16809319 : ℝ) / 50000000) ((420233 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((69979993 : ℝ) / 100000000)) (t := ((-30020007 : ℝ) / 169979993))
    (lo := ((-446201 : ℝ) / 1250000)) (hi := ((-35696079 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((69979993 : ℝ) / 50000000) = Real.log ((69979993 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((69979993 : ℝ) / 50000000) = ((69979993 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
