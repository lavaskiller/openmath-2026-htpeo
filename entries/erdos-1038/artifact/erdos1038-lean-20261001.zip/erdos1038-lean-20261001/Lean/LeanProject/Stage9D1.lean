import LeanProject.Stage9C

/-!
# EP-1038, Stage 9, Lemma A′ step (1): the `L¹` modulus of translations of `log`

`om α β a b = ∫_α^β |log|y - a| - log|y - b|| dy` (Mathlib's `Real.log` is even, so `log (y - a)`
is `log |y - a|`). For `a ≤ b` with midpoint `m ∈ [α, β]`, the integrand has the sign of `y - m`
(off the point `y = a` resp. `y = b`), so `om = Om` with an explicit expression in
`L(z) = z log z - z` (`om_eq`). `Om` is continuous with `Om a a = 0`, which gives the uniform modulus
`om_small` and the bound `om_bdd` on compact squares.
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage9

/-- `L(z) = z log z - z`, an antiderivative of `log |z|`. -/
noncomputable def Lf (z : ℝ) : ℝ := z * Real.log z - z

theorem Lf_continuous : Continuous Lf := Real.continuous_mul_log.sub continuous_id

theorem ii_log_sub (α β t : ℝ) : IntervalIntegrable (fun y => Real.log (y - t)) volume α β := by
  have h := (intervalIntegrable_log' (a := α - t) (b := β - t)).comp_sub_right t
  simpa using h

theorem integral_log_sub (α β t : ℝ) :
    ∫ y in α..β, Real.log (y - t) = Lf (β - t) - Lf (α - t) := by
  rw [intervalIntegral.integral_comp_sub_right (fun y => Real.log y) t, integral_log]
  unfold Lf
  ring

/-- `om α β a b = ∫_α^β |log|y - a| - log|y - b||`. -/
noncomputable def om (α β a b : ℝ) : ℝ := ∫ y in α..β, |Real.log (y - a) - Real.log (y - b)|

/-- The explicit value of `om` for `a ≤ b` (midpoint split). -/
noncomputable def Om (α β a b : ℝ) : ℝ :=
  (Lf (β - a) - Lf ((a + b) / 2 - a)) - (Lf (β - b) - Lf ((a + b) / 2 - b))
    - ((Lf ((a + b) / 2 - a) - Lf (α - a)) - (Lf ((a + b) / 2 - b) - Lf (α - b)))

theorem om_comm (α β a b : ℝ) : om α β a b = om α β b a := by
  unfold om
  congr 1
  funext y
  rw [abs_sub_comm]

theorem om_nonneg {α β : ℝ} (h : α ≤ β) (a b : ℝ) : 0 ≤ om α β a b :=
  intervalIntegral.integral_nonneg h fun _ _ => abs_nonneg _

theorem Om_self (α β a : ℝ) : Om α β a a = 0 := by
  unfold Om
  ring

theorem Om_continuous (α β : ℝ) : Continuous fun p : ℝ × ℝ => Om α β p.1 p.2 := by
  unfold Om
  have hL := Lf_continuous
  fun_prop

theorem log_sub_le_of_abs {x y : ℝ} (hx : x ≠ 0) (h : |x| ≤ |y|) : Real.log x ≤ Real.log y := by
  rw [← Real.log_abs x, ← Real.log_abs y]
  exact Real.log_le_log (abs_pos.mpr hx) h

theorem ae_ne_real (a : ℝ) : ∀ᵐ y ∂(volume : Measure ℝ), y ≠ a := by
  rw [ae_iff]
  simp

theorem om_eq {α β a b : ℝ} (hab : a ≤ b) (hαm : α ≤ (a + b) / 2) (hmβ : (a + b) / 2 ≤ β) :
    om α β a b = Om α β a b := by
  set m := (a + b) / 2 with hm
  have hi : ∀ c d : ℝ, IntervalIntegrable (fun y => Real.log (y - a) - Real.log (y - b)) volume c d :=
    fun c d => (ii_log_sub c d a).sub (ii_log_sub c d b)
  unfold om
  rw [← intervalIntegral.integral_add_adjacent_intervals (b := m) (hi α m).abs (hi m β).abs]
  have h1 : ∫ y in α..m, |Real.log (y - a) - Real.log (y - b)| =
      ∫ y in α..m, -(Real.log (y - a) - Real.log (y - b)) := by
    refine intervalIntegral.integral_congr_ae ?_
    filter_upwards [ae_ne_real a] with y hya hy
    rw [uIoc_of_le hαm] at hy
    have hle : Real.log (y - a) ≤ Real.log (y - b) := by
      refine log_sub_le_of_abs (sub_ne_zero.mpr hya) ?_
      apply sq_le_sq.mp
      nlinarith [hy.2]
    rw [abs_of_nonpos (by linarith)]
  have h2 : ∫ y in m..β, |Real.log (y - a) - Real.log (y - b)| =
      ∫ y in m..β, (Real.log (y - a) - Real.log (y - b)) := by
    refine intervalIntegral.integral_congr_ae ?_
    filter_upwards [ae_ne_real b] with y hyb hy
    rw [uIoc_of_le hmβ] at hy
    have hle : Real.log (y - b) ≤ Real.log (y - a) := by
      refine log_sub_le_of_abs (sub_ne_zero.mpr hyb) ?_
      apply sq_le_sq.mp
      nlinarith [hy.1]
    rw [abs_of_nonneg (by linarith)]
  rw [h1, h2, intervalIntegral.integral_neg, intervalIntegral.integral_sub (ii_log_sub _ _ a)
    (ii_log_sub _ _ b), intervalIntegral.integral_sub (ii_log_sub _ _ a) (ii_log_sub _ _ b),
    integral_log_sub, integral_log_sub, integral_log_sub, integral_log_sub]
  unfold Om
  ring

/-- **Uniform modulus**: `om α β a b ≤ η` once `|a - b| ≤ δ`, for `a, b ∈ [a₀, b₀] ⊆ [α, β]`. -/
theorem om_small {α β a0 b0 : ℝ} (hα : α ≤ a0) (hβ : b0 ≤ β) {η : ℝ} (hη : 0 < η) :
    ∃ δ > 0, ∀ a b, a ∈ Icc a0 b0 → b ∈ Icc a0 b0 → |a - b| ≤ δ → om α β a b ≤ η := by
  have hK : IsCompact (Icc a0 b0 ×ˢ Icc a0 b0) := isCompact_Icc.prod isCompact_Icc
  have hU := hK.uniformContinuousOn_of_continuous (Om_continuous α β).continuousOn
  rw [Metric.uniformContinuousOn_iff] at hU
  obtain ⟨δ, hδ, hδU⟩ := hU η hη
  refine ⟨δ / 2, by linarith, ?_⟩
  -- the case `a ≤ b`
  have key : ∀ a b, a ∈ Icc a0 b0 → b ∈ Icc a0 b0 → a ≤ b → b - a ≤ δ / 2 → om α β a b ≤ η := by
    intro a b ha hb hab hd
    rw [om_eq hab (by linarith [ha.1, hb.1]) (by linarith [ha.2, hb.2])]
    have hdist : dist (a, b) (a, a) < δ := by
      rw [Prod.dist_eq, dist_self, Real.dist_eq, abs_of_nonneg (by linarith)]
      simp only [max_eq_right (show (0:ℝ) ≤ b - a by linarith)]
      linarith
    have := hδU (a, b) ⟨ha, hb⟩ (a, a) ⟨ha, ha⟩ hdist
    rw [Real.dist_eq, Om_self, sub_zero] at this
    exact (le_abs_self _).trans this.le
  intro a b ha hb hd
  rcases le_total a b with hab | hab
  · exact key a b ha hb hab (by rw [abs_sub_comm, abs_of_nonneg (by linarith)] at hd; exact hd)
  · rw [om_comm]
    exact key b a hb ha hab (by rw [abs_of_nonneg (by linarith)] at hd; exact hd)

/-- `om` is bounded on compact squares. -/
theorem om_bdd {α β a0 b0 : ℝ} (hα : α ≤ a0) (hβ : b0 ≤ β) :
    ∃ M, ∀ a b, a ∈ Icc a0 b0 → b ∈ Icc a0 b0 → om α β a b ≤ M := by
  have hK : IsCompact (Icc a0 b0 ×ˢ Icc a0 b0) := isCompact_Icc.prod isCompact_Icc
  obtain ⟨C, hC⟩ := hK.exists_bound_of_continuousOn (Om_continuous α β).continuousOn
  refine ⟨C, fun a b ha hb => ?_⟩
  have key : ∀ a b, a ∈ Icc a0 b0 → b ∈ Icc a0 b0 → a ≤ b → om α β a b ≤ C := by
    intro a b ha hb hab
    rw [om_eq hab (by linarith [ha.1, hb.1]) (by linarith [ha.2, hb.2])]
    exact (le_abs_self _).trans (hC (a, b) ⟨ha, hb⟩)
  rcases le_total a b with hab | hab
  · exact key a b ha hb hab
  · rw [om_comm]; exact key b a hb ha hab

end EP1038.Stage9
