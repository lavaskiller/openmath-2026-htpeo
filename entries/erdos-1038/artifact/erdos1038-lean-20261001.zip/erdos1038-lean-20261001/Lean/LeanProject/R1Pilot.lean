import LeanProject.CertificateEndpoints
import Mathlib.Analysis.SpecialFunctions.Log.Deriv

/-!
# An actual negative certificate on a small middle-R1 slab

All logarithmic bounds below follow from a finite rational series and a proved
remainder bound. No external numerical checker is assumed correct.
-/

open Real Set Finset

namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12

theorem log_series_lower {x t : ℝ} (ht0 : 0 ≤ t) (ht1 : t < 1)
    (hx : x = (1 + t) / (1 - t)) (n : ℕ) :
    2 * (∑ i ∈ range n, t ^ (2 * i + 1) / (2 * i + 1)) ≤ Real.log x := by
  have h := Real.sum_range_le_log_div ht0 ht1 n
  rw [← hx] at h
  linarith

theorem log_series_upper {x t : ℝ} (ht0 : 0 ≤ t) (ht1 : t < 1)
    (hx : x = (1 + t) / (1 - t)) (n : ℕ) :
    Real.log x ≤ 2 * ((∑ i ∈ range n, t ^ (2 * i + 1) / (2 * i + 1)) +
      t ^ (2 * n + 1) / (1 - t ^ 2)) := by
  have h := Real.log_div_le_sum_range_add ht0 ht1 n
  rw [← hx] at h
  linarith

theorem log_bounds_of_series {x t lo hi : ℝ} (ht : |t| < 1)
    (hx : x = (1 + t) / (1 - t)) (n : ℕ)
    (hlo : lo ≤ 2 * ((∑ i ∈ range n, t ^ (2 * i + 1) / (2 * i + 1)) -
      |t| ^ (2 * n + 1) / (1 - t ^ 2)))
    (hhi : 2 * ((∑ i ∈ range n, t ^ (2 * i + 1) / (2 * i + 1)) +
      |t| ^ (2 * n + 1) / (1 - t ^ 2)) ≤ hi) : lo ≤ Real.log x ∧ Real.log x ≤ hi := by
  have h := Real.sum_range_sub_log_div_le ht n
  rw [← hx, abs_le] at h
  constructor <;> linarith [h.1, h.2]

theorem pilot_log_16_9_lower : (5753 : ℝ) / 10000 ≤ Real.log (16 / 9) := by
  have h := log_series_lower (t := (7 : ℝ) / 25) (by norm_num) (by norm_num)
    (x := (16 : ℝ) / 9) (by norm_num) 4
  norm_num [sum_range_succ] at h
  linarith

theorem pilot_log_25_9_upper : Real.log ((25 : ℝ) / 9) ≤ 10217 / 10000 := by
  have h := log_series_upper (t := (8 : ℝ) / 17) (by norm_num) (by norm_num)
    (x := (25 : ℝ) / 9) (by norm_num) 8
  norm_num [sum_range_succ] at h
  linarith

theorem pilot_log_D_lower : (6559 : ℝ) / 10000 ≤ Real.log (1927 / 1000) := by
  have h := log_series_lower (t := (927 : ℝ) / 2927) (by norm_num) (by norm_num)
    (x := (1927 : ℝ) / 1000) (by norm_num) 4
  norm_num [sum_range_succ] at h
  linarith

def pilotSlab : Set ℝ := Icc (9 / 5 : ℝ) (9001 / 5000)

theorem pilot_slab_subset : pilotSlab ⊆ Icc (36 / 25 : ℝ) (21 / 10) := by
  intro k hk
  constructor <;> linarith [hk.1, hk.2]

theorem pilot_a_bounds {k : ℝ} (hk : k ∈ pilotSlab) :
    18559 / 10000 ≤ r1A k ∧ r1A k ≤ 232 / 125 := by
  unfold r1A
  constructor <;> linarith [hk.1, hk.2]

theorem pilot_D0_lower {k : ℝ} (hk : k ∈ pilotSlab) : 1927 / 1000 ≤ D0a (r1A k) := by
  have ha := r1_a_pos (pilot_slab_subset hk)
  have hs := Real.sqrt_nonneg (r1A k)
  have h2 := Real.sqrt_nonneg (2 : ℝ)
  have hsq := Real.sq_sqrt ha.le
  have hsq2 := Real.sq_sqrt (show (0 : ℝ) ≤ 2 by norm_num)
  have hsa : (13623 : ℝ) / 10000 ≤ √(r1A k) := by
    nlinarith [(pilot_a_bounds hk).1]
  have hs2 : (14142 : ℝ) / 10000 ≤ √2 := by nlinarith
  have hsum : (27765 : ℝ) / 10000 ≤ √(r1A k) + √2 := by linarith
  have hprod := mul_nonneg (sub_nonneg.mpr hsum)
    (show (0 : ℝ) ≤ √(r1A k) + √2 + 27765 / 10000 by positivity)
  unfold D0a
  nlinarith [hprod]

theorem pilot_q_bound {k : ℝ} (hk : k ∈ pilotSlab) : qa (r1A k) < (1 : ℝ) / 50 := by
  have ha := r1_a_pos (pilot_slab_subset hk)
  have ha2 := (r1_a_mem (pilot_slab_subset hk)).2
  have hq := qa_pos ha ha2
  have hmul := D0a_mul_qa ha
  have hprod := mul_nonneg (sub_nonneg.mpr (pilot_D0_lower hk)) hq.le
  nlinarith [(pilot_a_bounds hk).1]

theorem pilot_negative_upper_bound {k : ℝ} (hk : k ∈ pilotSlab) :
    certE k (r1A k) (9 / 25) ≤ -(1 : ℝ) / 250 := by
  have hR1 := pilot_slab_subset hk
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hvq : qa (r1A k) < (9 : ℝ) / 25 := by linarith [pilot_q_bound hk]
  have hv1 : (9 : ℝ) / 25 < 1 := by norm_num
  obtain ⟨_, hq2, _, _⟩ := exterior_parameter_bounds ha ha2 hvq
  have hrat : (9 : ℝ) / 14 ≤ k / (k + 1) := by
    apply (le_div_iff₀ (show (0 : ℝ) < k + 1 by linarith)).mpr
    linarith [hk.1]
  have hratio : ((9 : ℝ) / 25 - (qa (r1A k)) ^ 2) / |1 - 9 / 25| ≤ 9 / 16 := by
    norm_num
    nlinarith [sq_nonneg (qa (r1A k))]
  have hlog : Real.log (((9 : ℝ) / 25 - (qa (r1A k)) ^ 2) / |1 - 9 / 25|) ≤
      Real.log (9 / 16) := Real.log_le_log (by norm_num; linarith) hratio
  have hlogneg : Real.log ((9 : ℝ) / 16) ≤ 0 := Real.log_nonpos (by norm_num) (by norm_num)
  have hmul : k / (k + 1) *
      Real.log (((9 : ℝ) / 25 - (qa (r1A k)) ^ 2) / |1 - 9 / 25|) ≤
      9 / 14 * Real.log (9 / 16) :=
    (mul_le_mul_of_nonneg_left hlog (by positivity)).trans
      (mul_le_mul_of_nonpos_right hrat hlogneg)
  have hD : Real.log ((1927 : ℝ) / 1000) ≤ Real.log (D0a (r1A k)) :=
    Real.log_le_log (by norm_num) (pilot_D0_lower hk)
  have hlog1 : Real.log ((9 : ℝ) / 16) = -Real.log (16 / 9) := by
    rw [show (9 : ℝ) / 16 = ((16 : ℝ) / 9)⁻¹ by norm_num, Real.log_inv]
  have hlog2 : Real.log ((9 : ℝ) / 25) = -Real.log (25 / 9) := by
    rw [show (9 : ℝ) / 25 = ((25 : ℝ) / 9)⁻¹ by norm_num, Real.log_inv]
  unfold certE
  rw [hlog1] at hmul
  rw [hlog2]
  linarith [pilot_log_16_9_lower, pilot_log_25_9_upper, pilot_log_D_lower]

theorem pilot_negative_certificate {k : ℝ} (hk : k ∈ pilotSlab) :
    certE k (r1A k) (9 / 25) < 0 := by linarith [pilot_negative_upper_bound hk]

noncomputable def pilotReference {k : ℝ} (hk : k ∈ pilotSlab) : SeparatedReference :=
  r1Reference (pilot_slab_subset hk) (by linarith [pilot_q_bound hk]) (by norm_num)
    (pilot_negative_certificate hk)

theorem pilotReference_k {k : ℝ} (hk : k ∈ pilotSlab) : (pilotReference hk).angles.k = k := rfl

theorem pilotReference_platform {k : ℝ} (hk : k ∈ pilotSlab) :
    let R := pilotReference hk
    (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) :=
  r1Reference_platform (pilot_slab_subset hk) (by linarith [pilot_q_bound hk]) (by norm_num)
    (pilot_negative_certificate hk)

theorem pilot_reference_exists {k : ℝ} (hk : k ∈ pilotSlab) :
    ∃ R : SeparatedReference, R.angles.k = k ∧
      (0 : ℝ) = R.c - R.r / 2 * (R.angles.ρ + 1 / R.angles.ρ) :=
  ⟨pilotReference hk, pilotReference_k hk, pilotReference_platform hk⟩

theorem pilot_normal_form_strict_lower {n : ℕ} (a : EP1038.NormalForm.NormalData n)
    (hres : 0 < a.residualCount) (hk : a.k ∈ pilotSlab) {L : ℝ}
    (hscalar : ScalarPositive (pilotReference hk) (calibratedCeff (pilotReference hk) L)) :
    L < a.J :=
  normal_form_strict_lower_of_scalarPositive (pilotReference hk) a hres
    (pilotReference_k hk) (pilotReference_platform hk) rfl hscalar

end EP1038.ReferenceCert
