import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk16
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_100 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((6687 : ℝ) / 9887) ((13407 : ℝ) / 19807))
    (hq : RB (qa a) ((1431179 : ℝ) / 50000000) ((144021 : ℝ) / 5000000))
    (hd : RB (D0a a) ((47239419 : ℝ) / 25000000) ((189024041 : ℝ) / 100000000))
    : certE k a ((7701797 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((9693621 : ℝ) / 25000000) ∧ 0 < certE k a ((133853039 : ℝ) / 100000000) ∧ certE k a ((66999387 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((8193 : ℝ) / 10000000) ((82969 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((7701797 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((1200813 : ℝ) / 3125000) ((7685411 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((7701797 : ℝ) / 20000000) ((7701797 : ℝ) / 20000000) ((7701797 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((12298203 : ℝ) / 20000000))
  have h3 : RB z3 ((7811307 : ℝ) / 12500000) ((62492147 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((12298203 : ℝ) / 20000000) ((12298203 : ℝ) / 20000000) ((12298203 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-11753909 : ℝ) / 25000000) ((-734577 : ℝ) / 1562500) := rb_log h3 (by norm_num) cov_log_1800.1 cov_log_1801.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-15912017 : ℝ) / 50000000) ((-31796849 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((7701797 : ℝ) / 20000000))
  have h6 : RB z6 ((-95427861 : ℝ) / 100000000) ((-95427859 : ℝ) / 100000000) := rb_log (show RB ((7701797 : ℝ) / 20000000) ((7701797 : ℝ) / 20000000) ((7701797 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1802.1 cov_log_1802.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((2544153 : ℝ) / 4000000) ((15907753 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((31817643 : ℝ) / 50000000) ((15917601 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1803.1 cov_log_1804.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-66579 : ℝ) / 100000000) ((-2137 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((8193 : ℝ) / 10000000) ((82969 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((9693621 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((7738303 : ℝ) / 20000000) ((19346277 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((9693621 : ℝ) / 25000000) ((9693621 : ℝ) / 25000000) ((9693621 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((15306379 : ℝ) / 25000000))
  have h12 : RB z12 ((63195081 : ℝ) / 100000000) ((63196779 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((15306379 : ℝ) / 25000000) ((15306379 : ℝ) / 25000000) ((15306379 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-45894373 : ℝ) / 100000000) ((-9178337 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_1805.1 cov_log_1806.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-31065071 : ℝ) / 100000000) ((-3879813 : ℝ) / 12500000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((9693621 : ℝ) / 25000000))
  have h15 : RB z15 ((-4737039 : ℝ) / 5000000) ((-47370389 : ℝ) / 50000000) := rb_log (show RB ((9693621 : ℝ) / 25000000) ((9693621 : ℝ) / 25000000) ((9693621 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1807.1 cov_log_1807.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((63675707 : ℝ) / 100000000) ((15925569 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((31817643 : ℝ) / 50000000) ((15917601 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1803.1 cov_log_1804.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((5303 : ℝ) / 100000000) ((6699 : ℝ) / 10000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((8193 : ℝ) / 10000000) ((82969 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133853039 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((13377007 : ℝ) / 10000000) ((133771109 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((133853039 : ℝ) / 100000000) ((133853039 : ℝ) / 100000000) ((133853039 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33853039 : ℝ) / 100000000))
  have h21 : RB z21 ((395149369 : ℝ) / 100000000) ((395152439 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((33853039 : ℝ) / 100000000) ((33853039 : ℝ) / 100000000) ((33853039 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((27481873 : ℝ) / 20000000) ((27482029 : ℝ) / 20000000) := rb_log h21 (by norm_num) cov_log_1808.1 cov_log_1809.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92935817 : ℝ) / 100000000) ((46505221 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133853039 : ℝ) / 100000000))
  have h24 : RB z24 ((7289307 : ℝ) / 25000000) ((2915723 : ℝ) / 10000000) := rb_log (show RB ((133853039 : ℝ) / 100000000) ((133853039 : ℝ) / 100000000) ((133853039 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1810.1 cov_log_1810.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((63778587 : ℝ) / 100000000) ((31926607 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((31817643 : ℝ) / 50000000) ((15917601 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1803.1 cov_log_1804.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((108183 : ℝ) / 100000000) ((27241 : ℝ) / 12500000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((8193 : ℝ) / 10000000) ((82969 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((66999387 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((26783161 : ℝ) / 20000000) ((33479211 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((66999387 : ℝ) / 50000000) ((66999387 : ℝ) / 50000000) ((66999387 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((16999387 : ℝ) / 50000000))
  have h30 : RB z30 ((393884217 : ℝ) / 100000000) ((196943637 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((16999387 : ℝ) / 50000000) ((16999387 : ℝ) / 50000000) ((16999387 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((137088681 : ℝ) / 100000000) ((6854473 : ℝ) / 5000000) := rb_log h30 (by norm_num) cov_log_1811.1 cov_log_1812.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((23179731 : ℝ) / 25000000) ((2899793 : ℝ) / 3125000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((66999387 : ℝ) / 50000000))
  have h33 : RB z33 ((14633023 : ℝ) / 50000000) ((228641 : ℝ) / 781250) := rb_log (show RB ((66999387 : ℝ) / 50000000) ((66999387 : ℝ) / 50000000) ((66999387 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1813.1 cov_log_1813.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((15863219 : ℝ) / 25000000) ((6352733 : ℝ) / 10000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((31817643 : ℝ) / 50000000) ((15917601 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1803.1 cov_log_1804.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-27191 : ℝ) / 12500000) ((-26989 : ℝ) / 25000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((7701797 : ℝ) / 20000000)) ((-66579 : ℝ) / 100000000) ((-2137 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((9693621 : ℝ) / 25000000)) ((5303 : ℝ) / 100000000) ((6699 : ℝ) / 10000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133853039 : ℝ) / 100000000)) ((108183 : ℝ) / 100000000) ((27241 : ℝ) / 12500000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((66999387 : ℝ) / 50000000)) ((-27191 : ℝ) / 12500000) ((-26989 : ℝ) / 25000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_100 {k A q d vp vm : ℝ}
    (hk : RB k ((6687 : ℝ) / 3200) ((13407 : ℝ) / 6400))
    (hA : RB A ((6687 : ℝ) / 9887) ((13407 : ℝ) / 19807))
    (hq : RB q ((1431179 : ℝ) / 50000000) ((144021 : ℝ) / 5000000))
    (hd : RB d ((47239419 : ℝ) / 25000000) ((189024041 : ℝ) / 100000000))
    (hp : RB vp ((7701797 : ℝ) / 20000000) ((9693621 : ℝ) / 25000000))
    (hm : RB vm ((133853039 : ℝ) / 100000000) ((66999387 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((8193 : ℝ) / 10000000) ((82969 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99917031 : ℝ) / 100000000) ((9991807 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((67578151 : ℝ) / 100000000) ((13526547 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((105649 : ℝ) / 50000000) ((107727 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49892273 : ℝ) / 50000000) ((49894351 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((15306379 : ℝ) / 25000000) ((12298203 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((61093603 : ℝ) / 100000000) ((30680543 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((55065967 : ℝ) / 50000000) ((22140693 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((5065967 : ℝ) / 50000000) ((2140693 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99917031 : ℝ) / 100000000) ((9991807 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((67578151 : ℝ) / 100000000) ((13526547 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((30571 : ℝ) / 50000000) ((30993 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49969007 : ℝ) / 50000000) ((49969429 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33853039 : ℝ) / 100000000) ((16999387 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((16916027 : ℝ) / 50000000) ((33977987 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((39777607 : ℝ) / 20000000) ((199907269 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((59777607 : ℝ) / 20000000) ((299907269 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((93427689 : ℝ) / 10000000) ((1233723 : ℝ) / 125000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33343639 : ℝ) / 100000000) ((6691469 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((6687 : ℝ) / 1600) ((13407 : ℝ) / 3200) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((11962867 : ℝ) / 100000000) ((603403 : ℝ) / 5000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((51431179 : ℝ) / 50000000) ((5144021 : ℝ) / 5000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((11627933 : ℝ) / 100000000) ((5866121 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((111627933 : ℝ) / 100000000) ((55866121 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((19015711 : ℝ) / 20000000) ((95489789 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((179658227 : ℝ) / 100000000) ((90249329 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((25772723 : ℝ) / 50000000) ((25978667 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((157687 : ℝ) / 100000000) ((160963 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99839037 : ℝ) / 100000000) ((99842313 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((179369043 : ℝ) / 100000000) ((45053509 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((47239419 : ℝ) / 12500000) ((189024041 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1081729 : ℝ) / 10000000) ((10889373 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((9887 : ℝ) / 3200) ((19807 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1747631 : ℝ) / 50000000) ((1762213 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1476413 : ℝ) / 20000000) ((1495973 : ℝ) / 20000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((21476413 : ℝ) / 20000000) ((21495973 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1003245817 : ℝ) / 100000000) ((265200763 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((2136107 : ℝ) / 100000000) ((268991 : ℝ) / 12500000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((102136107 : ℝ) / 100000000) ((12768991 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((17027947 : ℝ) / 50000000) ((34177323 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1037301711 : ℝ) / 100000000) ((8759843 : ℝ) / 800000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((9064103 : ℝ) / 25000000) ((19295887 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((9887 : ℝ) / 3200) ((19807 : ℝ) / 6400) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((111627933 : ℝ) / 50000000) ((55866121 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((967620529 : ℝ) / 100000000) ((204087149 : ℝ) / 20000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2160269591 : ℝ) / 100000000) ((2280311473 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((13549409 : ℝ) / 100000000) ((14326193 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-199882729 : ℝ) / 100000000) ((-6072127 : ℝ) / 3125000) := rb_log h47 (by norm_num) cov_log_1814.1 cov_log_1815.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1081729 : ℝ) / 20000000) ((5444687 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-291717163 : ℝ) / 100000000) ((-291052991 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1816.1 cov_log_1817.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((31817643 : ℝ) / 50000000) ((15917601 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_1803.1 cov_log_1804.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((132977861 : ℝ) / 100000000) ((33344887 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-79369651 : ℝ) / 50000000) ((-157673443 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((3229011 : ℝ) / 100000000) ((814801 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1045887 : ℝ) / 12500000) ((11236647 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-75186103 : ℝ) / 50000000) ((-36609199 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((111627933 : ℝ) / 100000000) ((55866121 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-199882729 : ℝ) / 100000000) ((-6072127 : ℝ) / 3125000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-75186103 : ℝ) / 50000000) ((-36609199 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((141 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1476413 : ℝ) / 20000000) ((1495973 : ℝ) / 20000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((169 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((21495973 : ℝ) / 40000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((141 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((169 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-166192883 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((141 : ℝ) / 50) + hfun ((169 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_38, cov_h_30]
  have hP : ((411726451 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((36609199 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((36609199 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((5875087 : ℝ) / 10000000) ≤ EP1038.Arc.sinc ((169 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((477 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((309 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((309 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((314 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((314 : ℝ) / 125)) (lo := ((309 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((319 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((319 : ℝ) / 125)) (lo := ((314 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((324 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((324 : ℝ) / 125)) (lo := ((319 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((329 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((329 : ℝ) / 125)) (lo := ((324 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((334 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((334 : ℝ) / 125)) (lo := ((329 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((339 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((339 : ℝ) / 125)) (lo := ((334 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((344 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((344 : ℝ) / 125)) (lo := ((339 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((349 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((349 : ℝ) / 125)) (lo := ((344 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((141 : ℝ) / 50)) (lo := ((349 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_100 {k : ℝ} (hk : RB k ((6687 : ℝ) / 3200) ((13407 : ℝ) / 6400)) :
    RB (k / (k + 1)) ((6687 : ℝ) / 9887) ((13407 : ℝ) / 19807) ∧
    RB (qa (r1A k)) ((1431179 : ℝ) / 50000000) ((144021 : ℝ) / 5000000) ∧ RB (D0a (r1A k)) ((47239419 : ℝ) / 25000000) ((189024041 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((52242187 : ℝ) / 100000000) ((26185547 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((89114453 : ℝ) / 50000000) ((178357813 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((133502399 : ℝ) / 100000000) ((13355067 : ℝ) / 10000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((54984751 : ℝ) / 20000000) ((274972027 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((137461877 : ℝ) / 100000000) ((68743007 : ℝ) / 50000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((47239419 : ℝ) / 25000000) ((189024041 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((21642187 : ℝ) / 100000000) ((10885547 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((2705273 : ℝ) / 50000000) ((2721387 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((1431179 : ℝ) / 50000000) ((144021 : ℝ) / 5000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((47239419 : ℝ) / 25000000) ((189024041 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((1431179 : ℝ) / 50000000) ((144021 : ℝ) / 5000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((6687 : ℝ) / 9887) ((13407 : ℝ) / 19807) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_100 {k : ℝ} (hk : RB k ((6687 : ℝ) / 3200) ((13407 : ℝ) / 6400)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_100 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_100 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((7701797 : ℝ) / 20000000)) (ph := ((9693621 : ℝ) / 25000000)) (ml := ((133853039 : ℝ) / 100000000)) (mh := ((66999387 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_100 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_101 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((13407 : ℝ) / 19807) ((21 : ℝ) / 31))
    (hq : RB (qa a) ((2880419 : ℝ) / 100000000) ((2898493 : ℝ) / 100000000))
    (hd : RB (D0a a) ((23611413 : ℝ) / 12500000) ((94478841 : ℝ) / 50000000))
    : certE k a ((38478739 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((19371823 : ℝ) / 50000000) ∧ 0 < certE k a ((33475427 : ℝ) / 25000000) ∧ certE k a ((134047169 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((10371 : ℝ) / 12500000) ((84013 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((38478739 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((19197363 : ℝ) / 50000000) ((38395771 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((38478739 : ℝ) / 100000000) ((38478739 : ℝ) / 100000000) ((38478739 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((61521261 : ℝ) / 100000000))
  have h3 : RB z3 ((62408873 : ℝ) / 100000000) ((62410573 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((61521261 : ℝ) / 100000000) ((61521261 : ℝ) / 100000000) ((61521261 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-23573137 : ℝ) / 50000000) ((-11785887 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_1818.1 cov_log_1819.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-31937799 : ℝ) / 100000000) ((-15955307 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((38478739 : ℝ) / 100000000))
  have h6 : RB z6 ((-19101287 : ℝ) / 20000000) ((-95506433 : ℝ) / 100000000) := rb_log (show RB ((38478739 : ℝ) / 100000000) ((38478739 : ℝ) / 100000000) ((38478739 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1820.1 cov_log_1820.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((31784317 : ℝ) / 50000000) ((63595821 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((12720031 : ℝ) / 20000000) ((63635291 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1821.1 cov_log_1822.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-66657 : ℝ) / 100000000) ((-2167 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((10371 : ℝ) / 12500000) ((84013 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((19371823 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((38659633 : ℝ) / 100000000) ((19330339 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((19371823 : ℝ) / 50000000) ((19371823 : ℝ) / 50000000) ((19371823 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((30628177 : ℝ) / 50000000))
  have h12 : RB z12 ((63111221 : ℝ) / 100000000) ((1972279 : ℝ) / 3125000) := rb_div_signed h11 (show RB ((30628177 : ℝ) / 50000000) ((30628177 : ℝ) / 50000000) ((30628177 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-23013581 : ℝ) / 50000000) ((-9204891 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_1823.1 cov_log_1824.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-31179691 : ℝ) / 100000000) ((-31153121 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((19371823 : ℝ) / 50000000))
  have h15 : RB z15 ((-94820343 : ℝ) / 100000000) ((-94820341 : ℝ) / 100000000) := rb_log (show RB ((19371823 : ℝ) / 50000000) ((19371823 : ℝ) / 50000000) ((19371823 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1825.1 cov_log_1825.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((1272813 : ℝ) / 2000000) ((31833611 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((12720031 : ℝ) / 20000000) ((63635291 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1821.1 cov_log_1822.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((5359 : ℝ) / 100000000) ((67067 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((10371 : ℝ) / 12500000) ((84013 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((33475427 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((26763539 : ℝ) / 20000000) ((6690937 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((33475427 : ℝ) / 25000000) ((33475427 : ℝ) / 25000000) ((33475427 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((8475427 : ℝ) / 25000000))
  have h21 : RB z21 ((15788903 : ℝ) / 4000000) ((394725659 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((8475427 : ℝ) / 25000000) ((8475427 : ℝ) / 25000000) ((8475427 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((68650649 : ℝ) / 50000000) ((137302083 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1826.1 cov_log_1827.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23234191 : ℝ) / 25000000) ((93011089 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((33475427 : ℝ) / 25000000))
  have h24 : RB z24 ((14596791 : ℝ) / 50000000) ((1824599 : ℝ) / 6250000) := rb_log (show RB ((33475427 : ℝ) / 25000000) ((33475427 : ℝ) / 25000000) ((33475427 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1828.1 cov_log_1828.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((3187159 : ℝ) / 5000000) ((63817507 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((12720031 : ℝ) / 20000000) ((63635291 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1821.1 cov_log_1822.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((107889 : ℝ) / 100000000) ((27169 : ℝ) / 12500000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((10371 : ℝ) / 12500000) ((84013 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((134047169 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((33490789 : ℝ) / 25000000) ((133964201 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((134047169 : ℝ) / 100000000) ((134047169 : ℝ) / 100000000) ((134047169 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((34047169 : ℝ) / 100000000))
  have h30 : RB z30 ((393463421 : ℝ) / 100000000) ((393466491 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((34047169 : ℝ) / 100000000) ((34047169 : ℝ) / 100000000) ((34047169 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((136981791 : ℝ) / 100000000) ((5479303 : ℝ) / 4000000) := rb_log h30 (by norm_num) cov_log_1829.1 cov_log_1830.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((5795031 : ℝ) / 6250000) ((11599331 : ℝ) / 12500000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((134047169 : ℝ) / 100000000))
  have h33 : RB z33 ((5860431 : ℝ) / 20000000) ((29302157 : ℝ) / 100000000) := rb_log (show RB ((134047169 : ℝ) / 100000000) ((134047169 : ℝ) / 100000000) ((134047169 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1831.1 cov_log_1831.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63418339 : ℝ) / 100000000) ((63492493 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((12720031 : ℝ) / 20000000) ((63635291 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1821.1 cov_log_1822.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-27119 : ℝ) / 12500000) ((-53831 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((38478739 : ℝ) / 100000000)) ((-66657 : ℝ) / 100000000) ((-2167 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((19371823 : ℝ) / 50000000)) ((5359 : ℝ) / 100000000) ((67067 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((33475427 : ℝ) / 25000000)) ((107889 : ℝ) / 100000000) ((27169 : ℝ) / 12500000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((134047169 : ℝ) / 100000000)) ((-27119 : ℝ) / 12500000) ((-53831 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_101 {k A q d vp vm : ℝ}
    (hk : RB k ((13407 : ℝ) / 6400) ((21 : ℝ) / 10))
    (hA : RB A ((13407 : ℝ) / 19807) ((21 : ℝ) / 31))
    (hq : RB q ((2880419 : ℝ) / 100000000) ((2898493 : ℝ) / 100000000))
    (hd : RB d ((23611413 : ℝ) / 12500000) ((94478841 : ℝ) / 50000000))
    (hp : RB vp ((38478739 : ℝ) / 100000000) ((19371823 : ℝ) / 50000000))
    (hm : RB vm ((33475427 : ℝ) / 25000000) ((134047169 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((10371 : ℝ) / 12500000) ((84013 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99915987 : ℝ) / 100000000) ((12489629 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((16907831 : ℝ) / 25000000) ((16921433 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((107073 : ℝ) / 50000000) ((218337 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99781663 : ℝ) / 100000000) ((49892927 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((30628177 : ℝ) / 50000000) ((61521261 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((3820163 : ℝ) / 6250000) ((15347379 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((110167547 : ℝ) / 100000000) ((55368819 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((10167547 : ℝ) / 100000000) ((5368819 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99915987 : ℝ) / 100000000) ((12489629 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((16907831 : ℝ) / 25000000) ((16921433 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((30947 : ℝ) / 50000000) ((62743 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99937257 : ℝ) / 100000000) ((49969053 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((8475427 : ℝ) / 25000000) ((34047169 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((33880437 : ℝ) / 100000000) ((2126631 : ℝ) / 6250000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((99381551 : ℝ) / 50000000) ((39955643 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((149381551 : ℝ) / 50000000) ((59955643 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((931303513 : ℝ) / 100000000) ((196704279 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16678997 : ℝ) / 50000000) ((4183917 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((13407 : ℝ) / 3200) ((21 : ℝ) / 5) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2413611 : ℝ) / 20000000) ((12173671 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102880419 : ℝ) / 100000000) ((102898493 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2932029 : ℝ) / 25000000) ((2958209 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((27932029 : ℝ) / 25000000) ((27958209 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((47579031 : ℝ) / 50000000) ((9556843 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((22468163 : ℝ) / 12500000) ((180583891 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((6440461 : ℝ) / 12500000) ((51934761 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((79877 : ℝ) / 50000000) ((81529 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49918471 : ℝ) / 50000000) ((49920123 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((89726107 : ℝ) / 50000000) ((90147701 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23611413 : ℝ) / 6250000) ((94478841 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5440861 : ℝ) / 50000000) ((10953851 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((19807 : ℝ) / 6400) ((31 : ℝ) / 10) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((438779 : ℝ) / 12500000) ((884847 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3717279 : ℝ) / 50000000) ((3766357 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((53717279 : ℝ) / 50000000) ((53766357 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((250135453 : ℝ) / 25000000) ((1057607249 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((214881 : ℝ) / 10000000) ((2164643 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((10214881 : ℝ) / 10000000) ((102164643 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((34074793 : ℝ) / 100000000) ((34195871 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((206923321 : ℝ) / 20000000) ((13647539 : ℝ) / 1250000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((36317443 : ℝ) / 100000000) ((38643149 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((19807 : ℝ) / 6400) ((31 : ℝ) / 10) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((27932029 : ℝ) / 12500000) ((27958209 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((964661507 : ℝ) / 100000000) ((1016992731 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((431119251 : ℝ) / 20000000) ((1137331813 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((340143 : ℝ) / 2500000) ((3595293 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-199467993 : ℝ) / 100000000) ((-193925033 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1832.1 cov_log_1833.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((5440861 : ℝ) / 100000000) ((2738463 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-291123291 : ℝ) / 100000000) ((-145231309 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_1834.1 cov_log_1835.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((12720031 : ℝ) / 20000000) ((63635291 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1821.1 cov_log_1822.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((133232387 : ℝ) / 100000000) ((2088033 : ℝ) / 1562500) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-19736363 : ℝ) / 12500000) ((-78414253 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((629529 : ℝ) / 20000000) ((1995417 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1629083 : ℝ) / 20000000) ((10988753 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-149745489 : ℝ) / 100000000) ((-145839753 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((27932029 : ℝ) / 25000000) ((27958209 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-199467993 : ℝ) / 100000000) ((-193925033 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-149745489 : ℝ) / 100000000) ((-145839753 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((141 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3717279 : ℝ) / 50000000) ((3766357 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((169 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((53766357 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((141 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((169 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-165778147 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((141 : ℝ) / 50) + hfun ((169 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_38, cov_h_30]
  have hP : ((204839473 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((145839753 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((145839753 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((5875087 : ℝ) / 10000000) ≤ EP1038.Arc.sinc ((169 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((477 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1233 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1233 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1253 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1253 : ℝ) / 500)) (lo := ((1233 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1273 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1273 : ℝ) / 500)) (lo := ((1253 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1293 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1293 : ℝ) / 500)) (lo := ((1273 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1313 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1313 : ℝ) / 500)) (lo := ((1293 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1333 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1333 : ℝ) / 500)) (lo := ((1313 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1353 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1353 : ℝ) / 500)) (lo := ((1333 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1373 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1373 : ℝ) / 500)) (lo := ((1353 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1393 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1393 : ℝ) / 500)) (lo := ((1373 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((141 : ℝ) / 50)) (lo := ((1393 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_101 {k : ℝ} (hk : RB k ((13407 : ℝ) / 6400) ((21 : ℝ) / 10)) :
    RB (k / (k + 1)) ((13407 : ℝ) / 19807) ((21 : ℝ) / 31) ∧
    RB (qa (r1A k)) ((2880419 : ℝ) / 100000000) ((2898493 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((23611413 : ℝ) / 12500000) ((94478841 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((52371093 : ℝ) / 100000000) ((21 : ℝ) / 40) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((1781 : ℝ) / 1000) ((178228907 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((133454111 : ℝ) / 100000000) ((83439 : ℝ) / 62500) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((274875467 : ℝ) / 100000000) ((274923757 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((137437733 : ℝ) / 100000000) ((137461879 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((23611413 : ℝ) / 12500000) ((94478841 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((21771093 : ℝ) / 100000000) ((219 : ℝ) / 1000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((5442773 : ℝ) / 100000000) ((219 : ℝ) / 4000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((2880419 : ℝ) / 100000000) ((2898493 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((23611413 : ℝ) / 12500000) ((94478841 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((2880419 : ℝ) / 100000000) ((2898493 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((13407 : ℝ) / 19807) ((21 : ℝ) / 31) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_101 {k : ℝ} (hk : RB k ((13407 : ℝ) / 6400) ((21 : ℝ) / 10)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_101 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_101 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((38478739 : ℝ) / 100000000)) (ph := ((19371823 : ℝ) / 50000000)) (ml := ((33475427 : ℝ) / 25000000)) (mh := ((134047169 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_101 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_102 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((21 : ℝ) / 31) ((273 : ℝ) / 401))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((497979 : ℝ) / 1250000) < 0 ∧ 0 < certE k a ((40974153 : ℝ) / 100000000) ∧ 0 < certE k a ((133564847 : ℝ) / 100000000) ∧ certE k a ((33546323 : ℝ) / 25000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((497979 : ℝ) / 1250000)) - (z1)
  have h2 : RB z2 ((39768971 : ℝ) / 100000000) ((9942243 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((497979 : ℝ) / 1250000) ((497979 : ℝ) / 1250000) ((497979 : ℝ) / 1250000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((752021 : ℝ) / 1250000))
  have h3 : RB z3 ((66103491 : ℝ) / 100000000) ((33051747 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((752021 : ℝ) / 1250000) ((752021 : ℝ) / 1250000) ((752021 : ℝ) / 1250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-2587179 : ℝ) / 6250000) ((-20697429 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_1836.1 cov_log_1837.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-28181541 : ℝ) / 100000000) ((-14020839 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((497979 : ℝ) / 1250000))
  have h6 : RB z6 ((-46017047 : ℝ) / 50000000) ((-23008523 : ℝ) / 25000000) := rb_log (show RB ((497979 : ℝ) / 1250000) ((497979 : ℝ) / 1250000) ((497979 : ℝ) / 1250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1838.1 cov_log_1838.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63852551 : ℝ) / 100000000) ((1999763 : ℝ) / 3125000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-65879 : ℝ) / 25000000) ((-123647 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((40974153 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((10226201 : ℝ) / 25000000) ((8180961 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((40974153 : ℝ) / 100000000) ((40974153 : ℝ) / 100000000) ((40974153 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((59025847 : ℝ) / 100000000))
  have h12 : RB z12 ((69299817 : ℝ) / 100000000) ((69299819 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((59025847 : ℝ) / 100000000) ((59025847 : ℝ) / 100000000) ((59025847 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-36672793 : ℝ) / 100000000) ((-36672789 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_1841.1 cov_log_1842.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4993353 : ℝ) / 20000000) ((-24842857 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((40974153 : ℝ) / 100000000))
  have h15 : RB z15 ((-713783 : ℝ) / 800000) ((-89222873 : ℝ) / 100000000) := rb_log (show RB ((40974153 : ℝ) / 100000000) ((40974153 : ℝ) / 100000000) ((40974153 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1843.1 cov_log_1843.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16064027 : ℝ) / 25000000) ((32190009 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((140041 : ℝ) / 100000000) ((52791 : ℝ) / 20000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133564847 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((66747749 : ℝ) / 50000000) ((133495499 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((133564847 : ℝ) / 100000000) ((133564847 : ℝ) / 100000000) ((133564847 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33564847 : ℝ) / 100000000))
  have h21 : RB z21 ((49715517 : ℝ) / 12500000) ((19886207 : ℝ) / 5000000) := rb_div_signed h20 (show RB ((33564847 : ℝ) / 100000000) ((33564847 : ℝ) / 100000000) ((33564847 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((27611769 : ℝ) / 20000000) ((138058849 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1844.1 cov_log_1845.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((93523733 : ℝ) / 100000000) ((93990189 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133564847 : ℝ) / 100000000))
  have h24 : RB z24 ((28941691 : ℝ) / 100000000) ((28941693 : ℝ) / 100000000) := rb_log (show RB ((133564847 : ℝ) / 100000000) ((133564847 : ℝ) / 100000000) ((133564847 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1846.1 cov_log_1846.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((1614551 : ℝ) / 2500000) ((32524249 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((465973 : ℝ) / 100000000) ((186487 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((33546323 : ℝ) / 25000000)) - (z28)
  have h29 : RB z29 ((134115943 : ℝ) / 100000000) ((16764493 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((33546323 : ℝ) / 25000000) ((33546323 : ℝ) / 25000000) ((33546323 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8546323 : ℝ) / 25000000))
  have h30 : RB z30 ((1961603 : ℝ) / 500000) ((98080151 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((8546323 : ℝ) / 25000000) ((8546323 : ℝ) / 25000000) ((8546323 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((136690917 : ℝ) / 100000000) ((136690921 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1847.1 cov_log_1848.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((5787317 : ℝ) / 6250000) ((93058907 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((33546323 : ℝ) / 25000000))
  have h33 : RB z33 ((29405143 : ℝ) / 100000000) ((5881029 : ℝ) / 20000000) := rb_log (show RB ((33546323 : ℝ) / 25000000) ((33546323 : ℝ) / 25000000) ((33546323 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1849.1 cov_log_1849.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63191927 : ℝ) / 100000000) ((15913441 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-46207 : ℝ) / 5000000) ((-462299 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((497979 : ℝ) / 1250000)) ((-65879 : ℝ) / 25000000) ((-123647 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((40974153 : ℝ) / 100000000)) ((140041 : ℝ) / 100000000) ((52791 : ℝ) / 20000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133564847 : ℝ) / 100000000)) ((465973 : ℝ) / 100000000) ((186487 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((33546323 : ℝ) / 25000000)) ((-46207 : ℝ) / 5000000) ((-462299 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_102 {k A q d vp vm : ℝ}
    (hk : RB k ((21 : ℝ) / 10) ((273 : ℝ) / 128))
    (hA : RB A ((21 : ℝ) / 31) ((273 : ℝ) / 401))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((497979 : ℝ) / 1250000) ((40974153 : ℝ) / 100000000))
    (hm : RB vm ((133564847 : ℝ) / 100000000) ((33546323 : ℝ) / 25000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((67694957 : ℝ) / 100000000) ((68032589 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((5289 : ℝ) / 3125000) ((174077 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99825923 : ℝ) / 100000000) ((3119711 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((59025847 : ℝ) / 100000000) ((752021 : ℝ) / 1250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7365387 : ℝ) / 12500000) ((30029929 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((56356241 : ℝ) / 50000000) ((115459971 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6356241 : ℝ) / 50000000) ((15459971 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((67694957 : ℝ) / 100000000) ((68032589 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((323 : ℝ) / 625000) ((25961 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49974039 : ℝ) / 50000000) ((624677 : ℝ) / 625000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33564847 : ℝ) / 100000000) ((8546323 : ℝ) / 25000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((33547419 : ℝ) / 100000000) ((17083813 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((99063009 : ℝ) / 50000000) ((2027953 : ℝ) / 1000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((149063009 : ℝ) / 50000000) ((3027953 : ℝ) / 1000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((646831743 : ℝ) / 100000000) ((15732569 : ℝ) / 2000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33025611 : ℝ) / 100000000) ((33542863 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((21 : ℝ) / 5) ((273 : ℝ) / 64) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2765073 : ℝ) / 25000000) ((5616557 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((10776503 : ℝ) / 100000000) ((10944891 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((110776503 : ℝ) / 100000000) ((110944891 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((46295347 : ℝ) / 50000000) ((23586743 : ℝ) / 25000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((87900201 : ℝ) / 50000000) ((179135023 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53209991 : ℝ) / 100000000) ((54981287 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((12613 : ℝ) / 10000000) ((130331 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99869669 : ℝ) / 100000000) ((9987387 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((175571279 : ℝ) / 100000000) ((4472727 : ℝ) / 2500000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((31 : ℝ) / 10) ((401 : ℝ) / 128) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1596009 : ℝ) / 50000000) ((3225807 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1285397 : ℝ) / 20000000) ((6610229 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((21285397 : ℝ) / 20000000) ((106610229 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((344201761 : ℝ) / 50000000) ((104828299 : ℝ) / 12500000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((122657 : ℝ) / 6250000) ((197163 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((6372657 : ℝ) / 6250000) ((10197163 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((16836871 : ℝ) / 50000000) ((6840841 : ℝ) / 20000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((45129829 : ℝ) / 6250000) ((872830597 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5762209 : ℝ) / 25000000) ((28155831 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((31 : ℝ) / 10) ((401 : ℝ) / 128) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((110776503 : ℝ) / 50000000) ((110944891 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((339928677 : ℝ) / 50000000) ((820171313 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((376561101 : ℝ) / 25000000) ((1819876339 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((4258531 : ℝ) / 25000000) ((20798833 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-88497579 : ℝ) / 50000000) ((-15702733 : ℝ) / 10000000) := rb_log h47 (by norm_num) cov_log_1850.1 cov_log_1851.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((33660933 : ℝ) / 25000000) ((2734951 : ℝ) / 2000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-8246477 : ℝ) / 5000000) ((-162825657 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4533967 : ℝ) / 100000000) ((7871769 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((16103119 : ℝ) / 100000000) ((34152567 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-148826421 : ℝ) / 100000000) ((-12867309 : ℝ) / 10000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((110776503 : ℝ) / 100000000) ((110944891 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-88497579 : ℝ) / 50000000) ((-15702733 : ℝ) / 10000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-148826421 : ℝ) / 100000000) ((-12867309 : ℝ) / 10000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((71 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1285397 : ℝ) / 20000000) ((6610229 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((106610229 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((71 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-1122247 : ℝ) / 781250) ≤ formC0 k A q vp vm + hfun ((71 : ℝ) / 25) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_36, cov_h_24]
  have hP : ((9108723 : ℝ) / 2500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((12867309 : ℝ) / 10000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((12867309 : ℝ) / 10000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2531 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2531 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2571 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2571 : ℝ) / 1000)) (lo := ((2531 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2611 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2611 : ℝ) / 1000)) (lo := ((2571 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2651 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2651 : ℝ) / 1000)) (lo := ((2611 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2691 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2691 : ℝ) / 1000)) (lo := ((2651 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2731 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2731 : ℝ) / 1000)) (lo := ((2691 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2771 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2771 : ℝ) / 1000)) (lo := ((2731 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2811 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2811 : ℝ) / 1000)) (lo := ((2771 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((71 : ℝ) / 25)) (lo := ((2811 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_102 {k : ℝ} (hk : RB k ((21 : ℝ) / 10) ((273 : ℝ) / 128)) :
    RB (k / (k + 1)) ((21 : ℝ) / 31) ((273 : ℝ) / 401) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((21 : ℝ) / 31) ((273 : ℝ) / 401) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_102 {k : ℝ} (hk : RB k ((21 : ℝ) / 10) ((273 : ℝ) / 128)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_102 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_102 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((497979 : ℝ) / 1250000)) (ph := ((40974153 : ℝ) / 100000000)) (ml := ((133564847 : ℝ) / 100000000)) (mh := ((33546323 : ℝ) / 25000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_102 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_103 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((273 : ℝ) / 401) ((693 : ℝ) / 1013))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((2516557 : ℝ) / 6250000) < 0 ∧ 0 < certE k a ((51571 : ℝ) / 125000) ∧ 0 < certE k a ((133776153 : ℝ) / 100000000) ∧ certE k a ((134383123 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((2516557 : ℝ) / 6250000)) - (z1)
  have h2 : RB z2 ((40195563 : ℝ) / 100000000) ((10048891 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((2516557 : ℝ) / 6250000) ((2516557 : ℝ) / 6250000) ((2516557 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((3733443 : ℝ) / 6250000))
  have h3 : RB z3 ((33644851 : ℝ) / 50000000) ((13457941 : ℝ) / 20000000) := rb_div_signed h2 (show RB ((3733443 : ℝ) / 6250000) ((3733443 : ℝ) / 6250000) ((3733443 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-19808149 : ℝ) / 50000000) ((-39616293 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1854.1 cov_log_1855.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-6775443 : ℝ) / 25000000) ((-26970693 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((2516557 : ℝ) / 6250000))
  have h6 : RB z6 ((-45484489 : ℝ) / 50000000) ((-5685561 : ℝ) / 6250000) := rb_log (show RB ((2516557 : ℝ) / 6250000) ((2516557 : ℝ) / 6250000) ((2516557 : ℝ) / 6250000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1856.1 cov_log_1856.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((15966801 : ℝ) / 25000000) ((12799657 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-248863 : ℝ) / 100000000) ((-58889 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((51571 : ℝ) / 125000)) - (z10)
  have h11 : RB z11 ((41187451 : ℝ) / 100000000) ((10296863 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((51571 : ℝ) / 125000) ((51571 : ℝ) / 125000) ((51571 : ℝ) / 125000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((73429 : ℝ) / 125000))
  have h12 : RB z12 ((35057207 : ℝ) / 50000000) ((70114417 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((73429 : ℝ) / 125000) ((73429 : ℝ) / 125000) ((73429 : ℝ) / 125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-1775209 : ℝ) / 5000000) ((-17752087 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_1857.1 cov_log_1858.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4857729 : ℝ) / 20000000) ((-2417117 : ℝ) / 10000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((51571 : ℝ) / 125000))
  have h15 : RB z15 ((-3541417 : ℝ) / 4000000) ((-88535423 : ℝ) / 100000000) := rb_log (show RB ((51571 : ℝ) / 125000) ((51571 : ℝ) / 125000) ((51571 : ℝ) / 125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1859.1 cov_log_1859.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((32123389 : ℝ) / 50000000) ((12872851 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((130711 : ℝ) / 100000000) ((1939 : ℝ) / 781250) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133776153 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((33426701 : ℝ) / 25000000) ((26741361 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((133776153 : ℝ) / 100000000) ((133776153 : ℝ) / 100000000) ((133776153 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33776153 : ℝ) / 100000000))
  have h21 : RB z21 ((395861553 : ℝ) / 100000000) ((395861557 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((33776153 : ℝ) / 100000000) ((33776153 : ℝ) / 100000000) ((33776153 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((68794717 : ℝ) / 50000000) ((68794719 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_1860.1 cov_log_1861.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23417653 : ℝ) / 25000000) ((18825169 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133776153 : ℝ) / 100000000))
  have h24 : RB z24 ((29099771 : ℝ) / 100000000) ((29099773 : ℝ) / 100000000) := rb_log (show RB ((133776153 : ℝ) / 100000000) ((133776153 : ℝ) / 100000000) ((133776153 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1862.1 cov_log_1862.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64570839 : ℝ) / 100000000) ((32513037 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((113693 : ℝ) / 25000000) ((910011 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((134383123 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((67156887 : ℝ) / 50000000) ((5372551 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((134383123 : ℝ) / 100000000) ((134383123 : ℝ) / 100000000) ((134383123 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((34383123 : ℝ) / 100000000))
  have h30 : RB z30 ((97659667 : ℝ) / 25000000) ((24414917 : ℝ) / 6250000) := rb_div_signed h29 (show RB ((34383123 : ℝ) / 100000000) ((34383123 : ℝ) / 100000000) ((34383123 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((68130641 : ℝ) / 50000000) ((68130643 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_1863.1 cov_log_1864.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((11595801 : ℝ) / 12500000) ((93217247 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((134383123 : ℝ) / 100000000))
  have h33 : RB z33 ((14776233 : ℝ) / 50000000) ((7388117 : ℝ) / 25000000) := rb_log (show RB ((134383123 : ℝ) / 100000000) ((134383123 : ℝ) / 100000000) ((134383123 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1865.1 cov_log_1865.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((3160697 : ℝ) / 5000000) ((63664781 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-902127 : ℝ) / 100000000) ((-225641 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((2516557 : ℝ) / 6250000)) ((-248863 : ℝ) / 100000000) ((-58889 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((51571 : ℝ) / 125000)) ((130711 : ℝ) / 100000000) ((1939 : ℝ) / 781250) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133776153 : ℝ) / 100000000)) ((113693 : ℝ) / 25000000) ((910011 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((134383123 : ℝ) / 100000000)) ((-902127 : ℝ) / 100000000) ((-225641 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_103 {k A q d vp vm : ℝ}
    (hk : RB k ((273 : ℝ) / 128) ((693 : ℝ) / 320))
    (hA : RB A ((273 : ℝ) / 401) ((693 : ℝ) / 1013))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((2516557 : ℝ) / 6250000) ((51571 : ℝ) / 125000))
    (hm : RB vm ((133776153 : ℝ) / 100000000) ((134383123 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((68032587 : ℝ) / 100000000) ((3418161 : ℝ) / 5000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((21011 : ℝ) / 12500000) ((21529 : ℝ) / 12500000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((12478471 : ℝ) / 12500000) ((12478989 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((73429 : ℝ) / 125000) ((3733443 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((2345681 : ℝ) / 4000000) ((59634681 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((114082251 : ℝ) / 100000000) ((58288591 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((14082251 : ℝ) / 100000000) ((8288591 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((68032587 : ℝ) / 100000000) ((3418161 : ℝ) / 5000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((12901 : ℝ) / 25000000) ((81 : ℝ) / 156250) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((156169 : ℝ) / 156250) ((24987099 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33776153 : ℝ) / 100000000) ((34383123 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((33758643 : ℝ) / 100000000) ((1718269 : ℝ) / 5000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((98984191 : ℝ) / 50000000) ((20250583 : ℝ) / 10000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((148984191 : ℝ) / 50000000) ((30250583 : ℝ) / 10000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((603238837 : ℝ) / 100000000) ((355056873 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16528607 : ℝ) / 50000000) ((1048769 : ℝ) / 3125000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((273 : ℝ) / 64) ((693 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((11233109 : ℝ) / 100000000) ((2851483 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2188977 : ℝ) / 20000000) ((444531 : ℝ) / 4000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((22188977 : ℝ) / 20000000) ((4444531 : ℝ) / 4000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((92519353 : ℝ) / 100000000) ((94118211 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((43916237 : ℝ) / 25000000) ((89350339 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((1077297 : ℝ) / 2000000) ((55442177 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((125081 : ℝ) / 100000000) ((128747 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99871253 : ℝ) / 100000000) ((99874919 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((2741231 : ℝ) / 1562500) ((89238579 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((401 : ℝ) / 128) ((1013 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((789733 : ℝ) / 25000000) ((3192021 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1276591 : ℝ) / 20000000) ((1635049 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((21276591 : ℝ) / 20000000) ((26635049 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((6417433 : ℝ) / 1000000) ((756556577 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1959623 : ℝ) / 100000000) ((492129 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101959623 : ℝ) / 100000000) ((25492129 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3370501 : ℝ) / 10000000) ((17110627 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((67544831 : ℝ) / 10000000) ((790777831 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((2667119 : ℝ) / 12500000) ((5048359 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((401 : ℝ) / 128) ((1013 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((22188977 : ℝ) / 10000000) ((4444531 : ℝ) / 2000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((636296051 : ℝ) / 100000000) ((371837177 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((352968961 : ℝ) / 25000000) ((1652641861 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1895639 : ℝ) / 10000000) ((22421413 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-166302913 : ℝ) / 100000000) ((-74757687 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1866.1 cov_log_1867.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((6837377 : ℝ) / 5000000) ((69425679 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-40706433 : ℝ) / 25000000) ((-160721849 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4965889 : ℝ) / 100000000) ((1000533 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((19673279 : ℝ) / 100000000) ((300109 : ℝ) / 800000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-143152453 : ℝ) / 100000000) ((-3850257 : ℝ) / 3125000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((22188977 : ℝ) / 20000000) ((4444531 : ℝ) / 4000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-166302913 : ℝ) / 100000000) ((-74757687 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-143152453 : ℝ) / 100000000) ((-3850257 : ℝ) / 3125000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((71 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1276591 : ℝ) / 20000000) ((1635049 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((26635049 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((71 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-132955371 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((71 : ℝ) / 25) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_36, cov_h_24]
  have hP : ((87086497 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((3850257 : ℝ) / 3125000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((3850257 : ℝ) / 3125000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1307 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1307 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1327 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1327 : ℝ) / 500)) (lo := ((1307 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1347 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1347 : ℝ) / 500)) (lo := ((1327 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1367 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1367 : ℝ) / 500)) (lo := ((1347 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1387 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1387 : ℝ) / 500)) (lo := ((1367 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1407 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1407 : ℝ) / 500)) (lo := ((1387 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((71 : ℝ) / 25)) (lo := ((1407 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_103 {k : ℝ} (hk : RB k ((273 : ℝ) / 128) ((693 : ℝ) / 320)) :
    RB (k / (k + 1)) ((273 : ℝ) / 401) ((693 : ℝ) / 1013) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((273 : ℝ) / 401) ((693 : ℝ) / 1013) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_103 {k : ℝ} (hk : RB k ((273 : ℝ) / 128) ((693 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_103 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_103 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((2516557 : ℝ) / 6250000)) (ph := ((51571 : ℝ) / 125000)) (ml := ((133776153 : ℝ) / 100000000)) (mh := ((134383123 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_103 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_104 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((693 : ℝ) / 1013) ((1407 : ℝ) / 2047))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((40633331 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((41511849 : ℝ) / 100000000) ∧ 0 < certE k a ((133982823 : ℝ) / 100000000) ∧ certE k a ((134576753 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40633331 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((20281991 : ℝ) / 50000000) ((40563983 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((40633331 : ℝ) / 100000000) ((40633331 : ℝ) / 100000000) ((40633331 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59366669 : ℝ) / 100000000))
  have h3 : RB z3 ((1067623 : ℝ) / 1562500) ((546623 : ℝ) / 800000) := rb_div_signed h2 (show RB ((59366669 : ℝ) / 100000000) ((59366669 : ℝ) / 100000000) ((59366669 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-38085243 : ℝ) / 100000000) ((-38085237 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1868.1 cov_log_1869.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-26177791 : ℝ) / 100000000) ((-13027181 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40633331 : ℝ) / 100000000))
  have h6 : RB z6 ((-90058151 : ℝ) / 100000000) ((-90058149 : ℝ) / 100000000) := rb_log (show RB ((40633331 : ℝ) / 100000000) ((40633331 : ℝ) / 100000000) ((40633331 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1870.1 cov_log_1870.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((31940179 : ℝ) / 50000000) ((64003789 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-235709 : ℝ) / 100000000) ((-56137 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((41511849 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((16577 : ℝ) / 40000) ((41442501 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((41511849 : ℝ) / 100000000) ((41511849 : ℝ) / 100000000) ((41511849 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((58488151 : ℝ) / 100000000))
  have h12 : RB z12 ((8857029 : ℝ) / 12500000) ((35428117 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((58488151 : ℝ) / 100000000) ((58488151 : ℝ) / 100000000) ((58488151 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-34451727 : ℝ) / 100000000) ((-34451723 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_1871.1 cov_log_1872.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-23680303 : ℝ) / 100000000) ((-23568651 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((41511849 : ℝ) / 100000000))
  have h15 : RB z15 ((-8791913 : ℝ) / 10000000) ((-10989891 : ℝ) / 12500000) := rb_log (show RB ((41511849 : ℝ) / 100000000) ((41511849 : ℝ) / 100000000) ((41511849 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1873.1 cov_log_1873.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((2569553 : ℝ) / 4000000) ((64350479 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((61379 : ℝ) / 50000000) ((14651 : ℝ) / 6250000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((133982823 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((66956737 : ℝ) / 50000000) ((5356539 : ℝ) / 4000000) := rb_widen (rb_sub (show RB ((133982823 : ℝ) / 100000000) ((133982823 : ℝ) / 100000000) ((133982823 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((33982823 : ℝ) / 100000000))
  have h21 : RB z21 ((394062241 : ℝ) / 100000000) ((78812449 : ℝ) / 20000000) := rb_div_signed h20 (show RB ((33982823 : ℝ) / 100000000) ((33982823 : ℝ) / 100000000) ((33982823 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((34283467 : ℝ) / 25000000) ((8570867 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_1874.1 cov_log_1875.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((46907093 : ℝ) / 50000000) ((47129301 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((133982823 : ℝ) / 100000000))
  have h24 : RB z24 ((29254141 : ℝ) / 100000000) ((29254143 : ℝ) / 100000000) := rb_log (show RB ((133982823 : ℝ) / 100000000) ((133982823 : ℝ) / 100000000) ((133982823 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1876.1 cov_log_1876.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64560043 : ℝ) / 100000000) ((65004461 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((55497 : ℝ) / 12500000) ((444199 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((134576753 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((33626851 : ℝ) / 25000000) ((26901481 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((134576753 : ℝ) / 100000000) ((134576753 : ℝ) / 100000000) ((134576753 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((34576753 : ℝ) / 100000000))
  have h30 : RB z30 ((38901109 : ℝ) / 10000000) ((194505547 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((34576753 : ℝ) / 100000000) ((34576753 : ℝ) / 100000000) ((34576753 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((67921883 : ℝ) / 50000000) ((13584377 : ℝ) / 10000000) := rb_log h30 (by norm_num) cov_log_1877.1 cov_log_1878.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46465809 : ℝ) / 50000000) ((46685927 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((134576753 : ℝ) / 100000000))
  have h33 : RB z33 ((593929 : ℝ) / 2000000) ((7424113 : ℝ) / 25000000) := rb_log (show RB ((134576753 : ℝ) / 100000000) ((134576753 : ℝ) / 100000000) ((134576753 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1879.1 cov_log_1879.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((31617583 : ℝ) / 50000000) ((15918851 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-880901 : ℝ) / 100000000) ((-440659 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40633331 : ℝ) / 100000000)) ((-235709 : ℝ) / 100000000) ((-56137 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((41511849 : ℝ) / 100000000)) ((61379 : ℝ) / 50000000) ((14651 : ℝ) / 6250000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((133982823 : ℝ) / 100000000)) ((55497 : ℝ) / 12500000) ((444199 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((134576753 : ℝ) / 100000000)) ((-880901 : ℝ) / 100000000) ((-440659 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_104 {k A q d vp vm : ℝ}
    (hk : RB k ((693 : ℝ) / 320) ((1407 : ℝ) / 640))
    (hA : RB A ((693 : ℝ) / 1013) ((1407 : ℝ) / 2047))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((40633331 : ℝ) / 100000000) ((41511849 : ℝ) / 100000000))
    (hm : RB vm ((133982823 : ℝ) / 100000000) ((134576753 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((68363219 : ℝ) / 100000000) ((17171767 : ℝ) / 25000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((33411 : ℝ) / 20000000) ((170671 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99829329 : ℝ) / 100000000) ((19966589 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((58488151 : ℝ) / 100000000) ((59366669 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((7298541 : ℝ) / 12500000) ((11853499 : ℝ) / 20000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((115346901 : ℝ) / 100000000) ((23527671 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((15346901 : ℝ) / 100000000) ((3527671 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((68363219 : ℝ) / 100000000) ((17171767 : ℝ) / 25000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((5153 : ℝ) / 10000000) ((647 : ℝ) / 1250000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((1249353 : ℝ) / 1250000) ((9994847 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((33982823 : ℝ) / 100000000) ((34576753 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((33965233 : ℝ) / 100000000) ((4319867 : ℝ) / 12500000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((19781633 : ℝ) / 10000000) ((101113789 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((29781633 : ℝ) / 10000000) ((151113789 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((283473147 : ℝ) / 50000000) ((651597349 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((1033989 : ℝ) / 3125000) ((33577743 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((693 : ℝ) / 160) ((1407 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((5702963 : ℝ) / 50000000) ((11578749 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((2778317 : ℝ) / 25000000) ((5640829 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((27778317 : ℝ) / 25000000) ((55640829 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((46235487 : ℝ) / 50000000) ((46971711 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((43893273 : ℝ) / 25000000) ((178368809 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((54441683 : ℝ) / 100000000) ((55865299 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((62067 : ℝ) / 50000000) ((127383 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99872617 : ℝ) / 100000000) ((49937933 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((175349441 : ℝ) / 100000000) ((178147393 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1013 : ℝ) / 320) ((2047 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((125061 : ℝ) / 4000000) ((631787 : ℝ) / 20000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3171869 : ℝ) / 50000000) ((6480897 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((53171869 : ℝ) / 50000000) ((106480897 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((602911881 : ℝ) / 100000000) ((693826703 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1956803 : ℝ) / 100000000) ((1965479 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101956803 : ℝ) / 100000000) ((101965479 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((8433777 : ℝ) / 25000000) ((34237707 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((636646989 : ℝ) / 100000000) ((72806441 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((19904927 : ℝ) / 100000000) ((11499541 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1013 : ℝ) / 320) ((2047 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((27778317 : ℝ) / 12500000) ((55640829 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((300016971 : ℝ) / 50000000) ((171293773 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((333358661 : ℝ) / 25000000) ((762474203 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((20758899 : ℝ) / 100000000) ((23986459 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-157219519 : ℝ) / 100000000) ((-17846009 : ℝ) / 12500000) := rb_log h47 (by norm_num) cov_log_1880.1 cov_log_1881.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((34712837 : ℝ) / 25000000) ((140955167 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-40180481 : ℝ) / 25000000) ((-3965451 : ℝ) / 2500000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2647827 : ℝ) / 50000000) ((8093607 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((23025501 : ℝ) / 100000000) ((1626453 : ℝ) / 4000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-137696423 : ℝ) / 100000000) ((-23591343 : ℝ) / 20000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((27778317 : ℝ) / 25000000) ((55640829 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-157219519 : ℝ) / 100000000) ((-17846009 : ℝ) / 12500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-137696423 : ℝ) / 100000000) ((-23591343 : ℝ) / 20000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((283 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3171869 : ℝ) / 50000000) ((6480897 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((106480897 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((283 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-3091229 : ℝ) / 2500000) ≤ formC0 k A q vp vm + hfun ((283 : ℝ) / 100) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_37, cov_h_24]
  have hP : ((166496899 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((23591343 : ℝ) / 20000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((23591343 : ℝ) / 20000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2687 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2687 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2727 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2727 : ℝ) / 1000)) (lo := ((2687 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2767 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2767 : ℝ) / 1000)) (lo := ((2727 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2807 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2807 : ℝ) / 1000)) (lo := ((2767 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((2807 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_104 {k : ℝ} (hk : RB k ((693 : ℝ) / 320) ((1407 : ℝ) / 640)) :
    RB (k / (k + 1)) ((693 : ℝ) / 1013) ((1407 : ℝ) / 2047) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((693 : ℝ) / 1013) ((1407 : ℝ) / 2047) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_104 {k : ℝ} (hk : RB k ((693 : ℝ) / 320) ((1407 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_104 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_104 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40633331 : ℝ) / 100000000)) (ph := ((41511849 : ℝ) / 100000000)) (ml := ((133982823 : ℝ) / 100000000)) (mh := ((134576753 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_104 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
