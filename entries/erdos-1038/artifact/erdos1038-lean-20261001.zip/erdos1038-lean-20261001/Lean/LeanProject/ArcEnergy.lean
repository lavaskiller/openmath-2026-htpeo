import LeanProject.CircLog
import Mathlib.Analysis.SpecialFunctions.Complex.LogBounds
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.PSeries

/-!
# EP-1038, Stage 12, Lemma 12.7(a): the arc energy as a sine series

* `Kl l u = log |1 - l e^{iu}|` (`0 ≤ l ≤ 1`); `Kl_hasSum`: for `0 ≤ l < 1`,
  `-K_l(u) = ∑_{m ≥ 1} l^m cos(m u) / m`.
* `int_cos_diff`, `int_cos`: `∫_{-R}^{R} cos(m(θ - φ)) dφ = 2 cos(mθ) sin(mR)/m` and
  `∫_{-Q}^{Q} cos(mθ) dθ = 2 sin(mQ)/m`.
* `double_hasSum`: for `0 ≤ l < 1`, termwise integration of the series over `[-Q, Q] × [-R, R]`.
* `lk k = 1 - 1/(k+2) → 1`; `Kl_bound`, `Bd`: the majorant `log 2 + |log |sin u||` (for `l ≥ 1/2`);
  `inner_tendsto`, `outer_tendsto`: dominated convergence of the double integral as `l = lk k → 1`.
* `arc_series` (**Lemma 12.7(a)**, unnormalized): for `R ≥ 0`,
  `∫_{-Q}^{Q} ∫_{-R}^{R} log|1 - e^{i(θ-φ)}| dφ dθ = -∑_{n ≥ 1} 4 sin(nQ) sin(nR)/n³`
  (the right-hand limit by Tannery's theorem `tendsto_tsum_of_dominated_convergence`).
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- `K_l(u) = log |1 - l e^{iu}|`. -/
noncomputable def Kl (l u : ℝ) : ℝ :=
  Real.log ‖(1 : ℂ) - (l : ℂ) * Complex.exp ((u : ℂ) * Complex.I)‖

theorem norm_l_exp (l u : ℝ) (h0 : 0 ≤ l) : ‖(l : ℂ) * Complex.exp ((u : ℂ) * Complex.I)‖ = l := by
  rw [norm_mul, Complex.norm_exp_ofReal_mul_I, mul_one, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg h0]

/-- The power series of `-K_l`. -/
theorem Kl_hasSum {l : ℝ} (h0 : 0 ≤ l) (h1 : l < 1) (u : ℝ) :
    HasSum (fun n : ℕ => l ^ (n + 1) * Real.cos ((n + 1) * u) / (n + 1)) (-Kl l u) := by
  set z : ℂ := (l : ℂ) * Complex.exp ((u : ℂ) * Complex.I) with hz
  have hzn : ‖z‖ < 1 := by rw [hz, norm_l_exp l u h0]; exact h1
  have h := Complex.reCLM.hasSum (Complex.hasSum_taylorSeries_neg_log' hzn)
  have e1 : ∀ n : ℕ, Complex.reCLM (z ^ (n + 1) / (n + 1)) =
      l ^ (n + 1) * Real.cos ((n + 1) * u) / (n + 1) := by
    intro n
    have hpow : z ^ (n + 1) / ((n : ℂ) + 1) =
        ((l ^ (n + 1) / (n + 1) : ℝ) : ℂ) * Complex.exp ((((n + 1) * u : ℝ) : ℂ) * Complex.I) := by
      rw [hz, mul_pow, ← Complex.exp_nat_mul]
      push_cast
      ring_nf
    rw [Complex.reCLM_apply, hpow, Complex.re_ofReal_mul, Complex.exp_ofReal_mul_I_re]
    ring
  have e2 : Complex.reCLM (-Complex.log (1 - z)) = -Kl l u := by
    rw [Complex.reCLM_apply, Complex.neg_re, Complex.log_re]
    rfl
  rw [e2] at h
  have e3 : (fun n : ℕ => Complex.reCLM (z ^ (n + 1) / ((n : ℂ) + 1))) =
      fun n : ℕ => l ^ (n + 1) * Real.cos ((n + 1) * u) / (n + 1) := funext e1
  rw [e3] at h
  exact h

/-- `∫_{-R}^{R} cos(m(θ - φ)) dφ = 2 cos(mθ) sin(mR)/m`. -/
theorem int_cos_diff {m : ℝ} (hm : m ≠ 0) (θ R : ℝ) :
    ∫ φ in (-R)..R, Real.cos (m * (θ - φ)) = 2 * Real.cos (m * θ) * Real.sin (m * R) / m := by
  have e : (fun φ => Real.cos (m * (θ - φ))) = fun φ => Real.cos (m * θ - m * φ) := by
    funext φ; ring_nf
  rw [e, intervalIntegral.integral_comp_sub_mul (fun x => Real.cos x) hm, integral_cos,
    smul_eq_mul]
  rw [show m * θ - m * -R = m * θ + m * R by ring, Real.sin_add, Real.sin_sub]
  field_simp
  ring

/-- `∫_{-Q}^{Q} cos(mθ) dθ = 2 sin(mQ)/m`. -/
theorem int_cos {m : ℝ} (hm : m ≠ 0) (Q : ℝ) :
    ∫ θ in (-Q)..Q, Real.cos (m * θ) = 2 * Real.sin (m * Q) / m := by
  rw [intervalIntegral.integral_comp_mul_left (fun x => Real.cos x) hm, integral_cos,
    show m * -Q = -(m * Q) by ring, Real.sin_neg, smul_eq_mul]
  field_simp
  ring

/-! ### Termwise integration -/

theorem summable_pow_succ {l : ℝ} (h0 : 0 ≤ l) (h1 : l < 1) : Summable (fun n : ℕ => l ^ (n + 1)) :=
  (summable_nat_add_iff 1).mpr (summable_geometric_of_lt_one h0 h1)

theorem aux_bound1 {p c m : ℝ} (hp : 0 ≤ p) (hm : 1 ≤ m) (hc : |c| ≤ 1) : |p * c / m| ≤ p := by
  have hm0 : 0 < m := by linarith
  rw [abs_div, abs_mul, abs_of_nonneg hp, abs_of_pos hm0, div_le_iff₀ hm0]
  nlinarith [abs_nonneg c]

theorem aux_bound2 {p c s m : ℝ} (hp : 0 ≤ p) (hm : 1 ≤ m) (hc : |c| ≤ 1) (hs : |s| ≤ 1) :
    |p / m * (2 * c * s / m)| ≤ 2 * p := by
  have hm0 : 0 < m := by linarith
  rw [abs_mul, abs_div, abs_div, abs_of_nonneg hp, abs_of_pos hm0, abs_mul, abs_mul, abs_two]
  have h2 : p / m ≤ p := div_le_self hp hm
  have h3 : 2 * |c| * |s| / m ≤ 2 := by
    rw [div_le_iff₀ hm0]; nlinarith [abs_nonneg c, abs_nonneg s]
  calc p / m * (2 * |c| * |s| / m) ≤ p * 2 :=
        mul_le_mul h2 h3 (by positivity) hp
    _ = 2 * p := by ring

theorem one_le_succ (n : ℕ) : (1 : ℝ) ≤ n + 1 := by
  have : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  linarith

theorem Kl_continuous {l : ℝ} (h0 : 0 ≤ l) (h1 : l < 1) : Continuous (Kl l) := by
  unfold Kl
  refine Continuous.log (by fun_prop) (fun u => ?_)
  have : l < ‖(1 : ℂ)‖ := by rw [norm_one]; exact h1
  have h := norm_sub_norm_le (1 : ℂ) ((l : ℂ) * Complex.exp ((u : ℂ) * Complex.I))
  rw [norm_l_exp l u h0, norm_one] at h
  exact norm_ne_zero_iff.mpr (fun h' => by rw [h', norm_zero] at h; linarith)

/-- The inner integral as a series. -/
theorem inner_hasSum {l : ℝ} (h0 : 0 ≤ l) (h1 : l < 1) (θ R : ℝ) :
    HasSum (fun n : ℕ => l ^ (n + 1) / (n + 1) *
        (2 * Real.cos ((n + 1) * θ) * Real.sin ((n + 1) * R) / (n + 1)))
      (∫ φ in (-R)..R, -Kl l (θ - φ)) := by
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence (μ := volume) (a := -R) (b := R)
    (F := fun (n : ℕ) (φ : ℝ) => l ^ (n + 1) * Real.cos ((n + 1) * (θ - φ)) / (n + 1))
    (f := fun φ => -Kl l (θ - φ)) (fun n _ => l ^ (n + 1))
    (fun n => (Continuous.aestronglyMeasurable (by fun_prop)))
    (fun n => Filter.Eventually.of_forall fun φ _ => by
      rw [Real.norm_eq_abs]
      exact aux_bound1 (pow_nonneg h0 _) (one_le_succ n) (Real.abs_cos_le_one _))
    (Filter.Eventually.of_forall fun φ _ => summable_pow_succ h0 h1)
    intervalIntegrable_const
    (Filter.Eventually.of_forall fun φ _ => Kl_hasSum h0 h1 (θ - φ))
  have hterm : ∀ n : ℕ, (∫ φ in (-R)..R, l ^ (n + 1) * Real.cos ((n + 1) * (θ - φ)) / (n + 1)) =
      l ^ (n + 1) / (n + 1) * (2 * Real.cos ((n + 1) * θ) * Real.sin ((n + 1) * R) / (n + 1)) := by
    intro n
    have hm : ((n : ℝ) + 1) ≠ 0 := by positivity
    rw [← int_cos_diff hm θ R, ← intervalIntegral.integral_const_mul]
    refine intervalIntegral.integral_congr (fun φ _ => ?_)
    show l ^ (n + 1) * Real.cos ((n + 1) * (θ - φ)) / (n + 1) =
      l ^ (n + 1) / (n + 1) * Real.cos ((n + 1) * (θ - φ))
    ring
  rw [show (fun n : ℕ => ∫ φ in (-R)..R, l ^ (n + 1) * Real.cos ((n + 1) * (θ - φ)) / (n + 1)) =
    _ from funext hterm] at h
  exact h

/-- The double integral as a series. -/
theorem double_hasSum {l : ℝ} (h0 : 0 ≤ l) (h1 : l < 1) (Q R : ℝ) :
    HasSum (fun n : ℕ => l ^ (n + 1) / (n + 1) *
        (4 * Real.sin ((n + 1) * Q) * Real.sin ((n + 1) * R) / (n + 1) ^ 2))
      (∫ θ in (-Q)..Q, ∫ φ in (-R)..R, -Kl l (θ - φ)) := by
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence (μ := volume) (a := -Q) (b := Q)
    (F := fun (n : ℕ) (θ : ℝ) => l ^ (n + 1) / (n + 1) *
      (2 * Real.cos ((n + 1) * θ) * Real.sin ((n + 1) * R) / (n + 1)))
    (f := fun θ => ∫ φ in (-R)..R, -Kl l (θ - φ)) (fun n _ => 2 * l ^ (n + 1))
    (fun n => (Continuous.aestronglyMeasurable (by fun_prop)))
    (fun n => Filter.Eventually.of_forall fun θ _ => by
      rw [Real.norm_eq_abs]
      exact aux_bound2 (pow_nonneg h0 _) (one_le_succ n) (Real.abs_cos_le_one _)
        (Real.abs_sin_le_one _))
    (Filter.Eventually.of_forall fun θ _ => (summable_pow_succ h0 h1).mul_left 2)
    intervalIntegrable_const
    (Filter.Eventually.of_forall fun θ _ => inner_hasSum h0 h1 θ R)
  have hterm : ∀ n : ℕ, (∫ θ in (-Q)..Q, l ^ (n + 1) / (n + 1) *
      (2 * Real.cos ((n + 1) * θ) * Real.sin ((n + 1) * R) / (n + 1))) =
      l ^ (n + 1) / (n + 1) * (4 * Real.sin ((n + 1) * Q) * Real.sin ((n + 1) * R) / (n + 1) ^ 2) := by
    intro n
    have hm : ((n : ℝ) + 1) ≠ 0 := by positivity
    have e : (fun θ : ℝ => l ^ (n + 1) / (n + 1) *
        (2 * Real.cos ((n + 1) * θ) * Real.sin ((n + 1) * R) / (n + 1))) =
        fun θ => (l ^ (n + 1) / (n + 1) * (2 * Real.sin ((n + 1) * R) / (n + 1))) *
          Real.cos ((n + 1) * θ) := by
      funext θ; ring
    rw [e, intervalIntegral.integral_const_mul, int_cos hm Q]
    field_simp
    ring
  rw [show (fun n : ℕ => ∫ θ in (-Q)..Q, l ^ (n + 1) / (n + 1) *
      (2 * Real.cos ((n + 1) * θ) * Real.sin ((n + 1) * R) / (n + 1))) = _ from funext hterm] at h
  exact h

/-! ### The limit `l → 1` (Lemma 12.7(a)) -/

/-- The approximating radii `l_k = 1 - 1/(k+2) ∈ [1/2, 1)`. -/
noncomputable def lk (k : ℕ) : ℝ := 1 - 1 / ((k : ℝ) + 2)

theorem lk_mem (k : ℕ) : 1 / 2 ≤ lk k ∧ lk k < 1 := by
  unfold lk
  have hk : (0 : ℝ) ≤ k := Nat.cast_nonneg k
  constructor
  · rw [show (1 : ℝ) / 2 = 1 - 1 / 2 by norm_num]
    apply sub_le_sub_left
    exact one_div_le_one_div_of_le (by norm_num) (by linarith)
  · have : (0 : ℝ) < 1 / ((k : ℝ) + 2) := by positivity
    linarith

theorem lk_tendsto : Tendsto lk atTop (𝓝 1) := by
  have h := (tendsto_const_div_atTop_nhds_zero_nat (1 : ℝ)).comp (Filter.tendsto_add_atTop_nat 2)
  have h' : Tendsto (fun k : ℕ => 1 - 1 / ((k : ℝ) + 2)) atTop (𝓝 (1 - 0)) := by
    refine tendsto_const_nhds.sub (h.congr (fun k => ?_))
    simp only [Function.comp_apply]
    push_cast; ring
  rw [sub_zero] at h'
  exact h'

theorem Kl_bound {l u : ℝ} (hl0 : 1 / 2 ≤ l) (hl1 : l ≤ 1) (hs : Real.sin u ≠ 0) :
    |Kl l u| ≤ Real.log 2 + |Real.log (|Real.sin u|)| := by
  unfold Kl
  set w : ℂ := 1 - (l : ℂ) * Complex.exp ((u : ℂ) * Complex.I) with hw
  have him : w.im = -(l * Real.sin u) := by
    rw [hw, Complex.sub_im, Complex.one_im, Complex.im_ofReal_mul, Complex.exp_ofReal_mul_I_im]
    ring
  have hspos : 0 < |Real.sin u| := abs_pos.mpr hs
  have hlow : l * |Real.sin u| ≤ ‖w‖ := by
    have h := Complex.abs_im_le_norm w
    rw [him, abs_neg, abs_mul, abs_of_nonneg (by linarith)] at h
    exact h
  have hup : ‖w‖ ≤ 2 := by
    calc ‖w‖ ≤ ‖(1 : ℂ)‖ + ‖(l : ℂ) * Complex.exp ((u : ℂ) * Complex.I)‖ := norm_sub_le _ _
      _ = 1 + l := by rw [norm_one, norm_l_exp l u (by linarith)]
      _ ≤ 2 := by linarith
  have hlpos : 0 < l * |Real.sin u| := mul_pos (by linarith) hspos
  have hwpos : 0 < ‖w‖ := lt_of_lt_of_le hlpos hlow
  rw [abs_le]
  constructor
  · have h1 : Real.log (l * |Real.sin u|) ≤ Real.log ‖w‖ := Real.log_le_log hlpos hlow
    have h2 : Real.log (l * |Real.sin u|) = Real.log l + Real.log |Real.sin u| :=
      Real.log_mul (by linarith) (ne_of_gt hspos)
    have h3 : Real.log (1 / 2) ≤ Real.log l := Real.log_le_log (by norm_num) hl0
    rw [one_div, Real.log_inv] at h3
    have h4 := neg_abs_le (Real.log |Real.sin u|)
    linarith
  · have h5 := Real.log_le_log hwpos hup
    have h6 := abs_nonneg (Real.log |Real.sin u|)
    linarith

theorem norm_one_sub_exp (u : ℝ) :
    ‖(1 : ℂ) - ((1 : ℝ) : ℂ) * Complex.exp ((u : ℂ) * Complex.I)‖ = 2 * |Real.sin (u / 2)| := by
  rw [Complex.ofReal_one, one_mul, norm_sub_rev, mul_comm (u : ℂ) Complex.I,
    Complex.norm_exp_I_mul_ofReal_sub_one, norm_mul, Real.norm_eq_abs, Real.norm_eq_abs, abs_two]

/-- `K_1(u) = log|2 sin(u/2)| = log 2 - L(u)` off the null set `2πℤ` (`L = Circ.Lsin`). -/
theorem Kl_one_eq {u : ℝ} (hs : Real.sin (u / 2) ≠ 0) : Kl 1 u = Real.log 2 - Circ.Lsin u := by
  unfold Kl Circ.Lsin
  rw [norm_one_sub_exp, Real.log_mul (by norm_num) (abs_ne_zero.mpr hs)]
  ring

theorem Kl_tendsto {u : ℝ} (hs : Real.sin u ≠ 0) :
    Tendsto (fun k : ℕ => Kl (lk k) u) atTop (𝓝 (Kl 1 u)) := by
  have hne : ‖(1 : ℂ) - ((1 : ℝ) : ℂ) * Complex.exp ((u : ℂ) * Complex.I)‖ ≠ 0 := by
    rw [norm_one_sub_exp]
    have h2 : Real.sin (u / 2) ≠ 0 := by
      intro h
      apply hs
      rw [show u = 2 * (u / 2) by ring, Real.sin_two_mul, h]
      ring
    positivity
  unfold Kl
  refine Tendsto.log ?_ hne
  refine (continuous_norm.tendsto _).comp ?_
  have hc : Continuous (fun l : ℝ => (1 : ℂ) - (l : ℂ) * Complex.exp ((u : ℂ) * Complex.I)) := by
    fun_prop
  exact (hc.tendsto 1).comp lk_tendsto

theorem ae_sin_ne' (c : ℝ) : ∀ᵐ u ∂(volume : Measure ℝ), Real.sin (c - u) ≠ 0 := by
  have hsub : {u : ℝ | Real.sin (c - u) = 0} ⊆ Set.range (fun k : ℤ => c - π * k) := by
    intro u hu
    obtain ⟨k, hk⟩ := Real.sin_eq_zero_iff.mp hu
    exact ⟨k, by simp only; linarith⟩
  have hnull : volume {u : ℝ | Real.sin (c - u) = 0} = 0 :=
    measure_mono_null hsub ((Set.countable_range _).measure_zero _)
  rw [ae_iff]
  simpa using hnull

theorem logsin_ii (c a b : ℝ) :
    IntervalIntegrable (fun φ => Real.log |Real.sin (c - φ)|) volume a b := by
  have h := (intervalIntegrable_log_sin (a := c - a) (b := c - b)).comp_sub_left c
  simp only [sub_sub_cancel] at h
  have e : (fun φ => Real.log |Real.sin (c - φ)|) = fun x => (Real.log ∘ Real.sin) (c - x) := by
    funext φ; simp [Real.log_abs]
  rw [e]
  exact h

/-- The dominating function `B(s) = log 2 + |log|sin s||`. -/
noncomputable def Bd (s : ℝ) : ℝ := Real.log 2 + |Real.log (|Real.sin s|)|

theorem Bd_ii (c a b : ℝ) : IntervalIntegrable (fun φ => Bd (c - φ)) volume a b :=
  intervalIntegrable_const.add (logsin_ii c a b).abs

theorem Bd_ii' (a b : ℝ) : IntervalIntegrable Bd volume a b := by
  have h := (Bd_ii 0 (-b) (-a)).comp_sub_left 0
  simp only [zero_sub, sub_neg_eq_add, zero_add] at h
  exact h.symm

/-- `θ ↦ ∫_{-R}^{R} g(θ - φ) dφ` is continuous when `g` is integrable on every interval. -/
theorem cont_window {g : ℝ → ℝ} (hg : ∀ a b, IntervalIntegrable g volume a b) (R : ℝ) :
    Continuous (fun θ => ∫ φ in (-R)..R, g (θ - φ)) := by
  have hP := intervalIntegral.continuous_primitive (μ := volume) hg 0
  have e : (fun θ => ∫ φ in (-R)..R, g (θ - φ)) =
      fun θ => (∫ s in (0 : ℝ)..(θ + R), g s) - ∫ s in (0 : ℝ)..(θ - R), g s := by
    funext θ
    rw [intervalIntegral.integral_comp_sub_left g θ, sub_neg_eq_add,
      intervalIntegral.integral_interval_sub_left (hg _ _) (hg _ _)]
  rw [e]
  exact (hP.comp (continuous_id.add continuous_const)).sub
    (hP.comp (continuous_id.sub continuous_const))

theorem inner_tendsto (θ R : ℝ) :
    Tendsto (fun k : ℕ => ∫ φ in (-R)..R, Kl (lk k) (θ - φ)) atTop
      (𝓝 (∫ φ in (-R)..R, Kl 1 (θ - φ))) := by
  refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
    (fun φ => Bd (θ - φ)) (Eventually.of_forall fun k =>
      ((Kl_continuous (by linarith [(lk_mem k).1]) (lk_mem k).2).comp
        (continuous_const.sub continuous_id)).aestronglyMeasurable) ?_ (Bd_ii θ _ _) ?_
  · refine Eventually.of_forall fun k => ?_
    filter_upwards [ae_sin_ne' θ] with φ hφ _
    rw [Real.norm_eq_abs]
    exact Kl_bound (lk_mem k).1 (lk_mem k).2.le hφ
  · filter_upwards [ae_sin_ne' θ] with φ hφ _
    exact Kl_tendsto hφ

theorem outer_tendsto {Q R : ℝ} (hR : 0 ≤ R) :
    Tendsto (fun k : ℕ => ∫ θ in (-Q)..Q, ∫ φ in (-R)..R, Kl (lk k) (θ - φ)) atTop
      (𝓝 (∫ θ in (-Q)..Q, ∫ φ in (-R)..R, Kl 1 (θ - φ))) := by
  refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
    (fun θ => ∫ φ in (-R)..R, Bd (θ - φ)) (Eventually.of_forall fun k => ?_) ?_
    ((cont_window Bd_ii' R).intervalIntegrable _ _)
    (Eventually.of_forall fun θ _ => inner_tendsto θ R)
  · have hc := Kl_continuous (by linarith [(lk_mem k).1]) (lk_mem k).2
    exact (cont_window (fun a b => hc.intervalIntegrable a b) R).aestronglyMeasurable
  · refine Eventually.of_forall fun k => Eventually.of_forall fun θ _ => ?_
    have hc := Kl_continuous (by linarith [(lk_mem k).1]) (lk_mem k).2
    rw [Real.norm_eq_abs]
    calc |∫ φ in (-R)..R, Kl (lk k) (θ - φ)| ≤ ∫ φ in (-R)..R, |Kl (lk k) (θ - φ)| :=
          intervalIntegral.abs_integral_le_integral_abs (by linarith)
      _ ≤ ∫ φ in (-R)..R, Bd (θ - φ) := by
          refine intervalIntegral.integral_mono_ae (by linarith)
            ((hc.comp (continuous_const.sub continuous_id)).intervalIntegrable _ _).abs
            (Bd_ii θ _ _) ?_
          filter_upwards [ae_sin_ne' θ] with φ hφ
          exact Kl_bound (lk_mem k).1 (lk_mem k).2.le hφ

theorem aux_bound3 {p c s m : ℝ} (hp0 : 0 ≤ p) (hp1 : p ≤ 1) (hm : 1 ≤ m) (hc : |c| ≤ 1)
    (hs : |s| ≤ 1) : |p / m * (4 * c * s / m ^ 2)| ≤ 4 * (1 / m ^ 3) := by
  have hm0 : 0 < m := by linarith
  have hcs : |c| * |s| ≤ 1 := by nlinarith [abs_nonneg c, abs_nonneg s]
  have e : |p / m * (4 * c * s / m ^ 2)| = p * (|c| * |s|) * 4 / m ^ 3 := by
    rw [abs_mul, abs_div, abs_div, abs_of_nonneg hp0, abs_of_pos hm0, abs_mul, abs_mul,
      abs_of_pos (by positivity : (0 : ℝ) < m ^ 2), abs_of_pos (by norm_num : (0 : ℝ) < 4)]
    field_simp
  have hpcs : p * (|c| * |s|) ≤ 1 := by
    calc p * (|c| * |s|) ≤ 1 * 1 := mul_le_mul hp1 hcs (by positivity) (by norm_num)
      _ = 1 := by norm_num
  rw [e, show 4 * (1 / m ^ 3) = 1 * 4 / m ^ 3 by ring]
  apply div_le_div_of_nonneg_right _ (by positivity)
  nlinarith

/-- **Lemma 12.7(a)**: `∫_{-Q}^{Q} ∫_{-R}^{R} log|1 - e^{i(θ-φ)}| dφ dθ
= -∑_{n ≥ 1} 4 sin(nQ) sin(nR)/n³`, i.e. `𝒜(Q, R) = -∑ sin(nQ) sin(nR)/(n³QR)`. -/
theorem arc_series {Q R : ℝ} (hR : 0 ≤ R) :
    ∫ θ in (-Q)..Q, ∫ φ in (-R)..R, Kl 1 (θ - φ) =
      -∑' n : ℕ, 1 / ((n : ℝ) + 1) * (4 * Real.sin ((n + 1) * Q) * Real.sin ((n + 1) * R) /
        ((n : ℝ) + 1) ^ 2) := by
  have t1 := outer_tendsto (Q := Q) hR
  have e : ∀ k : ℕ, (∫ θ in (-Q)..Q, ∫ φ in (-R)..R, Kl (lk k) (θ - φ)) =
      -∑' n : ℕ, lk k ^ (n + 1) / (n + 1) *
        (4 * Real.sin ((n + 1) * Q) * Real.sin ((n + 1) * R) / (n + 1) ^ 2) := by
    intro k
    rw [(double_hasSum (by linarith [(lk_mem k).1]) (lk_mem k).2 Q R).tsum_eq]
    simp only [intervalIntegral.integral_neg, neg_neg]
  have hs3 : Summable (fun n : ℕ => 4 * (1 / ((n : ℝ) + 1) ^ 3)) := by
    have h := (summable_nat_add_iff 1).mpr
      (summable_one_div_nat_pow.mpr (by norm_num : 1 < 3))
    refine (h.congr (fun n => ?_)).mul_left 4
    push_cast; ring
  have t2 : Tendsto (fun k : ℕ => ∑' n : ℕ, lk k ^ (n + 1) / (n + 1) *
      (4 * Real.sin ((n + 1) * Q) * Real.sin ((n + 1) * R) / (n + 1) ^ 2)) atTop
      (𝓝 (∑' n : ℕ, 1 / ((n : ℝ) + 1) * (4 * Real.sin ((n + 1) * Q) * Real.sin ((n + 1) * R) /
        ((n : ℝ) + 1) ^ 2))) := by
    refine tendsto_tsum_of_dominated_convergence hs3 (fun n => ?_)
      (Eventually.of_forall fun k n => ?_)
    · have h := ((lk_tendsto.pow (n + 1)).div_const ((n : ℝ) + 1)).mul_const
        (4 * Real.sin ((n + 1) * Q) * Real.sin ((n + 1) * R) / ((n : ℝ) + 1) ^ 2)
      rw [one_pow] at h
      exact h
    · rw [Real.norm_eq_abs]
      exact aux_bound3 (pow_nonneg (by linarith [(lk_mem k).1]) _)
        (pow_le_one₀ (by linarith [(lk_mem k).1]) (lk_mem k).2.le) (one_le_succ n)
        (Real.abs_sin_le_one _) (Real.abs_sin_le_one _)
  have t1' := t1.congr e
  exact tendsto_nhds_unique t1' t2.neg

end EP1038.Arc
