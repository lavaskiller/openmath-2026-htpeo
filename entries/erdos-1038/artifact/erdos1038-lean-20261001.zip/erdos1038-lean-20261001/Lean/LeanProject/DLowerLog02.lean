import LeanProject.DLowerArithmetic
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_120 : RB (Real.log ((31930744057 : ℝ) / 4000000000000)) ((-1207620082723 : ℝ) / 250000000000) ((-483048033089 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((31930744057 : ℝ) / 31250000000)) (t := ((680744057 : ℝ) / 63180744057))
    (lo := ((5387483257 : ℝ) / 250000000000)) (hi := ((21549933029 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31930744057 : ℝ) / 4000000000000) = Real.log ((31930744057 : ℝ) / 31250000000) - 7 * Real.log 2 := by
    rw [show ((31930744057 : ℝ) / 4000000000000) = ((31930744057 : ℝ) / 31250000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_121 : RB (Real.log ((503991343007 : ℝ) / 500000000000)) ((248468529 : ℝ) / 31250000000) ((7950992929 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((503991343007 : ℝ) / 500000000000)) (t := ((3991343007 : ℝ) / 1003991343007))
    (lo := ((248468529 : ℝ) / 31250000000)) (hi := ((7950992929 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_122 : RB (Real.log ((252157373609 : ℝ) / 250000000000)) ((8592473179 : ℝ) / 1000000000000) ((429623659 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((252157373609 : ℝ) / 250000000000)) (t := ((2157373609 : ℝ) / 502157373609))
    (lo := ((8592473179 : ℝ) / 1000000000000)) (hi := ((429623659 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_123 : RB (Real.log ((962152129781 : ℝ) / 1000000000000)) ((-19291350877 : ℝ) / 500000000000) ((-38582701753 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((962152129781 : ℝ) / 1000000000000)) (t := ((-37847870219 : ℝ) / 1962152129781))
    (lo := ((-19291350877 : ℝ) / 500000000000)) (hi := ((-38582701753 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_124 : RB (Real.log ((962173214479 : ℝ) / 1000000000000)) ((-19280393947 : ℝ) / 500000000000) ((-38560787893 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((962173214479 : ℝ) / 1000000000000)) (t := ((-37826785521 : ℝ) / 1962173214479))
    (lo := ((-19280393947 : ℝ) / 500000000000)) (hi := ((-38560787893 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_125 : RB (Real.log ((122598368311 : ℝ) / 250000000000)) ((-142509440699 : ℝ) / 200000000000) ((-712547203493 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((122598368311 : ℝ) / 125000000000)) (t := ((-2401631689 : ℝ) / 247598368311))
    (lo := ((-3880004587 : ℝ) / 200000000000)) (hi := ((-9700011467 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((122598368311 : ℝ) / 250000000000) = Real.log ((122598368311 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((122598368311 : ℝ) / 250000000000) = ((122598368311 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_126 : RB (Real.log ((837541585523 : ℝ) / 250000000000)) ((1209009998959 : ℝ) / 1000000000000) ((1209009998961 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((837541585523 : ℝ) / 1000000000000)) (t := ((-162458414477 : ℝ) / 1837541585523))
    (lo := ((-2216054527 : ℝ) / 12500000000)) (hi := ((-177284362159 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((837541585523 : ℝ) / 250000000000) = Real.log ((837541585523 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((837541585523 : ℝ) / 250000000000) = ((837541585523 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_127 : RB (Real.log ((3350191596273 : ℝ) / 1000000000000)) ((1209017537117 : ℝ) / 1000000000000) ((1209017537119 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3350191596273 : ℝ) / 4000000000000)) (t := ((-649808403727 : ℝ) / 7350191596273))
    (lo := ((-88638412001 : ℝ) / 500000000000)) (hi := ((-177276824001 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3350191596273 : ℝ) / 1000000000000) = Real.log ((3350191596273 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3350191596273 : ℝ) / 1000000000000) = ((3350191596273 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_128 : RB (Real.log ((22272970467 : ℝ) / 15625000000)) ((354501660989 : ℝ) / 1000000000000) ((5539088453 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((22272970467 : ℝ) / 31250000000)) (t := ((-8977029533 : ℝ) / 53522970467))
    (lo := ((-33864551957 : ℝ) / 100000000000)) (hi := ((-21165344973 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22272970467 : ℝ) / 15625000000) = Real.log ((22272970467 : ℝ) / 31250000000) + 1 * Real.log 2 := by
    rw [show ((22272970467 : ℝ) / 15625000000) = ((22272970467 : ℝ) / 31250000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_129 : RB (Real.log ((232641665837 : ℝ) / 25000000000000)) ((-4677131748953 : ℝ) / 1000000000000) ((-4677131748951 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((232641665837 : ℝ) / 195312500000)) (t := ((37329165837 : ℝ) / 427954165837))
    (lo := ((174898514967 : ℝ) / 1000000000000)) (hi := ((21862314371 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((232641665837 : ℝ) / 25000000000000) = Real.log ((232641665837 : ℝ) / 195312500000) - 7 * Real.log 2 := by
    rw [show ((232641665837 : ℝ) / 25000000000000) = ((232641665837 : ℝ) / 195312500000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_130 : RB (Real.log ((862949443553 : ℝ) / 100000000000000)) ((-4752569357813 : ℝ) / 1000000000000) ((-4752569357811 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((862949443553 : ℝ) / 781250000000)) (t := ((81699443553 : ℝ) / 1644199443553))
    (lo := ((99460906107 : ℝ) / 1000000000000)) (hi := ((24865226527 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((862949443553 : ℝ) / 100000000000000) = Real.log ((862949443553 : ℝ) / 781250000000) - 7 * Real.log 2 := by
    rw [show ((862949443553 : ℝ) / 100000000000000) = ((862949443553 : ℝ) / 781250000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_131 : RB (Real.log ((201725898887 : ℝ) / 200000000000)) ((4296236589 : ℝ) / 500000000000) ((8592473179 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((201725898887 : ℝ) / 200000000000)) (t := ((1725898887 : ℝ) / 401725898887))
    (lo := ((4296236589 : ℝ) / 500000000000)) (hi := ((8592473179 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_132 : RB (Real.log ((504652833317 : ℝ) / 500000000000)) ((4631317833 : ℝ) / 500000000000) ((9262635667 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((504652833317 : ℝ) / 500000000000)) (t := ((4652833317 : ℝ) / 1004652833317))
    (lo := ((4631317833 : ℝ) / 500000000000)) (hi := ((9262635667 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_133 : RB (Real.log ((191743568113 : ℝ) / 200000000000)) ((-42158469951 : ℝ) / 1000000000000) ((-843169399 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((191743568113 : ℝ) / 200000000000)) (t := ((-8256431887 : ℝ) / 391743568113))
    (lo := ((-42158469951 : ℝ) / 1000000000000)) (hi := ((-843169399 : ℝ) / 20000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_134 : RB (Real.log ((1917483193 : ℝ) / 2000000000)) ((-21066845699 : ℝ) / 500000000000) ((-42133691397 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1917483193 : ℝ) / 2000000000)) (t := ((-82516807 : ℝ) / 3917483193))
    (lo := ((-21066845699 : ℝ) / 500000000000)) (hi := ((-42133691397 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_135 : RB (Real.log ((7648533649 : ℝ) / 15625000000)) ((-714358246027 : ℝ) / 1000000000000) ((-28574329841 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((7648533649 : ℝ) / 7812500000)) (t := ((-163966351 : ℝ) / 15461033649))
    (lo := ((-21211065467 : ℝ) / 1000000000000)) (hi := ((-10605532733 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7648533649 : ℝ) / 15625000000) = Real.log ((7648533649 : ℝ) / 7812500000) - 1 * Real.log 2 := by
    rw [show ((7648533649 : ℝ) / 15625000000) = ((7648533649 : ℝ) / 7812500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_136 : RB (Real.log ((3353296419549 : ℝ) / 1000000000000)) ((241988773571 : ℝ) / 200000000000) ((1209943867857 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3353296419549 : ℝ) / 4000000000000)) (t := ((-646703580451 : ℝ) / 7353296419549))
    (lo := ((-11021905829 : ℝ) / 62500000000)) (hi := ((-176350493263 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3353296419549 : ℝ) / 1000000000000) = Real.log ((3353296419549 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3353296419549 : ℝ) / 1000000000000) = ((3353296419549 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_137 : RB (Real.log ((670664992211 : ℝ) / 200000000000)) ((37811011853 : ℝ) / 31250000000) ((604976189649 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((670664992211 : ℝ) / 800000000000)) (t := ((-129335007789 : ℝ) / 1470664992211))
    (lo := ((-176341981823 : ℝ) / 1000000000000)) (hi := ((-88170990911 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((670664992211 : ℝ) / 200000000000) = Real.log ((670664992211 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((670664992211 : ℝ) / 200000000000) = ((670664992211 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_138 : RB (Real.log ((712449523201 : ℝ) / 500000000000)) ((354100966579 : ℝ) / 1000000000000) ((177050483291 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((712449523201 : ℝ) / 1000000000000)) (t := ((-287550476799 : ℝ) / 1712449523201))
    (lo := ((-16952310699 : ℝ) / 50000000000)) (hi := ((-169523106989 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((712449523201 : ℝ) / 500000000000) = Real.log ((712449523201 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((712449523201 : ℝ) / 500000000000) = ((712449523201 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_139 : RB (Real.log ((241369067847 : ℝ) / 25000000000000)) ((-2320151969953 : ℝ) / 500000000000) ((-72504749061 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((241369067847 : ℝ) / 195312500000)) (t := ((46056567847 : ℝ) / 436681567847))
    (lo := ((105863162007 : ℝ) / 500000000000)) (hi := ((42345264803 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((241369067847 : ℝ) / 25000000000000) = Real.log ((241369067847 : ℝ) / 195312500000) - 7 * Real.log 2 := by
    rw [show ((241369067847 : ℝ) / 25000000000000) = ((241369067847 : ℝ) / 195312500000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_140 : RB (Real.log ((930566663343 : ℝ) / 100000000000000)) ((-2338565874479 : ℝ) / 500000000000) ((-1169282937239 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((930566663343 : ℝ) / 781250000000)) (t := ((149316663343 : ℝ) / 1711816663343))
    (lo := ((87449257481 : ℝ) / 500000000000)) (hi := ((174898514963 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((930566663343 : ℝ) / 100000000000000) = Real.log ((930566663343 : ℝ) / 781250000000) - 7 * Real.log 2 := by
    rw [show ((930566663343 : ℝ) / 100000000000000) = ((930566663343 : ℝ) / 781250000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_141 : RB (Real.log ((1009305666633 : ℝ) / 1000000000000)) ((1852527133 : ℝ) / 200000000000) ((4631317833 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1009305666633 : ℝ) / 1000000000000)) (t := ((9305666633 : ℝ) / 2009305666633))
    (lo := ((1852527133 : ℝ) / 200000000000)) (hi := ((4631317833 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_142 : RB (Real.log ((504827381357 : ℝ) / 500000000000)) ((2402113331 : ℝ) / 250000000000) ((384338133 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((504827381357 : ℝ) / 500000000000)) (t := ((4827381357 : ℝ) / 1004827381357))
    (lo := ((2402113331 : ℝ) / 250000000000)) (hi := ((384338133 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_143 : RB (Real.log ((95178488179 : ℝ) / 100000000000)) ((-49416234231 : ℝ) / 1000000000000) ((-4941623423 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((95178488179 : ℝ) / 100000000000)) (t := ((-4821511821 : ℝ) / 195178488179))
    (lo := ((-49416234231 : ℝ) / 1000000000000)) (hi := ((-4941623423 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_144 : RB (Real.log ((237949450471 : ℝ) / 250000000000)) ((-49402659729 : ℝ) / 1000000000000) ((-3087666233 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((237949450471 : ℝ) / 250000000000)) (t := ((-12050549529 : ℝ) / 487949450471))
    (lo := ((-49402659729 : ℝ) / 1000000000000)) (hi := ((-3087666233 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_145 : RB (Real.log ((487696213407 : ℝ) / 1000000000000)) ((-359031290241 : ℝ) / 500000000000) ((-560986391 : ℝ) / 781250000) := by
  have hm := log_bounds_of_series (x := ((487696213407 : ℝ) / 500000000000)) (t := ((-12303786593 : ℝ) / 987696213407))
    (lo := ((-12457699961 : ℝ) / 500000000000)) (hi := ((-24915399921 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((487696213407 : ℝ) / 1000000000000) = Real.log ((487696213407 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((487696213407 : ℝ) / 1000000000000) = ((487696213407 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_146 : RB (Real.log ((3345962368549 : ℝ) / 1000000000000)) ((603877177901 : ℝ) / 500000000000) ((301938588951 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3345962368549 : ℝ) / 4000000000000)) (t := ((-654037631451 : ℝ) / 7345962368549))
    (lo := ((-178540005317 : ℝ) / 1000000000000)) (hi := ((-44635001329 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3345962368549 : ℝ) / 1000000000000) = Real.log ((3345962368549 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3345962368549 : ℝ) / 1000000000000) = ((3345962368549 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_147 : RB (Real.log ((3345977897953 : ℝ) / 1000000000000)) ((301939749257 : ℝ) / 250000000000) ((120775899703 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((3345977897953 : ℝ) / 4000000000000)) (t := ((-654022102047 : ℝ) / 7345977897953))
    (lo := ((-178535364091 : ℝ) / 1000000000000)) (hi := ((-17853536409 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3345977897953 : ℝ) / 1000000000000) = Real.log ((3345977897953 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3345977897953 : ℝ) / 1000000000000) = ((3345977897953 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_148 : RB (Real.log ((89139035193 : ℝ) / 62500000000)) ((177515393607 : ℝ) / 500000000000) ((22189424201 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((89139035193 : ℝ) / 125000000000)) (t := ((-35860964807 : ℝ) / 214139035193))
    (lo := ((-67623278669 : ℝ) / 200000000000)) (hi := ((-2641534323 : ℝ) / 7812500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((89139035193 : ℝ) / 62500000000) = Real.log ((89139035193 : ℝ) / 125000000000) + 1 * Real.log 2 := by
    rw [show ((89139035193 : ℝ) / 62500000000) = ((89139035193 : ℝ) / 125000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_149 : RB (Real.log ((500559623251 : ℝ) / 50000000000000)) ((-71938305709 : ℝ) / 15625000000) ((-2302025782687 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((500559623251 : ℝ) / 390625000000)) (t := ((109934623251 : ℝ) / 891184623251))
    (lo := ((15498668659 : ℝ) / 62500000000)) (hi := ((49595739709 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((500559623251 : ℝ) / 50000000000000) = Real.log ((500559623251 : ℝ) / 390625000000) - 7 * Real.log 2 := by
    rw [show ((500559623251 : ℝ) / 50000000000000) = ((500559623251 : ℝ) / 390625000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_150 : RB (Real.log ((965476271383 : ℝ) / 100000000000000)) ((-4640303939911 : ℝ) / 1000000000000) ((-4640303939909 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((965476271383 : ℝ) / 781250000000)) (t := ((184226271383 : ℝ) / 1746726271383))
    (lo := ((211726324009 : ℝ) / 1000000000000)) (hi := ((21172632401 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((965476271383 : ℝ) / 100000000000000) = Real.log ((965476271383 : ℝ) / 781250000000) - 7 * Real.log 2 := by
    rw [show ((965476271383 : ℝ) / 100000000000000) = ((965476271383 : ℝ) / 781250000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_151 : RB (Real.log ((1009654762713 : ℝ) / 1000000000000)) ((9608453323 : ℝ) / 1000000000000) ((2402113331 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1009654762713 : ℝ) / 1000000000000)) (t := ((9654762713 : ℝ) / 2009654762713))
    (lo := ((9608453323 : ℝ) / 1000000000000)) (hi := ((2402113331 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_152 : RB (Real.log ((505005596233 : ℝ) / 500000000000)) ((9961412441 : ℝ) / 1000000000000) ((4980706221 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((505005596233 : ℝ) / 500000000000)) (t := ((5005596233 : ℝ) / 1005005596233))
    (lo := ((9961412441 : ℝ) / 1000000000000)) (hi := ((4980706221 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_153 : RB (Real.log ((189964154499 : ℝ) / 200000000000)) ((-25740986359 : ℝ) / 500000000000) ((-51481972717 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((189964154499 : ℝ) / 200000000000)) (t := ((-10035845501 : ℝ) / 389964154499))
    (lo := ((-25740986359 : ℝ) / 500000000000)) (hi := ((-51481972717 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_154 : RB (Real.log ((949834441197 : ℝ) / 1000000000000)) ((-51467581999 : ℝ) / 1000000000000) ((-25733790999 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((949834441197 : ℝ) / 1000000000000)) (t := ((-50165558803 : ℝ) / 1949834441197))
    (lo := ((-51467581999 : ℝ) / 1000000000000)) (hi := ((-25733790999 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_155 : RB (Real.log ((243591875179 : ℝ) / 500000000000)) ((-719113916267 : ℝ) / 1000000000000) ((-143822783253 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((243591875179 : ℝ) / 250000000000)) (t := ((-6408124821 : ℝ) / 493591875179))
    (lo := ((-25966735707 : ℝ) / 1000000000000)) (hi := ((-12983367853 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((243591875179 : ℝ) / 500000000000) = Real.log ((243591875179 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((243591875179 : ℝ) / 500000000000) = ((243591875179 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_156 : RB (Real.log ((334731196931 : ℝ) / 100000000000)) ((604078813261 : ℝ) / 500000000000) ((302039406631 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((334731196931 : ℝ) / 400000000000)) (t := ((-65268803069 : ℝ) / 734731196931))
    (lo := ((-178136734597 : ℝ) / 1000000000000)) (hi := ((-44534183649 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((334731196931 : ℝ) / 100000000000) = Real.log ((334731196931 : ℝ) / 400000000000) + 2 * Real.log 2 := by
    rw [show ((334731196931 : ℝ) / 100000000000) = ((334731196931 : ℝ) / 400000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_157 : RB (Real.log ((1673664212259 : ℝ) / 500000000000)) ((1208162542457 : ℝ) / 1000000000000) ((1208162542459 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1673664212259 : ℝ) / 2000000000000)) (t := ((-326335787741 : ℝ) / 3673664212259))
    (lo := ((-89065909331 : ℝ) / 500000000000)) (hi := ((-178131818661 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1673664212259 : ℝ) / 500000000000) = Real.log ((1673664212259 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1673664212259 : ℝ) / 500000000000) = ((1673664212259 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_158 : RB (Real.log ((285195303317 : ℝ) / 200000000000)) ((177428426911 : ℝ) / 500000000000) ((5544638341 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((285195303317 : ℝ) / 400000000000)) (t := ((-114804696683 : ℝ) / 685195303317))
    (lo := ((-338290326737 : ℝ) / 1000000000000)) (hi := ((-21143145421 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((285195303317 : ℝ) / 200000000000) = Real.log ((285195303317 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((285195303317 : ℝ) / 200000000000) = ((285195303317 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_159 : RB (Real.log ((21 : ℝ) / 20)) ((48790164169 : ℝ) / 1000000000000) ((4879016417 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((21 : ℝ) / 20)) (t := ((1 : ℝ) / 41))
    (lo := ((48790164169 : ℝ) / 1000000000000)) (hi := ((4879016417 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_160 : RB (Real.log ((3361841 : ℝ) / 3200000)) ((1541810337 : ℝ) / 31250000000) ((9867586157 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3361841 : ℝ) / 3200000)) (t := ((161841 : ℝ) / 6561841))
    (lo := ((1541810337 : ℝ) / 31250000000)) (hi := ((9867586157 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_161 : RB (Real.log ((1 : ℝ) / 20)) ((-599146454711 : ℝ) / 200000000000) ((-2995732273553 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((4 : ℝ) / 5)) (t := ((-1 : ℝ) / 9))
    (lo := ((-44628710263 : ℝ) / 200000000000)) (hi := ((-111571775657 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 20) = Real.log ((4 : ℝ) / 5) - 4 * Real.log 2 := by
    rw [show ((1 : ℝ) / 20) = ((4 : ℝ) / 5) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_162 : RB (Real.log ((161841 : ℝ) / 3200000)) ((-1492145858503 : ℝ) / 500000000000) ((-746072929251 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((161841 : ℝ) / 200000)) (t := ((-38159 : ℝ) / 361841))
    (lo := ((-105851497383 : ℝ) / 500000000000)) (hi := ((-42340598953 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((161841 : ℝ) / 3200000) = Real.log ((161841 : ℝ) / 200000) - 4 * Real.log 2 := by
    rw [show ((161841 : ℝ) / 3200000) = ((161841 : ℝ) / 200000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_163 : RB (Real.log ((14001903559 : ℝ) / 20000000000)) ((-178269492341 : ℝ) / 500000000000) ((-356538984681 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((14001903559 : ℝ) / 20000000000)) (t := ((-5998096441 : ℝ) / 34001903559))
    (lo := ((-178269492341 : ℝ) / 500000000000)) (hi := ((-356538984681 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_164 : RB (Real.log ((175048450381 : ℝ) / 250000000000)) ((-178199061469 : ℝ) / 500000000000) ((-44549765367 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((175048450381 : ℝ) / 250000000000)) (t := ((-74951549619 : ℝ) / 425048450381))
    (lo := ((-178199061469 : ℝ) / 500000000000)) (hi := ((-44549765367 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_165 : RB (Real.log ((82660435639 : ℝ) / 200000000000)) ((-883576287227 : ℝ) / 1000000000000) ((-35343051489 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((82660435639 : ℝ) / 100000000000)) (t := ((-17339564361 : ℝ) / 182660435639))
    (lo := ((-190429106667 : ℝ) / 1000000000000)) (hi := ((-95214553333 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((82660435639 : ℝ) / 200000000000) = Real.log ((82660435639 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((82660435639 : ℝ) / 200000000000) = ((82660435639 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_166 : RB (Real.log ((826960266431 : ℝ) / 250000000000)) ((598147865289 : ℝ) / 500000000000) ((59814786529 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((826960266431 : ℝ) / 1000000000000)) (t := ((-173039733569 : ℝ) / 1826960266431))
    (lo := ((-189998630541 : ℝ) / 1000000000000)) (hi := ((-9499931527 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((826960266431 : ℝ) / 250000000000) = Real.log ((826960266431 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((826960266431 : ℝ) / 250000000000) = ((826960266431 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_167 : RB (Real.log ((826993736253 : ℝ) / 250000000000)) ((18692753173 : ℝ) / 15625000000) ((598168101537 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((826993736253 : ℝ) / 1000000000000)) (t := ((-173006263747 : ℝ) / 1826993736253))
    (lo := ((-189958158047 : ℝ) / 1000000000000)) (hi := ((-94979079023 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((826993736253 : ℝ) / 250000000000) = Real.log ((826993736253 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((826993736253 : ℝ) / 250000000000) = ((826993736253 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_168 : RB (Real.log ((716098533079 : ℝ) / 500000000000)) ((359209675101 : ℝ) / 1000000000000) ((359209675103 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((716098533079 : ℝ) / 1000000000000)) (t := ((-283901466921 : ℝ) / 1716098533079))
    (lo := ((-166968752729 : ℝ) / 500000000000)) (hi := ((-333937505457 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((716098533079 : ℝ) / 500000000000) = Real.log ((716098533079 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((716098533079 : ℝ) / 500000000000) = ((716098533079 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_169 : RB (Real.log ((1050575312499 : ℝ) / 1000000000000)) ((49337930783 : ℝ) / 1000000000000) ((1541810337 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((1050575312499 : ℝ) / 1000000000000)) (t := ((50575312499 : ℝ) / 2050575312499))
    (lo := ((49337930783 : ℝ) / 1000000000000)) (hi := ((1541810337 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_170 : RB (Real.log ((1681841 : ℝ) / 1600000)) ((9977079503 : ℝ) / 200000000000) ((12471349379 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1681841 : ℝ) / 1600000)) (t := ((81841 : ℝ) / 3281841))
    (lo := ((9977079503 : ℝ) / 200000000000)) (hi := ((12471349379 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_171 : RB (Real.log ((50575312499 : ℝ) / 1000000000000)) ((-1492145858513 : ℝ) / 500000000000) ((-93259116157 : ℝ) / 31250000000) := by
  have hm := log_bounds_of_series (x := ((50575312499 : ℝ) / 62500000000)) (t := ((-11924687501 : ℝ) / 113075312499))
    (lo := ((-105851497393 : ℝ) / 500000000000)) (hi := ((-42340598957 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((50575312499 : ℝ) / 1000000000000) = Real.log ((50575312499 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((50575312499 : ℝ) / 1000000000000) = ((50575312499 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_172 : RB (Real.log ((81841 : ℝ) / 1600000)) ((-185811285481 : ℝ) / 62500000000) ((-1486490283847 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((81841 : ℝ) / 100000)) (t := ((-18159 : ℝ) / 181841))
    (lo := ((-12524490341 : ℝ) / 62500000000)) (hi := ((-40078369091 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((81841 : ℝ) / 1600000) = Real.log ((81841 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((81841 : ℝ) / 1600000) = ((81841 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_173 : RB (Real.log ((696387609807 : ℝ) / 1000000000000)) ((-22615553939 : ℝ) / 62500000000) ((-180924431511 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((696387609807 : ℝ) / 1000000000000)) (t := ((-303612390193 : ℝ) / 1696387609807))
    (lo := ((-22615553939 : ℝ) / 62500000000)) (hi := ((-180924431511 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_174 : RB (Real.log ((348243574989 : ℝ) / 500000000000)) ((-72341187071 : ℝ) / 200000000000) ((-361705935353 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((348243574989 : ℝ) / 500000000000)) (t := ((-151756425011 : ℝ) / 848243574989))
    (lo := ((-72341187071 : ℝ) / 200000000000)) (hi := ((-361705935353 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_175 : RB (Real.log ((412054410327 : ℝ) / 1000000000000)) ((-221649968613 : ℝ) / 250000000000) ((-17731997489 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((412054410327 : ℝ) / 500000000000)) (t := ((-87945589673 : ℝ) / 912054410327))
    (lo := ((-48363173473 : ℝ) / 250000000000)) (hi := ((-193452693891 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((412054410327 : ℝ) / 1000000000000) = Real.log ((412054410327 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((412054410327 : ℝ) / 1000000000000) = ((412054410327 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_176 : RB (Real.log ((3306104452319 : ℝ) / 1000000000000)) ((1195770593671 : ℝ) / 1000000000000) ((1195770593673 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3306104452319 : ℝ) / 4000000000000)) (t := ((-693895547681 : ℝ) / 7306104452319))
    (lo := ((-23815470931 : ℝ) / 125000000000)) (hi := ((-190523767447 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3306104452319 : ℝ) / 1000000000000) = Real.log ((3306104452319 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3306104452319 : ℝ) / 1000000000000) = ((3306104452319 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_177 : RB (Real.log ((3306239769289 : ℝ) / 1000000000000)) ((1195811522263 : ℝ) / 1000000000000) ((239162304453 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3306239769289 : ℝ) / 4000000000000)) (t := ((-693760230711 : ℝ) / 7306239769289))
    (lo := ((-23810354857 : ℝ) / 125000000000)) (hi := ((-38096567771 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3306239769289 : ℝ) / 1000000000000) = Real.log ((3306239769289 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3306239769289 : ℝ) / 1000000000000) = ((3306239769289 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_178 : RB (Real.log ((17906214431 : ℝ) / 12500000000)) ((179709591601 : ℝ) / 500000000000) ((89854795801 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((17906214431 : ℝ) / 25000000000)) (t := ((-7093785569 : ℝ) / 42906214431))
    (lo := ((-333727997357 : ℝ) / 1000000000000)) (hi := ((-83431999339 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((17906214431 : ℝ) / 12500000000) = Real.log ((17906214431 : ℝ) / 25000000000) + 1 * Real.log 2 := by
    rw [show ((17906214431 : ℝ) / 12500000000) = ((17906214431 : ℝ) / 25000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_179 : RB (Real.log ((1051150624999 : ℝ) / 1000000000000)) ((24942698757 : ℝ) / 500000000000) ((9977079503 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1051150624999 : ℝ) / 1000000000000)) (t := ((51150624999 : ℝ) / 2051150624999))
    (lo := ((24942698757 : ℝ) / 500000000000)) (hi := ((9977079503 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
