import LeanProject.DLowerPartition
import LeanProject.DWitnessData

/-! Actual admissibility cutoff and T/M overlap from rational logarithmic bounds.
The simple rational probe lies strictly below the exact dyadic QHI.
-/
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
set_option linter.style.longLine false

noncomputable def qProbe : ℝ := 123639 / 1000000

set_option maxHeartbeats 4000000 in
theorem log_cut_bounds :
    ((-46051701859881 : ℝ) / 10000000000000) ≤ Real.log ((1 : ℝ) / 100) ∧ Real.log ((1 : ℝ) / 100) ≤ ((-460517018598809 : ℝ) / 100000000000000) := by
  have hm := log_bounds_of_series (x := ((32 : ℝ) / 25)) (t := ((7 : ℝ) / 57))
    (lo := ((9874403117261 : ℝ) / 40000000000000)) (hi := ((246860077931527 : ℝ) / 1000000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 100) = Real.log ((32 : ℝ) / 25) - 7 * Real.log 2 := by
    rw [show ((1 : ℝ) / 100) = ((32 : ℝ) / 25) / 2 ^ 7 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem log_probe_bounds :
    ((-41807784994967 : ℝ) / 20000000000000) ≤ Real.log ((123639 : ℝ) / 1000000) ∧ Real.log ((123639 : ℝ) / 1000000) ≤ ((-104519462487417 : ℝ) / 50000000000000) := by
  have hm := log_bounds_of_series (x := ((123639 : ℝ) / 125000)) (t := ((-1361 : ℝ) / 248639))
    (lo := ((-5473854034253 : ℝ) / 500000000000000)) (hi := ((-2189541613701 : ℝ) / 200000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123639 : ℝ) / 1000000) = Real.log ((123639 : ℝ) / 125000) - 3 * Real.log 2 := by
    rw [show ((123639 : ℝ) / 1000000) = ((123639 : ℝ) / 125000) / 2 ^ 3 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem log_one_plus_probe_bounds :
    ((11657252550673 : ℝ) / 100000000000000) ≤ Real.log ((1123639 : ℝ) / 1000000) ∧ Real.log ((1123639 : ℝ) / 1000000) ≤ ((5828626275337 : ℝ) / 50000000000000) := by
  have hm := log_bounds_of_series (x := ((1123639 : ℝ) / 1000000)) (t := ((123639 : ℝ) / 2123639))
    (lo := ((58286262753369 : ℝ) / 500000000000000)) (hi := ((116572525506739 : ℝ) / 1000000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  constructor <;> linarith [hm.1, hm.2]

set_option maxHeartbeats 4000000 in
theorem log_tenth_bounds :
    ((-46051701859881 : ℝ) / 20000000000000) ≤ Real.log ((1 : ℝ) / 10) ∧ Real.log ((1 : ℝ) / 10) ≤ ((-57564627324851 : ℝ) / 25000000000000) := by
  have hm := log_bounds_of_series (x := ((4 : ℝ) / 5)) (t := ((-1 : ℝ) / 9))
    (lo := ((-22314355131421 : ℝ) / 100000000000000)) (hi := ((-223143551314209 : ℝ) / 1000000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1 : ℝ) / 10) = Real.log ((4 : ℝ) / 5) - 3 * Real.log 2 := by
    rw [show ((1 : ℝ) / 10) = ((4 : ℝ) / 5) / 2 ^ 3 by norm_num,
      Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

set_option maxHeartbeats 4000000 in
theorem log_one_plus_tenth_bounds :
    ((595688623777 : ℝ) / 6250000000000) ≤ Real.log ((11 : ℝ) / 10) ∧ Real.log ((11 : ℝ) / 10) ≤ ((9531017980433 : ℝ) / 100000000000000) := by
  have hm := log_bounds_of_series (x := ((11 : ℝ) / 10)) (t := ((1 : ℝ) / 21))
    (lo := ((23827544951081 : ℝ) / 250000000000000)) (hi := ((3812407192173 : ℝ) / 40000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  constructor <;> linarith [hm.1, hm.2]

theorem rho1_bounds : 0 < rho1 ∧ rho1 < 1 := by
  norm_num [rho1, rho1Idx, dyad, gridDen]

theorem qA_bounds : 0 < qA ∧ qA ≤ (1 : ℝ) / 100 := by
  norm_num [qA, qaIdx, dyad, gridDen]

theorem qA_lt_qB : qA < qB := by
  norm_num [qA, qB, qaIdx, qbIdx, dyad, gridDen]

theorem qB_bounds : (1 : ℝ) / 20 ≤ qB ∧ qB < (1 : ℝ) / 10 := by
  norm_num [qB, qbIdx, dyad, gridDen]

theorem qHi_bounds : qProbe < qHi ∧ qHi < 1 := by
  norm_num [qProbe, qHi, qhiIdx, dyad, gridDen]

theorem qProbe_bounds : 0 < qProbe ∧ qProbe < 1 := by norm_num [qProbe]

theorem fq_probe_neg : fq qProbe < 0 := by
  rw [fq_eq qProbe_bounds.1.le]
  norm_num [qProbe]
  nlinarith [log_probe_bounds.2, log_one_plus_probe_bounds.1,
    witness_log_two.2]

theorem fq_tenth_pos : 0 < fq ((1 : ℝ) / 10) := by
  rw [fq_eq (by norm_num : (0 : ℝ) ≤ 1 / 10)]
  norm_num
  nlinarith [log_tenth_bounds.1, log_one_plus_tenth_bounds.2,
    witness_log_two.1]

theorem fq_qHi_neg : fq qHi < 0 := by
  have hhi0 : 0 < qHi := qProbe_bounds.1.trans qHi_bounds.1
  have hm := fq_strictAntiOn
    (show qProbe ∈ Icc (0 : ℝ) 1 from ⟨qProbe_bounds.1.le, qProbe_bounds.2.le⟩)
    (show qHi ∈ Icc (0 : ℝ) 1 from ⟨hhi0.le, qHi_bounds.2.le⟩) qHi_bounds.1
  exact hm.trans fq_probe_neg

theorem qA_log_upper : Real.log qA ≤ -(921 : ℝ) / 200 := by
  have hm := Real.log_le_log qA_bounds.1 qA_bounds.2
  linarith [log_cut_bounds.2]

theorem tail_overlap_log : Real.log qA < -1 / rho1 := by
  have hr := rho1_bounds.1
  apply (lt_div_iff₀ hr).2
  have hm := mul_le_mul_of_nonneg_right qA_log_upper hr.le
  have hn : (-(921 : ℝ) / 200) * rho1 < -1 := by
    norm_num [rho1, rho1Idx, dyad, gridDen]
  exact hm.trans_lt hn

end EP1038.DLowerCert
