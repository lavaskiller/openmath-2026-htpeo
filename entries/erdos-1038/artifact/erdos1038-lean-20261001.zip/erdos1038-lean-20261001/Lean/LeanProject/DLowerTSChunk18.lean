import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk15
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_56 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((627039617157116997403846186631167 : ℝ) / 5192296858534827628530496329220096) ((315013405221771407709960985064243 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((120763437499 : ℝ) / 1000000000000) ((97071 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1120763437499 : ℝ) / 1000000000000) ((897071 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((114010093719 : ℝ) / 1000000000000) ((11452328399 : ℝ) / 100000000000) := rb_log h1 (by norm_num) dlower_log_719.1 dlower_log_720.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((114010093719 : ℝ) / 500000000000) ((11452328399 : ℝ) / 50000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((464100612579 : ℝ) / 1000000000000) ((232563496561 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1056960854503 : ℝ) / 500000000000) ((-2109169058151 : ℝ) / 1000000000000) := rb_log hqr (by norm_num) dlower_log_721.1 dlower_log_722.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((2109169058151 : ℝ) / 1000000000000) ((1056960854503 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((219544844353 : ℝ) / 1000000000000) ((27565772367 : ℝ) / 125000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((97434227633 : ℝ) / 125000000000) ((780455155647 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((3645951959 : ℝ) / 250000000000) ((3680773063 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((256827764143 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((242104671891 : ℝ) / 1000000000000) ((242243956307 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((256827764143 : ℝ) / 1000000000000) ((256827764143 : ℝ) / 1000000000000) ((256827764143 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((743172235857 : ℝ) / 1000000000000))
  have h11 : RB z11 ((65154390923 : ℝ) / 200000000000) ((81489843343 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((743172235857 : ℝ) / 1000000000000) ((743172235857 : ℝ) / 1000000000000) ((743172235857 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1121557668119 : ℝ) / 1000000000000) ((-560491263469 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_723.1 dlower_log_724.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-875325464439 : ℝ) / 1000000000000) ((-436888266809 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((256827764143 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-1359349597189 : ℝ) / 1000000000000) ((-1359349597187 : ℝ) / 1000000000000) := rb_log (show RB ((256827764143 : ℝ) / 1000000000000) ((256827764143 : ℝ) / 1000000000000) ((256827764143 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_725.1 dlower_log_725.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((121006033187 : ℝ) / 250000000000) ((485573063571 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((9448569813 : ℝ) / 500000000000) ((1342028187 : ℝ) / 62500000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((3645951959 : ℝ) / 250000000000) ((3680773063 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1485729150159 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1471006057907 : ℝ) / 1000000000000) ((1471145342323 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((1485729150159 : ℝ) / 1000000000000) ((1485729150159 : ℝ) / 1000000000000) ((1485729150159 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((485729150159 : ℝ) / 1000000000000))
  have h19 : RB z19 ((3028449203481 : ℝ) / 1000000000000) ((151436797837 : ℝ) / 50000000000) := rb_div_signed h18 (show RB ((485729150159 : ℝ) / 1000000000000) ((485729150159 : ℝ) / 1000000000000) ((485729150159 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((554025337233 : ℝ) / 500000000000) ((554072678243 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_726.1 dlower_log_727.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((431848246579 : ℝ) / 500000000000) ((216214439169 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1485729150159 : ℝ) / 1000000000000))
  have h22 : RB z22 ((79181132391 : ℝ) / 200000000000) ((395905661957 : ℝ) / 1000000000000) := rb_log (show RB ((1485729150159 : ℝ) / 1000000000000) ((1485729150159 : ℝ) / 1000000000000) ((1485729150159 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_728.1 dlower_log_728.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((467790831201 : ℝ) / 1000000000000) ((468952094721 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2663838079 : ℝ) / 1000000000000) ((2425741071 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1120763437499 : ℝ) / 1000000000000) ((897071 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((628055341417 : ℝ) / 500000000000) ((314350148063 : ℝ) / 250000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((198822874381 : ℝ) / 125000000000) ((6219595221 : ℝ) / 3906250000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((38403168313 : ℝ) / 31250000000))
  have h28 : RB z28 ((1954669647187 : ℝ) / 1000000000000) ((489169228003 : ℝ) / 250000000000) := rb_widen (rb_mul h27 (show RB ((38403168313 : ℝ) / 31250000000) ((38403168313 : ℝ) / 31250000000) ((38403168313 : ℝ) / 31250000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((3645951959 : ℝ) / 250000000000) ((3680773063 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((381576495757415482948737 : ℝ) / 1000000000000000000000000))
  have h30 : RB z30 ((2388742493 : ℝ) / 62500000000) ((19292451731 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((381576495757415482948737 : ℝ) / 1000000000000000000000000) ((381576495757415482948737 : ℝ) / 1000000000000000000000000) ((381576495757415482948737 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((480707548269 : ℝ) / 500000000000) ((60111257507 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((37584978151 : ℝ) / 20000000000) ((29404577429 : ℝ) / 15625000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((256827764143 : ℝ) / 1000000000000)) ((9448569813 : ℝ) / 500000000000) ((1342028187 : ℝ) / 62500000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1485729150159 : ℝ) / 1000000000000)) ((2663838079 : ℝ) / 1000000000000) ((2425741071 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((256827764143 : ℝ) / 1000000000000)) (wl := ((1485729150159 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((37584978151 : ℝ) / 20000000000) ≤ D0q (q) * (((1485729150159 : ℝ) / 1000000000000) - ((256827764143 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((1485729150159 : ℝ) / 1000000000000) * ((256827764143 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_57 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((315013405221771407709960985064243 : ℝ) / 2596148429267413814265248164610048) ((158253500932492158358999438406451 : ℝ) / 1298074214633706907132624082305024)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((121338749999 : ℝ) / 1000000000000) ((3121 : ℝ) / 25600) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1121338749999 : ℝ) / 1000000000000) ((28721 : ℝ) / 25600) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((28630820997 : ℝ) / 250000000000) ((11503621103 : ℝ) / 100000000000) := rb_log h1 (by norm_num) dlower_log_729.1 dlower_log_730.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((28630820997 : ℝ) / 125000000000) ((11503621103 : ℝ) / 50000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((463074758499 : ℝ) / 1000000000000) ((58012576573 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1054584529081 : ℝ) / 500000000000) ((-526109722049 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_731.1 dlower_log_732.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((526109722049 : ℝ) / 250000000000) ((1054584529081 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((54888293177 : ℝ) / 250000000000) ((220534136291 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((779465863709 : ℝ) / 1000000000000) ((195111706823 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((14723092251 : ℝ) / 1000000000000) ((3715759659 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((69942198153 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((33113219247 : ℝ) / 125000000000) ((265045700361 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((69942198153 : ℝ) / 250000000000) ((69942198153 : ℝ) / 250000000000) ((69942198153 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((180057801847 : ℝ) / 250000000000))
  have h11 : RB z11 ((91951636939 : ℝ) / 250000000000) ((18400042767 : ℝ) / 50000000000) := rb_div_signed h10 (show RB ((180057801847 : ℝ) / 250000000000) ((180057801847 : ℝ) / 250000000000) ((180057801847 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-48837801 : ℝ) / 48828125) ((-999670016521 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_733.1 dlower_log_734.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-195150371033 : ℝ) / 250000000000) ((-779208652851 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((69942198153 : ℝ) / 250000000000))
  have h14 : RB z14 ((-1273791757597 : ℝ) / 1000000000000) ((-254758351519 : ℝ) / 200000000000) := rb_log (show RB ((69942198153 : ℝ) / 250000000000) ((69942198153 : ℝ) / 250000000000) ((69942198153 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_735.1 dlower_log_735.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((493190273463 : ℝ) / 1000000000000) ((247291552373 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((29089660879 : ℝ) / 1000000000000) ((31508346247 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((14723092251 : ℝ) / 1000000000000) ((3715759659 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((743134795739 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((735703276421 : ℝ) / 500000000000) ((1471546499227 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((743134795739 : ℝ) / 500000000000) ((743134795739 : ℝ) / 500000000000) ((743134795739 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((243134795739 : ℝ) / 500000000000))
  have h19 : RB z19 ((3025906983757 : ℝ) / 1000000000000) ((1513097389819 : ℝ) / 500000000000) := rb_div_signed h18 (show RB ((243134795739 : ℝ) / 500000000000) ((243134795739 : ℝ) / 500000000000) ((243134795739 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1107210875883 : ℝ) / 1000000000000) ((1107305981979 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_736.1 dlower_log_737.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((431516540839 : ℝ) / 500000000000) ((864193440477 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((743134795739 : ℝ) / 500000000000))
  have h22 : RB z22 ((396269350753 : ℝ) / 1000000000000) ((79253870151 : ℝ) / 200000000000) := rb_log (show RB ((743134795739 : ℝ) / 500000000000) ((743134795739 : ℝ) / 500000000000) ((743134795739 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_738.1 dlower_log_738.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((466763730923 : ℝ) / 1000000000000) ((116981022431 : ℝ) / 250000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2663118339 : ℝ) / 1000000000000) ((193973249 : ℝ) / 40000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1121338749999 : ℝ) / 1000000000000) ((28721 : ℝ) / 25600) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1257400592249 : ℝ) / 1000000000000) ((314672790909 : ℝ) / 250000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((397238031413 : ℝ) / 250000000000) ((1590582995053 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((603250399433 : ℝ) / 500000000000))
  have h28 : RB z28 ((958536004479 : ℝ) / 500000000000) ((383807930839 : ℝ) / 200000000000) := rb_widen (rb_mul h27 (show RB ((603250399433 : ℝ) / 500000000000) ((603250399433 : ℝ) / 500000000000) ((603250399433 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((14723092251 : ℝ) / 1000000000000) ((3715759659 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((51976481137966318070067 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((8852015811 : ℝ) / 250000000000) ((35744625047 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((51976481137966318070067 : ℝ) / 125000000000000000000000) ((51976481137966318070067 : ℝ) / 125000000000000000000000) ((51976481137966318070067 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((964255374953 : ℝ) / 1000000000000) ((241147984189 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1848546988809 : ℝ) / 1000000000000) ((115693136047 : ℝ) / 62500000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((69942198153 : ℝ) / 250000000000)) ((29089660879 : ℝ) / 1000000000000) ((31508346247 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((743134795739 : ℝ) / 500000000000)) ((2663118339 : ℝ) / 1000000000000) ((193973249 : ℝ) / 40000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((69942198153 : ℝ) / 250000000000)) (wl := ((743134795739 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1848546988809 : ℝ) / 1000000000000) ≤ D0q (q) * (((743134795739 : ℝ) / 500000000000) - ((69942198153 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((743134795739 : ℝ) / 500000000000) * ((69942198153 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_58 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((158253500932492158358999438406451 : ℝ) / 1298074214633706907132624082305024) ((634507600373181542444035645374463 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((121914062499 : ℝ) / 1000000000000) ((782091 : ℝ) / 6400000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1121914062499 : ℝ) / 1000000000000) ((7182091 : ℝ) / 6400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((28759052757 : ℝ) / 250000000000) ((28823143981 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_739.1 dlower_log_740.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((28759052757 : ℝ) / 125000000000) ((28823143981 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((462562028711 : ℝ) / 1000000000000) ((57884344813 : ℝ) / 125000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1052219444103 : ℝ) / 500000000000) ((-420416433457 : ℝ) / 200000000000) := rb_log hqr (by norm_num) dlower_log_741.1 dlower_log_742.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((420416433457 : ℝ) / 200000000000) ((1052219444103 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((109901511349 : ℝ) / 500000000000) ((110146683539 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((389853316461 : ℝ) / 500000000000) ((390098488651 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2972607727 : ℝ) / 200000000000) ((7466630033 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((113848210541 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((26595395127 : ℝ) / 125000000000) ((212833382447 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((113848210541 : ℝ) / 500000000000) ((113848210541 : ℝ) / 500000000000) ((113848210541 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((386151789459 : ℝ) / 500000000000))
  have h11 : RB z11 ((137745808011 : ℝ) / 500000000000) ((275582540671 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((386151789459 : ℝ) / 500000000000) ((386151789459 : ℝ) / 500000000000) ((386151789459 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-257839616543 : ℝ) / 200000000000) ((-644434046049 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_743.1 dlower_log_744.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-502914223639 : ℝ) / 500000000000) ((-100493900037 : ℝ) / 100000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((113848210541 : ℝ) / 500000000000))
  have h14 : RB z14 ((-1479742023727 : ℝ) / 1000000000000) ((-59189680949 : ℝ) / 40000000000) := rb_log (show RB ((113848210541 : ℝ) / 500000000000) ((113848210541 : ℝ) / 500000000000) ((113848210541 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_745.1 dlower_log_745.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((473913576447 : ℝ) / 1000000000000) ((474803023357 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((10838817943 : ℝ) / 1000000000000) ((6120497323 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2972607727 : ℝ) / 200000000000) ((7466630033 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1487754281443 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((1472821021377 : ℝ) / 1000000000000) ((184111405351 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((1487754281443 : ℝ) / 1000000000000) ((1487754281443 : ℝ) / 1000000000000) ((1487754281443 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((487754281443 : ℝ) / 1000000000000))
  have h19 : RB z19 ((603919259107 : ℝ) / 200000000000) ((3019740264403 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((487754281443 : ℝ) / 1000000000000) ((487754281443 : ℝ) / 1000000000000) ((487754281443 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((44204925819 : ℝ) / 40000000000) ((276292705631 : ℝ) / 250000000000) := rb_log h19 (by norm_num) dlower_log_746.1 dlower_log_747.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((430835923361 : ℝ) / 500000000000) ((26945341723 : ℝ) / 31250000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1487754281443 : ℝ) / 1000000000000))
  have h22 : RB z22 ((79453557867 : ℝ) / 200000000000) ((397267789337 : ℝ) / 1000000000000) := rb_log (show RB ((1487754281443 : ℝ) / 1000000000000) ((1487754281443 : ℝ) / 1000000000000) ((1487754281443 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_748.1 dlower_log_748.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((92880811477 : ℝ) / 200000000000) ((464983145801 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1329298881 : ℝ) / 1000000000000) ((242111709 : ℝ) / 100000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1121914062499 : ℝ) / 1000000000000) ((7182091 : ℝ) / 6400000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1258691163633 : ℝ) / 1000000000000) ((629668348783 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1588137631393 : ℝ) / 1000000000000) ((1588952125657 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1260057860361 : ℝ) / 1000000000000))
  have h28 : RB z28 ((2001145305771 : ℝ) / 1000000000000) ((250271451959 : ℝ) / 125000000000) := rb_widen (rb_mul h27 (show RB ((1260057860361 : ℝ) / 1000000000000) ((1260057860361 : ℝ) / 1000000000000) ((1260057860361 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2972607727 : ℝ) / 200000000000) ((7466630033 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((169378162666996833290663 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((21937654773 : ℝ) / 500000000000) ((22041300707 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((169378162666996833290663 : ℝ) / 500000000000000000000000) ((169378162666996833290663 : ℝ) / 500000000000000000000000) ((169378162666996833290663 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((477958699293 : ℝ) / 500000000000) ((478062345227 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((382585922977 : ℝ) / 200000000000) ((1914325716271 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((113848210541 : ℝ) / 500000000000)) ((10838817943 : ℝ) / 1000000000000) ((6120497323 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1487754281443 : ℝ) / 1000000000000)) ((1329298881 : ℝ) / 1000000000000) ((242111709 : ℝ) / 100000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((113848210541 : ℝ) / 500000000000)) (wl := ((1487754281443 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((382585922977 : ℝ) / 200000000000) ≤ D0q (q) * (((1487754281443 : ℝ) / 1000000000000) - ((113848210541 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((1487754281443 : ℝ) / 1000000000000) * ((113848210541 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_59 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((634507600373181542444035645374463 : ℝ) / 5192296858534827628530496329220096) ((636001197016394451452073537123123 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((122201718749 : ℝ) / 1000000000000) ((195983 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1122201718749 : ℝ) / 1000000000000) ((1795983 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((57646287961 : ℝ) / 500000000000) ((115548875111 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_749.1 dlower_log_750.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((57646287961 : ℝ) / 250000000000) ((115548875111 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((462049430337 : ℝ) / 1000000000000) ((115640507179 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-420416433459 : ℝ) / 200000000000) ((-524932746863 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_751.1 dlower_log_752.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((524932746863 : ℝ) / 250000000000) ((420416433459 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((219805599193 : ℝ) / 1000000000000) ((27536981611 : ℝ) / 125000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((97463018389 : ℝ) / 125000000000) ((780194400807 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2986652013 : ℝ) / 200000000000) ((3750911747 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((60363290651 : ℝ) / 250000000000)) - (z9)
  have h10 : RB z10 ((7076547363 : ℝ) / 31250000000) ((226519902539 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((60363290651 : ℝ) / 250000000000) ((60363290651 : ℝ) / 250000000000) ((60363290651 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((189636709349 : ℝ) / 250000000000))
  have h11 : RB z11 ((149265348197 : ℝ) / 500000000000) ((298623488191 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((189636709349 : ℝ) / 250000000000) ((189636709349 : ℝ) / 250000000000) ((189636709349 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-1208882515947 : ℝ) / 1000000000000) ((-604285867957 : ℝ) / 500000000000) := rb_log h11 (by norm_num) dlower_log_753.1 dlower_log_754.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-14736927659 : ℝ) / 15625000000) ((-471164197287 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((60363290651 : ℝ) / 250000000000))
  have h14 : RB z14 ((-88817485523 : ℝ) / 62500000000) ((-710539884183 : ℝ) / 500000000000) := rb_log (show RB ((60363290651 : ℝ) / 250000000000) ((60363290651 : ℝ) / 250000000000) ((60363290651 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_755.1 dlower_log_755.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((47791639819 : ℝ) / 100000000000) ((239375686897 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((7677184737 : ℝ) / 500000000000) ((16701943457 : ℝ) / 1000000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2986652013 : ℝ) / 200000000000) ((3750911747 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((744012965897 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((736511142403 : ℝ) / 500000000000) ((1473092671729 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((744012965897 : ℝ) / 500000000000) ((744012965897 : ℝ) / 500000000000) ((744012965897 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((244012965897 : ℝ) / 500000000000))
  have h19 : RB z19 ((603665579569 : ℝ) / 200000000000) ((37730901571 : ℝ) / 12500000000) := rb_div_signed h18 (show RB ((244012965897 : ℝ) / 500000000000) ((244012965897 : ℝ) / 500000000000) ((244012965897 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((13808787523 : ℝ) / 12500000000) ((552375392359 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_756.1 dlower_log_757.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((861341511861 : ℝ) / 1000000000000) ((34476815061 : ℝ) / 40000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((744012965897 : ℝ) / 500000000000))
  have h22 : RB z22 ((397450363539 : ℝ) / 1000000000000) ((397450363541 : ℝ) / 1000000000000) := rb_log (show RB ((744012965897 : ℝ) / 500000000000) ((744012965897 : ℝ) / 500000000000) ((744012965897 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_758.1 dlower_log_758.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((2899319677 : ℝ) / 6250000000) ((232235006493 : ℝ) / 500000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((332279901 : ℝ) / 250000000000) ((2420582649 : ℝ) / 1000000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1122201718749 : ℝ) / 1000000000000) ((1795983 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((1259336697563 : ℝ) / 1000000000000) ((314995599247 : ℝ) / 250000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1587323763237 : ℝ) / 1000000000000) ((794068815699 : ℝ) / 500000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((124657276919 : ℝ) / 100000000000))
  have h28 : RB z28 ((1978714579139 : ℝ) / 1000000000000) ((1979729125027 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((124657276919 : ℝ) / 100000000000) ((124657276919 : ℝ) / 100000000000) ((124657276919 : ℝ) / 100000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2986652013 : ℝ) / 200000000000) ((3750911747 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((44911070908553161928947 : ℝ) / 125000000000000000000000))
  have h30 : RB z30 ((2597713479 : ℝ) / 62500000000) ((20879661023 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((44911070908553161928947 : ℝ) / 125000000000000000000000) ((44911070908553161928947 : ℝ) / 125000000000000000000000) ((44911070908553161928947 : ℝ) / 125000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((479120338977 : ℝ) / 500000000000) ((59902286521 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1896084799791 : ℝ) / 1000000000000) ((948722410251 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((60363290651 : ℝ) / 250000000000)) ((7677184737 : ℝ) / 500000000000) ((16701943457 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((744012965897 : ℝ) / 500000000000)) ((332279901 : ℝ) / 250000000000) ((2420582649 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((60363290651 : ℝ) / 250000000000)) (wl := ((744012965897 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1896084799791 : ℝ) / 1000000000000) ≤ D0q (q) * (((744012965897 : ℝ) / 500000000000) - ((60363290651 : ℝ) / 250000000000)) * (1 - (q) ^ 2 / (((744012965897 : ℝ) / 500000000000) * ((60363290651 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
