import LeanProject.Stage10C9

/-!
# EP-1038, Stage 10 Part (c), N6(i): estimates along the segment `T_s = T₀ + s(T - T₀)`

With `a₀ ≤ T₀ ≤ 2`, `0 ≤ T ≤ 2` and `a' < a₀`:
* `Seg_lower`: `T_s ≥ a'` for `0 ≤ s ≤ (a₀ - a')/2`;
* `LS_seg_close`: `|L_{T_s}(x) - L_{T₀}(x)| ≤ 2s/(a' - x)` for `x < a'`;
* `JS_seg_close`: `|J_{T_s}(x) - J_{T₀}(x)| ≤ 2s/(a' - x)²`;
* `WS_pos_iff`: `W_S(y) > 0 ⟺ |Ψ_S(y)| > R(S)` (real axis, `y ≠ 0`).
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

section segest

variable {T0 T : ℝ → ℝ} {a0 a' : ℝ} (hm0 : Measurable T0) (hm1 : Measurable T)
  (h0a : ∀ u, a0 ≤ T0 u) (h02 : ∀ u, T0 u ≤ 2) (h1 : ∀ u, 0 ≤ T u) (h12 : ∀ u, T u ≤ 2)
  (ha' : 0 < a') (ha'0 : a' < a0)
include h0a h02 h1 h12 ha' ha'0

theorem Seg_lower {s : ℝ} (hs0 : 0 ≤ s) (hs : s ≤ (a0 - a') / 2) (u : ℝ) :
    a' ≤ Seg T0 T s u := by
  unfold Seg
  have := h0a u; have := h02 u; have := h1 u
  nlinarith

theorem Seg_upper {s : ℝ} (hs0 : 0 ≤ s) (hs1 : s ≤ 1) (u : ℝ) : Seg T0 T s u ≤ 2 := by
  unfold Seg
  have := h02 u; have := h12 u
  nlinarith

include hm0 hm1

theorem LS_seg_close {s x : ℝ} (hs0 : 0 ≤ s) (hs : s ≤ (a0 - a') / 2) (hx : x < a') :
    |LS (Seg T0 T s) x - LS T0 x| ≤ 2 * s / (a' - x) := by
  have hsa : s ≤ 1 := by linarith [h02 0, h0a 0]
  have hSm : Measurable (Seg T0 T s) := Seg_measurable hm0 hm1 s
  have hSa : ∀ u, a' ≤ Seg T0 T s u := Seg_lower h0a h02 h1 h12 ha' ha'0 hs0 hs
  have hS2 : ∀ u, Seg T0 T s u ≤ 2 := Seg_upper h0a h02 h1 h12 ha' ha'0 hs0 hsa
  have h0a' : ∀ u, a' ≤ T0 u := fun u => by linarith [h0a u]
  have i1 := ii_log hSm ha' hSa hS2 hx
  have i2 := ii_log hm0 ha' h0a' h02 hx
  unfold LS
  rw [← intervalIntegral.integral_sub i1 i2]
  have hbound : ∀ u ∈ uIcc (0 : ℝ) 1, |Real.log (Seg T0 T s u - x) - Real.log (T0 u - x)| ≤
      2 * s / (a' - x) := by
    intro u _
    have hA : a' - x ≤ Seg T0 T s u - x := by linarith [hSa u]
    have hB : a' - x ≤ T0 u - x := by linarith [h0a' u]
    have hax : 0 < a' - x := by linarith
    have hdiff : |Seg T0 T s u - T0 u| ≤ 2 * s := by
      unfold Seg
      have := h02 u; have := h12 u; have := h1 u; have := h0a u
      rw [abs_le]; constructor <;> nlinarith
    -- `|log p - log q| ≤ |p - q| / min p q`
    have hp : 0 < Seg T0 T s u - x := by linarith
    have hq : 0 < T0 u - x := by linarith
    rw [abs_le]
    constructor
    · have := Real.log_le_sub_one_of_pos (div_pos hq hp)
      rw [Real.log_div hq.ne' hp.ne'] at this
      have e : (T0 u - x) / (Seg T0 T s u - x) - 1 = (T0 u - Seg T0 T s u) / (Seg T0 T s u - x) := by
        field_simp; ring
      rw [e] at this
      have : (T0 u - Seg T0 T s u) / (Seg T0 T s u - x) ≤ 2 * s / (a' - x) := by
        rw [div_le_div_iff₀ hp hax]
        have := (abs_le.mp hdiff).1
        nlinarith
      linarith
    · have := Real.log_le_sub_one_of_pos (div_pos hp hq)
      rw [Real.log_div hp.ne' hq.ne'] at this
      have e : (Seg T0 T s u - x) / (T0 u - x) - 1 = (Seg T0 T s u - T0 u) / (T0 u - x) := by
        field_simp; ring
      rw [e] at this
      have : (Seg T0 T s u - T0 u) / (T0 u - x) ≤ 2 * s / (a' - x) := by
        rw [div_le_div_iff₀ hq hax]
        have := (abs_le.mp hdiff).2
        nlinarith
      linarith
  have := intervalIntegral.norm_integral_le_of_norm_le_const (a := 0) (b := 1)
    (f := fun u => Real.log (Seg T0 T s u - x) - Real.log (T0 u - x)) (C := 2 * s / (a' - x))
    (fun u hu => by rw [Real.norm_eq_abs]; exact hbound u (Set.uIoc_subset_uIcc hu))
  simpa [Real.norm_eq_abs] using this

theorem JS_seg_close {s x : ℝ} (hs0 : 0 ≤ s) (hs : s ≤ (a0 - a') / 2) (hx : x < a') :
    |JS (Seg T0 T s) x - JS T0 x| ≤ 2 * s / (a' - x) ^ 2 := by
  have hsa : s ≤ 1 := by linarith [h02 0, h0a 0]
  have hSm : Measurable (Seg T0 T s) := Seg_measurable hm0 hm1 s
  have hSa : ∀ u, a' ≤ Seg T0 T s u := Seg_lower h0a h02 h1 h12 ha' ha'0 hs0 hs
  have hS2 : ∀ u, Seg T0 T s u ≤ 2 := Seg_upper h0a h02 h1 h12 ha' ha'0 hs0 hsa
  have h0a' : ∀ u, a' ≤ T0 u := fun u => by linarith [h0a u]
  unfold JS
  rw [← intervalIntegral.integral_sub (ii_inv hSm ha' hSa hS2 hx) (ii_inv hm0 ha' h0a' h02 hx)]
  have hbound : ∀ u, |1 / (Seg T0 T s u - x) - 1 / (T0 u - x)| ≤ 2 * s / (a' - x) ^ 2 := by
    intro u
    have hp : a' - x ≤ Seg T0 T s u - x := by linarith [hSa u]
    have hq : a' - x ≤ T0 u - x := by linarith [h0a' u]
    have hax : 0 < a' - x := by linarith
    have hdiff : |Seg T0 T s u - T0 u| ≤ 2 * s := by
      unfold Seg
      have := h02 u; have := h12 u; have := h1 u; have := h0a u
      rw [abs_le]; constructor <;> nlinarith
    have hp1 : 0 < Seg T0 T s u - x := by linarith
    have hq1 : 0 < T0 u - x := by linarith
    have e : 1 / (Seg T0 T s u - x) - 1 / (T0 u - x) =
        (T0 u - Seg T0 T s u) / ((Seg T0 T s u - x) * (T0 u - x)) := by
      field_simp
      ring
    rw [e, abs_div, abs_of_pos (mul_pos hp1 hq1), abs_sub_comm,
      div_le_div_iff₀ (mul_pos hp1 hq1) (by positivity)]
    have hprod : (a' - x) ^ 2 ≤ (Seg T0 T s u - x) * (T0 u - x) := by
      rw [sq]; exact mul_le_mul hp hq hax.le (by linarith)
    nlinarith [abs_nonneg (Seg T0 T s u - T0 u)]
  have := intervalIntegral.norm_integral_le_of_norm_le_const (a := 0) (b := 1)
    (f := fun u => 1 / (Seg T0 T s u - x) - 1 / (T0 u - x)) (C := 2 * s / (a' - x) ^ 2)
    (fun u _ => by rw [Real.norm_eq_abs]; exact hbound u)
  simpa [Real.norm_eq_abs] using this

end segest

theorem WS_pos_iff {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
    (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k) {y : ℝ} (hy : y < a) (hy0 : y ≠ 0) :
    0 < WS k S y ↔ RS k S < |PsiS k S y| := by
  rw [WS_eq hSm ha hSa hS2 hk hy hy0]
  have hR := RS_pos hSm ha hSa hS2 hk
  have hΨ : 0 < |PsiS k S y| := by
    unfold PsiS; rw [abs_mul]; exact mul_pos (abs_pos.mpr hy0) (by positivity)
  constructor
  · intro h
    have h' : 0 < Real.log (|PsiS k S y| / RS k S) := by
      by_contra hc; push Not at hc; nlinarith
    have := (Real.log_pos_iff (div_pos hΨ hR).le).mp h'
    rwa [one_lt_div hR] at this
  · intro h
    exact mul_pos hk (Real.log_pos ((one_lt_div hR).mpr h))

end EP1038.Stage10
