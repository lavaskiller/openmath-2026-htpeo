import LeanProject.DLowerLogs
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_T_8 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((27389091493816409 : ℝ) / 144115188075855872) ((113469093331525123 : ℝ) / 576460752303423488)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((31089198061 : ℝ) / 5000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((113469093331525123 : ℝ) / 576460752303423488) ≤ ((-5080332761793 : ℝ) / 1000000000000) by norm_num).trans dlower_log_79.1)
  have hql : ((259305023801 : ℝ) / 50000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_80.2.trans (show ((-5261773217579 : ℝ) / 1000000000000) ≤ -1 / ((27389091493816409 : ℝ) / 144115188075855872) by norm_num))
  have hqr : RB (tailQ r) ((259305023801 : ℝ) / 50000000000000) ((31089198061 : ℝ) / 5000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((251296525119 : ℝ) / 250000000000) ((1006217839613 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((5172698971 : ℝ) / 1000000000000) ((6198588607 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_81.1 dlower_log_82.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((5172698971 : ℝ) / 500000000000) ((6198588607 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((136150000669 : ℝ) / 200000000000) ((341400891309 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((25875307627 : ℝ) / 200000000000) ((134400995887 : ℝ) / 1000000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((865599004113 : ℝ) / 1000000000000) ((174124692373 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((13447819 : ℝ) / 500000000000) ((3866153 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((123825437721 : ℝ) / 250000000000)) - (z7)
  have h8 : RB z8 ((247631544677 : ℝ) / 500000000000) ((247637427623 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((123825437721 : ℝ) / 250000000000) ((123825437721 : ℝ) / 250000000000) ((123825437721 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((126174562279 : ℝ) / 250000000000))
  have h9 : RB z9 ((98130534477 : ℝ) / 100000000000) ((981328657497 : ℝ) / 1000000000000) := rb_div_signed h8 (show RB ((126174562279 : ℝ) / 250000000000) ((126174562279 : ℝ) / 250000000000) ((126174562279 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-18871609163 : ℝ) / 1000000000000) ((-18847852591 : ℝ) / 1000000000000) := rb_log h9 (by norm_num) dlower_log_83.1 dlower_log_84.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-16430065701 : ℝ) / 1000000000000) ((-254916913 : ℝ) / 15625000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((123825437721 : ℝ) / 250000000000))
  have h12 : RB z12 ((-351294052199 : ℝ) / 500000000000) ((-175647026099 : ℝ) / 250000000000) := rb_log (show RB ((123825437721 : ℝ) / 250000000000) ((123825437721 : ℝ) / 250000000000) ((123825437721 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_85.1 dlower_log_85.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((137231607739 : ℝ) / 200000000000) ((343136710983 : ℝ) / 500000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((3356256077 : ℝ) / 1000000000000) ((5523418621 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((13447819 : ℝ) / 500000000000) ((3866153 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((356316456457 : ℝ) / 250000000000)) - (z15)
  have h16 : RB z16 ((712613582149 : ℝ) / 500000000000) ((142523893019 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB ((356316456457 : ℝ) / 250000000000) ((356316456457 : ℝ) / 250000000000) ((356316456457 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((106316456457 : ℝ) / 250000000000))
  have h17 : RB z17 ((1675689742437 : ℝ) / 500000000000) ((3351407152021 : ℝ) / 1000000000000) := rb_div_signed h16 (show RB ((106316456457 : ℝ) / 250000000000) ((106316456457 : ℝ) / 250000000000) ((106316456457 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((302343011901 : ℝ) / 250000000000) ((1209380303023 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_86.1 dlower_log_87.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((130853905001 : ℝ) / 125000000000) ((105291486613 : ℝ) / 100000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((356316456457 : ℝ) / 250000000000))
  have h20 : RB z20 ((177179170381 : ℝ) / 500000000000) ((70871668153 : ℝ) / 200000000000) := rb_log (show RB ((356316456457 : ℝ) / 250000000000) ((356316456457 : ℝ) / 250000000000) ((356316456457 : ℝ) / 250000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_88.1 dlower_log_88.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((692472899243 : ℝ) / 1000000000000) ((87319565671 : ℝ) / 125000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((77368933 : ℝ) / 8000000000) ((17806522023 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((251296525119 : ℝ) / 250000000000) ((1006217839613 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((101039909659 : ℝ) / 100000000000) ((253118585189 : ℝ) / 250000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((197535870243 : ℝ) / 100000000000) ((1979415863247 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((14530688671 : ℝ) / 15625000000))
  have h26 : RB z26 ((1837012628387 : ℝ) / 1000000000000) ((920392821097 : ℝ) / 500000000000) := rb_widen (rb_mul h25 (show RB ((14530688671 : ℝ) / 15625000000) ((14530688671 : ℝ) / 15625000000) ((14530688671 : ℝ) / 15625000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((13447819 : ℝ) / 500000000000) ((3866153 : ℝ) / 100000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((44121041187983661814497 : ℝ) / 62500000000000000000000))
  have h28 : RB z28 ((19049611 : ℝ) / 500000000000) ((3422893 : ℝ) / 62500000000) := rb_div_signed h27 (show RB ((44121041187983661814497 : ℝ) / 62500000000000000000000) ((44121041187983661814497 : ℝ) / 62500000000000000000000) ((44121041187983661814497 : ℝ) / 62500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((62496577107 : ℝ) / 62500000000) ((499980950389 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((229614002753 : ℝ) / 125000000000) ((920357754847 : ℝ) / 500000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((123825437721 : ℝ) / 250000000000)) ((3356256077 : ℝ) / 1000000000000) ((5523418621 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((356316456457 : ℝ) / 250000000000)) ((77368933 : ℝ) / 8000000000) ((17806522023 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((123825437721 : ℝ) / 250000000000)) (wl := ((356316456457 : ℝ) / 250000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((229614002753 : ℝ) / 125000000000) ≤ D0q (tailQ r) * (((356316456457 : ℝ) / 250000000000) - ((123825437721 : ℝ) / 250000000000)) * (1 - (tailQ r) ^ 2 / (((356316456457 : ℝ) / 250000000000) * ((123825437721 : ℝ) / 250000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_9 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((113469093331525123 : ℝ) / 576460752303423488) ((230850914019309733 : ℝ) / 1152921504606846976)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((27107873297 : ℝ) / 4000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((230850914019309733 : ℝ) / 1152921504606846976) ≤ ((-156069544589 : ℝ) / 31250000000) by norm_num).trans dlower_log_89.1)
  have hql : ((124356792243 : ℝ) / 20000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_90.2.trans (show ((-5080332761799 : ℝ) / 1000000000000) ≤ -1 / ((113469093331525123 : ℝ) / 576460752303423488) by norm_num))
  have hqr : RB (tailQ r) ((124356792243 : ℝ) / 20000000000000) ((27107873297 : ℝ) / 4000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((251554459903 : ℝ) / 250000000000) ((40271078733 : ℝ) / 40000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((1239717721 : ℝ) / 200000000000) ((67541079 : ℝ) / 10000000000) := rb_log h1 (by norm_num) dlower_log_91.1 dlower_log_92.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((1239717721 : ℝ) / 100000000000) ((67541079 : ℝ) / 5000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((679638964759 : ℝ) / 1000000000000) ((13615000067 : ℝ) / 20000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((5351137389 : ℝ) / 40000000000) ((136307424109 : ℝ) / 1000000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((863692575891 : ℝ) / 1000000000000) ((34648862611 : ℝ) / 40000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((38661529 : ℝ) / 1000000000000) ((459273 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((246379800243 : ℝ) / 500000000000)) - (z7)
  have h8 : RB z8 ((246356836593 : ℝ) / 500000000000) ((492720938957 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((246379800243 : ℝ) / 500000000000) ((246379800243 : ℝ) / 500000000000) ((246379800243 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((253620199757 : ℝ) / 500000000000))
  have h9 : RB z9 ((485680629597 : ℝ) / 500000000000) ((60710973957 : ℝ) / 62500000000) := rb_div_signed h8 (show RB ((253620199757 : ℝ) / 500000000000) ((253620199757 : ℝ) / 500000000000) ((253620199757 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-29056831281 : ℝ) / 1000000000000) ((-29042084951 : ℝ) / 1000000000000) := rb_log h9 (by norm_num) dlower_log_93.1 dlower_log_94.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-201357231 : ℝ) / 8000000000) ((-627085829 : ℝ) / 25000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((246379800243 : ℝ) / 500000000000))
  have h12 : RB z12 ((-707733849657 : ℝ) / 1000000000000) ((-141546769931 : ℝ) / 200000000000) := rb_log (show RB ((246379800243 : ℝ) / 500000000000) ((246379800243 : ℝ) / 500000000000) ((246379800243 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_95.1 dlower_log_95.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((34128209789 : ℝ) / 50000000000) ((682650416497 : ℝ) / 1000000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((181419243 : ℝ) / 100000000000) ((1505725869 : ℝ) / 500000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((38661529 : ℝ) / 1000000000000) ((459273 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((1427406949753 : ℝ) / 1000000000000)) - (z15)
  have h16 : RB z16 ((1427361022453 : ℝ) / 1000000000000) ((44605259007 : ℝ) / 31250000000) := rb_widen (rb_sub (show RB ((1427406949753 : ℝ) / 1000000000000) ((1427406949753 : ℝ) / 1000000000000) ((1427406949753 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((427406949753 : ℝ) / 1000000000000))
  have h17 : RB z17 ((3339583091191 : ℝ) / 1000000000000) ((104362502839 : ℝ) / 31250000000) := rb_div_signed h16 (show RB ((427406949753 : ℝ) / 1000000000000) ((427406949753 : ℝ) / 1000000000000) ((427406949753 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((1205845976199 : ℝ) / 1000000000000) ((602925533271 : ℝ) / 500000000000) := rb_log h17 (by norm_num) dlower_log_96.1 dlower_log_97.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1041480217311 : ℝ) / 1000000000000) ((1044534198349 : ℝ) / 1000000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((1427406949753 : ℝ) / 1000000000000))
  have h20 : RB z20 ((355859476361 : ℝ) / 1000000000000) ((355859476363 : ℝ) / 1000000000000) := rb_log (show RB ((1427406949753 : ℝ) / 1000000000000) ((1427406949753 : ℝ) / 1000000000000) ((1427406949753 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_98.1 dlower_log_98.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((171405185237 : ℝ) / 250000000000) ((172168680497 : ℝ) / 250000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((2435368799 : ℝ) / 500000000000) ((9035757229 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((251554459903 : ℝ) / 250000000000) ((40271078733 : ℝ) / 40000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1012474340753 : ℝ) / 1000000000000) ((20271997279 : ℝ) / 20000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((1973165221437 : ℝ) / 1000000000000) ((1975358702437 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((934647349267 : ℝ) / 1000000000000))
  have h26 : RB z26 ((1844213643881 : ℝ) / 1000000000000) ((369252755017 : ℝ) / 200000000000) := rb_widen (rb_mul h25 (show RB ((934647349267 : ℝ) / 1000000000000) ((934647349267 : ℝ) / 1000000000000) ((934647349267 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((38661529 : ℝ) / 1000000000000) ((459273 : ℝ) / 10000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((351684239145614078189979 : ℝ) / 500000000000000000000000))
  have h28 : RB z28 ((54966251 : ℝ) / 1000000000000) ((8162027 : ℝ) / 125000000000) := rb_div_signed h27 (show RB ((351684239145614078189979 : ℝ) / 500000000000000000000000) ((351684239145614078189979 : ℝ) / 500000000000000000000000) ((351684239145614078189979 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((124991837973 : ℝ) / 125000000000) ((999945033749 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((461023305927 : ℝ) / 250000000000) ((1846162292887 : ℝ) / 1000000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((246379800243 : ℝ) / 500000000000)) ((181419243 : ℝ) / 100000000000) ((1505725869 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((1427406949753 : ℝ) / 1000000000000)) ((2435368799 : ℝ) / 500000000000) ((9035757229 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((246379800243 : ℝ) / 500000000000)) (wl := ((1427406949753 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((461023305927 : ℝ) / 250000000000) ≤ D0q (tailQ r) * (((1427406949753 : ℝ) / 1000000000000) - ((246379800243 : ℝ) / 500000000000)) * (1 - (tailQ r) ^ 2 / (((1427406949753 : ℝ) / 1000000000000) * ((246379800243 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_10 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((230850914019309733 : ℝ) / 1152921504606846976) ((58690910343892305 : ℝ) / 288230376151711744)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((736520543237 : ℝ) / 100000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((58690910343892305 : ℝ) / 288230376151711744) ≤ ((-12277470841 : ℝ) / 2500000000) by norm_num).trans dlower_log_99.1)
  have hql : ((33884841621 : ℝ) / 5000000000000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_100.2.trans (show ((-4994225426853 : ℝ) / 1000000000000) ≤ -1 / ((230850914019309733 : ℝ) / 1152921504606846976) by norm_num))
  have hqr : RB (tailQ r) ((33884841621 : ℝ) / 5000000000000) ((736520543237 : ℝ) / 100000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((251694242081 : ℝ) / 250000000000) ((1007365205433 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((3377053949 : ℝ) / 500000000000) ((1467642951 : ℝ) / 200000000000) := rb_log h1 (by norm_num) dlower_log_101.1 dlower_log_102.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((3377053949 : ℝ) / 250000000000) ((1467642951 : ℝ) / 100000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((678470751049 : ℝ) / 1000000000000) ((169909741191 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((13585104657 : ℝ) / 100000000000) ((138391484201 : ℝ) / 1000000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((861608515799 : ℝ) / 1000000000000) ((86414895343 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((45927299 : ℝ) / 1000000000000) ((13561563 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((492019142357 : ℝ) / 1000000000000)) - (z7)
  have h8 : RB z8 ((98392979221 : ℝ) / 200000000000) ((245986607529 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((492019142357 : ℝ) / 1000000000000) ((492019142357 : ℝ) / 1000000000000) ((492019142357 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((507980857643 : ℝ) / 1000000000000))
  have h9 : RB z9 ((4842356643 : ℝ) / 5000000000) ((96848770511 : ℝ) / 100000000000) := rb_div_signed h8 (show RB ((507980857643 : ℝ) / 1000000000000) ((507980857643 : ℝ) / 1000000000000) ((507980857643 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-32036400497 : ℝ) / 1000000000000) ((-32019490991 : ℝ) / 1000000000000) := rb_log h9 (by norm_num) dlower_log_103.1 dlower_log_104.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-13842110981 : ℝ) / 500000000000) ((-27588266109 : ℝ) / 1000000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((492019142357 : ℝ) / 1000000000000))
  have h12 : RB z12 ((-354618828009 : ℝ) / 500000000000) ((-44327353501 : ℝ) / 62500000000) := rb_log (show RB ((492019142357 : ℝ) / 1000000000000) ((492019142357 : ℝ) / 1000000000000) ((492019142357 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_105.1 dlower_log_105.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((340776717027 : ℝ) / 500000000000) ((681649389909 : ℝ) / 1000000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((191446929 : ℝ) / 100000000000) ((158931943 : ℝ) / 50000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((45927299 : ℝ) / 1000000000000) ((13561563 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((5706898037 : ℝ) / 4000000000)) - (z15)
  have h16 : RB z16 ((713335131499 : ℝ) / 500000000000) ((1426678581951 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((5706898037 : ℝ) / 4000000000) ((5706898037 : ℝ) / 4000000000) ((5706898037 : ℝ) / 4000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((1706898037 : ℝ) / 4000000000))
  have h17 : RB z17 ((66866103637 : ℝ) / 20000000000) ((1671662338377 : ℝ) / 500000000000) := rb_div_signed h16 (show RB ((1706898037 : ℝ) / 4000000000) ((1706898037 : ℝ) / 4000000000) ((1706898037 : ℝ) / 4000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((301739973271 : ℝ) / 250000000000) ((1206965724097 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_106.1 dlower_log_107.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1039926922109 : ℝ) / 1000000000000) ((208599633461 : ℝ) / 200000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((5706898037 : ℝ) / 4000000000))
  have h20 : RB z20 ((355381263969 : ℝ) / 1000000000000) ((355381263971 : ℝ) / 1000000000000) := rb_log (show RB ((5706898037 : ℝ) / 4000000000) ((5706898037 : ℝ) / 4000000000) ((5706898037 : ℝ) / 4000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_108.1 dlower_log_108.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((342272829069 : ℝ) / 500000000000) ((85952112917 : ℝ) / 125000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((2453346687 : ℝ) / 500000000000) ((9146152287 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((251694242081 : ℝ) / 250000000000) ((1007365205433 : ℝ) / 1000000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((1013599863947 : ℝ) / 1000000000000) ((507392328559 : ℝ) / 500000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((1970861488663 : ℝ) / 1000000000000) ((493291305361 : ℝ) / 250000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((934705366893 : ℝ) / 1000000000000))
  have h26 : RB z26 ((230271851357 : ℝ) / 125000000000) ((1844328122251 : ℝ) / 1000000000000) := rb_widen (rb_mul h25 (show RB ((934705366893 : ℝ) / 1000000000000) ((934705366893 : ℝ) / 1000000000000) ((934705366893 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((45927299 : ℝ) / 1000000000000) ((13561563 : ℝ) / 250000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((2807903077683586853209 : ℝ) / 4000000000000000000000))
  have h28 : RB z28 ((65425761 : ℝ) / 1000000000000) ((77276531 : ℝ) / 1000000000000) := rb_div_signed h27 (show RB ((2807903077683586853209 : ℝ) / 4000000000000000000000) ((2807903077683586853209 : ℝ) / 4000000000000000000000) ((2807903077683586853209 : ℝ) / 4000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((999922723469 : ℝ) / 1000000000000) ((999934574239 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1842032453977 : ℝ) / 1000000000000) ((1844207455681 : ℝ) / 1000000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((492019142357 : ℝ) / 1000000000000)) ((191446929 : ℝ) / 100000000000) ((158931943 : ℝ) / 50000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((5706898037 : ℝ) / 4000000000)) ((2453346687 : ℝ) / 500000000000) ((9146152287 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((492019142357 : ℝ) / 1000000000000)) (wl := ((5706898037 : ℝ) / 4000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1842032453977 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((5706898037 : ℝ) / 4000000000) - ((492019142357 : ℝ) / 1000000000000)) * (1 - (tailQ r) ^ 2 / (((5706898037 : ℝ) / 4000000000) * ((492019142357 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_T_11 {r : ℝ} (hr0 : 0 < r)
    (hqa : tailQ r ∈ Qadm) (hr : RB r ((58690910343892305 : ℝ) / 288230376151711744) ((238676368731828707 : ℝ) / 1152921504606846976)) : lowerTarget ≤ Lam (tailQ r) := by
  have hqu : tailQ r ≤ ((79826860143 : ℝ) / 10000000000000) := tail_q_upper hr0 hr.2 (by norm_num)
    ((show -1 / ((238676368731828707 : ℝ) / 1152921504606846976) ≤ ((-966096066177 : ℝ) / 200000000000) by norm_num).trans dlower_log_109.1)
  have hql : ((719258343 : ℝ) / 97656250000) ≤ tailQ r := tail_q_lower hr0 hr.1 (by norm_num) (by norm_num)
    (dlower_log_110.2.trans (show ((-982197667281 : ℝ) / 200000000000) ≤ -1 / ((58690910343892305 : ℝ) / 288230376151711744) by norm_num))
  have hqr : RB (tailQ r) ((719258343 : ℝ) / 97656250000) ((79826860143 : ℝ) / 10000000000000) := ⟨hql, hqu⟩
  let z1 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h1 : RB z1 ((125920650679 : ℝ) / 125000000000) ((201596537203 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((7338214753 : ℝ) / 1000000000000) ((795099293 : ℝ) / 100000000000) := rb_log h1 (by norm_num) dlower_log_111.1 dlower_log_112.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((7338214753 : ℝ) / 500000000000) ((795099293 : ℝ) / 50000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((677245194699 : ℝ) / 1000000000000) ((339235375527 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := (r) * (z4)
  have h5 : RB z5 ((13790405277 : ℝ) / 100000000000) ((28091233359 : ℝ) / 200000000000) := rb_widen (rb_mul hr h4 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (z5)
  have h6 : RB z6 ((171908766641 : ℝ) / 200000000000) ((86209594723 : ℝ) / 100000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (tailQ r) ^ 2
  have h7 : RB z7 ((54246251 : ℝ) / 1000000000000) ((63723277 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (((491230793963 : ℝ) / 1000000000000)) - (z7)
  have h8 : RB z8 ((245583535343 : ℝ) / 500000000000) ((3837316779 : ℝ) / 7812500000) := rb_widen (rb_sub (show RB ((491230793963 : ℝ) / 1000000000000) ((491230793963 : ℝ) / 1000000000000) ((491230793963 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / (((508769206037 : ℝ) / 1000000000000))
  have h9 : RB z9 ((965402514259 : ℝ) / 1000000000000) ((482710570809 : ℝ) / 500000000000) := rb_div_signed h8 (show RB ((508769206037 : ℝ) / 1000000000000) ((508769206037 : ℝ) / 1000000000000) ((508769206037 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := Real.log (z9)
  have h10 : RB z10 ((-35210151389 : ℝ) / 1000000000000) ((-1759542833 : ℝ) / 50000000000) := rb_log h9 (by norm_num) dlower_log_113.1 dlower_log_114.2
  let z11 : ℝ := (z10) * (z6)
  have h11 : RB z11 ((-15177264407 : ℝ) / 500000000000) ((-30248083827 : ℝ) / 1000000000000) := rb_mul_signed h10 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (((491230793963 : ℝ) / 1000000000000))
  have h12 : RB z12 ((-355420606411 : ℝ) / 500000000000) ((-35542060641 : ℝ) / 50000000000) := rb_log (show RB ((491230793963 : ℝ) / 1000000000000) ((491230793963 : ℝ) / 1000000000000) ((491230793963 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_115.1 dlower_log_115.2
  let z13 : ℝ := (z11) - (z12)
  have h13 : RB z13 ((340243342003 : ℝ) / 500000000000) ((136118625799 : ℝ) / 200000000000) := rb_widen (rb_sub h11 h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (z13) - (z4)
  have h14 : RB z14 ((251991619 : ℝ) / 125000000000) ((418491787 : ℝ) / 125000000000) := rb_widen (rb_sub h13 h4) (by norm_num) (by norm_num)
  let z15 : ℝ := (tailQ r) ^ 2
  have h15 : RB z15 ((54246251 : ℝ) / 1000000000000) ((63723277 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (((1426078737363 : ℝ) / 1000000000000)) - (z15)
  have h16 : RB z16 ((713007507043 : ℝ) / 500000000000) ((178253061389 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB ((1426078737363 : ℝ) / 1000000000000) ((1426078737363 : ℝ) / 1000000000000) ((1426078737363 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h15) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) / (((426078737363 : ℝ) / 1000000000000))
  have h17 : RB z17 ((1673417245497 : ℝ) / 500000000000) ((209178545839 : ℝ) / 62500000000) := rb_div_signed h16 (show RB ((426078737363 : ℝ) / 1000000000000) ((426078737363 : ℝ) / 1000000000000) ((426078737363 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z18 : ℝ := Real.log (z17)
  have h18 : RB z18 ((151001871381 : ℝ) / 125000000000) ((1208021616839 : ℝ) / 1000000000000) := rb_log h17 (by norm_num) dlower_log_116.1 dlower_log_117.2
  let z19 : ℝ := (z6) * (z18)
  have h19 : RB z19 ((1038341818783 : ℝ) / 1000000000000) ((260357635011 : ℝ) / 250000000000) := rb_widen (rb_mul h6 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (((1426078737363 : ℝ) / 1000000000000))
  have h20 : RB z20 ((44366067001 : ℝ) / 125000000000) ((354928536011 : ℝ) / 1000000000000) := rb_log (show RB ((1426078737363 : ℝ) / 1000000000000) ((1426078737363 : ℝ) / 1000000000000) ((1426078737363 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_118.1 dlower_log_118.2
  let z21 : ℝ := (z19) - (z20)
  have h21 : RB z21 ((170853320693 : ℝ) / 250000000000) ((171625501009 : ℝ) / 250000000000) := rb_widen (rb_sub h19 h20) (by norm_num) (by norm_num)
  let z22 : ℝ := (z21) - (z4)
  have h22 : RB z22 ((2471265859 : ℝ) / 500000000000) ((9256809337 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h4) (by norm_num) (by norm_num)
  let z23 : ℝ := ((1 : ℝ)) + (tailQ r)
  have h23 : RB z23 ((125920650679 : ℝ) / 125000000000) ((201596537203 : ℝ) / 200000000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) ^ 2
  have h24 : RB z24 ((202956931423 : ℝ) / 200000000000) ((1016029095307 : ℝ) / 1000000000000) := rb_widen (rb_sq h23 (by norm_num)) (by norm_num) (by norm_num)
  let z25 : ℝ := ((2 : ℝ)) / (z24)
  have h25 : RB z25 ((123027972897 : ℝ) / 62500000000) ((1970861488669 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) * (((4674239717 : ℝ) / 5000000000))
  have h26 : RB z26 ((920099579547 : ℝ) / 500000000000) ((1842455809409 : ℝ) / 1000000000000) := rb_widen (rb_mul h25 (show RB ((4674239717 : ℝ) / 5000000000) ((4674239717 : ℝ) / 5000000000) ((4674239717 : ℝ) / 5000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (tailQ r) ^ 2
  have h27 : RB z27 ((54246251 : ℝ) / 1000000000000) ((63723277 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) / (((700533790408579042939569 : ℝ) / 1000000000000000000000000))
  have h28 : RB z28 ((15487119 : ℝ) / 200000000000) ((5685243 : ℝ) / 62500000000) := rb_div_signed h27 (show RB ((700533790408579042939569 : ℝ) / 1000000000000000000000000) ((700533790408579042939569 : ℝ) / 1000000000000000000000000) ((700533790408579042939569 : ℝ) / 1000000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((62494314757 : ℝ) / 62500000000) ((199984512881 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((1840031767423 : ℝ) / 1000000000000) ((460578284437 : ℝ) / 250000000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval (tailQ r) = 1 - r * (Real.log 2 - 2 * Real.log (1 + tailQ r)) := by
    simpa only [delta] using aval_tailQ hr0
  have es0 : RB (E (tailQ r) ((491230793963 : ℝ) / 1000000000000)) ((251991619 : ℝ) / 125000000000) ((418491787 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h14
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  have es1 : RB (E (tailQ r) ((1426078737363 : ℝ) / 1000000000000)) ((2471265859 : ℝ) / 500000000000) ((9256809337 : ℝ) / 1000000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h22
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((491230793963 : ℝ) / 1000000000000)) (wl := ((1426078737363 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h30.1
    have hb : ((1840031767423 : ℝ) / 1000000000000) ≤ D0q (tailQ r) * (((1426078737363 : ℝ) / 1000000000000) - ((491230793963 : ℝ) / 1000000000000)) * (1 - (tailQ r) ^ 2 / (((1426078737363 : ℝ) / 1000000000000) * ((491230793963 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
