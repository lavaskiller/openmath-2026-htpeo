import LeanProject.Stage10B3

/-!
# EP-1038, Stage 10, Lemma 10.4(5) and Lemma 10.7 (targets with an atom at `a`)

Hypothesis `hatom`: `S = a` on a subset of `(0, 1)` of positive measure (for an atomic quantile `T_ν`,
`S = d₁ = a` on an interval of length `q₁ > 0`). Then:
* `PsiS_tendsto_zero`: `Ψ_S(y) → 0` as `y ↑ a`;
* `yc_lt` (**Lemma 10.4(5)**): `y_c < a`, so `y_c` is the unique critical point in `(0, a)` and
  `Ψ_S ≤ Ψ_S(y_c) = P(S)` on `(0, a)` (`PsiS_le_yc`);
* **Lemma 10.7**: if `R > Ψ_S(y_c)` then `W_S < 0` on all of `(0, a)` (`WS_neg_of_gt`, the contrapositive
  of "`d₁` not in the main component ⇒ `R ≤ Ψ_S(y_c)`"), and in the contact case `R = Ψ_S(y_c)` the zero
  `y_c` of `W_S` separates the main component from `(y_c, a)`, where `W_S < 0` (`contact_right`).
-/

open Real Set Filter Topology MeasureTheory intervalIntegral

namespace EP1038.Stage10

section atom

variable {k a : ℝ} {S : ℝ → ℝ} (hSm : Measurable S) (ha : 0 < a) (hSa : ∀ u, a ≤ S u)
  (hS2 : ∀ u, S u ≤ 2) (hk : 0 < k)
  (hatom : 0 < volume ({u | S u = a} ∩ Ioc (0 : ℝ) 1))
include hSm ha hSa hS2 hk hatom

omit hk in
theorem LS_sub_le_atom {y : ℝ} (hy0 : 0 ≤ y) (hy : y < a) :
    LS S y - LS S 0 ≤ (volume ({u | S u = a} ∩ Ioc (0 : ℝ) 1)).toReal * Real.log (1 - y / a) := by
  set A := {u | S u = a} ∩ Ioc (0 : ℝ) 1 with hA
  have hAm : MeasurableSet A := (measurableSet_eq_fun hSm measurable_const).inter measurableSet_Ioc
  have hlog0 : Real.log (1 - y / a) ≤ 0 :=
    Real.log_nonpos (by rw [sub_nonneg, div_le_one ha]; exact hy.le)
      (by have := div_nonneg hy0 ha.le; linarith)
  unfold LS
  rw [← intervalIntegral.integral_sub (ii_log hSm ha hSa hS2 hy) (ii_log hSm ha hSa hS2 ha),
    intervalIntegral.integral_of_le zero_le_one]
  have hpt : ∀ u ∈ Ioc (0 : ℝ) 1, Real.log (S u - y) - Real.log (S u - 0) ≤
      A.indicator (fun _ => Real.log (1 - y / a)) u := by
    intro u hu
    have hS : 0 < S u := by linarith [hSa u]
    rw [sub_zero, ← Real.log_div (by linarith [hSa u]) hS.ne']
    by_cases huA : u ∈ A
    · rw [indicator_of_mem huA]
      have hSu : S u = a := huA.1
      rw [hSu, sub_div, div_self ha.ne']
    · rw [indicator_of_notMem huA]
      refine Real.log_nonpos (div_nonneg (by linarith [hSa u]) hS.le) ?_
      rw [div_le_one hS]; linarith
  have hint1 : IntegrableOn (fun u => Real.log (S u - y) - Real.log (S u - 0)) (Ioc 0 1) :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le zero_le_one).mp
      ((ii_log hSm ha hSa hS2 hy).sub (ii_log hSm ha hSa hS2 ha))
  have hint2 : IntegrableOn (A.indicator fun _ => Real.log (1 - y / a)) (Ioc (0 : ℝ) 1) :=
    (integrableOn_const (measure_Ioc_lt_top.ne)).indicator hAm
  calc ∫ u in Ioc (0 : ℝ) 1, (Real.log (S u - y) - Real.log (S u - 0))
      ≤ ∫ u in Ioc (0 : ℝ) 1, A.indicator (fun _ => Real.log (1 - y / a)) u :=
        setIntegral_mono_on hint1 hint2 measurableSet_Ioc hpt
    _ = (volume A).toReal * Real.log (1 - y / a) := by
        rw [MeasureTheory.integral_indicator hAm, Measure.restrict_restrict hAm, setIntegral_const,
          smul_eq_mul]
        have hAA : A ∩ Ioc (0 : ℝ) 1 = A := by rw [hA, inter_assoc, inter_self]
        rw [hAA, measureReal_def]

/-- `Ψ_S(y) → 0` as `y ↑ a`. -/
theorem PsiS_tendsto_zero : Tendsto (PsiS k S) (𝓝[<] a) (𝓝 0) := by
  set m := (volume ({u | S u = a} ∩ Ioc (0 : ℝ) 1)).toReal
  have hm : 0 < m := ENNReal.toReal_pos hatom.ne'
    (ne_top_of_le_ne_top measure_Ioc_lt_top.ne (measure_mono inter_subset_right))
  -- the upper bound `y * (1 - y/a)^(m/k)` tends to 0
  have hlog : Tendsto (fun y => Real.log (1 - y / a)) (𝓝[<] a) atBot := by
    have h1 : Tendsto (fun y => 1 - y / a) (𝓝[<] a) (𝓝[>] 0) := by
      have hc : Tendsto (fun y => 1 - y / a) (𝓝 a) (𝓝 0) :=
        (by fun_prop : Continuous fun y : ℝ => 1 - y / a).tendsto' a 0
          (by rw [div_self ha.ne', sub_self])
      refine tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within _ (hc.mono_left nhdsWithin_le_nhds) ?_
      filter_upwards [self_mem_nhdsWithin] with y hy
      simp only [mem_Ioi, sub_pos]
      rw [div_lt_one ha]; exact hy
    exact Real.tendsto_log_nhdsGT_zero.comp h1
  have hexp : Tendsto (fun y => Real.exp ((1 / k) * (m * Real.log (1 - y / a)))) (𝓝[<] a) (𝓝 0) :=
    Real.tendsto_exp_atBot.comp ((hlog.const_mul_atBot hm).const_mul_atBot (by positivity))
  have hup : Tendsto (fun y => y * Real.exp ((1 / k) * (m * Real.log (1 - y / a)))) (𝓝[<] a) (𝓝 0) := by
    have := (tendsto_nhdsWithin_of_tendsto_nhds (continuous_id.tendsto a)).mul hexp
    simpa using this
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hup ?_ ?_
  · filter_upwards [Ioo_mem_nhdsLT ha] with y hy
    exact (PsiS_pos hSm ha hSa hS2 hy.1).le
  · filter_upwards [Ioo_mem_nhdsLT ha] with y hy
    unfold PsiS
    have hL := LS_sub_le_atom hSm ha hSa hS2 hatom hy.1.le hy.2
    refine mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr ?_) hy.1.le
    exact mul_le_mul_of_nonneg_left hL (by positivity)

/-- **Lemma 10.4(5)**: `y_c < a`. -/
theorem yc_lt : yc k a S < a := by
  have hle := yc_le hSm ha hSa hS2 hk
  rcases hle.lt_or_eq with h | h
  · exact h
  exfalso
  have hmono := PsiS_strictMonoOn hSm ha hSa hS2 hk
  have hpos : 0 < PsiS k S (a / 2) := PsiS_pos hSm ha hSa hS2 (half_pos ha)
  have hev := (PsiS_tendsto_zero hSm ha hSa hS2 hk hatom).eventually (gt_mem_nhds hpos)
  obtain ⟨y, hy1, hy2⟩ := (hev.and (Ioo_mem_nhdsLT (show a / 2 < a by linarith))).exists
  have := hmono (show a / 2 ∈ Iio (yc k a S) by rw [h]; simp only [mem_Iio]; linarith)
    (show y ∈ Iio (yc k a S) by rw [h]; exact hy2.2) hy2.1
  linarith

/-- `Ψ_S ≤ Ψ_S(y_c)` on `(0, a)`, i.e. `P(S) = Ψ_S(y_c)`. -/
theorem PsiS_le_yc {y : ℝ} (hy0 : 0 < y) (hy : y < a) : PsiS k S y ≤ PsiS k S (yc k a S) := by
  have hyc := yc_lt hSm ha hSa hS2 hk hatom
  rcases le_total y (yc k a S) with h | h
  · exact (PsiS_strictMonoOn_Iic hSm ha hSa hS2 hk hyc).monotoneOn h (Set.mem_Iic.mpr le_rfl) h
  · exact (PsiS_strictAntiOn hSm ha hSa hS2 hk).antitoneOn ⟨le_rfl, hyc⟩ ⟨h, hy⟩ h

/-- **Lemma 10.7** (contrapositive of the first claim): if `R > Ψ_S(y_c)` then `W_S < 0` on `(0, a)`,
so `(0, d₁]` lies in the main component. -/
theorem WS_neg_of_gt (hgt : PsiS k S (yc k a S) < RS k S) {y : ℝ} (hy0 : 0 < y) (hy : y < a) :
    WS k S y < 0 := by
  rw [WS_neg_iff hSm ha hSa hS2 hk hy hy0.ne', abs_of_pos (PsiS_pos hSm ha hSa hS2 hy0)]
  exact lt_of_le_of_lt (PsiS_le_yc hSm ha hSa hS2 hk hatom hy0 hy) hgt

/-- **Lemma 10.7**, contact case: `W_S(y_c) = 0` and `W_S < 0` on `(y_c, a)`. -/
theorem contact_right (hcon : RS k S = PsiS k S (yc k a S)) :
    WS k S (yc k a S) = 0 ∧ ∀ y, yc k a S < y → y < a → WS k S y < 0 := by
  have hyc := yc_lt hSm ha hSa hS2 hk hatom
  have hycpos := yc_pos hSm ha hSa hS2 hk
  have hR := RS_pos hSm ha hSa hS2 hk
  refine ⟨WS_zero_of_abs hSm ha hSa hS2 hk hyc hycpos.ne' (by rw [← hcon, abs_of_pos hR]), ?_⟩
  intro y h1 h2
  rw [WS_neg_iff hSm ha hSa hS2 hk h2 (by linarith), abs_of_pos (PsiS_pos hSm ha hSa hS2
    (by linarith)), hcon]
  exact PsiS_strictAntiOn hSm ha hSa hS2 hk ⟨le_rfl, hyc⟩ ⟨h1.le, h2⟩ h1

/-- **Lemma 10.7**: an atomic-type target is admissible or has `(0, a) ⊆ {W_S < 0}`. -/
theorem sep_or_contact_or_swallow :
    RS k S < PsiS k S (yc k a S) ∨ RS k S = PsiS k S (yc k a S) ∨
      ∀ y, 0 < y → y < a → WS k S y < 0 := by
  rcases lt_trichotomy (RS k S) (PsiS k S (yc k a S)) with h | h | h
  · exact Or.inl h
  · exact Or.inr (Or.inl h)
  · exact Or.inr (Or.inr fun y hy0 hy => WS_neg_of_gt hSm ha hSa hS2 hk hatom h hy0 hy)

end atom

end EP1038.Stage10
