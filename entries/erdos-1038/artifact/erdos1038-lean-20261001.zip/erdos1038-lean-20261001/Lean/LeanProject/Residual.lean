import LeanProject.Atomize
import LeanProject.NumericK

/-!
# EP-1038: the universal lower bound `|S_p| ≥ 61/40 = 1.525` (roadmap 15d, part 2)

* `rhoR`, `ellL`, `comp_props`: the component `(ℓ v, ρ v)` of `S` around a root value `v`; its ends
  are outside `S` with `|f| = 1`.
* `other_outside`, `comp_disjoint`: for a clustered configuration, other root values lie outside
  `[ℓ v, ρ v]` and components of distinct values are disjoint.
* `comp_width`: **Lemma 7.5(b)**, the component of `v` has width `≥ 2 R_v`,
  `R_v = exp(-(∑_{s j ≠ v} log|v - s j|)/m_v)` (concavity of the residual log-potential + `radius_bound`).
* `setup`: the main-component data of `Atom.sqrt2_clustered` (least root `c0` of multiplicity
  `a ≥ b`, first point `r0 ∉ S` right of `c0`, `r0 ≥ c0 + 1`, `|f(r0)| = 1`).
* `prop81_link`: the residual radii satisfy `∑ R_v > 1/3` when `b ≤ a ≤ (29/20) b`
  (Proposition 8.1, `prop81_full` in `NumericK`).
* `window`, `bound_clustered`, `bound_le`: if `20a ≥ 29b` the window `(c0 - 21/40, c0 + 1)` has
  length `61/40`; otherwise `(c0 - 2/5, r0)` and the disjoint residual components give
  `≥ 7/5 + 2/3`.
* `EP1038.volume_bounds_1525`: **every `p ∈ 𝒫` has `61/40 ≤ |S_p| ≤ 2√2`**
  (`61/40 = 1.525 > 2^{4/3} - 1 ≈ 1.5198`).
-/

open Real MeasureTheory Finset

namespace EP1038.Resid

open Atom

variable {n : ℕ} (s : Fin n → ℝ)

theorem sublevel_open : IsOpen (sublevel s) := isOpen_lt (continuous_absProd s) continuous_const

theorem pos_comb {p q a : ℝ} (hp : 0 < p) (hq : 0 < q) (ha : 0 ≤ a) (ha1 : a ≤ 1) :
    0 < a * p + (1 - a) * q := by
  rcases eq_or_lt_of_le ha with h | h
  · rw [← h]; simp; exact hq
  · have h1 := mul_pos h hp
    have h2 := mul_nonneg (sub_nonneg.mpr ha1) hq.le
    linarith

/-- The component of `S` around a root value `v`: its right end `ρ v = inf (Sᶜ ∩ [v, ∞))`. -/
noncomputable def rhoR (v : ℝ) : ℝ := sInf ((sublevel s)ᶜ ∩ Set.Ici v)

/-- Its left end `ℓ v = sup (Sᶜ ∩ (-∞, v])`. -/
noncomputable def ellL (v : ℝ) : ℝ := sSup ((sublevel s)ᶜ ∩ Set.Iic v)

section comp

variable {s} (hs : ∀ i, s i ∈ Set.Icc (-1 : ℝ) 1)
include hs

theorem compl_right_nonempty (v : ℝ) (hv : v ≤ 2) : ((sublevel s)ᶜ ∩ Set.Ici v).Nonempty :=
  ⟨2, fun h => lt_irrefl _ (sublevel_subset_Ioo s hs h).2, by simpa using hv⟩

theorem compl_left_nonempty (v : ℝ) (hv : -2 ≤ v) : ((sublevel s)ᶜ ∩ Set.Iic v).Nonempty :=
  ⟨-2, fun h => lt_irrefl _ (sublevel_subset_Ioo s hs h).1, by simpa using hv⟩

/-- Properties of the right end: `ρ ∉ S`, `v ≤ ρ`, `[v, ρ) ⊆ S`. -/
theorem rhoR_props (v : ℝ) (hv : v ≤ 2) :
    rhoR s v ∉ sublevel s ∧ v ≤ rhoR s v ∧ ∀ y, v ≤ y → y < rhoR s v → y ∈ sublevel s := by
  have hne := compl_right_nonempty hs v hv
  have hbdd : BddBelow ((sublevel s)ᶜ ∩ Set.Ici v) := ⟨v, fun y hy => hy.2⟩
  have hcl : IsClosed ((sublevel s)ᶜ ∩ Set.Ici v) :=
    (sublevel_open s).isClosed_compl.inter isClosed_Ici
  have hmem := hcl.csInf_mem hne hbdd
  refine ⟨hmem.1, hmem.2, fun y hy1 hy2 => ?_⟩
  by_contra hy
  have := csInf_le hbdd ⟨hy, hy1⟩
  exact absurd hy2 (not_lt.mpr this)

/-- Properties of the left end: `ℓ ∉ S`, `ℓ ≤ v`, `(ℓ, v] ⊆ S`. -/
theorem ellL_props (v : ℝ) (hv : -2 ≤ v) :
    ellL s v ∉ sublevel s ∧ ellL s v ≤ v ∧ ∀ y, ellL s v < y → y ≤ v → y ∈ sublevel s := by
  have hne := compl_left_nonempty hs v hv
  have hbdd : BddAbove ((sublevel s)ᶜ ∩ Set.Iic v) := ⟨v, fun y hy => hy.2⟩
  have hcl : IsClosed ((sublevel s)ᶜ ∩ Set.Iic v) :=
    (sublevel_open s).isClosed_compl.inter isClosed_Iic
  have hmem := hcl.csSup_mem hne hbdd
  refine ⟨hmem.1, hmem.2, fun y hy1 hy2 => ?_⟩
  by_contra hy
  have := le_csSup hbdd ⟨hy, hy2⟩
  exact absurd hy1 (not_lt.mpr this)

omit hs in
/-- A boundary point outside `S` that is a limit of points of `S` has `|f| = 1`. -/
theorem abs_eq_one_of_boundary {z : ℝ} (hz : z ∉ sublevel s)
    (hlim : ∀ ε > 0, ∃ y, |y - z| < ε ∧ y ∈ sublevel s) : |∏ i, (z - s i)| = 1 := by
  apply le_antisymm _ (not_lt.mp hz)
  by_contra hgt
  push Not at hgt
  have hopen : IsOpen {x : ℝ | 1 < |∏ i, (x - s i)|} :=
    isOpen_lt continuous_const (continuous_absProd s)
  obtain ⟨ε, hε, hball⟩ := Metric.isOpen_iff.mp hopen z hgt
  obtain ⟨y, hy, hyS⟩ := hlim ε hε
  have h1 : 1 < |∏ i, (y - s i)| := hball (by rw [Metric.mem_ball, Real.dist_eq]; exact hy)
  have h2 : |∏ i, (y - s i)| < 1 := hyS
  linarith

/-- The component `(ℓ v, ρ v)` of a root value `v` lies in `S`, its ends are outside `S` with
`|f| = 1`, and `ℓ v < v < ρ v`. -/
theorem comp_props (i : Fin n) :
    ellL s (s i) < s i ∧ s i < rhoR s (s i) ∧
      Set.Ioo (ellL s (s i)) (rhoR s (s i)) ⊆ sublevel s ∧
      |∏ j, (ellL s (s i) - s j)| = 1 ∧ |∏ j, (rhoR s (s i) - s j)| = 1 := by
  have hv1 : -2 ≤ s i := by linarith [(hs i).1]
  have hv2 : s i ≤ 2 := by linarith [(hs i).2]
  obtain ⟨hL1, hL2, hL3⟩ := ellL_props hs (s i) hv1
  obtain ⟨hR1, hR2, hR3⟩ := rhoR_props hs (s i) hv2
  have hroot := root_mem s i
  have hlt1 : ellL s (s i) < s i := lt_of_le_of_ne hL2 (fun h => hL1 (by rw [h]; exact hroot))
  have hlt2 : s i < rhoR s (s i) := lt_of_le_of_ne hR2 (fun h => hR1 (by rw [← h]; exact hroot))
  have hIoo : Set.Ioo (ellL s (s i)) (rhoR s (s i)) ⊆ sublevel s := by
    intro y ⟨h1, h2⟩
    rcases le_total y (s i) with h | h
    · exact hL3 y h1 h
    · exact hR3 y h h2
  refine ⟨hlt1, hlt2, hIoo, ?_, ?_⟩
  · apply abs_eq_one_of_boundary hL1
    intro ε hε
    refine ⟨ellL s (s i) + min (ε / 2) ((s i - ellL s (s i)) / 2), ?_, hIoo ⟨?_, ?_⟩⟩
    · have h0 : 0 < min (ε / 2) ((s i - ellL s (s i)) / 2) := lt_min (by linarith) (by linarith)
      rw [add_sub_cancel_left, abs_of_pos h0]
      exact lt_of_le_of_lt (min_le_left _ _) (by linarith)
    · have : 0 < min (ε / 2) ((s i - ellL s (s i)) / 2) := lt_min (by linarith) (by linarith)
      linarith
    · have : min (ε / 2) ((s i - ellL s (s i)) / 2) ≤ (s i - ellL s (s i)) / 2 := min_le_right _ _
      linarith
  · apply abs_eq_one_of_boundary hR1
    intro ε hε
    refine ⟨rhoR s (s i) - min (ε / 2) ((rhoR s (s i) - s i) / 2), ?_, hIoo ⟨?_, ?_⟩⟩
    · have h0 : 0 < min (ε / 2) ((rhoR s (s i) - s i) / 2) := lt_min (by linarith) (by linarith)
      rw [sub_sub_cancel_left, abs_neg, abs_of_pos h0]
      exact lt_of_le_of_lt (min_le_left _ _) (by linarith)
    · have : min (ε / 2) ((rhoR s (s i) - s i) / 2) ≤ (rhoR s (s i) - s i) / 2 := min_le_right _ _
      linarith
    · have : 0 < min (ε / 2) ((rhoR s (s i) - s i) / 2) := lt_min (by linarith) (by linarith)
      linarith

variable (hcl : ∀ i j, Set.uIcc (s i) (s j) ⊆ sublevel s → s i = s j)
include hcl

/-- Other root values lie outside the closed component `[ℓ v, ρ v]`. -/
theorem other_outside (i j : Fin n) (hij : s j ≠ s i) :
    s j < ellL s (s i) ∨ rhoR s (s i) < s j := by
  obtain ⟨h1, h2, hIoo, -, -⟩ := comp_props hs i
  have hL := (ellL_props hs (s i) (by linarith [(hs i).1])).1
  have hR := (rhoR_props hs (s i) (by linarith [(hs i).2])).1
  have hroot := root_mem s j
  by_contra hc
  push Not at hc
  obtain ⟨hc1, hc2⟩ := hc
  have hc1' : ellL s (s i) < s j := lt_of_le_of_ne hc1 (fun h => hL (by rw [h]; exact hroot))
  have hc2' : s j < rhoR s (s i) := lt_of_le_of_ne hc2 (fun h => hR (by rw [← h]; exact hroot))
  apply hij
  apply hcl j i
  intro y hy
  apply hIoo
  rw [Set.mem_uIcc] at hy
  rcases hy with ⟨a, b⟩ | ⟨a, b⟩ <;> constructor <;> linarith

/-- Components of distinct root values are disjoint. -/
theorem comp_disjoint (i j : Fin n) (hij : s i ≠ s j) :
    Disjoint (Set.Ioo (ellL s (s i)) (rhoR s (s i))) (Set.Ioo (ellL s (s j)) (rhoR s (s j))) := by
  obtain ⟨hi1, hi2, hIi, -, -⟩ := comp_props hs i
  obtain ⟨hj1, hj2, hIj, -, -⟩ := comp_props hs j
  rw [Set.disjoint_left]
  intro x hxi hxj
  apply hij
  apply hcl i j
  intro y hy
  rw [Set.mem_uIcc] at hy
  rcases hy with ⟨a, b⟩ | ⟨a, b⟩
  · rcases le_total y x with h | h
    · exact hIi ⟨by linarith [hxi.1], by linarith [hxi.2]⟩
    · exact hIj ⟨by linarith [hxj.1], by linarith [hxj.2]⟩
  · rcases le_total y x with h | h
    · exact hIj ⟨by linarith [hxj.1], by linarith [hxj.2]⟩
    · exact hIi ⟨by linarith [hxi.1], by linarith [hxi.2]⟩

/-- **Lemma 7.5(b)**: the component of the root value `v = s i` (multiplicity `m`) has width
`≥ 2 R_v`, `R_v = exp(-(∑_{s j ≠ v} log|v - s j|)/m)`. -/
theorem comp_width (i : Fin n) :
    2 * Real.exp (-(∑ j ∈ univ.filter (fun j => s j ≠ s i), Real.log |s i - s j|) /
        ((univ.filter (fun j => s j = s i)).card : ℝ)) ≤
      rhoR s (s i) - ellL s (s i) := by
  classical
  obtain ⟨hl, hr, hIoo, hfl, hfr⟩ := comp_props hs i
  set l := ellL s (s i) with hldef
  set r := rhoR s (s i) with hrdef
  set v := s i with hv
  set F := univ.filter (fun j => s j ≠ v) with hF
  set E := univ.filter (fun j => s j = v) with hE
  have hiE : i ∈ E := by simp [hE, hv]
  have hmpos : (0 : ℝ) < E.card := by
    exact_mod_cast Finset.card_pos.mpr ⟨i, hiE⟩
  set H : ℝ → ℝ := fun x => ∑ j ∈ F, Real.log |x - s j| with hH
  -- the log of |f| splits
  have hsplit : ∀ x, ∑ j, Real.log |x - s j| = E.card * Real.log |x - v| + H x := by
    intro x
    rw [← Finset.sum_filter_add_sum_filter_not univ (fun j => s j = v)]
    congr 1
    rw [Finset.sum_congr rfl (fun j hj => by rw [(Finset.mem_filter.mp hj).2]), sum_const,
      nsmul_eq_mul]
  have hlogf : ∀ x, x ∉ sublevel s → |∏ j, (x - s j)| = 1 → ∑ j, Real.log |x - s j| = 0 := by
    intro x hx h1
    have hne : ∀ j, x - s j ≠ 0 := fun j h =>
      hx (by rw [show x = s j by linarith]; exact root_mem s j)
    rw [← Real.log_prod (fun j _ => abs_ne_zero.mpr (hne j)), ← Finset.abs_prod, h1, Real.log_one]
  have hLnot := (ellL_props hs v (by linarith [(hs i).1])).1
  have hRnot := (rhoR_props hs v (by linarith [(hs i).2])).1
  have hHl : H l = -(E.card : ℝ) * Real.log (v - l) := by
    have := hsplit l
    rw [hlogf l hLnot hfl, abs_sub_comm, abs_of_pos (by linarith)] at this
    linarith
  have hHr : H r = -(E.card : ℝ) * Real.log (r - v) := by
    have := hsplit r
    rw [hlogf r hRnot hfr, abs_of_pos (by linarith)] at this
    linarith
  set R := Real.exp (-(H v) / E.card) with hRdef
  have hHv : H v = -(E.card : ℝ) * Real.log R := by
    rw [hRdef, Real.log_exp]; field_simp
  -- concavity of H on [l, r]
  have hside : ∀ j ∈ F, s j < l ∨ r < s j := fun j hj =>
    other_outside hs hcl i j (Finset.mem_filter.mp hj).2
  have hconc : ConcaveOn ℝ (Set.Icc l r) H := by
    refine ⟨convex_Icc l r, fun x hx y hy a b ha hb hab => ?_⟩
    simp only [hH, smul_eq_mul, Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro j hj
    have hb' : b = 1 - a := by linarith
    subst hb'
    rcases hside j hj with h | h
    · have p1 : 0 < x - s j := by linarith [hx.1]
      have p2 : 0 < y - s j := by linarith [hy.1]
      have e0 : a * x + (1 - a) * y - s j = a * (x - s j) + (1 - a) * (y - s j) := by ring
      rw [abs_of_pos p1, abs_of_pos p2, abs_of_pos (by rw [e0]; exact pos_comb p1 p2 ha (by linarith))]
      have := Arcsine.log_two_point p1 p2 ha (by linarith)
      have e : a * (x - s j) + (1 - a) * (y - s j) = a * x + (1 - a) * y - s j := by ring
      rw [e] at this; exact this
    · have p1 : 0 < s j - x := by linarith [hx.2]
      have p2 : 0 < s j - y := by linarith [hy.2]
      have e0 : s j - (a * x + (1 - a) * y) = a * (s j - x) + (1 - a) * (s j - y) := by ring
      rw [abs_sub_comm, abs_of_pos p1, abs_sub_comm y, abs_of_pos p2, abs_sub_comm,
        abs_of_pos (by rw [e0]; exact pos_comb p1 p2 ha (by linarith))]
      have := Arcsine.log_two_point p1 p2 ha (by linarith)
      have e : a * (s j - x) + (1 - a) * (s j - y) = s j - (a * x + (1 - a) * y) := by ring
      rw [e] at this; exact this
  have hRpos : 0 < R := Real.exp_pos _
  have := radius_bound hl hr hmpos hRpos hconc (by rw [hHl]) (by rw [hHr]) hHv
  simpa [hH, hRdef] using this

end comp

/-- The main-component setup of `sqrt2_clustered`, packaged: least root `c0` with multiplicity
`a ≥ b` (`b` = number of other roots), the first point `r0 ∉ S` right of `c0`, `r0 ≥ c0 + 1`,
`|f(r0)| = 1`, other roots `> r0`, and `(c0, r0) ⊆ S`. -/
theorem setup {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Set.Icc (-1 : ℝ) 1)
    (hsum : ∑ i, s i ≤ 0) (hcl : ∀ i j, Set.uIcc (s i) (s j) ⊆ sublevel s → s i = s j) :
    ∃ i0 : Fin n, ∃ r0 : ℝ, -1 ≤ s i0 ∧ s i0 ≤ 0 ∧ (∀ i, s i0 ≤ s i) ∧ s i0 + 1 ≤ r0 ∧
      r0 ∉ sublevel s ∧ |∏ i, (r0 - s i)| = 1 ∧ (∀ i, s i ≠ s i0 → r0 < s i) ∧
      (∀ y, s i0 ≤ y → y < r0 → y ∈ sublevel s) ∧
      ((univ.filter (fun i => s i ≠ s i0)).card ≤ (univ.filter (fun i => s i = s i0)).card) := by
  classical
  have hne : (univ : Finset (Fin n)).Nonempty := ⟨⟨0, hn⟩, mem_univ _⟩
  obtain ⟨i0, -, hmin⟩ := (univ : Finset (Fin n)).exists_min_image s hne
  set c0 := s i0 with hc0
  have hc0l : -1 ≤ c0 := (hs i0).1
  have hcle : ∀ i, c0 ≤ s i := fun i => hmin i (mem_univ i)
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hc0n : (n : ℝ) * c0 ≤ 0 := by
    calc (n : ℝ) * c0 = ∑ _i : Fin n, c0 := by simp
      _ ≤ ∑ i, s i := sum_le_sum fun i _ => hcle i
      _ ≤ 0 := hsum
  have hc00 : c0 ≤ 0 := by nlinarith
  have hIoo : Set.Ioo c0 (c0 + 1) ⊆ sublevel s := by
    have ht : ∀ i, (fun i => s i - (c0 + 1)) i ∈ Set.Icc (-1 : ℝ) 1 := fun i =>
      ⟨by linarith [hcle i], by linarith [(hs i).2]⟩
    have htsum : ∑ i, (fun i => s i - (c0 + 1)) i ≤ 0 := by
      simp only [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
        nsmul_eq_mul]
      nlinarith
    have h := Ioo_subset_sublevel hn _ ht htsum
    intro x hx
    have hx' : x - (c0 + 1) ∈ Set.Ioo (-1 : ℝ) 0 := ⟨by linarith [hx.1], by linarith [hx.2]⟩
    have := (mem_sublevel_shift s (c0 + 1) (x - (c0 + 1))).mp (h hx')
    rwa [sub_add_cancel] at this
  obtain ⟨hR1, hR2, hR3⟩ := rhoR_props hs c0 (by linarith)
  set r0 := rhoR s c0 with hr0
  have hr0ge : c0 + 1 ≤ r0 := by
    by_contra hc
    push Not at hc
    rcases hR2.lt_or_eq with h | h
    · exact hR1 (hIoo ⟨h, hc⟩)
    · rw [← h] at hR1; exact hR1 (root_mem s i0)
  have hf1 : |∏ i, (r0 - s i)| = 1 := by
    apply abs_eq_one_of_boundary hR1
    intro ε hε
    refine ⟨r0 - min (ε / 2) (1 / 2), ?_, hR3 _ ?_ ?_⟩
    · have h0 : 0 < min (ε / 2) (1 / 2) := lt_min (by linarith) (by norm_num)
      rw [sub_sub_cancel_left, abs_neg, abs_of_pos h0]
      exact lt_of_le_of_lt (min_le_left _ _) (by linarith)
    · have : min (ε / 2) (1 / 2) ≤ 1 / 2 := min_le_right _ _
      linarith
    · have : 0 < min (ε / 2) (1 / 2) := lt_min (by linarith) (by norm_num)
      linarith
  have hother : ∀ i, s i ≠ c0 → r0 < s i := by
    intro i hi
    by_contra hle
    push Not at hle
    rcases hle.lt_or_eq with h | h
    · apply hi; symm
      apply hcl i0 i
      intro x hx
      rw [Set.uIcc_of_le (hcle i)] at hx
      exact hR3 x hx.1 (lt_of_le_of_lt hx.2 h)
    · rw [← h] at hR1; exact hR1 (root_mem s i)
  -- a ≥ b by AM–GM at r0
  set A := univ.filter (fun i => s i = c0) with hA
  set O := univ.filter (fun i => s i ≠ c0) with hO
  have hsplitAO : ∀ g : Fin n → ℝ, ∑ i, g i = ∑ i ∈ A, g i + ∑ i ∈ O, g i := fun g =>
    (Finset.sum_filter_add_sum_filter_not univ (fun i => s i = c0) g).symm
  have hz : ∀ i, |r0 - s i| = if s i = c0 then r0 - c0 else s i - r0 := by
    intro i
    split_ifs with h
    · rw [h, abs_of_nonneg (by linarith)]
    · rw [abs_sub_comm, abs_of_pos (by linarith [hother i h])]
  have hamgm := amgm_prod_le hn (fun i => |r0 - s i|) (fun i => abs_nonneg _)
  rw [← Finset.abs_prod, hf1] at hamgm
  have hsumz : (n : ℝ) ≤ ∑ i, |r0 - s i| := by
    by_contra hc
    push Not at hc
    have hmean : (∑ i, |r0 - s i|) / n < 1 := by rw [div_lt_one hnR]; exact hc
    have hmean0 : 0 ≤ (∑ i, |r0 - s i|) / n := by positivity
    have := pow_lt_one₀ hmean0 hmean (Nat.pos_iff_ne_zero.mp hn)
    linarith
  have hcardAO : (A.card : ℝ) + O.card = n := by
    have := Finset.card_filter_add_card_filter_not (s := univ) (fun i => s i = c0)
    rw [Finset.card_univ, Fintype.card_fin] at this
    exact_mod_cast this
  have hzA : ∑ i ∈ A, |r0 - s i| = A.card * (r0 - c0) := by
    rw [Finset.sum_congr rfl (fun i hi => by rw [hz i, if_pos (Finset.mem_filter.mp hi).2]),
      sum_const, nsmul_eq_mul]
  have hzO : ∑ i ∈ O, |r0 - s i| = ∑ i ∈ O, s i - O.card * r0 := by
    rw [Finset.sum_congr rfl (fun i hi => by rw [hz i, if_neg (Finset.mem_filter.mp hi).2]),
      sum_sub_distrib, sum_const, nsmul_eq_mul]
  have hsA : ∑ i ∈ A, s i = A.card * c0 := by
    rw [Finset.sum_congr rfl (fun i hi => (Finset.mem_filter.mp hi).2), sum_const, nsmul_eq_mul]
  have hs_split := hsplitAO s
  have hz_split := hsplitAO (fun i => |r0 - s i|)
  have hr0nn : 0 ≤ r0 := by linarith
  have hAO : (O.card : ℝ) ≤ A.card := by
    by_contra hc
    push Not at hc
    nlinarith
  refine ⟨i0, r0, hc0l, hc00, hcle, hr0ge, hR1, hf1, hother, hR3, ?_⟩
  exact_mod_cast hAO

/-- Regrouping a sum over the other roots by value. -/
theorem regroup {n : ℕ} (s : Fin n → ℝ) (c0 : ℝ) (g : ℝ → ℝ) :
    ∑ i ∈ univ.filter (fun i => s i ≠ c0), g (s i) =
      ∑ w ∈ (univ.filter (fun i => s i ≠ c0)).image s,
        ((univ.filter (fun i => s i = w)).card : ℝ) * g w := by
  classical
  rw [Finset.sum_comp]
  apply Finset.sum_congr rfl
  intro w hw
  obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hw
  have hne : s i ≠ c0 := (Finset.mem_filter.mp hi).2
  have hfib : (univ.filter (fun i => s i ≠ c0)).filter (fun a => s a = s i) =
      univ.filter (fun a => s a = s i) := by
    ext j
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    constructor
    · rintro ⟨_, h⟩; exact h
    · intro h; exact ⟨by rw [h]; exact hne, h⟩
  rw [hfib, nsmul_eq_mul]

/-- Sum over a finset of reals via its order isomorphism with `Fin`. -/
theorem sum_via_fin (V : Finset ℝ) (F : ℝ → ℝ) :
    ∑ w ∈ V, F w = ∑ j : Fin V.card, F (V.orderIsoOfFin rfl j) := by
  rw [← Finset.sum_coe_sort V F]
  exact ((V.orderIsoOfFin rfl).toEquiv.sum_comp (fun x => F x)).symm

/-- **Link to Proposition 8.1** (`prop81_full`): for `b ≤ a ≤ (29/20) b`, the residual radii satisfy
`∑ R > 1/3`. Here the residual values are enumerated as `v j`, `j : Fin N`. -/
theorem prop81_link {n : ℕ} (s : Fin n → ℝ) {c0 r0 : ℝ} (hc0l : -1 ≤ c0)
    (hs : ∀ i, s i ∈ Set.Icc (-1 : ℝ) 1) (hr0ge : c0 + 1 ≤ r0)
    (hf1 : |∏ i, (r0 - s i)| = 1) (hother : ∀ i, s i ≠ c0 → r0 < s i)
    (hb1 : 1 ≤ (univ.filter (fun i => s i ≠ c0)).card)
    (hab : (univ.filter (fun i => s i ≠ c0)).card ≤ (univ.filter (fun i => s i = c0)).card)
    (hk : 20 * (univ.filter (fun i => s i = c0)).card ≤ 29 * (univ.filter (fun i => s i ≠ c0)).card) :
    let V := (univ.filter (fun i => s i ≠ c0)).image s
    let v : Fin V.card → ℝ := fun j => V.orderIsoOfFin rfl j
    1 / 3 < ∑ j, Real.exp (-(∑ i ∈ univ.filter (fun i => s i ≠ v j), Real.log |v j - s i|) /
      ((univ.filter (fun i => s i = v j)).card : ℝ)) := by
  classical
  intro V v
  set O := univ.filter (fun i => s i ≠ c0) with hO
  set A := univ.filter (fun i => s i = c0) with hA
  set aR : ℝ := (A.card : ℝ) with haR
  set bR : ℝ := (O.card : ℝ) with hbR
  have hbpos : (0 : ℝ) < bR := by rw [hbR]; exact_mod_cast hb1
  have habR : bR ≤ aR := by rw [hbR, haR]; exact_mod_cast hab
  have hkR : 20 * aR ≤ 29 * bR := by rw [hbR, haR]; exact_mod_cast hk
  -- facts about the values v j
  have hvV : ∀ j, v j ∈ V := fun j => (V.orderIsoOfFin rfl j).2
  have hvO : ∀ j, ∃ i ∈ O, s i = v j := fun j => Finset.mem_image.mp (hvV j)
  have hvne : ∀ j, v j ≠ c0 := by
    intro j; obtain ⟨i, hi, h⟩ := hvO j; rw [← h]; exact (Finset.mem_filter.mp hi).2
  have hvgt : ∀ j, r0 < v j := by
    intro j; obtain ⟨i, hi, h⟩ := hvO j; rw [← h]; exact hother i (Finset.mem_filter.mp hi).2
  have hvle : ∀ j, v j ≤ 1 := by
    intro j; obtain ⟨i, _, h⟩ := hvO j; rw [← h]; exact (hs i).2
  have hvinj : ∀ j j', v j = v j' → j = j' := fun j j' h =>
    (V.orderIsoOfFin rfl).injective (Subtype.ext h)
  set m : Fin V.card → ℝ := fun j => ((univ.filter (fun i => s i = v j)).card : ℝ) with hm
  have hmpos : ∀ j, 0 < m j := by
    intro j; obtain ⟨i, _, h⟩ := hvO j
    simp only [hm]
    exact_mod_cast Finset.card_pos.mpr ⟨i, Finset.mem_filter.mpr ⟨mem_univ _, h⟩⟩
  -- regrouping over the values
  have hreg : ∀ g : ℝ → ℝ, ∑ i ∈ O, g (s i) = ∑ j, m j * g (v j) := by
    intro g
    rw [regroup s c0 g, sum_via_fin]
  have hsum_m : ∑ j, m j = bR := by
    have := hreg (fun _ => 1)
    simp only [mul_one, Finset.sum_const, nsmul_eq_mul] at this
    rw [hbR]; linarith
  -- data for prop81_full
  set q : Fin V.card → ℝ := fun j => m j / bR with hq
  set d : Fin V.card → ℝ := fun j => v j - c0 with hd
  set k : ℝ := aR / bR with hkdef
  set bb : ℝ := r0 - c0 with hbb
  have hq0 : ∀ j, 0 < q j := fun j => div_pos (hmpos j) hbpos
  have hq1 : ∑ j, q j = 1 := by
    simp only [hq, ← Finset.sum_div, hsum_m]; field_simp
  have hd1 : ∀ j, 1 ≤ d j := fun j => by simp only [hd]; linarith [hvgt j]
  have hd2 : ∀ j, d j ≤ 2 := fun j => by simp only [hd]; linarith [hvle j]
  have hdist : ∀ j j', j ≠ j' → d j ≠ d j' := by
    intro j j' hjj' h; apply hjj'; apply hvinj; simp only [hd] at h; linarith
  have hk1 : 1 ≤ k := by rw [hkdef, le_div_iff₀ hbpos]; linarith
  have hkK : k ≤ 29 / 20 := by rw [hkdef, div_le_iff₀ hbpos]; linarith
  have hbb0 : 0 < bb := by simp only [hbb]; linarith
  have hbbd : ∀ j, bb < d j := fun j => by simp only [hbb, hd]; linarith [hvgt j]
  -- the separation condition from |f(r0)| = 1
  have hne0 : ∀ i, r0 - s i ≠ 0 := by
    intro i h
    by_cases hi : s i = c0
    · rw [hi] at h; linarith
    · have := hother i hi; linarith
  have hlog0 : ∑ i, Real.log |r0 - s i| = 0 := by
    rw [← Real.log_prod (fun i _ => abs_ne_zero.mpr (hne0 i)), ← Finset.abs_prod, hf1, Real.log_one]
  have hsplit : ∑ i, Real.log |r0 - s i| =
      aR * Real.log (r0 - c0) + ∑ j, m j * Real.log (v j - r0) := by
    rw [← Finset.sum_filter_add_sum_filter_not univ (fun i => s i = c0)]
    congr 1
    · rw [Finset.sum_congr rfl (fun i hi => by rw [(Finset.mem_filter.mp hi).2]), sum_const,
        nsmul_eq_mul, abs_of_pos (by linarith)]
    · rw [hreg (fun w => Real.log |r0 - w|)]
      apply Finset.sum_congr rfl
      intro j _
      rw [abs_sub_comm, abs_of_pos (by linarith [hvgt j])]
  have hsep : 0 ≤ k * Real.log bb + ∑ j, q j * Real.log (d j - bb) := by
    have e1 : ∀ j, q j * Real.log (d j - bb) = m j * Real.log (v j - r0) / bR := fun j => by
      simp only [hq, hd, hbb]
      rw [show v j - c0 - (r0 - c0) = v j - r0 by ring]
      ring
    have e2 : k * Real.log bb = aR * Real.log (r0 - c0) / bR := by
      simp only [hkdef, hbb]; ring
    rw [Finset.sum_congr rfl (fun j _ => e1 j), e2, ← Finset.sum_div, ← add_div, ← hsplit,
      hlog0, zero_div]
  have hP := prop81_full q d k bb hq0 hq1 hd1 hd2 hdist hk1 hkK hbb0 hbbd hsep
  -- match the terms
  convert hP using 2 with j
  congr 1
  -- exponent identity
  have hsplit2 : ∑ i ∈ univ.filter (fun i => s i ≠ v j), Real.log |v j - s i| =
      aR * Real.log (v j - c0) +
        ∑ j', (if j = j' then 0 else m j' * Real.log |v j - v j'|) := by
    have hfilt : univ.filter (fun i => s i ≠ v j) =
        A ∪ O.filter (fun i => s i ≠ v j) := by
      ext i
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_union, hA, hO]
      constructor
      · intro h
        by_cases hc : s i = c0
        · left; exact hc
        · right; exact ⟨hc, h⟩
      · rintro (h | ⟨_, h⟩)
        · rw [h]; exact (hvne j).symm
        · exact h
    have hdisj : Disjoint A (O.filter (fun i => s i ≠ v j)) := by
      rw [Finset.disjoint_left]
      intro i hiA hiO
      exact (Finset.mem_filter.mp (Finset.mem_filter.mp hiO).1).2 (Finset.mem_filter.mp hiA).2
    rw [hfilt, Finset.sum_union hdisj]
    congr 1
    · rw [Finset.sum_congr rfl (fun i hi => by rw [(Finset.mem_filter.mp hi).2]), sum_const,
        nsmul_eq_mul, abs_of_pos (by linarith [hvgt j])]
    · rw [Finset.sum_filter]
      have := hreg (fun w => if w = v j then 0 else Real.log |v j - w|)
      rw [show (∑ i ∈ O, if s i ≠ v j then Real.log |v j - s i| else 0) =
          ∑ i ∈ O, (if s i = v j then 0 else Real.log |v j - s i|) from
        Finset.sum_congr rfl (fun i _ => by by_cases h : s i = v j <;> simp [h])]
      rw [this]
      apply Finset.sum_congr rfl
      intro j' _
      by_cases h : j = j'
      · subst h; simp
      · have : v j' ≠ v j := fun h' => h (hvinj j j' h'.symm)
        simp [h, this]
  rw [hsplit2]
  have hdd : ∀ j', d j - d j' = v j - v j' := fun j' => by simp only [hd]; ring
  have hsumq : (∑ j', if j = j' then 0 else q j' * Real.log |d j - d j'|) =
      (∑ j', if j = j' then 0 else m j' * Real.log |v j - v j'|) / bR := by
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro j' _
    split_ifs
    · simp
    · rw [hdd j']; simp only [hq]; ring
  have hcard : ((univ.filter (fun i => s i = v j)).card : ℝ) = m j := rfl
  have hdj : d j = v j - c0 := rfl
  have hqj : q j = m j / bR := rfl
  rw [hsumq, hcard, hdj, hqj, hkdef]
  have hb := hbpos.ne'
  have hmj := (hmpos j).ne'
  field_simp


/-- The window left of the least root `c0`: if `u^a (2 + u)^b < 1` (`a` = multiplicity of `c0`,
`b` = number of other roots) then `(c0 - u, c0) ⊆ S`. -/
theorem window {n : ℕ} (s : Fin n → ℝ) (hs : ∀ i, s i ∈ Set.Icc (-1 : ℝ) 1) {c0 u : ℝ}
    (hc0l : -1 ≤ c0) (hcle : ∀ i, c0 ≤ s i) (hu : 0 < u)
    (hw : u ^ (univ.filter (fun i => s i = c0)).card *
      (2 + u) ^ (univ.filter (fun i => s i ≠ c0)).card < 1) :
    Set.Ioo (c0 - u) c0 ⊆ sublevel s := by
  classical
  set A := univ.filter (fun i => s i = c0) with hA
  set O := univ.filter (fun i => s i ≠ c0) with hO
  intro x ⟨hx1, hx2⟩
  set w := c0 - x with hwdef
  have hw0 : 0 < w := by linarith
  have hwu : w ≤ u := by linarith
  have hfac : ∀ i, |x - s i| = if s i = c0 then w else s i - x := by
    intro i
    split_ifs with h
    · rw [h, hwdef, abs_of_neg (by linarith)]; ring
    · rw [abs_sub_comm, abs_of_pos (by linarith [hcle i])]
  change |∏ i, (x - s i)| < 1
  rw [Finset.abs_prod]
  have hprod : ∏ i, |x - s i| = (∏ i ∈ A, |x - s i|) * ∏ i ∈ O, |x - s i| :=
    (Finset.prod_filter_mul_prod_filter_not univ (fun i => s i = c0) _).symm
  have hPA : ∏ i ∈ A, |x - s i| = w ^ A.card := by
    rw [Finset.prod_congr rfl (fun i hi => by rw [hfac i, if_pos (Finset.mem_filter.mp hi).2]),
      prod_const]
  have hPO : ∏ i ∈ O, |x - s i| ≤ (2 + u) ^ O.card := by
    rw [← prod_const]
    gcongr with i hi
    rw [hfac i, if_neg (Finset.mem_filter.mp hi).2]
    linarith [(hs i).2]
  rw [hprod, hPA]
  calc w ^ A.card * ∏ i ∈ O, |x - s i| ≤ u ^ A.card * (2 + u) ^ O.card :=
        mul_le_mul (pow_le_pow_left₀ hw0.le hwu _) hPO
          (Finset.prod_nonneg fun i _ => abs_nonneg _) (by positivity)
    _ < 1 := hw

/-- **The `61/40 = 1.525` bound for a clustered configuration** (Lemma 7.5 + Proposition 8.1):
if `s ∈ [-1,1]ⁿ`, `∑ s ≤ 0`, and every component of `S(s)` contains one root value (in the
segment form `hcl`, as in `sqrt2_clustered`), then `|S(s)| ≥ 61/40`. -/
theorem bound_clustered {n : ℕ} (hn : 0 < n) (s : Fin n → ℝ)
    (hs : ∀ i, s i ∈ Set.Icc (-1 : ℝ) 1) (hsum : ∑ i, s i ≤ 0)
    (hcl : ∀ i j, Set.uIcc (s i) (s j) ⊆ sublevel s → s i = s j) :
    ENNReal.ofReal (61 / 40) ≤ volume (sublevel s) := by
  classical
  obtain ⟨i0, r0, hc0l, -, hcle, hr0ge, hR1, hf1, hother, hbelow, hab⟩ := setup hn s hs hsum hcl
  set c0 := s i0 with hc0
  set A := univ.filter (fun i => s i = c0) with hA
  set O := univ.filter (fun i => s i ≠ c0) with hO
  have hApos : 0 < A.card := Finset.card_pos.mpr ⟨i0, Finset.mem_filter.mpr ⟨mem_univ _, rfl⟩⟩
  by_cases hcase : 29 * O.card ≤ 20 * A.card
  · -- a ≥ (29/20) b: the window `u = 21/40` already gives `61/40`
    have hw : (21 / 40 : ℝ) ^ A.card * (2 + 21 / 40) ^ O.card < 1 := by
      rcases Nat.eq_zero_or_pos O.card with h0 | hpos
      · rw [h0, pow_zero, mul_one]
        exact pow_lt_one₀ (by norm_num) (by norm_num) hApos.ne'
      · by_contra hge
        push Not at hge
        have h20 : 1 ≤ ((21 / 40 : ℝ) ^ A.card * (2 + 21 / 40) ^ O.card) ^ 20 := one_le_pow₀ hge
        have hle : ((21 / 40 : ℝ) ^ A.card * (2 + 21 / 40) ^ O.card) ^ 20 ≤
            ((21 / 40 : ℝ) ^ 29 * (101 / 40) ^ 20) ^ O.card := by
          have e : (2 + 21 / 40 : ℝ) = 101 / 40 := by norm_num
          rw [e, mul_pow, mul_pow, ← pow_mul, ← pow_mul, ← pow_mul, ← pow_mul,
            mul_comm O.card 20]
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          exact pow_le_pow_of_le_one (by norm_num) (by norm_num) (by omega)
        have hnum : (21 / 40 : ℝ) ^ 29 * (101 / 40) ^ 20 < 1 := by norm_num
        have := pow_lt_one₀ (by positivity) hnum hpos.ne'
        linarith
    have hwin := window s hs hc0l hcle (by norm_num) hw
    have hbig : Set.Ioo (c0 - 21 / 40) (c0 + 1) ⊆ sublevel s := by
      intro x hx
      rcases lt_or_ge x c0 with h | h
      · exact hwin ⟨hx.1, h⟩
      · exact hbelow x h (by linarith [hx.2])
    calc ENNReal.ofReal (61 / 40) = volume (Set.Ioo (c0 - 21 / 40) (c0 + 1)) := by
          rw [Real.volume_Ioo]; congr 1; ring
      _ ≤ volume (sublevel s) := measure_mono hbig
  · -- b ≤ a < (29/20) b: window `u = 2/5` plus the residual components (Prop. 8.1)
    push Not at hcase
    have hb1 : 1 ≤ O.card := by omega
    have hw : (2 / 5 : ℝ) ^ A.card * (2 + 2 / 5) ^ O.card < 1 := by
      have h1 : (2 / 5 : ℝ) ^ A.card ≤ (2 / 5) ^ O.card :=
        pow_le_pow_of_le_one (by norm_num) (by norm_num) hab
      calc (2 / 5 : ℝ) ^ A.card * (2 + 2 / 5) ^ O.card ≤ (2 / 5) ^ O.card * (2 + 2 / 5) ^ O.card :=
            mul_le_mul_of_nonneg_right h1 (by positivity)
        _ = (24 / 25) ^ O.card := by rw [← mul_pow]; norm_num
        _ < 1 := pow_lt_one₀ (by norm_num) (by norm_num) (by omega)
    have hwin := window s hs hc0l hcle (by norm_num) hw
    have hmain : Set.Ioo (c0 - 2 / 5) r0 ⊆ sublevel s := by
      intro x hx
      rcases lt_or_ge x c0 with h | h
      · exact hwin ⟨hx.1, h⟩
      · exact hbelow x h hx.2
    -- the residual values and their components
    set V := O.image s with hV
    set v : Fin V.card → ℝ := fun j => V.orderIsoOfFin rfl j with hv
    have hvO : ∀ j, ∃ i, s i = v j ∧ s i ≠ c0 := by
      intro j
      obtain ⟨i, hi, h⟩ := Finset.mem_image.mp (V.orderIsoOfFin rfl j).2
      exact ⟨i, h, (Finset.mem_filter.mp hi).2⟩
    choose ι hι hιne using hvO
    set W : Fin V.card → Set ℝ := fun j => Set.Ioo (ellL s (v j)) (rhoR s (v j)) with hW
    have hWsub : ∀ j, W j ⊆ sublevel s := by
      intro j
      have := (comp_props hs (ι j)).2.2.1
      rw [hι j] at this
      exact this
    have hWdisj : Pairwise (Function.onFun Disjoint W) := by
      intro j j' hjj'
      have hne : s (ι j) ≠ s (ι j') := by
        rw [hι j, hι j']
        intro h
        exact hjj' ((V.orderIsoOfFin rfl).injective (Subtype.ext h))
      have := comp_disjoint hs hcl (ι j) (ι j') hne
      rw [hι j, hι j'] at this
      exact this
    have hellge : ∀ j, r0 ≤ ellL s (v j) := by
      intro j
      unfold ellL
      refine le_csSup ⟨v j, fun y hy => hy.2⟩ ⟨hR1, ?_⟩
      show r0 ≤ v j
      rw [← hι j]
      exact (hother (ι j) (hιne j)).le
    have hwidth : ∀ j, 2 * Real.exp (-(∑ i ∈ univ.filter (fun i => s i ≠ v j),
        Real.log |v j - s i|) / ((univ.filter (fun i => s i = v j)).card : ℝ)) ≤
        rhoR s (v j) - ellL s (v j) := by
      intro j
      have := comp_width hs hcl (ι j)
      rw [hι j] at this
      exact this
    have hwpos : ∀ j, 0 ≤ rhoR s (v j) - ellL s (v j) := fun j =>
      le_trans (by positivity) (hwidth j)
    have hlink : 1 / 3 < ∑ j, Real.exp (-(∑ i ∈ univ.filter (fun i => s i ≠ v j),
        Real.log |v j - s i|) / ((univ.filter (fun i => s i = v j)).card : ℝ)) :=
      prop81_link s hc0l hs hr0ge hf1 hother hb1 hab hcase.le
    have hsumw : 2 / 3 < ∑ j, (rhoR s (v j) - ellL s (v j)) := by
      have h2 := Finset.sum_le_sum (fun j (_ : j ∈ (univ : Finset (Fin V.card))) => hwidth j)
      rw [← Finset.mul_sum] at h2
      linarith
    -- volume of the disjoint union
    have hdisj2 : Disjoint (Set.Ioo (c0 - 2 / 5) r0) (⋃ j, W j) := by
      rw [Set.disjoint_iUnion_right]
      intro j
      rw [Set.disjoint_left]
      intro x hx hxW
      have h1 := hellge j
      have h2 : ellL s (v j) < x := hxW.1
      linarith [hx.2]
    have hsubU : Set.Ioo (c0 - 2 / 5) r0 ∪ ⋃ j, W j ⊆ sublevel s :=
      Set.union_subset hmain (Set.iUnion_subset hWsub)
    have hvolU : volume (Set.Ioo (c0 - 2 / 5) r0 ∪ ⋃ j, W j) =
        ENNReal.ofReal (r0 - (c0 - 2 / 5)) + ∑ j, ENNReal.ofReal (rhoR s (v j) - ellL s (v j)) := by
      rw [measure_union hdisj2 (MeasurableSet.iUnion fun j => measurableSet_Ioo), Real.volume_Ioo,
        measure_iUnion hWdisj (fun j => measurableSet_Ioo), tsum_fintype]
      congr 1
      apply Finset.sum_congr rfl
      intro j _
      exact Real.volume_Ioo
    calc ENNReal.ofReal (61 / 40)
        ≤ ENNReal.ofReal (r0 - (c0 - 2 / 5) + ∑ j, (rhoR s (v j) - ellL s (v j))) :=
          ENNReal.ofReal_le_ofReal (by linarith)
      _ = volume (Set.Ioo (c0 - 2 / 5) r0 ∪ ⋃ j, W j) := by
          rw [hvolU, ENNReal.ofReal_add (by linarith) (Finset.sum_nonneg fun j _ => hwpos j),
            ENNReal.ofReal_sum_of_nonneg fun j _ => hwpos j]
      _ ≤ volume (sublevel s) := measure_mono hsubU

/-- **`|S| ≥ 61/40` for every root vector in `[-1, 1]ⁿ`, `n ≥ 1`** (atomization + reflection,
as in `Atom.sqrt2_le`). -/
theorem bound_le {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1) :
    ENNReal.ofReal (61 / 40) ≤ volume (sublevel r) := by
  have main : ∀ r' : Fin n → ℝ, (∀ i, r' i ∈ Set.Icc (-1 : ℝ) 1) → ∑ i, r' i ≤ 0 →
      ENNReal.ofReal (61 / 40) ≤ volume (sublevel r') := by
    intro r' hr' hs
    have h := bound_clustered hn (cmean r') (cmean_mem_Icc r' hr')
      (by rw [sum_cmean]; exact hs) (fun i j h => cmean_eq_of_uIcc r' h)
    exact h.trans (measure_mono (sublevel_cmean_subset r'))
  rcases le_total (∑ i, r i) 0 with h | h
  · exact main r hr h
  · rw [← volume_sublevel_neg]
    exact main _ (fun i => ⟨by linarith [(hr i).2], by linarith [(hr i).1]⟩)
      (by simp only [Finset.sum_neg_distrib]; linarith)

end EP1038.Resid

namespace EP1038

open Polynomial in
/-- **Every `p ∈ 𝒫` satisfies `61/40 ≤ |S_p| ≤ 2√2`** (monic, degree `≥ 1`, all roots real in
`[-1, 1]`). `61/40 = 1.525` improves the classical `2^{4/3} - 1 ≈ 1.5198`. -/
theorem volume_bounds_1525 (p : ℝ[X]) (hm : p.Monic) (hdeg : 1 ≤ p.natDegree)
    (hsplit : Multiset.card p.roots = p.natDegree)
    (hroots : ∀ r ∈ p.roots, r ∈ Set.Icc (-1 : ℝ) 1) :
    ENNReal.ofReal (61 / 40) ≤ volume {x : ℝ | |p.eval x| < 1} ∧
      volume {x : ℝ | |p.eval x| < 1} ≤ ENNReal.ofReal (2 * √2) := by
  refine ⟨?_, (sup_theorem p hm hdeg hsplit hroots).1⟩
  set l := p.roots.toList with hl
  set r : Fin l.length → ℝ := fun i => l[i.1] with hrdef
  have hlen : l.length = p.natDegree := by rw [hl, Multiset.length_toList, hsplit]
  have hn : 0 < l.length := by omega
  have hr : ∀ i, r i ∈ Set.Icc (-1 : ℝ) 1 := by
    intro i
    apply hroots
    rw [← Multiset.mem_toList]
    exact List.getElem_mem _
  have hset : {x : ℝ | |p.eval x| < 1} = sublevel r := by
    ext x
    simp only [Set.mem_ofPred_eq, sublevel]
    rw [eval_eq_prod p hm hsplit x]
  rw [hset]
  exact Resid.bound_le hn r hr

end EP1038
