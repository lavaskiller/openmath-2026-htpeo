import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk26
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_150 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1071 : ℝ) / 1327) ((21 : ℝ) / 26))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((45546579 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((45577413 : ℝ) / 100000000) ∧ 0 < certE k a ((141526063 : ℝ) / 100000000) ∧ certE k a ((141633709 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((45546579 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((4547723 : ℝ) / 10000000) ((45477231 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((45546579 : ℝ) / 100000000) ((45546579 : ℝ) / 100000000) ((45546579 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((54453421 : ℝ) / 100000000))
  have h3 : RB z3 ((20878959 : ℝ) / 25000000) ((83515839 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((54453421 : ℝ) / 100000000) ((54453421 : ℝ) / 100000000) ((54453421 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-1125837 : ℝ) / 6250000) ((-4503347 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_2512.1 cov_log_2513.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-14549279 : ℝ) / 100000000) ((-1453831 : ℝ) / 10000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((45546579 : ℝ) / 100000000))
  have h6 : RB z6 ((-19660867 : ℝ) / 25000000) ((-39321733 : ℝ) / 50000000) := rb_log (show RB ((45546579 : ℝ) / 100000000) ((45546579 : ℝ) / 100000000) ((45546579 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2514.1 cov_log_2514.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((64094187 : ℝ) / 100000000) ((32052579 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-547 : ℝ) / 2500000) ((-2181 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((45577413 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((1422127 : ℝ) / 3125000) ((9101613 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((45577413 : ℝ) / 100000000) ((45577413 : ℝ) / 100000000) ((45577413 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((54422587 : ℝ) / 100000000))
  have h12 : RB z12 ((8361981 : ℝ) / 10000000) ((83619813 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((54422587 : ℝ) / 100000000) ((54422587 : ℝ) / 100000000) ((54422587 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-8944487 : ℝ) / 50000000) ((-17888969 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2515.1 cov_log_2516.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-14448787 : ℝ) / 100000000) ((-7218947 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((45577413 : ℝ) / 100000000))
  have h15 : RB z15 ((-39287897 : ℝ) / 50000000) ((-4910987 : ℝ) / 6250000) := rb_log (show RB ((45577413 : ℝ) / 100000000) ((45577413 : ℝ) / 100000000) ((45577413 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2517.1 cov_log_2517.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((12825401 : ℝ) / 20000000) ((641379 : ℝ) / 1000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((5469 : ℝ) / 50000000) ((21837 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((141526063 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((70728357 : ℝ) / 50000000) ((28291343 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((141526063 : ℝ) / 100000000) ((141526063 : ℝ) / 100000000) ((141526063 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((41526063 : ℝ) / 100000000))
  have h21 : RB z21 ((170322809 : ℝ) / 50000000) ((340645621 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((41526063 : ℝ) / 100000000) ((41526063 : ℝ) / 100000000) ((41526063 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((490269 : ℝ) / 400000) ((61283627 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_2518.1 cov_log_2519.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((98922023 : ℝ) / 100000000) ((98996629 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((141526063 : ℝ) / 100000000))
  have h24 : RB z24 ((3473137 : ℝ) / 10000000) ((8682843 : ℝ) / 25000000) := rb_log (show RB ((141526063 : ℝ) / 100000000) ((141526063 : ℝ) / 100000000) ((141526063 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2520.1 cov_log_2520.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64190651 : ℝ) / 100000000) ((64265259 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((9323 : ℝ) / 12500000) ((37299 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((141633709 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((3539109 : ℝ) / 2500000) ((141564361 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((141633709 : ℝ) / 100000000) ((141633709 : ℝ) / 100000000) ((141633709 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((41633709 : ℝ) / 100000000))
  have h30 : RB z30 ((340023417 : ℝ) / 100000000) ((17001171 : ℝ) / 5000000) := rb_div_signed h29 (show RB ((41633709 : ℝ) / 100000000) ((41633709 : ℝ) / 100000000) ((41633709 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((12238443 : ℝ) / 10000000) ((61192217 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_2521.1 cov_log_2522.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((12346809 : ℝ) / 12500000) ((49424483 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((141633709 : ℝ) / 100000000))
  have h33 : RB z33 ((17403701 : ℝ) / 50000000) ((8701851 : ℝ) / 25000000) := rb_log (show RB ((141633709 : ℝ) / 100000000) ((141633709 : ℝ) / 100000000) ((141633709 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2523.1 cov_log_2523.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((15991767 : ℝ) / 25000000) ((16010391 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-148999 : ℝ) / 100000000) ((-74499 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((45546579 : ℝ) / 100000000)) ((-547 : ℝ) / 2500000) ((-2181 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((45577413 : ℝ) / 100000000)) ((5469 : ℝ) / 50000000) ((21837 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((141526063 : ℝ) / 100000000)) ((9323 : ℝ) / 12500000) ((37299 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((141633709 : ℝ) / 100000000)) ((-148999 : ℝ) / 100000000) ((-74499 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_150 {k A q d vp vm : ℝ}
    (hk : RB k ((1071 : ℝ) / 256) ((21 : ℝ) / 5))
    (hA : RB A ((1071 : ℝ) / 1327) ((21 : ℝ) / 26))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((45546579 : ℝ) / 100000000) ((45577413 : ℝ) / 100000000))
    (hm : RB vm ((141526063 : ℝ) / 100000000) ((141633709 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((40326197 : ℝ) / 50000000) ((80713219 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((76077 : ℝ) / 50000000) ((7613 : ℝ) / 5000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((4992387 : ℝ) / 5000000) ((49923923 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((54422587 : ℝ) / 100000000) ((54453421 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((54339723 : ℝ) / 100000000) ((6796321 : ℝ) / 12500000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((37084583 : ℝ) / 25000000) ((148534469 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((12084583 : ℝ) / 25000000) ((48534469 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((40326197 : ℝ) / 50000000) ((80713219 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((24481 : ℝ) / 50000000) ((49001 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99950999 : ℝ) / 100000000) ((49975519 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((41526063 : ℝ) / 100000000) ((41633709 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((20752857 : ℝ) / 50000000) ((1664533 : ℝ) / 4000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((96906933 : ℝ) / 50000000) ((19446291 : ℝ) / 10000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((146906933 : ℝ) / 50000000) ((29446291 : ℝ) / 10000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((103019567 : ℝ) / 50000000) ((206875157 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16980067 : ℝ) / 50000000) ((17017577 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1071 : ℝ) / 128) ((42 : ℝ) / 5) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((86071 : ℝ) / 390625) ((11060297 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4293763 : ℝ) / 20000000) ((21553017 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((24293763 : ℝ) / 20000000) ((121553017 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((1918973 : ℝ) / 2000000) ((9608713 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((182176097 : ℝ) / 100000000) ((182439031 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((1611507 : ℝ) / 2500000) ((64552981 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((26857 : ℝ) / 25000000) ((21517 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19978483 : ℝ) / 20000000) ((24973143 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((90990051 : ℝ) / 50000000) ((182243041 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1327 : ℝ) / 256) ((26 : ℝ) / 5) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((480769 : ℝ) / 25000000) ((482291 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1444467 : ℝ) / 25000000) ((5781783 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((26444467 : ℝ) / 25000000) ((105781783 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((217943803 : ℝ) / 100000000) ((21883623 : ℝ) / 10000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((371861 : ℝ) / 20000000) ((1860721 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20371861 : ℝ) / 20000000) ((101860721 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((8647889 : ℝ) / 25000000) ((17334227 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((252535359 : ℝ) / 100000000) ((63376171 : ℝ) / 25000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((2428223 : ℝ) / 50000000) ((2445261 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1327 : ℝ) / 256) ((26 : ℝ) / 5) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((24293763 : ℝ) / 10000000) ((121553017 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((59999817 : ℝ) / 25000000) ((240910311 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((583048533 : ℝ) / 100000000) ((585667503 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1770149 : ℝ) / 2000000) ((89186401 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-6104173 : ℝ) / 50000000) ((-11444161 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2524.1 cov_log_2525.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((6705889 : ℝ) / 2500000) ((134643741 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-1958607 : ℝ) / 6250000) ((-1211429 : ℝ) / 4000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((600003 : ℝ) / 50000000) ((731473 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((1226869 : ℝ) / 5000000) ((30123799 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-1700083 : ℝ) / 25000000) ((-80963 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((24293763 : ℝ) / 20000000) ((121553017 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-6104173 : ℝ) / 50000000) ((-11444161 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-1700083 : ℝ) / 25000000) ((-80963 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((259 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1444467 : ℝ) / 25000000) ((5781783 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((105781783 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((259 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((26315473 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((259 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_61, cov_h_25]
  have hP : ((104623 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((80963 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((80963 : ℝ) / 50000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((259 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_150 {k : ℝ} (hk : RB k ((1071 : ℝ) / 256) ((21 : ℝ) / 5)) :
    RB (k / (k + 1)) ((1071 : ℝ) / 1327) ((21 : ℝ) / 26) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1071 : ℝ) / 1327) ((21 : ℝ) / 26) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_150 {k : ℝ} (hk : RB k ((1071 : ℝ) / 256) ((21 : ℝ) / 5)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_150 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_150 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((45546579 : ℝ) / 100000000)) (ph := ((45577413 : ℝ) / 100000000)) (ml := ((141526063 : ℝ) / 100000000)) (mh := ((141633709 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_150 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_151 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((20388291 : ℝ) / 25000000) ((86063237 : ℝ) / 100000000))
    (hq : RB (qa a) ((1 : ℝ) / 100) ((13 : ℝ) / 500))
    (hd : RB (D0a a) ((94995991 : ℝ) / 50000000) ((19605921 : ℝ) / 10000000))
    : certE k a ((43184363 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((51274871 : ℝ) / 100000000) ∧ 0 < certE k a ((35036843 : ℝ) / 25000000) ∧ certE k a ((145147653 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1 : ℝ) / 10000) ((169 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((43184363 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((43116763 : ℝ) / 100000000) ((43174363 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43184363 : ℝ) / 100000000) ((43184363 : ℝ) / 100000000) ((43184363 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((56815637 : ℝ) / 100000000))
  have h3 : RB z3 ((75888901 : ℝ) / 100000000) ((75990283 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((56815637 : ℝ) / 100000000) ((56815637 : ℝ) / 100000000) ((56815637 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-1103599 : ℝ) / 4000000) ((-2745647 : ℝ) / 10000000) := rb_log h3 (by norm_num) cov_log_2526.1 cov_log_2527.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-11872413 : ℝ) / 50000000) ((-1119581 : ℝ) / 5000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((43184363 : ℝ) / 100000000))
  have h6 : RB z6 ((-41984587 : ℝ) / 50000000) ((-20992293 : ℝ) / 25000000) := rb_log (show RB ((43184363 : ℝ) / 100000000) ((43184363 : ℝ) / 100000000) ((43184363 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2528.1 cov_log_2528.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((30112173 : ℝ) / 50000000) ((30788777 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((4011323 : ℝ) / 6250000) ((67324653 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2529.1 cov_log_2530.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-7100307 : ℝ) / 100000000) ((-1301807 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1 : ℝ) / 10000) ((169 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((51274871 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((51207271 : ℝ) / 100000000) ((51264871 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((51274871 : ℝ) / 100000000) ((51274871 : ℝ) / 100000000) ((51274871 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((48725129 : ℝ) / 100000000))
  have h12 : RB z12 ((26273543 : ℝ) / 25000000) ((105212387 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((48725129 : ℝ) / 100000000) ((48725129 : ℝ) / 100000000) ((48725129 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((4968663 : ℝ) / 100000000) ((2540543 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_2531.1 cov_log_2532.2
  let z14 : ℝ := (k / (k + 1)) * (z13)
  have h14 : RB z14 ((4052101 : ℝ) / 100000000) ((1093237 : ℝ) / 25000000) := rb_widen (rb_mul hA h13 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((51274871 : ℝ) / 100000000))
  have h15 : RB z15 ((-66796941 : ℝ) / 100000000) ((-66796939 : ℝ) / 100000000) := rb_log (show RB ((51274871 : ℝ) / 100000000) ((51274871 : ℝ) / 100000000) ((51274871 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2533.1 cov_log_2533.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((885613 : ℝ) / 1250000) ((71169889 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((4011323 : ℝ) / 6250000) ((67324653 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2529.1 cov_log_2530.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((3524387 : ℝ) / 100000000) ((6988721 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1 : ℝ) / 10000) ((169 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((35036843 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((35019943 : ℝ) / 25000000) ((35034343 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((35036843 : ℝ) / 25000000) ((35036843 : ℝ) / 25000000) ((35036843 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((10036843 : ℝ) / 25000000))
  have h21 : RB z21 ((174456963 : ℝ) / 50000000) ((174528699 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((10036843 : ℝ) / 25000000) ((10036843 : ℝ) / 25000000) ((10036843 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((124965507 : ℝ) / 100000000) ((125006621 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2534.1 cov_log_2535.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((25478331 : ℝ) / 25000000) ((21516949 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((35036843 : ℝ) / 25000000))
  have h24 : RB z24 ((33752433 : ℝ) / 100000000) ((6750487 : ℝ) / 20000000) := rb_log (show RB ((35036843 : ℝ) / 25000000) ((35036843 : ℝ) / 25000000) ((35036843 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2536.1 cov_log_2536.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((68160889 : ℝ) / 100000000) ((9229039 : ℝ) / 12500000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((4011323 : ℝ) / 6250000) ((67324653 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2529.1 cov_log_2530.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((209059 : ℝ) / 25000000) ((1206393 : ℝ) / 12500000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1 : ℝ) / 10000) ((169 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((145147653 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((145080053 : ℝ) / 100000000) ((145137653 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((145147653 : ℝ) / 100000000) ((145147653 : ℝ) / 100000000) ((145147653 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((45147653 : ℝ) / 100000000))
  have h30 : RB z30 ((12853829 : ℝ) / 4000000) ((321473307 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((45147653 : ℝ) / 100000000) ((45147653 : ℝ) / 100000000) ((45147653 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((58367369 : ℝ) / 50000000) ((23354887 : ℝ) / 20000000) := rb_log h30 (by norm_num) cov_log_2537.1 cov_log_2538.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((11900109 : ℝ) / 12500000) ((100499859 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((145147653 : ℝ) / 100000000))
  have h33 : RB z33 ((37258133 : ℝ) / 100000000) ((7451627 : ℝ) / 20000000) := rb_log (show RB ((145147653 : ℝ) / 100000000) ((145147653 : ℝ) / 100000000) ((145147653 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2539.1 cov_log_2539.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((57942737 : ℝ) / 100000000) ((31620863 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((4011323 : ℝ) / 6250000) ((67324653 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2529.1 cov_log_2530.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-2345479 : ℝ) / 25000000) ((-469721 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((43184363 : ℝ) / 100000000)) ((-7100307 : ℝ) / 100000000) ((-1301807 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((51274871 : ℝ) / 100000000)) ((3524387 : ℝ) / 100000000) ((6988721 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((35036843 : ℝ) / 25000000)) ((209059 : ℝ) / 25000000) ((1206393 : ℝ) / 12500000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((145147653 : ℝ) / 100000000)) ((-2345479 : ℝ) / 25000000) ((-469721 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_151 {k A q d vp vm : ℝ}
    (hk : RB k ((442098409 : ℝ) / 100000000) ((123505343 : ℝ) / 20000000))
    (hA : RB A ((20388291 : ℝ) / 25000000) ((86063237 : ℝ) / 100000000))
    (hq : RB q ((1 : ℝ) / 100) ((13 : ℝ) / 500))
    (hd : RB d ((94995991 : ℝ) / 50000000) ((19605921 : ℝ) / 10000000))
    (hp : RB vp ((43184363 : ℝ) / 100000000) ((51274871 : ℝ) / 100000000))
    (hm : RB vm ((35036843 : ℝ) / 25000000) ((145147653 : ℝ) / 100000000))
    : FormulaPositiveZero k A q vp vm := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1 : ℝ) / 10000) ((169 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((249831 : ℝ) / 250000) ((9999 : ℝ) / 10000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((40749017 : ℝ) / 50000000) ((86054631 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((9751 : ℝ) / 50000000) ((156539 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99843461 : ℝ) / 100000000) ((49990249 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((48725129 : ℝ) / 100000000) ((56815637 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((9729771 : ℝ) / 20000000) ((56804557 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((143470943 : ℝ) / 100000000) ((7075573 : ℝ) / 4000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((43470943 : ℝ) / 100000000) ((3075573 : ℝ) / 4000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((249831 : ℝ) / 250000) ((9999 : ℝ) / 10000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((40749017 : ℝ) / 50000000) ((86054631 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((6889 : ℝ) / 100000000) ((9647 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19990353 : ℝ) / 20000000) ((99993111 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((10036843 : ℝ) / 25000000) ((45147653 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((20064003 : ℝ) / 50000000) ((45144543 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((180526877 : ℝ) / 100000000) ((42890061 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((280526877 : ℝ) / 100000000) ((62890061 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((26011413 : ℝ) / 20000000) ((230038719 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((31801527 : ℝ) / 100000000) ((35647209 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((442098409 : ℝ) / 50000000) ((123505343 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((552623 : ℝ) / 6250000) ((3211139 : ℝ) / 10000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((101 : ℝ) / 100) ((513 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4308951 : ℝ) / 50000000) ((1987091 : ℝ) / 6250000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((54308951 : ℝ) / 50000000) ((8237091 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((88872501 : ℝ) / 100000000) ((10196329 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((84425313 : ℝ) / 50000000) ((199908421 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((60521749 : ℝ) / 100000000) ((4651517 : ℝ) / 6250000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((3359 : ℝ) / 25000000) ((6981 : ℝ) / 6250000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((6243019 : ℝ) / 6250000) ((24996641 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((84331013 : ℝ) / 50000000) ((99940781 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((94995991 : ℝ) / 25000000) ((19605921 : ℝ) / 5000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((3799839 : ℝ) / 100000000) ((10195079 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((542098409 : ℝ) / 100000000) ((143505343 : ℝ) / 20000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((264787 : ℝ) / 50000000) ((188067 : ℝ) / 10000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1950273 : ℝ) / 100000000) ((3010349 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((101950273 : ℝ) / 100000000) ((53010349 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((33148383 : ℝ) / 25000000) ((15243041 : ℝ) / 6250000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((688953 : ℝ) / 100000000) ((185519 : ℝ) / 10000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((100688953 : ℝ) / 100000000) ((10185519 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((2001289 : ℝ) / 6250000) ((36308533 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((41153539 : ℝ) / 25000000) ((280197189 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((871753 : ℝ) / 100000000) ((1053917 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((542098409 : ℝ) / 100000000) ((143505343 : ℝ) / 20000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((54308951 : ℝ) / 25000000) ((8237091 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((5058081 : ℝ) / 3125000) ((33210741 : ℝ) / 12500000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((351614813 : ℝ) / 100000000) ((350156667 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((3870399 : ℝ) / 5000000) ((204066123 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-25608031 : ℝ) / 100000000) ((7132739 : ℝ) / 10000000) := rb_log h47 (by norm_num) cov_log_2540.1 cov_log_2541.2
  have hap : RB (formApi k q) ((54308951 : ℝ) / 50000000) ((8237091 : ℝ) / 6250000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-25608031 : ℝ) / 100000000) ((7132739 : ℝ) / 10000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((29 : ℝ) / 10) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1950273 : ℝ) / 100000000) ((3010349 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((53010349 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((29 : ℝ) / 10) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((6462659 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((29 : ℝ) / 10) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_28, cov_h_25]
  have hP : (0 : ℝ) ≤ -(π * 0 / formApi k q) := by simp
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := 0) (hi := ((29 : ℝ) / 10)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_tparams_151 {q : ℝ} (hq : RB q ((1 : ℝ) / 100) ((13 : ℝ) / 500)) :
    RB (terminalK q) ((442098409 : ℝ) / 100000000) ((123505343 : ℝ) / 20000000) ∧
    RB (terminalK q / (terminalK q + 1)) ((20388291 : ℝ) / 25000000) ((86063237 : ℝ) / 100000000) ∧
    RB (D0q q) ((94995991 : ℝ) / 50000000) ((19605921 : ℝ) / 10000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((101 : ℝ) / 100) ((513 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := (z1) ^ 2
  have h2 : RB z2 ((10201 : ℝ) / 10000) ((263169 : ℝ) / 250000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z3 : ℝ := ((2 : ℝ)) / (z2)
  have h3 : RB z3 ((94995991 : ℝ) / 50000000) ((19605921 : ℝ) / 10000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (q)
  have h4 : RB z4 ((-230258513 : ℝ) / 50000000) ((-364965873 : ℝ) / 100000000) := rb_log hq (by norm_num) cov_log_2542.1 cov_log_2543.2
  let z5 : ℝ := ((0 : ℝ)) - (z4)
  have h5 : RB z5 ((364965873 : ℝ) / 100000000) ((230258513 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z3)
  have h6 : RB z6 ((4011323 : ℝ) / 6250000) ((67324653 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2529.1 cov_log_2530.2
  let z7 : ℝ := (z5) / (z6)
  have h7 : RB z7 ((542098409 : ℝ) / 100000000) ((143505343 : ℝ) / 20000000) := rb_div_signed h5 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) - ((1 : ℝ))
  have h8 : RB z8 ((442098409 : ℝ) / 100000000) ((123505343 : ℝ) / 20000000) := rb_widen (rb_sub h7 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z9 : ℝ := (z6) / (z5)
  have h9 : RB z9 ((13936763 : ℝ) / 100000000) ((4611709 : ℝ) / 25000000) := rb_div_signed h6 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z9)
  have h10 : RB z10 ((20388291 : ℝ) / 25000000) ((86063237 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  have hd : RB (D0q q) ((94995991 : ℝ) / 50000000) ((19605921 : ℝ) / 10000000) := by
    have hh := h3
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q] using hh
  have hk : RB (terminalK q) ((442098409 : ℝ) / 100000000) ((123505343 : ℝ) / 20000000) := by
    have hh := h8
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, terminalK, D0q, zero_sub] using hh
  have he : terminalK q / (terminalK q + 1) = 1 - Real.log (D0q q) / (-Real.log q) := by
    rw [terminal_mass_ratio hqd]
    unfold Aq
    rw [log_H_eq hqd.1]
    change (Real.log (D0q q) + Real.log q) / Real.log q = _
    field_simp [(log_q_neg hqd.1 (terminal_admissible hqd).2.1).ne] <;> ring
  have hA : RB (terminalK q / (terminalK q + 1)) ((20388291 : ℝ) / 25000000) ((86063237 : ℝ) / 100000000) := by
    rw [he]
    have hh := h10
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q, zero_sub] using hh
  exact ⟨hk, hA, hd⟩
theorem cov_terminal_151 {q : ℝ} (hq : RB q ((1 : ℝ) / 100) ((13 : ℝ) / 500)) : RatioCertified (terminalK q) := by
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  obtain ⟨hk, hA, hd0⟩ := cov_tparams_151 hq
  have hq0 : RB (qa (terminalA q)) ((1 : ℝ) / 100) ((13 : ℝ) / 500) := by rwa [terminal_qa hqd]
  have hd : RB (D0a (terminalA q)) ((94995991 : ℝ) / 50000000) ((19605921 : ℝ) / 10000000) := by rwa [terminal_D0 hqd]
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_151 hA hq0 hd
  apply terminal_ratio_certified_of_box hqd (pl := ((43184363 : ℝ) / 100000000)) (ph := ((51274871 : ℝ) / 100000000)) (ml := ((35036843 : ℝ) / 25000000)) (mh := ((145147653 : ℝ) / 100000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · intro vp hp vm hm
    exact cov_numeric_151 hk hA hq hd0 ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_152 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2025483 : ℝ) / 2500000) ((16568021 : ℝ) / 20000000))
    (hq : RB (qa a) ((13 : ℝ) / 500) ((17 : ℝ) / 500))
    (hd : RB (D0a a) ((2338293 : ℝ) / 1250000) ((189991983 : ℝ) / 100000000))
    : certE k a ((8574349 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((23692963 : ℝ) / 50000000) ∧ 0 < certE k a ((141493749 : ℝ) / 100000000) ∧ certE k a ((28753663 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((169 : ℝ) / 250000) ((289 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8574349 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((8551229 : ℝ) / 20000000) ((8560829 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((8574349 : ℝ) / 20000000) ((8574349 : ℝ) / 20000000) ((8574349 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11425651 : ℝ) / 20000000))
  have h3 : RB z3 ((37421189 : ℝ) / 50000000) ((74926401 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((11425651 : ℝ) / 20000000) ((11425651 : ℝ) / 20000000) ((11425651 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-905581 : ℝ) / 3125000) ((-28866387 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2544.1 cov_log_2545.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-24005897 : ℝ) / 100000000) ((-467747 : ℝ) / 2000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8574349 : ℝ) / 20000000))
  have h6 : RB z6 ((-42347861 : ℝ) / 50000000) ((-2117393 : ℝ) / 2500000) := rb_log (show RB ((8574349 : ℝ) / 20000000) ((8574349 : ℝ) / 20000000) ((8574349 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2546.1 cov_log_2546.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((60689823 : ℝ) / 100000000) ((15327093 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((31313881 : ℝ) / 50000000) ((6418117 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_2547.1 cov_log_2548.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-3491347 : ℝ) / 100000000) ((-131939 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((169 : ℝ) / 250000) ((289 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((23692963 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((23635163 : ℝ) / 50000000) ((23659163 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((23692963 : ℝ) / 50000000) ((23692963 : ℝ) / 50000000) ((23692963 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((26307037 : ℝ) / 50000000))
  have h12 : RB z12 ((179687 : ℝ) / 200000) ((22483683 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((26307037 : ℝ) / 50000000) ((26307037 : ℝ) / 50000000) ((26307037 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-2677523 : ℝ) / 25000000) ((-10608597 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2549.1 cov_log_2550.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-2218063 : ℝ) / 25000000) ((-8595013 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((23692963 : ℝ) / 50000000))
  have h15 : RB z15 ((-37342247 : ℝ) / 50000000) ((-18671123 : ℝ) / 25000000) := rb_log (show RB ((23692963 : ℝ) / 50000000) ((23692963 : ℝ) / 50000000) ((23692963 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2551.1 cov_log_2551.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((822653 : ℝ) / 1250000) ((66089481 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((31313881 : ℝ) / 50000000) ((6418117 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_2547.1 cov_log_2548.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((163107 : ℝ) / 10000000) ((3461719 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((169 : ℝ) / 250000) ((289 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((141493749 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((141378149 : ℝ) / 100000000) ((141426149 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((141493749 : ℝ) / 100000000) ((141493749 : ℝ) / 100000000) ((141493749 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((41493749 : ℝ) / 100000000))
  have h21 : RB z21 ((8518039 : ℝ) / 2500000) ((340837241 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((41493749 : ℝ) / 100000000) ((41493749 : ℝ) / 100000000) ((41493749 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((122589541 : ℝ) / 100000000) ((12262349 : ℝ) / 10000000) := rb_log h21 (by norm_num) cov_log_2552.1 cov_log_2553.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((24830303 : ℝ) / 25000000) ((25395357 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((141493749 : ℝ) / 100000000))
  have h24 : RB z24 ((6941707 : ℝ) / 20000000) ((34708537 : ℝ) / 100000000) := rb_log (show RB ((141493749 : ℝ) / 100000000) ((141493749 : ℝ) / 100000000) ((141493749 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2554.1 cov_log_2554.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((2584507 : ℝ) / 4000000) ((66872893 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((31313881 : ℝ) / 50000000) ((6418117 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_2547.1 cov_log_2548.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((86301 : ℝ) / 20000000) ((4245131 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((169 : ℝ) / 250000) ((289 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((28753663 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((28730543 : ℝ) / 20000000) ((28740143 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((28753663 : ℝ) / 20000000) ((28753663 : ℝ) / 20000000) ((28753663 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8753663 : ℝ) / 20000000))
  have h30 : RB z30 ((20513229 : ℝ) / 6250000) ((328321333 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((8753663 : ℝ) / 20000000) ((8753663 : ℝ) / 20000000) ((8753663 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((118848853 : ℝ) / 100000000) ((14860283 : ℝ) / 12500000) := rb_log h30 (by norm_num) cov_log_2555.1 cov_log_2556.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((24072633 : ℝ) / 25000000) ((98482193 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((28753663 : ℝ) / 20000000))
  have h33 : RB z33 ((36303289 : ℝ) / 100000000) ((36303291 : ℝ) / 100000000) := rb_log (show RB ((28753663 : ℝ) / 20000000) ((28753663 : ℝ) / 20000000) ((28753663 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2557.1 cov_log_2557.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((59987241 : ℝ) / 100000000) ((7772363 : ℝ) / 12500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((31313881 : ℝ) / 50000000) ((6418117 : ℝ) / 10000000) := rb_log hd (by norm_num) cov_log_2547.1 cov_log_2548.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-4193929 : ℝ) / 100000000) ((-224429 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8574349 : ℝ) / 20000000)) ((-3491347 : ℝ) / 100000000) ((-131939 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((23692963 : ℝ) / 50000000)) ((163107 : ℝ) / 10000000) ((3461719 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((141493749 : ℝ) / 100000000)) ((86301 : ℝ) / 20000000) ((4245131 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((28753663 : ℝ) / 20000000)) ((-4193929 : ℝ) / 100000000) ((-224429 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_152 {k A q d vp vm : ℝ}
    (hk : RB k ((53356441 : ℝ) / 12500000) ((241377073 : ℝ) / 50000000))
    (hA : RB A ((2025483 : ℝ) / 2500000) ((16568021 : ℝ) / 20000000))
    (hq : RB q ((13 : ℝ) / 500) ((17 : ℝ) / 500))
    (hd : RB d ((2338293 : ℝ) / 1250000) ((189991983 : ℝ) / 100000000))
    (hp : RB vp ((8574349 : ℝ) / 20000000) ((23692963 : ℝ) / 50000000))
    (hm : RB vm ((141493749 : ℝ) / 100000000) ((28753663 : ℝ) / 20000000))
    : FormulaPositiveZero k A q vp vm := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((169 : ℝ) / 250000) ((289 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((249711 : ℝ) / 250000) ((249831 : ℝ) / 250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((80925661 : ℝ) / 100000000) ((41392053 : ℝ) / 50000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((71329 : ℝ) / 50000000) ((134821 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49865179 : ℝ) / 50000000) ((49928671 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((26307037 : ℝ) / 50000000) ((11425651 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((13118051 : ℝ) / 25000000) ((57046757 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((141858477 : ℝ) / 100000000) ((78883771 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((41858477 : ℝ) / 100000000) ((28883771 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((249711 : ℝ) / 250000) ((249831 : ℝ) / 250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((80925661 : ℝ) / 100000000) ((41392053 : ℝ) / 50000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((2351 : ℝ) / 5000000) ((817 : ℝ) / 1000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((999183 : ℝ) / 1000000) ((4997649 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((41493749 : ℝ) / 100000000) ((8753663 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((5182481 : ℝ) / 12500000) ((5468467 : ℝ) / 12500000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((11561407 : ℝ) / 6250000) ((199672961 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((17811407 : ℝ) / 6250000) ((299672961 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((17310759 : ℝ) / 10000000) ((59725059 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((3336971 : ℝ) / 10000000) ((35089873 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((53356441 : ℝ) / 6250000) ((241377073 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((22196279 : ℝ) / 100000000) ((16413641 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((513 : ℝ) / 500) ((517 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1073321 : ℝ) / 5000000) ((15997701 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((6073321 : ℝ) / 5000000) ((65997701 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((94107823 : ℝ) / 100000000) ((10089657 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((176041331 : ℝ) / 100000000) ((38339079 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((60660839 : ℝ) / 100000000) ((17031487 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((99227 : ℝ) / 100000000) ((23821 : ℝ) / 12500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((12476179 : ℝ) / 12500000) ((99900773 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((43926463 : ℝ) / 25000000) ((95752591 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((2338293 : ℝ) / 625000) ((189991983 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((4863649 : ℝ) / 50000000) ((2583891 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((65856441 : ℝ) / 12500000) ((291377073 : ℝ) / 50000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((834597 : ℝ) / 50000000) ((2452201 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5486861 : ℝ) / 100000000) ((991329 : ℝ) / 12500000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105486861 : ℝ) / 100000000) ((13491329 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((91302881 : ℝ) / 50000000) ((51569307 : ℝ) / 20000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((361693 : ℝ) / 20000000) ((1201467 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20361693 : ℝ) / 20000000) ((51201467 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33973189 : ℝ) / 100000000) ((1796653 : ℝ) / 5000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((216578951 : ℝ) / 100000000) ((58755919 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((1807561 : ℝ) / 50000000) ((7204067 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((65856441 : ℝ) / 12500000) ((291377073 : ℝ) / 50000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((6073321 : ℝ) / 2500000) ((65997701 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((2064773 : ℝ) / 1000000) ((273990109 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((31350073 : ℝ) / 6250000) ((180827173 : ℝ) / 25000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((36419549 : ℝ) / 50000000) ((58089393 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-7922933 : ℝ) / 25000000) ((1874501 : ℝ) / 12500000) := rb_log h47 (by norm_num) cov_log_2558.1 cov_log_2559.2
  have hap : RB (formApi k q) ((6073321 : ℝ) / 5000000) ((65997701 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-7922933 : ℝ) / 25000000) ((1874501 : ℝ) / 12500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((259 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5486861 : ℝ) / 100000000) ((991329 : ℝ) / 12500000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((17 : ℝ) / 10) := by
    have hu : (1 + q / vp) / 2 ≤ ((13491329 : ℝ) / 25000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((259 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((17 : ℝ) / 10) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((6527417 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((259 : ℝ) / 100) + hfun ((17 : ℝ) / 10) := by
    linarith [hc0.1, cov_h_61, cov_h_35]
  have hP : (0 : ℝ) ≤ -(π * 0 / formApi k q) := by simp
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := 0) (hi := ((259 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_tparams_152 {q : ℝ} (hq : RB q ((13 : ℝ) / 500) ((17 : ℝ) / 500)) :
    RB (terminalK q) ((53356441 : ℝ) / 12500000) ((241377073 : ℝ) / 50000000) ∧
    RB (terminalK q / (terminalK q + 1)) ((2025483 : ℝ) / 2500000) ((16568021 : ℝ) / 20000000) ∧
    RB (D0q q) ((2338293 : ℝ) / 1250000) ((189991983 : ℝ) / 100000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((513 : ℝ) / 500) ((517 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := (z1) ^ 2
  have h2 : RB z2 ((263169 : ℝ) / 250000) ((267289 : ℝ) / 250000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z3 : ℝ := ((2 : ℝ)) / (z2)
  have h3 : RB z3 ((2338293 : ℝ) / 1250000) ((189991983 : ℝ) / 100000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (q)
  have h4 : RB z4 ((-364965879 : ℝ) / 100000000) ((-13525579 : ℝ) / 4000000) := rb_log hq (by norm_num) cov_log_2543.1 cov_log_2560.2
  let z5 : ℝ := ((0 : ℝ)) - (z4)
  have h5 : RB z5 ((13525579 : ℝ) / 4000000) ((364965879 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z3)
  have h6 : RB z6 ((31313881 : ℝ) / 50000000) ((6418117 : ℝ) / 10000000) := rb_log h3 (by norm_num) cov_log_2547.1 cov_log_2548.2
  let z7 : ℝ := (z5) / (z6)
  have h7 : RB z7 ((65856441 : ℝ) / 12500000) ((291377073 : ℝ) / 50000000) := rb_div_signed h5 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) - ((1 : ℝ))
  have h8 : RB z8 ((53356441 : ℝ) / 12500000) ((241377073 : ℝ) / 50000000) := rb_widen (rb_sub h7 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z9 : ℝ := (z6) / (z5)
  have h9 : RB z9 ((3431979 : ℝ) / 20000000) ((474517 : ℝ) / 2500000) := rb_div_signed h6 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z9)
  have h10 : RB z10 ((2025483 : ℝ) / 2500000) ((16568021 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  have hd : RB (D0q q) ((2338293 : ℝ) / 1250000) ((189991983 : ℝ) / 100000000) := by
    have hh := h3
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q] using hh
  have hk : RB (terminalK q) ((53356441 : ℝ) / 12500000) ((241377073 : ℝ) / 50000000) := by
    have hh := h8
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, terminalK, D0q, zero_sub] using hh
  have he : terminalK q / (terminalK q + 1) = 1 - Real.log (D0q q) / (-Real.log q) := by
    rw [terminal_mass_ratio hqd]
    unfold Aq
    rw [log_H_eq hqd.1]
    change (Real.log (D0q q) + Real.log q) / Real.log q = _
    field_simp [(log_q_neg hqd.1 (terminal_admissible hqd).2.1).ne] <;> ring
  have hA : RB (terminalK q / (terminalK q + 1)) ((2025483 : ℝ) / 2500000) ((16568021 : ℝ) / 20000000) := by
    rw [he]
    have hh := h10
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q, zero_sub] using hh
  exact ⟨hk, hA, hd⟩
theorem cov_terminal_152 {q : ℝ} (hq : RB q ((13 : ℝ) / 500) ((17 : ℝ) / 500)) : RatioCertified (terminalK q) := by
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  obtain ⟨hk, hA, hd0⟩ := cov_tparams_152 hq
  have hq0 : RB (qa (terminalA q)) ((13 : ℝ) / 500) ((17 : ℝ) / 500) := by rwa [terminal_qa hqd]
  have hd : RB (D0a (terminalA q)) ((2338293 : ℝ) / 1250000) ((189991983 : ℝ) / 100000000) := by rwa [terminal_D0 hqd]
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_152 hA hq0 hd
  apply terminal_ratio_certified_of_box hqd (pl := ((8574349 : ℝ) / 20000000)) (ph := ((23692963 : ℝ) / 50000000)) (ml := ((141493749 : ℝ) / 100000000)) (mh := ((28753663 : ℝ) / 20000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · intro vp hp vm hm
    exact cov_numeric_152 hk hA hq hd0 ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_153 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((80848769 : ℝ) / 100000000) ((5106693 : ℝ) / 6250000))
    (hq : RB (qa a) ((17 : ℝ) / 500) ((19 : ℝ) / 500))
    (hd : RB (D0a a) ((11601531 : ℝ) / 6250000) ((187063441 : ℝ) / 100000000))
    : certE k a ((8558953 : ℝ) / 20000000) < 0 ∧ 0 < certE k a ((22583663 : ℝ) / 50000000) ∧ 0 < certE k a ((142194767 : ℝ) / 100000000) ∧ certE k a ((28679903 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((289 : ℝ) / 250000) ((361 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((8558953 : ℝ) / 20000000)) - (z1)
  have h2 : RB z2 ((8530073 : ℝ) / 20000000) ((8535833 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((8558953 : ℝ) / 20000000) ((8558953 : ℝ) / 20000000) ((8558953 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((11441047 : ℝ) / 20000000))
  have h3 : RB z3 ((74556751 : ℝ) / 100000000) ((74607097 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((11441047 : ℝ) / 20000000) ((11441047 : ℝ) / 20000000) ((11441047 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-91753 : ℝ) / 312500) ((-14646727 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_2561.1 cov_log_2562.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-11994993 : ℝ) / 50000000) ((-5920849 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((8558953 : ℝ) / 20000000))
  have h6 : RB z6 ((-42437721 : ℝ) / 50000000) ((-1060943 : ℝ) / 1250000) := rb_log (show RB ((8558953 : ℝ) / 20000000) ((8558953 : ℝ) / 20000000) ((8558953 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2563.1 cov_log_2563.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((30442727 : ℝ) / 50000000) ((30596023 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((1546389 : ℝ) / 2500000) ((15656941 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_2564.1 cov_log_2565.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-174231 : ℝ) / 10000000) ((-331757 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((289 : ℝ) / 250000) ((361 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22583663 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((22511463 : ℝ) / 50000000) ((22525863 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22583663 : ℝ) / 50000000) ((22583663 : ℝ) / 50000000) ((22583663 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27416337 : ℝ) / 50000000))
  have h12 : RB z12 ((41054833 : ℝ) / 50000000) ((82162191 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((27416337 : ℝ) / 50000000) ((27416337 : ℝ) / 50000000) ((27416337 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-3942289 : ℝ) / 20000000) ((-3929499 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_2566.1 cov_log_2567.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-1006603 : ℝ) / 6250000) ((-15884757 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22583663 : ℝ) / 50000000))
  have h15 : RB z15 ((-635837 : ℝ) / 800000) ((-79479623 : ℝ) / 100000000) := rb_log (show RB ((22583663 : ℝ) / 50000000) ((22583663 : ℝ) / 50000000) ((22583663 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2568.1 cov_log_2568.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((2534959 : ℝ) / 4000000) ((15898717 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((1546389 : ℝ) / 2500000) ((15656941 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_2564.1 cov_log_2565.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((746211 : ℝ) / 100000000) ((434827 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((289 : ℝ) / 250000) ((361 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((142194767 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((142050367 : ℝ) / 100000000) ((142079167 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((142194767 : ℝ) / 100000000) ((142194767 : ℝ) / 100000000) ((142194767 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((42194767 : ℝ) / 100000000))
  have h21 : RB z21 ((33665399 : ℝ) / 10000000) ((168361123 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((42194767 : ℝ) / 100000000) ((42194767 : ℝ) / 100000000) ((42194767 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((121388547 : ℝ) / 100000000) ((121408823 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2569.1 cov_log_2570.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((19628229 : ℝ) / 20000000) ((49599807 : ℝ) / 50000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((142194767 : ℝ) / 100000000))
  have h24 : RB z24 ((550043 : ℝ) / 1562500) ((17601377 : ℝ) / 50000000) := rb_log (show RB ((142194767 : ℝ) / 100000000) ((142194767 : ℝ) / 100000000) ((142194767 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2571.1 cov_log_2571.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((62938391 : ℝ) / 100000000) ((31998431 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((1546389 : ℝ) / 2500000) ((15656941 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_2564.1 cov_log_2565.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((310627 : ℝ) / 100000000) ((1070651 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((289 : ℝ) / 250000) ((361 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((28679903 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((28651023 : ℝ) / 20000000) ((28656783 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((28679903 : ℝ) / 20000000) ((28679903 : ℝ) / 20000000) ((28679903 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8679903 : ℝ) / 20000000))
  have h30 : RB z30 ((165042299 : ℝ) / 50000000) ((4126887 : ℝ) / 1250000) := rb_div_signed h29 (show RB ((8679903 : ℝ) / 20000000) ((8679903 : ℝ) / 20000000) ((8679903 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((119417879 : ℝ) / 100000000) ((3732437 : ℝ) / 3125000) := rb_log h30 (by norm_num) cov_log_2572.1 cov_log_2573.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((19309577 : ℝ) / 20000000) ((97589299 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((28679903 : ℝ) / 20000000))
  have h33 : RB z33 ((7209287 : ℝ) / 20000000) ((36046437 : ℝ) / 100000000) := rb_log (show RB ((28679903 : ℝ) / 20000000) ((28679903 : ℝ) / 20000000) ((28679903 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2574.1 cov_log_2574.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((7562681 : ℝ) / 12500000) ((3846429 : ℝ) / 6250000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((1546389 : ℝ) / 2500000) ((15656941 : ℝ) / 25000000) := rb_log hd (by norm_num) cov_log_2564.1 cov_log_2565.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-531579 : ℝ) / 25000000) ((-39087 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((8558953 : ℝ) / 20000000)) ((-174231 : ℝ) / 10000000) ((-331757 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22583663 : ℝ) / 50000000)) ((746211 : ℝ) / 100000000) ((434827 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((142194767 : ℝ) / 100000000)) ((310627 : ℝ) / 100000000) ((1070651 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((28679903 : ℝ) / 20000000)) ((-531579 : ℝ) / 25000000) ((-39087 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_153 {k A q d vp vm : ℝ}
    (hk : RB k ((211079823 : ℝ) / 50000000) ((446659801 : ℝ) / 100000000))
    (hA : RB A ((80848769 : ℝ) / 100000000) ((5106693 : ℝ) / 6250000))
    (hq : RB q ((17 : ℝ) / 500) ((19 : ℝ) / 500))
    (hd : RB d ((11601531 : ℝ) / 6250000) ((187063441 : ℝ) / 100000000))
    (hp : RB vp ((8558953 : ℝ) / 20000000) ((22583663 : ℝ) / 50000000))
    (hm : RB vm ((142194767 : ℝ) / 100000000) ((28679903 : ℝ) / 20000000))
    : FormulaPositiveZero k A q vp vm := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((289 : ℝ) / 250000) ((361 : ℝ) / 250000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((249639 : ℝ) / 250000) ((249711 : ℝ) / 250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((80732023 : ℝ) / 100000000) ((16322527 : ℝ) / 20000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((255937 : ℝ) / 100000000) ((13497 : ℝ) / 4000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((3986503 : ℝ) / 4000000) ((99744063 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27416337 : ℝ) / 50000000) ((11441047 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27323827 : ℝ) / 50000000) ((28529413 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((70744553 : ℝ) / 50000000) ((149343347 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((20744553 : ℝ) / 50000000) ((49343347 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((249639 : ℝ) / 250000) ((249711 : ℝ) / 250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((80732023 : ℝ) / 100000000) ((16322527 : ℝ) / 20000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((80613 : ℝ) / 100000000) ((101551 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99898449 : ℝ) / 100000000) ((99919387 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((42194767 : ℝ) / 100000000) ((8679903 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((42151917 : ℝ) / 100000000) ((4336453 : ℝ) / 10000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((186170639 : ℝ) / 100000000) ((193615477 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((286170639 : ℝ) / 100000000) ((293615477 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((101330783 : ℝ) / 50000000) ((241027127 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((681163 : ℝ) / 2000000) ((17472093 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((211079823 : ℝ) / 25000000) ((446659801 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((5741371 : ℝ) / 20000000) ((6789229 : ℝ) / 20000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((517 : ℝ) / 500) ((519 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((27655929 : ℝ) / 100000000) ((4103741 : ℝ) / 12500000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((127655929 : ℝ) / 100000000) ((16603741 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((97027441 : ℝ) / 100000000) ((402419 : ℝ) / 400000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((90053349 : ℝ) / 50000000) ((47048677 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((15212979 : ℝ) / 25000000) ((64769727 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((89239 : ℝ) / 50000000) ((118649 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49881351 : ℝ) / 50000000) ((49910761 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((44919827 : ℝ) / 25000000) ((93929411 : ℝ) / 50000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((11601531 : ℝ) / 3125000) ((187063441 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2524493 : ℝ) / 20000000) ((7108411 : ℝ) / 50000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((261079823 : ℝ) / 50000000) ((546659801 : ℝ) / 100000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((288627 : ℝ) / 12500000) ((2722697 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1505513 : ℝ) / 20000000) ((8879591 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((21505513 : ℝ) / 20000000) ((108879591 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((217917047 : ℝ) / 100000000) ((262429351 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1185499 : ℝ) / 50000000) ((2672391 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((51185499 : ℝ) / 50000000) ((102672391 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((8716417 : ℝ) / 25000000) ((2242377 : ℝ) / 6250000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((50556543 : ℝ) / 20000000) ((298307383 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5836793 : ℝ) / 100000000) ((8122007 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((261079823 : ℝ) / 50000000) ((546659801 : ℝ) / 100000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((127655929 : ℝ) / 50000000) ((16603741 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((59179929 : ℝ) / 25000000) ((275971313 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((120874701 : ℝ) / 20000000) ((733144993 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((71221879 : ℝ) / 100000000) ((90450657 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-33937013 : ℝ) / 100000000) ((-10036571 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2575.1 cov_log_2576.2
  have hap : RB (formApi k q) ((127655929 : ℝ) / 100000000) ((16603741 : ℝ) / 12500000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-33937013 : ℝ) / 100000000) ((-10036571 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((247 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1505513 : ℝ) / 20000000) ((8879591 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((43 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((108879591 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((247 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((43 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((6203773 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((247 : ℝ) / 100) + hfun ((43 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_65, cov_h_66]
  have hP : (0 : ℝ) ≤ -(π * 0 / formApi k q) := by simp
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := 0) (hi := ((247 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_tparams_153 {q : ℝ} (hq : RB q ((17 : ℝ) / 500) ((19 : ℝ) / 500)) :
    RB (terminalK q) ((211079823 : ℝ) / 50000000) ((446659801 : ℝ) / 100000000) ∧
    RB (terminalK q / (terminalK q + 1)) ((80848769 : ℝ) / 100000000) ((5106693 : ℝ) / 6250000) ∧
    RB (D0q q) ((11601531 : ℝ) / 6250000) ((187063441 : ℝ) / 100000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((517 : ℝ) / 500) ((519 : ℝ) / 500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := (z1) ^ 2
  have h2 : RB z2 ((267289 : ℝ) / 250000) ((269361 : ℝ) / 250000) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z3 : ℝ := ((2 : ℝ)) / (z2)
  have h3 : RB z3 ((11601531 : ℝ) / 6250000) ((187063441 : ℝ) / 100000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (q)
  have h4 : RB z4 ((-338139481 : ℝ) / 100000000) ((-327016911 : ℝ) / 100000000) := rb_log hq (by norm_num) cov_log_2560.1 cov_log_2577.2
  let z5 : ℝ := ((0 : ℝ)) - (z4)
  have h5 : RB z5 ((327016911 : ℝ) / 100000000) ((338139481 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z3)
  have h6 : RB z6 ((1546389 : ℝ) / 2500000) ((15656941 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_2564.1 cov_log_2565.2
  let z7 : ℝ := (z5) / (z6)
  have h7 : RB z7 ((261079823 : ℝ) / 50000000) ((546659801 : ℝ) / 100000000) := rb_div_signed h5 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) - ((1 : ℝ))
  have h8 : RB z8 ((211079823 : ℝ) / 50000000) ((446659801 : ℝ) / 100000000) := rb_widen (rb_sub h7 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z9 : ℝ := (z6) / (z5)
  have h9 : RB z9 ((1143307 : ℝ) / 6250000) ((19151231 : ℝ) / 100000000) := rb_div_signed h6 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z9)
  have h10 : RB z10 ((80848769 : ℝ) / 100000000) ((5106693 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  have hd : RB (D0q q) ((11601531 : ℝ) / 6250000) ((187063441 : ℝ) / 100000000) := by
    have hh := h3
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q] using hh
  have hk : RB (terminalK q) ((211079823 : ℝ) / 50000000) ((446659801 : ℝ) / 100000000) := by
    have hh := h8
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, terminalK, D0q, zero_sub] using hh
  have he : terminalK q / (terminalK q + 1) = 1 - Real.log (D0q q) / (-Real.log q) := by
    rw [terminal_mass_ratio hqd]
    unfold Aq
    rw [log_H_eq hqd.1]
    change (Real.log (D0q q) + Real.log q) / Real.log q = _
    field_simp [(log_q_neg hqd.1 (terminal_admissible hqd).2.1).ne] <;> ring
  have hA : RB (terminalK q / (terminalK q + 1)) ((80848769 : ℝ) / 100000000) ((5106693 : ℝ) / 6250000) := by
    rw [he]
    have hh := h10
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q, zero_sub] using hh
  exact ⟨hk, hA, hd⟩
theorem cov_terminal_153 {q : ℝ} (hq : RB q ((17 : ℝ) / 500) ((19 : ℝ) / 500)) : RatioCertified (terminalK q) := by
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  obtain ⟨hk, hA, hd0⟩ := cov_tparams_153 hq
  have hq0 : RB (qa (terminalA q)) ((17 : ℝ) / 500) ((19 : ℝ) / 500) := by rwa [terminal_qa hqd]
  have hd : RB (D0a (terminalA q)) ((11601531 : ℝ) / 6250000) ((187063441 : ℝ) / 100000000) := by rwa [terminal_D0 hqd]
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_153 hA hq0 hd
  apply terminal_ratio_certified_of_box hqd (pl := ((8558953 : ℝ) / 20000000)) (ph := ((22583663 : ℝ) / 50000000)) (ml := ((142194767 : ℝ) / 100000000)) (mh := ((28679903 : ℝ) / 20000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · intro vp hp vm hm
    exact cov_numeric_153 hk hA hq hd0 ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_154 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((631121 : ℝ) / 781250) ((10150329 : ℝ) / 12500000))
    (hq : RB (qa a) ((19 : ℝ) / 500) ((1 : ℝ) / 25))
    (hd : RB (D0a a) ((92455621 : ℝ) / 50000000) ((185624497 : ℝ) / 100000000))
    : certE k a ((668363 : ℝ) / 1562500) < 0 ∧ 0 < certE k a ((43990813 : ℝ) / 100000000) ∧ 0 < certE k a ((71326237 : ℝ) / 50000000) ∧ certE k a ((28631711 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((361 : ℝ) / 250000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((668363 : ℝ) / 1562500)) - (z1)
  have h2 : RB z2 ((665863 : ℝ) / 1562500) ((2664427 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((668363 : ℝ) / 1562500) ((668363 : ℝ) / 1562500) ((668363 : ℝ) / 1562500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((894137 : ℝ) / 1562500))
  have h3 : RB z3 ((74469907 : ℝ) / 100000000) ((74497169 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((894137 : ℝ) / 1562500) ((894137 : ℝ) / 1562500) ((894137 : ℝ) / 1562500) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-7369377 : ℝ) / 25000000) ((-14720453 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_2578.1 cov_log_2579.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-23936513 : ℝ) / 100000000) ((-2378339 : ℝ) / 10000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((668363 : ℝ) / 1562500))
  have h6 : RB z6 ((-10615137 : ℝ) / 12500000) ((-42460547 : ℝ) / 50000000) := rb_log (show RB ((668363 : ℝ) / 1562500) ((668363 : ℝ) / 1562500) ((668363 : ℝ) / 1562500) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2580.1 cov_log_2580.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((60984581 : ℝ) / 100000000) ((30568853 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((2458823 : ℝ) / 4000000) ((61855563 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2581.1 cov_log_2582.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-435491 : ℝ) / 50000000) ((-332869 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((361 : ℝ) / 250000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((43990813 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((43830813 : ℝ) / 100000000) ((43846413 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((43990813 : ℝ) / 100000000) ((43990813 : ℝ) / 100000000) ((43990813 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((56009187 : ℝ) / 100000000))
  have h12 : RB z12 ((7825647 : ℝ) / 10000000) ((19571081 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((56009187 : ℝ) / 100000000) ((56009187 : ℝ) / 100000000) ((56009187 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-6129467 : ℝ) / 25000000) ((-612057 : ℝ) / 2500000) := rb_log h12 (by norm_num) cov_log_2583.1 cov_log_2584.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-3981831 : ℝ) / 20000000) ((-19777639 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((43990813 : ℝ) / 100000000))
  have h15 : RB z15 ((-41059469 : ℝ) / 50000000) ((-10264867 : ℝ) / 12500000) := rb_log (show RB ((43990813 : ℝ) / 100000000) ((43990813 : ℝ) / 100000000) ((43990813 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2585.1 cov_log_2585.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((62209781 : ℝ) / 100000000) ((62341299 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((2458823 : ℝ) / 4000000) ((61855563 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2581.1 cov_log_2582.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((177109 : ℝ) / 50000000) ((217681 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((361 : ℝ) / 250000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((71326237 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((71246237 : ℝ) / 50000000) ((71254037 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((71326237 : ℝ) / 50000000) ((71326237 : ℝ) / 50000000) ((71326237 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((21326237 : ℝ) / 50000000))
  have h21 : RB z21 ((334077863 : ℝ) / 100000000) ((334114439 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((21326237 : ℝ) / 50000000) ((21326237 : ℝ) / 50000000) ((21326237 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((12062039 : ℝ) / 10000000) ((6031567 : ℝ) / 5000000) := rb_log h21 (by norm_num) cov_log_2586.1 cov_log_2587.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((48720679 : ℝ) / 50000000) ((6122239 : ℝ) / 6250000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((71326237 : ℝ) / 50000000))
  have h24 : RB z24 ((35524123 : ℝ) / 100000000) ((284193 : ℝ) / 800000) := rb_log (show RB ((71326237 : ℝ) / 50000000) ((71326237 : ℝ) / 50000000) ((71326237 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2588.1 cov_log_2588.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((61917233 : ℝ) / 100000000) ((62431701 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((2458823 : ℝ) / 4000000) ((61855563 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2581.1 cov_log_2582.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((6167 : ℝ) / 10000000) ((480563 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((361 : ℝ) / 250000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((28631711 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((28599711 : ℝ) / 20000000) ((28602831 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((28631711 : ℝ) / 20000000) ((28631711 : ℝ) / 20000000) ((28631711 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8631711 : ℝ) / 20000000))
  have h30 : RB z30 ((165666523 : ℝ) / 50000000) ((331369193 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((8631711 : ℝ) / 20000000) ((8631711 : ℝ) / 20000000) ((8631711 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((59897693 : ℝ) / 50000000) ((59903149 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_2589.1 cov_log_2590.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((96774891 : ℝ) / 100000000) ((24321467 : ℝ) / 25000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((28631711 : ℝ) / 20000000))
  have h33 : RB z33 ((1793913 : ℝ) / 5000000) ((17939131 : ℝ) / 50000000) := rb_log (show RB ((28631711 : ℝ) / 20000000) ((28631711 : ℝ) / 20000000) ((28631711 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2591.1 cov_log_2591.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((60896629 : ℝ) / 100000000) ((7675951 : ℝ) / 12500000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((2458823 : ℝ) / 4000000) ((61855563 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_2581.1 cov_log_2582.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-479467 : ℝ) / 50000000) ((-62967 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((668363 : ℝ) / 1562500)) ((-435491 : ℝ) / 50000000) ((-332869 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((43990813 : ℝ) / 100000000)) ((177109 : ℝ) / 50000000) ((217681 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((71326237 : ℝ) / 50000000)) ((6167 : ℝ) / 10000000) ((480563 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((28631711 : ℝ) / 20000000)) ((-479467 : ℝ) / 50000000) ((-62967 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_154 {k A q d vp vm : ℝ}
    (hk : RB k ((16815433 : ℝ) / 4000000) ((215994679 : ℝ) / 50000000))
    (hA : RB A ((631121 : ℝ) / 781250) ((10150329 : ℝ) / 12500000))
    (hq : RB q ((19 : ℝ) / 500) ((1 : ℝ) / 25))
    (hd : RB d ((92455621 : ℝ) / 50000000) ((185624497 : ℝ) / 100000000))
    (hp : RB vp ((668363 : ℝ) / 1562500) ((43990813 : ℝ) / 100000000))
    (hm : RB vm ((71326237 : ℝ) / 50000000) ((28631711 : ℝ) / 20000000))
    : FormulaPositiveZero k A q vp vm := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((361 : ℝ) / 250000) ((1 : ℝ) / 625) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((624 : ℝ) / 625) ((249639 : ℝ) / 250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((40327117 : ℝ) / 50000000) ((1266959 : ℝ) / 1562500) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((1313 : ℝ) / 400000) ((374049 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99625951 : ℝ) / 100000000) ((398687 : ℝ) / 400000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((56009187 : ℝ) / 100000000) ((894137 : ℝ) / 1562500) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((11159937 : ℝ) / 20000000) ((445601 : ℝ) / 781250) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((35351761 : ℝ) / 25000000) ((29063023 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((10351761 : ℝ) / 25000000) ((9063023 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((624 : ℝ) / 625) ((249639 : ℝ) / 250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((40327117 : ℝ) / 50000000) ((1266959 : ℝ) / 1562500) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((100867 : ℝ) / 100000000) ((112161 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99887839 : ℝ) / 100000000) ((99899133 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((21326237 : ℝ) / 50000000) ((8631711 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((21302317 : ℝ) / 50000000) ((43115023 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((46766897 : ℝ) / 25000000) ((47580139 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((71766897 : ℝ) / 25000000) ((72580139 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((220676919 : ℝ) / 100000000) ((241504803 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((8611171 : ℝ) / 25000000) ((17417501 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((16815433 : ℝ) / 2000000) ((215994679 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((15974661 : ℝ) / 50000000) ((34559149 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((519 : ℝ) / 500) ((26 : ℝ) / 25) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((30720501 : ℝ) / 100000000) ((16646989 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((130720501 : ℝ) / 100000000) ((66646989 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((98661661 : ℝ) / 100000000) ((100383323 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((91218251 : ℝ) / 50000000) ((186336039 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((30509963 : ℝ) / 50000000) ((62976613 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((229291 : ℝ) / 100000000) ((26221 : ℝ) / 10000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((9973779 : ℝ) / 10000000) ((99770709 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((36391627 : ℝ) / 20000000) ((46477197 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((92455621 : ℝ) / 25000000) ((185624497 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((7026627 : ℝ) / 50000000) ((371249 : ℝ) / 2500000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((20815433 : ℝ) / 4000000) ((265994679 : ℝ) / 50000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2641641 : ℝ) / 100000000) ((570729 : ℝ) / 20000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((8638167 : ℝ) / 100000000) ((4675603 : ℝ) / 50000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((108638167 : ℝ) / 100000000) ((54675603 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((239739359 : ℝ) / 100000000) ((52817683 : ℝ) / 20000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((2654399 : ℝ) / 100000000) ((1402009 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((102654399 : ℝ) / 100000000) ((51402009 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((35358983 : ℝ) / 100000000) ((17905891 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((137549171 : ℝ) / 50000000) ((299900197 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((726711 : ℝ) / 10000000) ((8558087 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((20815433 : ℝ) / 4000000) ((265994679 : ℝ) / 50000000) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((130720501 : ℝ) / 50000000) ((66646989 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((255121603 : ℝ) / 100000000) ((55267961 : ℝ) / 20000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((26679699 : ℝ) / 4000000) ((368344319 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((35319251 : ℝ) / 50000000) ((3190377 : ℝ) / 4000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-8689871 : ℝ) / 25000000) ((-11307763 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_2592.1 cov_log_2593.2
  have hap : RB (formApi k q) ((130720501 : ℝ) / 100000000) ((66646989 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-8689871 : ℝ) / 25000000) ((-11307763 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((241 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((8638167 : ℝ) / 100000000) ((4675603 : ℝ) / 50000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((43 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((54675603 : ℝ) / 100000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((241 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((43 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((1276569 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((241 : ℝ) / 100) + hfun ((43 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_69, cov_h_66]
  have hP : (0 : ℝ) ≤ -(π * 0 / formApi k q) := by simp
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := 0) (hi := ((241 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_tparams_154 {q : ℝ} (hq : RB q ((19 : ℝ) / 500) ((1 : ℝ) / 25)) :
    RB (terminalK q) ((16815433 : ℝ) / 4000000) ((215994679 : ℝ) / 50000000) ∧
    RB (terminalK q / (terminalK q + 1)) ((631121 : ℝ) / 781250) ((10150329 : ℝ) / 12500000) ∧
    RB (D0q q) ((92455621 : ℝ) / 50000000) ((185624497 : ℝ) / 100000000) := by
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((519 : ℝ) / 500) ((26 : ℝ) / 25) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z2 : ℝ := (z1) ^ 2
  have h2 : RB z2 ((269361 : ℝ) / 250000) ((676 : ℝ) / 625) := rb_widen (rb_sq h1 (by norm_num)) (by norm_num) (by norm_num)
  let z3 : ℝ := ((2 : ℝ)) / (z2)
  have h3 : RB z3 ((92455621 : ℝ) / 50000000) ((185624497 : ℝ) / 100000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (q)
  have h4 : RB z4 ((-327016917 : ℝ) / 100000000) ((-160943791 : ℝ) / 50000000) := rb_log hq (by norm_num) cov_log_2577.1 cov_log_2594.2
  let z5 : ℝ := ((0 : ℝ)) - (z4)
  have h5 : RB z5 ((160943791 : ℝ) / 50000000) ((327016917 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (z3)
  have h6 : RB z6 ((2458823 : ℝ) / 4000000) ((61855563 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2581.1 cov_log_2582.2
  let z7 : ℝ := (z5) / (z6)
  have h7 : RB z7 ((20815433 : ℝ) / 4000000) ((265994679 : ℝ) / 50000000) := rb_div_signed h5 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) - ((1 : ℝ))
  have h8 : RB z8 ((16815433 : ℝ) / 4000000) ((215994679 : ℝ) / 50000000) := rb_widen (rb_sub h7 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z9 : ℝ := (z6) / (z5)
  have h9 : RB z9 ((2349671 : ℝ) / 12500000) ((150129 : ℝ) / 781250) := rb_div_signed h6 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z9)
  have h10 : RB z10 ((631121 : ℝ) / 781250) ((10150329 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  have hd : RB (D0q q) ((92455621 : ℝ) / 50000000) ((185624497 : ℝ) / 100000000) := by
    have hh := h3
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q] using hh
  have hk : RB (terminalK q) ((16815433 : ℝ) / 4000000) ((215994679 : ℝ) / 50000000) := by
    have hh := h8
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, terminalK, D0q, zero_sub] using hh
  have he : terminalK q / (terminalK q + 1) = 1 - Real.log (D0q q) / (-Real.log q) := by
    rw [terminal_mass_ratio hqd]
    unfold Aq
    rw [log_H_eq hqd.1]
    change (Real.log (D0q q) + Real.log q) / Real.log q = _
    field_simp [(log_q_neg hqd.1 (terminal_admissible hqd).2.1).ne] <;> ring
  have hA : RB (terminalK q / (terminalK q + 1)) ((631121 : ℝ) / 781250) ((10150329 : ℝ) / 12500000) := by
    rw [he]
    have hh := h10
    simpa only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, D0q, zero_sub] using hh
  exact ⟨hk, hA, hd⟩
theorem cov_terminal_154 {q : ℝ} (hq : RB q ((19 : ℝ) / 500) ((1 : ℝ) / 25)) : RatioCertified (terminalK q) := by
  have hqd : q ∈ terminalDomain := ⟨by linarith [hq.1], by norm_num [terminalCut]; linarith [hq.2]⟩
  obtain ⟨hk, hA, hd0⟩ := cov_tparams_154 hq
  have hq0 : RB (qa (terminalA q)) ((19 : ℝ) / 500) ((1 : ℝ) / 25) := by rwa [terminal_qa hqd]
  have hd : RB (D0a (terminalA q)) ((92455621 : ℝ) / 50000000) ((185624497 : ℝ) / 100000000) := by rwa [terminal_D0 hqd]
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_154 hA hq0 hd
  apply terminal_ratio_certified_of_box hqd (pl := ((668363 : ℝ) / 1562500)) (ph := ((43990813 : ℝ) / 100000000)) (ml := ((71326237 : ℝ) / 50000000)) (mh := ((28631711 : ℝ) / 20000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · intro vp hp vm hm
    exact cov_numeric_154 hk hA hq hd0 ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
