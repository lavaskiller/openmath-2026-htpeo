import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk22
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_130 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1197 : ℝ) / 1517) ((483 : ℝ) / 611))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((45198787 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((22642093 : ℝ) / 50000000) ∧ 0 < certE k a ((4387829 : ℝ) / 3125000) ∧ certE k a ((140668261 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((45198787 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((22564719 : ℝ) / 50000000) ((45129439 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((45198787 : ℝ) / 100000000) ((45198787 : ℝ) / 100000000) ((45198787 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((54801213 : ℝ) / 100000000))
  have h3 : RB z3 ((41175583 : ℝ) / 50000000) ((82351169 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((54801213 : ℝ) / 100000000) ((54801213 : ℝ) / 100000000) ((54801213 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-9708879 : ℝ) / 50000000) ((-19417753 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2232.1 cov_log_2233.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-15349881 : ℝ) / 100000000) ((-383043 : ℝ) / 2500000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((45198787 : ℝ) / 100000000))
  have h6 : RB z6 ((-15881999 : ℝ) / 20000000) ((-79409993 : ℝ) / 100000000) := rb_log (show RB ((45198787 : ℝ) / 100000000) ((45198787 : ℝ) / 100000000) ((45198787 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2234.1 cov_log_2234.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((4003757 : ℝ) / 6250000) ((2563531 : ℝ) / 4000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-11191 : ℝ) / 20000000) ((-6947 : ℝ) / 25000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22642093 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((45214837 : ℝ) / 100000000) ((22607419 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22642093 : ℝ) / 50000000) ((22642093 : ℝ) / 50000000) ((22642093 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27357907 : ℝ) / 50000000))
  have h12 : RB z12 ((3305431 : ℝ) / 4000000) ((82635777 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((27357907 : ℝ) / 50000000) ((27357907 : ℝ) / 50000000) ((27357907 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-19072749 : ℝ) / 100000000) ((-9536373 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_2235.1 cov_log_2236.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15077149 : ℝ) / 100000000) ((-1504949 : ℝ) / 10000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22642093 : ℝ) / 50000000))
  have h15 : RB z15 ((-4951327 : ℝ) / 6250000) ((-7922123 : ℝ) / 10000000) := rb_log (show RB ((22642093 : ℝ) / 50000000) ((22642093 : ℝ) / 50000000) ((22642093 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2237.1 cov_log_2237.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64144081 : ℝ) / 100000000) ((32085871 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((14007 : ℝ) / 50000000) ((55679 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((4387829 : ℝ) / 3125000)) - (z19)
  have h20 : RB z20 ((140341179 : ℝ) / 100000000) ((7017059 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((4387829 : ℝ) / 3125000) ((4387829 : ℝ) / 3125000) ((4387829 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((1262829 : ℝ) / 3125000))
  have h21 : RB z21 ((173644327 : ℝ) / 50000000) ((173644329 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((1262829 : ℝ) / 3125000) ((1262829 : ℝ) / 3125000) ((1262829 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((12449861 : ℝ) / 10000000) ((62249307 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_2238.1 cov_log_2239.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((98236543 : ℝ) / 100000000) ((6151067 : ℝ) / 6250000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((4387829 : ℝ) / 3125000))
  have h24 : RB z24 ((8485007 : ℝ) / 25000000) ((3394003 : ℝ) / 10000000) := rb_log (show RB ((4387829 : ℝ) / 3125000) ((4387829 : ℝ) / 3125000) ((4387829 : ℝ) / 3125000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2240.1 cov_log_2240.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64296513 : ℝ) / 100000000) ((16119261 : ℝ) / 25000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((90223 : ℝ) / 50000000) ((360981 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((140668261 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((1098429 : ℝ) / 781250) ((140598913 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((140668261 : ℝ) / 100000000) ((140668261 : ℝ) / 100000000) ((140668261 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((40668261 : ℝ) / 100000000))
  have h30 : RB z30 ((13828859 : ℝ) / 4000000) ((172860739 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((40668261 : ℝ) / 100000000) ((40668261 : ℝ) / 100000000) ((40668261 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((124046327 : ℝ) / 100000000) ((124046331 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_2241.1 cov_log_2242.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((48939833 : ℝ) / 50000000) ((98059539 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((140668261 : ℝ) / 100000000))
  have h33 : RB z33 ((34123417 : ℝ) / 100000000) ((34123419 : ℝ) / 100000000) := rb_log (show RB ((140668261 : ℝ) / 100000000) ((140668261 : ℝ) / 100000000) ((140668261 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2243.1 cov_log_2243.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63756247 : ℝ) / 100000000) ((31968061 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-17991 : ℝ) / 5000000) ((-179941 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((45198787 : ℝ) / 100000000)) ((-11191 : ℝ) / 20000000) ((-6947 : ℝ) / 25000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22642093 : ℝ) / 50000000)) ((14007 : ℝ) / 50000000) ((55679 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((4387829 : ℝ) / 3125000)) ((90223 : ℝ) / 50000000) ((360981 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((140668261 : ℝ) / 100000000)) ((-17991 : ℝ) / 5000000) ((-179941 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_130 {k A q d vp vm : ℝ}
    (hk : RB k ((1197 : ℝ) / 320) ((483 : ℝ) / 128))
    (hA : RB A ((1197 : ℝ) / 1517) ((483 : ℝ) / 611))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((45198787 : ℝ) / 100000000) ((22642093 : ℝ) / 50000000))
    (hm : RB vm ((4387829 : ℝ) / 3125000) ((140668261 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((39425507 : ℝ) / 50000000) ((78995917 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((153139 : ℝ) / 100000000) ((19179 : ℝ) / 12500000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((12480821 : ℝ) / 12500000) ((99846861 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27357907 : ℝ) / 50000000) ((54801213 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((27315931 : ℝ) / 50000000) ((54717291 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((144106209 : ℝ) / 100000000) ((144596787 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((44106209 : ℝ) / 100000000) ((44596787 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((39425507 : ℝ) / 50000000) ((78995917 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((24649 : ℝ) / 50000000) ((49391 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99950609 : ℝ) / 100000000) ((49975351 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((1262829 : ℝ) / 3125000) ((40668261 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((5048821 : ℝ) / 12500000) ((40648213 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((193983961 : ℝ) / 100000000) ((19558011 : ℝ) / 10000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((293983961 : ℝ) / 100000000) ((29558011 : ℝ) / 10000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1121157 : ℝ) / 500000) ((226725449 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((1353271 : ℝ) / 4000000) ((17007731 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1197 : ℝ) / 160) ((483 : ℝ) / 64) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((9850573 : ℝ) / 50000000) ((19873971 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((19195647 : ℝ) / 100000000) ((9682019 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((119195647 : ℝ) / 100000000) ((59682019 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((47563171 : ℝ) / 50000000) ((47734737 : ℝ) / 50000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((36122959 : ℝ) / 20000000) ((90633149 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((12692771 : ℝ) / 20000000) ((63700477 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((21773 : ℝ) / 20000000) ((54637 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49945363 : ℝ) / 50000000) ((19978227 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((180417429 : ℝ) / 100000000) ((181068963 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1517 : ℝ) / 320) ((611 : ℝ) / 128) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((83797 : ℝ) / 4000000) ((2109427 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5815281 : ℝ) / 100000000) ((182071 : ℝ) / 3125000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105815281 : ℝ) / 100000000) ((3307071 : ℝ) / 3125000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((118635543 : ℝ) / 50000000) ((239935091 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((936033 : ℝ) / 50000000) ((117219 : ℝ) / 6250000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50936033 : ℝ) / 50000000) ((6367219 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((4308141 : ℝ) / 12500000) ((2165839 : ℝ) / 6250000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((135868107 : ℝ) / 50000000) ((54917703 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5692669 : ℝ) / 100000000) ((1158449 : ℝ) / 20000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1517 : ℝ) / 320) ((611 : ℝ) / 128) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((119195647 : ℝ) / 50000000) ((59682019 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((10322527 : ℝ) / 4000000) ((260740911 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((307600071 : ℝ) / 50000000) ((622461761 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((1189989 : ℝ) / 1562500) ((77591619 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-106384 : ℝ) / 390625) ((-6342769 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_2244.1 cov_log_2245.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((59958537 : ℝ) / 25000000) ((60484493 : ℝ) / 25000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-14934781 : ℝ) / 25000000) ((-11527047 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((593521 : ℝ) / 25000000) ((3025619 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((8197457 : ℝ) / 20000000) ((53149393 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-18751839 : ℝ) / 100000000) ((-2242921 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((119195647 : ℝ) / 100000000) ((59682019 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-106384 : ℝ) / 390625) ((-6342769 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-18751839 : ℝ) / 100000000) ((-2242921 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((66 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5815281 : ℝ) / 100000000) ((182071 : ℝ) / 3125000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((3307071 : ℝ) / 6250000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((66 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((5170929 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((66 : ℝ) / 25) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_56, cov_h_25]
  have hP : ((11806129 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((2242921 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((2242921 : ℝ) / 50000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((66 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_130 {k : ℝ} (hk : RB k ((1197 : ℝ) / 320) ((483 : ℝ) / 128)) :
    RB (k / (k + 1)) ((1197 : ℝ) / 1517) ((483 : ℝ) / 611) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1197 : ℝ) / 1517) ((483 : ℝ) / 611) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_130 {k : ℝ} (hk : RB k ((1197 : ℝ) / 320) ((483 : ℝ) / 128)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_130 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_130 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((45198787 : ℝ) / 100000000)) (ph := ((22642093 : ℝ) / 50000000)) (ml := ((4387829 : ℝ) / 3125000)) (mh := ((140668261 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_130 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_131 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((483 : ℝ) / 611) ((609 : ℝ) / 769))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((11307 : ℝ) / 25000) < 0 ∧ 0 < certE k a ((11327789 : ℝ) / 25000000) ∧ 0 < certE k a ((70248823 : ℝ) / 50000000) ∧ certE k a ((28150351 : ℝ) / 20000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((11307 : ℝ) / 25000)) - (z1)
  have h2 : RB z2 ((45158651 : ℝ) / 100000000) ((11289663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((11307 : ℝ) / 25000) ((11307 : ℝ) / 25000) ((11307 : ℝ) / 25000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((13693 : ℝ) / 25000))
  have h3 : RB z3 ((10306053 : ℝ) / 12500000) ((82448427 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((13693 : ℝ) / 25000) ((13693 : ℝ) / 25000) ((13693 : ℝ) / 25000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-9649863 : ℝ) / 50000000) ((-19299721 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_2246.1 cov_log_2247.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-15284179 : ℝ) / 100000000) ((-15256571 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((11307 : ℝ) / 25000))
  have h6 : RB z6 ((-9918173 : ℝ) / 12500000) ((-39672691 : ℝ) / 50000000) := rb_log (show RB ((11307 : ℝ) / 25000) ((11307 : ℝ) / 25000) ((11307 : ℝ) / 25000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2248.1 cov_log_2248.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((64061203 : ℝ) / 100000000) ((64088813 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-3429 : ℝ) / 6250000) ((-109 : ℝ) / 400000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((11327789 : ℝ) / 25000000)) - (z10)
  have h11 : RB z11 ((45241807 : ℝ) / 100000000) ((2827613 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((11327789 : ℝ) / 25000000) ((11327789 : ℝ) / 25000000) ((11327789 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((13672211 : ℝ) / 25000000))
  have h12 : RB z12 ((41362921 : ℝ) / 50000000) ((16545169 : ℝ) / 20000000) := rb_div_signed h11 (show RB ((13672211 : ℝ) / 25000000) ((13672211 : ℝ) / 25000000) ((13672211 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-2370477 : ℝ) / 12500000) ((-18963811 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2249.1 cov_log_2250.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-15018159 : ℝ) / 100000000) ((-1873879 : ℝ) / 12500000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((11327789 : ℝ) / 25000000))
  have h15 : RB z15 ((-79161693 : ℝ) / 100000000) ((-79161691 : ℝ) / 100000000) := rb_log (show RB ((11327789 : ℝ) / 25000000) ((11327789 : ℝ) / 25000000) ((11327789 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2251.1 cov_log_2251.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((16035883 : ℝ) / 25000000) ((64170661 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((5493 : ℝ) / 20000000) ((27299 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((70248823 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((140428297 : ℝ) / 100000000) ((70214149 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((70248823 : ℝ) / 50000000) ((70248823 : ℝ) / 50000000) ((70248823 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((20248823 : ℝ) / 50000000))
  have h21 : RB z21 ((34675669 : ℝ) / 10000000) ((346756693 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((20248823 : ℝ) / 50000000) ((20248823 : ℝ) / 50000000) ((20248823 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((31086329 : ℝ) / 25000000) ((3108633 : ℝ) / 2500000) := rb_log h21 (by norm_num) cov_log_2252.1 cov_log_2253.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((6143493 : ℝ) / 6250000) ((24618433 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((70248823 : ℝ) / 50000000))
  have h24 : RB z24 ((17001027 : ℝ) / 50000000) ((4250257 : ℝ) / 12500000) := rb_log (show RB ((70248823 : ℝ) / 50000000) ((70248823 : ℝ) / 50000000) ((70248823 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2254.1 cov_log_2254.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((8036729 : ℝ) / 12500000) ((32235839 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((35553 : ℝ) / 20000000) ((71123 : ℝ) / 20000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((28150351 : ℝ) / 20000000)) - (z28)
  have h29 : RB z29 ((70341203 : ℝ) / 50000000) ((140682407 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((28150351 : ℝ) / 20000000) ((28150351 : ℝ) / 20000000) ((28150351 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8150351 : ℝ) / 20000000))
  have h30 : RB z30 ((34521803 : ℝ) / 10000000) ((345218033 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((8150351 : ℝ) / 20000000) ((8150351 : ℝ) / 20000000) ((8150351 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((619503 : ℝ) / 500000) ((30975151 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_2255.1 cov_log_2256.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((6121521 : ℝ) / 6250000) ((19624309 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((28150351 : ℝ) / 20000000))
  have h33 : RB z33 ((17091377 : ℝ) / 50000000) ((8545689 : ℝ) / 25000000) := rb_log (show RB ((28150351 : ℝ) / 20000000) ((28150351 : ℝ) / 20000000) ((28150351 : ℝ) / 20000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2257.1 cov_log_2257.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((3188079 : ℝ) / 5000000) ((63938791 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-354487 : ℝ) / 100000000) ((-22159 : ℝ) / 12500000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((11307 : ℝ) / 25000)) ((-3429 : ℝ) / 6250000) ((-109 : ℝ) / 400000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((11327789 : ℝ) / 25000000)) ((5493 : ℝ) / 20000000) ((27299 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((70248823 : ℝ) / 50000000)) ((35553 : ℝ) / 20000000) ((71123 : ℝ) / 20000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((28150351 : ℝ) / 20000000)) ((-354487 : ℝ) / 100000000) ((-22159 : ℝ) / 12500000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_131 {k A q d vp vm : ℝ}
    (hk : RB k ((483 : ℝ) / 128) ((609 : ℝ) / 160))
    (hA : RB A ((483 : ℝ) / 611) ((609 : ℝ) / 769))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((11307 : ℝ) / 25000) ((11327789 : ℝ) / 25000000))
    (hm : RB vm ((70248823 : ℝ) / 50000000) ((28150351 : ℝ) / 20000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((15799183 : ℝ) / 20000000) ((79138839 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((19131 : ℝ) / 12500000) ((153333 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99846667 : ℝ) / 100000000) ((12480869 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((13672211 : ℝ) / 25000000) ((13693 : ℝ) / 25000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((54604987 : ℝ) / 100000000) ((54688173 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((28889579 : ℝ) / 20000000) ((36232423 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((8889579 : ℝ) / 20000000) ((11232423 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((15799183 : ℝ) / 20000000) ((79138839 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((49269 : ℝ) / 100000000) ((617 : ℝ) / 1250000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((1249383 : ℝ) / 1250000) ((99950731 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((20248823 : ℝ) / 50000000) ((8150351 : ℝ) / 20000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((5059707 : ℝ) / 12500000) ((20365839 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((96971103 : ℝ) / 50000000) ((97756203 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((146971103 : ℝ) / 50000000) ((147756203 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((44513993 : ℝ) / 20000000) ((224982533 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16919763 : ℝ) / 50000000) ((17010147 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((483 : ℝ) / 64) ((609 : ℝ) / 80) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((19873963 : ℝ) / 100000000) ((5011697 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((19364029 : ℝ) / 100000000) ((19532421 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((119364029 : ℝ) / 100000000) ((119532421 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((9518649 : ℝ) / 10000000) ((19104751 : ℝ) / 20000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((180728997 : ℝ) / 100000000) ((181369361 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((2541771 : ℝ) / 4000000) ((7972031 : ℝ) / 12500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((1699 : ℝ) / 1562500) ((21827 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19978173 : ℝ) / 20000000) ((1560801 : ℝ) / 1562500) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((90265879 : ℝ) / 50000000) ((45293037 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((611 : ℝ) / 128) ((769 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2080623 : ℝ) / 100000000) ((2094927 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((290591 : ℝ) / 5000000) ((5822509 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((5290591 : ℝ) / 5000000) ((105822509 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((23550533 : ℝ) / 10000000) ((119041081 : ℝ) / 50000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((374191 : ℝ) / 20000000) ((1874341 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20374191 : ℝ) / 20000000) ((101874341 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((4309081 : ℝ) / 12500000) ((34657951 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((134988989 : ℝ) / 50000000) ((272740113 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((5617223 : ℝ) / 100000000) ((5713707 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((611 : ℝ) / 128) ((769 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((119364029 : ℝ) / 50000000) ((119532421 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((256409491 : ℝ) / 100000000) ((259002827 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((306060699 : ℝ) / 50000000) ((6191847 : ℝ) / 1000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((77092303 : ℝ) / 100000000) ((39258961 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-1040667 : ℝ) / 4000000) ((-3023041 : ℝ) / 12500000) := rb_log h47 (by norm_num) cov_log_2258.1 cov_log_2259.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((60484489 : ℝ) / 25000000) ((244041781 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-14408829 : ℝ) / 25000000) ((-27765713 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2270899 : ℝ) / 100000000) ((291129 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((39744757 : ℝ) / 100000000) ((51827923 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-17890559 : ℝ) / 100000000) ((-3703503 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((119364029 : ℝ) / 100000000) ((119532421 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-1040667 : ℝ) / 4000000) ((-3023041 : ℝ) / 12500000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-17890559 : ℝ) / 100000000) ((-3703503 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((66 : ℝ) / 25) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((290591 : ℝ) / 5000000) ((5822509 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((105822509 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((66 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((11559487 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((66 : ℝ) / 25) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_56, cov_h_25]
  have hP : ((2433347 : ℝ) / 25000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((3703503 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((3703503 : ℝ) / 100000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((66 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_131 {k : ℝ} (hk : RB k ((483 : ℝ) / 128) ((609 : ℝ) / 160)) :
    RB (k / (k + 1)) ((483 : ℝ) / 611) ((609 : ℝ) / 769) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((483 : ℝ) / 611) ((609 : ℝ) / 769) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_131 {k : ℝ} (hk : RB k ((483 : ℝ) / 128) ((609 : ℝ) / 160)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_131 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_131 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((11307 : ℝ) / 25000)) (ph := ((11327789 : ℝ) / 25000000)) (ml := ((70248823 : ℝ) / 50000000)) (mh := ((28150351 : ℝ) / 20000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_131 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_132 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((609 : ℝ) / 769) ((2457 : ℝ) / 3097))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((45256437 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((22668719 : ℝ) / 50000000) ∧ 0 < certE k a ((35145883 : ℝ) / 25000000) ∧ certE k a ((140834093 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((45256437 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((2824193 : ℝ) / 6250000) ((45187089 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((45256437 : ℝ) / 100000000) ((45256437 : ℝ) / 100000000) ((45256437 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((54743563 : ℝ) / 100000000))
  have h3 : RB z3 ((41271599 : ℝ) / 50000000) ((82543201 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((54743563 : ℝ) / 100000000) ((54743563 : ℝ) / 100000000) ((54743563 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-9592421 : ℝ) / 50000000) ((-9592419 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_2260.1 cov_log_2261.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1902533 : ℝ) / 12500000) ((-7596597 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((45256437 : ℝ) / 100000000))
  have h6 : RB z6 ((-79282529 : ℝ) / 100000000) ((-79282527 : ℝ) / 100000000) := rb_log (show RB ((45256437 : ℝ) / 100000000) ((45256437 : ℝ) / 100000000) ((45256437 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2262.1 cov_log_2262.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((64062263 : ℝ) / 100000000) ((12817867 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-13451 : ℝ) / 25000000) ((-3341 : ℝ) / 12500000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22668719 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((45268089 : ℝ) / 100000000) ((4526809 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((22668719 : ℝ) / 50000000) ((22668719 : ℝ) / 50000000) ((22668719 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27331281 : ℝ) / 50000000))
  have h12 : RB z12 ((82813697 : ℝ) / 100000000) ((828137 : ℝ) / 1000000) := rb_div_signed h11 (show RB ((27331281 : ℝ) / 50000000) ((27331281 : ℝ) / 50000000) ((27331281 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-2357209 : ℝ) / 12500000) ((-18857667 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2263.1 cov_log_2264.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-233761 : ℝ) / 1562500) ((-2986819 : ℝ) / 20000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22668719 : ℝ) / 50000000))
  have h15 : RB z15 ((-39551853 : ℝ) / 50000000) ((-9887963 : ℝ) / 12500000) := rb_log (show RB ((22668719 : ℝ) / 50000000) ((22668719 : ℝ) / 50000000) ((22668719 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2265.1 cov_log_2265.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64143 : ℝ) / 100000) ((64169611 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((26933 : ℝ) / 100000000) ((13387 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((35145883 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((140514183 : ℝ) / 100000000) ((17564273 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((35145883 : ℝ) / 25000000) ((35145883 : ℝ) / 25000000) ((35145883 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((10145883 : ℝ) / 25000000))
  have h21 : RB z21 ((86558621 : ℝ) / 25000000) ((43279311 : ℝ) / 12500000) := rb_div_signed h20 (show RB ((10145883 : ℝ) / 25000000) ((10145883 : ℝ) / 25000000) ((10145883 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((24838921 : ℝ) / 20000000) ((124194609 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2266.1 cov_log_2267.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((157367 : ℝ) / 160000) ((19705919 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((35145883 : ℝ) / 25000000))
  have h24 : RB z24 ((6812633 : ℝ) / 20000000) ((34063167 : ℝ) / 100000000) := rb_log (show RB ((35145883 : ℝ) / 25000000) ((35145883 : ℝ) / 25000000) ((35145883 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2268.1 cov_log_2268.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((8036401 : ℝ) / 12500000) ((6446643 : ℝ) / 10000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((175141 : ℝ) / 100000000) ((350367 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((140834093 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((17595593 : ℝ) / 12500000) ((28152949 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((140834093 : ℝ) / 100000000) ((140834093 : ℝ) / 100000000) ((140834093 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((40834093 : ℝ) / 100000000))
  have h30 : RB z30 ((86180893 : ℝ) / 25000000) ((13788943 : ℝ) / 4000000) := rb_div_signed h29 (show RB ((40834093 : ℝ) / 100000000) ((40834093 : ℝ) / 100000000) ((40834093 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((61878633 : ℝ) / 50000000) ((12375727 : ℝ) / 10000000) := rb_log h30 (by norm_num) cov_log_2269.1 cov_log_2270.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((98008029 : ℝ) / 100000000) ((98182633 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((140834093 : ℝ) / 100000000))
  have h33 : RB z33 ((8560309 : ℝ) / 25000000) ((17120619 : ℝ) / 50000000) := rb_log (show RB ((140834093 : ℝ) / 100000000) ((140834093 : ℝ) / 100000000) ((140834093 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2271.1 cov_log_2271.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63766791 : ℝ) / 100000000) ((63941397 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-87319 : ℝ) / 25000000) ((-87333 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((45256437 : ℝ) / 100000000)) ((-13451 : ℝ) / 25000000) ((-3341 : ℝ) / 12500000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22668719 : ℝ) / 50000000)) ((26933 : ℝ) / 100000000) ((13387 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((35145883 : ℝ) / 25000000)) ((175141 : ℝ) / 100000000) ((350367 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((140834093 : ℝ) / 100000000)) ((-87319 : ℝ) / 25000000) ((-87333 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_132 {k A q d vp vm : ℝ}
    (hk : RB k ((609 : ℝ) / 160) ((2457 : ℝ) / 640))
    (hA : RB A ((609 : ℝ) / 769) ((2457 : ℝ) / 3097))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((45256437 : ℝ) / 100000000) ((22668719 : ℝ) / 50000000))
    (hm : RB vm ((35145883 : ℝ) / 25000000) ((140834093 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((39569419 : ℝ) / 50000000) ((4954989 : ℝ) / 6250000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((152959 : ℝ) / 100000000) ((38309 : ℝ) / 25000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((24961691 : ℝ) / 25000000) ((99847041 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27331281 : ℝ) / 50000000) ((54743563 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((54578799 : ℝ) / 100000000) ((13664957 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((144784279 : ℝ) / 100000000) ((72628773 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((44784279 : ℝ) / 100000000) ((22628773 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((39569419 : ℝ) / 50000000) ((4954989 : ℝ) / 6250000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((1231 : ℝ) / 2500000) ((4933 : ℝ) / 10000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((9995067 : ℝ) / 10000000) ((2498769 : ℝ) / 2500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((10145883 : ℝ) / 25000000) ((40834093 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((5070439 : ℝ) / 12500000) ((40813987 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((193901267 : ℝ) / 100000000) ((97723077 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((293901267 : ℝ) / 100000000) ((147723077 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((220957627 : ℝ) / 100000000) ((223292643 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6769423 : ℝ) / 20000000) ((4253129 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((609 : ℝ) / 80) ((2457 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1002339 : ℝ) / 5000000) ((10109803 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((4883103 : ℝ) / 25000000) ((3940161 : ℝ) / 20000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((29883103 : ℝ) / 25000000) ((23940161 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((47623047 : ℝ) / 50000000) ((11947207 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((90421083 : ℝ) / 50000000) ((90735851 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((63623097 : ℝ) / 100000000) ((6385057 : ℝ) / 10000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((108609 : ℝ) / 100000000) ((109 : ℝ) / 100000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99891 : ℝ) / 100000) ((99891391 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((22580631 : ℝ) / 12500000) ((11329663 : ℝ) / 6250000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((769 : ℝ) / 160) ((3097 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((413303 : ℝ) / 20000000) ((3329 : ℝ) / 160000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((5808451 : ℝ) / 100000000) ((116377 : ℝ) / 2000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((105808451 : ℝ) / 100000000) ((2116377 : ℝ) / 2000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((116895921 : ℝ) / 50000000) ((236285707 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1869861 : ℝ) / 100000000) ((468299 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101869861 : ℝ) / 100000000) ((25468299 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((34480009 : ℝ) / 100000000) ((8665597 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((268271851 : ℝ) / 100000000) ((54189619 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((2771939 : ℝ) / 50000000) ((2818707 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((769 : ℝ) / 160) ((3097 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((29883103 : ℝ) / 12500000) ((23940161 : ℝ) / 10000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((127402371 : ℝ) / 50000000) ((10292707 : ℝ) / 4000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((152287127 : ℝ) / 25000000) ((616022657 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((78020669 : ℝ) / 100000000) ((79439783 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-24819641 : ℝ) / 100000000) ((-23017089 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2272.1 cov_log_2273.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((61010441 : ℝ) / 25000000) ((246145589 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-13882877 : ℝ) / 25000000) ((-26713809 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2168439 : ℝ) / 100000000) ((1399 : ℝ) / 50000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2404071 : ℝ) / 6250000) ((50470087 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-4266593 : ℝ) / 25000000) ((-2957531 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((29883103 : ℝ) / 25000000) ((23940161 : ℝ) / 20000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-24819641 : ℝ) / 100000000) ((-23017089 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-4266593 : ℝ) / 25000000) ((-2957531 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((263 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((5808451 : ℝ) / 100000000) ((116377 : ℝ) / 2000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((2116377 : ℝ) / 4000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((263 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((12949007 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((263 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_57, cov_h_25]
  have hP : ((3880961 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((2957531 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((2957531 : ℝ) / 100000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((263 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_132 {k : ℝ} (hk : RB k ((609 : ℝ) / 160) ((2457 : ℝ) / 640)) :
    RB (k / (k + 1)) ((609 : ℝ) / 769) ((2457 : ℝ) / 3097) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((609 : ℝ) / 769) ((2457 : ℝ) / 3097) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_132 {k : ℝ} (hk : RB k ((609 : ℝ) / 160) ((2457 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_132 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_132 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((45256437 : ℝ) / 100000000)) (ph := ((22668719 : ℝ) / 50000000)) (ml := ((35145883 : ℝ) / 25000000)) (mh := ((140834093 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_132 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_133 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2457 : ℝ) / 3097) ((1239 : ℝ) / 1559))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((45284127 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((45363059 : ℝ) / 100000000) ∧ 0 < certE k a ((14066821 : ℝ) / 10000000) ∧ certE k a ((140915297 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((45284127 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((22607389 : ℝ) / 50000000) ((45214779 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((45284127 : ℝ) / 100000000) ((45284127 : ℝ) / 100000000) ((45284127 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((54715873 : ℝ) / 100000000))
  have h3 : RB z3 ((41317789 : ℝ) / 50000000) ((4131779 : ℝ) / 5000000) := rb_div_signed h2 (show RB ((54715873 : ℝ) / 100000000) ((54715873 : ℝ) / 100000000) ((54715873 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-4768247 : ℝ) / 25000000) ((-2384123 : ℝ) / 12500000) := rb_log h3 (by norm_num) cov_log_2274.1 cov_log_2275.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-15158071 : ℝ) / 100000000) ((-15131521 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((45284127 : ℝ) / 100000000))
  have h6 : RB z6 ((-79221363 : ℝ) / 100000000) ((-79221361 : ℝ) / 100000000) := rb_log (show RB ((45284127 : ℝ) / 100000000) ((45284127 : ℝ) / 100000000) ((45284127 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2276.1 cov_log_2276.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((6406329 : ℝ) / 10000000) ((32044921 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-52777 : ℝ) / 100000000) ((-26221 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((45363059 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((4529371 : ℝ) / 10000000) ((45293711 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((45363059 : ℝ) / 100000000) ((45363059 : ℝ) / 100000000) ((45363059 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((54636941 : ℝ) / 100000000))
  have h12 : RB z12 ((3315977 : ℝ) / 4000000) ((82899427 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((54636941 : ℝ) / 100000000) ((54636941 : ℝ) / 100000000) ((54636941 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-9377103 : ℝ) / 50000000) ((-18754203 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_2277.1 cov_log_2278.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-7452361 : ℝ) / 50000000) ((-1859827 : ℝ) / 12500000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((45363059 : ℝ) / 100000000))
  have h15 : RB z15 ((-79047211 : ℝ) / 100000000) ((-79047209 : ℝ) / 100000000) := rb_log (show RB ((45363059 : ℝ) / 100000000) ((45363059 : ℝ) / 100000000) ((45363059 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2279.1 cov_log_2279.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64142487 : ℝ) / 100000000) ((12833719 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1321 : ℝ) / 5000000) ((13133 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((14066821 : ℝ) / 10000000)) - (z19)
  have h20 : RB z20 ((140598861 : ℝ) / 100000000) ((70299431 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((14066821 : ℝ) / 10000000) ((14066821 : ℝ) / 10000000) ((14066821 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((4066821 : ℝ) / 10000000))
  have h21 : RB z21 ((345721783 : ℝ) / 100000000) ((345721787 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((4066821 : ℝ) / 10000000) ((4066821 : ℝ) / 10000000) ((4066821 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((7752901 : ℝ) / 6250000) ((124046421 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2280.1 cov_log_2281.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((3936481 : ℝ) / 4000000) ((2464617 : ℝ) / 2500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((14066821 : ℝ) / 10000000))
  have h24 : RB z24 ((34123381 : ℝ) / 100000000) ((34123383 : ℝ) / 100000000) := rb_log (show RB ((14066821 : ℝ) / 10000000) ((14066821 : ℝ) / 10000000) ((14066821 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2282.1 cov_log_2282.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((32144321 : ℝ) / 50000000) ((64461299 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((6903 : ℝ) / 4000000) ((86309 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((140915297 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((35211487 : ℝ) / 25000000) ((140845949 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((140915297 : ℝ) / 100000000) ((140915297 : ℝ) / 100000000) ((140915297 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((40915297 : ℝ) / 100000000))
  have h30 : RB z30 ((21514867 : ℝ) / 6250000) ((86059469 : ℝ) / 25000000) := rb_div_signed h29 (show RB ((40915297 : ℝ) / 100000000) ((40915297 : ℝ) / 100000000) ((40915297 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((123616271 : ℝ) / 100000000) ((30904069 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_2283.1 cov_log_2284.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((98070771 : ℝ) / 100000000) ((98242827 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((140915297 : ℝ) / 100000000))
  have h33 : RB z33 ((34298879 : ℝ) / 100000000) ((34298881 : ℝ) / 100000000) := rb_log (show RB ((140915297 : ℝ) / 100000000) ((140915297 : ℝ) / 100000000) ((140915297 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2285.1 cov_log_2285.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((6377189 : ℝ) / 10000000) ((15985987 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-344177 : ℝ) / 100000000) ((-34423 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((45284127 : ℝ) / 100000000)) ((-52777 : ℝ) / 100000000) ((-26221 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((45363059 : ℝ) / 100000000)) ((1321 : ℝ) / 5000000) ((13133 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((14066821 : ℝ) / 10000000)) ((6903 : ℝ) / 4000000) ((86309 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((140915297 : ℝ) / 100000000)) ((-344177 : ℝ) / 100000000) ((-34423 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_133 {k A q d vp vm : ℝ}
    (hk : RB k ((2457 : ℝ) / 640) ((1239 : ℝ) / 320))
    (hA : RB A ((2457 : ℝ) / 3097) ((1239 : ℝ) / 1559))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((45284127 : ℝ) / 100000000) ((45363059 : ℝ) / 100000000))
    (hm : RB vm ((14066821 : ℝ) / 10000000) ((140915297 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((39639911 : ℝ) / 50000000) ((79418909 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((152873 : ℝ) / 100000000) ((76571 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49923429 : ℝ) / 50000000) ((99847127 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((54636941 : ℝ) / 100000000) ((54715873 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((13638317 : ℝ) / 25000000) ((13658057 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((145115483 : ℝ) / 100000000) ((454939 : ℝ) / 312500) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((45115483 : ℝ) / 100000000) ((142439 : ℝ) / 312500) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((39639911 : ℝ) / 50000000) ((79418909 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((12303 : ℝ) / 25000000) ((493 : ℝ) / 1000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((999507 : ℝ) / 1000000) ((24987697 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((4066821 : ℝ) / 10000000) ((40915297 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((254051 : ℝ) / 625000) ((20447581 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((193861127 : ℝ) / 100000000) ((97690657 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((293861127 : ℝ) / 100000000) ((147690657 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1371201 : ℝ) / 625000) ((55413349 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6770909 : ℝ) / 20000000) ((425371 : ℝ) / 1250000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2457 : ℝ) / 320) ((1239 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((20219597 : ℝ) / 100000000) ((20392423 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3940159 : ℝ) / 20000000) ((4967297 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((23940159 : ℝ) / 20000000) ((29967297 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((95305151 : ℝ) / 100000000) ((9563117 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((22619287 : ℝ) / 12500000) ((45393327 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((6370037 : ℝ) / 10000000) ((6392349 : ℝ) / 10000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((21697 : ℝ) / 20000000) ((27217 : ℝ) / 25000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((24972783 : ℝ) / 25000000) ((19978303 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((90378647 : ℝ) / 50000000) ((181376329 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((3097 : ℝ) / 640) ((1559 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((513149 : ℝ) / 25000000) ((2066517 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((580517 : ℝ) / 10000000) ((1453823 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((10580517 : ℝ) / 10000000) ((26453823 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((232128247 : ℝ) / 100000000) ((234543189 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((116799 : ℝ) / 6250000) ((468017 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((6366799 : ℝ) / 6250000) ((25468017 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((34487213 : ℝ) / 100000000) ((34666739 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((13330773 : ℝ) / 5000000) ((33651241 : ℝ) / 12500000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((2736269 : ℝ) / 50000000) ((5563269 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((3097 : ℝ) / 640) ((1559 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((23940159 : ℝ) / 10000000) ((29967297 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((50649341 : ℝ) / 20000000) ((63920769 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((303138319 : ℝ) / 50000000) ((122594091 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((15788893 : ℝ) / 20000000) ((40178647 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-5910639 : ℝ) / 25000000) ((-5467183 : ℝ) / 25000000) := rb_log h47 (by norm_num) cov_log_2286.1 cov_log_2287.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((246145573 : ℝ) / 100000000) ((248249397 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-53427699 : ℝ) / 100000000) ((-5132381 : ℝ) / 10000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1033359 : ℝ) / 50000000) ((1342877 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((7429869 : ℝ) / 20000000) ((49076937 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-8139177 : ℝ) / 50000000) ((-2246873 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((23940159 : ℝ) / 20000000) ((29967297 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-5910639 : ℝ) / 25000000) ((-5467183 : ℝ) / 25000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-8139177 : ℝ) / 50000000) ((-2246873 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((263 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((580517 : ℝ) / 10000000) ((1453823 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((26453823 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((263 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((3531523 : ℝ) / 25000000) ≤ formC0 k A q vp vm + hfun ((263 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_57, cov_h_25]
  have hP : ((1177709 : ℝ) / 20000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((2246873 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((2246873 : ℝ) / 100000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((263 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_133 {k : ℝ} (hk : RB k ((2457 : ℝ) / 640) ((1239 : ℝ) / 320)) :
    RB (k / (k + 1)) ((2457 : ℝ) / 3097) ((1239 : ℝ) / 1559) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2457 : ℝ) / 3097) ((1239 : ℝ) / 1559) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_133 {k : ℝ} (hk : RB k ((2457 : ℝ) / 640) ((1239 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_133 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_133 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((45284127 : ℝ) / 100000000)) (ph := ((45363059 : ℝ) / 100000000)) (ml := ((14066821 : ℝ) / 10000000)) (mh := ((140915297 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_133 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_134 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1239 : ℝ) / 1559) ((2499 : ℝ) / 3139))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((45311101 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((22694021 : ℝ) / 50000000) ∧ 0 < certE k a ((70375853 : ℝ) / 50000000) ∧ certE k a ((140995391 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((45311101 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((5655219 : ℝ) / 12500000) ((45241753 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((45311101 : ℝ) / 100000000) ((45311101 : ℝ) / 100000000) ((45311101 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((54688899 : ℝ) / 100000000))
  have h3 : RB z3 ((41362829 : ℝ) / 50000000) ((82725661 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((54688899 : ℝ) / 100000000) ((54688899 : ℝ) / 100000000) ((54688899 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-9482019 : ℝ) / 50000000) ((-9482017 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_2288.1 cov_log_2289.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-603901 : ℝ) / 4000000) ((-376787 : ℝ) / 2500000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((45311101 : ℝ) / 100000000))
  have h6 : RB z6 ((-39580907 : ℝ) / 50000000) ((-19790453 : ℝ) / 25000000) := rb_log (show RB ((45311101 : ℝ) / 100000000) ((45311101 : ℝ) / 100000000) ((45311101 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2290.1 cov_log_2290.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((64064287 : ℝ) / 100000000) ((32045167 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-2589 : ℝ) / 5000000) ((-25729 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((22694021 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((45318693 : ℝ) / 100000000) ((22659347 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((22694021 : ℝ) / 50000000) ((22694021 : ℝ) / 50000000) ((22694021 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((27305979 : ℝ) / 50000000))
  have h12 : RB z12 ((16596619 : ℝ) / 20000000) ((82983097 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((27305979 : ℝ) / 50000000) ((27305979 : ℝ) / 50000000) ((27305979 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-1165833 : ℝ) / 6250000) ((-4663331 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_2291.1 cov_log_2292.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-2970033 : ℝ) / 20000000) ((-7412273 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((22694021 : ℝ) / 50000000))
  have h15 : RB z15 ((-9874019 : ℝ) / 12500000) ((-1579843 : ℝ) / 2000000) := rb_log (show RB ((22694021 : ℝ) / 50000000) ((22694021 : ℝ) / 50000000) ((22694021 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2293.1 cov_log_2293.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((12828397 : ℝ) / 20000000) ((32083803 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((12959 : ℝ) / 50000000) ((51543 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((70375853 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((140682357 : ℝ) / 100000000) ((70341179 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((70375853 : ℝ) / 50000000) ((70375853 : ℝ) / 50000000) ((70375853 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((20375853 : ℝ) / 50000000))
  have h21 : RB z21 ((13808733 : ℝ) / 4000000) ((43152291 : ℝ) / 12500000) := rb_div_signed h20 (show RB ((20375853 : ℝ) / 50000000) ((20375853 : ℝ) / 50000000) ((20375853 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((24780137 : ℝ) / 20000000) ((123900689 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_2294.1 cov_log_2295.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((98468857 : ℝ) / 100000000) ((98639001 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((70375853 : ℝ) / 50000000))
  have h24 : RB z24 ((106821 : ℝ) / 312500) ((17091361 : ℝ) / 50000000) := rb_log (show RB ((70375853 : ℝ) / 50000000) ((70375853 : ℝ) / 50000000) ((70375853 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2296.1 cov_log_2296.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((12857227 : ℝ) / 20000000) ((64456281 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((42517 : ℝ) / 25000000) ((170109 : ℝ) / 50000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((140995391 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((70463021 : ℝ) / 50000000) ((140926043 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((140995391 : ℝ) / 100000000) ((140995391 : ℝ) / 100000000) ((140995391 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((40995391 : ℝ) / 100000000))
  have h30 : RB z30 ((343760697 : ℝ) / 100000000) ((3437607 : ℝ) / 1000000) := rb_div_signed h29 (show RB ((40995391 : ℝ) / 100000000) ((40995391 : ℝ) / 100000000) ((40995391 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((123477557 : ℝ) / 100000000) ((123477561 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_2297.1 cov_log_2298.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((4906629 : ℝ) / 5000000) ((98302143 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((140995391 : ℝ) / 100000000))
  have h33 : RB z33 ((34355701 : ℝ) / 100000000) ((34355703 : ℝ) / 100000000) := rb_log (show RB ((140995391 : ℝ) / 100000000) ((140995391 : ℝ) / 100000000) ((140995391 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_2299.1 cov_log_2299.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((63776877 : ℝ) / 100000000) ((31973221 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-33919 : ℝ) / 10000000) ((-169621 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((45311101 : ℝ) / 100000000)) ((-2589 : ℝ) / 5000000) ((-25729 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((22694021 : ℝ) / 50000000)) ((12959 : ℝ) / 50000000) ((51543 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((70375853 : ℝ) / 50000000)) ((42517 : ℝ) / 25000000) ((170109 : ℝ) / 50000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((140995391 : ℝ) / 100000000)) ((-33919 : ℝ) / 10000000) ((-169621 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_134 {k A q d vp vm : ℝ}
    (hk : RB k ((1239 : ℝ) / 320) ((2499 : ℝ) / 640))
    (hA : RB A ((1239 : ℝ) / 1559) ((2499 : ℝ) / 3139))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((45311101 : ℝ) / 100000000) ((22694021 : ℝ) / 50000000))
    (hm : RB vm ((70375853 : ℝ) / 50000000) ((140995391 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((79418907 : ℝ) / 100000000) ((79556133 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((152789 : ℝ) / 100000000) ((153051 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99846949 : ℝ) / 100000000) ((99847211 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((27305979 : ℝ) / 50000000) ((54688899 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((54528373 : ℝ) / 100000000) ((54605341 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((72720823 : ℝ) / 50000000) ((145898601 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((22720823 : ℝ) / 50000000) ((45898601 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((79418907 : ℝ) / 100000000) ((79556133 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((1537 : ℝ) / 3125000) ((49271 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99950729 : ℝ) / 100000000) ((3123463 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((20375853 : ℝ) / 50000000) ((40995391 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((40731627 : ℝ) / 100000000) ((10243807 : ℝ) / 25000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((193821757 : ℝ) / 100000000) ((97658919 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((293821757 : ℝ) / 100000000) ((147658919 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((54467891 : ℝ) / 25000000) ((55015613 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((33861821 : ℝ) / 100000000) ((106357 : ℝ) / 312500) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1239 : ℝ) / 160) ((2499 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((10196207 : ℝ) / 50000000) ((514131 : ℝ) / 2500000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((9934589 : ℝ) / 50000000) ((20037571 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((59934589 : ℝ) / 50000000) ((120037571 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((5960229 : ℝ) / 6250000) ((9568429 : ℝ) / 10000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((90532697 : ℝ) / 50000000) ((90837083 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((63776147 : ℝ) / 100000000) ((7999381 : ℝ) / 12500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((27091 : ℝ) / 25000000) ((108739 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99891261 : ℝ) / 100000000) ((24972909 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((36173701 : ℝ) / 20000000) ((181477297 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1559 : ℝ) / 320) ((3139 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((407773 : ℝ) / 20000000) ((2052599 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((232079 : ℝ) / 4000000) ((581183 : ℝ) / 10000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((4232079 : ℝ) / 4000000) ((10581183 : ℝ) / 10000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((230512417 : ℝ) / 100000000) ((58213027 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((933861 : ℝ) / 50000000) ((935479 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50933861 : ℝ) / 50000000) ((50935479 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((6898853 : ℝ) / 20000000) ((34671007 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((132503341 : ℝ) / 50000000) ((53504623 : ℝ) / 20000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((675391 : ℝ) / 12500000) ((5491177 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1559 : ℝ) / 320) ((3139 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((59934589 : ℝ) / 25000000) ((120037571 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((50346677 : ℝ) / 20000000) ((63524173 : ℝ) / 25000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((301750739 : ℝ) / 50000000) ((122004599 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((4991487 : ℝ) / 6250000) ((40635257 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-22484761 : ℝ) / 100000000) ((-20738691 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_2300.1 cov_log_2301.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((248249381 : ℝ) / 100000000) ((125176603 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-51323891 : ℝ) / 100000000) ((-49220001 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((7863 : ℝ) / 400000) ((2574543 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((559349 : ℝ) / 1562500) ((23824561 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-3105111 : ℝ) / 20000000) ((-1570879 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((59934589 : ℝ) / 50000000) ((120037571 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-22484761 : ℝ) / 100000000) ((-20738691 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-3105111 : ℝ) / 20000000) ((-1570879 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((263 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((232079 : ℝ) / 4000000) ((581183 : ℝ) / 10000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((10581183 : ℝ) / 20000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((263 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((15283887 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((263 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_57, cov_h_25]
  have hP : ((4111143 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((1570879 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((1570879 : ℝ) / 100000000))
    linarith [hap.2]
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  have hcell := hQQ
  exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((263 : ℝ) / 100)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
theorem cov_params_134 {k : ℝ} (hk : RB k ((1239 : ℝ) / 320) ((2499 : ℝ) / 640)) :
    RB (k / (k + 1)) ((1239 : ℝ) / 1559) ((2499 : ℝ) / 3139) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1239 : ℝ) / 1559) ((2499 : ℝ) / 3139) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_134 {k : ℝ} (hk : RB k ((1239 : ℝ) / 320) ((2499 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_134 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_134 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((45311101 : ℝ) / 100000000)) (ph := ((22694021 : ℝ) / 50000000)) (ml := ((70375853 : ℝ) / 50000000)) (mh := ((140995391 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_134 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
