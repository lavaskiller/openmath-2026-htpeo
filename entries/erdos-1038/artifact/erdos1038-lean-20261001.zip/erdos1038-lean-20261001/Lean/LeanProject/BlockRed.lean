import LeanProject.RefDensities

/-!
# EP-1038, Stage 12, Proposition 12.5 (block reduction), steps 2–4

Abstract form. For finitely many blocks `i` with masses `q_i, r_i > 0`, radii `R_i > 0` and block
energies `𝓔_i`, suppose

* (step 1, integrated pointwise bound, Lemma 12.4) `∫_{I_i} g dξ̂ ≥ r_i(-q_i log R_i - C - q_i) + 𝓔_i`;
* (Theorem 12.4, the supporting inequality) `M_k ≥ M_0 + ∑_i ∫_{I_i} g dξ̂`;
* (12.4) for every block: `𝓔_i ≥ q_i r_i log(q_i r_i/2) + C_eff r_i`;
* `∑_i r_i = R_ξ > 0` and `C_eff = C + (L - M_0)/R_ξ`.

Then `𝒥_k = M_k + 2 ∑_i R_i ≥ L` (`block_reduction`), strictly if (12.4) is strict for some block
(`block_reduction_strict`). The key step is the minimisation `-a log y + 2y ≥ -a log(a/2) + a`
(`xi_min`).
-/

open Real Finset

namespace EP1038.Arc

/-- `-a log y + 2y ≥ -a log(a/2) + a` for `a, y > 0` (minimum at `y = a/2`). -/
theorem xi_min {a y : ℝ} (ha : 0 < a) (hy : 0 < y) :
    -a * Real.log (a / 2) + a ≤ -a * Real.log y + 2 * y := by
  have ht : 0 < 2 * y / a := by positivity
  have h := Real.log_le_sub_one_of_pos ht
  have e : Real.log (2 * y / a) = Real.log y - Real.log (a / 2) := by
    rw [show 2 * y / a = y / (a / 2) by field_simp, Real.log_div hy.ne' (by positivity)]
  rw [e] at h
  have h2 : a * (Real.log y - Real.log (a / 2)) ≤ a * (2 * y / a - 1) :=
    mul_le_mul_of_nonneg_left h ha.le
  have h3 : a * (2 * y / a - 1) = 2 * y - a := by field_simp
  linarith

/-- **Proposition 12.5**, steps 2–4 (abstract form). -/
theorem block_reduction {ι : Type*} (s : Finset ι) (q r R E Ig : ι → ℝ) {M0 Mk C Ceff L Rxi : ℝ}
    (hq : ∀ i ∈ s, 0 < q i) (hr : ∀ i ∈ s, 0 < r i) (hR : ∀ i ∈ s, 0 < R i)
    (hIg : ∀ i ∈ s, r i * (-q i * Real.log (R i) - C - q i) + E i ≤ Ig i)
    (hM : M0 + ∑ i ∈ s, Ig i ≤ Mk)
    (h84 : ∀ i ∈ s, q i * r i * Real.log (q i * r i / 2) + Ceff * r i ≤ E i)
    (hsum : ∑ i ∈ s, r i = Rxi) (hRxi : 0 < Rxi) (hCeff : Ceff = C + (L - M0) / Rxi) :
    L ≤ Mk + 2 * ∑ i ∈ s, R i := by
  -- per block: `Ig i + 2 R_i ≥ (C_eff - C) r_i`
  have hblock : ∀ i ∈ s, (Ceff - C) * r i ≤ Ig i + 2 * R i := by
    intro i hi
    have hmin := xi_min (mul_pos (hq i hi) (hr i hi)) (hR i hi)
    have h1 := hIg i hi
    have h2 := h84 i hi
    nlinarith [hmin]
  have hs := Finset.sum_le_sum hblock
  rw [← Finset.mul_sum, hsum, Finset.sum_add_distrib, ← Finset.mul_sum] at hs
  have hC : (Ceff - C) * Rxi = L - M0 := by
    rw [hCeff]
    field_simp
    ring
  linarith

/-- **Proposition 12.5**, strict form: if (12.4) is strict for one block, then `𝒥_k > L`. -/
theorem block_reduction_strict {ι : Type*} (s : Finset ι) (q r R E Ig : ι → ℝ)
    {M0 Mk C Ceff L Rxi : ℝ}
    (hq : ∀ i ∈ s, 0 < q i) (hr : ∀ i ∈ s, 0 < r i) (hR : ∀ i ∈ s, 0 < R i)
    (hIg : ∀ i ∈ s, r i * (-q i * Real.log (R i) - C - q i) + E i ≤ Ig i)
    (hM : M0 + ∑ i ∈ s, Ig i ≤ Mk)
    (h84 : ∀ i ∈ s, q i * r i * Real.log (q i * r i / 2) + Ceff * r i ≤ E i)
    {j : ι} (hj : j ∈ s) (h84j : q j * r j * Real.log (q j * r j / 2) + Ceff * r j < E j)
    (hsum : ∑ i ∈ s, r i = Rxi) (hRxi : 0 < Rxi) (hCeff : Ceff = C + (L - M0) / Rxi) :
    L < Mk + 2 * ∑ i ∈ s, R i := by
  have hblock : ∀ i ∈ s, (Ceff - C) * r i ≤ Ig i + 2 * R i := by
    intro i hi
    have hmin := xi_min (mul_pos (hq i hi) (hr i hi)) (hR i hi)
    have h1 := hIg i hi
    have h2 := h84 i hi
    nlinarith [hmin]
  have hblockj : (Ceff - C) * r j < Ig j + 2 * R j := by
    have hmin := xi_min (mul_pos (hq j hj) (hr j hj)) (hR j hj)
    have h1 := hIg j hj
    nlinarith [hmin]
  have hs := Finset.sum_lt_sum hblock ⟨j, hj, hblockj⟩
  rw [← Finset.mul_sum, hsum, Finset.sum_add_distrib, ← Finset.mul_sum] at hs
  have hC : (Ceff - C) * Rxi = L - M0 := by
    rw [hCeff]
    field_simp
    ring
  linarith

end EP1038.Arc
