import LeanProject.ArcMass

/-!
# EP-1038, Stage 12, Lemma 12.7(c), (d): the diagonal arc energy and `h`

* `Kl1_eq`: `K(u) = log(2|sin(u/2)|)` for every `u`; `Kl1_ii`: `K` is integrable on every interval.
* `Fp x = ∫_0^x K`; `Fp_odd`; `inner_eq`, `double_eq`:
  `∫_{-Q}^{Q} ∫_{-Q}^{Q} K(θ - φ) = 2 ∫_0^{2Q} Fp`.
* `int_Fp` (integration by parts, `0 ≤ a ≤ 2π`): `∫_0^a Fp = ∫_0^a (a - t) K(t) dt`.
* `AE_diag` (**Lemma 12.7(c)**, first formula): `𝒜(Q, Q) = 2 ∫_0^1 (1 - x) log(2 sin(Qx)) dx`
  for `0 < Q ≤ π`.
* `hfun X = 𝒜(X, X) - log(X/π)`; `hfun_eq`: `h(X) = log π + 2 ∫_0^1 (1 - x)(K(2Xx) - log X) dx`;
  `hfun_anti` (**Lemma 12.7(d)**, monotonicity): `h` is nonincreasing on `(0, π]`;
  `hfun_pi`: `h(π) = 0`; `hfun_nonneg`: `h ≥ 0` on `(0, π]`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- `K(u) = log(2|sin(u/2)|)` for every `u` (both sides are `log 0 = 0` on `2πℤ`). -/
theorem Kl1_eq (u : ℝ) : Kl 1 u = Real.log (2 * |Real.sin (u / 2)|) := by
  unfold Kl
  rw [norm_one_sub_exp]

theorem Kl1_fun : Kl 1 = fun u => Real.log (2 * |Real.sin (u / 2)|) := funext Kl1_eq

theorem Kl1_measurable : Measurable (Kl 1) := by
  rw [Kl1_fun]
  exact Real.measurable_log.comp
    ((continuous_const.mul (Real.continuous_sin.comp (continuous_id.div_const 2)).abs).measurable)

theorem Kl1_even (u : ℝ) : Kl 1 (-u) = Kl 1 u := by
  rw [Kl1_eq, Kl1_eq, neg_div, Real.sin_neg, abs_neg]

theorem Kl1_ii (a b : ℝ) : IntervalIntegrable (Kl 1) volume a b := by
  refine IntervalIntegrable.mono_fun' (g := fun u => Real.log 2 + Circ.Lsin u)
    (intervalIntegrable_const.add (Lsin_ii' a b)) Kl1_measurable.aestronglyMeasurable ?_
  refine ae_restrict_of_ae ?_
  filter_upwards [Circ.ae_sin_ne 0] with u hu
  have hu' : Real.sin (u / 2) ≠ 0 := by
    rwa [zero_sub, neg_div, Real.sin_neg, neg_ne_zero] at hu
  show ‖Kl 1 u‖ ≤ Real.log 2 + Circ.Lsin u
  rw [Real.norm_eq_abs, Kl_one_eq hu', abs_le]
  have h0 := Circ.Lsin_nonneg u
  have h2 : 0 < Real.log 2 := Real.log_pos one_lt_two
  constructor <;> linarith

theorem Kl1_contAt {x : ℝ} (h0 : 0 < x) (h1 : x < 2 * π) : ContinuousAt (Kl 1) x := by
  rw [Kl1_fun]
  have hs : 0 < Real.sin (x / 2) := Real.sin_pos_of_pos_of_lt_pi (by linarith) (by linarith)
  have hc : Continuous (fun u : ℝ => 2 * |Real.sin (u / 2)|) :=
    continuous_const.mul (Real.continuous_sin.comp (continuous_id.div_const 2)).abs
  exact hc.continuousAt.log (show 2 * |Real.sin (x / 2)| ≠ 0 by rw [abs_of_pos hs]; positivity)

/-- The primitive `Fp x = ∫_0^x K`. -/
noncomputable def Fp (x : ℝ) : ℝ := ∫ t in (0 : ℝ)..x, Kl 1 t

theorem Fp_cont : Continuous Fp := intervalIntegral.continuous_primitive Kl1_ii 0

theorem Fp_odd (x : ℝ) : Fp (-x) = -Fp x := by
  have h := intervalIntegral.integral_comp_neg (a := 0) (b := x) (f := Kl 1)
  simp only [Kl1_even, neg_zero] at h
  unfold Fp
  rw [intervalIntegral.integral_symm (-x) 0, ← h]

theorem inner_eq (θ Q : ℝ) : ∫ φ in (-Q)..Q, Kl 1 (θ - φ) = Fp (θ + Q) - Fp (θ - Q) := by
  rw [intervalIntegral.integral_comp_sub_left (Kl 1) θ, sub_neg_eq_add]
  unfold Fp
  rw [intervalIntegral.integral_interval_sub_left (Kl1_ii _ _) (Kl1_ii _ _)]

theorem double_eq (Q : ℝ) :
    ∫ θ in (-Q)..Q, ∫ φ in (-Q)..Q, Kl 1 (θ - φ) = 2 * ∫ s in (0 : ℝ)..(2 * Q), Fp s := by
  simp_rw [inner_eq]
  have hA : Continuous (fun θ => Fp (θ + Q)) := Fp_cont.comp (continuous_id.add continuous_const)
  have hB : Continuous (fun θ => Fp (θ - Q)) := Fp_cont.comp (continuous_sub_right Q)
  rw [intervalIntegral.integral_sub (hA.intervalIntegrable _ _) (hB.intervalIntegrable _ _)]
  rw [intervalIntegral.integral_comp_add_right Fp Q, intervalIntegral.integral_comp_sub_right Fp Q]
  have e1 : -Q + Q = 0 := by ring
  have e2 : Q + Q = 2 * Q := by ring
  have e3 : -Q - Q = -(2 * Q) := by ring
  have e4 : Q - Q = 0 := by ring
  rw [e1, e2, e3, e4]
  have hneg : ∫ x in -(2 * Q)..0, Fp x = -∫ x in (0 : ℝ)..(2 * Q), Fp x := by
    have h := intervalIntegral.integral_comp_neg (a := 0) (b := 2 * Q) (f := Fp)
    simp only [Fp_odd, neg_zero, intervalIntegral.integral_neg] at h
    linarith
  rw [hneg]
  ring

/-- Integration by parts: `∫_0^a Fp = ∫_0^a (a - t) K(t) dt` for `0 ≤ a ≤ 2π`. -/
theorem int_Fp {a : ℝ} (ha0 : 0 ≤ a) (ha : a ≤ 2 * π) :
    ∫ s in (0 : ℝ)..a, Fp s = ∫ t in (0 : ℝ)..a, (a - t) * Kl 1 t := by
  have hu : ∀ x ∈ Ioo (min 0 a) (max 0 a), HasDerivAt Fp (Kl 1 x) x := by
    intro x hx
    rw [min_eq_left ha0, max_eq_right ha0] at hx
    show HasDerivAt (fun u => ∫ t in (0 : ℝ)..u, Kl 1 t) (Kl 1 x) x
    exact intervalIntegral.integral_hasDerivAt_right (Kl1_ii 0 x)
      Kl1_measurable.stronglyMeasurable.stronglyMeasurableAtFilter
      (Kl1_contAt hx.1 (by linarith [hx.2]))
  have hv : ∀ x ∈ Ioo (min 0 a) (max 0 a), HasDerivAt (fun s : ℝ => s - a) 1 x := by
    intro x _
    simpa using (hasDerivAt_id x).sub_const a
  have hvc : Continuous (fun s : ℝ => s - a) := continuous_sub_right a
  have h := intervalIntegral.integral_mul_deriv_eq_deriv_mul_of_hasDerivAt
    Fp_cont.continuousOn hvc.continuousOn hu hv
    (Kl1_ii 0 a) (intervalIntegrable_const (c := (1 : ℝ)))
  have hF0 : Fp 0 = 0 := by simp [Fp]
  simp only [mul_one, sub_self, mul_zero, hF0, zero_mul, zero_sub] at h
  have key : ∫ t in (0 : ℝ)..a, (a - t) * Kl 1 t = -∫ t in (0 : ℝ)..a, Kl 1 t * (t - a) := by
    rw [← intervalIntegral.integral_neg]
    congr 1
    funext t
    ring
  rw [key]
  linarith [h]

/-- The change of variables `t = 2Qx`. -/
theorem int_sub {Q : ℝ} (hQ : 0 < Q) :
    ∫ t in (0 : ℝ)..(2 * Q), (2 * Q - t) * Kl 1 t =
      4 * Q ^ 2 * ∫ x in (0 : ℝ)..1, (1 - x) * Kl 1 (2 * Q * x) := by
  have hc : 2 * Q ≠ 0 := (by linarith : (0 : ℝ) < 2 * Q).ne'
  have hQ0 := hQ.ne'
  have h := intervalIntegral.integral_comp_mul_left (fun t => (2 * Q - t) * Kl 1 t) hc
    (a := 0) (b := 1)
  simp only [mul_zero, mul_one, smul_eq_mul] at h
  have e : ∫ x in (0 : ℝ)..1, (1 - x) * Kl 1 (2 * Q * x) =
      (2 * Q)⁻¹ * ∫ x in (0 : ℝ)..1, (2 * Q - 2 * Q * x) * Kl 1 (2 * Q * x) := by
    rw [← intervalIntegral.integral_const_mul]
    congr 1
    funext x
    field_simp
    try ring
  rw [e, h]
  field_simp
  try ring

/-- `𝒜(Q, Q) = 2 ∫_0^1 (1 - x) K(2Qx) dx` for `0 < Q ≤ π`. -/
theorem AE_diag_K {Q : ℝ} (hQ : 0 < Q) (hQπ : Q ≤ π) :
    AE Q Q = 2 * ∫ x in (0 : ℝ)..1, (1 - x) * Kl 1 (2 * Q * x) := by
  have hQ0 := hQ.ne'
  unfold AE
  rw [double_eq, int_Fp (by linarith) (by linarith), int_sub hQ]
  field_simp
  try ring

/-- **Lemma 12.7(c)**: `𝒜(Q, Q) = 2 ∫_0^1 (1 - x) log(2 sin(Qx)) dx` for `0 < Q ≤ π`. -/
theorem AE_diag {Q : ℝ} (hQ : 0 < Q) (hQπ : Q ≤ π) :
    AE Q Q = 2 * ∫ x in (0 : ℝ)..1, (1 - x) * Real.log (2 * Real.sin (Q * x)) := by
  rw [AE_diag_K hQ hQπ]
  congr 1
  refine intervalIntegral.integral_congr (fun x hx => ?_)
  rw [uIcc_of_le zero_le_one] at hx
  show (1 - x) * Kl 1 (2 * Q * x) = (1 - x) * Real.log (2 * Real.sin (Q * x))
  have h0 : 0 ≤ Q * x := mul_nonneg hQ.le hx.1
  have h1 : Q * x ≤ π := by nlinarith [hx.2]
  rw [Kl1_eq, show 2 * Q * x / 2 = Q * x by ring,
    abs_of_nonneg (Real.sin_nonneg_of_nonneg_of_le_pi h0 h1)]

/-- `h(X) = 𝒜(X, X) - log(X/π)`. -/
noncomputable def hfun (X : ℝ) : ℝ := AE X X - Real.log (X / π)

theorem ii_term {X : ℝ} (hX : 0 < X) :
    IntervalIntegrable (fun x => (1 - x) * (Kl 1 (2 * X * x) - Real.log X)) volume 0 1 := by
  have hc : 2 * X ≠ 0 := (by linarith : (0 : ℝ) < 2 * X).ne'
  have h1 : IntervalIntegrable (fun x => Kl 1 (2 * X * x)) volume 0 1 := by
    have := (Kl1_ii 0 (2 * X)).comp_mul_left (c := 2 * X)
    rwa [zero_div, div_self hc] at this
  exact (h1.sub intervalIntegrable_const).continuousOn_mul
    (continuous_const.sub continuous_id).continuousOn

theorem hfun_eq {X : ℝ} (hX : 0 < X) (hXπ : X ≤ π) :
    hfun X = Real.log π + 2 * ∫ x in (0 : ℝ)..1, (1 - x) * (Kl 1 (2 * X * x) - Real.log X) := by
  have hc : 2 * X ≠ 0 := (by linarith : (0 : ℝ) < 2 * X).ne'
  have h1 : IntervalIntegrable (fun x => (1 - x) * Kl 1 (2 * X * x)) volume 0 1 := by
    have := (Kl1_ii 0 (2 * X)).comp_mul_left (c := 2 * X)
    rw [zero_div, div_self hc] at this
    exact this.continuousOn_mul (continuous_const.sub continuous_id).continuousOn
  have h2 : IntervalIntegrable (fun x : ℝ => Real.log X * (1 - x)) volume 0 1 :=
    (continuous_const.mul (continuous_const.sub continuous_id)).intervalIntegrable _ _
  have hlin : ∫ x in (0 : ℝ)..1, (1 - x) = 1 / 2 := by
    have hid : IntervalIntegrable (fun x : ℝ => x) volume 0 1 := continuous_id.intervalIntegrable 0 1
    rw [intervalIntegral.integral_sub intervalIntegrable_const hid]
    simp
    norm_num
  have e : ∀ x : ℝ, (1 - x) * (Kl 1 (2 * X * x) - Real.log X) =
      (1 - x) * Kl 1 (2 * X * x) - Real.log X * (1 - x) := fun x => by ring
  simp_rw [e]
  rw [intervalIntegral.integral_sub h1 h2, intervalIntegral.integral_const_mul, hlin]
  unfold hfun
  rw [AE_diag_K hX hXπ, Real.log_div hX.ne' Real.pi_pos.ne']
  ring

/-- **Lemma 12.7(d)**, monotonicity: `h` is nonincreasing on `(0, π]`. -/
theorem hfun_anti {X Y : ℝ} (hX : 0 < X) (hXY : X ≤ Y) (hYπ : Y ≤ π) : hfun Y ≤ hfun X := by
  have hY : 0 < Y := hX.trans_le hXY
  rw [hfun_eq hY hYπ, hfun_eq hX (hXY.trans hYπ)]
  have hmono := intervalIntegral.integral_mono_on zero_le_one (ii_term hY) (ii_term hX)
    (fun x hx => ?_)
  · linarith
  rcases eq_or_lt_of_le hx.1 with h0 | h0
  · -- x = 0
    subst h0
    simp only [mul_zero, sub_zero, one_mul]
    rw [Kl1_eq, zero_div, Real.sin_zero, abs_zero, mul_zero, Real.log_zero, zero_sub, zero_sub,
      neg_le_neg_iff]
    exact Real.log_le_log hX hXY
  rcases eq_or_lt_of_le hx.2 with h1 | h1
  · -- x = 1
    subst h1
    simp
  -- 0 < x < 1
  have hYx : 0 < Y * x := mul_pos hY h0
  have hYxπ : Y * x < π := by nlinarith
  have hXx : 0 < X * x := mul_pos hX h0
  have hXxπ : X * x < π := by nlinarith
  have hsY : 0 < Real.sin (Y * x) := Real.sin_pos_of_pos_of_lt_pi hYx hYxπ
  have hsX : 0 < Real.sin (X * x) := Real.sin_pos_of_pos_of_lt_pi hXx hXxπ
  have hconc : X / Y * Real.sin (Y * x) ≤ Real.sin (X * x) := by
    have := strictConcaveOn_sin_Icc.concaveOn.2 (⟨hYx.le, hYxπ.le⟩ : Y * x ∈ Icc 0 π)
      (⟨le_refl 0, Real.pi_pos.le⟩ : (0 : ℝ) ∈ Icc 0 π) (div_nonneg hX.le hY.le)
      (by rw [sub_nonneg, div_le_one hY]; exact hXY) (by ring : X / Y + (1 - X / Y) = 1)
    simp only [smul_eq_mul, Real.sin_zero, mul_zero, add_zero] at this
    have hY0 := hY.ne'
    have e : X / Y * (Y * x) = X * x := by field_simp
    rwa [e] at this
  rw [div_mul_eq_mul_div, div_le_iff₀ hY] at hconc
  have key : Kl 1 (2 * Y * x) - Real.log Y ≤ Kl 1 (2 * X * x) - Real.log X := by
    rw [Kl1_eq, Kl1_eq, show 2 * Y * x / 2 = Y * x by ring, show 2 * X * x / 2 = X * x by ring,
      abs_of_pos hsY, abs_of_pos hsX, ← Real.log_div (by positivity) hY.ne',
      ← Real.log_div (by positivity) hX.ne']
    apply Real.log_le_log (div_pos (by linarith) hY)
    rw [div_le_div_iff₀ hY hX]
    linarith
  exact mul_le_mul_of_nonneg_left key (by linarith)

/-- `h(π) = 0`. -/
theorem hfun_pi : hfun π = 0 := by
  unfold hfun
  rw [div_self Real.pi_ne_zero, Real.log_one, sub_zero, AE_series Real.pi_pos Real.pi_pos]
  have h : ∀ n : ℕ, xs n π * xs n π / ((n : ℝ) + 1) = 0 := by
    intro n
    unfold xs
    rw [show ((n : ℝ) + 1) * π = ((n + 1 : ℕ) : ℝ) * π by norm_num, Real.sin_nat_mul_pi]
    simp
  rw [tsum_congr h, tsum_zero, neg_zero]

/-- **Lemma 12.7(d)**: `h ≥ 0` on `(0, π]`. -/
theorem hfun_nonneg {X : ℝ} (hX : 0 < X) (hXπ : X ≤ π) : 0 ≤ hfun X := by
  have := hfun_anti hX hXπ le_rfl
  rw [hfun_pi] at this
  exact this

end EP1038.Arc
